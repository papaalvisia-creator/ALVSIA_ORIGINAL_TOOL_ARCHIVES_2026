do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(144, 242, 18, 184, 1)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(144, 242, 26, 174, 28, 74, 237, 197, 144, 10, 117, 87, 136, 6, 183, 109, 98, 195, 102, 140, 237, 124, 216, 182, 162, 17, 116, 94, 145, 44, 131, 110, 96, 219))), nil, {
  ["_OnRecvChatMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ and _ARG_3_.content and _ARG_3_.content and _ARG_3_.content.msgType == require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 111, 148, 224, 108, 202, 199, 140, 22, 113, 95, 211, 42, 169, 110, 103, 225, 126, 138, 241, 108, 204))).friendComebackMsgType then
        if not tonumber(_ARG_3_.sender_uid) then
          return
        end
        if not (require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerChatCache) or {})[tonumber(_ARG_3_.sender_uid)] then
          ;(require((table.concat({
            U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
            U1(128)
          }))).LoadFileToTable_N(require((table.concat({
            U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
            U1(128)
          }))).ePlayerPrefsType.eReturnPlayerChatCache) or {})[tonumber(_ARG_3_.sender_uid)] = {}
        end
        ;(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerChatCache) or {})[tonumber(_ARG_3_.sender_uid)][_ARG_3_.content.sendTime] = _ARG_3_.content.other
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChatMsgCache"] = function(_ARG_0_, _ARG_1_)
    do
      if not tonumber(_ARG_1_.sender_uid) or not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerChatCache) or {})[tonumber(_ARG_1_.sender_uid)] then
        return nil
      end
      if not (_ARG_1_.content and _ARG_1_.content.sendTime or _ARG_1_.send_time) or not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerChatCache) or {})[tonumber(_ARG_1_.sender_uid)][_ARG_1_.content and _ARG_1_.content.sendTime or _ARG_1_.send_time] then
        return nil
      end
      do return (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerChatCache) or {})[tonumber(_ARG_1_.sender_uid)][_ARG_1_.content and _ARG_1_.content.sendTime or _ARG_1_.send_time] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[140]
      _ARG_1_ = U1[53]
    end
  end,
  ["OnLogin"] = function(_ARG_0_)
    do
      _ARG_0_:_InstallJumpCancelHook()
      _ARG_0_:ReqGetTaskList()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogOut"] = function(_ARG_0_)
    do
      _ARG_0_:_CancelGuideMatch()
      _ARG_0_._watchingGuideMatch = false
      _ARG_0_:_UninstallJumpCancelHook()
      _ENV()
      if _ARG_0_.TeamUpGuideTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.TeamUpGuideTimer)
        _ARG_0_.TeamUpGuideTimer = nil
      end
      _ARG_0_:StopActExpireTimer()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_ROLEINFO, EVENTID_CUMULATIVE_ROLEINFO_INTERACT_RECORD, _ARG_0_.OnInteractRecordRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_FB_SLAP, _ARG_0_.ShowFBUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURNACTIVITY_FIRST_GAME, _ARG_0_.OnPostSwitchShowFBUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_SIGN_SLAP, _ARG_0_.ShowSignRewardUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_RECHARGE_REBATE_SLAP, _ARG_0_.ShowRebateUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CHAT, EVENTID_ON_RECV_CHATMSG, _ARG_0_._OnRecvChatMsg, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_GUIDE_SLAP, _ARG_0_.ShowGuideUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_RECOMMEND_PANEL, _ARG_0_.ShowRecFriendUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_FB_GUIDE_SLAP, _ARG_0_.ShowFBGuideUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_RETURN_MODE_SELECT_SLAP, _ARG_0_.ShowModeSelectUI, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 252, 246, 191, 12, 117, 120, 138, 32, 181, 108, 123, 249, 114, 134, 247, 77, 215, 233),
        U1(135, 235, 0, 235, 2, 76, 166, 251, 139, 15, 116, 94, 182, 124, 162, 66, 35, 192, 102, 131, 246, 93, 199, 249, 155, 27, 75, 14, 142, 20)
      }), _ARG_1_, _ARG_2_))
      if _ARG_2_ == GameStatus.Fighting and not GameStatus.IsInMainCity() then
        if _ARG_0_.TeamUpGuideTimer then
          _ARG_0_:RemoveTimer(_ARG_0_.TeamUpGuideTimer)
          _ARG_0_.TeamUpGuideTimer = nil
        end
        _ARG_0_:StopActExpireTimer()
      end
      if _ARG_2_ == GameStatus.Fighting then
        _ARG_0_.bIsAfterFighting = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[103]
    end
  end,
  ["OnPreSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if GameStatus.IsPreSwitchEnterFightingFromLobbyOrMainCity(_ARG_1_, _ARG_2_) then
        _ARG_0_.bIsAfterFighting = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRecFriendUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 224, 240, 128, 9, 66, 78, 158, 15, 179, 102, 118, 208, 119, 190, 219))
      if not _ARG_0_.bIsAfterFighting then
        log(bWriteLog and table.concat({
          U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 224, 240, 128, 9, 66, 78, 158, 15, 179, 102, 118, 208, 119, 190, 219, 62, 193, 193),
          U1(128, 223, 21, 191, 23, 76, 133, 193, 152, 6, 116, 82, 131, 62, 241, 118, 112, 142, 109, 146, 238)
        }))
        return
      end
      if require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 87, 131, 207, 103, 192, 235, 134, 17, 126, 5, 145, 38, 166, 102, 112, 225, 107, 134, 251, 109, 208, 225),
        U1(156, 240, 44, 166, 19, 87, 173)
      }))).IsInXMission() then
        return
      end
      if require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 142, 54, 188, 114, 108, 192, 45, 152, 237, 99, 222, 247, 129, 33, 115, 68, 147, 47, 168, 104))):IsBlockingPopupTip() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_guide):GetGuideConifg().pop_frd_recommand == 0 then
        return false
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsActInProgress() then
        return
      end
      if not DataMgr.roleData.back_user_data.is_friend_recommend then
        return
      end
      if 7 < math.ceil((require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec() - tonumber(DataMgr.roleData.back_user_data.rejoin_start_time)) / 86400) then
        return
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).CheckAndSaveCurrentDate_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eAddRecBackUserShowTime, true) then
        return
      end
      if not require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).IsModDownloaded(require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[229]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowTeamUpPopup"] = function(_ARG_0_)
    do
      if require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 142, 54, 188, 114, 108, 192, 45, 152, 237, 99, 222, 247, 129, 33, 115, 68, 147, 47, 168, 104))):IsBlockingPopupTip() then
        return
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).CheckAndSaveCurrentDate_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerTeamUpGuide, true, 3) then
        return
      end
      if U2 then
        return
      end
      U2 = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsNeedShowLoadingGuide"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):CheckIsSelectedThemeView(nil) then
          return false
        end
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):IsClassicRankMode(_ARG_1_) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):IsClassicMatchMode(_ARG_1_) then
          return false
        end
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsNewActOpen() then
        return
      end
      if require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 111, 148, 227, 106, 218, 246, 136, 80, 124, 68, 154, 32, 162, 80, 127, 209, 114, 143, 251, 112, 196))).GetToLobby() then
        return
      end
      if not (DataMgr.roleData and DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.loading_plan_id) then
        return
      end
      if not _ARG_0_:GetLoadingDataByCaseID(DataMgr.roleData and DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.loading_plan_id) then
        return
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OldFriendGiftMailReceive"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_1_.opt.subtype ~= require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 110, 154, 235, 98, 157, 245, 142, 23, 124, 116, 144, 40, 162, 125, 124))).Enum_Mail_SubType.OldFriendGift then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetInteractFriendList"] = function(_ARG_0_)
    do
      goto lbl_71
      ::lbl_71::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsNeedUpdateInteractFrd"] = function(_ARG_0_)
    do
      if not (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data) then
        return false
      end
      if not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnFriendRecordUpdate) or {})[DataMgr.roleData.uid] then
        ;(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnFriendRecordUpdate) or {})[DataMgr.roleData.uid] = true
        U2 = true
        return true
      end
      if (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).update_time ~= 0 and require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).IsSameDay((DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).update_time, require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec()) then
        return false
      end
      if require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CountTable((DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list) < DataMgr.roleData.back_user_data.friend_record_cfg.show_num then
      end
      goto lbl_567
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 101, 137, 235, 107, 221, 252, 193, 18, 127, 76, 148, 42, 158, 97, 118, 201, 76, 141, 224, 119, 198, 230),
        U1(151)
      }))).IsMyFriend((U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 250, 235, 161, 27, 117, 79, 168, 57, 165, 110, 103, 219, 90, 133, 230, 123, 209, 233))) then
      else
        ::lbl_567::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInteractRecordRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsNewActOpen() then
        return
      end
      if not UIManager.GetUI(UIManager.UI_Config.ReturnActivity_Reward_UIBP) and not UIManager.GetUI(UIManager.UI_Config.ReturnActivity_WelcomeBack_UIBP) then
        return
      end
      if not U2 then
        return
      end
      if _ARG_3_ then
        U2[_ARG_3_] = _ARG_4_
      end
      if U3 and U3[#U3] and U3[#U3].uid and _ARG_3_ and _ARG_3_ ~= U3[#U3].uid then
        return
      end
      if not _ARG_0_:IsNeedUpdateInteractFrd() then
        goto lbl_191
        ;(238).interactData = U2[(238).uid] and U2[(238).uid].data or U2[(238).uid]
        ::lbl_191::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return
      end
      if not (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data) then
        return
      end
      if (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid] and (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].time and require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec() > (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].time then
      end
      goto lbl_501
      ;(74).interactData = U2[(74).uid] and U2[(74).uid].data or U2[(74).uid]
      if not (not U4 and (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid] and (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid][1]) or (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid][1] == 0 then
      else
      end
      if (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid] and (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].uids and (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].uids[(74).uid] and (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].uids[(74).uid][3] then
        ;({
          [(74).uid] = {
            (74).interactData and (74).interactData.recent_play_date or 0,
            (74).interactData and (74).interactData.teamup_num or 0
          },
          [(74).uid] = {
            (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid][1],
            (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid][2]
          }
        })[(74).uid][3] = (require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid] and (require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].uids and (require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].uids[(74).uid] and (require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerFrdRecord) or {})[DataMgr.roleData.uid].uids[(74).uid][3], ({
          [(74).uid] = {
            (74).interactData and (74).interactData.recent_play_date or 0,
            (74).interactData and (74).interactData.teamup_num or 0
          },
          [(74).uid] = {
            (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid][1],
            (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data).frd_list[(74).uid][2]
          }
        })[(74).uid]
      end
      ::lbl_501::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      U4 = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckInteractFriendList"] = function(_ARG_0_)
    do
      if not require((U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 42, 180, 126, 112, 193, 109, 213, 238, 97, 212, 241, 140, 33, 99, 78, 156, 58, 174, 97, 76, 221, 124, 133, 244, 119, 196))).GetSeasonConfig(DataMgr.season_id - 1) then
      end
      U2 = {}
      if not _ARG_0_:IsNeedUpdateInteractFrd() then
        U3 = {}
        if not (DataMgr.roleData.back_user_data and DataMgr.roleData.back_user_data.friend_record_data and DataMgr.roleData.back_user_data.friend_record_data.frd_list) then
          return
        end
        goto lbl_183
        ::lbl_183::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_197
        ::lbl_197::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return
      end
      U3 = {}
      goto lbl_424
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(203) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(203).lastLoginTime then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(203) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(203).lastLoginTime and 1209600 >= require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec() - (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(203) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(203).lastLoginTime) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordData(203) or {}).add_friend_date and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordData(203) or {}).add_friend_date < DataMgr.roleData.back_user_data.rejoin_start_time then
      end
      ::lbl_424::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if #U3 == 0 then
        return
      end
      if 5 < #U3 then
        U3 = require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).TableSlice(U3, 1, 5)
      end
      goto lbl_458
      ::lbl_458::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[102]
    end
  end,
  ["GetLoadingDataByCaseID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or _ARG_1_ == 0 then
        log(bWriteLog and table.concat({
          U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 244, 253, 155, 50, 127, 74, 153, 32, 175, 104, 87, 223, 103, 138, 208, 103, 224, 233),
          U1(128, 251, 58, 143, 82, 87, 167, 136, 194, 78)
        }) .. tostring(_ARG_1_) .. U1(154, 237, 83, 162, 28, 72, 162, 196, 150, 10))
        return
      end
      if not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerLoading) or {})[DataMgr.roleData.uid] then
        ;(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerLoading) or {})[DataMgr.roleData.uid] = {}
      end
      goto lbl_226
      if not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerLoading) or {})[DataMgr.roleData.uid][(190).slapID] then
        ;(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerLoading) or {})[DataMgr.roleData.uid][(190).slapID] = {}
        ;(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerLoading) or {})[DataMgr.roleData.uid][(190).slapID].showCount = 0
        ;({
          [(190).caseID] = {}
        })[(190).caseID][#({
          [(190).caseID] = {}
        })[(190).caseID] + 1] = 190, ({
          [(190).caseID] = {}
        })[(190).caseID], #({
          [(190).caseID] = {}
        })[(190).caseID] + 1
      elseif (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerLoading) or {})[DataMgr.roleData.uid][(190).slapID].showCount < (190).showCount then
        ;({
          [(190).caseID] = {}
        })[(190).caseID][#({
          [(190).caseID] = {}
        })[(190).caseID] + 1] = 190, ({
          [(190).caseID] = {}
        })[(190).caseID], #({
          [(190).caseID] = {}
        })[(190).caseID] + 1
      end
      ::lbl_226::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if #{
        [(190).caseID] = {}
      } == 0 then
        return
      end
      if not ({
        [(190).caseID] = {}
      })[_ARG_1_] or #({
        [(190).caseID] = {}
      })[_ARG_1_] == 0 then
        return
      end
      do return ({
        [(190).caseID] = {}
      })[_ARG_1_][math.random(1, #({
        [(190).caseID] = {}
      })[_ARG_1_])] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportReturnGuideMatch"] = function(_ARG_0_)
    do
      if not _ENV then
        return
      end
      _ENV = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TeamUpGuideShow"] = function(_ARG_0_)
    do
      if not DataMgr.roleData.back_user_data then
        return false
      end
      if _ARG_0_.TeamUpGuideTimer then
        return
      end
      _ARG_0_.TeamUpGuideTimer = _ARG_0_:AddTimerLoop(0, function()
        log(bWriteLog and table.concat({
          U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 231, 253, 142, 19, 69, 91, 186, 60, 168, 107, 118, 237, 123, 132, 229, 62, 215, 225),
          U1(158, 251, 83, 246, 82)
        }) .. tostring(U2))
        if UIManager.IsAndroidStackEmpty() and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NewFaceSlapSystem):IsSlapEnd() and U3.curPage == ENUM_LobbyPageType.Mid and not U4.IsInTeam() and not U5:GetLobbySelectGuideShow() then
        else
          U2 = tonumber(U6.ParamValue)
          return
        end
        if U2 <= 0 then
          U5.TeamUpGuideTimer = nil
        end
        U2 = U2 - 5
        return
      end, 0, 5)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsReturnGuideMatch"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsReturnGuideMatch"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartReturnGuideMatchDelay"] = function(_ARG_0_)
    do
      _ARG_0_:AddTimerOnce(1, function()
        EventSystem:postEvent(EVENTTYPE_LOBBY, EVENTID_LOBBY_COME_BACK_FIRSTBATTLE_START_MATCH)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartReturnGuideMatchAfterFaceSlap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_._pendingFaceSlapMatch then
        return
      end
      _ARG_0_._pendingFaceSlapMatch = true
      _ARG_0_._pendingFaceSlapCounting = false
      _ARG_0_._pendingMatchModeName = _ARG_1_ or _ENV()
      _ARG_0_._pendingMatchOnCountdownEnd = _ARG_3_
      U1.EventSystem:registEvent(U1.EVENTTYPE_STATE, U1.EVENTID_ON_MODE_POST_SWITCH, _ARG_0_._OnModeSwitchCancelGuideMatch, _ARG_0_)
      if _ARG_2_ == false then
        _ARG_0_:_StartGuideMatchCountdown()
        return
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.NewFaceSlapSystem) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.NewFaceSlapSystem):IsSlapEnd() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetThemeGoMatchTarget"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)] and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)].ViewID and require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsThemeCard((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)]) and require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsThemeOpen((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)]) then
      else
        _ARG_0_ = _ARG_0_
      end
      if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)] and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_target_recovery):GetDailyTargetStatus() then
        return tonumber((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)].ViewID), (LocUtil.GetLocalizeResStr((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)].InfoCard1Title or (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)].InfoCard2Title or (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() or {})[U1(156, 250, 22, 148, 7, 74, 170, 196, 140)].InfoCard3Title))
      end
      do return 10001, require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 110, 148, 230, 107, 236, 235, 138, 18, 117, 72, 137, 32, 174, 97, 61, 210, 124, 140, 251, 125, 252, 229),
        U1(156, 250, 22, 148, 7, 74, 170, 196, 140)
      }))).GetMapNameByViewID(10001) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartThemeGoMatch"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetThemeGoMatchTarget() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_perfect_game):IsAIDescApplicable(_ARG_0_:GetThemeGoMatchTarget()) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_perfect_game):IsAccompanySelected(_ARG_0_:GetThemeGoMatchTarget()) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_perfect_game):TryInterceptAIDescConsent(_ARG_0_:GetThemeGoMatchTarget()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartThemeGoMatch"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:SetIsReturnGuideMatch(true)
      ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_slap).isClickStartGame = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnModeSwitchCancelGuideMatch"] = function(_ARG_0_)
    do
      if _ARG_0_._pendingFaceSlapMatch and not _ARG_0_._pendingFaceSlapCounting then
        _ARG_0_:_CancelGuideMatch()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelGuideMatch"] = function(_ARG_0_)
    do
      _ARG_0_._pendingFaceSlapMatch = false
      _ARG_0_._pendingFaceSlapCounting = false
      _ARG_0_._pendingMatchOnCountdownEnd = nil
      EventSystem:unregistEvent(EVENTTYPE_LOBBY, EVENTID_ON_FACESLAP_END, _ARG_0_._OnFaceSlapEnd, _ARG_0_)
      EventSystem:unregistEvent(EVENTTYPE_STATE, EVENTID_ON_MODE_POST_SWITCH, _ARG_0_._OnModeSwitchCancelGuideMatch, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnFaceSlapEnd"] = function(_ARG_0_)
    do
      EventSystem:unregistEvent(EVENTTYPE_LOBBY, EVENTID_ON_FACESLAP_END, _ARG_0_._OnFaceSlapEnd, _ARG_0_)
      _ARG_0_:_StartGuideMatchCountdown()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StartGuideMatchCountdown"] = function(_ARG_0_)
    do
      _ARG_0_._pendingFaceSlapCounting = true
      EventSystem:unregistEvent(EVENTTYPE_LOBBY, EVENTID_ON_FACESLAP_END, _ARG_0_._OnFaceSlapEnd, _ARG_0_)
      EventSystem:unregistEvent(EVENTTYPE_STATE, EVENTID_ON_MODE_POST_SWITCH, _ARG_0_._OnModeSwitchCancelGuideMatch, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_WatchMatchStarted"] = function(_ARG_0_)
    do
      if _ARG_0_._watchingGuideMatch then
        return
      end
      _ARG_0_._watchingGuideMatch = true
      EventSystem:registEvent(EVENTTYPE_MATCH, EVENTID_MATCH_UPDATE_STATUS, _ARG_0_._OnMatchStatusForGuide, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnMatchStatusForGuide"] = function(_ARG_0_)
    do
      if require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 110, 154, 246, 109, 219, 182, 131, 17, 119, 66, 158, 22, 172, 110, 103, 221, 123))).nMatchStatus == ENUM_MatchStatus.Matching then
        _ARG_0_._watchingGuideMatch = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_InstallJumpCancelHook"] = function(_ARG_0_)
    do
      if _ENV then
        return
      end
      _ENV = true
      U3 = U1.require((U2(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 164, 118, 97, 207, 112, 158, 172, 123, 218, 199, 133, 11, 125, 91, 162, 36, 160, 97, 114, 217, 118, 153))).OpenJumpModule
      U1.require((U2(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 164, 118, 97, 207, 112, 158, 172, 123, 218, 199, 133, 11, 125, 91, 162, 36, 160, 97, 114, 217, 118, 153))).OpenJumpModule = function(_ARG_0_, _ARG_1_)
        do
          _ENV:_OnJumpCancelGuideMatch(_ARG_0_)
          do return U1(_ARG_0_, _ARG_1_) end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_UninstallJumpCancelHook"] = function(_ARG_0_)
    do
      if _ENV and U1 then
        U2.require((U3(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 164, 118, 97, 207, 112, 158, 172, 123, 218, 199, 133, 11, 125, 91, 162, 36, 160, 97, 114, 217, 118, 153))).OpenJumpModule = U1
      end
      _ENV = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnJumpCancelGuideMatch"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._pendingFaceSlapMatch or _ARG_0_._pendingFaceSlapCounting then
        return
      end
      if _ARG_0_:_IsSlapModule(_ARG_1_) then
        return
      end
      log_format(table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 147, 242, 154, 19, 96, 11, 137, 38, 225, 98, 124, 218, 102, 135, 247, 69, 134, 251),
        U1(174, 190, 23, 190, 0, 87, 173, 207, 223, 8, 97, 88, 136, 116, 162, 115, 98, 222, 35, 140, 227, 103, 199, 180, 207, 29, 113, 69, 158, 44, 173, 47, 99, 219, 125, 143, 251, 112, 196, 168),
        U1(148, 235, 26, 175, 23, 30, 174, 201, 139, 13, 104)
      }), tostring(_ARG_1_))
      _ARG_0_:_CancelGuideMatch()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsSlapModule"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NewFaceSlapSystem).tFaceSlapCategory then
        return false
      end
      goto lbl_23
      if nil and (nil).ModuleID == _ARG_1_ then
        return true
      end
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLobbySelectGuideShow"] = function(_ARG_0_)
    do
      if not DataMgr.roleData.back_user_data then
        return false
      end
      if _ARG_0_:GetLobbyFirstBattleGuideShow() then
        return false
      end
      if (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerSelectGuide) or {})[DataMgr.roleData.back_user_data.rejoin_start_time] then
        return false
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).CheckAndSaveCurrentDate_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerSelectGuide, true) then
        return
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLobbyFirstBattleGuideShow"] = function(_ARG_0_)
    do
      if not DataMgr.roleData.back_user_data then
        return false
      end
      if require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 53, 180, 105, 102, 194, 92, 142, 236, 98, 220, 251, 132, 80, 101, 95, 148, 37, 239, 99, 118, 200, 118, 135, 205, 107, 205, 228),
        U1(156, 253, 24, 148, 7, 74, 170, 196)
      }))):IsSwitchOpen() and next(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetMenuInfo() or {}) and DataMgr.roleData.level < (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetMenuInfo() or {}).sub_menus[1].level_limit then
        return false
      end
      if not DataMgr.roleData.back_user_data.daily_battle_data or DataMgr.roleData.back_user_data.daily_battle_data.status ~= 0 then
        return false
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).CheckAndSaveCurrentDate_N(GameStatus.IsInMainCity() and require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.ReturnPlayerFirstBattleGuideMainCity or require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerFirstBattleGuide, true) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModeJumpState"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetModeJumpState"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAbtestConfig"] = function(_ARG_0_)
    do
      if DataMgr and DataMgr.roleData and DataMgr.roleData.back_user_data then
        return DataMgr.roleData.back_user_data.client_guide_abtest_cfg
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLeftMenuList"] = function(_ARG_0_)
    do
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMenuList"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_target_recovery) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_target_recovery):IsTargetRecoveryNewUI() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_target_recovery):HasCompletedFirstBattle() then
        else
        end
      else
      end
      if require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsTabMenuOpen(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).Enum_MenuID.RankGoal) then
      else
      end
      if tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_login):GetQuestionnaireActivityId()) and tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_login):GetQuestionnaireActivityId()) ~= 0 and require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 98, 152, 246, 103, 197, 241, 155, 7, 62, 71, 146, 46, 168, 108, 76, 223, 112, 159, 251, 104, 202, 252),
        U1(138, 193, 30, 172, 0)
      }))).GetActivityByID((tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_login):GetQuestionnaireActivityId()))) and next((require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 98, 152, 246, 103, 197, 241, 155, 7, 62, 71, 146, 46, 168, 108, 76, 223, 112, 159, 251, 104, 202, 252),
        U1(138, 193, 30, 172, 0)
      }))).GetActivityByID((tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_login):GetQuestionnaireActivityId()))))) then
        if require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec() > require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 98, 152, 246, 103, 197, 241, 155, 7, 62, 71, 146, 46, 168, 108, 76, 223, 112, 159, 251, 104, 202, 252),
          U1(138, 193, 30, 172, 0)
        }))).GetActivityByID((tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_login):GetQuestionnaireActivityId()))).StartTime and require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec() < require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 98, 152, 246, 103, 197, 241, 155, 7, 62, 71, 146, 46, 168, 108, 76, 223, 112, 159, 251, 104, 202, 252),
          U1(138, 193, 30, 172, 0)
        }))).GetActivityByID((tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_login):GetQuestionnaireActivityId()))).EndTime then
        end
      end
      do return {} end
      return
    end
  end,
  ["GetItemInfoBySelectIndex"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if type(_ARG_1_) ~= U1(135, 255, 17, 167, 23) or not _ARG_2_ then
        return
      end
      goto lbl_25
      if (17).index == _ARG_2_ then
        ;(17).item_id = 255
        return 17
      end
      ::lbl_25::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialItemList"] = function(_ARG_0_)
    do
      if _ENV ~= nil and 0 < #_ENV then
        return _ENV
      end
      if not U1() or #U1() <= 0 then
        return
      end
      _ENV = {}
      _ARG_0_ = _ARG_0_
      if U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)].special_display == 1 then
        U2.require((U3(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)]).score, U2.require((U3(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)]).level = 0, U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)].level
      end
      _ARG_0_ = _ARG_0_
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Get310RewardItemList"] = function(_ARG_0_)
    do
      if _ENV ~= nil and 0 < #_ENV then
        return _ENV
      end
      if not U1() or #U1() <= 0 then
        return
      end
      _ENV = {}
      _ARG_0_ = _ARG_0_
      U2.require((U3(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)]).score, U2.require((U3(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)]).level = 0, U1()[U3(135, 190, 16, 164, 28, 88, 170, 207, 179, 7, 115, 79, 205, 48, 162, 63, 109, 199, 111)].level
      _ARG_0_ = _ARG_0_
      do return _ENV end
      return
    end
  end,
  ["Get310SelectedRewardList"] = function(_ARG_0_)
    do
      goto lbl_46
      if (nil).select_default == 2 or (nil).select_default == 3 then
      end
      if (nil).select_default == 1 or (nil).select_default == 2 or (nil).select_default == 3 then
        goto lbl_44
        ::lbl_44::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_46::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {}, true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Get400ARewardItemList"] = function(_ARG_0_)
    do
      if _ARG_0_.reward_item_list then
        return _ARG_0_.reward_item_list
      end
      _ARG_0_.reward_item_list = {}
      if not (LobbySystem.roleData and LobbySystem.roleData.back_user_data) or not (LobbySystem.roleData and LobbySystem.roleData.back_user_data).longline_select_items then
        return _ARG_0_.reward_item_list
      end
      _ARG_0_.reward_item_list[1].level = 0
      goto lbl_251
      require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable((LobbySystem.roleData and LobbySystem.roleData.back_user_data).longline_select_items[0])).level = require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable((LobbySystem.roleData and LobbySystem.roleData.back_user_data).longline_select_items[0])
      ::lbl_251::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_264
      require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable((LobbySystem.roleData and LobbySystem.roleData.back_user_data).longline_select_items[0])).start_score = 0
      require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable((LobbySystem.roleData and LobbySystem.roleData.back_user_data).longline_select_items[0])).end_score = 0 + require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable(require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).CopyTable((LobbySystem.roleData and LobbySystem.roleData.back_user_data).longline_select_items[0])).score
      ::lbl_264::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.reward_item_list[#_ARG_0_.reward_item_list].is_last = true
      do return _ARG_0_.reward_item_list end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Get400ASpecialRewardItemList"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 244, 253, 155, 74, 32, 27, 188, 26, 177, 106, 112, 215, 114, 135, 192, 123, 212, 233),
        U1(129, 250, 58, 191, 23, 83, 143, 193, 140, 26, 46, 27, 158, 45, 176, 109, 119, 142, 100, 158, 246, 122, 218, 246, 136, 94, 99, 91, 152, 42, 168, 110, 127, 158, 97, 142, 229, 127, 209, 236),
        U1(211, 242, 26, 184, 6)
      }))
      if not _ARG_0_:Get400ARewardItemList() or #_ARG_0_:Get400ARewardItemList() == 0 then
        return {}
      end
      goto lbl_437
      if next(U1(150, 242, 73, 238, 1).team_reward) and not nil and not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).totalSummaryData and require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).totalSummaryData.team_battle_reward_status and require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).totalSummaryData.team_battle_reward_status[U1(150, 242, 73, 238, 1).level]) then
      end
      if U1(150, 242, 73, 238, 1).special_display == 1 then
      end
      ::lbl_437::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if U1(150, 242, 73, 238, 1) then
      elseif U1(150, 242, 73, 238, 1) then
      else
      end
      goto lbl_798
      ::lbl_798::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSuitWithVehicleItemList"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(135, 255, 17, 167, 23) or #_ARG_1_ <= 0 then
        log(bWriteLog and table.concat({
          U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 223, 138, 10, 67, 94, 148, 61, 150, 102, 103, 214, 69, 142, 250, 119, 192, 228),
          U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)
        }))
        return
      end
      _ARG_0_ = _ARG_0_
      if CDataTable.GetTableData(U1(186, 234, 22, 166), _ARG_1_[U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)].item_id) ~= nil then
        if CDataTable.GetTableData(U1(186, 234, 22, 166), _ARG_1_[U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)].item_id).ItemType == ENUM_ITEM_TYPE.Extra or CDataTable.GetTableData(U1(186, 234, 22, 166), _ARG_1_[U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)].item_id).ItemType == ENUM_ITEM_TYPE.Backpack then
        elseif CDataTable.GetTableData(U1(186, 234, 22, 166), _ARG_1_[U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)].item_id).ItemType == ENUM_ITEM_TYPE.Aircraft_Skin or CDataTable.GetTableData(U1(186, 234, 22, 166), _ARG_1_[U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)].item_id).ItemType == ENUM_ITEM_TYPE.Vehicle then
        elseif CDataTable.GetTableData(U1(186, 234, 22, 166), _ARG_1_[U1(150, 215, 7, 174, 31, 114, 170, 219, 139, 78, 114, 94, 154, 56, 163, 123, 79, 199, 112, 143, 162, 107, 193, 234, 128, 12)].item_id).ItemType == ENUM_ITEM_TYPE.Weapon then
        end
      end
      _ARG_0_ = _ARG_0_
      do return {}, {}, {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartActExpireTimer"] = function(_ARG_0_)
    do
      if _ARG_0_._actExpireTimer then
        return
      end
      _ARG_0_._actExpireTimer = _ARG_0_:AddTimerLoop(0, function()
        if not IsActInProgress() then
          U1:StopActExpireTimer()
          U2.EventSystem:postEvent(U2.EVENTTYPE_COME_BACK, U2.EVENTID_PLAYER_RETURN_CLOSE)
        end
        return
      end, TIMER_INFINITE, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopActExpireTimer"] = function(_ARG_0_)
    do
      if _ARG_0_._actExpireTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._actExpireTimer)
        _ARG_0_._actExpireTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterMainUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsActInProgress() then
        return
      end
      if _ARG_2_ then
      end
      if _ARG_3_ or _ARG_2_ then
      end
      if not require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).IsModDownloaded(require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      if require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).IsSameDay(require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec(), DataMgr.roleData.back_user_data.rejoin_start_time) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRedDataByMenuId"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).MenuEntranceInfoList[_ARG_1_] or not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).MenuEntranceInfoList[_ARG_1_].red_node_name then
        return
      end
      do return require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 113, 203, 103, 139, 237, 103, 221, 236, 176, 26, 113, 95, 156)
      }))).GetRedDataByNodeName(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).MenuEntranceInfoList[_ARG_1_].red_node_name) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAllDayTaskRewardReceived"] = function(_ARG_0_)
    do
      if type((require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).GetDayTaskListData())) ~= U1(135, 255, 17, 167, 23) or next((require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).GetDayTaskListData())) == nil then
        return true
      end
      goto lbl_174
      if U1(151, 204, 22, 168, 23, 87, 181, 205, 155, 78, 116, 90, 158, 50, 157, 118, 112, 218, 35, 146, 241, 46, 221, 241, 131).status ~= require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).E_Reward_State.HasGot then
        return false
      end
      ::lbl_174::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAllSignRewardReceived"] = function(_ARG_0_)
    do
      if #(require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).GetTableValue(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 211, 228),
        U1(146, 231, 22, 185, 45, 76, 166, 220, 138, 28, 110)
      }))).login_reward_info, (U1(148, 241, 7, 148, 27, 80, 167, 205, 135, 29))) or {}) ~= U2 and (require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).GetTableValue(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 211, 228),
        U1(146, 231, 22, 185, 45, 76, 166, 220, 138, 28, 110)
      }))).login_reward_info, (U1(144, 235, 1, 148, 22, 95, 186))) or 0) > #(require((U1(144, 241, 30, 166, 29, 80, 237, 220, 158, 12, 108, 94, 178, 44, 165, 118, 111))).GetTableValue(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 211, 228),
        U1(146, 231, 22, 185, 45, 76, 166, 220, 138, 28, 110)
      }))).login_reward_info, (U1(148, 241, 7, 148, 27, 80, 167, 205, 135, 29))) or {}) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AutoPopReturnGiftUI"] = function(_ARG_0_, _ARG_1_)
    do
      if UIManager.GetTopUIName() ~= UIManager.UI_Config.ReturnActivity_Main_UIBP.keyName then
        return
      end
      if not _ARG_0_:CheckShowReturnGiftUI() then
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AutoPopTaskUI"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:IsAllDayTaskRewardReceived() then
        log(bWriteLog and table.concat({
          U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 217, 154, 10, 127, 123, 146, 57, 149, 110, 96, 213, 70, 162, 178, 95, 207, 228),
          U1(183, 255, 10, 159, 19, 77, 168, 250, 154, 25, 97, 73, 137, 11, 180, 124, 102, 199, 117, 158, 230)
        }))
        _ARG_1_:Resolve()
        return false
      end
      U2()
      if U3 >= U4 then
        log(bWriteLog and table.concat({
          U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 217, 154, 10, 127, 123, 146, 57, 149, 110, 96, 213, 70, 162, 178, 106, 204, 236),
          U1(146, 231, 50, 190, 6, 81, 147, 199, 143, 58, 97, 72, 134, 13, 184, 114, 102, 221, 35, 137, 231, 111, 208, 240, 207, 18, 121, 70, 148, 61, 164, 107)
        }))
        _ARG_1_:Resolve()
        return false
      end
      U6 = require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec()
      U3 = U3 + 1
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AutoPopSignUI"] = function(_ARG_0_)
    do
      if UIManager.GetTopUIName() ~= UIManager.UI_Config.ReturnActivity_Reward_UIBP.keyName then
        return
      end
      if _ARG_0_:IsAllSignRewardReceived() then
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDayTaskList"] = function(_ARG_0_)
    do
      goto lbl_76
      U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107).task_no = U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      ::lbl_76::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < #{} then
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDayTaskTitle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 223, 138, 10, 84, 74, 132, 29, 160, 124, 120, 234, 122, 159, 254, 123, 143, 168),
        U1(131, 255, 1, 170, 67, 30, 254, 136)
      }) .. tostring(_ARG_2_))
      log(bWriteLog and table.concat({
        U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 223, 138, 10, 84, 74, 132, 29, 160, 124, 120, 234, 122, 159, 254, 123, 143, 168),
        U1(131, 255, 1, 170, 64, 30, 254, 136)
      }) .. tostring(_ARG_3_))
      _ARG_2_ = _ARG_2_ or 0
      _ARG_3_ = _ARG_3_ or 0
      if not CDataTable.GetTableData(U1(176, 241, 30, 174, 48, 95, 160, 195, 171, 15, 115, 80), _ARG_1_) then
        return (U1())
      end
      if CDataTable.GetTableData(U1(176, 241, 30, 174, 48, 95, 160, 195, 171, 15, 115, 80), _ARG_1_).showText == U1() or _ARG_2_ == 0 then
        return (U1())
      end
      if _ARG_1_ == require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).Enum_DayTaskType.SurviveTime then
        _ARG_2_ = math.ceil(_ARG_2_ / 60)
      end
      if _ARG_3_ ~= 0 then
      else
      end
      if _ARG_1_ == require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).Enum_DayTaskType.TeamUp and _ARG_0_:ReturnActivityABTest() then
      end
      do return (LocUtil.LocalizeResFormat(86321, (LocUtil.LocalizeResFormat(CDataTable.GetTableData(U1(176, 241, 30, 174, 48, 95, 160, 195, 171, 15, 115, 80), _ARG_1_).showText, _ARG_2_)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[86321]
    end
  end,
  ["RefreshDayTaskList"] = function(_ARG_0_)
    do
      if require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).IsSameDay(require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec(), U2) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenUIByMenuId"] = function(_ARG_0_, _ARG_1_, ...)
    do
      if not _ARG_1_ then
        return
      end
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).MenuEntranceInfoList[_ARG_1_] or not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).MenuEntranceInfoList[_ARG_1_].uiConfig then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseAllUI"] = function(_ARG_0_)
    do
      goto lbl_91
      if U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190).ui_module and UIManager.GetUI(UIManager.UI_Config[U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190).ui_module]) then
      end
      ::lbl_91::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[230]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFBUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_slap):CanShowFBUI() then
        return
      end
      if not _ARG_0_.isShowFBSlap then
        if not require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 161, 126, 104, 241, 118, 143, 235, 98))).IsPufferDownloaded(UIManager.UI_Config.ReturnActivity_First_UIBP.path) then
          return
        end
        if _ARG_1_ then
        end
        _ARG_0_.isShowFBSlap = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSwitchShowFBUI"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 252, 246, 191, 17, 99, 95, 174, 62, 168, 123, 112, 214, 64, 131, 253, 105, 229, 202),
        U1(166, 215)
      }))
      _ARG_0_:ShowFBUI(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSignRewardUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).IsModDownloaded(require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRebateUI"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).IsModDownloaded(require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowModeSelectUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).IsModDownloaded(require((table.concat({
        U1(180, 255, 30, 174, 62, 75, 162, 134, 178, 1, 100, 21, 161, 54, 179, 125, 122, 128, 65, 154, 241, 107, 157, 219, 128, 19, 125, 68, 147, 103, 141, 96, 113, 220, 106, 166, 253, 122, 246, 252),
        U1(154, 242, 0)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_target_recovery):IsTargetRecoveryNewUI() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):GetModeIntroductionList() then
        return
      end
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFBGuideUI"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowGuideUI"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowReturnGiftUI"] = function(_ARG_0_)
    do
      if not DataMgr.roleData.back_user_data then
        return false
      end
      if not DataMgr.roleData.back_user_data.welcome_gift_dropid then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowReturnGuide"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_player_return_slap).bIsShowReturnFlag then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_guide):HasValidGuideUI() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReturnActivityABTest"] = function(_ARG_0_)
    do
      if LobbySystem.roleData.back_user_data and LobbySystem.roleData.back_user_data.longline_select_items then
        goto lbl_28
        if (nil).team_cnt and (nil).team_cnt > 0 then
        else
          ::lbl_28::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return true end
      return
    end
  end,
  ["IsMultipleChoicePlan"] = function(_ARG_0_)
    do
      if LobbySystem.roleData.back_user_data and LobbySystem.roleData.back_user_data.longline_select_items then
        goto lbl_30
        if (nil).select_items and next((nil).select_items) then
        else
          ::lbl_30::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsReturnTimeOK"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return false
      end
      if (_ARG_1_.rejoinStartTime or 0) ~= _ENV() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNewPostEnterSaveData"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetInitialAnimIndex"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnActivityAnimIndexRecord) or not _ARG_0_:IsReturnTimeOK((require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnActivityAnimIndexRecord))) then
        return
      end
      do return tonumber(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnActivityAnimIndexRecord).animIndex) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAnimIndexSaveData"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAutoReplyMsg"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_1_[174].msgType == require((U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 111, 148, 224, 108, 202, 199, 140, 22, 113, 95, 211, 42, 169, 110, 103, 225, 126, 138, 241, 108, 204))).friendComebackMsgType and _ARG_1_[174].sender_uid ~= DataMgr.roleData.uid then
      else
        _ARG_0_ = _ARG_0_
      end
      if not _ARG_1_[174] then
        return false
      end
      if (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerAutoReplyMsg) or {}) and (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerAutoReplyMsg) or {})[_ARG_1_[174].sender_uid] and (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerAutoReplyMsg) or {})[_ARG_1_[174].sender_uid][_ARG_1_[174].send_time] then
        return false
      end
      if not (require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerAutoReplyMsg) or {})[_ARG_1_[174].sender_uid] then
        ;(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).LoadFileToTable_N(require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
          U1(128)
        }))).ePlayerPrefsType.eReturnPlayerAutoReplyMsg) or {})[_ARG_1_[174].sender_uid] = {}
      end
      ;(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).LoadFileToTable_N(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 196, 144, 9, 105, 88, 195, 21, 190, 120, 106, 205, 83, 151, 227, 119, 214, 234, 191, 12, 117, 77, 142, 103, 177, 99, 114, 199, 118, 153, 226, 108, 198, 238),
        U1(128)
      }))).ePlayerPrefsType.eReturnPlayerAutoReplyMsg) or {})[_ARG_1_[174].sender_uid][_ARG_1_[174].send_time] = true
      do return true end
      do return end
      _ARG_1_ = _ENV[117]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqGetTaskList"] = function(_ARG_0_)
    do
      U2 = require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FetchAllMessage"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 222, 138, 10, 115, 67, 188, 37, 173, 66, 118, 205, 96, 138, 245, 123))
      if not require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsActInProgress() then
        return
      end
      if 0 < #_ARG_0_:GetLeftMenuList() then
        _ARG_0_ = _ARG_0_
        if require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
          U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
        }))).MenuEntranceInfoList[_ARG_0_:GetLeftMenuList()[U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)]] and require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
          U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
        }))).MenuEntranceInfoList[_ARG_0_:GetLeftMenuList()[U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)]].red_dot_require_func ~= nil then
        end
        _ARG_0_ = _ARG_0_
      end
      if require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 127, 132, 245, 119, 192, 215),
        U1(129, 251, 7, 190, 0, 80, 156, 201, 156, 26, 105, 77, 132, 45, 168, 64, 118, 218, 106, 151, 241)
      }))).IsTabMenuOpen(require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 113, 158, 246, 123, 193, 246, 176, 31, 115, 95, 148, 63, 168, 123, 106, 144, 97, 142, 230, 107, 209, 230),
        U1(172, 255, 16, 191, 27, 72, 170, 220, 134, 49, 109, 90, 142, 43, 190)
      }))).Enum_MenuID.Task) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_backuser_get_friend_recommend_req"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_backuser_get_friend_recommend_res"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 116, 142, 230, 65, 197, 250),
        U1(154, 251, 29, 175, 45, 76, 166, 203, 144, 3, 109, 94, 131, 61, 142, 109, 102, 221, 35, 137, 231, 122, 147, 165, 207)
      }) .. tostring(_ARG_1_))
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 116, 142, 230, 65, 197, 250),
        U1(154, 251, 29, 175, 45, 76, 166, 203, 144, 3, 109, 94, 131, 61, 142, 109, 102, 221, 35, 146, 241, 81, 213, 234, 134, 27, 126, 79, 162, 59, 164, 108, 124, 211, 126, 142, 252, 122, 131, 181),
        U1(211)
      }) .. tostring(_ARG_2_))
      if _ARG_1_ ~= 0 then
        return
      end
      if DataMgr.roleData and DataMgr.roleData.back_user_data then
        DataMgr.roleData.back_user_data.is_friend_recommend = false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_backuser_active_frd_sync_res"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 114, 136, 230, 119, 213, 237),
        U1(172, 248, 1, 175, 45, 77, 186, 198, 156, 49, 114, 94, 158, 121, 163, 122, 119, 142, 62, 219)
      }) .. tostring(_ARG_1_))
      log_tree(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 114, 136, 230, 119, 213, 237),
        U1(172, 248, 1, 175, 45, 77, 186, 198, 156, 49, 114, 94, 158, 121, 164, 118, 103, 241, 106, 149, 228, 97, 236, 244, 134, 13, 100)
      }), _ARG_2_)
      DataMgr.roleData.back_user_data.friend_record_data.frd_list = _ARG_2_
      DataMgr.roleData.back_user_data.friend_record_data.update_time = require((U1(144, 242, 26, 174, 28, 74, 237, 203, 144, 3, 109, 84, 131, 119, 165, 118, 110, 203, 92, 142, 246, 103, 223))).GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_backuser_frd_active_reward_res"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 117, 153, 246, 65, 194, 235),
        U1(135, 247, 5, 174, 45, 76, 166, 223, 158, 28, 100, 100, 159, 60, 162, 63, 113, 203, 119, 219, 191, 46)
      }) .. tostring(_ARG_1_))
      log_tree(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 117, 153, 246, 65, 194, 235),
        U1(135, 247, 5, 174, 45, 76, 166, 223, 158, 28, 100, 100, 159, 60, 162, 63, 106, 218, 102, 150, 238, 103, 192, 236)
      }), _ARG_3_)
      log(bWriteLog and table.concat({
        U1(159, 241, 20, 162, 17, 97, 177, 205, 139, 27, 114, 85, 178, 56, 178, 107, 106, 216, 106, 143, 251, 52, 220, 246, 176, 28, 113, 72, 150, 60, 178, 106, 97, 225, 117, 153, 246, 65, 194, 235),
        U1(135, 247, 5, 174, 45, 76, 166, 223, 158, 28, 100, 100, 159, 60, 162, 63, 101, 220, 103, 164, 247, 103, 215, 184, 210, 94)
      }) .. tostring(_ARG_2_))
      DataMgr.roleData.back_user_data.friend_record_data.got_indexs[_ARG_2_] = true
      goto lbl_328
      require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).curScore = require((table.concat({
        U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
        U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      }))).curScore + U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
      ::lbl_328::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_back_user_score_change_notify"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(211, 242, 28, 172, 27, 93, 156, 218, 154, 26, 117, 73, 131, 6, 176, 124, 119, 199, 117, 146, 246, 119, 137, 247, 129, 33, 114, 74, 158, 34, 158, 122, 96, 219, 97, 180, 225, 125, 204, 250),
        U1(150, 193, 16, 163, 19, 80, 164, 205, 160, 0, 111, 79, 132, 63, 168, 51, 35, 220, 102, 143, 221, 98, 214, 238, 138, 18, 48, 66, 142, 115)
      }) .. tostring(_ARG_1_) .. U1(200, 190, 1, 174, 6, 97, 176, 203, 144, 28, 101, 27, 208, 121) .. tostring(_ARG_2_))
      if _ARG_1_ then
        require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
          U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
        }))).curLevel = _ARG_1_
      end
      if _ARG_2_ then
        require((table.concat({
          U1(144, 242, 26, 174, 28, 74, 237, 219, 147, 27, 97, 21, 129, 54, 182, 118, 96, 128, 115, 151, 227, 119, 214, 234, 176, 12, 117, 95, 136, 59, 175, 33, 127, 209, 116, 130, 241, 65, 207, 231),
          U1(157, 249, 31, 162, 28, 91, 156, 220, 158, 29, 107)
        }))).curScore = _ARG_2_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[214]
    end
  end
})) end
return
