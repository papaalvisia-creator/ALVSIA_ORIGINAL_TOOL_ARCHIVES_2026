do return {
  teamInfo = {
    members = {}
  },
  nInviter = 0,
  nInviterTeamID = 0,
  nInviterRoomID = 0,
  nApplierID = 0,
  nApplierTeamID = 0,
  inviteApplyQueue = {},
  bInviteApplyShowing = false,
  nInviteApplyShowType = 0,
  nInviteApplyShowTime = 0,
  autoRefuseInviterMap = {},
  autoRefuseApplierMap = {},
  autoRefuseSoloMap = {},
  bIsAddMember = true,
  changeMemberInfo = {},
  changeWearInfo = {},
  headShowChangeInfo = {},
  changeWearPair = {},
  changeAvatarInfo = {},
  bHasEnterFighting = false,
  bIsFightingBackLobby = false,
  nCurTeamEmulatorType = -1,
  nWXPlatformInviteType = 0,
  nMsgIdGuid = 0,
  msgContentCacheMap = {},
  oneMoreGameTeamInfo = nil,
  oneMoreGameReplyList = {},
  nShowVehicleUID = 0,
  teamPriorIntimacyInfo = {},
  nVihicleVideoPlayingUser = nil,
  nShowTeamGroup = 1,
  nLastShowTeamGroup = nil,
  ugcModInfoSyncCache = {},
  E_InviteFromType = {
    Normal = 0,
    TeamTask = 1,
    TeamRecruit = 2,
    CorpsRecruitWithTeamTask = 3,
    TeamRecruitWithTeamTask = 4,
    Appointment = 5,
    TeamConscribe = 6,
    TPlan = 7,
    TPlanTeamConscribe = 8,
    MagicWish = 9,
    AllStar = 10,
    BeatIt = 11,
    PanJam = 12,
    TapJoy = 13,
    CommunityLive = 14,
    NearsFriend = 15,
    InviteFreeFriend = 16,
    FriendReserveList = 17,
    ChannelSocialIslandChat = 18,
    ChannelWorld = 19,
    ChannelTeamRecruit = 20,
    ChannelPrivate = 21,
    ChannelLBS = 22,
    ChannelCorps = 23,
    ChannelClub = 24,
    ChannelTopic = 25,
    FriendBar = 26,
    RecentBar = 27,
    CorpsBar = 28,
    SocialIslandArena = 29,
    SocialIslandDuel = 30,
    SocialIslandPlayerInteract = 31,
    FightPlayerInteract = 32,
    MailMessageCenter = 33,
    FriendCare = 34,
    Sponsor = 35,
    Tournament = 36,
    FireBaseInvite = 37,
    SwtichModeFriendBar = 38,
    SwtichModeRecentBar = 39,
    SwtichModeCorpsBar = 40,
    SwtichModeAppointment = 41,
    SwtichModeNearsFriend = 42,
    SwtichModeFriendReserveList = 43,
    SwtichModeTPlan = 44,
    RecommendTeamFriend = 45,
    RecommendTeamCorps = 46,
    RecommendTeamStranger = 47,
    RecommendTeamFriendCorps = 48,
    ChannelSameAge = 49,
    TeamConscribeNew = 50,
    TPlanTeamConscribeNew = 51,
    RecommendTeamBackUser = 52,
    ChannelChatRoom = 53,
    WorldCup_LuckyStar = 54,
    ReturnFriendInteract = 55,
    WorldCup_LuckyStar_Stranger = 56,
    LuckyStar = 57,
    LuckyStar_Stranger = 58,
    CreativeWoW = 59,
    RecommendTeamSocialEdge = 60,
    RecommendTeamLuckyStar = 61,
    SoloPK = 62,
    WOWTeam = 63,
    MainCityInfoCard = 64,
    RecommendReturnPlayer = 65,
    WOWTogether = 66,
    MainCityInteract = 67,
    NewbieChatChannelNewbie = 68,
    NewbieChatChannelMentor = 69,
    FlashTeam = 70,
    WoWEditorPro = 72,
    TPlanPVE = 73
  },
  E_InviteTipType = {
    Invite = 0,
    Join = 1,
    RoomInvite = 2,
    AsiaRoomInvite = 3
  },
  C_APPLY_INVITE_CLOSE_TIME = 15,
  ["E_QUIT_TYPE"] = {
    TeamPlatform = 1,
    EnterXMission = 2,
    QuitXMission = 3
  },
  ["E_UI_TYPE"] = {
    TeamPlatformMain = 1,
    XMissionTeamPlatformMain = 2,
    LobbyMyTeamUI = 3,
    MentorUI = 4,
    LobbyMyXMissionTeamUI = 5,
    WoWTeamPlatformMain = 6,
    WOWLobbyMyTeamUI = 7,
    PeakTeamPlatformMain = 8,
    PeakLobbyMyTeamUI = 9,
    WowHallUI = 10,
    WowRoomUI = 11,
    WowRecruitHallUI = 12
  },
  ["OnModePostSwitch"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == GameStatus.Lobby then
        U1.Enter()
        if U1.IsInOneMoreGameTeam() then
          U1.ShowOneMoreGameInviteUI()
        end
      elseif _ARG_1_ == GameStatus.Fighting and not GameStatus.IsInMainCity() then
        U1.ReleaseOneMoreGameInfo()
        U1.bHasEnterFighting = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CreateTeamUI"] = function()
    if IsWoWEditor then
      return
    end
    UIManager.ShowUI(UIManager.UI_Config.team_main)
    return
  end,
  ["ShowTeamUI"] = function()
    if UIManager.GetUI(UIManager.UI_Config.team_main) then
    end
    return
  end,
  ["HideTeamUI"] = function()
    if UIManager.GetUI(UIManager.UI_Config.team_main) then
    end
    return
  end,
  ["GetSelfUID"] = function()
    do return tonumber(DataMgr.roleData.uid) or 0 end
    return
  end,
  ["GetTeamNum"] = function()
    if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_room_team):IsSelfInXmissionRoom() then
      return U1.RealGetTeamNum()
    else
      return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_room_team):GetTeamNum()
    end
    return
  end,
  ["RealGetTeamNum"] = function()
    if teamInfo then
      return teamInfo.player_count or 1
    else
      return 1
    end
    return
  end,
  ["GetTeamAntsVoiceURL"] = function()
    if teamInfo then
      return U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).GetTableValue(teamInfo, (U2(229, 215, 4, 175, 82, 182, 147, 176, 35, 126, 167, 159, 221)))
    else
      return (U2())
    end
    return
  end,
  ["GetTeamZoneID"] = function()
    if teamInfo then
      return teamInfo.zone_id or 1
    else
      return 1
    end
    return
  end,
  ["GetTeamID"] = function()
    if teamInfo then
      return teamInfo.id
    else
      return nil
    end
    return
  end,
  ["GetTeamLeader"] = function()
    if teamInfo then
      return teamInfo.leader
    end
    return
  end,
  ["GetDefaultMaxTeamNum"] = function()
    do return _ENV end
    return
  end,
  ["GetMaxTeamNum"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
      return U1
    end
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
      return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti):GetMaxTeamSize()
    else
      return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetModeMaxTeamNum() > U1 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetModeMaxTeamNum() or U1
    end
    return
  end,
  ["IsInLargeTeam"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
      return false
    end
    do return U1.GetTeamNum() > U1.GetDefaultMaxTeamNum() end
    return
  end,
  ["ShowExtraTeamUI"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
      return
    end
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):IsSelect8PlayersMode() and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
    elseif U1.GetTeamNum() > 4 then
    end
    return
  end,
  ["GetShowTeamGroup"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
      return 1
    end
    do return U1.nShowTeamGroup end
    return
  end,
  ["SwitchTeamGroup"] = function(_ARG_0_)
    do
      if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
        return
      end
      if _ARG_0_ then
        U1.nShowTeamGroup = _ARG_0_
      else
        U1.nShowTeamGroup = U1.nShowTeamGroup == 1 and 2 or 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceSwitchTeamGroup"] = function(_ARG_0_)
    do
      if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
        return U1
      end
      if not _ARG_0_ or _ARG_0_ == U2.nShowTeamGroup then
        return
      end
      U2.nLastShowTeamGroup = U2.nShowTeamGroup
      U2.SwitchTeamGroup(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RevertTeamGroup"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
      return U1
    end
    if U1 and U1 ~= BP_ENUM_SWITCH_8PLAYERS_TEAM_UP then
      U1(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP)
    end
    return
  end,
  ["FixTeamGroup"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
      return
    end
    if U1.nShowTeamGroup == 1 and not U1.nLastShowTeamGroup then
      return
    end
    if U1.GetTeamNum() <= U2 then
      U1.nShowTeamGroup = 1
      if U1.nLastShowTeamGroup then
        U1.nLastShowTeamGroup = nil
        return
      end
    end
    return
  end,
  ["InShowGroup"] = function(_ARG_0_)
    do
      if not LobbySystem.CheckOpen(BP_ENUM_SWITCH_8PLAYERS_TEAM_UP) then
        return true
      end
      do return _ARG_0_ > (U1.nShowTeamGroup - 1) * U2 and _ARG_0_ <= U1.nShowTeamGroup * U2 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamType"] = function()
    if teamInfo then
      return teamInfo.team_type or 0
    else
      return 0
    end
    return
  end,
  ["IsTeamLeader"] = function(_ARG_0_)
    do
      _ARG_0_ = tonumber(_ARG_0_) or U1.GetSelfUID()
      if U1.teamInfo and U1.teamInfo.leader and _ARG_0_ and _ARG_0_ ~= U1.teamInfo.leader then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamReadyInfo"] = function()
    log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 177, 51, 80, 166, 132, 232, 75, 100, 232))
    if U2.teamInfo and U2.teamInfo.members then
      goto lbl_63
      if 81 == U2.teamInfo.leader or (169).status == 1 then
      end
      ::lbl_63::
    end
    do return 0 + 1, (U2.GetTeamNum()) end
    return
  end,
  ["GetMemberInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return nil
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_room_team):IsSelfInXmissionRoom() then
        return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_room_team):GetRowMemberInfo(_ARG_0_)
      end
      if U1.teamInfo and U1.teamInfo.members then
        return U1.teamInfo.members[tonumber(_ARG_0_)]
      else
        return nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMemberRelationInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(255, 227, 56, 129, 36, 158, 159, 167, 11, 68, 191, 143, 212, 71, 64, 242, 56, 232, 116, 133, 155, 135, 195, 141, 48, 94))
      if not _ARG_0_ then
        return nil
      end
      if not (U2.teamInfo and U2.teamInfo.intimacy_info) or not next(U2.teamInfo.intimacy_info) then
        log(bWriteLog and table.concat({
          U1(255, 227, 56, 129, 36, 141, 159, 178, 43, 116, 162, 163, 212, 66, 65, 238, 39, 253, 101, 129, 218, 157, 239, 130, 59, 120, 172, 155, 206, 5, 109, 245, 100, 205, 117, 157, 137, 172, 234, 189),
          U1(193, 206, 35, 165, 119, 173, 159, 190, 104, 85, 183, 140, 220, 124, 124, 241, 59, 167, 105, 130, 128, 128, 231, 130, 53, 72, 157, 148, 207, 67, 109, 167, 45, 234, 48, 146, 141, 149)
        }))
        if require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 102, 158, 157, 140, 228, 135, 120, 93, 173, 154, 200, 70, 93, 233, 33, 238, 79, 154, 150, 144, 255, 157),
          U1(192)
        }))).GetIntimacyData(_ARG_0_) and require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 102, 158, 157, 140, 228, 135, 120, 93, 173, 154, 200, 70, 93, 233, 33, 238, 79, 154, 150, 144, 255, 157),
          U1(192)
        }))).GetRelation(_ARG_0_) then
          return {
            relation = require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 102, 158, 157, 140, 228, 135, 120, 93, 173, 154, 200, 70, 93, 233, 33, 238, 79, 154, 150, 144, 255, 157),
              U1(192)
            }))).GetRelation(_ARG_0_),
            intimacy = require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 102, 158, 157, 140, 228, 135, 120, 93, 173, 154, 200, 70, 93, 233, 33, 238, 79, 154, 150, 144, 255, 157),
              U1(192)
            }))).GetIntimacyData(_ARG_0_).intimacy
          }
        end
        return nil
      end
      log_tree(U1(255, 227, 56, 129, 80, 188, 155, 190, 19, 81, 156, 136, 198, 102, 107, 228, 32, 236, 109, 194, 157, 135, 254, 138, 59, 80, 161, 132, 254, 76, 108, 225, 43), U2.teamInfo.intimacy_info)
      do return U2.teamInfo.intimacy_info[tonumber(_ARG_0_)] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMemberName"] = function(_ARG_0_)
    do
      _ARG_0_ = tonumber(_ARG_0_)
      if U1.GetMemberInfo(_ARG_0_) then
        return U1.GetMemberInfo(_ARG_0_).name
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) then
        return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_).nickName
      else
        return (U2())
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMyStatus"] = function()
    if teamInfo and GetMemberInfo((GetSelfUID())) then
      return GetMemberInfo((GetSelfUID())).status
    end
    do return 1 end
    return
  end,
  ["IsEverybodyReady"] = function()
    if not teamInfo then
      return true
    end
    if teamInfo.player_count and teamInfo.player_count == 1 then
      return true
    end
    goto lbl_30
    if (nil).status ~= 1 and nil ~= teamInfo.leader then
      return false
    end
    ::lbl_30::
    do return true end
    return
  end,
  ["IsAnyoneInGuiding"] = function()
    if not teamInfo then
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 29, 250, 65, 130, 141, 134, 228, 134, 31, 95, 133, 136, 200, 65, 107, 233, 35, 181, 48, 142, 129, 141, 239, 129),
        U2(202, 153, 22, 189, 104, 170, 159)
      }))
      return false
    end
    if teamInfo.player_count and teamInfo.player_count == 1 then
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 29, 250, 65, 130, 141, 134, 228, 134, 31, 95, 133, 136, 200, 65, 107, 233, 35, 181, 48, 142, 129, 141, 239, 129),
        U2(202, 153, 22, 189, 104, 170, 159)
      }))
      return false
    end
    goto lbl_285
    if U2(203, 215, 47, 190, 97, 190, 147, 189, 40, 68, 160, 178, 214, 64, 123, 243, 49) ~= teamInfo.leader and U2(203, 215, 47, 190, 97, 190, 147, 189, 40, 68, 160, 178, 214, 64, 123, 243, 49).metro_team_info and U2(203, 215, 47, 190, 97, 190, 147, 189, 40, 68, 160, 178, 214, 64, 123, 243, 49).metro_team_info.guide_progress < U1.require((U1.table.concat({
      U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
      U2(203, 215, 47, 190, 97, 190, 147, 189, 40, 68, 160, 178, 214, 64, 123, 243, 49)
    }))).state_Equiped then
      return true
    end
    ::lbl_285::
    do return false end
    return
  end,
  ["GetMemberClanName"] = function(_ARG_0_)
    do
      if GetMemberInfo(U1.tonumber(_ARG_0_)) then
        return GetMemberInfo(U1.tonumber(_ARG_0_)).carteam_name or U2()
      else
        return (U2())
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsOpenVoice"] = function(_ARG_0_)
    do
      if GetMemberInfo(U1.tonumber(_ARG_0_)) and GetMemberInfo(U1.tonumber(_ARG_0_)).voice then
        return GetMemberInfo(U1.tonumber(_ARG_0_)).voice.voice_open
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsOpenSpeaker"] = function(_ARG_0_)
    do
      if GetMemberInfo(U1.tonumber(_ARG_0_)) and GetMemberInfo(U1.tonumber(_ARG_0_)).voice then
        return GetMemberInfo(U1.tonumber(_ARG_0_)).voice.trumpet_open
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPlayerRelation"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 102, 158, 157, 140, 228, 135, 120, 93, 173, 154, 200, 70, 93, 233, 33, 238, 79, 154, 150, 144, 255, 157),
        U1(192)
      }))).IsMyFriend(_ARG_0_) then
        return (U1(194, 203, 25, 185, 106, 189))
      end
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 99, 131, 134, 153, 249, 205, 58, 94, 165, 148, 194, 122, 97, 232, 54, 233, 99, 163, 137, 156, 247, 145),
        U1(193, 203)
      }))).isInit and DataMgr.corpsInfo.corpsMemberList then
        goto lbl_150
        if tostring(_ARG_0_) == tostring(U1(193, 203).id) then
          return (U1(199, 214, 2, 172, 119))
        end
        ::lbl_150::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 102, 158, 157, 140, 228, 135, 120, 93, 173, 154, 200, 70, 93, 233, 33, 238, 79, 154, 150, 144, 255, 157),
        U1(192)
      }))).GetRecentTeammateData(_ARG_0_) then
        return (U1(214, 220, 19, 185, 106, 173))
      end
      if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 108, 142, 135, 199, 230, 140, 49, 88, 161, 162, 205, 71, 113, 216, 34, 235, 121, 153, 138, 157))):IsNearsFriend(_ARG_0_) then
        return (U1(200, 219, 3, 178, 97, 184, 136, 191, 63))
      end
      do return (U1(203, 205, 24, 185, 118)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowInviteTip"] = function()
    if not UIManager.IsUIShow(UIManager.UI_Config.Return_Team_Guidance_UIBP) then
      UIManager.CloseUI(UIManager.UI_Config.Return_Team_Guidance_UIBP)
    end
    log(bWriteLog and table.concat({
      U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
      U1(247, 209, 31, 171, 77, 183, 140, 186, 50, 68, 134, 132, 193)
    }))
    if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
      return
    end
    if GameStatus.IsCollectionHallMode() and _G.SubsystemMgr and _G.SubsystemMgr:Get((U1(244, 213, 17, 178, 71, 145, 165, 146, 40, 72, 191, 170, 212, 91, 77, 208, 33, 224, 100, 137, 171, 170, 230, 138, 51, 95, 182))) and (_G.SubsystemMgr and _G.SubsystemMgr:Get((U1(244, 213, 17, 178, 71, 145, 165, 146, 40, 72, 191, 170, 212, 91, 77, 208, 33, 224, 100, 137, 171, 170, 230, 138, 51, 95, 182)))).IsGuiding and (_G.SubsystemMgr and _G.SubsystemMgr:Get((U1(244, 213, 17, 178, 71, 145, 165, 146, 40, 72, 191, 170, 212, 91, 77, 208, 33, 224, 100, 137, 171, 170, 230, 138, 51, 95, 182)))):IsGuiding() then
      return
    end
    log_tree(table.concat({
      U1(255, 218, 24, 169, 102, 132, 174, 182, 39, 76, 135, 157, 255, 80, 101, 196, 45, 250, 116, 137, 153, 199, 217, 139, 57, 70, 139, 147, 215, 76, 118, 226, 16, 240, 96, 208, 196, 173, 255, 146),
      U1(201, 236, 0, 146, 97, 174, 169, 170, 53, 85, 183, 128, 159, 92, 124, 225, 61, 253, 101, 173, 132, 153, 230, 154, 7, 68, 167, 136, 196, 5, 63, 167)
    }), U2.inviteApplyQueue)
    if not U2.inviteApplyQueue or not U2.inviteApplyQueue[1] then
      U2.inviteApplyQueue = {}
      return
    end
    if not U2.IsInviteUIShow() then
      U2.RemoveSameInviteInfo()
      if U2.IsRecommendType(U2.inviteApplyQueue[1]) then
      elseif U2.inviteApplyQueue[1].from == U3.RecommendTeamBackUser and U2.CanShowAssemblyInviteTip() then
      elseif U2.inviteApplyQueue[1].from == U3.WOWTeam then
      elseif U2.inviteApplyQueue[1].from == U3.TPlanPVE then
      else
      end
    end
    return
  end,
  ["RemoveCurInviteInfo"] = function()
    return
  end,
  ["RemoveSameInviteInfo"] = function()
    if not (inviteApplyQueue and #inviteApplyQueue) or (inviteApplyQueue and #inviteApplyQueue) < 2 then
      return
    end
    if inviteApplyQueue[nil] and inviteApplyQueue[nil].playerId == inviteApplyQueue[1].playerId and inviteApplyQueue[nil].inviterTeamID == inviteApplyQueue[1].inviterTeamID and inviteApplyQueue[nil].type == inviteApplyQueue[1].type and inviteApplyQueue[nil].from == inviteApplyQueue[1].from then
    end
    if 0 < 0 + 1 then
    end
    return
  end,
  ["CanShowAssemblyInviteTip"] = function()
    do return (require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).CheckAndSaveCurrentDate_N(require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).ePlayerPrefsType.eBackUserInviteTipsCheckTime, true)) end
    return
  end,
  ["ShowNextInviteTip"] = function()
    log(bWriteLog and table.concat({
      U1(255, 218, 24, 169, 102, 132, 174, 182, 39, 76, 135, 157, 255, 80, 101, 196, 45, 250, 116, 137, 153, 199, 217, 139, 57, 70, 140, 152, 217, 81, 75, 233, 50, 240, 100, 153, 176, 144, 234, 219),
      U1(141)
    }))
    U2.ShowInviteTip()
    return
  end,
  ["IsInviteUIShow"] = function()
    do return UIManager.IsUIShow(UIManager.UI_Config.Team_Invite_Tip_UIBP) or UIManager.IsUIShow(UIManager.UI_Config.Recommend_Team_Invite_Tip_UIBP) or UIManager.IsUIShow(UIManager.UI_Config.Assembly_Team_Invite_Tip_UIBP) or UIManager.IsUIShow(UIManager.UI_Config.WOW_Team_Invite_Tip_UIBP) or UIManager.IsUIShow(UIManager.UI_Config.TPlanPVE_Team_Invite_Tip_UIBP) end
    return
  end,
  ["IsInviteUIReadyToShow"] = function()
    if inviteApplyQueue and U1.next(inviteApplyQueue) then
      return true
    end
    do return false end
    return
  end,
  ["IsRecommendType"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return false
      end
      do return _ARG_0_.from == RecommendTeamFriend or _ARG_0_.from == RecommendTeamCorps or _ARG_0_.from == RecommendTeamStranger or _ARG_0_.from == RecommendTeamFriendCorps or _ARG_0_.from == RecommendTeamSocialEdge or _ARG_0_.from == RecommendTeamLuckyStar or _ARG_0_.from == RecommendReturnPlayer end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanInviteFriend"] = function(_ARG_0_, _ARG_1_)
    do
      if IsInOneMoreGameTeam() then
        if not _ARG_1_ then
          U1.ShowNotice(8003)
        end
        return false
      end
      if not U2.CanInviteInBan() then
        U1.log(U1.bWriteLog and U1.table.concat({
          U3(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 23, 232, 110, 165, 154, 159, 227, 151, 51, 119, 176, 148, 196, 75, 102, 167, 42, 246, 100, 220, 169, 152, 238, 144),
          U3(204, 234, 9, 175, 112, 188, 151, 253, 5, 64, 188, 164, 223, 67, 123, 227, 49, 192, 110, 174, 149, 135, 162, 202)
        }))
        return false
      end
      if not _ARG_0_ then
        return true
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_) then
        if U1.require((U1.table.concat({
          U3(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
          U3(203, 215, 47, 177, 101, 176, 148)
        }))).IsInXMission() then
          if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).socialland_type and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).socialland_type == 1 then
            if not _ARG_1_ then
            end
            return false
          elseif U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).cwow_type and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).cwow_type == 1 then
            if not _ARG_1_ then
            end
            return false
          end
        elseif U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).tplan_type and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).tplan_type == 1 then
          if not _ARG_1_ then
          end
          return false
        elseif U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).socialland_type and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).socialland_type == 1 then
          if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):IsSelect8PlayersMode() then
            if not _ARG_1_ then
            end
            return false
          end
        elseif U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).cwow_type and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).cwow_type == 1 and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):IsSelect8PlayersMode() then
          if not _ARG_1_ then
          end
          return false
        end
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
        return GetTeamNum() < U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGCMulti):GetMaxTeamSize()
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInTeam"] = function()
    if teamInfo and teamInfo.player_count then
      return teamInfo.player_count > 1
    else
      return false
    end
    return
  end,
  ["SendInMainCity"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanInvite"] = function()
    log_tree(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 23, 232, 110, 165, 154, 159, 227, 151, 51, 17, 182, 152, 192, 72, 75, 233, 34, 246, 42), U2.teamInfo)
    log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 23, 232, 110, 165, 154, 159, 227, 151, 51, 17, 175, 156, 217, 113, 103, 230, 41, 215, 101, 145, 222) .. tostring(U2.GetMaxTeamNum()))
    if U2.teamInfo and U2.teamInfo.player_count then
      return U2.teamInfo.player_count < U2.GetMaxTeamNum()
    else
      return false
    end
    return
  end,
  ["CanTeamUp"] = function(_ARG_0_)
    do
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        return false
      end
      if U1.GetTeamNum() >= U1.GetMaxTeamNum() then
        return false
      end
      if U1.IsInOneMoreGameTeam() then
        if _ARG_0_ == false then
        else
          ShowNotice(8003)
        end
        return false
      end
      if not U2.CanInviteInBan() then
        return false
      end
      if U2.nMatchStatus == ENUM_MatchStatus.Matching then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMemberInSocialLand"] = function()
    if teamInfo and teamInfo.members then
      goto lbl_21
      if (nil).socialland_type and (nil).socialland_type == 1 then
        return true
      end
      ::lbl_21::
    end
    do return false end
    return
  end,
  ["KeepJoinApply"] = function()
    if #inviteApplyQueue > 0 and #inviteApplyQueue > 0 then
      if inviteApplyQueue[nil] then
        if inviteApplyQueue[nil].type == U1.Invite then
        elseif inviteApplyQueue[nil].type == U1.RoomInvite or inviteApplyQueue[nil].type == U1.AsiaRoomInvite then
        end
      end
    end
    return
  end,
  ["RemoveAllInvite"] = function()
    if #inviteApplyQueue > 0 then
      if inviteApplyQueue[nil].type == U1.Invite then
      elseif inviteApplyQueue[nil].type == U1.Join then
      elseif inviteApplyQueue[nil].type == U1.RoomInvite or inviteApplyQueue[nil].type == U1.AsiaRoomInvite then
      end
    end
    inviteApplyQueue = {}
    return
  end,
  ["RemoveAllRoomInvite"] = function()
    log(bWriteLog and table.concat({
      U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
      U1(246, 220, 29, 179, 114, 188, 187, 191, 42, 115, 189, 130, 220, 124, 124, 225, 61, 253, 101)
    }))
    if #U2.inviteApplyQueue > 0 then
      if U2.inviteApplyQueue[U1(246, 220, 29, 179, 114, 188, 187, 191, 42, 115, 189, 130, 220, 124, 124, 225, 61, 253, 101)] and (U2.inviteApplyQueue[U1(246, 220, 29, 179, 114, 188, 187, 191, 42, 115, 189, 130, 220, 124, 124, 225, 61, 253, 101)].type == U3.RoomInvite or U2.inviteApplyQueue[U1(246, 220, 29, 179, 114, 188, 187, 191, 42, 115, 189, 130, 220, 124, 124, 225, 61, 253, 101)].type == U3.AsiaRoomInvite) and U2.inviter and U2.inviter == U2.inviteApplyQueue[U1(246, 220, 29, 179, 114, 188, 187, 191, 42, 115, 189, 130, 220, 124, 124, 225, 61, 253, 101)].playerId then
      end
    end
    return
  end,
  ["RemoveInvite"] = function(_ARG_0_)
    do
      goto lbl_15
      if nil == _ARG_0_ and nil then
      else
        ::lbl_15::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTeamMemberWear"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not GetMemberInfo(U1.tonumber(_ARG_0_)) then
        return
      end
      if GetMemberInfo(U1.tonumber(_ARG_0_)).wear_ext then
        GetMemberInfo(U1.tonumber(_ARG_0_)).wear_ext = _ARG_2_
      else
      end
      if GetMemberInfo(U1.tonumber(_ARG_0_)).ware then
        GetMemberInfo(U1.tonumber(_ARG_0_)).ware = _ARG_1_
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_stranger_staus_rsp"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        goto lbl_12
        goto lbl_14
        ::lbl_12::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_14::
      if 0 < nil and not U1.GetMemberInfo(nil) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInOneMoreGameTeam"] = function()
    if GetOneMoreGameInfo() then
      if GetOneMoreGameInfo().member_status and U1.next(GetOneMoreGameInfo().member_status) then
        goto lbl_38
        if GetOneMoreGameInfo().team_leader == GetSelfUID() and U1.tonumber(nil) == GetSelfUID() then
        elseif (nil).status == 0 then
          goto lbl_40
        end
        ::lbl_38::
      end
      ::lbl_40::
      if true and GetOneMoreGameInfo().team_unlock_time and 0 < GetOneMoreGameInfo().team_unlock_time and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 176, 41, 76, 191, 130, 223, 27, 102, 254, 57, 236, 95, 153, 128, 128, 230))).GetServerTimeInSec() > GetOneMoreGameInfo().team_unlock_time then
      end
    end
    do return false end
    return
  end,
  ["ReleaseOneMoreGameInfo"] = function()
    ClearOneMoreGameInfo()
    U1.UIManager.CloseUI(U1.UIManager.UI_Config.one_more_team_tip)
    return
  end,
  ["ClearOneMoreGameInfo"] = function()
    oneMoreGameTeamInfo = nil
    if teamInfo then
      teamInfo.team_omb_info = nil
    end
    return
  end,
  ["GetOneMoreGameInfo"] = function()
    if oneMoreGameTeamInfo then
    else
    end
    do return teamInfo.team_omb_info end
    return
  end,
  ["Enter"] = function()
    log(bWriteLog and table.concat({
      U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
      U1(225, 215, 4, 185, 118)
    }))
    U2.teamInfo = {}
    U2.teamInfo.members = {}
    U2.team_info_request()
    if require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).LoadFileToTable_N(require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).ePlayerPrefsType.eTeamVehicleShowUID) then
      U2.nShowVehicleUID = tonumber((require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
        U1(215)
      }))).LoadFileToTable_N(require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
        U1(215)
      }))).ePlayerPrefsType.eTeamVehicleShowUID))) or 0
    end
    return
  end,
  ["ReconnectFetchTeamUpInfo"] = function()
    changeMemberInfo = {}
    ReleaseOneMoreGameInfo()
    team_info_request()
    return
  end,
  ["CheckInviteList"] = function()
    log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 23, 225, 101, 143, 159, 160, 228, 149, 63, 69, 167, 177, 200, 86, 118))
    if not GameStatus.IsInLobbyOrMainCity() then
      log_warning(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 23, 225, 101, 143, 159, 160, 228, 149, 63, 69, 167, 177, 200, 86, 118, 167, 105, 185, 126, 147, 144, 217, 243, 157),
        U1(232, 214, 18, 190, 125, 150, 136, 158, 39, 72, 188, 174, 216, 65, 107)
      }))
      return
    end
    if U2.inviteApplyQueue and #U2.inviteApplyQueue > 0 then
      U2.ShowInviteTip()
    end
    return
  end,
  ["UpdateVoiceInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetMemberInfo(_ARG_0_) then
        return
      end
      teamInfo.members[_ARG_0_].voice = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateClanName"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetMemberInfo(_ARG_0_) then
        return
      end
      teamInfo.members[_ARG_0_].carteam_name = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCrops"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not GetMemberInfo(_ARG_0_) then
        return
      end
      teamInfo.members[_ARG_0_].corps_name = _ARG_1_
      teamInfo.members[_ARG_0_].corps_icon = _ARG_2_
      teamInfo.members[_ARG_0_].cur_corps_alias_id = _ARG_3_
      teamInfo.members[_ARG_0_].corps_position = _ARG_4_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCredit"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetMemberInfo(_ARG_0_) then
        return
      end
      teamInfo.members[_ARG_0_].credit = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateVehicle"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212)
      }))
      if _ARG_0_ and _ARG_0_.uid then
        if U2.teamInfo and U2.teamInfo.members then
          goto lbl_132
          if U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212) == _ARG_0_.uid then
            if _ARG_0_.vst_info then
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.skin_id = _ARG_0_.vst_info.skin_id
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.vst_type = _ARG_0_.vst_info.vst_type
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.skin_style_list = _ARG_0_.vst_info.skin_style_list
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.show_tire_feature = _ARG_0_.vst_info.show_tire_feature
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.car_install_acc = _ARG_0_.vst_info.car_install_acc
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.chassis_light = _ARG_0_.vst_info.chassis_light
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.car_applique_list = _ARG_0_.vst_info.car_applique_list
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.brake_caliper = _ARG_0_.vst_info.brake_caliper
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.wheel_hub = _ARG_0_.vst_info.wheel_hub
              U1(241, 201, 20, 189, 112, 188, 172, 182, 46, 72, 177, 129, 212).vst_info.sunroof = _ARG_0_.vst_info.sunroof
            end
          else
            ::lbl_132::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
        if tonumber(_ARG_0_.uid) == U2.nShowVehicleUID and _ARG_0_.vst_info.skin_id == 0 and _ARG_0_.vst_info.vst_type == 0 then
          U2.nShowVehicleUID = U2.GetSelfUID()
        end
      end
      U2.ShowVehicleAvatar()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBackground"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(241, 201, 20, 189, 112, 188, 184, 178, 37, 74, 181, 159, 222, 64, 124, 243)
      }))
      if _ARG_0_ and _ARG_0_.uid and U2.teamInfo and U2.teamInfo.members then
        goto lbl_97
        if U1(241, 201, 20, 189, 112, 188, 184, 178, 37, 74, 181, 159, 222, 64, 124, 243) == _ARG_0_.uid then
          if _ARG_0_.background then
            U1(241, 201, 20, 189, 112, 188, 184, 178, 37, 74, 181, 159, 222, 64, 124, 243).background = _ARG_0_.background
          end
        else
          ::lbl_97::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckInviteAutoRefuse"] = function(_ARG_0_)
    do
      do return CheckAutoRefuse(autoRefuseInviterMap, _ARG_0_, U1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckApplyAutoRefuse"] = function(_ARG_0_)
    do
      do return CheckAutoRefuse(autoRefuseApplierMap, _ARG_0_, U1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckSoloAutoRefuse"] = function(_ARG_0_)
    do
      do return CheckAutoRefuse(autoRefuseSoloMap, _ARG_0_, U1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAutoRefuse"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_0_ and _ARG_1_) or not _ARG_2_ then
        return false
      end
      if not _ARG_0_[_ARG_1_] then
        return false
      end
      do return _ARG_2_ > require((U1(199, 213, 25, 185, 106, 173, 212, 176, 41, 76, 191, 130, 223, 27, 102, 254, 57, 236, 95, 153, 128, 128, 230))).GetServerTimeInSec() - _ARG_0_[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOldGameType"] = function(_ARG_0_)
    do
      if _ARG_0_ and 200 < _ARG_0_ then
        return 2
      else
        return 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CacheMsg"] = function(_ARG_0_)
    do
      nMsgIdGuid = nMsgIdGuid + 1
      msgContentCacheMap[nMsgIdGuid] = _ARG_0_
      do return nMsgIdGuid end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckInviteApplyOnTeamChange"] = function(_ARG_0_)
    do
      if teamInfo and teamInfo.id and teamInfo.id ~= _ARG_0_.id then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReLinkLine"] = function(_ARG_0_)
    do
      log_tree(table.concat({
        U1(255, 253, 21, 189, 106, 147, 163, 135, 27, 1, 134, 136, 208, 88, 71, 231, 26, 236, 119, 191, 141, 154, 254, 134, 59, 31, 144, 152, 237, 76, 108, 236, 8, 240, 126, 153, 196, 141, 202, 146),
        U1(214, 216, 29)
      }), _ARG_0_)
      if not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U1(246, 220, 60, 181, 106, 178, 182, 186, 40, 68, 242, 153, 225, 84, 96, 246, 57, 169, 110, 131, 154, 140)
        }))
        U2.team_info_request()
        return
      end
      if not U2.GetMemberInfo(_ARG_0_.uid) then
        return
      end
      if not (U2.GetMemberInfo(_ARG_0_.uid).svr ~= nil) and _ARG_0_.svr ~= nil then
        U2.lastMemberLoginTime = true
      end
      U2.GetMemberInfo(_ARG_0_.uid).svr = _ARG_0_.svr
      U2.GetMemberInfo(_ARG_0_.uid).game_start = _ARG_0_.game_start or 0
      U2.GetMemberInfo(_ARG_0_.uid).socialland_type = _ARG_0_.socialland_type or 0
      U2.GetMemberInfo(_ARG_0_.uid).sub_mode = _ARG_0_.sub_mode or 0
      U2.GetMemberInfo(_ARG_0_.uid).cwow_type = _ARG_0_.cwow_type or 0
      return
    end
  end,
  ["CheckSameInvite"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_117
      if tonumber((nil).playerId) == tonumber(_ARG_0_) and (nil).type == _ARG_1_ then
        return nil
      end
      ::lbl_117::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OtherJoinTeam"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 27, 253, 104, 137, 134, 163, 229, 138, 56, 101, 167, 156, 204))
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U1(235, 205, 24, 185, 118, 147, 149, 186, 40, 117, 183, 140, 220, 21, 102, 199, 53, 251, 97, 129, 212, 135, 229, 141, 51)
        }))
        U2.team_info_request()
        return
      end
      if not _ARG_1_.uid then
        return
      end
      if not U2.teamInfo or not U2.teamInfo.members then
        return
      end
      if U2.GetTeamNum() > 1 and _ARG_0_ ~= U2.teamInfo.id then
        return
      end
      if U2.GetTeamNum() == 1 then
        if U2.GetMemberInfo((U2.GetSelfUID())) and not U2.GetMemberInfo((U2.GetSelfUID())).join_time then
          U2.GetMemberInfo((U2.GetSelfUID())).join_time = 0
        end
        U2.teamInfo.leader = U2.GetSelfUID(), U2.GetMemberInfo((U2.GetSelfUID())), U2.teamInfo
      end
      require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).members[tonumber(_ARG_1_.uid)] = _ARG_1_
      require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).player_count = require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CountTable(require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).members)
      if _ARG_1_.join_from == U3.WOWTeam or _ARG_1_.join_from == U3.WOWTogether then
        if UIManager.IsUIShow(UIManager.UI_Config.TeamPlatform_MyTeam_UIBP) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QuitTeam"] = function()
    U2.nShowVehicleUID = 0
    U2.afterteamID = 0
    if not U2.teamInfo then
      return
    end
    if not U2.GetMemberInfo((U2.GetSelfUID())) then
      return
    end
    if U2.GetTeamNum() == 1 then
      return
    end
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).members = {}
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).members[U2.GetSelfUID()] = U2.GetMemberInfo((U2.GetSelfUID())), require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))), require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo), require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).members
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).player_count = nil
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).create_time = nil
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).AntsVoice_url = nil
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).leader = nil
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).zone_id = nil
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).is_participate_competition = nil
    require((U1(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(U2.teamInfo).team_omb_info = nil
    return
  end,
  ["OtherQuitTeam"] = function(_ARG_0_)
    do
      if not teamInfo then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U2(235, 205, 24, 185, 118, 136, 143, 186, 50, 117, 183, 140, 220, 21, 70, 242, 53, 228, 85, 156, 186, 140, 253, 176, 47, 66, 182, 152, 204, 11, 118, 226, 37, 244, 89, 146, 130, 150, 186, 157),
          U2(203, 215, 21)
        }))
        team_info_request()
        return
      end
      if not _ARG_0_ then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U2(235, 205, 24, 185, 118, 136, 143, 186, 50, 117, 183, 140, 220, 21, 103, 254, 48, 169, 105, 159, 212, 135, 229, 141, 51)
        }))
        team_info_request()
        return
      end
      _ARG_0_ = U1.tonumber(_ARG_0_)
      if not (teamInfo and teamInfo.members) or not teamInfo.members[_ARG_0_] then
        return
      end
      U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(teamInfo).members[_ARG_0_] = nil
      ugcModInfoSyncCache[_ARG_0_] = nil
      U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(teamInfo).player_count = U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CountTable(U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(teamInfo).members)
      if U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(teamInfo).player_count == 1 then
        nShowVehicleUID = 0
        if not IsInOneMoreGameTeam() then
          U1.require((U2(199, 214, 29, 177, 107, 183, 212, 167, 39, 67, 190, 136, 238, 64, 102, 254, 56))).CopyTable(teamInfo).team_omb_info = nil
        end
        ugcModInfoSyncCache = {}
      elseif nShowVehicleUID == _ARG_0_ then
        nShowVehicleUID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_info_request"] = function()
    log(bWriteLog and table.concat({
      U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
      U1(208, 220, 17, 177, 91, 176, 148, 181, 41, 126, 160, 136, 192, 64, 119, 228, 32)
    }))
    return
  end,
  ["team_invite_request"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 32, 236, 97, 129, 171, 128, 228, 149, 63, 69, 167, 162, 211, 64, 115, 242, 33, 234, 100, 220, 145, 144, 254, 211),
        U1(153, 153)
      }) .. _ARG_0_ .. U1(136, 153, 22, 174, 107, 180, 218, 238, 102) .. tostring(_ARG_1_))
      log_tree(U1(201, 208, 3, 175, 109, 182, 148, 154, 40, 71, 189, 205, 140, 21), _ARG_2_)
      log_tree(U1(208, 220, 17, 177, 84, 181, 155, 167, 32, 78, 160, 128, 248, 91, 116, 248, 116, 180, 32), _ARG_3_)
      log_tree(U1(197, 204, 4, 179, 82, 182, 147, 176, 35, 115, 183, 156, 196, 80, 97, 227, 116, 180, 32), _ARG_4_)
      if _ARG_1_ == U2.E_InviteFromType.FireBaseInvite then
      elseif _ARG_1_ == U2.E_InviteFromType.TPlanPVE then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection).hasSelectTxMission then
        _ARG_1_ = U2.E_InviteFromType.TPlan
      end
      if _ARG_1_ == U2.E_InviteFromType.FlashTeam then
      end
      do return end
      _ARG_1_ = U1[253]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_invite_reply"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      goto lbl_64
      if U1(192).friUid == _ARG_1_ then
        _ARG_4_ = U1(192).from
      else
        ::lbl_64::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if 0 ~= U1(192) then
      end
      if _ARG_5_ then
        _ARG_3_ = U1(201, 220, 4, 174, 107, 134) .. _ARG_3_
      end
      if (_ARG_4_ == U2.WOWTeam or _ARG_4_ == U2.WOWTogether) and _ARG_0_ and tostring(_ARG_0_) == U1(203, 210) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_apply_reply"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(208, 220, 17, 177, 91, 184, 138, 163, 42, 88, 141, 159, 212, 69, 126, 238, 116, 224, 115, 156, 145, 155, 231, 138, 34, 17, 255, 221)
      }) .. _ARG_0_ .. U1(136, 153, 5, 175, 97, 171, 147, 183, 102, 28, 242) .. _ARG_1_)
      goto lbl_160
      if U1(192).friUid == _ARG_1_ then
        _ARG_4_ = 5
      else
        ::lbl_160::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["room_invite_reply"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(214, 214, 31, 177, 91, 176, 148, 165, 47, 85, 183, 178, 195, 80, 98, 251, 45, 169, 105, 159, 132, 140, 248, 142, 63, 69, 226, 192, 129)
      }) .. _ARG_0_ .. U1(136, 153, 2, 179, 107, 180, 165, 186, 34, 1, 239, 205) .. _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[116]
    end
  end,
  ["team_apply_request"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_ then
        log_warning((table.concat({
          U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U1(208, 220, 17, 177, 91, 184, 138, 163, 42, 88, 141, 159, 212, 68, 103, 242, 39, 253, 44, 204, 161, 160, 206, 195, 63, 66, 226, 147, 200, 73)
        })))
        return
      end
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(208, 220, 17, 177, 91, 184, 138, 163, 42, 88, 141, 159, 212, 68, 103, 242, 39, 253, 32, 153, 135, 140, 248, 138, 50, 17, 255, 221)
      }) .. _ARG_0_ .. U1(136, 153, 22, 174, 107, 180, 218, 238, 102) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_quit_request"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        log_warning((table.concat({
          U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U1(208, 220, 17, 177, 91, 168, 143, 186, 50, 126, 160, 136, 192, 64, 119, 228, 32, 169, 116, 137, 149, 132, 227, 135, 118, 88, 177, 221, 207, 76, 110)
        })))
        U2.on_team_quit_respond(NetErrorCode_NONE)
        return
      end
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(208, 220, 17, 177, 91, 168, 143, 186, 50, 126, 160, 136, 192, 64, 119, 228, 32, 169, 116, 137, 149, 132, 227, 135, 118, 12, 226)
      }) .. _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JoinTeamByChat"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(238, 214, 25, 178, 80, 188, 155, 190, 4, 88, 145, 133, 208, 65, 50, 226, 61, 237, 32, 209, 212)
      }) .. tostring(_ARG_0_) .. U1(136, 153, 4, 185, 101, 180, 147, 183, 102, 28, 242) .. tostring(_ARG_1_) .. U1(136, 153, 3, 174, 103, 249, 199, 243) .. tostring(_ARG_2_))
      if IsWoWEditor then
        return
      end
      if U2.GetSelfUID() == tonumber(_ARG_0_) then
        if _ARG_2_ ~= ShareSource.Facebook then
          ShowNotice(110045)
        end
        return
      end
      U2.team_invite_reply(U1(193, 215, 28, 181, 119, 173), tonumber(_ARG_0_), tonumber(_ARG_1_), _ARG_2_, _ARG_3_, _ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_kick_request"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(208, 220, 17, 177, 91, 178, 147, 176, 45, 126, 160, 136, 192, 64, 119, 228, 32, 169, 117, 159, 145, 155, 227, 135, 118, 12, 226)
      }) .. _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["recv_stau_request"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_change_type_request"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_change_fill_request"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(208, 220, 17, 177, 91, 186, 146, 178, 40, 70, 183, 178, 215, 92, 126, 251, 11, 251, 101, 157, 129, 140, 249, 151, 118, 87, 171, 145, 205, 5, 63, 167)
      }) .. tostring(_ARG_0_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_change_leader_request"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(208, 220, 17, 177, 91, 186, 146, 178, 40, 70, 183, 178, 221, 80, 115, 243, 49, 251, 95, 158, 145, 152, 255, 134, 37, 69, 226, 147, 196, 82, 93, 235, 33, 248, 116, 153, 150, 217, 167, 211)
      }) .. _ARG_0_)
      if LobbySystem.isInMatch then
        ShowNotice(110017)
        return
      end
      if U2.GetMemberInfo(_ARG_0_) and not U2.GetMemberInfo(_ARG_0_).svr then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["stranger_all_status_request"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["get_teamid_for_plat_request"] = function()
    log(bWriteLog and table.concat({
      U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
      U1(195, 220, 4, 131, 112, 188, 155, 190, 47, 69, 141, 139, 222, 71, 77, 231, 56, 232, 116, 179, 134, 140, 251, 150, 51, 66, 182)
    }))
    if _G.BP_Platform == BP_ENUM_PLAYFORM_WX and Client.IsInstallWX(NetInterface) == false then
      ShowNotice(110126)
      return
    elseif _G.BP_Platform == BP_ENUM_PLAYFORM_BGBG and Client.IsInstallFaceBook(NetInterface) == false then
      ShowNotice(110125)
      return
    end
    return
  end,
  ["ReportVoiceInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if GameStatus.GetGameStatus() == GameStatus.Login then
        return
      end
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(246, 220, 0, 179, 118, 173, 172, 188, 47, 66, 183, 164, 223, 83, 125, 173)
      }) .. _ARG_0_ .. U1(205, 202, 63, 172, 97, 183, 192) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportSpeakerInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if GameStatus.GetGameStatus() == GameStatus.Login then
        return
      end
      log(bWriteLog and table.concat({
        U1(255, 253, 21, 189, 106, 147, 163, 135, 27, 1, 134, 136, 208, 88, 71, 231, 26, 236, 119, 191, 141, 154, 254, 134, 59, 31, 144, 152, 209, 74, 112, 243, 23, 233, 117, 157, 143, 156, 232, 186),
        U1(202, 223, 31, 230)
      }) .. _ARG_0_ .. U1(205, 202, 63, 172, 97, 183, 192) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_player_action"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 32, 236, 97, 129, 171, 153, 230, 130, 47, 84, 176, 162, 192, 70, 118, 238, 43, 247, 48, 157, 135, 141, 243, 156),
        U1(202, 230, 25, 184, 36, 228, 218)
      }) .. tostring(_ARG_0_))
      _ARG_1_ = _ARG_1_ or 0
      if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).IsInviteAction(_ARG_0_) then
        if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).CheckHasEquipXSuitByAction(_ARG_0_) then
          if not require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
            U1(203, 215, 47, 177, 101, 176, 148)
          }))).IsInXMission() then
          end
        else
          return
        end
      end
      if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).IsBattleEmotion(_ARG_0_) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):Is2LevelParticleEmote(_ARG_0_) then
        _ARG_0_ = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_0_)
      end
      if CDataTable.GetTableData(U1(237, 205, 21, 177), _ARG_0_) and CDataTable.GetTableData(U1(237, 205, 21, 177), _ARG_0_).ItemSubType == 2206 then
      end
      _ARG_2_ = _ARG_2_ or {}
      if not _ARG_2_.stopAction then
        if not require((U1(199, 213, 25, 185, 106, 173, 212, 176, 41, 76, 191, 130, 223, 27, 103, 254, 11, 252, 116, 133, 152))).CanClickNow(require((U1(199, 213, 25, 185, 106, 173, 212, 176, 41, 76, 191, 130, 223, 27, 103, 254, 11, 252, 116, 133, 152))).ClickFrequencyLimit.SyncLobbyEmotion, false) then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ErrorNotice"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ or _ARG_2_ == _ENV() then
        U1.ShowNotice(_ARG_0_)
      else
        U1.ShowNotice(U1.LocUtil.LocalizeResFormat(_ARG_1_, _ARG_2_))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_invite_respond"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 168, 97, 184, 151, 140, 47, 79, 164, 132, 197, 80, 77, 229, 49, 250, 112, 131, 154, 141, 170, 144, 34, 80, 182, 152, 129, 24, 34)
      }) .. _ARG_0_ .. U1(136, 153, 25, 178, 114, 176, 142, 182, 35, 1, 239, 205) .. _ARG_1_ .. U1(132, 236, 3, 185, 118, 151, 147, 176, 45, 1, 239, 205) .. tostring(_ARG_4_))
      log(bWriteLog and table.concat({
        U1(255, 218, 24, 169, 102, 132, 174, 182, 39, 76, 135, 157, 255, 80, 101, 196, 45, 250, 116, 137, 153, 199, 229, 141, 9, 69, 167, 156, 204, 122, 107, 233, 50, 240, 100, 153, 187, 139, 255, 128),
        U1(212, 214, 30, 184, 36, 172, 137, 182, 52, 111, 187, 142, 218, 21, 47, 183)
      }) .. tostring(_ARG_4_))
      log(bWriteLog and table.concat({
        U1(255, 218, 24, 169, 102, 132, 174, 182, 39, 76, 135, 157, 255, 80, 101, 196, 45, 250, 116, 137, 153, 199, 229, 141, 9, 69, 167, 156, 204, 122, 107, 233, 50, 240, 100, 153, 187, 139, 255, 128),
        U1(212, 214, 30, 184, 36, 173, 159, 171, 50, 126, 187, 137, 145, 8, 50)
      }) .. tostring(_ARG_5_))
      if _ARG_0_ == NetErrorCode_NONE then
        ShowNotice(LocUtil.LocalizeResFormat(110004))
      elseif _ARG_0_ == U1(208, 216, 2, 187, 97, 173, 165, 189, 41, 85, 141, 130, 223, 89, 123, 249, 49) then
        ShowNotice(110016)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 41, 71, 180, 129, 216, 91, 119) then
        ShowNotice(110016)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 128, 212, 65, 96, 248, 11, 250, 99, 137, 154, 138, 239) then
        ShowNotice(1994019)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 176, 137, 140, 32, 84, 190, 129) then
        ShowNotice(110007)
      elseif _ARG_0_ == U1(214, 220, 22, 169, 119, 188) then
        if _ARG_5_ then
        else
          U2.ErrorNotice(110011, 38826, _ARG_4_)
        end
      elseif _ARG_0_ == U1(208, 208, 29, 185, 107, 172, 142) then
        U2.ErrorNotice(110011, 38828, _ARG_4_)
      elseif _ARG_0_ == U1(197, 204, 4, 179, 86, 188, 156, 166, 53, 68, 157, 131, 229, 80, 115, 250, 23, 225, 97, 130, 147, 140) then
        ShowNotice(110056)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(110059)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 136, 140, 47, 79, 141, 138, 208, 88, 119) then
        ShowNotice(9911106)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 138, 208, 88, 119) then
        ShowNotice(9911106)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 36, 176, 148, 243, 43, 64, 166, 142, 217) then
        ShowNotice(110060)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(110061)
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 63, 95, 180, 148, 213, 64, 93, 245, 33, 234, 96, 147, 138, 157, 186, 190),
          U1(197, 205, 19, 180, 87, 160, 137, 167, 35, 76, 252, 188, 196, 80, 96, 238, 4, 229, 97, 149, 145, 155, 217, 151, 55, 69, 167, 221, 144)
        }))
        U3.QueryPlayerState()
      elseif _ARG_0_ == U1(202, 214, 4, 131, 119, 184, 151, 182, 25, 87, 183, 159, 194, 92, 125, 249) then
        U2.HandleVersionErrorCode(_ARG_2_, true)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 46, 64, 161, 178, 197, 80, 115, 250) then
        ShowNotice(110044)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 254, 40, 78, 166, 192, 216, 91, 63, 227, 49, 232, 109, 193, 131, 129, 227, 151, 51, 93, 171, 142, 213) then
        ShowNotice(8889349)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 39, 77, 160, 136, 208, 81, 107, 200, 61, 231, 95, 152, 145, 136, 231) then
        ShowNotice(6283)
        if _ARG_1_ then
        end
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 37, 78, 188, 137, 238, 89, 123, 250, 61, 253) then
        ShowNotice(7134)
      elseif _ARG_0_ == U1(212, 216, 2, 189, 105, 134, 159, 161, 52) then
        ShowNotice(108109)
      elseif _ARG_0_ == U1(200, 214, 7, 131, 116, 171, 147, 188, 52, 72, 166, 148, 238, 88, 115, 227, 55, 225, 95, 142, 149, 135, 228, 134, 50) then
        U3.ShowBanTip(U3.GetTeamUpBanTip())
      elseif _ARG_0_ == U1(201, 216, 4, 191, 108, 134, 147, 160, 41, 77, 179, 153, 216, 90, 124, 200, 56, 232, 98, 137, 152, 182, 232, 130, 56, 95, 167, 153) then
        U3.ShowBanTip(LocUtil.GetLocalizeResStr(29113))
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 43, 64, 166, 142, 217, 106, 123, 228, 59, 229, 97, 152, 157, 134, 228, 188, 58, 80, 160, 152, 205, 122, 96, 230, 42, 247, 117, 152) then
      elseif _ARG_0_ == U1(195, 204, 21, 175, 112, 134, 137, 167, 39, 85, 183, 178, 211, 84, 124, 249, 49, 237) then
        ShowNotice(22006)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 33, 84, 183, 158, 197, 106, 97, 227, 53, 253, 101, 179, 150, 136, 228, 141, 51, 85) then
        ShowNotice(22007)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 112, 180, 155, 163) then
        ShowNotice(LocUtil.LocalizeResFormat(11615))
      elseif _ARG_0_ == U1(201, 220, 4, 174, 107, 134, 151, 188, 34, 68, 141, 131, 222, 65, 77, 248, 36, 236, 110) then
        ShowNotice(LocUtil.LocalizeResFormat(100080023))
      elseif _ARG_0_ == U1(202, 214, 4, 131, 98, 171, 147, 182, 40, 69) then
        ShowNotice(29388)
      elseif _ARG_0_ == U1(212, 203, 21, 131, 112, 188, 155, 190, 25, 77, 187, 128, 216, 65) then
        ShowNotice(27192)
      elseif _ARG_0_ == U1(210, 208, 21, 171, 91, 183, 149, 167, 25, 83, 187, 138, 217, 65) then
        ShowNotice(31199)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 176, 148, 165, 47, 85, 183, 192, 137, 67, 42, 186, 36, 229, 97, 149, 145, 155) then
        ShowNotice(411028)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 176, 148, 165, 47, 85, 183, 192, 194, 90, 113, 254, 53, 229, 108, 141, 154, 141, 167, 147, 58, 80, 187, 152, 211) then
        ShowNotice(411028)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 176, 148, 165, 47, 85, 183, 192, 196, 82, 113, 186, 36, 229, 97, 149, 145, 155) then
        ShowNotice(48410)
      elseif _ARG_0_ == U1(209, 222, 19, 241, 103, 184, 148, 167, 107, 72, 188, 155, 216, 65, 119, 186, 39, 230, 99, 133, 149, 133, 230, 130, 56, 85, 239, 141, 205, 68, 123, 226, 54) then
        ShowNotice(48409)
      elseif _ARG_0_ == U1(209, 222, 19, 241, 103, 184, 148, 167, 107, 72, 188, 155, 216, 65, 119, 186, 33, 231, 108, 131, 151, 130, 167, 147, 58, 80, 187, 152, 211) then
        ShowNotice(511204)
      elseif _ARG_0_ == U1(209, 222, 19, 241, 103, 184, 148, 167, 107, 72, 188, 155, 216, 65, 119, 186, 48, 236, 118, 193, 152, 128, 231, 138, 34) then
        ShowNotice(511205)
      elseif _ARG_0_ == U1(213, 203, 19, 179, 96, 188, 165, 191, 41, 70, 187, 131, 238, 89, 123, 250, 61, 253) then
        ShowNotice(LocUtil.LocalizeResFormat(200000128, _ARG_4_))
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 171, 159, 185, 35, 66, 166, 178, 194, 65, 96, 246, 58, 238, 101, 158, 135) then
        ShowNotice(773309)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 116, 171, 149, 190, 41, 85, 187, 130, 223, 106, 96, 246, 32, 224, 110, 139) then
        ShowNotice(85159)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 116, 171, 149, 190, 41, 85, 187, 130, 223, 106, 126, 246, 45, 236, 114) then
        ShowNotice(85159)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 109, 183, 140, 186, 50, 68, 160, 178, 193, 71, 125, 250, 59, 253, 105, 131, 154, 182, 231, 150, 58, 69, 171, 162, 204, 74, 102, 226) then
        ShowNotice(100610010)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 109, 183, 140, 186, 50, 68, 160, 178, 193, 71, 125, 250, 59, 253, 105, 131, 154, 182, 231, 140, 50, 84) then
        ShowNotice(100610009)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 109, 183, 140, 186, 50, 68, 160, 178, 193, 71, 125, 250, 59, 253, 105, 131, 154, 182, 248, 130, 34, 88, 172, 154) then
        ShowNotice(100610011)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 109, 183, 140, 186, 50, 68, 183, 178, 193, 71, 125, 250, 59, 253, 105, 131, 154, 182, 248, 130, 34, 88, 172, 154) then
        ShowNotice(100610012)
      elseif not U2.HandleTeamJoinErrorCode(_ARG_0_) then
        U2.HandleErrorCode(_ARG_0_, _ARG_1_, _ARG_3_)
      end
      if _ARG_0_ ~= NetErrorCode_NONE then
        EventSystem:postEvent(EVENTTYPE_FLASH_TEAM, EVENTID_FLASH_TEAM_ONEKEY_STATE_FAIL)
      end
      do return end
      _ARG_2_ = _ENV[110007]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleErrorCode"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_ == _ENV(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 159, 222, 90, 127) then
        U1.ShowNotice(110117)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 159, 222, 90, 127) then
        U1.ShowNotice(110118)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 136, 140, 47, 79, 141, 159, 222, 90, 127) then
        U1.ShowNotice(110119)
      elseif _ARG_0_ == _ENV(197, 201, 0, 176, 109, 186, 155, 189, 50, 126, 187, 131, 238, 71, 125, 248, 57) then
        U1.ShowNotice(110120)
      elseif _ARG_0_ == _ENV(207, 208, 19, 183, 75, 172, 142) then
        U1.ShowNotice(110121)
      elseif _ARG_0_ == _ENV(207, 208, 19, 183, 75, 172, 142, 140, 47, 79, 141, 140, 221, 89, 97, 227, 53, 251) then
        U1.ShowNotice(12646)
      elseif _ARG_0_ == _ENV(203, 206, 21, 184, 91, 170, 142, 178, 50, 68, 141, 143, 208, 91, 124, 242, 48) then
        U1.ShowNotice(24226)
      elseif _ARG_0_ == _ENV(203, 223, 22, 176, 109, 183, 159, 140, 47, 79, 164, 132, 197, 80, 119, 200, 55, 229, 111, 159, 145, 141) then
        U1.ShowNotice(33400)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 159, 140, 32, 83, 183, 156, 196, 80, 124, 227, 56, 240) then
        U1.require((U1.table.concat({
          _ENV(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 232, 34, 255, 124, 149, 138, 156, 197, 154),
          _ENV(202, 207, 25, 168, 97)
        }))).bAllCanInvite = false
      elseif _ARG_0_ == _ENV(203, 223, 22, 176, 109, 183, 159, 140, 47, 79, 164, 132, 197, 80, 119, 200, 33, 250, 101, 158, 171, 133, 227, 142, 63, 69) then
        U1.ShowNotice(U1.LocUtil.LocalizeResFormat(33116, _ARG_2_))
      elseif _ARG_0_ == _ENV(203, 223, 22, 176, 109, 183, 159, 140, 47, 79, 164, 132, 197, 80, 77, 228, 33, 234, 99, 137, 135, 154) then
        U1.ShowNotice(33073)
      elseif _ARG_0_ == _ENV(192, 219, 47, 185, 118, 171, 149, 161) then
        U1.ShowNotice(100500002)
      elseif _ARG_0_ == _ENV(212, 220, 17, 183, 99, 184, 151, 182, 25, 82, 183, 138, 220, 80, 124, 227, 11, 229, 105, 129, 157, 157) then
        U1.ShowNotice(46129)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVersionErrorCode"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ then
        if _ARG_0_ == 1 then
          ShowNotice(110150)
        elseif _ARG_1_ then
        else
        end
      else
        ShowNotice(110116)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_invite_notify"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if CheckInviteAutoRefuse(_ARG_0_) then
        if _ARG_3_ then
        end
        return
      end
      if IsInOneMoreGameTeam() then
        return
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_) then
        return
      end
      if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 114, 137, 132, 133, 235, 154, 120, 93, 173, 154, 200, 70, 93, 245, 33, 233, 124, 157, 157))).IsPlayingReplay() then
        return
      end
      if _ARG_3_ then
        U1.require((U1.table.concat({
          U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 99, 132, 149, 132, 250, 138, 57, 95, 177, 149, 200, 85, 44, 235, 43, 254, 121, 159, 187, 154, 242, 146),
          U2(201, 201, 25, 179, 106, 170, 146, 186, 54, 126, 161, 157, 222, 91, 97, 248, 38)
        }))).pub_id = _ARG_3_.pug_id or 0
        if ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.Tournament then
        end
        if _ARG_3_.zone_id then
          if ({
            type = 0,
            playerId = _ARG_0_,
            inviterTeamID = _ARG_1_,
            playerName = GetMemberName(_ARG_0_),
            gameType = GetOldGameType(_ARG_2_),
            showCD = U3,
            closeCD = U4,
            closeTotalTime = U4,
            modeID = _ARG_2_,
            subViewId = _ARG_4_ and _ARG_4_[1],
            ["playerName"] = _ARG_3_.playerName,
            ["src"] = _ARG_3_.src,
            ["from"] = _ARG_3_.from,
            ["missionInfo"] = _ARG_3_.missionInfo,
            ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
            ["ugcModID"] = _ARG_3_.ugcModID,
            ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
            ["isTMode"] = _ARG_3_.isTMode,
            ["tournament_id"] = _ARG_3_.tournament_id,
            ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
            ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
            ["netDelay"] = 360,
            ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
            ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
            ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
            ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
            ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
            ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
            ["squad_id"] = _ARG_3_.squad_id,
            ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
            ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
          }).zoneName ~= U2() then
          else
          end
        end
        if ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.TPlan or ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.TPlanTeamConscribeNew then
          if not U1.require((U1.table.concat({
            U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
            U2(203, 215, 47, 184, 107, 174, 148, 191, 41, 64, 182)
          }))).CheckResHasDownloaded() then
            return
          end
        elseif ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.TPlanPVE then
        elseif ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.AllStar then
          if U1.require((U1.table.concat({
            U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
            U2(203, 215, 47, 177, 101, 176, 148)
          }))).IsInXMission() then
            return
          end
        elseif ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.TapJoy then
        elseif ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.Sponsor then
        elseif ({
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }).from == U5.FlashTeam then
          if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):getOwnFlashTeamInfo() and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):getOwnFlashTeamInfo().setting and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):getOwnFlashTeamInfo().setting.block_team_invite then
            return
          end
          if _ARG_3_.squad_id then
          else
          end
        else
        end
      end
      if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 189, 35, 85, 165, 130, 195, 94, 60, 199, 38, 230, 116, 131, 151, 134, 230, 205, 16, 67, 171, 152, 207, 65, 74, 230, 42, 253, 124, 153, 150))).friend_status_data and not U1.GameStatus.IsInFightingNotSocialNotMainCityNotHome() and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 189, 35, 85, 165, 130, 195, 94, 60, 199, 38, 230, 116, 131, 151, 134, 230, 205, 16, 67, 171, 152, 207, 65, 74, 230, 42, 253, 124, 153, 150))).friend_status_data.is_agree_invite and (({
        type = 0,
        playerId = _ARG_0_,
        inviterTeamID = _ARG_1_,
        playerName = GetMemberName(_ARG_0_),
        gameType = GetOldGameType(_ARG_2_),
        showCD = U3,
        closeCD = U4,
        closeTotalTime = U4,
        modeID = _ARG_2_,
        subViewId = _ARG_4_ and _ARG_4_[1],
        ["playerName"] = _ARG_3_.playerName,
        ["src"] = _ARG_3_.src,
        ["from"] = _ARG_3_.from,
        ["missionInfo"] = _ARG_3_.missionInfo,
        ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
        ["ugcModID"] = _ARG_3_.ugcModID,
        ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
        ["isTMode"] = _ARG_3_.isTMode,
        ["tournament_id"] = _ARG_3_.tournament_id,
        ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
        ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
        ["netDelay"] = 360,
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
        ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
        ["squad_id"] = _ARG_3_.squad_id,
        ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
        ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
      }).from == U5.FriendBar or ({
        type = 0,
        playerId = _ARG_0_,
        inviterTeamID = _ARG_1_,
        playerName = GetMemberName(_ARG_0_),
        gameType = GetOldGameType(_ARG_2_),
        showCD = U3,
        closeCD = U4,
        closeTotalTime = U4,
        modeID = _ARG_2_,
        subViewId = _ARG_4_ and _ARG_4_[1],
        ["playerName"] = _ARG_3_.playerName,
        ["src"] = _ARG_3_.src,
        ["from"] = _ARG_3_.from,
        ["missionInfo"] = _ARG_3_.missionInfo,
        ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
        ["ugcModID"] = _ARG_3_.ugcModID,
        ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
        ["isTMode"] = _ARG_3_.isTMode,
        ["tournament_id"] = _ARG_3_.tournament_id,
        ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
        ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
        ["netDelay"] = 360,
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
        ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
        ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
        ["squad_id"] = _ARG_3_.squad_id,
        ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
        ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
      }).from == U5.MainCityInfoCard) then
        return
      end
      if CheckSameInvite(_ARG_0_, 0) == 0 then
      else
        inviteApplyQueue[CheckSameInvite(_ARG_0_, 0)] = {
          type = 0,
          playerId = _ARG_0_,
          inviterTeamID = _ARG_1_,
          playerName = GetMemberName(_ARG_0_),
          gameType = GetOldGameType(_ARG_2_),
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4,
          modeID = _ARG_2_,
          subViewId = _ARG_4_ and _ARG_4_[1],
          ["playerName"] = _ARG_3_.playerName,
          ["src"] = _ARG_3_.src,
          ["from"] = _ARG_3_.from,
          ["missionInfo"] = _ARG_3_.missionInfo,
          ["recommend_info_type_team_labels"] = _ARG_3_.recommend_info_type_team_labels,
          ["ugcModID"] = _ARG_3_.ugcModID,
          ["mainCityID"] = _ARG_3_.main_city_info and _ARG_3_.main_city_info.room_id,
          ["isTMode"] = _ARG_3_.isTMode,
          ["tournament_id"] = _ARG_3_.tournament_id,
          ["zoneName"] = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_.zone_id),
          ["netDelay"] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 120, 232, 42, 252, 79, 152, 129, 149, 251, 138))).GetZoneDelay(_ARG_3_.zone_id, 360, 10000),
          ["netDelay"] = 360,
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(35194),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(12585),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(92221),
          ["mapName"] = U1.LocUtil.GetLocalizeResStr(62485),
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamSummaryById(_ARG_3_.squad_id).name or U1.LocUtil.GetLocalizeResStr(88801431)),
          ["squad_id"] = _ARG_3_.squad_id,
          ["mapName"] = U1.LocUtil.LocalizeResFormat(18010390, U1.LocUtil.GetLocalizeResStr(88801427)),
          ["mapName"] = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSelectMapName(_ARG_4_)
        }, CheckSameInvite(_ARG_0_, 0), U1.require((U2(199, 213, 25, 185, 106, 173, 212, 189, 35, 85, 165, 130, 195, 94, 60, 199, 38, 230, 116, 131, 151, 134, 230, 205, 16, 67, 171, 152, 207, 65, 74, 230, 42, 253, 124, 153, 150))), inviteApplyQueue
      end
      if U1.GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[106]
    end
  end,
  ["directlyAgree"] = function(_ARG_0_)
    do
      team_invite_reply(U1.NetErrorCode_NONE, _ARG_0_.playerId, _ARG_0_.inviterTeamID, _ARG_0_.src, _ARG_0_.from)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_info_sync"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 63, 95, 164, 146, 254, 86, 123, 233, 39, 185, 121, 143, 169, 156, 247, 145),
        U1(193, 203, 33, 169, 109, 173, 218, 238, 102)
      }) .. tostring(_ARG_3_))
      if not _ARG_1_.player_count then
        _ARG_1_.player_count = 1
      end
      if 2 <= _ARG_1_.player_count then
      end
      if GameStatus.IsInLobbyOrMainCity() and 1 >= (U2.teamInfo and U2.teamInfo.player_count or 0) and _ARG_1_.player_count > 1 then
      end
      if U2.bHasEnterFighting then
        if not require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 91, 119, 224, 54, 224, 101, 179, 153, 136, 228, 130, 49, 84, 176, 211, 207, 64, 117, 229, 45, 252, 79, 155, 145, 144, 254, 150),
          U1(251, 212, 17, 178, 101, 190, 159, 161)
        }))).NeedUpdateRole() and not require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 117, 130, 159, 135, 229, 148, 9, 65, 163, 142, 210, 11, 76, 226, 51, 203, 64, 172, 150, 156, 236, 154),
          U1(193, 206, 94, 176, 107, 190, 147, 176, 25, 84, 188, 134, 223, 90, 101, 231, 53, 250, 115, 179, 128, 156, 228, 141, 51, 93)
        }))).isShowRP and not GameStatus.IsInLobbyOrMainCity() then
          U2.bHasEnterFighting = false
        else
        end
      end
      if GameStatus.IsInFightingStatus() then
        if not require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 111, 232, 32, 252, 79, 145, 131, 139))).IsSocialIslandMode(true) and not GameStatus.IsInLobbyOrMainCity() and not require((table.concat({
          U1(227, 216, 29, 185, 72, 172, 155, 253, 11, 78, 182, 195, 226, 92, 124, 240, 56, 236, 84, 158, 149, 128, 228, 138, 56, 86, 236, 186, 192, 72, 103, 215, 40, 248, 105, 210, 160, 152, 238, 146),
          U1(138, 234, 25, 178, 99, 181, 159, 135, 52, 64, 187, 131, 229, 90, 125, 251)
        }))).IsSelfInTraining() then
          return
        end
      end
      if _ARG_0_ == 0 then
        _ARG_1_.player_count = 1
        _ARG_1_.id = 0
      else
        _ARG_1_.id = _ARG_0_
      end
      if _ARG_1_.player_count == 1 then
        _ARG_1_.leader = U2.GetSelfUID(), "leader"
      end
      if not GameStatus.IsInFightingStatus() or GameStatus.IsInLobbyOrMainCity() then
        goto lbl_1393
        if tonumber(U1(195, 220)) ~= U2.GetSelfUID() then
        end
        ::lbl_1393::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if _ARG_1_.player_count == 1 then
          if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 253, 43, 247, 117))).nChooseZoneID ~= 0 and _ARG_1_.self_zone_id and 0 < _ARG_1_.self_zone_id and _ARG_1_.self_zone_id ~= require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 253, 43, 247, 117))).nChooseZoneID then
          end
          if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 253, 43, 247, 117))).nChooseZoneID == 0 and _ARG_1_.self_zone_id and 0 < _ARG_1_.self_zone_id and _ARG_1_.self_zone_id ~= require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 253, 43, 247, 117))).nChooseZoneID then
          end
        end
        if not GameStatus.IsInMainCity() and _ARG_1_.main_city_info ~= nil then
        end
      end
      if _ARG_1_.player_count > 1 and U2.teamInfo.player_count == 1 then
      end
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 108, 131, 150, 139, 243, 205, 27, 80, 171, 147, 226, 76, 118, 254, 106, 213, 127, 158, 134, 128, 197, 190),
        U1(197, 208, 30, 131, 71, 176, 142, 170, 25, 100, 188, 153, 212, 71)
      }))).bInMainCity and _ARG_1_.player_count > 1 and U2.teamInfo.player_count ~= nil and _ARG_1_.player_count > U2.teamInfo.player_count then
      end
      if _ARG_1_.player_count ~= U2.teamInfo.player_count then
      end
      if U2.teamInfo.player_count and U2.teamInfo.player_count < _ARG_1_.player_count then
        if require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 99, 131, 153, 140, 213, 129, 55, 82, 169, 211, 205, 74, 101, 238, 39, 198, 113, 143, 151, 156, 247, 145),
          U1(200, 192, 47, 189, 103, 173, 147, 165, 47, 85, 171)
        }))).HasReqAssemblyInfo then
        else
          require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 99, 131, 153, 140, 213, 129, 55, 82, 169, 211, 205, 74, 101, 238, 39, 198, 113, 143, 151, 156, 247, 145),
            U1(200, 192, 47, 189, 103, 173, 147, 165, 47, 85, 171)
          }))).isNeedShowTips = true
          require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 99, 131, 153, 140, 213, 129, 55, 82, 169, 211, 205, 74, 101, 238, 39, 198, 113, 143, 151, 156, 247, 145),
            U1(200, 192, 47, 189, 103, 173, 147, 165, 47, 85, 171)
          }))).tipsTeamInfo = {
            oldCount = U2.teamInfo.members,
            newCount = _ARG_1_.members
          }
        end
      end
      if (tonumber(U2.teamInfo and U2.teamInfo.id) or 0) ~= (tonumber(_ARG_1_.id) or 0) then
        U2.ugcModInfoSyncCache = {}
      end
      U2.teamInfo = _ARG_1_
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule):IsWeaponEntranceDownloadFeatureEnabled() then
        goto lbl_2908
        if 0 < (tonumber(U1(251, 205, 28, 179, 99)) or 0) and (tonumber(U1(251, 205, 28, 179, 99)) or 0) ~= U2.GetSelfUID() and not (((tonumber(U2.teamInfo and U2.teamInfo.id) or 0) == (tonumber(_ARG_1_.id) or 0) and U2.teamInfo and U2.teamInfo.members or {}) and ((tonumber(U2.teamInfo and U2.teamInfo.id) or 0) == (tonumber(_ARG_1_.id) or 0) and U2.teamInfo and U2.teamInfo.members or {}[tonumber(U1(251, 205, 28, 179, 99)) or 0] ~= nil or (tonumber(U2.teamInfo and U2.teamInfo.id) or 0) == (tonumber(_ARG_1_.id) or 0) and U2.teamInfo and U2.teamInfo.members or {}[tostring(tonumber(U1(251, 205, 28, 179, 99)) or 0)] ~= nil)) then
          if next((U3(U1(251, 205, 28, 179, 99)))) then
            if require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 100, 131, 131, 135, 230, 140, 55, 85, 236, 141, 212, 67, 100, 226, 54, 183, 96, 137, 130, 159, 255, 129),
              U1(251, 212, 17, 178, 101, 190, 159, 161)
            }))).GetListIsDownloaded(require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 100, 131, 131, 135, 230, 140, 55, 85, 236, 141, 212, 67, 100, 226, 54, 198, 115, 147, 138, 138, 238))).ENUM_DownloadType.ODPAK, (U3(U1(251, 205, 28, 179, 99)))) then
            else
            end
          else
          end
        end
        ::lbl_2908::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U2.teamInfo.player_count and 1 < U2.teamInfo.player_count then
      else
      end
      if U2.teamInfo.player_count and 1 >= U2.teamInfo.player_count then
      end
      goto lbl_3217
      if U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias and U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.id and U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.id ~= 0 then
        U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliasid = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.id
        U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliastitle = FuncUtil.Gen_title(U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.id, U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.rank or 0, U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.ext_info or {}, U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.rank_id)
        U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliasnation = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.nation or U1()
        U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliasRankId = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).alias.rank_id
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(203, 204, 30, 168, 36, 228, 218, 243, 102)) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(203, 204, 30, 168, 36, 228, 218, 243, 102)).alias then
          ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(203, 204, 30, 168, 36, 228, 218, 243, 102)).alias.id = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliasid
          ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(203, 204, 30, 168, 36, 228, 218, 243, 102)).alias.title = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliastitle
          ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(203, 204, 30, 168, 36, 228, 218, 243, 102)).alias.nation = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliasnation
          ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(203, 204, 30, 168, 36, 228, 218, 243, 102)).alias.rank_id = U1(203, 204, 30, 168, 36, 228, 218, 243, 102).aliasRankId
        end
      end
      ::lbl_3217::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_3256
      ::lbl_3256::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not _ARG_2_ then
      else
      end
      if not GameStatus.IsInFightingStatus() or GameStatus.IsInLobbyOrMainCity() then
        if _ARG_0_ == 0 then
        else
        end
        goto lbl_3344
        if tonumber(("Compatible").gid) ~= U2.GetSelfUID() then
        end
        ::lbl_3344::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if true then
        end
        if not _ARG_1_.tournament_id or _ARG_1_.tournament_id == 0 then
        else
        end
        goto lbl_3808
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_share_bag_team_util):GetUsingSharePetInfoByUID(U1(233, 216, 30, 189, 99, 188, 136)) then
        else
          if tostring(U1(233, 216, 30, 189, 99, 188, 136)) == tostring(DataMgr.roleData.uid) then
          else
          end
          if U1(233, 216, 30, 189, 99, 188, 136).pet_info ~= nil and U1(233, 216, 30, 189, 99, 188, 136).pet_info.id ~= 0 then
            if U1(233, 216, 30, 189, 99, 188, 136).name ~= nil then
            end
          end
        end
        ::lbl_3808::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if true and _ARG_1_.player_count > 1 then
          if not U2.IsTeamLeader() then
            if _ARG_1_.members and _ARG_1_.members[U2.GetSelfUID()] then
            end
          else
          end
          goto lbl_4302
          if U1(251, 212, 17, 178, 101, 190, 159, 161).voice_download_ids then
            goto lbl_4300
            ::lbl_4300::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          ::lbl_4302::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        goto lbl_4527
        ::lbl_4527::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_1_.team_omb_info and _ARG_1_.team_omb_info.member_status and (not U2.oneMoreGameTeamInfo or not U2.oneMoreGameTeamInfo.member_status) then
        if UIManager.GetUI(UIManager.UI_Config.one_more_team_tip) then
        else
        end
      end
      if not _ARG_3_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateOnePet"] = function(_ARG_0_)
    do
      if not U2.teamInfo.members[tonumber(_ARG_0_)] then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_share_bag_team_util):GetUsingSharePetInfoByUID((tonumber(_ARG_0_))) then
      else
        if tostring((tonumber(_ARG_0_))) == tostring(DataMgr.roleData.uid) then
        else
        end
        if U2.teamInfo.members[tonumber(_ARG_0_)].pet_info ~= nil and U2.teamInfo.members[tonumber(_ARG_0_)].pet_info.id ~= 0 then
          if U2.teamInfo.members[tonumber(_ARG_0_)].name ~= nil then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_quit_respond"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_ == NetErrorCode_NONE then
        if _ARG_1_ and 0 < _ARG_1_ and _ARG_1_ ~= require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 253, 43, 247, 117))).nChooseZoneID then
          if _ARG_2_ ~= 11 then
          end
        end
        if 0 < require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 116, 137, 149, 132, 255, 147, 120, 93, 173, 154, 200, 70, 93, 253, 43, 247, 117))).nChooseZoneID and not slua_GameFrontendHUD.UDPPingCollector:IsChooingZoneAccess() then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_quit_for_reason"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_QUIT_TEAM_SUC_AND_APPLY, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_apply_respond"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 168, 97, 184, 151, 140, 39, 81, 162, 129, 200, 106, 96, 242, 39, 249, 111, 130, 144, 201, 249, 151, 55, 69, 167, 221, 156, 5)
      }) .. _ARG_0_ .. U1(132, 153, 5, 175, 97, 171, 180, 186, 37, 74, 242, 208, 145) .. tostring(_ARG_2_))
      log(bWriteLog and table.concat({
        U1(255, 218, 24, 169, 102, 132, 174, 182, 39, 76, 135, 157, 255, 80, 101, 196, 45, 250, 116, 137, 153, 199, 229, 141, 9, 69, 167, 156, 204, 122, 107, 233, 50, 240, 100, 153, 187, 139, 255, 128),
        U1(212, 214, 30, 184, 36, 172, 137, 182, 52, 111, 187, 142, 218, 21, 47, 183)
      }) .. tostring(_ARG_2_))
      log(bWriteLog and table.concat({
        U1(255, 218, 24, 169, 102, 132, 174, 182, 39, 76, 135, 157, 255, 80, 101, 196, 45, 250, 116, 137, 153, 199, 229, 141, 9, 69, 167, 156, 204, 122, 107, 233, 50, 240, 100, 153, 187, 139, 255, 128),
        U1(212, 214, 30, 184, 36, 173, 159, 171, 50, 126, 187, 137, 145, 8, 50)
      }) .. tostring(_ARG_3_))
      if _ARG_0_ == NetErrorCode_NONE then
      elseif _ARG_0_ == U1(214, 220, 22, 169, 119, 188) then
        if _ARG_3_ then
        else
          U2.ErrorNotice(110013, 38827, _ARG_2_)
        end
      elseif _ARG_0_ == U1(208, 208, 29, 185, 107, 172, 142) then
        U2.ErrorNotice(110013, 38829, _ARG_2_)
      elseif _ARG_0_ == U1(197, 204, 4, 179, 86, 188, 156, 166, 53, 68, 157, 131, 229, 80, 115, 250, 23, 225, 97, 130, 147, 140) then
        ShowNotice(110057)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 36, 176, 148, 243, 43, 64, 166, 142, 217) then
        ShowNotice(110060)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(110061)
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 63, 95, 180, 148, 213, 64, 93, 245, 33, 234, 96, 147, 138, 157, 186, 190),
          U1(197, 205, 19, 180, 87, 160, 137, 167, 35, 76, 252, 188, 196, 80, 96, 238, 4, 229, 97, 149, 145, 155, 217, 151, 55, 69, 167, 221, 147)
        }))
        U3.QueryPlayerState()
      elseif _ARG_0_ == U1(215, 220, 30, 184, 91, 184, 138, 163, 42, 88, 141, 158, 196, 86, 113, 242, 39, 250) then
        ShowNotice(110012)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 119, 184, 151, 182, 25, 87, 183, 159, 194, 92, 125, 249) then
        U2.HandleVersionErrorCode(_ARG_1_)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 176, 137, 140, 32, 84, 190, 129) then
        ShowNotice(110007)
      elseif _ARG_0_ == U1(200, 220, 17, 184, 97, 171, 165, 176, 46, 64, 188, 138, 212, 81) then
        ShowNotice(6432)
      elseif _ARG_0_ == U1(200, 214, 7, 131, 116, 171, 147, 188, 52, 72, 166, 148, 238, 88, 115, 227, 55, 225, 95, 142, 149, 135, 228, 134, 50) then
        U3.ShowBanTip(U3.GetTeamUpBanTip())
      elseif _ARG_0_ == U1(201, 216, 4, 191, 108, 134, 147, 160, 41, 77, 179, 153, 216, 90, 124, 200, 56, 232, 98, 137, 152, 182, 232, 130, 56, 95, 167, 153) then
        U3.ShowBanTip(LocUtil.GetLocalizeResStr(29113))
      elseif _ARG_0_ == U1(195, 204, 21, 175, 112, 134, 137, 167, 39, 85, 183, 178, 211, 84, 124, 249, 49, 237) then
        ShowNotice(22021)
      elseif _ARG_0_ == U1(201, 220, 4, 174, 107, 134, 151, 188, 34, 68, 141, 131, 222, 65, 77, 248, 36, 236, 110) then
        ShowNotice(740016)
      elseif _ARG_0_ == U1(212, 203, 21, 131, 112, 188, 155, 190, 25, 77, 187, 128, 216, 65) then
        ShowNotice(27192)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 98, 171, 147, 182, 40, 69) then
        ShowNotice(29388)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 179, 149, 186, 40, 12, 234, 155, 137, 24, 102, 242, 53, 228) then
        ShowNotice(11893)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 179, 149, 186, 40, 12, 161, 130, 210, 92, 115, 251, 56, 232, 110, 136, 217, 157, 239, 130, 59) then
        ShowNotice(11893)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 179, 149, 186, 40, 12, 167, 138, 210, 24, 102, 242, 53, 228) then
        ShowNotice(48410)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 179, 149, 186, 40, 12, 167, 138, 210, 24, 102, 242, 53, 228, 45, 128, 145, 159, 239, 143, 123, 93, 171, 144, 200, 81) then
        ShowNotice(511200)
      elseif _ARG_0_ == U1(199, 216, 30, 168, 41, 179, 149, 186, 40, 12, 167, 138, 210, 24, 102, 242, 53, 228, 45, 136, 145, 159, 167, 143, 63, 92, 171, 137) then
        ShowNotice(511203)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 171, 159, 185, 35, 66, 166, 178, 194, 65, 96, 246, 58, 238, 101, 158, 135) then
        ShowNotice(773309)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 101, 169, 138, 191, 63, 126, 162, 159, 222, 88, 125, 227, 61, 230, 110, 179, 134, 136, 254, 138, 56, 86) then
        ShowNotice(100610015)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 101, 169, 138, 191, 63, 126, 162, 159, 222, 88, 125, 227, 61, 230, 110, 179, 153, 156, 230, 151, 63, 110, 175, 146, 197, 64) then
        ShowNotice(100610014)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 101, 169, 138, 191, 63, 126, 162, 159, 222, 88, 125, 227, 61, 230, 110, 179, 153, 134, 238, 134) then
        ShowNotice(100610013)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 101, 169, 138, 191, 63, 126, 162, 129, 208, 76, 119, 229, 11, 249, 114, 131, 153, 134, 254, 138, 57, 95, 157, 143, 192, 81, 107, 233, 35) then
        ShowNotice(100610016)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 109, 183, 165, 167, 35, 64, 191) then
        ShowNotice(817224)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 138, 208, 88, 119) then
        ShowNotice(9911106)
      elseif not U2.HandleTeamJoinErrorCode(_ARG_0_) then
        U2.HandleErrorCode(_ARG_0_)
      end
      if _ARG_0_ ~= NetErrorCode_NONE then
        EventSystem:postEvent(EVENTTYPE_FLASH_TEAM, EVENTID_FLASH_TEAM_ONEKEY_STATE_FAIL)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = _ENV[188]
    end
  end,
  ["HandleTeamJoinErrorCode"] = function(_ARG_0_)
    do
      if _ARG_0_ == _ENV(192, 220, 6, 181, 103, 188, 165, 167, 63, 81, 183, 178, 221, 92, 127, 254, 32) then
        if U1.require((_ENV(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).IsX86Phone() then
        else
        end
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 129, 216, 88, 123, 227, 11, 228, 105, 130, 171, 133, 239, 149, 51, 93) then
        U1.ShowNotice(7127)
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 129, 216, 88, 123, 227, 11, 228, 105, 130, 171, 154, 239, 132, 9, 93, 167, 139, 196, 73) then
        U1.ShowNotice(7128)
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 129, 216, 88, 123, 227, 11, 228, 97, 148, 171, 154, 239, 132, 9, 93, 167, 139, 196, 73) then
        U1.ShowNotice(7129)
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 132, 213, 106, 124, 248, 32, 214, 101, 148, 157, 154, 254) then
        U1.ShowNotice(7130)
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 132, 213, 106, 96, 226, 56, 236, 95, 129, 155, 141, 239, 188, 51, 67, 176) then
        U1.ShowNotice(7131)
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 131, 222, 65, 77, 254, 58, 214, 116, 133, 153, 140) then
        U1.ShowNotice(7132)
      elseif _ARG_0_ == _ENV(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 152, 223, 67, 123, 228, 61, 235, 108, 137, 171, 155, 239, 132, 63, 94, 172) then
        U1.ShowNotice(7133)
      elseif _ARG_0_ == _ENV(202, 214, 4, 131, 103, 184, 136, 167, 35, 64, 191, 178, 197, 80, 115, 250, 57, 232, 116, 137) then
        U1.ShowNotice(12651)
      elseif _ARG_0_ == _ENV(215, 220, 23, 177, 97, 183, 142, 140, 42, 68, 164, 136, 221, 106, 124, 248, 32, 214, 101, 130, 155, 156, 237, 139) then
        U1.ShowNotice(7128)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 128, 208, 91, 125, 229) or _ARG_0_ == _ENV(208, 216, 2, 187, 97, 173, 165, 186, 40, 126, 191, 140, 223, 90, 96) then
        U1.ShowNotice(655422)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 136, 140, 47, 79, 141, 128, 208, 91, 125, 229) or _ARG_0_ == _ENV(203, 215, 21, 175, 97, 181, 156, 140, 47, 79, 141, 128, 208, 91, 125, 229) then
        U1.ShowNotice(655423)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 142, 222, 89, 126, 242, 55, 253, 95, 132, 149, 133, 230) or _ARG_0_ == _ENV(208, 216, 2, 187, 97, 173, 165, 186, 40, 126, 177, 130, 221, 89, 119, 244, 32, 214, 104, 141, 152, 133) then
        U1.ShowNotice(100051049)
      elseif _ARG_0_ == _ENV(205, 215, 6, 181, 112, 188, 136, 140, 47, 79, 141, 142, 222, 89, 126, 242, 55, 253, 95, 132, 149, 133, 230) or _ARG_0_ == _ENV(203, 215, 21, 175, 97, 181, 156, 140, 47, 79, 141, 142, 222, 89, 126, 242, 55, 253, 95, 132, 149, 133, 230) then
        U1.ShowNotice(100051050)
      elseif _ARG_0_ == _ENV(212, 220, 17, 183, 99, 184, 151, 182, 25, 82, 183, 138, 220, 80, 124, 227, 11, 229, 105, 129, 157, 157) then
        U1.ShowNotice(46129)
      elseif _ARG_0_ == _ENV(206, 214, 25, 178, 91, 173, 159, 178, 43, 126, 162, 155, 212, 106, 124, 242, 35, 235, 105, 137, 171, 135, 229, 151, 9, 87, 171, 147, 200, 86, 106) then
        U1.require((U1.table.concat({
          _ENV(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
          _ENV(203, 215, 47, 178, 97, 174, 152, 186, 35, 126, 180, 129, 222, 66)
        }))).ShowNotFinishMemberTips(nil)
      else
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_join_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 168, 97, 184, 151, 140, 44, 78, 187, 131, 238, 71, 97, 231, 120, 169, 114, 137, 135, 201, 183, 195)
      }) .. tostring(_ARG_0_) .. U1(136, 153, 4, 185, 101, 180, 147, 183, 102, 28, 242) .. tostring(_ARG_1_) .. U1(136, 153, 4, 185, 101, 180, 179, 189, 32, 78, 242, 208, 145) .. tostring(_ARG_2_))
      if _ARG_0_ == NetErrorCode_NONE then
        ShowNotice(110042)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 176, 137, 140, 32, 84, 190, 129) then
        ShowNotice(110007)
      elseif _ARG_0_ == U1(208, 216, 2, 187, 97, 173, 165, 189, 41, 85, 141, 130, 223, 89, 123, 249, 49) then
        ShowNotice(110009)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 153, 212, 84, 127) then
        ShowNotice(39090)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 46, 64, 161, 178, 197, 80, 115, 250) then
        ShowNotice(39090)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 41, 176, 148, 254, 43, 64, 166, 142, 217) then
        ShowNotice(110059)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 183, 149, 167, 25, 68, 170, 132, 194, 65) then
        ShowNotice(520037)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 119, 184, 151, 182, 25, 87, 183, 159, 194, 92, 125, 249) then
        U2.HandleVersionErrorCode(_ARG_3_)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 136, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(110059)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 159, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(39091)
      elseif _ARG_0_ == U1(205, 215, 6, 181, 112, 188, 136, 140, 47, 79, 141, 138, 208, 88, 119) then
        ShowNotice(9911106)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 183, 149, 167, 25, 71, 189, 152, 223, 81) then
        ShowNotice(4361)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(39091)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 138, 208, 88, 119) then
        ShowNotice(39091)
      elseif _ARG_0_ == U1(215, 220, 23, 177, 97, 183, 142, 140, 42, 72, 191, 132, 197) then
        ShowNotice(7788)
      elseif _ARG_0_ == U1(200, 214, 7, 131, 116, 171, 147, 188, 52, 72, 166, 148, 238, 88, 115, 227, 55, 225, 95, 142, 149, 135, 228, 134, 50) then
        U3.ShowBanTip(U3.GetTeamUpBanTip())
      elseif _ARG_0_ == U1(201, 216, 4, 191, 108, 134, 147, 160, 41, 77, 179, 153, 216, 90, 124, 200, 56, 232, 98, 137, 152, 182, 232, 130, 56, 95, 167, 153) then
        U3.ShowBanTip(LocUtil.GetLocalizeResStr(29113))
      elseif _ARG_0_ == U1(210, 214, 25, 191, 97, 134, 142, 182, 39, 76, 141, 131, 222, 106, 123, 249, 34, 224, 116, 137) then
        ShowNotice(10573)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 97, 161, 147, 160, 50, 126, 177, 130, 223, 70, 113, 229, 61, 235, 101) then
        ShowNotice(100220010)
      elseif _ARG_0_ == U1(195, 204, 21, 175, 112, 134, 137, 167, 39, 85, 183, 178, 211, 84, 124, 249, 49, 237) then
        ShowNotice(22006)
      elseif _ARG_0_ == U1(199, 214, 29, 172, 97, 173, 159, 140, 39, 77, 160, 136, 208, 81, 107, 200, 61, 231, 95, 142, 149, 157, 254, 143, 51) then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 63, 95, 180, 148, 213, 64, 93, 245, 33, 234, 96, 147, 138, 157, 186, 190),
          U1(197, 205, 19, 180, 87, 160, 137, 167, 35, 76, 252, 188, 196, 80, 96, 238, 4, 229, 97, 149, 145, 155, 217, 151, 55, 69, 167, 221, 146)
        }))
        U3.QueryPlayerState()
      elseif _ARG_0_ == U1(206, 214, 25, 178, 91, 173, 159, 178, 43, 126, 187, 131, 238, 86, 125, 248, 56, 214, 100, 131, 131, 135, 213, 151, 63, 92, 167) then
        ShowNotice(29776)
      elseif _ARG_0_ == U1(212, 203, 21, 131, 112, 188, 155, 190, 25, 77, 187, 128, 216, 65) then
        ShowNotice(27192)
      elseif _ARG_0_ == U1(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 132, 213, 106, 124, 248, 32, 214, 105, 130, 130, 136, 230, 138, 50) then
        ShowNotice(501076)
      elseif _ARG_0_ == U1(208, 214, 5, 174, 106, 184, 151, 182, 40, 85, 141, 140, 196, 65, 122, 200, 55, 225, 101, 143, 159, 182, 236, 130, 63, 93, 167, 153) then
        ShowNotice(505047)
      elseif _ARG_0_ == U1(215, 216, 29, 185, 91, 180, 155, 186, 40, 126, 177, 132, 197, 76, 77, 251, 61, 228, 105, 152) then
        ShowNotice(77922)
      elseif _ARG_0_ == U1(206, 214, 25, 178, 91, 173, 159, 178, 43, 126, 162, 159, 222, 88, 125, 227, 61, 230, 110, 179, 157, 135, 252, 130, 58, 88, 166) then
        if not _ARG_3_ or not _ARG_3_.error_code then
          ShowNotice(85160)
        elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_3_.member_uid or 0) then
        end
      elseif _ARG_0_ == U1(197, 201, 0, 176, 125, 188, 136, 140, 47, 79, 141, 128, 212, 65, 96, 248, 11, 250, 99, 137, 154, 138, 239) then
        ShowNotice(6656432)
      elseif type(_ARG_0_) == U1(202, 204, 29, 190, 97, 171) then
        if _ARG_0_ == 505046 then
        else
          ShowNotice(_ARG_0_)
        end
      elseif not U2.HandleTeamJoinErrorCode(_ARG_0_) then
        U2.HandleErrorCode(_ARG_0_)
      end
      if _ARG_0_ ~= NetErrorCode_NONE then
        if U2.oneMoreGameTeamInfo then
          U2.one_more_battle_reply_rsp()
        end
        EventSystem:postEvent(EVENTTYPE_FLASH_TEAM, EVENTID_FLASH_TEAM_ONEKEY_STATE_FAIL)
        EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_JOINT_TEAM_FAIL, _ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1.member_uid
    end
  end,
  ["on_join_anchor_team_res"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(255, 237, 21, 189, 105, 140, 138, 157, 35, 86, 129, 148, 194, 65, 119, 250, 9, 169, 111, 130, 171, 131, 229, 138, 56, 110, 163, 147, 194, 77, 109, 245, 27, 237, 117, 157, 137, 166, 232, 150),
        U1(215, 153, 21, 174, 118, 249, 199, 243)
      }) .. tostring(_ARG_0_) .. U1(136, 153, 6, 185, 118, 134, 136, 182, 50, 1, 239, 205) .. tostring(_ARG_1_))
      if _ARG_0_ == U1(195, 204, 21, 175, 112, 134, 137, 167, 39, 85, 183, 178, 211, 84, 124, 249, 49, 237) then
        ShowNotice(22006)
      elseif _ARG_0_ == U1(203, 206, 21, 184, 91, 170, 142, 178, 50, 68, 141, 143, 208, 91, 124, 242, 48) then
        ShowNotice(24226)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 46, 64, 161, 178, 197, 80, 115, 250) then
        ShowNotice(110044)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
        ShowNotice(4360)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 138, 208, 88, 119) then
        ShowNotice(4400)
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 159, 222, 90, 127) then
        ShowNotice(110117)
      elseif _ARG_0_ == U1(200, 214, 7, 131, 116, 171, 147, 188, 52, 72, 166, 148, 238, 88, 115, 227, 55, 225, 95, 142, 149, 135, 228, 134, 50) then
        U2.ShowBanTip(U2.GetTeamUpBanTip())
      elseif _ARG_0_ == U1(201, 216, 4, 191, 108, 134, 147, 160, 41, 77, 179, 153, 216, 90, 124, 200, 56, 232, 98, 137, 152, 182, 232, 130, 56, 95, 167, 153) then
        U2.ShowBanTip(LocUtil.GetLocalizeResStr(29113))
      elseif _ARG_0_ == U1(197, 215, 19, 180, 107, 171, 165, 190, 39, 85, 177, 133, 238, 92, 97, 248, 56, 232, 116, 133, 155, 135, 213, 143, 55, 83, 167, 145, 254, 71, 99, 233, 42, 252, 116) then
        U2.ShowBanTip(LocUtil.GetLocalizeResStr(29112))
      elseif _ARG_0_ == U1(197, 215, 19, 180, 107, 171, 165, 167, 35, 64, 191, 178, 221, 92, 127, 254, 32) then
        ShowNotice(25237)
      elseif _ARG_0_ == U1(202, 214, 4, 131, 119, 184, 151, 182, 25, 87, 183, 159, 194, 92, 125, 249) then
        U3.HandleVersionErrorCode(_ARG_1_)
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 176, 137, 140, 32, 84, 190, 129) then
        ShowNotice(110007)
      elseif _ARG_0_ == U1(197, 201, 0, 176, 125, 188, 136, 243, 47, 79, 242, 158, 222, 86, 123, 246, 56, 229, 97, 130, 144) then
        ShowNotice(25236)
      elseif _ARG_0_ == U1(212, 203, 21, 131, 112, 188, 155, 190, 25, 77, 187, 128, 216, 65) then
        ShowNotice(27192)
      else
        U3.HandleErrorCode(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_kick_respond"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 168, 97, 184, 151, 140, 45, 72, 177, 134, 238, 71, 119, 228, 36, 230, 110, 136, 212, 155, 239, 144, 118, 12, 226)
      }) .. _ARG_0_ .. U1(136, 153, 4, 189, 118, 190, 159, 167, 19, 104, 150, 205, 140, 21) .. _ARG_1_)
      if _ARG_0_ == NetErrorCode_NONE then
        U2.team_info_request()
      else
        ShowNotice(301165)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_apply_notify"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 168, 97, 184, 151, 140, 39, 81, 162, 129, 200, 106, 124, 248, 32, 224, 102, 149, 212, 136, 250, 147, 58, 88, 167, 143, 232, 97, 34, 186, 100)
      }) .. _ARG_0_ .. U1(136, 153, 17, 172, 116, 181, 147, 182, 52, 111, 179, 128, 212, 21, 47, 183) .. _ARG_1_)
      if U2.CheckApplyAutoRefuse(_ARG_0_) then
        if _ARG_3_ then
        end
        return
      end
      if _ARG_3_ then
      end
      if U2.CheckSameInvite(_ARG_0_, 1) == 0 then
      else
        U2.inviteApplyQueue[U2.CheckSameInvite(_ARG_0_, 1)] = {
          type = 1,
          playerId = _ARG_0_,
          playerName = _ARG_1_,
          applierTeamID = _ARG_2_,
          showCD = U3,
          closeCD = U4,
          closeTotalTime = U4
        }, U2.inviteApplyQueue
      end
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[103]
    end
  end,
  ["IsUGCModInfoSyncChanged"] = function(_ARG_0_)
    do
      if not (_ARG_0_ and _ARG_0_.uid) or type(_ARG_0_ and _ARG_0_.mod_info) ~= U1(208, 216, 18, 176, 97) or not next(_ARG_0_ and _ARG_0_.mod_info) then
        return true
      end
      if not U2.ugcModInfoSyncCache[_ARG_0_ and _ARG_0_.uid] then
        U2.ugcModInfoSyncCache[_ARG_0_ and _ARG_0_.uid] = {
          [176] = 97
        }, U2.ugcModInfoSyncCache
      end
      goto lbl_46
      if ({
        [176] = 97
      })[176] ~= 97 then
      end
      ::lbl_46::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_info_change_notify"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 168, 97, 184, 151, 140, 47, 79, 180, 130, 238, 86, 122, 246, 58, 238, 101, 179, 154, 134, 254, 138, 48, 72, 226, 137, 196, 68, 111, 238, 32, 185, 45, 220)
      }) .. tostring(_ARG_0_) .. U1(136, 153, 31, 172, 97, 171, 155, 167, 35, 126, 166, 148, 193, 80, 50, 170, 116) .. tostring(_ARG_1_) .. U1(136, 153, 0, 189, 118, 184, 151, 243, 123, 1) .. tostring(_ARG_2_) .. U1(136, 153, 0, 189, 118, 184, 151, 226, 102, 28, 242) .. tostring(_ARG_3_) .. U1(136, 153, 0, 189, 118, 184, 151, 225, 102, 28, 242) .. tostring(_ARG_4_))
      if _ARG_1_ == 1 then
        if U2.GetTeamNum() == 1 then
        end
      elseif _ARG_1_ == 2 then
        if _ARG_2_ then
          if U2.GetSelfUID() == tonumber(_ARG_2_) then
            if _ARG_4_ and _ARG_4_ == 6 then
            elseif _ARG_4_ and _ARG_4_ == 11 then
            else
            end
          else
          end
        else
        end
      elseif _ARG_1_ == 3 then
        if _ARG_2_ then
          if U2.GetSelfUID() == tonumber(_ARG_2_) and 1 < (_ARG_3_ or U2.GetTeamNum()) then
            if GameStatus.IsInLobbyOrMainCity() then
            end
          elseif U2.GetSelfUID() ~= tonumber(_ARG_2_) then
            if #U2.inviteApplyQueue == 0 then
            end
          end
        end
        if U2.teamInfo then
          U2.teamInfo.leader = _ARG_2_
        end
      elseif _ARG_1_ == 4 then
      elseif _ARG_1_ == 5 then
        if U2.teamInfo then
          U2.teamInfo.game_type = 1
          U2.teamInfo.team_type = tonumber(_ARG_2_)
          U2.teamInfo.sub_mode_view_ids = _ARG_3_
        end
        if U2.teamInfo and U2.teamInfo.team_type and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):IsUGCSingleMatchMode(U2.teamInfo.team_type) then
          if U2.teamInfo.id then
            if U2.afterteamID then
              goto lbl_933
              ::lbl_933::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
              if U2.afterteamID ~= U2.teamInfo.id and U2.teamInfo.id ~= 0 and 1 < 0 + 1 then
                U2.afterteamID = U2.teamInfo.id
              end
            else
              U2.afterteamID = U2.teamInfo.id
            end
          end
        else
        end
        if 1 < U2.GetTeamNum() then
        end
      elseif _ARG_1_ == 6 then
        if U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).status = _ARG_2_.status
        else
        end
      elseif _ARG_1_ == 7 then
        if _ARG_2_.status and U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).status = _ARG_2_.status
        end
      elseif _ARG_1_ == 8 then
        if U2.teamInfo then
          U2.teamInfo.fill = _ARG_2_
        end
        require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 109, 141, 128, 138, 226, 205, 58, 94, 165, 148, 194, 122, 111, 232, 32, 252, 79, 145, 131, 139))).bAutoMatch = _ARG_2_ == 1
        if U2.teamInfo.player_count and 1 < U2.teamInfo.player_count then
        end
      elseif _ARG_1_ == 9 then
      elseif _ARG_1_ == 10 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 11 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 12 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 13 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 14 then
        if _ARG_2_ then
          if U2.GetMemberInfo(_ARG_2_.uid) then
            U2.GetMemberInfo(_ARG_2_.uid).ban = U2.GetMemberInfo(_ARG_2_.uid).ban or {}
            if type(U2.GetMemberInfo(_ARG_2_.uid).ban[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 210, 90, 124, 241, 61, 238, 46, 175, 152, 128, 239, 141, 34, 124, 163, 158, 211, 74, 113, 169, 6, 248, 126, 177, 133, 154, 232, 156))).PLAYER_BAN_EXT_SIM_MATCH]) ~= U1(208, 216, 18, 176, 97) then
              U2.GetMemberInfo(_ARG_2_.uid).ban[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 210, 90, 124, 241, 61, 238, 46, 175, 152, 128, 239, 141, 34, 124, 163, 158, 211, 74, 113, 169, 6, 248, 126, 177, 133, 154, 232, 156))).PLAYER_BAN_EXT_SIM_MATCH] = {
                ["end_time"] = _ARG_2_.force_ext_sim_end_time
              }, U2.GetMemberInfo(_ARG_2_.uid).ban, require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 210, 90, 124, 241, 61, 238, 46, 175, 152, 128, 239, 141, 34, 124, 163, 158, 211, 74, 113, 169, 6, 248, 126, 177, 133, 154, 232, 156))).PLAYER_BAN_EXT_SIM_MATCH
            end
          else
          end
        end
      elseif _ARG_1_ == 15 then
        if U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).weapon_wear_info = _ARG_2_.weapon_wear_info
        end
      elseif _ARG_1_ == 16 then
      elseif _ARG_1_ == 17 then
      elseif _ARG_1_ == 18 then
      elseif _ARG_1_ == 19 then
        if U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).brand_id = _ARG_2_.brand_id
        end
      elseif _ARG_1_ == 20 then
      elseif _ARG_1_ == 21 then
        if _ARG_2_ and U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).level = _ARG_2_.level
        end
      elseif _ARG_1_ == 22 then
        if _ARG_2_ and U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).ace_imprint_show_id = _ARG_2_.ace_imprint_show_id
          U2.GetMemberInfo(_ARG_2_.uid).ace_imprint_base_id = _ARG_2_.ace_imprint_base_id
          U2.GetMemberInfo(_ARG_2_.uid).peakgame_ace_count = _ARG_2_.peakgame_ace_count
          U2.GetMemberInfo(_ARG_2_.uid).peakgame_ace_id = _ARG_2_.peakgame_ace_id
          U2.GetMemberInfo(_ARG_2_.uid).ace_show_type = _ARG_2_.ace_show_type
        end
      elseif _ARG_1_ == 23 then
      elseif _ARG_1_ == 24 then
        if _ARG_2_ ~= nil and _ARG_3_ ~= nil and type(_ARG_3_) == U1(208, 216, 18, 176, 97) and LobbySystem.CheckOpen(BP_ENUM_TEAM_UP_LIMIT_SWITCH) then
        end
      elseif _ARG_1_ == 25 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 26 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 27 then
        if _ARG_2_ and type(_ARG_2_.voice_download_ids) == U1(208, 216, 18, 176, 97) and next(_ARG_2_.voice_download_ids) then
          goto lbl_2364
          ::lbl_2364::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      elseif _ARG_1_ == 29 or _ARG_1_ == 30 then
        if U2.GetMemberInfo(_ARG_3_) then
          U2.GetMemberInfo(_ARG_3_).main_city_info = _ARG_2_
        end
      elseif _ARG_1_ == 100 then
        if U2.GetMemberInfo(_ARG_3_) then
          U2.GetMemberInfo(_ARG_3_).upvote = _ARG_2_
          U2.GetMemberInfo(_ARG_3_).recent_upvote = _ARG_4_
        end
      elseif _ARG_1_ == 101 then
      elseif _ARG_1_ == 102 then
        if U2.GetMemberInfo(_ARG_3_) then
          U2.GetMemberInfo(_ARG_3_).aliasid = _ARG_2_.id
          U2.GetMemberInfo(_ARG_3_).aliastitle = FuncUtil.Gen_title(_ARG_2_.id, _ARG_2_.rank, _ARG_2_.ext_info, _ARG_2_.rank_id)
          U2.GetMemberInfo(_ARG_3_).aliasnation = _ARG_2_.nation
          U2.GetMemberInfo(_ARG_3_).aliasRankId = _ARG_2_.rank_id
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U2.GetMemberInfo(_ARG_3_).uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U2.GetMemberInfo(_ARG_3_).uid).alias then
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U2.GetMemberInfo(_ARG_3_).uid).alias.id = U2.GetMemberInfo(_ARG_3_).aliasid
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U2.GetMemberInfo(_ARG_3_).uid).alias.title = U2.GetMemberInfo(_ARG_3_).aliastitle
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U2.GetMemberInfo(_ARG_3_).uid).alias.nation = U2.GetMemberInfo(_ARG_3_).aliasnation
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U2.GetMemberInfo(_ARG_3_).uid).alias.rank_id = U2.GetMemberInfo(_ARG_3_).aliasRankId
          end
        end
      elseif _ARG_1_ == 103 then
        if 1 < U2.GetTeamNum() then
          if U2.lastMemberLoginTime and _ARG_2_ and _ARG_2_.map_info then
            goto lbl_2536
            if EVENTTYPE_TEAMUP ~= 77 then
            else
              ::lbl_2536::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
            if false then
            end
          end
          if true then
            U2.lastMemberLoginTime = nil
          else
            U2.lastMemberLoginTime = nil
          end
        end
      elseif _ARG_1_ == 104 then
        goto lbl_2742
        U2.headShowChangeInfo.uid = 220, 17, U2.headShowChangeInfo
        U2.headShowChangeInfo.param = 17, U2.headShowChangeInfo, "param"
        ::lbl_2742::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_1_ == 105 then
      elseif _ARG_1_ == 106 then
      elseif _ARG_1_ == 107 then
        if _ARG_2_ and U2.GetSelfUID() == tonumber(_ARG_2_) then
        else
        end
      elseif _ARG_1_ == 117 then
      elseif _ARG_1_ == 109 then
        U2.teamInfo.intimacy_info = _ARG_2_
        if 1 < U2.GetTeamNum() then
        end
      elseif _ARG_1_ == 118 and _ARG_2_ then
        if U2.teamInfo and U2.teamInfo.members[U2.teamInfo.leader or 0] and U2.teamInfo.members[U2.teamInfo.leader or 0].ugc_mod_bundle then
          U2.teamInfo.members[U2.teamInfo.leader or 0].ugc_mod_bundle = _ARG_2_
        end
      elseif _ARG_1_ == 119 and _ARG_2_ then
        if 1 < U2.GetTeamNum() and U2.IsUGCModInfoSyncChanged(_ARG_2_) then
        end
      elseif _ARG_1_ == 120 then
      elseif _ARG_1_ == 130 then
        if _ARG_2_ then
        else
        end
      elseif _ARG_1_ == 131 then
        if _ARG_2_ then
        end
      elseif _ARG_1_ == 132 then
        if _ARG_2_ then
          if _ARG_2_.privilege_data and _ARG_2_.privilege_data.use_color then
          end
        else
        end
      elseif _ARG_1_ == 133 then
        if _ARG_2_ and type(_ARG_2_) == U1(208, 216, 18, 176, 97) and U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).brief_collect_data = _ARG_2_.brief_collect_data or {}
        end
      elseif _ARG_1_ == 134 then
        if _ARG_2_ and U2.GetMemberInfo(_ARG_2_.uid) then
          U2.GetMemberInfo(_ARG_2_.uid).set_milestone_data = _ARG_2_.set_milestone_data or {}
        end
      elseif _ARG_1_ == 135 and _ARG_2_ then
        if type(_ARG_2_) == U1(208, 216, 18, 176, 97) and _ARG_2_.uid and _ARG_2_.uid ~= tonumber(DataMgr.roleData.uid) then
          if _ARG_2_.flag == 1 then
            if require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
              U1(202, 216, 23, 185, 118)
            }))).GetAvatarByUid(_ARG_2_.uid) ~= nil and require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
              U1(202, 216, 23, 185, 118)
            }))).GetAvatarByUid(_ARG_2_.uid):GetModel() ~= nil then
            end
          elseif _ARG_2_.flag == 2 and require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
            U1(202, 216, 23, 185, 118)
          }))).CheckHasEquipped(_ARG_2_.uid, _ARG_2_.resid) and CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 15, 85, 183, 128, 194), _ARG_2_.resid) and CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 15, 85, 183, 128, 194), _ARG_2_.resid).Features and CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 15, 85, 183, 128, 194), _ARG_2_.resid).Features ~= U1() then
            goto lbl_4014
            if CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 5, 78, 188, 139, 216, 82), tonumber(107) or 0) and CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 5, 78, 188, 139, 216, 82), tonumber(107) or 0).FeatureType == 49 and CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 5, 78, 188, 139, 216, 82), tonumber(107) or 0).ExpressionID and 0 < CDataTable.GetTableData(U1(226, 220, 17, 168, 113, 171, 159, 160, 5, 78, 188, 139, 216, 82), tonumber(107) or 0).ExpressionID then
            else
              ::lbl_4014::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
      elseif _ARG_1_ == 136 then
      elseif _ARG_1_ == 999 then
      elseif _ARG_1_ == 122 then
        if require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
          U1(203, 215, 47, 177, 101, 176, 148)
        }))).IsInXMission() then
          if _ARG_2_ then
          end
        end
      elseif _ARG_1_ == 123 then
        if require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
          U1(203, 215, 47, 177, 101, 176, 148)
        }))).IsInXMission() then
          if _ARG_2_ then
          end
        end
      elseif _ARG_1_ == 137 then
      elseif _ARG_1_ == 138 and _ARG_2_ then
        if type(_ARG_2_) == U1(208, 216, 18, 176, 97) and _ARG_2_.uid and _ARG_2_.uid ~= tonumber(DataMgr.roleData.uid) and require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
          U1(202, 216, 23, 185, 118)
        }))).GetAvatarByUid(_ARG_2_.uid) ~= nil and require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
          U1(202, 216, 23, 185, 118)
        }))).GetAvatarByUid(_ARG_2_.uid):GetModel() ~= nil then
        end
      elseif _ARG_1_ == 139 and _ARG_2_ then
        if type(_ARG_2_) == U1(208, 216, 18, 176, 97) and _ARG_2_.uid and _ARG_2_.uid ~= tonumber(DataMgr.roleData.uid) and require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
          U1(202, 216, 23, 185, 118)
        }))).GetAvatarByUid(_ARG_2_.uid) ~= nil and require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
          U1(202, 216, 23, 185, 118)
        }))).GetAvatarByUid(_ARG_2_.uid):GetModel() ~= nil then
        end
      end
      do return end
      _ARG_0_ = _ENV[73]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_change_wear"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      changeWearInfo = {
        uid = _ARG_0_,
        pos = _ARG_1_,
        resId = _ARG_2_,
        avatarPos = _ARG_3_,
        wearInfo = _ARG_4_ or {}
      }
      if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).IsXSuit(_ARG_2_) and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_) then
        if _ARG_6_ and _ARG_6_.set_info and _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_)] and _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_)][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_) or 0] and _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_)][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_) or 0].bicolor_state then
        end
        changeWearInfo.resId = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel(_ARG_2_, _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_)][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_) or 0]), _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_)][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_) or 0].bicolor_state), changeWearInfo
      end
      if _ARG_4_ and _ARG_4_[1] then
        if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).IsXSuit(_ARG_4_[1]) and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1]) then
          if _ARG_5_ and _ARG_5_.set_info and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])] and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0] and (_ARG_4_[U1.ENUM_AVATAR_DATA_TYPE.Source] or 0) ~= U1.EWardrobeDataSource.InheritWardrobe then
          end
          if _ARG_6_ and _ARG_6_.set_info and _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])] and _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0] and _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0].bicolor_state then
          end
          _ARG_4_[1] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel(_ARG_4_[1], _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0]), _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0].bicolor_state)
          changeWearInfo.resId = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel(_ARG_4_[1], _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0]), _ARG_6_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_4_[1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0].bicolor_state), U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_4_[1]) or 0, _ARG_4_[U1.ENUM_AVATAR_DATA_TYPE.Source] or 0, changeWearInfo
        end
      end
      if not GetMemberInfo(U1.tonumber(_ARG_0_)) then
        return
      end
      if not GetMemberInfo(U1.tonumber(_ARG_0_)).wear_ext then
        return
      end
      if GetMemberInfo(U1.tonumber(_ARG_0_)).wear_ext[_ARG_3_] then
        if _ARG_1_ == 1 then
          teamInfo.members[U1.tonumber(_ARG_0_)].wear_ext[_ARG_3_] = _ARG_4_
        else
          goto lbl_416
          if U1.tonumber(_ARG_0_) == _ARG_3_ then
            if changeWearInfo and changeWearInfo.resId and changeWearInfo.resId <= 0 then
              changeWearInfo.resId = _ARG_0_[1]
            end
            teamInfo.members[U1.tonumber(_ARG_0_)].wear_ext[U1.tonumber(_ARG_0_)] = nil
          end
          ::lbl_416::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      elseif _ARG_1_ == 1 then
        teamInfo.members[U1.tonumber(_ARG_0_)].wear_ext[_ARG_3_] = _ARG_4_
      end
      do return end
      _ARG_0_ = U1[44]
    end
  end,
  ["on_change_type_rsp"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 191, 108, 184, 148, 180, 35, 126, 166, 148, 193, 80, 77, 229, 39, 249, 32, 138, 149, 128, 230, 135)
      }) .. _ARG_0_)
      if _ARG_0_ ~= NetErrorCode_NONE then
        if _ARG_0_ == U1(199, 216, 30, 168, 41, 186, 146, 178, 40, 70, 183, 192, 197, 90, 63, 175, 34, 177) then
          ShowNotice(27577)
        elseif _ARG_0_ == U1(209, 222, 19, 131, 105, 188, 151, 177, 35, 83, 141, 129, 212, 67, 119, 251, 11, 229, 105, 129, 157, 157) then
          ShowNotice(48643)
        elseif _ARG_0_ == U1(209, 222, 19, 131, 105, 188, 151, 177, 35, 83, 141, 137, 212, 67, 77, 251, 61, 228, 105) then
          ShowNotice(48458)
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_change_leader_rsp"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 191, 108, 184, 148, 180, 35, 126, 190, 136, 208, 81, 119, 229, 11, 251, 115, 156)
      }) .. _ARG_0_)
      if _ARG_0_ == U1(201, 220, 29, 190, 97, 171, 215, 188, 32, 71, 190, 132, 223, 80) then
        ShowNotice(110065)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_update_wear"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      changeWearPair = {
        uid = _ARG_0_,
        ware = _ARG_1_,
        wear_ext = _ARG_2_
      }
      if _ARG_1_ and _ARG_1_[3] then
        if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).IsXSuit(_ARG_1_[3]) and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3]) and _ARG_5_ and _ARG_5_.set_info and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])] and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_1_[3]) or 0] and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_1_[3]) or 0].bicolor_state then
        end
        _ARG_1_[3] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel(_ARG_1_[3], _ARG_4_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_1_[3]) or 0]), _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_1_[3]) or 0].bicolor_state)
        changeWearPair.ware[3] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel(_ARG_1_[3], _ARG_4_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_1_[3]) or 0]), _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_1_[3])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_1_[3]) or 0].bicolor_state), changeWearPair.ware
      end
      if _ARG_2_ and _ARG_2_[3] and _ARG_2_[3][1] then
        if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).IsXSuit(_ARG_2_[3][1]) then
          if _ARG_4_ and _ARG_4_.set_info and _ARG_4_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])] and _ARG_4_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_[3][1]) or 0] and (_ARG_2_[3][U1.ENUM_AVATAR_DATA_TYPE.Source] or 0) ~= U1.EWardrobeDataSource.InheritWardrobe then
          end
          if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1]) and _ARG_5_ and _ARG_5_.set_info and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])] and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_[3][1]) or 0] and _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_[3][1]) or 0].bicolor_state then
          end
          changeWearPair.wear_ext[3][1] = U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel(_ARG_2_[3][1], _ARG_4_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_[3][1]) or 0]), _ARG_5_.set_info[U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1])][U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId(_ARG_2_[3][1]) or 0].bicolor_state), U1.require((U2(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId(_ARG_2_[3][1]), changeWearPair.wear_ext[3]
        end
      end
      if _ARG_3_ and teamInfo and teamInfo.members then
        goto lbl_334
        if U1.tonumber(_ARG_0_) == U1.tonumber(_ARG_0_) then
          if _ARG_3_.weapon_wear_info then
            _ARG_2_[3][1].weapon_wear_info.weapon_id = _ARG_3_.weapon_wear_info.weapon_id
            _ARG_2_[3][1].weapon_wear_info.skin_id = _ARG_3_.weapon_wear_info.skin_id
            if _ARG_3_.weapon_wear_info.ext_info then
              _ARG_2_[3][1].weapon_wear_info.ext_info = _ARG_3_.weapon_wear_info.ext_info
            end
          else
            _ARG_2_[3][1].weapon_wear_info.weapon_id = 0
            _ARG_2_[3][1].weapon_wear_info.skin_id = 0
          end
          _ARG_2_[3][1].vst_info.skin_id = _ARG_3_.vst_skin.skin_id
          _ARG_2_[3][1].vst_info.vst_type = _ARG_3_.vst_skin.vst_type
          _ARG_2_[3][1].vst_info.skin_style_list = _ARG_3_.vst_skin.skin_style_list
          _ARG_2_[3][1].background = _ARG_3_.background
          _ARG_2_[3][1].bag_pendants = _ARG_3_.bag_pendants
          headShowChangeInfo.uid = U1.tonumber(_ARG_0_), U1.pairs(teamInfo.members)
          headShowChangeInfo.param = _ARG_3_.skin_info
          _ARG_2_[3][1].skin_info = _ARG_3_.skin_info
        else
          ::lbl_334::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_3_ = U1.Source
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_plat_get_teamid_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_ == NetErrorCode_NONE then
        if _G.BP_Platform == BP_ENUM_PLAYFORM_WX then
        elseif _G.BP_Platform == BP_ENUM_PLAYFORM_BGBG then
        end
      elseif _ARG_0_ == U1(208, 220, 17, 177, 91, 176, 137, 140, 32, 84, 190, 129) then
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 128, 208, 65, 113, 255) then
      elseif _ARG_0_ == U1(197, 213, 2, 185, 101, 189, 131, 140, 47, 79, 141, 138, 208, 88, 119) then
      elseif _ARG_0_ == U1(195, 204, 21, 175, 112, 134, 137, 167, 39, 85, 183, 178, 211, 84, 124, 249, 49, 237) then
      elseif _ARG_0_ == U1(202, 214, 4, 131, 98, 171, 147, 182, 40, 69) then
      elseif _ARG_0_ == U1(200, 214, 7, 131, 116, 171, 147, 188, 52, 72, 166, 148, 238, 88, 115, 227, 55, 225, 95, 142, 149, 135, 228, 134, 50) or _ARG_0_ == U1(201, 216, 4, 191, 108, 134, 147, 160, 41, 77, 179, 153, 216, 90, 124, 200, 56, 232, 98, 137, 152, 182, 232, 130, 56, 95, 167, 153) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_room_invite_notify"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_)
    do
      log(bWriteLog and U1(203, 215, 47, 174, 107, 182, 151, 140, 47, 79, 164, 132, 197, 80, 77, 249, 59, 253, 105, 138, 141, 201, 227, 141, 32, 88, 182, 152, 211, 5, 63, 167) .. _ARG_0_)
      log(bWriteLog and U1(203, 215, 47, 174, 107, 182, 151, 140, 47, 79, 164, 132, 197, 80, 77, 249, 59, 253, 105, 138, 141, 201, 248, 140, 57, 92, 157, 148, 197, 5, 63, 167) .. _ARG_1_)
      log(bWriteLog and U1(203, 215, 47, 174, 107, 182, 151, 140, 47, 79, 164, 132, 197, 80, 77, 249, 59, 253, 105, 138, 141, 201, 231, 140, 50, 84, 226, 192, 129) .. tostring(_ARG_2_))
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(203, 215, 47, 174, 107, 182, 151, 140, 47, 79, 164, 132, 197, 80, 77, 249, 59, 253, 105, 138, 141, 197, 170, 153, 57, 95, 167, 162, 200, 65, 34, 186, 100)
      }) .. tostring(_ARG_3_))
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
        U1(203, 215, 47, 177, 101, 176, 148)
      }))).IsInXMission() and _ARG_6_ ~= U1(208, 212, 31, 184, 97) then
        return
      end
      if _ARG_8_ then
      end
      if U2.CheckInviteAutoRefuse(_ARG_0_) then
        if _ARG_4_ and _ARG_4_ == require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 101, 159, 132, 134, 248, 151, 120, 93, 173, 154, 200, 70, 93, 226, 55, 233, 127, 142, 144, 166, 249, 150),
          U1(202, 205, 21, 174)
        }))).E_CompeteType.AllStar then
        else
        end
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_) then
        return
      end
      if _ARG_6_ and _ARG_6_ == U1(197, 202, 25, 189, 106, 134, 157, 178, 43, 68, 161) then
      end
      if _ARG_3_ then
      end
      if _ARG_4_ then
      end
      if _ARG_5_ then
      end
      if U2.CheckSameInvite(_ARG_0_, true and U3.AsiaRoomInvite or U3.RoomInvite) == 0 then
      else
        U2.inviteApplyQueue[U2.CheckSameInvite(_ARG_0_, true and U3.AsiaRoomInvite or U3.RoomInvite)] = {
          type = true and U3.AsiaRoomInvite or U3.RoomInvite,
          playerId = _ARG_0_,
          inviterRoomID = _ARG_1_,
          playerName = U2.GetMemberName(_ARG_0_),
          gameType = U2.GetOldGameType(999),
          showCD = U4,
          closeCD = U5,
          closeTotalTime = U5,
          mapName = true and LocUtil.GetLocalizeResStr(29743) or U1(),
          map_id = _ARG_7_,
          mod_id = _ARG_8_,
          ["zoneName"] = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(_ARG_3_),
          ["competeType"] = _ARG_4_,
          ["stageID"] = _ARG_5_
        }, U2.inviteApplyQueue
      end
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        return
      end
      do return end
      _ARG_0_ = IsInXMission
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_match_zone_notify"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 59, 80, 182, 158, 201, 122, 120, 232, 42, 252, 79, 146, 139, 141, 243, 149),
          U1(221, 149, 80, 177, 101, 173, 153, 187, 25, 91, 189, 131, 212, 21, 123, 228, 116, 231, 105, 128)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 59, 80, 182, 158, 201, 122, 120, 232, 42, 252, 79, 146, 139, 141, 243, 149),
        U1(221, 149, 80, 177, 101, 173, 153, 187, 25, 91, 189, 131, 212, 21, 47, 183)
      }) .. tostring(_ARG_0_))
      if not U2.teamInfo then
        log_error(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 59, 231, 95, 152, 145, 136, 231, 188, 59, 80, 182, 158, 201, 122, 120, 232, 42, 252, 79, 146, 139, 141, 243, 149),
          U1(221, 149, 80, 168, 97, 184, 151, 186, 40, 71, 189, 205, 216, 70, 50, 249, 61, 229)
        }))
        return
      end
      U2.teamInfo.zone_id = _ARG_0_
      if GameStatus.IsInMainCity() and U2.GetTeamNum() > 1 then
        ShowNotice(656093)
      end
      if not U2.GetMemberInfo(U2.teamInfo.leader) then
        return
      end
      U2.GetMemberInfo(U2.teamInfo.leader).self_zone_id = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[52]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWeapon"] = function()
    if GetTeamNum() > 1 and teamInfo.members then
      goto lbl_143
      if U1.tonumber(nil) ~= GetSelfUID() then
        if (nil).weapon_wear_info then
        else
        end
        if not ({
          ["weaponId"] = (nil).weapon_wear_info.weapon_id,
          ["skinId"] = (nil).weapon_wear_info.skin_id,
          ["usingDiyRecommend"] = (nil).weapon_wear_info.is_using_recommend,
          ["diyPlanId"] = (nil).weapon_wear_info.cur_use_plan,
          ["weaponId"] = 0,
          ["skinId"] = 0,
          ["usingDiyRecommend"] = false,
          ["diyPlanId"] = 0,
          ["weaponId"] = (106).weapon_id,
          ["skinId"] = (106).skin_id,
          ["usingDiyRecommend"] = (106).is_using_recommend,
          ["diyPlanId"] = (106).cur_use_plan
        }).weaponId or U1.tonumber(({
          ["weaponId"] = (nil).weapon_wear_info.weapon_id,
          ["skinId"] = (nil).weapon_wear_info.skin_id,
          ["usingDiyRecommend"] = (nil).weapon_wear_info.is_using_recommend,
          ["diyPlanId"] = (nil).weapon_wear_info.cur_use_plan,
          ["weaponId"] = 0,
          ["skinId"] = 0,
          ["usingDiyRecommend"] = false,
          ["diyPlanId"] = 0,
          ["weaponId"] = (106).weapon_id,
          ["skinId"] = (106).skin_id,
          ["usingDiyRecommend"] = (106).is_using_recommend,
          ["diyPlanId"] = (106).cur_use_plan
        }).weaponId) == 0 then
        else
        end
        if (nil).weapon_wear_info.ext_info and U1.next((nil).weapon_wear_info.ext_info) then
          goto lbl_141
          if not (106).weapon_id or U1.tonumber((106).weapon_id) == 0 then
          else
          end
          ::lbl_141::
        end
      end
      ::lbl_143::
    end
    return
  end,
  ["CompareMember"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
          U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 124, 242, 35, 221, 101, 141, 153, 160, 228, 133, 57, 17, 172, 146, 207, 64)
        }))
        return
      end
      if not U2.teamInfo.player_count then
        U2.bIsAddMember = true
        goto lbl_410
        if U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221) ~= U2.GetSelfUID() then
          if (U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3] and (U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1] then
            if U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info.set_info and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])] and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]) or 0] and (U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][ENUM_AVATAR_DATA_TYPE.Source] ~= EWardrobeDataSource.InheritWardrobe then
            end
            if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]) and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info_all and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info_all.set_info and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])] and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]) or 0] and U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]) or 0].bicolor_state then
            end
            ;(U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1] = require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1], U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]) or 0]), U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]) or 0].bicolor_state), (U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][ENUM_AVATAR_DATA_TYPE.Source], require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))), require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3][1]), (U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 97, 242, 56, 239, 85, 165, 176).wear_ext or {})[3]
          end
        end
        ::lbl_410::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return
      end
      U2.changeMemberInfo = {}
      if _ARG_0_.player_count == U2.teamInfo.player_count then
        U2.bIsAddMember = false
        return
      end
      if _ARG_0_.player_count > U2.teamInfo.player_count then
        U2.bIsAddMember = true
        goto lbl_583
        if U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221).wear_ext == nil then
        end
        goto lbl_537
        if pairs(_ARG_0_.members) == U1(231, 214, 29, 172, 101, 171, 159, 158, 35, 76, 176, 136, 195, 21, 100, 185, 35, 236, 97, 158, 171, 140, 242, 151, 118, 12, 226, 147, 200, 73, 34, 181) then
        else
          ::lbl_537::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if true == false then
        end
        ::lbl_583::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_0_.player_count < U2.teamInfo.player_count then
        U2.bIsAddMember = false
        goto lbl_712
        if U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221).wear_ext == nil then
        end
        goto lbl_671
        if pairs(_ARG_0_.members) == U1(132, 132, 80, 178, 109, 181, 218, 225) then
        else
          ::lbl_671::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if true == false then
        end
        ::lbl_712::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeMember"] = function()
    if #changeMemberInfo == 0 then
      return
    end
    goto lbl_516
    if U1.tonumber(U2(203, 215, 47, 177, 101, 176, 148).gid) ~= GetSelfUID() then
      if U2(203, 215, 47, 177, 101, 176, 148).gender then
      end
      if U2(203, 215, 47, 177, 101, 176, 148).wear then
        goto lbl_215
        ::lbl_215::
        goto lbl_294
        if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_suit_dye):SetPlanData(U2(203, 215, 47, 177, 101, 176, 148).gid, U2(205, 215, 22, 179, 62, 249)[1], U2(205, 215, 22, 179, 62, 249)[5])[1] then
        else
        end
        ::lbl_294::
        goto lbl_313
        ::lbl_313::
      end
      if U2(203, 215, 47, 177, 101, 176, 148).bag_pendants then
        goto lbl_330
        ::lbl_330::
      end
      if U2(203, 215, 47, 177, 101, 176, 148).skin_info and U2(203, 215, 47, 177, 101, 176, 148).skin_info.helmet_skin and U2(203, 215, 47, 177, 101, 176, 148).skin_info.helmet_skin ~= 0 and (U2(203, 215, 47, 177, 101, 176, 148).skin_info.head_show == 0 or U2(203, 215, 47, 177, 101, 176, 148).skin_info.head_show == U2(203, 215, 47, 177, 101, 176, 148).skin_info.helmet_skin) and U2(203, 215, 47, 177, 101, 176, 148).depot_show_info.helmet ~= false and U1.DataMgr.GetEquipmentItemIDByResID(U2(203, 215, 47, 177, 101, 176, 148).skin_info.helmet_level, U2(203, 215, 47, 177, 101, 176, 148).skin_info.helmet_skin) ~= 0 then
        if U2(203, 215, 47, 177, 101, 176, 148).wear[1] then
          goto lbl_379
          if U1.AvatarData.CreateAvatarCustom(U1.ipairs((U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 184, 134, 232, 129, 47, 112, 180, 156, 213, 68, 112, 202, 37, 247, 113, 155, 129, 139))).SortEquipmentIDList({})))).ItemID == U2(203, 215, 47, 177, 101, 176, 148).wear[1][1] then
            U1.AvatarData.CreateAvatarCustom(U1.ipairs((U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 184, 134, 232, 129, 47, 112, 180, 156, 213, 68, 112, 202, 37, 247, 113, 155, 129, 139))).SortEquipmentIDList({})))).ItemID = 0
          end
          ::lbl_379::
        end
      end
    end
    ::lbl_516::
    changeMemberInfo = {}
    return
  end,
  ["UpdateTeamMemberAvatar"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_1063
      if tonumber(185) ~= U2.GetSelfUID() or _ARG_1_ then
        if (106).wear_ext == nil then
        end
        goto lbl_300
        ::lbl_300::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if (106).wear_ext or {}[3] and (106).wear_ext or {}[3][1] then
          if require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1]) then
            if (106).gold_dress_set_info and (106).gold_dress_set_info.set_info and (106).gold_dress_set_info.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])] and (106).gold_dress_set_info.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((106).wear_ext or {}[3][1]) or 0] and ((106).wear_ext or {}[3][ENUM_AVATAR_DATA_TYPE.Source] or 0) ~= EWardrobeDataSource.InheritWardrobe then
            end
            if (106).gold_dress_set_info_all and (106).gold_dress_set_info_all.set_info and (106).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])] and (106).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((106).wear_ext or {}[3][1]) or 0] and (106).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((106).wear_ext or {}[3][1]) or 0].bicolor_state then
            end
            ;(106).wear_ext or {}[3][1] = require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).ChangeItemIDByState(require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetSwitchItemByItemAndSwitchLevel((106).wear_ext or {}[3][1], (106).gold_dress_set_info.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((106).wear_ext or {}[3][1]) or 0]), (106).gold_dress_set_info_all.set_info[require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetPeriodByItemId((106).wear_ext or {}[3][1])][require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((106).wear_ext or {}[3][1]) or 0].bicolor_state), require((U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 88, 191, 129, 128, 254, 205, 58, 94, 165, 148, 194, 122, 122, 244, 49, 240, 100))).GetBranchByItemId((106).wear_ext or {}[3][1]) or 0, (106).wear_ext or {}[3][ENUM_AVATAR_DATA_TYPE.Source] or 0, (106).wear_ext or {}[3]
          end
        end
        if U2.GetMemberInfo(185) ~= nil then
          goto lbl_517
          if U3((106).wear_ext or {}, 185) == nil then
          end
          ::lbl_517::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if (function()
          if not _ENV or _ENV == 0 then
            return false
          end
          do return (U1 == _ENV or U1 == 0) and U1.helmet ~= false end
          return
        end)() then
          if DataMgr.GetEquipmentItemIDByResID((106).skin_info.helmet_level, (106).skin_info.helmet_skin) ~= 0 then
            goto lbl_549
            if 83 ~= 1 then
            end
            ::lbl_549::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          else
          end
        else
        end
        goto lbl_579
        ::lbl_579::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_679
        ::lbl_679::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if _ARG_2_ and _ARG_2_.members and _ARG_2_.members[185] and not _ARG_1_ then
          goto lbl_772
          if U1(200, 221, 80, 168, 97, 184, 151, 178, 50, 68)[1] ~= nil then
          end
          ::lbl_772::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if DataMgr.roleData.uid ~= tostring(185) or not require((table.concat({
          U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 145, 206, 66, 107, 228, 27, 238, 113, 142, 128, 139, 245, 145),
          U1(193, 230, 30, 185, 115)
        }))):IsInFashionBagEditMode() then
          goto lbl_945
          if ({
            [U1(200, 221, 80, 168, 97, 184, 151, 178, 50, 68)[1]] = true
          })[({})[U1(193, 230, 30, 185, 115).itemID].itemID] then
          else
          end
          ::lbl_945::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
        end
      end
      ::lbl_1063::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecoverTargetEquipment"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
        U1(202, 216, 23, 185, 118)
      }))).teamInfo or not U2.teamInfo.members then
        return
      end
      goto lbl_661
      if tonumber(U1(202, 216, 23, 185, 118)) == tonumber(_ARG_0_) then
        if U1(202, 216, 23, 185, 118).wear_ext == nil then
        end
        if _ARG_0_ == DataMgr.roleData.uid then
          if require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
            U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
          }))):GetKnapsackExtInfoByIndex((require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
            U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
          }))):GetFashionBagUseIndex())) ~= nil and require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
            U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
          }))):GetKnapsackExtInfoByIndex((require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
            U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
          }))):GetFashionBagUseIndex())).head_show == require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
            U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
          }))):GetKnapsackExtInfoByIndex((require((table.concat({
            U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
            U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
          }))):GetFashionBagUseIndex())).helmet_skin then
          end
        end
        if (function()
          if not _ENV or _ENV == 0 then
            return false
          end
          do return (U1 == _ENV or U1 == 0) and U1.helmet ~= false end
          return
        end)() then
          if DataMgr.GetEquipmentItemIDByResID(U1(202, 216, 23, 185, 118).skin_info.helmet_level, U1(202, 216, 23, 185, 118).skin_info.helmet_skin) ~= 0 then
            goto lbl_398
            if require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
              U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
            }))):GetKnapsackExtInfoByIndex((require((table.concat({
              U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 119, 141, 134, 141, 248, 140, 52, 84, 236, 155, 192, 86, 106, 238, 43, 247, 114, 157, 131, 215, 252, 146),
              U1(215, 209, 25, 179, 106, 187, 155, 180, 25, 69, 179, 153, 208)
            }))):GetFashionBagUseIndex())).helmet_level ~= 1 then
            end
            ::lbl_398::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          else
          end
        else
        end
        goto lbl_428
        ::lbl_428::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_528
        ::lbl_528::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_657
        ::lbl_657::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_661::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMemberHeadShowInfo"] = function(_ARG_0_)
    do
      if teamInfo then
        if _ARG_0_.param.head_show then
          teamInfo.members[U1.tonumber(_ARG_0_.uid)].skin_info.head_show = _ARG_0_.param.head_show
        end
        if _ARG_0_.param.bag_skin then
          teamInfo.members[U1.tonumber(_ARG_0_.uid)].skin_info.bag_skin = _ARG_0_.param.bag_skin
        end
        if _ARG_0_.param.helmet_skin then
          teamInfo.members[U1.tonumber(_ARG_0_.uid)].skin_info.helmet_skin = _ARG_0_.param.helmet_skin
        end
        if _ARG_0_.param.bag_level then
          teamInfo.members[U1.tonumber(_ARG_0_.uid)].skin_info.bag_level = _ARG_0_.param.bag_level
        end
        if _ARG_0_.param.helmet_level then
          teamInfo.members[U1.tonumber(_ARG_0_.uid)].skin_info.helmet_level = _ARG_0_.param.helmet_level
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMemberWeaponChange"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(235, 215, 61, 185, 105, 187, 159, 161, 17, 68, 179, 157, 222, 91, 81, 255, 53, 231, 103, 137, 212, 156, 227, 135, 118, 12, 226)
      }) .. tostring(_ARG_0_))
      if U2.GetMemberInfo(_ARG_0_) and U2.GetMemberInfo(_ARG_0_).weapon_wear_info then
        if not U2.GetMemberInfo(_ARG_0_).weapon_wear_info.weapon_id or tonumber(U2.GetMemberInfo(_ARG_0_).weapon_wear_info.weapon_id) == 0 then
        else
          if U2.GetMemberInfo(_ARG_0_).weapon_wear_info then
          else
          end
          if U2.GetMemberInfo(_ARG_0_).weapon_wear_info.ext_info and next(U2.GetMemberInfo(_ARG_0_).weapon_wear_info.ext_info) then
            goto lbl_218
            if not (173).weapon_id or tonumber((173).weapon_id) == 0 then
            else
            end
            ::lbl_218::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeBagPendant"] = function(_ARG_0_)
    do
      if GetMemberInfo(_ARG_0_.uid) then
        if not _ARG_0_.bag_pendants or not U1.next(_ARG_0_.bag_pendants) then
          if GetMemberInfo(_ARG_0_.uid).bag_pendants then
            goto lbl_87
            ::lbl_87::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            GetMemberInfo(_ARG_0_.uid).bag_pendants = _ARG_0_.bag_pendants
          end
        else
          GetMemberInfo(_ARG_0_.uid).bag_pendants = _ARG_0_.bag_pendants
          goto lbl_108
          ::lbl_108::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_team_change_avatar"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(203, 215, 47, 168, 97, 184, 151, 140, 37, 73, 179, 131, 214, 80, 77, 246, 34, 232, 116, 141, 134) .. _ARG_0_)
      U2.changeAvatarInfo = {
        reCreate = U3(_ARG_0_, _ARG_1_),
        needChangeSex = U4(_ARG_0_, _ARG_1_),
        uid = _ARG_0_,
        avatar = _ARG_1_
      }
      if U2.GetMemberInfo(_ARG_0_) then
        if U2.GetMemberInfo(_ARG_0_).avatar then
          U2.changeAvatarInfo.oldAvatar = U2.GetMemberInfo(_ARG_0_).avatar
        end
        U2.GetMemberInfo(_ARG_0_).avatar = _ARG_1_
        U2.GetMemberInfo(_ARG_0_).gender = _ARG_1_.gamegender
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["sync_player_action"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U1(215, 192, 30, 191, 91, 169, 150, 178, 63, 68, 160, 178, 208, 86, 102, 254, 59, 231, 32, 156, 152, 136, 243, 134, 36, 110, 183, 148, 197, 5, 63, 167)
      }) .. tostring(_ARG_0_) .. U1(136, 153, 17, 191, 112, 176, 149, 189, 25, 72, 182, 205, 140, 21) .. tostring(_ARG_1_) .. U1(136, 203, 17, 178, 96, 138, 149, 166, 40, 69, 155, 137, 140) .. tostring(_ARG_2_) .. U1(194, 214, 28, 176, 107, 174, 165, 186, 34) .. tostring(_ARG_3_))
      if _ARG_4_ and _ARG_4_.stopAction or false then
        return
      end
      if GlobalData.IsJapanOrKorea() and CDataTable.GetTableData(U1(237, 205, 21, 177), _ARG_1_) and CDataTable.GetTableData(U1(237, 205, 21, 177), _ARG_1_).JKBPID and CDataTable.GetTableData(U1(237, 205, 21, 177), _ARG_1_).JKBPID > 0 then
        _ARG_1_ = CDataTable.GetTableData(U1(237, 205, 21, 177), _ARG_1_).JKBPID
      end
      if _ARG_1_ == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule):GetActionItemID() then
      end
      if U2.GetTeamNum() > 1 and U2.IsTeamLeader(_ARG_0_) and U2.CheckEmoteCanFollow(_ARG_1_) then
        goto lbl_418
        ::lbl_418::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[221]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPlayerAction"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 7, 253, 111, 156, 164, 133, 235, 154, 51, 67, 131, 158, 213, 76, 109, 233, 100, 233, 124, 157, 157, 156, 232, 172),
        U1(209, 208, 20, 252, 57, 249)
      }) .. tostring(_ARG_0_))
      if U2.GetTeamNum() > 1 and U2.IsTeamLeader(_ARG_0_) then
        goto lbl_128
        ::lbl_128::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamCode"] = function()
    do return U1.teamInfo.code end
    return
  end,
  ["SetTeamCode"] = function(_ARG_0_)
    do
      if teamInfo then
        teamInfo.code = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInFaceTeam"] = function()
    if GetTeamCode() and U1.string.len((GetTeamCode())) > 0 then
      return true
    end
    do return false end
    return
  end,
  ["team_recruit_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["team_recruit_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      msgContentCacheMap[_ARG_3_] = nil
      if _ARG_0_ == U1.NetErrorCode_NONE then
        if not teamInfo then
          teamInfo = {}
        end
        teamInfo.id = _ARG_2_
        if not msgContentCacheMap[_ARG_3_] then
          return
        end
        if true == msgContentCacheMap[_ARG_3_].quickMsg then
        end
        if nil ~= msgContentCacheMap[_ARG_3_].voice and U2() ~= msgContentCacheMap[_ARG_3_].voice then
        end
        if _ARG_4_ then
        end
        if msgContentCacheMap[_ARG_3_].taskId and 0 < msgContentCacheMap[_ARG_3_].taskId then
          if msgContentCacheMap[_ARG_3_].send_to_recruit_channel then
          elseif msgContentCacheMap[_ARG_3_].send_to_corps_channel then
          end
        end
      elseif _ARG_0_ == U2(214, 220, 1, 169, 97, 170, 142, 140, 32, 83, 183, 156, 196, 80, 124, 227) then
      elseif _ARG_0_ == U2(199, 209, 17, 168, 91, 181, 159, 165, 35, 77, 141, 129, 216, 88, 123, 227) then
      elseif _ARG_0_ == U2(200, 214, 7, 131, 116, 171, 147, 188, 52, 72, 166, 148, 238, 88, 115, 227, 55, 225, 95, 142, 149, 135, 228, 134, 50) then
      elseif _ARG_0_ == U2(201, 216, 4, 191, 108, 134, 147, 160, 41, 77, 179, 153, 216, 90, 124, 200, 56, 232, 98, 137, 152, 182, 232, 130, 56, 95, 167, 153) then
      elseif _ARG_0_ == U2(195, 204, 21, 175, 112, 134, 137, 167, 39, 85, 183, 178, 211, 84, 124, 249, 49, 237) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTeamEmulatorType"] = function()
    if nCurTeamEmulatorType < 0 then
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
        U2(237, 215, 25, 168, 80, 188, 155, 190, 3, 76, 167, 129, 208, 65, 125, 229, 0, 240, 112, 137)
      }))
      nCurTeamEmulatorType = 0
      if U1.DataMgr.IsEmulator() or U1.DataMgr.IsBLE() then
        nCurTeamEmulatorType = 1
        if U1.DataMgr.IsEmulator() and not U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).is_blue_simulator((U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).GetEmulatorName())) then
          nCurTeamEmulatorType = 2
        end
      end
    end
    return
  end,
  ["NeedShowEmulatorTips"] = function()
    if U1.GameStatus.IsInLobbyOrMainCity() and GetTeamNum() > 1 and teamInfo and teamInfo.members then
      goto lbl_85
      if (185).device_type and (185).device_type ~= 0 and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).IsEmulator((185).emulator_name) and (185).emulator_name and not U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).is_blue_simulator(U1.tostring((185).emulator_name)) then
      else
        ::lbl_85::
      end
    end
    if nCurTeamEmulatorType ~= 2 and 2 > nCurTeamEmulatorType then
      return true
    end
    do return false end
    return
  end,
  ["SetTeamEmulatorType"] = function()
    nCurTeamEmulatorType = 0
    if teamInfo and teamInfo.members then
      goto lbl_149
      if (185).device_type and (185).device_type ~= 0 then
        nCurTeamEmulatorType = 1
        if U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).IsEmulator((185).emulator_name) and U1.require((U2(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 240, 61, 231, 46, 128, 155, 142, 227, 128, 9, 84, 175, 136, 205, 68, 118, 232, 54))).is_blue_simulator(U1.tostring((185).emulator_name)) == false then
          nCurTeamEmulatorType = 2
      end
      else
        ::lbl_149::
      end
    end
    return
  end,
  ["IsEmulatorTeam"] = function()
    if teamInfo and teamInfo.members then
      goto lbl_21
      if (nil).device_type and (nil).device_type ~= 0 then
        return true
      end
      ::lbl_21::
    end
    do return false end
    return
  end,
  ["IsMixEmulatorTeam"] = function()
    if IsEmulatorTeam() and teamInfo and teamInfo.members then
      goto lbl_25
      if (nil).device_type and (nil).device_type == 0 then
        return true
      end
      ::lbl_25::
    end
    do return false end
    return
  end,
  ["ProcessEmulatorTips"] = function()
    if NeedShowEmulatorTips() then
      if nCurTeamEmulatorType == 2 then
      else
      end
    elseif bIsFightingBackLobby and GetTeamNum() > 1 and IsMixEmulatorTeam() then
      if nCurTeamEmulatorType == 2 then
      else
      end
    end
    bIsFightingBackLobby = false
    return
  end,
  ["one_more_battle_apply_req"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["one_more_battle_apply_rsp"] = function()
    return
  end,
  ["one_more_battle_reply_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not GetOneMoreGameInfo() then
        return
      end
      if _ARG_0_ == 1 then
        if U1.GameStatus.IsInFightingStatus() then
        end
      elseif _ARG_0_ == 2 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["one_more_battle_reply_rsp"] = function()
    ReleaseOneMoreGameInfo()
    return
  end,
  ["end_one_more_battle_req"] = function()
    if not GetOneMoreGameInfo() then
      return
    end
    return
  end,
  ["one_more_battle_info_notify"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or {}
      log(bWriteLog and table.concat({
        U1(255, 219, 9, 174, 107, 183, 167, 136, 42, 78, 181, 132, 210, 106, 102, 242, 53, 228, 95, 153, 132, 180, 170, 183, 51, 80, 175, 168, 209, 107, 103, 240, 23, 224, 99, 136, 129, 148, 180, 156),
        U1(202, 220, 47, 177, 107, 171, 159, 140, 36, 64, 166, 153, 221, 80, 77, 254, 58, 239, 111, 179, 154, 134, 254, 138, 48, 72, 238, 221, 213, 64, 99, 234, 27, 240, 116, 220, 217, 217)
      }) .. _ARG_0_ .. U1(136, 212, 3, 187, 91, 173, 131, 163, 35, 27) .. tostring(_ARG_1_))
      if _ARG_1_ == 1 then
        if not U2.oneMoreGameTeamInfo and _ARG_2_.team_omb_info then
          U2.oneMoreGameTeamInfo = _ARG_2_.team_omb_info
          if U2.oneMoreGameTeamInfo.team_leader == tonumber(DataMgr.roleData.uid) then
            if not GameStatus.IsInLobbyOrMainCity() then
              EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_INVITE_GAME_LEADER)
            end
          else
            EventSystem:postEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_INVITE_GAME, U2.oneMoreGameTeamInfo.team_leader)
          end
        end
      elseif _ARG_1_ == 5 then
        if not U2.GetOneMoreGameInfo() then
          return
        end
        if U2.GetOneMoreGameInfo().team_leader == tonumber(DataMgr.roleData.uid) then
        else
        end
      else
        U2.oneMoreGameTeamInfo = _ARG_2_.team_omb_info
        if _ARG_1_ == 2 then
          if U2.oneMoreGameTeamInfo.member_status[_ARG_2_.uid] then
            if _ARG_2_.opt == 2 and U2.oneMoreGameTeamInfo.team_leader == tonumber(DataMgr.roleData.uid) and U2.oneMoreGameTeamInfo.member_status[_ARG_2_.uid].status == 2 then
            elseif _ARG_2_.opt == 1 then
            end
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOneMoreGameInviteUI"] = function()
    log(bWriteLog and table.concat({
      U1(255, 220, 20, 171, 101, 171, 158, 142, 29, 77, 189, 138, 216, 86, 77, 227, 49, 232, 109, 179, 129, 153, 215, 195, 2, 84, 163, 144, 244, 85, 76, 226, 51, 202, 105, 143, 144, 156, 247, 221),
      U1(247, 209, 31, 171, 75, 183, 159, 158, 41, 83, 183, 170, 208, 88, 119, 222, 58, 255, 105, 152, 145, 188, 195)
    }))
    if U2.oneMoreGameTeamInfo then
    else
    end
    if U2.teamInfo.team_omb_info.team_leader == tonumber(DataMgr.roleData.uid) then
    end
    if U2.teamInfo.team_omb_info and U2.teamInfo.team_omb_info.member_status[U2.teamInfo.team_omb_info.team_leader] then
    end
    if 0 < U2.teamInfo.team_omb_info.team_unlock_time and U2.teamInfo.team_omb_info.team_unlock_time > require((U1(199, 213, 25, 185, 106, 173, 212, 176, 41, 76, 191, 130, 223, 27, 102, 254, 57, 236, 95, 153, 128, 128, 230))).GetServerTimeInSec() then
    else
    end
    return
  end,
  ["ShowUpvoteTips"] = function(_ARG_0_, _ARG_1_)
    do
      if GameStatus.GetGameStatus() == GameStatus.Lobby then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowCarList"] = function()
    if U2.teamInfo and U2.teamInfo.members then
      goto lbl_104
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
        U1(202, 216, 23, 185, 118)
      }))).GetAvatarByUid(U1(202, 216, 23, 185, 118)) and require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
        U1(202, 216, 23, 185, 118)
      }))).GetAvatarByUid(U1(202, 216, 23, 185, 118)).positionIndex and U2.InShowGroup(require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 84, 100, 246, 32, 232, 114, 194, 152, 134, 237, 138, 53, 110, 182, 152, 192, 72, 93, 230, 50, 248, 100, 157, 150, 166, 247, 146),
        U1(202, 216, 23, 185, 118)
      }))).GetAvatarByUid(U1(202, 216, 23, 185, 118)).positionIndex) and U1(202, 216, 23, 185, 118) and U1(202, 216, 23, 185, 118).vst_info.skin_id and U1(202, 216, 23, 185, 118).vst_info.skin_id > 0 then
      end
      ::lbl_104::
    end
    do return {} end
    return
  end,
  ["ShowVehicleAvatar"] = function()
    return
  end,
  ["PlaySportsCarVideo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 4, 229, 97, 149, 162, 140, 226, 138, 53, 93, 167, 171, 200, 65, 103, 232))
      if IsWoWEditor then
        return false
      end
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
        U1(203, 215, 47, 177, 101, 176, 148)
      }))).IsInXMission() then
        return false
      end
      if not _ARG_0_.vst_info or not _ARG_0_.vst_info.skin_id then
        return false
      end
      if not CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 170, 185, 178, 52, 117, 183, 140, 220, 119, 96, 248, 53, 237, 99, 141, 135, 157, 201, 140, 56, 87, 171, 154), _ARG_0_.vst_info.skin_id) then
        return false
      else
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicVehicleResDependencyUtil):IsSportsCarSkinAndTeamBroadcastDownloaded(_ARG_0_.vst_info.skin_id) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayVehicleVideo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 186, 145, 129, 227, 128, 58, 84, 177, 171, 200, 65, 103, 232, 13, 247, 118, 147))
      do return U2.PlaySportsCarVideo(_ARG_0_) or U2.PlayWingmanVideo(_ARG_0_, (U2.PlaySportsCarVideo(_ARG_0_))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayWingmanVideo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 4, 229, 97, 149, 162, 140, 226, 138, 53, 93, 167, 171, 200, 65, 103, 232))
      if IsWoWEditor then
        return false
      end
      if require((table.concat({
        U1(199, 213, 25, 185, 106, 173, 212, 160, 42, 84, 179, 195, 221, 90, 117, 254, 55, 167, 84, 148, 185, 128, 249, 144, 63, 94, 172, 211, 205, 74, 101, 238, 39, 198, 104, 145, 141, 138, 233, 154),
        U1(203, 215, 47, 177, 101, 176, 148)
      }))).IsInXMission() then
        return false
      end
      if not _ARG_0_.skin_info or not _ARG_0_.skin_info.wingman_skin then
        return false
      end
      if not require((U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 89, 125, 245, 54, 240, 46, 132, 149, 133, 230, 188, 34, 89, 167, 144, 196, 122, 119, 243, 45, 245, 99))).CanShowWingmanTeamVideo(_ARG_0_.skin_info.wingman_skin) then
        return false
      end
      if GameStatus.GetGameStatus() ~= GameStatus.Lobby then
        return false
      end
      if not UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) or not UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):IsShow() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["set_receive_nonfriend_team_request"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["get_switch_status"] = function()
    if (require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).LoadFileToTable_N(require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).ePlayerPrefsType.MentorTeamSwitch) or {}) and (require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).LoadFileToTable_N(require((table.concat({
      U1(199, 213, 25, 185, 106, 173, 212, 191, 41, 70, 187, 142, 159, 121, 125, 240, 61, 234, 80, 128, 149, 144, 239, 145, 6, 67, 167, 155, 210, 11, 114, 235, 37, 224, 117, 142, 148, 139, 255, 149),
      U1(215)
    }))).ePlayerPrefsType.MentorTeamSwitch) or {}).open == false then
      return false
    end
    do return true end
    return
  end,
  ["SetShowUIType"] = function(_ARG_0_)
    do
      ShowUiType = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowUI"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return
      end
      if not require((table.concat({
        U1(227, 216, 29, 185, 72, 172, 155, 253, 11, 78, 182, 195, 253, 90, 112, 245, 45, 167, 66, 141, 135, 140, 164, 160, 57, 92, 175, 146, 207, 11, 78, 232, 38, 251, 105, 177, 139, 157, 207, 135),
        U1(205, 213, 3)
      }))).IsModDownloaded(require((table.concat({
        U1(227, 216, 29, 185, 72, 172, 155, 253, 11, 78, 182, 195, 253, 90, 112, 245, 45, 167, 66, 141, 135, 140, 164, 160, 57, 92, 175, 146, 207, 11, 78, 232, 38, 251, 105, 177, 139, 157, 207, 135),
        U1(205, 213, 3)
      }))).Enum_Mod_Name.TeamPlatform) then
        return
      end
      if UIManager.GetUI(UIManager.UI_Config.TeamPlatform_Tab) then
      elseif _ARG_0_ == U2.E_UI_TYPE.TeamPlatformMain or _ARG_0_ == U2.E_UI_TYPE.WoWTeamPlatformMain or _ARG_0_ == U2.E_UI_TYPE.WowRecruitHallUI or _ARG_0_ == U2.E_UI_TYPE.PeakTeamPlatformMain then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckUI"] = function(_ARG_0_)
    do
      do return ShowUiType == _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_notify_teamup_sex_show"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(255, 237, 21, 189, 105, 140, 138, 157, 35, 86, 129, 148, 194, 65, 119, 250, 9, 169, 111, 130, 171, 135, 229, 151, 63, 87, 187, 162, 213, 64, 99, 234, 49, 233, 79, 143, 129, 129, 197, 128),
        U1(204, 214, 7, 230, 36)
      }) .. tostring(_ARG_0_))
      U2.bShowTeamupSex = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowSex"] = function()
    do return bShowTeamupSex end
    return
  end,
  ["IsFollowLeaderEmote"] = function(_ARG_0_)
    do
      if not teamInfo or not teamInfo.members then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 29, 250, 70, 131, 152, 133, 229, 148, 26, 84, 163, 153, 196, 87, 71, 234, 43, 237, 117, 220, 138, 150, 238, 211),
          U2(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 32, 236, 97, 129, 189, 135, 236, 140)
        }))
        return false
      end
      if not teamInfo.members[_ARG_0_] then
        return false
      end
      do return teamInfo.members[_ARG_0_].is_follow_leader end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEmoteFollowersUID"] = function()
    if not LobbySystem.CheckOpen(BP_ENUM_DANCE_FOLLOW_SWITCH) then
      return {}
    end
    if not U1.teamInfo or not U1.teamInfo.members then
      log(bWriteLog and table.concat({
        U2(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 169, 153, 134, 254, 134, 16, 94, 174, 145, 206, 82, 103, 245, 55, 204, 89, 184, 196, 151, 245, 135),
        U2(132, 237, 21, 189, 105, 140, 138, 157, 35, 86, 129, 148, 194, 65, 119, 250, 122, 253, 101, 141, 153, 160, 228, 133, 57)
      }))
      return {}
    end
    goto lbl_118
    ::lbl_118::
    do return {} end
    return
  end,
  ["UpdateEmoteFollowerState"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 183, 1, 249, 100, 141, 128, 140, 207, 142, 57, 69, 167, 187, 206, 73, 110, 232, 51, 252, 98, 175, 144, 152, 238, 150),
        U1(132, 204, 25, 184, 62)
      }) .. tostring(_ARG_0_) .. U1(132, 208, 3, 131, 98, 182, 150, 191, 41, 86, 141, 129, 212, 84, 118, 242, 38, 179) .. tostring(_ARG_1_))
      if not U2.teamInfo or not U2.teamInfo.members then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 1, 249, 100, 141, 128, 140, 207, 142, 57, 69, 167, 187, 206, 73, 110, 232, 51, 252, 98, 175, 144, 152, 238, 150),
          U1(132, 215, 31, 168, 36, 141, 159, 178, 43, 116, 162, 163, 212, 66, 65, 238, 39, 253, 101, 129, 218, 157, 239, 130, 59, 120, 172, 155, 206)
        }))
        return
      end
      if not U2.teamInfo.members[_ARG_0_] then
        return
      end
      U2.teamInfo.members[_ARG_0_].is_follow_leader = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateEmoteShowEffect"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 183, 1, 249, 100, 141, 128, 140, 207, 142, 57, 69, 167, 174, 201, 74, 117, 194, 34, 255, 117, 159, 144, 217, 239, 154),
        U1(192, 131)
      }) .. tostring(_ARG_0_) .. U1(132, 208, 3, 147, 116, 188, 148, 233) .. tostring(_ARG_1_))
      if not U2.teamInfo or not U2.teamInfo.members then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 1, 249, 100, 141, 128, 140, 207, 142, 57, 69, 167, 174, 201, 74, 117, 194, 34, 255, 117, 159, 144, 217, 244, 156),
          U1(208, 153, 36, 185, 101, 180, 175, 163, 8, 68, 165, 190, 200, 70, 102, 242, 57, 167, 116, 137, 149, 132, 195, 141, 48, 94)
        }))
        return
      end
      if not U2.teamInfo.members[_ARG_0_] or not U2.teamInfo.members[_ARG_0_].motion_effect_info then
        return
      end
      U2.teamInfo.members[_ARG_0_].motion_effect_info.show_effect = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateEmoteLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 183, 1, 249, 100, 141, 128, 140, 207, 142, 57, 69, 167, 177, 196, 83, 103, 235, 100, 236, 121, 152, 222) .. tostring(_ARG_0_) .. U1(132, 252, 29, 179, 112, 188, 179, 151, 124) .. tostring(_ARG_1_) .. U1(232, 220, 6, 185, 104) .. tostring(_ARG_2_))
      if not U2.teamInfo or not U2.teamInfo.members then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 1, 249, 100, 141, 128, 140, 207, 142, 57, 69, 167, 177, 196, 83, 103, 235, 100, 247, 127, 136, 196, 173, 255, 146),
          U1(201, 236, 0, 146, 97, 174, 169, 170, 53, 85, 183, 128, 159, 65, 119, 246, 57, 192, 110, 138, 155)
        }))
        return
      end
      if not U2.teamInfo.members[_ARG_0_] or not U2.teamInfo.members[_ARG_0_].motion_effect_info then
        return
      end
      if not U2.teamInfo.members[_ARG_0_].motion_effect_info.motion_effect_level then
        U2.teamInfo.members[_ARG_0_].motion_effect_info.motion_effect_level = {}
      end
      U2.teamInfo.members[_ARG_0_].motion_effect_info.motion_effect_level[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFollowPlayEmoteID"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 170, 155, 133, 230, 140, 33, 97, 174, 156, 216, 96, 111, 232, 48, 252, 89, 184, 196, 172, 211, 183),
        U1(132)
      }) .. tostring(_ARG_0_) .. U1(132, 252, 29, 179, 112, 188, 179, 151, 102) .. tostring(_ARG_1_))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):IsParticleEmote((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_))) then
        return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_))
      end
      if not U2.GetMemberInfo(_ARG_0_) or not U2.GetMemberInfo(_ARG_0_).motion_effect_info then
        return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_))
      end
      if not U2.GetMemberInfo(_ARG_0_).motion_effect_info.motion_effect_level or not U2.GetMemberInfo(_ARG_0_).motion_effect_info.motion_effect_level[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_)] then
        return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_))
      end
      if U2.GetMemberInfo(_ARG_0_).motion_effect_info.show_effect == true and U2.GetMemberInfo(_ARG_0_).motion_effect_info.motion_effect_level[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_)] > 0 then
        return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetParticleEmoteID((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_))))
      end
      do return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicParticleEmote):GetBaseID(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckEmoteCanFollow"] = function(_ARG_0_)
    do
      if CDataTable.GetTableData(U1(232, 214, 18, 190, 125, 159, 149, 191, 42, 78, 165, 168, 220, 90, 102, 242, 23, 239, 103), _ARG_0_) and CDataTable.GetTableData(U1(232, 214, 18, 190, 125, 159, 149, 191, 42, 78, 165, 168, 220, 90, 102, 242, 23, 239, 103), _ARG_0_).CanPlay == 0 then
        return false
      end
      if require((table.concat({
        U1(227, 216, 29, 185, 72, 172, 155, 253, 11, 78, 182, 195, 253, 92, 112, 229, 53, 251, 121, 194, 179, 136, 231, 134, 6, 93, 163, 132, 143, 100, 116, 230, 48, 248, 98, 210, 161, 148, 245, 135),
        U1(193, 151, 28, 179, 99, 176, 153, 140, 35, 76, 189, 153, 212)
      }))).IsMileStoneEmote(_ARG_0_) then
        return false
      end
      if require((table.concat({
        U1(227, 216, 29, 185, 72, 172, 155, 253, 11, 78, 182, 195, 253, 92, 112, 229, 53, 251, 121, 194, 179, 136, 231, 134, 6, 93, 163, 132, 143, 100, 116, 230, 48, 248, 98, 210, 161, 148, 245, 135),
        U1(193, 151, 28, 179, 99, 176, 153, 140, 35, 76, 189, 153, 212)
      }))).IsCustomWeaponShow(_ARG_0_) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMemberPetInfo"] = function(_ARG_0_)
    do
      do return GetMemberInfo(_ARG_0_) and GetMemberInfo(_ARG_0_).pet_info or {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMemberPetInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetMemberInfo(_ARG_0_) then
        return
      end
      GetMemberInfo(_ARG_0_).pet_info = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGarageCarInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 171, 149, 155, 235, 132, 51, 114, 163, 143, 232, 75, 100, 232, 100, 247, 127, 136, 196, 140, 243, 151),
          U1(132)
        }) .. tostring(_ARG_0_))
        return nil
      end
      if not U2.teamInfo or not U2.teamInfo.members then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 171, 149, 155, 235, 132, 51, 114, 163, 143, 232, 75, 100, 232, 100, 247, 127, 136, 196, 141, 255, 146),
          U1(201, 240, 30, 186, 107)
        }))
        return nil
      end
      if not U2.teamInfo.members[tonumber(_ARG_0_)] then
        return nil
      end
      do return U2.teamInfo.members[tonumber(_ARG_0_)].car_page_info end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGarageRefitList"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetGarageCarInfo(_ARG_0_) or not GetGarageCarInfo(_ARG_0_)[_ARG_1_] then
        return
      end
      do return GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data and GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data.car_data end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGarageVehicleShowTireConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetGarageCarInfo(_ARG_0_) or not GetGarageCarInfo(_ARG_0_)[_ARG_1_] then
        return
      end
      do return GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data and GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data.show_tire_feature end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamShowTireConfig"] = function(_ARG_0_)
    do
      if not teamInfo then
        return false
      end
      goto lbl_27
      if U1.tonumber(nil) == U1.tonumber(_ARG_0_) and nil and (nil).vst_info then
        return (nil).vst_info.show_tire_feature
      end
      ::lbl_27::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamShowVehicleAccessoryList"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 81, 159, 135, 156, 233, 128),
          U1(203, 203, 9, 144, 109, 170, 142, 243, 54, 64, 160, 140, 220, 21, 123, 228, 116, 231, 105, 128)
        }))
        return nil
      end
      if not U2.teamInfo then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 81, 159, 135, 156, 233, 128),
          U1(203, 203, 9, 144, 109, 170, 142, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230)
        }))
        return nil
      end
      goto lbl_252
      if tonumber((U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 81, 159, 135, 156, 233, 128))) == tonumber(_ARG_0_) then
        if U1(203, 203, 9, 144, 109, 170, 142, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230) and U1(203, 203, 9, 144, 109, 170, 142, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info and U1(203, 203, 9, 144, 109, 170, 142, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.car_install_acc then
          return U1(203, 203, 9, 144, 109, 170, 142, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.car_install_acc
        end
      else
        ::lbl_252::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 81, 159, 135, 156, 233, 128),
        U1(203, 203, 9, 144, 109, 170, 142, 243, 40, 72, 190)
      }))
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGarageVehicleAccessoryList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 171, 149, 155, 235, 132, 51, 103, 167, 149, 200, 70, 110, 226, 5, 250, 115, 153, 151, 138, 245, 129),
          U1(221, 245, 25, 175, 112, 249, 138, 178, 52, 64, 191, 205, 216, 70, 50, 249, 61, 229)
        }))
        return nil
      end
      if not U2.GetGarageCarInfo(_ARG_0_) or not U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_] then
        return nil
      end
      if not (U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data and U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data.car_install_acc) then
        return nil
      end
      do return U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data and U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data.car_install_acc end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamShowVehicleChassisLight"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 83, 148, 133, 138, 233, 154),
          U1(215, 245, 25, 187, 108, 173, 218, 163, 39, 83, 179, 128, 145, 92, 97, 183, 58, 224, 108)
        }))
        return nil
      end
      if not U2.teamInfo then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 83, 148, 133, 138, 233, 154),
          U1(215, 245, 25, 187, 108, 173, 218, 167, 35, 64, 191, 164, 223, 83, 125, 183, 61, 250, 32, 130, 157, 133)
        }))
        return nil
      end
      goto lbl_249
      if tonumber((U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 83, 148, 133, 138, 233, 154))) == tonumber(_ARG_0_) then
        if U1(215, 245, 25, 187, 108, 173, 218, 167, 35, 64, 191, 164, 223, 83, 125, 183, 61, 250, 32, 130, 157, 133) and U1(215, 245, 25, 187, 108, 173, 218, 167, 35, 64, 191, 164, 223, 83, 125, 183, 61, 250, 32, 130, 157, 133).vst_info and U1(215, 245, 25, 187, 108, 173, 218, 167, 35, 64, 191, 164, 223, 83, 125, 183, 61, 250, 32, 130, 157, 133).vst_info.chassis_light then
          return U1(215, 245, 25, 187, 108, 173, 218, 167, 35, 64, 191, 164, 223, 83, 125, 183, 61, 250, 32, 130, 157, 133).vst_info.chassis_light
        end
      else
        ::lbl_249::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      log(bWriteLog and table.concat({
        U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 184, 145, 136, 231, 176, 62, 94, 181, 171, 196, 77, 107, 228, 40, 252, 83, 148, 133, 138, 233, 154),
        U1(215, 245, 25, 187, 108, 173, 218, 189, 47, 77)
      }))
      do return nil end
      return
    end
  end,
  ["GetGarageVehicleChassisLight"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(240, 220, 17, 177, 81, 169, 180, 182, 49, 114, 171, 158, 197, 80, 127, 185, 19, 236, 116, 171, 149, 155, 235, 132, 51, 103, 167, 149, 200, 70, 110, 226, 7, 241, 113, 143, 151, 144, 233, 191),
          U1(205, 222, 24, 168, 36, 169, 155, 161, 39, 76, 242, 132, 194, 21, 124, 254, 56)
        }))
        return nil
      end
      if not U2.GetGarageCarInfo(_ARG_0_) or not U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_] then
        return nil
      end
      if not (U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data and U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data.chassis_light) then
        return nil
      end
      do return U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data and U2.GetGarageCarInfo(_ARG_0_)[_ARG_1_].ext_data.chassis_light end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateGarageCarInfo"] = function(_ARG_0_, _ARG_1_)
    do
      teamInfo = teamInfo or {}
      teamInfo.members = teamInfo.members or {}
      teamInfo.members[_ARG_0_] = teamInfo.members[_ARG_0_] or {}
      teamInfo.members[_ARG_0_].car_page_info = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMileStoneData"] = function(_ARG_0_)
    do
      if not GetMemberInfo(_ARG_0_) then
        return
      end
      do return GetMemberInfo(_ARG_0_).set_milestone_data end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTempMatchTeamData"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGarageVehicleMultiSlotData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_2_ and _ARG_0_) or not _ARG_1_ then
        return {
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.sunroof,
          [177] = tonumber(107)
        }
      end
      if not U2.GetGarageCarInfo(_ARG_0_) or not U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_] then
        return {
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.sunroof,
          [177] = tonumber(107)
        }
      end
      if not U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data then
        return {
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.sunroof,
          [177] = tonumber(107)
        }
      end
      if U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.brake_caliper then
      end
      if U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.wheel_hub then
      end
      if U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.sunroof then
      end
      if CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 154, 155, 161, 2, 68, 180, 140, 196, 89, 102, 196, 49, 253), _ARG_1_) and CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 154, 155, 161, 2, 68, 180, 140, 196, 89, 102, 196, 49, 253), _ARG_1_).SetIDList and CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 154, 155, 161, 2, 68, 180, 140, 196, 89, 102, 196, 49, 253), _ARG_1_).SetIDList ~= U1() then
        goto lbl_355
        if tonumber(107) and tonumber(107) > 0 and not ({
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.sunroof,
          [177] = tonumber(107)
        })[177] then
        end
        ::lbl_355::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {
        [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.brake_caliper,
        [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.wheel_hub,
        [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U2.GetGarageCarInfo(_ARG_0_)[_ARG_2_].ext_data.sunroof,
        [177] = tonumber(107)
      } end
      do return end
      _ARG_0_ = _ENV[253]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTeamShowVehicleMultiSlotData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or not _ARG_1_ then
        return {
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.sunroof,
          [177] = tonumber(107)
        }
      end
      if not U2.teamInfo then
        return {
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.sunroof,
          [177] = tonumber(107)
        }
      end
      goto lbl_181
      if tonumber(U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230)) == tonumber(_ARG_0_) then
        if U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230) and U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info then
        end
      else
        ::lbl_181::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info then
        return {
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.sunroof,
          [177] = tonumber(107)
        }
      end
      if U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.brake_caliper then
      end
      if U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.wheel_hub then
      end
      if U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.sunroof then
      end
      if CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 154, 155, 161, 2, 68, 180, 140, 196, 89, 102, 196, 49, 253), _ARG_1_) and CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 154, 155, 161, 2, 68, 180, 140, 196, 89, 102, 196, 49, 253), _ARG_1_).SetIDList and CDataTable.GetTableData(U1(247, 201, 31, 174, 112, 154, 155, 161, 2, 68, 180, 140, 196, 89, 102, 196, 49, 253), _ARG_1_).SetIDList ~= U1() then
        goto lbl_376
        if tonumber(107) and tonumber(107) > 0 and not ({
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.brake_caliper,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.wheel_hub,
          [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.sunroof,
          [177] = tonumber(107)
        })[177] then
        end
        ::lbl_376::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {
        [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).BrakeCaliper] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.brake_caliper,
        [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).WheelHub] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.wheel_hub,
        [import((U1(225, 239, 21, 180, 109, 186, 150, 182, 22, 64, 160, 153, 226, 89, 125, 227))).Canopy] = U1(200, 214, 4, 152, 101, 173, 155, 243, 50, 68, 179, 128, 248, 91, 116, 248, 116, 224, 115, 204, 154, 128, 230).vst_info.sunroof,
        [177] = tonumber(107)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
