local season_new_jump_module = {}
local gamelet_define = require("client.slua.logic.gamelet.gamelet_define")
local GameletApp = gamelet_define.GameletApp

function season_new_jump_module:JumpCheck(ctorData, _)
  local logic_season_const = require("client.logic.season.logic_season_const")
  if ctorData and ctorData.ESeasonType and ctorData.ESeasonType == logic_season_const.ESeasonType.PeakGame then
    local LogicPeakGameUtil = require("client.logic.PeakGame.LogicPeakGameUtil")
    if not LogicPeakGameUtil.IsOpen() then
      log(bWriteLog and "season_new_jump_module:JumpCheck is LogicPeakGameUtil.IsOpen() = false")
      return false
    end
  end
  local level_unlock_manager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager)
  local unlockGuideConfigMap = level_unlock_manager:GetSystemList()
  local currentLevel = DataMgr.roleData.level
  local unlockGuideConfig = unlockGuideConfigMap[level_unlock_manager.featureDef.season]
  if unlockGuideConfig then
    local level_unlock_ui_util = require("client.logic.level_unlock.util.level_unlock_ui_util")
    local config = level_unlock_ui_util:GetGuideStepConfig(unlockGuideConfig, 1)
    local level_unlock_config = require("client.logic.level_unlock.config.level_unlock_config")
    local ELockType = level_unlock_config.ELockType
    if config and config.EntranceDisplayType == ELockType.hide then
      local requireLevel = unlockGuideConfig.unlockLevel
      if requireLevel and currentLevel < requireLevel then
        log(bWriteLog and "season_new_jump_module:JumpCheck is not open")
        ShowNotice(LocUtil.LocalizeResFormat(31028, requireLevel))
        return false
      end
    end
  end
  return true
end

function season_new_jump_module:ShowModule(ctorData)
  log(bWriteLog and "season_new_jump_module:ShowModule")
  log_tree("season_new_jump_module:ShowModule:ctorData", ctorData)
  local logic_season_const = require("client.logic.season.logic_season_const")
  local DefaultSeasonType = logic_season_const.ESeasonType.Classic
  if ctorData then
    if not ctorData.ESeasonType then
      ctorData.ESeasonType = DefaultSeasonType
    end
  else
    ctorData = {}
    ctorData.ESeasonType = DefaultSeasonType
  end
  log(bWriteLog and "season_new_jump_module:ShowModule:ESeasonType")
  local logic_season_util = require("client.logic.season.logic_season_util")
  if logic_season_util.IsModReady() then
    UIManager.ShowUI(UIManager.UI_Config.Lobby_SeasonUI_Homepage_New01_Sidebar_UIBP, tonumber(ctorData.ESeasonType))
  end
end

local class = require("class")
local CModuleBase = require("client.module_framework.JumpModuleBase")
local Cseason_new_jump_module = class(CModuleBase, nil, season_new_jump_module)
return Cseason_new_jump_module
