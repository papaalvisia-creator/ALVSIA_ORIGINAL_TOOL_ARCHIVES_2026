do return {
  bInit = false,
  sdkInstance = nil,
  flowEndCallback = nil,
  flowEndForbiddenCallback = nil,
  sdkErrorCallback = nil,
  luaSdkCallBackDel = {},
  sCountry = nil,
  nYear = nil,
  nMonth = nil,
  certState = nil,
  bForceCert = true,
  bQueryUserStatus = false,
  lastSendEmailUrl = nil,
  lastSendParentName = nil,
  bReverifyCleared = false,
  bLegacyFlowCleared = false,
  bPendingBrazilMinorCheck = false,
  bBrazilMinorCheckDone = false,
  bLoginToLobby = false,
  bRegionReady = false,
  ["Enum_Minor_Cert_Status"] = {
    Init = 0,
    Process = 1,
    Finish = 2
  },
  ["EndFlowState"] = {ForbiddenEnterGame = -1, NextStep = 1},
  ["AUTH_FLOW_EVENT_STEP"] = {
    COUNTRY_PAGE_SHOW = 1,
    COUNTRY_SUBMITTED = 2,
    AGE_SUBMITTED = 3,
    BRANCH_DECIDED = 4,
    CPF_EMAIL_SENT = 5,
    PARENT_EMAIL_SENT = 6,
    PARENT_CONSENT_SUBMITTED = 7,
    THIRD_PARTY_AUTH_START = 8,
    AUTH_SKIPPED = 9,
    PARENT_UNAUTHORIZED = 10,
    REGISTER_COMPLIANCE_COMPLETE = 11
  },
  ["AUTH_FLOW_AGE_CONFIRM_METHOD"] = {
    AGE_SLIDER = 1,
    BIRTH_YEAR = 2,
    SELF_CONFIRM = 3
  },
  ["AUTH_FLOW_AGE_GROUP_RESULT"] = {ADULT = 1, MINOR = 2},
  ["AUTH_FLOW_AUTH_BRANCH"] = {
    NORMAL_ADULT = 1,
    ADULT_CPF = 2,
    MINOR_CPF = 3,
    CREDIT_CARD = 4,
    PARENT_EMAIL = 5,
    SELF_AUTH = 6
  },
  ["AUTH_FLOW_REGISTER_COMPLIANCE_TYPE"] = {
    SDK_SUCCESS_CALLBACK = 1,
    AUTH_SKIPPED = 2,
    NO_NEED_COMPLY = 3
  },
  ["CheckBrazilMinorBlock"] = function()
    if not IsIpRegionBrazil() then
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 177, 79, 199, 34, 184, 223, 229, 142, 239, 230, 76, 246, 38, 97, 10, 40, 160, 91, 221, 50, 168, 173, 233),
        U2(213, 182, 119, 240, 195, 130, 151, 206, 147, 165, 246, 64)
      }))
      return
    end
    if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_familycenter):IsInGrayScale() then
      return
    end
    if bBrazilMinorCheckDone then
      return
    end
    if flowEndCallback then
      return
    end
    if not IsEntryOpen() then
      return
    end
    if not bInit then
      if not bPendingBrazilMinorCheck then
        bPendingBrazilMinorCheck = true
      end
      return
    end
    bPendingBrazilMinorCheck = false
    bBrazilMinorCheckDone = true
    return
  end,
  ["OnModePostSwitch"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 189, 73, 239, 46, 183, 248, 199, 128, 230, 251, 115, 204, 38, 123, 6, 50))
      if _ARG_2_.pre ~= GameStatus.Login or _ARG_2_.current ~= GameStatus.Lobby then
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 189, 73, 239, 46, 183, 248, 199, 128, 230, 251, 115, 204, 38, 123, 6, 50, 194, 89, 221, 37, 227, 193, 232),
          U1(221, 171, 57, 191, 143, 175, 130, 197, 157, 252, 179, 16, 216, 52, 118, 5)
        }))
        return
      end
      U2.bLoginToLobby = true
      if U2.bRegionReady then
        U2.CheckBrazilMinorBlock()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSetRegionOK"] = function()
    log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 189, 73, 241, 36, 167, 207, 242, 136, 252, 224, 78, 244, 4))
    U2.bRegionReady = true
    if U2.bLoginToLobby then
      U2.CheckBrazilMinorBlock()
    end
    return
  end,
  ["ShowBrazilMinorBlockPopup"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 161, 79, 205, 54, 145, 239, 246, 149, 252, 227, 109, 210, 33, 96, 23, 24, 142, 88, 209, 58, 147, 226, 247),
        U1(207, 178)
      }))
      U2.ReportBrazilCompliance(U3.MinorBlockPopup, U2.GetBrazilReportUserType(), U4.Minor, DataMgr.RegionData.region, tostring(_ARG_0_ or U1()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogout"] = function()
    log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 157, 73, 238, 46, 180, 242, 226, 155))
    U2.bInit = false
    U2.sCountry = nil
    U2.nYear = nil
    U2.nMonth = nil
    U2.certState = nil
    U2.bForceCert = true
    U2.bQueryUserStatus = false
    U2.lastSendEmailUrl = nil
    U2.lastSendParentName = nil
    U2.bReverifyCleared = false
    U2.bLegacyFlowCleared = false
    U2.bPendingBrazilMinorCheck = false
    U2.bBrazilMinorCheckDone = false
    U2.bLoginToLobby = false
    U2.bRegionReady = false
    DataMgr.minor_cert_status = nil
    return
  end,
  ["SetLuaSdkCallBackDel"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(154, 174, 56, 245, 216, 128, 178, 196, 144, 232, 239, 92, 194, 62, 113, 22, 47, 220, 116, 199, 53, 159, 232, 246, 188, 241, 228, 99, 218, 35, 99, 39, 59, 129, 92, 246, 52, 175, 173, 234),
        U1(223, 182, 63, 253, 213, 170, 137, 135, 194, 165)
      }) .. tostring(_ARG_0_) .. U1(154, 161, 54, 254, 221, 129, 140, 196, 148, 165, 162, 16) .. tostring(_ARG_1_))
      if not _ARG_1_ then
        return
      end
      if not U2.luaSdkCallBackDel[_ARG_0_] then
        U2.luaSdkCallBackDel[_ARG_0_] = {}
      end
      table.insert(U2.luaSdkCallBackDel[_ARG_0_], _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LazyInitSdk"] = function()
    log(bWriteLog and table.concat({
      U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 190, 70, 216, 56, 154, 243, 254, 155, 198, 235, 75, 155, 35, 96, 2, 51, 129, 104, 209, 62, 174, 253, 235),
      U1(211, 163, 57, 241, 212, 205, 143, 238, 145, 236, 235, 16, 150, 127)
    }) .. tostring(U2.bInit))
    if U2.bInit == false then
      U2.sdkInstance = import((U1(243, 172, 35, 254, 226, 167, 166, 228, 144, 232, 239, 92, 194, 62, 113, 22, 47, 186, 66, 206, 49, 182, 239))).GetInstance(), import((U1(243, 172, 35, 254, 226, 167, 166, 228, 144, 232, 239, 92, 194, 62, 113, 22, 47, 186, 66, 206, 49, 182, 239))).GetInstance():SetLogConfig(true, false, 1)
      U2.bInit = true
    end
    return
  end,
  ["OnCppSDKCallback"] = function(_ARG_0_)
    do
      printf(table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 189, 73, 225, 49, 163, 206, 211, 164, 214, 238, 76, 215, 45, 110, 6, 49, 194, 68, 198, 35, 145, 232, 244),
        U1(207, 174, 35, 168, 148, 144, 193, 135)
      }), _ARG_0_)
      if U2.luaSdkCallBackDel[json.decode(_ARG_0_).methodId] and #U2.luaSdkCallBackDel[json.decode(_ARG_0_).methodId] > 0 then
        if #U2.luaSdkCallBackDel[json.decode(_ARG_0_).methodId] == 0 then
          U2.luaSdkCallBackDel[json.decode(_ARG_0_).methodId] = nil
        end
        if table.remove(U2.luaSdkCallBackDel[json.decode(_ARG_0_).methodId], 1) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKSetUserProfile"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(154, 174, 56, 245, 216, 128, 178, 196, 144, 232, 239, 92, 194, 62, 113, 22, 47, 220, 116, 230, 10, 128, 248, 227, 186, 230, 234, 82, 235, 61, 96, 3, 51, 142, 82, 146, 34, 145, 232, 224),
        U1(211, 173, 57, 168, 148, 144)
      }), _ARG_0_))
      if _ARG_0_ ~= nil and U2.IsEntryOpen() then
        U2.sdkInstance:SetUserProfile(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKQueryUserStatus"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 16, 166, 248, 229, 150, 192, 252, 69, 201, 28, 123, 4, 46, 151, 68))
      U2.bQueryUserStatus = true
      if _ARG_0_ then
      end
      if not U2.sdkInstance then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKCommitBirthday"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 2, 188, 240, 250, 134, 225, 205, 73, 201, 59, 103, 1, 59, 155, 23, 193, 19, 170, 255, 243),
        U1(210, 166, 54, 235, 145, 222, 205)
      }) .. tostring(_ARG_0_))
      U2.SetLuaSdkCallBackDel(U3.INTL_COMPLIANCE_COMMIT_BIRTHDAY, _ARG_1_)
      U2.sdkInstance:CommitBirthday(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKSendEmail"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 18, 182, 243, 243, 170, 248, 238, 73, 215, 111, 106, 8, 59, 139, 91, 231, 35, 175, 183, 167),
        U1(159, 177, 123, 178, 196, 144, 136, 213, 177, 228, 242, 85, 145, 127, 58, 6, 102, 210, 116, 193, 36, 189, 248, 173, 207, 176, 252)
      }), _ARG_0_, _ARG_1_, _ARG_2_))
      U2.SetLuaSdkCallBackDel(U3.INTL_COMPLIANCE_SEND_EMAIL, _ARG_3_)
      U2.sdkInstance:SendEmail(_ARG_0_, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKSetParentStatus"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 18, 182, 233, 199, 142, 231, 234, 78, 207, 28, 123, 4, 46, 151, 68, 146, 63, 144, 249, 230),
        U1(206, 183, 36, 178, 140, 195)
      }) .. tostring(_ARG_0_))
      U2.SetLuaSdkCallBackDel(U3.INTL_COMPLIANCE_SET_PARENT_CERTIFICATE_STATUS, _ARG_1_)
      U2.sdkInstance:SetParentStatus(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKChangeRegion"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 2, 187, 252, 249, 136, 240, 221, 69, 220, 38, 96, 11, 122, 145, 101, 215, 54, 170, 226, 233),
        U1(154, 255, 119)
      }) .. tostring(_ARG_0_))
      if not U2.IsEntryOpen() then
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 2, 187, 252, 249, 136, 240, 221, 69, 220, 38, 96, 11, 122, 145, 83, 217, 24, 173, 254, 243),
          U1(219, 172, 52, 247, 145, 138, 158, 135, 145, 236, 243)
        }))
        return
      end
      U2.SetLuaSdkCallBackDel(U3.INTL_COMPLIANCE_CHANGE_REGION, _ARG_1_)
      U2.sdkInstance:ChangeRegion(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKOpenAgeGate"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == nil or _ARG_1_ == U2() then
        _ARG_1_ = U1.json.encode({
          lang_type = _ENV(),
          package_name = U1.import((U2(241, 171, 36, 255, 212, 151, 190, 222, 140, 241, 250, 93, 231, 54, 125, 7, 43, 128, 94))).GetGameBundleId()
        })
      elseif U1.type((U1.json.decode(_ARG_1_))) == U2(206, 163, 53, 254, 212) then
        U1.json.decode(_ARG_1_).package_name, U1.json.decode(_ARG_1_).lang_type = U1.import((U2(241, 171, 36, 255, 212, 151, 190, 222, 140, 241, 250, 93, 231, 54, 125, 7, 43, 128, 94))).GetGameBundleId(), _ENV()
        _ARG_1_ = U1.json.encode((U1.json.decode(_ARG_1_)))
      else
        _ARG_1_ = U1.json.encode({
          lang_type = _ENV(),
          package_name = U1.import((U2(241, 171, 36, 255, 212, 151, 190, 222, 140, 241, 250, 93, 231, 54, 125, 7, 43, 128, 94))).GetGameBundleId()
        })
      end
      if not U3.IsEntryOpen() then
        return
      end
      if not U3.sdkInstance then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SDKClearUserStatus"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 2, 191, 248, 246, 157, 192, 252, 69, 201, 28, 123, 4, 46, 151, 68))
      if not U2.IsEntryOpen() then
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 161, 99, 233, 2, 191, 248, 246, 157, 192, 252, 69, 201, 28, 123, 4, 46, 151, 68, 146, 52, 173, 249, 245),
          U1(195, 226, 52, 254, 222, 144, 136, 195)
        }))
        return
      end
      U2.SetLuaSdkCallBackDel(U3.INTL_COMPLIANCE_CLEAR_USER_STATUS, _ARG_0_)
      if not U2.sdkInstance then
        return
      end
      U2.sdkInstance:ClearUserStatus()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSwitchOpen"] = function()
    do return LobbySystem.CheckOpen(20217) end
    return
  end,
  ["IsEntryOpen"] = function()
    if _ENV() then
    end
    do return (_ENV()) end
    return
  end,
  ["CanUseAgeGate"] = function()
    log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 177, 70, 204, 20, 160, 248, 214, 136, 240, 200, 65, 207, 42))
    if not U2.IsEntryOpen() then
      return false
    end
    if DataMgr.minor_cert_status == U2.Enum_Minor_Cert_Status.Finish then
      return false
    end
    if DataMgr.roleData.eugdpr and DataMgr.roleData.eugdpr.user_type ~= 0 then
      if require((U1(217, 174, 62, 247, 223, 151, 195, 212, 147, 240, 254, 30, 199, 48, 120, 28, 41, 220, 64, 198, 49, 161, 179, 251, 128, 242, 230, 67, 228, 40, 107, 21, 40))).IsEUGDPRUser(DataMgr.roleData.eugdpr.user_type) then
        if LobbySystem.CheckOpen(80043) and require((U1(217, 174, 62, 247, 223, 151, 195, 212, 147, 240, 254, 30, 199, 48, 120, 28, 41, 220, 64, 198, 49, 161, 179, 244, 128, 248, 255, 76, 210, 46, 97, 6, 63, 189, 66, 198, 56, 175))).CheckDGPRAgegateVersionMatch() then
          return true
        end
        return false
      end
    end
    do return true end
    return
  end,
  ["IsInRegistrationFlow"] = function()
    if (LobbySystem and LobbySystem.roleData and (LobbySystem and LobbySystem.roleData).is_first_login) ~= nil then
      return (LobbySystem and LobbySystem.NewbieRoleState) ~= nil and ((LobbySystem and LobbySystem.roleData and (LobbySystem and LobbySystem.roleData).is_first_login) == (LobbySystem and LobbySystem.NewbieRoleState).Init or (LobbySystem and LobbySystem.roleData and (LobbySystem and LobbySystem.roleData).is_first_login) == (LobbySystem and LobbySystem.NewbieRoleState).UpdateRole), {
        branch = U1(211, 177, 8, 244, 216, 145, 158, 211, 160, 233, 240, 87, 194, 49),
        rawIsFirstLogin = LobbySystem and LobbySystem.roleData and (LobbySystem and LobbySystem.roleData).is_first_login
      }
    end
    do return LobbySystem ~= nil and LobbySystem.isNewPlayer == true or require((table.concat({
      U1(217, 174, 62, 247, 223, 151, 195, 212, 147, 240, 254, 30, 199, 48, 120, 28, 41, 220, 68, 208, 36, 178, 233, 242, 189, 250, 227, 69, 149, 35, 96, 2, 51, 129, 104, 209, 35, 166, 236, 243),
      U1(223, 144, 56, 254, 212)
    }))).IsInCreateRolePhase() == true, {
      branch = U1(220, 163, 59, 254, 211, 130, 142, 204),
      isNewPlayer = LobbySystem ~= nil and LobbySystem.isNewPlayer == true,
      inCreateRolePhase = require((table.concat({
        U1(217, 174, 62, 247, 223, 151, 195, 212, 147, 240, 254, 30, 199, 48, 120, 28, 41, 220, 68, 208, 36, 178, 233, 242, 189, 250, 227, 69, 149, 35, 96, 2, 51, 129, 104, 209, 35, 166, 236, 243),
        U1(223, 144, 56, 254, 212)
      }))).IsInCreateRolePhase() == true,
      rawIsFirstLogin = LobbySystem and LobbySystem.roleData and (LobbySystem and LobbySystem.roleData).is_first_login
    } end
    return
  end,
  ["RefreshInRegistrationFlow"] = function(_ARG_0_)
    do
      bInRegistrationFlow = IsInRegistrationFlow()
      do return IsInRegistrationFlow() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BeginFlow"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(154, 174, 56, 245, 216, 128, 178, 196, 144, 232, 239, 92, 194, 62, 113, 22, 47, 220, 101, 199, 38, 186, 243, 209, 131, 250, 248, 12, 155, 60, 123, 4, 46, 151, 68, 136, 113) .. tostring(DataMgr.minor_cert_status))
      U2.flowEndCallback = _ARG_0_
      U2.flowEndForbiddenCallback = _ARG_1_
      U2.RefreshInRegistrationFlow((U1(248, 167, 48, 251, 223, 165, 129, 200, 136)))
      if U2.bInRegistrationFlow and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter):IsRegisterLegacySDK() then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter):IsInGrayScale() and U2.IsEntryOpen() and U2.sdkInstance ~= nil and not U2.bLegacyFlowCleared then
          U2.bLegacyFlowCleared = true
          return
        end
      elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter):IsInGrayScale() then
        return
      end
      if not DataMgr.minor_cert_status or DataMgr.minor_cert_status == U2.Enum_Minor_Cert_Status.Init then
      elseif DataMgr.minor_cert_status == U2.Enum_Minor_Cert_Status.Process then
      elseif DataMgr.minor_cert_status == U2.Enum_Minor_Cert_Status.Finish then
        if U2.IsEntryOpen() then
          return
        end
        if _ARG_0_ then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowSelectArea"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 128, 248, 251, 138, 246, 251, 97, 201, 42, 110, 69, 63, 151, 104, 213, 53, 179, 255, 216),
        U1(208, 178, 54, 245, 212)
      }))
      UIManager.ShowUI(UIManager.UI_Config.eu_gdpr_jpage, 0, nil, nil, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowNoCertificationRequired"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 157, 242, 212, 138, 231, 251, 73, 221, 38, 108, 4, 46, 139, 88, 220, 3, 166, 252, 242),
        U1(211, 176, 50, 246)
      }))
      U2.SDKSetParentStatus(1, function(_ARG_0_)
        do
          FlowHasCertificate(U1, U2.NO_NEED_COMPLY)
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowNeedCertificate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 157, 248, 242, 139, 214, 234, 82, 207, 38, 105, 12, 57, 131, 67, 215))
      if _ARG_0_.parentCertificateStatus == -1 then
        U2.FlowParentDenyVerify(_ARG_0_)
      elseif _ARG_0_.parentCertificateStatus == 10 then
        if not U2.bReverifyCleared and tonumber(_ARG_0_.adultStatusExpiration) ~= nil and tonumber(_ARG_0_.adultStatusExpiration) > 0 and tonumber(_ARG_0_.adultStatusExpiration) < U2.GetComplianceNowInSec(_ARG_0_) then
        else
        end
      elseif _ARG_0_.parentCertificateStatus == 0 then
        U2.FlowNotStartCertificate(_ARG_0_)
      elseif _ARG_0_.parentCertificateStatus == 1 then
        U2.FlowHasCertificate(_ARG_0_)
      elseif _ARG_0_.certificateType == 3 then
        U2.FlowMailVerify(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetComplianceNowInSec"] = function(_ARG_0_)
    do
      if _ARG_0_ and tonumber(_ARG_0_.tS) and (_ARG_0_ and tonumber(_ARG_0_.tS)) > 0 then
        return _ARG_0_ and tonumber(_ARG_0_.tS)
      end
      do return require((U1(217, 174, 62, 247, 223, 151, 195, 196, 144, 232, 242, 95, 197, 113, 107, 28, 39, 151, 120, 215, 53, 186, 241))).GetServerTimeInSec() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowParentDenyVerify"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 131, 252, 229, 138, 251, 251, 100, 222, 33, 118, 51, 63, 144, 94, 212, 40))
      if tonumber(_ARG_0_.parentCertificateStatusExpiration) == nil or tonumber(_ARG_0_.parentCertificateStatusExpiration) <= 0 or tonumber(_ARG_0_.parentCertificateStatusExpiration) < U2.GetComplianceNowInSec(_ARG_0_) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowParentOutOfDate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 131, 252, 229, 138, 251, 251, 111, 206, 59, 64, 3, 30, 131, 67, 215))
      UIManager.ShowUI(UIManager.UI_Config.gdpr_verify_result, 2, nil, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowParentReject"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 131, 252, 229, 138, 251, 251, 114, 222, 37, 106, 6, 46, 194, 83, 215, 61, 183, 236, 167),
        U1(135, 226)
      }) .. tostring(_ARG_0_))
      UIManager.ShowUI(UIManager.UI_Config.gdpr_verify_result, 1, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowRestartCertificate"] = function()
    log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 129, 248, 228, 155, 244, 253, 84, 248, 42, 125, 17, 51, 132, 94, 209, 48, 183, 232))
    U2.bReverifyCleared = true
    U2.SDKClearUserStatus(function(_ARG_0_)
      do
        printf(table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 180, 75, 205, 54, 129, 248, 228, 155, 244, 253, 84, 248, 42, 125, 17, 51, 132, 94, 209, 48, 183, 232, 167),
          U1(217, 174, 50, 243, 195, 182, 158, 194, 141, 214, 235, 81, 223, 42, 108, 89, 106, 128, 66, 214, 2, 188, 249, 242, 213, 176, 252)
        }), tostring(_ARG_0_ and _ARG_0_.retCode))
        U2.SDKQueryUserStatus(function(_ARG_0_)
          do
            printf(table.concat({
              U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 180, 75, 205, 54, 129, 248, 228, 155, 244, 253, 84, 248, 42, 125, 17, 51, 132, 94, 209, 48, 183, 232, 167),
              U1(200, 167, 49, 224, 212, 144, 133, 194, 155, 169, 191, 64, 202, 45, 122, 27, 62, 177, 66, 208, 53, 128, 233, 246, 155, 224, 252, 26, 158, 60, 35, 69, 57, 135, 69, 198, 56, 165, 228, 228),
              U1(219, 182, 50, 198, 200, 147, 136, 157, 218, 246, 179, 16, 202, 59, 106, 25, 62, 183, 95, 210, 40, 161, 252, 227, 134, 250, 225, 26, 158, 60)
            }), tostring(_ARG_0_ and _ARG_0_.parentCertificateStatus), tostring(_ARG_0_ and _ARG_0_.certificateType), tostring(_ARG_0_ and _ARG_0_.adultStatusExpiration))
            if not _ARG_0_ then
              return
            end
            if U2.IsBrazilRegion(_ARG_0_.region) then
              U2.FlowBrazil(_ARG_0_)
            elseif _ARG_0_.certificateType == -1 then
              U2.FlowSelectArea(_ARG_0_)
            elseif _ARG_0_.certificateType == 0 then
              U2.FlowNoCertificationRequired(_ARG_0_)
            else
              U2.FlowNeedCertificate(_ARG_0_)
            end
            do return end
            _ARG_0_ = _ARG_0_
          end
        end)
        do return end
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
    end)
    return
  end,
  ["FlowWaitEmail"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 132, 252, 254, 155, 208, 226, 65, 210, 35))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowNotStartCertificate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 157, 242, 227, 188, 225, 238, 82, 207, 12, 106, 23, 46, 139, 81, 219, 50, 162, 249, 226))
      U2.sCountry = tostring(_ARG_0_.region)
      UIManager.ShowUI(UIManager.UI_Config.agegate_select_age, _ARG_0_.adultAge, function()
        if nYear and nMonth then
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowHasCertificate"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(154, 174, 56, 245, 216, 128, 178, 196, 144, 232, 239, 92, 194, 62, 113, 22, 47, 210, 97, 206, 46, 164, 213, 246, 156, 214, 234, 82, 207, 38, 105, 12, 57, 131, 67, 215))
      if _ARG_0_ and U2.IsBrazilRegion(_ARG_0_.region) and not U2.IsBrazilMinorGameplayAllowed(_ARG_0_.adultStatus) then
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 155, 252, 228, 172, 240, 253, 84, 210, 41, 102, 6, 59, 150, 82, 146, 19, 177, 236, 253),
          U1(211, 174, 119, 255, 216, 141, 130, 213, 223, 226, 254, 93, 206, 47, 115, 20, 51, 210, 73, 205, 53, 243, 252, 251, 131, 250, 248, 69, 223, 99, 47, 22, 50, 141, 64, 146, 51, 175, 226, 228),
          U1(209, 226, 39, 253, 193, 150, 157)
        }))
        U2.ShowBrazilMinorBlockPopup(_ARG_0_.region)
        return
      end
      U2.EndFlow(U3.NextStep, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[253]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowMailVerify"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 158, 252, 254, 131, 195, 234, 82, 210, 41, 118))
      if _ARG_0_ and U3.IsBrazilRegion(_ARG_0_.region) then
        if _ARG_0_.adultStatus == 1 then
        else
        end
      end
      if U3.IsBrazilRegion(_ARG_0_.region) then
      end
      if U3.IsBrazilRegion(_ARG_0_.region) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowSelectCertificateOptions"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 128, 248, 251, 138, 246, 251, 99, 222, 61, 123, 12, 60, 139, 84, 211, 37, 166, 194, 247),
        U1(206, 171, 56, 252, 194)
      }))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter_fit):NeedForceSelfAuth(_ARG_0_) then
        return
      end
      if _ARG_0_.certificateType == -1 then
      elseif _ARG_0_.certificateType == 1 then
      elseif _ARG_0_.certificateType == 2 then
      elseif _ARG_0_.certificateType == 3 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowSelectCertificateUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(225, 160, 56, 230, 212, 143, 132, 210, 162, 165, 234, 94, 192, 49, 112, 2, 36, 210, 68, 199, 51, 167, 244, 241, 134, 246, 238, 84, 222, 111, 123, 28, 42, 135))
      U2.FlowMailVerify(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowSelfCertification"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 128, 248, 251, 137, 214, 234, 82, 207, 38, 105, 12, 57, 131, 67, 219, 62, 173))
      U2.ReportAuthFlowEvent({
        EventStep = U3.BRANCH_DECIDED,
        AuthBranch = U4.SELF_AUTH
      })
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlowCardVerify"] = function()
    log(bWriteLog and U1(225, 160, 56, 230, 212, 143, 132, 210, 162, 165, 236, 68, 202, 45, 107, 85, 41, 147, 85, 198, 97, 165, 248, 229, 134, 243, 246))
    U2.ReportAuthFlowEvent({
      EventStep = U3.BRANCH_DECIDED,
      AuthBranch = U4.CREDIT_CARD
    })
    U2.ReportAuthFlowEvent({
      EventStep = U3.THIRD_PARTY_AUTH_START,
      AuthBranch = U4.CREDIT_CARD
    })
    return
  end,
  ["EndFlow"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 183, 73, 198, 7, 191, 242, 224, 207, 230, 251, 65, 207, 42, 47, 88, 122) .. tostring(_ARG_0_))
      if _ARG_0_ == U2.ForbiddenEnterGame then
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 183, 73, 198, 7, 191, 242, 224, 207, 249, 224, 71, 210, 44, 80, 6, 53, 143, 71, 222, 56, 162, 227, 228),
          U1(223, 236, 49, 254, 222, 148, 168, 201, 155, 195, 240, 66, 201, 54, 123, 17, 47, 156, 100, 195, 45, 191, 255, 246, 140, 254, 175, 29, 155)
        }) .. tostring(U3.flowEndForbiddenCallback))
        if U3.flowEndForbiddenCallback then
          U3.flowEndForbiddenCallback()
        end
      elseif _ARG_0_ == U2.NextStep then
        U3.ReportToSvrReq(2)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportToSvrReq"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 160, 66, 210, 46, 161, 233, 195, 128, 198, 249, 82, 233, 42, 126, 69, 41, 150, 86, 198, 52, 227, 176, 167) .. tostring(_ARG_0_))
      U2.certState = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBrazilSwitchConfig"] = function()
    if not IsGlobalOperationRegion() then
      return false, false, false, false
    end
    do return U1.math.floor(U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(248, 176, 54, 232, 216, 143, 160, 206, 145, 234, 237, 115, 206, 45, 107, 28, 44, 155, 68, 195, 53, 186, 242, 249), 2122) / 100) % 10 == 2, U1.math.floor(U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(248, 176, 54, 232, 216, 143, 160, 206, 145, 234, 237, 115, 206, 45, 107, 28, 44, 155, 68, 195, 53, 186, 242, 249), 2122) / 10) % 10 == 2, U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(248, 176, 54, 232, 216, 143, 160, 206, 145, 234, 237, 115, 206, 45, 107, 28, 44, 155, 68, 195, 53, 186, 242, 249), 2122) % 10 == 2, U1.math.floor(U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(248, 176, 54, 232, 216, 143, 160, 206, 145, 234, 237, 115, 206, 45, 107, 28, 44, 155, 68, 195, 53, 186, 242, 249), 2122) / 1000) % 10 == 2 end
    return
  end,
  ["IsBrazilChestIpBlockEnabled"] = function()
    do return GetBrazilSwitchConfig() end
    return
  end,
  ["IsComplianceRegionBrazil"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 225, 46, 190, 237, 251, 134, 244, 225, 67, 222, 29, 106, 2, 51, 141, 89, 240, 35, 162, 247, 238),
        U1(214, 226, 37, 247, 214, 138, 130, 201, 197, 160, 236)
      }), tostring(_ARG_0_)))
      if _ARG_0_ and _ARG_0_ ~= U1() then
        if not tonumber(_ARG_0_) then
          return false
        end
        if CDataTable.GetTableDataByFilter(U1(232, 167, 48, 251, 222, 141, 174, 200, 145, 227, 246, 87), U1(232, 167, 48, 251, 222, 141), (tonumber(_ARG_0_))) and CDataTable.GetTableDataByFilter(U1(232, 167, 48, 251, 222, 141, 174, 200, 145, 227, 246, 87), U1(232, 167, 48, 251, 222, 141), (tonumber(_ARG_0_))).RegionCode == U1(248, 144) then
          return true
        else
        end
      else
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 225, 46, 190, 237, 251, 134, 244, 225, 67, 222, 29, 106, 2, 51, 141, 89, 240, 35, 162, 247, 238),
          U1(214, 226, 37, 247, 214, 138, 130, 201, 223, 236, 236, 16, 197, 54, 115, 85, 37, 128, 7, 199, 44, 163, 233, 238)
        }))
      end
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 225, 46, 190, 237, 251, 134, 244, 225, 67, 222, 29, 106, 2, 51, 141, 89, 240, 35, 162, 247, 238),
        U1(214, 226, 37, 247, 197, 150, 159, 201, 223, 227, 254, 92, 216, 58)
      }))
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsIpRegionBrazil"] = function()
    do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).sIpRegion == U1(248, 144) end
    return
  end,
  ["IsGameRegionBrazil"] = function()
    log(bWriteLog and string.format(table.concat({
      U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 229, 32, 190, 248, 197, 138, 242, 230, 79, 213, 13, 125, 4, 32, 139, 91, 146, 21, 162, 249, 230),
      U1(247, 165, 37, 188, 227, 134, 138, 206, 144, 235, 219, 81, 223, 62, 49, 7, 47, 149, 78, 205, 47, 233, 184, 228)
    }), tostring(DataMgr.RegionData.region)))
    if DataMgr.RegionData.region == U1(248, 144) then
      if CDataTable.GetTableDataByFilter(U1(232, 167, 48, 251, 222, 141, 174, 200, 145, 227, 246, 87), U1(232, 167, 48, 251, 222, 141, 174, 200, 155, 224), (U1(248, 144))) then
        return true
      else
      end
    end
    log(bWriteLog and table.concat({
      U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 229, 32, 190, 248, 197, 138, 242, 230, 79, 213, 13, 125, 4, 32, 139, 91, 146, 35, 166, 249, 242),
      U1(200, 172, 119, 244, 208, 143, 158, 194)
    }))
    do return false end
    return
  end,
  ["IsBrazilRegion"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 224, 51, 178, 231, 254, 131, 199, 234, 71, 210, 32, 97, 69, 40, 135, 80, 219, 62, 173, 183, 162),
        U1(201)
      }), tostring(_ARG_0_)))
      if not U2.GetBrazilSwitchConfig() then
        return false
      end
      if U2.IsComplianceRegionBrazil(_ARG_0_) then
        return true
      end
      if U2.IsIpRegionBrazil() then
        return true
      end
      if U2.IsGameRegionBrazil() then
        if (_ARG_0_ == nil or _ARG_0_ == U1()) and CDataTable.GetTableDataByFilter(U1(232, 167, 48, 251, 222, 141, 174, 200, 145, 227, 246, 87), U1(232, 167, 48, 251, 222, 141, 174, 200, 155, 224), (U1(248, 144))) then
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAdultCertified"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return false
      end
      if tonumber(_ARG_0_.adultStatus or _ARG_0_.adult_check_status) ~= 1 then
        return false
      end
      if tonumber(_ARG_0_.needAdultVerification or _ARG_0_.need_adult_verification) ~= 1 then
        return true
      end
      if not U1.IsComplianceRegionBrazil(_ARG_0_.region) then
        return true
      end
      do return tonumber(_ARG_0_.adultVerificationStatus or _ARG_0_.adult_verification_status) == 1 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBrazilMinorGameplayAllowed"] = function(_ARG_0_)
    do
      if _ARG_0_ == 1 then
        log(bWriteLog and table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 187, 84, 224, 51, 178, 231, 254, 131, 216, 230, 78, 212, 61, 72, 4, 55, 135, 71, 222, 48, 186, 204, 235),
          U1(214, 173, 32, 247, 213, 195, 140, 195, 138, 233, 235, 99, 223, 62, 107, 0, 57, 207, 22, 142, 97, 178, 249, 226, 131, 225, 175, 85, 200, 42, 125, 73, 122, 131, 91, 222, 62, 180)
        }))
        return true
      end
      if not U2.GetBrazilSwitchConfig() then
        return true
      end
      if U2.GetBrazilSwitchConfig() then
        return true
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBrazilSkipCertificationAllowed"] = function(_ARG_0_)
    do
      if not GetBrazilSwitchConfig() then
        return false
      end
      if not IsBrazilRegion(_ARG_0_) then
        return false
      end
      do return GetBrazilSwitchConfig() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLegacySkipAllowed"] = function()
    if not bInRegistrationFlow then
      return false
    end
    if not U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_familycenter):IsRegisterLegacySDK() then
      return false
    end
    do return U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_familycenter):IsAllowSkipCertification() end
    return
  end,
  ["ReportSkipCertificationComplete"] = function()
    ReportAuthFlowEvent({
      EventStep = U1.REGISTER_COMPLIANCE_COMPLETE,
      RegisterComplianceType = U2.AUTH_SKIPPED
    })
    return
  end,
  ["FlowBrazil"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 218, 43, 122, 9, 46, 177, 67, 211, 37, 182, 254, 167),
        U1(135, 226)
      }) .. tostring(_ARG_0_.adultStatus) .. U1(150, 226, 57, 247, 212, 135, 172, 195, 138, 233, 235, 102, 206, 45, 118, 19, 35, 145, 70, 214, 40, 188, 243, 183, 210, 181) .. tostring(_ARG_0_.needAdultVerification) .. U1(150, 226, 54, 246, 196, 143, 153, 241, 154, 247, 246, 86, 194, 60, 126, 1, 35, 157, 73, 241, 53, 178, 233, 226, 156, 181, 178, 0) .. tostring(_ARG_0_.adultVerificationStatus))
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 203, 46, 125, 0, 52, 150, 118, 214, 36, 175, 249, 209),
        U1(223, 176, 62, 244, 216, 128, 140, 211, 150, 234, 241, 99, 223, 62, 107, 0, 57, 210, 26, 130)
      }) .. tostring(_ARG_0_.parentAdultVerificationStatus) .. U1(150, 226, 57, 247, 212, 135, 189, 198, 141, 224, 241, 68, 234, 59, 106, 25, 62, 164, 66, 208, 40, 181, 244, 244, 142, 225, 230, 79, 213, 111, 50, 69) .. tostring(_ARG_0_.needParentAdultVerification) .. U1(150, 226, 39, 243, 195, 134, 131, 211, 188, 224, 237, 68, 194, 57, 118, 22, 43, 134, 66, 241, 53, 178, 233, 226, 156, 181, 178, 0) .. tostring(_ARG_0_.parentCertificateStatus))
      if _ARG_0_.retCode == 5 and _ARG_0_.thirdCode == 30025 then
        return
      elseif _ARG_0_.retCode ~= 0 then
        ShowNotice(87846)
        return
      end
      if _ARG_0_.adultStatus == 1 then
        if _ARG_0_.needAdultVerification == 0 then
          log(bWriteLog and table.concat({
            U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 224, 14, 107, 16, 54, 150, 106, 146, 63, 166, 232, 227),
            U1(251, 166, 34, 254, 197, 181, 136, 213, 150, 227, 246, 83, 202, 43, 118, 26, 36, 207, 23, 142, 97, 189, 242, 183, 153, 240, 253, 73, 221, 38, 108, 4, 46, 139, 88, 220, 113, 177, 232, 246),
            U1(207, 171, 37, 247, 213)
          }))
          U2.FlowHasCertificate(_ARG_0_, U3.NO_NEED_COMPLY)
        elseif _ARG_0_.adultVerificationStatus == 1 then
          log(bWriteLog and table.concat({
            U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 224, 14, 107, 16, 54, 150, 106, 146, 48, 167, 248, 235),
            U1(206, 148, 50, 224, 216, 133, 132, 196, 158, 241, 246, 95, 197, 12, 107, 20, 62, 135, 84, 159, 112, 255, 189, 246, 131, 231, 234, 65, 223, 54, 47, 19, 63, 144, 94, 212, 56, 166, 233)
          }))
          U2.FlowHasCertificate(_ARG_0_)
        elseif _ARG_0_.adultVerificationStatus == 10 then
          U2.FlowWaitEmail(_ARG_0_)
        else
          log(bWriteLog and table.concat({
            U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 224, 14, 107, 16, 54, 150, 106, 146, 48, 167, 248, 235),
            U1(206, 148, 50, 224, 216, 133, 132, 196, 158, 241, 246, 95, 197, 12, 107, 20, 62, 135, 84, 130, 96, 238, 189, 166, 195, 181, 225, 69, 222, 43, 47, 19, 63, 144, 94, 212, 56, 160, 236, 243),
            U1(211, 173, 57)
          }))
          U2.BrazilFlowNotStartCertificate(_ARG_0_)
        end
      elseif _ARG_0_.needParentAdultVerification == 1 then
        if _ARG_0_.parentAdultVerificationStatus == 0 then
          log(bWriteLog and table.concat({
            U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 224, 2, 102, 11, 53, 144, 106, 146, 33, 162, 255, 226),
            U1(212, 182, 22, 246, 196, 143, 153, 241, 154, 247, 246, 86, 194, 60, 126, 1, 35, 157, 73, 241, 53, 178, 233, 226, 156, 168, 191, 12, 155, 63, 110, 23, 63, 140, 67, 146, 63, 172, 249, 167),
            U1(201, 182, 54, 224, 197, 134, 137)
          }))
          U2.BrazilFlowNotStartCertificate(_ARG_0_)
        elseif _ARG_0_.parentAdultVerificationStatus == 1 then
          log(bWriteLog and table.concat({
            U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 224, 2, 102, 11, 53, 144, 106, 146, 33, 162, 255, 226),
            U1(212, 182, 22, 246, 196, 143, 153, 241, 154, 247, 246, 86, 194, 60, 126, 1, 35, 157, 73, 241, 53, 178, 233, 226, 156, 168, 190, 12, 155, 63, 110, 23, 63, 140, 67, 146, 48, 175, 255, 226),
            U1(219, 166, 46, 178, 199, 134, 159, 206, 153, 236, 250, 84)
          }))
          U2.FlowHasCertificate(_ARG_0_)
        elseif _ARG_0_.parentAdultVerificationStatus == 10 then
          log(bWriteLog and table.concat({
            U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 180, 75, 205, 54, 145, 239, 246, 149, 252, 227, 0, 224, 2, 102, 11, 53, 144, 106, 146, 33, 162, 255, 226),
            U1(212, 182, 22, 246, 196, 143, 153, 241, 154, 247, 246, 86, 194, 60, 126, 1, 35, 157, 73, 241, 53, 178, 233, 226, 156, 168, 190, 16, 151, 111, 120, 4, 51, 150, 94, 220, 54, 227, 232, 234),
            U1(219, 171, 59, 178, 199, 134, 159, 206, 153, 236, 252, 81, 223, 54, 112, 27)
          }))
          U2.FlowWaitEmail(_ARG_0_)
        end
      elseif _ARG_0_.parentCertificateStatus == 1 then
        U2.FlowHasCertificate(_ARG_0_)
      elseif _ARG_0_.certificateType == -1 then
        U2.FlowSelectArea()
      elseif _ARG_0_.certificateType == 0 then
        U2.FlowNoCertificationRequired(_ARG_0_)
      else
        U2.FlowNeedCertificate(_ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BrazilFlowNotStartCertificate"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 106, 176, 85, 195, 59, 186, 241, 209, 131, 250, 248, 110, 212, 59, 92, 17, 59, 144, 67, 241, 52, 177, 249, 238),
        U1(220, 171, 52, 243, 197, 134)
      }))
      U2.sCountry = tostring(_ARG_0_.region)
      if not _ARG_0_.adultAge or _ARG_0_.adultAge <= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportBrazilCompliance"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 160, 66, 210, 46, 161, 233, 213, 157, 244, 245, 73, 215, 12, 96, 8, 42, 142, 94, 211, 63, 160, 232, 167),
        U1(223, 180, 50, 252, 197, 176, 153, 198, 152, 224, 162, 21, 216, 115, 63, 0, 57, 151, 85, 246, 56, 163, 248, 170, 202, 230, 163, 0, 216, 32, 98, 21, 54, 139, 86, 220, 50, 166, 222, 243),
        U1(219, 182, 34, 225, 140, 198, 158, 139, 223, 247, 250, 87, 194, 48, 113, 72, 111, 129, 11, 130, 51, 182, 250, 254, 128, 251, 204, 79, 214, 63, 99, 12, 59, 140, 84, 215, 108, 230, 254)
      }), tostring(_ARG_0_), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_4_)))
      if _ARG_0_ == U2.CertSuccessEnterGame or _ARG_0_ == U2.MinorBlockPopup then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBrazilReportUserType"] = function()
    if require((U1(217, 174, 62, 247, 223, 151, 195, 212, 147, 240, 254, 30, 199, 48, 120, 28, 41, 220, 64, 198, 49, 161, 179, 251, 128, 242, 230, 67, 228, 40, 107, 21, 40))).GetIsNewUser() then
      return U2.NewUser
    else
      return U2.ExistingUser
    end
    return
  end,
  ["BRAZIL_COMPLIANCE_EVENT_STAGE"] = {
    ShowAgeCollectPopup = 1,
    CertSuccessEnterGame = 2,
    MinorBlockPopup = 3
  },
  ["BRAZIL_COMPLIANCE_USER_TYPE"] = {NewUser = 1, ExistingUser = 2},
  ["BRAZIL_COMPLIANCE_STATUS"] = {Adult = 0, Minor = 1},
  ["ReportAuthFlowEvent"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or {}
      if type(_ARG_0_.EventStep) ~= U1(212, 183, 58, 240, 212, 145) then
        printf(table.concat({
          U1(225, 149, 22, 192, 255, 190, 205, 203, 144, 226, 246, 83, 244, 60, 112, 24, 58, 158, 78, 195, 47, 176, 248, 185, 189, 240, 255, 79, 201, 59, 78, 16, 46, 138, 113, 222, 62, 180, 200, 241),
          U1(223, 172, 35, 178, 216, 141, 155, 198, 147, 236, 251, 16, 238, 41, 122, 27, 62, 161, 83, 199, 49, 238, 184, 228, 195, 181, 252, 75, 210, 63)
        }), _ARG_0_.EventStep)
        return
      end
      if not U2.bInRegistrationFlow then
        printf(table.concat({
          U1(214, 173, 48, 251, 210, 188, 142, 200, 146, 245, 243, 89, 202, 49, 124, 16, 100, 160, 66, 210, 46, 161, 233, 214, 154, 225, 231, 102, 215, 32, 120, 32, 44, 135, 89, 198, 113, 176, 230, 238),
          U1(202, 248, 119, 252, 222, 151, 205, 206, 145, 165, 237, 85, 204, 54, 108, 1, 56, 147, 83, 203, 46, 189, 189, 241, 131, 250, 248, 12, 155, 10, 121, 0, 52, 150, 100, 198, 52, 179, 176, 162),
          U1(201)
        }), _ARG_0_.EventStep)
        return
      end
      if _ARG_0_.EventStep == U3.REGISTER_COMPLIANCE_COMPLETE and type(_ARG_0_.RegisterComplianceType) ~= U1(212, 183, 58, 240, 212, 145) then
        printf(table.concat({
          U1(225, 149, 22, 192, 255, 190, 205, 203, 144, 226, 246, 83, 244, 60, 112, 24, 58, 158, 78, 195, 47, 176, 248, 185, 189, 240, 255, 79, 201, 59, 78, 16, 46, 138, 113, 222, 62, 180, 200, 241),
          U1(223, 172, 35, 178, 227, 166, 170, 238, 172, 209, 218, 98, 244, 28, 80, 56, 26, 190, 110, 227, 15, 144, 216, 200, 172, 218, 194, 112, 247, 10, 91, 32, 122, 143, 94, 193, 34, 170, 227, 224),
          U1(154, 144, 50, 245, 216, 144, 153, 194, 141, 198, 240, 93, 219, 51, 118, 20, 36, 145, 66, 246, 56, 163, 248, 170, 202, 230, 163, 0, 200, 36, 102, 21)
        }), _ARG_0_.RegisterComplianceType)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportMinorComplianceAuthFlowReq"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
