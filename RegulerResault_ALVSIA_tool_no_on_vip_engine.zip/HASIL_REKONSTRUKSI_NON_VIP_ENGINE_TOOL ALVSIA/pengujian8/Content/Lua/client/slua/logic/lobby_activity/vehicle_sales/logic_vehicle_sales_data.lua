local logic_vehicle_sales_data = {}
local TableUtil = require("common.table_util")
logic_vehicle_sales_data.ERR = {
  NOT_OPEN = 19990001,
  PRICE_MISMATCH = 19990002,
  LIMIT_BUY = 19990003,
  PAY_FAILED = 19990004,
  NO_REFUND = 19990005
}
logic_vehicle_sales_data.COND_TYPE = {
  LOGIN = 1,
  PROGRESS = 2,
  OWN_SPORTS_CAR = 3
}
logic_vehicle_sales_data.CURRENT_ACT_ID = 447270001

function logic_vehicle_sales_data:RequestOpenAfterExitBattle()
  if self.PendingJumpUrl then
    return
  end
  self.PendingJumpUrl = "game://?module=" .. BP_ENUM_MODULE_VEHICLE_SALES
  self.PendingJumpFromState = GameStatus.GetGameStatus()
  if SubsystemMgr then
    local CreativeModeResultSubsystem = SubsystemMgr:Get("CreativeModeResultSubsystem")
    if CreativeModeResultSubsystem then
      CreativeModeResultSubsystem:RealExitGame()
      return
    end
  end
  self.PendingJumpUrl = nil
  self.PendingJumpFromState = nil
end

function logic_vehicle_sales_data:OnPostSwitchGameStatus(preState, nextState)
  if not self.PendingJumpUrl or preState ~= self.PendingJumpFromState or nextState ~= GameStatus.Lobby then
    return
  end
  local jumpUrl = self.PendingJumpUrl
  self.PendingJumpUrl = nil
  self.PendingJumpFromState = nil
  self:AddTimerOnce(0, function()
    GlobalData.JumpUrl(jumpUrl)
  end)
end

function logic_vehicle_sales_data:OnLogin(bReLogin)
  self:SendGetDiscountSaleShop(self.CURRENT_ACT_ID)
end

function logic_vehicle_sales_data:OnLogOut()
  self.PendingJumpUrl = nil
  self.PendingJumpFromState = nil
  self.shopInfo = nil
  self.buyResult = nil
end

function logic_vehicle_sales_data:SendGetDiscountSaleShop(act_id)
  local VehicleSalesHandler = RequireMod("client.network.Protocol.VehicleSalesHandler")
  if VehicleSalesHandler then
    VehicleSalesHandler.send_get_discount_sale_shop_req(act_id or self.CURRENT_ACT_ID)
  end
end

function logic_vehicle_sales_data:SendBuyDiscountSale(act_id, client_price)
  local VehicleSalesHandler = RequireMod("client.network.Protocol.VehicleSalesHandler")
  local final_act_id = act_id or self.CURRENT_ACT_ID
  local final_price = client_price or self:GetCurPrice(final_act_id)
  log_format(bWriteLog and "[VehicleSales] SendBuyDiscountSale act_id=%s client_price=%s handler=%s", tostring(final_act_id), tostring(final_price), tostring(VehicleSalesHandler ~= nil))
  if VehicleSalesHandler then
    VehicleSalesHandler.send_buy_discount_sale_req(final_act_id, final_price)
  end
end

function logic_vehicle_sales_data:SendTakeDiscountSaleRefund(act_id)
  local VehicleSalesHandler = RequireMod("client.network.Protocol.VehicleSalesHandler")
  if VehicleSalesHandler then
    VehicleSalesHandler.send_take_discount_sale_refund_req(act_id or self.CURRENT_ACT_ID)
  end
end

function logic_vehicle_sales_data:OnGetDiscountSaleShopRsp(ret, act_id, product)
  act_id = act_id or self.CURRENT_ACT_ID
  self.shopInfo = self.shopInfo or {}
  self.shopInfo[act_id] = {ret = ret, product = product}
  log_format(bWriteLog and "[VehicleSales] OnGetDiscountSaleShopRsp ret=%s act_id=%s has_product=%s", tostring(ret), tostring(act_id), tostring(product ~= nil))
  EventSystem:postEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_SHOP_UPDATE, act_id)
  self:UpdateSidebarRedDot(act_id, product)
end

function logic_vehicle_sales_data:UpdateSidebarRedDot(act_id, product)
  local bHasRefund = product ~= nil and product.refund_info ~= nil and 0 < (product.refund_info.refundable or 0)
  local logic_lobby_reddot = require("client.slua.logic.lobby.logic_lobby_reddot")
  logic_lobby_reddot.ProcModuleReddot(BP_ENUM_MODULE_VEHICLE_SALES, bHasRefund)
end

function logic_vehicle_sales_data:OnBuyDiscountSaleRsp(ret, act_id, item_info, price_info)
  act_id = act_id or self.CURRENT_ACT_ID
  self.buyResult = {
    ret = ret,
    act_id = act_id,
    item_info = item_info,
    price_info = price_info
  }
  log_format(bWriteLog and "[VehicleSales] OnBuyDiscountSaleRsp ret=%s act_id=%s", tostring(ret), tostring(act_id))
  if ret == self.ERR.PRICE_MISMATCH then
    self:SendGetDiscountSaleShop(act_id)
  end
  EventSystem:postEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_BUY_RESULT, self.buyResult)
end

function logic_vehicle_sales_data:OnTakeDiscountSaleRefundRsp(ret, act_id, owed)
  act_id = act_id or self.CURRENT_ACT_ID
  log_format(bWriteLog and "[VehicleSales] OnTakeDiscountSaleRefundRsp ret=%s act_id=%s owed=%s", tostring(ret), tostring(act_id), tostring(owed))
  if ret == 0 and 0 < (owed or 0) then
    self:SendGetDiscountSaleShop(act_id)
  end
  EventSystem:postEvent(EVENTTYPE_ACTIVITY, EVENTID_VEHICLE_SALES_REFUND_RESULT, {
    ret = ret,
    act_id = act_id,
    owed = owed or 0
  })
end

function logic_vehicle_sales_data:GetItemCfg(act_id)
  return CDataTable.GetTableData("discount_sale_items_table", act_id or self.CURRENT_ACT_ID)
end

function logic_vehicle_sales_data:GetSourceActID(act_id)
  local rel = CDataTable.GetTableData("ugc_sports_car_relation_act_table", act_id or self.CURRENT_ACT_ID)
  return rel and rel.source_act_id or nil
end

function logic_vehicle_sales_data:GetActivityData(act_id)
  local logic_activity_mgr = require("client.slua.logic.activity.logic_activity_mgr")
  local data = logic_activity_mgr.GetServerDataByID(act_id or self.CURRENT_ACT_ID)
  if data and data.cfg then
    return data
  end
  return logic_activity_mgr.GetActivityByID(act_id or self.CURRENT_ACT_ID)
end

function logic_vehicle_sales_data:GetTierList(act_id)
  local activityData = self:GetActivityData(act_id)
  if not (activityData and activityData.cfg) or not activityData.cfg.award then
    return {}
  end
  local awardCfg = activityData.cfg.award
  local list = {}
  local awardEntries = {}
  for i, awardItem in pairs(awardCfg) do
    local condStr = awardItem and awardItem.cond
    if condStr and condStr ~= "" then
      awardEntries[#awardEntries + 1] = {key = i, item = awardItem}
    end
  end
  table.sort(awardEntries, function(a, b)
    return (tonumber(a.key) or 0) < (tonumber(b.key) or 0)
  end)
  for _, entry in ipairs(awardEntries) do
    local i = entry.key
    local condStr = entry.item.cond
    local StringUtil = require("common.string_util")
    local cond = StringUtil.SplitToNum(condStr, ",")
    local TableUtil = require("common.table_util")
    local status = TableUtil.GetTableValue(activityData.data, "award", i, "status") or ActivityProgressStatus.Not
    list[#list + 1] = {
      index = i,
      discount = cond[1] or 100,
      cond_type = cond[2] or 0,
      layer = cond[3] or 1,
      cond_param = cond[4] or 0,
      status = status,
      done = status ~= ActivityProgressStatus.Not
    }
  end
  return list
end

function logic_vehicle_sales_data:GetBasePrice(act_id)
  local shopInfo = self:GetShopInfo(act_id)
  local product = shopInfo and shopInfo.product
  local price_info = product and product.price_info
  return price_info and price_info.base_price or 0
end

function logic_vehicle_sales_data:GetCurPrice(act_id)
  local shopInfo = self:GetShopInfo(act_id)
  local product = shopInfo and shopInfo.product
  local price_info = product and product.price_info
  if price_info and price_info.cur_price then
    return price_info.cur_price
  end
  return self:CalculatePrice(act_id)
end

function logic_vehicle_sales_data:CalculatePrice(act_id, excludeCondTypes)
  local price = self:GetBasePrice(act_id)
  if price <= 0 then
    return 0
  end
  local layerMin = {}
  local tiers = self:GetTierList(act_id) or {}
  for _, tier in ipairs(tiers) do
    if excludeCondTypes and excludeCondTypes[tier.cond_type] then
    elseif tier.done and tier.discount then
      local cur = layerMin[tier.layer]
      if not cur or cur > tier.discount then
        layerMin[tier.layer] = tier.discount
      end
    end
  end
  for _, disc in pairs(layerMin) do
    price = price * disc / 100
  end
  return math.floor(price + 0.5)
end

function logic_vehicle_sales_data:GetDiscountRate(act_id)
  local base = self:GetBasePrice(act_id)
  if base <= 0 then
    return 100
  end
  return math.floor(self:CalculatePrice(act_id) * 100 / base + 0.5)
end

function logic_vehicle_sales_data:GetFloorPrice(act_id)
  local price = self:GetBasePrice(act_id)
  if price <= 0 then
    return 0
  end
  local layerMin = {}
  for _, tier in ipairs(self:GetTierList(act_id)) do
    if tier.discount then
      local cur = layerMin[tier.layer]
      if not cur or cur > tier.discount then
        layerMin[tier.layer] = tier.discount
      end
    end
  end
  for _, disc in pairs(layerMin) do
    price = price * disc / 100
  end
  return math.floor(price + 0.5)
end

function logic_vehicle_sales_data:GetWowFloorPrice(act_id)
  local price = self:GetBasePrice(act_id)
  if price <= 0 then
    return 0
  end
  local minDiscount
  for _, tier in ipairs(self:GetTierList(act_id)) do
    if tier.cond_type == self.COND_TYPE.PROGRESS and tier.discount and (not minDiscount or minDiscount > tier.discount) then
      minDiscount = tier.discount
    end
  end
  if not minDiscount then
    return 0
  end
  return math.floor(price * minDiscount / 100 + 0.5)
end

function logic_vehicle_sales_data:GetNextTier(act_id)
  for _, tier in ipairs(self:GetTierList(act_id)) do
    if not tier.done then
      return tier
    end
  end
  return nil
end

function logic_vehicle_sales_data:IsCondTypeAllDone(act_id, condType)
  local bHas = false
  for _, tier in ipairs(self:GetTierList(act_id)) do
    if tier.cond_type == condType then
      bHas = true
      if not tier.done then
        return false
      end
    end
  end
  return bHas
end

function logic_vehicle_sales_data:GetShopInfo(act_id)
  return self.shopInfo and self.shopInfo[act_id or self.CURRENT_ACT_ID] or nil
end

function logic_vehicle_sales_data:IsBought(act_id)
  local shopInfo = self:GetShopInfo(act_id)
  return shopInfo ~= nil and shopInfo.product ~= nil and shopInfo.product.refund_info ~= nil
end

function logic_vehicle_sales_data:GetBuyResult()
  return self.buyResult
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local CTemplate = class(CModuleBase, nil, logic_vehicle_sales_data)
return CTemplate
