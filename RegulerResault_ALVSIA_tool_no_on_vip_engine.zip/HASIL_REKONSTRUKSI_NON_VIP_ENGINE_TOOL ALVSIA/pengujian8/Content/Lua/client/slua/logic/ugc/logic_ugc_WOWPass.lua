do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(249, 51, 6, 146, 51)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(249, 51, 14, 132, 46, 106, 69, 211, 205, 241, 120, 182, 187, 182, 138, 150, 11, 2, 114, 166, 223, 92, 112, 160, 255, 234, 121, 191, 162, 156, 190, 149, 9, 26))), nil, {
  ["DefineAndResetData"] = function(_ARG_0_)
    do
      _ARG_0_.bShowRedDot = false
      _ARG_0_.RedDotInfo = {task_has = false, level_has = false}
      _ARG_0_.IsBuyPass = 0
      _ARG_0_.UGCPassInfo = nil
      _ARG_0_.UGCPASSTaskStatus = nil
      _ARG_0_.CurScore = 0
      _ARG_0_.CurLevel = 0
      _ARG_0_.BeforeLevel = 0
      _ARG_0_.nUCCountLackTip = 0
      _ARG_0_.OpenPanelQueue = {}
      _ARG_0_.FinishingTaskInfo = nil
      _ARG_0_.LastSendPassInfoTime = 0
      _ARG_0_.LastReqRedDotTime = 0
      _ARG_0_.ShowTipsQueue = {}
      _ARG_0_.show_flag = nil
      _ARG_0_.BeforePurchaseState = nil
      _ARG_0_.NowPurchaseState = nil
      _ARG_0_.before_wow_pass_level = nil
      _ARG_0_.BuyPlusAwardList = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_DATA_MGR, EVNETID_DATAMGR_COMMON_ITEM_BUY_SUC, _ARG_0_.DirectBuyMissionCardSuccess, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_DATA_MGR, EVNETID_DATAMGR_COMMON_ITEM_BUY_FAIL, _ARG_0_.DirectBuyMissionCardFail, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogin"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 252, 65, 124, 231, 220), _ARG_1_)
      U2.send_ugc_pass_get_info_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogOut"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 252, 65, 124, 193, 199, 241))
      _ARG_0_:ClearData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 224, 92, 126, 221, 197, 236, 105, 169, 166, 190, 157, 153, 31, 44, 115, 160, 212, 75, 120), _ARG_1_, _ARG_2_)
      _ARG_0_:ClearData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 224, 65, 104, 250, 225, 242, 116, 190, 173, 145, 187, 149, 23, 26, 84, 181, 193, 74, 126, 237), _ARG_1_, _ARG_2_)
      if _ARG_2_ == GameStatus.Lobby then
        U2.send_ugc_pass_get_info_req()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDestroy"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 244, 75, 104, 250, 192, 234, 100))
      _ARG_0_:ClearData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSystemOpen"] = function(_ARG_0_)
    do
      do return LobbySystem.CheckOpen(92066) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenWowPassPanel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_1_ then
        return
      end
      if require((table.concat({
        U1(249, 51, 14, 132, 46, 106, 69, 205, 206, 224, 108, 244, 178, 134, 139, 141, 9, 65, 115, 190, 199, 64, 119, 225, 211, 225, 51, 172, 167, 141, 210, 152, 21, 24, 110, 162, 255, 88, 98, 234),
        U1(204, 58, 21, 146, 41, 113, 5, 225, 198, 250, 122, 180, 178, 134, 141, 128)
      }))).IfNotFitLobbyResDownloadedShowWindow() then
        return
      end
      if _ARG_0_:GetValidUGCPassInfo() then
      elseif _ARG_4_ == U1(240, 42, 10, 145, 31, 115, 4, 218, 215, 249, 104, 133, 137, 166, 187, 180, 11, 28, 100) then
        if not _ARG_0_:ReqUGCWOWPassInfo(_ARG_3_) then
        else
          _ARG_0_.ModulePendingJump = true
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseWOWPassJump"] = function(_ARG_0_)
    do
      _ARG_0_.ModulePendingJump = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenQueuePanels"] = function(_ARG_0_, _ARG_1_)
    do
      if UIManager.IsUIShow(UIManager.UI_Config.UGC_WOW_PASS_Pop_BuyPassGuide) then
        _ARG_0_:_CloseBuyBuyPassGuide()
      end
      if UIManager.IsUIShow(UIManager.UI_Config.UGC_WoWPass_Cover_UIBP) then
        _ARG_0_:_CloseBuyBuyPassGuide()
      end
      goto lbl_82
      if nil == UIManager.UI_Config.UGC_WOW_PASS_MainUI then
      elseif nil == UIManager.UI_Config.UGC_WOW_PASS_BuyLevel then
      elseif nil == UIManager.UI_Config.UGC_WOW_PASS_Privilege_MainUIBP then
      elseif nil == UIManager.UI_Config.UGC_WOW_PASS_Pop_BuyPassGuide then
      elseif nil == UIManager.UI_Config.UGC_WoWPass_Cover_UIBP then
      elseif nil == UIManager.UI_Config.UGC_WOW_PASS_Buy_Panel then
      elseif nil == UIManager.UI_Config.UGC_WoWPass_RightsDetails_UIBP then
      end
      ::lbl_82::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.OpenPanelQueue = {}
      _ARG_0_.ModulePendingJump = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseWowPassPanel"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == UIManager.UI_Config.UGC_WOW_PASS_MainUI then
        _ARG_0_:_CloseWOWPassMainUI()
      elseif _ARG_1_ == UIManager.UI_Config.UGC_WOW_PASS_BuyLevel then
        _ARG_0_:_CloseBuyPassLevelUI()
      elseif _ARG_1_ == UIManager.UI_Config.UGC_WOW_PASS_Privilege_MainUIBP then
        _ARG_0_:_ClosePrivilgeUI()
      elseif _ARG_1_ == UIManager.UI_Config.UGC_WOW_PASS_Pop_BuyPassGuide then
        _ARG_0_:_CloseBuyBuyPassGuide()
      elseif _ARG_1_ == UIManager.UI_Config.UGC_WoWPass_Cover_UIBP then
        _ARG_0_:_CloseBuyBuyPassGuide()
      elseif _ARG_1_ == UIManager.UI_Config.UGC_WOW_PASS_Buy_Panel then
        _ARG_0_:_ClosePrivilegeUI()
      elseif _ARG_1_ == UIManager.UI_Config.UGC_WoWPass_RightsDetails_UIBP then
        _ARG_0_:_CloseRightsDetailsToPrivilege()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SelectWOWPassMainUITab"] = function(_ARG_0_, _ARG_1_)
    do
      if UIManager.GetUI(UIManager.UI_Config.UGC_WOW_PASS_MainUI) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearData"] = function(_ARG_0_)
    do
      _ARG_0_.UGCPassInfo = nil
      _ARG_0_.UGCPASSTaskStatus = nil
      _ARG_0_.show_flag = nil
      _ARG_0_.PassRecordList = nil
      _ENV = {}
      U1 = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWOWPassRedDotState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bShowRedDot = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWOWPassRedDotState"] = function(_ARG_0_)
    do
      do return _ARG_0_.bShowRedDot end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWOWPassTaskRedDotState"] = function(_ARG_0_)
    do
      _ARG_0_.RedDotInfo.task_has = _ARG_0_:CanPlayerGetTaskReward()
      _ARG_0_.bShowRedDot = _ARG_0_.RedDotInfo.task_has or _ARG_0_.RedDotInfo.level_has
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_RED_DOT_STATE_CHANGE, _ARG_0_.bShowRedDot)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWOWPassTaskRedDotState"] = function(_ARG_0_)
    do
      do return _ARG_0_.RedDotInfo.task_has end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWOWPassRewardRedDotState"] = function(_ARG_0_)
    do
      _ARG_0_.RedDotInfo.level_has = _ARG_0_:CanPlayerGetPassReward()
      _ARG_0_.bShowRedDot = _ARG_0_.RedDotInfo.task_has or _ARG_0_.RedDotInfo.level_has
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_RED_DOT_STATE_CHANGE, _ARG_0_.bShowRedDot)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWOWPasssRewardRedDotState"] = function(_ARG_0_)
    do
      do return _ARG_0_.RedDotInfo.level_has end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OpenWOWPassMainUI"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 161, 213, 64, 76, 193, 229, 213, 124, 185, 189, 180, 157, 157, 20, 42, 78))
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_MainUI, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CloseWOWPassMainUI"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 95, 184, 212, 75, 76, 193, 229, 213, 124, 185, 189, 180, 157, 157, 20, 42, 78))
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_MainUI)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OpenBuyPassLevelUI"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_WOW_PASS, EVENTID_WOW_PASS_HIDE_TAB)
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_BuyLevel)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CloseBuyPassLevelUI"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_BuyLevel)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenUpLevelSuccessUI"] = function(_ARG_0_, _ARG_1_)
    do
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_Pop_UpLevel, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseUpLevelSuccessUI"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_Pop_UpLevel)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OpenPrivilgeUI"] = function(_ARG_0_, _ARG_1_)
    do
      EventSystem:postEvent(EVENTTYPE_WOW_PASS, EVENTID_WOW_PASS_HIDE_TAB)
      if UIManager.IsUIShow(UIManager.UI_Config.UGC_WOW_PASS_MainUI) then
        _ARG_0_:_ClosePrivilgeUI()
      end
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_Privilege_MainUIBP, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClosePrivilgeUI"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_Privilege_MainUIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenBuyPassSuccessUI"] = function(_ARG_0_)
    do
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_Pop_BuySuccess)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseBuySuccessUI"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_Pop_BuySuccess)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowBuyBuyPassGuide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 72, 130, 216, 65, 108, 204, 199, 252, 95, 191, 183, 169, 157, 135, 9, 56, 114, 168, 196, 91))
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_Pop_BuyPassGuide)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowWOWPassTogetherPopup"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 72, 130, 216, 65, 108, 217, 253, 210, 77, 171, 189, 138, 168, 155, 29, 26, 115, 169, 197, 76, 91, 241),
        U1(234, 42, 23)
      }))
      UIManager.ShowUI(UIManager.UI_Config.UGC_WoWPass_Cover_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowWOWPassToPrivilege"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 72, 130, 216, 65, 108, 217, 253, 210, 77, 171, 189, 138, 168, 155, 42, 13, 110, 183, 201, 82, 110, 249),
        U1(255)
      }))
      EventSystem:postEvent(EVENTTYPE_WOW_PASS, EVENTID_WOW_PASS_HIDE_TAB)
      if UIManager.IsUIShow(UIManager.UI_Config.UGC_WOW_PASS_MainUI) then
        _ARG_0_:_ClosePrivilgeUI()
      end
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_Buy_Panel)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowRightsDetailsUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 72, 130, 216, 65, 108, 220, 219, 226, 117, 190, 189, 189, 153, 128, 27, 22, 107, 178, 245, 119))
      UIManager.ShowUI(UIManager.UI_Config.UGC_WoWPass_RightsDetails_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CloseBuyBuyPassGuide"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_Pop_BuyPassGuide)
      UIManager.CloseUI(UIManager.UI_Config.UGC_WoWPass_Cover_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClosePrivilegeUI"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 72, 146, 220, 65, 104, 235, 229, 202, 74, 154, 175, 138, 143, 160, 21, 47, 117, 168, 214, 87, 103, 251),
        U1(253, 58)
      }))
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_Buy_Panel)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CloseRightsDetailsToPrivilege"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 72, 146, 220, 65, 104, 235, 224, 236, 122, 162, 186, 138, 184, 145, 14, 30, 110, 173, 211, 106, 100, 206),
        U1(232, 54, 17, 136, 44, 123, 12, 219)
      }))
      UIManager.CloseUI(UIManager.UI_Config.UGC_WoWPass_RightsDetails_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenBuyPrivilegeSuccessUI"] = function(_ARG_0_, _ARG_1_)
    do
      UIManager.ShowUI(UIManager.UI_Config.UGC_WOW_PASS_Privilege_Success, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseBuyPrivilegeSuccessUI"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.UGC_WOW_PASS_Privilege_Success)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCWOWPassAllTaskConfig"] = function(_ARG_0_)
    do
      if _ARG_0_.AllTaskConfig then
        return _ARG_0_.AllTaskConfig
      end
      if not _ARG_0_.UGCPassInfo then
        log_warning(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 181, 22, 19, 83, 160, 211, 85, 72, 241),
          U1(244, 57, 14, 134, 96, 75, 44, 253, 242, 244, 126, 169, 151, 135, 138, 139, 74, 6, 100, 241, 254, 71, 119)
        }))
        return
      end
      _ARG_0_.AllTaskConfig = CDataTable.GetTableByFilter(U1(205, 48, 16, 177, 33, 109, 24, 234, 195, 230, 102, 153, 184, 142), U1(233, 58, 6, 146, 47, 112, 52, 215, 198), _ARG_0_:GetSeasonID()) or {}
      do return _ARG_0_.AllTaskConfig end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCWOWPassWeekTaskConfig"] = function(_ARG_0_)
    do
      if _ARG_0_.WeekTaskConfig then
        return _ARG_0_.WeekTaskConfig
      end
      if not _ARG_0_.UGCPassInfo then
        log_warning(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 163, 31, 26, 108, 149, 193, 77, 96, 221),
          U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226)
        }))
        return
      end
      goto lbl_107
      if 0 < U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226).week_index then
        ;({
          [U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226).week_index] = {}
        })[U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226).week_index] or {}[U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226)] = U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226)
      end
      ::lbl_107::
      _ARG_0_ = _ARG_0_
      _ARG_0_.WeekTaskConfig, _ARG_0_ = {
        [U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226).week_index] = {}
      }, _ARG_0_
      do return {
        [U1(245, 49, 1, 136, 39, 62, 62, 249, 225, 197, 108, 169, 173, 160, 130, 130, 5, 79, 126, 162, 144, 96, 114, 226).week_index] = {}
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCWOWPassSeasonTaskConfig"] = function(_ARG_0_)
    do
      if _ARG_0_.SeasonTaskConfig then
        return _ARG_0_.SeasonTaskConfig
      end
      if not _ARG_0_.UGCPassInfo then
        log_warning(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 167, 31, 30, 116, 174, 206, 106, 106, 237),
          U1(241, 28, 8, 143, 38, 119, 12, 158, 247, 210, 78, 138, 191, 154, 159, 173, 4, 9, 120, 241, 217, 93, 59, 192, 219, 233)
        }))
        return
      end
      goto lbl_101
      if U1(241, 28, 8, 143, 38, 119, 12, 158, 247, 210, 78, 138, 191, 154, 159, 173, 4, 9, 120, 241, 217, 93, 59, 192, 219, 233).week_index == 0 then
      end
      ::lbl_101::
      _ARG_0_ = _ARG_0_
      _ARG_0_.SeasonTaskConfig, _ARG_0_ = {
        [U1(241, 28, 8, 143, 38, 119, 12, 158, 247, 210, 78, 138, 191, 154, 159, 173, 4, 9, 120, 241, 217, 93, 59, 192, 219, 233)] = U1(241, 28, 8, 143, 38, 119, 12, 158, 247, 210, 78, 138, 191, 154, 159, 173, 4, 9, 120, 241, 217, 93, 59, 192, 219, 233)
      }, _ARG_0_
      do return {
        [U1(241, 28, 8, 143, 38, 119, 12, 158, 247, 210, 78, 138, 191, 154, 159, 173, 4, 9, 120, 241, 217, 93, 59, 192, 219, 233)] = U1(241, 28, 8, 143, 38, 119, 12, 158, 247, 210, 78, 138, 191, 154, 159, 173, 4, 9, 120, 241, 217, 93, 59, 192, 219, 233)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetValidUGCPassInfo"] = function(_ARG_0_)
    do
      if _ARG_0_.UGCPassInfo then
        if _ARG_0_:IsSeasonActive() then
          return _ARG_0_.UGCPassInfo
        else
          print(bWriteLog and table.concat({
            U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 120, 122, 226, 219, 225, 72, 141, 141, 169, 157, 135, 9, 54, 105, 167, 207, 30, 94, 217),
            U1(217, 15, 6, 146, 51, 62, 46, 208, 198)
          }))
          return nil
        end
      else
        return nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetValidUGCPASSTaskStatus"] = function(_ARG_0_)
    do
      if _ARG_0_:GetCurWeekIndex() == _ARG_0_.CurTaskWeek then
        return _ARG_0_.UGCPASSTaskStatus
      else
        print(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 120, 122, 226, 219, 225, 72, 141, 141, 169, 189, 167, 41, 43, 102, 178, 203, 109, 127, 255),
          U1(238, 42, 20, 193, 21, 89, 40, 238, 195, 230, 126, 142, 191, 154, 135, 196, 36, 10, 111, 165, 144, 121, 126, 235, 217)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCPASSTaskStatusByID"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetValidUGCPASSTaskStatus() and (_ARG_1_ and _ARG_1_ ~= 0 and _ARG_0_:GetValidUGCPASSTaskStatus().week_task[_ARG_1_] or _ARG_0_:GetValidUGCPASSTaskStatus().challenge_task) then
        return (_ARG_1_ and _ARG_1_ ~= 0 and _ARG_0_:GetValidUGCPASSTaskStatus().week_task[_ARG_1_] or _ARG_0_:GetValidUGCPASSTaskStatus().challenge_task)[_ARG_2_]
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRewardSlapUI"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and #_ARG_1_ == 1 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory):CheckTabIdIsInventory((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory):GetTabIDDigits(_ARG_1_[1].resid))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuyPassLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckUCRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCameraAndBg"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or false
      if not require((table.concat({
        U1(249, 51, 14, 132, 46, 106, 69, 205, 206, 224, 108, 244, 170, 155, 141, 141, 30, 28, 57, 149, 213, 90, 122, 231, 222, 198, 114, 167, 190, 150, 146, 145, 20, 11, 41, 128, 214, 95, 127, 255),
        U1(232, 27, 14, 146, 48, 114, 10, 199, 140, 214, 98, 180, 173, 157, 173, 146, 11, 27, 118, 163, 244, 71, 104, 226, 211, 252)
      }))).CameraID[_ARG_1_] then
        return
      end
      if CDataTable.GetTableData(U1(214, 48, 5, 131, 57, 93, 10, 211, 199, 231, 108, 147, 176, 143, 131), require((table.concat({
        U1(249, 51, 14, 132, 46, 106, 69, 205, 206, 224, 108, 244, 170, 155, 141, 141, 30, 28, 57, 149, 213, 90, 122, 231, 222, 198, 114, 167, 190, 150, 146, 145, 20, 11, 41, 128, 214, 95, 127, 255),
        U1(232, 27, 14, 146, 48, 114, 10, 199, 140, 214, 98, 180, 173, 157, 173, 146, 11, 27, 118, 163, 244, 71, 104, 226, 211, 252)
      }))).CameraID[_ARG_1_]) then
      end
      if _ARG_2_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassIsBuy"] = function(_ARG_0_)
    do
      send_ugc_pass_get_buy_info_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCWOWPassIsBuyRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 217, 253, 210, 77, 171, 189, 138, 181, 135, 56, 10, 126, 147, 211, 78), _ARG_1_, _ARG_2_)
      if _ARG_1_ == 0 then
        _ARG_0_.IsBuyPass = _ARG_2_
      else
        ShowNotice(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassInfo"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 189, 20, 25, 104))
      if U2.GetServerTimeInSec() - _ARG_0_.LastSendPassInfoTime < U3 then
        return false
      end
      _ARG_0_.LastSendPassInfoTime = U2.GetServerTimeInSec()
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCWOWPassInfoRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 217, 253, 210, 77, 171, 189, 138, 181, 154, 28, 16, 85, 178, 208), _ARG_1_, _ARG_2_)
      if _ARG_1_ == 0 and _ARG_2_ then
        log_tree(_ARG_2_)
        if not _ARG_2_.static_season_info then
          _ARG_0_.OpenPanelQueue = {}
          return
        end
        if not _ARG_2_.static_season_info.cfg then
          _ARG_0_.OpenPanelQueue = {}
          return
        end
        if require((U1(249, 51, 14, 132, 46, 106, 69, 221, 205, 248, 96, 181, 176, 199, 154, 129, 24, 28, 126, 190, 222, 113, 110, 250, 219, 233))).CompareVersionStandard(require((U1(249, 51, 14, 132, 46, 106, 69, 221, 205, 248, 96, 181, 176, 199, 154, 129, 24, 28, 126, 190, 222, 113, 110, 250, 219, 233))).GetClientFormat(Client.GetAppVersion()), _ARG_2_.static_season_info.cfg.version) == -1 then
          _ARG_0_.OpenPanelQueue = {}
          return
        end
        _ARG_0_.UGCPassInfo = _ARG_2_
        if _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.is_buy then
          if _ARG_0_.UGCPassInfo.is_buy == U2.Enum_UGCWOWPassBuyType.Elite then
            _ARG_0_.IsBuyPass = U2.Enum_UGCWOWPassBuyType.Elite
          elseif _ARG_0_.UGCPassInfo.is_buy == U2.Enum_UGCWOWPassBuyType.Plus then
            _ARG_0_.IsBuyPass = U2.Enum_UGCWOWPassBuyType.Plus
          end
        end
      else
        if _ARG_0_.ShowTipsQueue[1] then
          ShowNotice(_ARG_1_)
        end
        table.remove(_ARG_0_.ShowTipsQueue, 1)
        _ARG_0_.OpenPanelQueue = {}
        _ARG_0_:CloseWOWPassJump()
        _ARG_0_:ReqUGCWOWPassIsBuy()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckWoWPassDisplay"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 84, 185, 213, 77, 112, 217, 221, 210, 77, 171, 189, 138, 184, 157, 9, 15, 107, 160, 217, 30, 126, 247),
        U1(254, 101, 71, 196, 51)
      }), tostring(_ARG_1_)))
      if tonumber(DataMgr.roleData.uid) == tonumber(_ARG_1_) then
        return require((table.concat({
          U1(249, 51, 14, 132, 46, 106, 69, 205, 206, 224, 108, 244, 178, 134, 139, 141, 9, 65, 100, 180, 196, 90, 114, 224, 213, 171, 113, 165, 169, 144, 159, 171, 9, 26, 115, 181, 201, 80, 108, 193),
          U1(248, 62, 20, 136, 35)
        }))).bWoWPassDisplay
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_).ugc_privacy_setting and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_).ugc_privacy_setting.wow_pass_display == true then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWOWpassIcon"] = function(_ARG_0_)
    do
      if not _ARG_0_:CheckWoWPassDisplay(tonumber(DataMgr.roleData.uid)) then
        return nil
      end
      if _ARG_0_:IsBuyElite() then
        goto lbl_61
        if (_ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.accumulate_buy_times and (_ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.accumulate_buy_times) > 0 and _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.accumulate_buy_times or 1) >= (33).AccBuyCount then
          if nil == nil then
          elseif (33).AccBuyCount < (33).AccBuyCount then
          end
        end
        ::lbl_61::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if 33 ~= nil then
          return (33).SignIconPath
        end
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWRedPointInfo"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 152, 171, 157, 172, 155, 19, 17, 115, 136, 206, 88, 100))
      if U2.GetServerTimeInSec() - _ARG_0_.LastReqRedDotTime < 3 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCWOWRedPointInfoRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == 0 and type(_ARG_2_) == U1(238, 62, 5, 141, 37) then
        print(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 217, 253, 210, 79, 175, 170, 169, 147, 157, 20, 11, 78, 175, 198, 81, 89, 237),
          U1(234)
        }), _ARG_1_, _ARG_2_.task_has, _ARG_2_.level_has)
        _ARG_0_.bShowRedDot = _ARG_2_.task_has or _ARG_2_.level_has
        _ARG_0_.RedDotInfo = _ARG_2_
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_RED_DOT_STATE_CHANGE, _ARG_0_.bShowRedDot)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCPassRewardInfoNotify"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        print(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 222, 211, 246, 110, 152, 171, 142, 157, 134, 30, 54, 105, 167, 207, 112, 100, 234),
          U1(243, 57, 30)
        }), _ARG_1_.task_has, _ARG_1_.level_has)
        if _ARG_1_.task_has ~= nil then
          _ARG_0_.bShowRedDot = _ARG_1_.task_has or _ARG_0_.RedDotInfo.level_has
          _ARG_0_.RedDotInfo.task_has = _ARG_1_.task_has
        end
        if _ARG_1_.level_has ~= nil then
          _ARG_0_.bShowRedDot = _ARG_1_.level_has or _ARG_0_.RedDotInfo.task_has
          _ARG_0_.RedDotInfo.level_has = _ARG_1_.level_has
        end
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_RED_DOT_STATE_CHANGE, _ARG_0_.bShowRedDot)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassTaskStatus"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 160, 27, 12, 108, 146, 212, 95, 127, 235),
        U1(233)
      }))
      U2.send_ugc_pass_get_current_task_status_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetUGCWOWPassTaskStatusRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 247, 75, 111, 219, 245, 198, 74, 133, 153, 169, 157, 135, 9, 43, 102, 178, 203, 109, 127, 255),
        U1(238, 42, 20, 179, 51, 110)
      }), _ARG_1_)
      if _ARG_1_ == 0 then
        log_tree(table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 247, 75, 111, 219, 245, 198, 74, 133, 153, 169, 157, 135, 9, 43, 102, 178, 203, 109, 127, 255),
          U1(238, 42, 20, 179, 51, 110, 75, 237, 214, 244, 121, 175, 173, 165, 133, 151, 30)
        }), _ARG_2_)
        U2 = {
          From = U1(239, 56, 4, 190, 48, 127, 24, 205, 253, 242, 104, 174, 129, 138, 153, 150, 24, 10, 121, 165, 239, 90, 122, 253, 217, 218, 110, 190, 175, 141, 137, 135, 37, 13, 116, 177),
          StatusList = DeepCopy(_ARG_2_ or {})
        }
        _ARG_0_:SetUGCWOWPassTaskStatus(_ARG_2_)
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_TASK_STATUS_CHANGE_ALL)
      else
        ShowNotice(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCWOWPassTaskStatusNotify"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 217, 253, 210, 77, 171, 189, 138, 168, 149, 9, 20, 84, 181, 193, 74, 126, 237),
        U1(212, 48, 19, 136, 38, 103)
      }))
      log_tree(table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 217, 253, 210, 77, 171, 189, 138, 168, 149, 9, 20, 84, 181, 193, 74, 126, 237),
        U1(212, 48, 19, 136, 38, 103, 75, 237, 214, 244, 121, 175, 173, 165, 133, 151, 30)
      }), _ARG_1_)
      U2 = {
        From = U1(239, 56, 4, 190, 48, 127, 24, 205, 253, 225, 108, 169, 181, 182, 159, 144, 11, 27, 98, 162, 239, 77, 115, 239, 220, 226, 120, 149, 160, 150, 136, 157, 28, 6),
        StatusList = DeepCopy(_ARG_1_ or {})
      }
      _ARG_0_:SetUGCWOWPassTaskStatus(_ARG_1_)
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_TASK_STATUS_CHANGE_ALL)
      _ARG_0_:RefreshWOWPassTaskRedDotState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCWOWPassTaskStatus"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UGCPASSTaskStatus = _ARG_1_
      _ARG_0_.CurTaskWeek = _ARG_0_:GetCurWeekIndex()
      if not _ARG_0_:GetUGCWOWPassWeekTaskConfig() then
        return
      end
      goto lbl_41
      goto lbl_39
      if _ARG_0_:GetUGCWOWPassWeekTaskConfig()[nil] and _ARG_0_:GetUGCWOWPassWeekTaskConfig()[nil][nil] and (_ARG_0_:GetUGCWOWPassWeekTaskConfig()[nil] and _ARG_0_:GetUGCWOWPassWeekTaskConfig()[nil][nil]).task_limit_week > 0 and (_ARG_0_:GetUGCWOWPassWeekTaskConfig()[nil] and _ARG_0_:GetUGCWOWPassWeekTaskConfig()[nil][nil]).week_index ~= _ARG_0_.CurTaskWeek and (nil).status ~= U1.Enum_UGCPASSTask_Status.UnReward then
        ;(nil).status = U1.Enum_UGCPASSTask_Status.Expired
      end
      ::lbl_39::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_41::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FinishTaskByCardReq"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 81, 184, 222, 71, 104, 230, 230, 228, 110, 161, 140, 128, 191, 149, 8, 27, 85, 164, 209), _ARG_1_, _ARG_2_)
      if not _ARG_0_:GetUGCPASSTaskStatusByID(_ARG_1_, _ARG_2_) or _ARG_0_:GetUGCPASSTaskStatusByID(_ARG_1_, _ARG_2_).status ~= U2.Enum_UGCPASSTask_Status.UnFinish then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFinishTaskByCardRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 246, 71, 117, 231, 193, 237, 73, 171, 189, 146, 190, 141, 57, 30, 117, 165, 242, 77, 123), _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_1_ == 0 then
        _ARG_0_.FinishingTaskInfo = {WeekID = _ARG_2_, TaskID = _ARG_3_}
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_TASK_STATUS_CHANGE_ALL)
      else
        ShowNotice(_ARG_1_)
        _ARG_0_:ReportTLogData(_ARG_1_, _ARG_2_, _ARG_3_, (U1(252, 54, 9, 136, 51, 118, 52, 204, 209, 229)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSingleTaskRewardReq"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 125, 114, 224, 213, 233, 120, 158, 175, 138, 151, 166, 31, 8, 102, 179, 196, 108, 110, 239), _ARG_1_, _ARG_2_)
      if not _ARG_0_:GetUGCPASSTaskStatusByID(_ARG_1_, _ARG_2_) or _ARG_0_:GetUGCPASSTaskStatusByID(_ARG_1_, _ARG_2_).status ~= U2.Enum_UGCPASSTask_Status.UnReward then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_FormatDebugString"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return _ARG_1_
      end
      _ARG_1_ = string.gsub(_ARG_1_, U1(238, 45, 18, 132), (U1(171)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(252, 62, 11, 146, 37), (U1(170)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(182), (U1(183)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(225), (U1(166)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(231), (U1(164)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(191, 119), (U1(166)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(191, 118), (U1(164)))
      _ARG_1_ = string.gsub(_ARG_1_, U1(186), (U1()))
      if string.len(_ARG_1_) > 255 then
        _ARG_1_ = string.sub(_ARG_1_, 1, 255)
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GenerateStr"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_3_.WeekID ~= _ARG_1_ or _ARG_3_.TaskID ~= _ARG_2_ then
        return
      end
      do return {
        from = _ARG_4_,
        click_from = U1(207, 24, 36, 190, 23, 81, 60, 225, 242, 212, 94, 137, 129, 164, 141, 141, 4, 58, 94),
        basic_info = string.format(U1(205, 58, 2, 138, 9, 90, 81, 155, 209, 185, 89, 187, 173, 130, 165, 160, 80, 74, 100), tostring(_ARG_1_), tostring(_ARG_2_)),
        client_task = _ARG_3_.TaskStr,
        client_status = _ARG_3_.StatusStr,
        server_info = string.format(U1(220, 45, 8, 140, 122, 59, 24, 146, 241, 225, 108, 174, 171, 154, 214, 193, 25), tostring(U2.From), dump((U2.StatusList or {}).challenge_task or {}[_ARG_2_] or (U2.StatusList or {}).week_task or {}[_ARG_1_] or {}[_ARG_2_] or {}))
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportTLogData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if table.remove(U1, 1) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetSingleTaskRewardRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 247, 75, 111, 221, 219, 235, 122, 166, 171, 173, 157, 135, 17, 45, 98, 182, 193, 76, 111, 204),
        U1(233, 47)
      }), _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_1_ == 0 then
        log_tree(table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 247, 75, 111, 221, 219, 235, 122, 166, 171, 173, 157, 135, 17, 45, 98, 182, 193, 76, 111, 204),
          U1(233, 47, 71, 168, 52, 123, 6, 242, 203, 230, 121)
        }), _ARG_4_)
        _ARG_0_:ShowRewardSlapUI(_ARG_4_)
      else
        ShowNotice(_ARG_1_)
        _ARG_0_:ReportTLogData(_ARG_1_, _ARG_2_, _ARG_3_, (U1(232, 58, 16, 128, 50, 122, 52, 204, 209, 229)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllTaskRewardReq"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 111, 119, 226, 230, 228, 110, 161, 156, 156, 139, 149, 8, 27, 85, 164, 209))
      U2.send_ugc_pass_get_all_task_reward_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetAllTaskRewardRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 247, 75, 111, 207, 222, 233, 73, 171, 189, 146, 174, 145, 13, 30, 117, 165, 242, 77, 123), _ARG_1_)
      if _ARG_1_ == 0 then
        log_tree(table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 247, 75, 111, 207, 222, 233, 73, 171, 189, 146, 174, 145, 13, 30, 117, 165, 242, 77, 123, 190),
          U1(211, 43, 2, 140, 12, 119, 24, 202)
        }), _ARG_2_)
        _ARG_0_:ShowRewardSlapUI(_ARG_2_)
      else
        ShowNotice(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassBuyLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 182, 15, 6, 75, 164, 214, 91, 103))
      _ARG_0_.nUCCountLackTip = _ARG_1_
      U2.send_ugc_pass_buy_level_req(_ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCWOWPassBuyLevelRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 217, 253, 210, 77, 171, 189, 138, 190, 129, 3, 51, 98, 183, 197, 82, 89, 237),
        U1(234)
      }), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_ == 0 then
        _ARG_0_:SetBeforeLevel(_ARG_5_)
        _ARG_0_:SetLevel(_ARG_4_)
        if _ARG_5_ < _ARG_4_ then
          EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_BUY_Level_RSP)
          _ARG_0_:OpenUpLevelSuccessUI()
        end
      elseif _ARG_1_ == 2008006 then
      else
        ShowNotice(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCPassScoreLevelChangeRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 229, 105, 88, 222, 211, 246, 110, 153, 173, 150, 142, 145, 54, 26, 113, 164, 204, 125, 99, 255),
        U1(244, 56, 2, 179, 51, 110)
      }), _ARG_1_, _ARG_2_, _ARG_3_)
      _ARG_0_:SetLevel(_ARG_3_)
      _ARG_0_:SetScore(_ARG_2_)
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_SCORE_LEVEL_CHANGE)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = EVENTID_UGC_WOW_PASS_SCORE_LEVEL_CHANGE
    end
  end,
  ["BuyPass"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckUCRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuyPassDeluxeEdition"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckUCRestrict() then
        return
      end
      if not _ARG_0_:GetSeasonID() or _ARG_0_:GetSeasonID() < 8 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassBuyReq"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 182, 15, 6))
      _ARG_0_.nUCCountLackTip = _ARG_1_
      U2.send_ugc_buy_pass_req(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassBuyRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 182, 15, 6, 85, 178, 208))
      if _ARG_1_ == 0 then
        _ARG_0_:SetLevel(_ARG_4_)
        _ARG_0_:SetScore(_ARG_3_)
        if _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.level_reward_status_list then
          _ARG_0_.UGCPassInfo.level_reward_status_list = _ARG_5_
          EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_AWARD_STATUS_CHANGE)
        end
        _ARG_0_.before_wow_pass_level = _ARG_6_ and next(_ARG_6_) and _ARG_6_.before_wow_pass_level
        _ARG_0_.BuyPlusAwardList = _ARG_6_ and next(_ARG_6_) and _ARG_6_.super_item_list
        if _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.is_buy then
          if _ARG_6_ and next(_ARG_6_) and _ARG_6_.buy_super_pass then
            _ARG_0_.UGCPassInfo.is_buy = U2.Enum_UGCWOWPassBuyType.Plus
            _ARG_0_.IsBuyPass = U2.Enum_UGCWOWPassBuyType.Plus
          else
            _ARG_0_.UGCPassInfo.is_buy = U2.Enum_UGCWOWPassBuyType.Elite
            _ARG_0_.IsBuyPass = U2.Enum_UGCWOWPassBuyType.Elite
          end
        end
      elseif _ARG_1_ == 2008006 then
      else
        ShowNotice(_ARG_1_)
      end
      do return end
      _ARG_1_ = U1[6]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassBuyGuideReq"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 182, 15, 6, 64, 180, 201, 90, 110, 204),
        U1(255, 46)
      }))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_newbie_guide):IsOngoingStrongGuide() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqUGCWOWPassBuyGuideRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 123, 92, 205, 229, 202, 74, 154, 175, 138, 143, 182, 15, 6, 64, 180, 201, 90, 110, 204),
        U1(233, 47, 71, 132, 50, 108, 4, 204, 253, 246, 98, 190, 187, 211, 204, 193, 25, 67, 55, 162, 216, 65, 108, 209, 212, 233, 124, 173, 244, 217, 217, 135)
      }), _ARG_1_, _ARG_2_))
      if _ARG_1_ == 0 then
        _ARG_0_.show_flag = _ARG_2_
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_BUY_GUIDE_RSP)
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LevelRewardStatusChangeNotify"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 91, 180, 198, 75, 119, 220, 215, 242, 124, 184, 170, 170, 136, 149, 14, 10, 116, 130, 200, 95, 101, 249),
        U1(255, 17, 8, 149, 41, 120, 18)
      }))
      if _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.level_reward_status_list then
        _ARG_0_.UGCPassInfo.level_reward_status_list = _ARG_1_
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_AWARD_STATUS_CHANGE)
        _ARG_0_:RefreshWOWPassRewardRedDotState()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqWOWPassGetAllAward"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 121, 84, 217, 226, 228, 110, 185, 137, 156, 136, 181, 22, 19, 70, 182, 193, 76, 111))
      U2.send_ugc_pass_get_all_level_award_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["WOWPassGetAllAwardRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 64, 158, 231, 126, 122, 253, 193, 194, 120, 190, 143, 149, 144, 181, 13, 30, 117, 165, 242, 77, 123), _ARG_1_)
      if _ARG_1_ == 0 then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_pass):IsTakingJointReward() then
        else
        end
        if _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.level_reward_status_list then
          _ARG_0_.UGCPassInfo.level_reward_status_list = _ARG_3_
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqWOWPassAward"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 121, 84, 217, 226, 228, 110, 185, 143, 142, 157, 134, 30), _ARG_1_, _ARG_2_)
      U2.send_ugc_pass_get_level_award_req(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["WOWPassGetAwardRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      print(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 64, 158, 231, 126, 122, 253, 193, 194, 120, 190, 143, 142, 157, 134, 30, 45, 116, 177), _ARG_1_, _ARG_2_, _ARG_3_)
      if _ARG_1_ == 0 then
        log_tree(table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 64, 158, 231, 126, 122, 253, 193, 194, 120, 190, 143, 142, 157, 134, 30, 45, 116, 177, 128, 119, 127, 251),
          U1(247, 19, 14, 146, 52)
        }), _ARG_4_)
        _ARG_0_:ShowRewardSlapUI(_ARG_4_)
        if _ARG_0_.UGCPassInfo and _ARG_0_.UGCPassInfo.level_reward_status_list then
          _ARG_0_.UGCPassInfo.level_reward_status_list = _ARG_5_
          EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_AWARD_STATUS_CHANGE)
          _ARG_0_:RefreshWOWPassRewardRedDotState()
        end
      else
        ShowNotice(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCPassSeasonInfo"] = function(_ARG_0_)
    do
      if _ARG_0_.UGCPassInfo then
        return _ARG_0_.UGCPassInfo.static_season_info
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCPassSeasonInfoCfg"] = function(_ARG_0_)
    do
      if _ARG_0_:GetUGCPassSeasonInfo() then
        return _ARG_0_:GetUGCPassSeasonInfo().cfg
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMaxLevel"] = function(_ARG_0_)
    do
      if _ARG_0_:GetUGCPassSeasonInfoCfg() then
        return _ARG_0_:GetUGCPassSeasonInfoCfg().max_level
      end
      do return 50 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBuyElite"] = function(_ARG_0_)
    do
      if _ARG_0_:GetValidUGCPassInfo() then
        return _ARG_0_.UGCPassInfo.is_buy > Enum_UGCWOWPassBuyType.None and true or false
      end
      do return _ARG_0_.IsBuyPass > Enum_UGCWOWPassBuyType.None and true or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBuyPlus"] = function(_ARG_0_)
    do
      if _ARG_0_:GetValidUGCPassInfo() then
        return _ARG_0_.UGCPassInfo.is_buy == Enum_UGCWOWPassBuyType.Plus and true or false
      end
      do return _ARG_0_.IsBuyPass == Enum_UGCWOWPassBuyType.Plus and true or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLevel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.CurLevel = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevel"] = function(_ARG_0_)
    do
      do return _ARG_0_.CurLevel end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetScore"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.CurScore = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScore"] = function(_ARG_0_)
    do
      do return _ARG_0_.CurScore end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMaxScorePerLevel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.MaxScorePerLevel = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMaxScorePerLevel"] = function(_ARG_0_)
    do
      do return _ARG_0_.MaxScorePerLevel end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUCPricePerLevel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UCPricePerLevel = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUCPricePerLevel"] = function(_ARG_0_)
    do
      do return _ARG_0_.UCPricePerLevel end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBeforeLevel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.BeforeLevel = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBeforeLevel"] = function(_ARG_0_)
    do
      do return _ARG_0_.BeforeLevel end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonID"] = function(_ARG_0_)
    do
      if _ARG_0_:GetUGCPassSeasonInfo() then
        return _ARG_0_:GetUGCPassSeasonInfo().season_id
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonPirce"] = function(_ARG_0_)
    do
      if _ARG_0_:GetSeasonID() and CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())) then
        return CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).Price, CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).DiscountPrice
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonDeluxeEditionPrice"] = function(_ARG_0_)
    do
      if _ARG_0_:GetSeasonID() and CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())) then
        return CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).DeluxeEditionPrice, CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).DeluxeEditionDiscountPrice
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonPlusPriceDiff"] = function(_ARG_0_)
    do
      if _ARG_0_:GetSeasonPirce() and _ARG_0_:GetSeasonDeluxeEditionPrice() then
      end
      if _ARG_0_:GetSeasonPirce() and _ARG_0_:GetSeasonDeluxeEditionPrice() then
      end
      do return _ARG_0_:GetSeasonDeluxeEditionPrice() - _ARG_0_:GetSeasonPirce(), _ARG_0_:GetSeasonDeluxeEditionPrice() - _ARG_0_:GetSeasonPirce() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonPassRoleImagePath"] = function(_ARG_0_)
    do
      if _ARG_0_:GetSeasonID() and CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())) then
        return CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).RoleImagePath, CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).RoleImagePath2
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonImagePreviewRolePath"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 125, 126, 239, 193, 234, 115, 131, 163, 152, 155, 145, 42, 13, 98, 183, 201, 91, 124, 204),
        U1(245, 51, 2, 177, 33, 106, 3)
      }))
      if _ARG_0_:GetSeasonID() and CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())) then
        return CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).ImagePreviewRolePath
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonImagePreviewBGPath"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 80, 180, 196, 125, 126, 239, 193, 234, 115, 131, 163, 152, 155, 145, 42, 13, 98, 183, 201, 91, 124, 220),
        U1(221, 15, 6, 149, 40)
      }))
      if _ARG_0_:GetSeasonID() and CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())) then
        return CDataTable.GetTableData(U1(205, 48, 16, 177, 33, 109, 24, 237, 199, 244, 126, 181, 176, 189, 133, 137, 15, 44, 113, 182), (_ARG_0_:GetSeasonID())).ImagePreviewBGPath
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSeasonEndTime"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetUGCPassSeasonInfoCfg() then
        return GetServerTimeInSec()
      end
      do return _ARG_0_:GetUGCPassSeasonInfoCfg().end_time end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurWeekIndex"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetUGCPassSeasonInfoCfg() then
        return 1
      end
      do return math.ceil(math.max(U1.GetServerTimeInSec() - _ARG_0_:GetUGCPassSeasonInfoCfg().start_time, 0) / 604800) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFirstUnRewardTaskWeek"] = function(_ARG_0_)
    do
      if _ARG_0_:GetValidUGCPASSTaskStatus() then
        goto lbl_25
        if not (nil > _ARG_0_:GetCurWeekIndex()) then
          goto lbl_23
          if (nil).status == U1.Enum_UGCPASSTask_Status.UnReward then
            return nil
          end
          ::lbl_23::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          ::lbl_25::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return _ARG_0_:GetCurWeekIndex() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTaskConfig"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetUGCWOWPassWeekTaskConfig(), _ARG_0_:GetUGCWOWPassSeasonTaskConfig() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSeasonActive"] = function(_ARG_0_)
    do
      if not _ARG_0_.UGCPassInfo then
        _ARG_0_:ReqUGCWOWPassInfo()
        return false
      end
      do return _ARG_0_:GetSeasonEndTime() - GetServerTimeInSec() > 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPassRewardStatus"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetValidUGCPassInfo() and _ARG_0_:GetValidUGCPassInfo().level_reward_status_list then
        return _ARG_0_:GetValidUGCPassInfo().level_reward_status_list.normal_status[_ARG_1_] or 0, _ARG_0_:GetValidUGCPassInfo().level_reward_status_list.elite_status[_ARG_1_] or 0
      end
      do return 0, 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanPlayerGetPassReward"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetValidUGCPassInfo() then
        return
      end
      if not _ARG_0_:GetValidUGCPassInfo().level_reward_status_list then
        return
      end
      goto lbl_19
      if nil == U1.Done then
        return true
      end
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_30
      if nil == U1.Done then
        return true
      end
      ::lbl_30::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanPlayerGetTaskReward"] = function(_ARG_0_)
    do
      if _ARG_0_:GetValidUGCPASSTaskStatus() then
        goto lbl_22
        goto lbl_20
        if (nil).status == U1.Enum_UGCPASSTask_Status.UnReward then
          return true
        end
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_22::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_35
        if (nil).status == U1.Enum_UGCPASSTask_Status.UnReward then
          return true
        end
        ::lbl_35::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFinishingTaskInfo"] = function(_ARG_0_)
    do
      do return _ARG_0_.FinishingTaskInfo end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearFinishingTaskInfo"] = function(_ARG_0_)
    do
      _ARG_0_.FinishingTaskInfo = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPendingTaskFinishByCardInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.PendingFinishByCardInfo = {
        WeekID = _ARG_1_,
        TaskID = _ARG_2_,
        GoodsID = _ARG_3_
      }
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DirectBuyMissionCardSuccess"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.PendingFinishByCardInfo and _ARG_3_ and _ARG_0_.PendingFinishByCardInfo.GoodsID == _ARG_3_.id then
        _ARG_0_.PendingFinishByCardInfo = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DirectBuyMissionCardFail"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.PendingFinishByCardInfo and _ARG_3_ and _ARG_0_.PendingFinishByCardInfo.GoodsID == _ARG_3_.id then
        _ARG_0_.PendingFinishByCardInfo = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowTaskPanel"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 68, 185, 223, 89, 79, 239, 193, 238, 77, 171, 160, 156, 144))
      if not _ARG_0_:IsSeasonActive() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqPassRecordInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 69, 180, 193, 126, 122, 253, 193, 215, 120, 169, 161, 139, 152, 189, 20, 25, 104))
      if _ARG_0_.GM_PassRecordMock then
        _ARG_0_:OnPassRecordInfoRsp(0, _ARG_0_.GM_PassRecordMock)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPassRecordInfoRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 224, 79, 104, 253, 224, 224, 126, 165, 188, 157, 181, 154, 28, 16, 85, 178, 208), _ARG_1_)
      if _ARG_1_ == 0 then
        log_tree(bWriteLog and table.concat({
          U1(246, 48, 0, 136, 35, 65, 30, 217, 193, 202, 90, 149, 137, 185, 141, 151, 25, 85, 88, 191, 224, 79, 104, 253, 224, 224, 126, 165, 188, 157, 181, 154, 28, 16, 85, 178, 208, 30, 89, 251),
          U1(249, 48, 21, 133, 12, 119, 24, 202)
        }), _ARG_2_)
        _ARG_0_.PassRecordList = _ARG_2_
      else
        ShowNotice(_ARG_1_)
      end
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_RECORD_RSP, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPassRecordList"] = function(_ARG_0_)
    do
      do return _ARG_0_.PassRecordList end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBuyPassStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.BeforePurchaseState = _ARG_1_
      _ARG_0_.NowPurchaseState = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowPrivilegeSlapFace"] = function(_ARG_0_)
    do
      if not _ARG_0_.BeforePurchaseState or not _ARG_0_.NowPurchaseState then
        return true
      end
      if _ARG_0_.BeforePurchaseState == Enum_UGCWOWPassBuyType.Elite and _ARG_0_.NowPurchaseState == Enum_UGCWOWPassBuyType.Plus then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowPlayAnimType"] = function(_ARG_0_)
    do
      if not _ARG_0_.BeforePurchaseState or not _ARG_0_.NowPurchaseState then
        return (_ENV())
      end
      if _ARG_0_.BeforePurchaseState == U1.Enum_UGCWOWPassBuyType.None and _ARG_0_.NowPurchaseState == U1.Enum_UGCWOWPassBuyType.Elite then
        return (_ENV(212, 48, 9, 132, 20, 113, 46, 210, 203, 225, 104))
      elseif _ARG_0_.BeforePurchaseState == U1.Enum_UGCWOWPassBuyType.None and _ARG_0_.NowPurchaseState == U1.Enum_UGCWOWPassBuyType.Plus then
        return (_ENV(212, 48, 9, 132, 20, 113, 59, 210, 215, 230))
      elseif _ARG_0_.BeforePurchaseState == U1.Enum_UGCWOWPassBuyType.Elite and _ARG_0_.NowPurchaseState == U1.Enum_UGCWOWPassBuyType.Plus then
        return (_ENV(223, 51, 14, 149, 37, 74, 4, 238, 206, 224, 126))
      end
      do return (_ENV()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPlusGiveLevelCount"] = function(_ARG_0_)
    do
      if _ARG_0_.UGCPassInfo then
        return _ARG_0_.UGCPassInfo.give_level_count
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
