do return {
  RECOMMEND_RES_KEY = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(174, 240, 24, 33, 97, 231, 15, 68, 182, 198, 194, 229, 171, 109, 21, 120, 85),
  SAVED_CACHE_KEY = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(175, 244, 13, 43, 104, 245, 9, 75, 177, 209, 213, 255, 179, 119, 7),
  LOGIN_DELETE_KEY = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(176, 250, 28, 39, 98, 245, 14, 79, 190, 220, 196, 229, 167, 121, 27, 100),
  savedCacheSize = 0,
  savedAllDirSize = {},
  appSize = 0,
  otherPaksSize = 0,
  deviceFreeSpace = 0,
  lastUpdateSpaceTime = 0,
  spaceAlertSwitch = false,
  spaceAlertSize = 0,
  spaceAlertCDTime = 0,
  spaceAlertTime = 0,
  SilentCleanup = false,
  spaceAlertAutoDelete = false,
  needQuitGame = false,
  PakMountTimes = nil,
  ignoreFileDeleteNotify = false,
  uploadDeleteCrashFileList = {},
  CacheDirs = {},
  ExtraDirs = {},
  AllDirs = {},
  cacheSizeGetting = false,
  CacheSizeCallbacks = {},
  ["CheckRestartAfterDeleteRes"] = function()
    if not needQuitGame then
      return
    end
    if not U1.require((U1.table.concat({
      U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
      U2(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
    }))).IsFITVersion() then
    end
    return
  end,
  ["OnGameStateChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.current ~= GameStatus.Lobby then
        U1.Destroy()
      end
      if _ARG_2_.current == GameStatus.Lobby and _ARG_2_.pre == GameStatus.Login then
        U1.InitSpaceAlertSize()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Destroy"] = function()
    if TimerDeletePak then
      TimerDeletePak = nil
    end
    return
  end,
  ["InitSpaceAlertSize"] = function()
    log(bWriteLog and U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 149, 244, 83, 78, 177, 249, 225, 211, 141, 99, 34, 72, 110, 225, 104, 39, 182, 239, 4))
    if require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
      U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
    }))).IsFITVersion() then
      U2.spaceAlertSwitch = true
    end
    if require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
      U1(143)
    }))).LoadFileToTable_N(require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
      U1(143)
    }))).ePlayerPrefsType.eSpaceAlertSize) and next((require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
      U1(143)
    }))).LoadFileToTable_N(require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
      U1(143)
    }))).ePlayerPrefsType.eSpaceAlertSize))) then
      U2.spaceAlertSwitch = require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).ePlayerPrefsType.eSpaceAlertSize).spaceAlertSwitch
      U2.spaceAlertSize = require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).ePlayerPrefsType.eSpaceAlertSize).spaceAlertSize
      U2.spaceAlertTime = require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).ePlayerPrefsType.eSpaceAlertSize).spaceAlertTime or 0
      U2.spaceAlertAutoDelete = require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).ePlayerPrefsType.eSpaceAlertSize).spaceAlertAutoDelete == true
    end
    if require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
      U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
    }))).IsFITVersion() then
      U2.spaceAlertAutoDelete = false
    end
    return
  end,
  ["SaveSpaceAlertData"] = function()
    return
  end,
  ["SetSpaceAlert"] = function(_ARG_0_, _ARG_1_)
    do
      spaceAlertSwitch = _ARG_0_
      spaceAlertSize = _ARG_1_
      U1.log(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 143, 255, 78, 105, 146, 232, 227, 213, 169, 78, 43, 95, 104, 187, 27, 61, 187, 227, 94, 73),
        U2(148, 136, 126, 29, 0, 138, 57, 99, 136, 252, 173, 133, 139)
      }), U1.tostring(_ARG_0_), U1.tostring(_ARG_1_)))
      SaveSpaceAlertData()
      if not _ARG_0_ then
        U1.require((U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).BanAutoDownload = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SaveUISpaceAlertTime"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        SetSpaceAlertAddTime(518400)
      else
        SetSpaceAlertAddTime()
      end
      SaveSpaceAlertData()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSizeAlertUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 143, 242, 85, 77, 177, 224, 250, 213, 169, 78, 43, 95, 104, 192, 114, 96))
      if UIManager.IsUIShow(UIManager.UI_Config.Download_Main_UIBP) then
        return
      end
      if U2.spaceAlertAutoDelete and _ARG_0_ then
        if next((require((table.concat({
          U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 212, 141, 78, 43, 89, 121, 187, 87, 33, 171, 227, 73, 117),
          U1(152, 218, 44, 0, 64, 197, 43, 110, 173, 253, 245, 204, 157, 70, 59)
        }))).GetDeleteList((require((table.concat({
          U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 212, 141, 78, 43, 89, 121, 187, 87, 33, 171, 227, 73, 117),
          U1(152, 218, 44, 0, 64, 197, 43, 110, 173, 253, 245, 204, 157, 70, 59)
        }))).GetMainSwitchData(_ARG_0_, U2.GetDeleteTargetSize(_ARG_0_)))))) then
          U2.SilentCleanup = true
        else
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSpaceAlertAddTime"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or 0
      if FuncUtil.GetServerTimeInSec() + _ARG_0_ <= U2.spaceAlertTime then
        return
      end
      U2.spaceAlertTime = FuncUtil.GetServerTimeInSec() + _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsGameSizeNeedAlert"] = function()
    if spaceAlertSwitch and GetSpaceAlertSize() > 0 and U1.tonumber(U1.string.format(U2(217, 155, 106, 8), GetGameSize() / 1000)) >= GetSpaceAlertSize() then
      U1.require((U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).BanAutoDownload = true
      return true
    end
    do return false end
    return
  end,
  ["GetCurPaksSize"] = function()
    do return 0 + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):GetAllMapCurSize() + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager):GetAllODPakCurSize() + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetAllResCurSize() + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager):GetAllUGCPakCurSize() + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_prefetch_manager):GetSize() / U1.MB, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):GetAllMapCurSize(), ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager):GetAllODPakCurSize(), ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetAllResCurSize(), ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager):GetAllUGCPakCurSize(), ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_prefetch_manager):GetSize() / U1.MB end
    return
  end,
  ["GetAppsize"] = function()
    if appSize ~= 0 then
      return appSize
    end
    if not U1.PufferDownloader.GetPufferFileListJson() or U1.next((U1.PufferDownloader.GetPufferFileListJson())) == nil then
      return 0
    end
    appSize = U1.tonumber(U1.PufferDownloader.GetPufferFileListJson().AppSize) or 0
    do return appSize end
    return
  end,
  ["GetOtherPaksSize"] = function()
    if otherPaksSize ~= 0 then
      return otherPaksSize
    end
    goto lbl_109
    ::lbl_109::
    otherPaksSize = 0 + U1.Client.GetFileSizeOnDisk(U1.Client.ProjectSavedDir() .. U1.PufferDownloader.DOWNLOAD_DIR_RELATIVE .. U2(163, 216, 58, 0, 77, 205, 47, 120)) / 1024.0
    do return otherPaksSize end
    return
  end,
  ["GetGameSize"] = function()
    do return GetAppsize() + GetCurPaksSize() + GetOtherPaksSize() + GetSavedCacheSize() / U3.MB end
    return
  end,
  ["GetUnDeleteSize"] = function()
    do return GetAppsize() + U1.require((U1.table.concat({
      U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 187, 75, 59, 170, 236, 79, 88),
      U2(163, 216, 58, 0, 77, 205, 47, 120)
    }))).GetSize(U3.ENUM_DownloadType.ODPAK, U1.require((U1.table.concat({
      U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 220, 135, 69, 39, 78, 67, 249, 84, 44, 174, 243, 117, 78),
      U2(147, 194, 53, 2, 67, 203, 46, 111, 128)
    }))).GetUserEquipmentPaks()) / U3.MB + U1.require((U1.table.concat({
      U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 187, 75, 59, 170, 236, 79, 88),
      U2(163, 216, 58, 0, 77, 205, 47, 120)
    }))).GetSize(U3.ENUM_DownloadType.RES, {
      U3.FIT_COMMERCIAL_CORE_DEP
    }) / U3.MB end
    return
  end,
  ["GetDeleteCfgSelectMap"] = function()
    if not (require((U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).SmartDownloadCfg.DeleteCfg and require((U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).SmartDownloadCfg.DeleteCfg.selectMap) or not next(require((U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).SmartDownloadCfg.DeleteCfg and require((U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).SmartDownloadCfg.DeleteCfg.selectMap) then
      return nil
    end
    if not UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP) or not UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP).allItemData then
      return nil
    end
    goto lbl_108
    if 148 then
      if (UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP).mergeBundleDataMap or {})[142] then
        goto lbl_102
        ::lbl_102::
      else
      end
    end
    ::lbl_108::
    if not false then
      return nil
    end
    do return {} end
    return
  end,
  ["GetSelectMapSize"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return nil
      end
      if not UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP) or not UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP).allItemData then
        return nil
      end
      goto lbl_34
      if nil and UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP).allItemData[nil] and 0 < (nil and UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP).allItemData[nil]).cSize then
      end
      ::lbl_34::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 + (nil and UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP).allItemData[nil]).cSize end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSavedCacheDirs"] = function()
    if Client and not next(U1.CacheDirs) then
      U1.CacheDirs = {
        Client.ProjectSavedDir() .. U2(176, 220, 45, 11, 122, 195, 46, 111, 157, 182),
        Client.ProjectSavedDir() .. U2(172, 212, 53, 10, 67, 216, 43, 37),
        Client.ProjectSavedDir() .. U2(177, 218, 45, 7, 73, 217, 26, 107, 153, 221, 249, 210, 215),
        Client.ProjectContentDir() .. U2(177, 218, 45, 7, 73, 217, 26, 107, 153, 221, 249, 210, 215)
      }
      U1.ExtraDirs = {
        Client.ProjectSavedDir() .. U2(187, 212, 54, 11, 64, 207, 62, 37)
      }
    end
    do return U1.CacheDirs end
    return
  end,
  ["GetSavedCacheSize"] = function()
    do return savedCacheSize end
    return
  end,
  ["GetFitLobbyResKeys"] = function()
    if not require((table.concat({
      U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
      U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
    }))).IsFITVersion() then
      return nil
    end
    goto lbl_150
    goto lbl_148
    ::lbl_148::
    ::lbl_150::
    do return {
      [U2.FIT_LOBBY_RES_KEY] = true,
      [U1(140, 192, 61, 8, 73, 216, 21, 104, 135, 247, 244, 204, 157)] = true
    } end
    return
  end,
  ["DeletedFitLobbyRes"] = function()
    log_format((U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 152, 255, 86, 95, 150, 236, 228, 246, 129, 86, 2, 66, 126, 247, 66, 28, 169, 249, 4)))
    goto lbl_123
    goto lbl_121
    ::lbl_121::
    ::lbl_123::
    return
  end,
  ["TryShowFitLobbyResDeleteConfirm"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_ then
        return false
      end
      if not GetFitLobbyResKeys() then
        return false
      end
      if not U1.require((U1.table.concat({
        U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 214, 129, 86, 96, 65, 115, 242, 82, 45, 147, 236, 67, 94),
        U2(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)
      }))).IsFitLobbyResDownloaded() then
        return false
      end
      if not GetFitLobbyResKeys()[_ARG_0_] then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = U1[239]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[112]
    end
  end,
  ["OnGetCacheSizeCallback"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil or _ARG_0_ == nil then
        return
      end
      if not cacheSizeGetting then
        return
      end
      _ARG_1_ = _ARG_1_ * 1024
      U1.log(U1.bWriteLog and U1.string.format(U1.table.concat({
        U2(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 147, 244, 125, 95, 150, 202, 225, 211, 128, 71, 29, 68, 102, 240, 120, 47, 160, 230, 72, 75),
        U2(159, 222, 117, 78, 72, 195, 56, 55, 215, 234, 188, 128, 156, 91, 44, 0, 41, 246)
      }), U1.tostring(_ARG_0_), U1.tostring(_ARG_1_ / U3.MB)))
      savedAllDirSize[_ARG_0_] = _ARG_1_
      if not U4[_ARG_0_] then
        U5 = U5 + _ARG_1_
      end
      U6[_ARG_0_] = nil
      if not U1.next(U6) then
        savedCacheSize = U5
        U1.log_format(U1.table.concat({
          U2(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 147, 244, 125, 95, 150, 202, 225, 211, 128, 71, 29, 68, 102, 240, 120, 47, 160, 230, 72, 75),
          U2(159, 222, 117, 78, 124, 223, 44, 108, 151, 235, 212, 197, 148, 87, 42, 88, 65, 228, 69, 63, 187, 255, 72, 20, 145, 232, 246, 213, 140, 97, 47, 78, 116, 240, 104, 39, 182, 239, 23, 15),
          U2(143)
        }), savedCacheSize)
        cacheSizeGetting = false
        CacheSizeCallbacks = {}
        goto lbl_219
        ::lbl_219::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSavedCacheSizeAsync"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 155, 255, 78, 105, 131, 255, 229, 212, 171, 67, 45, 69, 121, 198, 82, 52, 169, 203, 89, 83),
        U1(146, 214, 117)
      }))
      if U2.savedCacheSize ~= 0 then
        _ARG_0_()
        return
      end
      if U2.cacheSizeGetting then
        table.insert(U2.CacheSizeCallbacks, _ARG_0_)
        return
      end
      U2.cacheSizeGetting = true
      U2.CacheSizeCallbacks = {_ARG_0_}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDirSize"] = function(_ARG_0_)
    do
      do return import((U1(175, 212, 45, 11, 72, 236, 35, 102, 151, 204, 228, 201, 148))).GetDirSize(_ARG_0_, true) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedShowCacheDelete"] = function()
    do return GetSavedCacheSize() >= 100 * U1.MB end
    return
  end,
  ["NeedShowCacheDeleteReddot"] = function()
    if U2.NeedShowCacheDelete() then
      if not require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).ePlayerPrefsType.eCacheReddot) then
        return true
      elseif not ({["CacheReddot"] = false}).CacheReddot then
        return true
      end
    end
    do return false end
    return
  end,
  ["UpdateDeviceFreeSpace"] = function(_ARG_0_)
    do
      if not _ARG_0_ and require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 42, 84, 97, 224, 116, 43, 168, 243, 86))).GetServerTimeInSec() - U2.lastUpdateSpaceTime <= 10 then
        return
      end
      U2.deviceFreeSpace = Client.GetDeviceFreeSpace()
      U2.lastUpdateSpaceTime = require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 42, 84, 97, 224, 116, 43, 168, 243, 86))).GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDeviceFreeSpace"] = function()
    UpdateDeviceFreeSpace(deviceFreeSpace == 0)
    do return deviceFreeSpace end
    return
  end,
  ["HaveEnoughSpace"] = function(_ARG_0_, _ARG_1_)
    do
      UpdateDeviceFreeSpace()
      if U1._G.IsEditor or deviceFreeSpace >= 1000 then
        return true
      end
      if IsShowDeleteUI() then
        return false
      end
      if deviceFreeSpace - 100 <= 0 then
        U1.require((U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).BanAutoDownload = true
        return false
      end
      if _ARG_0_ == U3.ENUM_DownloadType.MAP or _ARG_0_ == U3.ENUM_DownloadType.RES then
        if 0 >= deviceFreeSpace - U1.require((U1.table.concat({
          U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 187, 75, 59, 170, 236, 79, 88),
          U2(163, 216, 58, 0, 77, 205, 47, 120)
        }))).GetSize(_ARG_0_, _ARG_1_) / U3.MB then
          U1.require((U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 192, 157, 68, 40, 72, 110, 202, 72, 57, 165, 254, 73, 66))).BanAutoDownload = true
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowDeleteUI"] = function()
    if UIManager.IsUIShow(UIManager.UI_Config.notify_recommend_delete) then
      return true
    end
    if UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP) and not UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP):IsViewMode() then
      return true
    end
    do return false end
    return
  end,
  ["ShowDeleteUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      printf(table.concat({
        U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 143, 242, 85, 77, 166, 236, 236, 213, 156, 71, 27, 100, 50, 181, 89, 28, 169, 233, 69, 71),
        U1(145, 208, 53, 10, 17, 143, 57, 38, 210, 237, 255, 212, 153, 94, 13, 84, 118, 224, 22, 123, 175, 182, 26, 89, 141, 237, 229, 141, 205, 81, 98, 13, 117, 225, 94, 35, 155, 226, 67, 94),
        U1(153, 217, 50, 29, 88, 151, 111, 121, 222, 185, 228, 193, 138, 85, 59, 73, 95, 236, 81, 59, 225, 191, 73)
      }), tostring(_ARG_0_), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_), tostring(_ARG_4_))
      if not GameStatus.InSupportDownloadState() then
        log(bWriteLog and table.concat({
          U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 143, 242, 85, 77, 166, 236, 236, 213, 156, 71, 27, 100, 50, 181, 85, 33, 184, 170, 89, 95),
          U1(140, 197, 52, 28, 88, 138, 46, 101, 133, 247, 252, 207, 153, 86, 126, 78, 120, 228, 95, 59)
        }))
        return
      end
      if require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 127, 38, 145, 243, 73, 73, 139, 230, 238, 158, 132, 77, 41, 68, 127, 202, 67, 35, 165, 249, 89, 67),
        U1(147, 219, 4, 3, 77, 195, 36)
      }))).bEnterXMissionReq then
        return
      end
      if _ARG_4_ == nil then
        _ARG_4_ = U2.GetDeleteTargetSize(_ARG_3_)
      end
      if _ARG_0_ or GameStatus.GetGameStatus() == GameStatus.Login or GameStatus.GetGameStatus() == GameStatus.None then
        return
      end
      if UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP) and UIManager.GetUI(UIManager.UI_Config.Download_Main_UIBP):IsShow() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDeleteHintMsgBox"] = function(_ARG_0_, _ARG_1_)
    do
      if Client.GetDevicePlatformName() == U1(181, 250, 8) or _ARG_1_ == 0 then
      elseif Client.GetDevicePlatformName() ~= U1(181, 250, 8) or _ARG_1_ == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDeleteTargetSize"] = function(_ARG_0_)
    do
      if _ARG_0_ ~= nil then
        if U1.CDataTable.GetTableByFilter(U2(174, 208, 56, 1, 65, 199, 47, 100, 150, 221, 245, 204, 157, 70, 59, 105, 109, 231, 71, 59), U2(184, 208, 45, 7, 79, 207, 30, 99, 151, 235), U1.import((U2(175, 225, 30, 22, 88, 216, 43, 77, 147, 244, 245, 233, 150, 65, 42, 92, 98, 230, 78))).GetInstance():GetDeviceLevel() + 1, U2(181, 198, 29, 7, 88, 252, 47, 120, 129, 240, 255, 206), (U1.require((U1.table.concat({
          U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
          U2(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
        }))).IsFITVersion())) then
          goto lbl_317
          if GetDeviceFreeSpace() / 1000 <= (198).Condition and GetSpaceAlertSize() > (198).TargetNumber then
            goto lbl_319
          elseif GetSpaceAlertSize() > (198).TargetNumber then
          end
          ::lbl_317::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_319::
        if 0 >= (198).TargetNumber * 1000 then
        end
        if 0 > GetGameSize() - 10000 then
        end
        if testDeleteSize then
        end
      end
      do return testDeleteSize end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteODPak"] = function(_ARG_0_)
    do
      if Client.IsODPakMonted((string.gsub(_ARG_0_, U1(179, 241, 11, 15, 71, 217, 101), (U1())))) then
        return false
      end
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager).itemToPaks = {}
      if GCPufferDownloader.DeleteFile(Client.ProjectSavedDir() .. PufferDownloader.DOWNLOAD_DIR_RELATIVE .. _ARG_0_) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteMap"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and string.format(U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 152, 255, 86, 95, 150, 236, 205, 209, 152, 2, 35, 76, 108, 222, 94, 55, 246, 175, 89), _ARG_0_))
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).MapPaks[_ARG_0_] or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).MapPaks[_ARG_0_].notInPuffer then
        return false
      end
      goto lbl_241
      ::lbl_241::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ;(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 102, 157, 254, 249, 195, 214, 126, 49, 90, 101, 230, 123, 50, 189, 227, 95, 72, 178, 251, 229, 214, 155, 12, 62, 65, 125, 236, 94, 60, 188, 248, 79, 76),
        U1(143)
      }))).ePlayerPrefsType.eDeleteHistory) or {})[ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).MapPaks[_ARG_0_].filepre] = true
      if not _ARG_1_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteRes"] = function(_ARG_0_)
    do
      log_format(U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 152, 255, 86, 95, 150, 236, 210, 213, 155, 12, 110, 95, 121, 230, 112, 43, 181, 183, 15, 89), _ARG_0_)
      if require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 214, 129, 86, 96, 65, 115, 242, 82, 45, 147, 236, 67, 94),
        U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)
      }))).IsCommercialRes(_ARG_0_) then
        return false
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_) or not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_).pakName then
        return false
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_).totalSize or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_).totalSize <= 0 then
        return false
      end
      goto lbl_394
      ::lbl_394::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_).percent = 0
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_).state = U2.ENUM_DownloadState.Not
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(_ARG_0_).curSize = 0
      if _ARG_0_ == U1(142, 208, 40, 49, 89, 199, 45, 126, 151, 225, 253, 196) then
        U3.needQuitGame = true
      elseif _ARG_0_ == U2.FIT_SHADER_KEY then
        U3.needQuitGame = true
      end
      do return true end
      do return end
      _ARG_0_ = U1[115]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteUGCPak"] = function(_ARG_0_)
    do
      if Client.IsODPakMonted((string.gsub(_ARG_0_, PufferDownloader.DOWNLOAD_UGCPAKS_RELATIVE, (U1())))) then
        return false
      end
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_ugcpak_manager).assetToPaks = {}
      if GCPufferDownloader.DeleteFile(Client.ProjectSavedDir() .. PufferDownloader.DOWNLOAD_DIR_RELATIVE .. _ARG_0_) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeletePak"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 152, 255, 86, 95, 150, 236, 208, 209, 131, 2, 62, 76, 119, 219, 90, 35, 169, 176, 15, 89), _ARG_0_))
      if Client.IsFileExistsWithOutPakCheck(Client.ProjectSavedDir() .. U2.PAKS_RELATIVE_DIR .. _ARG_0_) then
        if GCPufferDownloader.DeleteFile(Client.ProjectSavedDir() .. U2.PAKS_RELATIVE_DIR .. _ARG_0_) then
        end
      end
      do return (GCPufferDownloader.DeleteFile(Client.ProjectSavedDir() .. U2.PAKS_RELATIVE_DIR .. _ARG_0_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteSavedCache"] = function()
    goto lbl_11
    ::lbl_11::
    savedCacheSize = 0
    return
  end,
  ["AsynDeletePaks"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log_tree(U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 157, 233, 67, 84, 166, 236, 236, 213, 156, 71, 30, 76, 119, 230), _ARG_0_)
      Client.AddCrashContextData(30, U1(189, 198, 34, 0, 104, 207, 38, 111, 134, 252, 192, 193, 147, 65), false, 1200)
      if require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
        U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
      }))).IsFITVersion() then
      end
      U2.WaitDeleteMap = {}
      goto lbl_218
      U2.WaitDeleteMap[U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)] = U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)
      ::lbl_218::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not next(U2.WaitDeleteMap) then
        return
      end
      if not U2.TimerDeletePak then
        if _ARG_2_ then
        end
        U2.ignoreFileDeleteNotify = true
        U2.TimerDeletePak = require((U1(159, 218, 54, 3, 67, 196, 100, 126, 155, 244, 245, 255, 140, 91, 61, 86, 105, 247))).AddTimerLoop(0, function()
          if next(U1.WaitDeleteMap) then
            while 0 < 30 and next(U1.WaitDeleteMap) do
              if next(U1.WaitDeleteMap) == U1.SAVED_CACHE_KEY or next(U1.WaitDeleteMap) == U1.SAVED_CACHE_KEY then
              elseif next(U1.WaitDeleteMap) == U1.LOGIN_DELETE_KEY then
              elseif next(U1.WaitDeleteMap) == U2.ENUM_DownloadType.ODPAK then
                if U1.DeleteODPak(next(U1.WaitDeleteMap)) then
                  U3.ResDeleteKey[next(U1.WaitDeleteMap)] = true
                end
              elseif next(U1.WaitDeleteMap) == U2.ENUM_DownloadType.MAP then
                if U5.Starts(next(U1.WaitDeleteMap)) then
                  if IsWoWEditor then
                    goto lbl_137
                    ::lbl_137::
                  end
                else
                end
                U3.ResDeleteKey[next(U1.WaitDeleteMap)] = true
              elseif next(U1.WaitDeleteMap) == U2.ENUM_DownloadType.RES then
                if next(U1.WaitDeleteMap) == U2.LOBBY_MAPKEY then
                  if IsWoWEditor and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager).LobbyResKeyList then
                    goto lbl_182
                    ::lbl_182::
                  end
                else
                end
                U3.ResDeleteKey[next(U1.WaitDeleteMap)] = true
              elseif next(U1.WaitDeleteMap) == U2.ENUM_DownloadType.PREFETCH then
                goto lbl_224
                ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_prefetch_manager).PrefetchPaks[ipairs(require((table.concat({
                  U6(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 210, 157, 76, 42, 65, 121, 187, 87, 33, 171, 227, 73, 117),
                  U6(140, 192, 61, 8, 73, 216, 21, 104, 135, 247, 244, 204, 157)
                }))).GetPackDownloadTypeAndResList(next(U1.WaitDeleteMap)))].state = U2.ENUM_DownloadState.Not
                ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_prefetch_manager).PrefetchPaks[ipairs(require((table.concat({
                  U6(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 210, 157, 76, 42, 65, 121, 187, 87, 33, 171, 227, 73, 117),
                  U6(140, 192, 61, 8, 73, 216, 21, 104, 135, 247, 244, 204, 157)
                }))).GetPackDownloadTypeAndResList(next(U1.WaitDeleteMap)))].percent = 0
                ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_prefetch_manager).PrefetchPaks[ipairs(require((table.concat({
                  U6(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 210, 157, 76, 42, 65, 121, 187, 87, 33, 171, 227, 73, 117),
                  U6(140, 192, 61, 8, 73, 216, 21, 104, 135, 247, 244, 204, 157)
                }))).GetPackDownloadTypeAndResList(next(U1.WaitDeleteMap)))].curSize = 0
                ::lbl_224::
              elseif next(U1.WaitDeleteMap) == U2.ENUM_DownloadType.UGCPAK then
              end
              U1.WaitDeleteMap[next(U1.WaitDeleteMap)] = nil
            end
          else
            U3:UploadMapStateByDeleteNotify()
            if U7 then
              logic_connection_waiting:Hide(1)
            end
            if U8 then
              U8(U9)
            end
            U10.RemoveTimer(U1.TimerDeletePak)
            U1.TimerDeletePak = nil
            U1.ignoreFileDeleteNotify = false
          end
          return
        end, TIMER_INFINITE, 0.1)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteExpiredVideo"] = function()
    goto lbl_127
    if CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252))).VideoState == 2 then
      if string.find(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) or string.find(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) then
        if string.match(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) and string.match(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) ~= U1() then
        end
      elseif string.find(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) and string.match(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) and string.match(CDataTable.GetTable((U1(170, 220, 63, 11, 67, 254, 43, 104, 158, 252)))) ~= U1() then
      end
    end
    ::lbl_127::
    goto lbl_321
    ::lbl_321::
    goto lbl_466
    ::lbl_466::
    return
  end,
  ["GetPakMountTime"] = function()
    if not PakMountTimes then
      PakMountTimes = {}
      goto lbl_74
      PakMountTimes[U1.require((U2(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(3, (U2(208)))[1]] = U1.tonumber(U1.require((U2(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(3, (U2(208)))[2])
      ::lbl_74::
    end
    do return PakMountTimes end
    return
  end,
  ["DeleteExpiredMap"] = function()
    if not PufferDownloader.PufferJsonDownloadReturn then
      return
    end
    if not PufferDownloader.GetPufferFileListJson() or not next((PufferDownloader.GetPufferFileListJson())) then
      return
    end
    goto lbl_234
    if string.match(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3]))))) and not PufferDownloader.GetPufferFileListJson().version_mapping[string.match(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3]))))) .. U1(163, 209, 62, 8, 77, 223, 38, 126)] and tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))[#require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))], (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))[#require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))], (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))[#require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))], (U1(210)))[3])) and tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])) > tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))[#require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))], (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))[#require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))], (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))[#require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(tostring((tonumber(string.format(U1(217, 198, 126, 29, 9, 217), require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[1], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[2], require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(Client.GetApplicationVersion(), (U1(210)))[3])))))], (U1(210)))[3])) then
    end
    ::lbl_234::
    return
  end,
  ["GetSpaceAlertSize"] = function()
    if spaceAlertSize == 0 then
      if U1.CDataTable.GetTableByFilter(U2(174, 208, 56, 1, 65, 199, 47, 100, 150, 221, 245, 204, 157, 70, 59, 105, 109, 231, 71, 59), U2(181, 198, 29, 7, 88, 252, 47, 120, 129, 240, 255, 206), (U1.require((U1.table.concat({
        U2(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
        U2(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
      }))).IsFITVersion())) ~= nil then
        goto lbl_122
        if GetDeviceFreeSpace() / 1000 <= (29).Condition then
        else
          ::lbl_122::
        end
      end
    end
    do return (29).StartupThreshold end
    return
  end,
  ["IsFitLobbyResFile"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return false
      end
      if _ARG_1_[_ARG_0_] then
        return true
      end
      if not require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Starts(_ARG_0_, U2.MAP_PREFIX) and not require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Starts(_ARG_0_, U2.RES_FILE_PREFIX) then
        return false
      end
      goto lbl_67
      if require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Starts(_ARG_0_, 54) and string.find(_ARG_0_, _ARG_2_, 1, true) then
        return true
      end
      ::lbl_67::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDeleteFileNotify"] = function(_ARG_0_)
    do
      log_tree(U1(154, 220, 55, 11, 96, 195, 57, 126, 210, 164, 176), _ARG_0_)
      if not _ARG_0_ then
        return
      end
      if require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
        U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
      }))).IsFITVersion() then
      end
      goto lbl_415
      if require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Starts(U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)) then
        ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_odpak_manager).itemToPaks = {}
        ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).ResDeleteKey[U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)] = true
      elseif require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Starts(U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)) then
        if require((table.concat({
          U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
          U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
        }))).IsFITVersion() and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(U2.FIT_SHADER_KEY) then
          ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(U2.FIT_SHADER_KEY).curSize = 0
          ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(U2.FIT_SHADER_KEY).state = U2.ENUM_DownloadState.Not
          ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):GetResData(U2.FIT_SHADER_KEY).percent = 0
        end
      end
      if require((table.concat({
        U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 155, 93, 48, 91, 101, 226, 5, 29, 176, 243, 95, 84, 150, 196, 225, 211, 154, 77, 61, 3, 76, 224, 89, 34, 165, 249, 66, 120),
        U1(153, 210, 50, 1, 66, 231, 43, 105, 128, 246, 227)
      }))).IsFITVersion() then
        if U3.IsFitLobbyResFile(U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)) then
          if require((table.concat({
            U1(159, 217, 50, 11, 66, 222, 100, 121, 158, 236, 241, 142, 148, 93, 57, 84, 111, 171, 79, 49, 171, 244, 86, 85, 131, 237, 174, 214, 129, 86, 96, 65, 115, 242, 82, 45, 147, 236, 67, 94),
            U1(170, 208, 41, 29, 69, 197, 36, 85, 150, 246, 231, 206, 148, 93, 63, 89)
          }))).IsFitLobbyResDownloaded() then
          end
        end
      end
      ::lbl_415::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_426
      ::lbl_426::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if true then
      end
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteCheckAlways"] = function(_ARG_0_, _ARG_1_)
    do
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteCheckDaily"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ and _ARG_1_ then
        if _ARG_0_.checkDay ~= require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 42, 84, 97, 224, 116, 43, 168, 243, 86))).GetServerTimeInSec() // 86400 then
          _ARG_1_.checkDay = require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 42, 84, 97, 224, 116, 43, 168, 243, 86))).GetServerTimeInSec() // 86400
          return true
        else
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteCheckByVersion"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ and _ARG_1_ then
        if require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 40, 88, 126, 246, 66, 49, 178, 197, 79, 78, 139, 229))).CompareVersionStandard(_ARG_0_.checkVersion, (require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 40, 88, 126, 246, 66, 49, 178, 197, 79, 78, 139, 229))).GetAppVersion())) ~= 0 then
          _ARG_1_.checkVersion = require((U1(159, 217, 50, 11, 66, 222, 100, 105, 157, 244, 253, 207, 150, 28, 40, 88, 126, 246, 66, 49, 178, 197, 79, 78, 139, 229))).GetAppVersion()
          return true
        else
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ENV[210]
    end
  end,
  ["HandleDeleteStrategy"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 148, 251, 84, 94, 142, 236, 196, 213, 132, 71, 58, 72, 79, 225, 73, 47, 184, 239, 77, 83),
        U1(210, 149, 63, 7, 94, 151, 111, 121, 222, 185, 228, 201, 149, 87, 49, 72, 120, 193, 74, 39, 225, 191, 73)
      }), tostring(_ARG_0_), tostring(_ARG_1_)))
      if _ARG_0_ == nil then
        return
      end
      if type(_ARG_1_) == U1(146, 192, 54, 12, 73, 216) then
        if U2.startTime == nil then
          U2.startTime = {}
        end
        U2.startTime[_ARG_0_] = slua.getMiliseconds(), U2.startTime
      else
      end
      do return end
      _ARG_0_ = U1[243]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteLogicInLogin"] = function()
    log(bWriteLog and U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 152, 255, 86, 95, 150, 236, 204, 223, 143, 75, 45, 100, 114, 217, 84, 41, 165, 228, 4))
    goto lbl_342
    ::lbl_342::
    return
  end,
  ["HandleDeleteCrashFile"] = function()
    log_format((table.concat({
      U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 148, 251, 84, 94, 142, 236, 196, 213, 132, 71, 58, 72, 95, 231, 90, 61, 164, 204, 67, 70),
      U1(153, 155)
    })))
    if not HDmpveRemote.HDmpveRemoteConfigGetBool(U1(176, 218, 60, 7, 66, 238, 47, 102, 151, 237, 245, 227, 138, 83, 45, 85, 74, 236, 71, 59, 153, 244, 91, 88, 142, 236), true) then
      log_format((table.concat({
        U1(172, 192, 61, 8, 73, 216, 14, 111, 158, 252, 228, 197, 181, 83, 48, 92, 107, 224, 89, 112, 148, 251, 84, 94, 142, 236, 196, 213, 132, 71, 58, 72, 95, 231, 90, 61, 164, 204, 67, 70),
        U1(153, 155, 123, 28, 73, 199, 37, 126, 151, 185, 226, 197, 140, 71, 44, 83)
      })))
      return
    end
    U2.uploadDeleteCrashFileList = {}
    if not Client.IsFileExistsWithOutPakCheck(Client.ProjectSavedDir() .. U3.PAKS_RELATIVE_DIR .. U3.ODPAKS_RELATIVE_DIR .. U1(189, 198, 34, 0, 79, 230, 37, 107, 150, 240, 254, 199, 190, 91, 50, 88, 79, 247, 74, 45, 180, 180, 78, 66, 150)) then
      return
    end
    if Client.LoadFileToString(U3.PAKS_RELATIVE_DIR .. U3.ODPAKS_RELATIVE_DIR .. U1(189, 198, 34, 0, 79, 230, 37, 107, 150, 240, 254, 199, 190, 91, 50, 88, 79, 247, 74, 45, 180, 180, 78, 66, 150)) == U1() then
      return
    end
    if type((require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Split(require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).StrReplace(Client.LoadFileToString(U3.PAKS_RELATIVE_DIR .. U3.ODPAKS_RELATIVE_DIR .. U1(189, 198, 34, 0, 79, 230, 37, 107, 150, 240, 254, 199, 190, 91, 50, 88, 79, 247, 74, 45, 180, 180, 78, 66, 150)), U1(241), (U1())), (U1(246))))) == U1(136, 212, 57, 2, 73) then
      goto lbl_664
      if require((U1(159, 218, 54, 3, 67, 196, 100, 121, 134, 235, 249, 206, 159, 109, 43, 73, 101, 233))).Starts(57, U3.ODPAKS_RELATIVE_DIR) then
      else
      end
      if Client.GetODPakName(57) ~= U1() then
        if false then
        end
      end
      ::lbl_664::
    end
    return
  end
} end
return
