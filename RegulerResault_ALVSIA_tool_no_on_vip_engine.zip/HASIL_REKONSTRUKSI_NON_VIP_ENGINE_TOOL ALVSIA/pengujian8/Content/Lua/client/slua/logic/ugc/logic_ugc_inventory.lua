local logic_ugc_inventory = {}
logic_ugc_inventory.DefaultDressIcon = "/Game/Mod/Lobby/Split/WoW/Store/Texture/UGC_Homepage_WarehouseBG_000.UGC_Homepage_WarehouseBG_000"
local UGC_Inventory = require("client.slua.logic.ugc.ugc_Inventory")

function logic_ugc_inventory:ctor()
  self.SettingList = nil
  self.SelectTab = 1
  self.SelectSubTab = 1
  self.personal_depot = nil
  self.OldPersonalDepot = nil
  self.defaultItem = {
    [30101] = 301010003,
    [30102] = 301020003,
    [30103] = 301030001,
    [30104] = 301040003
  }
  self.bIsOwnCheckedMap = {}
end

function logic_ugc_inventory:SetOwnChecked(bool, tabID)
  if not self.bIsOwnCheckedMap then
    self.bIsOwnCheckedMap = {}
  end
  local key = tabID or self:GetSelectTabID()
  self.bIsOwnCheckedMap[key] = bool
end

function logic_ugc_inventory:GetOwnChecked(tabID)
  if not self.bIsOwnCheckedMap then
    self.bIsOwnCheckedMap = {}
  end
  local key = tabID or self:GetSelectTabID()
  return self.bIsOwnCheckedMap[key] or false
end

function logic_ugc_inventory:OpenInventoryWithItem(itemId)
  if not itemId then
    return
  end
  local tabId = self:GetTabIDDigits(itemId)
  if not self:CheckTabIdIsInventory(tabId) then
    return
  end
  local ui_jump_manager = require("client.common.uibase.ui_jump_manager")
  ui_jump_manager.OpenJumpModule(BP_ENUM_MODULE_UGC_DEPOT, {targetItemId = itemId})
end

function logic_ugc_inventory:MarkTargetItem(sortedData, targetItemId)
  if not targetItemId or not sortedData then
    return nil
  end
  for idx, itemData in ipairs(sortedData) do
    if itemData.ID == targetItemId then
      itemData.NowSelect = true
      return idx
    end
  end
  return nil
end

function logic_ugc_inventory:InventoryReq()
  local UGCPassHandler = require("client.network.Protocol.UGCPassHandler")
  UGCPassHandler.send_ugc_personal_setting_get_req()
end

function logic_ugc_inventory:InventoryRsp(ugc_personal_setting, ugc_personal_depot)
  if not ugc_personal_setting and not ugc_personal_depot then
    log(bWriteLog and "logic_ugc_inventory:InventoryRsp: invalid parameters")
    return
  end
  self.personal_depot = ugc_personal_depot
  self.SettingList = ugc_personal_setting
  for subtabID, defaultItemId in pairs(self.defaultItem) do
    if ugc_personal_depot and ugc_personal_depot[defaultItemId] then
      self.SettingList[301] = self.SettingList[301] or {}
      self.SettingList[301][subtabID] = self.SettingList[301][subtabID] or {}
      if not next(self.SettingList[301][subtabID]) then
        table.insert(self.SettingList[301][subtabID], defaultItemId)
        self:SaveOldPersonalDepot(defaultItemId)
        local res_ids = {}
        table.insert(res_ids, defaultItemId)
        local UGCPassHandler = require("client.network.Protocol.UGCPassHandler")
        UGCPassHandler.send_ugc_personal_setting_set_req(301, subtabID, res_ids)
      end
    end
  end
  self:SavePersonalDepot()
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_INVENTORY_RSP)
end

function logic_ugc_inventory:FindTabIndexByTabId(tabId)
  for tabIndex, tabData in pairs(UGC_Inventory.InventoryList) do
    if tabData.TabID == tabId then
      return tabIndex
    end
  end
  return nil
end

function logic_ugc_inventory:FindSubTabIndexBySubTabId(tabIndex, subTabId)
  local tabData = UGC_Inventory.InventoryList[tabIndex]
  if tabData then
    for subTabIndex, subTabData in pairs(tabData) do
      if type(subTabIndex) == "number" and subTabData.SubTabID == subTabId then
        return subTabIndex
      end
    end
  end
  return nil
end

function logic_ugc_inventory:SettingInventoryReq(inst_id, bool)
  local maintype = self:GetSelectTabID()
  local subtype = self:GetSelectSubTabID()
  local res_ids = {}
  if bool then
    if not inst_id then
      log(bWriteLog and "logic_ugc_inventory:SettingInventoryReq Ues inst_id is nil !!")
      return
    end
    log(bWriteLog and "logic_ugc_inventory:SettingInventoryReq Ues inst_id: " .. inst_id)
    table.insert(res_ids, inst_id)
  else
    res_ids = {}
  end
  local UGCPassHandler = require("client.network.Protocol.UGCPassHandler")
  UGCPassHandler.send_ugc_personal_setting_set_req(maintype, subtype, res_ids)
end

function logic_ugc_inventory:SettingInventoryRsp(maintype, subtype, subtype_list)
  if not self.SettingList then
    self.SettingList = {}
  end
  if not self.SettingList[maintype] then
    self.SettingList[maintype] = {}
  end
  if not subtype_list or not next(subtype_list) then
    self.SettingList[maintype][subtype] = {}
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_INVENTORY_SET_ITEM, false)
  else
    self.SettingList[maintype][subtype] = subtype_list
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_INVENTORY_SET_ITEM, true)
  end
end

function logic_ugc_inventory:GetInventoryList()
  if self.SettingList then
    return self.SettingList
  end
end

function logic_ugc_inventory:GetSubTabList()
  if self.SettingList and self.SettingList[self.SelectTab] then
    return self.SettingList[self.SelectTab]
  end
end

function logic_ugc_inventory:SetSelectTab(tab)
  if not tab then
    self.SelectTab = 1
  else
    self.SelectTab = tab
  end
end

function logic_ugc_inventory:SetSelectSubTab(subtab)
  if not subtab then
    self.SelectSubTab = 1
  else
    self.SelectSubTab = subtab
  end
end

function logic_ugc_inventory:GetSelectTab()
  return self.SelectTab
end

function logic_ugc_inventory:GetSelectTabID()
  return UGC_Inventory.InventoryList[self.SelectTab].TabID
end

function logic_ugc_inventory:GetSelectSubTab()
  return self.SelectSubTab
end

function logic_ugc_inventory:GetSelectSubTabID()
  return UGC_Inventory.InventoryList[self.SelectTab][self.SelectSubTab].SubTabID
end

function logic_ugc_inventory:SavePersonalDepot()
  if not self.personal_depot then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  self.OldPersonalDepot = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eUGCInventoryRedDot) or {}
  local hasNewItems = false
  local cacheDirty = false
  local isFirstLoad = not next(self.OldPersonalDepot)
  for itemId, itemData in pairs(self.personal_depot) do
    if not self.OldPersonalDepot[itemId] then
      self.OldPersonalDepot[itemId] = {isNew = true}
      hasNewItems = true
    end
    if self:IsDefaultItem(itemId) then
      self.OldPersonalDepot[itemId].isNew = false
    end
  end
  for itemId in pairs(self.OldPersonalDepot) do
    if not self.personal_depot[itemId] then
      self.OldPersonalDepot[itemId] = nil
      cacheDirty = true
    end
  end
  if isFirstLoad or hasNewItems or cacheDirty then
    PlayerPrefsSystem.SaveTableToFile_N(self.OldPersonalDepot, PlayerPrefsSystem.ePlayerPrefsType.eUGCInventoryRedDot)
  end
  self.hasNewItems = hasNewItems
  local bForceRefresh = isFirstLoad or hasNewItems or cacheDirty
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_INVENTORY_SELECT_TAB, bForceRefresh)
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_INVENTORY_SET_NEWITEM)
end

function logic_ugc_inventory:HasNewItems()
  return self.hasNewItems
end

function logic_ugc_inventory:SaveOldPersonalDepot(itemId)
  if not itemId or not self.OldPersonalDepot then
    return
  end
  local item = self.OldPersonalDepot[itemId]
  if not item or not item.isNew then
    return
  end
  item.isNew = false
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.SaveTableToFile_N(self.OldPersonalDepot, PlayerPrefsSystem.ePlayerPrefsType.eUGCInventoryRedDot)
  EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_INVENTORY_SET_NEWITEM)
end

function logic_ugc_inventory:IsDefaultItem(itemId)
  for _, defaultId in pairs(self.defaultItem) do
    if itemId == defaultId then
      return true
    end
  end
  return false
end

local DressEffectFields = {
  [30101] = {
    "InfoCardBluprint",
    "InfoCardBluprintAni",
    "InfoCardBackground"
  },
  [30102] = {"WidgetPath"},
  [30103] = {
    "WidgetAniPath",
    "WidgetPath_L",
    "WidgetPath_R"
  },
  [30104] = {
    "WidgetPath",
    "WidgetAniPath"
  },
  [30105] = {"WidgetPath"}
}

function logic_ugc_inventory:GetDefaultDressData(subTabID)
  local defaultID = self.defaultItem[subTabID]
  if not defaultID then
    return nil
  end
  if subTabID == 30101 then
    return self:GetInforCardData(defaultID)
  elseif subTabID == 30102 then
    return self:GetUpRoomTipsData(defaultID)
  elseif subTabID == 30103 then
    return self:GetMatchRoomDressData(defaultID)
  elseif subTabID == 30104 then
    return self:GetPlayerCommentData(defaultID)
  end
  return nil
end

function logic_ugc_inventory:IsDressResReady(data)
  if not data or not data.SelectSubTabID then
    return true
  end
  if self:IsDefaultItem(data.ID) then
    return true
  end
  local fields = DressEffectFields[data.SelectSubTabID]
  if not fields then
    return true
  end
  local pak_util = require("client.common.pak_util")
  for _, f in ipairs(fields) do
    local p = data[f]
    if p and p ~= "" and not pak_util.IsPufferDownloaded(p) then
      return false
    end
  end
  if data.ID then
    local PufferConst = require("client.slua.logic.download.puffer_const")
    local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
    if PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {
      data.ID
    }) ~= PufferConst.ENUM_DownloadState.Done then
      log(bWriteLog and "logic_ugc_inventory:IsDressResReady item dependency not ready, itemId=" .. tostring(data.ID))
      return false
    end
  end
  return true
end

function logic_ugc_inventory:IsIconResReady(iconPath)
  if not iconPath or iconPath == "" then
    return false
  end
  local pak_util = require("client.common.pak_util")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  if PufferManager.GetPakName(iconPath) == "" then
    return pak_util.IsFileExist(iconPath)
  end
  return pak_util.IsPufferDownloaded(iconPath)
end

function logic_ugc_inventory:IsHomePageDressResReady(Data)
  if not Data then
    return true
  end
  local CheckData = {
    ID = Data.ID,
    SelectSubTabID = 30101,
    InfoCardBluprint = Data.InfoCardBluprint,
    InfoCardBluprintAni = Data.InfoCardBluprintAni,
    InfoCardBackground = Data.InfoCardBackground
  }
  return self:IsDressResReady(CheckData)
end

function logic_ugc_inventory:IsPlayerCommentSkinReady(Data)
  if not Data then
    return true
  end
  local WidgetAniPath = Data.WidgetAniPath
  if not WidgetAniPath or WidgetAniPath == "" then
    local WidgetPath = Data.WidgetPath
    if not (not self:IsDefaultItem(Data.ID) and WidgetPath) or WidgetPath == "" then
      return true
    end
    local pak_util = require("client.common.pak_util")
    return pak_util.IsPufferDownloaded(WidgetPath)
  end
  local CheckData = {
    ID = Data.ID,
    SelectSubTabID = 30104,
    WidgetPath = Data.WidgetPath,
    WidgetAniPath = Data.WidgetAniPath
  }
  return self:IsDressResReady(CheckData)
end

function logic_ugc_inventory:GetSubTabData()
  local TimeUtil = require("client.common.time_util")
  local SelectTabID = self:GetSelectTabID()
  local SelectSubTabID = self:GetSelectSubTabID()
  local List = (self.SettingList or {})[SelectTabID] and self.SettingList[SelectTabID][SelectSubTabID] or {}
  local sortedData = {}
  local DataList = CDataTable.GetTable(UGC_Inventory.InventoryList[self.SelectTab][self.SelectSubTab].DataName)
  local NewDataList = {}
  for k, v in pairs(DataList) do
    if type(k) == "number" then
      table.insert(NewDataList, v)
    end
  end
  for k, v in pairs(NewDataList) do
    local Item = CDataTable.GetTableData("Item", v.ID)
    if not Item then
      log(bWriteLog and "logic_ugc_inventory:GetSubTabData Item config missing, id = " .. tostring(v.ID))
    end
    local IsUsing = false
    local cnt, expire_time
    local Now = false
    local isNew = false
    if List then
      for _, item in ipairs(List) do
        if item == v.ID then
          IsUsing = true
          break
        end
      end
    end
    if self.personal_depot and self.personal_depot[v.ID] then
      cnt = self.personal_depot[v.ID].cnt
      expire_time = self.personal_depot[v.ID].expire_time
      Now = true
    end
    if Now and self.OldPersonalDepot and self.OldPersonalDepot[v.ID] then
      isNew = self.OldPersonalDepot[v.ID].isNew
    end
    if v.IsShow == 1 or Now then
      table.insert(sortedData, {
        ID = v.ID,
        Name = v.Name,
        sort = v.sort,
        LoopAnimation = v.LoopAnimation,
        InfoCardBluprint = v.InfoCardBluprint,
        InfoCardBluprintAni = v.InfoCardBluprintAni,
        InfoCardBackground = v.InfoCardBackground,
        InterfaceBluprint = v.InterfaceBluprint,
        InterfaceBluprintAni = v.InterfaceBluprintAni,
        InterfaceBackground = v.InterfaceBackground,
        ShowIcon = v.ShowIcon,
        GetLink = v.GetLink,
        GetString = v.GetString,
        StartLinkTime = v.StartLinkTime,
        EndLinkTime = v.EndLinkTime,
        WidgetPath = v.WidgetPath,
        WidgetAniPath = v.WidgetAniPath,
        WidgetPath_L = v.WidgetPath_L,
        WidgetPath_R = v.WidgetPath_R,
        TxtColor = v.TxtColor,
        IconPath = v.IconPath,
        IsUsing = IsUsing,
        cnt = cnt,
        expire_time = expire_time,
        Now = Now,
        ItemQuality = Item and Item.ItemQuality or nil,
        ItemBigIcon = v.ShowIcon,
        isNew = isNew,
        SelectTabID = SelectTabID,
        SelectSubTabID = SelectSubTabID
      })
      if v.StartLinkTime and v.StartLinkTime ~= "" and v.EndLinkTime and v.EndLinkTime ~= "" then
        local Start = TimeUtil.TimeStringToUnixstamp(v.StartLinkTime)
        local End = TimeUtil.TimeStringToUnixstamp(v.EndLinkTime)
        local IsHidenLink = TimeUtil.UnixTimeBetween(Start, End)
        if IsHidenLink ~= 0 then
          sortedData[#sortedData].GetLink = ""
        end
      end
    end
  end
  table.sort(sortedData, function(a, b)
    if a.IsUsing and not b.IsUsing then
      return true
    elseif not a.IsUsing and b.IsUsing then
      return false
    end
    if a.Now and not b.Now then
      return true
    elseif not a.Now and b.Now then
      return false
    end
    return a.sort < b.sort
  end)
  return sortedData
end

function logic_ugc_inventory:NowGetList()
  local List = self:GetSubTabData()
  local NowList = {}
  for k, v in pairs(List) do
    if v.Now then
      table.insert(NowList, v)
    end
  end
  return NowList
end

function logic_ugc_inventory:HasNewItemsInTab(TabID)
  if not self.OldPersonalDepot or not TabID then
    return
  end
  for k, v in pairs(self.OldPersonalDepot) do
    if v.isNew then
      local NowTab = self:GetTabIDDigits(k)
      if NowTab == TabID then
        return true
      end
    end
  end
  return false
end

function logic_ugc_inventory:HasNewItemsAllTab()
  if not self.OldPersonalDepot then
    return
  end
  for k, v in pairs(self.OldPersonalDepot) do
    if v.isNew then
      return true
    end
  end
  return false
end

function logic_ugc_inventory:HasNewItemsInSubTab(SubTabID)
  if not self.OldPersonalDepot or not SubTabID then
    return
  end
  for k, v in pairs(self.OldPersonalDepot) do
    if v.isNew then
      local NowSubTab = self:GetSubTabIDDigits(k)
      if NowSubTab == SubTabID then
        return true
      end
    end
  end
  return false
end

function logic_ugc_inventory:GetTabIDDigits(itemId)
  local idStr = tostring(itemId or "")
  local firstThree = string.sub(idStr, 1, 3)
  return tonumber(firstThree) or 0
end

function logic_ugc_inventory:GetSubTabIDDigits(itemId)
  local idStr = tostring(itemId or "")
  local firstThree = string.sub(idStr, 1, 5)
  return tonumber(firstThree) or 0
end

function logic_ugc_inventory:CheckTabIdIsInventory(tabId)
  if type(tabId) ~= "number" then
    return false
  end
  if not UGC_Inventory or not UGC_Inventory.InventoryList then
    return false
  end
  for _, tabData in pairs(UGC_Inventory.InventoryList) do
    if tabData.TabID == tabId then
      return true
    end
  end
  return false
end

function logic_ugc_inventory:IsItemVisibleInInventory(itemId)
  if not itemId then
    return false
  end
  local tabId = self:GetTabIDDigits(itemId)
  local subTabId = self:GetSubTabIDDigits(itemId)
  local tabIndex = self:FindTabIndexByTabId(tabId)
  if not tabIndex then
    return false
  end
  local subTabIndex = self:FindSubTabIndexBySubTabId(tabIndex, subTabId)
  if not subTabIndex then
    return false
  end
  local dataName = UGC_Inventory.InventoryList[tabIndex][subTabIndex].DataName
  if not dataName then
    return false
  end
  local dataList = CDataTable.GetTable(dataName)
  if not dataList then
    return false
  end
  local configData
  for k, v in pairs(dataList) do
    if type(k) == "number" and v.ID == itemId then
      configData = v
      break
    end
  end
  if not configData then
    return false
  end
  if configData.IsShow == 1 then
    return true
  end
  if self.personal_depot and self.personal_depot[itemId] then
    return true
  end
  return false
end

function logic_ugc_inventory:GetPersonalData(ID)
  if self.personal_depot[ID] then
    return self.personal_depot[ID]
  end
end

function logic_ugc_inventory:GetInforCardData(ID)
  if not ID then
    return nil
  end
  return CDataTable.GetTableData(UGC_Inventory.DataNameList.Dress_HomePageConfig, ID)
end

function logic_ugc_inventory:GetUpRoomTipsData(ID)
  if not ID then
    return nil
  end
  return CDataTable.GetTableData(UGC_Inventory.DataNameList.Dress_UpInRoomNotice, ID)
end

function logic_ugc_inventory:GetPlayerCommentData(ID)
  if not ID then
    return nil
  end
  return CDataTable.GetTableData(UGC_Inventory.DataNameList.Dress_PlayerComment, ID)
end

function logic_ugc_inventory:GetMatchRoomDressData(ID)
  if not ID then
    return nil
  end
  return CDataTable.GetTableData(UGC_Inventory.DataNameList.Dress_MatchRoom, ID)
end

function logic_ugc_inventory:GetSelfRoomDecorationID()
  local settingList = self.SettingList or {}
  local dressList = settingList[301] and settingList[301][30103]
  if dressList and dressList[1] then
    return dressList[1]
  end
  return self.defaultItem[30103] or 301030001
end

function logic_ugc_inventory:GetEffectRootKey(parentPanel)
  if type(parentPanel) == "string" then
    return parentPanel
  end
  if not parentPanel then
    return nil
  end
  local model_util = require("client.common.model_util")
  local parts = {}
  local current = parentPanel
  while current and #parts < 16 do
    table.insert(parts, 1, model_util.GetObjectName(current))
    current = current.GetParent and current:GetParent()
  end
  return table.concat(parts, "/")
end

function logic_ugc_inventory:RemoveEffectSkin(parentUIBase, parentPanel)
  if not parentUIBase or not parentUIBase.effectRoots then
    return
  end
  local key = self:GetEffectRootKey(parentPanel)
  if not key then
    return
  end
  local EffectSkinRoots = parentUIBase.EffectSkinRoots
  local EffectList = EffectSkinRoots and EffectSkinRoots[key]
  if EffectList then
    for Index = #EffectList, 1, -1 do
      local ChildUI = table.remove(EffectList, Index)
      if ChildUI and not ChildUI._IsClosed then
        ChildUI:Close()
      end
    end
    EffectSkinRoots[key] = nil
    parentUIBase.effectRoots[key] = nil
    return
  end
  local ChildUI = parentUIBase.effectRoots[key]
  if ChildUI and not ChildUI._IsClosed then
    ChildUI:Close()
  end
  parentUIBase.effectRoots[key] = nil
end

function logic_ugc_inventory:AddEffectSkinByCreateChildWindow(parentUIBase, bgPath, parentPanel, aniName, extraData, effectKey)
  if not parentUIBase then
    log(bWriteLog and "logic_ugc_inventory.AddEffectSkinByCreateChildWindow invalid parentUIBase")
    return nil
  end
  if not parentUIBase.effectRoots then
    parentUIBase.effectRoots = {}
  end
  if not parentUIBase.EffectSkinRoots then
    parentUIBase.EffectSkinRoots = {}
  end
  local key = effectKey or self:GetEffectRootKey(parentPanel)
  if not key then
    log(bWriteLog and "logic_ugc_inventory.AddEffectSkinByCreateChildWindow invalid parentPanel " .. tostring(parentPanel))
    return nil
  end
  self:RemoveEffectSkin(parentUIBase, key)
  local pak_util = require("client.common.pak_util")
  if bgPath and bgPath ~= "" and pak_util.IsFileExist(bgPath) then
    local uiConfig = UIManager.UI_Config.UGC_Inventory_EffectSkin_Item_UIBP
    local childUI = parentUIBase:CreateChildWindowWithBpPath(parentPanel, uiConfig, bgPath, aniName, extraData)
    parentUIBase.effectRoots[key] = childUI
    if childUI then
      local EffectList = parentUIBase.EffectSkinRoots[key]
      if not EffectList then
        EffectList = {}
        parentUIBase.EffectSkinRoots[key] = EffectList
      end
      EffectList[#EffectList + 1] = childUI
    end
    return childUI
  else
    log(bWriteLog and "logic_ugc_inventory.AddEffectSkinByCreateChildWindow Error bgPath" .. tostring(bgPath))
  end
  return nil
end

function logic_ugc_inventory:AddUpBPEffectByCreateChildWindow(parentUIBase, bgPath, parentPanel, IsLoop, playerName, ShowKey)
  if not parentUIBase then
    log(bWriteLog and "logic_ugc_inventory.AddUpBPEffectByCreateChildWindow invalid parentUIBase")
    return nil
  end
  if not parentUIBase.effectRoots then
    parentUIBase.effectRoots = {}
  end
  local key = self:GetEffectRootKey(parentPanel)
  if not key then
    log(bWriteLog and "logic_ugc_inventory.AddUpBPEffectByCreateChildWindow invalid parentPanel " .. tostring(parentPanel))
    return nil
  end
  self:RemoveEffectSkin(parentUIBase, key)
  local pak_util = require("client.common.pak_util")
  if bgPath and bgPath ~= "" and pak_util.IsFileExist(bgPath) then
    local uiConfig = UIManager.UI_Config.UGC_Inventory_UpInRoomEffect_Item_UIBP
    local childUI = parentUIBase:CreateChildWindowWithBpPath(parentPanel, uiConfig, bgPath, IsLoop, playerName, ShowKey)
    parentUIBase.effectRoots[key] = childUI
    return childUI
  else
    log(bWriteLog and "logic_ugc_inventory.AddUpBPEffectByCreateChildWindow Error bgPath" .. tostring(bgPath))
  end
  return nil
end

function logic_ugc_inventory:GetDownloadList(Data)
  if not Data or not Data.ID then
    log(bWriteLog and "logic_ugc_inventory:GetDownloadList Data or Data.ID is nil")
    return {}
  end
  local tDownloadList = {
    Data.ID
  }
  local tempListForCheck = {
    [Data.ID] = true
  }
  local InfoCardBluprint = Data.InfoCardBluprint
  if InfoCardBluprint and InfoCardBluprint ~= "" and not tempListForCheck[InfoCardBluprint] then
    table.insert(tDownloadList, InfoCardBluprint)
    tempListForCheck[InfoCardBluprint] = true
  end
  local InfoCardBluprintAni = Data.InfoCardBluprintAni
  if InfoCardBluprintAni and InfoCardBluprintAni ~= "" and not tempListForCheck[InfoCardBluprintAni] then
    table.insert(tDownloadList, InfoCardBluprintAni)
    tempListForCheck[InfoCardBluprintAni] = true
  end
  local InfoCardBackground = Data.InfoCardBackground
  if InfoCardBackground and InfoCardBackground ~= "" and not tempListForCheck[InfoCardBackground] then
    table.insert(tDownloadList, InfoCardBackground)
    tempListForCheck[InfoCardBackground] = true
  end
  local InterfaceBluprint = Data.InterfaceBluprint
  if InterfaceBluprint and InterfaceBluprint ~= "" and not tempListForCheck[InterfaceBluprint] then
    table.insert(tDownloadList, InterfaceBluprint)
    tempListForCheck[InterfaceBluprint] = true
  end
  local InterfaceBluprintAni = Data.InterfaceBluprintAni
  if InterfaceBluprintAni and InterfaceBluprintAni ~= "" and not tempListForCheck[InterfaceBluprintAni] then
    table.insert(tDownloadList, InterfaceBluprintAni)
    tempListForCheck[InterfaceBluprintAni] = true
  end
  local InterfaceBackground = Data.InterfaceBackground
  if InterfaceBackground and InterfaceBackground ~= "" and not tempListForCheck[InterfaceBackground] then
    table.insert(tDownloadList, InterfaceBackground)
    tempListForCheck[InterfaceBackground] = true
  end
  local WidgetPath = Data.WidgetPath
  if WidgetPath and WidgetPath ~= "" and not tempListForCheck[WidgetPath] then
    table.insert(tDownloadList, WidgetPath)
    tempListForCheck[WidgetPath] = true
  end
  local WidgetAniPath = Data.WidgetAniPath
  if WidgetAniPath and WidgetAniPath ~= "" and not tempListForCheck[WidgetAniPath] then
    table.insert(tDownloadList, WidgetAniPath)
    tempListForCheck[WidgetAniPath] = true
  end
  local WidgetPath_L = Data.WidgetPath_L
  if WidgetPath_L and WidgetPath_L ~= "" and not tempListForCheck[WidgetPath_L] then
    table.insert(tDownloadList, WidgetPath_L)
    tempListForCheck[WidgetPath_L] = true
  end
  local WidgetPath_R = Data.WidgetPath_R
  if WidgetPath_R and WidgetPath_R ~= "" and not tempListForCheck[WidgetPath_R] then
    table.insert(tDownloadList, WidgetPath_R)
    tempListForCheck[WidgetPath_R] = true
  end
  local ItemBigIcon = Data.ItemBigIcon
  if ItemBigIcon and ItemBigIcon ~= "" and not tempListForCheck[ItemBigIcon] then
    table.insert(tDownloadList, ItemBigIcon)
    tempListForCheck[ItemBigIcon] = true
  end
  local IconPath = Data.IconPath
  if IconPath and IconPath ~= "" and not tempListForCheck[IconPath] then
    table.insert(tDownloadList, IconPath)
    tempListForCheck[IconPath] = true
  end
  log(bWriteLog and string.format("logic_ugc_inventory:GetDownloadList itemId=%s, downloadList count=%s, IconPath=%s", tostring(Data.ID), tostring(#tDownloadList), tostring(IconPath)))
  return tDownloadList
end

function logic_ugc_inventory:AutoDownloadResource(Data, callback, bForce)
  if not Data or not Data.ID then
    log(bWriteLog and "logic_ugc_inventory:AutoDownloadResource Data or Data.ID is nil")
    if callback then
      callback(false, "Invalid parameters")
    end
    return false
  end
  local downloadList = self:GetDownloadList(Data)
  if #downloadList == 0 then
    log(bWriteLog and "logic_ugc_inventory:AutoDownloadResource downloadList is empty")
    if callback then
      callback(true, "No resources to download")
    end
    return true
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, downloadList)
  local bDownloaded = state == PufferConst.ENUM_DownloadState.Done
  if bDownloaded and not bForce then
    if callback then
      callback(true, "Resources already downloaded")
    end
    return true
  end
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  
  local function onDownloadComplete()
    if callback then
      local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, downloadList)
      if state == PufferConst.ENUM_DownloadState.Done then
        callback(true, "Download success")
      else
        callback(false, "Download failed")
      end
    end
  end
  
  local bSuccess = PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, downloadList, PufferTlog.Enum_TLog_From.UGCInventory, onDownloadComplete, {bAutoDownload = true})
  if not bSuccess then
    if callback then
      callback(false, "Download trigger failed")
    end
    return false
  end
  return false
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
local Clogic_ugc_inventory = class(CModuleBase, nil, logic_ugc_inventory)
return Clogic_ugc_inventory
