do return {
  IsReqOnlineAndGroupInfo = false,
  GetAllFriendStamp = 0,
  GetAllFriendCD = 120,
  Intimacy_CanShowToBuild = 70,
  Friend_Intimacy_Threshold = 100,
  Friend_Intimacy_MaxCount = 30,
  Friend_Max_Num = 300,
  OpenFrom = 0,
  OpenFromUID = 0,
  JumpToUID = 0,
  JumpToType = 1,
  CurTab = 0,
  ReserveBack2Lobby = {},
  ignoreFriendTime = false,
  InviteBySMS = ShareSource.SMS,
  InviteByLine = ShareSource.Line,
  InviteByMore = ShareSource.More,
  InviteByWhatsapp = ShareSource.Whatsapp,
  InviteByFacebook = ShareSource.Facebook,
  InviteByMessenger = ShareSource.Messenger,
  teamState = 0,
  rejectInviteFreeFriendTime = 0,
  bShouldShowFriendBanned = false,
  FriendTopList = {},
  del_friend_timer = nil,
  loginchannel_icon_path = {
    [ShareSource.Facebook] = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 182, 51, 14, 24, 100, 197, 34, 17, 134, 194, 157, 2, 119, 191, 8, 90, 158, 16, 99, 189, 84, 161, 43, 42, 216, 245, 199, 38, 124, 189, 3, 65, 132, 123, 108, 219, 25, 145, 34),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(170, 130, 125, 47, 18, 44, 249, 1, 9, 239, 212, 167, 10, 109, 173, 84, 115, 174, 69, 58, 227, 36, 166, 29, 25, 201, 232, 143)
    }),
    [ShareSource.Twitter] = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 182, 51, 14, 24, 100, 197, 34, 17, 134, 194, 157, 2, 119, 191, 8, 90, 158, 16, 99, 189, 84, 161, 43, 42, 216, 245, 199, 38, 124, 189, 3, 65, 132, 123, 108, 219, 25, 145, 34),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(170, 130, 125, 47, 18, 44, 249, 1, 9, 253, 193, 167, 10, 109, 173, 84, 115, 174, 69, 58, 227, 36, 180, 8, 25, 201, 232, 143)
    }),
    [ShareSource.GooglePlay] = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 182, 51, 14, 24, 100, 197, 34, 17, 134, 194, 157, 2, 119, 191, 8, 90, 158, 16, 99, 189, 84, 161, 43, 42, 216, 245, 199, 38, 124, 189, 3, 65, 132, 123, 108, 219, 25, 145, 34),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(170, 130, 125, 47, 18, 44, 249, 1, 9, 238, 209, 167, 10, 109, 173, 84, 115, 174, 69, 58, 227, 36, 167, 24, 25, 201, 232, 143)
    }),
    [ShareSource.Discord] = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 182, 51, 14, 24, 100, 197, 34, 17, 134, 194, 157, 2, 119, 191, 8, 90, 158, 16, 99, 189, 84, 161, 43, 42, 216, 245, 199, 38, 124, 189, 3, 65, 132, 123, 108, 219, 25, 145, 34),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(170, 130, 125, 47, 18, 44, 249, 1, 9, 205, 255, 139, 25, 108, 184, 30, 96, 177, 76, 52, 163, 55, 143, 56, 47, 215, 217, 140, 3, 96, 185, 5, 93, 181, 109, 51, 243, 12)
    }),
    [ShareSource.Messenger] = table.concat({
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 182, 51, 14, 24, 100, 197, 34, 17, 134, 194, 157, 2, 119, 191, 8, 90, 238, 99, 39, 225, 26, 147, 112, 11, 220, 245, 155, 11, 116, 191, 40, 64, 169, 102, 42, 237, 24, 165, 6),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 183, 32, 2, 16, 46, 227, 64, 21, 225, 215, 172, 37, 97, 190, 20, 96, 135, 96, 62, 232, 8, 147, 62, 33, 220, 217, 152, 4, 116, 244, 41, 103, 144, 102, 28, 255, 31, 158, 16),
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(137, 179, 63, 6, 14, 56, 241, 8, 51, 246, 230, 150, 29)
    })
  },
  ImageInviteTintColor = FSlateColor(FLinearColor(0, 0, 0, 0.698039)),
  TabType = {
    Platform = 0,
    Inner = 1,
    RecentTeammate = 2,
    Intimacy = 3,
    Search = 5,
    RecentLike = 7,
    Apply = 8,
    NewbieFriendsRecommend = 9,
    ReturnFriendsRecommend = 10,
    RoleInfoCard = 11,
    ChatWorldSocialCard = 12,
    ChatTopic1SocialCard = 13,
    ChatTopic2SocialCard = 14,
    ChatCorpsSocialCard = 15,
    QRCode = 16,
    PlanPHPlayerList = 17,
    PlanPHHomeDetailLobby = 18,
    PlanPHHomeDetailIngame = 19,
    PlanPHHomePigeonVisitor = 20,
    WOWResult = 21,
    MainCityInfoCard = 22,
    ReturnFriendsChatChannel = 24,
    FlashTeamMemberCard = 25,
    PlanBT = 27
  },
  ["OpenFromType"] = {Lobby = 0, PersonSpaceRelationShip = 1},
  ["RelationChangeType"] = {RelationType = 1, CustomName = 2},
  ["RelationApplyOp"] = {Agree = 1, Refuse = 2},
  ["Init"] = function()
    EventSystem:registEvent(EVENTTYPE_STATE, EVENTID_ON_MODE_PRE_SWITCH, U1.OnGameStateChange)
    EventSystem:registEvent(EVENTTYPE_URL, BP_ENUM_MODULE_FRIEND, U1.OnJumpUrl)
    EventSystem:registEvent(EVENTTYPE_URL, BP_ENUM_MODULE_ADD_FRIEND, U1.OnJumpUrl)
    EventSystem:registEvent(EVENTTYPE_URL, BP_ENUM_MODULE_QUICKTEAM_MAIN, U1.OnJumpUrl)
    EventSystem:registEvent(EVENTTYPE_URL, BP_ENUM_MODULE_FRIEND_APPLYLIST, U1.OnJumpUrl)
    EventSystem:registEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED, U1.OnApplicationReactivated)
    EventSystem:registEvent(EVENTTYPE_URL, BP_ENUM_MODULE_INTIMACY_LEVEL_UP_SLAP, U1.OnIntimacyLevelUpSlap)
    return
  end,
  ["OnLogin"] = function()
    ReqFriendData()
    return
  end,
  ["ResetData"] = function()
    _ENV = {}
    U1 = {}
    ;({}):ClearData()
    ;({}).ClearData:ClearData()
    U4 = {}
    U5 = {}
    U6 = {}
    return
  end,
  ["OnJumpUrl"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == BP_ENUM_MODULE_FRIEND then
      elseif _ARG_1_ == BP_ENUM_MODULE_ADD_FRIEND then
        UIManager.ShowUI(UIManager.UI_Config.friend_new_search)
      elseif _ARG_1_ == BP_ENUM_MODULE_FRIEND_APPLYLIST then
      elseif _ARG_1_ == BP_ENUM_MODULE_QUICKTEAM_MAIN then
        if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_flash_team_utils):CheckFlashTeamResourceDownload() then
          return
        end
      end
      return
    end
  end,
  ["ReqFriendData"] = function()
    log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 40, 102, 187, 60, 77, 168, 71, 61, 233, 63, 129, 43, 39))
    U2.IsReqOnlineAndGroupInfo = true
    if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_spk_fb):IsWaitingAuthoRefresh() then
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_spk_fb).bWaitAuthoRefresh = false
    else
    end
    return
  end,
  ["OnGameStateChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 53, 109, 141, 27, 82, 164, 113, 39, 236, 15, 133, 28, 46, 216, 232, 143, 15, 51) .. _ARG_2_.current .. U1(239, 209) .. _ARG_2_.pre)
      if _ARG_2_.pre == GameStatus.Fighting and _ARG_2_.current == GameStatus.Lobby then
        U2.IsReqOnlineAndGroupInfo = true
        U2.get_all_friendlist_req(true)
      elseif _ARG_2_.current == GameStatus.Login then
        U2.ResetData()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnApplicationReactivated"] = function()
    return
  end,
  ["SortInnerList"] = function()
    log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 41, 108, 184, 14, 118, 175, 76, 54, 255, 55, 137, 44, 50))
    return
  end,
  ["AddFriendData"] = function(_ARG_0_)
    do
      ;(_ENV[_ARG_0_] or {}).uid = _ARG_0_
      ;(_ENV[_ARG_0_] or {}).intimacy = 0
      _ENV[_ARG_0_], (_ENV[_ARG_0_] or {}).create_time = _ENV[_ARG_0_] or {}, U1.GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddInnerFriend"] = function(_ARG_0_)
    do
      _ARG_0_ = _ENV(_ARG_0_)
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_friend_search):RemoveSearchList(_ARG_0_) then
      end
      if U2.IsInnerFriend(_ARG_0_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddSource"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ and _ARG_1_ and _ENV[_ARG_0_] then
        _ENV[_ARG_0_].source = _ARG_1_
        _ENV[_ARG_0_], _ENV[_ARG_0_].add_from = _ENV[_ARG_0_], _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddIntimacy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      if _ARG_3_ then
        if _ENV[_ARG_0_] then
          _ENV[_ARG_0_].intimacy = _ARG_3_
          _ENV[_ARG_0_].awardlevel = _ARG_4_
          _ENV[_ARG_0_].createtime = _ARG_5_
        end
      else
      end
      if _ARG_1_ == 3 and U1.GetInnerFriendIntimacy(_ARG_0_) and U1.GetInnerFriendIntimacy(_ARG_0_) >= U1.Friend_Intimacy_Threshold then
        _ARG_2_, _ARG_1_ = U1.GetInnerFriendIntimacy(_ARG_0_), 0
      end
      if _ARG_1_ == 2 and _ARG_2_ and _ARG_2_ > U2.require((U2.table.concat({
        U3(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U3(172, 136, 17, 12, 19, 56, 228)
      }))).EIntimacyType.Max then
        return
      end
      if not _ARG_7_ then
        _ARG_0_ = _ARG_0_
        if U4[U2.table.concat({
          U3(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 59, 103, 174, 51, 81, 181, 75, 62, 236, 24, 153, 127, 52, 220, 234, 137, 30, 122, 181, 4, 123, 168, 66, 38, 189, 5, 159, 59),
          U3(239, 148, 42, 10, 9, 113, 176, 74, 50, 133, 182, 149, 27, 123, 234, 14, 70, 177, 71, 110, 168, 31)
        })].uid == _ARG_0_ then
          U4[U2.table.concat({
            U3(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 59, 103, 174, 51, 81, 181, 75, 62, 236, 24, 153, 127, 52, 220, 234, 137, 30, 122, 181, 4, 123, 168, 66, 38, 189, 5, 159, 59),
            U3(239, 148, 42, 10, 9, 113, 176, 74, 50, 133, 182, 149, 27, 123, 234, 14, 70, 177, 71, 110, 168, 31)
          })] = {
            ["uid"] = _ARG_0_,
            ["state"] = _ARG_1_,
            ["param"] = _ARG_2_,
            ["intimacy"] = _ARG_3_,
            ["awardlevel"] = _ARG_4_,
            ["createtime"] = _ARG_5_,
            ["intimacy"] = U1.GetInnerFriendIntimacy(_ARG_0_)
          }
        else
          _ARG_0_ = _ARG_0_
        end
      end
      if not true then
      end
      if not _ARG_6_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeList"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil].uid == _ARG_0_ then
        _ENV[nil].awardlevel = _ARG_1_
      else
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIntimacyAwardLevel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ENV(_ARG_0_) or _ARG_0_
      _ARG_1_ = _ENV(_ARG_1_)
      if not _ARG_0_ or not _ARG_1_ then
        return false
      end
      _ARG_0_ = _ARG_0_
      if U1[nil].uid == _ARG_0_ then
        if (function(_ARG_0_)
          do
            do return _ARG_0_ == nil or _ARG_0_ < _ENV end
            do return end
            _ARG_0_ = _ARG_0_
          end
        end)(U1[nil].awardlevel) then
          U1[nil].awardlevel = _ARG_1_
        end
      else
        _ARG_0_ = _ARG_0_
      end
      if U2[_ARG_0_] and (function(_ARG_0_)
        do
          do return _ARG_0_ == nil or _ARG_0_ < _ENV end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)(U2[_ARG_0_].awardlevel) then
        U2[_ARG_0_].awardlevel = _ARG_1_
      end
      if U3.require((U3.table.concat({
        U4(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U4(174, 146, 55)
      }))).list and U3.require((U3.table.concat({
        U4(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U4(174, 146, 55)
      }))).list[_ARG_0_] and (function(_ARG_0_)
        do
          do return _ARG_0_ == nil or _ARG_0_ < _ENV end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)((U3.require((U3.table.concat({
        U4(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U4(174, 146, 55)
      }))).list and U3.require((U3.table.concat({
        U4(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U4(174, 146, 55)
      }))).list[_ARG_0_]).award_level) then
        ;(U3.require((U3.table.concat({
          U4(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
          U4(174, 146, 55)
        }))).list and U3.require((U3.table.concat({
          U4(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
          U4(174, 146, 55)
        }))).list[_ARG_0_]).award_level = _ARG_1_
      end
      if true then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteInnerFriend"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      if U2[53] == _ARG_0_ then
      else
        _ARG_0_ = _ARG_0_
      end
      if not true then
        U3[_ARG_0_] = nil
      elseif U3[_ARG_0_] then
        U3[_ARG_0_].intimacy = 0
        U3[_ARG_0_].remark = nil
      end
      _ARG_0_ = _ARG_0_
      if U4[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)] == _ARG_0_ then
      else
        _ARG_0_ = _ARG_0_
      end
      if require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U1(174, 146, 55)
      }))).IntimacyPartnerData and require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U1(174, 146, 55)
      }))).IntimacyPartnerData.partner_uid == _ARG_0_ then
        require((table.concat({
          U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
          U1(174, 146, 55)
        }))).IntimacyPartnerData = {partner_uid = 0}
      end
      if not _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteIntimacyData"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil].uid == _ARG_0_ then
        if U1.GetInnerFriendIntimacy(_ENV[nil].uid) >= U1.Friend_Intimacy_Threshold then
          _ENV[nil], _ENV[nil].param, _ENV[nil].state = _ENV[nil], U1.GetInnerFriendIntimacy(_ENV[nil].uid), 0
        else
        end
      else
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[46]
    end
  end,
  ["GetFriendData"] = function(_ARG_0_)
    do
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllFriendData"] = function()
    do return _ENV end
    return
  end,
  ["GetRemark"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ENV(_ARG_0_)
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) then
      end
      if U3[_ARG_0_] and U3[_ARG_0_].remark and U3[_ARG_0_].remark ~= U2() then
        if _ARG_1_ then
        else
        end
      end
      do return (U1.LocUtil.LocalizeResFormat(34627, U1.LocUtil.LocalizeResFormat(8801379, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.NicknameColorManager):ChangeTextColorByUID(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_).nickName, _ARG_0_), U3[_ARG_0_].remark), U3[_ARG_0_].remark)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNamePure"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) then
      end
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_).nickName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRemarkNamePure"] = function(_ARG_0_)
    do
      if type(_ARG_0_) == U1(188, 133, 32, 10, 19, 44) then
        _ARG_0_ = U2(_ARG_0_)
      end
      if U3[_ARG_0_] and U3[_ARG_0_].remark and U3[_ARG_0_].remark ~= U1() then
      end
      do return U3[_ARG_0_].remark end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFriendDataByNickName"] = function(_ARG_0_)
    do
      goto lbl_21
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile((nil).uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile((nil).uid).nickName == _ARG_0_ then
        return U1[nil]
      end
      ::lbl_21::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPLatformList"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_ then
      end
      do return U1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetInnerList"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        _ENV:Sort(U1)
      end
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetInnerListSortByIntimacy"] = function()
    _ENV:Sort(U1)
    do return _ENV end
    return
  end,
  ["GetIntimacyData"] = function(_ARG_0_)
    do
      goto lbl_9
      if (nil).uid == _ARG_0_ then
        return nil
      end
      ::lbl_9::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIntimacyList"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return _ENV
      end
      _ARG_0_ = _ARG_0_
      _ENV[nil].stateSortPriority = ({
        [0] = 1,
        [1] = 3,
        [2] = 2,
        [4] = 4
      })[_ENV[nil].state] or 0
      _ENV[nil].relation = _ENV[nil].state == 4 and _ENV[nil].param or 0
      _ENV[nil].relationSortPriority = ({
        [1] = 2,
        [2] = 4,
        [4] = 3
      })[_ENV[nil].relation] or 1
      if U1.GetFriendData(_ENV[nil].uid) then
        _ENV[nil].intimacy = U1.GetFriendData(_ENV[nil].uid).intimacy
      end
      _ARG_0_ = _ARG_0_
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIntimacyHasBuildList"] = function()
    if _ENV[nil].state == 4 then
    end
    do return {} end
    return
  end,
  ["GetIntimacyHasBuildSortV2"] = function()
    if _ENV[nil].state == 4 then
    end
    do return {} end
    return
  end,
  ["GetIntimacyCanBePartnerList"] = function()
    if U2[U1(174, 146, 55)].state == 4 and U2[U1(174, 146, 55)].intimacy >= require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
      U1(174, 146, 55)
    }))).PartnerIntimacyLimit then
    end
    do return {} end
    return
  end,
  ["GetIntimacyCanBuildList"] = function()
    if U1.GetInnerFriendIntimacy(_ENV[nil]) >= U1.Intimacy_CanShowToBuild and (not U1.GetIntimacyData(_ENV[nil]) or U1.GetIntimacyData(_ENV[nil]).state == 0 or U1.GetIntimacyData(_ENV[nil]).state == 1) then
    end
    do return {} end
    return
  end,
  ["GetLimitedIntimacyCanBuildList"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or 3
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAvaliableIntimacyTb"] = function()
    if U3.GetInnerFriendIntimacy(U2[U1(188)]) >= U3.Friend_Intimacy_Threshold and (not U3.GetIntimacyData(U2[U1(188)]) or U3.GetIntimacyData(U2[U1(188)]).state == 0 or U3.GetIntimacyData(U2[U1(188)]).state == 2) then
    end
    return
  end,
  ["GetRelationRichText"] = function(_ARG_0_)
    do
      do return require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U1(172, 136, 7, 23, 20, 39, 227)
      }))).GetRelationRichText(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRelationText"] = function(_ARG_0_)
    do
      do return require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U1(172, 136, 7, 23, 20, 39, 227)
      }))).GetRelationText(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRelationCnt"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil].state == 4 and _ARG_0_ == _ENV[nil].relation then
      end
      _ARG_0_ = _ARG_0_
      do return 0 + 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllFriendList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_342
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(174, 133, 39, 16, 56, 37, 229, 2)) then
        if _ARG_0_ and U1(174, 133, 39, 16, 56, 37, 229, 2).online ~= 1 then
        end
        if _ARG_2_ and U1(174, 133, 39, 16, 56, 37, 229, 2).teamState ~= _ARG_2_ then
        end
        if false then
        end
      end
      ::lbl_342::
      if not _ARG_1_ or not (_ARG_1_ <= #{}) then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SortNearList"] = function(_ARG_0_)
    do
      table.sort(_ARG_0_, U1)
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAtLeastOneOnlineAndFree"] = function()
    goto lbl_89
    if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(U1(174, 133, 39, 16, 40, 63, 249, 3)) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(U1(174, 133, 39, 16, 40, 63, 249, 3)).online == 1 and require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 82, 63, 236, 2, 133, 45, 25, 202, 242, 137, 30, 102, 169, 68, 127, 189, 83, 58, 248, 25, 163, 59),
      U1(174, 133, 39, 16, 40, 63, 249, 3)
    }))).IsIdleOrFree((ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(U1(174, 133, 39, 16, 40, 63, 249, 3)))) or require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 82, 63, 236, 2, 133, 45, 25, 202, 242, 137, 30, 102, 169, 68, 127, 189, 83, 58, 248, 25, 163, 59),
      U1(174, 133, 39, 16, 40, 63, 249, 3)
    }))).IsMainCityIdle() then
      return true
    end
    ::lbl_89::
    goto lbl_114
    if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(U1(174, 133, 39, 16, 40, 63, 249, 3)) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(U1(174, 133, 39, 16, 40, 63, 249, 3)).online == 1 and require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 82, 63, 236, 2, 133, 45, 25, 202, 242, 137, 30, 102, 169, 68, 127, 189, 83, 58, 248, 25, 163, 59),
      U1(174, 133, 39, 16, 40, 63, 249, 3)
    }))).IsIdleOrFree((ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(U1(174, 133, 39, 16, 40, 63, 249, 3)))) or require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 82, 63, 236, 2, 133, 45, 25, 202, 242, 137, 30, 102, 169, 68, 127, 189, 83, 58, 248, 25, 163, 59),
      U1(174, 133, 39, 16, 40, 63, 249, 3)
    }))).IsMainCityIdle() then
      return true
    end
    ::lbl_114::
    do return false end
    return
  end,
  ["GetFriendList"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 41, 108, 184, 14, 121, 179, 75, 54, 227, 31, 172, 54, 53, 205))
      goto lbl_78
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):GetBlackMap()[(226).uid] then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((226).uid) then
          ;(226).device_type = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((226).uid).device_type
          ;(226).online = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((226).uid).online
          ;(226).teamState = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((226).uid).teamState
        else
          ;(226).device_type = 0
          ;(226).online = 0
          ;(226).teamState = 0
        end
      end
      ::lbl_78::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_ then
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChangeRelationApplyList"] = function()
    goto lbl_44
    if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):GetBlackMap()[(nil).uid] and (nil).change_data and (nil).change_data[1] and (nil).change_data and (nil).change_data[1].state == 2 then
    end
    ::lbl_44::
    do return {} end
    return
  end,
  ["GetChangeCustomNameApplyList"] = function()
    goto lbl_44
    if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):GetBlackMap()[(nil).uid] and (nil).change_data and (nil).change_data[2] and (nil).change_data and (nil).change_data[2].state == 2 then
    end
    ::lbl_44::
    do return {} end
    return
  end,
  ["GetRecentTeammateList"] = function()
    goto lbl_31
    if U1(nil) ~= U1(DataMgr.roleData.uid) then
    end
    ::lbl_31::
    goto lbl_48
    if U2.IsPlatFriend((nil).uid) == false then
      ;(nil).platName = U3()
      ;(nil).remarks_name = U3()
    end
    ::lbl_48::
    do return {} end
    return
  end,
  ["GetRecentTeammateIDList"] = function()
    goto lbl_29
    if U1(nil) ~= U1(DataMgr.roleData.uid) then
    end
    ::lbl_29::
    do return {} end
    return
  end,
  ["GetRecentTeammateData"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetRecentDataMap()[_ARG_0_] then
        return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetRecentDataMap()[_ARG_0_]
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetStrangerRecallList"] = function()
    goto lbl_28
    if not U2.IsMyFriend(nil) then
      ;(nil).uid = nil
      ;(nil).intimacy = 0
      ;(nil).lastOnlineTime = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLastOnlineTime(nil)
    end
    ::lbl_28::
    do return {} end
    return
  end,
  ["GetFromIDByTab"] = function(_ARG_0_)
    do
      if _ARG_0_ == U1.TabType.RecentTeammate then
      elseif _ARG_0_ == U1.TabType.Search then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_search):IsFromRecommand() then
        else
        end
      elseif _ARG_0_ == U1.TabType.Intimacy then
      elseif _ARG_0_ == U1.TabType.ReturnFriendsRecommend then
      elseif _ARG_0_ == U1.TabType.NewbieFriendsRecommend then
      elseif _ARG_0_ == U1.TabType.RoleInfoCard then
      elseif _ARG_0_ == U1.TabType.ChatWorldSocialCard then
      elseif _ARG_0_ == U1.TabType.ChatTopic1SocialCard then
      elseif _ARG_0_ == U1.TabType.ChatTopic2SocialCard then
      elseif _ARG_0_ == U1.TabType.ChatCorpsSocialCard then
      elseif _ARG_0_ == U1.TabType.QRCode then
      elseif _ARG_0_ == U1.TabType.PlanPHHomePigeonVisitor then
      elseif _ARG_0_ == U1.TabType.PlanPHHomeDetailLobby then
      elseif _ARG_0_ == U1.TabType.PlanPHHomeDetailIngame then
      elseif _ARG_0_ == U1.TabType.PlanPHPlayerList then
      elseif _ARG_0_ == U1.TabType.MainCityInfoCard then
      elseif _ARG_0_ == U1.TabType.ReturnFriendsChatChannel then
      elseif _ARG_0_ == U1.TabType.FlashTeamMemberCard then
      elseif _ARG_0_ == U1.TabType.PlanBT then
      end
      do return BP_ENUM_ADD_FRIEND_FROM_PLANBT end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetReserveState"] = function(_ARG_0_)
    do
      if not GetFriendData(_ARG_0_) then
        return 0
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_friend_reserve):IsCanReserve(_ARG_0_) then
        return 0
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_friend_reserve):IsReserveSuccess(_ARG_0_) then
        return 3
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_friend_reserve):CheckCanReserve(_ARG_0_) then
        return 2
      end
      do return 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllApplyCnt"] = function()
    if U2[U1(174, 146, 55)].state == 2 then
    end
    if require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
      U1(174, 146, 55)
    }))).IntimacyPartnerData and require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
      U1(174, 146, 55)
    }))).IntimacyPartnerData.wait_confirm_list then
      goto lbl_89
      ::lbl_89::
    end
    if U3.GetChangeRelationApplyList() and next((U3.GetChangeRelationApplyList())) then
      goto lbl_105
      ::lbl_105::
    end
    if U3.GetChangeCustomNameApplyList() and next((U3.GetChangeCustomNameApplyList())) then
      goto lbl_121
      ::lbl_121::
    end
    do return 0 + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_apply):GetApplyCnt() + 1 + 1 + 1 + 1 + #ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint):GetJointApplications() + #ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint):GetTerminateApplications() end
    return
  end,
  ["GetAllApplyCntWithProfileCheck"] = function(_ARG_0_)
    do
      goto lbl_94
      ::lbl_94::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if U2[187].state == 2 then
      end
      _ARG_0_ = _ARG_0_
      if require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U1(174, 146, 55)
      }))).IntimacyPartnerData and require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
        U1(174, 146, 55)
      }))).IntimacyPartnerData.wait_confirm_list then
        goto lbl_176
        ::lbl_176::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U3.GetChangeRelationApplyList() and next((U3.GetChangeRelationApplyList())) then
        goto lbl_209
        ::lbl_209::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U3.GetChangeCustomNameApplyList() and next((U3.GetChangeCustomNameApplyList())) then
        goto lbl_238
        ::lbl_238::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not _ARG_0_ then
      end
      do return 0 + ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamApplyCnt() + #ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_flash_match_team):GetFlashTeamInviteList() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetApplyIntimacyList"] = function()
    if U2[U1(174, 146, 55)].state == 2 then
    end
    if require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
      U1(174, 146, 55)
    }))).IntimacyPartnerData and require((table.concat({
      U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
      U1(174, 146, 55)
    }))).IntimacyPartnerData.wait_confirm_list then
      goto lbl_90
      ::lbl_90::
    end
    if U3.GetChangeRelationApplyList() and next((U3.GetChangeRelationApplyList())) then
      goto lbl_110
      ::lbl_110::
    end
    if U3.GetChangeCustomNameApplyList() and next((U3.GetChangeCustomNameApplyList())) then
      goto lbl_130
      ::lbl_130::
    end
    do return {} end
    return
  end,
  ["GetIntimacyApplyCnt"] = function()
    if _ENV[nil].state == 2 then
    end
    do return 0 + 1 end
    return
  end,
  ["GetInnerFriendIntimacy"] = function(_ARG_0_)
    do
      if _ENV[U1(_ARG_0_)] then
      end
      do return _ENV[U1(_ARG_0_)].intimacy end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEmptyIntimacyRelations"] = function()
    do return {} end
    return
  end,
  ["GetRelation"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil].uid == _ARG_0_ and _ENV[nil].state == 4 then
        return U1(_ENV[nil].param) or 0
      end
      _ARG_0_ = _ARG_0_
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIntimacyRankUIDList"] = function()
    goto lbl_14
    ::lbl_14::
    do return {} end
    return
  end,
  ["GetFriendUIDAndIntimacyByRankUID"] = function(_ARG_0_)
    do
      goto lbl_16
      if U2((nil).rank_uid) == U2(_ARG_0_) then
        return (nil).uid, (nil).intimacy
      end
      ::lbl_16::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      log_warning(bWriteLog and table.concat({
        U3(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 61, 102, 190, 60, 77, 168, 71, 61, 233, 46, 169, 27, 4, 192, 212, 137, 4, 120, 143, 35, 107, 241, 92, 44, 233, 75, 150, 38),
        U3(161, 149, 114, 22, 20, 47, 188, 79, 36, 200, 248, 147, 47, 74, 142, 90, 2, 225)
      }) .. tostring(_ARG_0_))
      do return nil, nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[137]
    end
  end,
  ["SetRemark"] = function(_ARG_0_, _ARG_1_)
    do
      if _ENV[_ARG_0_] then
        _ENV[_ARG_0_].remark = _ARG_1_
        U1.EventSystem:postEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_UPDATE_REMARK, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HaveRelationWaitConfirm"] = function()
    if _ENV[nil].state == 2 then
      return true
    end
    do return false end
    return
  end,
  ["IsIntimacyRelationFull"] = function(_ARG_0_)
    do
      if not CDataTable.GetTableData(U1(137, 131, 59, 6, 19, 47, 217, 1, 34, 192, 251, 153, 25, 122, 137, 21, 81, 167, 75, 52), _ARG_0_) then
        return false
      end
      goto lbl_41
      if (19).state == 4 then
      end
      ::lbl_41::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 + 1 >= CDataTable.GetTableData(U1(137, 131, 59, 6, 19, 47, 217, 1, 34, 192, 251, 153, 25, 122, 137, 21, 81, 167, 75, 52), _ARG_0_).IntimacyRelationMaxCount end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowIntimacyLevelUpSlap"] = function()
    do return _ENV end
    return
  end,
  ["OnIntimacyLevelUpSlap"] = function()
    if _ENV then
      U1.GetNextUpgradeDataAndShow(true)
      _ENV = false
    end
    return
  end,
  ["ClearIntimacyUpgradeData"] = function(_ARG_0_)
    do
      if IntimacyLevelUpData and IntimacyLevelUpData[_ARG_0_] then
        IntimacyLevelUpData[_ARG_0_] = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIntimacyLevelUpData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not IntimacyLevelUpData then
        IntimacyLevelUpData = {}
      end
      IntimacyLevelUpData[_ARG_0_] = {
        targetUID = _ARG_0_,
        level = _ARG_1_,
        itemList = _ARG_2_
      }, IntimacyLevelUpData
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNextUpgradeDataAndShow"] = function(_ARG_0_)
    do
      if IntimacyLevelUpData and U1.next(IntimacyLevelUpData) then
        if _ARG_0_ then
        end
        return U1.next(IntimacyLevelUpData)
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMyFriend"] = function(_ARG_0_)
    do
      _ARG_0_ = _ENV(_ARG_0_)
      if U1[_ARG_0_] then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFriendReserveSwitchOpen"] = function(_ARG_0_)
    do
      _ARG_0_ = _ENV(_ARG_0_)
      if not U1[_ARG_0_] then
        U2.log(U2.bWriteLog and U2.table.concat({
          U3(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 51, 112, 140, 8, 86, 164, 76, 55, 223, 30, 147, 58, 52, 207, 227, 187, 29, 122, 174, 9, 71, 158, 66, 38, 243, 75, 158, 32),
          U3(187, 209, 52, 17, 20, 46, 254, 11)
        }))
        return false
      end
      if U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) and U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_).friend_appointment_privacy and U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_).friend_appointment_privacy == 0 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPlatFriend"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil] == _ARG_0_ then
      else
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInnerFriend"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil] == _ARG_0_ then
      else
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInIntimacyList"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ENV[nil].uid == _ARG_0_ then
      else
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["get_all_friendlist_req"] = function(_ARG_0_)
    do
      if not _ARG_0_ and GetServerTimeInSec() - U1.GetAllFriendStamp < U1.GetAllFriendCD then
        U2.log(U2.bWriteLog and U3(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 29, 102, 190, 37, 94, 173, 78, 12, 235, 9, 137, 58, 40, 221, 234, 129, 25, 103, 133, 24, 74, 160, 18, 0, 217))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateIntimacyRankUID"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 47, 115, 174, 27, 75, 164, 107, 61, 249, 18, 141, 62, 37, 192, 212, 137, 4, 120, 143, 35, 107, 241, 71, 42, 249, 75, 205, 111) .. tostring(_ARG_0_) .. U1(227, 209, 32, 2, 19, 32, 197, 38, 18, 137, 171, 216) .. tostring(_ARG_1_))
      if U2[_ARG_0_] and _ARG_1_ then
        U2[_ARG_0_].rank_uid = _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_report_friend_info_req"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 9, 102, 164, 30, 96, 179, 71, 35, 226, 9, 148, 0, 32, 203, 239, 141, 4, 119, 133, 3, 65, 183, 93, 28, 239, 14, 129, 111),
        U1(172, 158, 54, 6, 93, 34, 227, 79)
      }) .. tostring(_ARG_0_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["proc_report_friend_info_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 10, 113, 165, 25, 96, 179, 71, 35, 226, 9, 148, 0, 32, 203, 239, 141, 4, 119, 133, 3, 65, 183, 93, 28, 239, 24, 128, 111),
        U1(172, 158, 54, 6, 93, 34, 227, 79)
      }) .. tostring(_ARG_2_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_get_all_friendlist_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 29, 90, 181, 125, 50, 225, 23, 191, 57, 52, 208, 227, 134, 14, 127, 179, 25, 91, 142, 64, 48, 237))
      goto lbl_92
      ::lbl_92::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if next(_ARG_1_) ~= nil then
        goto lbl_170
        if U5(37) > 0 then
          ;(U6[U5(37)] or {}).uid, U6[U5(37)] = U5(37), U6[U5(37)] or {}
          ;(U6[U5(37)] or {}).lastInviteTime = (_ARG_1_.op_timelist or {})[37] or 190.lastInviteTime
          ;(U6[U5(37)] or {}).intimacy = 0
          ;(U6[U5(37)] or {}).remarks_name = (_ARG_1_.op_timelist or {})[37] or 190.remarks_name
          ;(U6[U5(37)] or {}).remark = (_ARG_1_.op_timelist or {})[37] or 190.remark
          if (_ARG_1_.op_timelist or {})[37] or 190.add_from then
            ;(U6[U5(37)] or {}).add_from = (_ARG_1_.op_timelist or {})[37] or 190.add_from
          end
          if (_ARG_1_.op_timelist or {})[37] or 190.presented and U5((_ARG_1_.op_timelist or {})[37] or 190.presented) == 0 then
          else
          end
          ;(U6[U5(37)] or {}).isTop = false
          ;(U6[U5(37)] or {}).SetTopTimeStamp = 0
          if (_ARG_1_.top_list or {})[(U6[U5(37)] or {}).uid] then
            ;(U6[U5(37)] or {}).isTop = true
            ;(U6[U5(37)] or {}).SetTopTimeStamp = (_ARG_1_.op_timelist or {})[(U6[U5(37)] or {}).uid] or (_ARG_1_.top_list or {})[(U6[U5(37)] or {}).uid]
          end
        end
        ::lbl_170::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_245
        if U5((U5(37))) > 0 then
          ;(U6[U5((U5(37)))] or {}).uid, U6[U5((U5(37)))] = U5((U5(37))), U6[U5((U5(37)))] or {}
          ;(U6[U5((U5(37)))] or {}).intimacy = (_ARG_1_.op_timelist or {})[37] or 190.intimacy
          ;(U6[U5((U5(37)))] or {}).create_time = (_ARG_1_.op_timelist or {})[37] or 190.create_time
          ;(U6[U5((U5(37)))] or {}).remark = (_ARG_1_.op_timelist or {})[37] or 190.remark
          ;(U6[U5((U5(37)))] or {}).rank_uid = (_ARG_1_.op_timelist or {})[37] or 190.rank_uid
          ;(U6[U5((U5(37)))] or {}).change_data = (_ARG_1_.op_timelist or {})[37] or 190.change_data
          ;(U6[U5((U5(37)))] or {}).custom_name = (_ARG_1_.op_timelist or {})[37] or 190.custom_name
          if (_ARG_1_.op_timelist or {})[37] or 190.add_from then
            ;(U6[U5((U5(37)))] or {}).add_from = (_ARG_1_.op_timelist or {})[37] or 190.add_from
          end
          if (_ARG_1_.op_timelist or {})[37] or 190.presented ~= nil and U5((_ARG_1_.op_timelist or {})[37] or 190.presented) == 0 then
          else
          end
          ;(U6[U5((U5(37)))] or {}).isTop = false
          ;(U6[U5((U5(37)))] or {}).SetTopTimeStamp = 0
          if (_ARG_1_.top_list or {})[(U6[U5((U5(37)))] or {}).uid] then
            ;(U6[U5((U5(37)))] or {}).isTop = true
            ;(U6[U5((U5(37)))] or {}).SetTopTimeStamp = (_ARG_1_.op_timelist or {})[(U6[U5((U5(37)))] or {}).uid] or (_ARG_1_.top_list or {})[(U6[U5((U5(37)))] or {}).uid]
          end
        end
        ::lbl_245::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if next((FuncUtil.UnionList(U3, U2))) then
          if U7.IsReqOnlineAndGroupInfo then
            U7.IsReqOnlineAndGroupInfo = false
          end
        else
        end
        if U3 and DataMgr.roleData.back_user_data and not DataMgr.roleData.back_user_data.have_task_list and not DataMgr.roleData.has_send_back_friend_list then
          DataMgr.roleData.has_send_back_friend_list = true
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      U7.GetAllFriendStamp = U4.GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FilterFriendData"] = function()
    log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 60, 106, 166, 14, 90, 179, 100, 33, 228, 30, 142, 59, 2, 216, 242, 137))
    goto lbl_160
    if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(53) then
      U2[53] = nil
      if U3[53] == 53 then
      else
      end
      if U4[53] == 53 then
      else
      end
      if U5[53].uid == 53 then
      else
      end
    end
    ::lbl_160::
    return
  end,
  ["on_notify_topn_plat_friend_chg_info"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 148, 48, 54, 215, 217, 152, 6, 114, 174, 53, 73, 163, 91, 38, 243, 15, 175, 44),
        U1(167, 150, 13, 10, 19, 45, 255)
      }))
      if _ARG_0_ == nil then
        return
      end
      goto lbl_128
      if U1(167, 150, 13, 10, 19, 45, 255) > 0 then
        ;(U2[U1(167, 150, 13, 10, 19, 45, 255)] or {}).uid = U1(167, 150, 13, 10, 19, 45, 255)
        ;(U2[U1(167, 150, 13, 10, 19, 45, 255)] or {}).lastInviteTime = U1(167, 150, 13, 10, 19, 45, 255).lastInviteTime
        ;(U2[U1(167, 150, 13, 10, 19, 45, 255)] or {}).remarks_name = U1(167, 150, 13, 10, 19, 45, 255).remarks_name
        if (U2[U1(167, 150, 13, 10, 19, 45, 255)] or {}).intimacy == nil then
          ;(U2[U1(167, 150, 13, 10, 19, 45, 255)] or {}).intimacy = 0
        end
        if U1(167, 150, 13, 10, 19, 45, 255).presented ~= nil and U3(U1(167, 150, 13, 10, 19, 45, 255).presented) == 0 then
        else
        end
        U2[U1(167, 150, 13, 10, 19, 45, 255)] = U2[U1(167, 150, 13, 10, 19, 45, 255)] or {}, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_gift):SetLastPresentTime(U1(167, 150, 13, 10, 19, 45, 255))
      end
      ::lbl_128::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_batch_get_all_profile_rsp"] = function(_ARG_0_)
    do
      goto lbl_169
      if U3[U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166).uid] then
        U3[U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166).uid].uid = U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166).uid
        U3[U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166).uid].lastOnlineTime = U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166).lastOnlineTime
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):IsPlayerBannedOver30day(U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166).uid) and (_ENV(U1.LobbySystem.roleData.last_logout_time) or 0) < (U1.require((U2(172, 158, 63, 14, 18, 37, 190, 27, 55, 203, 250, 157, 37, 118, 190, 19, 83))).GetTableValue(U2(189, 158, 52, 10, 17, 46, 207, 29, 37, 217, 182, 148, 27, 112, 190, 54, 80, 166, 77, 38, 249, 47, 137, 50, 35, 131, 166)) or 0) then
          U4.bShouldShowFriendBanned = true
        end
      end
      ::lbl_169::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowIntimacyErrCode"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 41, 107, 165, 13, 118, 175, 86, 58, 224, 26, 131, 38, 3, 203, 244, 171, 5, 119, 191, 80) .. tostring(_ARG_0_) .. U1(239, 131, 55, 15, 28, 63, 249, 0, 56, 147) .. tostring(_ARG_1_))
      if _ARG_0_ == 100100011 then
      elseif _ARG_0_ == 100100002 then
      elseif _ARG_0_ == 100100005 then
      elseif _ARG_0_ == U1(171, 148, 62, 78, 30, 47) then
      elseif _ARG_0_ == U1(169, 132, 62, 15) then
      elseif _ARG_0_ == U1(166, 159, 36, 2, 17, 34, 244, 66, 38, 200, 228, 153, 23) then
      elseif _ARG_0_ == U1(163, 158, 37, 78, 20, 37, 228, 6, 59, 200, 245, 129) then
      elseif _ARG_0_ == U1(160, 129, 127, 15, 18, 60, 189, 6, 56, 221, 255, 149, 27, 96, 179) then
      elseif _ARG_0_ == U1(174, 157, 32, 6, 28, 47, 233, 66, 52, 220, 255, 148, 30) then
      elseif _ARG_0_ == U1(184, 144, 59, 23, 80, 40, 255, 1, 48, 192, 228, 149) then
      elseif _ARG_0_ == U1(160, 129, 127, 7, 24, 39, 189, 12, 50) then
      elseif _ARG_0_ == U1(160, 129, 127, 2, 17, 57, 245, 14, 50, 208, 187, 154, 15, 106, 166, 30) then
      elseif _ARG_0_ == U1(160, 129, 127, 2, 17, 57, 245, 14, 50, 208, 187, 139, 31, 109, 174) then
      elseif _ARG_0_ == U1(188, 133, 51, 23, 24, 102, 245, 29, 36, 198, 228) or _ARG_0_ == U1(189, 148, 62, 2, 9, 34, 255, 1, 123, 204, 228, 138, 21, 113) or _ARG_0_ == U1(160, 129, 127, 16, 9, 42, 228, 10, 123, 204, 228, 138, 21, 113) or _ARG_0_ == U1(160, 129, 127, 17, 24, 39, 241, 27, 63, 198, 248, 213, 31, 113, 184, 21, 77) then
      elseif _ARG_0_ == U1(161, 158, 38, 78, 24, 51, 249, 28, 34) then
      elseif _ARG_0_ == U1(172, 132, 32, 78, 15, 46, 252, 14, 34, 192, 249, 150, 87, 101, 191, 22, 83) then
      elseif _ARG_0_ == U1(174, 157, 62, 78, 15, 46, 252, 14, 34, 192, 249, 150, 87, 101, 191, 22, 83) then
      elseif U2.GetRelationText(_ARG_1_) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["get_intimacy_relation_req"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 29, 102, 190, 37, 86, 175, 86, 58, 224, 26, 131, 38, 25, 203, 227, 132, 11, 103, 179, 5, 65, 142, 64, 38, 236))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_get_intimacy_relation_rsp"] = function(_ARG_0_)
    do
      log_tree(U1(160, 159, 13, 4, 24, 63, 207, 6, 56, 221, 255, 149, 27, 96, 179, 37, 77, 164, 78, 50, 249, 18, 143, 49, 25, 203, 245, 152), _ARG_0_)
      goto lbl_48
      ::lbl_48::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      U2 = {}
      goto lbl_172
      if ({
        [(4).uid] = (4).awardlevel
      })[U3(13)] and (4).award_level and (4).award_level < ({
        [(4).uid] = (4).awardlevel
      })[U3(13)] then
      end
      ::lbl_172::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["build_intimacy_relation_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      printf(table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 24, 118, 163, 22, 91, 158, 75, 61, 249, 18, 141, 62, 37, 192, 217, 154, 15, 127, 187, 30, 70, 190, 92, 28, 239, 14, 129, 111),
        U1(169, 131, 59, 54, 20, 47, 170, 74, 37, 133, 182, 138, 31, 111, 171, 14, 86, 174, 76, 105, 168, 8, 204, 127, 48, 214, 241, 183, 3, 119, 224, 79, 92)
      }), _ARG_0_, _ARG_1_, _ARG_2_)
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[171]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["proc_build_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 10, 113, 165, 25, 96, 163, 87, 58, 225, 31, 191, 54, 40, 205, 239, 133, 11, 112, 163, 53, 93, 180, 94, 34, 233, 2, 159, 33),
        U1(144, 131, 33, 19)
      }))
      if U2.GetRelationText(_ARG_1_) ~= U1() then
      end
      _ARG_0_ = _ARG_0_
      if U3[61].uid == _ARG_0_ then
        U3[61].state = 1
        U3[61], U3[61].param = U3[61], _ARG_1_
      else
        _ARG_0_ = _ARG_0_
      end
      if not true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["delete_intimacy_relation_req"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 30, 102, 166, 31, 75, 164, 125, 58, 227, 15, 137, 50, 39, 218, 255, 183, 24, 118, 182, 11, 91, 184, 93, 45, 194, 25, 149, 62),
        U1(239, 151, 32, 10, 40, 34, 244, 85, 118)
      }) .. tostring(_ARG_0_))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_delete_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 30, 90, 173, 71, 39, 232, 36, 137, 49, 50, 208, 235, 137, 9, 106, 133, 24, 74, 189, 83, 55, 244, 4, 158, 16),
        U1(189, 130, 34, 67, 15, 46, 227, 85, 118)
      }) .. tostring(_ARG_0_) .. U1(239, 151, 32, 10, 40, 34, 244, 85, 118) .. tostring(_ARG_1_))
      if _ARG_0_ == NetErrorCode_NONE then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_) then
        end
        if _ARG_1_ == require((table.concat({
          U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
          U1(174, 146, 55)
        }))).IntimacyPartnerData.partner_uid then
          require((table.concat({
            U1(172, 157, 59, 6, 19, 63, 190, 3, 57, 206, 255, 155, 84, 115, 175, 8, 76, 174, 76, 32, 253, 26, 131, 58, 104, 213, 233, 143, 3, 112, 133, 26, 74, 163, 65, 44, 243, 52, 131, 63),
            U1(174, 146, 55)
          }))).IntimacyPartnerData = {partner_uid = 0}
          require((table.concat({
            U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 82, 54, 255, 8, 143, 49, 25, 202, 246, 137, 9, 118, 244, 6, 64, 182, 91, 32, 194, 2, 158, 59),
            U1(166, 156, 51, 0, 4, 20, 241, 24, 55, 219, 242)
          }))).has_intimacy_reward = false
        end
      elseif _ARG_0_ == U1(161, 158, 38, 78, 31, 62, 249, 3, 50) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["cancel_build_intimacy_relation_req"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 25, 98, 164, 25, 90, 173, 125, 49, 248, 18, 140, 59, 25, 208, 232, 156, 3, 126, 187, 9, 86, 142, 64, 38, 241, 10, 132, 38),
        U1(160, 159, 13, 17, 24, 58, 176, 26, 63, 205, 172, 216)
      }) .. tostring(_ARG_0_))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_cancel_build_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 25, 94, 175, 65, 54, 225, 36, 130, 42, 47, 213, 226, 183, 3, 125, 174, 3, 66, 176, 81, 58, 194, 25, 149, 35),
        U1(174, 133, 59, 12, 19, 20, 226, 28, 38, 137, 228, 157, 9, 57, 234)
      }) .. tostring(_ARG_0_) .. U1(239, 151, 32, 10, 40, 34, 244, 85, 118) .. tostring(_ARG_1_))
      _ARG_0_ = _ARG_0_
      if U2[U1(239, 151, 32, 10, 40, 34, 244, 85, 118)].uid == _ARG_1_ then
        U2[U1(239, 151, 32, 10, 40, 34, 244, 85, 118)], U2[U1(239, 151, 32, 10, 40, 34, 244, 85, 118)].state = U2[U1(239, 151, 32, 10, 40, 34, 244, 85, 118)], 0
      else
        _ARG_0_ = _ARG_0_
      end
      EventSystem:postEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_INTIMACY_CHANGE)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_cancel_build_intimacy_relation_notify"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 25, 94, 175, 65, 54, 225, 36, 130, 42, 47, 213, 226, 183, 3, 125, 174, 3, 66, 176, 81, 58, 194, 25, 149, 35),
        U1(174, 133, 59, 12, 19, 20, 254, 0, 34, 192, 240, 129, 90, 101, 184, 19, 106, 168, 70, 105, 173)
      }) .. tostring(_ARG_0_) .. U1(239, 146, 51, 13, 63, 62, 249, 3, 50, 147, 182) .. tostring(_ARG_1_))
      if _ARG_1_ then
        _ARG_0_ = _ARG_0_
        if U2[U1(239, 146, 51, 13, 63, 62, 249, 3, 50, 147, 182)].uid == _ARG_0_ then
          U2[U1(239, 146, 51, 13, 63, 62, 249, 3, 50, 147, 182)] = {
            ["state"] = 0,
            ["param"] = U3.GetInnerFriendIntimacy(_ARG_0_)
          }
        else
          _ARG_0_ = _ARG_0_
        end
      else
        _ARG_0_ = _ARG_0_
        if U2[U1(239, 146, 51, 13, 63, 62, 249, 3, 50, 147, 182)].uid == _ARG_0_ then
        else
          _ARG_0_ = _ARG_0_
        end
      end
      EventSystem:postEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_INTIMACY_CHANGE)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["reply_intimacy_relation_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      printf(table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 8, 102, 186, 22, 70, 158, 75, 61, 249, 18, 141, 62, 37, 192, 217, 154, 15, 127, 187, 30, 70, 190, 92, 28, 239, 14, 129, 111),
        U1(169, 131, 59, 54, 20, 47, 170, 74, 37, 133, 182, 138, 31, 111, 171, 14, 86, 174, 76, 105, 168, 8, 204, 127, 41, 201, 188, 205, 25, 63, 250, 28, 64, 166, 109, 42, 249, 81, 213, 60)
      }), _ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      _ARG_3_ = _ARG_3_ or 0
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return require((U1(172, 157, 59, 6, 19, 63, 190, 1, 51, 221, 225, 151, 8, 104, 228, 42, 77, 174, 86, 60, 238, 20, 140, 113, 0, 203, 239, 141, 4, 119, 146, 11, 65, 181, 94, 38, 239))).send_reply_intimacy_relation_req(_ARG_0_, _ARG_1_, _ARG_2_, nil, _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_reply_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 8, 90, 177, 78, 42, 210, 18, 142, 43, 47, 212, 231, 139, 19, 76, 168, 15, 67, 176, 70, 42, 242, 5, 175, 61),
        U1(188, 129, 114, 17, 24, 56, 170)
      }) .. tostring(_ARG_0_) .. U1(239, 151, 32, 10, 40, 34, 244, 85) .. tostring(_ARG_1_) .. U1(239, 131, 55, 15, 28, 63, 249, 0, 56, 147) .. tostring(_ARG_2_) .. U1(239, 158, 34, 89) .. tostring(_ARG_3_))
      if _ARG_0_ == NetErrorCode_NONE then
        if _ARG_3_ == 1 then
          _ARG_0_ = _ARG_0_
          if U2[U1(239, 151, 32, 10, 40, 34, 244, 85)].uid == _ARG_1_ then
            U2[U1(239, 151, 32, 10, 40, 34, 244, 85)].state = 4
            U2[U1(239, 151, 32, 10, 40, 34, 244, 85)], U2[U1(239, 151, 32, 10, 40, 34, 244, 85)].param = U2[U1(239, 151, 32, 10, 40, 34, 244, 85)], _ARG_2_
          else
            _ARG_0_ = _ARG_0_
          end
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_) then
          end
          if _ARG_2_ == require((table.concat({
            U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
            U1(172, 136, 17, 12, 19, 56, 228)
          }))).EIntimacyType.Bonding then
          else
          end
        else
          U4.DeleteIntimacyData(_ARG_1_)
        end
      else
        if _ARG_3_ == 0 then
          U4.DeleteIntimacyData(_ARG_1_)
        end
        U4.ShowIntimacyErrCode(_ARG_0_, _ARG_2_, _ARG_4_)
      end
      if _ARG_0_ ~= 100100011 then
        EventSystem:postEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_INTIMACYAPPLY_CHANGE)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_notify_intimacy_relation_chg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 137, 49, 50, 208, 235, 137, 9, 106, 133, 24, 74, 189, 83, 55, 244, 4, 158, 16),
        U1(172, 153, 53, 67, 27, 57, 249, 58, 63, 205, 172)
      }) .. tostring(_ARG_0_) .. U1(239, 130, 38, 2, 9, 46, 170) .. tostring(_ARG_1_))
      if _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 137, 49, 50, 208, 235, 137, 9, 106, 133, 24, 74, 189, 83, 55, 244, 4, 158, 16),
          U1(172, 153, 53, 67, 13, 42, 226, 14, 59, 147, 182)
        }) .. tostring(_ARG_2_))
      end
      if _ARG_1_ ~= 3 then
        U2.AddIntimacy(_ARG_0_, _ARG_1_, _ARG_2_)
      else
        U2.DeleteIntimacyData(_ARG_0_)
      end
      U2.UpdateIntimacyRankUID(_ARG_0_, _ARG_3_)
      if _ARG_1_ == 2 then
        EventSystem:postEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_INTIMACYAPPLY_CHANGE)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["notify_friend_intimacy_chg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if U1[_ARG_0_] then
        U1[_ARG_0_].intimacy = _ARG_2_
      end
      if _ARG_2_ >= U2.Friend_Intimacy_Threshold and U2.IsInIntimacyList(_ARG_0_) == false then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) then
        if _ARG_3_ and _ARG_3_.times_intimacy then
        elseif _ARG_3_ and _ARG_3_.intimacy_double_act then
        else
        end
      end
      do return end
      _ARG_3_ = tostring
    end
  end,
  ["on_take_intimacy_award_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(148, 161, 10, 58, 32, 36, 254, 48, 34, 200, 253, 157, 37, 106, 164, 14, 86, 172, 67, 48, 244, 36, 129, 40, 39, 203, 226, 183, 24, 96, 170))
      U2.SetIntimacyAwardLevel(_ARG_1_, _ARG_0_)
      EventSystem:postEvent(EVENTTYPE_PERSON_SPACE, EVENTID_PERSONSPACE_INTIMACY_DATA_UPDATE)
      goto lbl_133
      ::lbl_133::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[3]
      _ARG_1_ = U1[8]
    end
  end,
  ["send_change_intimacy_relation_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      if not U2.GetFriendData(_ARG_0_) then
        return
      end
      if require((U1(172, 158, 63, 14, 18, 37, 190, 27, 55, 203, 250, 157, 37, 118, 190, 19, 83))).GetTableValue(U2.GetFriendData(_ARG_0_), U1(172, 153, 51, 13, 26, 46, 207, 11, 55, 221, 247), U2.RelationChangeType.RelationType) and require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 190, 19, 82, 164, 125, 38, 249, 18, 140))).WithinInNDay(require((U1(172, 158, 63, 14, 18, 37, 190, 27, 55, 203, 250, 157, 37, 118, 190, 19, 83))).GetTableValue(U2.GetFriendData(_ARG_0_), U1(172, 153, 51, 13, 26, 46, 207, 11, 55, 221, 247), U2.RelationChangeType.RelationType).create_ts or 0, 60) and _ARG_1_ == U2.RelationChangeType.RelationType then
        return
      end
      do return end
      _ARG_0_ = U1[161]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["proc_change_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 10, 113, 165, 25, 96, 162, 74, 50, 227, 28, 133, 0, 47, 215, 242, 129, 7, 114, 185, 19, 112, 163, 87, 47, 252, 31, 153, 32),
        U1(161, 174, 32, 16, 13)
      }))
      if not U2[_ARG_0_] then
        return
      end
      if not U2[_ARG_0_].change_data then
        U2[_ARG_0_].change_data = {}
      end
      U2[_ARG_0_].change_data[_ARG_1_] = {
        apply_ts = require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 190, 19, 82, 164, 125, 38, 249, 18, 140))).GetServerTimeInSec(),
        update_ts = require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 190, 19, 82, 164, 125, 38, 249, 18, 140))).GetServerTimeInSec(),
        state = 1,
        param = _ARG_2_,
        apply_uid = _ARG_0_
      }
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["get_change_intimacy_relation_tip"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(148, 149, 61, 13, 26, 32, 241, 6, 44, 193, 247, 165, 90, 106, 164, 14, 86, 172, 67, 48, 244, 91, 146, 58, 42, 216, 242, 129, 5, 125, 250, 15, 93, 163, 81, 44, 249, 14, 208, 125),
        U1(239, 133, 59, 19, 71, 107)
      }) .. tostring(_ARG_0_))
      if {
        [100100006] = 200051,
        [100100012] = 200055,
        [100100013] = 77154,
        [100100014] = 200046,
        [100100015] = 73271,
        [100100016] = 77155,
        [100100017] = 45744,
        [100100018] = 20220914,
        [100100005] = 8075918
      } and ({
        [100100006] = 200051,
        [100100012] = 200055,
        [100100013] = 77154,
        [100100014] = 200046,
        [100100015] = 73271,
        [100100016] = 77155,
        [100100017] = 45744,
        [100100018] = 20220914,
        [100100005] = 8075918
      })[_ARG_0_] then
        return ({
          [100100006] = 200051,
          [100100012] = 200055,
          [100100013] = 77154,
          [100100014] = 200046,
          [100100015] = 73271,
          [100100016] = 77155,
          [100100017] = 45744,
          [100100018] = 20220914,
          [100100005] = 8075918
        })[_ARG_0_]
      else
        return _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_reply_change_intimacy_relation_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return require((U1(172, 157, 59, 6, 19, 63, 190, 1, 51, 221, 225, 151, 8, 104, 228, 42, 77, 174, 86, 60, 238, 20, 140, 113, 0, 203, 239, 141, 4, 119, 146, 11, 65, 181, 94, 38, 239))).send_reply_change_intimacy_relation_req(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_reply_change_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 8, 90, 177, 78, 42, 210, 24, 136, 62, 40, 222, 227, 183, 3, 125, 174, 3, 66, 176, 81, 58, 194, 25, 149, 35),
        U1(174, 133, 59, 12, 19, 20, 226, 28, 38, 137, 227, 145, 30, 35, 247, 90, 26, 178, 2, 127, 173, 24, 136, 62, 40, 222, 227, 183, 30, 106, 170, 15, 15, 236, 18, 102, 249, 71, 208, 63),
        U1(174, 131, 51, 14, 93, 118, 176, 74, 37)
      }), tostring(_ARG_0_), _ARG_2_, tostring(_ARG_3_)))
      if _ARG_1_ == U2.RelationApplyOp.Agree then
        if type(_ARG_3_) == U1(161, 132, 63, 1, 24, 57) then
        else
        end
        if U3[_ARG_0_] then
          U3[_ARG_0_].change_data[_ARG_2_].update_ts = require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 190, 19, 82, 164, 125, 38, 249, 18, 140))).GetServerTimeInSec(), require((table.concat({
            U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 78, 60, 239, 25, 153, 0, 37, 209, 231, 156, 68, 127, 181, 13, 70, 178, 109, 32, 245, 10, 132, 16),
            U1(162, 144, 59, 13)
          }))), require((table.concat({
            U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 78, 60, 239, 25, 153, 0, 37, 209, 231, 156, 68, 127, 181, 13, 70, 178, 109, 32, 245, 10, 132, 16),
            U1(162, 144, 59, 13)
          }))), require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))), LocUtil.LocalizeResFormat(73286, _ARG_3_), type(_ARG_3_) == U1(161, 132, 63, 1, 24, 57), U3[_ARG_0_].change_data[_ARG_2_]
          U3[_ARG_0_].change_data[_ARG_2_].state = 4
          U3[_ARG_0_].change_data[_ARG_2_].param = _ARG_3_
          if _ARG_2_ == U2.RelationChangeType.CustomName then
            U3[_ARG_0_].custom_name = _ARG_3_
          end
          _ARG_0_ = _ARG_0_
          if U4[require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))).GetIntimacyRelationName(_ARG_3_)].uid == _ARG_0_ then
            U4[require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))).GetIntimacyRelationName(_ARG_3_)].state = 4
            if _ARG_2_ == U2.RelationChangeType.RelationType then
              U4[require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))).GetIntimacyRelationName(_ARG_3_)].param = _ARG_3_
            elseif _ARG_2_ == U2.RelationChangeType.CustomName then
              U4[require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))).GetIntimacyRelationName(_ARG_3_)].custom_name = _ARG_3_
            end
            U4[require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))).GetIntimacyRelationName(_ARG_3_)] = U4[require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 191, 19, 96, 180, 86, 58, 225))).GetIntimacyRelationName(_ARG_3_)]
          else
            _ARG_0_ = _ARG_0_
          end
        end
      elseif _ARG_1_ == U2.RelationApplyOp.Refuse and U3[_ARG_0_] then
        U3[_ARG_0_].change_data[_ARG_2_].update_ts = require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 190, 19, 82, 164, 125, 38, 249, 18, 140))).GetServerTimeInSec(), require((table.concat({
          U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 78, 60, 239, 25, 153, 0, 37, 209, 231, 156, 68, 127, 181, 13, 70, 178, 109, 32, 245, 10, 132, 16),
          U1(162, 144, 59, 13)
        }))), U3[_ARG_0_].change_data[_ARG_2_]
        U3[_ARG_0_].change_data[_ARG_2_].state = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_cancel_change_intimacy_relation_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_cancel_change_intimacy_relation_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 25, 94, 175, 65, 54, 225, 36, 131, 55, 39, 215, 225, 141, 53, 122, 180, 30, 70, 188, 83, 32, 228, 52, 130, 42),
        U1(163, 144, 38, 10, 18, 37, 207, 29, 37, 217, 182, 141, 19, 103, 234, 71, 31, 228, 81, 115, 161, 91, 131, 55, 39, 215, 225, 141, 53, 103, 163, 26, 74, 241, 15, 99, 184, 15, 220, 111),
        U1(191, 144, 32, 2, 16, 107, 173, 79, 115, 218)
      }), tostring(_ARG_0_), _ARG_1_, tostring(_ARG_2_)))
      if U2[_ARG_0_] then
        U2[_ARG_0_].change_data[_ARG_1_].update_ts = require((U1(172, 157, 59, 6, 19, 63, 190, 12, 57, 196, 251, 151, 20, 45, 190, 19, 82, 164, 125, 38, 249, 18, 140))).GetServerTimeInSec(), U2[_ARG_0_].change_data[_ARG_1_]
        U2[_ARG_0_].change_data[_ARG_1_].state = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_notify_change_intimacy_relation_update"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 131, 55, 39, 215, 225, 141, 53, 122, 180, 30, 70, 188, 83, 32, 228, 52, 130, 42),
        U1(163, 144, 38, 10, 18, 37, 207, 26, 38, 205, 247, 140, 31, 35, 172, 8, 86, 158, 87, 58, 233, 91, 221, 127)
      }) .. tostring(_ARG_0_) .. U1(239, 146, 58, 2, 19, 44, 245, 48, 34, 208, 230, 157, 90, 62, 234) .. tostring(_ARG_1_))
      log_tree(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 131, 55, 39, 215, 225, 141, 53, 122, 180, 30, 70, 188, 83, 32, 228, 52, 130, 42),
        U1(163, 144, 38, 10, 18, 37, 207, 26, 38, 205, 247, 140, 31, 35, 169, 18, 94, 175, 69, 54, 210, 31, 129, 43, 39)
      }), _ARG_2_)
      if not U2.GetFriendData(_ARG_0_) then
      end
      if _ARG_1_ == U2.RelationChangeType.RelationType and _ARG_2_ and U2.GetFriendData(_ARG_0_).change_data and U2.GetFriendData(_ARG_0_).change_data[_ARG_1_] then
        if require((U1(172, 158, 63, 14, 18, 37, 190, 27, 55, 203, 250, 157, 37, 118, 190, 19, 83))).GetTableValue(U2.GetFriendData(_ARG_0_), U1(172, 153, 51, 13, 26, 46, 207, 11, 55, 221, 247), _ARG_1_, (U1(188, 133, 51, 23, 24))) then
          _ARG_0_ = _ARG_0_
          if U3[133].uid == _ARG_0_ then
          else
            _ARG_0_ = _ARG_0_
          end
          if U3[133] and U3[133].param ~= U2.GetFriendData(_ARG_0_).change_data[_ARG_1_].param and require((U1(172, 158, 63, 14, 18, 37, 190, 27, 55, 203, 250, 157, 37, 118, 190, 19, 83))).GetTableValue(U2.GetFriendData(_ARG_0_), U1(172, 153, 51, 13, 26, 46, 207, 11, 55, 221, 247), _ARG_1_, (U1(188, 133, 51, 23, 24))) == 4 then
            U3[133].state = U2.GetFriendData(_ARG_0_).change_data[_ARG_1_].state
            U3[133], U3[133].param = U3[133], U2.GetFriendData(_ARG_0_).change_data[_ARG_1_].param
          end
        end
      elseif _ARG_1_ == U2.RelationChangeType.CustomName and _ARG_2_ and _ARG_2_.state and _ARG_2_.state == 4 then
        _ARG_0_ = _ARG_0_
        if U3[133].uid == _ARG_0_ then
          U2.GetFriendData(_ARG_0_).custom_name, U3[133].custom_name = _ARG_2_.param, _ARG_2_.param, U3[133]
        else
          _ARG_0_ = _ARG_0_
        end
      end
      if not U2.GetFriendData(_ARG_0_).change_data then
        U2.GetFriendData(_ARG_0_).change_data = {}
      end
      U2.GetFriendData(_ARG_0_).change_data[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_notify_intimacy_level_up"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 137, 49, 50, 208, 235, 137, 9, 106, 133, 6, 74, 167, 87, 47, 194, 30, 128, 111),
        U1(169, 131, 59, 60, 8, 34, 244, 79, 107, 137, 179, 139, 90, 111, 175, 12, 90, 173, 2, 110, 173, 94, 147, 127)
      }), tostring(_ARG_0_), tostring(_ARG_1_)))
      log_tree(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 137, 49, 50, 208, 235, 137, 9, 106, 133, 6, 74, 167, 87, 47, 194, 30, 128, 111),
        U1(166, 133, 55, 14, 49, 34, 227, 27)
      }), _ARG_2_)
      if not U2.bSetShowIntimayLevelUpSlap then
        U3 = true
        U2.bSetShowIntimayLevelUpSlap = true
      end
      U2.SetIntimacyLevelUpData(_ARG_0_, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_notify_team_result_finished"] = function()
    log(bWriteLog and table.concat({
      U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 20, 80, 181, 75, 53, 244, 36, 148, 58, 39, 212, 217, 154, 15, 96, 175, 6, 91, 142, 84, 42, 243, 2, 131, 39),
      U1(170, 149)
    }))
    return
  end,
  ["on_get_recent_teammate_rsp"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 29, 90, 181, 125, 33, 232, 24, 133, 49, 50, 230, 242, 141, 11, 126, 183, 11, 91, 180, 109, 49, 238, 27))
      U2 = {}
      if _ARG_0_ then
        _ARG_0_ = _ARG_0_
        if _ARG_0_[53].uid > 0 then
          if CDataTable.GetTableData(U1(130, 144, 38, 0, 21, 6, 255, 11, 51, 253, 247, 154, 22, 102), U4(_ARG_0_[53].mode)) then
          else
          end
          U2[_ARG_0_[53].uid] = {
            uid = _ARG_0_[53].uid,
            endtime = _ARG_0_[53].endtime,
            endtimeStr = U3.GetTimeAgoStr(_ARG_0_[53].endtime),
            rank = _ARG_0_[53].rank,
            total = _ARG_0_[53].total,
            score = tostring(_ARG_0_[53].score),
            kill = _ARG_0_[53].kill,
            mode = _ARG_0_[53].mode,
            battleid = _ARG_0_[53].battleid or 0,
            ["modeStr"] = CDataTable.GetTableData(U1(130, 144, 38, 0, 21, 6, 255, 11, 51, 253, 247, 154, 22, 102), U4(_ARG_0_[53].mode)).ModeStr,
            ["modeStr"] = U1()
          }, CDataTable.GetTableData(U1(130, 144, 38, 0, 21, 6, 255, 11, 51, 253, 247, 154, 22, 102), U4(_ARG_0_[53].mode)), _ARG_0_[53].uid
        end
        _ARG_0_ = _ARG_0_
      end
      if 0 < #{} then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_batch_get_profile_rsp"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 24, 94, 181, 65, 59, 210, 28, 133, 43, 25, 203, 227, 139, 15, 125, 174, 30, 74, 176, 95, 46, 252, 31, 149, 16),
        U1(191, 131, 61, 5, 20, 39, 245, 48, 36, 218, 230)
      }))
      EventSystem:postEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_INFO_UPDATE, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["del_inner_friend_req"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return
      end
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 30, 102, 166, 37, 86, 175, 76, 54, 255, 36, 134, 45, 47, 220, 232, 140, 53, 97, 191, 27, 21, 241) .. _ARG_0_)
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_del_inner_friend_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(160, 159, 13, 7, 24, 39, 207, 6, 56, 199, 243, 138, 37, 101, 184, 19, 90, 175, 70, 12, 255, 8, 144, 101) .. _ARG_0_)
      if _ARG_0_ == NetErrorCode_NONE then
        if U2.IsPlatFriend(_ARG_1_) then
          ShowNotice(86240)
        end
        U2.DeleteInnerFriend(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_del_inner_friend_notify"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 30, 90, 173, 125, 58, 227, 21, 133, 45, 25, 223, 244, 129, 15, 125, 190, 53, 65, 190, 70, 42, 251, 18, 208, 58),
        U1(166, 149, 104, 67)
      }) .. tostring(_ARG_0_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["del_inner_friend_batch_req"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 30, 102, 166, 37, 86, 175, 76, 54, 255, 36, 134, 45, 47, 220, 232, 140, 53, 113, 187, 30, 76, 185, 109, 49, 248, 26))
      if _ARG_0_ == nil then
        return
      end
      if #_ARG_0_ == 0 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckSocialRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["del_inner_friend_batch_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 30, 102, 166, 37, 86, 175, 76, 54, 255, 36, 134, 45, 47, 220, 232, 140, 53, 113, 187, 30, 76, 185, 109, 49, 238, 27, 202) .. _ARG_0_)
      if _ARG_0_ ~= NetErrorCode_NONE then
        return
      end
      if not U2.del_friend_time then
        U2.del_friend_timer = require((U1(172, 158, 63, 14, 18, 37, 190, 27, 63, 196, 243, 167, 14, 106, 169, 17, 90, 179))).AddTimer(0, function()
          goto lbl_26
          if U2.IsPlatFriend(nil) and not U3 then
            U3 = true
          end
          ::lbl_26::
          EventSystem:postEvent(EVENTTYPE_FRIEND, EVENTID_FRIEND_DELETE_BATCH_FRIEND)
          if U2.del_friend_timer then
            U4.RemoveTimer(U2.del_friend_timer)
            U2.del_friend_timer = nil
          end
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["invite_offline_friend_req"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 19, 109, 188, 19, 75, 164, 125, 60, 235, 29, 140, 54, 40, 220, 217, 142, 24, 122, 191, 4, 75, 142, 64, 38, 236, 75, 147, 39),
        U1(174, 159, 60, 6, 17, 107, 173, 79)
      }) .. tostring(_ARG_0_))
      U2.InviteChannnel = _ARG_0_
      U2.TokenType = _ARG_1_ or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem).E_TokenType.InviteFriend
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_invite_offline_friend_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 19, 109, 188, 19, 75, 164, 125, 60, 235, 29, 140, 54, 40, 220, 217, 142, 24, 122, 191, 4, 75, 142, 64, 48, 237, 71, 208, 61),
        U1(170, 130, 114, 94, 93)
      }) .. _ARG_0_ .. U1(227, 209, 38, 6, 28, 38, 249, 11, 118, 148, 182) .. tostring(_ARG_1_))
      if _ARG_0_ == NetErrorCode_NONE then
        if not U2.InviteChannnel then
          U2.InviteChannnel = U2.InviteByMessenger
        end
        if require((table.concat({
          U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 25, 108, 164, 28, 86, 166, 12, 16, 225, 18, 133, 49, 50, 244, 231, 139, 24, 124, 169, 68, 127, 164, 80, 47, 244, 24, 152, 29),
          U1(170, 150, 59, 12, 19, 6, 241, 12, 36, 198, 229)
        }))).IsBlueholeOperationRegion() then
          if U2.TokenType == ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem).E_TokenType.InviteFriend then
          else
          end
        end
      elseif _ARG_0_ == U1(187, 148, 51, 14, 34, 34, 227, 48, 48, 220, 250, 148) then
      elseif _ARG_0_ == U1(174, 157, 32, 6, 28, 47, 233, 48, 63, 199, 201, 138, 21, 108, 167) then
      end
      do return end
      _ARG_0_ = U1[179]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConstructInviteLink"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return U1.PrivateConstructInviteLink(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem):GetRegionToken(ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem).E_TokenType.InviteFriend))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConstructMessageInviteLink"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return U1.PrivateConstructInviteLink(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem):GetRegionToken(ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem).E_TokenType.MessageInvite))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PrivateConstructInviteLink"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      do return ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem):GetShareLinkDomain() .. _ARG_0_ .. table.concat({
        U1(224, 148, 36, 6, 19, 63, 191, 6, 56, 223, 255, 140, 31, 115, 166, 27, 70, 238, 75, 61, 233, 30, 152, 113, 46, 205, 235, 132, 85, 126, 181, 14, 90, 189, 87, 126, 172, 91, 192, 124),
        U1(254, 193, 98, 69, 8, 34, 244, 82)
      }) .. _ARG_1_ .. U1(233, 133, 55, 2, 16, 34, 244, 82) .. _ARG_2_ .. U1(233, 130, 32, 0, 64) .. _ARG_3_ .. U1(233, 144, 54, 9, 8, 56, 228, 48, 34, 148) .. _ARG_4_ .. U1(233, 144, 54, 9, 8, 56, 228, 48, 50, 204, 243, 136, 22, 106, 164, 17, 2) .. FuncUtil.GetKeywordByID(3377010) .. require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 70, 54, 232, 11, 140, 54, 40, 210, 168, 132, 5, 116, 179, 9, 112, 181, 87, 38, 237, 7, 153, 33),
        U1(164)
      }))):GetDeeplinkUrlSchemeAppId() .. U1(234, 194, 51, 70, 79, 45, 181, 93, 48, 196, 249, 156, 15, 111, 175, 95, 12, 165, 19, 99, 189, 72, 209, 111, 118, 156, 180, 222, 31, 122, 190, 79, 28, 181) .. _ARG_1_ .. U1(234, 195, 100, 23, 24, 42, 253, 6, 50, 140, 165, 156) .. _ARG_2_ .. U1(234, 195, 100, 16, 15, 40, 181, 92, 50) .. _ARG_3_ .. U1(233, 146, 32, 94) .. ModuleManager.GetModule(ModuleManager.CommonModuleConfig.AdjustSystem):GetShareLinkCr() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasFriend"] = function()
    do return next(U1) end
    return
  end,
  ["ShowReserveBack2LobbyNotify"] = function()
    if not GameStatus.IsInLobbyOrMainCity() then
      return
    end
    return
  end,
  ["ShowReserveFriendGameEndNotify"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(148, 135, 13, 20, 17, 39, 231, 26, 11, 137, 218, 151, 29, 106, 169, 60, 77, 168, 71, 61, 233, 85, 179, 55, 41, 206, 212, 141, 25, 118, 168, 28, 74, 151, 64, 42, 248, 5, 148, 8),
        U1(174, 156, 55, 38, 19, 47, 222, 0, 34, 192, 240, 129, 86, 35, 164, 15, 82, 158, 87, 58, 233, 91, 221, 127)
      }) .. tostring(_ARG_0_) .. U1(239, 151, 32, 12, 16, 107, 173, 79) .. tostring(_ARG_1_))
      if not GameStatus.IsInLobbyOrMainCity() then
        log(bWriteLog and table.concat({
          U1(148, 135, 13, 20, 17, 39, 231, 26, 11, 137, 218, 151, 29, 106, 169, 60, 77, 168, 71, 61, 233, 85, 179, 55, 41, 206, 212, 141, 25, 118, 168, 28, 74, 151, 64, 42, 248, 5, 148, 8),
          U1(174, 156, 55, 38, 19, 47, 222, 0, 34, 192, 240, 129, 90, 113, 175, 14, 74, 179, 76, 115)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_appointment_game_friend_notify"] = function(_ARG_0_, _ARG_1_)
    do
      if nil == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_reserve):IsSingleGameReserveOpen() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["appointment_game_friend_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if nil == _ARG_0_ or _ENV() == _ARG_0_ then
        return
      end
      U1.log(U1.bWriteLog and _ENV(239, 189, 61, 4, 20, 40, 214, 29, 63, 204, 248, 156, 84, 98, 186, 10, 80, 168, 76, 39, 224, 30, 142, 43, 25, 222, 231, 133, 15, 76, 188, 24, 70, 180, 92, 39, 194, 25, 149, 62))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_appointment_game_friend_res"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if nil == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_) then
        return
      end
      if _ARG_1_ == 0 or _ARG_1_ == 1 then
      elseif _ARG_1_ == -2 then
      elseif _ARG_1_ == -1 then
      elseif _ARG_1_ == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_reserve).ErrorCodeConfig.err_friend_appointment_enter_waiting then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["appointment_game_friend_answer"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 27, 115, 186, 21, 86, 175, 86, 62, 232, 21, 148, 0, 33, 216, 235, 141, 53, 117, 168, 3, 74, 191, 86, 28, 252, 5, 131, 56),
        U1(170, 131, 126, 67, 8, 34, 244, 79, 107, 137)
      }) .. tostring(_ARG_0_) .. U1(239, 131, 55, 16, 8, 39, 228, 79, 107, 137) .. tostring(_ARG_1_))
      if nil == _ARG_0_ or U1() == _ARG_0_ then
        return
      end
      if not U2.IsMyFriend(_ARG_0_) then
        log(bWriteLog and table.concat({
          U1(148, 135, 13, 20, 17, 39, 231, 26, 11, 137, 218, 151, 29, 106, 169, 60, 77, 168, 71, 61, 233, 85, 129, 47, 54, 214, 239, 134, 30, 126, 191, 4, 91, 142, 85, 34, 240, 14, 175, 41),
          U1(189, 152, 55, 13, 25, 20, 241, 1, 37, 222, 243, 138, 90, 113, 175, 14, 74, 179, 76)
        }))
        return
      end
      _ARG_0_ = U3(_ARG_0_)
      if _ARG_1_ == 1 or _ARG_1_ == true then
      else
      end
      if 1 == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_notify_appointment_friend_list"] = function(_ARG_0_)
    do
      if nil == _ARG_0_ or next(_ARG_0_) == nil then
        log(bWriteLog and table.concat({
          U1(131, 158, 48, 1, 4, 8, 248, 14, 34, 250, 239, 139, 14, 102, 167, 84, 80, 175, 125, 33, 232, 8, 133, 45, 48, 220, 217, 138, 11, 112, 177, 30, 64, 142, 94, 44, 255, 9, 137, 16),
          U1(161, 158, 38, 10, 27, 50, 176, 10, 59, 217, 226, 129, 90, 111, 163, 9, 75)
        }))
        return
      end
      U2.ReserveBack2Lobby = _ARG_0_
      log_tree(bWriteLog and table.concat({
        U1(148, 135, 13, 20, 17, 39, 231, 26, 11, 137, 218, 151, 29, 106, 169, 60, 77, 168, 71, 61, 233, 85, 143, 49, 25, 215, 233, 156, 3, 117, 163, 53, 78, 161, 66, 44, 244, 5, 132, 34),
        U1(170, 159, 38, 60, 27, 57, 249, 10, 56, 205, 201, 148, 19, 112, 190)
      }), _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_appointment_friend_game_end"] = function(_ARG_0_)
    do
      _ARG_0_ = _ENV(_ARG_0_)
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_friend_reserve):GetReserveInfoByUid(_ARG_0_) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_friend_reserve):GetReserveInfoByUid(_ARG_0_).from then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ParsePassInfo"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        if _ARG_0_.is_buy then
          if _ARG_0_.is_buy == 0 then
          else
          end
        else
        end
        if _ARG_0_.switch then
        else
        end
      end
      do return false, false, _ARG_0_.keep_buy or 0, _ARG_0_.cur_value or 0, _ARG_0_.pass_type or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JoinFriend"] = function(_ARG_0_, _ARG_1_)
    do
      if LobbySystem.isInMatch then
        return
      end
      if not require((U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 86, 54, 236, 22, 149, 47, 104, 213, 233, 143, 3, 112, 133, 30, 74, 176, 95, 28, 232, 27))).CanInviteFriend() then
        return
      end
      if require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 118, 43, 192, 18, 147, 44, 47, 214, 232, 198, 6, 124, 189, 3, 76, 142, 74, 46, 244, 24, 131, 38),
        U1(160, 159, 13, 14, 28, 34, 254)
      }))).IsInXMission() then
        if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).tplan_type or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_).tplan_type == 0 then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InviteFriend"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = U1(_ARG_0_) or 0
      if RoomSystem.IsShowWaiting() then
      else
        if LobbySystem.isInMatch then
          return
        end
        if not require((U2(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 86, 54, 236, 22, 149, 47, 104, 213, 233, 143, 3, 112, 133, 30, 74, 176, 95, 28, 232, 27))).CanInviteFriend(_ARG_0_) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFriendOnlineCount"] = function()
    goto lbl_40
    if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):GetBlackMap()[(nil).uid] and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((nil).uid) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((nil).uid).online and 0 < ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData((nil).uid).online then
    end
    ::lbl_40::
    do return 0 + 1, 0 + 1, 0 + 1 end
    return
  end,
  ["ChangeIgnoreFriendTime"] = function()
    ignoreFriendTime = not ignoreFriendTime
    U1.log(U1.bWriteLog and U1.table.concat({
      U2(148, 135, 13, 20, 17, 39, 231, 26, 11, 229, 249, 159, 19, 96, 140, 8, 86, 164, 76, 55, 163, 56, 136, 62, 40, 222, 227, 161, 13, 125, 181, 24, 74, 151, 64, 42, 248, 5, 148, 27),
      U2(166, 156, 55, 79, 93, 57, 245, 28, 35, 197, 226, 216, 71, 35)
    }) .. U1.tostring(ignoreFriendTime))
    return
  end,
  ["ReserveFriend"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_reserve):GetDefaultReserveMsg() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_reserve):GetDefaultReserveMsg().id
      U1.appointment_game_friend_req(_ARG_0_, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowIntimateRelationComplaint"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_do_friend_top_op_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log((U1(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 214, 21, 109, 149, 30, 80, 158, 68, 33, 228, 30, 142, 59, 25, 205, 233, 152, 53, 124, 170, 53, 93, 162, 66)))
      goto lbl_63
      ;(53).isTop = false
      ;(53).SetTopTimeStamp = 0
      if _ARG_0_[158] then
        ;(53).isTop = true
        if _ARG_1_ and _ARG_1_[158] then
          ;(53).SetTopTimeStamp = _ARG_1_[158]
        else
          ;(53).SetTopTimeStamp = _ARG_0_[158] or 0
        end
      end
      ::lbl_63::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_80
      ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetOriginalTopMap()[_ARG_0_[158] or 0] = 30
      ::lbl_80::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenTeamUpSideBar"] = function()
    return
  end,
  ["GetLoginChannelIcon"] = function()
    if _path then
      U1.log(U1.bWriteLog and U2(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 194, 41, 107, 165, 13, 115, 174, 69, 58, 227, 56, 136, 62, 40, 215, 227, 132, 74, 76, 170, 11, 91, 185, 18) .. U1.tostring(_path))
      return _path, ImageInviteTintColor
    end
    ImageInviteTintColor, _path = U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)), loginchannel_icon_path[U1.import((U2(134, 188, 1, 39, 54, 3, 245, 3, 38, 204, 228))).GetInstance():GetCurLoginPlatform()], U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)), U1.import((U2(134, 188, 1, 39, 54, 3, 245, 3, 38, 204, 228))), U1.import((U2(134, 188, 1, 39, 54, 3, 245, 3, 38, 204, 228))).GetInstance(), U1.import((U2(134, 188, 1, 39, 54, 3, 245, 3, 38, 204, 228))).GetInstance():GetCurLoginPlatform(), U1.log(U1.bWriteLog and U2(131, 158, 53, 10, 30, 13, 226, 6, 51, 199, 242, 194, 41, 107, 165, 13, 115, 174, 69, 58, 227, 56, 136, 62, 40, 215, 227, 132, 74, 99, 187, 30, 71, 241) .. U1.tostring(loginchannel_icon_path[U1.import((U2(134, 188, 1, 39, 54, 3, 245, 3, 38, 204, 228))).GetInstance():GetCurLoginPlatform()]))
    do return loginchannel_icon_path[U1.import((U2(134, 188, 1, 39, 54, 3, 245, 3, 38, 204, 228))).GetInstance():GetCurLoginPlatform()], (U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1))) end
    return
  end,
  ["GetInMainCityFreeFriendList"] = function()
    goto lbl_151
    ::lbl_151::
    do return {} end
    return
  end,
  ["IsAlreadyBonding"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyCountByRelationAndState(_ARG_0_, require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U1(172, 136, 17, 12, 19, 56, 228)
      }))).EIntimacyType.Bonding, require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U1(172, 136, 17, 12, 19, 56, 228)
      }))).EStateType.Has_Build) > 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAlreadyBondingApplying"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyCountByRelationAndState(_ARG_0_, require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U1(172, 136, 17, 12, 19, 56, 228)
      }))).EIntimacyType.Bonding, require((table.concat({
        U1(172, 157, 59, 6, 19, 63, 190, 28, 58, 220, 247, 214, 22, 108, 173, 19, 92, 239, 68, 33, 228, 30, 142, 59, 104, 240, 232, 156, 3, 126, 187, 9, 86, 255, 123, 45, 233, 2, 157, 46),
        U1(172, 136, 17, 12, 19, 56, 228)
      }))).EStateType.Has_Send) > 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
