do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(33, 35, 124, 207, 252)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(33, 35, 116, 217, 225, 132, 161, 18, 10, 72, 212, 207, 40, 21, 172, 170, 211, 18, 8, 251, 16, 178, 148, 97, 56, 83, 213, 198, 49, 63, 152, 169, 209, 10))), nil, {
  ["OnInitialize"] = function(_ARG_0_)
    do
      _ENV = nil
      _ARG_0_.matchInfo = {}
      if not U1 or not U2 then
        _ARG_0_:RequireModeData()
      end
      _ARG_0_.tempMultiSelect = nil
      _ARG_0_._req_ugc = nil
      _ARG_0_.bCheckModeRes = false
      _ARG_0_.hasSelectTxMission = U3.require((U3.table.concat({
        U4(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U4(45, 43, 120, 227, 252, 149, 227, 26, 6, 88, 200, 204, 35, 21, 172, 183, 192, 32, 24, 225, 24)
      }))).GetTxMissionChoiceInLocal()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_TEAMINFO_SYNC, _ARG_0_.OnSyncMatchInfoByTeam, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_MATCH_MODE_SELECTION, _ARG_0_.OnUrlModeJump, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_SOCIAL_ENTRY, _ARG_0_.EnterSocialIsland, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_ENTER_SINGLE_TRAINING, _ARG_0_.OnUrlEnterSingleTraining, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_LOGIN, EVENTID_LOGIN_SUCCESS, _ARG_0_.OnLogin, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_TEAMUP, EVENTID_TEAMUP_NEW_TEAM_MATCH_MODE, _ARG_0_.OnChangeTeamMatchMode, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_LEVEL_UNLOCK, EVENTID_LEVEL_UNLOCK_START_UNLOCK_GUIDE, _ARG_0_.OnStartUnlockGuide, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_NETWORK, EVENTID_LOBBY_SERVER_CONNECT_FAILED, _ARG_0_.OnServerError, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogOut"] = function(_ARG_0_)
    do
      _ENV = nil
      U1 = false
      U2 = nil
      U3 = nil
      U4 = nil
      _ARG_0_._req_ugc = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 143, 145, 31, 26, 79, 197, 224, 42, 51, 174, 171, 202, 40, 28, 241, 10, 131, 155, 62),
        U1(54, 58, 110, 156, 255, 130, 234, 44, 17, 77, 213, 198, 119, 106)
      }) .. tostring(_ARG_1_) .. U1(98, 33, 120, 196, 251, 163, 251, 30, 17, 73, 155, 131) .. tostring(_ARG_2_))
      if _ARG_1_ == GameStatus.Fighting and _ARG_2_ == GameStatus.Lobby then
        if DataMgr.GetNewbieGuideValue(require((U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 36, 175, 175, 208, 22, 8, 162, 19, 175, 152, 38, 22, 99, 223, 214, 42, 56, 179, 173))).NEWBIE_GUIDE_MODULE_ID_FIGHT_GUIDE, -2) then
        else
        end
        if require((U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 36, 175, 175, 208, 22, 8, 162, 19, 175, 152, 38, 22, 99, 223, 214, 42, 56, 179, 173))).newbieTotalGameCnt and require((U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 36, 175, 175, 208, 22, 8, 162, 19, 175, 152, 38, 22, 99, 223, 214, 42, 56, 179, 173))).newbieTotalGameCnt == 2 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSyncMatchInfo"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSyncMatchInfoByTeam"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 143, 145, 28, 12, 82, 210, 254, 60, 46, 185, 160, 235, 1, 27, 243, 45, 169, 187, 58),
        U1(35, 34)
      }))
      if _ARG_3_ and _ARG_3_ ~= ENUM_TeamInfoSyncType.All and _ARG_3_ ~= ENUM_TeamInfoSyncType.Compatible and _ARG_3_ ~= ENUM_TeamInfoSyncType.MatchMode then
        return
      end
      if not require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo then
        return
      end
      _ARG_0_.matchMode = require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo.team_type
      _ARG_0_.bAutoFill = require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo.fill == 1
      if require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo.sub_mode_view_ids then
        _ARG_0_.viewId = require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo.sub_mode_view_ids[1]
        _ARG_0_.viewIDs = require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo.sub_mode_view_ids
        if _ARG_0_.viewId and _ARG_0_.viewId ~= require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).teamInfo.sub_mode_view_ids[1] then
        end
      end
      if _ARG_3_ == ENUM_TeamInfoSyncType.Compatible then
        return
      end
      if not require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).IsTeamLeader() then
        return
      end
      if 1 >= require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).GetTeamNum() then
        return
      end
      if not _ARG_0_.viewId then
        return
      end
      if not _ARG_0_:GetMenuListByViewID(_ARG_0_.viewId) then
        return
      end
      if not ((require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}) and (require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).menuFilter) or not (require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).menuFilter[_ARG_0_:GetMenuListByViewID(_ARG_0_.viewId)[1]] then
        return
      end
      ;(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).menuFilter[_ARG_0_:GetMenuListByViewID(_ARG_0_.viewId)[1]].perspective = _ARG_0_.perspective
      ;(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).menuFilter[_ARG_0_:GetMenuListByViewID(_ARG_0_.viewId)[1]].teamNum = _ARG_0_.teamNum
      ;(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).menuFilter[_ARG_0_:GetMenuListByViewID(_ARG_0_.viewId)[1]].bAutoFill = _ARG_0_.bAutoFill
      if not (require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).modeLogin200 then
        ;(require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U1(49)
        }))).LoadFileToTable_N(require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U1(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).modeLogin200 = true
        ;(require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U1(49)
        }))).LoadFileToTable_N(require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U1(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).multiSelect = nil
      end
      do return end
      _ARG_2_ = _ENV[63]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUrlModeJump"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):IsRestrictBatlleAll() then
        return
      end
      if not require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).IsTeamLeader() then
        return
      end
      if LobbySystem.isInMatch and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomMatchInfo() then
        return
      end
      do return end
      _ARG_2_ = _ENV[126]
    end
  end,
  ["OnUrlEnterSingleTraining"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log_tree(table.concat({
        U1(25, 2, 114, 216, 234, 163, 234, 19, 0, 79, 213, 202, 34, 36, 151, 248, 253, 17, 56, 254, 19, 133, 145, 59, 16, 78, 226, 218, 51, 61, 182, 173, 246, 29, 28, 245, 1, 185, 129, 56),
        U1(98, 63, 124, 206, 238, 157, 252)
      }), _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFromLobby"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFromLobby"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowMainUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ENV = _ARG_2_ or false
      if not U1 or not U2 then
        _ARG_0_:RequireModeData()
        return
      end
      if not U3.require((U3.table.concat({
        U4(5, 46, 112, 217, 195, 133, 238, 81, 40, 67, 197, 141, 1, 37, 168, 186, 203, 81, 47, 237, 12, 165, 209, 2, 26, 88, 212, 224, 56, 54, 191, 171, 214, 6, 18, 242, 65, 157, 128, 59),
        U4(39, 28, 120, 208, 234, 147, 251, 22, 10, 66, 244, 215, 36, 38)
      }))).IsModeSelectionModDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeTeamMatchMode"] = function(_ARG_0_, ...)
    do
      if not (_ARG_0_.old_perspective and _ARG_0_.old_teamNum and _ARG_0_.teamNum) or not _ARG_0_.perspective then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):IsSwitchLTMatchMode() then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_multi_select_match):IsSwitchingMSMatch() then
      end
      if _ARG_0_.old_perspective == _ARG_0_.perspective and _ARG_0_.old_teamNum == _ARG_0_.teamNum then
        return
      end
      _ARG_0_.lastTimeTeamNum = _ARG_0_.old_teamNum
      _ARG_0_.old_perspective = _ARG_0_.perspective
      _ARG_0_.old_teamNum = _ARG_0_.teamNum
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnStartUnlockGuide"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ ~= 8 then
        return
      end
      if not LobbySystem.roleData.is_newbie_rankmode_open then
        log(bWriteLog and table.concat({
          U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 143, 145, 28, 1, 93, 195, 199, 8, 52, 182, 167, 193, 4, 58, 233, 6, 180, 138, 127),
          U1(43, 60, 66, 210, 234, 135, 237, 22, 0, 115, 211, 194, 35, 33, 167, 183, 214, 26, 50, 227, 15, 165, 145)
        }) .. tostring(LobbySystem.roleData.is_newbie_rankmode_open))
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager):GetUnlockFeature(_ARG_3_) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager):GetUnlockFeature(_ARG_3_).currentUnlock == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager).featureDef.matchMode then
        if _ARG_0_:GetFirstAvailableViewId(true) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelectInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_.matchMode then
        return
      end
      _ARG_0_.old_perspective = _ARG_0_.perspective
      _ARG_0_.old_teamNum = _ARG_0_.teamNum
      if not CDataTable.GetTableData(U1(15, 46, 105, 223, 231, 189, 224, 27, 0, 120, 192, 193, 33, 47), tostring(_ARG_0_.matchMode)) then
        return
      end
      _ARG_0_.perspective = CDataTable.GetTableData(U1(15, 46, 105, 223, 231, 189, 224, 27, 0, 120, 192, 193, 33, 47), tostring(_ARG_0_.matchMode)).PersonPerspective
      _ARG_0_.teamNum = CDataTable.GetTableData(U1(15, 46, 105, 223, 231, 189, 224, 27, 0, 120, 192, 193, 33, 47), tostring(_ARG_0_.matchMode)).MaxTeamPlayerNum
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RestoreSelectInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_ then
        return
      end
      log(bWriteLog and table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 146, 154, 60, 1, 83, 195, 214, 14, 63, 182, 173, 193, 27, 52, 242, 9, 191, 207, 50),
        U1(35, 59, 126, 212, 194, 159, 235, 26, 69, 17, 129)
      }) .. tostring(_ARG_1_) .. U1(98, 57, 116, 217, 248, 185, 235, 95, 88, 12) .. tostring(_ARG_2_))
      _ARG_0_.matchMode = _ARG_1_
      _ARG_0_.viewId = _ARG_2_
      _ARG_0_.viewIDs = _ARG_3_
      _ARG_0_:SetSelectInfo()
      EventSystem:postEvent(EVENTTYPE_MATCH, EVENTID_MATCH_MODE_SELECT_CHANGE)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConvertMenuTable"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetSplitTable(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), (U1(52, 38, 120, 203, 208, 157, 234, 17, 16, 115, 213, 194, 47, 38, 175))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConvertViewMultiTable"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      if not CDataTable.GetSplitTable(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), (U1(52, 38, 120, 203, 208, 157, 250, 19, 17, 69, 254, 208, 40, 38, 175, 187, 198, 32, 25, 237, 29, 172, 154))) then
        return
      end
      goto lbl_145
      if CDataTable.GetSplitTable(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), (U1(52, 38, 120, 203, 208, 157, 250, 19, 17, 69, 254, 208, 40, 38, 175, 187, 198, 32, 25, 237, 29, 172, 154)))[U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 131, 144, 33, 3, 89, 195, 199, 11, 51, 191, 191, 239, 26, 17, 232, 6, 132, 142, 61)] then
        U1(46, 42, 61, 210, 224, 208, 236, 19, 12, 73, 207, 215, 109, 41, 172, 191).big_bg = CDataTable.GetSplitTable(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), (U1(52, 38, 120, 203, 208, 157, 250, 19, 17, 69, 254, 208, 40, 38, 175, 187, 198, 32, 25, 237, 29, 172, 154)))[U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 131, 144, 33, 3, 89, 195, 199, 11, 51, 191, 191, 239, 26, 17, 232, 6, 132, 142, 61)].big_bg
        U1(46, 42, 61, 210, 224, 208, 236, 19, 12, 73, 207, 215, 109, 41, 172, 191).small_bg = CDataTable.GetSplitTable(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), (U1(52, 38, 120, 203, 208, 157, 250, 19, 17, 69, 254, 208, 40, 38, 175, 187, 198, 32, 25, 237, 29, 172, 154)))[U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 131, 144, 33, 3, 89, 195, 199, 11, 51, 191, 191, 239, 26, 17, 232, 6, 132, 142, 61)].small_bg
        U1(46, 42, 61, 210, 224, 208, 236, 19, 12, 73, 207, 215, 109, 41, 172, 191).lobby_bg = CDataTable.GetSplitTable(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), (U1(52, 38, 120, 203, 208, 157, 250, 19, 17, 69, 254, 208, 40, 38, 175, 187, 198, 32, 25, 237, 29, 172, 154)))[U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 131, 144, 33, 3, 89, 195, 199, 11, 51, 191, 191, 239, 26, 17, 232, 6, 132, 142, 61)].lobby_bg
      end
      ::lbl_145::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConvertViewTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      if not tonumber(_ARG_2_) then
        return
      end
      if CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))) then
        _ARG_1_.big_bg = CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))).big_bg or U1()
        _ARG_1_.small_bg = CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))).small_bg or U1()
        _ARG_1_.lobby_bg = CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))).lobby_bg or U1()
        _ARG_1_.icon = CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))).icon or U1()
        _ARG_1_.group_icon = CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))).group_icon or U1()
        _ARG_1_.group_icon_background = CDataTable.GetSplitTableData(U1(14, 32, 127, 222, 246), U1(15, 32, 121, 217, 220, 149, 227, 26, 6, 88, 200, 204, 35), U1(52, 38, 120, 203, 208, 147, 224, 17, 17, 77, 200, 205, 18, 62, 171, 186, 222, 26), (tonumber(_ARG_2_))).group_icon_background or U1()
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLastTimeTeamNum"] = function(_ARG_0_)
    do
      do return _ARG_0_.lastTimeTeamNum end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMenuInfo"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetViewDictionary"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSimpleViewInfoDictionary"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMutiViewInfoDictionary"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPeakGameViewID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ == 90091 or _ARG_1_ == 90069 or _ARG_1_ == 90109 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsArenaViewID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ == 90117 or _ARG_1_ == 90118 or _ARG_1_ == 90119 or _ARG_1_ == 90120 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBgCfgByViews"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV then
        return nil
      end
      if not _ARG_1_ or U1.type(_ARG_1_) ~= U2(54, 46, 127, 208, 234) then
        return nil
      end
      U1.table.sort(_ARG_1_)
      goto lbl_54
      if _ARG_0_:IsPeakGameViewID(127) or _ARG_0_:IsArenaViewID(127) then
        return U3[127]
      end
      if U3[127] and U3[127].group_key and _ENV[U3[127].group_key] then
        return _ENV[U3[127].group_key]
      end
      ::lbl_54::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ENV[U1.table.concat(_ARG_1_, (U2(110)))] then
        return _ENV[U1.table.concat(_ARG_1_, (U2(110)))]
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTabInfoByTabID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ENV then
        return
      end
      do return (function(_ARG_0_)
        do
          goto lbl_23
          if (nil).id == U1 then
            return nil
          else
            if (nil).sub_menus and U2((nil).sub_menus) then
              return (U2((nil).sub_menus))
            else
            end
          end
          ::lbl_23::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)(sub_menus) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllTabInfo"] = function(_ARG_0_)
    do
      if not _ENV or not U1.next(_ENV) then
        return
      end
      if not sub_menus or not U1.next(sub_menus) then
        return
      end
      goto lbl_43
      if (nil).id == 100 then
      elseif (nil).id == 200 then
        goto lbl_41
        ::lbl_41::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_43::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        [(nil).id] = (nil).sub_views,
        [(nil).id] = (nil).sub_views
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSubviewInfoBySubviewID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ENV then
        return
      end
      do return _ENV[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSelectMapName"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        log_error(bWriteLog and table.concat({
          U1(25, 21, 85, 225, 175, 156, 224, 24, 12, 79, 254, 206, 34, 46, 175, 135, 193, 26, 1, 233, 28, 180, 150, 32, 27, 6, 246, 214, 41, 9, 191, 164, 199, 12, 9, 209, 14, 160, 161, 62),
          U1(47, 42, 49, 156, 249, 153, 234, 8, 44, 104, 210, 131, 36, 46, 234, 189, 223, 15, 25, 245)
        }))
        return
      end
      do return require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U1(45, 43, 120, 227, 250, 132, 230, 19, 22)
      }))).GetMapNameByViewID(_ARG_1_[1]) or U1() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSelectInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 21, 85, 225, 175, 156, 224, 24, 12, 79, 254, 206, 34, 46, 175, 135, 193, 26, 1, 233, 28, 180, 150, 32, 27, 6, 246, 214, 41, 25, 175, 186, 241, 10, 17, 249, 12, 164, 166, 49),
        U1(36, 32)
      }) .. tostring(_ARG_0_.matchMode) .. U1(98) .. tostring(_ARG_0_.viewId) .. U1(98) .. tostring(_ARG_0_.viewIDs))
      if GameStatus.IsSocialIslandMode() and UIManager.GetUI(UIManager.UI_Config.Sociallsland_SelectMap_UIBP) then
        return _ARG_0_.matchMode, _ARG_0_.viewId, _ARG_0_.viewIDs
      end
      if _ARG_0_.hasSelectTxMission then
        return U2.Enum_TabID.MatchTxMission, U2.C_Xmission_ViewID, {
          U2.C_Xmission_ViewID
        }
      end
      do return _ARG_0_.matchMode, _ARG_0_.viewId, _ARG_0_.viewIDs end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFilterInfo"] = function(_ARG_0_)
    do
      do return {
        ["perspective"] = _ARG_0_.perspective or 100054,
        ["teamNum"] = _ARG_0_.teamNum or 1,
        ["bAutoFill"] = _ARG_0_.bAutoFill
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetValidThemeData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ENV or not _ARG_1_ then
        return nil
      end
      if not (_ENV[_ARG_1_] and _ENV[_ARG_1_].group_type) or _ENV[_ARG_1_].group_type ~= U1(54, 39, 120, 209, 234) then
        return nil
      end
      goto lbl_163
      if U1(42, 42, 112, 217, 203, 145, 251, 30, 69, 95, 196, 209, 59, 47, 184, 140, 219, 18, 8, 172, 66, 224).view_id ~= _ARG_1_ then
        if _ARG_0_:IsThemeOpen(_ENV[U1(42, 42, 112, 217, 203, 145, 251, 30, 69, 95, 196, 209, 59, 47, 184, 140, 219, 18, 8, 172, 66, 224).view_id], U2.require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec(), _ARG_2_ and nil == nil) then
          return _ENV[U1(42, 42, 112, 217, 203, 145, 251, 30, 69, 95, 196, 209, 59, 47, 184, 140, 219, 18, 8, 172, 66, 224).view_id]
        elseif _ARG_0_:IsThemeOpen(_ENV[U1(42, 42, 112, 217, 203, 145, 251, 30, 69, 95, 196, 209, 59, 47, 184, 140, 219, 18, 8, 172, 66, 224).view_id], U2.require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec(), _ARG_2_ and nil == nil) then
        end
      end
      ::lbl_163::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_ then
        return _ENV[U1(42, 42, 112, 217, 203, 145, 251, 30, 69, 95, 196, 209, 59, 47, 184, 140, 219, 18, 8, 172, 66, 224).view_id]
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAnyThemeOpen"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV then
        return false
      end
      goto lbl_91
      if (225).group_type == U2(54, 39, 120, 209, 234) and (225).group_view then
        goto lbl_89
        if (120).view_id ~= (225).id and _ENV[(120).view_id] and _ENV[(120).view_id].is_group_base ~= true and _ENV[(120).view_id].group_type == U2(54, 39, 120, 209, 234) and _ARG_0_:IsThemeOpen(_ENV[(120).view_id], U1.require((U2(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec(), _ARG_1_ == true) then
          return true
        end
        ::lbl_89::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_91::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCpMode"] = function(_ARG_0_, _ARG_1_)
    do
      if not tonumber(_ARG_1_) then
        return false, nil
      end
      if not CDataTable.GetTableDataByFilter(U1(1, 31, 84, 210, 233, 159), U1(20, 38, 120, 203, 198, 180), (tonumber(_ARG_1_))) then
        return false, nil
      end
      do return true, (CDataTable.GetTableDataByFilter(U1(1, 31, 84, 210, 233, 159), U1(20, 38, 120, 203, 198, 180), (tonumber(_ARG_1_)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsThemeOpen"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        return nil, nil
      end
      if _ARG_1_.id and _ARG_0_:IsCpMode(_ARG_1_.id) and _ARG_0_:IsCpMode(_ARG_1_.id) then
        return _ARG_0_:IsCpMode(_ARG_1_.id).CPName == Client.GetUEPUBGMCPName(), false
      end
      if not _ARG_1_.open_limits then
        return true, false
      end
      goto lbl_116
      if require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U1(45, 43, 120, 227, 250, 132, 230, 19, 22)
      }))).IsViewOpen(U1(45, 43, 120, 227, 250, 132, 230, 19, 22)) then
        return true
      else
      end
      ::lbl_116::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil, not _ARG_3_ or false or require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U1(45, 43, 120, 227, 250, 132, 230, 19, 22)
      }))).IsViewPreOpen(U1(45, 43, 120, 227, 250, 132, 230, 19, 22)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsSelectTheme"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return false
      end
      if (require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).themeSelect and type((require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).themeSelect[_ARG_1_.id]) ~= U1(44, 38, 113) then
        return (require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U1(49)
        }))).LoadFileToTable_N(require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U1(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).themeSelect[_ARG_1_.id]
      end
      goto lbl_103
      if (113).view_id == _ARG_1_.id then
        return false
      elseif (113).view_id == _ARG_2_.id then
        return true
      end
      ::lbl_103::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsSelectedThemeView"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:CheckIsTargetThemeView(_ARG_0_:GetCurSelectInfo()) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsTargetThemeView"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ENV and _ENV[_ARG_1_]) then
        return false
      end
      if _ARG_2_ and (_ENV and _ENV[_ARG_1_]).menu_id ~= _ARG_2_ then
        return false
      end
      if not _ARG_0_:GetModeIDByViewID(_ARG_1_) then
      end
      if U1.CDataTable.GetTableData(U2(0, 27, 80, 211, 235, 149), (_ARG_0_:GetModeIDByViewID(_ARG_1_))) and U1.CDataTable.GetTableData(U2(0, 27, 80, 211, 235, 149), (_ARG_0_:GetModeIDByViewID(_ARG_1_))).BattleModeFightType == 1 then
      end
      do return true end
      do return end
      _ARG_0_ = U1[146]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModeIDByViewID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_) then
        return
      end
      if not _ENV then
        _ENV = {}
        goto lbl_24
        goto lbl_22
        _ENV[(nil).id] = nil, nil, U1.pairs(nil)
        ::lbl_22::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_24::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return _ENV[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMatchModeByViewId"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_) or not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).options then
        return nil
      end
      if not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).options.team_type then
        return nil
      end
      _ARG_2_ = _ARG_2_ or _ARG_0_:GetFilterInfo().perspective
      _ARG_3_ = _ARG_3_ or _ARG_0_:GetFilterInfo().teamNum
      if not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).options.team_type[_ARG_2_] then
        return nil
      end
      do return _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).options.team_type[_ARG_2_][_ARG_3_] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNormalViewIdByThemeId"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if not U1.require((U1.table.concat({
        U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U2(45, 43, 120, 227, 250, 132, 230, 19, 22)
      }))).IsThemeGroupView(_ENV and _ENV[_ARG_1_]) then
        return
      end
      if (_ENV and _ENV[_ARG_1_]).is_group_base then
        return
      end
      goto lbl_93
      if U2(45, 43, 120, 227, 250, 132, 230, 19, 22).note == U2(32, 46, 110, 217) then
        return U2(45, 43, 120, 227, 250, 132, 230, 19, 22).view_id
      end
      ::lbl_93::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMenuListByViewID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV or not U1 then
        return {}
      end
      do return U2(U1, _ARG_1_, {}) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetViewTypeMenuList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV or _ARG_1_ then
        _ENV = U1()
        _ARG_0_:GetAllModeInfo(_ARG_1_)
      end
      do return _ENV or {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllModeInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV or _ARG_1_ then
        _ENV = U1()
      end
      do return _ENV or {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMaxPlayerNumByViewId"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ENV then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(25, 57, 66, 203, 227, 156, 248, 10, 56, 12, 205, 204, 42, 35, 169, 135, 223, 16, 9, 233, 32, 179, 154, 35, 16, 95, 197, 218, 50, 52, 224, 143, 199, 27, 48, 253, 23, 128, 131, 62),
          U2(59, 42, 111, 242, 250, 157, 205, 6, 51, 69, 196, 212, 4, 46, 234, 182, 219, 19, 65, 172, 9, 169, 154, 56, 60, 88, 145, 142, 125)
        }) .. U1.tostring(_ARG_1_))
        return
      end
      if not U1.require((U2(33, 32, 112, 209, 224, 158, 161, 11, 4, 78, 205, 198, 18, 63, 190, 177, 222))).GetTableValue(_ENV, _ARG_1_, U2(45, 63, 105, 213, 224, 158, 252), (U2(54, 42, 124, 209, 208, 132, 246, 15, 0))) then
        return
      end
      goto lbl_257
      goto lbl_255
      if U2(98) > 0 then
      end
      ::lbl_255::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_257::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return U2(98) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModeMaxTeamNum"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetMaxPlayerNumByViewId(_ARG_0_:GetCurSelectInfo()) or 4 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSelect8PlayersMode"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID() > 0 then
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo() or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().setting then
        elseif (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().setting.team_size or 1) == -1 then
        end
        return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().setting.max_num or 1) >= 5
      end
      do return _ARG_0_:GetModeMaxTeamNum() == 8 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsClassicRankMode"] = function(_ARG_0_, _ARG_1_)
    do
      do return ({
        [101] = true,
        [102] = true,
        [103] = true,
        [401] = true,
        [402] = true,
        [403] = true,
        [11201] = true,
        [723] = true
      })[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsClassicMatchMode"] = function(_ARG_0_, _ARG_1_)
    do
      do return ({
        [111] = true,
        [112] = true,
        [113] = true,
        [411] = true,
        [412] = true,
        [413] = true
      })[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModeJumpActivity"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 12, 239, 11, 169, 137, 38, 1, 69, 159, 223, 50, 61, 179, 171, 253, 14, 30, 232, 6, 166, 134, 43),
        U1(59, 16, 112, 219, 253)
      }))).GetActivityListByType(ActivityType.GAME_URI)[1] and require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) and require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI).actClick and require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI).actClick[require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 12, 239, 11, 169, 137, 38, 1, 69, 159, 223, 50, 61, 179, 171, 253, 14, 30, 232, 6, 166, 134, 43),
        U1(59, 16, 112, 219, 253)
      }))).GetActivityListByType(ActivityType.GAME_URI)[1].ID] then
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHasMapKey"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return false
      end
      do return _ENV[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMenuPathStrByMapId"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapIdListByTabId() or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapIdListByTabId())) then
        return
      end
      goto lbl_42
      goto lbl_40
      if nil == tonumber(_ARG_1_) then
        return U1.jumpMenuConfig[nil] or U2()
      end
      ::lbl_40::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_42::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return (U2()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMenuPathStrByMapKey"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapIdListByTabId() or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapIdListByTabId())) then
        return
      end
      goto lbl_51
      goto lbl_49
      if CDataTable.GetTableData(U1(15, 46, 109), nil) and CDataTable.GetTableData(U1(15, 46, 109), nil).MapKey == _ARG_1_ then
        return U2.jumpMenuConfig[nil] or U1()
      end
      ::lbl_49::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_51::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return (U1()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDefaultViewID"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelectView"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ENV then
        return
      end
      if U1.type(_ARG_1_) == U2(44, 58, 112, 222, 234, 130) and _ARG_1_ == _ARG_0_.viewId and U1.type(_ARG_0_.viewIDs) == U2(54, 46, 127, 208, 234) and #_ARG_0_.viewIDs > 1 then
      end
      if not {_ARG_1_} then
        return
      end
      if _ARG_3_ then
        if U1.type(_ARG_1_) == U2(44, 58, 112, 222, 234, 130) then
        elseif U1.type(_ARG_1_) == U2(54, 46, 127, 208, 234) then
        end
        if U1.require((U2(33, 32, 112, 209, 224, 158, 161, 11, 4, 78, 205, 198, 18, 63, 190, 177, 222))).IsSameTable(_ARG_1_, _ARG_0_.viewIDs) and _ARG_2_.perspective == _ARG_0_.perspective and _ARG_2_.teamNum == _ARG_0_.teamNum and _ARG_2_.bAutoFill == _ARG_0_.bAutoFill then
          return
        end
      end
      if _ARG_2_.teamNum == 1 then
        _ARG_2_.bAutoFill = false
      end
      _ARG_0_ = _ARG_0_
      if not _ENV[({_ARG_1_})[217]] or not _ARG_0_:IsModeMapAvailable(_ENV[({_ARG_1_})[217]]) then
        if not (_ENV[({_ARG_1_})[217]] and _ENV[({_ARG_1_})[217]].menu_id == U1.require((U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 12, 254, 26, 174, 158, 97, 22, 83, 223, 213, 52, 61, 133, 169, 208, 10, 19, 253))).ModeMenuId) then
        end
      end
      _ARG_0_ = _ARG_0_
      if #{_ARG_1_} == 0 then
        if U1.type(_ARG_1_) == U2(44, 58, 112, 222, 234, 130) then
        elseif U1.type(_ARG_1_) == U2(54, 46, 127, 208, 234) then
        end
        if true and not _ARG_3_ then
        end
        return
      end
      if _ENV[({_ARG_1_})[1]].url and _ENV[({_ARG_1_})[1]].url ~= U2() then
        if U1.tonumber(U1.require((U2(33, 32, 112, 209, 224, 158, 161, 12, 17, 94, 200, 205, 42, 21, 191, 172, 219, 19))).ParseURLParams(_ENV[({_ARG_1_})[1]].url).module) == U1.BP_ENUM_MODULE_MATCH_MODE_SELECTION then
          if U1.UIManager.IsUIShow((U1.require((U1.table.concat({
            U2(5, 46, 112, 217, 195, 133, 238, 81, 40, 67, 197, 141, 1, 37, 168, 186, 203, 81, 62, 252, 19, 169, 139, 97, 56, 83, 213, 214, 14, 63, 182, 173, 193, 27, 20, 243, 1, 228, 216, 111),
            U2(108, 35, 114, 219, 230, 147, 161, 18, 10, 72, 196, 252, 59, 35, 175, 175, 237, 9, 95, 211, 10, 180, 150, 35, 6)
          }))).GetModeMainUIConfigDefault())) then
            if U1.UIManager.GetUI((U1.require((U1.table.concat({
              U2(5, 46, 112, 217, 195, 133, 238, 81, 40, 67, 197, 141, 1, 37, 168, 186, 203, 81, 62, 252, 19, 169, 139, 97, 56, 83, 213, 214, 14, 63, 182, 173, 193, 27, 20, 243, 1, 228, 216, 111),
              U2(108, 35, 114, 219, 230, 147, 161, 18, 10, 72, 196, 252, 59, 35, 175, 175, 237, 9, 95, 211, 10, 180, 150, 35, 6)
            }))).GetModeMainUIConfigDefault())) then
            end
          elseif U1.UIManager.IsUIShow(U1.UIManager.UI_Config.Sociallsland_SelectMap_UIBP) and U1.UIManager.GetUI(U1.UIManager.UI_Config.Sociallsland_SelectMap_UIBP) then
          end
        end
        if not true then
        end
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_newbie_mode_selection):IsNewbieView(_ARG_1_) then
        end
        if not true and not (U1.tonumber(U1.require((U2(33, 32, 112, 209, 224, 158, 161, 12, 17, 94, 200, 205, 42, 21, 191, 172, 219, 19))).ParseURLParams(_ENV[({_ARG_1_})[1]].url).module) == U1.BP_ENUM_MODULE_MATCH_MODE_SELECTION) and (U1.type(_ARG_1_) ~= U2(44, 58, 112, 222, 234, 130) or not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_newbie_mode_selection):IsNewbieView(_ARG_1_)) then
        end
        return
      end
      if not _ENV[({_ARG_1_})[1]].options then
        return
      end
      if not _ENV[({_ARG_1_})[1]].options.team_type[_ARG_2_.perspective] then
        _ARG_2_.perspective = _ENV[({_ARG_1_})[1]].options.default_person
      end
      if not _ENV[({_ARG_1_})[1]].options.team_type[_ARG_2_.perspective][_ARG_2_.teamNum] then
        _ARG_2_.teamNum = _ENV[({_ARG_1_})[1]].options.default_team_size
      end
      if U1.require((U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).GetTeamNum() > _ARG_2_.teamNum then
        return
      end
      if _ARG_2_.teamNum > U1.require((U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).GetDefaultMaxTeamNum() and U1.require((U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).IsMemberInSocialLand() then
        return
      end
      if not U1.require((U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).IsTeamLeader() then
        return
      end
      _ARG_0_.selectedID = ({_ARG_1_})[1]
      if _ENV[({_ARG_1_})[1]].options.fill_team and _ENV[({_ARG_1_})[1]].options.fill_team.mutable == false then
        _ARG_2_.bAutoFill = _ENV[({_ARG_1_})[1]].options.fill_team.default
      end
      if U1.require((U1.table.concat({
        U2(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 30, 233, 24, 173, 154, 33, 1, 108, 195, 220, 48, 53, 174, 161, 205, 1, 46, 229, 1, 179, 193, 51),
        U2(45, 40, 116, 223, 208, 131, 234, 24, 8, 73, 207, 215, 18, 58, 184, 183, 223, 16, 25, 229, 16, 174, 160, 60, 12, 82, 210)
      }))) then
      end
      if not _ARG_3_ then
      end
      if _ARG_4_ then
      else
      end
      do return true, {_ARG_1_} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsXMissionMode"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ENV) or not _ENV[_ARG_1_] then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(25, 57, 66, 203, 227, 156, 248, 10, 56, 12, 205, 204, 42, 35, 169, 135, 223, 16, 9, 233, 32, 179, 154, 35, 16, 95, 197, 218, 50, 52, 224, 129, 209, 55, 48, 245, 28, 163, 134, 48),
          U2(44, 2, 114, 216, 234, 208, 235, 30, 17, 77, 129, 202, 62, 106, 175, 170, 192, 16, 31, 172)
        }) .. U1.tostring(_ARG_1_))
        return true
      end
      if not _ENV[_ARG_1_].url then
        return false
      end
      if _ENV[_ARG_1_].url == U2() then
        return false
      end
      if U1.string.find(_ENV[_ARG_1_].url, U1.tostring(U1.BP_ENUM_MODULE_TXMISSION_LOBBY_FROM_JUMP)) ~= nil then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurOpenThemeViewId"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 135, 154, 59, 54, 73, 195, 252, 45, 63, 180, 156, 202, 10, 16, 249, 57, 185, 138, 40),
        U1(11, 43, 61, 207, 251, 145, 253, 11)
      }))
      goto lbl_102
      goto lbl_100
      if _ARG_0_:GetValidThemeData(U1(11, 43, 61, 207, 251, 145, 253, 11).id, false) and _ARG_0_:GetSubviewInfoBySubviewID(U1(11, 43, 61, 207, 251, 145, 253, 11).id) and _ARG_0_:GetIsSelectTheme(_ARG_0_:GetSubviewInfoBySubviewID(U1(11, 43, 61, 207, 251, 145, 253, 11).id), (_ARG_0_:GetValidThemeData(U1(11, 43, 61, 207, 251, 145, 253, 11).id, false))) and (not nil or nil > _ARG_0_:GetValidThemeData(U1(11, 43, 61, 207, 251, 145, 253, 11).id, false).id) then
      end
      ::lbl_100::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_102::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return _ARG_0_:GetValidThemeData(U1(11, 43, 61, 207, 251, 145, 253, 11).id, false).id or 10001 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsModeMapAvailable"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapKeyListByViewData(_ARG_1_) then
        return true
      end
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapListState(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapKeyListByViewData(_ARG_1_)) == ENUM_DownloadState.Done end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetModeToAvailableMap"] = function(_ARG_0_)
    do
      if not _ENV or not _ARG_0_.viewIDs then
        return
      end
      if U1 then
        return
      end
      U1 = true
      if U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsSelectUgcMode() then
        return
      end
      if U2.require((U3(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).GetTeamNum() > 1 then
        return
      end
      goto lbl_196
      if _ENV[132] then
        if not _ARG_0_:IsModeMapAvailable(_ENV[132]) then
        elseif _ARG_0_:CheckSubViewIsOpen(_ENV[132].id) then
        end
      end
      ::lbl_196::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not true then
        return
      end
      if #{} <= 0 then
      end
      if not (U2.require((U2.table.concat({
        U3(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U3(45, 43, 120, 227, 250, 132, 230, 19, 22)
      }))).GetMtchIdByViewData(_ENV[({
        U4 or 10201
      })[1]], _ARG_0_.perspective, _ARG_0_.teamNum) and {
        U4 or 10201
      }) or 0 >= #{
        U4 or 10201
      } then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ForceResetModeToAvailableMap"] = function(_ARG_0_)
    do
      if not _ENV or not _ARG_0_.viewIDs then
        return false
      end
      if not (U2.require((U2.table.concat({
        U3(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 3, 18, 251, 6, 179, 176, 50),
        U3(45, 43, 120, 227, 250, 132, 230, 19, 22)
      }))).GetMtchIdByViewData(_ENV[({
        U1 or 10201
      })[1]], _ARG_0_.perspective, _ARG_0_.teamNum) and {
        U1 or 10201
      }) or #{
        U1 or 10201
      } <= 0 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSubViewNew"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ENV then
        return false
      end
      if not _ENV[_ARG_1_] then
        return false
      end
      if _ENV[_ARG_1_].is_new and _ENV[_ARG_1_].is_new == 1 then
        if (U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).mapClick and (U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).mapClick[_ARG_1_] then
          return false, U1.require((U1.table.concat({
            U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
            U2(49)
          }))).LoadFileToTable_N(U1.require((U1.table.concat({
            U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
            U2(49)
          }))).ePlayerPrefsType.eModeSelectionMainUI) or {}
        end
        return true, U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSubViewNew2"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ENV then
        return false
      end
      if not _ENV[_ARG_1_] then
        return false
      end
      if not _ENV[_ARG_1_].is_new then
        return false
      end
      if _ENV[_ARG_1_].is_new == 2 then
        if (U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUINewDetail) or {}).mapClick and (U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUINewDetail) or {}).mapClick[_ARG_1_] then
          return false, U1.require((U1.table.concat({
            U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
            U2(49)
          }))).LoadFileToTable_N(U1.require((U1.table.concat({
            U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
            U2(49)
          }))).ePlayerPrefsType.eModeSelectionMainUINewDetail) or {}
        end
        return true, U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUINewDetail) or {}
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClickSubViewDetail"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ENV then
        return false
      end
      if not _ENV[_ARG_1_] then
        return false
      end
      if not _ENV[_ARG_1_].is_new then
        return false
      end
      if _ENV[_ARG_1_].is_new == 2 then
        _ARG_2_ = _ARG_2_ or U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUINewDetail) or {}
        if not _ARG_2_.mapClick then
          _ARG_2_.mapClick = {}
        end
        if not _ARG_2_.mapClick[_ARG_1_] then
          _ARG_2_.mapClick[_ARG_1_] = 1
        end
      end
      do return false, _ARG_2_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckSubViewIsOpen"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_1_ and _ENV) or not _ENV[_ARG_1_] then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(25, 57, 66, 235, 227, 156, 248, 10, 56, 12, 205, 204, 42, 35, 169, 135, 223, 16, 9, 233, 32, 179, 154, 35, 16, 95, 197, 218, 50, 52, 224, 139, 202, 10, 30, 247, 60, 165, 141, 9),
          U2(43, 42, 106, 245, 252, 191, 255, 26, 11, 12, 207, 204, 57, 106, 165, 168, 215, 17, 77)
        }) .. U1.tostring(_ARG_1_))
        return
      end
      if not _ENV[_ARG_1_].open_limits then
      else
      end
      if U3:GetTimeLimitStr(_ENV[_ARG_1_]) and not _ARG_2_ and (not (_ENV[_ARG_1_].level_limit <= U1.DataMgr.roleData.level) or not ((_ENV[_ARG_1_].pre_level_limit or 0) <= (U1.DataMgr.roleData.pve_level or 0))) then
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckMapKeyNeedDownload"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):IsDefaultMapKey(_ARG_1_) then
        return false
      end
      if _ARG_1_ == U1(47, 46, 109, 227, 252, 159, 236, 22, 4, 64, 200, 208, 33, 43, 164, 188) or _ARG_1_ == U1(47, 46, 109, 227, 252, 153, 225, 24, 9, 73, 213, 209, 44, 35, 164, 177, 220, 24) then
        return true
      end
      if require((U1(33, 32, 112, 209, 224, 158, 161, 12, 17, 94, 200, 205, 42, 21, 191, 172, 219, 19))).Starts(_ARG_1_, (U1(47, 46, 109, 227, 251, 128, 227, 30, 11))) then
        _ARG_1_ = U1(47, 46, 109, 227, 251, 128, 227, 30, 11)
      end
      if _ARG_0_:CheckHasMapKey(_ARG_1_) then
        return true
      end
      if require((U1(33, 32, 112, 209, 224, 158, 161, 12, 17, 94, 200, 205, 42, 21, 191, 172, 219, 19))).Starts(_ARG_1_, (U1(47, 46, 109, 227, 255, 130, 230, 18, 0, 75, 212, 202, 41, 47))) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshModeSelectionGuideUIToLobby"] = function(_ARG_0_)
    do
      if not _ARG_0_.selectedID then
        return
      end
      if DataMgr.HaveNewbieGuide(require((U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 36, 175, 175, 208, 22, 8, 162, 19, 175, 152, 38, 22, 99, 223, 214, 42, 56, 179, 173))).NEWBIE_GUIDE_MODULE_ID_MATCH_FIRST_SELECT, _ARG_0_.selectedID) then
        if not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_0_.selectedID) or not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_0_.selectedID).details then
          return
        end
        goto lbl_260
        if (_ARG_0_:GetSubviewInfoBySubviewID(_ARG_0_.selectedID).details[161] or {}).force_popup then
          if (_ARG_0_:GetSubviewInfoBySubviewID(_ARG_0_.selectedID).details[161] or {}).type == 5 then
            if require((table.concat({
              U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 27, 229, 27, 165, 144, 97, 25, 83, 211, 209, 36, 5, 172, 161, 198, 10, 18, 195, 9, 165, 129, 60),
              U1(54, 38, 114, 210, 208, 156, 230, 29, 23, 77, 211, 218)
            }))).IsVideoFileReady((_ARG_0_:GetSubviewInfoBySubviewID(_ARG_0_.selectedID).details[161] or {}).pads[1].url or U1()) then
            else
            end
          else
          end
        end
        ::lbl_260::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if not true then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DelayCloseMainUI"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenModeSelectionDetails"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        log_error((U1(25, 21, 85, 225, 175, 191, 255, 26, 11, 97, 206, 199, 40, 25, 175, 180, 215, 28, 25, 229, 16, 174, 187, 42, 1, 93, 216, 223, 46, 122, 180, 167, 130, 25, 20, 249, 24, 240, 134, 59)))
        return
      end
      if not (_ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_) and _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).details) or not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).details[1] then
        return
      end
      if not require((table.concat({
        U1(5, 46, 112, 217, 195, 133, 238, 81, 40, 67, 197, 141, 1, 37, 168, 186, 203, 81, 47, 237, 12, 165, 209, 2, 26, 88, 212, 224, 56, 54, 191, 171, 214, 6, 18, 242, 65, 157, 128, 59),
        U1(39, 28, 120, 208, 234, 147, 251, 22, 10, 66, 244, 215, 36, 38)
      }))).IsModeSelectionModDownloaded() then
        return
      end
      if _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).details[1].type == require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 2, 18, 248, 10, 143, 156, 58),
        U1(46, 42, 126, 200, 230, 159, 225, 32, 8, 77, 194, 209, 34)
      }))).E_UITYPE.TEXT then
      elseif _ARG_0_:GetSubviewInfoBySubviewID(_ARG_1_).details[1].type == require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 227, 27, 165, 160, 60, 16, 80, 212, 208, 41, 51, 181, 166, 140, 2, 18, 248, 10, 143, 156, 58),
        U1(46, 42, 126, 200, 230, 159, 225, 32, 8, 77, 194, 209, 34)
      }))).E_UITYPE.GAMEGUIDE then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClickSubView"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ENV then
        return false
      end
      if not _ENV[_ARG_1_] then
        return false
      end
      if not _ENV[_ARG_1_].is_new then
        return false
      end
      if _ENV[_ARG_1_].is_new == 1 then
        _ARG_2_ = _ARG_2_ or U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).LoadFileToTable_N(U1.require((U1.table.concat({
          U2(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
          U2(49)
        }))).ePlayerPrefsType.eModeSelectionMainUI) or {}
        if not _ARG_2_.mapClick then
          _ARG_2_.mapClick = {}
        end
        if not _ARG_2_.mapClick[_ARG_1_] then
          _ARG_2_.mapClick[_ARG_1_] = 1
        end
      end
      do return false, _ARG_2_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTempMultiSelect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ENV then
        return
      end
      if not _ENV[_ARG_1_] then
        return
      end
      if not _ENV[_ARG_1_].group_view then
        if _ARG_2_ then
          _ARG_0_.tempMultiSelect = {_ARG_1_}
        end
        return
      end
      if not _ARG_0_.tempMultiSelect then
        _ARG_0_.tempMultiSelect = {}
      end
      if _ARG_2_ then
        goto lbl_57
        if (nil).view_id == _ARG_1_ then
        else
          goto lbl_55
          if (nil).view_id == nil then
          else
            ::lbl_55::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
        ::lbl_57::
        _ARG_0_ = _ARG_0_
        _ARG_0_.tempMultiSelect, _ARG_0_ = {}, _ARG_0_
      else
        goto lbl_73
        if _ARG_1_ == nil then
          return
        end
        ::lbl_73::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTimeLimitStr"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_1_.open_limits then
        return true, _ENV(), 0
      end
      goto lbl_194
      if U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() >= (28).begin_timestamp and U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() <= (28).close_timestamp then
        if (28).notice_content ~= 0 then
        end
        if (28).open_type == 0 and U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() % 86400 <= (28).close_timestamp % 86400 and U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() % 86400 >= (28).begin_timestamp % 86400 then
          return true, U1.LocUtil.LocalizeResFormat((28).notice_content), 0, 28
        end
        if (28).open_type == 1 then
          return true, U1.LocUtil.LocalizeResFormat((28).notice_content), 0, 28
        end
        if (28).open_type == 2 and U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec())) >= U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((28).begin_timestamp) and U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec())) <= U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((28).close_timestamp) then
          return true, U1.LocUtil.LocalizeResFormat((28).notice_content), 0, 28
        end
      end
      if U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() <= (28).close_timestamp then
        if (28).open_type == 0 then
          if U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() < (28).begin_timestamp then
          elseif U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() > U1.math.floor(U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() / 86400) * 86400 + (28).close_timestamp % 86400 then
          end
          if 0 == 0 or 0 >= U1.math.floor(U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() / 86400) * 86400 + (28).begin_timestamp % 86400 + 86400 then
          end
        elseif (28).open_type == 1 and U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() < (28).begin_timestamp then
          if U1.math.floor(U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() / 86400) * 86400 + (28).begin_timestamp % 86400 + 86400 == 0 or (28).begin_timestamp < U1.math.floor(U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() / 86400) * 86400 + (28).begin_timestamp % 86400 + 86400 then
          end
        elseif (28).open_type == 2 then
          if U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() < (28).begin_timestamp then
          elseif U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec())) < U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((28).begin_timestamp) then
          elseif U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec())) > U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((28).close_timestamp) then
          elseif U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((28).close_timestamp) >= U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetWeekDayByTime((U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec())) + 1 then
          else
          end
          if 0 < 0 and ((28).begin_timestamp == 0 or (28).begin_timestamp >= 0) then
          end
        end
      end
      ::lbl_194::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < 0 then
      end
      do return false, _ENV(), 0 - U1.require((_ENV(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnJumpActivityUrl"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      ;(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).actClick = (require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).actClick or {}
      ;(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).LoadFileToTable_N(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 19, 10, 75, 200, 192, 99, 6, 165, 191, 219, 28, 61, 224, 30, 185, 154, 61, 37, 78, 212, 213, 46, 116, 170, 164, 195, 22, 24, 238, 31, 162, 138, 57),
        U1(49)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).actClick[_ARG_1_.ID] = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterSocialIsland"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager):IsFeatureUnlocked(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.level_unlock_manager).featureDef.socialIsland) then
        return
      end
      if require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 17, 0, 88, 214, 204, 63, 33, 228, 136, 192, 16, 25, 227, 28, 175, 147, 97, 38, 83, 210, 218, 60, 54, 147, 187, 206, 14, 19, 248, 39, 177, 129, 59),
        U1(46, 42, 111)
      }))).pvt_socialland_info and tostring(require((table.concat({
        U1(33, 35, 116, 217, 225, 132, 161, 17, 0, 88, 214, 204, 63, 33, 228, 136, 192, 16, 25, 227, 28, 175, 147, 97, 38, 83, 210, 218, 60, 54, 147, 187, 206, 14, 19, 248, 39, 177, 129, 59),
        U1(46, 42, 111)
      }))).pvt_socialland_info.owner) == tostring(DataMgr.roleData.uid) then
        if not LobbySystem.CheckLobbyMenuOpen(BP_ENUM_SOCIAL_ISLAND_PVT_SWITCH, true) then
          return
        end
      else
        if not LobbySystem.CheckLobbyMenuOpen(BP_ENUM_SOCIAL_ISLAND_SWITCH, true) then
          return
        end
        if require((table.concat({
          U1(33, 35, 116, 217, 225, 132, 161, 17, 0, 88, 214, 204, 63, 33, 228, 136, 192, 16, 25, 227, 28, 175, 147, 97, 38, 83, 210, 218, 60, 54, 147, 187, 206, 14, 19, 248, 39, 177, 129, 59),
          U1(46, 42, 111)
        }))).ReqEnterSystemIsland() and type(_ARG_1_) == U1(36, 58, 115, 223, 251, 153, 224, 17) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FindAllPeakGameView"] = function(_ARG_0_)
    do
      goto lbl_14
      if (nil).menu_id == 120 then
      end
      ::lbl_14::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPeakGameView"] = function(_ARG_0_)
    do
      if _ARG_0_:GetCurSelectInfo() and next(_ARG_0_:GetCurSelectInfo()) then
        goto lbl_21
        if _ARG_0_:IsPeakGameViewID(nil) then
          return true
        end
        ::lbl_21::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FindAllArenaGameView"] = function(_ARG_0_)
    do
      goto lbl_55
      if (217).menu_id == require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 12, 254, 26, 174, 158, 97, 22, 83, 223, 213, 52, 61, 133, 169, 208, 10, 19, 253))).ModeMenuId then
      end
      ::lbl_55::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetViewDataListByTabID"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_0_:GetTabInfoByTabID(_ARG_1_) and _ARG_0_:GetTabInfoByTabID(_ARG_1_).sub_views) then
        return {}
      end
      goto lbl_112
      if _ARG_0_:GetSubviewInfoBySubviewID(string.format(table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 135, 154, 59, 35, 85, 212, 196, 25, 59, 174, 169, 238, 6, 14, 232, 45, 169, 187, 62),
        U1(32, 6, 89, 156, 225, 159, 175, 12, 16, 78, 254, 213, 36, 47, 189, 171, 146, 25, 2, 254, 95, 180, 158, 45, 60, 88, 139, 147, 120, 41)
      }), tostring(_ARG_1_))) then
      end
      ::lbl_112::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnNotifyViewIdConflict"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if _ARG_1_ == 31042 then
        if (_ARG_3_ and _ARG_3_[1] or 0) == 0 then
          return
        end
        if not _ARG_0_:GetSubviewInfoBySubviewID(_ARG_3_ and _ARG_3_[1] or 0) then
          return
        end
        if _ARG_4_ and _ARG_4_.simple and _ARG_4_.simple ~= 0 then
          if LocUtil.GetLocalizeResStr(_ARG_4_.simple) and LocUtil.GetLocalizeResStr(_ARG_4_.simple) ~= U1() then
          end
        end
      elseif _ARG_1_ == 31043 then
        if require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 25, 233, 30, 173, 138, 63, 91, 80, 222, 212, 52, 57, 133, 188, 199, 14, 16, 195, 26, 160))).IsTeamLeader() then
        end
      elseif _ARG_1_ == 31044 then
        _ARG_0_:RequireModeData()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogin"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequireModeData"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 45, 114, 200, 234, 156, 230, 10, 56, 12, 205, 204, 42, 35, 169, 135, 223, 16, 9, 233, 32, 179, 154, 35, 16, 95, 197, 218, 50, 52, 224, 154, 199, 30, 8, 245, 29, 181, 162, 48),
        U1(38, 42, 89, 221, 251, 145)
      }))
      log(bWriteLog and table.concat({
        U1(25, 45, 114, 200, 234, 156, 230, 10, 56, 12, 205, 204, 42, 35, 169, 135, 223, 16, 9, 233, 32, 179, 154, 35, 16, 95, 197, 218, 50, 52, 224, 154, 199, 30, 8, 245, 29, 181, 162, 48),
        U1(38, 42, 89, 221, 251, 145, 175, 12, 0, 66, 197, 252, 42, 47, 190, 135, 223, 16, 9, 233, 32, 179, 151, 38, 16, 80, 213, 236, 43, 104, 133, 186, 199, 30)
      }))
      if _ARG_0_._req_ugc or not DataMgr.is_open_ugc then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequireUGCData"] = function(_ARG_0_)
    do
      _ARG_0_._req_ugc = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasSelectMetroTxMission"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.hasSelectTxMission = _ARG_1_ == 20000
      log(bWriteLog and table.concat({
        U1(56, 56, 113, 156, 227, 159, 232, 22, 6, 115, 204, 204, 41, 47, 149, 171, 215, 19, 8, 239, 11, 169, 144, 33, 79, 116, 208, 192, 14, 63, 182, 173, 193, 27, 48, 249, 27, 162, 128, 11),
        U1(58, 2, 116, 207, 252, 153, 224, 17)
      }) .. tostring(_ARG_0_.hasSelectTxMission))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetModeShield"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      log_tree(table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 143, 145, 8, 16, 72, 252, 220, 57, 63, 137, 160, 203, 10, 17, 248, 79, 180, 138, 57),
        U1(35, 58, 113, 200, 208, 134, 230, 26, 18, 115, 200, 199)
      }), _ARG_2_, {limitLevel = 1})
      log(bWriteLog and table.concat({
        U1(25, 57, 66, 203, 227, 156, 248, 10, 56, 12, 205, 204, 42, 35, 169, 135, 223, 16, 9, 233, 32, 179, 154, 35, 16, 95, 197, 218, 50, 52, 224, 135, 204, 40, 24, 232, 34, 191, 139, 58),
        U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)
      }) .. tostring(_ARG_5_))
      U2 = _ARG_1_
      U3 = _ARG_2_
      U4 = {}
      goto lbl_216
      if U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85).base_view_object then
        goto lbl_167
        U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)[U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)] = U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85).base_view_object = nil
      end
      if U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85).options and type(U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85).options.team_type_maps) == U1(54, 46, 127, 208, 234) then
        goto lbl_214
        goto lbl_212
        if not ({
          [U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)] = true
        })[U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)] and CDataTable.GetTableData(U1(15, 46, 109), U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)) then
          U4[CDataTable.GetTableData(U1(15, 46, 109), U1(17, 39, 116, 217, 227, 148, 175, 27, 0, 74, 192, 214, 33, 62, 149, 174, 219, 26, 26, 229, 27, 224, 150, 60, 85)).MapKey] = true
        end
        ::lbl_212::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        ::lbl_214::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_216::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      U5 = _ARG_4_
      U6 = _ARG_5_
      U7 = _ARG_6_
      U8 = _ARG_7_
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).bHaveInitMapPaks and not Client.IsWindows() then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).bReEnterGame then
          if _ARG_0_.delayInitMapTimer then
            _ARG_0_.delayInitMapTimer = nil
          end
          if not PufferDownloader.PufferJsonDownloadReturn then
            PufferDownloader.forceInitMapPaks = true
          end
        elseif not _ARG_0_.delayInitMapTimer then
          _ARG_0_.delayInitMapTimer = _ARG_0_:AddTimerOnce(2, function()
            printf((table.concat({
              U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 143, 145, 8, 16, 72, 252, 220, 57, 63, 137, 160, 203, 10, 17, 248, 65, 240, 139, 58),
              U1(46, 46, 100, 156, 236, 152, 234, 28, 14)
            })))
            U2.delayInitMapTimer = nil
            if not U3.bHaveInitMapPaks then
              U3:InitMapPaks()
              if not PufferDownloader.PufferJsonDownloadReturn then
                PufferDownloader.forceInitMapPaks = true
              end
            end
            return
          end)
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayAnimOnMatchSuccess"] = function(_ARG_0_)
    do
      if not (require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))) and not require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).IsSocialIslandMode() and require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID) or require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID == 10080 or require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID == 20011 then
        return false
      end
      if require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nLastInGameModeID and require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nLastInGameModeID >= 21001 and require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nLastInGameModeID <= 21004 then
        return
      end
      if not U2 then
        return
      end
      if not (U2[require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID] and U2[require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID].id) then
        return false
      end
      if not _ARG_0_.viewId then
        return false
      end
      if not DataMgr.roleData.match_success_animation or DataMgr.roleData.match_success_animation ~= 1 then
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_opening):GetEquipedOpeningID() ~= nil then
        if CDataTable.GetTableData(U1(18, 42, 111, 207, 224, 158, 238, 19, 42, 92, 196, 205, 36, 36, 173, 155, 212, 24), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_opening):GetEquipedOpeningID())) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_opening):CheckAndDownloadOpeningBP((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_opening):GetEquipedOpeningID())) then
          if CDataTable.GetTableData(U1(18, 42, 111, 207, 224, 158, 238, 19, 42, 92, 196, 205, 36, 36, 173, 155, 212, 24), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_opening):GetEquipedOpeningID())).BPPath ~= U1() then
            if CDataTable.GetTableData(U1(18, 42, 111, 207, 224, 158, 238, 19, 42, 92, 196, 205, 36, 36, 173, 155, 212, 24), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_opening):GetEquipedOpeningID())).SoundID == 0 then
            end
            return true
          else
          end
        else
        end
      end
      goto lbl_730
      if require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 188, 189, 192, 12, 4, 227, 17, 159, 138, 59, 28, 80))).HigherVersion(Client.GetAppVersion(), (209).MinVersion) and require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 188, 189, 192, 12, 4, 227, 17, 159, 138, 59, 28, 80))).LowerVersion(Client.GetAppVersion(), (209).MaxVersion) and require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() >= require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).TimeStringToUnixstamp((209).StartTime) and require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).GetServerTimeInSec() < require((U1(33, 35, 116, 217, 225, 132, 161, 28, 10, 65, 204, 204, 35, 100, 190, 177, 223, 26, 50, 249, 11, 169, 147))).TimeStringToUnixstamp((209).EndTime) then
        goto lbl_726
        if tonumber(153) == (U2[require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID] and U2[require((U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 0, 237, 11, 163, 151, 97, 25, 83, 214, 218, 62, 5, 183, 167, 198, 10, 34, 241, 8, 162))).nInGameModeID].id) then
        else
          ::lbl_726::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_730::
      if not 209 then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not 209 then
        return false
      end
      if not require((table.concat({
        U1(5, 46, 112, 217, 195, 133, 238, 81, 40, 67, 197, 141, 1, 37, 168, 186, 203, 81, 47, 237, 12, 165, 209, 2, 26, 88, 212, 224, 56, 54, 191, 171, 214, 6, 18, 242, 65, 157, 128, 59),
        U1(39, 28, 120, 208, 234, 147, 251, 22, 10, 66, 244, 215, 36, 38)
      }))).IsModeSelectionModDownloaded() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FixedGroupView"] = function(_ARG_0_)
    do
      goto lbl_45
      if (nil).group_view then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if (nil).group_view_v2 then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_45::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSingleMode"] = function(_ARG_0_)
    do
      if _ARG_0_:GetFilterInfo() and _ARG_0_:GetFilterInfo().teamNum and _ARG_0_:GetFilterInfo().teamNum == 1 then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFirstAvailableViewId"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetMenuInfo() or not _ARG_0_:GetMenuInfo().sub_menus then
        return nil
      end
      goto lbl_43
      if (nil).type == 1 then
      elseif (nil).type == 2 then
        goto lbl_38
        ::lbl_38::
        if not U1((nil).sub_views, _ARG_1_) then
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if U1((nil).sub_views, _ARG_1_) then
        return (U1((nil).sub_views, _ARG_1_))
      end
      ::lbl_43::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCacheGuideThemeViewId"] = function(_ARG_0_)
    do
      do return _ARG_0_.guideThemeViewId end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCacheGuideThemeViewId"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(25, 8, 104, 213, 235, 149, 219, 23, 0, 65, 196, 245, 36, 47, 189, 133, 146, 44, 8, 248, 60, 161, 156, 39, 16, 123, 196, 218, 57, 63, 142, 160, 199, 2, 24, 202, 6, 181, 152, 22),
        U1(38, 111)
      }) .. tostring(_ARG_1_))
      _ARG_0_.guideThemeViewId = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSubMenuData"] = function(_ARG_0_, _ARG_1_)
    do
      if _ENV == nil then
        return nil
      end
      goto lbl_20
      goto lbl_18
      if (nil).id == _ARG_1_ then
        return nil
      end
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_20::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowExtraInfoViewIDMap"] = function(_ARG_0_)
    do
      if _ARG_0_.extraInfoViewIDs then
        return _ARG_0_.extraInfoViewIDs
      end
      if _ENV == nil then
        return {
          [nil] = true
        }
      end
      goto lbl_31
      goto lbl_29
      if (nil).name == 29597 then
        goto lbl_27
        ::lbl_27::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_29::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_31::
      _ARG_0_ = _ARG_0_
      _ARG_0_.extraInfoViewIDs, _ARG_0_ = {
        [nil] = true
      }, _ARG_0_
      do return {
        [nil] = true
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearExtraInfoViewIDMap"] = function(_ARG_0_)
    do
      _ARG_0_.extraInfoViewIDs = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnServerError"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 143, 145, 28, 16, 78, 199, 214, 47, 31, 168, 186, 205, 29))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckModeRes"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.bCheckModeRes then
        return
      end
      if not _ARG_1_ or #_ARG_1_ == 0 then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download) then
        return
      end
      goto lbl_817
      if U2[U1(29, 34, 124, 210, 238, 151, 234, 13)] then
        goto lbl_780
        if CDataTable.GetTableData(U1(15, 32, 121, 217, 217, 153, 234, 8, 44, 88, 196, 206, 4, 14, 185), tostring(U1(29, 34, 124, 210, 238, 151, 234, 13))) and CDataTable.GetTableData(U1(15, 32, 121, 217, 217, 153, 234, 8, 44, 88, 196, 206, 4, 14, 185), tostring(U1(29, 34, 124, 210, 238, 151, 234, 13))).ItemIDs and CDataTable.GetTableData(U1(15, 32, 121, 217, 217, 153, 234, 8, 44, 88, 196, 206, 4, 14, 185), tostring(U1(29, 34, 124, 210, 238, 151, 234, 13))).ItemIDs ~= U1() then
          goto lbl_778
          if tonumber(type(tostring(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13)))) == U1(49, 59, 111, 213, 225, 151) and string.match(tostring(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13)))) or tostring(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13)))) then
            if next(require((table.concat({
              U1(33, 35, 116, 217, 225, 132, 161, 12, 9, 89, 192, 141, 33, 37, 173, 177, 209, 81, 9, 227, 8, 174, 147, 32, 20, 88, 159, 195, 40, 60, 188, 173, 208, 65, 13, 233, 9, 182, 138, 45),
              U1(29, 34, 124, 210, 238, 151, 234, 13)
            }))).GetPakNamesByItemID((tonumber(type(tostring(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13)))) == U1(49, 59, 111, 213, 225, 151) and string.match(tostring(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13)))) or tostring(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13)))))) or {}) then
              if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager) then
                goto lbl_566
                if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):IsDepend(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13))) then
                else
                  ::lbl_566::
                  _ARG_0_ = _ARG_0_
                  _ARG_0_ = _ARG_0_
                end
              end
            elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):IsItemInDependItems(tostring(U1(29, 34, 124, 210, 238, 151, 234, 13))) then
            else
              goto lbl_703
              ::lbl_703::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
            if false then
            end
          end
          ::lbl_778::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_780::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_817::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < #{} then
      end
      do return end
      _ARG_1_ = U1[208]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleCheckModeRes"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == nil then
        _ARG_0_.bCheckModeRes = not _ARG_0_.bCheckModeRes
      else
        _ARG_0_.bCheckModeRes = _ARG_1_
      end
      printf(table.concat({
        U1(46, 32, 122, 213, 236, 175, 226, 16, 1, 73, 254, 208, 40, 38, 175, 187, 198, 22, 2, 226, 69, 148, 144, 40, 18, 80, 212, 240, 53, 63, 185, 163, 239, 0, 25, 249, 61, 181, 156, 127),
        U1(32, 12, 117, 217, 236, 155, 194, 16, 1, 73, 243, 198, 62, 112, 239, 171)
      }), tostring(_ARG_0_.bCheckModeRes))
      do return _ARG_0_.bCheckModeRes end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
