local logic_home_download = {
  HomeChileModuleType = {HomeShopType = 1, HomeEntranceMainUIType = 2},
  HomeShopMap = "map_planph_3",
  HomeMap = "map_planph",
  HomeMiniMap = "map_planph_2"
}

function logic_home_download.PauseHomeSource(downloadTypeInfo)
  log(bWriteLog and "logic_home_download.PauseHomeSource")
  if not downloadTypeInfo then
    log(bWriteLog and "logic_home_download.PauseHomeSource downloadTypeInfo is not valid")
    return
  end
  log_tree(bWriteLog and "logic_home_download.PauseHomeSource downloadTypeInfo is valid", downloadTypeInfo)
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  for downloadType, keyList in pairs(downloadTypeInfo) do
    PufferManager.Pause(downloadType, keyList)
  end
end

function logic_home_download.DownloadHomeSource(downloadTypeInfo, callback)
  log_tree(WriteLog and "logic_home_download.DownloadHomeSource", downloadTypeInfo)
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  for downloadType, keyList in pairs(self.downloadTypeInfo) do
    PufferManager.Download(downloadType, keyList, PufferTlog.Enum_TLog_From.LobbyEntrance, callback, {bAutoDownload = false})
  end
end

function logic_home_download.PauseHomeChileModuleSource(HomeChileModuleType)
  log(bWriteLog and string.format("logic_home_download.PauseHomeChileModuleSource, HomeChileModuleType.%s", HomeChileModuleType))
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  if HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeShopType then
    PufferManager.Pause(PufferConst.ENUM_DownloadType.MAP, {
      logic_home_download.HomeShopMap
    })
  elseif HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeEntranceMainUIType then
    local LobbyModUtils = require("GameLua.Mod.Lobby.Base.Common.LobbyModUtils")
    local Modkey = LobbyModUtils.Enum_Mod_Name.EName_Home
    local ResList = LobbyModUtils.GetModResList(Modkey)
    if not ResList or #ResList <= 0 then
      log(bWriteLog and "logic_home_download.DownloadHomeChileModuleSource ResList is not valid")
      return
    end
    PufferManager.Pause(PufferConst.ENUM_DownloadType.ODPAK, ResList)
  end
end

function logic_home_download.DownloadHomeChileModuleSource(HomeChileModuleType, callback)
  log(bWriteLog and string.format("logic_home_download.DownloadHomeChileModuleSource, HomeChileModuleType.%s", HomeChileModuleType))
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  if HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeShopType then
    local function realCallback()
      if callback then
        callback()
      end
      local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
      PufferMapManager:MountMapPak(logic_home_download.HomeShopMap)
    end
    
    PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {
      logic_home_download.HomeShopMap
    }, PufferTlog.Enum_TLog_From.LobbyEntrance, realCallback, {bAutoDownload = false})
  elseif HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeEntranceMainUIType then
    local LobbyModUtils = require("GameLua.Mod.Lobby.Base.Common.LobbyModUtils")
    local Modkey = LobbyModUtils.Enum_Mod_Name.EName_Home
    local ResList = LobbyModUtils.GetModResList(Modkey)
    if not ResList or #ResList <= 0 then
      log(bWriteLog and "logic_home_download.DownloadHomeChileModuleSource ResList is not valid")
      return
    end
    PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, ResList, PufferTlog.Enum_TLog_From.LobbyEntrance, callback, {bAutoDownload = false})
  end
end

function logic_home_download.GetChildModuleDownloadList(HomeChileModuleType)
  log(bWriteLog and string.format("logic_home_download.GetChildModuleDownloadList, HomeChileModuleType.%s", HomeChileModuleType))
  local downloadList = {}
  if HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeShopType then
    local StoreMap = logic_home_download.HomeShopMap
    downloadList = {StoreMap}
    local LobbyModUtils = require("GameLua.Mod.Lobby.Base.Common.LobbyModUtils")
    if not LobbyModUtils.IsModDownloaded(LobbyModUtils.Enum_Mod_Name.EName_Home) then
      log(bWriteLog and "logic_home_download.GetChildModuleDownloadList Home is not downloaded")
      logic_home_download.GetHomePageSourceList(downloadList)
    end
  elseif HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeEntranceMainUIType then
    logic_home_download.GetHomePageSourceList(downloadList)
  end
  log_tree(bWriteLog and "logic_home_download.GetChildModuleDownloadList", downloadList)
  return downloadList
end

function logic_home_download.GetHomePageSourceList(downloadList)
  local LobbyModUtils = require("GameLua.Mod.Lobby.Base.Common.LobbyModUtils")
  local Modkey = LobbyModUtils.Enum_Mod_Name.EName_Home
  local ResList = LobbyModUtils.GetModResList(Modkey)
  if not ResList or #ResList <= 0 then
    log(bWriteLog and "logic_home_download.GetChildModuleDownloadList ResList is not valid")
  else
    for i, v in pairs(ResList) do
      downloadList[#downloadList + 1] = v
    end
  end
end

function logic_home_download.CheckHomeChildModuleReady(HomeChileModuleType, gotoFuc, extraParams)
  local downloaded = false
  local downloadSize = 0
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  if HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeShopType then
    downloaded, downloadSize = home_download_tools.CheckDownloadReady(logic_home_download.HomeShopMap)
    local homeDownloaded, homeDownloadSize = home_download_tools.CheckHomeODPAKDownloadReady()
    downloadSize = downloadSize + homeDownloadSize
    if downloaded then
      log(bWriteLog and "logic_home_download.CheckHomeChildModuleReady gotoFuc is function")
      local PufferMapManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager)
      PufferMapManager:MountMapPak(logic_home_download.HomeShopMap)
    end
    downloaded = downloaded and homeDownloaded
  elseif HomeChileModuleType == logic_home_download.HomeChileModuleType.HomeEntranceMainUIType then
    downloaded, downloadSize = home_download_tools.CheckHomeODPAKDownloadReady()
  end
  if downloaded then
    if gotoFuc and type(gotoFuc) == "function" then
      gotoFuc()
    else
      log(bWriteLog and "logic_home_download.CheckHomeChildModuleReady gotoFuc is not function")
    end
  elseif extraParams then
    UIManager.ShowUI(UIManager.UI_Config.Home_Download_Store_Popup_UIBP, HomeChileModuleType, downloadSize, gotoFuc, extraParams)
  else
    UIManager.ShowUI(UIManager.UI_Config.Home_Download_Store_Popup_UIBP, HomeChileModuleType, downloadSize, gotoFuc)
  end
  return downloaded, downloadSize
end

function logic_home_download.CheckAllHomeResReady(uID, callback)
  log(bWriteLog and "logic_home_download.CheckAllHomeResReady", uID)
  uID = uID or DataMgr.roleData.uid
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  local downloaded, downloadSize = home_download_tools.CheckDownloadReady("map_planph")
  downloaded = downloaded == true
  downloadSize = downloadSize or 0
  log(bWriteLog and string.format("logic_home_download.CheckAllHomeResReady downloaded:%s downloadSize:%s", tostring(downloaded), tostring(downloadSize)))
  if callback and type(callback) == "function" then
    callback(downloaded, downloadSize, 0, downloadSize)
  else
    log(bWriteLog and "logic_home_download.CheckAllHomeResReady callback is not valid")
  end
end

function logic_home_download.IsAllHomeResDownloading()
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local mapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
    logic_home_download.HomeMap
  })
  return mapState == PufferConst.ENUM_DownloadState.Download or mapState == PufferConst.ENUM_DownloadState.Wait
end

function logic_home_download.StartDownloadAllHomeRes(uID)
  log(bWriteLog and "logic_home_download.StartDownloadAllHomeRes", uID)
  uID = uID or DataMgr.roleData.uid
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  if home_download_tools.CheckDownloadReady(logic_home_download.HomeMap) then
    log(bWriteLog and "logic_home_download.StartDownloadAllHomeRes already downloaded, skip")
    return
  end
  ShowNotice(202608817)
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local mapState = PufferManager.GetState(PufferConst.ENUM_DownloadType.MAP, {
    logic_home_download.HomeMap
  })
  if mapState == PufferConst.ENUM_DownloadState.Download or mapState == PufferConst.ENUM_DownloadState.Wait then
    log(bWriteLog and string.format("logic_home_download.StartDownloadAllHomeRes is downloading, skip, state:%s", tostring(mapState)))
    return
  end
  PufferManager.Download(PufferConst.ENUM_DownloadType.MAP, {"map_planph"}, PufferTlog.Enum_TLog_From.LobbyEntrance, nil, {bSkipPopUp = true, bAutoDownload = false})
end

function logic_home_download.ShowDownloadAllHomeResPopup(uID, downloadSize)
  uID = uID or DataMgr.roleData.uid
  local DownloadData = {
    downloadSize = downloadSize or 0,
    bDownloadAllMode = true,
    rewardKey = logic_home_download.ERewardKey.B,
    GotoFunc = function()
      logic_home_download.StartDownloadAllHomeRes(uID)
    end
  }
  UIManager.ShowUI(UIManager.UI_Config.Home_Download_Entrance_Popup_UIBP, uID, DownloadData)
end

function logic_home_download.GetHomeMapPakSize(uID, callback)
  log(bWriteLog and "logic_home_download.GetHomeMapPakSize", uID)
  local logic_home_detail = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_detail)
  logic_home_detail:SendGetManorUseItems(uID, function(ReturnUid, use_items)
    log(bWriteLog and string.format("logic_home_download.GetHomeMapPakSize, uID.%s, ReturnUid\239\188\154%s", uID, ReturnUid))
    if uID ~= ReturnUid then
      log(bWriteLog and "logic_home_download.GetHomeMapPakSize uID ~= ReturnUid")
      return
    end
    local PufferConst = require("client.slua.logic.download.puffer_const")
    local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
    local downloadTypeInfo = {}
    local use_items_arr = {}
    if use_items and next(use_items) then
      local index = 1
      for itemID, _ in pairs(use_items) do
        use_items_arr[index] = itemID
        index = index + 1
        local type = PufferManager.GetDownloadType(itemID) or PufferConst.ENUM_DownloadType.ODPAK
        if not downloadTypeInfo[type] then
          downloadTypeInfo[type] = {itemID}
        else
          table.insert(downloadTypeInfo[type], itemID)
        end
      end
    end
    local curSize = 0
    local totalSize = 0
    local state = PufferConst.ENUM_DownloadState.Done
    for downloadType, keyList in pairs(downloadTypeInfo) do
      local TempCurSize, TempTotalSize = PufferManager.GetSize(downloadType, keyList)
      curSize = curSize + TempCurSize
      totalSize = totalSize + TempTotalSize
      if PufferManager.GetState(downloadType, keyList) ~= PufferConst.ENUM_DownloadState.Done then
        state = PufferConst.ENUM_DownloadState.Not
      end
    end
    local leftSize = totalSize - curSize
    if state == PufferConst.ENUM_DownloadState.Done then
      leftSize = -1
    end
    if callback and type(callback) == "function" then
      callback(leftSize, downloadTypeInfo, use_items_arr, use_items)
    else
      log(bWriteLog and "logic_home_download.GetHomeMapPakSize callback is not valid")
    end
  end)
end

function logic_home_download.CheckHomeDownloadedDone(uID, gotoFuc)
  log(bWriteLog and "logic_home_download.CheckHomeDownloadedDone", uID)
  if not uID then
    log(bWriteLog and "logic_home_download.CheckHomeDownloadedDone uID is not valid")
    uID = DataMgr.roleData.uid
  end
  if logic_home_download.skipCheckUID and logic_home_download.skipCheckUID == tonumber(uID) then
    log(bWriteLog and "logic_home_download.CheckHomeDownloadedDone skip check, called from mini pak enter popup")
    logic_home_download.skipCheckUID = nil
    if gotoFuc and type(gotoFuc) == "function" then
      gotoFuc()
    end
    return
  end
  local logic_home_profile = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile)
  if tonumber(uID) == tonumber(DataMgr.roleData.uid) and not logic_home_profile:GetHomeProfileByUid(uID) then
    log(bWriteLog and "logic_home_download.CheckHomeDownloadedDone self profile not ready, req profile first, uID = " .. tostring(uID))
    logic_home_profile:GetOrReqHomeProfile({uID}, function()
      log(bWriteLog and "logic_home_download.CheckHomeDownloadedDone self profile ready, continue check, uID = " .. tostring(uID))
      logic_home_download._DoCheckHomeDownloadedDone(uID, gotoFuc)
    end)
    return
  end
  logic_home_download._DoCheckHomeDownloadedDone(uID, gotoFuc)
end

function logic_home_download.IsSelfOnlyMiniHomeDownloaded(uID)
  local logic_home_profile = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile)
  if logic_home_profile:IsSelfNotCreatedHome(uID) then
    return false
  end
  if tonumber(uID) ~= tonumber(DataMgr.roleData.uid) then
    return false
  end
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  local miniDownloaded = home_download_tools.CheckDownloadReady(logic_home_download.HomeMiniMap)
  local fullDownloaded, fullDownloadSize = home_download_tools.CheckDownloadReady(logic_home_download.HomeMap)
  if not miniDownloaded or fullDownloaded then
    log(bWriteLog and string.format("logic_home_download.IsSelfOnlyMiniHomeDownloaded not hit, miniDownloaded:%s fullDownloaded:%s", tostring(miniDownloaded), tostring(fullDownloaded)))
    return false
  end
  return true, fullDownloadSize
end

function logic_home_download.IsSelfJointHome(uID)
  log(bWriteLog and "logic_home_download.IsSelfJointHome uID = " .. tostring(uID))
  local logic_home_profile = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile)
  local profile = logic_home_profile:GetHomeProfileByUid(uID)
  local logic_home_joint = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint)
  local bJoint = logic_home_joint:HasJointHome()
  log(bWriteLog and "logic_home_download.IsSelfJointHome bJoint = " .. tostring(bJoint))
  return bJoint
end

function logic_home_download.HasUndownloadedRepActorItem(use_items)
  log(bWriteLog and "logic_home_download.HasUndownloadedRepActorItem")
  if not use_items then
    log(bWriteLog and "logic_home_download.HasUndownloadedRepActorItem use_items is nil")
    return false
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local logic_home_common_public = require("client.slua.logic.home.logic_home_common_public")
  for itemID, _ in pairs(use_items) do
    local checkID = tonumber(itemID)
    if checkID and logic_home_common_public.IsRepActorItem(checkID) then
      local downloadType = PufferManager.GetDownloadType(checkID) or PufferConst.ENUM_DownloadType.ODPAK
      local state = PufferManager.GetState(downloadType, {checkID})
      log(bWriteLog and string.format("logic_home_download.HasUndownloadedRepActorItem RepActor itemID:%s state:%s", tostring(checkID), tostring(state)))
      if state ~= PufferConst.ENUM_DownloadState.Done then
        log(bWriteLog and string.format("logic_home_download.HasUndownloadedRepActorItem hit undownloaded RepActor, itemID:%s", tostring(checkID)))
        return true
      end
    end
  end
  return false
end

function logic_home_download.ShowMiniPakEnterPopup(uID, gotoFuc, fullDownloadSize, bBlockEnter, rewardKey, downloadFunc)
  log(bWriteLog and string.format("logic_home_download:ShowMiniPakEnterPopup bBlockEnter=%s rewardKey=%s", tostring(bBlockEnter), tostring(rewardKey)))
  local DownloadData = {
    downloadSize = fullDownloadSize or 0,
    bEnterMiniHomeMode = true,
    rewardKey = rewardKey,
    GotoFunc = function(...)
      if bBlockEnter then
        log(bWriteLog and "logic_home_download:ShowMiniPakEnterPopup block enter, has undownloaded RepActor item")
        ShowNotice(2026080702)
        return
      end
      log(bWriteLog and "logic_home_download:ShowMiniPakEnterPopup GotoFunc enter mini home")
      if gotoFuc and type(gotoFuc) == "function" then
        logic_home_download.skipCheckUID = tonumber(uID)
        gotoFuc(...)
        logic_home_download.skipCheckUID = nil
      end
    end,
    DownloadFunc = downloadFunc or function()
      logic_home_download.StartDownloadAllHomeRes(uID)
    end
  }
  UIManager.ShowUI(UIManager.UI_Config.Home_Download_Entrance_Popup_UIBP, uID, DownloadData)
end

function logic_home_download.CheckSelfMiniHomeDownloadedDone(uID, gotoFuc)
  log(bWriteLog and "logic_home_download.CheckSelfMiniHomeDownloadedDone")
  local bHit, fullDownloadSize = logic_home_download.IsSelfOnlyMiniHomeDownloaded(uID)
  if not bHit then
    log(bWriteLog and "logic_home_download.CheckSelfMiniHomeDownloadedDone not hit")
    return false
  end
  log(bWriteLog and string.format("logic_home_download.CheckSelfMiniHomeDownloadedDone hit, fullDownloadSize:%s", tostring(fullDownloadSize)))
  local bBlockEnter = logic_home_download.IsSelfJointHome(uID)
  log(bWriteLog and "logic_home_download.CheckSelfMiniHomeDownloadedDone bBlockEnter(joint home) = " .. tostring(bBlockEnter))
  logic_home_download.ShowMiniPakEnterPopup(uID, gotoFuc, fullDownloadSize, bBlockEnter)
  return true
end

function logic_home_download._DoCheckHomeDownloadedDone(uID, gotoFuc)
  log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone", uID)
  if logic_home_download.CheckSelfEnterHomeDownload(uID, gotoFuc) then
    log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone hit CheckSelfEnterHomeDownload")
    return
  end
  if logic_home_download.CheckSelfMiniHomeDownloadedDone(uID, gotoFuc) then
    log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone hit CheckSelfMiniHomeDownloadedDone")
    return
  end
  logic_home_download.GetHomeMapPakSize(uID, function(leftSize, downloadTypeInfo, use_items_arr, items_arr)
    log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone, leftSize:%s", leftSize)
    local DownloadData = {
      downloadSize = leftSize,
      use_items = use_items_arr,
      downloadHomeTypeInfo = downloadTypeInfo,
      GotoFunc = gotoFuc,
      items_arr = items_arr
    }
    if GameStatus and GameStatus.IsInFightingNotMainCity() then
      log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone in fighting(not main city), use bDownloadAllMode")
      DownloadData.bDownloadAllMode = true
      DownloadData.rewardKey = logic_home_download.ERewardKey.B
      
      function DownloadData.GotoFunc()
        logic_home_download.StartDownloadAllHomeRes(uID)
      end
    end
    if DownloadData.downloadSize > 0 then
      UIManager.ShowUI(UIManager.UI_Config.Home_Download_Entrance_Popup_UIBP, uID, DownloadData)
    elseif gotoFuc and type(gotoFuc) == "function" then
      gotoFuc(DownloadData)
    else
      log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone gotoFuc is not function")
      local logic_home_switch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch)
      if logic_home_switch:CheckHomeLimit(true) then
        log(bWriteLog and "logic_home_download._DoCheckHomeDownloadedDone CheckHomeLimit")
        return
      end
      local logic_home_entry = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_entry)
      logic_home_entry:EntryVisitHome(tonumber(uID))
    end
  end)
end

function logic_home_download.GetDownloadReward()
  log(bWriteLog and "logic_home_download.GetDownloadReward")
  local logic_home_award_state = require("client.slua.logic.home.logic_home_award_state")
  if logic_home_award_state.IsAllLightAwardGot() then
    log(bWriteLog and "logic_home_download.GetDownloadReward has got reward")
    return {}
  end
  local logic_lobby_home_entry_item_version_award = require("client.slua.logic.home.Lobby.logic_lobby_home_entry_item_version_award")
  local info = logic_lobby_home_entry_item_version_award.GetShowInfo({bIgnoreMiniHomeLimit = true})
  log(bWriteLog and "logic_home_download.GetDownloadReward info.bShow = " .. tostring(info.bShow))
  if not info.bShow then
    log(bWriteLog and "logic_home_download.GetDownloadReward VersionAward not show")
    return {}
  end
  if logic_home_download.GetEnterHomeLightRewardCfg() then
    return logic_home_download.MergeRewardList(logic_home_download.GetLightRewardList(logic_home_download.ERewardKey.A), logic_home_download.GetLightRewardList(logic_home_download.ERewardKey.B))
  end
  local logic_lobby_home_entry_item = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_lobby_home_entry_item)
  local rewardList = logic_lobby_home_entry_item:GetEnterHomeRewardList(info.cfgText.RewardID)
  return rewardList
end

logic_home_download.ERewardKey = {A = "A", B = "B"}

function logic_home_download.GetLightRewardList(key)
  return logic_home_download.GetDownloadRewardByKey(key)
end

function logic_home_download.MergeRewardList(listA, listB)
  local merged, index = {}, {}
  
  local function append(list)
    for _, v in ipairs(list or {}) do
      local itemID = tonumber(v.RewardItemID)
      if itemID and 0 < itemID then
        if index[itemID] then
          local exist = merged[index[itemID]]
          exist.RewardItemNumber = (exist.RewardItemNumber or 0) + (v.RewardItemNumber or 0)
        else
          index[itemID] = #merged + 1
          merged[#merged + 1] = {
            RewardItemID = itemID,
            RewardItemNumber = v.RewardItemNumber or 0
          }
        end
      end
    end
  end
  
  append(listA)
  append(listB)
  return merged
end

function logic_home_download.GetDownloadRewardForTips()
  log(bWriteLog and "logic_home_download:GetDownloadRewardForTips")
  if not logic_home_download.GetEnterHomeLightRewardCfg() then
    log(bWriteLog and "logic_home_download:GetDownloadRewardForTips light cfg not found, fallback old table")
    return logic_home_download.GetDownloadReward()
  end
  local logic_home_award_state = require("client.slua.logic.home.logic_home_award_state")
  local gotA = logic_home_award_state.IsLightAwardGot(logic_home_download.ERewardKey.A)
  local gotB = logic_home_award_state.IsLightAwardGot(logic_home_download.ERewardKey.B)
  log(bWriteLog and string.format("logic_home_download:GetDownloadRewardForTips gotA=%s gotB=%s", tostring(gotA), tostring(gotB)))
  if gotA and gotB then
    return {}
  end
  if gotA then
    return logic_home_download.GetLightRewardList(logic_home_download.ERewardKey.B)
  end
  if gotB then
    return logic_home_download.GetLightRewardList(logic_home_download.ERewardKey.A)
  end
  return logic_home_download.MergeRewardList(logic_home_download.GetLightRewardList(logic_home_download.ERewardKey.A), logic_home_download.GetLightRewardList(logic_home_download.ERewardKey.B))
end

function logic_home_download.IsSelfEnterHomeDownload(uID)
  if tonumber(uID) ~= tonumber(DataMgr.roleData.uid) then
    return false
  end
  local logic_home_profile = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile)
  if logic_home_profile:IsSelfNotCreatedHome(uID) then
    return false
  end
  return true
end

function logic_home_download.IsMiniPakDownloaded(uID)
  local bReady = logic_home_download.CheckMiniPakReadyByData(uID)
  return bReady
end

function logic_home_download.IsFullPakDownloaded(uID)
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  local downloaded = home_download_tools.CheckDownloadReady(logic_home_download.HomeMap)
  return downloaded == true
end

local C_TakeOverRealEnterHome = true

function logic_home_download.KeepEnterEntryFor470(uID)
  if tonumber(uID) ~= tonumber(DataMgr.roleData.uid) then
    return false
  end
  if not C_TakeOverRealEnterHome then
    return false
  end
  return logic_home_download.IsSelfEnterHomeDownload(uID)
end

local C_ThemeSetCompositionPathCache = {}
local C_ThemeSetCompositionKeyCache = {}
local C_ThemeSetDownloadKeyCache = {}
local C_ThemeSetPathSkipPrefixes = {
  "/Game/Mod/PlanPH/"
}

function logic_home_download.IsThemeSetCompositionPathSkipped(resPath)
  if not resPath or resPath == "" then
    return true
  end
  for _, prefix in ipairs(C_ThemeSetPathSkipPrefixes) do
    if string.sub(resPath, 1, #prefix) == prefix then
      return true
    end
  end
  return false
end

function logic_home_download.GetThemeSetCompositionPaths(themeID)
  local nThemeID = tonumber(themeID)
  if not nThemeID or nThemeID <= 0 then
    return {}
  end
  local cachedList = C_ThemeSetCompositionPathCache[nThemeID]
  if cachedList then
    return cachedList
  end
  local pathList = {}
  local cfg
  if CDataTable and CDataTable.GetTableData then
    cfg = CDataTable.GetTableData("PlanPH_ThemeSetCompositionCfg", nThemeID)
  end
  if cfg and cfg.ThemeSetItemPath and cfg.ThemeSetItemPath ~= "" then
    local StringUtil = require("common.string_util")
    for _, path in ipairs(StringUtil.Split(cfg.ThemeSetItemPath, "|")) do
      if path and path ~= "" then
        pathList[#pathList + 1] = path
      end
    end
  else
    printf("logic_home_download:GetThemeSetCompositionPaths cfg missing, themeID = %s", nThemeID)
  end
  C_ThemeSetCompositionPathCache[nThemeID] = pathList
  return pathList
end

function logic_home_download.GetThemeSetCompositionDownloadKeys(themeID)
  local nThemeID = tonumber(themeID)
  if not nThemeID or nThemeID <= 0 then
    return {}
  end
  local cachedKeys = C_ThemeSetCompositionKeyCache[nThemeID]
  if cachedKeys then
    return cachedKeys
  end
  local keyList, addedPaths = {}, {}
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  for _, resPath in ipairs(logic_home_download.GetThemeSetCompositionPaths(nThemeID)) do
    if addedPaths[resPath] then
    elseif logic_home_download.IsThemeSetCompositionPathSkipped(resPath) then
      printf("logic_home_download:GetThemeSetCompositionDownloadKeys path skipped(in map pak), themeID = %s, path = %s", nThemeID, resPath)
    else
      addedPaths[resPath] = true
      local pakName = PufferManager.GetPakName(resPath)
      if pakName and pakName ~= "" then
        keyList[#keyList + 1] = resPath
        printf("logic_home_download:GetThemeSetCompositionDownloadKeys res added, themeID = %s, pak = %s, path = %s", nThemeID, pakName, resPath)
      else
        printf("logic_home_download:GetThemeSetCompositionDownloadKeys path skipped(main pak), themeID = %s, path = %s", nThemeID, resPath)
      end
    end
  end
  C_ThemeSetCompositionKeyCache[nThemeID] = keyList
  return keyList
end

function logic_home_download.GetThemeSetDownloadKeyList(themeID)
  local nThemeID = tonumber(themeID)
  if not nThemeID or nThemeID <= 0 then
    return {}
  end
  local cachedKeys = C_ThemeSetDownloadKeyCache[nThemeID]
  if cachedKeys then
    return cachedKeys
  end
  local keyList = {nThemeID}
  for _, key in ipairs(logic_home_download.GetThemeSetCompositionDownloadKeys(nThemeID)) do
    keyList[#keyList + 1] = key
  end
  C_ThemeSetDownloadKeyCache[nThemeID] = keyList
  return keyList
end

function logic_home_download.GetKeyListDownloadState(keyList)
  if not keyList or #keyList == 0 then
    return nil
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  return PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, keyList)
end

function logic_home_download.StartKeyListDownload(keyList)
  if not keyList or #keyList == 0 then
    return
  end
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
  PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, keyList, PufferTlog.Enum_TLog_From.Click, nil, {bSkipPopUp = true, bAutoDownload = false})
end

function logic_home_download.GetMiniPakResKeyList(uID)
  local keyList = {
    logic_home_download.HomeMiniMap
  }
  local bDataReady = true
  local logic_home_detail = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_detail)
  local useItems
  local LogicPHomeStore = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicPHomeStore)
  if LogicPHomeStore and LogicPHomeStore.manorItems ~= nil then
    useItems = LogicPHomeStore.manorItems
  else
    local cacheData = logic_home_detail.itemCacheData and logic_home_detail.itemCacheData[tonumber(uID)]
    useItems = cacheData and cacheData.use_items
  end
  if useItems then
    for itemID in pairs(useItems) do
      if tonumber(itemID) then
        keyList[#keyList + 1] = itemID
      end
    end
  else
    bDataReady = false
  end
  local themeIDs = logic_home_detail:GetManorAmbientThemeIds(uID)
  if themeIDs then
    local addedThemeKeys = {}
    for _, themeID in ipairs(themeIDs) do
      for _, key in ipairs(logic_home_download.GetThemeSetDownloadKeyList(themeID)) do
        if not addedThemeKeys[key] then
          addedThemeKeys[key] = true
          keyList[#keyList + 1] = key
        end
      end
    end
  else
    bDataReady = false
  end
  if LogicPHomeStore and LogicPHomeStore.manorPileItems ~= nil then
    local home_pile_info_utils = require("client.slua.logic.home.HomeArea.home_pile_info_utils")
    local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
    local addedPaths = {}
    local addedItemIDs = {}
    for i = 1, #keyList do
      local existID = tonumber(keyList[i])
      if existID then
        addedItemIDs[existID] = true
      end
    end
    
    local function _AddPileResPath(resPath, resKind, nItemID, nPileNum)
      if not resPath or addedPaths[resPath] then
        return
      end
      if PufferManager.GetPakName(resPath) == "" then
        return
      end
      addedPaths[resPath] = true
      keyList[#keyList + 1] = resPath
      log(bWriteLog and string.format("logic_home_download:GetMiniPakResKeyList pile item extra res, kind=%s, itemID=%s, pileNum=%s, path=%s", resKind, tostring(nItemID), tostring(nPileNum), resPath))
    end
    
    for itemID, pileData in pairs(LogicPHomeStore.manorPileItems) do
      local nItemID = tonumber(type(pileData) == "table" and (pileData.item_id or itemID) or itemID)
      local pileCountMap = type(pileData) == "table" and pileData.use_items or pileData
      if nItemID and not addedItemIDs[nItemID] then
        addedItemIDs[nItemID] = true
        keyList[#keyList + 1] = nItemID
        log(bWriteLog and string.format("logic_home_download:GetMiniPakResKeyList pile item self res, itemID=%s", tostring(nItemID)))
      end
      if nItemID and type(pileCountMap) == "table" then
        for pileNum in pairs(pileCountMap) do
          local nPileNum = tonumber(pileNum) or 0
          if 1 < nPileNum then
            local specialBPPath, specialIconPath = home_pile_info_utils.GetPileItemSpecialLookRes(nItemID, nPileNum)
            _AddPileResPath(specialBPPath, "BP", nItemID, nPileNum)
            _AddPileResPath(specialIconPath, "Icon", nItemID, nPileNum)
          end
        end
      end
    end
  end
  log(bWriteLog and string.format("logic_home_download:GetMiniPakResKeyList uid = %s, keyCount = %s, dataReady = %s", tostring(uID), tostring(#keyList), tostring(bDataReady)))
  return keyList, bDataReady
end

function logic_home_download.CheckMiniPakReadyByData(uID)
  local keyList, bDataReady = logic_home_download.GetMiniPakResKeyList(uID)
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local typeMap = {}
  for _, key in ipairs(keyList) do
    local downloadType = PufferManager.GetDownloadType(key) or PufferConst.ENUM_DownloadType.ODPAK
    typeMap[downloadType] = typeMap[downloadType] or {}
    typeMap[downloadType][#typeMap[downloadType] + 1] = key
  end
  local bAllDone = true
  for downloadType, list in pairs(typeMap) do
    if PufferManager.GetState(downloadType, list) ~= PufferConst.ENUM_DownloadState.Done then
      bAllDone = false
      break
    end
  end
  log(bWriteLog and string.format("logic_home_download:CheckMiniPakReadyByData ready = %s, dataReady = %s, keyCount = %s", tostring(bAllDone), tostring(bDataReady), tostring(#keyList)))
  return bAllDone, bDataReady
end

function logic_home_download.EnsureMiniPakData(uID, callback)
  local _, bDataReady = logic_home_download.GetMiniPakResKeyList(uID)
  if bDataReady then
    logic_home_download.nMiniPakDataTryCount = 0
    return true
  end
  if logic_home_download.bMiniPakDataRequesting then
    return false
  end
  if (logic_home_download.nMiniPakDataTryCount or 0) >= 2 then
    log(bWriteLog and "logic_home_download:EnsureMiniPakData retry too many times, give up take-over")
    return nil
  end
  logic_home_download.bMiniPakDataRequesting = true
  logic_home_download.nMiniPakDataTryCount = (logic_home_download.nMiniPakDataTryCount or 0) + 1
  local logic_home_detail = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_detail)
  logic_home_detail:ReqManorAmbientInfo(uID, function()
    logic_home_download.bMiniPakDataRequesting = false
    if callback then
      callback()
    end
  end)
  return false
end

function logic_home_download.TryReportLightPkgDownloadDone()
  local uid = tonumber(DataMgr.roleData.uid)
  if not uid then
    return
  end
  local bReady, bDataReady = logic_home_download.CheckMiniPakReadyByData(uid)
  if not bDataReady then
    if not logic_home_download.bLightPkgDataRequested then
      logic_home_download.bLightPkgDataRequested = true
      log(bWriteLog and "logic_home_download:TryReportLightPkgDownloadDone data not ready, req manor use item detail")
      local logic_home_detail = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_detail)
      logic_home_detail:ReqManorAmbientInfo(uid, nil)
    end
    return
  end
  if not bReady then
    logic_home_download.bLightPkgReported = false
    return
  end
  if logic_home_download.bLightPkgReported then
    return
  end
  logic_home_download.bLightPkgReported = true
  log(bWriteLog and "logic_home_download:TryReportLightPkgDownloadDone report light pkg download done")
  local PHomeVisitHandler = require("client.network.Protocol.PHomeVisitHandler")
  PHomeVisitHandler.send_manor_light_pkg_download_report()
end

function logic_home_download.DispatchEnterHomeByPakState(uID, gotoFuc, bMiniPakDone, bFullPakDone, bGotoOnEntranceOnly)
  if not bMiniPakDone then
    logic_home_download.ShowEnterHomeResChoicePopup(uID, gotoFuc, bGotoOnEntranceOnly)
    return true
  end
  if not bFullPakDone then
    logic_home_download.ShowEnterHomeMiniPakPopup(uID, gotoFuc)
    return true
  end
  logic_home_download.GotoEnterHome(uID, gotoFuc)
  return true
end

function logic_home_download.ContinueEnterHomeWithout470(uID, gotoFuc)
  log(bWriteLog and "logic_home_download:ContinueEnterHomeWithout470")
  logic_home_download._DoCheckHomeDownloadedDone(uID, gotoFuc)
end

function logic_home_download.CheckSelfEnterHomeDownload(uID, gotoFuc, bGotoOnEntranceOnly)
  if not logic_home_download.IsSelfEnterHomeDownload(uID) then
    log(bWriteLog and "logic_home_download:CheckSelfEnterHomeDownload not self enter home, skip")
    return false
  end
  if not C_TakeOverRealEnterHome then
    log(bWriteLog and "logic_home_download:CheckSelfEnterHomeDownload real take-over disabled, skip")
    return false
  end
  local bDataReady = logic_home_download.EnsureMiniPakData(uID, function()
    if not logic_home_download.CheckSelfEnterHomeDownload(uID, gotoFuc, bGotoOnEntranceOnly) then
      log(bWriteLog and "logic_home_download:CheckSelfEnterHomeDownload async fallback to 460 flow")
      logic_home_download.ContinueEnterHomeWithout470(uID, gotoFuc)
    end
  end)
  if bDataReady == false then
    log(bWriteLog and "logic_home_download:CheckSelfEnterHomeDownload wait manor use item data")
    return true
  end
  if bDataReady == nil then
    log(bWriteLog and "logic_home_download:CheckSelfEnterHomeDownload data not ready, give up take-over")
    return false
  end
  local miniPakDone = logic_home_download.IsMiniPakDownloaded(uID)
  local fullPakDone = logic_home_download.IsFullPakDownloaded(uID)
  log(bWriteLog and string.format("logic_home_download:CheckSelfEnterHomeDownload [real] miniPakDone=%s fullPakDone=%s", tostring(miniPakDone), tostring(fullPakDone)))
  return logic_home_download.DispatchEnterHomeByPakState(uID, gotoFuc, miniPakDone, fullPakDone, bGotoOnEntranceOnly)
end

function logic_home_download.GotoEnterHome(uID, gotoFuc)
  if gotoFuc and type(gotoFuc) == "function" then
    gotoFuc()
    return
  end
  local logic_home_switch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch)
  if logic_home_switch:CheckHomeLimit(true) then
    return
  end
  local logic_home_entry = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_entry)
  logic_home_entry:EntryVisitHome(tonumber(uID), nil, {bSkipDownloadCheck = true})
end

function logic_home_download.OpenHomeEntranceMainPage(showInfo)
  log(bWriteLog and "logic_home_download:OpenHomeEntranceMainPage")
  local logic_lobby_home_main = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lobby_home_main)
  if not logic_lobby_home_main then
    log_error("logic_home_download:OpenHomeEntranceMainPage logic_lobby_home_main is nil")
    return
  end
  logic_lobby_home_main:ShowMainUI(nil, showInfo)
  local logic_home_joint = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint)
  if logic_home_joint and logic_home_joint:HasJointHome() then
    local PHomeJointHandler = require("client.network.Protocol.PHomeJointHandler")
    PHomeJointHandler.send_manor_joint_info_req()
  end
end

function logic_home_download.GetMiniPakResList(uID)
  local keyList = logic_home_download.GetMiniPakResKeyList(uID)
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
  local typeMap = {}
  for _, key in ipairs(keyList) do
    local downloadType = PufferManager.GetDownloadType(key) or PufferConst.ENUM_DownloadType.ODPAK
    typeMap[downloadType] = typeMap[downloadType] or {}
    typeMap[downloadType][#typeMap[downloadType] + 1] = key
  end
  local leftSize = 0
  for downloadType, list in pairs(typeMap) do
    local curSize, totalSize = PufferManager.GetSize(downloadType, list)
    leftSize = leftSize + math.max(0, (totalSize or 0) - (curSize or 0))
  end
  local sizeMB = leftSize / PufferConst.MB
  log(bWriteLog and string.format("logic_home_download:GetMiniPakResList sizeMB = %s, keyCount = %s", tostring(sizeMB), tostring(#keyList)))
  log_tree(bWriteLog and "logic_home_download:GetMiniPakResList keyList", keyList)
  return keyList, sizeMB
end

function logic_home_download.ShowEnterHomeResChoicePopup(uID, gotoFuc, bGotoOnEntranceOnly)
  log(bWriteLog and "logic_home_download:ShowEnterHomeResChoicePopup", tostring(bGotoOnEntranceOnly))
  local PufferConst = require("client.slua.logic.download.puffer_const")
  local miniPakResList, miniPakResSizeMB = logic_home_download.GetMiniPakResList(uID)
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  local bEntranceDownloaded, childModuleSize = home_download_tools.CheckHomeODPAKDownloadReady()
  local entranceSizeByte = childModuleSize or 0
  local extraParams = {
    bEnterHomeResChoice = true,
    bEntranceDownloaded = bEntranceDownloaded == true,
    bGotoOnEntranceOnly = bGotoOnEntranceOnly == true,
    myHomeResList = miniPakResList,
    myHomeResSizeByte = (miniPakResSizeMB or 0) * PufferConst.MB
  }
  log(bWriteLog and string.format("logic_home_download:ShowEnterHomeResChoicePopup bEntranceDownloaded = %s, entranceSizeByte = %s, bGotoOnEntranceOnly = %s", tostring(bEntranceDownloaded), tostring(entranceSizeByte), tostring(bGotoOnEntranceOnly)))
  UIManager.ShowUI(UIManager.UI_Config.Home_Download_Store_Popup_UIBP, logic_home_download.HomeChileModuleType.HomeEntranceMainUIType, entranceSizeByte, gotoFuc, extraParams)
end

function logic_home_download.ShowEnterHomeMiniPakPopup(uID, gotoFuc)
  log(bWriteLog and "logic_home_download:ShowEnterHomeMiniPakPopup")
  local home_download_tools = require("client.slua.logic.download.home_download_tools")
  local _, fullDownloadSize = home_download_tools.CheckDownloadReady(logic_home_download.HomeMap)
  logic_home_download.ShowMiniPakEnterPopup(uID, gotoFuc, fullDownloadSize or 0, false, logic_home_download.ERewardKey.B, nil)
end

function logic_home_download.GetEnterHomeLightRewardCfg()
  log(bWriteLog and "logic_home_download:GetEnterHomeLightRewardCfg")
  if not CDataTable or not CDataTable.GetTableAllRowFields then
    log(bWriteLog and "logic_home_download:GetEnterHomeLightRewardCfg CDataTable API not ready")
    return nil
  end
  local version_util = require("client.common.version_util")
  local time_util = require("client.common.time_util")
  local clientVersion = version_util.GetClientFormat(Client.GetAppVersion(), 3)
  local tNow = time_util.GetServerTimeInSec()
  local ok, rows = pcall(CDataTable.GetTableAllRowFields, "PlanPH_Bubble_LightReward", {
    "ID",
    "RewardStartVersion",
    "StartTime",
    "EndTime",
    "LightARewardItemID",
    "LightARewardItemNumber",
    "LightARewardItemID1",
    "LightARewardItemNumber1",
    "LightARewardItemID2",
    "LightARewardItemNumber2",
    "LightBRewardItemID",
    "LightBRewardItemNumber",
    "LightBRewardItemID1",
    "LightBRewardItemNumber1",
    "LightBRewardItemID2",
    "LightBRewardItemNumber2"
  }, true)
  if not ok then
    log(bWriteLog and "logic_home_download:GetEnterHomeLightRewardCfg GetTableAllRowFields failed: " .. tostring(rows))
    return nil
  end
  for _, row in ipairs(rows or {}) do
    local cfg = row.configs or row
    if cfg.ID then
      local rewardVersion = version_util.GetClientFormat(cfg.RewardStartVersion, 3)
      local tStart = time_util.TimeStringToUnixstamp(cfg.StartTime)
      local tEnd = time_util.TimeStringToUnixstamp(cfg.EndTime)
      if clientVersion == rewardVersion and tNow >= tStart and tNow <= tEnd then
        log(bWriteLog and string.format("logic_home_download:GetEnterHomeLightRewardCfg hit ID=%s version=%s", tostring(cfg.ID), tostring(rewardVersion)))
        return cfg
      end
    end
  end
  log(bWriteLog and "logic_home_download:GetEnterHomeLightRewardCfg no matched cfg, clientVersion = " .. tostring(clientVersion))
  return nil
end

function logic_home_download.IsHomeAwardGotReal()
  local logic_home_award_state = require("client.slua.logic.home.logic_home_award_state")
  return logic_home_award_state.IsAllLightAwardGot()
end

function logic_home_download.GetDownloadRewardByKey(key, bSkipGot)
  if not key then
    return logic_home_download.GetDownloadReward()
  end
  if bSkipGot then
    local logic_home_award_state = require("client.slua.logic.home.logic_home_award_state")
    if logic_home_award_state.IsLightAwardGot(key) then
      log(bWriteLog and string.format("logic_home_download:GetDownloadRewardByKey key=%s already got, skip reward display", tostring(key)))
      return {}
    end
  end
  local cfg = logic_home_download.GetEnterHomeLightRewardCfg()
  if not cfg then
    return {}
  end
  local prefix = key == logic_home_download.ERewardKey.A and "LightA" or "LightB"
  local rewardList = {}
  for i = 0, 2 do
    local suffix = i == 0 and "" or tostring(i)
    local itemID = cfg[prefix .. "RewardItemID" .. suffix]
    local itemNumber = cfg[prefix .. "RewardItemNumber" .. suffix]
    if itemID and 0 < itemID then
      rewardList[#rewardList + 1] = {
        RewardItemID = itemID,
        RewardItemNumber = itemNumber or 0
      }
    end
  end
  log(bWriteLog and string.format("logic_home_download:GetDownloadRewardByKey key=%s count=%s", tostring(key), tostring(#rewardList)))
  log_tree(bWriteLog and "logic_home_download:GetDownloadRewardByKey rewardList", rewardList)
  return rewardList
end

function logic_home_download.GetDownloadSizeStr(size)
  log(bWriteLog and string.format("logic_home_download.GetDownloadSizeStr, size:%s", size))
  local PufferConst = require("client.slua.logic.download.puffer_const")
  size = size / PufferConst.MB
  if size < 0.1 then
    size = 0.1
  end
  local sizeStr = string.format("%.1f", size)
  return sizeStr
end

return logic_home_download
