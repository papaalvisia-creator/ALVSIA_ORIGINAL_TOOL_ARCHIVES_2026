do return {
  TalentMap = nil,
  ShownRowMap = {},
  OriginIDToPreTalentIDMap = {},
  UnlockLayerNeedPrePointList = {},
  TalentTree = nil,
  TalentSchemeList = {},
  CurSelectSchemeID = 0,
  PointDeploy = {},
  configQueue = {},
  talentConfigData = nil,
  weekend_talent_data = {},
  ["GetTalentIDByPosition"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.TalentTree and _ARG_0_.TalentTree[_ARG_1_] then
        return _ARG_0_.TalentTree[_ARG_1_][_ARG_2_]
      else
        return 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRowAndLine"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.TalentMap and _ARG_0_.TalentMap[_ARG_1_] then
        return _ARG_0_.TalentMap[_ARG_1_].layer, _ARG_0_.TalentMap[_ARG_1_].line
      end
      do return nil, nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearData"] = function(_ARG_0_)
    do
      _ARG_0_.TalentMap = nil
      _ARG_0_.TalentTree = nil
      _ARG_0_.talentConfigData = nil
      _ARG_0_.weekend_talent_data = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequireTalentData"] = function(_ARG_0_)
    do
      send_metro_mastery_info_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetTalentData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(table.concat({
        U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 172, 63, 65, 8, 162, 173, 241, 1, 138, 160, 147, 82, 83, 39, 50, 129, 183, 36, 102, 17, 169, 144, 160, 57),
        U1(114, 21, 23, 103)
      }), _ARG_2_)
      if _ARG_1_ ~= 0 then
        return
      end
      _ARG_0_:InitTalentMap()
      _ARG_0_:InitTalentTree()
      _ARG_0_:InitDeploy(_ARG_2_)
      U2 = _ARG_2_.total_point
      _ARG_0_ = _ARG_0_
      if _ARG_0_.PointDeploy[U1(114, 21, 23, 103)].bUse then
      end
      _ARG_0_.TalentSchemeList[U1(114, 21, 23, 103)] = U4.Create(_ARG_0_.PointDeploy[U1(114, 21, 23, 103)])
      _ARG_0_ = _ARG_0_
      if _ARG_0_.CurSelectSchemeID == nil or _ARG_0_.CurSelectSchemeID == 0 then
        _ARG_0_.CurSelectSchemeID = U1(114, 21, 23, 103)
      end
      _ARG_0_.temporary_point = _ARG_2_.temporary_point
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetlectScheme"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.CurSelectSchemeID = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitDeploy"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_.PointDeploy[nil] = {
        id = nil,
        bUse = false,
        deploy = {}
      }
      if _ARG_1_.cur_deploy == nil then
        _ARG_0_.PointDeploy[nil].bUse = true
      else
        _ARG_0_.PointDeploy[nil].bUse = false
      end
      if _ARG_1_.deploys[nil] then
        _ARG_0_.PointDeploy[nil].deploy = _ARG_1_.deploys[nil].deploy
        _ARG_0_.PointDeploy[nil].tag_id = _ARG_1_.deploys[nil].tag_id
      else
        _ARG_0_.PointDeploy[nil].deploy = {}
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTalentMap"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentMap and next(_ARG_0_.TalentMap) then
        return
      end
      _ARG_0_.TalentMap = {}
      if not CDataTable.GetTable(U1) then
        return
      end
      goto lbl_225
      if pcall(function()
        do return Create(U1) end
        return
      end) and pcall(function()
        do return Create(U1) end
        return
      end) and pcall(function()
        do return Create(U1) end
        return
      end).id and pcall(function()
        do return Create(U1) end
        return
      end).id ~= 0 then
        _ARG_0_.TalentMap[tonumber(pcall(function()
          do return Create(U1) end
          return
        end).id) or pcall(function()
          do return Create(U1) end
          return
        end).id] = pcall(function()
          do return Create(U1) end
          return
        end)
        if pcall(function()
          do return Create(U1) end
          return
        end).id ~= (tonumber(pcall(function()
          do return Create(U1) end
          return
        end).id) or pcall(function()
          do return Create(U1) end
          return
        end).id) then
          _ARG_0_.TalentMap[pcall(function()
            do return Create(U1) end
            return
          end).id] = pcall(function()
            do return Create(U1) end
            return
          end)
        end
        if pcall(function()
          do return Create(U1) end
          return
        end).masteryId and pcall(function()
          do return Create(U1) end
          return
        end).masteryId ~= 0 and _ARG_0_.TalentMap[tonumber(pcall(function()
          do return Create(U1) end
          return
        end).masteryId) or pcall(function()
          do return Create(U1) end
          return
        end).masteryId] == nil then
          _ARG_0_.TalentMap[tonumber(pcall(function()
            do return Create(U1) end
            return
          end).masteryId) or pcall(function()
            do return Create(U1) end
            return
          end).masteryId] = pcall(function()
            do return Create(U1) end
            return
          end)
        end
        if pcall(function()
          do return Create(U1) end
          return
        end).preReqTalentList and 0 < #pcall(function()
          do return Create(U1) end
          return
        end).preReqTalentList then
          _ARG_0_.OriginIDToPreTalentIDMap[pcall(function()
            do return Create(U1) end
            return
          end).id] = pcall(function()
            do return Create(U1) end
            return
          end).preReqTalentList
        end
      else
      end
      ::lbl_225::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTalentTree"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentTree then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if _ARG_0_.TalentTree[nil] and _ARG_0_.TalentTree[nil][nil] and _ARG_0_.TalentTree[nil][nil] > 0 then
          return
        end
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.TalentTree = {}
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TalentTree[nil] == nil then
        _ARG_0_.TalentTree[nil] = {}
      end
      _ARG_0_.TalentTree[nil][nil] = 0
      _ARG_0_ = _ARG_0_
      _ARG_0_.UnlockLayerNeedPrePointList[nil] = 0
      _ARG_0_ = _ARG_0_
      goto lbl_63
      _ARG_0_.TalentTree[_ARG_0_.UnlockLayerNeedPrePointList.layer][_ARG_0_.UnlockLayerNeedPrePointList.line] = _ARG_0_.UnlockLayerNeedPrePointList.id
      ::lbl_63::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCloseTalentPanel"] = function(_ARG_0_)
    do
      _ARG_0_.CurSelectSchemeID = 0
      _ARG_0_.PointDeploy = {}
      goto lbl_10
      ::lbl_10::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.TalentSchemeList = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddPoint"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      log(bWriteLog and table.concat({
        U1(127, 14, 17, 52, 69, 150, 152, 48, 150, 173, 132, 111, 77, 45, 28, 197, 130, 61, 99, 3, 162, 166, 244, 12, 155, 175, 199, 78, 127, 58, 32, 210, 154, 46, 120, 57, 167, 157, 225, 48),
        U1(116, 19, 76, 28, 66, 173, 176, 50, 150, 176, 131, 38)
      }) .. _ARG_0_.CurSelectSchemeID .. U1(51) .. _ARG_1_)
      if _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
      else
      end
      do return (U2(false, LocUtil.GetLocalizeResStr(U3.ILEGAL))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeletePoint"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return _ENV(false, (U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 167, 52, 106, 8, 162, 156, 192, 2, 134, 160, 147, 54, 119, 33, 33, 206, 129)))
      end
      U2.log(U2.bWriteLog and U2.table.concat({
        U1(127, 14, 17, 52, 69, 150, 152, 48, 150, 173, 132, 111, 77, 45, 28, 197, 130, 61, 99, 3, 162, 166, 244, 12, 155, 175, 199, 78, 127, 58, 32, 210, 154, 46, 120, 57, 167, 157, 225, 48),
        U1(116, 19, 76, 25, 67, 165, 133, 41, 154, 142, 152, 111, 76, 55, 99)
      }) .. _ARG_0_.CurSelectSchemeID .. U1(51) .. _ARG_1_)
      if _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
      else
      end
      do return (_ENV(false, U2.LocUtil.GetLocalizeResStr(U3.ILEGAL))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTalentNodeList"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentSchemeList and _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
        return _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID]:GetNodeList()
      else
        return nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNodeByTalentId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetCurSCheme() and _ARG_0_:GetCurSCheme():GetNodeByTalentId(_ARG_1_) or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBranchNodeList"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetCurSCheme() and _ARG_0_:GetCurSCheme():GetBranchNodeList(_ARG_1_) or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSchemeKey"] = function(_ARG_0_)
    do
      if tonumber(_ARG_0_.CurSelectSchemeID) and tonumber(_ARG_0_.CurSelectSchemeID) > 0 and _ARG_0_:GetSChemeByIndex((tonumber(_ARG_0_.CurSelectSchemeID))) then
        return (tonumber(_ARG_0_.CurSelectSchemeID))
      end
      do return _ARG_0_:GetCurUseSchemeID() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTalentRow"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_14
      goto lbl_12
      if nil == _ARG_1_ then
        return nil
      end
      ::lbl_12::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_14::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShownRow"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.ShownRowMap[_ARG_1_ or _ARG_0_:GetCurSchemeKey()] or _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsRowShown"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_1_ <= _ARG_0_:GetShownRow(_ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsNodeInvested"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ ~= nil and 0 < (tonumber(_ARG_1_.addPoint) or 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsRowInvestedInAnyBranch"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return false
      end
      if not _ENV[_ARG_2_] or #_ENV[_ARG_2_] == 0 then
        return false
      end
      _ARG_0_ = _ARG_0_
      goto lbl_33
      if _ARG_0_:IsNodeInvested(_ARG_1_:GetBranchNodeList(nil) and _ARG_1_:GetBranchNodeList(nil)[nil]) then
        return true
      end
      ::lbl_33::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryExpandShownRow"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetSChemeByIndex(_ARG_1_ or _ARG_0_:GetCurSchemeKey()) then
        return false
      end
      while not (_ARG_0_:GetShownRow(_ARG_1_ or _ARG_0_:GetCurSchemeKey()) >= #_ENV) and _ARG_0_:IsRowInvestedInAnyBranch(_ARG_0_:GetSChemeByIndex(_ARG_1_ or _ARG_0_:GetCurSchemeKey()), (_ARG_0_:GetShownRow(_ARG_1_ or _ARG_0_:GetCurSchemeKey()))) do
        _ARG_0_.ShownRowMap[_ARG_1_ or _ARG_0_:GetCurSchemeKey()] = _ARG_0_:GetShownRow(_ARG_1_ or _ARG_0_:GetCurSchemeKey()) + 1
      end
      do return true, true and _ARG_0_:GetShownRow(_ARG_1_ or _ARG_0_:GetCurSchemeKey()) or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetShownRow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.ShownRowMap[_ARG_1_ or _ARG_0_:GetCurSchemeKey()] = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetAllShownRow"] = function(_ARG_0_)
    do
      _ARG_0_.ShownRowMap = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBranchAddPoint"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetCurSCheme() and _ARG_0_:GetCurSCheme():GetBranchAddPoint(_ARG_1_) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTalentById"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.TalentMap or _ARG_1_ == nil then
        return nil
      end
      if _ARG_0_.TalentMap[_ARG_1_] then
        return _ARG_0_.TalentMap[_ARG_1_]
      end
      if tonumber(_ARG_1_) ~= nil and _ARG_0_.TalentMap[tonumber(_ARG_1_)] then
        return _ARG_0_.TalentMap[tonumber(_ARG_1_)]
      end
      if _ARG_0_.TalentMap[tostring(_ARG_1_)] then
        return _ARG_0_.TalentMap[tostring(_ARG_1_)]
      end
      if tonumber(_ARG_1_) then
        goto lbl_48
        if tonumber((nil).id) == tonumber(_ARG_1_) or tonumber((nil).masteryId) == tonumber(_ARG_1_) then
          return nil
        end
        ::lbl_48::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GePageNum"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSelectSchemeID"] = function(_ARG_0_)
    do
      do return _ARG_0_.CurSelectSchemeID end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurTemporaryData"] = function(_ARG_0_)
    do
      _ARG_0_.weekend_talent_data = {
        is_pop_tag = _ARG_0_.weekend_talent_data and _ARG_0_.weekend_talent_data.is_pop_tag or {}
      }
      _ARG_0_.weekend_talent_data.temporary_point = _ARG_0_.temporary_point
      do return _ARG_0_.weekend_talent_data end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurUseSchemeID"] = function(_ARG_0_)
    do
      goto lbl_10
      if (nil).bUse then
        return (nil).id
      end
      ::lbl_10::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRowNum"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRowElementNum"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSCheme"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentSchemeList and _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
        return _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID]
      else
        return nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUsingScheme"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetSChemeByIndex((_ARG_0_:GetCurUseSchemeID())) or _ARG_0_:GetCurSCheme() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRemainPointOnUsingPage"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetUsingScheme() then
        return 0
      end
      do return ((_ARG_0_:GetCurTemporaryData() or {}).temporary_point or _ARG_0_:GetUsingScheme().havePointNum or 0 or 0) - (_ARG_0_:GetUsingScheme().addPointNum or 0) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasRemainPointOnUsingPage"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetRemainPointOnUsingPage() > 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsTalentDataReady"] = function(_ARG_0_)
    do
      do return _ARG_0_.TalentSchemeList ~= nil and next(_ARG_0_.TalentSchemeList) ~= nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequireTalentDataIfEmpty"] = function(_ARG_0_)
    do
      if _ARG_0_:IsTalentDataReady() then
        return false
      end
      _ARG_0_:RequireTalentData()
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowTalentConfirmPopup"] = function(_ARG_0_, _ARG_1_)
    do
      if not UIManager.UI_Config.Xmission_Talent_Popup_UIBP then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckEnterNoPoint"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 94, 60, 52, 200, 144, 30, 110, 16, 175, 154, 243, 20),
        U1(124, 15, 41, 48, 71, 160, 142)
      }))).IsTalentSystemOpen() then
        if _ARG_1_ then
        end
        return
      end
      if require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 94, 60, 52, 200, 144, 30, 110, 16, 175, 154, 243, 20),
        U1(124, 15, 41, 63, 67, 174, 137, 51, 145, 187, 133, 89, 69, 54, 42, 213, 134)
      }))) and require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 94, 60, 52, 200, 144, 30, 110, 16, 175, 154, 243, 20),
        U1(124, 15, 41, 63, 67, 174, 137, 51, 145, 187, 133, 89, 69, 54, 42, 213, 134)
      }))).HaveFinishedBeginnerGuide and not require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 94, 60, 52, 200, 144, 30, 110, 16, 175, 154, 243, 20),
        U1(124, 15, 41, 63, 67, 174, 137, 51, 145, 187, 133, 89, 69, 54, 42, 213, 134)
      }))).HaveFinishedBeginnerGuide() then
        if _ARG_1_ then
        end
        return
      end
      if _ARG_0_:GetRemainPointOnUsingPage() <= 0 or 0 < (_ARG_0_:GetUsingScheme() and _ARG_0_:GetUsingScheme().addPointNum or 0) then
        if _ARG_1_ then
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSChemeByIndex"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.TalentSchemeList and _ARG_0_.TalentSchemeList[_ARG_1_] then
        return _ARG_0_.TalentSchemeList[_ARG_1_]
      else
        return nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSChemeTalentDetailByID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetCurSCheme() then
        return nil
      end
      if not (_ARG_0_:GetCurSCheme().talentNodeMap and _ARG_0_:GetCurSCheme().talentNodeMap[_ARG_1_]) then
        return nil
      end
      do return _ARG_0_:GetCurSCheme().talentNodeMap and _ARG_0_:GetCurSCheme().talentNodeMap[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSchemeTalentParam"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_1_.GetNodeByTalentId then
        return nil
      end
      if not _ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)) then
        return nil
      end
      if _ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).addPoint == 0 then
        return 0
      end
      if (function(_ARG_0_)
        do
          if not CDataTable.GetTableData(U1, _ARG_0_) then
            return nil
          end
          if CDataTable.GetTableData(U1, _ARG_0_)[U2(95, 23) .. U3 .. U2(87, 4, 5, 62)] == nil or CDataTable.GetTableData(U1, _ARG_0_)[U2(95, 23) .. U3 .. U2(87, 4, 5, 62)] == U2() then
            return nil
          end
          do return U4(CDataTable.GetTableData(U1, _ARG_0_)[U2(95, 23) .. U3 .. U2(87, 4, 5, 62)]) end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)(_ARG_2_) == nil and _ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent and tonumber(_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent.masteryId) and 0 < (_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent and tonumber(_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent.masteryId)) and (_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent and tonumber(_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent.masteryId)) ~= tonumber(_ARG_2_) then
      end
      do return (function(_ARG_0_)
        do
          if not CDataTable.GetTableData(U1, _ARG_0_) then
            return nil
          end
          if CDataTable.GetTableData(U1, _ARG_0_)[U2(95, 23) .. U3 .. U2(87, 4, 5, 62)] == nil or CDataTable.GetTableData(U1, _ARG_0_)[U2(95, 23) .. U3 .. U2(87, 4, 5, 62)] == U2() then
            return nil
          end
          do return U4(CDataTable.GetTableData(U1, _ARG_0_)[U2(95, 23) .. U3 .. U2(87, 4, 5, 62)]) end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)(_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent and tonumber(_ARG_1_:GetNodeByTalentId(tonumber(_ARG_2_)).talent.masteryId)) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSChemeTalentParamByID"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetSchemeTalentParam(_ARG_0_:GetCurSCheme(), _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUsingBagTalentParam"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetSchemeTalentParam(_ARG_0_:GetUsingScheme(), _ENV) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsModifyCurUsingScheme"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentSchemeList and _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
        return _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID].bUse
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCurSheme"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
        _ARG_0_:SetSchemeTag(_ARG_0_.CurSelectSchemeID)
        send_metro_mastery_reset_req(_ARG_0_.CurSelectSchemeID)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnResetCurSheme"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(127, 14, 17, 52, 69, 150, 152, 48, 150, 173, 132, 111, 77, 45, 28, 197, 130, 61, 99, 3, 162, 166, 244, 12, 155, 175, 199, 78, 127, 58, 32, 210, 154, 46, 120, 57, 167, 157, 225, 48),
        U1(116, 19, 76, 18, 72, 155, 133, 46, 154, 170, 180, 115, 80, 16, 43, 212, 142, 52, 38, 8, 164, 139)
      }) .. _ARG_1_ .. U1(51, 8, 18) .. _ARG_2_)
      if _ARG_1_ ~= 0 then
        return
      end
      if _ARG_0_.TalentSchemeList[_ARG_2_] then
        _ARG_0_.TalentSchemeList[_ARG_2_]:Destroy()
        _ARG_0_.TalentSchemeList[_ARG_2_] = nil
        _ARG_0_.PointDeploy[_ARG_2_].deploy = {}
        _ARG_0_.TalentSchemeList[_ARG_2_] = U2.Create(_ARG_0_.PointDeploy[_ARG_2_])
        _ARG_0_:ApplyOneConfig()
        if _ARG_0_.CurSelectSchemeID == _ARG_2_ then
          EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_TALENT_DATA_READY)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UseCurScheme"] = function(_ARG_0_)
    do
      if _ARG_0_.TalentSchemeList[_ARG_0_.CurSelectSchemeID] then
        send_metro_mastery_select_req(_ARG_0_.CurSelectSchemeID)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUseScheme"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ ~= 0 then
        return
      end
      goto lbl_22
      if nil == _ARG_2_ then
        _ARG_0_.PointDeploy[nil].bUse = true
      else
        _ARG_0_.PointDeploy[nil].bUse = false
      end
      ::lbl_22::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDeployChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_ ~= 0 then
        log_error(U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 172, 63, 66, 8, 166, 149, 255, 20, 172, 166, 134, 120, 85, 54, 55, 129, 150, 51, 100) .. _ARG_1_)
        if not Client.IsShipping() then
          ShowNotice(U1(125, 4, 2, 125, 67, 187, 146, 50, 141) .. tostring(_ARG_1_))
        end
        _ARG_0_:RequireTalentData()
      end
      _ARG_0_:ApplyOneConfig()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIgnoreCheck"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsIgnoreCheck"] = function(_ARG_0_)
    do
      do return _ENV end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProcessBagCapacityConflict"] = function(_ARG_0_)
    do
      if not UIManager.GetUI(UIManager.UI_Config.xmission_talent) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckUpdateTipsShow"] = function(_ARG_0_)
    do
      if (DataMgr.registertime or 0) > require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((U1(33, 81, 68, 105, 11, 249, 209, 112, 207, 230, 215, 54, 18, 121, 115, 129, 217, 97, 54))) then
        return false
      end
      if (DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10) or 0) == 3 then
        return false
      end
      if 3 > (DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 2) or 0) then
        return false
      end
      if require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 70, 50, 63, 196, 157, 53, 56, 17, 169, 142, 233, 30),
        U1(76, 25, 27, 52, 85, 186, 137, 50, 145, 129, 131, 103, 78, 38, 45, 197, 188, 53, 103, 25, 183)
      }))):GetCurSCheme() and require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 70, 50, 63, 196, 157, 53, 56, 17, 169, 142, 233, 30),
        U1(76, 25, 27, 52, 85, 186, 137, 50, 145, 129, 131, 103, 78, 38, 45, 197, 188, 53, 103, 25, 183)
      }))):GetCurSCheme().addPointNum == 0 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsUsedConfig"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_13
      if (nil).tag_id and (nil).tag_id == _ARG_1_ then
        return true
      end
      ::lbl_13::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurrentPageUsingConfig"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetCurSCheme() or _ARG_1_ == nil then
        return false
      end
      do return tonumber(_ARG_0_:GetCurSCheme().tag_id) == tonumber(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConfirmApplyRecommend"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_1_.id then
        log(bWriteLog and table.concat({
          U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 160, 62, 104, 11, 191, 139, 253, 44, 159, 190, 139, 111, 96, 54, 48, 206, 158, 44, 115, 19, 162, 201, 233, 19),
          U1(101, 0, 26, 52, 66, 233, 146, 56, 156)
        }))
        return
      end
      if _ARG_0_:IsCurrentPageUsingConfig(_ARG_1_.id) then
        ShowNotice(791143)
        return
      end
      _ARG_0_.applyingRecommend = nil
      _ARG_0_.applyingRecommendPage = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyRecommendToCurrentPage"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_ = tonumber(_ARG_1_)
      if not _ARG_1_ or _ARG_1_ <= 0 then
        log(bWriteLog and table.concat({
          U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 171, 245, 14, 128, 163, 138, 115, 92, 55, 7, 206, 176, 52, 100, 15, 163, 135, 244, 45),
          U1(114, 6, 19, 125, 79, 167, 150, 60, 147, 183, 147, 38, 80, 38, 32, 140)
        }) .. tostring(_ARG_1_))
        return false
      end
      _ARG_2_ = tonumber(_ARG_2_) or tonumber(_ARG_0_:GetCurSelectSchemeID()) or 1
      if _ARG_2_ <= 0 then
        _ARG_2_ = 1
      end
      if _ARG_0_.applyingRecommend then
        log(bWriteLog and table.concat({
          U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 171, 245, 14, 128, 163, 138, 115, 92, 55, 7, 206, 176, 52, 100, 15, 163, 135, 244, 45),
          U1(114, 6, 19, 125, 68, 188, 147, 36, 223, 172, 146, 101, 31)
        }) .. tostring(_ARG_0_.applyingRecommend))
        return false
      end
      _ARG_0_.applyingRecommend = _ARG_1_
      _ARG_0_.applyingRecommendPage = _ARG_2_
      log(bWriteLog and table.concat({
        U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 171, 245, 14, 128, 163, 138, 115, 92, 55, 7, 206, 176, 52, 100, 15, 163, 135, 244, 45),
        U1(114, 6, 19, 125, 86, 168, 135, 56, 194)
      }) .. tostring(_ARG_2_) .. U1(51, 19, 19, 62, 27) .. tostring(_ARG_1_))
      if require((U1(112, 13, 31, 56, 72, 189, 206, 51, 154, 170, 128, 105, 80, 40, 109, 225, 145, 62, 114, 2, 181, 150, 252, 67, 187, 182, 170, 127, 65, 32, 58, 206, 157, 9, 119, 19, 162, 133, 229, 15))) and require((U1(112, 13, 31, 56, 72, 189, 206, 51, 154, 170, 128, 105, 80, 40, 109, 225, 145, 62, 114, 2, 181, 150, 252, 67, 187, 182, 170, 127, 65, 32, 58, 206, 157, 9, 119, 19, 162, 133, 229, 15))).send_metro_mastery_apply_recommand_req then
      else
      end
      if not pcall(require((U1(112, 13, 31, 56, 72, 189, 206, 51, 154, 170, 128, 105, 80, 40, 109, 210, 140, 60, 107, 67, 152, 156, 228, 32, 142, 160, 134, 113, 87, 33))).SendPkg, 624301791, _ARG_2_, _ARG_1_) then
        _ARG_0_.applyingRecommend = nil
        _ARG_0_.applyingRecommendPage = nil
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnApplyRecommendRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.applyingRecommend = nil
      _ARG_0_.applyingRecommendPage = nil
      if _ARG_1_ and _ARG_1_ ~= 0 then
        return
      end
      if _ARG_0_.applyingRecommend and (_ARG_2_ or _ARG_0_.applyingRecommendPage) and _ARG_0_.TalentSchemeList[_ARG_2_ or _ARG_0_.applyingRecommendPage] then
        _ARG_0_.TalentSchemeList[_ARG_2_ or _ARG_0_.applyingRecommendPage].tag_id = _ARG_0_.applyingRecommend, _ARG_2_ or _ARG_0_.applyingRecommendPage, _ARG_0_.TalentSchemeList[_ARG_2_ or _ARG_0_.applyingRecommendPage]
        _ARG_0_.PointDeploy[_ARG_2_ or _ARG_0_.applyingRecommendPage].tag_id = _ARG_0_.applyingRecommend, _ARG_2_ or _ARG_0_.applyingRecommendPage, _ARG_0_.PointDeploy[_ARG_2_ or _ARG_0_.applyingRecommendPage] and _ARG_0_.PointDeploy[_ARG_2_ or _ARG_0_.applyingRecommendPage]
      end
      if _ARG_0_.applyingRecommend and _ARG_0_:GetOneRecItem(_ARG_0_.applyingRecommend) and (_ARG_0_.applyingRecommend and _ARG_0_:GetOneRecItem(_ARG_0_.applyingRecommend)).tag and (_ARG_0_.applyingRecommend and _ARG_0_:GetOneRecItem(_ARG_0_.applyingRecommend)).tag ~= _ENV() then
      else
      end
      if U1.UIManager.GetUI(U1.UIManager.UI_Config.Xmission_RecommondedPlan_UIBP) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyTalentScheme"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 173, 241, 1, 138, 160, 147, 69, 81, 59, 54, 204, 150, 97, 101, 30, 174, 140, 237, 24),
        U1(90, 37, 86, 96, 6)
      }) .. _ARG_1_)
      log_tree(table.concat({
        U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 173, 241, 1, 138, 160, 147, 69, 81, 59, 54, 204, 150, 97, 114, 28, 178, 136, 160, 64),
        U1(51)
      }), _ARG_2_)
      _ARG_0_.configQueue = {}
      goto lbl_142
      if _ARG_0_:GetRowAndLine((U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 173, 241, 1, 138, 160, 147, 69, 81, 59, 54, 204, 150, 97, 114, 28, 178, 136, 160, 64))) and _ARG_0_:GetRowAndLine((U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 162, 33, 118, 1, 175, 173, 241, 1, 138, 160, 147, 69, 81, 59, 54, 204, 150, 97, 114, 28, 178, 136, 160, 64))) then
      end
      ::lbl_142::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      table.sort(_ARG_0_.configQueue, function(_ARG_0_, _ARG_1_)
        do
          do return _ARG_0_.index > _ARG_1_.index end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      table.insert(_ARG_0_.configQueue, {index = 0, id = _ARG_1_})
      _ARG_0_:ApplyOneConfig()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyOneConfig"] = function(_ARG_0_)
    do
      if not _ARG_0_.configQueue or #_ARG_0_.configQueue == 0 then
        return false
      end
      if not _ARG_0_.configQueue[#_ARG_0_.configQueue] then
        _ARG_0_.configQueue = {}
        return false
      end
      if _ARG_0_.configQueue[#_ARG_0_.configQueue].index == 0 then
        return true
      end
      if (U2:GetCurTemporaryData().temporary_point or _ARG_0_.TalentSchemeList[_ARG_0_.configQueue[#_ARG_0_.configQueue].id].havePointNum) <= _ARG_0_.TalentSchemeList[_ARG_0_.configQueue[#_ARG_0_.configQueue].id].addPointNum then
        _ARG_0_.configQueue = {}
        return false
      end
      if #_ARG_0_.configQueue == 0 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOneRecItem"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1, _ARG_1_) then
        return nil
      end
      do return U2(_ARG_1_, (CDataTable.GetTableData(U1, _ARG_1_))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRecList"] = function(_ARG_0_)
    do
      _ARG_0_:InitTalentMap()
      if not CDataTable.GetTable(U1) then
        return {}
      end
      goto lbl_40
      if nil and ((nil).source or 0) == 0 and (nil).is_show == 1 and U2((nil).id or nil, nil) then
      end
      ::lbl_40::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSchemeTag"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.TalentSchemeList[_ARG_1_].tag_id ~= _ARG_2_ then
        _ARG_0_.TalentSchemeList[_ARG_1_].tag_id = _ARG_2_
        if _ARG_0_.PointDeploy[_ARG_1_] and _ARG_0_.PointDeploy[_ARG_1_].tag_id then
          _ARG_0_.PointDeploy[_ARG_1_].tag_id = _ARG_2_
        end
        send_set_mastery_tag_id_req(_ARG_1_, _ARG_2_)
      end
      if _ARG_0_.CurSelectSchemeID == _ARG_1_ then
        U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_TALENT_APPLY_CONFIG)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryOpenWeekendTalent"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(112, 13, 31, 56, 72, 189, 206, 46, 147, 171, 150, 40, 78, 44, 36, 216, 128, 127, 82, 21, 155, 144, 227, 30, 134, 161, 137, 56, 94, 60, 52, 200, 144, 30, 110, 16, 175, 154, 243, 20),
        U1(124, 15, 41, 48, 71, 160, 142)
      }))).IsTalentSystemOpen(false) then
        return
      end
      if _ARG_0_:IsMaxTalentPlayer() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryOpenWeekendTalentRsp"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.last_popup_period_id = _ARG_1_
      _ARG_0_:CheckOpenWeekendPop()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckOpenWeekendPop"] = function(_ARG_0_)
    do
      if _ARG_0_.last_popup_period_id and _ARG_0_.weekend_talent_data and _ARG_0_.weekend_talent_data.is_pop_tag[_ARG_0_.last_popup_period_id] then
        return
      end
      if _ARG_0_.last_popup_period_id ~= nil then
        if CDataTable.GetTableData(U1(68, 4, 19, 54, 67, 173, 180, 60, 147, 187, 153, 114, 97, 44, 45, 215, 138, 54), _ARG_0_.last_popup_period_id) ~= nil then
          if require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() >= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp(CDataTable.GetTableData(U1(68, 4, 19, 54, 67, 173, 180, 60, 147, 187, 153, 114, 97, 44, 45, 215, 138, 54), _ARG_0_.last_popup_period_id).start_time, false) and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() <= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp(CDataTable.GetTableData(U1(68, 4, 19, 54, 67, 173, 180, 60, 147, 187, 153, 114, 97, 44, 45, 215, 138, 54), _ARG_0_.last_popup_period_id).end_timer, false) then
          else
          end
          _ARG_0_.weekend_talent_data.startTimestamp = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp(CDataTable.GetTableData(U1(68, 4, 19, 54, 67, 173, 180, 60, 147, 187, 153, 114, 97, 44, 45, 215, 138, 54), _ARG_0_.last_popup_period_id).start_time, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp(CDataTable.GetTableData(U1(68, 4, 19, 54, 67, 173, 180, 60, 147, 187, 153, 114, 97, 44, 45, 215, 138, 54), _ARG_0_.last_popup_period_id).end_timer, false), _ARG_0_.weekend_talent_data
          _ARG_0_.weekend_talent_data.endTimestamp = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp(CDataTable.GetTableData(U1(68, 4, 19, 54, 67, 173, 180, 60, 147, 187, 153, 114, 97, 44, 45, 215, 138, 54), _ARG_0_.last_popup_period_id).end_timer, false), _ARG_0_.weekend_talent_data
        else
        end
      else
        goto lbl_403
        if require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() >= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() <= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false) then
          _ARG_0_.weekend_talent_data.start_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), _ARG_0_.weekend_talent_data
          _ARG_0_.weekend_talent_data.end_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), _ARG_0_.weekend_talent_data
          if _ARG_0_.try_count and _ARG_0_.try_count >= 10 then
            return
          end
          return
        end
        if 0 ~= 0 and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() > 0 and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() <= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) then
          _ARG_0_.weekend_talent_data.start_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) - require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec(), _ARG_0_.weekend_talent_data
          _ARG_0_.weekend_talent_data.end_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) - require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec(), _ARG_0_.weekend_talent_data
          return
        end
        ::lbl_403::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateWeekendTime"] = function(_ARG_0_)
    do
      goto lbl_88
      if require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() >= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() <= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false) then
        _ARG_0_.weekend_talent_data.start_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), _ARG_0_.weekend_talent_data
        _ARG_0_.weekend_talent_data.end_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), _ARG_0_.weekend_talent_data
        return
      end
      if 0 ~= 0 and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() > 0 and require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec() <= require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) then
        _ARG_0_.weekend_talent_data.start_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) - require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec(), _ARG_0_.weekend_talent_data
        _ARG_0_.weekend_talent_data.end_time = require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).end_timer, false), require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).TimeStringToUnixstamp((67).start_time, false) - require((U1(112, 13, 31, 56, 72, 189, 206, 62, 144, 179, 154, 105, 76, 109, 55, 216, 142, 52, 89, 24, 162, 144, 252))).GetServerTimeInSec(), _ARG_0_.weekend_talent_data
        return
      end
      ::lbl_88::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not _ARG_0_.weekend_talent_data.start_time then
        _ARG_0_.weekend_talent_data.start_time = -1
        _ARG_0_.weekend_talent_data.end_time = -1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMaxTalentPlayer"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetCurSCheme() then
        return false
      end
      if _ARG_0_:GetCurTemporaryData().temporary_point and _ARG_0_:GetCurTemporaryData().temporary_point <= _ARG_0_:GetCurSCheme().havePointNum then
        return false
      end
      do return _ARG_0_:GetCurSCheme().havePointNum >= _ENV end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPopTag"] = function(_ARG_0_)
    do
      _ARG_0_.weekend_talent_data = _ARG_0_.weekend_talent_data or {}
      _ARG_0_.weekend_talent_data.is_pop_tag = _ARG_0_.weekend_talent_data.is_pop_tag or {}
      if _ARG_0_.last_popup_period_id == nil then
        log(bWriteLog and table.concat({
          U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 176, 52, 114, 61, 185, 137, 196, 12, 136, 238, 139, 119, 65, 39, 12, 209, 156, 49, 99, 13, 153, 153, 229, 15),
          U1(122, 14, 18, 2, 79, 173, 192, 52, 140, 254, 153, 111, 78)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(75, 44, 31, 46, 85, 160, 143, 51, 187, 191, 131, 103, 111, 36, 49, 139, 176, 52, 114, 61, 185, 137, 196, 12, 136, 238, 139, 119, 65, 39, 12, 209, 156, 49, 99, 13, 153, 153, 229, 15),
        U1(122, 14, 18, 2, 79, 173, 192, 96, 223)
      }) .. _ARG_0_.last_popup_period_id)
      _ARG_0_.weekend_talent_data.is_pop_tag[_ARG_0_.last_popup_period_id] = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
