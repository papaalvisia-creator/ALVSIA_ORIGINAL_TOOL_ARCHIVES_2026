.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	57

.upvalue	"_ENV"	0	true

.constant	k0	132
.constant	k1	110
.constant	k2	150
.constant	k3	219
.constant	k4	151
.constant	k5	146
.constant	k6	199
.constant	k7	1
.constant	k8	120
.constant	k9	183
.constant	k10	166
.constant	k11	92
.constant	k12	69
.constant	k13	7
.constant	k14	86
.constant	k15	158
.constant	k16	"require"
.constant	k17	224
.constant	k18	36
.constant	k19	186
.constant	k20	218
.constant	k21	122
.constant	k22	68
.constant	k23	40
.constant	k24	235
.constant	k25	220
.constant	k26	250
.constant	k27	46
.constant	k28	75
.constant	k29	240
.constant	k30	136
.constant	k31	104
.constant	k32	25
.constant	k33	209
.constant	k34	111
.constant	k35	20
.constant	k36	180
.constant	k37	185
.constant	k38	206
.constant	k39	234
.constant	k40	98
.constant	k41	74
.constant	k42	255
.constant	k43	144
.constant	k44	52
.constant	k45	6
.constant	k46	55
.constant	k47	222
.constant	k48	254
.constant	k49	9
.constant	k50	"table"
.constant	k51	"concat"
.constant	k52	82
.constant	k53	242
.constant	k54	47
.constant	k55	16
.constant	k56	208
.constant	k57	231
.constant	k58	133
.constant	k59	114
.constant	k60	19
.constant	k61	142
.constant	k62	245
.constant	k63	216
.constant	k64	236
.constant	k65	62
.constant	k66	93
.constant	k67	229
.constant	k68	147
.constant	k69	79
.constant	k70	11
.constant	k71	160
.constant	k72	58
.constant	k73	188
.constant	k74	204
.constant	k75	"import"
.constant	k76	43
.constant	k77	161
.constant	k78	214
.constant	k79	100
.constant	k80	78
.constant	k81	217
.constant	k82	123
.constant	k83	243
.constant	k84	29
.constant	k85	"SortConfig"
.constant	k86	"version"
.constant	k87	0
.constant	k88	"SortPreference"
.constant	k89	"SortPreference_Inherit"
.constant	k90	"SortPreferenceByMatch"
.constant	k91	1
.constant	k92	"SortPreferenceByMatch_Inherit"
.constant	k93	"lastThemeItemInsID"
.constant	k94	"VehicleSceneType"
.constant	k95	"None"
.constant	k96	"SuperCar"
.constant	k97	"Ordinary"
.constant	k98	2
.constant	k99	"lastSubTabString"
.constant	k100	"recordTime"
.constant	k101	"bTriggerPutOn"
.constant	k102	false
.constant	k103	"bTriggerSuitDye"
.constant	k104	"bFirstEnter"
.constant	k105	true
.constant	k106	"wardrobeEditMode"
.constant	k107	"EWardrobeEditMode"
.constant	k108	"RecordForShareSkinCmp"
.constant	k109	nil
.constant	k110	"depotItemPackageArray"
.constant	k111	"depotPackageTimeOut"
.constant	k112	"isInShareSubscribeSetup"
.constant	k113	"currentShareList"
.constant	k114	"currentShareType"
.constant	k115	"searchString"
.constant	k116	"_LazySortType"
.constant	k117	"characterUseCache"
.constant	k118	"IsLowMemoryDevice"
.constant	k119	39
.constant	k120	190
.constant	k121	210
.constant	k122	94
.constant	k123	97
.constant	k124	249
.constant	k125	50
.constant	k126	18
.constant	k127	"CreateSuperData"
.constant	k128	"pageId"
.constant	k129	-1
.constant	k130	"tabId"
.constant	k131	"ENUM_WardrobeSubTabString"
.constant	k132	"ENUM_WardrobeSubTabString_empty"
.constant	k133	212
.constant	k134	238
.constant	k135	4
.constant	k136	165
.constant	k137	124
.constant	k138	65
.constant	k139	53
.constant	k140	60
.constant	k141	31
.constant	k142	237
.constant	k143	163
.constant	k144	230
.constant	k145	23
.constant	k146	178
.constant	k147	201
.constant	k148	117
.constant	k149	103
.constant	k150	"ENUM_WardrobePageTypeId"
.constant	k151	155
.constant	k152	12
.constant	k153	10
.constant	k154	192
.constant	k155	113
.constant	k156	"OnModePostSwitch"
.constant	k157	"on_sync_depot_info"
.constant	k158	"on_sync_depot_item_info"
.constant	k159	"clearSyncDepotItemInfo"
.constant	k160	"GetCurrSceneType"
.constant	k161	"SetCurrSceneType"
.constant	k162	"Enter"
.constant	k163	"EnterBeforShowUI"
.constant	k164	"_ExtractJumpArgs"
.constant	k165	"EnterWardrobe"
.constant	k166	"JumpTo"
.constant	k167	"IsWearValid"
.constant	k168	"UpdateInvalidWearInfo"
.constant	k169	"GetItemPart"
.constant	k170	"wardrobe_puton_data_req"
.constant	k171	"wardrobe_puton_req"
.constant	k172	"on_puton_rsp"
.constant	k173	"wardrobe_put_down_data_req"
.constant	k174	"wardrobe_put_down_req"
.constant	k175	"on_putdown_rsp"
.constant	k176	"wardrobe_change_item_new_status"
.constant	k177	"wardrobe_change_item_list_new_status"
.constant	k178	"FindMotion"
.constant	k179	"EquipMotion"
.constant	k180	"equip_motion_list_req"
.constant	k181	"unequip_motion_req"
.constant	k182	"PlayMotion"
.constant	k183	"StopMVPMotionLocalPlay"
.constant	k184	"IsValidTime"
.constant	k185	"GetRemainTimeStr"
.constant	k186	"GetTimeStr"
.constant	k187	"ShowLobbyHotDot"
.constant	k188	"IsServerJK"
.constant	k189	"IsCharacterUse"
.constant	k190	"IsItemIsolated"
.constant	k191	"IsCanUse"
.constant	k192	"HasSameDiySuit"
.constant	k193	"GetShaoJiItemId"
.constant	k194	"GetItemResId"
.constant	k195	"GetWardrobeInsIdByResId"
.constant	k196	"IsValidCurrentPageItem"
.constant	k197	"IsValidCurrentPageItemBySubTabGroup"
.constant	k198	"SetDisplayItemId"
.constant	k199	"RemoveDisplayItemId"
.constant	k200	"ArrayHallDepotToCommonItem"
.constant	k201	"on_use_item_rsp"
.constant	k202	"on_depot_set_skin_info_rsp"
.constant	k203	"UpdateLastEquipForeverSkin"
.constant	k204	"UpdateSkinInfo"
.constant	k205	"RecordCurrentFashion"
.constant	k206	"SetWardrobeEditMode"
.constant	k207	"GetWardrobeEditMode"
.constant	k208	"IsInFashionBagEditMode"
.constant	k209	"IsInInheritMode"
.constant	k210	"GetShareType"
.constant	k211	"SetCurrentPageId"
.constant	k212	"GetCurrentPageId"
.constant	k213	"SetCurrentTabId"
.constant	k214	"GetCurrentTabId"
.constant	k215	"SetCurrentThrowObjectType"
.constant	k216	"GetCurrentThrowObjectType"
.constant	k217	"SetCurrentPlaneType"
.constant	k218	"GetCurrentPlaneObjectType"
.constant	k219	"GetCurrentPageAndTabData"
.constant	k220	"CheckCanUseRedEmotion"
.constant	k221	"SetClickItemInsId"
.constant	k222	"GetClickItemInsId"
.constant	k223	"GetSortCmpFunction"
.constant	k224	"GetSortFuncForLazyInit"
.constant	k225	"SortItemTable"
.constant	k226	"CanLazySort"
.constant	k227	"LazySortType"
.constant	k228	"CalcSortPriorityOfSubType"
.constant	k229	"wardrobe_batch_put_down_req"
.constant	k230	"isVehicle"
.constant	k231	"wardrobe_batch_put_on_req"
.constant	k232	"ChangeToLobbyScene"
.constant	k233	"EnterGrenadeScene"
.constant	k234	"EnterHolographyScene"
.constant	k235	"EnterPlatingScene"
.constant	k236	"EnterGarageScene"
.constant	k237	"EnterVehicleSceneByItemID"
.constant	k238	"EnterParachuteScene"
.constant	k239	"EnterWardrobeScene"
.constant	k240	"EnterAvatarPageAndOpenSubscribePopup"
.constant	k241	"EnterSubscribeEditModeWithoutPopup"
.constant	k242	"ExitWardrobeScene"
.constant	k243	"ShowGrenadeModel"
.constant	k244	"PlayMVPTabDisplay"
.constant	k245	"ShowVehicleModel"
.constant	k246	"ShowBagPendantModel"
.constant	k247	"ShowParachuteModel"
.constant	k248	"ShowMinitvModel"
.constant	k249	"ShowHolographyModel"
.constant	k250	"ExtractHigh32Bits"
.constant	k251	"ExtractLow19Bits"
.constant	k252	"GetSortPreference"
.constant	k253	"SetSortPreference"
.constant	k254	"GetMatchTabSortPreference"
.constant	k255	"SetMatchSortPreference"
.constant	k256	"IsWardrobeShow"
.constant	k257	"SwitchCameraInWardrobe"
.constant	k258	"IsCharacterAction"
.constant	k259	"ShowAircraftNotice"
.constant	k260	"IsFirstPutOnAircraft"
.constant	k261	"OnPutOffAircraft"
.constant	k262	"EquipSlotVehicle"
.constant	k263	"SetFristEnter"
.constant	k264	"SetTriggerPutOn"
.constant	k265	"SetTriggerSuitDye"
.constant	k266	"GetSearchString"
.constant	k267	"SetSearchString"
.constant	k268	"PutItemToShareList"
.constant	k269	"RemoveItemFromShareList"
.constant	k270	"FindItemInShareList"
.constant	k271	"SetSubscribeShareList"
.constant	k272	"GetShareBagItemList"
.constant	k273	"SyncSubscribeShareItemListToServer"
.constant	k274	"SetSharedBackpackParams"
.constant	k275	"GetSharedBackpackQualityLimit"
.constant	k276	"GetSharedBackpackBlackItemTable"
.constant	k277	"TryLoadSaveOperation"
.constant	k278	"CompatibilityCornerTagCache"
.constant	k279	"WardrobeSelectWithSaveOperation"
.constant	k280	"ReportTLog"
.constant	k281	"OnGameStateChange"
.constant	k282	"ReportTLogEnum"
.constant	k283	"Wardrobe"
.constant	k284	1
.constant	k285	"WardrobeSuit"
.constant	k286	2
.constant	k287	"FashionBag"
.constant	k288	3
.constant	k289	"SharePackage"
.constant	k290	4

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 132
.line	0	loadk         r2    k1 ; k1 = 110
.line	0	loadk         r3    k2 ; k2 = 150
.line	0	loadk         r4    k3 ; k3 = 219
.line	0	loadk         r5    k4 ; k4 = 151
.line	0	loadk         r6    k5 ; k5 = 146
.line	0	loadk         r7    k6 ; k6 = 199
.line	0	loadk         r8    k7 ; k7 = 1
.line	0	loadk         r9    k8 ; k8 = 120
.line	0	loadk        r10    k9 ; k9 = 183
.line	0	loadk        r11   k10 ; k10 = 166
.line	0	loadk        r12   k11 ; k11 = 92
.line	0	loadk        r13   k12 ; k12 = 69
.line	0	loadk        r14   k13 ; k13 = 7
.line	0	loadk        r15   k14 ; k14 = 86
.line	0	loadk        r16   k15 ; k15 = 158
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	gettabup      r2    u0   k16 ; k16 = "require"
.line	0	move          r3    r1
.line	0	loadk         r4   k17 ; k17 = 224
.line	0	loadk         r5   k18 ; k18 = 36
.line	0	loadk         r6   k19 ; k19 = 186
.line	0	loadk         r7   k20 ; k20 = 218
.line	0	loadk         r8   k21 ; k21 = 122
.line	0	loadk         r9   k22 ; k22 = 68
.line	0	loadk        r10   k23 ; k23 = 40
.line	0	loadk        r11    k5 ; k5 = 146
.line	0	loadk        r12   k24 ; k24 = 235
.line	0	loadk        r13   k25 ; k25 = 220
.line	0	loadk        r14   k26 ; k26 = 250
.line	0	loadk        r15   k27 ; k27 = 46
.line	0	loadk        r16   k28 ; k28 = 75
.line	0	loadk        r17   k29 ; k29 = 240
.line	0	loadk        r18   k30 ; k30 = 136
.line	0	loadk        r19   k31 ; k31 = 104
.line	0	loadk        r20   k18 ; k18 = 36
.line	0	loadk        r21   k32 ; k32 = 25
.line	0	loadk        r22   k33 ; k33 = 209
.line	0	loadk        r23   k24 ; k24 = 235
.line	0	loadk        r24    k2 ; k2 = 150
.line	0	loadk        r25   k34 ; k34 = 111
.line	0	loadk        r26   k35 ; k35 = 20
.line	0	loadk        r27   k36 ; k36 = 180
.line	0	loadk        r28   k37 ; k37 = 185
.line	0	loadk        r29   k38 ; k38 = 206
.line	0	loadk        r30   k39 ; k39 = 234
.line	0	loadk        r31   k40 ; k40 = 98
.line	0	loadk        r32   k41 ; k41 = 74
.line	0	loadk        r33   k42 ; k42 = 255
.line	0	loadk        r34   k43 ; k43 = 144
.line	0	loadk        r35   k44 ; k44 = 52
.line	0	loadk        r36   k45 ; k45 = 6
.line	0	loadk        r37   k46 ; k46 = 55
.line	0	loadk        r38   k47 ; k47 = 222
.line	0	loadk        r39   k48 ; k48 = 254
.line	0	loadk        r40    k4 ; k4 = 151
.line	0	loadk        r41   k40 ; k40 = 98
.line	0	loadk        r42   k49 ; k49 = 9
.line	0	call          r3    40     2
.line	0	call          r2     2     2
.line	0	gettabup      r3    u0   k16 ; k16 = "require"
.line	0	gettabup      r4    u0   k50 ; k50 = "table"
.line	0	gettable      r4    r4   k51 ; k51 = "concat"
.line	0	newtable      r5     1     0
.line	0	move          r6    r1
.line	0	loadk         r7   k17 ; k17 = 224
.line	0	loadk         r8   k18 ; k18 = 36
.line	0	loadk         r9   k19 ; k19 = 186
.line	0	loadk        r10   k20 ; k20 = 218
.line	0	loadk        r11   k21 ; k21 = 122
.line	0	loadk        r12   k22 ; k22 = 68
.line	0	loadk        r13   k23 ; k23 = 40
.line	0	loadk        r14    k5 ; k5 = 146
.line	0	loadk        r15   k24 ; k24 = 235
.line	0	loadk        r16   k25 ; k25 = 220
.line	0	loadk        r17   k26 ; k26 = 250
.line	0	loadk        r18   k27 ; k27 = 46
.line	0	loadk        r19   k52 ; k52 = 82
.line	0	loadk        r20   k53 ; k53 = 242
.line	0	loadk        r21   k30 ; k30 = 136
.line	0	loadk        r22   k54 ; k54 = 47
.line	0	loadk        r23   k55 ; k55 = 16
.line	0	loadk        r24   k14 ; k14 = 86
.line	0	loadk        r25   k56 ; k56 = 208
.line	0	loadk        r26   k57 ; k57 = 231
.line	0	loadk        r27   k58 ; k58 = 133
.line	0	loadk        r28   k59 ; k59 = 114
.line	0	loadk        r29   k60 ; k60 = 19
.line	0	loadk        r30   k61 ; k61 = 142
.line	0	loadk        r31   k62 ; k62 = 245
.line	0	loadk        r32   k63 ; k63 = 216
.line	0	loadk        r33   k64 ; k64 = 236
.line	0	loadk        r34   k65 ; k65 = 62
.line	0	loadk        r35   k66 ; k66 = 93
.line	0	loadk        r36   k67 ; k67 = 229
.line	0	loadk        r37   k15 ; k15 = 158
.line	0	loadk        r38   k18 ; k18 = 36
.line	0	loadk        r39   k45 ; k45 = 6
.line	0	loadk        r40   k46 ; k46 = 55
.line	0	loadk        r41   k33 ; k33 = 209
.line	0	loadk        r42   k48 ; k48 = 254
.line	0	loadk        r43   k68 ; k68 = 147
.line	0	loadk        r44   k69 ; k69 = 79
.line	0	loadk        r45   k70 ; k70 = 11
.line	0	loadk        r46   k71 ; k71 = 160
.line	0	call          r6    41     2
.line	0	move          r7    r1
.line	0	loadk         r8   k17 ; k17 = 224
.line	0	loadk         r9   k72 ; k72 = 58
.line	0	loadk        r10   k73 ; k73 = 188
.line	0	loadk        r11   k74 ; k74 = 204
.line	0	call          r7     5     0
.line	0	setlist       r5     0     1
.line	0	call          r4     2     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k75 ; k75 = "import"
.line	0	move          r5    r1
.line	0	loadk         r6   k56 ; k56 = 208
.line	0	loadk         r7   k76 ; k76 = 43
.line	0	loadk         r8   k77 ; k77 = 161
.line	0	loadk         r9   k78 ; k78 = 214
.line	0	loadk        r10   k79 ; k79 = 100
.line	0	loadk        r11   k22 ; k22 = 68
.line	0	loadk        r12   k80 ; k80 = 78
.line	0	loadk        r13    k0 ; k0 = 132
.line	0	loadk        r14   k24 ; k24 = 235
.line	0	loadk        r15   k81 ; k81 = 217
.line	0	loadk        r16   k48 ; k48 = 254
.line	0	loadk        r17   k59 ; k59 = 114
.line	0	loadk        r18   k82 ; k82 = 123
.line	0	loadk        r19   k83 ; k83 = 243
.line	0	loadk        r20   k30 ; k30 = 136
.line	0	loadk        r21   k54 ; k54 = 47
.line	0	loadk        r22   k84 ; k84 = 29
.line	0	loadk        r23   k84 ; k84 = 29
.line	0	call          r5    19     2
.line	0	call          r4     2     2
.line	0	newtable      r5     0    18
.line	0	newtable      r6     0     5
.line	0	settable      r6   k86   k87 ; k87 = 0
.line	0	newtable      r7     0     0
.line	0	settable      r6   k88    r7 ; k88 = "SortPreference"
.line	0	newtable      r7     0     0
.line	0	settable      r6   k89    r7 ; k89 = "SortPreference_Inher" (truncated)
.line	0	settable      r6   k90   k91 ; k91 = 1
.line	0	settable      r6   k92   k91 ; k91 = 1
.line	0	settable      r5   k85    r6 ; k85 = "SortConfig"
.line	0	settable      r5   k93   k87 ; k87 = 0
.line	0	newtable      r6     0     3
.line	0	settable      r6   k95   k87 ; k87 = 0
.line	0	settable      r6   k96   k91 ; k91 = 1
.line	0	settable      r6   k97   k98 ; k98 = 2
.line	0	settable      r5   k94    r6 ; k94 = "VehicleSceneType"
.line	0	move          r6    r1
.line	0	call          r6     1     2
.line	0	settable      r5   k99    r6 ; k99 = "lastSubTabString"
.line	0	settable      r5  k100   k87 ; k87 = 0
.line	0	settable      r5  k101  k102 ; k102 = false
.line	0	settable      r5  k103  k102 ; k102 = false
.line	0	settable      r5  k104  k105 ; k105 = true
.line	0	gettable      r6    r2  k107 ; k107 = "EWardrobeEditMode"
.line	0	gettable      r6    r6   k95 ; k95 = "None"
.line	0	settable      r5  k106    r6 ; k106 = "wardrobeEditMode"
.line	0	settable      r5  k108  k109 ; k109 = nil
.line	0	settable      r5  k110  k109 ; k109 = nil
.line	0	settable      r5  k111  k109 ; k109 = nil
.line	0	settable      r5  k112  k102 ; k102 = false
.line	0	newtable      r6     0     0
.line	0	settable      r5  k113    r6 ; k113 = "currentShareList"
.line	0	settable      r5  k114  k109 ; k109 = nil
.line	0	move          r6    r1
.line	0	call          r6     1     2
.line	0	settable      r5  k115    r6 ; k115 = "searchString"
.line	0	settable      r5  k116   k91 ; k91 = 1
.line	0	newtable      r6     0     0
.line	0	settable      r5  k117    r6 ; k117 = "characterUseCache"
.line	0	gettable      r6    r4  k118 ; k118 = "IsLowMemoryDevice"
.line	0	call          r6     1     2
.line	0	settable      r5  k118    r6 ; k118 = "IsLowMemoryDevice"
.line	0	loadk         r6   k91 ; k91 = 1
.line	0	gettabup      r7    u0   k16 ; k16 = "require"
.line	0	move          r8    r1
.line	0	loadk         r9   k17 ; k17 = 224
.line	0	loadk        r10  k119 ; k119 = 39
.line	0	loadk        r11  k120 ; k120 = 190
.line	0	loadk        r12  k121 ; k121 = 210
.line	0	loadk        r13   k82 ; k82 = 123
.line	0	loadk        r14  k122 ; k122 = 94
.line	0	loadk        r15   k23 ; k23 = 40
.line	0	loadk        r16    k5 ; k5 = 146
.line	0	loadk        r17   k53 ; k53 = 242
.line	0	loadk        r18   k81 ; k81 = 217
.line	0	loadk        r19   k48 ; k48 = 254
.line	0	loadk        r20   k59 ; k59 = 114
.line	0	loadk        r21  k123 ; k123 = 97
.line	0	loadk        r22  k124 ; k124 = 249
.line	0	loadk        r23   k61 ; k61 = 142
.line	0	loadk        r24  k125 ; k125 = 50
.line	0	loadk        r25  k126 ; k126 = 18
.line	0	call          r8    18     2
.line	0	call          r7     2     2
.line	0	gettable      r8    r7  k127 ; k127 = "CreateSuperData"
.line	0	newtable      r9     0     2
.line	0	settable      r9  k128  k129 ; k129 = -1
.line	0	gettable     r10    r2  k131 ; k131 = "ENUM_WardrobeSubTabS" (truncated)
.line	0	gettable     r10   r10  k132 ; k132 = "ENUM_WardrobeSubTabS" (truncated)
.line	0	settable      r9  k130   r10 ; k130 = "tabId"
.line	0	call          r8     2     2
.line	0	loadnil       r9     0
.line	0	gettabup     r10    u0   k16 ; k16 = "require"
.line	0	gettabup     r11    u0   k50 ; k50 = "table"
.line	0	gettable     r11   r11   k51 ; k51 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14   k17 ; k17 = 224
.line	0	loadk        r15   k18 ; k18 = 36
.line	0	loadk        r16   k19 ; k19 = 186
.line	0	loadk        r17   k20 ; k20 = 218
.line	0	loadk        r18   k21 ; k21 = 122
.line	0	loadk        r19   k22 ; k22 = 68
.line	0	loadk        r20   k23 ; k23 = 40
.line	0	loadk        r21    k5 ; k5 = 146
.line	0	loadk        r22   k24 ; k24 = 235
.line	0	loadk        r23   k25 ; k25 = 220
.line	0	loadk        r24   k26 ; k26 = 250
.line	0	loadk        r25   k27 ; k27 = 46
.line	0	loadk        r26   k52 ; k52 = 82
.line	0	loadk        r27   k53 ; k53 = 242
.line	0	loadk        r28   k30 ; k30 = 136
.line	0	loadk        r29   k54 ; k54 = 47
.line	0	loadk        r30   k55 ; k55 = 16
.line	0	loadk        r31   k14 ; k14 = 86
.line	0	loadk        r32  k133 ; k133 = 212
.line	0	loadk        r33  k134 ; k134 = 238
.line	0	loadk        r34    k2 ; k2 = 150
.line	0	loadk        r35   k79 ; k79 = 100
.line	0	loadk        r36  k135 ; k135 = 4
.line	0	loadk        r37  k120 ; k120 = 190
.line	0	loadk        r38   k62 ; k62 = 245
.line	0	loadk        r39   k25 ; k25 = 220
.line	0	loadk        r40  k136 ; k136 = 165
.line	0	loadk        r41  k137 ; k137 = 124
.line	0	loadk        r42  k138 ; k138 = 65
.line	0	loadk        r43   k39 ; k39 = 234
.line	0	loadk        r44    k2 ; k2 = 150
.line	0	loadk        r45  k139 ; k139 = 53
.line	0	loadk        r46  k140 ; k140 = 60
.line	0	loadk        r47  k141 ; k141 = 31
.line	0	loadk        r48  k121 ; k121 = 210
.line	0	loadk        r49  k142 ; k142 = 237
.line	0	loadk        r50   k43 ; k43 = 144
.line	0	loadk        r51   k40 ; k40 = 98
.line	0	loadk        r52   k49 ; k49 = 9
.line	0	loadk        r53  k143 ; k143 = 163
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15  k144 ; k144 = 230
.line	0	loadk        r16  k145 ; k145 = 23
.line	0	loadk        r17  k146 ; k146 = 178
.line	0	loadk        r18  k147 ; k147 = 201
.line	0	loadk        r19  k148 ; k148 = 117
.line	0	loadk        r20   k22 ; k22 = 68
.line	0	loadk        r21  k149 ; k149 = 103
.line	0	loadk        r22   k68 ; k68 = 147
.line	0	call         r14     9     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	call         r10     2     2
.line	0	loadk        r11   k87 ; k87 = 0
.line	0	gettabup     r12    u0   k16 ; k16 = "require"
.line	0	move         r13    r1
.line	0	loadk        r14   k17 ; k17 = 224
.line	0	loadk        r15   k18 ; k18 = 36
.line	0	loadk        r16   k19 ; k19 = 186
.line	0	loadk        r17   k20 ; k20 = 218
.line	0	loadk        r18   k21 ; k21 = 122
.line	0	loadk        r19   k22 ; k22 = 68
.line	0	loadk        r20   k23 ; k23 = 40
.line	0	loadk        r21    k5 ; k5 = 146
.line	0	loadk        r22   k24 ; k24 = 235
.line	0	loadk        r23   k25 ; k25 = 220
.line	0	loadk        r24   k26 ; k26 = 250
.line	0	loadk        r25   k27 ; k27 = 46
.line	0	loadk        r26   k28 ; k28 = 75
.line	0	loadk        r27   k29 ; k29 = 240
.line	0	loadk        r28   k30 ; k30 = 136
.line	0	loadk        r29   k31 ; k31 = 104
.line	0	loadk        r30   k18 ; k18 = 36
.line	0	loadk        r31   k32 ; k32 = 25
.line	0	loadk        r32   k33 ; k33 = 209
.line	0	loadk        r33   k24 ; k24 = 235
.line	0	loadk        r34    k2 ; k2 = 150
.line	0	loadk        r35   k34 ; k34 = 111
.line	0	loadk        r36   k35 ; k35 = 20
.line	0	loadk        r37   k36 ; k36 = 180
.line	0	loadk        r38   k37 ; k37 = 185
.line	0	loadk        r39   k38 ; k38 = 206
.line	0	loadk        r40   k39 ; k39 = 234
.line	0	loadk        r41   k40 ; k40 = 98
.line	0	loadk        r42   k41 ; k41 = 74
.line	0	loadk        r43   k42 ; k42 = 255
.line	0	loadk        r44   k43 ; k43 = 144
.line	0	loadk        r45   k44 ; k44 = 52
.line	0	loadk        r46   k45 ; k45 = 6
.line	0	loadk        r47   k46 ; k46 = 55
.line	0	loadk        r48   k47 ; k47 = 222
.line	0	loadk        r49   k48 ; k48 = 254
.line	0	loadk        r50    k4 ; k4 = 151
.line	0	loadk        r51   k40 ; k40 = 98
.line	0	loadk        r52   k49 ; k49 = 9
.line	0	call         r13    40     2
.line	0	call         r12     2     2
.line	0	gettable     r13   r12  k131 ; k131 = "ENUM_WardrobeSubTabS" (truncated)
.line	0	gettable     r14   r12  k150 ; k150 = "ENUM_WardrobePageTyp" (truncated)
.line	0	gettabup     r15    u0   k16 ; k16 = "require"
.line	0	move         r16    r1
.line	0	loadk        r17   k17 ; k17 = 224
.line	0	loadk        r18   k18 ; k18 = 36
.line	0	loadk        r19   k19 ; k19 = 186
.line	0	loadk        r20   k20 ; k20 = 218
.line	0	loadk        r21   k21 ; k21 = 122
.line	0	loadk        r22   k22 ; k22 = 68
.line	0	loadk        r23   k23 ; k23 = 40
.line	0	loadk        r24    k5 ; k5 = 146
.line	0	loadk        r25   k24 ; k24 = 235
.line	0	loadk        r26   k25 ; k25 = 220
.line	0	loadk        r27   k26 ; k26 = 250
.line	0	loadk        r28   k27 ; k27 = 46
.line	0	loadk        r29   k52 ; k52 = 82
.line	0	loadk        r30   k53 ; k53 = 242
.line	0	loadk        r31   k30 ; k30 = 136
.line	0	loadk        r32   k54 ; k54 = 47
.line	0	loadk        r33   k55 ; k55 = 16
.line	0	loadk        r34   k14 ; k14 = 86
.line	0	loadk        r35  k133 ; k133 = 212
.line	0	loadk        r36  k134 ; k134 = 238
.line	0	loadk        r37    k2 ; k2 = 150
.line	0	loadk        r38   k79 ; k79 = 100
.line	0	loadk        r39  k135 ; k135 = 4
.line	0	loadk        r40  k120 ; k120 = 190
.line	0	loadk        r41   k62 ; k62 = 245
.line	0	loadk        r42   k25 ; k25 = 220
.line	0	loadk        r43  k136 ; k136 = 165
.line	0	loadk        r44  k149 ; k149 = 103
.line	0	loadk        r45   k69 ; k69 = 79
.line	0	loadk        r46   k42 ; k42 = 255
.line	0	loadk        r47  k151 ; k151 = 155
.line	0	loadk        r48   k18 ; k18 = 36
.line	0	loadk        r49  k152 ; k152 = 12
.line	0	loadk        r50  k153 ; k153 = 10
.line	0	loadk        r51   k78 ; k78 = 214
.line	0	loadk        r52  k154 ; k154 = 192
.line	0	loadk        r53   k43 ; k43 = 144
.line	0	loadk        r54  k155 ; k155 = 113
.line	0	loadk        r55  k126 ; k126 = 18
.line	0	loadk        r56   k71 ; k71 = 160
.line	0	call         r16    41     2
.line	0	call         r15     2     2
.line	0	closure      r16    f1
.line	0	settable      r5  k156   r16 ; k156 = "OnModePostSwitch"
.line	0	closure      r16    f2
.line	0	settable      r5  k157   r16 ; k157 = "on_sync_depot_info"
.line	0	closure      r16    f3
.line	0	settable      r5  k158   r16 ; k158 = "on_sync_depot_item_i" (truncated)
.line	0	closure      r16    f4
.line	0	settable      r5  k159   r16 ; k159 = "clearSyncDepotItemIn" (truncated)
.line	0	closure      r16    f5
.line	0	settable      r5  k160   r16 ; k160 = "GetCurrSceneType"
.line	0	closure      r16    f6
.line	0	settable      r5  k161   r16 ; k161 = "SetCurrSceneType"
.line	0	closure      r16    f7
.line	0	settable      r5  k162   r16 ; k162 = "Enter"
.line	0	closure      r16    f8
.line	0	settable      r5  k163   r16 ; k163 = "EnterBeforShowUI"
.line	0	closure      r16    f9
.line	0	settable      r5  k164   r16 ; k164 = "_ExtractJumpArgs"
.line	0	closure      r16   f10
.line	0	settable      r5  k165   r16 ; k165 = "EnterWardrobe"
.line	0	closure      r16   f11
.line	0	settable      r5  k166   r16 ; k166 = "JumpTo"
.line	0	closure      r16   f12
.line	0	settable      r5  k167   r16 ; k167 = "IsWearValid"
.line	0	closure      r16   f13
.line	0	settable      r5  k168   r16 ; k168 = "UpdateInvalidWearInf" (truncated)
.line	0	closure      r16   f14
.line	0	settable      r5  k169   r16 ; k169 = "GetItemPart"
.line	0	closure      r16   f15
.line	0	closure      r17   f16
.line	0	settable      r5  k170   r17 ; k170 = "wardrobe_puton_data_" (truncated)
.line	0	closure      r17   f17
.line	0	settable      r5  k171   r17 ; k171 = "wardrobe_puton_req"
.line	0	closure      r17   f18
.line	0	closure      r18   f19
.line	0	closure      r19   f20
.line	0	settable      r5  k172   r19 ; k172 = "on_puton_rsp"
.line	0	closure      r19   f21
.line	0	settable      r5  k173   r19 ; k173 = "wardrobe_put_down_da" (truncated)
.line	0	closure      r19   f22
.line	0	settable      r5  k174   r19 ; k174 = "wardrobe_put_down_re" (truncated)
.line	0	closure      r19   f23
.line	0	settable      r5  k175   r19 ; k175 = "on_putdown_rsp"
.line	0	closure      r19   f24
.line	0	settable      r5  k176   r19 ; k176 = "wardrobe_change_item" (truncated)
.line	0	closure      r19   f25
.line	0	settable      r5  k177   r19 ; k177 = "wardrobe_change_item" (truncated)
.line	0	closure      r19   f26
.line	0	settable      r5  k178   r19 ; k178 = "FindMotion"
.line	0	closure      r19   f27
.line	0	settable      r5  k179   r19 ; k179 = "EquipMotion"
.line	0	closure      r19   f28
.line	0	settable      r5  k180   r19 ; k180 = "equip_motion_list_re" (truncated)
.line	0	closure      r19   f29
.line	0	settable      r5  k181   r19 ; k181 = "unequip_motion_req"
.line	0	closure      r19   f30
.line	0	settable      r5  k182   r19 ; k182 = "PlayMotion"
.line	0	closure      r19   f31
.line	0	settable      r5  k183   r19 ; k183 = "StopMVPMotionLocalPl" (truncated)
.line	0	closure      r19   f32
.line	0	settable      r5  k184   r19 ; k184 = "IsValidTime"
.line	0	closure      r19   f33
.line	0	settable      r5  k185   r19 ; k185 = "GetRemainTimeStr"
.line	0	closure      r19   f34
.line	0	settable      r5  k186   r19 ; k186 = "GetTimeStr"
.line	0	closure      r19   f35
.line	0	settable      r5  k187   r19 ; k187 = "ShowLobbyHotDot"
.line	0	closure      r19   f36
.line	0	settable      r5  k188   r19 ; k188 = "IsServerJK"
.line	0	closure      r19   f37
.line	0	settable      r5  k189   r19 ; k189 = "IsCharacterUse"
.line	0	closure      r19   f38
.line	0	settable      r5  k190   r19 ; k190 = "IsItemIsolated"
.line	0	closure      r19   f39
.line	0	settable      r5  k191   r19 ; k191 = "IsCanUse"
.line	0	closure      r19   f40
.line	0	settable      r5  k192   r19 ; k192 = "HasSameDiySuit"
.line	0	closure      r19   f41
.line	0	settable      r5  k193   r19 ; k193 = "GetShaoJiItemId"
.line	0	closure      r19   f42
.line	0	settable      r5  k193   r19 ; k193 = "GetShaoJiItemId"
.line	0	closure      r19   f43
.line	0	settable      r5  k194   r19 ; k194 = "GetItemResId"
.line	0	closure      r19   f44
.line	0	settable      r5  k195   r19 ; k195 = "GetWardrobeInsIdByRe" (truncated)
.line	0	closure      r19   f45
.line	0	settable      r5  k196   r19 ; k196 = "IsValidCurrentPageIt" (truncated)
.line	0	closure      r19   f46
.line	0	settable      r5  k197   r19 ; k197 = "IsValidCurrentPageIt" (truncated)
.line	0	closure      r19   f47
.line	0	settable      r5  k198   r19 ; k198 = "SetDisplayItemId"
.line	0	closure      r19   f48
.line	0	settable      r5  k199   r19 ; k199 = "RemoveDisplayItemId"
.line	0	closure      r19   f49
.line	0	settable      r5  k200   r19 ; k200 = "ArrayHallDepotToComm" (truncated)
.line	0	closure      r19   f50
.line	0	settable      r5  k201   r19 ; k201 = "on_use_item_rsp"
.line	0	closure      r19   f51
.line	0	settable      r5  k202   r19 ; k202 = "on_depot_set_skin_in" (truncated)
.line	0	closure      r19   f52
.line	0	settable      r5  k203   r19 ; k203 = "UpdateLastEquipForev" (truncated)
.line	0	closure      r19   f53
.line	0	settable      r5  k204   r19 ; k204 = "UpdateSkinInfo"
.line	0	closure      r19   f54
.line	0	settable      r5  k205   r19 ; k205 = "RecordCurrentFashion"
.line	0	closure      r19   f55
.line	0	settable      r5  k206   r19 ; k206 = "SetWardrobeEditMode"
.line	0	closure      r19   f56
.line	0	settable      r5  k207   r19 ; k207 = "GetWardrobeEditMode"
.line	0	closure      r19   f57
.line	0	settable      r5  k208   r19 ; k208 = "IsInFashionBagEditMo" (truncated)
.line	0	closure      r19   f58
.line	0	settable      r5  k209   r19 ; k209 = "IsInInheritMode"
.line	0	closure      r19   f59
.line	0	settable      r5  k210   r19 ; k210 = "GetShareType"
.line	0	closure      r19   f60
.line	0	settable      r5  k211   r19 ; k211 = "SetCurrentPageId"
.line	0	closure      r19   f61
.line	0	settable      r5  k212   r19 ; k212 = "GetCurrentPageId"
.line	0	closure      r19   f62
.line	0	settable      r5  k213   r19 ; k213 = "SetCurrentTabId"
.line	0	closure      r19   f63
.line	0	settable      r5  k214   r19 ; k214 = "GetCurrentTabId"
.line	0	closure      r19   f64
.line	0	settable      r5  k215   r19 ; k215 = "SetCurrentThrowObjec" (truncated)
.line	0	closure      r19   f65
.line	0	settable      r5  k216   r19 ; k216 = "GetCurrentThrowObjec" (truncated)
.line	0	closure      r19   f66
.line	0	settable      r5  k217   r19 ; k217 = "SetCurrentPlaneType"
.line	0	closure      r19   f67
.line	0	settable      r5  k218   r19 ; k218 = "GetCurrentPlaneObjec" (truncated)
.line	0	closure      r19   f68
.line	0	settable      r5  k219   r19 ; k219 = "GetCurrentPageAndTab" (truncated)
.line	0	closure      r19   f69
.line	0	settable      r5  k220   r19 ; k220 = "CheckCanUseRedEmotio" (truncated)
.line	0	closure      r19   f70
.line	0	settable      r5  k221   r19 ; k221 = "SetClickItemInsId"
.line	0	closure      r19   f71
.line	0	settable      r5  k222   r19 ; k222 = "GetClickItemInsId"
.line	0	closure      r19   f72
.line	0	closure      r20   f73
.line	0	settable      r5  k223   r20 ; k223 = "GetSortCmpFunction"
.line	0	closure      r20   f74
.line	0	settable      r5  k224   r20 ; k224 = "GetSortFuncForLazyIn" (truncated)
.line	0	closure      r20   f75
.line	0	settable      r5  k225   r20 ; k225 = "SortItemTable"
.line	0	closure      r20   f76
.line	0	settable      r5  k226   r20 ; k226 = "CanLazySort"
.line	0	closure      r20   f77
.line	0	settable      r5  k227   r20 ; k227 = "LazySortType"
.line	0	closure      r20   f78
.line	0	settable      r5  k228   r20 ; k228 = "CalcSortPriorityOfSu" (truncated)
.line	0	closure      r20   f79
.line	0	settable      r5  k229   r20 ; k229 = "wardrobe_batch_put_d" (truncated)
.line	0	closure      r20   f80
.line	0	settable      r5  k230   r20 ; k230 = "isVehicle"
.line	0	closure      r20   f81
.line	0	settable      r5  k231   r20 ; k231 = "wardrobe_batch_put_o" (truncated)
.line	0	closure      r20   f82
.line	0	settable      r5  k232   r20 ; k232 = "ChangeToLobbyScene"
.line	0	closure      r20   f83
.line	0	settable      r5  k233   r20 ; k233 = "EnterGrenadeScene"
.line	0	closure      r20   f84
.line	0	settable      r5  k234   r20 ; k234 = "EnterHolographyScene"
.line	0	closure      r20   f85
.line	0	settable      r5  k235   r20 ; k235 = "EnterPlatingScene"
.line	0	closure      r20   f86
.line	0	settable      r5  k236   r20 ; k236 = "EnterGarageScene"
.line	0	closure      r20   f87
.line	0	settable      r5  k237   r20 ; k237 = "EnterVehicleSceneByI" (truncated)
.line	0	closure      r20   f88
.line	0	settable      r5  k238   r20 ; k238 = "EnterParachuteScene"
.line	0	closure      r20   f89
.line	0	settable      r5  k239   r20 ; k239 = "EnterWardrobeScene"
.line	0	closure      r20   f90
.line	0	settable      r5  k240   r20 ; k240 = "EnterAvatarPageAndOp" (truncated)
.line	0	closure      r20   f91
.line	0	settable      r5  k241   r20 ; k241 = "EnterSubscribeEditMo" (truncated)
.line	0	closure      r20   f92
.line	0	settable      r5  k242   r20 ; k242 = "ExitWardrobeScene"
.line	0	closure      r20   f93
.line	0	settable      r5  k243   r20 ; k243 = "ShowGrenadeModel"
.line	0	closure      r20   f94
.line	0	settable      r5  k244   r20 ; k244 = "PlayMVPTabDisplay"
.line	0	closure      r20   f95
.line	0	settable      r5  k245   r20 ; k245 = "ShowVehicleModel"
.line	0	closure      r20   f96
.line	0	settable      r5  k246   r20 ; k246 = "ShowBagPendantModel"
.line	0	closure      r20   f97
.line	0	settable      r5  k247   r20 ; k247 = "ShowParachuteModel"
.line	0	closure      r20   f98
.line	0	settable      r5  k248   r20 ; k248 = "ShowMinitvModel"
.line	0	closure      r20   f99
.line	0	settable      r5  k249   r20 ; k249 = "ShowHolographyModel"
.line	0	closure      r20  f100
.line	0	settable      r5  k250   r20 ; k250 = "ExtractHigh32Bits"
.line	0	closure      r20  f101
.line	0	settable      r5  k251   r20 ; k251 = "ExtractLow19Bits"
.line	0	closure      r20  f102
.line	0	settable      r5  k252   r20 ; k252 = "GetSortPreference"
.line	0	closure      r20  f103
.line	0	settable      r5  k253   r20 ; k253 = "SetSortPreference"
.line	0	closure      r20  f104
.line	0	settable      r5  k254   r20 ; k254 = "GetMatchTabSortPrefe" (truncated)
.line	0	closure      r20  f105
.line	0	settable      r5  k255   r20 ; k255 = "SetMatchSortPreferen" (truncated)
.line	0	loadk        r20  k256 ; k256 = "IsWardrobeShow"
.line	0	closure      r21  f106
.line	0	settable      r5   r20   r21
.line	0	loadk        r20  k257 ; k257 = "SwitchCameraInWardro" (truncated)
.line	0	closure      r21  f107
.line	0	settable      r5   r20   r21
.line	0	loadk        r20  k258 ; k258 = "IsCharacterAction"
.line	0	closure      r21  f108
.line	0	settable      r5   r20   r21
.line	0	closure      r20  f109
.line	0	loadk        r21  k259 ; k259 = "ShowAircraftNotice"
.line	0	closure      r22  f110
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k260 ; k260 = "IsFirstPutOnAircraft"
.line	0	closure      r22  f111
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k261 ; k261 = "OnPutOffAircraft"
.line	0	closure      r22  f112
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k262 ; k262 = "EquipSlotVehicle"
.line	0	closure      r22  f113
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k263 ; k263 = "SetFristEnter"
.line	0	closure      r22  f114
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k264 ; k264 = "SetTriggerPutOn"
.line	0	closure      r22  f115
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k265 ; k265 = "SetTriggerSuitDye"
.line	0	closure      r22  f116
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k266 ; k266 = "GetSearchString"
.line	0	closure      r22  f117
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k267 ; k267 = "SetSearchString"
.line	0	closure      r22  f118
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k268 ; k268 = "PutItemToShareList"
.line	0	closure      r22  f119
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k269 ; k269 = "RemoveItemFromShareL" (truncated)
.line	0	closure      r22  f120
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k270 ; k270 = "FindItemInShareList"
.line	0	closure      r22  f121
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k271 ; k271 = "SetSubscribeShareLis" (truncated)
.line	0	closure      r22  f122
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k272 ; k272 = "GetShareBagItemList"
.line	0	closure      r22  f123
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k273 ; k273 = "SyncSubscribeShareIt" (truncated)
.line	0	closure      r22  f124
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k274 ; k274 = "SetSharedBackpackPar" (truncated)
.line	0	closure      r22  f125
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k275 ; k275 = "GetSharedBackpackQua" (truncated)
.line	0	closure      r22  f126
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k276 ; k276 = "GetSharedBackpackBla" (truncated)
.line	0	closure      r22  f127
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k277 ; k277 = "TryLoadSaveOperation"
.line	0	closure      r22  f128
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k278 ; k278 = "CompatibilityCornerT" (truncated)
.line	0	closure      r22  f129
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k279 ; k279 = "WardrobeSelectWithSa" (truncated)
.line	0	closure      r22  f130
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k280 ; k280 = "ReportTLog"
.line	0	closure      r22  f131
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k281 ; k281 = "OnGameStateChange"
.line	0	closure      r22  f132
.line	0	settable      r5   r21   r22
.line	0	loadk        r21  k282 ; k282 = "ReportTLogEnum"
.line	0	newtable     r22     0     4
.line	0	loadk        r23  k283 ; k283 = "Wardrobe"
.line	0	loadk        r24  k284 ; k284 = 1
.line	0	settable     r22   r23   r24
.line	0	loadk        r23  k285 ; k285 = "WardrobeSuit"
.line	0	loadk        r24  k286 ; k286 = 2
.line	0	settable     r22   r23   r24
.line	0	loadk        r23  k287 ; k287 = "FashionBag"
.line	0	loadk        r24  k288 ; k288 = 3
.line	0	settable     r22   r23   r24
.line	0	loadk        r23  k289 ; k289 = "SharePackage"
.line	0	loadk        r24  k290 ; k290 = 4
.line	0	settable     r22   r23   r24
.line	0	settable      r5   r21   r22
.line	0	return        r5     2
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	72
.lastlinedefined	76
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	216
.constant	k5	60
.constant	k6	186
.constant	k7	209
.constant	k8	115
.constant	k9	88
.constant	k10	103
.constant	k11	142
.constant	k12	239
.constant	k13	220
.constant	k14	198
.constant	k15	87
.constant	k16	95
.constant	k17	139
.constant	k18	52
.constant	k19	28
.constant	k20	26
.constant	k21	195
.constant	k22	31
.constant	k23	178
.constant	k24	185
.constant	k25	246
.constant	k26	229
.constant	k27	93
.constant	k28	65
.constant	k29	233
.constant	k30	154
.constant	k31	6
.constant	k32	12
.constant	k33	27
.constant	k34	199
.constant	k35	204
.constant	k36	131
.constant	k37	121
.constant	k38	18
.constant	k39	162
.constant	k40	235
.constant	k41	102
.constant	k42	243
.constant	k43	113
.constant	k44	72
.constant	k45	114
.constant	k46	200
.constant	k47	101
.constant	k48	30
.constant	k49	160
.constant	k50	207
.constant	k51	"tostring"
.constant	k52	"require"
.constant	k53	224
.constant	k54	36
.constant	k55	218
.constant	k56	122
.constant	k57	68
.constant	k58	40
.constant	k59	146
.constant	k60	250
.constant	k61	46
.constant	k62	82
.constant	k63	242
.constant	k64	136
.constant	k65	47
.constant	k66	16
.constant	k67	86
.constant	k68	212
.constant	k69	238
.constant	k70	150
.constant	k71	100
.constant	k72	4
.constant	k73	190
.constant	k74	245
.constant	k75	165
.constant	k76	79
.constant	k77	255
.constant	k78	155
.constant	k79	10
.constant	k80	214
.constant	k81	192
.constant	k82	144
.constant	k83	61
.constant	k84	167
.constant	k85	120
.constant	k86	"OnModePostSwitch"

.line	72	gettabup      r2    u0    k0 ; k0 = "log"
.line	72	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	72	test          r3     0
.line	72	jmp            0   l73
.line	72	gettabup      r3    u0    k2 ; k2 = "table"
.line	72	gettable      r3    r3    k3 ; k3 = "concat"
.line	72	newtable      r4     1     0
.line	72	getupval      r5    u1
.line	72	loadk         r6    k4 ; k4 = 216
.line	72	loadk         r7    k5 ; k5 = 60
.line	72	loadk         r8    k6 ; k6 = 186
.line	72	loadk         r9    k7 ; k7 = 209
.line	72	loadk        r10    k8 ; k8 = 115
.line	72	loadk        r11    k9 ; k9 = 88
.line	72	loadk        r12   k10 ; k10 = 103
.line	72	loadk        r13   k11 ; k11 = 142
.line	72	loadk        r14   k12 ; k12 = 239
.line	72	loadk        r15   k13 ; k13 = 220
.line	72	loadk        r16   k14 ; k14 = 198
.line	72	loadk        r17   k15 ; k15 = 87
.line	72	loadk        r18   k16 ; k16 = 95
.line	72	loadk        r19   k12 ; k12 = 239
.line	72	loadk        r20   k17 ; k17 = 139
.line	72	loadk        r21   k18 ; k18 = 52
.line	72	loadk        r22   k19 ; k19 = 28
.line	72	loadk        r23   k20 ; k20 = 26
.line	72	loadk        r24   k14 ; k14 = 198
.line	72	loadk        r25   k21 ; k21 = 195
.line	72	loadk        r26   k17 ; k17 = 139
.line	72	loadk        r27   k10 ; k10 = 103
.line	72	loadk        r28   k22 ; k22 = 31
.line	72	loadk        r29   k23 ; k23 = 178
.line	72	loadk        r30   k24 ; k24 = 185
.line	72	loadk        r31   k25 ; k25 = 246
.line	72	loadk        r32   k26 ; k26 = 229
.line	72	loadk        r33   k27 ; k27 = 93
.line	72	loadk        r34   k28 ; k28 = 65
.line	72	loadk        r35   k29 ; k29 = 233
.line	72	loadk        r36   k30 ; k30 = 154
.line	72	loadk        r37   k31 ; k31 = 6
.line	72	loadk        r38   k32 ; k32 = 12
.line	72	loadk        r39   k33 ; k33 = 27
.line	72	loadk        r40   k34 ; k34 = 199
.line	72	loadk        r41   k35 ; k35 = 204
.line	72	loadk        r42   k36 ; k36 = 131
.line	72	loadk        r43   k37 ; k37 = 121
.line	72	loadk        r44   k38 ; k38 = 18
.line	72	loadk        r45   k39 ; k39 = 162
.line	72	call          r5    41     2
.line	72	getupval      r6    u1
.line	72	loadk         r7   k40 ; k40 = 235
.line	72	loadk         r8   k41 ; k41 = 102
.line	72	loadk         r9   k42 ; k42 = 243
.line	72	loadk        r10    k7 ; k7 = 209
.line	72	loadk        r11   k43 ; k43 = 113
.line	72	loadk        r12   k44 ; k44 = 72
.line	72	loadk        r13   k45 ; k45 = 114
.line	72	loadk        r14   k23 ; k23 = 178
.line	72	loadk        r15   k42 ; k42 = 243
.line	72	loadk        r16   k46 ; k46 = 200
.line	72	loadk        r17   k12 ; k12 = 239
.line	72	loadk        r18   k47 ; k47 = 101
.line	72	loadk        r19   k48 ; k48 = 30
.line	72	loadk        r20   k49 ; k49 = 160
.line	72	loadk        r21   k50 ; k50 = 207
.line	72	call          r6    16     0
.line	72	setlist       r4     0     1
.line	72	call          r3     2     2
.line	72	gettabup      r4    u0   k51 ; k51 = "tostring"
.line	72	move          r5    r1
.line	72	call          r4     2     2
.line	72	concat        r3    r3    r4
.label	l73
.line	72	call          r2     2     1
.line	72	gettabup      r2    u0   k52 ; k52 = "require"
.line	72	gettabup      r3    u0    k2 ; k2 = "table"
.line	72	gettable      r3    r3    k3 ; k3 = "concat"
.line	72	newtable      r4     1     0
.line	72	getupval      r5    u1
.line	72	loadk         r6   k53 ; k53 = 224
.line	72	loadk         r7   k54 ; k54 = 36
.line	72	loadk         r8    k6 ; k6 = 186
.line	72	loadk         r9   k55 ; k55 = 218
.line	72	loadk        r10   k56 ; k56 = 122
.line	72	loadk        r11   k57 ; k57 = 68
.line	72	loadk        r12   k58 ; k58 = 40
.line	72	loadk        r13   k59 ; k59 = 146
.line	72	loadk        r14   k40 ; k40 = 235
.line	72	loadk        r15   k13 ; k13 = 220
.line	72	loadk        r16   k60 ; k60 = 250
.line	72	loadk        r17   k61 ; k61 = 46
.line	72	loadk        r18   k62 ; k62 = 82
.line	72	loadk        r19   k63 ; k63 = 242
.line	72	loadk        r20   k64 ; k64 = 136
.line	72	loadk        r21   k65 ; k65 = 47
.line	72	loadk        r22   k66 ; k66 = 16
.line	72	loadk        r23   k67 ; k67 = 86
.line	72	loadk        r24   k68 ; k68 = 212
.line	72	loadk        r25   k69 ; k69 = 238
.line	72	loadk        r26   k70 ; k70 = 150
.line	72	loadk        r27   k71 ; k71 = 100
.line	72	loadk        r28   k72 ; k72 = 4
.line	72	loadk        r29   k73 ; k73 = 190
.line	72	loadk        r30   k74 ; k74 = 245
.line	72	loadk        r31   k13 ; k13 = 220
.line	72	loadk        r32   k75 ; k75 = 165
.line	72	loadk        r33   k10 ; k10 = 103
.line	72	loadk        r34   k76 ; k76 = 79
.line	72	loadk        r35   k77 ; k77 = 255
.line	72	loadk        r36   k78 ; k78 = 155
.line	72	loadk        r37   k54 ; k54 = 36
.line	72	loadk        r38   k32 ; k32 = 12
.line	72	loadk        r39   k79 ; k79 = 10
.line	72	loadk        r40   k80 ; k80 = 214
.line	72	loadk        r41   k81 ; k81 = 192
.line	72	loadk        r42   k82 ; k82 = 144
.line	72	loadk        r43   k43 ; k43 = 113
.line	72	loadk        r44   k38 ; k38 = 18
.line	72	loadk        r45   k49 ; k49 = 160
.line	72	call          r5    41     2
.line	72	getupval      r6    u1
.line	72	loadk         r7   k13 ; k13 = 220
.line	72	loadk         r8   k83 ; k83 = 61
.line	72	loadk         r9   k84 ; k84 = 167
.line	72	loadk        r10   k80 ; k80 = 214
.line	72	loadk        r11   k85 ; k85 = 120
.line	72	call          r6     6     0
.line	72	setlist       r4     0     1
.line	72	call          r3     2     2
.line	72	call          r2     2     2
.line	72	gettable      r3    r2   k86 ; k86 = "OnModePostSwitch"
.line	72	move          r4    r0
.line	72	move          r5    r1
.line	72	call          r3     3     1
.line	72	return        r0     1
.line	72	move          r0    r0
.line	72	move          r0    r0
.line	72	move          r0    r0
.line	72	return        r0     1

.function	main/f2

.source	null
.linedefined	78
.lastlinedefined	98
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true
.upvalue	"U2"	1	true

.constant	k0	"LobbySystem"
.constant	k1	"roleData"
.constant	k2	"depot"
.constant	k3	"InitHallDepotData"
.constant	k4	"items"
.constant	k5	"WaitDepotInfo"
.constant	k6	"CreatLobbyAvatar"
.constant	k7	"require"
.constant	k8	224
.constant	k9	36
.constant	k10	186
.constant	k11	218
.constant	k12	122
.constant	k13	68
.constant	k14	40
.constant	k15	141
.constant	k16	232
.constant	k17	206
.constant	k18	242
.constant	k19	99
.constant	k20	16
.constant	k21	241
.constant	k22	128
.constant	k23	17
.constant	k24	1
.constant	k25	231
.constant	k26	133
.constant	k27	108
.constant	k28	26
.constant	k29	142
.constant	k30	227
.constant	k31	209
.constant	k32	238
.constant	k33	125
.constant	k34	75
.constant	k35	210
.constant	k36	138
.constant	k37	34
.constant	k38	10
.constant	k39	4
.constant	k40	192
.constant	k41	"OnRecvRoleDepotData"
.constant	k42	"module"
.constant	k43	"funcName"
.constant	k44	215
.constant	k45	188
.constant	k46	216
.constant	k47	70
.constant	k48	85
.constant	k49	118
.constant	k50	245
.constant	k51	221
.constant	k52	222
.constant	k53	120
.constant	k54	119
.constant	k55	249
.constant	k56	131
.constant	k57	35
.constant	k58	"param"
.constant	k59	"debugInfo"
.constant	k60	212
.constant	k61	41
.constant	k62	161
.constant	k63	219
.constant	k64	102
.constant	k65	95
.constant	k66	100
.constant	k67	132
.constant	k68	195
.constant	k69	200
.constant	k70	239
.constant	k71	97
.constant	k72	201
.constant	k73	163
.constant	k74	20
.constant	k75	42
.constant	k76	198
.constant	k77	255
.constant	k78	139
.constant	k79	114
.constant	k80	2
.constant	k81	148
.constant	k82	240
.constant	k83	124
.constant	k84	"protect"
.constant	k85	true
.constant	k86	"ModuleManager"
.constant	k87	"GetModule"
.constant	k88	"LobbyModuleConfig"
.constant	k89	"queue_task_module"
.constant	k90	"Enqueue"
.constant	k91	"TaskEnum"
.constant	k92	"Lobby"

.line	78	gettabup      r1    u0    k0 ; k0 = "LobbySystem"
.line	78	gettable      r1    r1    k1 ; k1 = "roleData"
.line	78	gettable      r1    r1    k2 ; k2 = "depot"
.line	78	test          r1     0
.line	78	jmp            0    l7
.line	78	return        r0     1
.label	l7
.line	78	gettabup      r1    u0    k0 ; k0 = "LobbySystem"
.line	78	gettable      r1    r1    k1 ; k1 = "roleData"
.line	78	settable      r1    k2    r0 ; k2 = "depot"
.line	78	getupval      r1    u1
.line	78	self          r1    r1    k3 ; k3 = "InitHallDepotData"
.line	78	gettable      r3    r0    k4 ; k4 = "items"
.line	78	call          r1     3     1
.line	78	gettabup      r1    u0    k0 ; k0 = "LobbySystem"
.line	78	gettable      r1    r1    k5 ; k5 = "WaitDepotInfo"
.line	78	test          r1     0
.line	78	jmp            0   l21
.line	78	gettabup      r1    u0    k0 ; k0 = "LobbySystem"
.line	78	gettable      r1    r1    k6 ; k6 = "CreatLobbyAvatar"
.line	78	call          r1     1     1
.label	l21
.line	78	gettabup      r1    u0    k7 ; k7 = "require"
.line	78	getupval      r2    u2
.line	78	loadk         r3    k8 ; k8 = 224
.line	78	loadk         r4    k9 ; k9 = 36
.line	78	loadk         r5   k10 ; k10 = 186
.line	78	loadk         r6   k11 ; k11 = 218
.line	78	loadk         r7   k12 ; k12 = 122
.line	78	loadk         r8   k13 ; k13 = 68
.line	78	loadk         r9   k14 ; k14 = 40
.line	78	loadk        r10   k15 ; k15 = 141
.line	78	loadk        r11   k16 ; k16 = 232
.line	78	loadk        r12   k17 ; k17 = 206
.line	78	loadk        r13   k18 ; k18 = 242
.line	78	loadk        r14   k19 ; k19 = 99
.line	78	loadk        r15   k20 ; k20 = 16
.line	78	loadk        r16   k21 ; k21 = 241
.line	78	loadk        r17   k22 ; k22 = 128
.line	78	loadk        r18    k9 ; k9 = 36
.line	78	loadk        r19   k23 ; k23 = 17
.line	78	loadk        r20   k24 ; k24 = 1
.line	78	loadk        r21   k15 ; k15 = 141
.line	78	loadk        r22   k25 ; k25 = 231
.line	78	loadk        r23   k26 ; k26 = 133
.line	78	loadk        r24   k27 ; k27 = 108
.line	78	loadk        r25   k28 ; k28 = 26
.line	78	loadk        r26   k29 ; k29 = 142
.line	78	loadk        r27   k30 ; k30 = 227
.line	78	loadk        r28   k31 ; k31 = 209
.line	78	loadk        r29   k32 ; k32 = 238
.line	78	loadk        r30   k33 ; k33 = 125
.line	78	loadk        r31   k34 ; k34 = 75
.line	78	loadk        r32   k35 ; k35 = 210
.line	78	loadk        r33   k36 ; k36 = 138
.line	78	loadk        r34   k37 ; k37 = 34
.line	78	loadk        r35   k38 ; k38 = 10
.line	78	loadk        r36   k39 ; k39 = 4
.line	78	loadk        r37   k40 ; k40 = 192
.line	78	call          r2    36     2
.line	78	call          r1     2     2
.line	78	gettable      r2    r1   k41 ; k41 = "OnRecvRoleDepotData"
.line	78	move          r3    r0
.line	78	call          r2     2     1
.line	78	newtable      r2     0     5
.line	78	getupval      r3    u1
.line	78	settable      r2   k42    r3 ; k42 = "module"
.line	78	getupval      r3    u2
.line	78	loadk         r4   k44 ; k44 = 215
.line	78	loadk         r5   k39 ; k39 = 4
.line	78	loadk         r6   k45 ; k45 = 188
.line	78	loadk         r7   k46 ; k46 = 216
.line	78	loadk         r8   k47 ; k47 = 70
.line	78	loadk         r9   k48 ; k48 = 85
.line	78	loadk        r10   k49 ; k49 = 118
.line	78	loadk        r11   k29 ; k29 = 142
.line	78	loadk        r12   k50 ; k50 = 245
.line	78	loadk        r13   k51 ; k51 = 221
.line	78	loadk        r14   k52 ; k52 = 222
.line	78	loadk        r15   k53 ; k53 = 120
.line	78	loadk        r16   k54 ; k54 = 119
.line	78	loadk        r17   k55 ; k55 = 249
.line	78	loadk        r18   k56 ; k56 = 131
.line	78	loadk        r19   k57 ; k57 = 35
.line	78	call          r3    17     2
.line	78	settable      r2   k43    r3 ; k43 = "funcName"
.line	78	getupval      r3    u1
.line	78	settable      r2   k58    r3 ; k58 = "param"
.line	78	getupval      r3    u2
.line	78	loadk         r4   k60 ; k60 = 212
.line	78	loadk         r5   k61 ; k61 = 41
.line	78	loadk         r6   k62 ; k62 = 161
.line	78	loadk         r7   k63 ; k63 = 219
.line	78	loadk         r8   k64 ; k64 = 102
.line	78	loadk         r9   k65 ; k65 = 95
.line	78	loadk        r10   k66 ; k66 = 100
.line	78	loadk        r11   k67 ; k67 = 132
.line	78	loadk        r12   k68 ; k68 = 195
.line	78	loadk        r13   k69 ; k69 = 200
.line	78	loadk        r14   k70 ; k70 = 239
.line	78	loadk        r15   k71 ; k71 = 97
.line	78	loadk        r16   k39 ; k39 = 4
.line	78	loadk        r17   k72 ; k72 = 201
.line	78	loadk        r18   k73 ; k73 = 163
.line	78	loadk        r19   k61 ; k61 = 41
.line	78	loadk        r20   k74 ; k74 = 20
.line	78	loadk        r21   k75 ; k75 = 42
.line	78	loadk        r22   k76 ; k76 = 198
.line	78	loadk        r23   k77 ; k77 = 255
.line	78	loadk        r24   k78 ; k78 = 139
.line	78	loadk        r25   k79 ; k79 = 114
.line	78	loadk        r26   k80 ; k80 = 2
.line	78	loadk        r27   k81 ; k81 = 148
.line	78	loadk        r28   k70 ; k70 = 239
.line	78	loadk        r29   k82 ; k82 = 240
.line	78	loadk        r30   k70 ; k70 = 239
.line	78	loadk        r31   k83 ; k83 = 124
.line	78	loadk        r32   k34 ; k34 = 75
.line	78	call          r3    30     2
.line	78	settable      r2   k59    r3 ; k59 = "debugInfo"
.line	78	settable      r2   k84   k85 ; k85 = true
.line	78	gettabup      r3    u0   k86 ; k86 = "ModuleManager"
.line	78	gettable      r3    r3   k87 ; k87 = "GetModule"
.line	78	gettabup      r4    u0   k86 ; k86 = "ModuleManager"
.line	78	gettable      r4    r4   k88 ; k88 = "LobbyModuleConfig"
.line	78	gettable      r4    r4   k89 ; k89 = "queue_task_module"
.line	78	call          r3     2     2
.line	78	self          r4    r3   k90 ; k90 = "Enqueue"
.line	78	gettable      r6    r3   k91 ; k91 = "TaskEnum"
.line	78	gettable      r6    r6   k92 ; k92 = "Lobby"
.line	78	move          r7    r2
.line	78	call          r4     4     1
.line	78	return        r0     1
.line	78	move          r0    r0
.line	78	gettabup      r3    u0   k48 ; k48 = 85
.line	78	move          r0    r0
.line	78	move          r0    r0
.line	78	return        r0     1

.function	main/f3

.source	null
.linedefined	100
.lastlinedefined	131
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	6	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	212
.constant	k7	41
.constant	k8	161
.constant	k9	219
.constant	k10	102
.constant	k11	95
.constant	k12	100
.constant	k13	132
.constant	k14	203
.constant	k15	198
.constant	k16	252
.constant	k17	105
.constant	k18	93
.constant	k19	179
.constant	k20	128
.constant	k21	40
.constant	k22	44
.constant	k23	11
.constant	k24	218
.constant	k25	225
.constant	k26	135
.constant	k27	18
.constant	k28	180
.constant	k29	231
.constant	k30	214
.constant	k31	255
.constant	k32	79
.constant	k33	71
.constant	k34	249
.constant	k35	154
.constant	k36	59
.constant	k37	60
.constant	k38	1
.constant	k39	221
.constant	k40	155
.constant	k41	48
.constant	k42	70
.constant	k43	162
.constant	k44	246
.constant	k45	58
.constant	k46	140
.constant	k47	96
.constant	k48	85
.constant	k49	107
.constant	k50	190
.constant	k51	228
.constant	k52	199
.constant	k53	239
.constant	k54	32
.constant	k55	3
.constant	k56	189
.constant	k57	202
.constant	k58	53
.constant	k59	88
.constant	k60	215
.constant	k61	224
.constant	k62	144
.constant	k63	97
.constant	k64	26
.constant	k65	241
.constant	k66	170
.constant	k67	153
.constant	k68	174
.constant	k69	99
.constant	k70	14
.constant	k71	"tostring"
.constant	k72	"items"
.constant	k73	"itemcount"
.constant	k74	"on_sync_depot_info"
.constant	k75	74
.constant	k76	226
.constant	k77	183
.constant	k78	159
.constant	k79	81
.constant	k80	101
.constant	k81	138
.constant	k82	230
.constant	k83	206
.constant	k84	254
.constant	k85	"depotItemPackageArray"
.constant	k86	"totalCount"
.constant	k87	-1
.constant	k88	"insert"
.constant	k89	0
.constant	k90	"clearSyncDepotItemInfo"
.constant	k91	"depotPackageTimeOut"
.constant	k92	"require"
.constant	k93	39
.constant	k94	210
.constant	k95	123
.constant	k96	94
.constant	k97	149
.constant	k98	238
.constant	k99	196
.constant	k100	244
.constant	k101	45
.constant	k102	22
.constant	k103	10
.constant	k104	"AddTimerOnce"

.line	100	gettabup      r3    u0    k0 ; k0 = "log"
.line	100	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	100	test          r4     0
.line	100	jmp            0   l92
.line	100	gettabup      r4    u0    k2 ; k2 = "string"
.line	100	gettable      r4    r4    k3 ; k3 = "format"
.line	100	gettabup      r5    u0    k4 ; k4 = "table"
.line	100	gettable      r5    r5    k5 ; k5 = "concat"
.line	100	newtable      r6     1     0
.line	100	getupval      r7    u1
.line	100	loadk         r8    k6 ; k6 = 212
.line	100	loadk         r9    k7 ; k7 = 41
.line	100	loadk        r10    k8 ; k8 = 161
.line	100	loadk        r11    k9 ; k9 = 219
.line	100	loadk        r12   k10 ; k10 = 102
.line	100	loadk        r13   k11 ; k11 = 95
.line	100	loadk        r14   k12 ; k12 = 100
.line	100	loadk        r15   k13 ; k13 = 132
.line	100	loadk        r16   k14 ; k14 = 203
.line	100	loadk        r17   k15 ; k15 = 198
.line	100	loadk        r18   k16 ; k16 = 252
.line	100	loadk        r19   k17 ; k17 = 105
.line	100	loadk        r20   k18 ; k18 = 93
.line	100	loadk        r21   k19 ; k19 = 179
.line	100	loadk        r22   k20 ; k20 = 128
.line	100	loadk        r23   k21 ; k21 = 40
.line	100	loadk        r24   k22 ; k22 = 44
.line	100	loadk        r25   k23 ; k23 = 11
.line	100	loadk        r26   k24 ; k24 = 218
.line	100	loadk        r27   k25 ; k25 = 225
.line	100	loadk        r28   k26 ; k26 = 135
.line	100	loadk        r29   k11 ; k11 = 95
.line	100	loadk        r30   k27 ; k27 = 18
.line	100	loadk        r31   k28 ; k28 = 180
.line	100	loadk        r32   k29 ; k29 = 231
.line	100	loadk        r33   k30 ; k30 = 214
.line	100	loadk        r34   k31 ; k31 = 255
.line	100	loadk        r35   k32 ; k32 = 79
.line	100	loadk        r36   k33 ; k33 = 71
.line	100	loadk        r37   k34 ; k34 = 249
.line	100	loadk        r38   k35 ; k35 = 154
.line	100	loadk        r39   k36 ; k36 = 59
.line	100	loadk        r40   k37 ; k37 = 60
.line	100	loadk        r41   k38 ; k38 = 1
.line	100	loadk        r42   k39 ; k39 = 221
.line	100	loadk        r43   k34 ; k34 = 249
.line	100	loadk        r44   k40 ; k40 = 155
.line	100	loadk        r45   k41 ; k41 = 48
.line	100	loadk        r46   k42 ; k42 = 70
.line	100	loadk        r47   k43 ; k43 = 162
.line	100	call          r7    41     2
.line	100	getupval      r8    u1
.line	100	loadk         r9   k44 ; k44 = 246
.line	100	loadk        r10   k45 ; k45 = 58
.line	100	loadk        r11   k46 ; k46 = 140
.line	100	loadk        r12   k30 ; k30 = 214
.line	100	loadk        r13   k47 ; k47 = 96
.line	100	loadk        r14   k48 ; k48 = 85
.line	100	loadk        r15   k49 ; k49 = 107
.line	100	loadk        r16   k50 ; k50 = 190
.line	100	loadk        r17   k51 ; k51 = 228
.line	100	loadk        r18   k52 ; k52 = 199
.line	100	loadk        r19   k53 ; k53 = 239
.line	100	loadk        r20   k54 ; k54 = 32
.line	100	loadk        r21   k55 ; k55 = 3
.line	100	loadk        r22   k56 ; k56 = 189
.line	100	loadk        r23   k57 ; k57 = 202
.line	100	loadk        r24   k58 ; k58 = 53
.line	100	loadk        r25   k11 ; k11 = 95
.line	100	loadk        r26   k59 ; k59 = 88
.line	100	loadk        r27   k60 ; k60 = 215
.line	100	loadk        r28   k61 ; k61 = 224
.line	100	loadk        r29   k62 ; k62 = 144
.line	100	loadk        r30   k63 ; k63 = 97
.line	100	loadk        r31   k64 ; k64 = 26
.line	100	loadk        r32   k65 ; k65 = 241
.line	100	loadk        r33   k66 ; k66 = 170
.line	100	loadk        r34   k67 ; k67 = 153
.line	100	loadk        r35   k68 ; k68 = 174
.line	100	loadk        r36   k69 ; k69 = 99
.line	100	loadk        r37   k70 ; k70 = 14
.line	100	call          r8    30     0
.line	100	setlist       r6     0     1
.line	100	call          r5     2     2
.line	100	gettabup      r6    u0   k71 ; k71 = "tostring"
.line	100	move          r7    r0
.line	100	call          r6     2     2
.line	100	gettabup      r7    u0   k71 ; k71 = "tostring"
.line	100	move          r8    r2
.line	100	call          r7     2     0
.line	100	call          r4     0     2
.label	l92
.line	100	call          r3     2     1
.line	100	eq             0    r0    r2
.line	100	jmp            0  l105
.line	100	newtable      r3     0     2
.line	100	newtable      r4     1     0
.line	100	move          r5    r1
.line	100	setlist       r4     1     1
.line	100	settable      r3   k72    r4 ; k72 = "items"
.line	100	settable      r3   k73    r2 ; k73 = "itemcount"
.line	100	gettabup      r4    u2   k74 ; k74 = "on_sync_depot_info"
.line	100	move          r5    r3
.line	100	call          r4     2     1
.line	100	jmp            0  l237
.label	l105
.line	100	gettabup      r3    u0    k0 ; k0 = "log"
.line	100	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	100	test          r4     0
.line	100	jmp            0  l169
.line	100	gettabup      r4    u0    k4 ; k4 = "table"
.line	100	gettable      r4    r4    k5 ; k5 = "concat"
.line	100	newtable      r5     1     0
.line	100	getupval      r6    u1
.line	100	loadk         r7    k6 ; k6 = 212
.line	100	loadk         r8    k7 ; k7 = 41
.line	100	loadk         r9    k8 ; k8 = 161
.line	100	loadk        r10    k9 ; k9 = 219
.line	100	loadk        r11   k10 ; k10 = 102
.line	100	loadk        r12   k11 ; k11 = 95
.line	100	loadk        r13   k12 ; k12 = 100
.line	100	loadk        r14   k13 ; k13 = 132
.line	100	loadk        r15   k14 ; k14 = 203
.line	100	loadk        r16   k15 ; k15 = 198
.line	100	loadk        r17   k16 ; k16 = 252
.line	100	loadk        r18   k17 ; k17 = 105
.line	100	loadk        r19   k18 ; k18 = 93
.line	100	loadk        r20   k19 ; k19 = 179
.line	100	loadk        r21   k20 ; k20 = 128
.line	100	loadk        r22   k21 ; k21 = 40
.line	100	loadk        r23   k22 ; k22 = 44
.line	100	loadk        r24   k23 ; k23 = 11
.line	100	loadk        r25   k24 ; k24 = 218
.line	100	loadk        r26   k25 ; k25 = 225
.line	100	loadk        r27   k26 ; k26 = 135
.line	100	loadk        r28   k11 ; k11 = 95
.line	100	loadk        r29   k27 ; k27 = 18
.line	100	loadk        r30   k28 ; k28 = 180
.line	100	loadk        r31   k29 ; k29 = 231
.line	100	loadk        r32   k30 ; k30 = 214
.line	100	loadk        r33   k31 ; k31 = 255
.line	100	loadk        r34   k32 ; k32 = 79
.line	100	loadk        r35   k33 ; k33 = 71
.line	100	loadk        r36   k34 ; k34 = 249
.line	100	loadk        r37   k35 ; k35 = 154
.line	100	loadk        r38   k36 ; k36 = 59
.line	100	loadk        r39   k37 ; k37 = 60
.line	100	loadk        r40   k38 ; k38 = 1
.line	100	loadk        r41   k39 ; k39 = 221
.line	100	loadk        r42   k34 ; k34 = 249
.line	100	loadk        r43   k40 ; k40 = 155
.line	100	loadk        r44   k41 ; k41 = 48
.line	100	loadk        r45   k75 ; k75 = 74
.line	100	loadk        r46   k25 ; k25 = 225
.line	100	call          r6    41     2
.line	100	getupval      r7    u1
.line	100	loadk         r8   k76 ; k76 = 226
.line	100	loadk         r9   k22 ; k22 = 44
.line	100	loadk        r10   k77 ; k77 = 183
.line	100	loadk        r11   k78 ; k78 = 159
.line	100	loadk        r12   k12 ; k12 = 100
.line	100	loadk        r13   k79 ; k79 = 81
.line	100	loadk        r14   k80 ; k80 = 101
.line	100	loadk        r15   k81 ; k81 = 138
.line	100	loadk        r16   k82 ; k82 = 230
.line	100	loadk        r17   k83 ; k83 = 206
.line	100	loadk        r18   k84 ; k84 = 254
.line	100	call          r7    12     0
.line	100	setlist       r5     0     1
.line	100	call          r4     2     2
.label	l169
.line	100	call          r3     2     1
.line	100	gettabup      r3    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	test          r3     1
.line	100	jmp            0  l182
.line	100	newtable      r3     0     3
.line	100	settable      r3   k73    r0 ; k73 = "itemcount"
.line	100	newtable      r4     1     0
.line	100	move          r5    r1
.line	100	setlist       r4     1     1
.line	100	settable      r3   k72    r4 ; k72 = "items"
.line	100	settable      r3   k86   k87 ; k87 = -1
.line	100	settabup      u2   k85    r3 ; k85 = "depotItemPackageArra" (truncated)
.line	100	jmp            0  l193
.label	l182
.line	100	gettabup      r3    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	gettabup      r4    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	gettable      r4    r4   k73 ; k73 = "itemcount"
.line	100	add           r4    r4    r0
.line	100	settable      r3   k73    r4 ; k73 = "itemcount"
.line	100	gettabup      r3    u0    k4 ; k4 = "table"
.line	100	gettable      r3    r3   k88 ; k88 = "insert"
.line	100	gettabup      r4    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	gettable      r4    r4   k72 ; k72 = "items"
.line	100	move          r5    r1
.line	100	call          r3     3     1
.label	l193
.line	100	le             0   k89    r2 ; k89 = 0
.line	100	jmp            0  l197
.line	100	gettabup      r3    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	settable      r3   k86    r2 ; k86 = "totalCount"
.label	l197
.line	100	gettabup      r3    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	gettable      r3    r3   k73 ; k73 = "itemcount"
.line	100	eq             0    r3    r2
.line	100	jmp            0  l207
.line	100	gettabup      r3    u2   k74 ; k74 = "on_sync_depot_info"
.line	100	gettabup      r4    u2   k85 ; k85 = "depotItemPackageArra" (truncated)
.line	100	call          r3     2     1
.line	100	gettabup      r3    u2   k90 ; k90 = "clearSyncDepotItemIn" (truncated)
.line	100	call          r3     1     1
.line	100	jmp            0  l237
.label	l207
.line	100	gettabup      r3    u2   k91 ; k91 = "depotPackageTimeOut"
.line	100	test          r3     1
.line	100	jmp            0  l237
.line	100	gettabup      r3    u0   k92 ; k92 = "require"
.line	100	getupval      r4    u1
.line	100	loadk         r5   k61 ; k61 = 224
.line	100	loadk         r6   k93 ; k93 = 39
.line	100	loadk         r7   k50 ; k50 = 190
.line	100	loadk         r8   k94 ; k94 = 210
.line	100	loadk         r9   k95 ; k95 = 123
.line	100	loadk        r10   k96 ; k96 = 94
.line	100	loadk        r11   k21 ; k21 = 40
.line	100	loadk        r12   k97 ; k97 = 149
.line	100	loadk        r13   k98 ; k98 = 238
.line	100	loadk        r14   k99 ; k99 = 196
.line	100	loadk        r15   k84 ; k84 = 254
.line	100	loadk        r16   k11 ; k11 = 95
.line	100	loadk        r17   k75 ; k75 = 74
.line	100	loadk        r18  k100 ; k100 = 244
.line	100	loadk        r19   k46 ; k46 = 140
.line	100	loadk        r20  k101 ; k101 = 45
.line	100	loadk        r21  k102 ; k102 = 22
.line	100	loadk        r22  k103 ; k103 = 10
.line	100	call          r4    19     2
.line	100	call          r3     2     2
.line	100	gettable      r4    r3  k104 ; k104 = "AddTimerOnce"
.line	100	getupval      r5    u3
.line	100	gettabup      r6    u2   k90 ; k90 = "clearSyncDepotItemIn" (truncated)
.line	100	call          r4     3     2
.line	100	settabup      u2   k91    r4 ; k91 = "depotPackageTimeOut"
.label	l237
.line	100	return        r0     1
.line	100	move          r0    r0
.line	100	move          r0    r0
.line	100	move          r0    r0
.line	100	move          r0    r0
.line	100	return        r0     1

.function	main/f4

.source	null
.linedefined	133
.lastlinedefined	142
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	212
.constant	k5	41
.constant	k6	161
.constant	k7	219
.constant	k8	102
.constant	k9	95
.constant	k10	100
.constant	k11	132
.constant	k12	203
.constant	k13	198
.constant	k14	252
.constant	k15	105
.constant	k16	93
.constant	k17	179
.constant	k18	140
.constant	k19	42
.constant	k20	22
.constant	k21	25
.constant	k22	209
.constant	k23	220
.constant	k24	157
.constant	k25	110
.constant	k26	21
.constant	k27	149
.constant	k28	242
.constant	k29	201
.constant	k30	228
.constant	k31	103
.constant	k32	249
.constant	k33	154
.constant	k34	59
.constant	k35	6
.constant	k36	213
.constant	k37	240
.constant	k38	48
.constant	k39	15
.constant	k40	181
.constant	k41	230
.constant	k42	37
.constant	k43	176
.constant	k44	208
.constant	k45	97
.constant	k46	94
.constant	k47	114
.constant	k48	193
.constant	k49	186
.constant	k50	137
.constant	k51	"tostring"
.constant	k52	"depotItemPackageArray"
.constant	k53	"itemcount"
.constant	k54	18
.constant	k55	174
.constant	k56	247
.constant	k57	191
.constant	k58	123
.constant	k59	69
.constant	k60	104
.constant	k61	167
.constant	k62	148
.constant	k63	187
.constant	k64	"totalCount"
.constant	k65	"depotPackageTimeOut"
.constant	k66	"require"
.constant	k67	224
.constant	k68	39
.constant	k69	190
.constant	k70	210
.constant	k71	40
.constant	k72	238
.constant	k73	196
.constant	k74	254
.constant	k75	74
.constant	k76	244
.constant	k77	45
.constant	k78	10
.constant	k79	"RemoveTimer"
.constant	k80	nil

.line	133	gettabup      r0    u0    k0 ; k0 = "log"
.line	133	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	133	test          r1     0
.line	133	jmp            0   l72
.line	133	gettabup      r1    u0    k2 ; k2 = "table"
.line	133	gettable      r1    r1    k3 ; k3 = "concat"
.line	133	newtable      r2     1     0
.line	133	getupval      r3    u1
.line	133	loadk         r4    k4 ; k4 = 212
.line	133	loadk         r5    k5 ; k5 = 41
.line	133	loadk         r6    k6 ; k6 = 161
.line	133	loadk         r7    k7 ; k7 = 219
.line	133	loadk         r8    k8 ; k8 = 102
.line	133	loadk         r9    k9 ; k9 = 95
.line	133	loadk        r10   k10 ; k10 = 100
.line	133	loadk        r11   k11 ; k11 = 132
.line	133	loadk        r12   k12 ; k12 = 203
.line	133	loadk        r13   k13 ; k13 = 198
.line	133	loadk        r14   k14 ; k14 = 252
.line	133	loadk        r15   k15 ; k15 = 105
.line	133	loadk        r16   k16 ; k16 = 93
.line	133	loadk        r17   k17 ; k17 = 179
.line	133	loadk        r18   k18 ; k18 = 140
.line	133	loadk        r19   k19 ; k19 = 42
.line	133	loadk        r20   k20 ; k20 = 22
.line	133	loadk        r21   k21 ; k21 = 25
.line	133	loadk        r22   k22 ; k22 = 209
.line	133	loadk        r23   k23 ; k23 = 220
.line	133	loadk        r24   k24 ; k24 = 157
.line	133	loadk        r25   k25 ; k25 = 110
.line	133	loadk        r26   k26 ; k26 = 21
.line	133	loadk        r27   k27 ; k27 = 149
.line	133	loadk        r28   k28 ; k28 = 242
.line	133	loadk        r29   k29 ; k29 = 201
.line	133	loadk        r30   k30 ; k30 = 228
.line	133	loadk        r31   k10 ; k10 = 100
.line	133	loadk        r32   k31 ; k31 = 103
.line	133	loadk        r33   k32 ; k32 = 249
.line	133	loadk        r34   k33 ; k33 = 154
.line	133	loadk        r35   k34 ; k34 = 59
.line	133	loadk        r36   k19 ; k19 = 42
.line	133	loadk        r37   k35 ; k35 = 6
.line	133	loadk        r38   k36 ; k36 = 213
.line	133	loadk        r39   k37 ; k37 = 240
.line	133	loadk        r40    k4 ; k4 = 212
.line	133	loadk        r41   k38 ; k38 = 48
.line	133	loadk        r42   k39 ; k39 = 15
.line	133	loadk        r43   k40 ; k40 = 181
.line	133	call          r3    41     2
.line	133	getupval      r4    u1
.line	133	loadk         r5   k41 ; k41 = 230
.line	133	loadk         r6   k42 ; k42 = 37
.line	133	loadk         r7   k43 ; k43 = 176
.line	133	loadk         r8   k44 ; k44 = 208
.line	133	loadk         r9   k45 ; k45 = 97
.line	133	loadk        r10   k46 ; k46 = 94
.line	133	loadk        r11   k47 ; k47 = 114
.line	133	loadk        r12   k48 ; k48 = 193
.line	133	loadk        r13   k49 ; k49 = 186
.line	133	loadk        r14   k50 ; k50 = 137
.line	133	call          r4    11     0
.line	133	setlist       r2     0     1
.line	133	call          r1     2     2
.line	133	gettabup      r2    u0   k51 ; k51 = "tostring"
.line	133	gettabup      r3    u2   k52 ; k52 = "depotItemPackageArra" (truncated)
.line	133	test          r3     0
.line	133	jmp            0   l70
.line	133	gettabup      r3    u2   k52 ; k52 = "depotItemPackageArra" (truncated)
.line	133	gettable      r3    r3   k53 ; k53 = "itemcount"
.label	l70
.line	133	call          r2     2     2
.line	133	concat        r1    r1    r2
.label	l72
.line	133	call          r0     2     1
.line	133	gettabup      r0    u0    k0 ; k0 = "log"
.line	133	gettabup      r1    u0    k1 ; k1 = "bWriteLog"
.line	133	test          r1     0
.line	133	jmp            0  l145
.line	133	gettabup      r1    u0    k2 ; k2 = "table"
.line	133	gettable      r1    r1    k3 ; k3 = "concat"
.line	133	newtable      r2     1     0
.line	133	getupval      r3    u1
.line	133	loadk         r4    k4 ; k4 = 212
.line	133	loadk         r5    k5 ; k5 = 41
.line	133	loadk         r6    k6 ; k6 = 161
.line	133	loadk         r7    k7 ; k7 = 219
.line	133	loadk         r8    k8 ; k8 = 102
.line	133	loadk         r9    k9 ; k9 = 95
.line	133	loadk        r10   k10 ; k10 = 100
.line	133	loadk        r11   k11 ; k11 = 132
.line	133	loadk        r12   k12 ; k12 = 203
.line	133	loadk        r13   k13 ; k13 = 198
.line	133	loadk        r14   k14 ; k14 = 252
.line	133	loadk        r15   k15 ; k15 = 105
.line	133	loadk        r16   k16 ; k16 = 93
.line	133	loadk        r17   k17 ; k17 = 179
.line	133	loadk        r18   k18 ; k18 = 140
.line	133	loadk        r19   k19 ; k19 = 42
.line	133	loadk        r20   k20 ; k20 = 22
.line	133	loadk        r21   k21 ; k21 = 25
.line	133	loadk        r22   k22 ; k22 = 209
.line	133	loadk        r23   k23 ; k23 = 220
.line	133	loadk        r24   k24 ; k24 = 157
.line	133	loadk        r25   k25 ; k25 = 110
.line	133	loadk        r26   k26 ; k26 = 21
.line	133	loadk        r27   k27 ; k27 = 149
.line	133	loadk        r28   k28 ; k28 = 242
.line	133	loadk        r29   k29 ; k29 = 201
.line	133	loadk        r30   k30 ; k30 = 228
.line	133	loadk        r31   k10 ; k10 = 100
.line	133	loadk        r32   k31 ; k31 = 103
.line	133	loadk        r33   k32 ; k32 = 249
.line	133	loadk        r34   k33 ; k33 = 154
.line	133	loadk        r35   k34 ; k34 = 59
.line	133	loadk        r36   k19 ; k19 = 42
.line	133	loadk        r37   k35 ; k35 = 6
.line	133	loadk        r38   k36 ; k36 = 213
.line	133	loadk        r39   k37 ; k37 = 240
.line	133	loadk        r40    k4 ; k4 = 212
.line	133	loadk        r41   k38 ; k38 = 48
.line	133	loadk        r42   k54 ; k54 = 18
.line	133	loadk        r43   k55 ; k55 = 174
.line	133	call          r3    41     2
.line	133	getupval      r4    u1
.line	133	loadk         r5   k56 ; k56 = 247
.line	133	loadk         r6    k5 ; k5 = 41
.line	133	loadk         r7   k57 ; k57 = 191
.line	133	loadk         r8   k14 ; k14 = 252
.line	133	loadk         r9   k58 ; k58 = 123
.line	133	loadk        r10   k59 ; k59 = 69
.line	133	loadk        r11   k60 ; k60 = 104
.line	133	loadk        r12   k27 ; k27 = 149
.line	133	loadk        r13   k61 ; k61 = 167
.line	133	loadk        r14   k62 ; k62 = 148
.line	133	loadk        r15   k63 ; k63 = 187
.line	133	call          r4    12     0
.line	133	setlist       r2     0     1
.line	133	call          r1     2     2
.line	133	gettabup      r2    u0   k51 ; k51 = "tostring"
.line	133	gettabup      r3    u2   k52 ; k52 = "depotItemPackageArra" (truncated)
.line	133	test          r3     0
.line	133	jmp            0  l143
.line	133	gettabup      r3    u2   k52 ; k52 = "depotItemPackageArra" (truncated)
.line	133	gettable      r3    r3   k64 ; k64 = "totalCount"
.label	l143
.line	133	call          r2     2     2
.line	133	concat        r1    r1    r2
.label	l145
.line	133	call          r0     2     1
.line	133	gettabup      r0    u2   k65 ; k65 = "depotPackageTimeOut"
.line	133	test          r0     0
.line	133	jmp            0  l174
.line	133	gettabup      r0    u0   k66 ; k66 = "require"
.line	133	getupval      r1    u1
.line	133	loadk         r2   k67 ; k67 = 224
.line	133	loadk         r3   k68 ; k68 = 39
.line	133	loadk         r4   k69 ; k69 = 190
.line	133	loadk         r5   k70 ; k70 = 210
.line	133	loadk         r6   k58 ; k58 = 123
.line	133	loadk         r7   k46 ; k46 = 94
.line	133	loadk         r8   k71 ; k71 = 40
.line	133	loadk         r9   k27 ; k27 = 149
.line	133	loadk        r10   k72 ; k72 = 238
.line	133	loadk        r11   k73 ; k73 = 196
.line	133	loadk        r12   k74 ; k74 = 254
.line	133	loadk        r13    k9 ; k9 = 95
.line	133	loadk        r14   k75 ; k75 = 74
.line	133	loadk        r15   k76 ; k76 = 244
.line	133	loadk        r16   k18 ; k18 = 140
.line	133	loadk        r17   k77 ; k77 = 45
.line	133	loadk        r18   k20 ; k20 = 22
.line	133	loadk        r19   k78 ; k78 = 10
.line	133	call          r1    19     2
.line	133	call          r0     2     2
.line	133	gettable      r1    r0   k79 ; k79 = "RemoveTimer"
.line	133	gettabup      r2    u2   k65 ; k65 = "depotPackageTimeOut"
.line	133	call          r1     2     1
.label	l174
.line	133	settabup      u2   k65   k80 ; k80 = nil
.line	133	settabup      u2   k52   k80 ; k80 = nil
.line	133	return        r0     1
.line	133	move          r0    r0
.line	133	move          r0    r0
.line	133	return        r0     1

.function	main/f5

.source	null
.linedefined	144
.lastlinedefined	146
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	9	true

.line	144	getupval      r1    u0
.line	144	return        r1     2
.line	144	return        r0     1
.line	144	move          r0    r0
.line	144	move          r0    r0
.line	144	return        r0     1

.function	main/f6

.source	null
.linedefined	148
.lastlinedefined	150
.numparams	2
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	9	true
.upvalue	"U1"	5	true

.constant	k0	"VehicleSceneType"
.constant	k1	"None"

.line	148	testset       r2    r1     1
.line	148	jmp            0    l5
.line	148	gettabup      r2    u1    k0 ; k0 = "VehicleSceneType"
.line	148	gettable      r2    r2    k1 ; k1 = "None"
.label	l5
.line	148	setupval      r2    u0
.line	148	return        r0     1
.line	148	move          r0    r0
.line	148	return        r0     1

.function	main/f7

.source	null
.linedefined	152
.lastlinedefined	167
.numparams	5
.is_vararg	0
.maxstacksize	26

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	212
.constant	k3	41
.constant	k4	161
.constant	k5	219
.constant	k6	102
.constant	k7	95
.constant	k8	100
.constant	k9	132
.constant	k10	203
.constant	k11	198
.constant	k12	252
.constant	k13	105
.constant	k14	93
.constant	k15	167
.constant	k16	170
.constant	k17	40
.constant	k18	7
.constant	k19	29
.constant	k20	209
.constant	k21	"ModuleManager"
.constant	k22	"GetModule"
.constant	k23	"CommonModuleConfig"
.constant	k24	"QRcodeRestrictManager"
.constant	k25	"IsRestrictDepotCheck"
.constant	k26	"ShowRestrictTips"
.constant	k27	"EnterBeforShowUI"
.constant	k28	"UIManager"
.constant	k29	"ShowUI"
.constant	k30	"UI_Config"
.constant	k31	"wardrobe"
.constant	k32	"require"
.constant	k33	224
.constant	k34	39
.constant	k35	190
.constant	k36	210
.constant	k37	123
.constant	k38	94
.constant	k39	149
.constant	k40	238
.constant	k41	196
.constant	k42	254
.constant	k43	74
.constant	k44	244
.constant	k45	140
.constant	k46	45
.constant	k47	22
.constant	k48	10
.constant	k49	"AddTimerOnce"
.constant	k50	0.1
.constant	k51	"EventSystem"
.constant	k52	"postEvent"
.constant	k53	"EVENTTYPE_WARDROBE"
.constant	k54	"EVENTID_ENTER_WARDROBE"

.line	152	gettabup      r5    u0    k0 ; k0 = "log"
.line	152	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	152	test          r6     0
.line	152	jmp            0   l26
.line	152	getupval      r6    u1
.line	152	loadk         r7    k2 ; k2 = 212
.line	152	loadk         r8    k3 ; k3 = 41
.line	152	loadk         r9    k4 ; k4 = 161
.line	152	loadk        r10    k5 ; k5 = 219
.line	152	loadk        r11    k6 ; k6 = 102
.line	152	loadk        r12    k7 ; k7 = 95
.line	152	loadk        r13    k8 ; k8 = 100
.line	152	loadk        r14    k9 ; k9 = 132
.line	152	loadk        r15   k10 ; k10 = 203
.line	152	loadk        r16   k11 ; k11 = 198
.line	152	loadk        r17   k12 ; k12 = 252
.line	152	loadk        r18   k13 ; k13 = 105
.line	152	loadk        r19   k14 ; k14 = 93
.line	152	loadk        r20   k15 ; k15 = 167
.line	152	loadk        r21   k16 ; k16 = 170
.line	152	loadk        r22   k17 ; k17 = 40
.line	152	loadk        r23   k18 ; k18 = 7
.line	152	loadk        r24   k19 ; k19 = 29
.line	152	loadk        r25   k20 ; k20 = 209
.line	152	call          r6    20     2
.label	l26
.line	152	call          r5     2     1
.line	152	gettabup      r5    u0   k21 ; k21 = "ModuleManager"
.line	152	gettable      r5    r5   k22 ; k22 = "GetModule"
.line	152	gettabup      r6    u0   k21 ; k21 = "ModuleManager"
.line	152	gettable      r6    r6   k23 ; k23 = "CommonModuleConfig"
.line	152	gettable      r6    r6   k24 ; k24 = "QRcodeRestrictManage" (truncated)
.line	152	call          r5     2     2
.line	152	self          r6    r5   k25 ; k25 = "IsRestrictDepotCheck"
.line	152	call          r6     2     2
.line	152	test          r6     0
.line	152	jmp            0   l40
.line	152	self          r6    r5   k26 ; k26 = "ShowRestrictTips"
.line	152	call          r6     2     1
.line	152	return        r0     1
.label	l40
.line	152	getupval      r6    u2
.line	152	self          r6    r6   k27 ; k27 = "EnterBeforShowUI"
.line	152	call          r6     2     1
.line	152	gettabup      r6    u0   k28 ; k28 = "UIManager"
.line	152	gettable      r6    r6   k29 ; k29 = "ShowUI"
.line	152	gettabup      r7    u0   k28 ; k28 = "UIManager"
.line	152	gettable      r7    r7   k30 ; k30 = "UI_Config"
.line	152	gettable      r7    r7   k31 ; k31 = "wardrobe"
.line	152	move          r8    r1
.line	152	move          r9    r2
.line	152	move         r10    r3
.line	152	move         r11    r4
.line	152	call          r6     6     1
.line	152	gettabup      r6    u0   k32 ; k32 = "require"
.line	152	getupval      r7    u1
.line	152	loadk         r8   k33 ; k33 = 224
.line	152	loadk         r9   k34 ; k34 = 39
.line	152	loadk        r10   k35 ; k35 = 190
.line	152	loadk        r11   k36 ; k36 = 210
.line	152	loadk        r12   k37 ; k37 = 123
.line	152	loadk        r13   k38 ; k38 = 94
.line	152	loadk        r14   k17 ; k17 = 40
.line	152	loadk        r15   k39 ; k39 = 149
.line	152	loadk        r16   k40 ; k40 = 238
.line	152	loadk        r17   k41 ; k41 = 196
.line	152	loadk        r18   k42 ; k42 = 254
.line	152	loadk        r19    k7 ; k7 = 95
.line	152	loadk        r20   k43 ; k43 = 74
.line	152	loadk        r21   k44 ; k44 = 244
.line	152	loadk        r22   k45 ; k45 = 140
.line	152	loadk        r23   k46 ; k46 = 45
.line	152	loadk        r24   k47 ; k47 = 22
.line	152	loadk        r25   k48 ; k48 = 10
.line	152	call          r7    19     2
.line	152	call          r6     2     2
.line	152	gettable      r7    r6   k49 ; k49 = "AddTimerOnce"
.line	152	loadk         r8   k50 ; k50 = 0.1
.line	152	closure       r9    f0
.line	152	call          r7     3     1
.line	152	gettabup      r7    u0   k51 ; k51 = "EventSystem"
.line	152	self          r7    r7   k52 ; k52 = "postEvent"
.line	152	gettabup      r9    u0   k53 ; k53 = "EVENTTYPE_WARDROBE"
.line	152	gettabup     r10    u0   k54 ; k54 = "EVENTID_ENTER_WARDRO" (truncated)
.line	152	call          r7     4     1
.line	152	return        r0     1
.line	152	move          r0    r0
.line	152	move          r0    r0
.line	152	return        r0     1

.function	main/f7/f0

.source	null
.linedefined	162
.lastlinedefined	165
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	154
.constant	k44	209
.constant	k45	112
.constant	k46	85
.constant	k47	126
.constant	k48	233
.constant	k49	204
.constant	k50	236
.constant	k51	"JudgeIsShow"

.line	162	gettabup      r0    u0    k0 ; k0 = "require"
.line	162	gettabup      r1    u0    k1 ; k1 = "table"
.line	162	gettable      r1    r1    k2 ; k2 = "concat"
.line	162	newtable      r2     1     0
.line	162	getupval      r3    u1
.line	162	loadk         r4    k3 ; k3 = 224
.line	162	loadk         r5    k4 ; k4 = 36
.line	162	loadk         r6    k5 ; k5 = 186
.line	162	loadk         r7    k6 ; k6 = 218
.line	162	loadk         r8    k7 ; k7 = 122
.line	162	loadk         r9    k8 ; k8 = 68
.line	162	loadk        r10    k9 ; k9 = 40
.line	162	loadk        r11   k10 ; k10 = 146
.line	162	loadk        r12   k11 ; k11 = 235
.line	162	loadk        r13   k12 ; k12 = 220
.line	162	loadk        r14   k13 ; k13 = 250
.line	162	loadk        r15   k14 ; k14 = 46
.line	162	loadk        r16   k15 ; k15 = 82
.line	162	loadk        r17   k16 ; k16 = 242
.line	162	loadk        r18   k17 ; k17 = 136
.line	162	loadk        r19   k18 ; k18 = 47
.line	162	loadk        r20   k19 ; k19 = 16
.line	162	loadk        r21   k20 ; k20 = 86
.line	162	loadk        r22   k21 ; k21 = 212
.line	162	loadk        r23   k22 ; k22 = 238
.line	162	loadk        r24   k23 ; k23 = 150
.line	162	loadk        r25   k24 ; k24 = 100
.line	162	loadk        r26   k25 ; k25 = 4
.line	162	loadk        r27   k26 ; k26 = 190
.line	162	loadk        r28   k27 ; k27 = 245
.line	162	loadk        r29   k12 ; k12 = 220
.line	162	loadk        r30   k28 ; k28 = 165
.line	162	loadk        r31   k29 ; k29 = 124
.line	162	loadk        r32   k30 ; k30 = 65
.line	162	loadk        r33   k31 ; k31 = 234
.line	162	loadk        r34   k23 ; k23 = 150
.line	162	loadk        r35   k32 ; k32 = 53
.line	162	loadk        r36   k33 ; k33 = 60
.line	162	loadk        r37   k34 ; k34 = 31
.line	162	loadk        r38   k35 ; k35 = 210
.line	162	loadk        r39   k36 ; k36 = 237
.line	162	loadk        r40   k37 ; k37 = 144
.line	162	loadk        r41   k38 ; k38 = 98
.line	162	loadk        r42   k39 ; k39 = 9
.line	162	loadk        r43   k40 ; k40 = 163
.line	162	call          r3    41     2
.line	162	getupval      r4    u1
.line	162	loadk         r5   k41 ; k41 = 230
.line	162	loadk         r6   k42 ; k42 = 23
.line	162	loadk         r7   k43 ; k43 = 154
.line	162	loadk         r8   k44 ; k44 = 209
.line	162	loadk         r9   k45 ; k45 = 112
.line	162	loadk        r10   k46 ; k46 = 85
.line	162	loadk        r11   k47 ; k47 = 126
.line	162	loadk        r12   k26 ; k26 = 190
.line	162	loadk        r13   k48 ; k48 = 233
.line	162	loadk        r14   k49 ; k49 = 204
.line	162	loadk        r15   k50 ; k50 = 236
.line	162	call          r4    12     0
.line	162	setlist       r2     0     1
.line	162	call          r1     2     2
.line	162	call          r0     2     2
.line	162	self          r1    r0   k51 ; k51 = "JudgeIsShow"
.line	162	call          r1     2     1
.line	162	return        r0     1
.line	162	move          r0    r0
.line	162	move          r0    r0
.line	162	move          r0    r0
.line	162	return        r0     1

.function	main/f8

.source	null
.linedefined	169
.lastlinedefined	178
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	238
.constant	k15	155
.constant	k16	41
.constant	k17	1
.constant	k18	29
.constant	k19	229
.constant	k20	145
.constant	k21	109
.constant	k22	6
.constant	k23	142
.constant	k24	226
.constant	k25	205
.constant	k26	124
.constant	k27	93
.constant	k28	"log"
.constant	k29	"bWriteLog"
.constant	k30	212
.constant	k31	161
.constant	k32	219
.constant	k33	102
.constant	k34	95
.constant	k35	100
.constant	k36	132
.constant	k37	203
.constant	k38	198
.constant	k39	252
.constant	k40	105
.constant	k41	167
.constant	k42	170
.constant	k43	7
.constant	k44	209
.constant	k45	175
.constant	k46	"table"
.constant	k47	"concat"
.constant	k48	143
.constant	k49	221
.constant	k50	236
.constant	k51	111
.constant	k52	76
.constant	k53	246
.constant	k54	193
.constant	k55	22
.constant	k56	23
.constant	k57	215
.constant	k58	135
.constant	k59	26
.constant	k60	255
.constant	k61	196
.constant	k62	214
.constant	k63	121
.constant	k64	79
.constant	k65	225
.constant	k66	179
.constant	k67	57
.constant	k68	10
.constant	k69	202
.constant	k70	149
.constant	k71	126
.constant	k72	2
.constant	k73	173
.constant	k74	230
.constant	k75	58
.constant	k76	"send_client_in_depot"
.constant	k77	129
.constant	k78	25
.constant	k79	163
.constant	k80	228
.constant	k81	103
.constant	k82	123
.constant	k83	223
.constant	k84	4
.constant	k85	250
.constant	k86	44
.constant	k87	180
.constant	k88	56
.constant	k89	158
.constant	k90	222
.constant	k91	104
.constant	k92	"RequestJumpMapInfo"
.constant	k93	192
.constant	k94	216
.constant	k95	249
.constant	k96	116
.constant	k97	157
.constant	k98	51
.constant	k99	43
.constant	k100	9
.constant	k101	251
.constant	k102	152
.constant	k103	117
.constant	k104	20
.constant	k105	L"send_get_shared_backpack_table_params_req"

.line	169	gettabup      r1    u0    k0 ; k0 = "require"
.line	169	getupval      r2    u1
.line	169	loadk         r3    k1 ; k1 = 224
.line	169	loadk         r4    k2 ; k2 = 36
.line	169	loadk         r5    k3 ; k3 = 186
.line	169	loadk         r6    k4 ; k4 = 218
.line	169	loadk         r7    k5 ; k5 = 122
.line	169	loadk         r8    k6 ; k6 = 68
.line	169	loadk         r9    k7 ; k7 = 40
.line	169	loadk        r10    k8 ; k8 = 141
.line	169	loadk        r11    k9 ; k9 = 232
.line	169	loadk        r12   k10 ; k10 = 206
.line	169	loadk        r13   k11 ; k11 = 242
.line	169	loadk        r14   k12 ; k12 = 99
.line	169	loadk        r15   k13 ; k13 = 16
.line	169	loadk        r16   k14 ; k14 = 238
.line	169	loadk        r17   k15 ; k15 = 155
.line	169	loadk        r18   k16 ; k16 = 41
.line	169	loadk        r19   k17 ; k17 = 1
.line	169	loadk        r20   k18 ; k18 = 29
.line	169	loadk        r21    k8 ; k8 = 141
.line	169	loadk        r22   k19 ; k19 = 229
.line	169	loadk        r23   k20 ; k20 = 145
.line	169	loadk        r24   k21 ; k21 = 109
.line	169	loadk        r25   k22 ; k22 = 6
.line	169	loadk        r26   k23 ; k23 = 142
.line	169	loadk        r27   k24 ; k24 = 226
.line	169	loadk        r28   k25 ; k25 = 205
.line	169	loadk        r29   k24 ; k24 = 226
.line	169	loadk        r30   k26 ; k26 = 124
.line	169	loadk        r31   k27 ; k27 = 93
.line	169	call          r2    30     2
.line	169	call          r1     2     2
.line	169	gettabup      r2    u0   k28 ; k28 = "log"
.line	169	gettabup      r3    u0   k29 ; k29 = "bWriteLog"
.line	169	test          r3     0
.line	169	jmp            0   l60
.line	169	getupval      r3    u1
.line	169	loadk         r4   k30 ; k30 = 212
.line	169	loadk         r5   k16 ; k16 = 41
.line	169	loadk         r6   k31 ; k31 = 161
.line	169	loadk         r7   k32 ; k32 = 219
.line	169	loadk         r8   k33 ; k33 = 102
.line	169	loadk         r9   k34 ; k34 = 95
.line	169	loadk        r10   k35 ; k35 = 100
.line	169	loadk        r11   k36 ; k36 = 132
.line	169	loadk        r12   k37 ; k37 = 203
.line	169	loadk        r13   k38 ; k38 = 198
.line	169	loadk        r14   k39 ; k39 = 252
.line	169	loadk        r15   k40 ; k40 = 105
.line	169	loadk        r16   k27 ; k27 = 93
.line	169	loadk        r17   k41 ; k41 = 167
.line	169	loadk        r18   k42 ; k42 = 170
.line	169	loadk        r19    k7 ; k7 = 40
.line	169	loadk        r20   k43 ; k43 = 7
.line	169	loadk        r21   k18 ; k18 = 29
.line	169	loadk        r22   k44 ; k44 = 209
.line	169	loadk        r23   k45 ; k45 = 175
.line	169	call          r3    21     2
.label	l60
.line	169	call          r2     2     1
.line	169	gettabup      r2    u0    k0 ; k0 = "require"
.line	169	gettabup      r3    u0   k46 ; k46 = "table"
.line	169	gettable      r3    r3   k47 ; k47 = "concat"
.line	169	newtable      r4     1     0
.line	169	getupval      r5    u1
.line	169	loadk         r6    k1 ; k1 = 224
.line	169	loadk         r7    k2 ; k2 = 36
.line	169	loadk         r8    k3 ; k3 = 186
.line	169	loadk         r9    k4 ; k4 = 218
.line	169	loadk        r10    k5 ; k5 = 122
.line	169	loadk        r11    k6 ; k6 = 68
.line	169	loadk        r12    k7 ; k7 = 40
.line	169	loadk        r13   k48 ; k48 = 143
.line	169	loadk        r14   k24 ; k24 = 226
.line	169	loadk        r15   k49 ; k49 = 221
.line	169	loadk        r16   k50 ; k50 = 236
.line	169	loadk        r17   k51 ; k51 = 111
.line	169	loadk        r18   k52 ; k52 = 76
.line	169	loadk        r19   k53 ; k53 = 246
.line	169	loadk        r20   k54 ; k54 = 193
.line	169	loadk        r21   k55 ; k55 = 22
.line	169	loadk        r22   k17 ; k17 = 1
.line	169	loadk        r23   k56 ; k56 = 23
.line	169	loadk        r24   k57 ; k57 = 215
.line	169	loadk        r25    k1 ; k1 = 224
.line	169	loadk        r26   k58 ; k58 = 135
.line	169	loadk        r27   k51 ; k51 = 111
.line	169	loadk        r28   k59 ; k59 = 26
.line	169	loadk        r29   k60 ; k60 = 255
.line	169	loadk        r30   k61 ; k61 = 196
.line	169	loadk        r31   k62 ; k62 = 214
.line	169	loadk        r32    k9 ; k9 = 232
.line	169	loadk        r33   k63 ; k63 = 121
.line	169	loadk        r34   k64 ; k64 = 79
.line	169	loadk        r35   k65 ; k65 = 225
.line	169	loadk        r36   k66 ; k66 = 179
.line	169	loadk        r37   k67 ; k67 = 57
.line	169	loadk        r38   k17 ; k17 = 1
.line	169	loadk        r39   k68 ; k68 = 10
.line	169	loadk        r40   k69 ; k69 = 202
.line	169	loadk        r41   k57 ; k57 = 215
.line	169	loadk        r42   k70 ; k70 = 149
.line	169	loadk        r43   k71 ; k71 = 126
.line	169	loadk        r44   k72 ; k72 = 2
.line	169	loadk        r45   k73 ; k73 = 173
.line	169	call          r5    41     2
.line	169	getupval      r6    u1
.line	169	loadk         r7   k74 ; k74 = 230
.line	169	loadk         r8   k75 ; k75 = 58
.line	169	call          r6     3     0
.line	169	setlist       r4     0     1
.line	169	call          r3     2     2
.line	169	call          r2     2     2
.line	169	gettable      r3    r2   k76 ; k76 = "send_client_in_depot"
.line	169	call          r3     1     1
.line	169	gettabup      r3    u0   k28 ; k28 = "log"
.line	169	gettabup      r4    u0   k29 ; k29 = "bWriteLog"
.line	169	test          r4     0
.line	169	jmp            0  l178
.line	169	gettabup      r4    u0   k46 ; k46 = "table"
.line	169	gettable      r4    r4   k47 ; k47 = "concat"
.line	169	newtable      r5     1     0
.line	169	getupval      r6    u1
.line	169	loadk         r7   k30 ; k30 = 212
.line	169	loadk         r8   k16 ; k16 = 41
.line	169	loadk         r9   k31 ; k31 = 161
.line	169	loadk        r10   k32 ; k32 = 219
.line	169	loadk        r11   k33 ; k33 = 102
.line	169	loadk        r12   k34 ; k34 = 95
.line	169	loadk        r13   k35 ; k35 = 100
.line	169	loadk        r14   k36 ; k36 = 132
.line	169	loadk        r15   k37 ; k37 = 203
.line	169	loadk        r16   k38 ; k38 = 198
.line	169	loadk        r17   k39 ; k39 = 252
.line	169	loadk        r18   k40 ; k40 = 105
.line	169	loadk        r19   k27 ; k27 = 93
.line	169	loadk        r20   k41 ; k41 = 167
.line	169	loadk        r21   k42 ; k42 = 170
.line	169	loadk        r22    k7 ; k7 = 40
.line	169	loadk        r23   k43 ; k43 = 7
.line	169	loadk        r24   k18 ; k18 = 29
.line	169	loadk        r25   k44 ; k44 = 209
.line	169	loadk        r26   k25 ; k25 = 205
.line	169	loadk        r27   k77 ; k77 = 129
.line	169	loadk        r28   k33 ; k33 = 102
.line	169	loadk        r29   k78 ; k78 = 25
.line	169	loadk        r30   k79 ; k79 = 163
.line	169	loadk        r31   k61 ; k61 = 196
.line	169	loadk        r32   k44 ; k44 = 209
.line	169	loadk        r33   k80 ; k80 = 228
.line	169	loadk        r34   k81 ; k81 = 103
.line	169	loadk        r35   k82 ; k82 = 123
.line	169	loadk        r36   k61 ; k61 = 196
.line	169	loadk        r37   k83 ; k83 = 223
.line	169	loadk        r38   k84 ; k84 = 4
.line	169	loadk        r39   k22 ; k22 = 6
.line	169	loadk        r40   k78 ; k78 = 25
.line	169	loadk        r41   k38 ; k38 = 198
.line	169	loadk        r42   k85 ; k85 = 250
.line	169	loadk        r43   k58 ; k58 = 135
.line	169	loadk        r44   k35 ; k35 = 100
.line	169	loadk        r45   k86 ; k86 = 44
.line	169	loadk        r46   k87 ; k87 = 180
.line	169	call          r6    41     2
.line	169	getupval      r7    u1
.line	169	loadk         r8   k14 ; k14 = 238
.line	169	loadk         r9   k88 ; k88 = 56
.line	169	loadk        r10   k89 ; k89 = 158
.line	169	loadk        r11   k90 ; k90 = 222
.line	169	loadk        r12   k35 ; k35 = 100
.line	169	loadk        r13   k63 ; k63 = 121
.line	169	loadk        r14   k91 ; k91 = 104
.line	169	loadk        r15   k58 ; k58 = 135
.line	169	loadk        r16    k9 ; k9 = 232
.line	169	call          r7    10     0
.line	169	setlist       r5     0     1
.line	169	call          r4     2     2
.label	l178
.line	169	call          r3     2     1
.line	169	gettable      r3    r1   k92 ; k92 = "RequestJumpMapInfo"
.line	169	call          r3     1     1
.line	169	gettabup      r3    u0    k0 ; k0 = "require"
.line	169	getupval      r4    u1
.line	169	loadk         r5    k1 ; k1 = 224
.line	169	loadk         r6    k2 ; k2 = 36
.line	169	loadk         r7    k3 ; k3 = 186
.line	169	loadk         r8    k4 ; k4 = 218
.line	169	loadk         r9    k5 ; k5 = 122
.line	169	loadk        r10    k6 ; k6 = 68
.line	169	loadk        r11    k7 ; k7 = 40
.line	169	loadk        r12   k48 ; k48 = 143
.line	169	loadk        r13   k24 ; k24 = 226
.line	169	loadk        r14   k49 ; k49 = 221
.line	169	loadk        r15   k50 ; k50 = 236
.line	169	loadk        r16   k51 ; k51 = 111
.line	169	loadk        r17   k52 ; k52 = 76
.line	169	loadk        r18   k53 ; k53 = 246
.line	169	loadk        r19   k54 ; k54 = 193
.line	169	loadk        r20   k55 ; k55 = 22
.line	169	loadk        r21   k17 ; k17 = 1
.line	169	loadk        r22   k56 ; k56 = 23
.line	169	loadk        r23   k57 ; k57 = 215
.line	169	loadk        r24    k1 ; k1 = 224
.line	169	loadk        r25   k58 ; k58 = 135
.line	169	loadk        r26   k51 ; k51 = 111
.line	169	loadk        r27   k59 ; k59 = 26
.line	169	loadk        r28   k60 ; k60 = 255
.line	169	loadk        r29   k93 ; k93 = 192
.line	169	loadk        r30   k94 ; k94 = 216
.line	169	loadk        r31   k95 ; k95 = 249
.line	169	loadk        r32   k96 ; k96 = 116
.line	169	loadk        r33   k26 ; k26 = 124
.line	169	loadk        r34   k24 ; k24 = 226
.line	169	loadk        r35   k97 ; k97 = 157
.line	169	loadk        r36   k98 ; k98 = 51
.line	169	loadk        r37   k99 ; k99 = 43
.line	169	loadk        r38  k100 ; k100 = 9
.line	169	loadk        r39   k49 ; k49 = 221
.line	169	loadk        r40  k101 ; k101 = 251
.line	169	loadk        r41  k102 ; k102 = 152
.line	169	loadk        r42  k103 ; k103 = 117
.line	169	loadk        r43  k104 ; k104 = 20
.line	169	call          r4    40     2
.line	169	call          r3     2     2
.line	169	gettable      r4    r3  k105 ; k105 = L"send_get_shared_back" (truncated)
.line	169	call          r4     1     1
.line	169	return        r0     1
.line	169	move          r0    r0
.line	169	return        r0     1

.function	main/f9

.source	null
.linedefined	180
.lastlinedefined	188
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"voiceMode"
.constant	k1	"tonumber"

.line	180	test          r0     1
.line	180	jmp            0    l4
.line	180	return        r0     2
.label	l4
.line	180	newtable      r1     0     1
.line	180	gettabup      r2    u0    k1 ; k1 = "tonumber"
.line	180	gettable      r3    r0    k0 ; k0 = "voiceMode"
.line	180	call          r2     2     2
.line	180	settable      r1    k0    r2 ; k0 = "voiceMode"
.line	180	return        r1     2
.line	180	return        r0     1
.line	180	move          r0    r0
.line	180	move          r0    r0
.line	180	move          r0    r0
.line	180	return        r0     1

.function	main/f10

.source	null
.linedefined	190
.lastlinedefined	219
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"LobbySystem"
.constant	k1	"CheckLobbyMenuOpen"
.constant	k2	"BP_ENUM_LOBBY_MENU_WARDROBE"
.constant	k3	"UIManager"
.constant	k4	"IsUIShow"
.constant	k5	"UI_Config"
.constant	k6	"wardrobe"
.constant	k7	"CloseOtherMenu"
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	224
.constant	k12	36
.constant	k13	186
.constant	k14	218
.constant	k15	122
.constant	k16	68
.constant	k17	40
.constant	k18	146
.constant	k19	235
.constant	k20	220
.constant	k21	250
.constant	k22	46
.constant	k23	82
.constant	k24	242
.constant	k25	136
.constant	k26	47
.constant	k27	16
.constant	k28	86
.constant	k29	212
.constant	k30	238
.constant	k31	150
.constant	k32	100
.constant	k33	4
.constant	k34	190
.constant	k35	245
.constant	k36	165
.constant	k37	124
.constant	k38	65
.constant	k39	234
.constant	k40	53
.constant	k41	60
.constant	k42	31
.constant	k43	210
.constant	k44	237
.constant	k45	144
.constant	k46	98
.constant	k47	9
.constant	k48	163
.constant	k49	230
.constant	k50	23
.constant	k51	189
.constant	k52	99
.constant	k53	"itemId"
.constant	k54	"CDataTable"
.constant	k55	"GetTableData"
.constant	k56	202
.constant	k57	182
.constant	k58	"WardrobeMainTab"
.constant	k59	"WardrobeTab"
.constant	k60	"Enter"
.constant	k61	"tabId"
.constant	k62	"tonumber"
.constant	k63	"subTabId"
.constant	k64	"_ExtractJumpArgs"
.constant	k65	"ClientSendBAReport"
.constant	k66	"TLogEventDefine"
.constant	k67	"LobbyInventory"
.constant	k68	0
.constant	k69	"ModuleManager"
.constant	k70	"GetModule"
.constant	k71	"LobbyModuleConfig"
.constant	k72	"logic_return_tlog_report"
.constant	k73	"ReportReturnTLogEvent"

.line	190	gettabup      r1    u0    k0 ; k0 = "LobbySystem"
.line	190	gettable      r1    r1    k1 ; k1 = "CheckLobbyMenuOpen"
.line	190	gettabup      r2    u0    k2 ; k2 = "BP_ENUM_LOBBY_MENU_W" (truncated)
.line	190	call          r1     2     2
.line	190	test          r1     1
.line	190	jmp            0    l8
.line	190	return        r0     1
.label	l8
.line	190	gettabup      r1    u0    k3 ; k3 = "UIManager"
.line	190	gettable      r1    r1    k4 ; k4 = "IsUIShow"
.line	190	gettabup      r2    u0    k3 ; k3 = "UIManager"
.line	190	gettable      r2    r2    k5 ; k5 = "UI_Config"
.line	190	gettable      r2    r2    k6 ; k6 = "wardrobe"
.line	190	call          r1     2     2
.line	190	test          r1     1
.line	190	jmp            0   l19
.line	190	gettabup      r1    u0    k0 ; k0 = "LobbySystem"
.line	190	gettable      r1    r1    k7 ; k7 = "CloseOtherMenu"
.line	190	call          r1     1     1
.label	l19
.line	190	gettabup      r1    u0    k8 ; k8 = "require"
.line	190	gettabup      r2    u0    k9 ; k9 = "table"
.line	190	gettable      r2    r2   k10 ; k10 = "concat"
.line	190	newtable      r3     1     0
.line	190	getupval      r4    u1
.line	190	loadk         r5   k11 ; k11 = 224
.line	190	loadk         r6   k12 ; k12 = 36
.line	190	loadk         r7   k13 ; k13 = 186
.line	190	loadk         r8   k14 ; k14 = 218
.line	190	loadk         r9   k15 ; k15 = 122
.line	190	loadk        r10   k16 ; k16 = 68
.line	190	loadk        r11   k17 ; k17 = 40
.line	190	loadk        r12   k18 ; k18 = 146
.line	190	loadk        r13   k19 ; k19 = 235
.line	190	loadk        r14   k20 ; k20 = 220
.line	190	loadk        r15   k21 ; k21 = 250
.line	190	loadk        r16   k22 ; k22 = 46
.line	190	loadk        r17   k23 ; k23 = 82
.line	190	loadk        r18   k24 ; k24 = 242
.line	190	loadk        r19   k25 ; k25 = 136
.line	190	loadk        r20   k26 ; k26 = 47
.line	190	loadk        r21   k27 ; k27 = 16
.line	190	loadk        r22   k28 ; k28 = 86
.line	190	loadk        r23   k29 ; k29 = 212
.line	190	loadk        r24   k30 ; k30 = 238
.line	190	loadk        r25   k31 ; k31 = 150
.line	190	loadk        r26   k32 ; k32 = 100
.line	190	loadk        r27   k33 ; k33 = 4
.line	190	loadk        r28   k34 ; k34 = 190
.line	190	loadk        r29   k35 ; k35 = 245
.line	190	loadk        r30   k20 ; k20 = 220
.line	190	loadk        r31   k36 ; k36 = 165
.line	190	loadk        r32   k37 ; k37 = 124
.line	190	loadk        r33   k38 ; k38 = 65
.line	190	loadk        r34   k39 ; k39 = 234
.line	190	loadk        r35   k31 ; k31 = 150
.line	190	loadk        r36   k40 ; k40 = 53
.line	190	loadk        r37   k41 ; k41 = 60
.line	190	loadk        r38   k42 ; k42 = 31
.line	190	loadk        r39   k43 ; k43 = 210
.line	190	loadk        r40   k44 ; k44 = 237
.line	190	loadk        r41   k45 ; k45 = 144
.line	190	loadk        r42   k46 ; k46 = 98
.line	190	loadk        r43   k47 ; k47 = 9
.line	190	loadk        r44   k48 ; k48 = 163
.line	190	call          r4    41     2
.line	190	getupval      r5    u1
.line	190	loadk         r6   k49 ; k49 = 230
.line	190	loadk         r7   k50 ; k50 = 23
.line	190	loadk         r8   k51 ; k51 = 189
.line	190	loadk         r9   k14 ; k14 = 218
.line	190	loadk        r10   k52 ; k52 = 99
.line	190	call          r5     6     0
.line	190	setlist       r3     0     1
.line	190	call          r2     2     2
.line	190	call          r1     2     2
.line	190	test          r0     0
.line	190	jmp            0  l106
.line	190	gettable      r2    r0   k53 ; k53 = "itemId"
.line	190	test          r2     0
.line	190	jmp            0  l106
.line	190	gettabup      r2    u0   k54 ; k54 = "CDataTable"
.line	190	gettable      r2    r2   k55 ; k55 = "GetTableData"
.line	190	getupval      r3    u1
.line	190	loadk         r4   k56 ; k56 = 202
.line	190	loadk         r5   k41 ; k41 = 60
.line	190	loadk         r6   k57 ; k57 = 182
.line	190	loadk         r7   k43 ; k43 = 210
.line	190	call          r3     5     2
.line	190	gettable      r4    r0   k53 ; k53 = "itemId"
.line	190	call          r2     3     2
.line	190	test          r2     0
.line	190	jmp            0  l103
.line	190	gettable      r3    r2   k58 ; k58 = "WardrobeMainTab"
.line	190	test          r3     0
.line	190	jmp            0  l103
.line	190	gettable      r3    r2   k59 ; k59 = "WardrobeTab"
.line	190	test          r3     0
.line	190	jmp            0  l103
.line	190	self          r3    r1   k60 ; k60 = "Enter"
.line	190	gettable      r5    r2   k58 ; k58 = "WardrobeMainTab"
.line	190	gettable      r6    r2   k59 ; k59 = "WardrobeTab"
.line	190	call          r3     4     1
.line	190	jmp            0  l133
.label	l103
.line	190	self          r3    r1   k60 ; k60 = "Enter"
.line	190	call          r3     2     1
.line	190	jmp            0  l133
.label	l106
.line	190	test          r0     0
.line	190	jmp            0  l131
.line	190	gettable      r2    r0   k61 ; k61 = "tabId"
.line	190	test          r2     0
.line	190	jmp            0  l131
.line	190	gettabup      r2    u0   k62 ; k62 = "tonumber"
.line	190	gettable      r3    r0   k61 ; k61 = "tabId"
.line	190	call          r2     2     2
.line	190	loadnil       r3     0
.line	190	gettable      r4    r0   k63 ; k63 = "subTabId"
.line	190	test          r4     0
.line	190	jmp            0  l122
.line	190	gettabup      r4    u0   k62 ; k62 = "tonumber"
.line	190	gettable      r5    r0   k63 ; k63 = "subTabId"
.line	190	call          r4     2     2
.line	190	move          r3    r4
.label	l122
.line	190	gettable      r4    r1   k64 ; k64 = "_ExtractJumpArgs"
.line	190	move          r5    r0
.line	190	call          r4     2     2
.line	190	self          r5    r1   k60 ; k60 = "Enter"
.line	190	move          r7    r2
.line	190	move          r8    r3
.line	190	move          r9    r4
.line	190	call          r5     5     1
.line	190	jmp            0  l133
.label	l131
.line	190	self          r2    r1   k60 ; k60 = "Enter"
.line	190	call          r2     2     1
.label	l133
.line	190	gettabup      r2    u0   k65 ; k65 = "ClientSendBAReport"
.line	190	gettabup      r3    u0   k66 ; k66 = "TLogEventDefine"
.line	190	gettable      r3    r3   k67 ; k67 = "LobbyInventory"
.line	190	loadk         r4   k68 ; k68 = 0
.line	190	call          r2     3     1
.line	190	gettabup      r2    u0   k69 ; k69 = "ModuleManager"
.line	190	gettable      r2    r2   k70 ; k70 = "GetModule"
.line	190	gettabup      r3    u0   k69 ; k69 = "ModuleManager"
.line	190	gettable      r3    r3   k71 ; k71 = "LobbyModuleConfig"
.line	190	gettable      r3    r3   k72 ; k72 = "logic_return_tlog_re" (truncated)
.line	190	call          r2     2     2
.line	190	self          r3    r2   k73 ; k73 = "ReportReturnTLogEven" (truncated)
.line	190	gettabup      r5    u0   k66 ; k66 = "TLogEventDefine"
.line	190	gettable      r5    r5   k67 ; k67 = "LobbyInventory"
.line	190	loadk         r6   k68 ; k68 = 0
.line	190	call          r3     4     1
.line	190	return        r0     1
.line	190	move          r0    r0
.line	190	return        r0     1

.function	main/f11

.source	null
.linedefined	221
.lastlinedefined	233
.numparams	3
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true

.constant	k0	"log_tree"
.constant	k1	212
.constant	k2	41
.constant	k3	161
.constant	k4	219
.constant	k5	102
.constant	k6	95
.constant	k7	100
.constant	k8	132
.constant	k9	203
.constant	k10	198
.constant	k11	252
.constant	k12	105
.constant	k13	93
.constant	k14	167
.constant	k15	165
.constant	k16	51
.constant	k17	30
.constant	k18	8
.constant	k19	247
.constant	k20	224
.constant	k21	"ModuleManager"
.constant	k22	"GetModule"
.constant	k23	"CommonModuleConfig"
.constant	k24	"QRcodeRestrictManager"
.constant	k25	"IsRestrictDepotCheck"
.constant	k26	"ShowRestrictTips"
.constant	k27	"EnterWardrobe"
.constant	k28	"OpenDecompose"
.constant	k29	"require"
.constant	k30	36
.constant	k31	186
.constant	k32	218
.constant	k33	122
.constant	k34	68
.constant	k35	40
.constant	k36	141
.constant	k37	232
.constant	k38	206
.constant	k39	242
.constant	k40	99
.constant	k41	16
.constant	k42	249
.constant	k43	138
.constant	k44	37
.constant	k45	28
.constant	k46	21
.constant	k47	211
.constant	k48	151
.constant	k49	101
.constant	k50	88
.constant	k51	189
.constant	k52	248
.constant	k53	222
.constant	k54	226
.constant	k55	115
.constant	k56	113
.constant	k57	233
.constant	k58	154
.constant	k59	53
.constant	k60	12
.constant	k61	5
.constant	k62	195
.constant	k63	240
.constant	k64	135
.constant	k65	117
.constant	k66	"Show"

.line	221	gettabup      r3    u0    k0 ; k0 = "log_tree"
.line	221	getupval      r4    u1
.line	221	loadk         r5    k1 ; k1 = 212
.line	221	loadk         r6    k2 ; k2 = 41
.line	221	loadk         r7    k3 ; k3 = 161
.line	221	loadk         r8    k4 ; k4 = 219
.line	221	loadk         r9    k5 ; k5 = 102
.line	221	loadk        r10    k6 ; k6 = 95
.line	221	loadk        r11    k7 ; k7 = 100
.line	221	loadk        r12    k8 ; k8 = 132
.line	221	loadk        r13    k9 ; k9 = 203
.line	221	loadk        r14   k10 ; k10 = 198
.line	221	loadk        r15   k11 ; k11 = 252
.line	221	loadk        r16   k12 ; k12 = 105
.line	221	loadk        r17   k13 ; k13 = 93
.line	221	loadk        r18   k14 ; k14 = 167
.line	221	loadk        r19   k15 ; k15 = 165
.line	221	loadk        r20   k16 ; k16 = 51
.line	221	loadk        r21   k17 ; k17 = 30
.line	221	loadk        r22   k18 ; k18 = 8
.line	221	loadk        r23   k19 ; k19 = 247
.line	221	loadk        r24   k20 ; k20 = 224
.line	221	call          r4    21     2
.line	221	move          r5    r2
.line	221	call          r3     3     1
.line	221	gettabup      r3    u0   k21 ; k21 = "ModuleManager"
.line	221	gettable      r3    r3   k22 ; k22 = "GetModule"
.line	221	gettabup      r4    u0   k21 ; k21 = "ModuleManager"
.line	221	gettable      r4    r4   k23 ; k23 = "CommonModuleConfig"
.line	221	gettable      r4    r4   k24 ; k24 = "QRcodeRestrictManage" (truncated)
.line	221	call          r3     2     2
.line	221	self          r4    r3   k25 ; k25 = "IsRestrictDepotCheck"
.line	221	call          r4     2     2
.line	221	test          r4     0
.line	221	jmp            0   l39
.line	221	self          r4    r3   k26 ; k26 = "ShowRestrictTips"
.line	221	call          r4     2     1
.line	221	return        r0     1
.label	l39
.line	221	gettabup      r4    u2   k27 ; k27 = "EnterWardrobe"
.line	221	move          r5    r2
.line	221	call          r4     2     1
.line	221	test          r2     0
.line	221	jmp            0   l91
.line	221	gettable      r4    r2   k28 ; k28 = "OpenDecompose"
.line	221	test          r4     0
.line	221	jmp            0   l91
.line	221	gettabup      r4    u0   k29 ; k29 = "require"
.line	221	getupval      r5    u1
.line	221	loadk         r6   k20 ; k20 = 224
.line	221	loadk         r7   k30 ; k30 = 36
.line	221	loadk         r8   k31 ; k31 = 186
.line	221	loadk         r9   k32 ; k32 = 218
.line	221	loadk        r10   k33 ; k33 = 122
.line	221	loadk        r11   k34 ; k34 = 68
.line	221	loadk        r12   k35 ; k35 = 40
.line	221	loadk        r13   k36 ; k36 = 141
.line	221	loadk        r14   k37 ; k37 = 232
.line	221	loadk        r15   k38 ; k38 = 206
.line	221	loadk        r16   k39 ; k39 = 242
.line	221	loadk        r17   k40 ; k40 = 99
.line	221	loadk        r18   k41 ; k41 = 16
.line	221	loadk        r19   k42 ; k42 = 249
.line	221	loadk        r20   k43 ; k43 = 138
.line	221	loadk        r21   k44 ; k44 = 37
.line	221	loadk        r22   k45 ; k45 = 28
.line	221	loadk        r23   k46 ; k46 = 21
.line	221	loadk        r24   k47 ; k47 = 211
.line	221	loadk        r25   k20 ; k20 = 224
.line	221	loadk        r26   k48 ; k48 = 151
.line	221	loadk        r27   k49 ; k49 = 101
.line	221	loadk        r28   k50 ; k50 = 88
.line	221	loadk        r29   k51 ; k51 = 189
.line	221	loadk        r30   k52 ; k52 = 248
.line	221	loadk        r31   k53 ; k53 = 222
.line	221	loadk        r32   k54 ; k54 = 226
.line	221	loadk        r33   k55 ; k55 = 115
.line	221	loadk        r34   k56 ; k56 = 113
.line	221	loadk        r35   k57 ; k57 = 233
.line	221	loadk        r36   k58 ; k58 = 154
.line	221	loadk        r37   k59 ; k59 = 53
.line	221	loadk        r38   k60 ; k60 = 12
.line	221	loadk        r39   k61 ; k61 = 5
.line	221	loadk        r40   k62 ; k62 = 195
.line	221	loadk        r41   k63 ; k63 = 240
.line	221	loadk        r42   k64 ; k64 = 135
.line	221	loadk        r43   k65 ; k65 = 117
.line	221	call          r5    39     2
.line	221	call          r4     2     2
.line	221	gettable      r5    r4   k66 ; k66 = "Show"
.line	221	call          r5     1     1
.label	l91
.line	221	return        r0     1
.line	221	move          r0    r0
.line	221	move          r0    r0
.line	221	return        r0     1

.function	main/f12

.source	null
.linedefined	235
.lastlinedefined	248
.numparams	3
.is_vararg	0
.maxstacksize	31

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetHallDepotItemDataByInsID"
.constant	k1	nil
.constant	k2	"expireTS"
.constant	k3	0
.constant	k4	"log_tree"
.constant	k5	212
.constant	k6	41
.constant	k7	161
.constant	k8	219
.constant	k9	102
.constant	k10	95
.constant	k11	100
.constant	k12	132
.constant	k13	203
.constant	k14	198
.constant	k15	252
.constant	k16	105
.constant	k17	93
.constant	k18	167
.constant	k19	166
.constant	k20	53
.constant	k21	36
.constant	k22	29
.constant	k23	194
.constant	k24	253
.constant	k25	178
.constant	k26	97
.constant	k27	26
.constant	k28	184
.constant	k29	243
.constant	k30	"GetItemSource"
.constant	k31	"EWardrobeDataSource"
.constant	k32	"InheritWardrobe"
.constant	k33	"ModuleManager"
.constant	k34	"GetModule"
.constant	k35	"CommonModuleConfig"
.constant	k36	"LogicInheritSystem"
.constant	k37	"WaitingToClearData"

.line	235	getupval      r3    u0
.line	235	self          r3    r3    k0 ; k0 = "GetHallDepotItemData" (truncated)
.line	235	move          r5    r1
.line	235	call          r3     3     2
.line	235	eq             1    r3    k1 ; k1 = nil
.line	235	jmp            0   l13
.line	235	gettable      r4    r3    k2 ; k2 = "expireTS"
.line	235	eq             1    r4    k3 ; k3 = 0
.line	235	jmp            0   l45
.line	235	gettable      r4    r3    k2 ; k2 = "expireTS"
.line	235	lt             0    r4    r2
.line	235	jmp            0   l45
.label	l13
.line	235	gettabup      r4    u1    k4 ; k4 = "log_tree"
.line	235	getupval      r5    u2
.line	235	loadk         r6    k5 ; k5 = 212
.line	235	loadk         r7    k6 ; k6 = 41
.line	235	loadk         r8    k7 ; k7 = 161
.line	235	loadk         r9    k8 ; k8 = 219
.line	235	loadk        r10    k9 ; k9 = 102
.line	235	loadk        r11   k10 ; k10 = 95
.line	235	loadk        r12   k11 ; k11 = 100
.line	235	loadk        r13   k12 ; k12 = 132
.line	235	loadk        r14   k13 ; k13 = 203
.line	235	loadk        r15   k14 ; k14 = 198
.line	235	loadk        r16   k15 ; k15 = 252
.line	235	loadk        r17   k16 ; k16 = 105
.line	235	loadk        r18   k17 ; k17 = 93
.line	235	loadk        r19   k18 ; k18 = 167
.line	235	loadk        r20   k19 ; k19 = 166
.line	235	loadk        r21   k20 ; k20 = 53
.line	235	loadk        r22   k21 ; k21 = 36
.line	235	loadk        r23   k22 ; k22 = 29
.line	235	loadk        r24   k23 ; k23 = 194
.line	235	loadk        r25   k24 ; k24 = 253
.line	235	loadk        r26   k25 ; k25 = 178
.line	235	loadk        r27   k26 ; k26 = 97
.line	235	loadk        r28   k27 ; k27 = 26
.line	235	loadk        r29   k28 ; k28 = 184
.line	235	loadk        r30   k29 ; k29 = 243
.line	235	call          r5    26     2
.line	235	move          r6    r3
.line	235	call          r4     3     1
.line	235	loadbool      r4     0     0
.line	235	return        r4     2
.label	l45
.line	235	getupval      r4    u0
.line	235	self          r4    r4   k30 ; k30 = "GetItemSource"
.line	235	move          r6    r1
.line	235	call          r4     3     2
.line	235	gettabup      r5    u1   k31 ; k31 = "EWardrobeDataSource"
.line	235	gettable      r5    r5   k32 ; k32 = "InheritWardrobe"
.line	235	eq             0    r4    r5
.line	235	jmp            0   l64
.line	235	gettabup      r4    u1   k33 ; k33 = "ModuleManager"
.line	235	gettable      r4    r4   k34 ; k34 = "GetModule"
.line	235	gettabup      r5    u1   k33 ; k33 = "ModuleManager"
.line	235	gettable      r5    r5   k35 ; k35 = "CommonModuleConfig"
.line	235	gettable      r5    r5   k36 ; k36 = "LogicInheritSystem"
.line	235	call          r4     2     2
.line	235	gettable      r5    r4   k37 ; k37 = "WaitingToClearData"
.line	235	test          r5     0
.line	235	jmp            0   l64
.line	235	loadbool      r5     0     0
.line	235	return        r5     2
.label	l64
.line	235	loadbool      r4     1     0
.line	235	return        r4     2
.line	235	return        r0     1
.line	235	move          r0    r0
.line	235	move          r0    r0
.line	235	return        r0     1

.function	main/f13

.source	null
.linedefined	250
.lastlinedefined	312
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	241
.constant	k15	128
.constant	k16	17
.constant	k17	1
.constant	k18	231
.constant	k19	133
.constant	k20	108
.constant	k21	26
.constant	k22	142
.constant	k23	227
.constant	k24	209
.constant	k25	238
.constant	k26	125
.constant	k27	75
.constant	k28	210
.constant	k29	138
.constant	k30	34
.constant	k31	10
.constant	k32	4
.constant	k33	192
.constant	k34	130
.constant	k35	196
.constant	k36	246
.constant	k37	111
.constant	k38	80
.constant	k39	179
.constant	k40	155
.constant	k41	47
.constant	k42	30
.constant	k43	29
.constant	k44	252
.constant	k45	250
.constant	k46	144
.constant	k47	105
.constant	k48	"GetServerTimeInSec"
.constant	k49	"AvatarData"
.constant	k50	"GetRoleWear"
.constant	k51	nil
.constant	k52	-1
.constant	k53	"IsWearValid"
.constant	k54	"table"
.constant	k55	"insert"
.constant	k56	"RemoveRoleWearDataByIndex"
.constant	k57	"concat"
.constant	k58	146
.constant	k59	235
.constant	k60	220
.constant	k61	46
.constant	k62	82
.constant	k63	136
.constant	k64	86
.constant	k65	212
.constant	k66	150
.constant	k67	100
.constant	k68	190
.constant	k69	245
.constant	k70	165
.constant	k71	118
.constant	k72	79
.constant	k73	254
.constant	k74	151
.constant	k75	63
.constant	k76	12
.constant	k77	6
.constant	k78	147
.constant	k79	62
.constant	k80	0
.constant	k81	160
.constant	k82	240
.constant	k83	32
.constant	k84	208
.constant	k85	103
.constant	k86	134
.constant	k87	216
.constant	k88	205
.constant	k89	116
.constant	k90	95
.constant	k91	"GetHelmetSkin"
.constant	k92	"SetHelmetSkin"
.constant	k93	"GetBagSkin"
.constant	k94	"SetBagSkin"
.constant	k95	"SaveRolewearToFashionBag"
.constant	k96	"GetFashionBagUseIndex"
.constant	k97	"GetParachute"
.constant	k98	"SetParachute"
.constant	k99	"DataMgr"
.constant	k100	"defaultParachuteInsID"
.constant	k101	"GetPlanSkin"
.constant	k102	"SetPlanSkin"
.constant	k103	"defaultPlaneSkinInsID"
.constant	k104	"GetWingmanSkin"
.constant	k105	"SetWingmanSkin"
.constant	k106	"defaultWingmanSkinInsID"
.constant	k107	"next"
.constant	k108	"vehicleSkinInsIDTable"
.constant	k109	"pairs"
.constant	k110	"defaultVehicleSkinResIDTable"
.constant	k111	"defaultVehicleSkinInsIDTable"
.constant	k112	"vst_skin"
.constant	k113	"ProcPutOnVehicle"
.constant	k114	"res_id"
.constant	k115	"instid"
.constant	k116	"tonumber"
.constant	k117	"ProcessInvalidThrowObject"
.constant	k118	"ProcessInvalidBagPendants"
.constant	k119	"ModuleManager"
.constant	k120	"GetModule"
.constant	k121	"CommonModuleConfig"
.constant	k122	"logic_weapon_pendant"
.constant	k123	"ProcessInvalidPendant"

.line	250	gettabup      r2    u0    k0 ; k0 = "require"
.line	250	getupval      r3    u1
.line	250	loadk         r4    k1 ; k1 = 224
.line	250	loadk         r5    k2 ; k2 = 36
.line	250	loadk         r6    k3 ; k3 = 186
.line	250	loadk         r7    k4 ; k4 = 218
.line	250	loadk         r8    k5 ; k5 = 122
.line	250	loadk         r9    k6 ; k6 = 68
.line	250	loadk        r10    k7 ; k7 = 40
.line	250	loadk        r11    k8 ; k8 = 141
.line	250	loadk        r12    k9 ; k9 = 232
.line	250	loadk        r13   k10 ; k10 = 206
.line	250	loadk        r14   k11 ; k11 = 242
.line	250	loadk        r15   k12 ; k12 = 99
.line	250	loadk        r16   k13 ; k13 = 16
.line	250	loadk        r17   k14 ; k14 = 241
.line	250	loadk        r18   k15 ; k15 = 128
.line	250	loadk        r19    k2 ; k2 = 36
.line	250	loadk        r20   k16 ; k16 = 17
.line	250	loadk        r21   k17 ; k17 = 1
.line	250	loadk        r22    k8 ; k8 = 141
.line	250	loadk        r23   k18 ; k18 = 231
.line	250	loadk        r24   k19 ; k19 = 133
.line	250	loadk        r25   k20 ; k20 = 108
.line	250	loadk        r26   k21 ; k21 = 26
.line	250	loadk        r27   k22 ; k22 = 142
.line	250	loadk        r28   k23 ; k23 = 227
.line	250	loadk        r29   k24 ; k24 = 209
.line	250	loadk        r30   k25 ; k25 = 238
.line	250	loadk        r31   k26 ; k26 = 125
.line	250	loadk        r32   k27 ; k27 = 75
.line	250	loadk        r33   k28 ; k28 = 210
.line	250	loadk        r34   k29 ; k29 = 138
.line	250	loadk        r35   k30 ; k30 = 34
.line	250	loadk        r36   k31 ; k31 = 10
.line	250	loadk        r37   k32 ; k32 = 4
.line	250	loadk        r38   k33 ; k33 = 192
.line	250	call          r3    36     2
.line	250	call          r2     2     2
.line	250	gettabup      r3    u0    k0 ; k0 = "require"
.line	250	getupval      r4    u1
.line	250	loadk         r5    k1 ; k1 = 224
.line	250	loadk         r6    k2 ; k2 = 36
.line	250	loadk         r7    k3 ; k3 = 186
.line	250	loadk         r8    k4 ; k4 = 218
.line	250	loadk         r9    k5 ; k5 = 122
.line	250	loadk        r10    k6 ; k6 = 68
.line	250	loadk        r11    k7 ; k7 = 40
.line	250	loadk        r12   k34 ; k34 = 130
.line	250	loadk        r13    k9 ; k9 = 232
.line	250	loadk        r14   k35 ; k35 = 196
.line	250	loadk        r15   k36 ; k36 = 246
.line	250	loadk        r16   k37 ; k37 = 111
.line	250	loadk        r17   k38 ; k38 = 80
.line	250	loadk        r18   k39 ; k39 = 179
.line	250	loadk        r19   k40 ; k40 = 155
.line	250	loadk        r20   k41 ; k41 = 47
.line	250	loadk        r21   k42 ; k42 = 30
.line	250	loadk        r22   k43 ; k43 = 29
.line	250	loadk        r23   k44 ; k44 = 252
.line	250	loadk        r24   k45 ; k45 = 250
.line	250	loadk        r25   k46 ; k46 = 144
.line	250	loadk        r26   k47 ; k47 = 105
.line	250	loadk        r27   k21 ; k21 = 26
.line	250	call          r4    24     2
.line	250	call          r3     2     2
.line	250	gettable      r4    r3   k48 ; k48 = "GetServerTimeInSec"
.line	250	call          r4     1     2
.line	250	gettabup      r5    u0   k49 ; k49 = "AvatarData"
.line	250	gettable      r5    r5   k50 ; k50 = "GetRoleWear"
.line	250	call          r5     1     2
.line	250	eq             1    r5   k51 ; k51 = nil
.line	250	jmp            0   l97
.line	250	len           r6    r5
.line	250	loadk         r7   k17 ; k17 = 1
.line	250	loadk         r8   k52 ; k52 = -1
.line	250	move          r0    r0
.line	250	gettable     r10    r5    r9
.line	250	self         r11    r0   k53 ; k53 = "IsWearValid"
.line	250	move         r13   r10
.line	250	move         r14    r4
.line	250	call         r11     4     2
.line	250	test         r11     1
.line	250	jmp            0   l96
.line	250	test          r1     0
.line	250	jmp            0   l92
.line	250	gettabup     r11    u0   k54 ; k54 = "table"
.line	250	gettable     r11   r11   k55 ; k55 = "insert"
.line	250	move         r12    r1
.line	250	move         r13   r10
.line	250	call         r11     3     1
.label	l92
.line	250	gettabup     r11    u0   k49 ; k49 = "AvatarData"
.line	250	gettable     r11   r11   k56 ; k56 = "RemoveRoleWearDataBy" (truncated)
.line	250	move         r12    r9
.line	250	call         r11     2     1
.label	l96
.line	250	move          r0    r0
.label	l97
.line	250	gettabup      r6    u0    k0 ; k0 = "require"
.line	250	gettabup      r7    u0   k54 ; k54 = "table"
.line	250	gettable      r7    r7   k57 ; k57 = "concat"
.line	250	newtable      r8     1     0
.line	250	getupval      r9    u1
.line	250	loadk        r10    k1 ; k1 = 224
.line	250	loadk        r11    k2 ; k2 = 36
.line	250	loadk        r12    k3 ; k3 = 186
.line	250	loadk        r13    k4 ; k4 = 218
.line	250	loadk        r14    k5 ; k5 = 122
.line	250	loadk        r15    k6 ; k6 = 68
.line	250	loadk        r16    k7 ; k7 = 40
.line	250	loadk        r17   k58 ; k58 = 146
.line	250	loadk        r18   k59 ; k59 = 235
.line	250	loadk        r19   k60 ; k60 = 220
.line	250	loadk        r20   k45 ; k45 = 250
.line	250	loadk        r21   k61 ; k61 = 46
.line	250	loadk        r22   k62 ; k62 = 82
.line	250	loadk        r23   k11 ; k11 = 242
.line	250	loadk        r24   k63 ; k63 = 136
.line	250	loadk        r25   k41 ; k41 = 47
.line	250	loadk        r26   k13 ; k13 = 16
.line	250	loadk        r27   k64 ; k64 = 86
.line	250	loadk        r28   k65 ; k65 = 212
.line	250	loadk        r29   k25 ; k25 = 238
.line	250	loadk        r30   k66 ; k66 = 150
.line	250	loadk        r31   k67 ; k67 = 100
.line	250	loadk        r32   k32 ; k32 = 4
.line	250	loadk        r33   k68 ; k68 = 190
.line	250	loadk        r34   k69 ; k69 = 245
.line	250	loadk        r35   k60 ; k60 = 220
.line	250	loadk        r36   k70 ; k70 = 165
.line	250	loadk        r37   k71 ; k71 = 118
.line	250	loadk        r38   k72 ; k72 = 79
.line	250	loadk        r39   k73 ; k73 = 254
.line	250	loadk        r40   k74 ; k74 = 151
.line	250	loadk        r41   k75 ; k75 = 63
.line	250	loadk        r42   k76 ; k76 = 12
.line	250	loadk        r43   k77 ; k77 = 6
.line	250	loadk        r44   k24 ; k24 = 209
.line	250	loadk        r45   k73 ; k73 = 254
.line	250	loadk        r46   k78 ; k78 = 147
.line	250	loadk        r47   k79 ; k79 = 62
.line	250	loadk        r48   k80 ; k80 = 0
.line	250	loadk        r49   k81 ; k81 = 160
.line	250	call          r9    41     2
.line	250	getupval     r10    u1
.line	250	loadk        r11   k82 ; k82 = 240
.line	250	loadk        r12   k83 ; k83 = 32
.line	250	loadk        r13    k3 ; k3 = 186
.line	250	loadk        r14   k84 ; k84 = 208
.line	250	loadk        r15    k5 ; k5 = 122
.line	250	loadk        r16   k62 ; k62 = 82
.line	250	loadk        r17   k85 ; k85 = 103
.line	250	loadk        r18   k86 ; k86 = 134
.line	250	loadk        r19   k87 ; k87 = 216
.line	250	loadk        r20   k88 ; k88 = 205
.line	250	loadk        r21   k45 ; k45 = 250
.line	250	loadk        r22   k89 ; k89 = 116
.line	250	loadk        r23   k90 ; k90 = 95
.line	250	call         r10    14     0
.line	250	setlist       r8     0     1
.line	250	call          r7     2     2
.line	250	call          r6     2     2
.line	250	test          r1     0
.line	250	jmp            0  l199
.line	250	self          r7    r6   k91 ; k91 = "GetHelmetSkin"
.line	250	call          r7     2     2
.line	250	eq             1    r7   k80 ; k80 = 0
.line	250	jmp            0  l181
.line	250	self          r8    r0   k53 ; k53 = "IsWearValid"
.line	250	move         r10    r7
.line	250	move         r11    r4
.line	250	call          r8     4     2
.line	250	test          r8     1
.line	250	jmp            0  l181
.line	250	gettabup      r8    u0   k54 ; k54 = "table"
.line	250	gettable      r8    r8   k55 ; k55 = "insert"
.line	250	move          r9    r1
.line	250	move         r10    r7
.line	250	call          r8     3     1
.line	250	self          r8    r6   k92 ; k92 = "SetHelmetSkin"
.line	250	loadk        r10   k80 ; k80 = 0
.line	250	call          r8     3     1
.label	l181
.line	250	self          r8    r6   k93 ; k93 = "GetBagSkin"
.line	250	call          r8     2     2
.line	250	eq             1    r8   k80 ; k80 = 0
.line	250	jmp            0  l199
.line	250	self          r9    r0   k53 ; k53 = "IsWearValid"
.line	250	move         r11    r8
.line	250	move         r12    r4
.line	250	call          r9     4     2
.line	250	test          r9     1
.line	250	jmp            0  l199
.line	250	gettabup      r9    u0   k54 ; k54 = "table"
.line	250	gettable      r9    r9   k55 ; k55 = "insert"
.line	250	move         r10    r1
.line	250	move         r11    r8
.line	250	call          r9     3     1
.line	250	self          r9    r6   k94 ; k94 = "SetBagSkin"
.line	250	loadk        r11   k80 ; k80 = 0
.line	250	call          r9     3     1
.label	l199
.line	250	self          r7    r6   k95 ; k95 = "SaveRolewearToFashio" (truncated)
.line	250	self          r9    r6   k96 ; k96 = "GetFashionBagUseInde" (truncated)
.line	250	call          r9     2     0
.line	250	call          r7     0     1
.line	250	self          r7    r6   k97 ; k97 = "GetParachute"
.line	250	call          r7     2     2
.line	250	eq             1    r7   k80 ; k80 = 0
.line	250	jmp            0  l218
.line	250	self          r7    r0   k53 ; k53 = "IsWearValid"
.line	250	self          r9    r6   k97 ; k97 = "GetParachute"
.line	250	call          r9     2     2
.line	250	move         r10    r4
.line	250	call          r7     4     2
.line	250	test          r7     1
.line	250	jmp            0  l218
.line	250	self          r7    r6   k98 ; k98 = "SetParachute"
.line	250	gettabup      r9    u0   k99 ; k99 = "DataMgr"
.line	250	gettable      r9    r9  k100 ; k100 = "defaultParachuteInsI" (truncated)
.line	250	call          r7     3     1
.label	l218
.line	250	self          r7    r6  k101 ; k101 = "GetPlanSkin"
.line	250	call          r7     2     2
.line	250	eq             1    r7   k80 ; k80 = 0
.line	250	jmp            0  l233
.line	250	self          r7    r0   k53 ; k53 = "IsWearValid"
.line	250	self          r9    r6  k101 ; k101 = "GetPlanSkin"
.line	250	call          r9     2     2
.line	250	move         r10    r4
.line	250	call          r7     4     2
.line	250	test          r7     1
.line	250	jmp            0  l233
.line	250	self          r7    r6  k102 ; k102 = "SetPlanSkin"
.line	250	gettabup      r9    u0   k99 ; k99 = "DataMgr"
.line	250	gettable      r9    r9  k103 ; k103 = "defaultPlaneSkinInsI" (truncated)
.line	250	call          r7     3     1
.label	l233
.line	250	self          r7    r6  k104 ; k104 = "GetWingmanSkin"
.line	250	call          r7     2     2
.line	250	eq             1    r7   k80 ; k80 = 0
.line	250	jmp            0  l248
.line	250	self          r7    r0   k53 ; k53 = "IsWearValid"
.line	250	self          r9    r6  k104 ; k104 = "GetWingmanSkin"
.line	250	call          r9     2     2
.line	250	move         r10    r4
.line	250	call          r7     4     2
.line	250	test          r7     1
.line	250	jmp            0  l248
.line	250	self          r7    r6  k105 ; k105 = "SetWingmanSkin"
.line	250	gettabup      r9    u0   k99 ; k99 = "DataMgr"
.line	250	gettable      r9    r9  k106 ; k106 = "defaultWingmanSkinIn" (truncated)
.line	250	call          r7     3     1
.label	l248
.line	250	gettabup      r7    u0  k107 ; k107 = "next"
.line	250	gettabup      r8    u0   k99 ; k99 = "DataMgr"
.line	250	gettable      r8    r8  k108 ; k108 = "vehicleSkinInsIDTabl" (truncated)
.line	250	call          r7     2     2
.line	250	eq             1    r7   k51 ; k51 = nil
.line	250	jmp            0  l300
.line	250	newtable      r7     0     0
.line	250	gettabup      r8    u0  k109 ; k109 = "pairs"
.line	250	gettabup      r9    u0   k99 ; k99 = "DataMgr"
.line	250	gettable      r9    r9  k108 ; k108 = "vehicleSkinInsIDTabl" (truncated)
.line	250	call          r8     2     4
.line	250	jmp            0  l296
.line	250	gettabup     r13    u0   k99 ; k99 = "DataMgr"
.line	250	gettable     r13   r13  k110 ; k110 = "defaultVehicleSkinRe" (truncated)
.line	250	gettable     r13   r13   r11
.line	250	eq             1   r12   k80 ; k80 = 0
.line	250	jmp            0  l295
.line	250	self         r14    r0   k53 ; k53 = "IsWearValid"
.line	250	move         r16   r12
.line	250	move         r17    r4
.line	250	call         r14     4     2
.line	250	test         r14     1
.line	250	jmp            0  l295
.line	250	eq             1   r13   k51 ; k51 = nil
.line	250	jmp            0  l295
.line	250	gettabup     r14    u0   k99 ; k99 = "DataMgr"
.line	250	gettable     r14   r14  k111 ; k111 = "defaultVehicleSkinIn" (truncated)
.line	250	gettable     r14   r14   r13
.line	250	settable      r7   r11   r14
.line	250	gettabup     r15    u0   k99 ; k99 = "DataMgr"
.line	250	gettable     r15   r15  k112 ; k112 = "vst_skin"
.line	250	test         r15     0
.line	250	jmp            0  l296
.line	250	gettabup     r15    u0   k99 ; k99 = "DataMgr"
.line	250	gettable     r15   r15  k112 ; k112 = "vst_skin"
.line	250	eq             0   r15   r12
.line	250	jmp            0  l296
.line	250	gettable     r15    r2  k113 ; k113 = "ProcPutOnVehicle"
.line	250	newtable     r16     0     2
.line	250	settable     r16  k114   r13 ; k114 = "res_id"
.line	250	gettabup     r17    u0  k116 ; k116 = "tonumber"
.line	250	move         r18   r14
.line	250	call         r17     2     2
.line	250	settable     r16  k115   r17 ; k115 = "instid"
.line	250	loadbool     r17     1     0
.line	250	call         r15     3     1
.line	250	jmp            0  l296
.label	l295
.line	250	settable      r7   r11   r12
.label	l296
.line	250	move          r0    r0
.line	250	move          r0    r0
.line	250	gettabup      r8    u0   k99 ; k99 = "DataMgr"
.line	250	settable      r8  k108    r7 ; k108 = "vehicleSkinInsIDTabl" (truncated)
.label	l300
.line	250	self          r7    r6  k117 ; k117 = "ProcessInvalidThrowO" (truncated)
.line	250	call          r7     2     1
.line	250	self          r7    r6  k118 ; k118 = "ProcessInvalidBagPen" (truncated)
.line	250	call          r7     2     1
.line	250	gettabup      r7    u0  k119 ; k119 = "ModuleManager"
.line	250	gettable      r7    r7  k120 ; k120 = "GetModule"
.line	250	gettabup      r8    u0  k119 ; k119 = "ModuleManager"
.line	250	gettable      r8    r8  k121 ; k121 = "CommonModuleConfig"
.line	250	gettable      r8    r8  k122 ; k122 = "logic_weapon_pendant"
.line	250	call          r7     2     2
.line	250	self          r8    r7  k123 ; k123 = "ProcessInvalidPendan" (truncated)
.line	250	call          r8     2     1
.line	250	return        r0     1
.line	250	move          r0    r0
.line	250	return        r0     1

.function	main/f14

.source	null
.linedefined	314
.lastlinedefined	339
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CDataTable"
.constant	k1	"GetTableData"
.constant	k2	202
.constant	k3	60
.constant	k4	182
.constant	k5	210
.constant	k6	nil
.constant	k7	0
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	224
.constant	k12	36
.constant	k13	186
.constant	k14	218
.constant	k15	122
.constant	k16	68
.constant	k17	40
.constant	k18	141
.constant	k19	232
.constant	k20	206
.constant	k21	242
.constant	k22	99
.constant	k23	16
.constant	k24	252
.constant	k25	153
.constant	k26	39
.constant	k27	7
.constant	k28	25
.constant	k29	209
.constant	k30	161
.constant	k31	169
.constant	k32	111
.constant	k33	18
.constant	k34	180
.constant	k35	251
.constant	k36	253
.constant	k37	226
.constant	k38	94
.constant	k39	225
.constant	k40	158
.constant	k41	47
.constant	k42	55
.constant	k43	17
.constant	k44	195
.constant	k45	250
.constant	k46	188
.constant	k47	117
.constant	k48	10
.constant	k49	177
.constant	k50	230
.constant	k51	58
.constant	k52	"IsWeapon"
.constant	k53	"ItemType"
.constant	k54	6
.constant	k55	"ENUM_ITEM_TYPE"
.constant	k56	"Extra"
.constant	k57	"ItemSubType"
.constant	k58	401
.constant	k59	1
.constant	k60	402
.constant	k61	2
.constant	k62	403
.constant	k63	3
.constant	k64	404
.constant	k65	4
.constant	k66	405
.constant	k67	5

.line	314	gettabup      r2    u0    k0 ; k0 = "CDataTable"
.line	314	gettable      r2    r2    k1 ; k1 = "GetTableData"
.line	314	getupval      r3    u1
.line	314	loadk         r4    k2 ; k2 = 202
.line	314	loadk         r5    k3 ; k3 = 60
.line	314	loadk         r6    k4 ; k4 = 182
.line	314	loadk         r7    k5 ; k5 = 210
.line	314	call          r3     5     2
.line	314	move          r4    r1
.line	314	call          r2     3     2
.line	314	eq             0    r2    k6 ; k6 = nil
.line	314	jmp            0   l15
.line	314	loadk         r3    k7 ; k7 = 0
.line	314	return        r3     2
.label	l15
.line	314	gettabup      r3    u0    k8 ; k8 = "require"
.line	314	gettabup      r4    u0    k9 ; k9 = "table"
.line	314	gettable      r4    r4   k10 ; k10 = "concat"
.line	314	newtable      r5     1     0
.line	314	getupval      r6    u1
.line	314	loadk         r7   k11 ; k11 = 224
.line	314	loadk         r8   k12 ; k12 = 36
.line	314	loadk         r9   k13 ; k13 = 186
.line	314	loadk        r10   k14 ; k14 = 218
.line	314	loadk        r11   k15 ; k15 = 122
.line	314	loadk        r12   k16 ; k16 = 68
.line	314	loadk        r13   k17 ; k17 = 40
.line	314	loadk        r14   k18 ; k18 = 141
.line	314	loadk        r15   k19 ; k19 = 232
.line	314	loadk        r16   k20 ; k20 = 206
.line	314	loadk        r17   k21 ; k21 = 242
.line	314	loadk        r18   k22 ; k22 = 99
.line	314	loadk        r19   k23 ; k23 = 16
.line	314	loadk        r20   k24 ; k24 = 252
.line	314	loadk        r21   k25 ; k25 = 153
.line	314	loadk        r22   k26 ; k26 = 39
.line	314	loadk        r23   k27 ; k27 = 7
.line	314	loadk        r24   k28 ; k28 = 25
.line	314	loadk        r25   k29 ; k29 = 209
.line	314	loadk        r26   k30 ; k30 = 161
.line	314	loadk        r27   k31 ; k31 = 169
.line	314	loadk        r28   k32 ; k32 = 111
.line	314	loadk        r29   k33 ; k33 = 18
.line	314	loadk        r30   k34 ; k34 = 180
.line	314	loadk        r31   k35 ; k35 = 251
.line	314	loadk        r32   k36 ; k36 = 253
.line	314	loadk        r33   k37 ; k37 = 226
.line	314	loadk        r34   k22 ; k22 = 99
.line	314	loadk        r35   k38 ; k38 = 94
.line	314	loadk        r36   k39 ; k39 = 225
.line	314	loadk        r37   k40 ; k40 = 158
.line	314	loadk        r38   k41 ; k41 = 47
.line	314	loadk        r39   k42 ; k42 = 55
.line	314	loadk        r40   k43 ; k43 = 17
.line	314	loadk        r41   k44 ; k44 = 195
.line	314	loadk        r42   k45 ; k45 = 250
.line	314	loadk        r43   k46 ; k46 = 188
.line	314	loadk        r44   k47 ; k47 = 117
.line	314	loadk        r45   k48 ; k48 = 10
.line	314	loadk        r46   k49 ; k49 = 177
.line	314	call          r6    41     2
.line	314	getupval      r7    u1
.line	314	loadk         r8   k50 ; k50 = 230
.line	314	loadk         r9   k51 ; k51 = 58
.line	314	call          r7     3     0
.line	314	setlist       r5     0     1
.line	314	call          r4     2     2
.line	314	call          r3     2     2
.line	314	gettable      r4    r3   k52 ; k52 = "IsWeapon"
.line	314	gettable      r5    r2   k53 ; k53 = "ItemType"
.line	314	call          r4     2     2
.line	314	test          r4     0
.line	314	jmp            0   l75
.line	314	loadk         r4   k54 ; k54 = 6
.line	314	return        r4     2
.label	l75
.line	314	gettable      r4    r2   k53 ; k53 = "ItemType"
.line	314	gettabup      r5    u0   k55 ; k55 = "ENUM_ITEM_TYPE"
.line	314	gettable      r5    r5   k56 ; k56 = "Extra"
.line	314	eq             0    r4    r5
.line	314	jmp            0  l112
.line	314	gettable      r4    r2   k57 ; k57 = "ItemSubType"
.line	314	eq             0    r4   k58 ; k58 = 401
.line	314	jmp            0   l86
.line	314	loadk         r4   k59 ; k59 = 1
.line	314	return        r4     2
.line	314	jmp            0  l112
.label	l86
.line	314	gettable      r4    r2   k57 ; k57 = "ItemSubType"
.line	314	eq             0    r4   k60 ; k60 = 402
.line	314	jmp            0   l92
.line	314	loadk         r4   k61 ; k61 = 2
.line	314	return        r4     2
.line	314	jmp            0  l112
.label	l92
.line	314	gettable      r4    r2   k57 ; k57 = "ItemSubType"
.line	314	eq             0    r4   k62 ; k62 = 403
.line	314	jmp            0   l98
.line	314	loadk         r4   k63 ; k63 = 3
.line	314	return        r4     2
.line	314	jmp            0  l112
.label	l98
.line	314	gettable      r4    r2   k57 ; k57 = "ItemSubType"
.line	314	eq             0    r4   k64 ; k64 = 404
.line	314	jmp            0  l104
.line	314	loadk         r4   k65 ; k65 = 4
.line	314	return        r4     2
.line	314	jmp            0  l112
.label	l104
.line	314	gettable      r4    r2   k57 ; k57 = "ItemSubType"
.line	314	eq             0    r4   k66 ; k66 = 405
.line	314	jmp            0  l110
.line	314	loadk         r4   k67 ; k67 = 5
.line	314	return        r4     2
.line	314	jmp            0  l112
.label	l110
.line	314	loadk         r4    k7 ; k7 = 0
.line	314	return        r4     2
.label	l112
.line	314	loadk         r4    k7 ; k7 = 0
.line	314	return        r4     2
.line	314	return        r0     1
.line	314	move          r0    r0
.line	314	return        r0     1

.function	main/f15

.source	null
.linedefined	341
.lastlinedefined	351
.numparams	1
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetHallDepotItemDataByResID"
.constant	k1	"insID"
.constant	k2	"require"
.constant	k3	224
.constant	k4	39
.constant	k5	190
.constant	k6	210
.constant	k7	123
.constant	k8	94
.constant	k9	40
.constant	k10	149
.constant	k11	230
.constant	k12	203
.constant	k13	247
.constant	k14	101
.constant	k15	97
.constant	k16	232
.constant	k17	155
.constant	k18	47
.constant	k19	31
.constant	k20	"AvatarData"
.constant	k21	"GetRoleWear"
.constant	k22	"Find"
.constant	k23	0

.line	341	getupval      r1    u0
.line	341	self          r1    r1    k0 ; k0 = "GetHallDepotItemData" (truncated)
.line	341	move          r3    r0
.line	341	call          r1     3     2
.line	341	testset       r2    r1     0
.line	341	jmp            0    l8
.line	341	gettable      r2    r1    k1 ; k1 = "insID"
.label	l8
.line	341	gettabup      r3    u1    k2 ; k2 = "require"
.line	341	getupval      r4    u2
.line	341	loadk         r5    k3 ; k3 = 224
.line	341	loadk         r6    k4 ; k4 = 39
.line	341	loadk         r7    k5 ; k5 = 190
.line	341	loadk         r8    k6 ; k6 = 210
.line	341	loadk         r9    k7 ; k7 = 123
.line	341	loadk        r10    k8 ; k8 = 94
.line	341	loadk        r11    k9 ; k9 = 40
.line	341	loadk        r12   k10 ; k10 = 149
.line	341	loadk        r13   k11 ; k11 = 230
.line	341	loadk        r14   k12 ; k12 = 203
.line	341	loadk        r15   k13 ; k13 = 247
.line	341	loadk        r16   k14 ; k14 = 101
.line	341	loadk        r17   k15 ; k15 = 97
.line	341	loadk        r18   k16 ; k16 = 232
.line	341	loadk        r19   k17 ; k17 = 155
.line	341	loadk        r20   k18 ; k18 = 47
.line	341	loadk        r21   k19 ; k19 = 31
.line	341	call          r4    18     2
.line	341	call          r3     2     2
.line	341	test          r2     0
.line	341	jmp            0   l42
.line	341	gettabup      r4    u1   k20 ; k20 = "AvatarData"
.line	341	gettable      r4    r4   k21 ; k21 = "GetRoleWear"
.line	341	call          r4     1     2
.line	341	gettable      r5    r3   k22 ; k22 = "Find"
.line	341	move          r6    r4
.line	341	move          r7    r2
.line	341	call          r5     3     2
.line	341	lt             0   k23    r5 ; k23 = 0
.line	341	jmp            0   l42
.line	341	loadbool      r5     1     0
.line	341	return        r5     2
.label	l42
.line	341	return        r0     1
.line	341	move          r0    r0
.line	341	return        r0     1

.function	main/f16

.source	null
.linedefined	353
.lastlinedefined	363
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	163
.constant	k5	104
.constant	k6	132
.constant	k7	222
.constant	k8	102
.constant	k9	84
.constant	k10	116
.constant	k11	142
.constant	k12	229
.constant	k13	204
.constant	k14	215
.constant	k15	111
.constant	k16	89
.constant	k17	244
.constant	k18	140
.constant	k19	124
.constant	k20	4
.constant	k21	25
.constant	k22	209
.constant	k23	235
.constant	k24	150
.constant	k25	20
.constant	k26	180
.constant	k27	200
.constant	k28	201
.constant	k29	254
.constant	k30	100
.constant	k31	65
.constant	k32	227
.constant	k33	160
.constant	k34	50
.constant	k35	2
.constant	k36	28
.constant	k37	210
.constant	k38	192
.constant	k39	134
.constant	k40	117
.constant	k41	23
.constant	k42	239
.constant	k43	189
.constant	k44	208
.constant	k45	52
.constant	k46	114
.constant	k47	234
.constant	k48	237
.constant	k49	250
.constant	k50	95
.constant	k51	"resID"
.constant	k52	"res_id"
.constant	k53	"log_warning"
.constant	k54	58
.constant	k55	182
.constant	k56	93
.constant	k57	60
.constant	k58	193
.constant	k59	"tostring"
.constant	k60	"wardrobe_puton_req"
.constant	k61	"ins_id"
.constant	k62	"insID"
.constant	k63	"ModuleManager"
.constant	k64	"GetModule"
.constant	k65	"LobbyModuleConfig"
.constant	k66	"golden_suit_module"
.constant	k67	"ModifyVehicleWhenPutOn"

.line	353	test          r1     1
.line	353	jmp            0   l71
.line	353	gettabup      r2    u0    k0 ; k0 = "log"
.line	353	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	353	test          r3     0
.line	353	jmp            0   l69
.line	353	gettabup      r3    u0    k2 ; k2 = "table"
.line	353	gettable      r3    r3    k3 ; k3 = "concat"
.line	353	newtable      r4     1     0
.line	353	getupval      r5    u1
.line	353	loadk         r6    k4 ; k4 = 163
.line	353	loadk         r7    k5 ; k5 = 104
.line	353	loadk         r8    k6 ; k6 = 132
.line	353	loadk         r9    k7 ; k7 = 222
.line	353	loadk        r10    k8 ; k8 = 102
.line	353	loadk        r11    k9 ; k9 = 84
.line	353	loadk        r12   k10 ; k10 = 116
.line	353	loadk        r13   k11 ; k11 = 142
.line	353	loadk        r14   k12 ; k12 = 229
.line	353	loadk        r15   k13 ; k13 = 204
.line	353	loadk        r16   k14 ; k14 = 215
.line	353	loadk        r17   k15 ; k15 = 111
.line	353	loadk        r18   k16 ; k16 = 89
.line	353	loadk        r19   k17 ; k17 = 244
.line	353	loadk        r20   k18 ; k18 = 140
.line	353	loadk        r21   k19 ; k19 = 124
.line	353	loadk        r22   k20 ; k20 = 4
.line	353	loadk        r23   k21 ; k21 = 25
.line	353	loadk        r24   k22 ; k22 = 209
.line	353	loadk        r25   k23 ; k23 = 235
.line	353	loadk        r26   k24 ; k24 = 150
.line	353	loadk        r27   k15 ; k15 = 111
.line	353	loadk        r28   k25 ; k25 = 20
.line	353	loadk        r29   k26 ; k26 = 180
.line	353	loadk        r30   k27 ; k27 = 200
.line	353	loadk        r31   k28 ; k28 = 201
.line	353	loadk        r32   k29 ; k29 = 254
.line	353	loadk        r33   k30 ; k30 = 100
.line	353	loadk        r34   k31 ; k31 = 65
.line	353	loadk        r35   k32 ; k32 = 227
.line	353	loadk        r36   k33 ; k33 = 160
.line	353	loadk        r37   k34 ; k34 = 50
.line	353	loadk        r38   k35 ; k35 = 2
.line	353	loadk        r39   k36 ; k36 = 28
.line	353	loadk        r40   k37 ; k37 = 210
.line	353	loadk        r41   k38 ; k38 = 192
.line	353	loadk        r42   k39 ; k39 = 134
.line	353	loadk        r43   k40 ; k40 = 117
.line	353	loadk        r44   k41 ; k41 = 23
.line	353	loadk        r45   k42 ; k42 = 239
.line	353	call          r5    41     2
.line	353	getupval      r6    u1
.line	353	loadk         r7    k4 ; k4 = 163
.line	353	loadk         r8    k5 ; k5 = 104
.line	353	loadk         r9   k43 ; k43 = 189
.line	353	loadk        r10   k44 ; k44 = 208
.line	353	loadk        r11   k45 ; k45 = 52
.line	353	loadk        r12   k16 ; k16 = 89
.line	353	loadk        r13   k46 ; k46 = 114
.line	353	loadk        r14    k6 ; k6 = 132
.line	353	loadk        r15   k47 ; k47 = 234
.line	353	loadk        r16   k48 ; k48 = 237
.line	353	loadk        r17   k49 ; k49 = 250
.line	353	loadk        r18   k10 ; k10 = 116
.line	353	loadk        r19   k50 ; k50 = 95
.line	353	call          r6    14     0
.line	353	setlist       r4     0     1
.line	353	call          r3     2     2
.label	l69
.line	353	call          r2     2     1
.line	353	return        r0     1
.label	l71
.line	353	gettable      r2    r1   k51 ; k51 = "resID"
.line	353	test          r2     1
.line	353	jmp            0   l75
.line	353	gettable      r2    r1   k52 ; k52 = "res_id"
.label	l75
.line	353	gettabup      r3    u0   k53 ; k53 = "log_warning"
.line	353	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	353	test          r4     0
.line	353	jmp            0  l140
.line	353	gettabup      r4    u0    k2 ; k2 = "table"
.line	353	gettable      r4    r4    k3 ; k3 = "concat"
.line	353	newtable      r5     1     0
.line	353	getupval      r6    u1
.line	353	loadk         r7    k4 ; k4 = 163
.line	353	loadk         r8    k5 ; k5 = 104
.line	353	loadk         r9    k6 ; k6 = 132
.line	353	loadk        r10    k7 ; k7 = 222
.line	353	loadk        r11    k8 ; k8 = 102
.line	353	loadk        r12    k9 ; k9 = 84
.line	353	loadk        r13   k10 ; k10 = 116
.line	353	loadk        r14   k11 ; k11 = 142
.line	353	loadk        r15   k12 ; k12 = 229
.line	353	loadk        r16   k13 ; k13 = 204
.line	353	loadk        r17   k14 ; k14 = 215
.line	353	loadk        r18   k15 ; k15 = 111
.line	353	loadk        r19   k16 ; k16 = 89
.line	353	loadk        r20   k17 ; k17 = 244
.line	353	loadk        r21   k18 ; k18 = 140
.line	353	loadk        r22   k19 ; k19 = 124
.line	353	loadk        r23   k20 ; k20 = 4
.line	353	loadk        r24   k21 ; k21 = 25
.line	353	loadk        r25   k22 ; k22 = 209
.line	353	loadk        r26   k23 ; k23 = 235
.line	353	loadk        r27   k24 ; k24 = 150
.line	353	loadk        r28   k15 ; k15 = 111
.line	353	loadk        r29   k25 ; k25 = 20
.line	353	loadk        r30   k26 ; k26 = 180
.line	353	loadk        r31   k27 ; k27 = 200
.line	353	loadk        r32   k28 ; k28 = 201
.line	353	loadk        r33   k29 ; k29 = 254
.line	353	loadk        r34   k30 ; k30 = 100
.line	353	loadk        r35   k31 ; k31 = 65
.line	353	loadk        r36   k32 ; k32 = 227
.line	353	loadk        r37   k33 ; k33 = 160
.line	353	loadk        r38   k34 ; k34 = 50
.line	353	loadk        r39   k35 ; k35 = 2
.line	353	loadk        r40   k36 ; k36 = 28
.line	353	loadk        r41   k37 ; k37 = 210
.line	353	loadk        r42   k38 ; k38 = 192
.line	353	loadk        r43   k39 ; k39 = 134
.line	353	loadk        r44   k40 ; k40 = 117
.line	353	loadk        r45   k41 ; k41 = 23
.line	353	loadk        r46   k42 ; k42 = 239
.line	353	call          r6    41     2
.line	353	getupval      r7    u1
.line	353	loadk         r8    k4 ; k4 = 163
.line	353	loadk         r9   k54 ; k54 = 58
.line	353	loadk        r10   k55 ; k55 = 182
.line	353	loadk        r11   k13 ; k13 = 204
.line	353	loadk        r12   k56 ; k56 = 93
.line	353	loadk        r13    k9 ; k9 = 84
.line	353	loadk        r14   k57 ; k57 = 60
.line	353	loadk        r15   k58 ; k58 = 193
.line	353	call          r7     9     0
.line	353	setlist       r5     0     1
.line	353	call          r4     2     2
.line	353	gettabup      r5    u0   k59 ; k59 = "tostring"
.line	353	move          r6    r2
.line	353	call          r5     2     2
.line	353	concat        r4    r4    r5
.label	l140
.line	353	call          r3     2     1
.line	353	self          r3    r0   k60 ; k60 = "wardrobe_puton_req"
.line	353	gettable      r5    r1   k61 ; k61 = "ins_id"
.line	353	test          r5     1
.line	353	jmp            0  l146
.line	353	gettable      r5    r1   k62 ; k62 = "insID"
.label	l146
.line	353	call          r3     3     1
.line	353	gettabup      r3    u0   k63 ; k63 = "ModuleManager"
.line	353	gettable      r3    r3   k64 ; k64 = "GetModule"
.line	353	gettabup      r4    u0   k63 ; k63 = "ModuleManager"
.line	353	gettable      r4    r4   k65 ; k65 = "LobbyModuleConfig"
.line	353	gettable      r4    r4   k66 ; k66 = "golden_suit_module"
.line	353	call          r3     2     2
.line	353	self          r4    r3   k67 ; k67 = "ModifyVehicleWhenPut" (truncated)
.line	353	move          r6    r2
.line	353	call          r4     3     1
.line	353	return        r0     1
.line	353	move          r0    r0
.line	353	move          r0    r0
.line	353	move          r0    r0
.line	353	return        r0     1

.function	main/f17

.source	null
.linedefined	365
.lastlinedefined	379
.numparams	3
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log_warning"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	212
.constant	k5	41
.constant	k6	161
.constant	k7	219
.constant	k8	102
.constant	k9	95
.constant	k10	100
.constant	k11	132
.constant	k12	203
.constant	k13	198
.constant	k14	252
.constant	k15	105
.constant	k16	93
.constant	k17	167
.constant	k18	152
.constant	k19	39
.constant	k20	1
.constant	k21	28
.constant	k22	209
.constant	k23	224
.constant	k24	134
.constant	k25	101
.constant	k26	226
.constant	k27	205
.constant	k28	228
.constant	k29	126
.constant	k30	113
.constant	k31	255
.constant	k32	154
.constant	k33	77
.constant	k34	72
.constant	k35	147
.constant	k36	241
.constant	k37	155
.constant	k38	48
.constant	k39	15
.constant	k40	175
.constant	k41	240
.constant	k42	151
.constant	k43	"log"
.constant	k44	183
.constant	k45	159
.constant	k46	96
.constant	k47	85
.constant	k48	117
.constant	k49	149
.constant	k50	222
.constant	k51	250
.constant	k52	114
.constant	k53	90
.constant	k54	239
.constant	k55	128
.constant	k56	36
.constant	k57	22
.constant	k58	88
.constant	k59	238
.constant	k60	150
.constant	k61	4
.constant	k62	190
.constant	k63	245
.constant	k64	220
.constant	k65	91
.constant	k66	249
.constant	k67	144
.constant	k68	56
.constant	k69	60
.constant	k70	26
.constant	k71	214
.constant	k72	121
.constant	k73	8
.constant	k74	178
.constant	k75	202
.constant	k76	12
.constant	k77	243
.constant	k78	"tostring"
.constant	k79	"require"
.constant	k80	186
.constant	k81	218
.constant	k82	122
.constant	k83	68
.constant	k84	40
.constant	k85	146
.constant	k86	235
.constant	k87	46
.constant	k88	82
.constant	k89	242
.constant	k90	136
.constant	k91	47
.constant	k92	16
.constant	k93	86
.constant	k94	251
.constant	k95	145
.constant	k96	2
.constant	k97	236
.constant	k98	210
.constant	k99	135
.constant	k100	37
.constant	k101	199
.constant	k102	"relicInfoList"
.constant	k103	"DataMgr"
.constant	k104	"roleData"
.constant	k105	"uid"
.constant	k106	"status"
.constant	k107	143
.constant	k108	221
.constant	k109	111
.constant	k110	76
.constant	k111	246
.constant	k112	193
.constant	k113	23
.constant	k114	215
.constant	k115	207
.constant	k116	234
.constant	k117	254
.constant	k118	197
.constant	k119	158
.constant	k120	7
.constant	k121	237
.constant	k122	"send_wear_gold_dress_req"
.constant	k123	"wearID"
.constant	k124	192
.constant	k125	216
.constant	k126	116
.constant	k127	124
.constant	k128	157
.constant	k129	51
.constant	k130	43
.constant	k131	9
.constant	k132	20
.constant	k133	"send_depot_put_on_req"
.constant	k134	"tonumber"

.line	365	test          r1     1
.line	365	jmp            0   l61
.line	365	gettabup      r3    u0    k0 ; k0 = "log_warning"
.line	365	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	365	test          r4     0
.line	365	jmp            0   l59
.line	365	gettabup      r4    u0    k2 ; k2 = "table"
.line	365	gettable      r4    r4    k3 ; k3 = "concat"
.line	365	newtable      r5     1     0
.line	365	getupval      r6    u1
.line	365	loadk         r7    k4 ; k4 = 212
.line	365	loadk         r8    k5 ; k5 = 41
.line	365	loadk         r9    k6 ; k6 = 161
.line	365	loadk        r10    k7 ; k7 = 219
.line	365	loadk        r11    k8 ; k8 = 102
.line	365	loadk        r12    k9 ; k9 = 95
.line	365	loadk        r13   k10 ; k10 = 100
.line	365	loadk        r14   k11 ; k11 = 132
.line	365	loadk        r15   k12 ; k12 = 203
.line	365	loadk        r16   k13 ; k13 = 198
.line	365	loadk        r17   k14 ; k14 = 252
.line	365	loadk        r18   k15 ; k15 = 105
.line	365	loadk        r19   k16 ; k16 = 93
.line	365	loadk        r20   k17 ; k17 = 167
.line	365	loadk        r21   k18 ; k18 = 152
.line	365	loadk        r22   k19 ; k19 = 39
.line	365	loadk        r23   k20 ; k20 = 1
.line	365	loadk        r24   k21 ; k21 = 28
.line	365	loadk        r25   k22 ; k22 = 209
.line	365	loadk        r26   k23 ; k23 = 224
.line	365	loadk        r27   k24 ; k24 = 134
.line	365	loadk        r28   k25 ; k25 = 101
.line	365	loadk        r29    k5 ; k5 = 41
.line	365	loadk        r30    k6 ; k6 = 161
.line	365	loadk        r31   k26 ; k26 = 226
.line	365	loadk        r32   k27 ; k27 = 205
.line	365	loadk        r33   k28 ; k28 = 228
.line	365	loadk        r34   k29 ; k29 = 126
.line	365	loadk        r35   k30 ; k30 = 113
.line	365	loadk        r36   k31 ; k31 = 255
.line	365	loadk        r37   k32 ; k32 = 154
.line	365	loadk        r38   k19 ; k19 = 39
.line	365	loadk        r39   k33 ; k33 = 77
.line	365	loadk        r40   k34 ; k34 = 72
.line	365	loadk        r41   k35 ; k35 = 147
.line	365	loadk        r42   k36 ; k36 = 241
.line	365	loadk        r43   k37 ; k37 = 155
.line	365	loadk        r44   k38 ; k38 = 48
.line	365	loadk        r45   k39 ; k39 = 15
.line	365	loadk        r46   k40 ; k40 = 175
.line	365	call          r6    41     2
.line	365	getupval      r7    u1
.line	365	loadk         r8   k41 ; k41 = 240
.line	365	loadk         r9   k20 ; k20 = 1
.line	365	loadk        r10   k42 ; k42 = 151
.line	365	call          r7     4     0
.line	365	setlist       r5     0     1
.line	365	call          r4     2     2
.label	l59
.line	365	call          r3     2     1
.line	365	return        r0     1
.label	l61
.line	365	gettabup      r3    u0   k43 ; k43 = "log"
.line	365	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	365	test          r4     0
.line	365	jmp            0  l121
.line	365	gettabup      r4    u0    k2 ; k2 = "table"
.line	365	gettable      r4    r4    k3 ; k3 = "concat"
.line	365	newtable      r5     1     0
.line	365	getupval      r6    u1
.line	365	loadk         r7   k28 ; k28 = 228
.line	365	loadk         r8   k19 ; k19 = 39
.line	365	loadk         r9   k44 ; k44 = 183
.line	365	loadk        r10   k45 ; k45 = 159
.line	365	loadk        r11   k46 ; k46 = 96
.line	365	loadk        r12   k47 ; k47 = 85
.line	365	loadk        r13   k48 ; k48 = 117
.line	365	loadk        r14   k49 ; k49 = 149
.line	365	loadk        r15   k17 ; k17 = 167
.line	365	loadk        r16   k50 ; k50 = 222
.line	365	loadk        r17   k51 ; k51 = 250
.line	365	loadk        r18   k52 ; k52 = 114
.line	365	loadk        r19   k53 ; k53 = 90
.line	365	loadk        r20   k54 ; k54 = 239
.line	365	loadk        r21   k55 ; k55 = 128
.line	365	loadk        r22   k56 ; k56 = 36
.line	365	loadk        r23   k57 ; k57 = 22
.line	365	loadk        r24   k58 ; k58 = 88
.line	365	loadk        r25    k4 ; k4 = 212
.line	365	loadk        r26   k59 ; k59 = 238
.line	365	loadk        r27   k60 ; k60 = 150
.line	365	loadk        r28   k10 ; k10 = 100
.line	365	loadk        r29   k61 ; k61 = 4
.line	365	loadk        r30   k62 ; k62 = 190
.line	365	loadk        r31   k63 ; k63 = 245
.line	365	loadk        r32   k64 ; k64 = 220
.line	365	loadk        r33    k4 ; k4 = 212
.line	365	loadk        r34   k46 ; k46 = 96
.line	365	loadk        r35   k65 ; k65 = 91
.line	365	loadk        r36   k66 ; k66 = 249
.line	365	loadk        r37   k67 ; k67 = 144
.line	365	loadk        r38   k68 ; k68 = 56
.line	365	loadk        r39   k69 ; k69 = 60
.line	365	loadk        r40   k70 ; k70 = 26
.line	365	loadk        r41   k71 ; k71 = 214
.line	365	loadk        r42   k59 ; k59 = 238
.line	365	loadk        r43    k4 ; k4 = 212
.line	365	loadk        r44   k72 ; k72 = 121
.line	365	loadk        r45   k73 ; k73 = 8
.line	365	loadk        r46   k74 ; k74 = 178
.line	365	call          r6    41     2
.line	365	getupval      r7    u1
.line	365	loadk         r8   k75 ; k75 = 202
.line	365	loadk         r9   k76 ; k76 = 12
.line	365	loadk        r10   k77 ; k77 = 243
.line	365	call          r7     4     0
.line	365	setlist       r5     0     1
.line	365	call          r4     2     2
.line	365	gettabup      r5    u0   k78 ; k78 = "tostring"
.line	365	move          r6    r1
.line	365	call          r5     2     2
.line	365	concat        r4    r4    r5
.label	l121
.line	365	call          r3     2     1
.line	365	gettabup      r3    u0   k79 ; k79 = "require"
.line	365	getupval      r4    u1
.line	365	loadk         r5   k23 ; k23 = 224
.line	365	loadk         r6   k56 ; k56 = 36
.line	365	loadk         r7   k80 ; k80 = 186
.line	365	loadk         r8   k81 ; k81 = 218
.line	365	loadk         r9   k82 ; k82 = 122
.line	365	loadk        r10   k83 ; k83 = 68
.line	365	loadk        r11   k84 ; k84 = 40
.line	365	loadk        r12   k85 ; k85 = 146
.line	365	loadk        r13   k86 ; k86 = 235
.line	365	loadk        r14   k64 ; k64 = 220
.line	365	loadk        r15   k51 ; k51 = 250
.line	365	loadk        r16   k87 ; k87 = 46
.line	365	loadk        r17   k88 ; k88 = 82
.line	365	loadk        r18   k89 ; k89 = 242
.line	365	loadk        r19   k90 ; k90 = 136
.line	365	loadk        r20   k91 ; k91 = 47
.line	365	loadk        r21   k92 ; k92 = 16
.line	365	loadk        r22   k93 ; k93 = 86
.line	365	loadk        r23   k94 ; k94 = 251
.line	365	loadk        r24   k64 ; k64 = 220
.line	365	loadk        r25   k95 ; k95 = 145
.line	365	loadk        r26   k15 ; k15 = 105
.line	365	loadk        r27   k96 ; k96 = 2
.line	365	loadk        r28   k31 ; k31 = 255
.line	365	loadk        r29   k94 ; k94 = 251
.line	365	loadk        r30   k71 ; k71 = 214
.line	365	loadk        r31   k97 ; k97 = 236
.line	365	loadk        r32   k72 ; k72 = 121
.line	365	loadk        r33   k33 ; k33 = 77
.line	365	loadk        r34   k98 ; k98 = 210
.line	365	loadk        r35   k99 ; k99 = 135
.line	365	loadk        r36  k100 ; k100 = 37
.line	365	loadk        r37   k57 ; k57 = 22
.line	365	loadk        r38   k20 ; k20 = 1
.line	365	loadk        r39  k101 ; k101 = 199
.line	365	call          r4    36     2
.line	365	call          r3     2     2
.line	365	gettable      r4    r3  k102 ; k102 = "relicInfoList"
.line	365	gettabup      r5    u0  k103 ; k103 = "DataMgr"
.line	365	gettable      r5    r5  k104 ; k104 = "roleData"
.line	365	gettable      r5    r5  k105 ; k105 = "uid"
.line	365	gettable      r4    r4    r5
.line	365	test          r4     0
.line	365	jmp            0  l215
.line	365	gettable      r5    r4  k106 ; k106 = "status"
.line	365	test          r5     0
.line	365	jmp            0  l215
.line	365	gettabup      r5    u0   k79 ; k79 = "require"
.line	365	getupval      r6    u1
.line	365	loadk         r7   k23 ; k23 = 224
.line	365	loadk         r8   k56 ; k56 = 36
.line	365	loadk         r9   k80 ; k80 = 186
.line	365	loadk        r10   k81 ; k81 = 218
.line	365	loadk        r11   k82 ; k82 = 122
.line	365	loadk        r12   k83 ; k83 = 68
.line	365	loadk        r13   k84 ; k84 = 40
.line	365	loadk        r14  k107 ; k107 = 143
.line	365	loadk        r15   k26 ; k26 = 226
.line	365	loadk        r16  k108 ; k108 = 221
.line	365	loadk        r17   k97 ; k97 = 236
.line	365	loadk        r18  k109 ; k109 = 111
.line	365	loadk        r19  k110 ; k110 = 76
.line	365	loadk        r20  k111 ; k111 = 246
.line	365	loadk        r21  k112 ; k112 = 193
.line	365	loadk        r22   k57 ; k57 = 22
.line	365	loadk        r23   k20 ; k20 = 1
.line	365	loadk        r24  k113 ; k113 = 23
.line	365	loadk        r25  k114 ; k114 = 215
.line	365	loadk        r26   k23 ; k23 = 224
.line	365	loadk        r27   k99 ; k99 = 135
.line	365	loadk        r28  k109 ; k109 = 111
.line	365	loadk        r29   k70 ; k70 = 26
.line	365	loadk        r30   k31 ; k31 = 255
.line	365	loadk        r31  k115 ; k115 = 207
.line	365	loadk        r32  k116 ; k116 = 234
.line	365	loadk        r33  k117 ; k117 = 254
.line	365	loadk        r34   k72 ; k72 = 121
.line	365	loadk        r35   k53 ; k53 = 90
.line	365	loadk        r36  k118 ; k118 = 197
.line	365	loadk        r37  k119 ; k119 = 158
.line	365	loadk        r38   k68 ; k68 = 56
.line	365	loadk        r39  k120 ; k120 = 7
.line	365	loadk        r40   k61 ; k61 = 4
.line	365	loadk        r41   k71 ; k71 = 214
.line	365	loadk        r42  k121 ; k121 = 237
.line	365	call          r6    37     2
.line	365	call          r5     2     2
.line	365	gettable      r6    r5  k122 ; k122 = "send_wear_gold_dress" (truncated)
.line	365	loadk         r7   k20 ; k20 = 1
.line	365	gettable      r8    r4  k123 ; k123 = "wearID"
.line	365	call          r6     3     1
.label	l215
.line	365	gettabup      r5    u0   k79 ; k79 = "require"
.line	365	getupval      r6    u1
.line	365	loadk         r7   k23 ; k23 = 224
.line	365	loadk         r8   k56 ; k56 = 36
.line	365	loadk         r9   k80 ; k80 = 186
.line	365	loadk        r10   k81 ; k81 = 218
.line	365	loadk        r11   k82 ; k82 = 122
.line	365	loadk        r12   k83 ; k83 = 68
.line	365	loadk        r13   k84 ; k84 = 40
.line	365	loadk        r14  k107 ; k107 = 143
.line	365	loadk        r15   k26 ; k26 = 226
.line	365	loadk        r16  k108 ; k108 = 221
.line	365	loadk        r17   k97 ; k97 = 236
.line	365	loadk        r18  k109 ; k109 = 111
.line	365	loadk        r19  k110 ; k110 = 76
.line	365	loadk        r20  k111 ; k111 = 246
.line	365	loadk        r21  k112 ; k112 = 193
.line	365	loadk        r22   k57 ; k57 = 22
.line	365	loadk        r23   k20 ; k20 = 1
.line	365	loadk        r24  k113 ; k113 = 23
.line	365	loadk        r25  k114 ; k114 = 215
.line	365	loadk        r26   k23 ; k23 = 224
.line	365	loadk        r27   k99 ; k99 = 135
.line	365	loadk        r28  k109 ; k109 = 111
.line	365	loadk        r29   k70 ; k70 = 26
.line	365	loadk        r30   k31 ; k31 = 255
.line	365	loadk        r31  k124 ; k124 = 192
.line	365	loadk        r32  k125 ; k125 = 216
.line	365	loadk        r33   k66 ; k66 = 249
.line	365	loadk        r34  k126 ; k126 = 116
.line	365	loadk        r35  k127 ; k127 = 124
.line	365	loadk        r36   k26 ; k26 = 226
.line	365	loadk        r37  k128 ; k128 = 157
.line	365	loadk        r38  k129 ; k129 = 51
.line	365	loadk        r39  k130 ; k130 = 43
.line	365	loadk        r40  k131 ; k131 = 9
.line	365	loadk        r41  k108 ; k108 = 221
.line	365	loadk        r42   k94 ; k94 = 251
.line	365	loadk        r43   k18 ; k18 = 152
.line	365	loadk        r44   k48 ; k48 = 117
.line	365	loadk        r45  k132 ; k132 = 20
.line	365	call          r6    40     2
.line	365	call          r5     2     2
.line	365	gettable      r6    r5  k133 ; k133 = "send_depot_put_on_re" (truncated)
.line	365	gettabup      r7    u0  k134 ; k134 = "tonumber"
.line	365	move          r8    r1
.line	365	call          r7     2     2
.line	365	move          r8    r2
.line	365	call          r6     3     1
.line	365	return        r0     1
.line	365	move          r0    r0
.line	365	move          r0    r0
.line	365	return        r0     1

.function	main/f18

.source	null
.linedefined	381
.lastlinedefined	402
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	75
.constant	k46	240
.constant	k47	104
.constant	k48	25
.constant	k49	209
.constant	k50	111
.constant	k51	20
.constant	k52	180
.constant	k53	185
.constant	k54	202
.constant	k55	254
.constant	k56	114
.constant	k57	90
.constant	k58	236
.constant	k59	157
.constant	k60	251
.constant	k61	126
.constant	k62	1
.constant	k63	141
.constant	k64	232
.constant	k65	206
.constant	k66	128
.constant	k67	33
.constant	k68	26
.constant	k69	27
.constant	k70	243
.constant	k71	227
.constant	k72	133
.constant	k73	121
.constant	k74	19
.constant	k75	199
.constant	k76	203
.constant	k77	118
.constant	k78	93
.constant	k79	143
.constant	k80	58
.constant	k81	2
.constant	k82	17
.constant	k83	214
.constant	k84	132
.constant	k85	3
.constant	k86	167
.constant	k87	"LoadFileToTable_N"
.constant	k88	"ePlayerPrefsType"
.constant	k89	"eXsuitMotionCoast"
.constant	k90	79
.constant	k91	151
.constant	k92	63
.constant	k93	12
.constant	k94	6
.constant	k95	147
.constant	k96	62
.constant	k97	0
.constant	k98	160
.constant	k99	32
.constant	k100	208
.constant	k101	103
.constant	k102	134
.constant	k103	216
.constant	k104	205
.constant	k105	116
.constant	k106	95
.constant	k107	"GetAircraftOrGliding"
.constant	k108	"tostring"
.constant	k109	"res_id"
.constant	k110	255
.constant	k111	155
.constant	k112	10
.constant	k113	192
.constant	k114	113
.constant	k115	18
.constant	k116	"GetHallDepotItemListByResID"
.constant	k117	"SetDisplaySetting"
.constant	k118	"wardrobe_puton_req"
.constant	k119	"insID"
.constant	k120	"LocUtil"
.constant	k121	"LocalizeResFormat"
.constant	k122	200000266
.constant	k123	"ItemName"
.constant	k124	"ShowNotice"

.line	381	gettabup      r2    u0    k0 ; k0 = "require"
.line	381	gettabup      r3    u0    k1 ; k1 = "table"
.line	381	gettable      r3    r3    k2 ; k2 = "concat"
.line	381	newtable      r4     1     0
.line	381	getupval      r5    u1
.line	381	loadk         r6    k3 ; k3 = 224
.line	381	loadk         r7    k4 ; k4 = 36
.line	381	loadk         r8    k5 ; k5 = 186
.line	381	loadk         r9    k6 ; k6 = 218
.line	381	loadk        r10    k7 ; k7 = 122
.line	381	loadk        r11    k8 ; k8 = 68
.line	381	loadk        r12    k9 ; k9 = 40
.line	381	loadk        r13   k10 ; k10 = 146
.line	381	loadk        r14   k11 ; k11 = 235
.line	381	loadk        r15   k12 ; k12 = 220
.line	381	loadk        r16   k13 ; k13 = 250
.line	381	loadk        r17   k14 ; k14 = 46
.line	381	loadk        r18   k15 ; k15 = 82
.line	381	loadk        r19   k16 ; k16 = 242
.line	381	loadk        r20   k17 ; k17 = 136
.line	381	loadk        r21   k18 ; k18 = 47
.line	381	loadk        r22   k19 ; k19 = 16
.line	381	loadk        r23   k20 ; k20 = 86
.line	381	loadk        r24   k21 ; k21 = 212
.line	381	loadk        r25   k22 ; k22 = 238
.line	381	loadk        r26   k23 ; k23 = 150
.line	381	loadk        r27   k24 ; k24 = 100
.line	381	loadk        r28   k25 ; k25 = 4
.line	381	loadk        r29   k26 ; k26 = 190
.line	381	loadk        r30   k27 ; k27 = 245
.line	381	loadk        r31   k12 ; k12 = 220
.line	381	loadk        r32   k28 ; k28 = 165
.line	381	loadk        r33   k29 ; k29 = 124
.line	381	loadk        r34   k30 ; k30 = 65
.line	381	loadk        r35   k31 ; k31 = 234
.line	381	loadk        r36   k23 ; k23 = 150
.line	381	loadk        r37   k32 ; k32 = 53
.line	381	loadk        r38   k33 ; k33 = 60
.line	381	loadk        r39   k34 ; k34 = 31
.line	381	loadk        r40   k35 ; k35 = 210
.line	381	loadk        r41   k36 ; k36 = 237
.line	381	loadk        r42   k37 ; k37 = 144
.line	381	loadk        r43   k38 ; k38 = 98
.line	381	loadk        r44   k39 ; k39 = 9
.line	381	loadk        r45   k40 ; k40 = 163
.line	381	call          r5    41     2
.line	381	getupval      r6    u1
.line	381	loadk         r7   k41 ; k41 = 230
.line	381	loadk         r8   k42 ; k42 = 23
.line	381	loadk         r9   k43 ; k43 = 189
.line	381	loadk        r10    k6 ; k6 = 218
.line	381	loadk        r11   k44 ; k44 = 99
.line	381	call          r6     6     0
.line	381	setlist       r4     0     1
.line	381	call          r3     2     2
.line	381	call          r2     2     2
.line	381	gettabup      r3    u0    k0 ; k0 = "require"
.line	381	getupval      r4    u1
.line	381	loadk         r5    k3 ; k3 = 224
.line	381	loadk         r6    k4 ; k4 = 36
.line	381	loadk         r7    k5 ; k5 = 186
.line	381	loadk         r8    k6 ; k6 = 218
.line	381	loadk         r9    k7 ; k7 = 122
.line	381	loadk        r10    k8 ; k8 = 68
.line	381	loadk        r11    k9 ; k9 = 40
.line	381	loadk        r12   k10 ; k10 = 146
.line	381	loadk        r13   k11 ; k11 = 235
.line	381	loadk        r14   k12 ; k12 = 220
.line	381	loadk        r15   k13 ; k13 = 250
.line	381	loadk        r16   k14 ; k14 = 46
.line	381	loadk        r17   k45 ; k45 = 75
.line	381	loadk        r18   k46 ; k46 = 240
.line	381	loadk        r19   k17 ; k17 = 136
.line	381	loadk        r20   k47 ; k47 = 104
.line	381	loadk        r21    k4 ; k4 = 36
.line	381	loadk        r22   k48 ; k48 = 25
.line	381	loadk        r23   k49 ; k49 = 209
.line	381	loadk        r24   k11 ; k11 = 235
.line	381	loadk        r25   k23 ; k23 = 150
.line	381	loadk        r26   k50 ; k50 = 111
.line	381	loadk        r27   k51 ; k51 = 20
.line	381	loadk        r28   k52 ; k52 = 180
.line	381	loadk        r29   k53 ; k53 = 185
.line	381	loadk        r30   k54 ; k54 = 202
.line	381	loadk        r31   k55 ; k55 = 254
.line	381	loadk        r32   k56 ; k56 = 114
.line	381	loadk        r33   k57 ; k57 = 90
.line	381	loadk        r34   k58 ; k58 = 236
.line	381	loadk        r35   k59 ; k59 = 157
.line	381	loadk        r36   k39 ; k39 = 9
.line	381	loadk        r37   k25 ; k25 = 4
.line	381	loadk        r38   k25 ; k25 = 4
.line	381	loadk        r39    k6 ; k6 = 218
.line	381	loadk        r40   k60 ; k60 = 251
.line	381	loadk        r41   k59 ; k59 = 157
.line	381	loadk        r42   k61 ; k61 = 126
.line	381	loadk        r43   k62 ; k62 = 1
.line	381	call          r4    40     2
.line	381	call          r3     2     2
.line	381	gettabup      r4    u0    k0 ; k0 = "require"
.line	381	gettabup      r5    u0    k1 ; k1 = "table"
.line	381	gettable      r5    r5    k2 ; k2 = "concat"
.line	381	newtable      r6     1     0
.line	381	getupval      r7    u1
.line	381	loadk         r8    k3 ; k3 = 224
.line	381	loadk         r9    k4 ; k4 = 36
.line	381	loadk        r10    k5 ; k5 = 186
.line	381	loadk        r11    k6 ; k6 = 218
.line	381	loadk        r12    k7 ; k7 = 122
.line	381	loadk        r13    k8 ; k8 = 68
.line	381	loadk        r14    k9 ; k9 = 40
.line	381	loadk        r15   k63 ; k63 = 141
.line	381	loadk        r16   k64 ; k64 = 232
.line	381	loadk        r17   k65 ; k65 = 206
.line	381	loadk        r18   k16 ; k16 = 242
.line	381	loadk        r19   k44 ; k44 = 99
.line	381	loadk        r20   k19 ; k19 = 16
.line	381	loadk        r21   k49 ; k49 = 209
.line	381	loadk        r22   k66 ; k66 = 128
.line	381	loadk        r23   k67 ; k67 = 33
.line	381	loadk        r24   k68 ; k68 = 26
.line	381	loadk        r25   k69 ; k69 = 27
.line	381	loadk        r26   k70 ; k70 = 243
.line	381	loadk        r27   k71 ; k71 = 227
.line	381	loadk        r28   k72 ; k72 = 133
.line	381	loadk        r29   k73 ; k73 = 121
.line	381	loadk        r30   k74 ; k74 = 19
.line	381	loadk        r31   k40 ; k40 = 163
.line	381	loadk        r32   k75 ; k75 = 199
.line	381	loadk        r33   k76 ; k76 = 203
.line	381	loadk        r34   k22 ; k22 = 238
.line	381	loadk        r35   k77 ; k77 = 118
.line	381	loadk        r36   k78 ; k78 = 93
.line	381	loadk        r37   k40 ; k40 = 163
.line	381	loadk        r38   k79 ; k79 = 143
.line	381	loadk        r39   k80 ; k80 = 58
.line	381	loadk        r40   k81 ; k81 = 2
.line	381	loadk        r41   k82 ; k82 = 17
.line	381	loadk        r42   k83 ; k83 = 214
.line	381	loadk        r43   k36 ; k36 = 237
.line	381	loadk        r44   k84 ; k84 = 132
.line	381	loadk        r45   k38 ; k38 = 98
.line	381	loadk        r46   k85 ; k85 = 3
.line	381	loadk        r47   k86 ; k86 = 167
.line	381	call          r7    41     2
.line	381	getupval      r8    u1
.line	381	loadk         r9   k46 ; k46 = 240
.line	381	call          r8     2     0
.line	381	setlist       r6     0     1
.line	381	call          r5     2     2
.line	381	call          r4     2     2
.line	381	gettable      r5    r4   k87 ; k87 = "LoadFileToTable_N"
.line	381	gettable      r6    r4   k88 ; k88 = "ePlayerPrefsType"
.line	381	gettable      r6    r6   k89 ; k89 = "eXsuitMotionCoast"
.line	381	call          r5     2     2
.line	381	test          r5     1
.line	381	jmp            0  l159
.line	381	newtable      r5     0     0
.label	l159
.line	381	gettabup      r6    u0    k0 ; k0 = "require"
.line	381	gettabup      r7    u0    k1 ; k1 = "table"
.line	381	gettable      r7    r7    k2 ; k2 = "concat"
.line	381	newtable      r8     1     0
.line	381	getupval      r9    u1
.line	381	loadk        r10    k3 ; k3 = 224
.line	381	loadk        r11    k4 ; k4 = 36
.line	381	loadk        r12    k5 ; k5 = 186
.line	381	loadk        r13    k6 ; k6 = 218
.line	381	loadk        r14    k7 ; k7 = 122
.line	381	loadk        r15    k8 ; k8 = 68
.line	381	loadk        r16    k9 ; k9 = 40
.line	381	loadk        r17   k10 ; k10 = 146
.line	381	loadk        r18   k11 ; k11 = 235
.line	381	loadk        r19   k12 ; k12 = 220
.line	381	loadk        r20   k13 ; k13 = 250
.line	381	loadk        r21   k14 ; k14 = 46
.line	381	loadk        r22   k15 ; k15 = 82
.line	381	loadk        r23   k16 ; k16 = 242
.line	381	loadk        r24   k17 ; k17 = 136
.line	381	loadk        r25   k18 ; k18 = 47
.line	381	loadk        r26   k19 ; k19 = 16
.line	381	loadk        r27   k20 ; k20 = 86
.line	381	loadk        r28   k21 ; k21 = 212
.line	381	loadk        r29   k22 ; k22 = 238
.line	381	loadk        r30   k23 ; k23 = 150
.line	381	loadk        r31   k24 ; k24 = 100
.line	381	loadk        r32   k25 ; k25 = 4
.line	381	loadk        r33   k26 ; k26 = 190
.line	381	loadk        r34   k27 ; k27 = 245
.line	381	loadk        r35   k12 ; k12 = 220
.line	381	loadk        r36   k28 ; k28 = 165
.line	381	loadk        r37   k77 ; k77 = 118
.line	381	loadk        r38   k90 ; k90 = 79
.line	381	loadk        r39   k55 ; k55 = 254
.line	381	loadk        r40   k91 ; k91 = 151
.line	381	loadk        r41   k92 ; k92 = 63
.line	381	loadk        r42   k93 ; k93 = 12
.line	381	loadk        r43   k94 ; k94 = 6
.line	381	loadk        r44   k49 ; k49 = 209
.line	381	loadk        r45   k55 ; k55 = 254
.line	381	loadk        r46   k95 ; k95 = 147
.line	381	loadk        r47   k96 ; k96 = 62
.line	381	loadk        r48   k97 ; k97 = 0
.line	381	loadk        r49   k98 ; k98 = 160
.line	381	call          r9    41     2
.line	381	getupval     r10    u1
.line	381	loadk        r11   k46 ; k46 = 240
.line	381	loadk        r12   k99 ; k99 = 32
.line	381	loadk        r13    k5 ; k5 = 186
.line	381	loadk        r14  k100 ; k100 = 208
.line	381	loadk        r15    k7 ; k7 = 122
.line	381	loadk        r16   k15 ; k15 = 82
.line	381	loadk        r17  k101 ; k101 = 103
.line	381	loadk        r18  k102 ; k102 = 134
.line	381	loadk        r19  k103 ; k103 = 216
.line	381	loadk        r20  k104 ; k104 = 205
.line	381	loadk        r21   k13 ; k13 = 250
.line	381	loadk        r22  k105 ; k105 = 116
.line	381	loadk        r23  k106 ; k106 = 95
.line	381	call         r10    14     0
.line	381	setlist       r8     0     1
.line	381	call          r7     2     2
.line	381	call          r6     2     2
.line	381	self          r7    r6  k107 ; k107 = "GetAircraftOrGliding"
.line	381	call          r7     2     2
.line	381	gettabup      r8    u0  k108 ; k108 = "tostring"
.line	381	move          r9    r7
.line	381	call          r8     2     2
.line	381	move          r7    r8
.line	381	gettable      r8    r0  k109 ; k109 = "res_id"
.line	381	gettable      r8    r5    r8
.line	381	test          r8     0
.line	381	jmp            0  l330
.line	381	gettable      r8    r0  k109 ; k109 = "res_id"
.line	381	gettable      r8    r5    r8
.line	381	gettable      r8    r5    r8
.line	381	eq             1    r8    r7
.line	381	jmp            0  l330
.line	381	gettabup      r8    u0    k0 ; k0 = "require"
.line	381	getupval      r9    u1
.line	381	loadk        r10    k3 ; k3 = 224
.line	381	loadk        r11    k4 ; k4 = 36
.line	381	loadk        r12    k5 ; k5 = 186
.line	381	loadk        r13    k6 ; k6 = 218
.line	381	loadk        r14    k7 ; k7 = 122
.line	381	loadk        r15    k8 ; k8 = 68
.line	381	loadk        r16    k9 ; k9 = 40
.line	381	loadk        r17   k10 ; k10 = 146
.line	381	loadk        r18   k11 ; k11 = 235
.line	381	loadk        r19   k12 ; k12 = 220
.line	381	loadk        r20   k13 ; k13 = 250
.line	381	loadk        r21   k14 ; k14 = 46
.line	381	loadk        r22   k15 ; k15 = 82
.line	381	loadk        r23   k16 ; k16 = 242
.line	381	loadk        r24   k17 ; k17 = 136
.line	381	loadk        r25   k18 ; k18 = 47
.line	381	loadk        r26   k19 ; k19 = 16
.line	381	loadk        r27   k20 ; k20 = 86
.line	381	loadk        r28   k21 ; k21 = 212
.line	381	loadk        r29   k22 ; k22 = 238
.line	381	loadk        r30   k23 ; k23 = 150
.line	381	loadk        r31   k24 ; k24 = 100
.line	381	loadk        r32   k25 ; k25 = 4
.line	381	loadk        r33   k26 ; k26 = 190
.line	381	loadk        r34   k27 ; k27 = 245
.line	381	loadk        r35   k12 ; k12 = 220
.line	381	loadk        r36   k28 ; k28 = 165
.line	381	loadk        r37  k101 ; k101 = 103
.line	381	loadk        r38   k90 ; k90 = 79
.line	381	loadk        r39  k110 ; k110 = 255
.line	381	loadk        r40  k111 ; k111 = 155
.line	381	loadk        r41    k4 ; k4 = 36
.line	381	loadk        r42   k93 ; k93 = 12
.line	381	loadk        r43  k112 ; k112 = 10
.line	381	loadk        r44   k83 ; k83 = 214
.line	381	loadk        r45  k113 ; k113 = 192
.line	381	loadk        r46   k37 ; k37 = 144
.line	381	loadk        r47  k114 ; k114 = 113
.line	381	loadk        r48  k115 ; k115 = 18
.line	381	loadk        r49   k98 ; k98 = 160
.line	381	call          r9    41     2
.line	381	call          r8     2     2
.line	381	self          r9    r8  k116 ; k116 = "GetHallDepotItemList" (truncated)
.line	381	gettable     r11    r0  k109 ; k109 = "res_id"
.line	381	gettable     r11    r5   r11
.line	381	call          r9     3     2
.line	381	gettable     r10    r0  k109 ; k109 = "res_id"
.line	381	gettable     r10    r5   r10
.line	381	gettable     r10    r5   r10
.line	381	test         r10     0
.line	381	jmp            0  l306
.line	381	gettable     r10    r0  k109 ; k109 = "res_id"
.line	381	gettable     r10    r5   r10
.line	381	gettable     r10    r5   r10
.line	381	len          r10   r10
.line	381	lt             0   k94   r10 ; k94 = 6
.line	381	jmp            0  l306
.line	381	self         r10    r3  k117 ; k117 = "SetDisplaySetting"
.line	381	loadbool     r12     1     0
.line	381	call         r10     3     1
.line	381	self         r10    r2  k118 ; k118 = "wardrobe_puton_req"
.line	381	gettable     r12    r0  k109 ; k109 = "res_id"
.line	381	gettable     r12    r5   r12
.line	381	gettable     r12    r5   r12
.line	381	call         r10     3     1
.line	381	jmp            0  l319
.label	l306
.line	381	test          r9     0
.line	381	jmp            0  l319
.line	381	gettable     r10    r9   k62 ; k62 = 1
.line	381	test         r10     0
.line	381	jmp            0  l319
.line	381	gettable     r10    r9   k62 ; k62 = 1
.line	381	gettable     r10   r10  k119 ; k119 = "insID"
.line	381	test         r10     0
.line	381	jmp            0  l319
.line	381	self         r10    r2  k118 ; k118 = "wardrobe_puton_req"
.line	381	gettable     r12    r9   k62 ; k62 = 1
.line	381	gettable     r12   r12  k119 ; k119 = "insID"
.line	381	call         r10     3     1
.label	l319
.line	381	self         r10    r3  k117 ; k117 = "SetDisplaySetting"
.line	381	loadbool     r12     1     0
.line	381	call         r10     3     1
.line	381	gettabup     r10    u0  k120 ; k120 = "LocUtil"
.line	381	gettable     r10   r10  k121 ; k121 = "LocalizeResFormat"
.line	381	loadk        r11  k122 ; k122 = 200000266
.line	381	gettable     r12    r1  k123 ; k123 = "ItemName"
.line	381	call         r10     3     2
.line	381	gettabup     r11    u0  k124 ; k124 = "ShowNotice"
.line	381	move         r12   r10
.line	381	call         r11     2     1
.label	l330
.line	381	return        r0     1
.line	381	move          r0    r0
.line	381	return        r0     1

.function	main/f19

.source	null
.linedefined	403
.lastlinedefined	432
.numparams	1
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	146
.constant	k9	235
.constant	k10	220
.constant	k11	250
.constant	k12	46
.constant	k13	82
.constant	k14	242
.constant	k15	136
.constant	k16	47
.constant	k17	16
.constant	k18	86
.constant	k19	251
.constant	k20	145
.constant	k21	105
.constant	k22	2
.constant	k23	255
.constant	k24	214
.constant	k25	236
.constant	k26	121
.constant	k27	77
.constant	k28	210
.constant	k29	135
.constant	k30	37
.constant	k31	22
.constant	k32	1
.constant	k33	199
.constant	k34	"table"
.constant	k35	"concat"
.constant	k36	141
.constant	k37	232
.constant	k38	206
.constant	k39	99
.constant	k40	209
.constant	k41	128
.constant	k42	33
.constant	k43	26
.constant	k44	27
.constant	k45	243
.constant	k46	227
.constant	k47	133
.constant	k48	19
.constant	k49	163
.constant	k50	203
.constant	k51	238
.constant	k52	118
.constant	k53	93
.constant	k54	143
.constant	k55	58
.constant	k56	17
.constant	k57	237
.constant	k58	132
.constant	k59	98
.constant	k60	3
.constant	k61	167
.constant	k62	240
.constant	k63	"GetPeriodByItemId"
.constant	k64	"res_id"
.constant	k65	"GetBranchByItemId"
.constant	k66	"LoadFileToTable_N"
.constant	k67	"ePlayerPrefsType"
.constant	k68	"eXSuitParachutePrefs"
.constant	k69	212
.constant	k70	150
.constant	k71	100
.constant	k72	4
.constant	k73	190
.constant	k74	245
.constant	k75	165
.constant	k76	79
.constant	k77	254
.constant	k78	151
.constant	k79	63
.constant	k80	12
.constant	k81	6
.constant	k82	147
.constant	k83	62
.constant	k84	0
.constant	k85	160
.constant	k86	32
.constant	k87	208
.constant	k88	103
.constant	k89	134
.constant	k90	216
.constant	k91	205
.constant	k92	116
.constant	k93	95
.constant	k94	124
.constant	k95	65
.constant	k96	234
.constant	k97	53
.constant	k98	60
.constant	k99	31
.constant	k100	144
.constant	k101	9
.constant	k102	230
.constant	k103	23
.constant	k104	189
.constant	k105	"GetItemIDByLevel"
.constant	k106	"CDataTable"
.constant	k107	"GetTableData"
.constant	k108	219
.constant	k109	166
.constant	k110	96
.constant	k111	202
.constant	k112	117
.constant	k113	74
.constant	k114	248
.constant	k115	172
.constant	k116	20
.constant	k117	"BindParachuteResID"
.constant	k118	"ParachuteID"
.constant	k119	"HasItem"
.constant	k120	"GetHallDepotItemDataByResID"
.constant	k121	"insID"
.constant	k122	"GetLevelByPeriodSelf"
.constant	k123	"GetPeriodOfCurrentlyWearing"
.constant	k124	"GetParachute"
.constant	k125	"wardrobe_puton_req"
.constant	k126	182
.constant	k127	"ShowNotice"
.constant	k128	"LocUtil"
.constant	k129	"LocalizeResFormat"
.constant	k130	18141490
.constant	k131	"ItemName"

.line	403	gettabup      r1    u0    k0 ; k0 = "require"
.line	403	getupval      r2    u1
.line	403	loadk         r3    k1 ; k1 = 224
.line	403	loadk         r4    k2 ; k2 = 36
.line	403	loadk         r5    k3 ; k3 = 186
.line	403	loadk         r6    k4 ; k4 = 218
.line	403	loadk         r7    k5 ; k5 = 122
.line	403	loadk         r8    k6 ; k6 = 68
.line	403	loadk         r9    k7 ; k7 = 40
.line	403	loadk        r10    k8 ; k8 = 146
.line	403	loadk        r11    k9 ; k9 = 235
.line	403	loadk        r12   k10 ; k10 = 220
.line	403	loadk        r13   k11 ; k11 = 250
.line	403	loadk        r14   k12 ; k12 = 46
.line	403	loadk        r15   k13 ; k13 = 82
.line	403	loadk        r16   k14 ; k14 = 242
.line	403	loadk        r17   k15 ; k15 = 136
.line	403	loadk        r18   k16 ; k16 = 47
.line	403	loadk        r19   k17 ; k17 = 16
.line	403	loadk        r20   k18 ; k18 = 86
.line	403	loadk        r21   k19 ; k19 = 251
.line	403	loadk        r22   k10 ; k10 = 220
.line	403	loadk        r23   k20 ; k20 = 145
.line	403	loadk        r24   k21 ; k21 = 105
.line	403	loadk        r25   k22 ; k22 = 2
.line	403	loadk        r26   k23 ; k23 = 255
.line	403	loadk        r27   k19 ; k19 = 251
.line	403	loadk        r28   k24 ; k24 = 214
.line	403	loadk        r29   k25 ; k25 = 236
.line	403	loadk        r30   k26 ; k26 = 121
.line	403	loadk        r31   k27 ; k27 = 77
.line	403	loadk        r32   k28 ; k28 = 210
.line	403	loadk        r33   k29 ; k29 = 135
.line	403	loadk        r34   k30 ; k30 = 37
.line	403	loadk        r35   k31 ; k31 = 22
.line	403	loadk        r36   k32 ; k32 = 1
.line	403	loadk        r37   k33 ; k33 = 199
.line	403	call          r2    36     2
.line	403	call          r1     2     2
.line	403	gettabup      r2    u0    k0 ; k0 = "require"
.line	403	gettabup      r3    u0   k34 ; k34 = "table"
.line	403	gettable      r3    r3   k35 ; k35 = "concat"
.line	403	newtable      r4     1     0
.line	403	getupval      r5    u1
.line	403	loadk         r6    k1 ; k1 = 224
.line	403	loadk         r7    k2 ; k2 = 36
.line	403	loadk         r8    k3 ; k3 = 186
.line	403	loadk         r9    k4 ; k4 = 218
.line	403	loadk        r10    k5 ; k5 = 122
.line	403	loadk        r11    k6 ; k6 = 68
.line	403	loadk        r12    k7 ; k7 = 40
.line	403	loadk        r13   k36 ; k36 = 141
.line	403	loadk        r14   k37 ; k37 = 232
.line	403	loadk        r15   k38 ; k38 = 206
.line	403	loadk        r16   k14 ; k14 = 242
.line	403	loadk        r17   k39 ; k39 = 99
.line	403	loadk        r18   k17 ; k17 = 16
.line	403	loadk        r19   k40 ; k40 = 209
.line	403	loadk        r20   k41 ; k41 = 128
.line	403	loadk        r21   k42 ; k42 = 33
.line	403	loadk        r22   k43 ; k43 = 26
.line	403	loadk        r23   k44 ; k44 = 27
.line	403	loadk        r24   k45 ; k45 = 243
.line	403	loadk        r25   k46 ; k46 = 227
.line	403	loadk        r26   k47 ; k47 = 133
.line	403	loadk        r27   k26 ; k26 = 121
.line	403	loadk        r28   k48 ; k48 = 19
.line	403	loadk        r29   k49 ; k49 = 163
.line	403	loadk        r30   k33 ; k33 = 199
.line	403	loadk        r31   k50 ; k50 = 203
.line	403	loadk        r32   k51 ; k51 = 238
.line	403	loadk        r33   k52 ; k52 = 118
.line	403	loadk        r34   k53 ; k53 = 93
.line	403	loadk        r35   k49 ; k49 = 163
.line	403	loadk        r36   k54 ; k54 = 143
.line	403	loadk        r37   k55 ; k55 = 58
.line	403	loadk        r38   k22 ; k22 = 2
.line	403	loadk        r39   k56 ; k56 = 17
.line	403	loadk        r40   k24 ; k24 = 214
.line	403	loadk        r41   k57 ; k57 = 237
.line	403	loadk        r42   k58 ; k58 = 132
.line	403	loadk        r43   k59 ; k59 = 98
.line	403	loadk        r44   k60 ; k60 = 3
.line	403	loadk        r45   k61 ; k61 = 167
.line	403	call          r5    41     2
.line	403	getupval      r6    u1
.line	403	loadk         r7   k62 ; k62 = 240
.line	403	call          r6     2     0
.line	403	setlist       r4     0     1
.line	403	call          r3     2     2
.line	403	call          r2     2     2
.line	403	gettable      r3    r1   k63 ; k63 = "GetPeriodByItemId"
.line	403	gettable      r4    r0   k64 ; k64 = "res_id"
.line	403	call          r3     2     2
.line	403	gettable      r4    r1   k65 ; k65 = "GetBranchByItemId"
.line	403	gettable      r5    r0   k64 ; k64 = "res_id"
.line	403	call          r4     2     2
.line	403	gettable      r5    r2   k66 ; k66 = "LoadFileToTable_N"
.line	403	gettable      r6    r2   k67 ; k67 = "ePlayerPrefsType"
.line	403	gettable      r6    r6   k68 ; k68 = "eXSuitParachutePrefs"
.line	403	call          r5     2     2
.line	403	test          r5     1
.line	403	jmp            0  l105
.line	403	newtable      r5     0     0
.label	l105
.line	403	gettable      r6    r5    r3
.line	403	test          r6     1
.line	403	jmp            0  l109
.line	403	newtable      r6     0     0
.label	l109
.line	403	gettabup      r7    u0    k0 ; k0 = "require"
.line	403	gettabup      r8    u0   k34 ; k34 = "table"
.line	403	gettable      r8    r8   k35 ; k35 = "concat"
.line	403	newtable      r9     1     0
.line	403	getupval     r10    u1
.line	403	loadk        r11    k1 ; k1 = 224
.line	403	loadk        r12    k2 ; k2 = 36
.line	403	loadk        r13    k3 ; k3 = 186
.line	403	loadk        r14    k4 ; k4 = 218
.line	403	loadk        r15    k5 ; k5 = 122
.line	403	loadk        r16    k6 ; k6 = 68
.line	403	loadk        r17    k7 ; k7 = 40
.line	403	loadk        r18    k8 ; k8 = 146
.line	403	loadk        r19    k9 ; k9 = 235
.line	403	loadk        r20   k10 ; k10 = 220
.line	403	loadk        r21   k11 ; k11 = 250
.line	403	loadk        r22   k12 ; k12 = 46
.line	403	loadk        r23   k13 ; k13 = 82
.line	403	loadk        r24   k14 ; k14 = 242
.line	403	loadk        r25   k15 ; k15 = 136
.line	403	loadk        r26   k16 ; k16 = 47
.line	403	loadk        r27   k17 ; k17 = 16
.line	403	loadk        r28   k18 ; k18 = 86
.line	403	loadk        r29   k69 ; k69 = 212
.line	403	loadk        r30   k51 ; k51 = 238
.line	403	loadk        r31   k70 ; k70 = 150
.line	403	loadk        r32   k71 ; k71 = 100
.line	403	loadk        r33   k72 ; k72 = 4
.line	403	loadk        r34   k73 ; k73 = 190
.line	403	loadk        r35   k74 ; k74 = 245
.line	403	loadk        r36   k10 ; k10 = 220
.line	403	loadk        r37   k75 ; k75 = 165
.line	403	loadk        r38   k52 ; k52 = 118
.line	403	loadk        r39   k76 ; k76 = 79
.line	403	loadk        r40   k77 ; k77 = 254
.line	403	loadk        r41   k78 ; k78 = 151
.line	403	loadk        r42   k79 ; k79 = 63
.line	403	loadk        r43   k80 ; k80 = 12
.line	403	loadk        r44   k81 ; k81 = 6
.line	403	loadk        r45   k40 ; k40 = 209
.line	403	loadk        r46   k77 ; k77 = 254
.line	403	loadk        r47   k82 ; k82 = 147
.line	403	loadk        r48   k83 ; k83 = 62
.line	403	loadk        r49   k84 ; k84 = 0
.line	403	loadk        r50   k85 ; k85 = 160
.line	403	call         r10    41     2
.line	403	getupval     r11    u1
.line	403	loadk        r12   k62 ; k62 = 240
.line	403	loadk        r13   k86 ; k86 = 32
.line	403	loadk        r14    k3 ; k3 = 186
.line	403	loadk        r15   k87 ; k87 = 208
.line	403	loadk        r16    k5 ; k5 = 122
.line	403	loadk        r17   k13 ; k13 = 82
.line	403	loadk        r18   k88 ; k88 = 103
.line	403	loadk        r19   k89 ; k89 = 134
.line	403	loadk        r20   k90 ; k90 = 216
.line	403	loadk        r21   k91 ; k91 = 205
.line	403	loadk        r22   k11 ; k11 = 250
.line	403	loadk        r23   k92 ; k92 = 116
.line	403	loadk        r24   k93 ; k93 = 95
.line	403	call         r11    14     0
.line	403	setlist       r9     0     1
.line	403	call          r8     2     2
.line	403	call          r7     2     2
.line	403	gettabup      r8    u0    k0 ; k0 = "require"
.line	403	gettabup      r9    u0   k34 ; k34 = "table"
.line	403	gettable      r9    r9   k35 ; k35 = "concat"
.line	403	newtable     r10     1     0
.line	403	getupval     r11    u1
.line	403	loadk        r12    k1 ; k1 = 224
.line	403	loadk        r13    k2 ; k2 = 36
.line	403	loadk        r14    k3 ; k3 = 186
.line	403	loadk        r15    k4 ; k4 = 218
.line	403	loadk        r16    k5 ; k5 = 122
.line	403	loadk        r17    k6 ; k6 = 68
.line	403	loadk        r18    k7 ; k7 = 40
.line	403	loadk        r19    k8 ; k8 = 146
.line	403	loadk        r20    k9 ; k9 = 235
.line	403	loadk        r21   k10 ; k10 = 220
.line	403	loadk        r22   k11 ; k11 = 250
.line	403	loadk        r23   k12 ; k12 = 46
.line	403	loadk        r24   k13 ; k13 = 82
.line	403	loadk        r25   k14 ; k14 = 242
.line	403	loadk        r26   k15 ; k15 = 136
.line	403	loadk        r27   k16 ; k16 = 47
.line	403	loadk        r28   k17 ; k17 = 16
.line	403	loadk        r29   k18 ; k18 = 86
.line	403	loadk        r30   k69 ; k69 = 212
.line	403	loadk        r31   k51 ; k51 = 238
.line	403	loadk        r32   k70 ; k70 = 150
.line	403	loadk        r33   k71 ; k71 = 100
.line	403	loadk        r34   k72 ; k72 = 4
.line	403	loadk        r35   k73 ; k73 = 190
.line	403	loadk        r36   k74 ; k74 = 245
.line	403	loadk        r37   k10 ; k10 = 220
.line	403	loadk        r38   k75 ; k75 = 165
.line	403	loadk        r39   k94 ; k94 = 124
.line	403	loadk        r40   k95 ; k95 = 65
.line	403	loadk        r41   k96 ; k96 = 234
.line	403	loadk        r42   k70 ; k70 = 150
.line	403	loadk        r43   k97 ; k97 = 53
.line	403	loadk        r44   k98 ; k98 = 60
.line	403	loadk        r45   k99 ; k99 = 31
.line	403	loadk        r46   k28 ; k28 = 210
.line	403	loadk        r47   k57 ; k57 = 237
.line	403	loadk        r48  k100 ; k100 = 144
.line	403	loadk        r49   k59 ; k59 = 98
.line	403	loadk        r50  k101 ; k101 = 9
.line	403	loadk        r51   k49 ; k49 = 163
.line	403	call         r11    41     2
.line	403	getupval     r12    u1
.line	403	loadk        r13  k102 ; k102 = 230
.line	403	loadk        r14  k103 ; k103 = 23
.line	403	loadk        r15  k104 ; k104 = 189
.line	403	loadk        r16    k4 ; k4 = 218
.line	403	loadk        r17   k39 ; k39 = 99
.line	403	call         r12     6     0
.line	403	setlist      r10     0     1
.line	403	call          r9     2     2
.line	403	call          r8     2     2
.line	403	gettable      r9    r1  k105 ; k105 = "GetItemIDByLevel"
.line	403	move         r10    r3
.line	403	loadk        r11   k32 ; k32 = 1
.line	403	move         r12    r4
.line	403	call          r9     4     2
.line	403	gettabup     r10    u0  k106 ; k106 = "CDataTable"
.line	403	gettable     r10   r10  k107 ; k107 = "GetTableData"
.line	403	getupval     r11    u1
.line	403	loadk        r12  k108 ; k108 = 219
.line	403	loadk        r13   k44 ; k44 = 27
.line	403	loadk        r14  k109 ; k109 = 166
.line	403	loadk        r15   k24 ; k24 = 214
.line	403	loadk        r16  k110 ; k110 = 96
.line	403	loadk        r17  k110 ; k110 = 96
.line	403	loadk        r18   k88 ; k88 = 103
.line	403	loadk        r19   k82 ; k82 = 147
.line	403	loadk        r20  k102 ; k102 = 230
.line	403	loadk        r21  k111 ; k111 = 202
.line	403	loadk        r22   k45 ; k45 = 243
.line	403	loadk        r23  k112 ; k112 = 117
.line	403	loadk        r24  k113 ; k113 = 74
.line	403	loadk        r25  k114 ; k114 = 248
.line	403	loadk        r26  k115 ; k115 = 172
.line	403	loadk        r27   k86 ; k86 = 32
.line	403	loadk        r28  k116 ; k116 = 20
.line	403	call         r11    18     2
.line	403	move         r12    r9
.line	403	call         r10     3     2
.line	403	test         r10     0
.line	403	jmp            0  l320
.line	403	gettable     r11    r6  k117 ; k117 = "BindParachuteResID"
.line	403	gettable     r12   r10  k118 ; k118 = "ParachuteID"
.line	403	eq             0   r11   r12
.line	403	jmp            0  l320
.line	403	getupval     r11    u2
.line	403	self         r11   r11  k119 ; k119 = "HasItem"
.line	403	gettable     r13   r10  k118 ; k118 = "ParachuteID"
.line	403	call         r11     3     2
.line	403	test         r11     0
.line	403	jmp            0  l320
.line	403	getupval     r11    u2
.line	403	self         r11   r11  k120 ; k120 = "GetHallDepotItemData" (truncated)
.line	403	gettable     r13   r10  k118 ; k118 = "ParachuteID"
.line	403	call         r11     3     2
.line	403	test         r11     0
.line	403	jmp            0  l320
.line	403	gettable     r12   r11  k121 ; k121 = "insID"
.line	403	test         r12     0
.line	403	jmp            0  l320
.line	403	gettable     r12    r1  k122 ; k122 = "GetLevelByPeriodSelf"
.line	403	move         r13    r3
.line	403	move         r14    r4
.line	403	call         r12     3     2
.line	403	gettable     r13    r1  k105 ; k105 = "GetItemIDByLevel"
.line	403	move         r14    r3
.line	403	move         r15   r12
.line	403	move         r16    r4
.line	403	call         r13     4     2
.line	403	test         r13     0
.line	403	jmp            0  l320
.line	403	gettable     r14    r1  k123 ; k123 = "GetPeriodOfCurrently" (truncated)
.line	403	call         r14     1     2
.line	403	self         r15    r7  k124 ; k124 = "GetParachute"
.line	403	call         r15     2     2
.line	403	eq             0   r14    r3
.line	403	jmp            0  l320
.line	403	gettable     r16   r11  k121 ; k121 = "insID"
.line	403	eq             1   r15   r16
.line	403	jmp            0  l320
.line	403	self         r16    r8  k125 ; k125 = "wardrobe_puton_req"
.line	403	gettable     r18   r11  k121 ; k121 = "insID"
.line	403	call         r16     3     1
.line	403	gettabup     r16    u0  k106 ; k106 = "CDataTable"
.line	403	gettable     r16   r16  k107 ; k107 = "GetTableData"
.line	403	getupval     r17    u1
.line	403	loadk        r18  k111 ; k111 = 202
.line	403	loadk        r19   k98 ; k98 = 60
.line	403	loadk        r20  k126 ; k126 = 182
.line	403	loadk        r21   k28 ; k28 = 210
.line	403	call         r17     5     2
.line	403	move         r18   r13
.line	403	call         r16     3     2
.line	403	test         r16     0
.line	403	jmp            0  l320
.line	403	gettabup     r17    u0  k127 ; k127 = "ShowNotice"
.line	403	gettabup     r18    u0  k128 ; k128 = "LocUtil"
.line	403	gettable     r18   r18  k129 ; k129 = "LocalizeResFormat"
.line	403	loadk        r19  k130 ; k130 = 18141490
.line	403	gettable     r20   r16  k131 ; k131 = "ItemName"
.line	403	call         r18     3     0
.line	403	call         r17     0     1
.label	l320
.line	403	return        r0     1
.line	403	move          r0    r0
.line	403	move          r0    r0
.line	403	move          r0    r0
.line	403	move          r0    r0
.line	403	return        r0     1

.function	main/f20

.source	null
.linedefined	434
.lastlinedefined	613
.numparams	6
.is_vararg	0
.maxstacksize	60

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	10	true
.upvalue	"U4"	13	true
.upvalue	"U5"	14	true
.upvalue	"U6"	17	true
.upvalue	"U7"	18	true
.upvalue	"U8"	15	true
.upvalue	"U9"	12	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	241
.constant	k15	128
.constant	k16	17
.constant	k17	1
.constant	k18	231
.constant	k19	133
.constant	k20	108
.constant	k21	26
.constant	k22	142
.constant	k23	227
.constant	k24	209
.constant	k25	238
.constant	k26	125
.constant	k27	75
.constant	k28	210
.constant	k29	138
.constant	k30	34
.constant	k31	10
.constant	k32	4
.constant	k33	192
.constant	k34	"log_tree"
.constant	k35	212
.constant	k36	41
.constant	k37	161
.constant	k38	219
.constant	k39	102
.constant	k40	95
.constant	k41	100
.constant	k42	132
.constant	k43	203
.constant	k44	198
.constant	k45	252
.constant	k46	105
.constant	k47	93
.constant	k48	189
.constant	k49	159
.constant	k50	51
.constant	k51	7
.constant	k52	23
.constant	k53	205
.constant	k54	208
.constant	k55	116
.constant	k56	19
.constant	k57	188
.constant	k58	173
.constant	k59	"NetErrorCode_NONE"
.constant	k60	nil
.constant	k61	"CDataTable"
.constant	k62	"GetTableData"
.constant	k63	202
.constant	k64	60
.constant	k65	182
.constant	k66	"res_id"
.constant	k67	"expire_ts"
.constant	k68	199
.constant	k69	45
.constant	k70	181
.constant	k71	222
.constant	k72	97
.constant	k73	92
.constant	k74	114
.constant	k75	168
.constant	k76	243
.constant	k77	204
.constant	k78	246
.constant	k79	"UpdateLastEquipForeverSkin"
.constant	k80	"ItemType"
.constant	k81	"itemSubType"
.constant	k82	"instid"
.constant	k83	"AddToWearInfo"
.constant	k84	"ItemSubType"
.constant	k85	0
.constant	k86	"WardrobeTab"
.constant	k87	"ENUM_WardrobeSubTabString_parachute"
.constant	k88	"table"
.constant	k89	"concat"
.constant	k90	146
.constant	k91	235
.constant	k92	220
.constant	k93	250
.constant	k94	46
.constant	k95	82
.constant	k96	136
.constant	k97	47
.constant	k98	86
.constant	k99	150
.constant	k100	190
.constant	k101	245
.constant	k102	165
.constant	k103	118
.constant	k104	79
.constant	k105	254
.constant	k106	151
.constant	k107	63
.constant	k108	12
.constant	k109	6
.constant	k110	147
.constant	k111	62
.constant	k112	160
.constant	k113	240
.constant	k114	32
.constant	k115	103
.constant	k116	134
.constant	k117	216
.constant	k118	"UpdateParachute"
.constant	k119	"ENUM_WardrobeSubTabString_plane"
.constant	k120	"UpdatePlaneSkin"
.constant	k121	"ENUM_WardrobeSubTabString_Wingman"
.constant	k122	"UpdataWingmanSkin"
.constant	k123	"ENUM_WardrobeSubTabString_effect"
.constant	k124	153
.constant	k125	39
.constant	k126	25
.constant	k127	169
.constant	k128	111
.constant	k129	18
.constant	k130	180
.constant	k131	251
.constant	k132	253
.constant	k133	226
.constant	k134	94
.constant	k135	225
.constant	k136	158
.constant	k137	55
.constant	k138	195
.constant	k139	117
.constant	k140	177
.constant	k141	230
.constant	k142	58
.constant	k143	"UpdateAircraftOrGliding"
.constant	k144	"IsGlideSmoke"
.constant	k145	"ENUM_WardrobeSubTabString_MiniTVSuit"
.constant	k146	"DataMgr"
.constant	k147	"UpdateMiniTvDress"
.constant	k148	L"ENUM_WardrobeSubTabString_character_MVP_MOTION"
.constant	k149	"UpdateStatueSkin"
.constant	k150	"ENUM_ITEM_SUBTYPE"
.constant	k151	"Helmet"
.constant	k152	"Helmet_NoLevel"
.constant	k153	"ProcPutOnHelmet"
.constant	k154	143
.constant	k155	221
.constant	k156	236
.constant	k157	76
.constant	k158	193
.constant	k159	22
.constant	k160	215
.constant	k161	135
.constant	k162	255
.constant	k163	249
.constant	k164	124
.constant	k165	157
.constant	k166	43
.constant	k167	9
.constant	k168	152
.constant	k169	20
.constant	k170	"send_depot_set_head_show_req"
.constant	k171	"Upgrade_Backpack"
.constant	k172	"Backpack"
.constant	k173	"ProcPutOnBagSkin"
.constant	k174	"WardrobeMainTab"
.constant	k175	"ENUM_WardrobePageType_Avatar"
.constant	k176	"IsTabString_Bag_Helmet_Armor"
.constant	k177	"UpdateEquipmentSkin"
.constant	k178	"CheckPutoffHatAvatar"
.constant	k179	"ENUM_WardrobeSubTabString_helmet"
.constant	k180	"GetEquipmentItemIDBySkinInsID"
.constant	k181	"UpdateRoleWearData"
.constant	k182	184
.constant	k183	244
.constant	k184	21
.constant	k185	11
.constant	k186	237
.constant	k187	"ChangeAvatarEquipment"
.constant	k188	"roleData"
.constant	k189	"uid"
.constant	k190	"AvatarData"
.constant	k191	"CreateAvatarCustom"
.constant	k192	"color"
.constant	k193	"pattern"
.constant	k194	"ResetCurrentWearPreviewMapInited"
.constant	k195	"CheckPutOffHelmetAvatar"
.constant	k196	"ENUM_WardrobeSubTabString_head"
.constant	k197	"ProcPutOnHat"
.constant	k198	145
.constant	k199	2
.constant	k200	214
.constant	k201	121
.constant	k202	77
.constant	k203	37
.constant	k204	"IsXSuit"
.constant	k205	"GetItemShowID"
.constant	k206	"GetPeriodByItemId"
.constant	k207	"GetBranchByItemId"
.constant	k208	"GetDefaultSwitchLevelByItemID"
.constant	k209	"SetSwitchLevelByPeriod"
.constant	k210	"AvatarChange"
.constant	k211	"_SyncSelfXSuitSchemeToLobbyPawn"
.constant	k212	"bWriteLog"
.constant	k213	"GetWornXSuitPeriodAndBranch"
.constant	k214	"log"
.constant	k215	"string"
.constant	k216	"format"
.constant	k217	167
.constant	k218	44
.constant	k219	8
.constant	k220	139
.constant	k221	110
.constant	k222	163
.constant	k223	228
.constant	k224	201
.constant	k225	171
.constant	k226	87
.constant	k227	156
.constant	k228	27
.constant	k229	48
.constant	k230	179
.constant	k231	38
.constant	k232	176
.constant	k233	52
.constant	k234	67
.constant	k235	101
.constant	k236	137
.constant	k237	196
.constant	k238	30
.constant	k239	131
.constant	k240	5
.constant	k241	183
.constant	k242	154
.constant	k243	59
.constant	k244	89
.constant	k245	15
.constant	k246	178
.constant	k247	140
.constant	k248	234
.constant	k249	29
.constant	k250	56
.constant	k251	33
.constant	k252	120
.constant	k253	"tostring"
.constant	k254	229
.constant	k255	"GetSelfSchemeIDList"
.constant	k256	"RefreshSharedRelicInfo"
.constant	k257	"ProcessTakeOff"
.constant	k258	"ENUM_WardrobePageType_Parachute"
.constant	k259	"ENUM_ITEM_TYPE"
.constant	k260	"Hall_Theme"
.constant	k261	"ProcPutOnHallTheme"
.constant	k262	"ENUM_WardrobeSubTabString_throw_object"
.constant	k263	"ShowGrenadeModel"
.constant	k264	"PutOnThrowObjectSkin"
.constant	k265	"ENUM_WardrobeSubTabString_bag_pendant"
.constant	k266	"PutOnBagPendants"
.constant	k267	"ShowBagPendantModel"
.constant	k268	"IsGlideType"
.constant	k269	155
.constant	k270	144
.constant	k271	113
.constant	k272	65
.constant	k273	53
.constant	k274	96
.constant	k275	104
.constant	k276	"HasParaEffectCar"
.constant	k277	"HasGlide"
.constant	k278	"ShowGlideBanner"
.constant	k279	"ShowAircraftNotice"
.constant	k280	"ENUM_WardrobeSubTabString_FootEffect"
.constant	k281	"Foot_Effect"
.constant	k282	"UpdateFootEffect"
.constant	k283	"UpdateCommonPutOnDataBy"
.constant	k284	"PutonEquipment"
.constant	k285	"ProcPutOnWingman"
.constant	k286	"ENUM_WardrobePageType_Vehicle"
.constant	k287	"UpdateVehicleSkin"
.constant	k288	"bFromVehicleType"
.constant	k289	"bUpdateLobbyVehicle"
.constant	k290	"EquipSlotVehicle"
.constant	k291	"tonumber"
.constant	k292	"ProcPutOnVehicle"
.constant	k293	"ENUM_WardrobePageType_Tool"
.constant	k294	24
.constant	k295	194
.constant	k296	129
.constant	k297	57
.constant	k298	13
.constant	k299	14
.constant	k300	248
.constant	k301	"ModuleManager"
.constant	k302	"GetModule"
.constant	k303	"LobbyModuleConfig"
.constant	k304	"LogicAddScordCard"
.constant	k305	"ENUM_WardrobePropResId"
.constant	k306	"RATING_SHIELD_ONCE"
.constant	k307	"RATING_SHIELD_ONCE_SEASON"
.constant	k308	"IsPutOnSeasonAddScoreCard"
.constant	k309	"VS_TEAM_RATING_PROTECT_TIMES_CARD"
.constant	k310	"ProtectCard"
.constant	k311	"PointsProtectionCard"
.constant	k312	"LocUtil"
.constant	k313	"LocalizeResFormat"
.constant	k314	"ItemName"
.constant	k315	"ShowNotice"
.constant	k316	"ClickEffect"
.constant	k317	"CommonModuleConfig"
.constant	k318	"ClickEffectModule"
.constant	k319	"SetCurrentUse"
.constant	k320	"ItemID"
.constant	k321	20051011
.constant	k322	109
.constant	k323	233
.constant	k324	239
.constant	k325	83
.constant	k326	54
.constant	k327	130
.constant	k328	792644
.constant	k329	"UpdateCommonSubtypeWearData"
.constant	k330	"OnPutOffAircraft"
.constant	k331	"RemoveWearInfo"
.constant	k332	"EventSystem"
.constant	k333	"postEvent"
.constant	k334	"EVENTTYPE_WARDROBE"
.constant	k335	"EVENTID_WARDROBE_UPDATE_PUT_ON_DATA"
.constant	k336	"DataModuleConfig"
.constant	k337	"BasicDataAvatarWearInfo"
.constant	k338	"GetOrReqData"
.constant	k339	"bForceReq"
.constant	k340	true
.constant	k341	"Enum_AvatarShowSource"
.constant	k342	"WardrobeLogic"
.constant	k343	"EventSystem"
.constant	k344	"postEvent"
.constant	k345	"EVENTID_WARDROBE_UPDATE_PUT_ON_FAIL"
.constant	k346	80
.constant	k347	"recordTime"
.constant	k348	"GetServerTimeInSec"
.constant	k349	"bTriggerPutOn"
.constant	k350	"RequireBlackList"
.constant	k351	127
.constant	k352	42
.constant	k353	28
.constant	k354	31
.constant	k355	119
.constant	k356	"OnEquipItem"

.line	434	gettabup      r6    u0    k0 ; k0 = "require"
.line	434	getupval      r7    u1
.line	434	loadk         r8    k1 ; k1 = 224
.line	434	loadk         r9    k2 ; k2 = 36
.line	434	loadk        r10    k3 ; k3 = 186
.line	434	loadk        r11    k4 ; k4 = 218
.line	434	loadk        r12    k5 ; k5 = 122
.line	434	loadk        r13    k6 ; k6 = 68
.line	434	loadk        r14    k7 ; k7 = 40
.line	434	loadk        r15    k8 ; k8 = 141
.line	434	loadk        r16    k9 ; k9 = 232
.line	434	loadk        r17   k10 ; k10 = 206
.line	434	loadk        r18   k11 ; k11 = 242
.line	434	loadk        r19   k12 ; k12 = 99
.line	434	loadk        r20   k13 ; k13 = 16
.line	434	loadk        r21   k14 ; k14 = 241
.line	434	loadk        r22   k15 ; k15 = 128
.line	434	loadk        r23    k2 ; k2 = 36
.line	434	loadk        r24   k16 ; k16 = 17
.line	434	loadk        r25   k17 ; k17 = 1
.line	434	loadk        r26    k8 ; k8 = 141
.line	434	loadk        r27   k18 ; k18 = 231
.line	434	loadk        r28   k19 ; k19 = 133
.line	434	loadk        r29   k20 ; k20 = 108
.line	434	loadk        r30   k21 ; k21 = 26
.line	434	loadk        r31   k22 ; k22 = 142
.line	434	loadk        r32   k23 ; k23 = 227
.line	434	loadk        r33   k24 ; k24 = 209
.line	434	loadk        r34   k25 ; k25 = 238
.line	434	loadk        r35   k26 ; k26 = 125
.line	434	loadk        r36   k27 ; k27 = 75
.line	434	loadk        r37   k28 ; k28 = 210
.line	434	loadk        r38   k29 ; k29 = 138
.line	434	loadk        r39   k30 ; k30 = 34
.line	434	loadk        r40   k31 ; k31 = 10
.line	434	loadk        r41   k32 ; k32 = 4
.line	434	loadk        r42   k33 ; k33 = 192
.line	434	call          r7    36     2
.line	434	call          r6     2     2
.line	434	gettabup      r7    u0   k34 ; k34 = "log_tree"
.line	434	getupval      r8    u1
.line	434	loadk         r9   k35 ; k35 = 212
.line	434	loadk        r10   k36 ; k36 = 41
.line	434	loadk        r11   k37 ; k37 = 161
.line	434	loadk        r12   k38 ; k38 = 219
.line	434	loadk        r13   k39 ; k39 = 102
.line	434	loadk        r14   k40 ; k40 = 95
.line	434	loadk        r15   k41 ; k41 = 100
.line	434	loadk        r16   k42 ; k42 = 132
.line	434	loadk        r17   k43 ; k43 = 203
.line	434	loadk        r18   k44 ; k44 = 198
.line	434	loadk        r19   k45 ; k45 = 252
.line	434	loadk        r20   k46 ; k46 = 105
.line	434	loadk        r21   k47 ; k47 = 93
.line	434	loadk        r22   k48 ; k48 = 189
.line	434	loadk        r23   k49 ; k49 = 159
.line	434	loadk        r24   k50 ; k50 = 51
.line	434	loadk        r25   k51 ; k51 = 7
.line	434	loadk        r26   k52 ; k52 = 23
.line	434	loadk        r27   k53 ; k53 = 205
.line	434	loadk        r28   k54 ; k54 = 208
.line	434	loadk        r29    k8 ; k8 = 141
.line	434	loadk        r30   k55 ; k55 = 116
.line	434	loadk        r31   k56 ; k56 = 19
.line	434	loadk        r32   k57 ; k57 = 188
.line	434	loadk        r33   k58 ; k58 = 173
.line	434	call          r8    26     2
.line	434	move          r9    r2
.line	434	call          r7     3     1
.line	434	gettabup      r7    u0   k59 ; k59 = "NetErrorCode_NONE"
.line	434	eq             0    r1    r7
.line	434	jmp            0 l1806
.line	434	eq             0    r2   k60 ; k60 = nil
.line	434	jmp            0   l76
.line	434	return        r0     1
.label	l76
.line	434	gettabup      r7    u0   k61 ; k61 = "CDataTable"
.line	434	gettable      r7    r7   k62 ; k62 = "GetTableData"
.line	434	getupval      r8    u1
.line	434	loadk         r9   k63 ; k63 = 202
.line	434	loadk        r10   k64 ; k64 = 60
.line	434	loadk        r11   k65 ; k65 = 182
.line	434	loadk        r12   k28 ; k28 = 210
.line	434	call          r8     5     2
.line	434	gettable      r9    r2   k66 ; k66 = "res_id"
.line	434	call          r7     3     2
.line	434	eq             1    r7   k60 ; k60 = nil
.line	434	jmp            0 l1763
.line	434	gettable      r8    r2   k67 ; k67 = "expire_ts"
.line	434	test          r8     1
.line	434	jmp            0  l116
.line	434	gettabup      r8    u0   k61 ; k61 = "CDataTable"
.line	434	gettable      r8    r8   k62 ; k62 = "GetTableData"
.line	434	getupval      r9    u1
.line	434	loadk        r10   k68 ; k68 = 199
.line	434	loadk        r11   k69 ; k69 = 45
.line	434	loadk        r12   k70 ; k70 = 181
.line	434	loadk        r13   k71 ; k71 = 222
.line	434	loadk        r14   k72 ; k72 = 97
.line	434	loadk        r15   k73 ; k73 = 92
.line	434	loadk        r16   k74 ; k74 = 114
.line	434	loadk        r17   k75 ; k75 = 168
.line	434	loadk        r18   k76 ; k76 = 243
.line	434	loadk        r19   k77 ; k77 = 204
.line	434	loadk        r20   k78 ; k78 = 246
.line	434	call          r9    12     2
.line	434	gettable     r10    r2   k66 ; k66 = "res_id"
.line	434	call          r8     3     2
.line	434	test          r8     1
.line	434	jmp            0  l116
.line	434	getupval      r9    u2
.line	434	self          r9    r9   k79 ; k79 = "UpdateLastEquipForev" (truncated)
.line	434	gettable     r11    r7   k80 ; k80 = "ItemType"
.line	434	gettable     r12    r7   k81 ; k81 = "itemSubType"
.line	434	gettable     r13    r2   k82 ; k82 = "instid"
.line	434	call          r9     5     1
.label	l116
.line	434	test          r2     0
.line	434	jmp            0  l126
.line	434	getupval      r8    u3
.line	434	self          r8    r8   k83 ; k83 = "AddToWearInfo"
.line	434	gettable     r10    r7   k84 ; k84 = "ItemSubType"
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	gettable     r12    r2   k66 ; k66 = "res_id"
.line	434	loadk        r13   k85 ; k85 = 0
.line	434	loadk        r14   k85 ; k85 = 0
.line	434	call          r8     7     1
.label	l126
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4   k87 ; k87 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l198
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k91 ; k91 = 235
.line	434	loadk        r21   k92 ; k92 = 220
.line	434	loadk        r22   k93 ; k93 = 250
.line	434	loadk        r23   k94 ; k94 = 46
.line	434	loadk        r24   k95 ; k95 = 82
.line	434	loadk        r25   k11 ; k11 = 242
.line	434	loadk        r26   k96 ; k96 = 136
.line	434	loadk        r27   k97 ; k97 = 47
.line	434	loadk        r28   k13 ; k13 = 16
.line	434	loadk        r29   k98 ; k98 = 86
.line	434	loadk        r30   k35 ; k35 = 212
.line	434	loadk        r31   k25 ; k25 = 238
.line	434	loadk        r32   k99 ; k99 = 150
.line	434	loadk        r33   k41 ; k41 = 100
.line	434	loadk        r34   k32 ; k32 = 4
.line	434	loadk        r35  k100 ; k100 = 190
.line	434	loadk        r36  k101 ; k101 = 245
.line	434	loadk        r37   k92 ; k92 = 220
.line	434	loadk        r38  k102 ; k102 = 165
.line	434	loadk        r39  k103 ; k103 = 118
.line	434	loadk        r40  k104 ; k104 = 79
.line	434	loadk        r41  k105 ; k105 = 254
.line	434	loadk        r42  k106 ; k106 = 151
.line	434	loadk        r43  k107 ; k107 = 63
.line	434	loadk        r44  k108 ; k108 = 12
.line	434	loadk        r45  k109 ; k109 = 6
.line	434	loadk        r46   k24 ; k24 = 209
.line	434	loadk        r47  k105 ; k105 = 254
.line	434	loadk        r48  k110 ; k110 = 147
.line	434	loadk        r49  k111 ; k111 = 62
.line	434	loadk        r50   k85 ; k85 = 0
.line	434	loadk        r51  k112 ; k112 = 160
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k113 ; k113 = 240
.line	434	loadk        r14  k114 ; k114 = 32
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16   k54 ; k54 = 208
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18   k95 ; k95 = 82
.line	434	loadk        r19  k115 ; k115 = 103
.line	434	loadk        r20  k116 ; k116 = 134
.line	434	loadk        r21  k117 ; k117 = 216
.line	434	loadk        r22   k53 ; k53 = 205
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k55 ; k55 = 116
.line	434	loadk        r25   k40 ; k40 = 95
.line	434	call         r12    14     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	self          r9    r8  k118 ; k118 = "UpdateParachute"
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	call          r9     3     1
.line	434	jmp            0  l487
.label	l198
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k119 ; k119 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l270
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k91 ; k91 = 235
.line	434	loadk        r21   k92 ; k92 = 220
.line	434	loadk        r22   k93 ; k93 = 250
.line	434	loadk        r23   k94 ; k94 = 46
.line	434	loadk        r24   k95 ; k95 = 82
.line	434	loadk        r25   k11 ; k11 = 242
.line	434	loadk        r26   k96 ; k96 = 136
.line	434	loadk        r27   k97 ; k97 = 47
.line	434	loadk        r28   k13 ; k13 = 16
.line	434	loadk        r29   k98 ; k98 = 86
.line	434	loadk        r30   k35 ; k35 = 212
.line	434	loadk        r31   k25 ; k25 = 238
.line	434	loadk        r32   k99 ; k99 = 150
.line	434	loadk        r33   k41 ; k41 = 100
.line	434	loadk        r34   k32 ; k32 = 4
.line	434	loadk        r35  k100 ; k100 = 190
.line	434	loadk        r36  k101 ; k101 = 245
.line	434	loadk        r37   k92 ; k92 = 220
.line	434	loadk        r38  k102 ; k102 = 165
.line	434	loadk        r39  k103 ; k103 = 118
.line	434	loadk        r40  k104 ; k104 = 79
.line	434	loadk        r41  k105 ; k105 = 254
.line	434	loadk        r42  k106 ; k106 = 151
.line	434	loadk        r43  k107 ; k107 = 63
.line	434	loadk        r44  k108 ; k108 = 12
.line	434	loadk        r45  k109 ; k109 = 6
.line	434	loadk        r46   k24 ; k24 = 209
.line	434	loadk        r47  k105 ; k105 = 254
.line	434	loadk        r48  k110 ; k110 = 147
.line	434	loadk        r49  k111 ; k111 = 62
.line	434	loadk        r50   k85 ; k85 = 0
.line	434	loadk        r51  k112 ; k112 = 160
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k113 ; k113 = 240
.line	434	loadk        r14  k114 ; k114 = 32
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16   k54 ; k54 = 208
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18   k95 ; k95 = 82
.line	434	loadk        r19  k115 ; k115 = 103
.line	434	loadk        r20  k116 ; k116 = 134
.line	434	loadk        r21  k117 ; k117 = 216
.line	434	loadk        r22   k53 ; k53 = 205
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k55 ; k55 = 116
.line	434	loadk        r25   k40 ; k40 = 95
.line	434	call         r12    14     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	self          r9    r8  k120 ; k120 = "UpdatePlaneSkin"
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	call          r9     3     1
.line	434	jmp            0  l487
.label	l270
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k121 ; k121 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l342
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k91 ; k91 = 235
.line	434	loadk        r21   k92 ; k92 = 220
.line	434	loadk        r22   k93 ; k93 = 250
.line	434	loadk        r23   k94 ; k94 = 46
.line	434	loadk        r24   k95 ; k95 = 82
.line	434	loadk        r25   k11 ; k11 = 242
.line	434	loadk        r26   k96 ; k96 = 136
.line	434	loadk        r27   k97 ; k97 = 47
.line	434	loadk        r28   k13 ; k13 = 16
.line	434	loadk        r29   k98 ; k98 = 86
.line	434	loadk        r30   k35 ; k35 = 212
.line	434	loadk        r31   k25 ; k25 = 238
.line	434	loadk        r32   k99 ; k99 = 150
.line	434	loadk        r33   k41 ; k41 = 100
.line	434	loadk        r34   k32 ; k32 = 4
.line	434	loadk        r35  k100 ; k100 = 190
.line	434	loadk        r36  k101 ; k101 = 245
.line	434	loadk        r37   k92 ; k92 = 220
.line	434	loadk        r38  k102 ; k102 = 165
.line	434	loadk        r39  k103 ; k103 = 118
.line	434	loadk        r40  k104 ; k104 = 79
.line	434	loadk        r41  k105 ; k105 = 254
.line	434	loadk        r42  k106 ; k106 = 151
.line	434	loadk        r43  k107 ; k107 = 63
.line	434	loadk        r44  k108 ; k108 = 12
.line	434	loadk        r45  k109 ; k109 = 6
.line	434	loadk        r46   k24 ; k24 = 209
.line	434	loadk        r47  k105 ; k105 = 254
.line	434	loadk        r48  k110 ; k110 = 147
.line	434	loadk        r49  k111 ; k111 = 62
.line	434	loadk        r50   k85 ; k85 = 0
.line	434	loadk        r51  k112 ; k112 = 160
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k113 ; k113 = 240
.line	434	loadk        r14  k114 ; k114 = 32
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16   k54 ; k54 = 208
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18   k95 ; k95 = 82
.line	434	loadk        r19  k115 ; k115 = 103
.line	434	loadk        r20  k116 ; k116 = 134
.line	434	loadk        r21  k117 ; k117 = 216
.line	434	loadk        r22   k53 ; k53 = 205
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k55 ; k55 = 116
.line	434	loadk        r25   k40 ; k40 = 95
.line	434	call         r12    14     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	self          r9    r8  k122 ; k122 = "UpdataWingmanSkin"
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	call          r9     3     1
.line	434	jmp            0  l487
.label	l342
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k123 ; k123 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l470
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19    k8 ; k8 = 141
.line	434	loadk        r20    k9 ; k9 = 232
.line	434	loadk        r21   k10 ; k10 = 206
.line	434	loadk        r22   k11 ; k11 = 242
.line	434	loadk        r23   k12 ; k12 = 99
.line	434	loadk        r24   k13 ; k13 = 16
.line	434	loadk        r25   k45 ; k45 = 252
.line	434	loadk        r26  k124 ; k124 = 153
.line	434	loadk        r27  k125 ; k125 = 39
.line	434	loadk        r28   k51 ; k51 = 7
.line	434	loadk        r29  k126 ; k126 = 25
.line	434	loadk        r30   k24 ; k24 = 209
.line	434	loadk        r31   k37 ; k37 = 161
.line	434	loadk        r32  k127 ; k127 = 169
.line	434	loadk        r33  k128 ; k128 = 111
.line	434	loadk        r34  k129 ; k129 = 18
.line	434	loadk        r35  k130 ; k130 = 180
.line	434	loadk        r36  k131 ; k131 = 251
.line	434	loadk        r37  k132 ; k132 = 253
.line	434	loadk        r38  k133 ; k133 = 226
.line	434	loadk        r39   k12 ; k12 = 99
.line	434	loadk        r40  k134 ; k134 = 94
.line	434	loadk        r41  k135 ; k135 = 225
.line	434	loadk        r42  k136 ; k136 = 158
.line	434	loadk        r43   k97 ; k97 = 47
.line	434	loadk        r44  k137 ; k137 = 55
.line	434	loadk        r45   k16 ; k16 = 17
.line	434	loadk        r46  k138 ; k138 = 195
.line	434	loadk        r47   k93 ; k93 = 250
.line	434	loadk        r48   k57 ; k57 = 188
.line	434	loadk        r49  k139 ; k139 = 117
.line	434	loadk        r50   k31 ; k31 = 10
.line	434	loadk        r51  k140 ; k140 = 177
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k141 ; k141 = 230
.line	434	loadk        r14  k142 ; k142 = 58
.line	434	call         r12     3     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	gettabup      r9    u0    k0 ; k0 = "require"
.line	434	gettabup     r10    u0   k88 ; k88 = "table"
.line	434	gettable     r10   r10   k89 ; k89 = "concat"
.line	434	newtable     r11     1     0
.line	434	getupval     r12    u1
.line	434	loadk        r13    k1 ; k1 = 224
.line	434	loadk        r14    k2 ; k2 = 36
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16    k4 ; k4 = 218
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18    k6 ; k6 = 68
.line	434	loadk        r19    k7 ; k7 = 40
.line	434	loadk        r20   k90 ; k90 = 146
.line	434	loadk        r21   k91 ; k91 = 235
.line	434	loadk        r22   k92 ; k92 = 220
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k94 ; k94 = 46
.line	434	loadk        r25   k95 ; k95 = 82
.line	434	loadk        r26   k11 ; k11 = 242
.line	434	loadk        r27   k96 ; k96 = 136
.line	434	loadk        r28   k97 ; k97 = 47
.line	434	loadk        r29   k13 ; k13 = 16
.line	434	loadk        r30   k98 ; k98 = 86
.line	434	loadk        r31   k35 ; k35 = 212
.line	434	loadk        r32   k25 ; k25 = 238
.line	434	loadk        r33   k99 ; k99 = 150
.line	434	loadk        r34   k41 ; k41 = 100
.line	434	loadk        r35   k32 ; k32 = 4
.line	434	loadk        r36  k100 ; k100 = 190
.line	434	loadk        r37  k101 ; k101 = 245
.line	434	loadk        r38   k92 ; k92 = 220
.line	434	loadk        r39  k102 ; k102 = 165
.line	434	loadk        r40  k103 ; k103 = 118
.line	434	loadk        r41  k104 ; k104 = 79
.line	434	loadk        r42  k105 ; k105 = 254
.line	434	loadk        r43  k106 ; k106 = 151
.line	434	loadk        r44  k107 ; k107 = 63
.line	434	loadk        r45  k108 ; k108 = 12
.line	434	loadk        r46  k109 ; k109 = 6
.line	434	loadk        r47   k24 ; k24 = 209
.line	434	loadk        r48  k105 ; k105 = 254
.line	434	loadk        r49  k110 ; k110 = 147
.line	434	loadk        r50  k111 ; k111 = 62
.line	434	loadk        r51   k85 ; k85 = 0
.line	434	loadk        r52  k112 ; k112 = 160
.line	434	call         r12    41     2
.line	434	getupval     r13    u1
.line	434	loadk        r14  k113 ; k113 = 240
.line	434	loadk        r15  k114 ; k114 = 32
.line	434	loadk        r16    k3 ; k3 = 186
.line	434	loadk        r17   k54 ; k54 = 208
.line	434	loadk        r18    k5 ; k5 = 122
.line	434	loadk        r19   k95 ; k95 = 82
.line	434	loadk        r20  k115 ; k115 = 103
.line	434	loadk        r21  k116 ; k116 = 134
.line	434	loadk        r22  k117 ; k117 = 216
.line	434	loadk        r23   k53 ; k53 = 205
.line	434	loadk        r24   k93 ; k93 = 250
.line	434	loadk        r25   k55 ; k55 = 116
.line	434	loadk        r26   k40 ; k40 = 95
.line	434	call         r13    14     0
.line	434	setlist      r11     0     1
.line	434	call         r10     2     2
.line	434	call          r9     2     2
.line	434	self         r10    r9  k143 ; k143 = "UpdateAircraftOrGlid" (truncated)
.line	434	gettable     r12    r2   k82 ; k82 = "instid"
.line	434	gettable     r13    r8  k144 ; k144 = "IsGlideSmoke"
.line	434	gettable     r14    r7   k81 ; k81 = "itemSubType"
.line	434	call         r13     2     0
.line	434	call         r10     0     1
.line	434	jmp            0  l487
.label	l470
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k145 ; k145 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l479
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r8    r8  k147 ; k147 = "UpdateMiniTvDress"
.line	434	gettable      r9    r2   k66 ; k66 = "res_id"
.line	434	call          r8     2     1
.line	434	jmp            0  l487
.label	l479
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k148 ; k148 = L"ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l487
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r8    r8  k149 ; k149 = "UpdateStatueSkin"
.line	434	gettable      r9    r2   k82 ; k82 = "instid"
.line	434	call          r8     2     1
.label	l487
.line	434	gettable      r8    r7   k81 ; k81 = "itemSubType"
.line	434	gettabup      r9    u0  k150 ; k150 = "ENUM_ITEM_SUBTYPE"
.line	434	gettable      r9    r9  k151 ; k151 = "Helmet"
.line	434	eq             1    r8    r9
.line	434	jmp            0  l497
.line	434	gettable      r8    r7   k81 ; k81 = "itemSubType"
.line	434	gettabup      r9    u0  k150 ; k150 = "ENUM_ITEM_SUBTYPE"
.line	434	gettable      r9    r9  k152 ; k152 = "Helmet_NoLevel"
.line	434	eq             0    r8    r9
.line	434	jmp            0  l548
.label	l497
.line	434	gettable      r8    r6  k153 ; k153 = "ProcPutOnHelmet"
.line	434	move          r9    r2
.line	434	move         r10    r3
.line	434	call          r8     3     1
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	getupval      r9    u1
.line	434	loadk        r10    k1 ; k1 = 224
.line	434	loadk        r11    k2 ; k2 = 36
.line	434	loadk        r12    k3 ; k3 = 186
.line	434	loadk        r13    k4 ; k4 = 218
.line	434	loadk        r14    k5 ; k5 = 122
.line	434	loadk        r15    k6 ; k6 = 68
.line	434	loadk        r16    k7 ; k7 = 40
.line	434	loadk        r17  k154 ; k154 = 143
.line	434	loadk        r18  k133 ; k133 = 226
.line	434	loadk        r19  k155 ; k155 = 221
.line	434	loadk        r20  k156 ; k156 = 236
.line	434	loadk        r21  k128 ; k128 = 111
.line	434	loadk        r22  k157 ; k157 = 76
.line	434	loadk        r23   k78 ; k78 = 246
.line	434	loadk        r24  k158 ; k158 = 193
.line	434	loadk        r25  k159 ; k159 = 22
.line	434	loadk        r26   k17 ; k17 = 1
.line	434	loadk        r27   k52 ; k52 = 23
.line	434	loadk        r28  k160 ; k160 = 215
.line	434	loadk        r29    k1 ; k1 = 224
.line	434	loadk        r30  k161 ; k161 = 135
.line	434	loadk        r31  k128 ; k128 = 111
.line	434	loadk        r32   k21 ; k21 = 26
.line	434	loadk        r33  k162 ; k162 = 255
.line	434	loadk        r34   k33 ; k33 = 192
.line	434	loadk        r35  k117 ; k117 = 216
.line	434	loadk        r36  k163 ; k163 = 249
.line	434	loadk        r37   k55 ; k55 = 116
.line	434	loadk        r38  k164 ; k164 = 124
.line	434	loadk        r39  k133 ; k133 = 226
.line	434	loadk        r40  k165 ; k165 = 157
.line	434	loadk        r41   k50 ; k50 = 51
.line	434	loadk        r42  k166 ; k166 = 43
.line	434	loadk        r43  k167 ; k167 = 9
.line	434	loadk        r44  k155 ; k155 = 221
.line	434	loadk        r45  k131 ; k131 = 251
.line	434	loadk        r46  k168 ; k168 = 152
.line	434	loadk        r47  k139 ; k139 = 117
.line	434	loadk        r48  k169 ; k169 = 20
.line	434	call          r9    40     2
.line	434	call          r8     2     2
.line	434	gettable      r9    r8  k170 ; k170 = "send_depot_set_head_" (truncated)
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	call          r9     2     1
.line	434	jmp            0 l1756
.label	l548
.line	434	gettable      r8    r7   k81 ; k81 = "itemSubType"
.line	434	gettabup      r9    u0  k150 ; k150 = "ENUM_ITEM_SUBTYPE"
.line	434	gettable      r9    r9  k171 ; k171 = "Upgrade_Backpack"
.line	434	eq             1    r8    r9
.line	434	jmp            0  l558
.line	434	gettable      r8    r7   k81 ; k81 = "itemSubType"
.line	434	gettabup      r9    u0  k150 ; k150 = "ENUM_ITEM_SUBTYPE"
.line	434	gettable      r9    r9  k172 ; k172 = "Backpack"
.line	434	eq             0    r8    r9
.line	434	jmp            0  l563
.label	l558
.line	434	gettable      r8    r6  k173 ; k173 = "ProcPutOnBagSkin"
.line	434	move          r9    r2
.line	434	move         r10    r3
.line	434	call          r8     3     1
.line	434	jmp            0 l1756
.label	l563
.line	434	gettable      r8    r7  k174 ; k174 = "WardrobeMainTab"
.line	434	gettabup      r9    u5  k175 ; k175 = "ENUM_WardrobePageTyp" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1120
.line	434	getupval      r8    u3
.line	434	self          r8    r8  k176 ; k176 = "IsTabString_Bag_Helm" (truncated)
.line	434	gettable     r10    r7   k86 ; k86 = "WardrobeTab"
.line	434	call          r8     3     2
.line	434	test          r8     0
.line	434	jmp            0  l721
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r8    r8  k177 ; k177 = "UpdateEquipmentSkin"
.line	434	gettable      r9    r7   k84 ; k84 = "ItemSubType"
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	call          r8     3     1
.line	434	getupval      r8    u3
.line	434	self          r8    r8  k178 ; k178 = "CheckPutoffHatAvatar"
.line	434	move         r10    r7
.line	434	call          r8     3     1
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k179 ; k179 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l632
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	getupval      r9    u1
.line	434	loadk        r10    k1 ; k1 = 224
.line	434	loadk        r11    k2 ; k2 = 36
.line	434	loadk        r12    k3 ; k3 = 186
.line	434	loadk        r13    k4 ; k4 = 218
.line	434	loadk        r14    k5 ; k5 = 122
.line	434	loadk        r15    k6 ; k6 = 68
.line	434	loadk        r16    k7 ; k7 = 40
.line	434	loadk        r17  k154 ; k154 = 143
.line	434	loadk        r18  k133 ; k133 = 226
.line	434	loadk        r19  k155 ; k155 = 221
.line	434	loadk        r20  k156 ; k156 = 236
.line	434	loadk        r21  k128 ; k128 = 111
.line	434	loadk        r22  k157 ; k157 = 76
.line	434	loadk        r23   k78 ; k78 = 246
.line	434	loadk        r24  k158 ; k158 = 193
.line	434	loadk        r25  k159 ; k159 = 22
.line	434	loadk        r26   k17 ; k17 = 1
.line	434	loadk        r27   k52 ; k52 = 23
.line	434	loadk        r28  k160 ; k160 = 215
.line	434	loadk        r29    k1 ; k1 = 224
.line	434	loadk        r30  k161 ; k161 = 135
.line	434	loadk        r31  k128 ; k128 = 111
.line	434	loadk        r32   k21 ; k21 = 26
.line	434	loadk        r33  k162 ; k162 = 255
.line	434	loadk        r34   k33 ; k33 = 192
.line	434	loadk        r35  k117 ; k117 = 216
.line	434	loadk        r36  k163 ; k163 = 249
.line	434	loadk        r37   k55 ; k55 = 116
.line	434	loadk        r38  k164 ; k164 = 124
.line	434	loadk        r39  k133 ; k133 = 226
.line	434	loadk        r40  k165 ; k165 = 157
.line	434	loadk        r41   k50 ; k50 = 51
.line	434	loadk        r42  k166 ; k166 = 43
.line	434	loadk        r43  k167 ; k167 = 9
.line	434	loadk        r44  k155 ; k155 = 221
.line	434	loadk        r45  k131 ; k131 = 251
.line	434	loadk        r46  k168 ; k168 = 152
.line	434	loadk        r47  k139 ; k139 = 117
.line	434	loadk        r48  k169 ; k169 = 20
.line	434	call          r9    40     2
.line	434	call          r8     2     2
.line	434	gettable      r9    r8  k170 ; k170 = "send_depot_set_head_" (truncated)
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	call          r9     2     1
.label	l632
.line	434	getupval      r8    u3
.line	434	self          r8    r8  k180 ; k180 = "GetEquipmentItemIDBy" (truncated)
.line	434	gettable     r10    r7   k84 ; k84 = "ItemSubType"
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	call          r8     4     2
.line	434	test          r3     0
.line	434	jmp            0  l645
.line	434	gettabup      r9    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r9    r9  k181 ; k181 = "UpdateRoleWearData"
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	gettable     r11    r3   k82 ; k82 = "instid"
.line	434	call          r9     3     1
.line	434	jmp            0  l650
.label	l645
.line	434	gettabup      r9    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r9    r9  k181 ; k181 = "UpdateRoleWearData"
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	loadk        r11   k85 ; k85 = 0
.line	434	call          r9     3     1
.label	l650
.line	434	le             0   k85    r8 ; k85 = 0
.line	434	jmp            0 l1115
.line	434	gettabup      r9    u0    k0 ; k0 = "require"
.line	434	gettabup     r10    u0   k88 ; k88 = "table"
.line	434	gettable     r10   r10   k89 ; k89 = "concat"
.line	434	newtable     r11     1     0
.line	434	getupval     r12    u1
.line	434	loadk        r13    k1 ; k1 = 224
.line	434	loadk        r14    k2 ; k2 = 36
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16    k4 ; k4 = 218
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18    k6 ; k6 = 68
.line	434	loadk        r19    k7 ; k7 = 40
.line	434	loadk        r20    k8 ; k8 = 141
.line	434	loadk        r21    k9 ; k9 = 232
.line	434	loadk        r22   k10 ; k10 = 206
.line	434	loadk        r23   k11 ; k11 = 242
.line	434	loadk        r24   k12 ; k12 = 99
.line	434	loadk        r25   k13 ; k13 = 16
.line	434	loadk        r26   k45 ; k45 = 252
.line	434	loadk        r27  k124 ; k124 = 153
.line	434	loadk        r28  k125 ; k125 = 39
.line	434	loadk        r29   k51 ; k51 = 7
.line	434	loadk        r30  k126 ; k126 = 25
.line	434	loadk        r31   k24 ; k24 = 209
.line	434	loadk        r32   k37 ; k37 = 161
.line	434	loadk        r33   k96 ; k96 = 136
.line	434	loadk        r34  k128 ; k128 = 111
.line	434	loadk        r35   k16 ; k16 = 17
.line	434	loadk        r36  k182 ; k182 = 184
.line	434	loadk        r37  k183 ; k183 = 244
.line	434	loadk        r38  k141 ; k141 = 230
.line	434	loadk        r39  k162 ; k162 = 255
.line	434	loadk        r40  k139 ; k139 = 117
.line	434	loadk        r41  k104 ; k104 = 79
.line	434	loadk        r42    k1 ; k1 = 224
.line	434	loadk        r43  k112 ; k112 = 160
.line	434	loadk        r44  k137 ; k137 = 55
.line	434	loadk        r45  k184 ; k184 = 21
.line	434	loadk        r46  k167 ; k167 = 9
.line	434	loadk        r47   k68 ; k68 = 199
.line	434	loadk        r48  k105 ; k105 = 254
.line	434	loadk        r49  k116 ; k116 = 134
.line	434	loadk        r50  k104 ; k104 = 79
.line	434	loadk        r51  k185 ; k185 = 11
.line	434	loadk        r52  k112 ; k112 = 160
.line	434	call         r12    41     2
.line	434	getupval     r13    u1
.line	434	loadk        r14  k186 ; k186 = 237
.line	434	loadk        r15   k36 ; k36 = 41
.line	434	loadk        r16  k130 ; k130 = 180
.line	434	loadk        r17    k4 ; k4 = 218
.line	434	loadk        r18   k39 ; k39 = 102
.line	434	call         r13     6     0
.line	434	setlist      r11     0     1
.line	434	call         r10     2     2
.line	434	call          r9     2     2
.line	434	gettable     r10    r9  k187 ; k187 = "ChangeAvatarEquipmen" (truncated)
.line	434	gettabup     r11    u0  k146 ; k146 = "DataMgr"
.line	434	gettable     r11   r11  k188 ; k188 = "roleData"
.line	434	gettable     r11   r11  k189 ; k189 = "uid"
.line	434	gettabup     r12    u0  k190 ; k190 = "AvatarData"
.line	434	gettable     r12   r12  k191 ; k191 = "CreateAvatarCustom"
.line	434	move         r13    r8
.line	434	gettable     r14    r2  k192 ; k192 = "color"
.line	434	gettable     r15    r2  k193 ; k193 = "pattern"
.line	434	call         r12     4     2
.line	434	loadbool     r13     1     0
.line	434	call         r10     4     1
.line	434	jmp            0 l1115
.label	l721
.line	434	test          r3     0
.line	434	jmp            0  l732
.line	434	getupval      r8    u3
.line	434	self          r8    r8  k194 ; k194 = "ResetCurrentWearPrev" (truncated)
.line	434	call          r8     2     1
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r8    r8  k181 ; k181 = "UpdateRoleWearData"
.line	434	gettable      r9    r2   k82 ; k82 = "instid"
.line	434	gettable     r10    r3   k82 ; k82 = "instid"
.line	434	call          r8     3     1
.line	434	jmp            0  l737
.label	l732
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	gettable      r8    r8  k181 ; k181 = "UpdateRoleWearData"
.line	434	gettable      r9    r2   k82 ; k82 = "instid"
.line	434	loadk        r10   k85 ; k85 = 0
.line	434	call          r8     3     1
.label	l737
.line	434	getupval      r8    u3
.line	434	self          r8    r8  k195 ; k195 = "CheckPutOffHelmetAva" (truncated)
.line	434	move         r10    r7
.line	434	call          r8     3     1
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k196 ; k196 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0  l794
.line	434	gettable      r8    r6  k197 ; k197 = "ProcPutOnHat"
.line	434	move          r9    r2
.line	434	call          r8     2     1
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	getupval      r9    u1
.line	434	loadk        r10    k1 ; k1 = 224
.line	434	loadk        r11    k2 ; k2 = 36
.line	434	loadk        r12    k3 ; k3 = 186
.line	434	loadk        r13    k4 ; k4 = 218
.line	434	loadk        r14    k5 ; k5 = 122
.line	434	loadk        r15    k6 ; k6 = 68
.line	434	loadk        r16    k7 ; k7 = 40
.line	434	loadk        r17  k154 ; k154 = 143
.line	434	loadk        r18  k133 ; k133 = 226
.line	434	loadk        r19  k155 ; k155 = 221
.line	434	loadk        r20  k156 ; k156 = 236
.line	434	loadk        r21  k128 ; k128 = 111
.line	434	loadk        r22  k157 ; k157 = 76
.line	434	loadk        r23   k78 ; k78 = 246
.line	434	loadk        r24  k158 ; k158 = 193
.line	434	loadk        r25  k159 ; k159 = 22
.line	434	loadk        r26   k17 ; k17 = 1
.line	434	loadk        r27   k52 ; k52 = 23
.line	434	loadk        r28  k160 ; k160 = 215
.line	434	loadk        r29    k1 ; k1 = 224
.line	434	loadk        r30  k161 ; k161 = 135
.line	434	loadk        r31  k128 ; k128 = 111
.line	434	loadk        r32   k21 ; k21 = 26
.line	434	loadk        r33  k162 ; k162 = 255
.line	434	loadk        r34   k33 ; k33 = 192
.line	434	loadk        r35  k117 ; k117 = 216
.line	434	loadk        r36  k163 ; k163 = 249
.line	434	loadk        r37   k55 ; k55 = 116
.line	434	loadk        r38  k164 ; k164 = 124
.line	434	loadk        r39  k133 ; k133 = 226
.line	434	loadk        r40  k165 ; k165 = 157
.line	434	loadk        r41   k50 ; k50 = 51
.line	434	loadk        r42  k166 ; k166 = 43
.line	434	loadk        r43  k167 ; k167 = 9
.line	434	loadk        r44  k155 ; k155 = 221
.line	434	loadk        r45  k131 ; k131 = 251
.line	434	loadk        r46  k168 ; k168 = 152
.line	434	loadk        r47  k139 ; k139 = 117
.line	434	loadk        r48  k169 ; k169 = 20
.line	434	call          r9    40     2
.line	434	call          r8     2     2
.line	434	gettable      r9    r8  k170 ; k170 = "send_depot_set_head_" (truncated)
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	call          r9     2     1
.label	l794
.line	434	gettable      r8    r2   k66 ; k66 = "res_id"
.line	434	loadbool      r9     0     0
.line	434	gettabup     r10    u0    k0 ; k0 = "require"
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k91 ; k91 = 235
.line	434	loadk        r21   k92 ; k92 = 220
.line	434	loadk        r22   k93 ; k93 = 250
.line	434	loadk        r23   k94 ; k94 = 46
.line	434	loadk        r24   k95 ; k95 = 82
.line	434	loadk        r25   k11 ; k11 = 242
.line	434	loadk        r26   k96 ; k96 = 136
.line	434	loadk        r27   k97 ; k97 = 47
.line	434	loadk        r28   k13 ; k13 = 16
.line	434	loadk        r29   k98 ; k98 = 86
.line	434	loadk        r30  k131 ; k131 = 251
.line	434	loadk        r31   k92 ; k92 = 220
.line	434	loadk        r32  k198 ; k198 = 145
.line	434	loadk        r33   k46 ; k46 = 105
.line	434	loadk        r34  k199 ; k199 = 2
.line	434	loadk        r35  k162 ; k162 = 255
.line	434	loadk        r36  k131 ; k131 = 251
.line	434	loadk        r37  k200 ; k200 = 214
.line	434	loadk        r38  k156 ; k156 = 236
.line	434	loadk        r39  k201 ; k201 = 121
.line	434	loadk        r40  k202 ; k202 = 77
.line	434	loadk        r41   k28 ; k28 = 210
.line	434	loadk        r42  k161 ; k161 = 135
.line	434	loadk        r43  k203 ; k203 = 37
.line	434	loadk        r44  k159 ; k159 = 22
.line	434	loadk        r45   k17 ; k17 = 1
.line	434	loadk        r46   k68 ; k68 = 199
.line	434	call         r11    36     2
.line	434	call         r10     2     2
.line	434	gettable     r11   r10  k204 ; k204 = "IsXSuit"
.line	434	move         r12    r8
.line	434	call         r11     2     2
.line	434	test         r11     0
.line	434	jmp            0  l894
.line	434	gettable     r11   r10  k205 ; k205 = "GetItemShowID"
.line	434	gettable     r12    r2   k82 ; k82 = "instid"
.line	434	call         r11     2     2
.line	434	move          r8   r11
.line	434	test          r3     0
.line	434	jmp            0  l874
.line	434	gettable     r11    r3   k66 ; k66 = "res_id"
.line	434	test         r11     0
.line	434	jmp            0  l874
.line	434	gettable     r11   r10  k206 ; k206 = "GetPeriodByItemId"
.line	434	gettable     r12    r2   k66 ; k66 = "res_id"
.line	434	call         r11     2     2
.line	434	gettable     r12   r10  k206 ; k206 = "GetPeriodByItemId"
.line	434	gettable     r13    r3   k66 ; k66 = "res_id"
.line	434	call         r12     2     2
.line	434	eq             0   r11   r12
.line	434	jmp            0  l874
.line	434	gettable     r11   r10  k207 ; k207 = "GetBranchByItemId"
.line	434	gettable     r12    r3   k66 ; k66 = "res_id"
.line	434	call         r11     2     2
.line	434	test         r11     1
.line	434	jmp            0  l863
.line	434	loadk        r11   k85 ; k85 = 0
.label	l863
.line	434	gettable     r12   r10  k207 ; k207 = "GetBranchByItemId"
.line	434	gettable     r13    r2   k66 ; k66 = "res_id"
.line	434	call         r12     2     2
.line	434	test         r12     1
.line	434	jmp            0  l869
.line	434	loadk        r12   k85 ; k85 = 0
.label	l869
.line	434	eq             0   r11   r12
.line	434	jmp            0  l872
.line	434	loadbool      r9     0     1
.label	l872
.line	434	loadbool      r9     1     0
.line	434	jmp            0  l887
.label	l874
.line	434	gettable     r11   r10  k208 ; k208 = "GetDefaultSwitchLeve" (truncated)
.line	434	gettable     r12    r2   k66 ; k66 = "res_id"
.line	434	call         r11     2     2
.line	434	gettable     r12   r10  k207 ; k207 = "GetBranchByItemId"
.line	434	gettable     r13    r2   k66 ; k66 = "res_id"
.line	434	call         r12     2     2
.line	434	gettable     r13   r10  k209 ; k209 = "SetSwitchLevelByPeri" (truncated)
.line	434	gettable     r14   r10  k206 ; k206 = "GetPeriodByItemId"
.line	434	gettable     r15    r2   k66 ; k66 = "res_id"
.line	434	call         r14     2     2
.line	434	move         r15   r11
.line	434	move         r16   r12
.line	434	call         r13     4     1
.label	l887
.line	434	getupval     r11    u6
.line	434	move         r12    r2
.line	434	move         r13    r7
.line	434	call         r11     3     1
.line	434	getupval     r11    u7
.line	434	move         r12    r2
.line	434	call         r11     2     1
.label	l894
.line	434	getupval     r11    u3
.line	434	self         r11   r11  k210 ; k210 = "AvatarChange"
.line	434	move         r13    r8
.line	434	loadbool     r14     1     0
.line	434	gettable     r15    r2  k192 ; k192 = "color"
.line	434	gettable     r16    r2  k193 ; k193 = "pattern"
.line	434	call         r11     6     1
.line	434	test          r9     0
.line	434	jmp            0 l1112
.line	434	gettable     r11   r10  k211 ; k211 = "_SyncSelfXSuitScheme" (truncated)
.line	434	call         r11     1     1
.line	434	gettabup     r11    u0  k212 ; k212 = "bWriteLog"
.line	434	test         r11     0
.line	434	jmp            0 l1112
.line	434	gettable     r11   r10  k213 ; k213 = "GetWornXSuitPeriodAn" (truncated)
.line	434	call         r11     1     3
.line	434	gettabup     r13    u0  k214 ; k214 = "log"
.line	434	gettabup     r14    u0  k212 ; k212 = "bWriteLog"
.line	434	test         r14     0
.line	434	jmp            0 l1068
.line	434	gettabup     r14    u0  k215 ; k215 = "string"
.line	434	gettable     r14   r14  k216 ; k216 = "format"
.line	434	gettabup     r15    u0   k88 ; k88 = "table"
.line	434	gettable     r15   r15   k89 ; k89 = "concat"
.line	434	newtable     r16     3     0
.line	434	getupval     r17    u1
.line	434	loadk        r18   k35 ; k35 = 212
.line	434	loadk        r19   k36 ; k36 = 41
.line	434	loadk        r20   k37 ; k37 = 161
.line	434	loadk        r21   k38 ; k38 = 219
.line	434	loadk        r22   k39 ; k39 = 102
.line	434	loadk        r23   k40 ; k40 = 95
.line	434	loadk        r24   k41 ; k41 = 100
.line	434	loadk        r25   k42 ; k42 = 132
.line	434	loadk        r26   k43 ; k43 = 203
.line	434	loadk        r27   k44 ; k44 = 198
.line	434	loadk        r28   k45 ; k45 = 252
.line	434	loadk        r29   k46 ; k46 = 105
.line	434	loadk        r30   k47 ; k47 = 93
.line	434	loadk        r31  k217 ; k217 = 167
.line	434	loadk        r32   k15 ; k15 = 128
.line	434	loadk        r33    k7 ; k7 = 40
.line	434	loadk        r34  k218 ; k218 = 44
.line	434	loadk        r35  k219 ; k219 = 8
.line	434	loadk        r36  k200 ; k200 = 214
.line	434	loadk        r37  k131 ; k131 = 251
.line	434	loadk        r38  k220 ; k220 = 139
.line	434	loadk        r39  k221 ; k221 = 110
.line	434	loadk        r40   k36 ; k36 = 41
.line	434	loadk        r41  k222 ; k222 = 163
.line	434	loadk        r42  k223 ; k223 = 228
.line	434	loadk        r43  k224 ; k224 = 201
.line	434	loadk        r44  k225 ; k225 = 171
.line	434	loadk        r45   k12 ; k12 = 99
.line	434	loadk        r46  k226 ; k226 = 87
.line	434	loadk        r47   k23 ; k23 = 227
.line	434	loadk        r48  k227 ; k227 = 156
.line	434	loadk        r49  k103 ; k103 = 118
.line	434	loadk        r50  k228 ; k228 = 27
.line	434	loadk        r51  k228 ; k228 = 27
.line	434	loadk        r52   k44 ; k44 = 198
.line	434	loadk        r53   k78 ; k78 = 246
.line	434	loadk        r54   k15 ; k15 = 128
.line	434	loadk        r55  k229 ; k229 = 48
.line	434	loadk        r56   k32 ; k32 = 4
.line	434	loadk        r57  k230 ; k230 = 179
.line	434	call         r17    41     2
.line	434	getupval     r18    u1
.line	434	loadk        r19  k133 ; k133 = 226
.line	434	loadk        r20  k231 ; k231 = 38
.line	434	loadk        r21  k232 ; k232 = 176
.line	434	loadk        r22  k160 ; k160 = 215
.line	434	loadk        r23  k233 ; k233 = 52
.line	434	loadk        r24  k234 ; k234 = 67
.line	434	loadk        r25  k235 ; k235 = 101
.line	434	loadk        r26  k236 ; k236 = 137
.line	434	loadk        r27  k133 ; k133 = 226
.line	434	loadk        r28  k237 ; k237 = 196
.line	434	loadk        r29  k105 ; k105 = 254
.line	434	loadk        r30  k218 ; k218 = 44
.line	434	loadk        r31  k238 ; k238 = 30
.line	434	loadk        r32   k11 ; k11 = 242
.line	434	loadk        r33  k239 ; k239 = 131
.line	434	loadk        r34   k30 ; k30 = 34
.line	434	loadk        r35  k142 ; k142 = 58
.line	434	loadk        r36  k108 ; k108 = 12
.line	434	loadk        r37   k44 ; k44 = 198
.line	434	loadk        r38  k133 ; k133 = 226
.line	434	loadk        r39   k71 ; k71 = 222
.line	434	loadk        r40  k203 ; k203 = 37
.line	434	loadk        r41  k240 ; k240 = 5
.line	434	loadk        r42  k132 ; k132 = 253
.line	434	loadk        r43  k241 ; k241 = 183
.line	434	loadk        r44  k160 ; k160 = 215
.line	434	loadk        r45   k25 ; k25 = 238
.line	434	loadk        r46  k115 ; k115 = 103
.line	434	loadk        r47  k115 ; k115 = 103
.line	434	loadk        r48  k163 ; k163 = 249
.line	434	loadk        r49  k242 ; k242 = 154
.line	434	loadk        r50  k243 ; k243 = 59
.line	434	loadk        r51  k244 ; k244 = 89
.line	434	loadk        r52  k202 ; k202 = 77
.line	434	loadk        r53   k33 ; k33 = 192
.line	434	loadk        r54  k230 ; k230 = 179
.line	434	loadk        r55   k35 ; k35 = 212
.line	434	loadk        r56   k55 ; k55 = 116
.line	434	loadk        r57  k245 ; k245 = 15
.line	434	loadk        r58  k246 ; k246 = 178
.line	434	call         r18    41     2
.line	434	getupval     r19    u1
.line	434	loadk        r20   k76 ; k76 = 243
.line	434	loadk        r21    k2 ; k2 = 36
.line	434	loadk        r22  k246 ; k246 = 178
.line	434	loadk        r23   k44 ; k44 = 198
.line	434	loadk        r24   k47 ; k47 = 93
.line	434	loadk        r25    k6 ; k6 = 68
.line	434	loadk        r26   k12 ; k12 = 99
.line	434	loadk        r27  k247 ; k247 = 140
.line	434	loadk        r28   k48 ; k48 = 189
.line	434	loadk        r29  k247 ; k247 = 140
.line	434	loadk        r30    k9 ; k9 = 232
.line	434	loadk        r31  k218 ; k218 = 44
.line	434	loadk        r32  k238 ; k238 = 30
.line	434	loadk        r33  k248 ; k248 = 234
.line	434	loadk        r34   k15 ; k15 = 128
.line	434	loadk        r35  k233 ; k233 = 52
.line	434	loadk        r36  k249 ; k249 = 29
.line	434	loadk        r37    k7 ; k7 = 40
.line	434	loadk        r38   k44 ; k44 = 198
.line	434	loadk        r39  k132 ; k132 = 253
.line	434	loadk        r40    k8 ; k8 = 141
.line	434	loadk        r41  k128 ; k128 = 111
.line	434	loadk        r42  k129 ; k129 = 18
.line	434	loadk        r43   k91 ; k91 = 235
.line	434	loadk        r44  k246 ; k246 = 178
.line	434	loadk        r45   k63 ; k63 = 202
.line	434	loadk        r46  k217 ; k217 = 167
.line	434	loadk        r47  k229 ; k229 = 48
.line	434	loadk        r48  k244 ; k244 = 89
.line	434	loadk        r49  k133 ; k133 = 226
.line	434	loadk        r50    k8 ; k8 = 141
.line	434	loadk        r51  k250 ; k250 = 56
.line	434	loadk        r52  k251 ; k251 = 33
.line	434	loadk        r53   k21 ; k21 = 26
.line	434	loadk        r54   k28 ; k28 = 210
.line	434	loadk        r55   k14 ; k14 = 241
.line	434	loadk        r56  k106 ; k106 = 151
.line	434	loadk        r57  k252 ; k252 = 120
.line	434	loadk        r58   k73 ; k73 = 92
.line	434	loadk        r59  k223 ; k223 = 228
.line	434	call         r19    41     2
.line	434	getupval     r20    u1
.line	434	loadk        r21  k113 ; k113 = 240
.line	434	call         r20     2     0
.line	434	setlist      r16     0     1
.line	434	call         r15     2     2
.line	434	gettabup     r16    u0  k253 ; k253 = "tostring"
.line	434	testset      r17    r3     0
.line	434	jmp            0 l1054
.line	434	gettable     r17    r3   k66 ; k66 = "res_id"
.label	l1054
.line	434	call         r16     2     2
.line	434	gettabup     r17    u0  k253 ; k253 = "tostring"
.line	434	gettable     r18    r2   k66 ; k66 = "res_id"
.line	434	call         r17     2     2
.line	434	gettabup     r18    u0  k253 ; k253 = "tostring"
.line	434	move         r19    r8
.line	434	call         r18     2     2
.line	434	gettabup     r19    u0  k253 ; k253 = "tostring"
.line	434	move         r20   r11
.line	434	call         r19     2     2
.line	434	gettabup     r20    u0  k253 ; k253 = "tostring"
.line	434	move         r21   r12
.line	434	call         r20     2     0
.line	434	call         r14     0     2
.label	l1068
.line	434	call         r13     2     1
.line	434	gettabup     r13    u0   k34 ; k34 = "log_tree"
.line	434	getupval     r14    u1
.line	434	loadk        r15   k35 ; k35 = 212
.line	434	loadk        r16   k36 ; k36 = 41
.line	434	loadk        r17   k37 ; k37 = 161
.line	434	loadk        r18   k38 ; k38 = 219
.line	434	loadk        r19   k39 ; k39 = 102
.line	434	loadk        r20   k40 ; k40 = 95
.line	434	loadk        r21   k41 ; k41 = 100
.line	434	loadk        r22   k42 ; k42 = 132
.line	434	loadk        r23   k43 ; k43 = 203
.line	434	loadk        r24   k44 ; k44 = 198
.line	434	loadk        r25   k45 ; k45 = 252
.line	434	loadk        r26   k46 ; k46 = 105
.line	434	loadk        r27   k47 ; k47 = 93
.line	434	loadk        r28  k217 ; k217 = 167
.line	434	loadk        r29   k15 ; k15 = 128
.line	434	loadk        r30    k7 ; k7 = 40
.line	434	loadk        r31  k218 ; k218 = 44
.line	434	loadk        r32  k219 ; k219 = 8
.line	434	loadk        r33  k200 ; k200 = 214
.line	434	loadk        r34  k131 ; k131 = 251
.line	434	loadk        r35  k220 ; k220 = 139
.line	434	loadk        r36  k221 ; k221 = 110
.line	434	loadk        r37   k36 ; k36 = 41
.line	434	loadk        r38  k222 ; k222 = 163
.line	434	loadk        r39  k223 ; k223 = 228
.line	434	loadk        r40  k224 ; k224 = 201
.line	434	loadk        r41  k225 ; k225 = 171
.line	434	loadk        r42   k12 ; k12 = 99
.line	434	loadk        r43  k202 ; k202 = 77
.line	434	loadk        r44  k254 ; k254 = 229
.line	434	loadk        r45  k242 ; k242 = 154
.line	434	loadk        r46  k243 ; k243 = 59
.line	434	loadk        r47  k109 ; k109 = 6
.line	434	loadk        r48    k2 ; k2 = 36
.line	434	loadk        r49    k4 ; k4 = 218
.line	434	loadk        r50  k156 ; k156 = 236
.line	434	loadk        r51   k15 ; k15 = 128
.line	434	call         r14    38     2
.line	434	gettable     r15   r10  k255 ; k255 = "GetSelfSchemeIDList"
.line	434	call         r15     1     0
.line	434	call         r13     0     1
.label	l1112
.line	434	loadk        r11  k256 ; k256 = "RefreshSharedRelicIn" (truncated)
.line	434	gettable     r11   r10   r11
.line	434	call         r11     1     1
.label	l1115
.line	434	getupval      r8    u3
.line	434	loadk        r10  k257 ; k257 = "ProcessTakeOff"
.line	434	self          r8    r8   r10
.line	434	call          r8     2     1
.line	434	jmp            0 l1756
.label	l1120
.line	434	gettable      r8    r7  k174 ; k174 = "WardrobeMainTab"
.line	434	loadk         r9  k258 ; k258 = "ENUM_WardrobePageTyp" (truncated)
.line	434	gettabup      r9    u5    r9
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1527
.line	434	gettable      r8    r7   k80 ; k80 = "ItemType"
.line	434	loadk         r9  k259 ; k259 = "ENUM_ITEM_TYPE"
.line	434	gettabup      r9    u0    r9
.line	434	loadk        r10  k260 ; k260 = "Hall_Theme"
.line	434	gettable      r9    r9   r10
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1138
.line	434	loadk         r8  k261 ; k261 = "ProcPutOnHallTheme"
.line	434	gettable      r8    r6    r8
.line	434	move          r9    r2
.line	434	move         r10    r3
.line	434	call          r8     3     1
.line	434	jmp            0 l1756
.label	l1138
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	loadk         r9  k262 ; k262 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	gettabup      r9    u4    r9
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1217
.line	434	loadk        r10  k263 ; k263 = "ShowGrenadeModel"
.line	434	self          r8    r0   r10
.line	434	gettable     r10    r2   k66 ; k66 = "res_id"
.line	434	call          r8     3     1
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k91 ; k91 = 235
.line	434	loadk        r21   k92 ; k92 = 220
.line	434	loadk        r22   k93 ; k93 = 250
.line	434	loadk        r23   k94 ; k94 = 46
.line	434	loadk        r24   k95 ; k95 = 82
.line	434	loadk        r25   k11 ; k11 = 242
.line	434	loadk        r26   k96 ; k96 = 136
.line	434	loadk        r27   k97 ; k97 = 47
.line	434	loadk        r28   k13 ; k13 = 16
.line	434	loadk        r29   k98 ; k98 = 86
.line	434	loadk        r30   k35 ; k35 = 212
.line	434	loadk        r31   k25 ; k25 = 238
.line	434	loadk        r32   k99 ; k99 = 150
.line	434	loadk        r33   k41 ; k41 = 100
.line	434	loadk        r34   k32 ; k32 = 4
.line	434	loadk        r35  k100 ; k100 = 190
.line	434	loadk        r36  k101 ; k101 = 245
.line	434	loadk        r37   k92 ; k92 = 220
.line	434	loadk        r38  k102 ; k102 = 165
.line	434	loadk        r39  k103 ; k103 = 118
.line	434	loadk        r40  k104 ; k104 = 79
.line	434	loadk        r41  k105 ; k105 = 254
.line	434	loadk        r42  k106 ; k106 = 151
.line	434	loadk        r43  k107 ; k107 = 63
.line	434	loadk        r44  k108 ; k108 = 12
.line	434	loadk        r45  k109 ; k109 = 6
.line	434	loadk        r46   k24 ; k24 = 209
.line	434	loadk        r47  k105 ; k105 = 254
.line	434	loadk        r48  k110 ; k110 = 147
.line	434	loadk        r49  k111 ; k111 = 62
.line	434	loadk        r50   k85 ; k85 = 0
.line	434	loadk        r51  k112 ; k112 = 160
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k113 ; k113 = 240
.line	434	loadk        r14  k114 ; k114 = 32
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16   k54 ; k54 = 208
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18   k95 ; k95 = 82
.line	434	loadk        r19  k115 ; k115 = 103
.line	434	loadk        r20  k116 ; k116 = 134
.line	434	loadk        r21  k117 ; k117 = 216
.line	434	loadk        r22   k53 ; k53 = 205
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k55 ; k55 = 116
.line	434	loadk        r25   k40 ; k40 = 95
.line	434	call         r12    14     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	loadk        r11  k264 ; k264 = "PutOnThrowObjectSkin"
.line	434	self          r9    r8   r11
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	move         r12    r4
.line	434	call          r9     4     1
.line	434	jmp            0 l1756
.label	l1217
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	loadk         r9  k265 ; k265 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	gettabup      r9    u4    r9
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1302
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k91 ; k91 = 235
.line	434	loadk        r21   k92 ; k92 = 220
.line	434	loadk        r22   k93 ; k93 = 250
.line	434	loadk        r23   k94 ; k94 = 46
.line	434	loadk        r24   k95 ; k95 = 82
.line	434	loadk        r25   k11 ; k11 = 242
.line	434	loadk        r26   k96 ; k96 = 136
.line	434	loadk        r27   k97 ; k97 = 47
.line	434	loadk        r28   k13 ; k13 = 16
.line	434	loadk        r29   k98 ; k98 = 86
.line	434	loadk        r30   k35 ; k35 = 212
.line	434	loadk        r31   k25 ; k25 = 238
.line	434	loadk        r32   k99 ; k99 = 150
.line	434	loadk        r33   k41 ; k41 = 100
.line	434	loadk        r34   k32 ; k32 = 4
.line	434	loadk        r35  k100 ; k100 = 190
.line	434	loadk        r36  k101 ; k101 = 245
.line	434	loadk        r37   k92 ; k92 = 220
.line	434	loadk        r38  k102 ; k102 = 165
.line	434	loadk        r39  k103 ; k103 = 118
.line	434	loadk        r40  k104 ; k104 = 79
.line	434	loadk        r41  k105 ; k105 = 254
.line	434	loadk        r42  k106 ; k106 = 151
.line	434	loadk        r43  k107 ; k107 = 63
.line	434	loadk        r44  k108 ; k108 = 12
.line	434	loadk        r45  k109 ; k109 = 6
.line	434	loadk        r46   k24 ; k24 = 209
.line	434	loadk        r47  k105 ; k105 = 254
.line	434	loadk        r48  k110 ; k110 = 147
.line	434	loadk        r49  k111 ; k111 = 62
.line	434	loadk        r50   k85 ; k85 = 0
.line	434	loadk        r51  k112 ; k112 = 160
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k113 ; k113 = 240
.line	434	loadk        r14  k114 ; k114 = 32
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16   k54 ; k54 = 208
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18   k95 ; k95 = 82
.line	434	loadk        r19  k115 ; k115 = 103
.line	434	loadk        r20  k116 ; k116 = 134
.line	434	loadk        r21  k117 ; k117 = 216
.line	434	loadk        r22   k53 ; k53 = 205
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k55 ; k55 = 116
.line	434	loadk        r25   k40 ; k40 = 95
.line	434	call         r12    14     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	loadk        r11  k266 ; k266 = "PutOnBagPendants"
.line	434	self          r9    r8   r11
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	test          r3     0
.line	434	jmp            0 l1294
.line	434	gettable     r12    r3   k82 ; k82 = "instid"
.line	434	test         r12     1
.line	434	jmp            0 l1295
.label	l1294
.line	434	loadk        r12   k85 ; k85 = 0
.label	l1295
.line	434	call          r9     4     1
.line	434	loadk        r11  k267 ; k267 = "ShowBagPendantModel"
.line	434	self          r9    r0   r11
.line	434	gettable     r11    r2   k82 ; k82 = "instid"
.line	434	loadbool     r12     1     0
.line	434	call          r9     4     1
.line	434	jmp            0 l1756
.label	l1302
.line	434	loadk         r8  k268 ; k268 = "IsGlideType"
.line	434	gettabup      r8    u8    r8
.line	434	gettable      r9    r7   k84 ; k84 = "ItemSubType"
.line	434	call          r8     2     2
.line	434	test          r8     0
.line	434	jmp            0 l1431
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	getupval      r9    u1
.line	434	loadk        r10    k1 ; k1 = 224
.line	434	loadk        r11    k2 ; k2 = 36
.line	434	loadk        r12    k3 ; k3 = 186
.line	434	loadk        r13    k4 ; k4 = 218
.line	434	loadk        r14    k5 ; k5 = 122
.line	434	loadk        r15    k6 ; k6 = 68
.line	434	loadk        r16    k7 ; k7 = 40
.line	434	loadk        r17   k90 ; k90 = 146
.line	434	loadk        r18   k91 ; k91 = 235
.line	434	loadk        r19   k92 ; k92 = 220
.line	434	loadk        r20   k93 ; k93 = 250
.line	434	loadk        r21   k94 ; k94 = 46
.line	434	loadk        r22   k95 ; k95 = 82
.line	434	loadk        r23   k11 ; k11 = 242
.line	434	loadk        r24   k96 ; k96 = 136
.line	434	loadk        r25   k97 ; k97 = 47
.line	434	loadk        r26   k13 ; k13 = 16
.line	434	loadk        r27   k98 ; k98 = 86
.line	434	loadk        r28   k35 ; k35 = 212
.line	434	loadk        r29   k25 ; k25 = 238
.line	434	loadk        r30   k99 ; k99 = 150
.line	434	loadk        r31   k41 ; k41 = 100
.line	434	loadk        r32   k32 ; k32 = 4
.line	434	loadk        r33  k100 ; k100 = 190
.line	434	loadk        r34  k101 ; k101 = 245
.line	434	loadk        r35   k92 ; k92 = 220
.line	434	loadk        r36  k102 ; k102 = 165
.line	434	loadk        r37  k115 ; k115 = 103
.line	434	loadk        r38  k104 ; k104 = 79
.line	434	loadk        r39  k162 ; k162 = 255
.line	434	loadk        r40  k269 ; k269 = 155
.line	434	loadk        r41    k2 ; k2 = 36
.line	434	loadk        r42  k108 ; k108 = 12
.line	434	loadk        r43   k31 ; k31 = 10
.line	434	loadk        r44  k200 ; k200 = 214
.line	434	loadk        r45   k33 ; k33 = 192
.line	434	loadk        r46  k270 ; k270 = 144
.line	434	loadk        r47  k271 ; k271 = 113
.line	434	loadk        r48  k129 ; k129 = 18
.line	434	loadk        r49  k112 ; k112 = 160
.line	434	call          r9    41     2
.line	434	call          r8     2     2
.line	434	gettabup      r9    u0    k0 ; k0 = "require"
.line	434	gettabup     r10    u0   k88 ; k88 = "table"
.line	434	gettable     r10   r10   k89 ; k89 = "concat"
.line	434	newtable     r11     1     0
.line	434	getupval     r12    u1
.line	434	loadk        r13    k1 ; k1 = 224
.line	434	loadk        r14    k2 ; k2 = 36
.line	434	loadk        r15    k3 ; k3 = 186
.line	434	loadk        r16    k4 ; k4 = 218
.line	434	loadk        r17    k5 ; k5 = 122
.line	434	loadk        r18    k6 ; k6 = 68
.line	434	loadk        r19    k7 ; k7 = 40
.line	434	loadk        r20   k90 ; k90 = 146
.line	434	loadk        r21   k91 ; k91 = 235
.line	434	loadk        r22   k92 ; k92 = 220
.line	434	loadk        r23   k93 ; k93 = 250
.line	434	loadk        r24   k94 ; k94 = 46
.line	434	loadk        r25   k95 ; k95 = 82
.line	434	loadk        r26   k11 ; k11 = 242
.line	434	loadk        r27   k96 ; k96 = 136
.line	434	loadk        r28   k97 ; k97 = 47
.line	434	loadk        r29   k13 ; k13 = 16
.line	434	loadk        r30   k98 ; k98 = 86
.line	434	loadk        r31   k35 ; k35 = 212
.line	434	loadk        r32   k25 ; k25 = 238
.line	434	loadk        r33   k99 ; k99 = 150
.line	434	loadk        r34   k41 ; k41 = 100
.line	434	loadk        r35   k32 ; k32 = 4
.line	434	loadk        r36  k100 ; k100 = 190
.line	434	loadk        r37  k101 ; k101 = 245
.line	434	loadk        r38   k92 ; k92 = 220
.line	434	loadk        r39  k102 ; k102 = 165
.line	434	loadk        r40  k164 ; k164 = 124
.line	434	loadk        r41  k272 ; k272 = 65
.line	434	loadk        r42  k248 ; k248 = 234
.line	434	loadk        r43   k99 ; k99 = 150
.line	434	loadk        r44  k273 ; k273 = 53
.line	434	loadk        r45   k64 ; k64 = 60
.line	434	loadk        r46  k108 ; k108 = 12
.line	434	loadk        r47    k4 ; k4 = 218
.line	434	loadk        r48  k156 ; k156 = 236
.line	434	loadk        r49   k42 ; k42 = 132
.line	434	loadk        r50  k164 ; k164 = 124
.line	434	loadk        r51   k51 ; k51 = 7
.line	434	loadk        r52  k182 ; k182 = 184
.line	434	call         r12    41     2
.line	434	getupval     r13    u1
.line	434	loadk        r14   k92 ; k92 = 220
.line	434	loadk        r15  k243 ; k243 = 59
.line	434	loadk        r16   k65 ; k65 = 182
.line	434	loadk        r17   k43 ; k43 = 203
.line	434	loadk        r18  k274 ; k274 = 96
.line	434	loadk        r19  k244 ; k244 = 89
.line	434	loadk        r20  k275 ; k275 = 104
.line	434	loadk        r21  k116 ; k116 = 134
.line	434	call         r13     9     0
.line	434	setlist      r11     0     1
.line	434	call         r10     2     2
.line	434	call          r9     2     2
.line	434	loadk        r12  k276 ; k276 = "HasParaEffectCar"
.line	434	self         r10    r8   r12
.line	434	call         r10     2     2
.line	434	test         r10     0
.line	434	jmp            0 l1425
.line	434	loadk        r12  k277 ; k277 = "HasGlide"
.line	434	self         r10    r8   r12
.line	434	call         r10     2     2
.line	434	test         r10     0
.line	434	jmp            0 l1425
.line	434	loadk        r10  k278 ; k278 = "ShowGlideBanner"
.line	434	gettable     r10    r9   r10
.line	434	loadbool     r11     1     0
.line	434	call         r10     2     1
.label	l1425
.line	434	loadk        r12  k279 ; k279 = "ShowAircraftNotice"
.line	434	self         r10    r0   r12
.line	434	move         r12    r7
.line	434	loadbool     r13     1     0
.line	434	call         r10     4     1
.line	434	jmp            0 l1756
.label	l1431
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	loadk         r9  k280 ; k280 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	gettabup      r9    u4    r9
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1518
.line	434	gettable      r8    r7   k84 ; k84 = "ItemSubType"
.line	434	gettabup      r9    u0  k150 ; k150 = "ENUM_ITEM_SUBTYPE"
.line	434	loadk        r10  k281 ; k281 = "Foot_Effect"
.line	434	gettable      r9    r9   r10
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1448
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	loadk         r9  k282 ; k282 = "UpdateFootEffect"
.line	434	gettable      r8    r8    r9
.line	434	gettable      r9    r2   k82 ; k82 = "instid"
.line	434	call          r8     2     1
.line	434	jmp            0 l1454
.label	l1448
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	loadk         r9  k283 ; k283 = "UpdateCommonPutOnDat" (truncated)
.line	434	gettable      r8    r8    r9
.line	434	gettable      r9    r7   k84 ; k84 = "ItemSubType"
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	call          r8     3     1
.label	l1454
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12    k1 ; k1 = 224
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14    k3 ; k3 = 186
.line	434	loadk        r15    k4 ; k4 = 218
.line	434	loadk        r16    k5 ; k5 = 122
.line	434	loadk        r17    k6 ; k6 = 68
.line	434	loadk        r18    k7 ; k7 = 40
.line	434	loadk        r19    k8 ; k8 = 141
.line	434	loadk        r20    k9 ; k9 = 232
.line	434	loadk        r21   k10 ; k10 = 206
.line	434	loadk        r22   k11 ; k11 = 242
.line	434	loadk        r23   k12 ; k12 = 99
.line	434	loadk        r24   k13 ; k13 = 16
.line	434	loadk        r25   k45 ; k45 = 252
.line	434	loadk        r26  k124 ; k124 = 153
.line	434	loadk        r27  k125 ; k125 = 39
.line	434	loadk        r28   k51 ; k51 = 7
.line	434	loadk        r29  k126 ; k126 = 25
.line	434	loadk        r30   k24 ; k24 = 209
.line	434	loadk        r31   k37 ; k37 = 161
.line	434	loadk        r32   k96 ; k96 = 136
.line	434	loadk        r33  k128 ; k128 = 111
.line	434	loadk        r34   k16 ; k16 = 17
.line	434	loadk        r35  k182 ; k182 = 184
.line	434	loadk        r36  k183 ; k183 = 244
.line	434	loadk        r37  k141 ; k141 = 230
.line	434	loadk        r38  k162 ; k162 = 255
.line	434	loadk        r39  k139 ; k139 = 117
.line	434	loadk        r40  k104 ; k104 = 79
.line	434	loadk        r41    k1 ; k1 = 224
.line	434	loadk        r42  k112 ; k112 = 160
.line	434	loadk        r43  k137 ; k137 = 55
.line	434	loadk        r44  k184 ; k184 = 21
.line	434	loadk        r45  k167 ; k167 = 9
.line	434	loadk        r46   k68 ; k68 = 199
.line	434	loadk        r47  k105 ; k105 = 254
.line	434	loadk        r48  k116 ; k116 = 134
.line	434	loadk        r49  k104 ; k104 = 79
.line	434	loadk        r50  k185 ; k185 = 11
.line	434	loadk        r51  k112 ; k112 = 160
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k186 ; k186 = 237
.line	434	loadk        r14   k36 ; k36 = 41
.line	434	loadk        r15  k130 ; k130 = 180
.line	434	loadk        r16    k4 ; k4 = 218
.line	434	loadk        r17   k39 ; k39 = 102
.line	434	call         r12     6     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	loadk         r9  k284 ; k284 = "PutonEquipment"
.line	434	gettable      r9    r8    r9
.line	434	gettabup     r10    u0  k146 ; k146 = "DataMgr"
.line	434	gettable     r10   r10  k188 ; k188 = "roleData"
.line	434	gettable     r10   r10  k189 ; k189 = "uid"
.line	434	gettable     r11    r2   k66 ; k66 = "res_id"
.line	434	call          r9     3     1
.line	434	jmp            0 l1756
.label	l1518
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k121 ; k121 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1756
.line	434	loadk         r8  k285 ; k285 = "ProcPutOnWingman"
.line	434	gettable      r8    r6    r8
.line	434	gettable      r9    r2   k66 ; k66 = "res_id"
.line	434	call          r8     2     1
.line	434	jmp            0 l1756
.label	l1527
.line	434	gettable      r8    r7  k174 ; k174 = "WardrobeMainTab"
.line	434	loadk         r9  k286 ; k286 = "ENUM_WardrobePageTyp" (truncated)
.line	434	gettabup      r9    u5    r9
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1571
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4   k87 ; k87 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             1    r8    r9
.line	434	jmp            0 l1756
.line	434	gettable      r8    r7   k86 ; k86 = "WardrobeTab"
.line	434	gettabup      r9    u4  k119 ; k119 = "ENUM_WardrobeSubTabS" (truncated)
.line	434	eq             1    r8    r9
.line	434	jmp            0 l1756
.line	434	gettabup      r8    u0  k146 ; k146 = "DataMgr"
.line	434	loadk         r9  k287 ; k287 = "UpdateVehicleSkin"
.line	434	gettable      r8    r8    r9
.line	434	gettable      r9    r7   k84 ; k84 = "ItemSubType"
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	call          r8     3     1
.line	434	testset       r8    r5     0
.line	434	jmp            0 l1550
.line	434	loadk         r8  k288 ; k288 = "bFromVehicleType"
.line	434	gettable      r8    r5    r8
.label	l1550
.line	434	testset       r9    r5     0
.line	434	jmp            0 l1554
.line	434	loadk         r9  k289 ; k289 = "bUpdateLobbyVehicle"
.line	434	gettable      r9    r5    r9
.label	l1554
.line	434	test          r8     1
.line	434	jmp            0 l1565
.line	434	loadk        r12  k290 ; k290 = "EquipSlotVehicle"
.line	434	self         r10    r0   r12
.line	434	gettable     r12    r2   k66 ; k66 = "res_id"
.line	434	loadk        r13  k291 ; k291 = "tonumber"
.line	434	gettabup     r13    u0   r13
.line	434	gettable     r14    r2   k82 ; k82 = "instid"
.line	434	call         r13     2     2
.line	434	loadk        r14   k17 ; k17 = 1
.line	434	call         r10     5     1
.label	l1565
.line	434	loadk        r10  k292 ; k292 = "ProcPutOnVehicle"
.line	434	gettable     r10    r6   r10
.line	434	move         r11    r2
.line	434	move         r12    r9
.line	434	call         r10     3     1
.line	434	jmp            0 l1756
.label	l1571
.line	434	gettable      r8    r7  k174 ; k174 = "WardrobeMainTab"
.line	434	loadk         r9  k293 ; k293 = "ENUM_WardrobePageTyp" (truncated)
.line	434	gettabup      r9    u5    r9
.line	434	eq             0    r8    r9
.line	434	jmp            0 l1714
.line	434	gettabup      r8    u0    k0 ; k0 = "require"
.line	434	getupval      r9    u1
.line	434	loadk        r10    k1 ; k1 = 224
.line	434	loadk        r11    k2 ; k2 = 36
.line	434	loadk        r12    k3 ; k3 = 186
.line	434	loadk        r13    k4 ; k4 = 218
.line	434	loadk        r14    k5 ; k5 = 122
.line	434	loadk        r15    k6 ; k6 = 68
.line	434	loadk        r16    k7 ; k7 = 40
.line	434	loadk        r17    k8 ; k8 = 141
.line	434	loadk        r18    k9 ; k9 = 232
.line	434	loadk        r19   k10 ; k10 = 206
.line	434	loadk        r20   k11 ; k11 = 242
.line	434	loadk        r21   k12 ; k12 = 99
.line	434	loadk        r22   k13 ; k13 = 16
.line	434	loadk        r23   k53 ; k53 = 205
.line	434	loadk        r24   k29 ; k29 = 138
.line	434	loadk        r25  k125 ; k125 = 39
.line	434	loadk        r26  k294 ; k294 = 24
.line	434	loadk        r27  k107 ; k107 = 63
.line	434	loadk        r28  k295 ; k295 = 194
.line	434	loadk        r29  k133 ; k133 = 226
.line	434	loadk        r30  k296 ; k296 = 129
.line	434	loadk        r31   k94 ; k94 = 46
.line	434	loadk        r32  k231 ; k231 = 38
.line	434	loadk        r33  k130 ; k130 = 180
.line	434	loadk        r34   k78 ; k78 = 246
.line	434	loadk        r35   k28 ; k28 = 210
.line	434	loadk        r36   k77 ; k77 = 204
.line	434	loadk        r37  k271 ; k271 = 113
.line	434	loadk        r38  k234 ; k234 = 67
.line	434	loadk        r39    k9 ; k9 = 232
.line	434	loadk        r40   k57 ; k57 = 188
.line	434	loadk        r41  k297 ; k297 = 57
.line	434	loadk        r42  k298 ; k298 = 13
.line	434	loadk        r43  k299 ; k299 = 14
.line	434	loadk        r44    k4 ; k4 = 218
.line	434	loadk        r45  k300 ; k300 = 248
.line	434	call          r9    37     2
.line	434	call          r8     2     2
.line	434	loadk         r9  k301 ; k301 = "ModuleManager"
.line	434	gettabup      r9    u0    r9
.line	434	loadk        r10  k302 ; k302 = "GetModule"
.line	434	gettable      r9    r9   r10
.line	434	loadk        r10  k301 ; k301 = "ModuleManager"
.line	434	gettabup     r10    u0   r10
.line	434	loadk        r11  k303 ; k303 = "LobbyModuleConfig"
.line	434	gettable     r10   r10   r11
.line	434	loadk        r11  k304 ; k304 = "LogicAddScordCard"
.line	434	gettable     r10   r10   r11
.line	434	call          r9     2     2
.line	434	loadk        r10  k305 ; k305 = "ENUM_WardrobePropRes" (truncated)
.line	434	gettabup     r10    u9   r10
.line	434	loadk        r11  k306 ; k306 = "RATING_SHIELD_ONCE"
.line	434	gettable     r10   r10   r11
.line	434	gettable     r11    r2   k66 ; k66 = "res_id"
.line	434	eq             1   r10   r11
.line	434	jmp            0 l1661
.line	434	loadk        r10  k305 ; k305 = "ENUM_WardrobePropRes" (truncated)
.line	434	gettabup     r10    u9   r10
.line	434	loadk        r11  k307 ; k307 = "RATING_SHIELD_ONCE_S" (truncated)
.line	434	gettable     r10   r10   r11
.line	434	gettable     r11    r2   k66 ; k66 = "res_id"
.line	434	eq             1   r10   r11
.line	434	jmp            0 l1661
.line	434	loadk        r12  k308 ; k308 = "IsPutOnSeasonAddScor" (truncated)
.line	434	self         r10    r9   r12
.line	434	gettable     r12    r2   k66 ; k66 = "res_id"
.line	434	call         r10     3     2
.line	434	test         r10     1
.line	434	jmp            0 l1661
.line	434	loadk        r10  k305 ; k305 = "ENUM_WardrobePropRes" (truncated)
.line	434	gettabup     r10    u9   r10
.line	434	loadk        r11  k309 ; k309 = "VS_TEAM_RATING_PROTE" (truncated)
.line	434	gettable     r10   r10   r11
.line	434	gettable     r11    r2   k66 ; k66 = "res_id"
.line	434	eq             1   r10   r11
.line	434	jmp            0 l1661
.line	434	loadk        r10  k310 ; k310 = "ProtectCard"
.line	434	gettable     r10    r8   r10
.line	434	loadk        r11  k311 ; k311 = "PointsProtectionCard"
.line	434	gettable     r10   r10   r11
.line	434	gettable     r11    r2   k66 ; k66 = "res_id"
.line	434	eq             0   r10   r11
.line	434	jmp            0 l1681
.label	l1661
.line	434	loadk        r10  k312 ; k312 = "LocUtil"
.line	434	gettabup     r10    u0   r10
.line	434	loadk        r11  k313 ; k313 = "LocalizeResFormat"
.line	434	gettable     r10   r10   r11
.line	434	getupval     r11    u1
.line	434	loadk        r12    k3 ; k3 = 186
.line	434	loadk        r13  k271 ; k271 = 113
.line	434	loadk        r14  k133 ; k133 = 226
.line	434	loadk        r15  k154 ; k154 = 143
.line	434	loadk        r16  k203 ; k203 = 37
.line	434	loadk        r17   k17 ; k17 = 1
.line	434	loadk        r18  k233 ; k233 = 52
.line	434	call         r11     8     2
.line	434	loadk        r12  k314 ; k314 = "ItemName"
.line	434	gettable     r12    r7   r12
.line	434	call         r10     3     2
.line	434	loadk        r11  k315 ; k315 = "ShowNotice"
.line	434	gettabup     r11    u0   r11
.line	434	move         r12   r10
.line	434	call         r11     2     1
.label	l1681
.line	434	gettable     r10    r7   k84 ; k84 = "ItemSubType"
.line	434	gettabup     r11    u0  k150 ; k150 = "ENUM_ITEM_SUBTYPE"
.line	434	loadk        r12  k316 ; k316 = "ClickEffect"
.line	434	gettable     r11   r11   r12
.line	434	eq             0   r10   r11
.line	434	jmp            0 l1756
.line	434	loadk        r10  k301 ; k301 = "ModuleManager"
.line	434	gettabup     r10    u0   r10
.line	434	loadk        r11  k302 ; k302 = "GetModule"
.line	434	gettable     r10   r10   r11
.line	434	loadk        r11  k301 ; k301 = "ModuleManager"
.line	434	gettabup     r11    u0   r11
.line	434	loadk        r12  k317 ; k317 = "CommonModuleConfig"
.line	434	gettable     r11   r11   r12
.line	434	loadk        r12  k318 ; k318 = "ClickEffectModule"
.line	434	gettable     r11   r11   r12
.line	434	call         r10     2     2
.line	434	loadk        r13  k319 ; k319 = "SetCurrentUse"
.line	434	self         r11   r10   r13
.line	434	loadk        r13  k320 ; k320 = "ItemID"
.line	434	gettable     r13    r7   r13
.line	434	call         r11     3     1
.line	434	gettabup     r11    u0  k146 ; k146 = "DataMgr"
.line	434	loadk        r12  k283 ; k283 = "UpdateCommonPutOnDat" (truncated)
.line	434	gettable     r11   r11   r12
.line	434	gettable     r12    r7   k84 ; k84 = "ItemSubType"
.line	434	gettable     r13    r2   k82 ; k82 = "instid"
.line	434	call         r11     3     1
.line	434	loadk        r11  k315 ; k315 = "ShowNotice"
.line	434	gettabup     r11    u0   r11
.line	434	loadk        r12  k321 ; k321 = 20051011
.line	434	call         r11     2     1
.line	434	jmp            0 l1756
.label	l1714
.line	434	gettabup      r8    u0   k61 ; k61 = "CDataTable"
.line	434	gettable      r8    r8   k62 ; k62 = "GetTableData"
.line	434	getupval      r9    u1
.line	434	loadk        r10  k160 ; k160 = 215
.line	434	loadk        r11  k114 ; k114 = 32
.line	434	loadk        r12   k65 ; k65 = 182
.line	434	loadk        r13   k28 ; k28 = 210
.line	434	loadk        r14  k271 ; k271 = 113
.line	434	loadk        r15   k12 ; k12 = 99
.line	434	loadk        r16  k322 ; k322 = 109
.line	434	loadk        r17   k96 ; k96 = 136
.line	434	loadk        r18  k323 ; k323 = 233
.line	434	loadk        r19    k1 ; k1 = 224
.line	434	loadk        r20  k324 ; k324 = 239
.line	434	loadk        r21  k235 ; k235 = 101
.line	434	loadk        r22  k325 ; k325 = 83
.line	434	loadk        r23  k224 ; k224 = 201
.line	434	loadk        r24   k99 ; k99 = 150
.line	434	loadk        r25  k326 ; k326 = 54
.line	434	loadk        r26  k159 ; k159 = 22
.line	434	loadk        r27  k243 ; k243 = 59
.line	434	loadk        r28   k77 ; k77 = 204
.line	434	loadk        r29  k135 ; k135 = 225
.line	434	loadk        r30  k327 ; k327 = 130
.line	434	loadk        r31   k46 ; k46 = 105
.line	434	loadk        r32   k16 ; k16 = 17
.line	434	call          r9    24     2
.line	434	gettable     r10    r7   k81 ; k81 = "itemSubType"
.line	434	call          r8     3     2
.line	434	test          r8     0
.line	434	jmp            0 l1756
.line	434	loadk         r8  k315 ; k315 = "ShowNotice"
.line	434	gettabup      r8    u0    r8
.line	434	loadk         r9  k328 ; k328 = 792644
.line	434	call          r8     2     1
.line	434	gettabup      r8    u0  k190 ; k190 = "AvatarData"
.line	434	loadk         r9  k329 ; k329 = "UpdateCommonSubtypeW" (truncated)
.line	434	gettable      r8    r8    r9
.line	434	gettable      r9    r7   k81 ; k81 = "itemSubType"
.line	434	gettable     r10    r2   k82 ; k82 = "instid"
.line	434	loadbool     r11     1     0
.line	434	call          r8     4     1
.label	l1756
.line	434	eq             1    r3   k60 ; k60 = nil
.line	434	jmp            0 l1763
.line	434	loadk        r10  k330 ; k330 = "OnPutOffAircraft"
.line	434	self          r8    r0   r10
.line	434	move         r10    r3
.line	434	move         r11    r7
.line	434	call          r8     4     1
.label	l1763
.line	434	getupval      r8    u3
.line	434	loadk        r10  k331 ; k331 = "RemoveWearInfo"
.line	434	self          r8    r8   r10
.line	434	move         r10    r3
.line	434	call          r8     3     1
.line	434	loadk         r8  k332 ; k332 = "EventSystem"
.line	434	gettabup      r8    u0    r8
.line	434	loadk        r10  k333 ; k333 = "postEvent"
.line	434	self          r8    r8   r10
.line	434	loadk        r10  k334 ; k334 = "EVENTTYPE_WARDROBE"
.line	434	gettabup     r10    u0   r10
.line	434	loadk        r11  k335 ; k335 = "EVENTID_WARDROBE_UPD" (truncated)
.line	434	gettabup     r11    u0   r11
.line	434	move         r12    r2
.line	434	move         r13    r3
.line	434	call          r8     6     1
.line	434	loadk         r8  k301 ; k301 = "ModuleManager"
.line	434	gettabup      r8    u0    r8
.line	434	loadk         r9  k302 ; k302 = "GetModule"
.line	434	gettable      r8    r8    r9
.line	434	loadk         r9  k301 ; k301 = "ModuleManager"
.line	434	gettabup      r9    u0    r9
.line	434	loadk        r10  k336 ; k336 = "DataModuleConfig"
.line	434	gettable      r9    r9   r10
.line	434	loadk        r10  k337 ; k337 = "BasicDataAvatarWearI" (truncated)
.line	434	gettable      r9    r9   r10
.line	434	call          r8     2     2
.line	434	loadk        r11  k338 ; k338 = "GetOrReqData"
.line	434	self          r9    r8   r11
.line	434	gettabup     r11    u0  k146 ; k146 = "DataMgr"
.line	434	gettable     r11   r11  k188 ; k188 = "roleData"
.line	434	gettable     r11   r11  k189 ; k189 = "uid"
.line	434	closure      r12    f0
.line	434	newtable     r13     0     1
.line	434	loadk        r14  k339 ; k339 = "bForceReq"
.line	434	loadk        r15  k340 ; k340 = true
.line	434	settable     r13   r14   r15
.line	434	loadk        r14  k341 ; k341 = "Enum_AvatarShowSourc" (truncated)
.line	434	gettabup     r14    u0   r14
.line	434	loadk        r15  k342 ; k342 = "WardrobeLogic"
.line	434	gettable     r14   r14   r15
.line	434	call          r9     6     1
.line	434	jmp            0 l1821
.label	l1806
.line	434	loadk         r7  k315 ; k315 = "ShowNotice"
.line	434	gettabup      r7    u0    r7
.line	434	move          r8    r1
.line	434	call          r7     2     1
.line	434	loadk         r7  k343 ; k343 = "EventSystem"
.line	434	gettabup      r7    u0    r7
.line	434	loadk         r9  k344 ; k344 = "postEvent"
.line	434	self          r7    r7    r9
.line	434	loadk         r9  k334 ; k334 = "EVENTTYPE_WARDROBE"
.line	434	gettabup      r9    u0    r9
.line	434	loadk        r10  k345 ; k345 = "EVENTID_WARDROBE_UPD" (truncated)
.line	434	gettabup     r10    u0   r10
.line	434	move         r11    r2
.line	434	move         r12    r3
.line	434	call          r7     6     1
.label	l1821
.line	434	gettabup      r7    u0    k0 ; k0 = "require"
.line	434	getupval      r8    u1
.line	434	loadk         r9    k1 ; k1 = 224
.line	434	loadk        r10    k2 ; k2 = 36
.line	434	loadk        r11    k3 ; k3 = 186
.line	434	loadk        r12    k4 ; k4 = 218
.line	434	loadk        r13    k5 ; k5 = 122
.line	434	loadk        r14    k6 ; k6 = 68
.line	434	loadk        r15    k7 ; k7 = 40
.line	434	loadk        r16  k327 ; k327 = 130
.line	434	loadk        r17    k9 ; k9 = 232
.line	434	loadk        r18  k237 ; k237 = 196
.line	434	loadk        r19   k78 ; k78 = 246
.line	434	loadk        r20  k128 ; k128 = 111
.line	434	loadk        r21  k346 ; k346 = 80
.line	434	loadk        r22  k230 ; k230 = 179
.line	434	loadk        r23  k269 ; k269 = 155
.line	434	loadk        r24   k97 ; k97 = 47
.line	434	loadk        r25  k238 ; k238 = 30
.line	434	loadk        r26  k249 ; k249 = 29
.line	434	loadk        r27   k45 ; k45 = 252
.line	434	loadk        r28   k93 ; k93 = 250
.line	434	loadk        r29  k270 ; k270 = 144
.line	434	loadk        r30   k46 ; k46 = 105
.line	434	loadk        r31   k21 ; k21 = 26
.line	434	call          r8    24     2
.line	434	call          r7     2     2
.line	434	loadk         r8  k347 ; k347 = "recordTime"
.line	434	loadk         r9  k348 ; k348 = "GetServerTimeInSec"
.line	434	gettable      r9    r7    r9
.line	434	call          r9     1     2
.line	434	settabup      u2    r8    r9
.line	434	loadk         r8  k349 ; k349 = "bTriggerPutOn"
.line	434	loadk         r9  k340 ; k340 = true
.line	434	settabup      u2    r8    r9
.line	434	loadk         r8  k350 ; k350 = "RequireBlackList"
.line	434	gettabup      r8    u0    r8
.line	434	gettabup      r9    u0   k88 ; k88 = "table"
.line	434	gettable      r9    r9   k89 ; k89 = "concat"
.line	434	newtable     r10     1     0
.line	434	getupval     r11    u1
.line	434	loadk        r12  k135 ; k135 = 225
.line	434	loadk        r13    k2 ; k2 = 36
.line	434	loadk        r14  k246 ; k246 = 178
.line	434	loadk        r15   k92 ; k92 = 220
.line	434	loadk        r16  k351 ; k351 = 127
.line	434	loadk        r17   k73 ; k73 = 92
.line	434	loadk        r18  k128 ; k128 = 111
.line	434	loadk        r19   k90 ; k90 = 146
.line	434	loadk        r20   k76 ; k76 = 243
.line	434	loadk        r21  k161 ; k161 = 135
.line	434	loadk        r22    k9 ; k9 = 232
.line	434	loadk        r23   k20 ; k20 = 108
.line	434	loadk        r24   k27 ; k27 = 75
.line	434	loadk        r25   k45 ; k45 = 252
.line	434	loadk        r26  k158 ; k158 = 193
.line	434	loadk        r27  k352 ; k352 = 42
.line	434	loadk        r28  k353 ; k353 = 28
.line	434	loadk        r29  k354 ; k354 = 31
.line	434	loadk        r30   k63 ; k63 = 202
.line	434	loadk        r31  k156 ; k156 = 236
.line	434	loadk        r32   k63 ; k63 = 202
.line	434	loadk        r33   k20 ; k20 = 108
.line	434	loadk        r34  k126 ; k126 = 25
.line	434	loadk        r35  k230 ; k230 = 179
.line	434	loadk        r36  k101 ; k101 = 245
.line	434	loadk        r37   k33 ; k33 = 192
.line	434	loadk        r38   k35 ; k35 = 212
.line	434	loadk        r39  k355 ; k355 = 119
.line	434	loadk        r40  k234 ; k234 = 67
.line	434	loadk        r41  k222 ; k222 = 163
.line	434	loadk        r42  k110 ; k110 = 147
.line	434	loadk        r43  k297 ; k297 = 57
.line	434	loadk        r44   k32 ; k32 = 4
.line	434	loadk        r45   k17 ; k17 = 1
.line	434	loadk        r46   k54 ; k54 = 208
.line	434	loadk        r47   k33 ; k33 = 192
.line	434	loadk        r48  k110 ; k110 = 147
.line	434	loadk        r49   k26 ; k26 = 125
.line	434	loadk        r50  k297 ; k297 = 57
.line	434	loadk        r51   k65 ; k65 = 182
.line	434	call         r11    41     2
.line	434	getupval     r12    u1
.line	434	loadk        r13  k141 ; k141 = 230
.line	434	loadk        r14   k36 ; k36 = 41
.line	434	loadk        r15   k37 ; k37 = 161
.line	434	call         r12     4     0
.line	434	setlist      r10     0     1
.line	434	call          r9     2     2
.line	434	call          r8     2     2
.line	434	test          r8     0
.line	434	jmp            0 l1918
.line	434	loadk         r9  k356 ; k356 = "OnEquipItem"
.line	434	gettable      r9    r8    r9
.line	434	move         r10    r1
.line	434	move         r11    r2
.line	434	call          r9     3     1
.label	l1918
.line	434	return        r0     1
.line	434	move          r0    r0
.line	434	return        r0     1

.function	main/f20/f0

.source	null
.linedefined	599
.lastlinedefined	601
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"EventSystem"
.constant	k1	"postEvent"
.constant	k2	"EVENTTYPE_RANK"
.constant	k3	"EVENTID_WARZONE_UPDATE_AVATAR"

.line	599	gettabup      r2    u0    k0 ; k0 = "EventSystem"
.line	599	self          r2    r2    k1 ; k1 = "postEvent"
.line	599	gettabup      r4    u0    k2 ; k2 = "EVENTTYPE_RANK"
.line	599	gettabup      r5    u0    k3 ; k3 = "EVENTID_WARZONE_UPDA" (truncated)
.line	599	move          r6    r0
.line	599	call          r2     5     1
.line	599	return        r0     1
.line	599	move          r0    r0
.line	599	move          r0    r0
.line	599	move          r0    r0
.line	599	move          r0    r0
.line	599	return        r0     1

.function	main/f21

.source	null
.linedefined	615
.lastlinedefined	619
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false

.constant	k0	"wardrobe_put_down_req"
.constant	k1	"ins_id"
.constant	k2	"insID"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"golden_suit_module"
.constant	k7	"ModifyVehicleWhenPutOff"

.line	615	getupval      r2    u0
.line	615	self          r2    r2    k0 ; k0 = "wardrobe_put_down_re" (truncated)
.line	615	gettable      r4    r1    k1 ; k1 = "ins_id"
.line	615	test          r4     1
.line	615	jmp            0    l7
.line	615	gettable      r4    r1    k2 ; k2 = "insID"
.label	l7
.line	615	call          r2     3     1
.line	615	gettabup      r2    u1    k3 ; k3 = "ModuleManager"
.line	615	gettable      r2    r2    k4 ; k4 = "GetModule"
.line	615	gettabup      r3    u1    k3 ; k3 = "ModuleManager"
.line	615	gettable      r3    r3    k5 ; k5 = "LobbyModuleConfig"
.line	615	gettable      r3    r3    k6 ; k6 = "golden_suit_module"
.line	615	call          r2     2     2
.line	615	self          r3    r2    k7 ; k7 = "ModifyVehicleWhenPut" (truncated)
.line	615	move          r5    r1
.line	615	call          r3     3     1
.line	615	return        r0     1
.line	615	move          r0    r0
.line	615	move          r0    r0
.line	615	move          r0    r0
.line	615	move          r0    r0
.line	615	return        r0     1

.function	main/f22

.source	null
.linedefined	621
.lastlinedefined	625
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	228
.constant	k5	39
.constant	k6	183
.constant	k7	159
.constant	k8	96
.constant	k9	85
.constant	k10	117
.constant	k11	149
.constant	k12	167
.constant	k13	222
.constant	k14	250
.constant	k15	114
.constant	k16	90
.constant	k17	239
.constant	k18	128
.constant	k19	36
.constant	k20	22
.constant	k21	88
.constant	k22	212
.constant	k23	238
.constant	k24	150
.constant	k25	100
.constant	k26	4
.constant	k27	190
.constant	k28	245
.constant	k29	220
.constant	k30	91
.constant	k31	249
.constant	k32	160
.constant	k33	50
.constant	k34	12
.constant	k35	31
.constant	k36	221
.constant	k37	192
.constant	k38	134
.constant	k39	23
.constant	k40	225
.constant	k41	173
.constant	k42	102
.constant	k43	253
.constant	k44	145
.constant	k45	58
.constant	k46	16
.constant	k47	"require"
.constant	k48	224
.constant	k49	186
.constant	k50	218
.constant	k51	122
.constant	k52	68
.constant	k53	40
.constant	k54	143
.constant	k55	226
.constant	k56	236
.constant	k57	111
.constant	k58	76
.constant	k59	246
.constant	k60	193
.constant	k61	1
.constant	k62	215
.constant	k63	135
.constant	k64	26
.constant	k65	255
.constant	k66	216
.constant	k67	116
.constant	k68	124
.constant	k69	157
.constant	k70	51
.constant	k71	43
.constant	k72	9
.constant	k73	251
.constant	k74	152
.constant	k75	20
.constant	k76	"send_depot_put_down_req"
.constant	k77	"tonumber"

.line	621	gettabup      r2    u0    k0 ; k0 = "log"
.line	621	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	621	test          r3     0
.line	621	jmp            0   l62
.line	621	gettabup      r3    u0    k2 ; k2 = "table"
.line	621	gettable      r3    r3    k3 ; k3 = "concat"
.line	621	newtable      r4     1     0
.line	621	getupval      r5    u1
.line	621	loadk         r6    k4 ; k4 = 228
.line	621	loadk         r7    k5 ; k5 = 39
.line	621	loadk         r8    k6 ; k6 = 183
.line	621	loadk         r9    k7 ; k7 = 159
.line	621	loadk        r10    k8 ; k8 = 96
.line	621	loadk        r11    k9 ; k9 = 85
.line	621	loadk        r12   k10 ; k10 = 117
.line	621	loadk        r13   k11 ; k11 = 149
.line	621	loadk        r14   k12 ; k12 = 167
.line	621	loadk        r15   k13 ; k13 = 222
.line	621	loadk        r16   k14 ; k14 = 250
.line	621	loadk        r17   k15 ; k15 = 114
.line	621	loadk        r18   k16 ; k16 = 90
.line	621	loadk        r19   k17 ; k17 = 239
.line	621	loadk        r20   k18 ; k18 = 128
.line	621	loadk        r21   k19 ; k19 = 36
.line	621	loadk        r22   k20 ; k20 = 22
.line	621	loadk        r23   k21 ; k21 = 88
.line	621	loadk        r24   k22 ; k22 = 212
.line	621	loadk        r25   k23 ; k23 = 238
.line	621	loadk        r26   k24 ; k24 = 150
.line	621	loadk        r27   k25 ; k25 = 100
.line	621	loadk        r28   k26 ; k26 = 4
.line	621	loadk        r29   k27 ; k27 = 190
.line	621	loadk        r30   k28 ; k28 = 245
.line	621	loadk        r31   k29 ; k29 = 220
.line	621	loadk        r32   k22 ; k22 = 212
.line	621	loadk        r33    k8 ; k8 = 96
.line	621	loadk        r34   k30 ; k30 = 91
.line	621	loadk        r35   k31 ; k31 = 249
.line	621	loadk        r36   k32 ; k32 = 160
.line	621	loadk        r37   k33 ; k33 = 50
.line	621	loadk        r38   k34 ; k34 = 12
.line	621	loadk        r39   k35 ; k35 = 31
.line	621	loadk        r40   k36 ; k36 = 221
.line	621	loadk        r41   k37 ; k37 = 192
.line	621	loadk        r42   k38 ; k38 = 134
.line	621	loadk        r43   k10 ; k10 = 117
.line	621	loadk        r44   k39 ; k39 = 23
.line	621	loadk        r45   k40 ; k40 = 225
.line	621	call          r5    41     2
.line	621	getupval      r6    u1
.line	621	loadk         r7   k41 ; k41 = 173
.line	621	loadk         r8   k42 ; k42 = 102
.line	621	loadk         r9   k43 ; k43 = 253
.line	621	loadk        r10   k44 ; k44 = 145
.line	621	loadk        r11   k45 ; k45 = 58
.line	621	loadk        r12   k46 ; k46 = 16
.line	621	call          r6     7     0
.line	621	setlist       r4     0     1
.line	621	call          r3     2     2
.line	621	move          r4    r1
.line	621	concat        r3    r3    r4
.label	l62
.line	621	call          r2     2     1
.line	621	gettabup      r2    u0   k47 ; k47 = "require"
.line	621	getupval      r3    u1
.line	621	loadk         r4   k48 ; k48 = 224
.line	621	loadk         r5   k19 ; k19 = 36
.line	621	loadk         r6   k49 ; k49 = 186
.line	621	loadk         r7   k50 ; k50 = 218
.line	621	loadk         r8   k51 ; k51 = 122
.line	621	loadk         r9   k52 ; k52 = 68
.line	621	loadk        r10   k53 ; k53 = 40
.line	621	loadk        r11   k54 ; k54 = 143
.line	621	loadk        r12   k55 ; k55 = 226
.line	621	loadk        r13   k36 ; k36 = 221
.line	621	loadk        r14   k56 ; k56 = 236
.line	621	loadk        r15   k57 ; k57 = 111
.line	621	loadk        r16   k58 ; k58 = 76
.line	621	loadk        r17   k59 ; k59 = 246
.line	621	loadk        r18   k60 ; k60 = 193
.line	621	loadk        r19   k20 ; k20 = 22
.line	621	loadk        r20   k61 ; k61 = 1
.line	621	loadk        r21   k39 ; k39 = 23
.line	621	loadk        r22   k62 ; k62 = 215
.line	621	loadk        r23   k48 ; k48 = 224
.line	621	loadk        r24   k63 ; k63 = 135
.line	621	loadk        r25   k57 ; k57 = 111
.line	621	loadk        r26   k64 ; k64 = 26
.line	621	loadk        r27   k65 ; k65 = 255
.line	621	loadk        r28   k37 ; k37 = 192
.line	621	loadk        r29   k66 ; k66 = 216
.line	621	loadk        r30   k31 ; k31 = 249
.line	621	loadk        r31   k67 ; k67 = 116
.line	621	loadk        r32   k68 ; k68 = 124
.line	621	loadk        r33   k55 ; k55 = 226
.line	621	loadk        r34   k69 ; k69 = 157
.line	621	loadk        r35   k70 ; k70 = 51
.line	621	loadk        r36   k71 ; k71 = 43
.line	621	loadk        r37   k72 ; k72 = 9
.line	621	loadk        r38   k36 ; k36 = 221
.line	621	loadk        r39   k73 ; k73 = 251
.line	621	loadk        r40   k74 ; k74 = 152
.line	621	loadk        r41   k10 ; k10 = 117
.line	621	loadk        r42   k75 ; k75 = 20
.line	621	call          r3    40     2
.line	621	call          r2     2     2
.line	621	gettable      r3    r2   k76 ; k76 = "send_depot_put_down_" (truncated)
.line	621	gettabup      r4    u0   k77 ; k77 = "tonumber"
.line	621	move          r5    r1
.line	621	call          r4     2     0
.line	621	call          r3     0     1
.line	621	return        r0     1
.line	621	move          r0    r0
.line	621	return        r0     1

.function	main/f23

.source	null
.linedefined	627
.lastlinedefined	740
.numparams	3
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	10	true
.upvalue	"U3"	14	true
.upvalue	"U4"	13	true
.upvalue	"U5"	12	true
.upvalue	"U6"	5	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	241
.constant	k15	128
.constant	k16	17
.constant	k17	1
.constant	k18	231
.constant	k19	133
.constant	k20	108
.constant	k21	26
.constant	k22	142
.constant	k23	227
.constant	k24	209
.constant	k25	238
.constant	k26	125
.constant	k27	75
.constant	k28	210
.constant	k29	138
.constant	k30	34
.constant	k31	10
.constant	k32	4
.constant	k33	192
.constant	k34	"NetErrorCode_NONE"
.constant	k35	"CDataTable"
.constant	k36	"GetTableData"
.constant	k37	202
.constant	k38	60
.constant	k39	182
.constant	k40	"res_id"
.constant	k41	nil
.constant	k42	"RemoveWearInfo"
.constant	k43	"itemSubType"
.constant	k44	"ENUM_ITEM_SUBTYPE"
.constant	k45	"Helmet"
.constant	k46	"Helmet_NoLevel"
.constant	k47	"ProcPutDownHelmet"
.constant	k48	143
.constant	k49	226
.constant	k50	221
.constant	k51	236
.constant	k52	111
.constant	k53	76
.constant	k54	246
.constant	k55	193
.constant	k56	22
.constant	k57	23
.constant	k58	215
.constant	k59	135
.constant	k60	255
.constant	k61	216
.constant	k62	249
.constant	k63	116
.constant	k64	124
.constant	k65	157
.constant	k66	51
.constant	k67	43
.constant	k68	9
.constant	k69	251
.constant	k70	152
.constant	k71	117
.constant	k72	20
.constant	k73	"send_depot_set_head_show_req"
.constant	k74	0
.constant	k75	"Upgrade_Backpack"
.constant	k76	"Backpack"
.constant	k77	"ProcPutDownBagSkin"
.constant	k78	"WardrobeMainTab"
.constant	k79	"ENUM_WardrobePageType_Avatar"
.constant	k80	"instid"
.constant	k81	"IsTabString_Bag_Helmet_Armor"
.constant	k82	"WardrobeTab"
.constant	k83	"DataMgr"
.constant	k84	"equipmentSkinInsIDTable"
.constant	k85	"ItemSubType"
.constant	k86	"UpdateEquipmentSkin"
.constant	k87	"GetEquipmentItemIDBySkinInsID"
.constant	k88	"ENUM_WardrobeSubTabString_helmet"
.constant	k89	"table"
.constant	k90	"concat"
.constant	k91	252
.constant	k92	153
.constant	k93	39
.constant	k94	7
.constant	k95	25
.constant	k96	161
.constant	k97	136
.constant	k98	184
.constant	k99	244
.constant	k100	230
.constant	k101	79
.constant	k102	160
.constant	k103	55
.constant	k104	21
.constant	k105	199
.constant	k106	254
.constant	k107	134
.constant	k108	11
.constant	k109	237
.constant	k110	41
.constant	k111	180
.constant	k112	102
.constant	k113	"ChangeAvatarEquipment"
.constant	k114	"roleData"
.constant	k115	"uid"
.constant	k116	"AvatarData"
.constant	k117	"CreateAvatarCustom"
.constant	k118	"EventSystem"
.constant	k119	"postEvent"
.constant	k120	"EVENTTYPE_WARDROBE"
.constant	k121	"EVENTID_WARDROBE_UPDATE_PUT_DOWN_DATA"
.constant	k122	"GetRoleWear"
.constant	k123	"pairs"
.constant	k124	"UpdateRoleWearData"
.constant	k125	"ENUM_WardrobeSubTabString_head"
.constant	k126	146
.constant	k127	235
.constant	k128	220
.constant	k129	250
.constant	k130	46
.constant	k131	82
.constant	k132	47
.constant	k133	86
.constant	k134	212
.constant	k135	150
.constant	k136	100
.constant	k137	190
.constant	k138	245
.constant	k139	165
.constant	k140	118
.constant	k141	151
.constant	k142	63
.constant	k143	12
.constant	k144	6
.constant	k145	147
.constant	k146	62
.constant	k147	240
.constant	k148	32
.constant	k149	208
.constant	k150	103
.constant	k151	205
.constant	k152	95
.constant	k153	"SetHeadShow"
.constant	k154	"ProcPutDownHat"
.constant	k155	145
.constant	k156	105
.constant	k157	2
.constant	k158	214
.constant	k159	121
.constant	k160	77
.constant	k161	37
.constant	k162	"IsXSuit"
.constant	k163	"GetItemShowID"
.constant	k164	"AvatarChange"
.constant	k165	"RefreshSharedRelicInfo"
.constant	k166	"ENUM_WardrobeSubTabString_effect"
.constant	k167	"OnPutOffAircraft"
.constant	k168	"ClearAircraftOrGliding"
.constant	k169	"ENUM_WardrobeSubTabString_items"
.constant	k170	24
.constant	k171	194
.constant	k172	129
.constant	k173	38
.constant	k174	204
.constant	k175	113
.constant	k176	67
.constant	k177	188
.constant	k178	57
.constant	k179	13
.constant	k180	14
.constant	k181	248
.constant	k182	"ModuleManager"
.constant	k183	"GetModule"
.constant	k184	"LobbyModuleConfig"
.constant	k185	"LogicAddScordCard"
.constant	k186	"ENUM_WardrobePropResId"
.constant	k187	"RATING_SHIELD_ONCE"
.constant	k188	"RATING_SHIELD_ONCE_SEASON"
.constant	k189	"IsPutOnSeasonAddScoreCard"
.constant	k190	"VS_TEAM_RATING_PROTECT_TIMES_CARD"
.constant	k191	"ProtectCard"
.constant	k192	"PointsProtectionCard"
.constant	k193	"LocUtil"
.constant	k194	"LocalizeResFormat"
.constant	k195	123
.constant	k196	"ItemName"
.constant	k197	"ShowNotice"
.constant	k198	"ClickEffect"
.constant	k199	"CommonModuleConfig"
.constant	k200	"ClickEffectModule"
.constant	k201	"SetCurrentUse"
.constant	k202	"UpdateCommonPutOnDataBy"
.constant	k203	20051012
.constant	k204	"ENUM_WardrobeSubTabString_throw_object"
.constant	k205	"PutDownThrowObjectSkin"
.constant	k206	"ENUM_WardrobeSubTabString_bag_pendant"
.constant	k207	"PutDownBagPendants"
.constant	k208	"ENUM_WardrobeSubTabString_FootEffect"
.constant	k209	"Foot_Effect"
.constant	k210	"UpdateFootEffect"
.constant	k211	"PutoffEquipment"
.constant	k212	"itemType"
.constant	k213	61
.constant	k214	"UpdateStatueSkin"
.constant	k215	109
.constant	k216	233
.constant	k217	239
.constant	k218	101
.constant	k219	83
.constant	k220	201
.constant	k221	54
.constant	k222	59
.constant	k223	225
.constant	k224	130
.constant	k225	792645
.constant	k226	"UpdateCommonSubtypeWearData"
.constant	k227	"DataModuleConfig"
.constant	k228	"BasicDataAvatarWearInfo"
.constant	k229	"GetOrReqData"
.constant	k230	"bForceReq"
.constant	k231	true
.constant	k232	"Enum_AvatarShowSource"
.constant	k233	"WardrobeLogic"
.constant	k234	"ShowMessageBoxByID"
.constant	k235	"bTriggerPutOn"
.constant	k236	"RequireBlackList"
.constant	k237	178
.constant	k238	127
.constant	k239	92
.constant	k240	243
.constant	k241	42
.constant	k242	28
.constant	k243	31
.constant	k244	179
.constant	k245	119
.constant	k246	163
.constant	k247	"OnTakeOffItem"

.line	627	gettabup      r3    u0    k0 ; k0 = "require"
.line	627	getupval      r4    u1
.line	627	loadk         r5    k1 ; k1 = 224
.line	627	loadk         r6    k2 ; k2 = 36
.line	627	loadk         r7    k3 ; k3 = 186
.line	627	loadk         r8    k4 ; k4 = 218
.line	627	loadk         r9    k5 ; k5 = 122
.line	627	loadk        r10    k6 ; k6 = 68
.line	627	loadk        r11    k7 ; k7 = 40
.line	627	loadk        r12    k8 ; k8 = 141
.line	627	loadk        r13    k9 ; k9 = 232
.line	627	loadk        r14   k10 ; k10 = 206
.line	627	loadk        r15   k11 ; k11 = 242
.line	627	loadk        r16   k12 ; k12 = 99
.line	627	loadk        r17   k13 ; k13 = 16
.line	627	loadk        r18   k14 ; k14 = 241
.line	627	loadk        r19   k15 ; k15 = 128
.line	627	loadk        r20    k2 ; k2 = 36
.line	627	loadk        r21   k16 ; k16 = 17
.line	627	loadk        r22   k17 ; k17 = 1
.line	627	loadk        r23    k8 ; k8 = 141
.line	627	loadk        r24   k18 ; k18 = 231
.line	627	loadk        r25   k19 ; k19 = 133
.line	627	loadk        r26   k20 ; k20 = 108
.line	627	loadk        r27   k21 ; k21 = 26
.line	627	loadk        r28   k22 ; k22 = 142
.line	627	loadk        r29   k23 ; k23 = 227
.line	627	loadk        r30   k24 ; k24 = 209
.line	627	loadk        r31   k25 ; k25 = 238
.line	627	loadk        r32   k26 ; k26 = 125
.line	627	loadk        r33   k27 ; k27 = 75
.line	627	loadk        r34   k28 ; k28 = 210
.line	627	loadk        r35   k29 ; k29 = 138
.line	627	loadk        r36   k30 ; k30 = 34
.line	627	loadk        r37   k31 ; k31 = 10
.line	627	loadk        r38   k32 ; k32 = 4
.line	627	loadk        r39   k33 ; k33 = 192
.line	627	call          r4    36     2
.line	627	call          r3     2     2
.line	627	gettabup      r4    u0   k34 ; k34 = "NetErrorCode_NONE"
.line	627	eq             0    r1    r4
.line	627	jmp            0 l1006
.line	627	gettabup      r4    u0   k35 ; k35 = "CDataTable"
.line	627	gettable      r4    r4   k36 ; k36 = "GetTableData"
.line	627	getupval      r5    u1
.line	627	loadk         r6   k37 ; k37 = 202
.line	627	loadk         r7   k38 ; k38 = 60
.line	627	loadk         r8   k39 ; k39 = 182
.line	627	loadk         r9   k28 ; k28 = 210
.line	627	call          r5     5     2
.line	627	gettable      r6    r2   k40 ; k40 = "res_id"
.line	627	call          r4     3     2
.line	627	eq             1    r4   k41 ; k41 = nil
.line	627	jmp            0  l989
.line	627	getupval      r5    u2
.line	627	self          r5    r5   k42 ; k42 = "RemoveWearInfo"
.line	627	move          r7    r2
.line	627	call          r5     3     1
.line	627	gettable      r5    r4   k43 ; k43 = "itemSubType"
.line	627	gettabup      r6    u0   k44 ; k44 = "ENUM_ITEM_SUBTYPE"
.line	627	gettable      r6    r6   k45 ; k45 = "Helmet"
.line	627	eq             1    r5    r6
.line	627	jmp            0   l69
.line	627	gettable      r5    r4   k43 ; k43 = "itemSubType"
.line	627	gettabup      r6    u0   k44 ; k44 = "ENUM_ITEM_SUBTYPE"
.line	627	gettable      r6    r6   k46 ; k46 = "Helmet_NoLevel"
.line	627	eq             0    r5    r6
.line	627	jmp            0  l119
.label	l69
.line	627	gettable      r5    r3   k47 ; k47 = "ProcPutDownHelmet"
.line	627	move          r6    r2
.line	627	call          r5     2     1
.line	627	gettabup      r5    u0    k0 ; k0 = "require"
.line	627	getupval      r6    u1
.line	627	loadk         r7    k1 ; k1 = 224
.line	627	loadk         r8    k2 ; k2 = 36
.line	627	loadk         r9    k3 ; k3 = 186
.line	627	loadk        r10    k4 ; k4 = 218
.line	627	loadk        r11    k5 ; k5 = 122
.line	627	loadk        r12    k6 ; k6 = 68
.line	627	loadk        r13    k7 ; k7 = 40
.line	627	loadk        r14   k48 ; k48 = 143
.line	627	loadk        r15   k49 ; k49 = 226
.line	627	loadk        r16   k50 ; k50 = 221
.line	627	loadk        r17   k51 ; k51 = 236
.line	627	loadk        r18   k52 ; k52 = 111
.line	627	loadk        r19   k53 ; k53 = 76
.line	627	loadk        r20   k54 ; k54 = 246
.line	627	loadk        r21   k55 ; k55 = 193
.line	627	loadk        r22   k56 ; k56 = 22
.line	627	loadk        r23   k17 ; k17 = 1
.line	627	loadk        r24   k57 ; k57 = 23
.line	627	loadk        r25   k58 ; k58 = 215
.line	627	loadk        r26    k1 ; k1 = 224
.line	627	loadk        r27   k59 ; k59 = 135
.line	627	loadk        r28   k52 ; k52 = 111
.line	627	loadk        r29   k21 ; k21 = 26
.line	627	loadk        r30   k60 ; k60 = 255
.line	627	loadk        r31   k33 ; k33 = 192
.line	627	loadk        r32   k61 ; k61 = 216
.line	627	loadk        r33   k62 ; k62 = 249
.line	627	loadk        r34   k63 ; k63 = 116
.line	627	loadk        r35   k64 ; k64 = 124
.line	627	loadk        r36   k49 ; k49 = 226
.line	627	loadk        r37   k65 ; k65 = 157
.line	627	loadk        r38   k66 ; k66 = 51
.line	627	loadk        r39   k67 ; k67 = 43
.line	627	loadk        r40   k68 ; k68 = 9
.line	627	loadk        r41   k50 ; k50 = 221
.line	627	loadk        r42   k69 ; k69 = 251
.line	627	loadk        r43   k70 ; k70 = 152
.line	627	loadk        r44   k71 ; k71 = 117
.line	627	loadk        r45   k72 ; k72 = 20
.line	627	call          r6    40     2
.line	627	call          r5     2     2
.line	627	gettable      r6    r5   k73 ; k73 = "send_depot_set_head_" (truncated)
.line	627	loadk         r7   k74 ; k74 = 0
.line	627	call          r6     2     1
.line	627	jmp            0  l989
.label	l119
.line	627	gettable      r5    r4   k43 ; k43 = "itemSubType"
.line	627	gettabup      r6    u0   k44 ; k44 = "ENUM_ITEM_SUBTYPE"
.line	627	gettable      r6    r6   k75 ; k75 = "Upgrade_Backpack"
.line	627	eq             1    r5    r6
.line	627	jmp            0  l129
.line	627	gettable      r5    r4   k43 ; k43 = "itemSubType"
.line	627	gettabup      r6    u0   k44 ; k44 = "ENUM_ITEM_SUBTYPE"
.line	627	gettable      r6    r6   k76 ; k76 = "Backpack"
.line	627	eq             0    r5    r6
.line	627	jmp            0  l133
.label	l129
.line	627	gettable      r5    r3   k77 ; k77 = "ProcPutDownBagSkin"
.line	627	move          r6    r2
.line	627	call          r5     2     1
.line	627	jmp            0  l989
.label	l133
.line	627	gettable      r5    r4   k78 ; k78 = "WardrobeMainTab"
.line	627	gettabup      r6    u3   k79 ; k79 = "ENUM_WardrobePageTyp" (truncated)
.line	627	eq             0    r5    r6
.line	627	jmp            0  l488
.line	627	gettable      r5    r2   k80 ; k80 = "instid"
.line	627	getupval      r6    u2
.line	627	self          r6    r6   k81 ; k81 = "IsTabString_Bag_Helm" (truncated)
.line	627	gettable      r8    r4   k82 ; k82 = "WardrobeTab"
.line	627	call          r6     3     2
.line	627	test          r6     0
.line	627	jmp            0  l285
.line	627	gettabup      r6    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r6    r6   k84 ; k84 = "equipmentSkinInsIDTa" (truncated)
.line	627	gettable      r7    r4   k85 ; k85 = "ItemSubType"
.line	627	gettable      r6    r6    r7
.line	627	eq             0    r6    r5
.line	627	jmp            0  l989
.line	627	gettabup      r6    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r6    r6   k86 ; k86 = "UpdateEquipmentSkin"
.line	627	gettable      r7    r4   k85 ; k85 = "ItemSubType"
.line	627	loadk         r8   k74 ; k74 = 0
.line	627	call          r6     3     1
.line	627	getupval      r6    u2
.line	627	self          r6    r6   k87 ; k87 = "GetEquipmentItemIDBy" (truncated)
.line	627	gettable      r8    r4   k85 ; k85 = "ItemSubType"
.line	627	move          r9    r5
.line	627	call          r6     4     2
.line	627	le             0   k74    r6 ; k74 = 0
.line	627	jmp            0  l278
.line	627	gettable      r7    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r8    u4   k88 ; k88 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r7    r8
.line	627	jmp            0  l212
.line	627	gettabup      r7    u0    k0 ; k0 = "require"
.line	627	getupval      r8    u1
.line	627	loadk         r9    k1 ; k1 = 224
.line	627	loadk        r10    k2 ; k2 = 36
.line	627	loadk        r11    k3 ; k3 = 186
.line	627	loadk        r12    k4 ; k4 = 218
.line	627	loadk        r13    k5 ; k5 = 122
.line	627	loadk        r14    k6 ; k6 = 68
.line	627	loadk        r15    k7 ; k7 = 40
.line	627	loadk        r16   k48 ; k48 = 143
.line	627	loadk        r17   k49 ; k49 = 226
.line	627	loadk        r18   k50 ; k50 = 221
.line	627	loadk        r19   k51 ; k51 = 236
.line	627	loadk        r20   k52 ; k52 = 111
.line	627	loadk        r21   k53 ; k53 = 76
.line	627	loadk        r22   k54 ; k54 = 246
.line	627	loadk        r23   k55 ; k55 = 193
.line	627	loadk        r24   k56 ; k56 = 22
.line	627	loadk        r25   k17 ; k17 = 1
.line	627	loadk        r26   k57 ; k57 = 23
.line	627	loadk        r27   k58 ; k58 = 215
.line	627	loadk        r28    k1 ; k1 = 224
.line	627	loadk        r29   k59 ; k59 = 135
.line	627	loadk        r30   k52 ; k52 = 111
.line	627	loadk        r31   k21 ; k21 = 26
.line	627	loadk        r32   k60 ; k60 = 255
.line	627	loadk        r33   k33 ; k33 = 192
.line	627	loadk        r34   k61 ; k61 = 216
.line	627	loadk        r35   k62 ; k62 = 249
.line	627	loadk        r36   k63 ; k63 = 116
.line	627	loadk        r37   k64 ; k64 = 124
.line	627	loadk        r38   k49 ; k49 = 226
.line	627	loadk        r39   k65 ; k65 = 157
.line	627	loadk        r40   k66 ; k66 = 51
.line	627	loadk        r41   k67 ; k67 = 43
.line	627	loadk        r42   k68 ; k68 = 9
.line	627	loadk        r43   k50 ; k50 = 221
.line	627	loadk        r44   k69 ; k69 = 251
.line	627	loadk        r45   k70 ; k70 = 152
.line	627	loadk        r46   k71 ; k71 = 117
.line	627	loadk        r47   k72 ; k72 = 20
.line	627	call          r8    40     2
.line	627	call          r7     2     2
.line	627	gettable      r8    r7   k73 ; k73 = "send_depot_set_head_" (truncated)
.line	627	loadk         r9   k74 ; k74 = 0
.line	627	call          r8     2     1
.label	l212
.line	627	gettabup      r7    u0    k0 ; k0 = "require"
.line	627	gettabup      r8    u0   k89 ; k89 = "table"
.line	627	gettable      r8    r8   k90 ; k90 = "concat"
.line	627	newtable      r9     1     0
.line	627	getupval     r10    u1
.line	627	loadk        r11    k1 ; k1 = 224
.line	627	loadk        r12    k2 ; k2 = 36
.line	627	loadk        r13    k3 ; k3 = 186
.line	627	loadk        r14    k4 ; k4 = 218
.line	627	loadk        r15    k5 ; k5 = 122
.line	627	loadk        r16    k6 ; k6 = 68
.line	627	loadk        r17    k7 ; k7 = 40
.line	627	loadk        r18    k8 ; k8 = 141
.line	627	loadk        r19    k9 ; k9 = 232
.line	627	loadk        r20   k10 ; k10 = 206
.line	627	loadk        r21   k11 ; k11 = 242
.line	627	loadk        r22   k12 ; k12 = 99
.line	627	loadk        r23   k13 ; k13 = 16
.line	627	loadk        r24   k91 ; k91 = 252
.line	627	loadk        r25   k92 ; k92 = 153
.line	627	loadk        r26   k93 ; k93 = 39
.line	627	loadk        r27   k94 ; k94 = 7
.line	627	loadk        r28   k95 ; k95 = 25
.line	627	loadk        r29   k24 ; k24 = 209
.line	627	loadk        r30   k96 ; k96 = 161
.line	627	loadk        r31   k97 ; k97 = 136
.line	627	loadk        r32   k52 ; k52 = 111
.line	627	loadk        r33   k16 ; k16 = 17
.line	627	loadk        r34   k98 ; k98 = 184
.line	627	loadk        r35   k99 ; k99 = 244
.line	627	loadk        r36  k100 ; k100 = 230
.line	627	loadk        r37   k60 ; k60 = 255
.line	627	loadk        r38   k71 ; k71 = 117
.line	627	loadk        r39  k101 ; k101 = 79
.line	627	loadk        r40    k1 ; k1 = 224
.line	627	loadk        r41  k102 ; k102 = 160
.line	627	loadk        r42  k103 ; k103 = 55
.line	627	loadk        r43  k104 ; k104 = 21
.line	627	loadk        r44   k68 ; k68 = 9
.line	627	loadk        r45  k105 ; k105 = 199
.line	627	loadk        r46  k106 ; k106 = 254
.line	627	loadk        r47  k107 ; k107 = 134
.line	627	loadk        r48  k101 ; k101 = 79
.line	627	loadk        r49  k108 ; k108 = 11
.line	627	loadk        r50  k102 ; k102 = 160
.line	627	call         r10    41     2
.line	627	getupval     r11    u1
.line	627	loadk        r12  k109 ; k109 = 237
.line	627	loadk        r13  k110 ; k110 = 41
.line	627	loadk        r14  k111 ; k111 = 180
.line	627	loadk        r15    k4 ; k4 = 218
.line	627	loadk        r16  k112 ; k112 = 102
.line	627	call         r11     6     0
.line	627	setlist       r9     0     1
.line	627	call          r8     2     2
.line	627	call          r7     2     2
.line	627	gettable      r8    r7  k113 ; k113 = "ChangeAvatarEquipmen" (truncated)
.line	627	gettabup      r9    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r9    r9  k114 ; k114 = "roleData"
.line	627	gettable      r9    r9  k115 ; k115 = "uid"
.line	627	gettabup     r10    u0  k116 ; k116 = "AvatarData"
.line	627	gettable     r10   r10  k117 ; k117 = "CreateAvatarCustom"
.line	627	move         r11    r6
.line	627	call         r10     2     2
.line	627	loadbool     r11     0     0
.line	627	call          r8     4     1
.label	l278
.line	627	gettabup      r7    u0  k118 ; k118 = "EventSystem"
.line	627	self          r7    r7  k119 ; k119 = "postEvent"
.line	627	gettabup      r9    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup     r10    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r11    r2
.line	627	call          r7     5     1
.line	627	jmp            0  l989
.label	l285
.line	627	loadbool      r6     0     0
.line	627	gettabup      r7    u0  k116 ; k116 = "AvatarData"
.line	627	gettable      r7    r7  k122 ; k122 = "GetRoleWear"
.line	627	call          r7     1     2
.line	627	gettabup      r8    u0  k123 ; k123 = "pairs"
.line	627	move          r9    r7
.line	627	call          r8     2     4
.line	627	jmp            0  l297
.line	627	eq             0   r12    r5
.line	627	jmp            0  l297
.line	627	loadbool      r6     1     0
.line	627	jmp            0  l299
.label	l297
.line	627	move          r0    r0
.line	627	move          r0    r0
.label	l299
.line	627	test          r6     0
.line	627	jmp            0  l989
.line	627	gettabup      r8    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r8    r8  k124 ; k124 = "UpdateRoleWearData"
.line	627	loadk         r9   k74 ; k74 = 0
.line	627	move         r10    r5
.line	627	call          r8     3     1
.line	627	gettable      r8    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r9    u4  k125 ; k125 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r8    r9
.line	627	jmp            0  l425
.line	627	gettabup      r8    u0    k0 ; k0 = "require"
.line	627	gettabup      r9    u0   k89 ; k89 = "table"
.line	627	gettable      r9    r9   k90 ; k90 = "concat"
.line	627	newtable     r10     1     0
.line	627	getupval     r11    u1
.line	627	loadk        r12    k1 ; k1 = 224
.line	627	loadk        r13    k2 ; k2 = 36
.line	627	loadk        r14    k3 ; k3 = 186
.line	627	loadk        r15    k4 ; k4 = 218
.line	627	loadk        r16    k5 ; k5 = 122
.line	627	loadk        r17    k6 ; k6 = 68
.line	627	loadk        r18    k7 ; k7 = 40
.line	627	loadk        r19  k126 ; k126 = 146
.line	627	loadk        r20  k127 ; k127 = 235
.line	627	loadk        r21  k128 ; k128 = 220
.line	627	loadk        r22  k129 ; k129 = 250
.line	627	loadk        r23  k130 ; k130 = 46
.line	627	loadk        r24  k131 ; k131 = 82
.line	627	loadk        r25   k11 ; k11 = 242
.line	627	loadk        r26   k97 ; k97 = 136
.line	627	loadk        r27  k132 ; k132 = 47
.line	627	loadk        r28   k13 ; k13 = 16
.line	627	loadk        r29  k133 ; k133 = 86
.line	627	loadk        r30  k134 ; k134 = 212
.line	627	loadk        r31   k25 ; k25 = 238
.line	627	loadk        r32  k135 ; k135 = 150
.line	627	loadk        r33  k136 ; k136 = 100
.line	627	loadk        r34   k32 ; k32 = 4
.line	627	loadk        r35  k137 ; k137 = 190
.line	627	loadk        r36  k138 ; k138 = 245
.line	627	loadk        r37  k128 ; k128 = 220
.line	627	loadk        r38  k139 ; k139 = 165
.line	627	loadk        r39  k140 ; k140 = 118
.line	627	loadk        r40  k101 ; k101 = 79
.line	627	loadk        r41  k106 ; k106 = 254
.line	627	loadk        r42  k141 ; k141 = 151
.line	627	loadk        r43  k142 ; k142 = 63
.line	627	loadk        r44  k143 ; k143 = 12
.line	627	loadk        r45  k144 ; k144 = 6
.line	627	loadk        r46   k24 ; k24 = 209
.line	627	loadk        r47  k106 ; k106 = 254
.line	627	loadk        r48  k145 ; k145 = 147
.line	627	loadk        r49  k146 ; k146 = 62
.line	627	loadk        r50   k74 ; k74 = 0
.line	627	loadk        r51  k102 ; k102 = 160
.line	627	call         r11    41     2
.line	627	getupval     r12    u1
.line	627	loadk        r13  k147 ; k147 = 240
.line	627	loadk        r14  k148 ; k148 = 32
.line	627	loadk        r15    k3 ; k3 = 186
.line	627	loadk        r16  k149 ; k149 = 208
.line	627	loadk        r17    k5 ; k5 = 122
.line	627	loadk        r18  k131 ; k131 = 82
.line	627	loadk        r19  k150 ; k150 = 103
.line	627	loadk        r20  k107 ; k107 = 134
.line	627	loadk        r21   k61 ; k61 = 216
.line	627	loadk        r22  k151 ; k151 = 205
.line	627	loadk        r23  k129 ; k129 = 250
.line	627	loadk        r24   k63 ; k63 = 116
.line	627	loadk        r25  k152 ; k152 = 95
.line	627	call         r12    14     0
.line	627	setlist      r10     0     1
.line	627	call          r9     2     2
.line	627	call          r8     2     2
.line	627	self          r9    r8  k153 ; k153 = "SetHeadShow"
.line	627	loadk        r11   k74 ; k74 = 0
.line	627	call          r9     3     1
.line	627	gettabup      r9    u0    k0 ; k0 = "require"
.line	627	getupval     r10    u1
.line	627	loadk        r11    k1 ; k1 = 224
.line	627	loadk        r12    k2 ; k2 = 36
.line	627	loadk        r13    k3 ; k3 = 186
.line	627	loadk        r14    k4 ; k4 = 218
.line	627	loadk        r15    k5 ; k5 = 122
.line	627	loadk        r16    k6 ; k6 = 68
.line	627	loadk        r17    k7 ; k7 = 40
.line	627	loadk        r18   k48 ; k48 = 143
.line	627	loadk        r19   k49 ; k49 = 226
.line	627	loadk        r20   k50 ; k50 = 221
.line	627	loadk        r21   k51 ; k51 = 236
.line	627	loadk        r22   k52 ; k52 = 111
.line	627	loadk        r23   k53 ; k53 = 76
.line	627	loadk        r24   k54 ; k54 = 246
.line	627	loadk        r25   k55 ; k55 = 193
.line	627	loadk        r26   k56 ; k56 = 22
.line	627	loadk        r27   k17 ; k17 = 1
.line	627	loadk        r28   k57 ; k57 = 23
.line	627	loadk        r29   k58 ; k58 = 215
.line	627	loadk        r30    k1 ; k1 = 224
.line	627	loadk        r31   k59 ; k59 = 135
.line	627	loadk        r32   k52 ; k52 = 111
.line	627	loadk        r33   k21 ; k21 = 26
.line	627	loadk        r34   k60 ; k60 = 255
.line	627	loadk        r35   k33 ; k33 = 192
.line	627	loadk        r36   k61 ; k61 = 216
.line	627	loadk        r37   k62 ; k62 = 249
.line	627	loadk        r38   k63 ; k63 = 116
.line	627	loadk        r39   k64 ; k64 = 124
.line	627	loadk        r40   k49 ; k49 = 226
.line	627	loadk        r41   k65 ; k65 = 157
.line	627	loadk        r42   k66 ; k66 = 51
.line	627	loadk        r43   k67 ; k67 = 43
.line	627	loadk        r44   k68 ; k68 = 9
.line	627	loadk        r45   k50 ; k50 = 221
.line	627	loadk        r46   k69 ; k69 = 251
.line	627	loadk        r47   k70 ; k70 = 152
.line	627	loadk        r48   k71 ; k71 = 117
.line	627	loadk        r49   k72 ; k72 = 20
.line	627	call         r10    40     2
.line	627	call          r9     2     2
.line	627	gettable     r10    r9   k73 ; k73 = "send_depot_set_head_" (truncated)
.line	627	loadk        r11   k74 ; k74 = 0
.line	627	call         r10     2     1
.line	627	gettable     r10    r3  k154 ; k154 = "ProcPutDownHat"
.line	627	call         r10     1     1
.label	l425
.line	627	gettable      r8    r2   k40 ; k40 = "res_id"
.line	627	gettabup      r9    u0    k0 ; k0 = "require"
.line	627	getupval     r10    u1
.line	627	loadk        r11    k1 ; k1 = 224
.line	627	loadk        r12    k2 ; k2 = 36
.line	627	loadk        r13    k3 ; k3 = 186
.line	627	loadk        r14    k4 ; k4 = 218
.line	627	loadk        r15    k5 ; k5 = 122
.line	627	loadk        r16    k6 ; k6 = 68
.line	627	loadk        r17    k7 ; k7 = 40
.line	627	loadk        r18  k126 ; k126 = 146
.line	627	loadk        r19  k127 ; k127 = 235
.line	627	loadk        r20  k128 ; k128 = 220
.line	627	loadk        r21  k129 ; k129 = 250
.line	627	loadk        r22  k130 ; k130 = 46
.line	627	loadk        r23  k131 ; k131 = 82
.line	627	loadk        r24   k11 ; k11 = 242
.line	627	loadk        r25   k97 ; k97 = 136
.line	627	loadk        r26  k132 ; k132 = 47
.line	627	loadk        r27   k13 ; k13 = 16
.line	627	loadk        r28  k133 ; k133 = 86
.line	627	loadk        r29   k69 ; k69 = 251
.line	627	loadk        r30  k128 ; k128 = 220
.line	627	loadk        r31  k155 ; k155 = 145
.line	627	loadk        r32  k156 ; k156 = 105
.line	627	loadk        r33  k157 ; k157 = 2
.line	627	loadk        r34   k60 ; k60 = 255
.line	627	loadk        r35   k69 ; k69 = 251
.line	627	loadk        r36  k158 ; k158 = 214
.line	627	loadk        r37   k51 ; k51 = 236
.line	627	loadk        r38  k159 ; k159 = 121
.line	627	loadk        r39  k160 ; k160 = 77
.line	627	loadk        r40   k28 ; k28 = 210
.line	627	loadk        r41   k59 ; k59 = 135
.line	627	loadk        r42  k161 ; k161 = 37
.line	627	loadk        r43   k56 ; k56 = 22
.line	627	loadk        r44   k17 ; k17 = 1
.line	627	loadk        r45  k105 ; k105 = 199
.line	627	call         r10    36     2
.line	627	call          r9     2     2
.line	627	gettable     r10    r9  k162 ; k162 = "IsXSuit"
.line	627	move         r11    r8
.line	627	call         r10     2     2
.line	627	test         r10     0
.line	627	jmp            0  l474
.line	627	gettable     r10    r9  k163 ; k163 = "GetItemShowID"
.line	627	gettable     r11    r2   k80 ; k80 = "instid"
.line	627	call         r10     2     2
.line	627	move          r8   r10
.label	l474
.line	627	getupval     r10    u2
.line	627	self         r10   r10  k164 ; k164 = "AvatarChange"
.line	627	move         r12    r8
.line	627	loadbool     r13     0     0
.line	627	call         r10     4     1
.line	627	gettabup     r10    u0  k118 ; k118 = "EventSystem"
.line	627	self         r10   r10  k119 ; k119 = "postEvent"
.line	627	gettabup     r12    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup     r13    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r14    r2
.line	627	call         r10     5     1
.line	627	gettable     r10    r9  k165 ; k165 = "RefreshSharedRelicIn" (truncated)
.line	627	call         r10     1     1
.line	627	jmp            0  l989
.label	l488
.line	627	gettable      r5    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r6    u4  k166 ; k166 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r5    r6
.line	627	jmp            0  l568
.line	627	self          r5    r0  k167 ; k167 = "OnPutOffAircraft"
.line	627	move          r7    r2
.line	627	call          r5     3     1
.line	627	gettabup      r5    u0    k0 ; k0 = "require"
.line	627	gettabup      r6    u0   k89 ; k89 = "table"
.line	627	gettable      r6    r6   k90 ; k90 = "concat"
.line	627	newtable      r7     1     0
.line	627	getupval      r8    u1
.line	627	loadk         r9    k1 ; k1 = 224
.line	627	loadk        r10    k2 ; k2 = 36
.line	627	loadk        r11    k3 ; k3 = 186
.line	627	loadk        r12    k4 ; k4 = 218
.line	627	loadk        r13    k5 ; k5 = 122
.line	627	loadk        r14    k6 ; k6 = 68
.line	627	loadk        r15    k7 ; k7 = 40
.line	627	loadk        r16  k126 ; k126 = 146
.line	627	loadk        r17  k127 ; k127 = 235
.line	627	loadk        r18  k128 ; k128 = 220
.line	627	loadk        r19  k129 ; k129 = 250
.line	627	loadk        r20  k130 ; k130 = 46
.line	627	loadk        r21  k131 ; k131 = 82
.line	627	loadk        r22   k11 ; k11 = 242
.line	627	loadk        r23   k97 ; k97 = 136
.line	627	loadk        r24  k132 ; k132 = 47
.line	627	loadk        r25   k13 ; k13 = 16
.line	627	loadk        r26  k133 ; k133 = 86
.line	627	loadk        r27  k134 ; k134 = 212
.line	627	loadk        r28   k25 ; k25 = 238
.line	627	loadk        r29  k135 ; k135 = 150
.line	627	loadk        r30  k136 ; k136 = 100
.line	627	loadk        r31   k32 ; k32 = 4
.line	627	loadk        r32  k137 ; k137 = 190
.line	627	loadk        r33  k138 ; k138 = 245
.line	627	loadk        r34  k128 ; k128 = 220
.line	627	loadk        r35  k139 ; k139 = 165
.line	627	loadk        r36  k140 ; k140 = 118
.line	627	loadk        r37  k101 ; k101 = 79
.line	627	loadk        r38  k106 ; k106 = 254
.line	627	loadk        r39  k141 ; k141 = 151
.line	627	loadk        r40  k142 ; k142 = 63
.line	627	loadk        r41  k143 ; k143 = 12
.line	627	loadk        r42  k144 ; k144 = 6
.line	627	loadk        r43   k24 ; k24 = 209
.line	627	loadk        r44  k106 ; k106 = 254
.line	627	loadk        r45  k145 ; k145 = 147
.line	627	loadk        r46  k146 ; k146 = 62
.line	627	loadk        r47   k74 ; k74 = 0
.line	627	loadk        r48  k102 ; k102 = 160
.line	627	call          r8    41     2
.line	627	getupval      r9    u1
.line	627	loadk        r10  k147 ; k147 = 240
.line	627	loadk        r11  k148 ; k148 = 32
.line	627	loadk        r12    k3 ; k3 = 186
.line	627	loadk        r13  k149 ; k149 = 208
.line	627	loadk        r14    k5 ; k5 = 122
.line	627	loadk        r15  k131 ; k131 = 82
.line	627	loadk        r16  k150 ; k150 = 103
.line	627	loadk        r17  k107 ; k107 = 134
.line	627	loadk        r18   k61 ; k61 = 216
.line	627	loadk        r19  k151 ; k151 = 205
.line	627	loadk        r20  k129 ; k129 = 250
.line	627	loadk        r21   k63 ; k63 = 116
.line	627	loadk        r22  k152 ; k152 = 95
.line	627	call          r9    14     0
.line	627	setlist       r7     0     1
.line	627	call          r6     2     2
.line	627	call          r5     2     2
.line	627	self          r6    r5  k168 ; k168 = "ClearAircraftOrGlidi" (truncated)
.line	627	call          r6     2     1
.line	627	gettabup      r6    u0  k118 ; k118 = "EventSystem"
.line	627	self          r6    r6  k119 ; k119 = "postEvent"
.line	627	gettabup      r8    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup      r9    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r10    r2
.line	627	call          r6     5     1
.line	627	jmp            0  l989
.label	l568
.line	627	gettable      r5    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r6    u4  k169 ; k169 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r5    r6
.line	627	jmp            0  l685
.line	627	gettabup      r5    u0    k0 ; k0 = "require"
.line	627	getupval      r6    u1
.line	627	loadk         r7    k1 ; k1 = 224
.line	627	loadk         r8    k2 ; k2 = 36
.line	627	loadk         r9    k3 ; k3 = 186
.line	627	loadk        r10    k4 ; k4 = 218
.line	627	loadk        r11    k5 ; k5 = 122
.line	627	loadk        r12    k6 ; k6 = 68
.line	627	loadk        r13    k7 ; k7 = 40
.line	627	loadk        r14    k8 ; k8 = 141
.line	627	loadk        r15    k9 ; k9 = 232
.line	627	loadk        r16   k10 ; k10 = 206
.line	627	loadk        r17   k11 ; k11 = 242
.line	627	loadk        r18   k12 ; k12 = 99
.line	627	loadk        r19   k13 ; k13 = 16
.line	627	loadk        r20  k151 ; k151 = 205
.line	627	loadk        r21   k29 ; k29 = 138
.line	627	loadk        r22   k93 ; k93 = 39
.line	627	loadk        r23  k170 ; k170 = 24
.line	627	loadk        r24  k142 ; k142 = 63
.line	627	loadk        r25  k171 ; k171 = 194
.line	627	loadk        r26   k49 ; k49 = 226
.line	627	loadk        r27  k172 ; k172 = 129
.line	627	loadk        r28  k130 ; k130 = 46
.line	627	loadk        r29  k173 ; k173 = 38
.line	627	loadk        r30  k111 ; k111 = 180
.line	627	loadk        r31   k54 ; k54 = 246
.line	627	loadk        r32   k28 ; k28 = 210
.line	627	loadk        r33  k174 ; k174 = 204
.line	627	loadk        r34  k175 ; k175 = 113
.line	627	loadk        r35  k176 ; k176 = 67
.line	627	loadk        r36    k9 ; k9 = 232
.line	627	loadk        r37  k177 ; k177 = 188
.line	627	loadk        r38  k178 ; k178 = 57
.line	627	loadk        r39  k179 ; k179 = 13
.line	627	loadk        r40  k180 ; k180 = 14
.line	627	loadk        r41    k4 ; k4 = 218
.line	627	loadk        r42  k181 ; k181 = 248
.line	627	call          r6    37     2
.line	627	call          r5     2     2
.line	627	gettabup      r6    u0  k182 ; k182 = "ModuleManager"
.line	627	gettable      r6    r6  k183 ; k183 = "GetModule"
.line	627	gettabup      r7    u0  k182 ; k182 = "ModuleManager"
.line	627	gettable      r7    r7  k184 ; k184 = "LobbyModuleConfig"
.line	627	gettable      r7    r7  k185 ; k185 = "LogicAddScordCard"
.line	627	call          r6     2     2
.line	627	gettabup      r7    u5  k186 ; k186 = "ENUM_WardrobePropRes" (truncated)
.line	627	gettable      r7    r7  k187 ; k187 = "RATING_SHIELD_ONCE"
.line	627	gettable      r8    r2   k40 ; k40 = "res_id"
.line	627	eq             1    r7    r8
.line	627	jmp            0  l643
.line	627	gettabup      r7    u5  k186 ; k186 = "ENUM_WardrobePropRes" (truncated)
.line	627	gettable      r7    r7  k188 ; k188 = "RATING_SHIELD_ONCE_S" (truncated)
.line	627	gettable      r8    r2   k40 ; k40 = "res_id"
.line	627	eq             1    r7    r8
.line	627	jmp            0  l643
.line	627	self          r7    r6  k189 ; k189 = "IsPutOnSeasonAddScor" (truncated)
.line	627	gettable      r9    r2   k40 ; k40 = "res_id"
.line	627	call          r7     3     2
.line	627	test          r7     1
.line	627	jmp            0  l643
.line	627	gettabup      r7    u5  k186 ; k186 = "ENUM_WardrobePropRes" (truncated)
.line	627	gettable      r7    r7  k190 ; k190 = "VS_TEAM_RATING_PROTE" (truncated)
.line	627	gettable      r8    r2   k40 ; k40 = "res_id"
.line	627	eq             1    r7    r8
.line	627	jmp            0  l643
.line	627	gettable      r7    r5  k191 ; k191 = "ProtectCard"
.line	627	gettable      r7    r7  k192 ; k192 = "PointsProtectionCard"
.line	627	gettable      r8    r2   k40 ; k40 = "res_id"
.line	627	eq             0    r7    r8
.line	627	jmp            0  l656
.label	l643
.line	627	gettabup      r7    u0  k193 ; k193 = "LocUtil"
.line	627	gettable      r7    r7  k194 ; k194 = "LocalizeResFormat"
.line	627	getupval      r8    u1
.line	627	loadk         r9  k111 ; k111 = 180
.line	627	loadk        r10  k195 ; k195 = 123
.line	627	loadk        r11   k18 ; k18 = 231
.line	627	loadk        r12   k59 ; k59 = 135
.line	627	call          r8     5     2
.line	627	gettable      r9    r4  k196 ; k196 = "ItemName"
.line	627	call          r7     3     2
.line	627	gettabup      r8    u0  k197 ; k197 = "ShowNotice"
.line	627	move          r9    r7
.line	627	call          r8     2     1
.label	l656
.line	627	gettable      r7    r4   k85 ; k85 = "ItemSubType"
.line	627	gettabup      r8    u0   k44 ; k44 = "ENUM_ITEM_SUBTYPE"
.line	627	gettable      r8    r8  k198 ; k198 = "ClickEffect"
.line	627	eq             0    r7    r8
.line	627	jmp            0  l678
.line	627	gettabup      r7    u0  k182 ; k182 = "ModuleManager"
.line	627	gettable      r7    r7  k183 ; k183 = "GetModule"
.line	627	gettabup      r8    u0  k182 ; k182 = "ModuleManager"
.line	627	gettable      r8    r8  k199 ; k199 = "CommonModuleConfig"
.line	627	gettable      r8    r8  k200 ; k200 = "ClickEffectModule"
.line	627	call          r7     2     2
.line	627	self          r8    r7  k201 ; k201 = "SetCurrentUse"
.line	627	loadk        r10   k74 ; k74 = 0
.line	627	call          r8     3     1
.line	627	gettabup      r8    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r8    r8  k202 ; k202 = "UpdateCommonPutOnDat" (truncated)
.line	627	gettable      r9    r4   k85 ; k85 = "ItemSubType"
.line	627	loadk        r10   k74 ; k74 = 0
.line	627	call          r8     3     1
.line	627	gettabup      r8    u0  k197 ; k197 = "ShowNotice"
.line	627	loadk         r9  k203 ; k203 = 20051012
.line	627	call          r8     2     1
.label	l678
.line	627	gettabup      r7    u0  k118 ; k118 = "EventSystem"
.line	627	self          r7    r7  k119 ; k119 = "postEvent"
.line	627	gettabup      r9    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup     r10    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r11    r2
.line	627	call          r7     5     1
.line	627	jmp            0  l989
.label	l685
.line	627	gettable      r5    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r6    u4  k204 ; k204 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r5    r6
.line	627	jmp            0  l763
.line	627	gettabup      r5    u0    k0 ; k0 = "require"
.line	627	gettabup      r6    u0   k89 ; k89 = "table"
.line	627	gettable      r6    r6   k90 ; k90 = "concat"
.line	627	newtable      r7     1     0
.line	627	getupval      r8    u1
.line	627	loadk         r9    k1 ; k1 = 224
.line	627	loadk        r10    k2 ; k2 = 36
.line	627	loadk        r11    k3 ; k3 = 186
.line	627	loadk        r12    k4 ; k4 = 218
.line	627	loadk        r13    k5 ; k5 = 122
.line	627	loadk        r14    k6 ; k6 = 68
.line	627	loadk        r15    k7 ; k7 = 40
.line	627	loadk        r16  k126 ; k126 = 146
.line	627	loadk        r17  k127 ; k127 = 235
.line	627	loadk        r18  k128 ; k128 = 220
.line	627	loadk        r19  k129 ; k129 = 250
.line	627	loadk        r20  k130 ; k130 = 46
.line	627	loadk        r21  k131 ; k131 = 82
.line	627	loadk        r22   k11 ; k11 = 242
.line	627	loadk        r23   k97 ; k97 = 136
.line	627	loadk        r24  k132 ; k132 = 47
.line	627	loadk        r25   k13 ; k13 = 16
.line	627	loadk        r26  k133 ; k133 = 86
.line	627	loadk        r27  k134 ; k134 = 212
.line	627	loadk        r28   k25 ; k25 = 238
.line	627	loadk        r29  k135 ; k135 = 150
.line	627	loadk        r30  k136 ; k136 = 100
.line	627	loadk        r31   k32 ; k32 = 4
.line	627	loadk        r32  k137 ; k137 = 190
.line	627	loadk        r33  k138 ; k138 = 245
.line	627	loadk        r34  k128 ; k128 = 220
.line	627	loadk        r35  k139 ; k139 = 165
.line	627	loadk        r36  k140 ; k140 = 118
.line	627	loadk        r37  k101 ; k101 = 79
.line	627	loadk        r38  k106 ; k106 = 254
.line	627	loadk        r39  k141 ; k141 = 151
.line	627	loadk        r40  k142 ; k142 = 63
.line	627	loadk        r41  k143 ; k143 = 12
.line	627	loadk        r42  k144 ; k144 = 6
.line	627	loadk        r43   k24 ; k24 = 209
.line	627	loadk        r44  k106 ; k106 = 254
.line	627	loadk        r45  k145 ; k145 = 147
.line	627	loadk        r46  k146 ; k146 = 62
.line	627	loadk        r47   k74 ; k74 = 0
.line	627	loadk        r48  k102 ; k102 = 160
.line	627	call          r8    41     2
.line	627	getupval      r9    u1
.line	627	loadk        r10  k147 ; k147 = 240
.line	627	loadk        r11  k148 ; k148 = 32
.line	627	loadk        r12    k3 ; k3 = 186
.line	627	loadk        r13  k149 ; k149 = 208
.line	627	loadk        r14    k5 ; k5 = 122
.line	627	loadk        r15  k131 ; k131 = 82
.line	627	loadk        r16  k150 ; k150 = 103
.line	627	loadk        r17  k107 ; k107 = 134
.line	627	loadk        r18   k61 ; k61 = 216
.line	627	loadk        r19  k151 ; k151 = 205
.line	627	loadk        r20  k129 ; k129 = 250
.line	627	loadk        r21   k63 ; k63 = 116
.line	627	loadk        r22  k152 ; k152 = 95
.line	627	call          r9    14     0
.line	627	setlist       r7     0     1
.line	627	call          r6     2     2
.line	627	call          r5     2     2
.line	627	self          r6    r5  k205 ; k205 = "PutDownThrowObjectSk" (truncated)
.line	627	gettable      r8    r2   k80 ; k80 = "instid"
.line	627	call          r6     3     1
.line	627	gettabup      r6    u0  k118 ; k118 = "EventSystem"
.line	627	self          r6    r6  k119 ; k119 = "postEvent"
.line	627	gettabup      r8    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup      r9    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r10    r2
.line	627	call          r6     5     1
.line	627	jmp            0  l989
.label	l763
.line	627	gettable      r5    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r6    u4  k206 ; k206 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r5    r6
.line	627	jmp            0  l841
.line	627	gettabup      r5    u0    k0 ; k0 = "require"
.line	627	gettabup      r6    u0   k89 ; k89 = "table"
.line	627	gettable      r6    r6   k90 ; k90 = "concat"
.line	627	newtable      r7     1     0
.line	627	getupval      r8    u1
.line	627	loadk         r9    k1 ; k1 = 224
.line	627	loadk        r10    k2 ; k2 = 36
.line	627	loadk        r11    k3 ; k3 = 186
.line	627	loadk        r12    k4 ; k4 = 218
.line	627	loadk        r13    k5 ; k5 = 122
.line	627	loadk        r14    k6 ; k6 = 68
.line	627	loadk        r15    k7 ; k7 = 40
.line	627	loadk        r16  k126 ; k126 = 146
.line	627	loadk        r17  k127 ; k127 = 235
.line	627	loadk        r18  k128 ; k128 = 220
.line	627	loadk        r19  k129 ; k129 = 250
.line	627	loadk        r20  k130 ; k130 = 46
.line	627	loadk        r21  k131 ; k131 = 82
.line	627	loadk        r22   k11 ; k11 = 242
.line	627	loadk        r23   k97 ; k97 = 136
.line	627	loadk        r24  k132 ; k132 = 47
.line	627	loadk        r25   k13 ; k13 = 16
.line	627	loadk        r26  k133 ; k133 = 86
.line	627	loadk        r27  k134 ; k134 = 212
.line	627	loadk        r28   k25 ; k25 = 238
.line	627	loadk        r29  k135 ; k135 = 150
.line	627	loadk        r30  k136 ; k136 = 100
.line	627	loadk        r31   k32 ; k32 = 4
.line	627	loadk        r32  k137 ; k137 = 190
.line	627	loadk        r33  k138 ; k138 = 245
.line	627	loadk        r34  k128 ; k128 = 220
.line	627	loadk        r35  k139 ; k139 = 165
.line	627	loadk        r36  k140 ; k140 = 118
.line	627	loadk        r37  k101 ; k101 = 79
.line	627	loadk        r38  k106 ; k106 = 254
.line	627	loadk        r39  k141 ; k141 = 151
.line	627	loadk        r40  k142 ; k142 = 63
.line	627	loadk        r41  k143 ; k143 = 12
.line	627	loadk        r42  k144 ; k144 = 6
.line	627	loadk        r43   k24 ; k24 = 209
.line	627	loadk        r44  k106 ; k106 = 254
.line	627	loadk        r45  k145 ; k145 = 147
.line	627	loadk        r46  k146 ; k146 = 62
.line	627	loadk        r47   k74 ; k74 = 0
.line	627	loadk        r48  k102 ; k102 = 160
.line	627	call          r8    41     2
.line	627	getupval      r9    u1
.line	627	loadk        r10  k147 ; k147 = 240
.line	627	loadk        r11  k148 ; k148 = 32
.line	627	loadk        r12    k3 ; k3 = 186
.line	627	loadk        r13  k149 ; k149 = 208
.line	627	loadk        r14    k5 ; k5 = 122
.line	627	loadk        r15  k131 ; k131 = 82
.line	627	loadk        r16  k150 ; k150 = 103
.line	627	loadk        r17  k107 ; k107 = 134
.line	627	loadk        r18   k61 ; k61 = 216
.line	627	loadk        r19  k151 ; k151 = 205
.line	627	loadk        r20  k129 ; k129 = 250
.line	627	loadk        r21   k63 ; k63 = 116
.line	627	loadk        r22  k152 ; k152 = 95
.line	627	call          r9    14     0
.line	627	setlist       r7     0     1
.line	627	call          r6     2     2
.line	627	call          r5     2     2
.line	627	self          r6    r5  k207 ; k207 = "PutDownBagPendants"
.line	627	gettable      r8    r2   k80 ; k80 = "instid"
.line	627	call          r6     3     1
.line	627	gettabup      r6    u0  k118 ; k118 = "EventSystem"
.line	627	self          r6    r6  k119 ; k119 = "postEvent"
.line	627	gettabup      r8    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup      r9    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r10    r2
.line	627	call          r6     5     1
.line	627	jmp            0  l989
.label	l841
.line	627	gettable      r5    r4   k82 ; k82 = "WardrobeTab"
.line	627	gettabup      r6    u4  k208 ; k208 = "ENUM_WardrobeSubTabS" (truncated)
.line	627	eq             0    r5    r6
.line	627	jmp            0  l929
.line	627	gettable      r5    r4   k85 ; k85 = "ItemSubType"
.line	627	gettabup      r6    u0   k44 ; k44 = "ENUM_ITEM_SUBTYPE"
.line	627	gettable      r6    r6  k209 ; k209 = "Foot_Effect"
.line	627	eq             0    r5    r6
.line	627	jmp            0  l855
.line	627	gettabup      r5    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r5    r5  k210 ; k210 = "UpdateFootEffect"
.line	627	loadk         r6   k74 ; k74 = 0
.line	627	call          r5     2     1
.line	627	jmp            0  l860
.label	l855
.line	627	gettabup      r5    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r5    r5  k202 ; k202 = "UpdateCommonPutOnDat" (truncated)
.line	627	gettable      r6    r4   k85 ; k85 = "ItemSubType"
.line	627	loadk         r7   k74 ; k74 = 0
.line	627	call          r5     3     1
.label	l860
.line	627	gettabup      r5    u0    k0 ; k0 = "require"
.line	627	gettabup      r6    u0   k89 ; k89 = "table"
.line	627	gettable      r6    r6   k90 ; k90 = "concat"
.line	627	newtable      r7     1     0
.line	627	getupval      r8    u1
.line	627	loadk         r9    k1 ; k1 = 224
.line	627	loadk        r10    k2 ; k2 = 36
.line	627	loadk        r11    k3 ; k3 = 186
.line	627	loadk        r12    k4 ; k4 = 218
.line	627	loadk        r13    k5 ; k5 = 122
.line	627	loadk        r14    k6 ; k6 = 68
.line	627	loadk        r15    k7 ; k7 = 40
.line	627	loadk        r16    k8 ; k8 = 141
.line	627	loadk        r17    k9 ; k9 = 232
.line	627	loadk        r18   k10 ; k10 = 206
.line	627	loadk        r19   k11 ; k11 = 242
.line	627	loadk        r20   k12 ; k12 = 99
.line	627	loadk        r21   k13 ; k13 = 16
.line	627	loadk        r22   k91 ; k91 = 252
.line	627	loadk        r23   k92 ; k92 = 153
.line	627	loadk        r24   k93 ; k93 = 39
.line	627	loadk        r25   k94 ; k94 = 7
.line	627	loadk        r26   k95 ; k95 = 25
.line	627	loadk        r27   k24 ; k24 = 209
.line	627	loadk        r28   k96 ; k96 = 161
.line	627	loadk        r29   k97 ; k97 = 136
.line	627	loadk        r30   k52 ; k52 = 111
.line	627	loadk        r31   k16 ; k16 = 17
.line	627	loadk        r32   k98 ; k98 = 184
.line	627	loadk        r33   k99 ; k99 = 244
.line	627	loadk        r34  k100 ; k100 = 230
.line	627	loadk        r35   k60 ; k60 = 255
.line	627	loadk        r36   k71 ; k71 = 117
.line	627	loadk        r37  k101 ; k101 = 79
.line	627	loadk        r38    k1 ; k1 = 224
.line	627	loadk        r39  k102 ; k102 = 160
.line	627	loadk        r40  k103 ; k103 = 55
.line	627	loadk        r41  k104 ; k104 = 21
.line	627	loadk        r42   k68 ; k68 = 9
.line	627	loadk        r43  k105 ; k105 = 199
.line	627	loadk        r44  k106 ; k106 = 254
.line	627	loadk        r45  k107 ; k107 = 134
.line	627	loadk        r46  k101 ; k101 = 79
.line	627	loadk        r47  k108 ; k108 = 11
.line	627	loadk        r48  k102 ; k102 = 160
.line	627	call          r8    41     2
.line	627	getupval      r9    u1
.line	627	loadk        r10  k109 ; k109 = 237
.line	627	loadk        r11  k110 ; k110 = 41
.line	627	loadk        r12  k111 ; k111 = 180
.line	627	loadk        r13    k4 ; k4 = 218
.line	627	loadk        r14  k112 ; k112 = 102
.line	627	call          r9     6     0
.line	627	setlist       r7     0     1
.line	627	call          r6     2     2
.line	627	call          r5     2     2
.line	627	gettable      r6    r5  k211 ; k211 = "PutoffEquipment"
.line	627	gettabup      r7    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r7    r7  k114 ; k114 = "roleData"
.line	627	gettable      r7    r7  k115 ; k115 = "uid"
.line	627	gettable      r8    r2   k40 ; k40 = "res_id"
.line	627	call          r6     3     1
.line	627	gettabup      r6    u0  k118 ; k118 = "EventSystem"
.line	627	self          r6    r6  k119 ; k119 = "postEvent"
.line	627	gettabup      r8    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup      r9    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move         r10    r2
.line	627	call          r6     5     1
.line	627	jmp            0  l989
.label	l929
.line	627	gettable      r5    r4  k212 ; k212 = "itemType"
.line	627	eq             0    r5  k213 ; k213 = 61
.line	627	jmp            0  l943
.line	627	gettabup      r5    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r5    r5  k214 ; k214 = "UpdateStatueSkin"
.line	627	loadk         r6   k74 ; k74 = 0
.line	627	call          r5     2     1
.line	627	gettabup      r5    u0  k118 ; k118 = "EventSystem"
.line	627	self          r5    r5  k119 ; k119 = "postEvent"
.line	627	gettabup      r7    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup      r8    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move          r9    r2
.line	627	call          r5     5     1
.line	627	jmp            0  l989
.label	l943
.line	627	gettabup      r5    u0   k35 ; k35 = "CDataTable"
.line	627	gettable      r5    r5   k36 ; k36 = "GetTableData"
.line	627	getupval      r6    u1
.line	627	loadk         r7   k58 ; k58 = 215
.line	627	loadk         r8  k148 ; k148 = 32
.line	627	loadk         r9   k39 ; k39 = 182
.line	627	loadk        r10   k28 ; k28 = 210
.line	627	loadk        r11  k175 ; k175 = 113
.line	627	loadk        r12   k12 ; k12 = 99
.line	627	loadk        r13  k215 ; k215 = 109
.line	627	loadk        r14   k97 ; k97 = 136
.line	627	loadk        r15  k216 ; k216 = 233
.line	627	loadk        r16    k1 ; k1 = 224
.line	627	loadk        r17  k217 ; k217 = 239
.line	627	loadk        r18  k218 ; k218 = 101
.line	627	loadk        r19  k219 ; k219 = 83
.line	627	loadk        r20  k220 ; k220 = 201
.line	627	loadk        r21  k135 ; k135 = 150
.line	627	loadk        r22  k221 ; k221 = 54
.line	627	loadk        r23   k56 ; k56 = 22
.line	627	loadk        r24  k222 ; k222 = 59
.line	627	loadk        r25  k174 ; k174 = 204
.line	627	loadk        r26  k223 ; k223 = 225
.line	627	loadk        r27  k224 ; k224 = 130
.line	627	loadk        r28  k156 ; k156 = 105
.line	627	loadk        r29   k16 ; k16 = 17
.line	627	call          r6    24     2
.line	627	gettable      r7    r4   k43 ; k43 = "itemSubType"
.line	627	call          r5     3     2
.line	627	test          r5     0
.line	627	jmp            0  l989
.line	627	gettabup      r5    u0  k197 ; k197 = "ShowNotice"
.line	627	loadk         r6  k225 ; k225 = 792645
.line	627	call          r5     2     1
.line	627	gettabup      r5    u0  k116 ; k116 = "AvatarData"
.line	627	gettable      r5    r5  k226 ; k226 = "UpdateCommonSubtypeW" (truncated)
.line	627	gettable      r6    r4   k43 ; k43 = "itemSubType"
.line	627	gettable      r7    r2   k80 ; k80 = "instid"
.line	627	loadbool      r8     0     0
.line	627	call          r5     4     1
.line	627	gettabup      r5    u0  k118 ; k118 = "EventSystem"
.line	627	self          r5    r5  k119 ; k119 = "postEvent"
.line	627	gettabup      r7    u0  k120 ; k120 = "EVENTTYPE_WARDROBE"
.line	627	gettabup      r8    u0  k121 ; k121 = "EVENTID_WARDROBE_UPD" (truncated)
.line	627	move          r9    r2
.line	627	call          r5     5     1
.label	l989
.line	627	gettabup      r5    u0  k182 ; k182 = "ModuleManager"
.line	627	gettable      r5    r5  k183 ; k183 = "GetModule"
.line	627	gettabup      r6    u0  k182 ; k182 = "ModuleManager"
.line	627	gettable      r6    r6  k227 ; k227 = "DataModuleConfig"
.line	627	gettable      r6    r6  k228 ; k228 = "BasicDataAvatarWearI" (truncated)
.line	627	call          r5     2     2
.line	627	self          r6    r5  k229 ; k229 = "GetOrReqData"
.line	627	gettabup      r8    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r8    r8  k114 ; k114 = "roleData"
.line	627	gettable      r8    r8  k115 ; k115 = "uid"
.line	627	closure       r9    f0
.line	627	newtable     r10     0     1
.line	627	settable     r10  k230  k231 ; k231 = true
.line	627	gettabup     r11    u0  k232 ; k232 = "Enum_AvatarShowSourc" (truncated)
.line	627	gettable     r11   r11  k233 ; k233 = "WardrobeLogic"
.line	627	call          r6     6     1
.line	627	jmp            0 l1010
.label	l1006
.line	627	gettabup      r4    u0   k83 ; k83 = "DataMgr"
.line	627	gettable      r4    r4  k234 ; k234 = "ShowMessageBoxByID"
.line	627	move          r5    r1
.line	627	call          r4     2     1
.label	l1010
.line	627	settabup      u6  k235  k231 ; k231 = true
.line	627	gettabup      r4    u0  k236 ; k236 = "RequireBlackList"
.line	627	gettabup      r5    u0   k89 ; k89 = "table"
.line	627	gettable      r5    r5   k90 ; k90 = "concat"
.line	627	newtable      r6     1     0
.line	627	getupval      r7    u1
.line	627	loadk         r8  k223 ; k223 = 225
.line	627	loadk         r9    k2 ; k2 = 36
.line	627	loadk        r10  k237 ; k237 = 178
.line	627	loadk        r11  k128 ; k128 = 220
.line	627	loadk        r12  k238 ; k238 = 127
.line	627	loadk        r13  k239 ; k239 = 92
.line	627	loadk        r14   k52 ; k52 = 111
.line	627	loadk        r15  k126 ; k126 = 146
.line	627	loadk        r16  k240 ; k240 = 243
.line	627	loadk        r17   k59 ; k59 = 135
.line	627	loadk        r18    k9 ; k9 = 232
.line	627	loadk        r19   k20 ; k20 = 108
.line	627	loadk        r20   k27 ; k27 = 75
.line	627	loadk        r21   k91 ; k91 = 252
.line	627	loadk        r22   k55 ; k55 = 193
.line	627	loadk        r23  k241 ; k241 = 42
.line	627	loadk        r24  k242 ; k242 = 28
.line	627	loadk        r25  k243 ; k243 = 31
.line	627	loadk        r26   k37 ; k37 = 202
.line	627	loadk        r27   k51 ; k51 = 236
.line	627	loadk        r28   k37 ; k37 = 202
.line	627	loadk        r29   k20 ; k20 = 108
.line	627	loadk        r30   k95 ; k95 = 25
.line	627	loadk        r31  k244 ; k244 = 179
.line	627	loadk        r32  k138 ; k138 = 245
.line	627	loadk        r33   k33 ; k33 = 192
.line	627	loadk        r34  k134 ; k134 = 212
.line	627	loadk        r35  k245 ; k245 = 119
.line	627	loadk        r36  k176 ; k176 = 67
.line	627	loadk        r37  k246 ; k246 = 163
.line	627	loadk        r38  k145 ; k145 = 147
.line	627	loadk        r39  k178 ; k178 = 57
.line	627	loadk        r40   k32 ; k32 = 4
.line	627	loadk        r41   k17 ; k17 = 1
.line	627	loadk        r42  k149 ; k149 = 208
.line	627	loadk        r43   k33 ; k33 = 192
.line	627	loadk        r44  k145 ; k145 = 147
.line	627	loadk        r45   k26 ; k26 = 125
.line	627	loadk        r46  k178 ; k178 = 57
.line	627	loadk        r47   k39 ; k39 = 182
.line	627	call          r7    41     2
.line	627	getupval      r8    u1
.line	627	loadk         r9  k100 ; k100 = 230
.line	627	loadk        r10  k110 ; k110 = 41
.line	627	loadk        r11   k96 ; k96 = 161
.line	627	call          r8     4     0
.line	627	setlist       r6     0     1
.line	627	call          r5     2     2
.line	627	call          r4     2     2
.line	627	test          r4     0
.line	627	jmp            0 l1071
.line	627	gettable      r5    r4  k247 ; k247 = "OnTakeOffItem"
.line	627	move          r6    r1
.line	627	move          r7    r2
.line	627	call          r5     3     1
.label	l1071
.line	627	return        r0     1
.line	627	move          r0    r0
.line	627	move          r0    r0
.line	627	move          r0    r0
.line	627	return        r0     1

.function	main/f23/f0

.source	null
.linedefined	729
.lastlinedefined	731
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"EventSystem"
.constant	k1	"postEvent"
.constant	k2	"EVENTTYPE_RANK"
.constant	k3	"EVENTID_WARZONE_UPDATE_AVATAR"

.line	729	gettabup      r2    u0    k0 ; k0 = "EventSystem"
.line	729	self          r2    r2    k1 ; k1 = "postEvent"
.line	729	gettabup      r4    u0    k2 ; k2 = "EVENTTYPE_RANK"
.line	729	gettabup      r5    u0    k3 ; k3 = "EVENTID_WARZONE_UPDA" (truncated)
.line	729	move          r6    r0
.line	729	call          r2     5     1
.line	729	return        r0     1
.line	729	move          r0    r0
.line	729	return        r0     1

.function	main/f24

.source	null
.linedefined	742
.lastlinedefined	746
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false

.constant	k0	"ChangeHallDepotItemNewStatus"
.constant	k1	"ModuleManager"
.constant	k2	"GetModule"
.constant	k3	"LobbyModuleConfig"
.constant	k4	"wardrobe_red_point"
.constant	k5	"ClearItemNew"
.constant	k6	"tonumber"

.line	742	getupval      r2    u0
.line	742	self          r2    r2    k0 ; k0 = "ChangeHallDepotItemN" (truncated)
.line	742	move          r4    r1
.line	742	call          r2     3     1
.line	742	gettabup      r2    u1    k1 ; k1 = "ModuleManager"
.line	742	gettable      r2    r2    k2 ; k2 = "GetModule"
.line	742	gettabup      r3    u1    k1 ; k1 = "ModuleManager"
.line	742	gettable      r3    r3    k3 ; k3 = "LobbyModuleConfig"
.line	742	gettable      r3    r3    k4 ; k4 = "wardrobe_red_point"
.line	742	call          r2     2     2
.line	742	self          r3    r2    k5 ; k5 = "ClearItemNew"
.line	742	gettabup      r5    u1    k6 ; k6 = "tonumber"
.line	742	move          r6    r1
.line	742	call          r5     2     0
.line	742	call          r3     0     1
.line	742	return        r0     1
.line	742	move          r0    r0
.line	742	return        r0     1

.function	main/f25

.source	null
.linedefined	748
.lastlinedefined	754
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true

.constant	k0	"pairs"
.constant	k1	"ChangeHallDepotItemNewStatus"
.constant	k2	"ModuleManager"
.constant	k3	"GetModule"
.constant	k4	"LobbyModuleConfig"
.constant	k5	"wardrobe_red_point"
.constant	k6	"ClearItemListNew"

.line	748	gettabup      r2    u0    k0 ; k0 = "pairs"
.line	748	move          r3    r1
.line	748	call          r2     2     4
.line	748	jmp            0    l9
.line	748	getupval      r7    u1
.line	748	self          r7    r7    k1 ; k1 = "ChangeHallDepotItemN" (truncated)
.line	748	move          r9    r6
.line	748	call          r7     3     1
.label	l9
.line	748	move          r0    r0
.line	748	move          r0    r0
.line	748	gettabup      r2    u0    k2 ; k2 = "ModuleManager"
.line	748	gettable      r2    r2    k3 ; k3 = "GetModule"
.line	748	gettabup      r3    u0    k2 ; k2 = "ModuleManager"
.line	748	gettable      r3    r3    k4 ; k4 = "LobbyModuleConfig"
.line	748	gettable      r3    r3    k5 ; k5 = "wardrobe_red_point"
.line	748	call          r2     2     2
.line	748	self          r3    r2    k6 ; k6 = "ClearItemListNew"
.line	748	move          r5    r1
.line	748	call          r3     3     1
.line	748	return        r0     1
.line	748	move          r0    r0
.line	748	move          r0    r0
.line	748	return        r0     1

.function	main/f26

.source	null
.linedefined	756
.lastlinedefined	763
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"ipairs"
.constant	k1	"DataMgr"
.constant	k2	"MotionSlotList"
.constant	k3	-1

.line	756	gettabup      r2    u0    k0 ; k0 = "ipairs"
.line	756	gettabup      r3    u0    k1 ; k1 = "DataMgr"
.line	756	gettable      r3    r3    k2 ; k2 = "MotionSlotList"
.line	756	call          r2     2     4
.line	756	jmp            0    l9
.line	756	eq             0    r6    r1
.line	756	jmp            0    l9
.line	756	return        r5     2
.label	l9
.line	756	move          r0    r0
.line	756	move          r0    r0
.line	756	loadk         r2    k3 ; k3 = -1
.line	756	return        r2     2
.line	756	return        r0     1
.line	756	move          r0    r0
.line	756	move          r0    r0
.line	756	move          r0    r0
.line	756	return        r0     1

.function	main/f27

.source	null
.linedefined	765
.lastlinedefined	777
.numparams	3
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"FindMotion"
.constant	k1	"DataMgr"
.constant	k2	"MotionSlotList"
.constant	k3	"require"
.constant	k4	224
.constant	k5	36
.constant	k6	186
.constant	k7	218
.constant	k8	122
.constant	k9	68
.constant	k10	40
.constant	k11	143
.constant	k12	226
.constant	k13	221
.constant	k14	236
.constant	k15	111
.constant	k16	76
.constant	k17	246
.constant	k18	193
.constant	k19	22
.constant	k20	1
.constant	k21	23
.constant	k22	215
.constant	k23	135
.constant	k24	26
.constant	k25	255
.constant	k26	192
.constant	k27	216
.constant	k28	249
.constant	k29	116
.constant	k30	124
.constant	k31	157
.constant	k32	51
.constant	k33	43
.constant	k34	9
.constant	k35	251
.constant	k36	152
.constant	k37	117
.constant	k38	20
.constant	k39	0
.constant	k40	"send_exchange_motion_req"
.constant	k41	"send_equip_motion_req"

.line	765	self          r3    r0    k0 ; k0 = "FindMotion"
.line	765	move          r5    r1
.line	765	call          r3     3     2
.line	765	gettabup      r4    u0    k1 ; k1 = "DataMgr"
.line	765	gettable      r4    r4    k2 ; k2 = "MotionSlotList"
.line	765	gettable      r4    r4    r2
.line	765	gettabup      r5    u0    k3 ; k3 = "require"
.line	765	getupval      r6    u1
.line	765	loadk         r7    k4 ; k4 = 224
.line	765	loadk         r8    k5 ; k5 = 36
.line	765	loadk         r9    k6 ; k6 = 186
.line	765	loadk        r10    k7 ; k7 = 218
.line	765	loadk        r11    k8 ; k8 = 122
.line	765	loadk        r12    k9 ; k9 = 68
.line	765	loadk        r13   k10 ; k10 = 40
.line	765	loadk        r14   k11 ; k11 = 143
.line	765	loadk        r15   k12 ; k12 = 226
.line	765	loadk        r16   k13 ; k13 = 221
.line	765	loadk        r17   k14 ; k14 = 236
.line	765	loadk        r18   k15 ; k15 = 111
.line	765	loadk        r19   k16 ; k16 = 76
.line	765	loadk        r20   k17 ; k17 = 246
.line	765	loadk        r21   k18 ; k18 = 193
.line	765	loadk        r22   k19 ; k19 = 22
.line	765	loadk        r23   k20 ; k20 = 1
.line	765	loadk        r24   k21 ; k21 = 23
.line	765	loadk        r25   k22 ; k22 = 215
.line	765	loadk        r26    k4 ; k4 = 224
.line	765	loadk        r27   k23 ; k23 = 135
.line	765	loadk        r28   k15 ; k15 = 111
.line	765	loadk        r29   k24 ; k24 = 26
.line	765	loadk        r30   k25 ; k25 = 255
.line	765	loadk        r31   k26 ; k26 = 192
.line	765	loadk        r32   k27 ; k27 = 216
.line	765	loadk        r33   k28 ; k28 = 249
.line	765	loadk        r34   k29 ; k29 = 116
.line	765	loadk        r35   k30 ; k30 = 124
.line	765	loadk        r36   k12 ; k12 = 226
.line	765	loadk        r37   k31 ; k31 = 157
.line	765	loadk        r38   k32 ; k32 = 51
.line	765	loadk        r39   k33 ; k33 = 43
.line	765	loadk        r40   k34 ; k34 = 9
.line	765	loadk        r41   k13 ; k13 = 221
.line	765	loadk        r42   k35 ; k35 = 251
.line	765	loadk        r43   k36 ; k36 = 152
.line	765	loadk        r44   k37 ; k37 = 117
.line	765	loadk        r45   k38 ; k38 = 20
.line	765	call          r6    40     2
.line	765	call          r5     2     2
.line	765	lt             0   k39    r3 ; k39 = 0
.line	765	jmp            0   l60
.line	765	eq             0    r4    r1
.line	765	jmp            0   l55
.line	765	return        r0     1
.label	l55
.line	765	gettable      r6    r5   k40 ; k40 = "send_exchange_motion" (truncated)
.line	765	move          r7    r3
.line	765	move          r8    r2
.line	765	call          r6     3     1
.line	765	jmp            0   l64
.label	l60
.line	765	gettable      r6    r5   k41 ; k41 = "send_equip_motion_re" (truncated)
.line	765	move          r7    r1
.line	765	move          r8    r2
.line	765	call          r6     3     1
.label	l64
.line	765	return        r0     1
.line	765	gettabup      r2    u0   k34 ; k34 = 9
.line	765	move          r0    r0
.line	765	return        r0     1

.function	main/f28

.source	null
.linedefined	779
.lastlinedefined	782
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	143
.constant	k11	226
.constant	k12	221
.constant	k13	236
.constant	k14	111
.constant	k15	76
.constant	k16	246
.constant	k17	193
.constant	k18	22
.constant	k19	1
.constant	k20	23
.constant	k21	215
.constant	k22	135
.constant	k23	26
.constant	k24	255
.constant	k25	192
.constant	k26	216
.constant	k27	249
.constant	k28	116
.constant	k29	92
.constant	k30	157
.constant	k31	51
.constant	k32	45
.constant	k33	13
.constant	k34	196
.constant	k35	149
.constant	k36	126
.constant	k37	2
.constant	k38	173
.constant	k39	230
.constant	k40	58
.constant	k41	"send_equip_motion_list_req"

.line	779	gettabup      r2    u0    k0 ; k0 = "require"
.line	779	gettabup      r3    u0    k1 ; k1 = "table"
.line	779	gettable      r3    r3    k2 ; k2 = "concat"
.line	779	newtable      r4     1     0
.line	779	getupval      r5    u1
.line	779	loadk         r6    k3 ; k3 = 224
.line	779	loadk         r7    k4 ; k4 = 36
.line	779	loadk         r8    k5 ; k5 = 186
.line	779	loadk         r9    k6 ; k6 = 218
.line	779	loadk        r10    k7 ; k7 = 122
.line	779	loadk        r11    k8 ; k8 = 68
.line	779	loadk        r12    k9 ; k9 = 40
.line	779	loadk        r13   k10 ; k10 = 143
.line	779	loadk        r14   k11 ; k11 = 226
.line	779	loadk        r15   k12 ; k12 = 221
.line	779	loadk        r16   k13 ; k13 = 236
.line	779	loadk        r17   k14 ; k14 = 111
.line	779	loadk        r18   k15 ; k15 = 76
.line	779	loadk        r19   k16 ; k16 = 246
.line	779	loadk        r20   k17 ; k17 = 193
.line	779	loadk        r21   k18 ; k18 = 22
.line	779	loadk        r22   k19 ; k19 = 1
.line	779	loadk        r23   k20 ; k20 = 23
.line	779	loadk        r24   k21 ; k21 = 215
.line	779	loadk        r25    k3 ; k3 = 224
.line	779	loadk        r26   k22 ; k22 = 135
.line	779	loadk        r27   k14 ; k14 = 111
.line	779	loadk        r28   k23 ; k23 = 26
.line	779	loadk        r29   k24 ; k24 = 255
.line	779	loadk        r30   k25 ; k25 = 192
.line	779	loadk        r31   k26 ; k26 = 216
.line	779	loadk        r32   k27 ; k27 = 249
.line	779	loadk        r33   k28 ; k28 = 116
.line	779	loadk        r34   k29 ; k29 = 92
.line	779	loadk        r35   k11 ; k11 = 226
.line	779	loadk        r36   k30 ; k30 = 157
.line	779	loadk        r37   k31 ; k31 = 51
.line	779	loadk        r38   k32 ; k32 = 45
.line	779	loadk        r39   k33 ; k33 = 13
.line	779	loadk        r40   k34 ; k34 = 196
.line	779	loadk        r41   k21 ; k21 = 215
.line	779	loadk        r42   k35 ; k35 = 149
.line	779	loadk        r43   k36 ; k36 = 126
.line	779	loadk        r44   k37 ; k37 = 2
.line	779	loadk        r45   k38 ; k38 = 173
.line	779	call          r5    41     2
.line	779	getupval      r6    u1
.line	779	loadk         r7   k39 ; k39 = 230
.line	779	loadk         r8   k40 ; k40 = 58
.line	779	call          r6     3     0
.line	779	setlist       r4     0     1
.line	779	call          r3     2     2
.line	779	call          r2     2     2
.line	779	gettable      r3    r2   k41 ; k41 = "send_equip_motion_li" (truncated)
.line	779	move          r4    r1
.line	779	call          r3     2     1
.line	779	return        r0     1
.line	779	move          r0    r0
.line	779	return        r0     1

.function	main/f29

.source	null
.linedefined	784
.lastlinedefined	787
.numparams	3
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	143
.constant	k9	226
.constant	k10	221
.constant	k11	236
.constant	k12	111
.constant	k13	76
.constant	k14	246
.constant	k15	193
.constant	k16	22
.constant	k17	1
.constant	k18	23
.constant	k19	215
.constant	k20	135
.constant	k21	26
.constant	k22	255
.constant	k23	192
.constant	k24	216
.constant	k25	249
.constant	k26	116
.constant	k27	124
.constant	k28	157
.constant	k29	51
.constant	k30	43
.constant	k31	9
.constant	k32	251
.constant	k33	152
.constant	k34	117
.constant	k35	20
.constant	k36	"send_unequip_motion_req"

.line	784	gettabup      r3    u0    k0 ; k0 = "require"
.line	784	getupval      r4    u1
.line	784	loadk         r5    k1 ; k1 = 224
.line	784	loadk         r6    k2 ; k2 = 36
.line	784	loadk         r7    k3 ; k3 = 186
.line	784	loadk         r8    k4 ; k4 = 218
.line	784	loadk         r9    k5 ; k5 = 122
.line	784	loadk        r10    k6 ; k6 = 68
.line	784	loadk        r11    k7 ; k7 = 40
.line	784	loadk        r12    k8 ; k8 = 143
.line	784	loadk        r13    k9 ; k9 = 226
.line	784	loadk        r14   k10 ; k10 = 221
.line	784	loadk        r15   k11 ; k11 = 236
.line	784	loadk        r16   k12 ; k12 = 111
.line	784	loadk        r17   k13 ; k13 = 76
.line	784	loadk        r18   k14 ; k14 = 246
.line	784	loadk        r19   k15 ; k15 = 193
.line	784	loadk        r20   k16 ; k16 = 22
.line	784	loadk        r21   k17 ; k17 = 1
.line	784	loadk        r22   k18 ; k18 = 23
.line	784	loadk        r23   k19 ; k19 = 215
.line	784	loadk        r24    k1 ; k1 = 224
.line	784	loadk        r25   k20 ; k20 = 135
.line	784	loadk        r26   k12 ; k12 = 111
.line	784	loadk        r27   k21 ; k21 = 26
.line	784	loadk        r28   k22 ; k22 = 255
.line	784	loadk        r29   k23 ; k23 = 192
.line	784	loadk        r30   k24 ; k24 = 216
.line	784	loadk        r31   k25 ; k25 = 249
.line	784	loadk        r32   k26 ; k26 = 116
.line	784	loadk        r33   k27 ; k27 = 124
.line	784	loadk        r34    k9 ; k9 = 226
.line	784	loadk        r35   k28 ; k28 = 157
.line	784	loadk        r36   k29 ; k29 = 51
.line	784	loadk        r37   k30 ; k30 = 43
.line	784	loadk        r38   k31 ; k31 = 9
.line	784	loadk        r39   k10 ; k10 = 221
.line	784	loadk        r40   k32 ; k32 = 251
.line	784	loadk        r41   k33 ; k33 = 152
.line	784	loadk        r42   k34 ; k34 = 117
.line	784	loadk        r43   k35 ; k35 = 20
.line	784	call          r4    40     2
.line	784	call          r3     2     2
.line	784	gettable      r4    r3   k36 ; k36 = "send_unequip_motion_" (truncated)
.line	784	move          r5    r1
.line	784	move          r6    r2
.line	784	call          r4     3     1
.line	784	return        r0     1
.line	784	move          r0    r0
.line	784	move          r0    r0
.line	784	return        r0     1

.function	main/f30

.source	null
.linedefined	789
.lastlinedefined	824
.numparams	3
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	207
.constant	k22	134
.constant	k23	98
.constant	k24	15
.constant	k25	255
.constant	k26	251
.constant	k27	214
.constant	k28	236
.constant	k29	121
.constant	k30	77
.constant	k31	210
.constant	k32	147
.constant	k33	57
.constant	k34	1
.constant	k35	10
.constant	k36	202
.constant	k37	192
.constant	k38	145
.constant	k39	104
.constant	k40	22
.constant	k41	179
.constant	k42	230
.constant	k43	59
.constant	k44	160
.constant	k45	123
.constant	k46	94
.constant	k47	"log"
.constant	k48	"bWriteLog"
.constant	k49	212
.constant	k50	41
.constant	k51	161
.constant	k52	219
.constant	k53	102
.constant	k54	95
.constant	k55	100
.constant	k56	132
.constant	k57	203
.constant	k58	198
.constant	k59	252
.constant	k60	105
.constant	k61	93
.constant	k62	167
.constant	k63	191
.constant	k64	42
.constant	k65	18
.constant	k66	238
.constant	k67	144
.constant	k68	25
.constant	k69	183
.constant	k70	228
.constant	k71	71
.constant	k72	226
.constant	k73	4
.constant	k74	6
.constant	k75	27
.constant	k76	"tostring"
.constant	k77	"CDataTable"
.constant	k78	"GetTableData"
.constant	k79	60
.constant	k80	182
.constant	k81	"GlobalData"
.constant	k82	"IsJapanOrKorea"
.constant	k83	"JKBPID"
.constant	k84	0
.constant	k85	"BPID"
.constant	k86	"ModuleManager"
.constant	k87	"GetModule"
.constant	k88	"LobbyModuleConfig"
.constant	k89	"logic_profile"
.constant	k90	"AvatarData"
.constant	k91	"GetGameGender"
.constant	k92	"GetTauntRandSoundID"
.constant	k93	"GetExtraInfo"
.constant	k94	141
.constant	k95	232
.constant	k96	206
.constant	k97	99
.constant	k98	153
.constant	k99	39
.constant	k100	7
.constant	k101	209
.constant	k102	168
.constant	k103	111
.constant	k104	20
.constant	k105	248
.constant	k106	253
.constant	k107	113
.constant	k108	90
.constant	k109	2
.constant	k110	"PlayEmoteAction"
.constant	k111	"DataMgr"
.constant	k112	"roleData"
.constant	k113	"uid"
.constant	k114	"extraInfo"
.constant	k115	215
.constant	k116	234
.constant	k117	133
.constant	k118	109
.constant	k119	3
.constant	k120	185
.constant	k121	213
.constant	k122	119
.constant	k123	34
.constant	k124	9
.constant	k125	222
.constant	k126	129
.constant	k127	96
.constant	k128	"GetTeamNum"
.constant	k129	"team_player_action"
.constant	k130	"IsTeamLeader"
.constant	k131	"CheckEmoteCanFollow"
.constant	k132	"GetEmoteFollowersUID"
.constant	k133	"pairs"
.constant	k134	"GetFollowPlayEmoteID"
.constant	k135	"GetRoleSexByUid"

.line	789	gettabup      r3    u0    k0 ; k0 = "require"
.line	789	gettabup      r4    u0    k1 ; k1 = "table"
.line	789	gettable      r4    r4    k2 ; k2 = "concat"
.line	789	newtable      r5     1     0
.line	789	getupval      r6    u1
.line	789	loadk         r7    k3 ; k3 = 224
.line	789	loadk         r8    k4 ; k4 = 36
.line	789	loadk         r9    k5 ; k5 = 186
.line	789	loadk        r10    k6 ; k6 = 218
.line	789	loadk        r11    k7 ; k7 = 122
.line	789	loadk        r12    k8 ; k8 = 68
.line	789	loadk        r13    k9 ; k9 = 40
.line	789	loadk        r14   k10 ; k10 = 146
.line	789	loadk        r15   k11 ; k11 = 235
.line	789	loadk        r16   k12 ; k12 = 220
.line	789	loadk        r17   k13 ; k13 = 250
.line	789	loadk        r18   k14 ; k14 = 46
.line	789	loadk        r19   k15 ; k15 = 82
.line	789	loadk        r20   k16 ; k16 = 242
.line	789	loadk        r21   k17 ; k17 = 136
.line	789	loadk        r22   k18 ; k18 = 47
.line	789	loadk        r23   k19 ; k19 = 16
.line	789	loadk        r24   k20 ; k20 = 86
.line	789	loadk        r25   k21 ; k21 = 207
.line	789	loadk        r26    k3 ; k3 = 224
.line	789	loadk        r27   k22 ; k22 = 134
.line	789	loadk        r28   k23 ; k23 = 98
.line	789	loadk        r29   k24 ; k24 = 15
.line	789	loadk        r30   k25 ; k25 = 255
.line	789	loadk        r31   k26 ; k26 = 251
.line	789	loadk        r32   k27 ; k27 = 214
.line	789	loadk        r33   k28 ; k28 = 236
.line	789	loadk        r34   k29 ; k29 = 121
.line	789	loadk        r35   k30 ; k30 = 77
.line	789	loadk        r36   k31 ; k31 = 210
.line	789	loadk        r37   k32 ; k32 = 147
.line	789	loadk        r38   k33 ; k33 = 57
.line	789	loadk        r39   k34 ; k34 = 1
.line	789	loadk        r40   k35 ; k35 = 10
.line	789	loadk        r41   k36 ; k36 = 202
.line	789	loadk        r42   k37 ; k37 = 192
.line	789	loadk        r43   k38 ; k38 = 145
.line	789	loadk        r44   k39 ; k39 = 104
.line	789	loadk        r45   k40 ; k40 = 22
.line	789	loadk        r46   k41 ; k41 = 179
.line	789	call          r6    41     2
.line	789	getupval      r7    u1
.line	789	loadk         r8   k42 ; k42 = 230
.line	789	loadk         r9   k43 ; k43 = 59
.line	789	loadk        r10   k44 ; k44 = 160
.line	789	loadk        r11   k27 ; k27 = 214
.line	789	loadk        r12   k45 ; k45 = 123
.line	789	loadk        r13   k46 ; k46 = 94
.line	789	call          r7     7     0
.line	789	setlist       r5     0     1
.line	789	call          r4     2     2
.line	789	call          r3     2     2
.line	789	gettabup      r4    u0   k47 ; k47 = "log"
.line	789	gettabup      r5    u0   k48 ; k48 = "bWriteLog"
.line	789	test          r5     0
.line	789	jmp            0  l105
.line	789	getupval      r5    u1
.line	789	loadk         r6   k49 ; k49 = 212
.line	789	loadk         r7   k50 ; k50 = 41
.line	789	loadk         r8   k51 ; k51 = 161
.line	789	loadk         r9   k52 ; k52 = 219
.line	789	loadk        r10   k53 ; k53 = 102
.line	789	loadk        r11   k54 ; k54 = 95
.line	789	loadk        r12   k55 ; k55 = 100
.line	789	loadk        r13   k56 ; k56 = 132
.line	789	loadk        r14   k57 ; k57 = 203
.line	789	loadk        r15   k58 ; k58 = 198
.line	789	loadk        r16   k59 ; k59 = 252
.line	789	loadk        r17   k60 ; k60 = 105
.line	789	loadk        r18   k61 ; k61 = 93
.line	789	loadk        r19   k62 ; k62 = 167
.line	789	loadk        r20   k63 ; k63 = 191
.line	789	loadk        r21   k64 ; k64 = 42
.line	789	loadk        r22   k65 ; k65 = 18
.line	789	loadk        r23   k34 ; k34 = 1
.line	789	loadk        r24   k66 ; k66 = 238
.line	789	loadk        r25    k3 ; k3 = 224
.line	789	loadk        r26   k67 ; k67 = 144
.line	789	loadk        r27   k60 ; k60 = 105
.line	789	loadk        r28   k68 ; k68 = 25
.line	789	loadk        r29   k63 ; k63 = 191
.line	789	loadk        r30   k69 ; k69 = 183
.line	789	loadk        r31   k49 ; k49 = 212
.line	789	loadk        r32   k70 ; k70 = 228
.line	789	loadk        r33   k55 ; k55 = 100
.line	789	loadk        r34   k71 ; k71 = 71
.line	789	loadk        r35   k72 ; k72 = 226
.line	789	loadk        r36   k38 ; k38 = 145
.line	789	loadk        r37   k73 ; k73 = 4
.line	789	loadk        r38   k74 ; k74 = 6
.line	789	loadk        r39   k75 ; k75 = 27
.line	789	loadk        r40   k13 ; k13 = 250
.line	789	loadk        r41   k52 ; k52 = 219
.line	789	loadk        r42   k49 ; k49 = 212
.line	789	call          r5    38     2
.line	789	gettabup      r6    u0   k76 ; k76 = "tostring"
.line	789	move          r7    r1
.line	789	call          r6     2     2
.line	789	concat        r5    r5    r6
.label	l105
.line	789	call          r4     2     1
.line	789	gettabup      r4    u0   k77 ; k77 = "CDataTable"
.line	789	gettable      r4    r4   k78 ; k78 = "GetTableData"
.line	789	getupval      r5    u1
.line	789	loadk         r6   k36 ; k36 = 202
.line	789	loadk         r7   k79 ; k79 = 60
.line	789	loadk         r8   k80 ; k80 = 182
.line	789	loadk         r9   k31 ; k31 = 210
.line	789	call          r5     5     2
.line	789	move          r6    r1
.line	789	call          r4     3     2
.line	789	test          r4     0
.line	789	jmp            0  l129
.line	789	gettabup      r5    u0   k81 ; k81 = "GlobalData"
.line	789	gettable      r5    r5   k82 ; k82 = "IsJapanOrKorea"
.line	789	call          r5     1     2
.line	789	test          r5     0
.line	789	jmp            0  l128
.line	789	gettable      r5    r4   k83 ; k83 = "JKBPID"
.line	789	lt             0   k84    r5 ; k84 = 0
.line	789	jmp            0  l128
.line	789	gettable      r1    r4   k83 ; k83 = "JKBPID"
.line	789	jmp            0  l129
.label	l128
.line	789	gettable      r1    r4   k85 ; k85 = "BPID"
.label	l129
.line	789	gettabup      r5    u0   k86 ; k86 = "ModuleManager"
.line	789	gettable      r5    r5   k87 ; k87 = "GetModule"
.line	789	gettabup      r6    u0   k86 ; k86 = "ModuleManager"
.line	789	gettable      r6    r6   k88 ; k88 = "LobbyModuleConfig"
.line	789	gettable      r6    r6   k89 ; k89 = "logic_profile"
.line	789	call          r5     2     2
.line	789	gettabup      r6    u0   k90 ; k90 = "AvatarData"
.line	789	gettable      r6    r6   k91 ; k91 = "GetGameGender"
.line	789	call          r6     1     2
.line	789	gettable      r7    r3   k92 ; k92 = "GetTauntRandSoundID"
.line	789	move          r8    r1
.line	789	move          r9    r6
.line	789	call          r7     3     2
.line	789	gettable      r8    r3   k93 ; k93 = "GetExtraInfo"
.line	789	move          r9    r1
.line	789	call          r8     2     2
.line	789	gettabup      r9    u0    k0 ; k0 = "require"
.line	789	getupval     r10    u1
.line	789	loadk        r11    k3 ; k3 = 224
.line	789	loadk        r12    k4 ; k4 = 36
.line	789	loadk        r13    k5 ; k5 = 186
.line	789	loadk        r14    k6 ; k6 = 218
.line	789	loadk        r15    k7 ; k7 = 122
.line	789	loadk        r16    k8 ; k8 = 68
.line	789	loadk        r17    k9 ; k9 = 40
.line	789	loadk        r18   k94 ; k94 = 141
.line	789	loadk        r19   k95 ; k95 = 232
.line	789	loadk        r20   k96 ; k96 = 206
.line	789	loadk        r21   k16 ; k16 = 242
.line	789	loadk        r22   k97 ; k97 = 99
.line	789	loadk        r23   k19 ; k19 = 16
.line	789	loadk        r24   k59 ; k59 = 252
.line	789	loadk        r25   k98 ; k98 = 153
.line	789	loadk        r26   k99 ; k99 = 39
.line	789	loadk        r27  k100 ; k100 = 7
.line	789	loadk        r28   k68 ; k68 = 25
.line	789	loadk        r29  k101 ; k101 = 209
.line	789	loadk        r30   k51 ; k51 = 161
.line	789	loadk        r31  k102 ; k102 = 168
.line	789	loadk        r32  k103 ; k103 = 111
.line	789	loadk        r33  k104 ; k104 = 20
.line	789	loadk        r34   k41 ; k41 = 179
.line	789	loadk        r35   k66 ; k66 = 238
.line	789	loadk        r36  k105 ; k105 = 248
.line	789	loadk        r37  k106 ; k106 = 253
.line	789	loadk        r38  k107 ; k107 = 113
.line	789	loadk        r39  k108 ; k108 = 90
.line	789	loadk        r40   k28 ; k28 = 236
.line	789	loadk        r41   k94 ; k94 = 141
.line	789	loadk        r42   k75 ; k75 = 27
.line	789	loadk        r43  k109 ; k109 = 2
.line	789	loadk        r44   k74 ; k74 = 6
.line	789	loadk        r45   k31 ; k31 = 210
.line	789	loadk        r46  k105 ; k105 = 248
.line	789	loadk        r47   k38 ; k38 = 145
.line	789	loadk        r48   k23 ; k23 = 98
.line	789	call         r10    39     2
.line	789	call          r9     2     2
.line	789	gettable     r10    r9  k110 ; k110 = "PlayEmoteAction"
.line	789	gettabup     r11    u0  k111 ; k111 = "DataMgr"
.line	789	gettable     r11   r11  k112 ; k112 = "roleData"
.line	789	gettable     r11   r11  k113 ; k113 = "uid"
.line	789	move         r12    r1
.line	789	move         r13    r6
.line	789	move         r14    r7
.line	789	loadnil      r15     0
.line	789	move         r16    r8
.line	789	call         r10     7     2
.line	789	test          r2     0
.line	789	jmp            0  l200
.line	789	return        r0     1
.label	l200
.line	789	loadnil      r11     0
.line	789	test          r8     0
.line	789	jmp            0  l206
.line	789	newtable     r12     0     1
.line	789	settable     r12  k114    r8 ; k114 = "extraInfo"
.line	789	move         r11   r12
.label	l206
.line	789	gettabup     r12    u0    k0 ; k0 = "require"
.line	789	getupval     r13    u1
.line	789	loadk        r14    k3 ; k3 = 224
.line	789	loadk        r15    k4 ; k4 = 36
.line	789	loadk        r16    k5 ; k5 = 186
.line	789	loadk        r17    k6 ; k6 = 218
.line	789	loadk        r18    k7 ; k7 = 122
.line	789	loadk        r19    k8 ; k8 = 68
.line	789	loadk        r20    k9 ; k9 = 40
.line	789	loadk        r21   k10 ; k10 = 146
.line	789	loadk        r22   k11 ; k11 = 235
.line	789	loadk        r23   k12 ; k12 = 220
.line	789	loadk        r24   k13 ; k13 = 250
.line	789	loadk        r25   k14 ; k14 = 46
.line	789	loadk        r26   k15 ; k15 = 82
.line	789	loadk        r27   k16 ; k16 = 242
.line	789	loadk        r28   k17 ; k17 = 136
.line	789	loadk        r29   k18 ; k18 = 47
.line	789	loadk        r30   k19 ; k19 = 16
.line	789	loadk        r31   k20 ; k20 = 86
.line	789	loadk        r32  k115 ; k115 = 215
.line	789	loadk        r33  k116 ; k116 = 234
.line	789	loadk        r34  k117 ; k117 = 133
.line	789	loadk        r35  k118 ; k118 = 109
.line	789	loadk        r36  k119 ; k119 = 3
.line	789	loadk        r37   k51 ; k51 = 161
.line	789	loadk        r38  k120 ; k120 = 185
.line	789	loadk        r39  k121 ; k121 = 213
.line	789	loadk        r40   k70 ; k70 = 228
.line	789	loadk        r41  k122 ; k122 = 119
.line	789	loadk        r42   k71 ; k71 = 71
.line	789	loadk        r43   k66 ; k66 = 238
.line	789	loadk        r44   k44 ; k44 = 160
.line	789	loadk        r45  k123 ; k123 = 34
.line	789	loadk        r46   k74 ; k74 = 6
.line	789	loadk        r47  k124 ; k124 = 9
.line	789	loadk        r48  k125 ; k125 = 222
.line	789	loadk        r49   k37 ; k37 = 192
.line	789	loadk        r50  k126 ; k126 = 129
.line	789	loadk        r51  k127 ; k127 = 96
.line	789	call         r13    39     2
.line	789	call         r12     2     2
.line	789	gettable     r13   r12  k128 ; k128 = "GetTeamNum"
.line	789	call         r13     1     2
.line	789	lt             0   k34   r13 ; k34 = 1
.line	789	jmp            0  l290
.line	789	test         r10     0
.line	789	jmp            0  l290
.line	789	gettable     r13   r12  k129 ; k129 = "team_player_action"
.line	789	move         r14    r1
.line	789	move         r15    r7
.line	789	move         r16   r11
.line	789	call         r13     4     1
.line	789	gettable     r13   r12  k130 ; k130 = "IsTeamLeader"
.line	789	call         r13     1     2
.line	789	test         r13     0
.line	789	jmp            0  l290
.line	789	gettable     r13   r12  k131 ; k131 = "CheckEmoteCanFollow"
.line	789	move         r14    r1
.line	789	call         r13     2     2
.line	789	test         r13     0
.line	789	jmp            0  l290
.line	789	gettable     r13   r12  k132 ; k132 = "GetEmoteFollowersUID"
.line	789	call         r13     1     2
.line	789	gettabup     r14    u0  k133 ; k133 = "pairs"
.line	789	move         r15   r13
.line	789	call         r14     2     4
.line	789	jmp            0  l288
.line	789	gettable     r19   r12  k134 ; k134 = "GetFollowPlayEmoteID"
.line	789	move         r20   r18
.line	789	move         r21    r1
.line	789	call         r19     3     2
.line	789	gettable     r20    r9  k110 ; k110 = "PlayEmoteAction"
.line	789	move         r21   r18
.line	789	move         r22   r19
.line	789	self         r23    r5  k135 ; k135 = "GetRoleSexByUid"
.line	789	move         r25   r18
.line	789	loadbool     r26     1     0
.line	789	call         r23     4     2
.line	789	loadnil      r24     1
.line	789	move         r26    r8
.line	789	call         r20     7     1
.label	l288
.line	789	move          r0    r0
.line	789	move          r0    r0
.label	l290
.line	789	return        r0     1
.line	789	move          r0    r0
.line	789	move          r0    r0
.line	789	return        r0     1

.function	main/f31

.source	null
.linedefined	826
.lastlinedefined	829
.numparams	1
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	252
.constant	k15	153
.constant	k16	39
.constant	k17	7
.constant	k18	25
.constant	k19	209
.constant	k20	161
.constant	k21	168
.constant	k22	111
.constant	k23	20
.constant	k24	179
.constant	k25	238
.constant	k26	248
.constant	k27	253
.constant	k28	113
.constant	k29	90
.constant	k30	236
.constant	k31	27
.constant	k32	2
.constant	k33	6
.constant	k34	210
.constant	k35	145
.constant	k36	98
.constant	k37	"StopEmoteAction"
.constant	k38	"DataMgr"
.constant	k39	"roleData"
.constant	k40	"uid"

.line	826	gettabup      r1    u0    k0 ; k0 = "require"
.line	826	getupval      r2    u1
.line	826	loadk         r3    k1 ; k1 = 224
.line	826	loadk         r4    k2 ; k2 = 36
.line	826	loadk         r5    k3 ; k3 = 186
.line	826	loadk         r6    k4 ; k4 = 218
.line	826	loadk         r7    k5 ; k5 = 122
.line	826	loadk         r8    k6 ; k6 = 68
.line	826	loadk         r9    k7 ; k7 = 40
.line	826	loadk        r10    k8 ; k8 = 141
.line	826	loadk        r11    k9 ; k9 = 232
.line	826	loadk        r12   k10 ; k10 = 206
.line	826	loadk        r13   k11 ; k11 = 242
.line	826	loadk        r14   k12 ; k12 = 99
.line	826	loadk        r15   k13 ; k13 = 16
.line	826	loadk        r16   k14 ; k14 = 252
.line	826	loadk        r17   k15 ; k15 = 153
.line	826	loadk        r18   k16 ; k16 = 39
.line	826	loadk        r19   k17 ; k17 = 7
.line	826	loadk        r20   k18 ; k18 = 25
.line	826	loadk        r21   k19 ; k19 = 209
.line	826	loadk        r22   k20 ; k20 = 161
.line	826	loadk        r23   k21 ; k21 = 168
.line	826	loadk        r24   k22 ; k22 = 111
.line	826	loadk        r25   k23 ; k23 = 20
.line	826	loadk        r26   k24 ; k24 = 179
.line	826	loadk        r27   k25 ; k25 = 238
.line	826	loadk        r28   k26 ; k26 = 248
.line	826	loadk        r29   k27 ; k27 = 253
.line	826	loadk        r30   k28 ; k28 = 113
.line	826	loadk        r31   k29 ; k29 = 90
.line	826	loadk        r32   k30 ; k30 = 236
.line	826	loadk        r33    k8 ; k8 = 141
.line	826	loadk        r34   k31 ; k31 = 27
.line	826	loadk        r35   k32 ; k32 = 2
.line	826	loadk        r36   k33 ; k33 = 6
.line	826	loadk        r37   k34 ; k34 = 210
.line	826	loadk        r38   k26 ; k26 = 248
.line	826	loadk        r39   k35 ; k35 = 145
.line	826	loadk        r40   k36 ; k36 = 98
.line	826	call          r2    39     2
.line	826	call          r1     2     2
.line	826	gettable      r2    r1   k37 ; k37 = "StopEmoteAction"
.line	826	gettabup      r3    u0   k38 ; k38 = "DataMgr"
.line	826	gettable      r3    r3   k39 ; k39 = "roleData"
.line	826	gettable      r3    r3   k40 ; k40 = "uid"
.line	826	call          r2     2     1
.line	826	return        r0     1
.line	826	move          r0    r0
.line	826	return        r0     1

.function	main/f32

.source	null
.linedefined	831
.lastlinedefined	833
.numparams	3
.is_vararg	0
.maxstacksize	4

.constant	k0	0
.constant	k1	nil

.line	831	eq             1    r2    k0 ; k0 = 0
.line	831	jmp            0    l8
.line	831	eq             1    r2    k1 ; k1 = nil
.line	831	jmp            0    l8
.line	831	lt             1    r1    r2
.line	831	jmp            0    l8
.line	831	loadbool      r3     0     1
.label	l8
.line	831	loadbool      r3     1     0
.line	831	return        r3     2
.line	831	return        r0     1
.line	831	move          r0    r0
.line	831	move          r0    r0
.line	831	move          r0    r0
.line	831	move          r0    r0
.line	831	return        r0     1

.function	main/f33

.source	null
.linedefined	835
.lastlinedefined	843
.numparams	2
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	1	true
.upvalue	"U1"	0	false

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	130
.constant	k9	232
.constant	k10	196
.constant	k11	246
.constant	k12	111
.constant	k13	80
.constant	k14	179
.constant	k15	155
.constant	k16	47
.constant	k17	30
.constant	k18	29
.constant	k19	252
.constant	k20	250
.constant	k21	144
.constant	k22	105
.constant	k23	26
.constant	k24	"GetServerTimeInSec"
.constant	k25	0
.constant	k26	1
.constant	k27	"GetTimeStr"

.line	835	getupval      r2    u0
.line	835	call          r2     1     2
.line	835	gettabup      r3    u1    k0 ; k0 = "require"
.line	835	getupval      r4    u0
.line	835	loadk         r5    k1 ; k1 = 224
.line	835	loadk         r6    k2 ; k2 = 36
.line	835	loadk         r7    k3 ; k3 = 186
.line	835	loadk         r8    k4 ; k4 = 218
.line	835	loadk         r9    k5 ; k5 = 122
.line	835	loadk        r10    k6 ; k6 = 68
.line	835	loadk        r11    k7 ; k7 = 40
.line	835	loadk        r12    k8 ; k8 = 130
.line	835	loadk        r13    k9 ; k9 = 232
.line	835	loadk        r14   k10 ; k10 = 196
.line	835	loadk        r15   k11 ; k11 = 246
.line	835	loadk        r16   k12 ; k12 = 111
.line	835	loadk        r17   k13 ; k13 = 80
.line	835	loadk        r18   k14 ; k14 = 179
.line	835	loadk        r19   k15 ; k15 = 155
.line	835	loadk        r20   k16 ; k16 = 47
.line	835	loadk        r21   k17 ; k17 = 30
.line	835	loadk        r22   k18 ; k18 = 29
.line	835	loadk        r23   k19 ; k19 = 252
.line	835	loadk        r24   k20 ; k20 = 250
.line	835	loadk        r25   k21 ; k21 = 144
.line	835	loadk        r26   k22 ; k22 = 105
.line	835	loadk        r27   k23 ; k23 = 26
.line	835	call          r4    24     2
.line	835	call          r3     2     2
.line	835	gettable      r4    r3   k24 ; k24 = "GetServerTimeInSec"
.line	835	call          r4     1     2
.line	835	sub           r4    r1    r4
.line	835	le             0    r4   k25 ; k25 = 0
.line	835	jmp            0   l36
.line	835	loadk         r4   k26 ; k26 = 1
.label	l36
.line	835	self          r5    r0   k27 ; k27 = "GetTimeStr"
.line	835	move          r7    r4
.line	835	tailcall      r5     3
.line	835	return        r5     0
.line	835	return        r0     1
.line	835	move          r0    r0
.line	835	move          r0    r0
.line	835	move          r0    r0
.line	835	move          r0    r0
.line	835	return        r0     1

.function	main/f34

.source	null
.linedefined	845
.lastlinedefined	860
.numparams	2
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"math"
.constant	k1	"floor"
.constant	k2	"SecToHour"
.constant	k3	"HourToDay"
.constant	k4	1
.constant	k5	24
.constant	k6	0
.constant	k7	"LocUtil"
.constant	k8	"LocalizeResFormat"
.constant	k9	301152
.constant	k10	9910107
.constant	k11	"tostring"

.line	845	gettabup      r2    u0    k0 ; k0 = "math"
.line	845	gettable      r2    r2    k1 ; k1 = "floor"
.line	845	gettabup      r3    u0    k2 ; k2 = "SecToHour"
.line	845	mul           r3    r1    r3
.line	845	call          r2     2     2
.line	845	gettabup      r3    u0    k0 ; k0 = "math"
.line	845	gettable      r3    r3    k1 ; k1 = "floor"
.line	845	gettabup      r4    u0    k3 ; k3 = "HourToDay"
.line	845	mul           r4    r2    r4
.line	845	call          r3     2     2
.line	845	lt             0    k4    r2 ; k4 = 1
.line	845	jmp            0   l15
.line	845	mod           r2    r2    k5 ; k5 = 24
.line	845	jmp            0   l16
.label	l15
.line	845	loadk         r2    k4 ; k4 = 1
.label	l16
.line	845	getupval      r4    u1
.line	845	call          r4     1     2
.line	845	eq             1    r3    k6 ; k6 = 0
.line	845	jmp            0   l28
.line	845	gettabup      r5    u0    k7 ; k7 = "LocUtil"
.line	845	gettable      r5    r5    k8 ; k8 = "LocalizeResFormat"
.line	845	loadk         r6    k9 ; k9 = 301152
.line	845	move          r7    r3
.line	845	move          r8    r2
.line	845	call          r5     4     2
.line	845	move          r4    r5
.line	845	jmp            0   l38
.label	l28
.line	845	eq             1    r2    k6 ; k6 = 0
.line	845	jmp            0   l38
.line	845	gettabup      r5    u0    k7 ; k7 = "LocUtil"
.line	845	gettable      r5    r5    k8 ; k8 = "LocalizeResFormat"
.line	845	loadk         r6   k10 ; k10 = 9910107
.line	845	gettabup      r7    u0   k11 ; k11 = "tostring"
.line	845	move          r8    r2
.line	845	call          r7     2     0
.line	845	call          r5     0     2
.line	845	move          r4    r5
.label	l38
.line	845	return        r4     2
.line	845	return        r0     1
.line	845	move          r0    r0
.line	845	move          r0    r0
.line	845	move          r0    r0
.line	845	move          r0    r0
.line	845	return        r0     1

.function	main/f35

.source	null
.linedefined	862
.lastlinedefined	865
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"UpdateLobbyHotDot"
.constant	k1	"LobbySystem"
.constant	k2	"LobbyRedPointUpdate"
.constant	k3	"BP_ENUM_LOBBY_MENU_ARMORY"

.line	862	self          r2    r0    k0 ; k0 = "UpdateLobbyHotDot"
.line	862	call          r2     2     1
.line	862	gettabup      r2    u0    k1 ; k1 = "LobbySystem"
.line	862	gettable      r2    r2    k2 ; k2 = "LobbyRedPointUpdate"
.line	862	gettabup      r3    u0    k3 ; k3 = "BP_ENUM_LOBBY_MENU_A" (truncated)
.line	862	move          r4    r1
.line	862	call          r2     3     1
.line	862	return        r0     1
.line	862	move          r0    r0
.line	862	move          r0    r0
.line	862	move          r0    r0
.line	862	move          r0    r0
.line	862	return        r0     1

.function	main/f36

.source	null
.linedefined	867
.lastlinedefined	871
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	146
.constant	k9	235
.constant	k10	220
.constant	k11	250
.constant	k12	46
.constant	k13	82
.constant	k14	242
.constant	k15	136
.constant	k16	47
.constant	k17	16
.constant	k18	86
.constant	k19	215
.constant	k20	234
.constant	k21	133
.constant	k22	109
.constant	k23	3
.constant	k24	161
.constant	k25	185
.constant	k26	213
.constant	k27	228
.constant	k28	119
.constant	k29	71
.constant	k30	238
.constant	k31	160
.constant	k32	44
.constant	k33	12
.constant	k34	6
.constant	k35	214
.constant	k36	"nChooseZoneID"

.line	867	gettabup      r1    u0    k0 ; k0 = "require"
.line	867	getupval      r2    u1
.line	867	loadk         r3    k1 ; k1 = 224
.line	867	loadk         r4    k2 ; k2 = 36
.line	867	loadk         r5    k3 ; k3 = 186
.line	867	loadk         r6    k4 ; k4 = 218
.line	867	loadk         r7    k5 ; k5 = 122
.line	867	loadk         r8    k6 ; k6 = 68
.line	867	loadk         r9    k7 ; k7 = 40
.line	867	loadk        r10    k8 ; k8 = 146
.line	867	loadk        r11    k9 ; k9 = 235
.line	867	loadk        r12   k10 ; k10 = 220
.line	867	loadk        r13   k11 ; k11 = 250
.line	867	loadk        r14   k12 ; k12 = 46
.line	867	loadk        r15   k13 ; k13 = 82
.line	867	loadk        r16   k14 ; k14 = 242
.line	867	loadk        r17   k15 ; k15 = 136
.line	867	loadk        r18   k16 ; k16 = 47
.line	867	loadk        r19   k17 ; k17 = 16
.line	867	loadk        r20   k18 ; k18 = 86
.line	867	loadk        r21   k19 ; k19 = 215
.line	867	loadk        r22   k20 ; k20 = 234
.line	867	loadk        r23   k21 ; k21 = 133
.line	867	loadk        r24   k22 ; k22 = 109
.line	867	loadk        r25   k23 ; k23 = 3
.line	867	loadk        r26   k24 ; k24 = 161
.line	867	loadk        r27   k25 ; k25 = 185
.line	867	loadk        r28   k26 ; k26 = 213
.line	867	loadk        r29   k27 ; k27 = 228
.line	867	loadk        r30   k28 ; k28 = 119
.line	867	loadk        r31   k29 ; k29 = 71
.line	867	loadk        r32   k30 ; k30 = 238
.line	867	loadk        r33   k31 ; k31 = 160
.line	867	loadk        r34   k32 ; k32 = 44
.line	867	loadk        r35   k33 ; k33 = 12
.line	867	loadk        r36   k34 ; k34 = 6
.line	867	loadk        r37   k35 ; k35 = 214
.line	867	call          r2    36     2
.line	867	call          r1     2     2
.line	867	gettable      r2    r1   k36 ; k36 = "nChooseZoneID"
.line	867	eq             1    r2   k34 ; k34 = 6
.line	867	jmp            0   l44
.line	867	loadbool      r3     0     1
.label	l44
.line	867	loadbool      r3     1     0
.line	867	return        r3     2
.line	867	return        r0     1
.line	867	move          r0    r0
.line	867	move          r0    r0
.line	867	gettabup      r3    u1   k32 ; k32 = 44
.line	867	move          r0    r0
.line	867	return        r0     1

.function	main/f37

.source	null
.linedefined	873
.lastlinedefined	893
.numparams	2
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	0
.constant	k1	"characterUseCache"
.constant	k2	"CDataTable"
.constant	k3	"GetTableData"
.constant	k4	224
.constant	k5	32
.constant	k6	178
.constant	k7	205
.constant	k8	117
.constant	k9	83
.constant	k10	114
.constant	k11	132
.constant	k12	245
.constant	k13	246
.constant	k14	235
.constant	k15	97
.constant	k16	76
.constant	k17	252
.constant	k18	130
.constant	k19	25
.constant	k20	7
.constant	k21	193
.constant	k22	227
.constant	k23	129
.constant	k24	"ModuleManager"
.constant	k25	"GetModule"
.constant	k26	"LobbyModuleConfig"
.constant	k27	"NewCharacterNetSystem"
.constant	k28	"character_param"
.constant	k29	"IsUsedCharacter"
.constant	k30	"IsLowMemoryDevice"
.constant	k31	true

.line	873	test          r1     0
.line	873	jmp            0    l5
.line	873	eq             0    r1    k0 ; k0 = 0
.line	873	jmp            0    l7
.label	l5
.line	873	loadbool      r2     0     0
.line	873	return        r2     2
.label	l7
.line	873	gettabup      r2    u0    k1 ; k1 = "characterUseCache"
.line	873	gettable      r2    r2    r1
.line	873	test          r2     0
.line	873	jmp            0   l13
.line	873	loadbool      r2     1     0
.line	873	return        r2     2
.label	l13
.line	873	gettabup      r2    u1    k2 ; k2 = "CDataTable"
.line	873	gettable      r2    r2    k3 ; k3 = "GetTableData"
.line	873	getupval      r3    u2
.line	873	loadk         r4    k4 ; k4 = 224
.line	873	loadk         r5    k5 ; k5 = 32
.line	873	loadk         r6    k6 ; k6 = 178
.line	873	loadk         r7    k7 ; k7 = 205
.line	873	loadk         r8    k8 ; k8 = 117
.line	873	loadk         r9    k9 ; k9 = 83
.line	873	loadk        r10   k10 ; k10 = 114
.line	873	loadk        r11   k11 ; k11 = 132
.line	873	loadk        r12   k12 ; k12 = 245
.line	873	loadk        r13   k13 ; k13 = 246
.line	873	loadk        r14   k14 ; k14 = 235
.line	873	loadk        r15   k15 ; k15 = 97
.line	873	loadk        r16   k16 ; k16 = 76
.line	873	loadk        r17   k17 ; k17 = 252
.line	873	loadk        r18   k18 ; k18 = 130
.line	873	loadk        r19   k19 ; k19 = 25
.line	873	loadk        r20   k20 ; k20 = 7
.line	873	loadk        r21   k19 ; k19 = 25
.line	873	loadk        r22   k21 ; k21 = 193
.line	873	loadk        r23   k22 ; k22 = 227
.line	873	loadk        r24   k23 ; k23 = 129
.line	873	call          r3    22     2
.line	873	move          r4    r1
.line	873	call          r2     3     2
.line	873	gettabup      r3    u1   k24 ; k24 = "ModuleManager"
.line	873	gettable      r3    r3   k25 ; k25 = "GetModule"
.line	873	gettabup      r4    u1   k24 ; k24 = "ModuleManager"
.line	873	gettable      r4    r4   k26 ; k26 = "LobbyModuleConfig"
.line	873	gettable      r4    r4   k27 ; k27 = "NewCharacterNetSyste" (truncated)
.line	873	call          r3     2     2
.line	873	test          r2     0
.line	873	jmp            0   l59
.line	873	gettable      r4    r2   k28 ; k28 = "character_param"
.line	873	eq             1    r4    k0 ; k0 = 0
.line	873	jmp            0   l59
.line	873	self          r4    r3   k29 ; k29 = "IsUsedCharacter"
.line	873	gettable      r6    r2   k28 ; k28 = "character_param"
.line	873	call          r4     3     2
.line	873	test          r4     1
.line	873	jmp            0   l66
.line	873	loadbool      r4     0     0
.line	873	return        r4     2
.line	873	jmp            0   l66
.label	l59
.line	873	gettabup      r4    u0   k30 ; k30 = "IsLowMemoryDevice"
.line	873	test          r4     0
.line	873	jmp            0   l64
.line	873	loadbool      r4     1     0
.line	873	return        r4     2
.label	l64
.line	873	gettabup      r4    u0    k1 ; k1 = "characterUseCache"
.line	873	settable      r4    r1   k31 ; k31 = true
.label	l66
.line	873	loadbool      r4     1     0
.line	873	return        r4     2
.line	873	return        r0     1
.line	873	move          r0    r0
.line	873	return        r0     1

.function	main/f38

.source	null
.linedefined	895
.lastlinedefined	921
.numparams	2
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"CDataTable"
.constant	k2	"GetTableData"
.constant	k3	202
.constant	k4	60
.constant	k5	182
.constant	k6	210
.constant	k7	"ItemRegion"
.constant	k8	232
.constant	k9	58
.constant	k10	185
.constant	k11	207
.constant	k12	228
.constant	k13	36
.constant	k14	188
.constant	k15	221
.constant	k16	117
.constant	k17	92
.constant	k18	"IsServerJK"
.constant	k19	"ModuleManager"
.constant	k20	"GetModule"
.constant	k21	"LobbyModuleConfig"
.constant	k22	"login_module"
.constant	k23	"require"
.constant	k24	224
.constant	k25	39
.constant	k26	190
.constant	k27	123
.constant	k28	94
.constant	k29	40
.constant	k30	146
.constant	k31	243
.constant	k32	219
.constant	k33	242
.constant	k34	110
.constant	k35	89
.constant	k36	194
.constant	k37	154
.constant	k38	50
.constant	k39	26
.constant	k40	20
.constant	k41	"Split"
.constant	k42	"ValidRegionCodes"
.constant	k43	255
.constant	k44	1
.constant	k45	"ipairs"
.constant	k46	"sIpRegion"

.line	895	eq             0    r1    k0 ; k0 = 0
.line	895	jmp            0    l5
.line	895	loadbool      r2     0     0
.line	895	return        r2     2
.label	l5
.line	895	gettabup      r2    u0    k1 ; k1 = "CDataTable"
.line	895	gettable      r2    r2    k2 ; k2 = "GetTableData"
.line	895	getupval      r3    u1
.line	895	loadk         r4    k3 ; k3 = 202
.line	895	loadk         r5    k4 ; k4 = 60
.line	895	loadk         r6    k5 ; k5 = 182
.line	895	loadk         r7    k6 ; k6 = 210
.line	895	call          r3     5     2
.line	895	move          r4    r1
.line	895	call          r2     3     2
.line	895	test          r2     0
.line	895	jmp            0  l102
.line	895	gettable      r3    r2    k7 ; k7 = "ItemRegion"
.line	895	getupval      r4    u1
.line	895	loadk         r5    k8 ; k8 = 232
.line	895	loadk         r6    k9 ; k9 = 58
.line	895	loadk         r7   k10 ; k10 = 185
.line	895	loadk         r8   k11 ; k11 = 207
.line	895	call          r4     5     2
.line	895	eq             1    r3    r4
.line	895	jmp            0   l27
.line	895	loadbool      r4     0     1
.label	l27
.line	895	loadbool      r4     1     0
.line	895	getupval      r5    u1
.line	895	loadk         r6   k12 ; k12 = 228
.line	895	loadk         r7   k13 ; k13 = 36
.line	895	loadk         r8   k14 ; k14 = 188
.line	895	loadk         r9   k15 ; k15 = 221
.line	895	loadk        r10   k16 ; k16 = 117
.line	895	loadk        r11   k17 ; k17 = 92
.line	895	call          r5     7     2
.line	895	eq             1    r3    r5
.line	895	jmp            0   l39
.line	895	loadbool      r5     0     1
.label	l39
.line	895	loadbool      r5     1     0
.line	895	self          r6    r0   k18 ; k18 = "IsServerJK"
.line	895	call          r6     2     2
.line	895	test          r5     0
.line	895	jmp            0   l46
.line	895	test          r6     1
.line	895	jmp            0   l50
.label	l46
.line	895	test          r4     0
.line	895	jmp            0   l52
.line	895	test          r6     1
.line	895	jmp            0   l52
.label	l50
.line	895	loadbool      r7     1     0
.line	895	return        r7     2
.label	l52
.line	895	gettabup      r7    u0   k19 ; k19 = "ModuleManager"
.line	895	gettable      r7    r7   k20 ; k20 = "GetModule"
.line	895	gettabup      r8    u0   k19 ; k19 = "ModuleManager"
.line	895	gettable      r8    r8   k21 ; k21 = "LobbyModuleConfig"
.line	895	gettable      r8    r8   k22 ; k22 = "login_module"
.line	895	call          r7     2     2
.line	895	gettabup      r8    u0   k23 ; k23 = "require"
.line	895	getupval      r9    u1
.line	895	loadk        r10   k24 ; k24 = 224
.line	895	loadk        r11   k25 ; k25 = 39
.line	895	loadk        r12   k26 ; k26 = 190
.line	895	loadk        r13    k6 ; k6 = 210
.line	895	loadk        r14   k27 ; k27 = 123
.line	895	loadk        r15   k28 ; k28 = 94
.line	895	loadk        r16   k29 ; k29 = 40
.line	895	loadk        r17   k30 ; k30 = 146
.line	895	loadk        r18   k31 ; k31 = 243
.line	895	loadk        r19   k32 ; k32 = 219
.line	895	loadk        r20   k33 ; k33 = 242
.line	895	loadk        r21   k34 ; k34 = 110
.line	895	loadk        r22   k35 ; k35 = 89
.line	895	loadk        r23   k36 ; k36 = 194
.line	895	loadk        r24   k37 ; k37 = 154
.line	895	loadk        r25   k38 ; k38 = 50
.line	895	loadk        r26   k39 ; k39 = 26
.line	895	loadk        r27   k40 ; k40 = 20
.line	895	call          r9    19     2
.line	895	call          r8     2     2
.line	895	gettable      r9    r8   k41 ; k41 = "Split"
.line	895	gettable     r10    r2   k42 ; k42 = "ValidRegionCodes"
.line	895	getupval     r11    u1
.line	895	loadk        r12   k43 ; k43 = 255
.line	895	call         r11     2     2
.line	895	call          r9     3     2
.line	895	len          r10    r9
.line	895	lt             0   k44   r10 ; k44 = 1
.line	895	jmp            0  l102
.line	895	gettabup     r10    u0   k45 ; k45 = "ipairs"
.line	895	move         r11    r9
.line	895	call         r10     2     4
.line	895	jmp            0   l98
.line	895	gettable     r15    r7   k46 ; k46 = "sIpRegion"
.line	895	eq             0   r14   r15
.line	895	jmp            0   l98
.line	895	loadbool     r15     0     0
.line	895	return       r15     2
.label	l98
.line	895	move          r0    r0
.line	895	move          r0    r0
.line	895	loadbool     r10     1     0
.line	895	return       r10     2
.label	l102
.line	895	loadbool      r3     0     0
.line	895	return        r3     2
.line	895	return        r0     1
.line	895	move          r0    r0
.line	895	move          r0    r0
.line	895	move          r0    r0
.line	895	return        r0     1

.function	main/f39

.source	null
.linedefined	923
.lastlinedefined	925
.numparams	2
.is_vararg	0
.maxstacksize	5

.constant	k0	"IsCharacterUse"
.constant	k1	"IsItemIsolated"

.line	923	self          r2    r0    k0 ; k0 = "IsCharacterUse"
.line	923	move          r4    r1
.line	923	call          r2     3     2
.line	923	test          r2     0
.line	923	jmp            0   l10
.line	923	self          r2    r0    k1 ; k1 = "IsItemIsolated"
.line	923	move          r4    r1
.line	923	call          r2     3     2
.line	923	not           r2    r2
.label	l10
.line	923	return        r2     2
.line	923	return        r0     1
.line	923	move          r0    r0
.line	923	return        r0     1

.function	main/f40

.source	null
.linedefined	927
.lastlinedefined	935
.numparams	4
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false

.constant	k0	"GetArrayHallDepotItemInfo"
.constant	k1	"pairs"
.constant	k2	"resID"
.constant	k3	"colorID"
.constant	k4	"patternID"

.line	927	getupval      r4    u0
.line	927	self          r4    r4    k0 ; k0 = "GetArrayHallDepotIte" (truncated)
.line	927	call          r4     2     2
.line	927	gettabup      r5    u1    k1 ; k1 = "pairs"
.line	927	move          r6    r4
.line	927	call          r5     2     4
.line	927	jmp            0   l19
.line	927	gettable     r10    r9    k2 ; k2 = "resID"
.line	927	eq             0   r10    r1
.line	927	jmp            0   l19
.line	927	gettable     r10    r9    k3 ; k3 = "colorID"
.line	927	eq             0   r10    r2
.line	927	jmp            0   l19
.line	927	gettable     r10    r9    k4 ; k4 = "patternID"
.line	927	eq             0   r10    r3
.line	927	jmp            0   l19
.line	927	loadbool     r10     1     0
.line	927	return       r10     2
.label	l19
.line	927	move          r0    r0
.line	927	move          r0    r0
.line	927	loadbool      r5     0     0
.line	927	return        r5     2
.line	927	return        r0     1
.line	927	move          r0    r0
.line	927	move          r0    r0
.line	927	move          r0    r0
.line	927	move          r0    r0
.line	927	return        r0     1

.function	main/f41

.source	null
.linedefined	937
.lastlinedefined	943
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"FuncUtil"
.constant	k1	"IsPlayerJPKR"
.constant	k2	1602908
.constant	k3	1602008

.line	937	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	937	gettable      r1    r1    k1 ; k1 = "IsPlayerJPKR"
.line	937	call          r1     1     2
.line	937	test          r1     0
.line	937	jmp            0    l9
.line	937	loadk         r1    k2 ; k2 = 1602908
.line	937	return        r1     2
.line	937	jmp            0   l11
.label	l9
.line	937	loadk         r1    k3 ; k3 = 1602008
.line	937	return        r1     2
.label	l11
.line	937	return        r0     1
.line	937	move          r0    r0
.line	937	return        r0     1

.function	main/f42

.source	null
.linedefined	945
.lastlinedefined	951
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	false

.constant	k0	"FuncUtil"
.constant	k1	"IsPlayerJPKR"
.constant	k2	1602908
.constant	k3	1602008

.line	945	gettabup      r1    u0    k0 ; k0 = "FuncUtil"
.line	945	gettable      r1    r1    k1 ; k1 = "IsPlayerJPKR"
.line	945	call          r1     1     2
.line	945	test          r1     0
.line	945	jmp            0    l9
.line	945	loadk         r1    k2 ; k2 = 1602908
.line	945	return        r1     2
.line	945	jmp            0   l11
.label	l9
.line	945	loadk         r1    k3 ; k3 = 1602008
.line	945	return        r1     2
.label	l11
.line	945	return        r0     1
.line	945	move          r0    r0
.line	945	move          r0    r0
.line	945	move          r0    r0
.line	945	move          r0    r0
.line	945	return        r0     1

.function	main/f43

.source	null
.linedefined	953
.lastlinedefined	959
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	15	true

.constant	k0	"GetHallDepotItemDataByInsID"
.constant	k1	nil
.constant	k2	0
.constant	k3	"resID"

.line	953	getupval      r2    u0
.line	953	self          r2    r2    k0 ; k0 = "GetHallDepotItemData" (truncated)
.line	953	move          r4    r1
.line	953	call          r2     3     2
.line	953	eq             0    r2    k1 ; k1 = nil
.line	953	jmp            0    l9
.line	953	loadk         r3    k2 ; k2 = 0
.line	953	return        r3     2
.label	l9
.line	953	gettable      r3    r2    k3 ; k3 = "resID"
.line	953	return        r3     2
.line	953	return        r0     1
.line	953	move          r0    r0
.line	953	move          r0    r0
.line	953	move          r0    r0
.line	953	move          r0    r0
.line	953	return        r0     1

.function	main/f44

.source	null
.linedefined	961
.lastlinedefined	978
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	15	true
.upvalue	"U1"	0	false

.constant	k0	0
.constant	k1	"GetHallDepotItemListByResID"
.constant	k2	"pairs"
.constant	k3	"GetHallDepotItemDataByInsID"
.constant	k4	"insID"
.constant	k5	nil
.constant	k6	"expireTS"

.line	961	loadk         r2    k0 ; k0 = 0
.line	961	getupval      r3    u0
.line	961	self          r3    r3    k1 ; k1 = "GetHallDepotItemList" (truncated)
.line	961	move          r5    r1
.line	961	call          r3     3     2
.line	961	gettabup      r4    u1    k2 ; k2 = "pairs"
.line	961	move          r5    r3
.line	961	call          r4     2     4
.line	961	jmp            0   l28
.line	961	getupval      r9    u0
.line	961	self          r9    r9    k3 ; k3 = "GetHallDepotItemData" (truncated)
.line	961	gettable     r11    r8    k4 ; k4 = "insID"
.line	961	call          r9     3     2
.line	961	loadk        r10    k0 ; k0 = 0
.line	961	eq             1    r9    k5 ; k5 = nil
.line	961	jmp            0   l28
.line	961	gettable     r11    r9    k6 ; k6 = "expireTS"
.line	961	eq             0   r11    k0 ; k0 = 0
.line	961	jmp            0   l23
.line	961	gettable      r2    r9    k4 ; k4 = "insID"
.line	961	jmp            0   l30
.line	961	jmp            0   l28
.label	l23
.line	961	gettable     r11    r9    k6 ; k6 = "expireTS"
.line	961	lt             0   r10   r11
.line	961	jmp            0   l28
.line	961	gettable     r10    r9    k6 ; k6 = "expireTS"
.line	961	gettable      r2    r9    k4 ; k4 = "insID"
.label	l28
.line	961	move          r0    r0
.line	961	move          r0    r0
.label	l30
.line	961	return        r2     2
.line	961	return        r0     1
.line	961	move          r0    r0
.line	961	move          r0    r0
.line	961	move          r0    r0
.line	961	move          r0    r0
.line	961	return        r0     1

.function	main/f45

.source	null
.linedefined	980
.lastlinedefined	989
.numparams	5
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	130
.constant	k9	232
.constant	k10	196
.constant	k11	246
.constant	k12	111
.constant	k13	80
.constant	k14	179
.constant	k15	155
.constant	k16	47
.constant	k17	30
.constant	k18	29
.constant	k19	252
.constant	k20	250
.constant	k21	144
.constant	k22	105
.constant	k23	26
.constant	k24	"GetServerTimeInSec"
.constant	k25	"mainTabType"
.constant	k26	"subTabType"
.constant	k27	"expireTS"
.constant	k28	0

.line	980	test          r4     1
.line	980	jmp            0   l33
.line	980	gettabup      r5    u0    k0 ; k0 = "require"
.line	980	getupval      r6    u1
.line	980	loadk         r7    k1 ; k1 = 224
.line	980	loadk         r8    k2 ; k2 = 36
.line	980	loadk         r9    k3 ; k3 = 186
.line	980	loadk        r10    k4 ; k4 = 218
.line	980	loadk        r11    k5 ; k5 = 122
.line	980	loadk        r12    k6 ; k6 = 68
.line	980	loadk        r13    k7 ; k7 = 40
.line	980	loadk        r14    k8 ; k8 = 130
.line	980	loadk        r15    k9 ; k9 = 232
.line	980	loadk        r16   k10 ; k10 = 196
.line	980	loadk        r17   k11 ; k11 = 246
.line	980	loadk        r18   k12 ; k12 = 111
.line	980	loadk        r19   k13 ; k13 = 80
.line	980	loadk        r20   k14 ; k14 = 179
.line	980	loadk        r21   k15 ; k15 = 155
.line	980	loadk        r22   k16 ; k16 = 47
.line	980	loadk        r23   k17 ; k17 = 30
.line	980	loadk        r24   k18 ; k18 = 29
.line	980	loadk        r25   k19 ; k19 = 252
.line	980	loadk        r26   k20 ; k20 = 250
.line	980	loadk        r27   k21 ; k21 = 144
.line	980	loadk        r28   k22 ; k22 = 105
.line	980	loadk        r29   k23 ; k23 = 26
.line	980	call          r6    24     2
.line	980	call          r5     2     2
.line	980	gettable      r6    r5   k24 ; k24 = "GetServerTimeInSec"
.line	980	call          r6     1     2
.line	980	move          r4    r6
.label	l33
.line	980	gettable      r5    r3   k25 ; k25 = "mainTabType"
.line	980	eq             0    r5    r1
.line	980	jmp            0   l47
.line	980	gettable      r5    r3   k26 ; k26 = "subTabType"
.line	980	eq             0    r5    r2
.line	980	jmp            0   l47
.line	980	gettable      r5    r3   k27 ; k27 = "expireTS"
.line	980	eq             1    r5   k28 ; k28 = 0
.line	980	jmp            0   l45
.line	980	gettable      r5    r3   k27 ; k27 = "expireTS"
.line	980	lt             0    r4    r5
.line	980	jmp            0   l47
.label	l45
.line	980	loadbool      r5     1     0
.line	980	return        r5     2
.label	l47
.line	980	loadbool      r5     0     0
.line	980	return        r5     2
.line	980	return        r0     1
.line	980	move          r0    r0
.line	980	move          r0    r0
.line	980	move          r0    r0
.line	980	return        r0     1

.function	main/f46

.source	null
.linedefined	991
.lastlinedefined	1001
.numparams	5
.is_vararg	0
.maxstacksize	30

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	130
.constant	k9	232
.constant	k10	196
.constant	k11	246
.constant	k12	111
.constant	k13	80
.constant	k14	179
.constant	k15	155
.constant	k16	47
.constant	k17	30
.constant	k18	29
.constant	k19	252
.constant	k20	250
.constant	k21	144
.constant	k22	105
.constant	k23	26
.constant	k24	"GetServerTimeInSec"
.constant	k25	"mainTabType"
.constant	k26	"subTabType"
.constant	k27	"expireTS"
.constant	k28	0

.line	991	test          r2     1
.line	991	jmp            0    l5
.line	991	newtable      r5     0     0
.line	991	move          r2    r5
.label	l5
.line	991	test          r4     1
.line	991	jmp            0   l37
.line	991	gettabup      r5    u0    k0 ; k0 = "require"
.line	991	getupval      r6    u1
.line	991	loadk         r7    k1 ; k1 = 224
.line	991	loadk         r8    k2 ; k2 = 36
.line	991	loadk         r9    k3 ; k3 = 186
.line	991	loadk        r10    k4 ; k4 = 218
.line	991	loadk        r11    k5 ; k5 = 122
.line	991	loadk        r12    k6 ; k6 = 68
.line	991	loadk        r13    k7 ; k7 = 40
.line	991	loadk        r14    k8 ; k8 = 130
.line	991	loadk        r15    k9 ; k9 = 232
.line	991	loadk        r16   k10 ; k10 = 196
.line	991	loadk        r17   k11 ; k11 = 246
.line	991	loadk        r18   k12 ; k12 = 111
.line	991	loadk        r19   k13 ; k13 = 80
.line	991	loadk        r20   k14 ; k14 = 179
.line	991	loadk        r21   k15 ; k15 = 155
.line	991	loadk        r22   k16 ; k16 = 47
.line	991	loadk        r23   k17 ; k17 = 30
.line	991	loadk        r24   k18 ; k18 = 29
.line	991	loadk        r25   k19 ; k19 = 252
.line	991	loadk        r26   k20 ; k20 = 250
.line	991	loadk        r27   k21 ; k21 = 144
.line	991	loadk        r28   k22 ; k22 = 105
.line	991	loadk        r29   k23 ; k23 = 26
.line	991	call          r6    24     2
.line	991	call          r5     2     2
.line	991	gettable      r6    r5   k24 ; k24 = "GetServerTimeInSec"
.line	991	call          r6     1     2
.line	991	move          r4    r6
.label	l37
.line	991	gettable      r5    r3   k25 ; k25 = "mainTabType"
.line	991	eq             0    r5    r1
.line	991	jmp            0   l52
.line	991	gettable      r5    r3   k26 ; k26 = "subTabType"
.line	991	gettable      r5    r2    r5
.line	991	test          r5     0
.line	991	jmp            0   l52
.line	991	gettable      r5    r3   k27 ; k27 = "expireTS"
.line	991	eq             1    r5   k28 ; k28 = 0
.line	991	jmp            0   l50
.line	991	gettable      r5    r3   k27 ; k27 = "expireTS"
.line	991	lt             0    r4    r5
.line	991	jmp            0   l52
.label	l50
.line	991	loadbool      r5     1     0
.line	991	return        r5     2
.label	l52
.line	991	loadbool      r5     0     0
.line	991	return        r5     2
.line	991	return        r0     1
.line	991	move          r0    r0
.line	991	move          r0    r0
.line	991	move          r0    r0
.line	991	move          r0    r0
.line	991	return        r0     1

.function	main/f47

.source	null
.linedefined	1003
.lastlinedefined	1011
.numparams	3
.is_vararg	0
.maxstacksize	25

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	163
.constant	k3	104
.constant	k4	160
.constant	k5	218
.constant	k6	96
.constant	k7	116
.constant	k8	111
.constant	k9	146
.constant	k10	247
.constant	k11	197
.constant	k12	250
.constant	k13	121
.constant	k14	108
.constant	k15	248
.constant	k16	156
.constant	k17	15
.constant	k18	23
.constant	k19	86
.constant	k20	131
.constant	k21	175
.constant	k22	"tostring"
.constant	k23	"extra"
.constant	k24	"displayResId"

.line	1003	gettabup      r3    u0    k0 ; k0 = "log"
.line	1003	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1003	test          r4     0
.line	1003	jmp            0   l31
.line	1003	getupval      r4    u1
.line	1003	loadk         r5    k2 ; k2 = 163
.line	1003	loadk         r6    k3 ; k3 = 104
.line	1003	loadk         r7    k4 ; k4 = 160
.line	1003	loadk         r8    k5 ; k5 = 218
.line	1003	loadk         r9    k6 ; k6 = 96
.line	1003	loadk        r10    k7 ; k7 = 116
.line	1003	loadk        r11    k8 ; k8 = 111
.line	1003	loadk        r12    k9 ; k9 = 146
.line	1003	loadk        r13   k10 ; k10 = 247
.line	1003	loadk        r14   k11 ; k11 = 197
.line	1003	loadk        r15   k12 ; k12 = 250
.line	1003	loadk        r16   k13 ; k13 = 121
.line	1003	loadk        r17   k14 ; k14 = 108
.line	1003	loadk        r18   k15 ; k15 = 248
.line	1003	loadk        r19   k16 ; k16 = 156
.line	1003	loadk        r20   k17 ; k17 = 15
.line	1003	loadk        r21   k18 ; k18 = 23
.line	1003	loadk        r22   k19 ; k19 = 86
.line	1003	loadk        r23   k20 ; k20 = 131
.line	1003	loadk        r24   k21 ; k21 = 175
.line	1003	call          r4    21     2
.line	1003	gettabup      r5    u0   k22 ; k22 = "tostring"
.line	1003	move          r6    r2
.line	1003	call          r5     2     2
.line	1003	concat        r4    r4    r5
.label	l31
.line	1003	call          r3     2     1
.line	1003	gettable      r3    r1   k23 ; k23 = "extra"
.line	1003	test          r3     0
.line	1003	jmp            0   l37
.line	1003	settable      r3   k24    r2 ; k24 = "displayResId"
.line	1003	jmp            0   l40
.label	l37
.line	1003	newtable      r4     0     1
.line	1003	settable      r4   k24    r2 ; k24 = "displayResId"
.line	1003	settable      r1   k23    r4 ; k23 = "extra"
.label	l40
.line	1003	return        r0     1
.line	1003	move          r0    r0
.line	1003	return        r0     1

.function	main/f48

.source	null
.linedefined	1013
.lastlinedefined	1018
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"extra"
.constant	k1	"displayResId"
.constant	k2	nil

.line	1013	gettable      r2    r1    k0 ; k0 = "extra"
.line	1013	test          r2     0
.line	1013	jmp            0    l5
.line	1013	settable      r2    k1    k2 ; k2 = nil
.label	l5
.line	1013	return        r0     1
.line	1013	move          r0    r0
.line	1013	move          r0    r0
.line	1013	move          r0    r0
.line	1013	return        r0     1

.function	main/f49

.source	null
.linedefined	1020
.lastlinedefined	1085
.numparams	8
.is_vararg	0
.maxstacksize	53

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CDataTable"
.constant	k1	"GetTableData"
.constant	k2	202
.constant	k3	60
.constant	k4	182
.constant	k5	210
.constant	k6	"resID"
.constant	k7	nil
.constant	k8	"log_warning"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	194
.constant	k12	58
.constant	k13	161
.constant	k14	222
.constant	k15	109
.constant	k16	120
.constant	k17	103
.constant	k18	141
.constant	k19	235
.constant	k20	237
.constant	k21	254
.constant	k22	112
.constant	k23	81
.constant	k24	233
.constant	k25	187
.constant	k26	41
.constant	k27	48
.constant	k28	23
.constant	k29	206
.constant	k30	226
.constant	k31	139
.constant	k32	110
.constant	k33	63
.constant	k34	165
.constant	k35	242
.constant	k36	212
.constant	k37	171
.constant	k38	121
.constant	k39	90
.constant	k40	232
.constant	k41	146
.constant	k42	21
.constant	k43	5
.constant	k44	15
.constant	k45	147
.constant	k46	241
.constant	k47	157
.constant	k48	124
.constant	k49	72
.constant	k50	225
.constant	k51	234
.constant	k52	38
.constant	k53	160
.constant	k54	246
.constant	k55	80
.constant	k56	10
.constant	k57	"tostring"
.constant	k58	"insID"
.constant	k59	45
.constant	k60	"tonumber"
.constant	k61	"ModuleManager"
.constant	k62	"GetModule"
.constant	k63	"LobbyModuleConfig"
.constant	k64	"wardrobe_red_point"
.constant	k65	"Touch"
.constant	k66	"index"
.constant	k67	0
.constant	k68	"isUsing"
.constant	k69	"showUseCount"
.constant	k70	"isSelected"
.constant	k71	"isSourceBook"
.constant	k72	"hasLock"
.constant	k73	"isRolewear"
.constant	k74	"itemName"
.constant	k75	"count"
.constant	k76	"lock_cnt"
.constant	k77	"isNew"
.constant	k78	"ins_id"
.constant	k79	"res_id"
.constant	k80	"color_id"
.constant	k81	"colorID"
.constant	k82	"pattern_id"
.constant	k83	"patternID"
.constant	k84	"validHours"
.constant	k85	"itemSubType"
.constant	k86	"expireTS"
.constant	k87	"quality"
.constant	k88	"itemQuality"
.constant	k89	"hasLimitTime"
.constant	k90	"require"
.constant	k91	224
.constant	k92	36
.constant	k93	186
.constant	k94	218
.constant	k95	122
.constant	k96	68
.constant	k97	40
.constant	k98	130
.constant	k99	196
.constant	k100	111
.constant	k101	179
.constant	k102	154
.constant	k103	47
.constant	k104	44
.constant	k105	13
.constant	k106	215
.constant	k107	230
.constant	k108	136
.constant	k109	"GetSpecialQuality"
.constant	k110	220
.constant	k111	250
.constant	k112	46
.constant	k113	82
.constant	k114	16
.constant	k115	86
.constant	k116	251
.constant	k117	145
.constant	k118	105
.constant	k119	2
.constant	k120	255
.constant	k121	214
.constant	k122	236
.constant	k123	77
.constant	k124	135
.constant	k125	37
.constant	k126	22
.constant	k127	1
.constant	k128	199
.constant	k129	"IsXSuit"
.constant	k130	"ChangeItemIDByInsID"
.constant	k131	"SetDisplayItemId"
.constant	k132	1410923
.constant	k133	"AvatarData"
.constant	k134	"GetWearInfo"
.constant	k135	"pairs"
.constant	k136	"ItemID"
.constant	k137	1407726
.constant	k138	1410945
.constant	k139	1411189
.constant	k140	1408075
.constant	k141	1411190
.constant	k142	"ExtractHigh32Bits"
.constant	k143	"ExtractLow19Bits"
.constant	k144	"High32Bits"
.constant	k145	"Low19Bits"

.line	1020	gettabup      r8    u0    k0 ; k0 = "CDataTable"
.line	1020	gettable      r8    r8    k1 ; k1 = "GetTableData"
.line	1020	getupval      r9    u1
.line	1020	loadk        r10    k2 ; k2 = 202
.line	1020	loadk        r11    k3 ; k3 = 60
.line	1020	loadk        r12    k4 ; k4 = 182
.line	1020	loadk        r13    k5 ; k5 = 210
.line	1020	call          r9     5     2
.line	1020	gettable     r10    r1    k6 ; k6 = "resID"
.line	1020	call          r8     3     2
.line	1020	eq             0    r8    k7 ; k7 = nil
.line	1020	jmp            0  l135
.line	1020	gettabup      r9    u0    k8 ; k8 = "log_warning"
.line	1020	gettabup     r10    u0    k9 ; k9 = "table"
.line	1020	gettable     r10   r10   k10 ; k10 = "concat"
.line	1020	newtable     r11     1     0
.line	1020	getupval     r12    u1
.line	1020	loadk        r13   k11 ; k11 = 194
.line	1020	loadk        r14   k12 ; k12 = 58
.line	1020	loadk        r15   k13 ; k13 = 161
.line	1020	loadk        r16   k14 ; k14 = 222
.line	1020	loadk        r17   k15 ; k15 = 109
.line	1020	loadk        r18   k16 ; k16 = 120
.line	1020	loadk        r19   k17 ; k17 = 103
.line	1020	loadk        r20   k18 ; k18 = 141
.line	1020	loadk        r21   k19 ; k19 = 235
.line	1020	loadk        r22   k20 ; k20 = 237
.line	1020	loadk        r23   k21 ; k21 = 254
.line	1020	loadk        r24   k22 ; k22 = 112
.line	1020	loadk        r25   k23 ; k23 = 81
.line	1020	loadk        r26   k24 ; k24 = 233
.line	1020	loadk        r27   k25 ; k25 = 187
.line	1020	loadk        r28   k26 ; k26 = 41
.line	1020	loadk        r29   k27 ; k27 = 48
.line	1020	loadk        r30   k28 ; k28 = 23
.line	1020	loadk        r31   k29 ; k29 = 206
.line	1020	loadk        r32   k30 ; k30 = 226
.line	1020	loadk        r33   k31 ; k31 = 139
.line	1020	loadk        r34   k32 ; k32 = 110
.line	1020	loadk        r35   k33 ; k33 = 63
.line	1020	loadk        r36   k34 ; k34 = 165
.line	1020	loadk        r37   k35 ; k35 = 242
.line	1020	loadk        r38   k36 ; k36 = 212
.line	1020	loadk        r39   k37 ; k37 = 171
.line	1020	loadk        r40   k38 ; k38 = 121
.line	1020	loadk        r41   k39 ; k39 = 90
.line	1020	loadk        r42   k40 ; k40 = 232
.line	1020	loadk        r43   k41 ; k41 = 146
.line	1020	loadk        r44   k42 ; k42 = 21
.line	1020	loadk        r45   k43 ; k43 = 5
.line	1020	loadk        r46   k44 ; k44 = 15
.line	1020	loadk        r47   k45 ; k45 = 147
.line	1020	loadk        r48   k46 ; k46 = 241
.line	1020	loadk        r49   k47 ; k47 = 157
.line	1020	loadk        r50   k48 ; k48 = 124
.line	1020	loadk        r51   k49 ; k49 = 72
.line	1020	loadk        r52   k50 ; k50 = 225
.line	1020	call         r12    41     2
.line	1020	getupval     r13    u1
.line	1020	loadk        r14   k51 ; k51 = 234
.line	1020	loadk        r15   k52 ; k52 = 38
.line	1020	loadk        r16   k53 ; k53 = 160
.line	1020	loadk        r17   k54 ; k54 = 246
.line	1020	loadk        r18   k55 ; k55 = 80
.line	1020	loadk        r19   k56 ; k56 = 10
.line	1020	call         r13     7     0
.line	1020	setlist      r11     0     1
.line	1020	call         r10     2     2
.line	1020	gettabup     r11    u0   k57 ; k57 = "tostring"
.line	1020	gettable     r12    r1   k58 ; k58 = "insID"
.line	1020	call         r11     2     2
.line	1020	concat       r10   r10   r11
.line	1020	call          r9     2     1
.line	1020	gettabup      r9    u0    k8 ; k8 = "log_warning"
.line	1020	gettabup     r10    u0    k9 ; k9 = "table"
.line	1020	gettable     r10   r10   k10 ; k10 = "concat"
.line	1020	newtable     r11     1     0
.line	1020	getupval     r12    u1
.line	1020	loadk        r13   k11 ; k11 = 194
.line	1020	loadk        r14   k12 ; k12 = 58
.line	1020	loadk        r15   k13 ; k13 = 161
.line	1020	loadk        r16   k14 ; k14 = 222
.line	1020	loadk        r17   k15 ; k15 = 109
.line	1020	loadk        r18   k16 ; k16 = 120
.line	1020	loadk        r19   k17 ; k17 = 103
.line	1020	loadk        r20   k18 ; k18 = 141
.line	1020	loadk        r21   k19 ; k19 = 235
.line	1020	loadk        r22   k20 ; k20 = 237
.line	1020	loadk        r23   k21 ; k21 = 254
.line	1020	loadk        r24   k22 ; k22 = 112
.line	1020	loadk        r25   k23 ; k23 = 81
.line	1020	loadk        r26   k24 ; k24 = 233
.line	1020	loadk        r27   k25 ; k25 = 187
.line	1020	loadk        r28   k26 ; k26 = 41
.line	1020	loadk        r29   k27 ; k27 = 48
.line	1020	loadk        r30   k28 ; k28 = 23
.line	1020	loadk        r31   k29 ; k29 = 206
.line	1020	loadk        r32   k30 ; k30 = 226
.line	1020	loadk        r33   k31 ; k31 = 139
.line	1020	loadk        r34   k32 ; k32 = 110
.line	1020	loadk        r35   k33 ; k33 = 63
.line	1020	loadk        r36   k34 ; k34 = 165
.line	1020	loadk        r37   k35 ; k35 = 242
.line	1020	loadk        r38   k36 ; k36 = 212
.line	1020	loadk        r39   k37 ; k37 = 171
.line	1020	loadk        r40   k38 ; k38 = 121
.line	1020	loadk        r41   k39 ; k39 = 90
.line	1020	loadk        r42   k40 ; k40 = 232
.line	1020	loadk        r43   k41 ; k41 = 146
.line	1020	loadk        r44   k42 ; k42 = 21
.line	1020	loadk        r45   k43 ; k43 = 5
.line	1020	loadk        r46   k44 ; k44 = 15
.line	1020	loadk        r47   k45 ; k45 = 147
.line	1020	loadk        r48   k46 ; k46 = 241
.line	1020	loadk        r49   k47 ; k47 = 157
.line	1020	loadk        r50   k48 ; k48 = 124
.line	1020	loadk        r51   k49 ; k49 = 72
.line	1020	loadk        r52   k50 ; k50 = 225
.line	1020	call         r12    41     2
.line	1020	getupval     r13    u1
.line	1020	loadk        r14   k46 ; k46 = 241
.line	1020	loadk        r15   k59 ; k59 = 45
.line	1020	loadk        r16   k53 ; k53 = 160
.line	1020	loadk        r17   k54 ; k54 = 246
.line	1020	loadk        r18   k55 ; k55 = 80
.line	1020	loadk        r19   k56 ; k56 = 10
.line	1020	call         r13     7     0
.line	1020	setlist      r11     0     1
.line	1020	call         r10     2     2
.line	1020	gettabup     r11    u0   k57 ; k57 = "tostring"
.line	1020	gettable     r12    r1    k6 ; k6 = "resID"
.line	1020	call         r11     2     2
.line	1020	concat       r10   r10   r11
.line	1020	call          r9     2     1
.label	l135
.line	1020	gettabup      r9    u0   k60 ; k60 = "tonumber"
.line	1020	gettable     r10    r1   k58 ; k58 = "insID"
.line	1020	call          r9     2     2
.line	1020	gettabup     r10    u0   k61 ; k61 = "ModuleManager"
.line	1020	gettable     r10   r10   k62 ; k62 = "GetModule"
.line	1020	gettabup     r11    u0   k61 ; k61 = "ModuleManager"
.line	1020	gettable     r11   r11   k63 ; k63 = "LobbyModuleConfig"
.line	1020	gettable     r11   r11   k64 ; k64 = "wardrobe_red_point"
.line	1020	call         r10     2     2
.line	1020	self         r11   r10   k65 ; k65 = "Touch"
.line	1020	move         r13    r9
.line	1020	move         r14    r1
.line	1020	call         r11     4     2
.line	1020	newtable     r12     0    18
.line	1020	testset      r13    r2     1
.line	1020	jmp            0  l152
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l152
.line	1020	settable     r12   k66   r13 ; k66 = "index"
.line	1020	testset      r13    r3     1
.line	1020	jmp            0  l156
.line	1020	loadbool     r13     0     0
.label	l156
.line	1020	settable     r12   k68   r13 ; k68 = "isUsing"
.line	1020	settable     r12   k69    r4 ; k69 = "showUseCount"
.line	1020	testset      r13    r5     1
.line	1020	jmp            0  l161
.line	1020	loadbool     r13     0     0
.label	l161
.line	1020	settable     r12   k70   r13 ; k70 = "isSelected"
.line	1020	testset      r13    r6     1
.line	1020	jmp            0  l165
.line	1020	loadbool     r13     0     0
.label	l165
.line	1020	settable     r12   k71   r13 ; k71 = "isSourceBook"
.line	1020	testset      r13    r6     1
.line	1020	jmp            0  l169
.line	1020	loadbool     r13     0     0
.label	l169
.line	1020	settable     r12   k72   r13 ; k72 = "hasLock"
.line	1020	testset      r13    r7     1
.line	1020	jmp            0  l173
.line	1020	loadbool     r13     0     0
.label	l173
.line	1020	settable     r12   k73   r13 ; k73 = "isRolewear"
.line	1020	test          r8     0
.line	1020	jmp            0  l179
.line	1020	gettable     r13    r8   k74 ; k74 = "itemName"
.line	1020	test         r13     1
.line	1020	jmp            0  l180
.label	l179
.line	1020	loadnil      r13     0
.label	l180
.line	1020	settable     r12   k74   r13 ; k74 = "itemName"
.line	1020	gettable     r13    r1   k75 ; k75 = "count"
.line	1020	settable     r12   k75   r13 ; k75 = "count"
.line	1020	gettable     r13    r1   k76 ; k76 = "lock_cnt"
.line	1020	test         r13     1
.line	1020	jmp            0  l187
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l187
.line	1020	settable     r12   k76   r13 ; k76 = "lock_cnt"
.line	1020	settable     r12   k77   r11 ; k77 = "isNew"
.line	1020	gettable     r13    r1   k58 ; k58 = "insID"
.line	1020	settable     r12   k78   r13 ; k78 = "ins_id"
.line	1020	gettable     r13    r1    k6 ; k6 = "resID"
.line	1020	settable     r12   k79   r13 ; k79 = "res_id"
.line	1020	gettable     r13    r1   k81 ; k81 = "colorID"
.line	1020	test         r13     1
.line	1020	jmp            0  l197
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l197
.line	1020	settable     r12   k80   r13 ; k80 = "color_id"
.line	1020	gettable     r13    r1   k83 ; k83 = "patternID"
.line	1020	test         r13     1
.line	1020	jmp            0  l202
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l202
.line	1020	settable     r12   k82   r13 ; k82 = "pattern_id"
.line	1020	gettable     r13    r1   k84 ; k84 = "validHours"
.line	1020	test         r13     1
.line	1020	jmp            0  l207
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l207
.line	1020	settable     r12   k84   r13 ; k84 = "validHours"
.line	1020	test          r8     0
.line	1020	jmp            0  l213
.line	1020	gettable     r13    r8   k85 ; k85 = "itemSubType"
.line	1020	test         r13     1
.line	1020	jmp            0  l214
.label	l213
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l214
.line	1020	settable     r12   k85   r13 ; k85 = "itemSubType"
.line	1020	gettable     r13    r1   k86 ; k86 = "expireTS"
.line	1020	test         r13     1
.line	1020	jmp            0  l219
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l219
.line	1020	settable     r12   k86   r13 ; k86 = "expireTS"
.line	1020	gettable     r13    r1   k88 ; k88 = "itemQuality"
.line	1020	test         r13     1
.line	1020	jmp            0  l224
.line	1020	loadk        r13   k67 ; k67 = 0
.label	l224
.line	1020	settable     r12   k87   r13 ; k87 = "quality"
.line	1020	gettable     r13    r1   k84 ; k84 = "validHours"
.line	1020	lt             1   k67   r13 ; k67 = 0
.line	1020	jmp            0  l232
.line	1020	gettable     r13    r1   k86 ; k86 = "expireTS"
.line	1020	lt             1   k67   r13 ; k67 = 0
.line	1020	jmp            0  l232
.line	1020	loadbool     r13     0     1
.label	l232
.line	1020	loadbool     r13     1     0
.line	1020	settable     r12   k89   r13 ; k89 = "hasLimitTime"
.line	1020	gettabup     r13    u0   k90 ; k90 = "require"
.line	1020	getupval     r14    u1
.line	1020	loadk        r15   k91 ; k91 = 224
.line	1020	loadk        r16   k92 ; k92 = 36
.line	1020	loadk        r17   k93 ; k93 = 186
.line	1020	loadk        r18   k94 ; k94 = 218
.line	1020	loadk        r19   k95 ; k95 = 122
.line	1020	loadk        r20   k96 ; k96 = 68
.line	1020	loadk        r21   k97 ; k97 = 40
.line	1020	loadk        r22   k98 ; k98 = 130
.line	1020	loadk        r23   k40 ; k40 = 232
.line	1020	loadk        r24   k99 ; k99 = 196
.line	1020	loadk        r25   k54 ; k54 = 246
.line	1020	loadk        r26  k100 ; k100 = 111
.line	1020	loadk        r27   k55 ; k55 = 80
.line	1020	loadk        r28  k101 ; k101 = 179
.line	1020	loadk        r29  k102 ; k102 = 154
.line	1020	loadk        r30  k103 ; k103 = 47
.line	1020	loadk        r31  k104 ; k104 = 44
.line	1020	loadk        r32  k105 ; k105 = 13
.line	1020	loadk        r33  k106 ; k106 = 215
.line	1020	loadk        r34  k107 ; k107 = 230
.line	1020	loadk        r35  k108 ; k108 = 136
.line	1020	call         r14    22     2
.line	1020	call         r13     2     2
.line	1020	gettable     r14   r13  k109 ; k109 = "GetSpecialQuality"
.line	1020	gettable     r15    r1    k6 ; k6 = "resID"
.line	1020	call         r14     2     2
.line	1020	lt             0   k67   r14 ; k67 = 0
.line	1020	jmp            0  l265
.line	1020	settable     r12   k87   r14 ; k87 = "quality"
.label	l265
.line	1020	gettabup     r15    u0   k90 ; k90 = "require"
.line	1020	getupval     r16    u1
.line	1020	loadk        r17   k91 ; k91 = 224
.line	1020	loadk        r18   k92 ; k92 = 36
.line	1020	loadk        r19   k93 ; k93 = 186
.line	1020	loadk        r20   k94 ; k94 = 218
.line	1020	loadk        r21   k95 ; k95 = 122
.line	1020	loadk        r22   k96 ; k96 = 68
.line	1020	loadk        r23   k97 ; k97 = 40
.line	1020	loadk        r24   k41 ; k41 = 146
.line	1020	loadk        r25   k19 ; k19 = 235
.line	1020	loadk        r26  k110 ; k110 = 220
.line	1020	loadk        r27  k111 ; k111 = 250
.line	1020	loadk        r28  k112 ; k112 = 46
.line	1020	loadk        r29  k113 ; k113 = 82
.line	1020	loadk        r30   k35 ; k35 = 242
.line	1020	loadk        r31  k108 ; k108 = 136
.line	1020	loadk        r32  k103 ; k103 = 47
.line	1020	loadk        r33  k114 ; k114 = 16
.line	1020	loadk        r34  k115 ; k115 = 86
.line	1020	loadk        r35  k116 ; k116 = 251
.line	1020	loadk        r36  k110 ; k110 = 220
.line	1020	loadk        r37  k117 ; k117 = 145
.line	1020	loadk        r38  k118 ; k118 = 105
.line	1020	loadk        r39  k119 ; k119 = 2
.line	1020	loadk        r40  k120 ; k120 = 255
.line	1020	loadk        r41  k116 ; k116 = 251
.line	1020	loadk        r42  k121 ; k121 = 214
.line	1020	loadk        r43  k122 ; k122 = 236
.line	1020	loadk        r44   k38 ; k38 = 121
.line	1020	loadk        r45  k123 ; k123 = 77
.line	1020	loadk        r46    k5 ; k5 = 210
.line	1020	loadk        r47  k124 ; k124 = 135
.line	1020	loadk        r48  k125 ; k125 = 37
.line	1020	loadk        r49  k126 ; k126 = 22
.line	1020	loadk        r50  k127 ; k127 = 1
.line	1020	loadk        r51  k128 ; k128 = 199
.line	1020	call         r16    36     2
.line	1020	call         r15     2     2
.line	1020	gettable     r16    r1    k6 ; k6 = "resID"
.line	1020	gettable     r17   r15  k129 ; k129 = "IsXSuit"
.line	1020	move         r18   r16
.line	1020	call         r17     2     2
.line	1020	test         r17     0
.line	1020	jmp            0  l320
.line	1020	gettable     r17   r15  k130 ; k130 = "ChangeItemIDByInsID"
.line	1020	gettable     r18    r1   k58 ; k58 = "insID"
.line	1020	call         r17     2     2
.line	1020	eq             1   r17   r16
.line	1020	jmp            0  l359
.line	1020	self         r18    r0  k131 ; k131 = "SetDisplayItemId"
.line	1020	move         r20   r12
.line	1020	move         r21   r17
.line	1020	call         r18     4     1
.line	1020	jmp            0  l359
.label	l320
.line	1020	eq             0   r16  k132 ; k132 = 1410923
.line	1020	jmp            0  l340
.line	1020	gettabup     r17    u0  k133 ; k133 = "AvatarData"
.line	1020	gettable     r17   r17  k134 ; k134 = "GetWearInfo"
.line	1020	call         r17     1     2
.line	1020	gettabup     r18    u0  k135 ; k135 = "pairs"
.line	1020	move         r19   r17
.line	1020	call         r18     2     4
.line	1020	jmp            0  l337
.line	1020	gettable     r23   r22  k136 ; k136 = "ItemID"
.line	1020	eq             0   r23  k137 ; k137 = 1407726
.line	1020	jmp            0  l337
.line	1020	self         r23    r0  k131 ; k131 = "SetDisplayItemId"
.line	1020	move         r25   r12
.line	1020	loadk        r26  k138 ; k138 = 1410945
.line	1020	call         r23     4     1
.line	1020	jmp            0  l359
.label	l337
.line	1020	move          r0    r0
.line	1020	move          r0    r0
.line	1020	jmp            0  l359
.label	l340
.line	1020	eq             0   r16  k139 ; k139 = 1411189
.line	1020	jmp            0  l359
.line	1020	gettabup     r17    u0  k133 ; k133 = "AvatarData"
.line	1020	gettable     r17   r17  k134 ; k134 = "GetWearInfo"
.line	1020	call         r17     1     2
.line	1020	gettabup     r18    u0  k135 ; k135 = "pairs"
.line	1020	move         r19   r17
.line	1020	call         r18     2     4
.line	1020	jmp            0  l357
.line	1020	gettable     r23   r22  k136 ; k136 = "ItemID"
.line	1020	eq             0   r23  k140 ; k140 = 1408075
.line	1020	jmp            0  l357
.line	1020	self         r23    r0  k131 ; k131 = "SetDisplayItemId"
.line	1020	move         r25   r12
.line	1020	loadk        r26  k141 ; k141 = 1411190
.line	1020	call         r23     4     1
.line	1020	jmp            0  l359
.label	l357
.line	1020	move          r0    r0
.line	1020	move          r0    r0
.label	l359
.line	1020	self         r17    r0  k142 ; k142 = "ExtractHigh32Bits"
.line	1020	gettable     r19   r12   k78 ; k78 = "ins_id"
.line	1020	call         r17     3     2
.line	1020	self         r18    r0  k143 ; k143 = "ExtractLow19Bits"
.line	1020	gettable     r20   r12   k78 ; k78 = "ins_id"
.line	1020	call         r18     3     2
.line	1020	settable     r12  k144   r17 ; k144 = "High32Bits"
.line	1020	settable     r12  k145   r18 ; k145 = "Low19Bits"
.line	1020	return       r12     2
.line	1020	return        r0     1
.line	1020	move          r0    r0
.line	1020	return        r0     1

.function	main/f50

.source	null
.linedefined	1087
.lastlinedefined	1123
.numparams	4
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	10	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	212
.constant	k3	41
.constant	k4	161
.constant	k5	219
.constant	k6	102
.constant	k7	95
.constant	k8	100
.constant	k9	132
.constant	k10	203
.constant	k11	198
.constant	k12	252
.constant	k13	105
.constant	k14	93
.constant	k15	167
.constant	k16	128
.constant	k17	40
.constant	k18	44
.constant	k19	13
.constant	k20	208
.constant	k21	234
.constant	k22	187
.constant	k23	2
.constant	k24	180
.constant	k25	250
.constant	k26	230
.constant	k27	249
.constant	k28	99
.constant	k29	94
.constant	k30	223
.constant	k31	36
.constant	k32	6
.constant	k33	27
.constant	k34	147
.constant	k35	162
.constant	k36	"tostring"
.constant	k37	"log_tree"
.constant	k38	"NetErrorCode_NONE"
.constant	k39	"CDataTable"
.constant	k40	"GetTableData"
.constant	k41	202
.constant	k42	60
.constant	k43	182
.constant	k44	210
.constant	k45	"res_id"
.constant	k46	"ItemSubType"
.constant	k47	2101
.constant	k48	2102
.constant	k49	2197
.constant	k50	"LocUtil"
.constant	k51	"LocalizeResFormat"
.constant	k52	186
.constant	k53	113
.constant	k54	226
.constant	k55	143
.constant	k56	37
.constant	k57	1
.constant	k58	52
.constant	k59	"ItemName"
.constant	k60	"ShowNotice"
.constant	k61	"IsActiveSubType"
.constant	k62	"table"
.constant	k63	"concat"
.constant	k64	255
.constant	k65	97
.constant	k66	89
.constant	k67	171
.constant	k68	176
.constant	k69	224
.constant	k70	85
.constant	k71	70
.constant	k72	39
.constant	k73	140
.constant	k74	214
.constant	k75	50
.constant	k76	88
.constant	k77	163
.constant	k78	245
.constant	k79	49
.constant	k80	237
.constant	k81	101
.constant	k82	47
.constant	k83	23
.constant	k84	231
.constant	k85	194
.constant	k86	0
.constant	k87	19
.constant	k88	62
.constant	k89	247
.constant	k90	43
.constant	k91	188
.constant	k92	"ItemType"
.constant	k93	800
.constant	k94	8001
.constant	k95	29629
.constant	k96	"ENUM_ITEM_TYPE"
.constant	k97	"Item_Card"
.constant	k98	2110
.constant	k99	"choice_id"
.constant	k100	"expire_ts"
.constant	k101	"valid_hours"
.constant	k102	"choice_hours"
.constant	k103	"count"
.constant	k104	"choice_count"
.constant	k105	"insert"
.constant	k106	"require"
.constant	k107	218
.constant	k108	122
.constant	k109	68
.constant	k110	146
.constant	k111	235
.constant	k112	220
.constant	k113	46
.constant	k114	82
.constant	k115	242
.constant	k116	136
.constant	k117	16
.constant	k118	86
.constant	k119	192
.constant	k120	137
.constant	k121	109
.constant	k122	25
.constant	k123	191
.constant	k124	185
.constant	k125	228
.constant	k126	125
.constant	k127	67
.constant	k128	145
.constant	k129	31
.constant	k130	222
.constant	k131	216
.constant	k132	72
.constant	k133	141
.constant	k134	236
.constant	k135	75
.constant	k136	115
.constant	k137	73
.constant	k138	74
.constant	k139	248
.constant	k140	130
.constant	k141	22
.constant	k142	12
.constant	k143	"ShowPanel_DefaultStyle"
.constant	k144	"ModuleManager"
.constant	k145	"GetModule"
.constant	k146	"LobbyModuleConfig"
.constant	k147	"logic_challenge_add_score_card"
.constant	k148	"ShowChallengeCardTips"
.constant	k149	"EventSystem"
.constant	k150	"postEvent"
.constant	k151	"EVENTTYPE_WARDROBE"
.constant	k152	"EVENTID_WARDROBE_ITEM_USED"
.constant	k153	9910101

.line	1087	gettabup      r4    u0    k0 ; k0 = "log"
.line	1087	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1087	test          r5     0
.line	1087	jmp            0   l48
.line	1087	getupval      r5    u1
.line	1087	loadk         r6    k2 ; k2 = 212
.line	1087	loadk         r7    k3 ; k3 = 41
.line	1087	loadk         r8    k4 ; k4 = 161
.line	1087	loadk         r9    k5 ; k5 = 219
.line	1087	loadk        r10    k6 ; k6 = 102
.line	1087	loadk        r11    k7 ; k7 = 95
.line	1087	loadk        r12    k8 ; k8 = 100
.line	1087	loadk        r13    k9 ; k9 = 132
.line	1087	loadk        r14   k10 ; k10 = 203
.line	1087	loadk        r15   k11 ; k11 = 198
.line	1087	loadk        r16   k12 ; k12 = 252
.line	1087	loadk        r17   k13 ; k13 = 105
.line	1087	loadk        r18   k14 ; k14 = 93
.line	1087	loadk        r19   k15 ; k15 = 167
.line	1087	loadk        r20   k16 ; k16 = 128
.line	1087	loadk        r21   k17 ; k17 = 40
.line	1087	loadk        r22   k18 ; k18 = 44
.line	1087	loadk        r23   k19 ; k19 = 13
.line	1087	loadk        r24   k20 ; k20 = 208
.line	1087	loadk        r25   k21 ; k21 = 234
.line	1087	loadk        r26   k22 ; k22 = 187
.line	1087	loadk        r27   k13 ; k13 = 105
.line	1087	loadk        r28   k23 ; k23 = 2
.line	1087	loadk        r29   k24 ; k24 = 180
.line	1087	loadk        r30   k25 ; k25 = 250
.line	1087	loadk        r31   k26 ; k26 = 230
.line	1087	loadk        r32   k27 ; k27 = 249
.line	1087	loadk        r33   k28 ; k28 = 99
.line	1087	loadk        r34   k29 ; k29 = 94
.line	1087	loadk        r35    k4 ; k4 = 161
.line	1087	loadk        r36   k30 ; k30 = 223
.line	1087	loadk        r37   k31 ; k31 = 36
.line	1087	loadk        r38   k32 ; k32 = 6
.line	1087	loadk        r39   k33 ; k33 = 27
.line	1087	loadk        r40   k34 ; k34 = 147
.line	1087	loadk        r41   k35 ; k35 = 162
.line	1087	loadk        r42    k2 ; k2 = 212
.line	1087	call          r5    38     2
.line	1087	gettabup      r6    u0   k36 ; k36 = "tostring"
.line	1087	move          r7    r1
.line	1087	call          r6     2     2
.line	1087	concat        r5    r5    r6
.label	l48
.line	1087	call          r4     2     1
.line	1087	gettabup      r4    u0   k37 ; k37 = "log_tree"
.line	1087	getupval      r5    u1
.line	1087	loadk         r6    k2 ; k2 = 212
.line	1087	loadk         r7    k3 ; k3 = 41
.line	1087	loadk         r8    k4 ; k4 = 161
.line	1087	loadk         r9    k5 ; k5 = 219
.line	1087	loadk        r10    k6 ; k6 = 102
.line	1087	loadk        r11    k7 ; k7 = 95
.line	1087	loadk        r12    k8 ; k8 = 100
.line	1087	loadk        r13    k9 ; k9 = 132
.line	1087	loadk        r14   k10 ; k10 = 203
.line	1087	loadk        r15   k11 ; k11 = 198
.line	1087	loadk        r16   k12 ; k12 = 252
.line	1087	loadk        r17   k13 ; k13 = 105
.line	1087	loadk        r18   k14 ; k14 = 93
.line	1087	loadk        r19   k15 ; k15 = 167
.line	1087	loadk        r20   k16 ; k16 = 128
.line	1087	loadk        r21   k17 ; k17 = 40
.line	1087	loadk        r22   k18 ; k18 = 44
.line	1087	loadk        r23   k19 ; k19 = 13
.line	1087	loadk        r24   k20 ; k20 = 208
.line	1087	loadk        r25   k21 ; k21 = 234
.line	1087	loadk        r26   k22 ; k22 = 187
.line	1087	loadk        r27   k13 ; k13 = 105
.line	1087	loadk        r28   k23 ; k23 = 2
.line	1087	loadk        r29   k24 ; k24 = 180
.line	1087	loadk        r30   k25 ; k25 = 250
.line	1087	loadk        r31   k26 ; k26 = 230
.line	1087	loadk        r32   k27 ; k27 = 249
.line	1087	loadk        r33   k28 ; k28 = 99
.line	1087	loadk        r34   k29 ; k29 = 94
.line	1087	call          r5    30     2
.line	1087	move          r6    r3
.line	1087	call          r4     3     1
.line	1087	gettabup      r4    u0   k38 ; k38 = "NetErrorCode_NONE"
.line	1087	eq             0    r1    r4
.line	1087	jmp            0  l308
.line	1087	gettabup      r4    u0   k39 ; k39 = "CDataTable"
.line	1087	gettable      r4    r4   k40 ; k40 = "GetTableData"
.line	1087	getupval      r5    u1
.line	1087	loadk         r6   k41 ; k41 = 202
.line	1087	loadk         r7   k42 ; k42 = 60
.line	1087	loadk         r8   k43 ; k43 = 182
.line	1087	loadk         r9   k44 ; k44 = 210
.line	1087	call          r5     5     2
.line	1087	gettable      r6    r2   k45 ; k45 = "res_id"
.line	1087	call          r4     3     2
.line	1087	test          r4     0
.line	1087	jmp            0  l292
.line	1087	gettable      r5    r4   k46 ; k46 = "ItemSubType"
.line	1087	eq             1    r5   k47 ; k47 = 2101
.line	1087	jmp            0  l107
.line	1087	gettable      r5    r4   k46 ; k46 = "ItemSubType"
.line	1087	eq             1    r5   k48 ; k48 = 2102
.line	1087	jmp            0  l107
.line	1087	gettable      r5    r4   k46 ; k46 = "ItemSubType"
.line	1087	eq             0    r5   k49 ; k49 = 2197
.line	1087	jmp            0  l124
.label	l107
.line	1087	gettabup      r5    u0   k50 ; k50 = "LocUtil"
.line	1087	gettable      r5    r5   k51 ; k51 = "LocalizeResFormat"
.line	1087	getupval      r6    u1
.line	1087	loadk         r7   k52 ; k52 = 186
.line	1087	loadk         r8   k53 ; k53 = 113
.line	1087	loadk         r9   k54 ; k54 = 226
.line	1087	loadk        r10   k55 ; k55 = 143
.line	1087	loadk        r11   k56 ; k56 = 37
.line	1087	loadk        r12   k57 ; k57 = 1
.line	1087	loadk        r13   k58 ; k58 = 52
.line	1087	call          r6     8     2
.line	1087	gettable      r7    r4   k59 ; k59 = "ItemName"
.line	1087	call          r5     3     2
.line	1087	gettabup      r6    u0   k60 ; k60 = "ShowNotice"
.line	1087	move          r7    r5
.line	1087	call          r6     2     1
.line	1087	jmp            0  l187
.label	l124
.line	1087	getupval      r5    u2
.line	1087	self          r5    r5   k61 ; k61 = "IsActiveSubType"
.line	1087	gettable      r7    r4   k46 ; k46 = "ItemSubType"
.line	1087	call          r5     3     2
.line	1087	test          r5     0
.line	1087	jmp            0  l187
.line	1087	gettabup      r5    u0   k62 ; k62 = "table"
.line	1087	gettable      r5    r5   k63 ; k63 = "concat"
.line	1087	newtable      r6     1     0
.line	1087	getupval      r7    u1
.line	1087	loadk         r8    k6 ; k6 = 102
.line	1087	loadk         r9   k64 ; k64 = 255
.line	1087	loadk        r10   k65 ; k65 = 97
.line	1087	loadk        r11   k66 ; k66 = 89
.line	1087	loadk        r12   k67 ; k67 = 171
.line	1087	loadk        r13   k68 ; k68 = 176
.line	1087	loadk        r14   k69 ; k69 = 224
.line	1087	loadk        r15   k70 ; k70 = 85
.line	1087	loadk        r16   k42 ; k42 = 60
.line	1087	loadk        r17   k71 ; k71 = 70
.line	1087	loadk        r18   k72 ; k72 = 39
.line	1087	loadk        r19   k73 ; k73 = 140
.line	1087	loadk        r20   k74 ; k74 = 214
.line	1087	loadk        r21   k75 ; k75 = 50
.line	1087	loadk        r22   k76 ; k76 = 88
.line	1087	loadk        r23   k77 ; k77 = 163
.line	1087	loadk        r24   k25 ; k25 = 250
.line	1087	loadk        r25   k78 ; k78 = 245
.line	1087	loadk        r26   k71 ; k71 = 70
.line	1087	loadk        r27   k79 ; k79 = 49
.line	1087	loadk        r28    k8 ; k8 = 100
.line	1087	loadk        r29   k26 ; k26 = 230
.line	1087	loadk        r30   k80 ; k80 = 237
.line	1087	loadk        r31   k81 ; k81 = 101
.line	1087	loadk        r32   k53 ; k53 = 113
.line	1087	loadk        r33   k58 ; k58 = 52
.line	1087	loadk        r34    k3 ; k3 = 41
.line	1087	loadk        r35   k78 ; k78 = 245
.line	1087	loadk        r36   k34 ; k34 = 147
.line	1087	loadk        r37   k82 ; k82 = 47
.line	1087	loadk        r38   k83 ; k83 = 23
.line	1087	loadk        r39   k84 ; k84 = 231
.line	1087	loadk        r40   k85 ; k85 = 194
.line	1087	loadk        r41   k55 ; k55 = 143
.line	1087	loadk        r42   k86 ; k86 = 0
.line	1087	loadk        r43   k31 ; k31 = 36
.line	1087	loadk        r44   k87 ; k87 = 19
.line	1087	loadk        r45   k67 ; k67 = 171
.line	1087	loadk        r46   k27 ; k27 = 249
.line	1087	loadk        r47   k56 ; k56 = 37
.line	1087	call          r7    41     2
.line	1087	getupval      r8    u1
.line	1087	loadk         r9   k88 ; k88 = 62
.line	1087	loadk        r10   k89 ; k89 = 247
.line	1087	loadk        r11   k58 ; k58 = 52
.line	1087	loadk        r12   k90 ; k90 = 43
.line	1087	loadk        r13   k91 ; k91 = 188
.line	1087	call          r8     6     0
.line	1087	setlist       r6     0     1
.line	1087	call          r5     2     2
.line	1087	gettabup      r6    u0   k60 ; k60 = "ShowNotice"
.line	1087	move          r7    r5
.line	1087	call          r6     2     1
.label	l187
.line	1087	gettable      r5    r4   k92 ; k92 = "ItemType"
.line	1087	eq             0    r5   k93 ; k93 = 800
.line	1087	jmp            0  l196
.line	1087	gettable      r5    r4   k46 ; k46 = "ItemSubType"
.line	1087	eq             0    r5   k94 ; k94 = 8001
.line	1087	jmp            0  l196
.line	1087	gettabup      r5    u0   k60 ; k60 = "ShowNotice"
.line	1087	loadk         r6   k95 ; k95 = 29629
.line	1087	call          r5     2     1
.label	l196
.line	1087	gettable      r5    r4   k92 ; k92 = "ItemType"
.line	1087	gettabup      r6    u0   k96 ; k96 = "ENUM_ITEM_TYPE"
.line	1087	gettable      r6    r6   k97 ; k97 = "Item_Card"
.line	1087	eq             0    r5    r6
.line	1087	jmp            0  l292
.line	1087	gettable      r5    r4   k46 ; k46 = "ItemSubType"
.line	1087	eq             0    r5   k98 ; k98 = 2110
.line	1087	jmp            0  l292
.line	1087	test          r3     0
.line	1087	jmp            0  l292
.line	1087	newtable      r5     0     0
.line	1087	newtable      r6     0     0
.line	1087	gettable      r7    r3   k99 ; k99 = "choice_id"
.line	1087	settable      r6   k45    r7 ; k45 = "res_id"
.line	1087	settable      r6  k100   k86 ; k86 = 0
.line	1087	gettable      r7    r3  k102 ; k102 = "choice_hours"
.line	1087	settable      r6  k101    r7 ; k101 = "valid_hours"
.line	1087	gettable      r7    r3  k104 ; k104 = "choice_count"
.line	1087	settable      r6  k103    r7 ; k103 = "count"
.line	1087	gettabup      r7    u0   k62 ; k62 = "table"
.line	1087	gettable      r7    r7  k105 ; k105 = "insert"
.line	1087	move          r8    r5
.line	1087	move          r9    r6
.line	1087	call          r7     3     1
.line	1087	gettabup      r7    u0  k106 ; k106 = "require"
.line	1087	gettabup      r8    u0   k62 ; k62 = "table"
.line	1087	gettable      r8    r8   k63 ; k63 = "concat"
.line	1087	newtable      r9     1     0
.line	1087	getupval     r10    u1
.line	1087	loadk        r11   k69 ; k69 = 224
.line	1087	loadk        r12   k31 ; k31 = 36
.line	1087	loadk        r13   k52 ; k52 = 186
.line	1087	loadk        r14  k107 ; k107 = 218
.line	1087	loadk        r15  k108 ; k108 = 122
.line	1087	loadk        r16  k109 ; k109 = 68
.line	1087	loadk        r17   k17 ; k17 = 40
.line	1087	loadk        r18  k110 ; k110 = 146
.line	1087	loadk        r19  k111 ; k111 = 235
.line	1087	loadk        r20  k112 ; k112 = 220
.line	1087	loadk        r21   k25 ; k25 = 250
.line	1087	loadk        r22  k113 ; k113 = 46
.line	1087	loadk        r23  k114 ; k114 = 82
.line	1087	loadk        r24  k115 ; k115 = 242
.line	1087	loadk        r25  k116 ; k116 = 136
.line	1087	loadk        r26   k82 ; k82 = 47
.line	1087	loadk        r27  k117 ; k117 = 16
.line	1087	loadk        r28  k118 ; k118 = 86
.line	1087	loadk        r29  k119 ; k119 = 192
.line	1087	loadk        r30   k69 ; k69 = 224
.line	1087	loadk        r31  k120 ; k120 = 137
.line	1087	loadk        r32  k121 ; k121 = 109
.line	1087	loadk        r33  k122 ; k122 = 25
.line	1087	loadk        r34  k123 ; k123 = 191
.line	1087	loadk        r35  k124 ; k124 = 185
.line	1087	loadk        r36   k25 ; k25 = 250
.line	1087	loadk        r37  k125 ; k125 = 228
.line	1087	loadk        r38  k126 ; k126 = 125
.line	1087	loadk        r39  k127 ; k127 = 67
.line	1087	loadk        r40   k54 ; k54 = 226
.line	1087	loadk        r41  k128 ; k128 = 145
.line	1087	loadk        r42  k129 ; k129 = 31
.line	1087	loadk        r43   k83 ; k83 = 23
.line	1087	loadk        r44   k19 ; k19 = 13
.line	1087	loadk        r45  k130 ; k130 = 222
.line	1087	loadk        r46  k131 ; k131 = 216
.line	1087	loadk        r47  k128 ; k128 = 145
.line	1087	loadk        r48    k8 ; k8 = 100
.line	1087	loadk        r49  k132 ; k132 = 72
.line	1087	loadk        r50  k133 ; k133 = 141
.line	1087	call         r10    41     2
.line	1087	getupval     r11    u1
.line	1087	loadk        r12  k134 ; k134 = 236
.line	1087	loadk        r13   k82 ; k82 = 47
.line	1087	loadk        r14   k52 ; k52 = 186
.line	1087	loadk        r15  k112 ; k112 = 220
.line	1087	loadk        r16  k135 ; k135 = 75
.line	1087	loadk        r17  k136 ; k136 = 115
.line	1087	loadk        r18   k13 ; k13 = 105
.line	1087	loadk        r19   k73 ; k73 = 140
.line	1087	loadk        r20   k21 ; k21 = 234
.line	1087	loadk        r21   k11 ; k11 = 198
.line	1087	loadk        r22   k78 ; k78 = 245
.line	1087	loadk        r23  k137 ; k137 = 73
.line	1087	loadk        r24  k138 ; k138 = 74
.line	1087	loadk        r25  k139 ; k139 = 248
.line	1087	loadk        r26  k140 ; k140 = 130
.line	1087	loadk        r27   k57 ; k57 = 1
.line	1087	loadk        r28  k141 ; k141 = 22
.line	1087	loadk        r29  k142 ; k142 = 12
.line	1087	call         r11    19     0
.line	1087	setlist       r9     0     1
.line	1087	call          r8     2     2
.line	1087	call          r7     2     2
.line	1087	gettable      r8    r7  k143 ; k143 = "ShowPanel_DefaultSty" (truncated)
.line	1087	move          r9    r5
.line	1087	call          r8     2     1
.label	l292
.line	1087	gettabup      r5    u0  k144 ; k144 = "ModuleManager"
.line	1087	gettable      r5    r5  k145 ; k145 = "GetModule"
.line	1087	gettabup      r6    u0  k144 ; k144 = "ModuleManager"
.line	1087	gettable      r6    r6  k146 ; k146 = "LobbyModuleConfig"
.line	1087	gettable      r6    r6  k147 ; k147 = "logic_challenge_add_" (truncated)
.line	1087	call          r5     2     2
.line	1087	self          r6    r5  k148 ; k148 = "ShowChallengeCardTip" (truncated)
.line	1087	gettable      r8    r2   k45 ; k45 = "res_id"
.line	1087	call          r6     3     1
.line	1087	gettabup      r6    u0  k149 ; k149 = "EventSystem"
.line	1087	self          r6    r6  k150 ; k150 = "postEvent"
.line	1087	gettabup      r8    u0  k151 ; k151 = "EVENTTYPE_WARDROBE"
.line	1087	gettabup      r9    u0  k152 ; k152 = "EVENTID_WARDROBE_ITE" (truncated)
.line	1087	move         r10    r2
.line	1087	call          r6     5     1
.line	1087	jmp            0  l313
.label	l308
.line	1087	gettabup      r4    u0   k60 ; k60 = "ShowNotice"
.line	1087	move          r5    r1
.line	1087	call          r4     2     1
.line	1087	eq             0    r1  k153 ; k153 = 9910101
.line	1087	jmp            0  l313
.label	l313
.line	1087	return        r0     1
.line	1087	move          r0    r0
.line	1087	move          r0    r0
.line	1087	move          r0    r0
.line	1087	return        r0     1

.function	main/f51

.source	null
.linedefined	1125
.lastlinedefined	1168
.numparams	3
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	241
.constant	k15	128
.constant	k16	17
.constant	k17	1
.constant	k18	231
.constant	k19	133
.constant	k20	108
.constant	k21	26
.constant	k22	142
.constant	k23	227
.constant	k24	209
.constant	k25	238
.constant	k26	125
.constant	k27	75
.constant	k28	210
.constant	k29	138
.constant	k30	34
.constant	k31	10
.constant	k32	4
.constant	k33	192
.constant	k34	0
.constant	k35	179
.constant	k36	"log"
.constant	k37	"bWriteLog"
.constant	k38	45
.constant	k39	163
.constant	k40	208
.constant	k41	96
.constant	k42	111
.constant	k43	117
.constant	k44	132
.constant	k45	243
.constant	k46	246
.constant	k47	107
.constant	k48	87
.constant	k49	176
.constant	k50	47
.constant	k51	29
.constant	k52	30
.constant	k53	204
.constant	k54	150
.constant	k55	115
.constant	k56	6
.constant	k57	228
.constant	k58	254
.constant	k59	140
.constant	k60	"log_tree"
.constant	k61	240
.constant	k62	35
.constant	k63	89
.constant	k64	104
.constant	k65	135
.constant	k66	"table"
.constant	k67	"concat"
.constant	k68	146
.constant	k69	235
.constant	k70	220
.constant	k71	250
.constant	k72	46
.constant	k73	82
.constant	k74	136
.constant	k75	86
.constant	k76	212
.constant	k77	100
.constant	k78	190
.constant	k79	245
.constant	k80	165
.constant	k81	118
.constant	k82	79
.constant	k83	151
.constant	k84	63
.constant	k85	12
.constant	k86	147
.constant	k87	62
.constant	k88	160
.constant	k89	32
.constant	k90	103
.constant	k91	134
.constant	k92	216
.constant	k93	205
.constant	k94	116
.constant	k95	95
.constant	k96	"SetBagLevel"
.constant	k97	"bag_level"
.constant	k98	"SetHelmetLevel"
.constant	k99	"helmet_level"
.constant	k100	"ProcSetSkinInfo"
.constant	k101	"DataMgr"
.constant	k102	"GetBagLevel"
.constant	k103	"GetHelmetLevel"
.constant	k104	25
.constant	k105	20
.constant	k106	180
.constant	k107	185
.constant	k108	234
.constant	k109	98
.constant	k110	74
.constant	k111	255
.constant	k112	144
.constant	k113	52
.constant	k114	55
.constant	k115	222
.constant	k116	9
.constant	k117	nil
.constant	k118	"GetBindRelation"
.constant	k119	"CONST_RELATION_TYPE"
.constant	k120	"BAG"
.constant	k121	"GetBagSkinByLevel"
.constant	k122	"SetBagSkin"
.constant	k123	"UpdateEquipmentSkin"
.constant	k124	"ENUM_ITEM_SUBTYPE"
.constant	k125	"Backpack"
.constant	k126	"EventSystem"
.constant	k127	"postEvent"
.constant	k128	"EVENTTYPE_WARDROBE"
.constant	k129	"EVENTID_WARDROBE_REFRESH_EQUIPMENT_LEVEL"
.constant	k130	"UpdateSkinInfo"
.constant	k131	"HELMET"
.constant	k132	"GetHelmetSkinByLevel"
.constant	k133	"SetHelmetSkin"
.constant	k134	"Helmet_NoLevel"
.constant	k135	"CONST_RELATION_OP_TYPE"
.constant	k136	"UNBIND"
.constant	k137	"SetHeadShow"
.constant	k138	143
.constant	k139	226
.constant	k140	221
.constant	k141	236
.constant	k142	76
.constant	k143	193
.constant	k144	22
.constant	k145	23
.constant	k146	215
.constant	k147	249
.constant	k148	124
.constant	k149	157
.constant	k150	51
.constant	k151	43
.constant	k152	251
.constant	k153	152
.constant	k154	"send_depot_set_head_show_req"
.constant	k155	230
.constant	k156	58
.constant	k157	161
.constant	k158	102
.constant	k159	105
.constant	k160	137
.constant	k161	167
.constant	k162	207

.line	1125	gettabup      r3    u0    k0 ; k0 = "require"
.line	1125	getupval      r4    u1
.line	1125	loadk         r5    k1 ; k1 = 224
.line	1125	loadk         r6    k2 ; k2 = 36
.line	1125	loadk         r7    k3 ; k3 = 186
.line	1125	loadk         r8    k4 ; k4 = 218
.line	1125	loadk         r9    k5 ; k5 = 122
.line	1125	loadk        r10    k6 ; k6 = 68
.line	1125	loadk        r11    k7 ; k7 = 40
.line	1125	loadk        r12    k8 ; k8 = 141
.line	1125	loadk        r13    k9 ; k9 = 232
.line	1125	loadk        r14   k10 ; k10 = 206
.line	1125	loadk        r15   k11 ; k11 = 242
.line	1125	loadk        r16   k12 ; k12 = 99
.line	1125	loadk        r17   k13 ; k13 = 16
.line	1125	loadk        r18   k14 ; k14 = 241
.line	1125	loadk        r19   k15 ; k15 = 128
.line	1125	loadk        r20    k2 ; k2 = 36
.line	1125	loadk        r21   k16 ; k16 = 17
.line	1125	loadk        r22   k17 ; k17 = 1
.line	1125	loadk        r23    k8 ; k8 = 141
.line	1125	loadk        r24   k18 ; k18 = 231
.line	1125	loadk        r25   k19 ; k19 = 133
.line	1125	loadk        r26   k20 ; k20 = 108
.line	1125	loadk        r27   k21 ; k21 = 26
.line	1125	loadk        r28   k22 ; k22 = 142
.line	1125	loadk        r29   k23 ; k23 = 227
.line	1125	loadk        r30   k24 ; k24 = 209
.line	1125	loadk        r31   k25 ; k25 = 238
.line	1125	loadk        r32   k26 ; k26 = 125
.line	1125	loadk        r33   k27 ; k27 = 75
.line	1125	loadk        r34   k28 ; k28 = 210
.line	1125	loadk        r35   k29 ; k29 = 138
.line	1125	loadk        r36   k30 ; k30 = 34
.line	1125	loadk        r37   k31 ; k31 = 10
.line	1125	loadk        r38   k32 ; k32 = 4
.line	1125	loadk        r39   k33 ; k33 = 192
.line	1125	call          r4    36     2
.line	1125	call          r3     2     2
.line	1125	eq             1    r1   k34 ; k34 = 0
.line	1125	jmp            0   l47
.line	1125	getupval      r4    u1
.line	1125	loadk         r5   k35 ; k35 = 179
.line	1125	call          r4     2     2
.line	1125	eq             0    r1    r4
.line	1125	jmp            0  l358
.label	l47
.line	1125	gettabup      r4    u0   k36 ; k36 = "log"
.line	1125	gettabup      r5    u0   k37 ; k37 = "bWriteLog"
.line	1125	test          r5     0
.line	1125	jmp            0   l84
.line	1125	getupval      r5    u1
.line	1125	loadk         r6   k18 ; k18 = 231
.line	1125	loadk         r7   k38 ; k38 = 45
.line	1125	loadk         r8   k39 ; k39 = 163
.line	1125	loadk         r9   k40 ; k40 = 208
.line	1125	loadk        r10   k41 ; k41 = 96
.line	1125	loadk        r11   k42 ; k42 = 111
.line	1125	loadk        r12   k43 ; k43 = 117
.line	1125	loadk        r13   k44 ; k44 = 132
.line	1125	loadk        r14   k45 ; k45 = 243
.line	1125	loadk        r15   k46 ; k46 = 246
.line	1125	loadk        r16    k9 ; k9 = 232
.line	1125	loadk        r17   k47 ; k47 = 107
.line	1125	loadk        r18   k48 ; k48 = 87
.line	1125	loadk        r19   k45 ; k45 = 243
.line	1125	loadk        r20   k49 ; k49 = 176
.line	1125	loadk        r21   k50 ; k50 = 47
.line	1125	loadk        r22   k51 ; k51 = 29
.line	1125	loadk        r23   k52 ; k52 = 30
.line	1125	loadk        r24   k53 ; k53 = 204
.line	1125	loadk        r25   k40 ; k40 = 208
.line	1125	loadk        r26   k54 ; k54 = 150
.line	1125	loadk        r27   k55 ; k55 = 115
.line	1125	loadk        r28   k56 ; k56 = 6
.line	1125	loadk        r29   k14 ; k14 = 241
.line	1125	loadk        r30   k57 ; k57 = 228
.line	1125	loadk        r31   k53 ; k53 = 204
.line	1125	loadk        r32    k9 ; k9 = 232
.line	1125	loadk        r33   k55 ; k55 = 115
.line	1125	loadk        r34   k27 ; k27 = 75
.line	1125	loadk        r35   k58 ; k58 = 254
.line	1125	loadk        r36   k59 ; k59 = 140
.line	1125	call          r5    32     2
.label	l84
.line	1125	call          r4     2     1
.line	1125	gettabup      r4    u0   k60 ; k60 = "log_tree"
.line	1125	getupval      r5    u1
.line	1125	loadk         r6   k61 ; k61 = 240
.line	1125	loadk         r7   k62 ; k62 = 35
.line	1125	loadk         r8    k3 ; k3 = 186
.line	1125	loadk         r9   k24 ; k24 = 209
.line	1125	loadk        r10   k27 ; k27 = 75
.line	1125	loadk        r11   k63 ; k63 = 89
.line	1125	loadk        r12   k64 ; k64 = 104
.line	1125	loadk        r13   k65 ; k65 = 135
.line	1125	loadk        r14    k9 ; k9 = 232
.line	1125	call          r5    10     2
.line	1125	move          r6    r2
.line	1125	call          r4     3     1
.line	1125	gettabup      r4    u0    k0 ; k0 = "require"
.line	1125	gettabup      r5    u0   k66 ; k66 = "table"
.line	1125	gettable      r5    r5   k67 ; k67 = "concat"
.line	1125	newtable      r6     1     0
.line	1125	getupval      r7    u1
.line	1125	loadk         r8    k1 ; k1 = 224
.line	1125	loadk         r9    k2 ; k2 = 36
.line	1125	loadk        r10    k3 ; k3 = 186
.line	1125	loadk        r11    k4 ; k4 = 218
.line	1125	loadk        r12    k5 ; k5 = 122
.line	1125	loadk        r13    k6 ; k6 = 68
.line	1125	loadk        r14    k7 ; k7 = 40
.line	1125	loadk        r15   k68 ; k68 = 146
.line	1125	loadk        r16   k69 ; k69 = 235
.line	1125	loadk        r17   k70 ; k70 = 220
.line	1125	loadk        r18   k71 ; k71 = 250
.line	1125	loadk        r19   k72 ; k72 = 46
.line	1125	loadk        r20   k73 ; k73 = 82
.line	1125	loadk        r21   k11 ; k11 = 242
.line	1125	loadk        r22   k74 ; k74 = 136
.line	1125	loadk        r23   k50 ; k50 = 47
.line	1125	loadk        r24   k13 ; k13 = 16
.line	1125	loadk        r25   k75 ; k75 = 86
.line	1125	loadk        r26   k76 ; k76 = 212
.line	1125	loadk        r27   k25 ; k25 = 238
.line	1125	loadk        r28   k54 ; k54 = 150
.line	1125	loadk        r29   k77 ; k77 = 100
.line	1125	loadk        r30   k32 ; k32 = 4
.line	1125	loadk        r31   k78 ; k78 = 190
.line	1125	loadk        r32   k79 ; k79 = 245
.line	1125	loadk        r33   k70 ; k70 = 220
.line	1125	loadk        r34   k80 ; k80 = 165
.line	1125	loadk        r35   k81 ; k81 = 118
.line	1125	loadk        r36   k82 ; k82 = 79
.line	1125	loadk        r37   k58 ; k58 = 254
.line	1125	loadk        r38   k83 ; k83 = 151
.line	1125	loadk        r39   k84 ; k84 = 63
.line	1125	loadk        r40   k85 ; k85 = 12
.line	1125	loadk        r41   k56 ; k56 = 6
.line	1125	loadk        r42   k24 ; k24 = 209
.line	1125	loadk        r43   k58 ; k58 = 254
.line	1125	loadk        r44   k86 ; k86 = 147
.line	1125	loadk        r45   k87 ; k87 = 62
.line	1125	loadk        r46   k34 ; k34 = 0
.line	1125	loadk        r47   k88 ; k88 = 160
.line	1125	call          r7    41     2
.line	1125	getupval      r8    u1
.line	1125	loadk         r9   k61 ; k61 = 240
.line	1125	loadk        r10   k89 ; k89 = 32
.line	1125	loadk        r11    k3 ; k3 = 186
.line	1125	loadk        r12   k40 ; k40 = 208
.line	1125	loadk        r13    k5 ; k5 = 122
.line	1125	loadk        r14   k73 ; k73 = 82
.line	1125	loadk        r15   k90 ; k90 = 103
.line	1125	loadk        r16   k91 ; k91 = 134
.line	1125	loadk        r17   k92 ; k92 = 216
.line	1125	loadk        r18   k93 ; k93 = 205
.line	1125	loadk        r19   k71 ; k71 = 250
.line	1125	loadk        r20   k94 ; k94 = 116
.line	1125	loadk        r21   k95 ; k95 = 95
.line	1125	call          r8    14     0
.line	1125	setlist       r6     0     1
.line	1125	call          r5     2     2
.line	1125	call          r4     2     2
.line	1125	self          r5    r4   k96 ; k96 = "SetBagLevel"
.line	1125	gettable      r7    r2   k97 ; k97 = "bag_level"
.line	1125	call          r5     3     1
.line	1125	self          r5    r4   k98 ; k98 = "SetHelmetLevel"
.line	1125	gettable      r7    r2   k99 ; k99 = "helmet_level"
.line	1125	call          r5     3     1
.line	1125	gettable      r5    r3  k100 ; k100 = "ProcSetSkinInfo"
.line	1125	move          r6    r2
.line	1125	call          r5     2     1
.line	1125	gettabup      r5    u0  k101 ; k101 = "DataMgr"
.line	1125	self          r6    r4  k102 ; k102 = "GetBagLevel"
.line	1125	call          r6     2     2
.line	1125	test          r6     1
.line	1125	jmp            0  l179
.line	1125	gettabup      r6    u0  k101 ; k101 = "DataMgr"
.line	1125	gettable      r6    r6   k97 ; k97 = "bag_level"
.label	l179
.line	1125	settable      r5   k97    r6 ; k97 = "bag_level"
.line	1125	gettabup      r5    u0  k101 ; k101 = "DataMgr"
.line	1125	self          r6    r4  k103 ; k103 = "GetHelmetLevel"
.line	1125	call          r6     2     2
.line	1125	test          r6     1
.line	1125	jmp            0  l187
.line	1125	gettabup      r6    u0  k101 ; k101 = "DataMgr"
.line	1125	gettable      r6    r6   k99 ; k99 = "helmet_level"
.label	l187
.line	1125	settable      r5   k99    r6 ; k99 = "helmet_level"
.line	1125	gettabup      r5    u0    k0 ; k0 = "require"
.line	1125	getupval      r6    u1
.line	1125	loadk         r7    k1 ; k1 = 224
.line	1125	loadk         r8    k2 ; k2 = 36
.line	1125	loadk         r9    k3 ; k3 = 186
.line	1125	loadk        r10    k4 ; k4 = 218
.line	1125	loadk        r11    k5 ; k5 = 122
.line	1125	loadk        r12    k6 ; k6 = 68
.line	1125	loadk        r13    k7 ; k7 = 40
.line	1125	loadk        r14   k68 ; k68 = 146
.line	1125	loadk        r15   k69 ; k69 = 235
.line	1125	loadk        r16   k70 ; k70 = 220
.line	1125	loadk        r17   k71 ; k71 = 250
.line	1125	loadk        r18   k72 ; k72 = 46
.line	1125	loadk        r19   k27 ; k27 = 75
.line	1125	loadk        r20   k61 ; k61 = 240
.line	1125	loadk        r21   k74 ; k74 = 136
.line	1125	loadk        r22   k64 ; k64 = 104
.line	1125	loadk        r23    k2 ; k2 = 36
.line	1125	loadk        r24  k104 ; k104 = 25
.line	1125	loadk        r25   k24 ; k24 = 209
.line	1125	loadk        r26   k69 ; k69 = 235
.line	1125	loadk        r27   k54 ; k54 = 150
.line	1125	loadk        r28   k42 ; k42 = 111
.line	1125	loadk        r29  k105 ; k105 = 20
.line	1125	loadk        r30  k106 ; k106 = 180
.line	1125	loadk        r31  k107 ; k107 = 185
.line	1125	loadk        r32   k10 ; k10 = 206
.line	1125	loadk        r33  k108 ; k108 = 234
.line	1125	loadk        r34  k109 ; k109 = 98
.line	1125	loadk        r35  k110 ; k110 = 74
.line	1125	loadk        r36  k111 ; k111 = 255
.line	1125	loadk        r37  k112 ; k112 = 144
.line	1125	loadk        r38  k113 ; k113 = 52
.line	1125	loadk        r39   k56 ; k56 = 6
.line	1125	loadk        r40  k114 ; k114 = 55
.line	1125	loadk        r41  k115 ; k115 = 222
.line	1125	loadk        r42   k58 ; k58 = 254
.line	1125	loadk        r43   k83 ; k83 = 151
.line	1125	loadk        r44  k109 ; k109 = 98
.line	1125	loadk        r45  k116 ; k116 = 9
.line	1125	call          r6    40     2
.line	1125	call          r5     2     2
.line	1125	gettable      r6    r2   k97 ; k97 = "bag_level"
.line	1125	eq             1    r6  k117 ; k117 = nil
.line	1125	jmp            0  l262
.line	1125	gettable      r6    r3  k118 ; k118 = "GetBindRelation"
.line	1125	gettable      r7    r3  k119 ; k119 = "CONST_RELATION_TYPE"
.line	1125	gettable      r7    r7  k120 ; k120 = "BAG"
.line	1125	call          r6     2     2
.line	1125	test          r6     0
.line	1125	jmp            0  l258
.line	1125	self          r6    r4  k121 ; k121 = "GetBagSkinByLevel"
.line	1125	gettable      r8    r2   k97 ; k97 = "bag_level"
.line	1125	call          r6     3     2
.line	1125	self          r7    r4  k122 ; k122 = "SetBagSkin"
.line	1125	move          r9    r6
.line	1125	call          r7     3     1
.line	1125	gettabup      r7    u0  k101 ; k101 = "DataMgr"
.line	1125	gettable      r7    r7  k123 ; k123 = "UpdateEquipmentSkin"
.line	1125	gettabup      r8    u0  k124 ; k124 = "ENUM_ITEM_SUBTYPE"
.line	1125	gettable      r8    r8  k125 ; k125 = "Backpack"
.line	1125	move          r9    r6
.line	1125	call          r7     3     1
.line	1125	gettabup      r7    u0  k126 ; k126 = "EventSystem"
.line	1125	self          r7    r7  k127 ; k127 = "postEvent"
.line	1125	gettabup      r9    u0  k128 ; k128 = "EVENTTYPE_WARDROBE"
.line	1125	gettabup     r10    u0  k129 ; k129 = "EVENTID_WARDROBE_REF" (truncated)
.line	1125	call          r7     4     1
.line	1125	jmp            0  l262
.label	l258
.line	1125	self          r6    r0  k130 ; k130 = "UpdateSkinInfo"
.line	1125	gettabup      r8    u0  k124 ; k124 = "ENUM_ITEM_SUBTYPE"
.line	1125	gettable      r8    r8  k125 ; k125 = "Backpack"
.line	1125	call          r6     3     1
.label	l262
.line	1125	gettable      r6    r2   k99 ; k99 = "helmet_level"
.line	1125	eq             1    r6  k117 ; k117 = nil
.line	1125	jmp            0  l382
.line	1125	gettable      r6    r3  k118 ; k118 = "GetBindRelation"
.line	1125	gettable      r7    r3  k119 ; k119 = "CONST_RELATION_TYPE"
.line	1125	gettable      r7    r7  k131 ; k131 = "HELMET"
.line	1125	call          r6     2     2
.line	1125	test          r6     0
.line	1125	jmp            0  l289
.line	1125	self          r6    r4  k132 ; k132 = "GetHelmetSkinByLevel"
.line	1125	gettable      r8    r2   k99 ; k99 = "helmet_level"
.line	1125	call          r6     3     2
.line	1125	self          r7    r4  k133 ; k133 = "SetHelmetSkin"
.line	1125	move          r9    r6
.line	1125	call          r7     3     1
.line	1125	gettabup      r7    u0  k101 ; k101 = "DataMgr"
.line	1125	gettable      r7    r7  k123 ; k123 = "UpdateEquipmentSkin"
.line	1125	gettabup      r8    u0  k124 ; k124 = "ENUM_ITEM_SUBTYPE"
.line	1125	gettable      r8    r8  k134 ; k134 = "Helmet_NoLevel"
.line	1125	move          r9    r6
.line	1125	call          r7     3     1
.line	1125	gettabup      r7    u0  k126 ; k126 = "EventSystem"
.line	1125	self          r7    r7  k127 ; k127 = "postEvent"
.line	1125	gettabup      r9    u0  k128 ; k128 = "EVENTTYPE_WARDROBE"
.line	1125	gettabup     r10    u0  k129 ; k129 = "EVENTID_WARDROBE_REF" (truncated)
.line	1125	call          r7     4     1
.line	1125	jmp            0  l293
.label	l289
.line	1125	self          r6    r0  k130 ; k130 = "UpdateSkinInfo"
.line	1125	gettabup      r8    u0  k124 ; k124 = "ENUM_ITEM_SUBTYPE"
.line	1125	gettable      r8    r8  k134 ; k134 = "Helmet_NoLevel"
.line	1125	call          r6     3     1
.label	l293
.line	1125	gettable      r6    r3  k118 ; k118 = "GetBindRelation"
.line	1125	gettable      r7    r3  k119 ; k119 = "CONST_RELATION_TYPE"
.line	1125	gettable      r7    r7  k131 ; k131 = "HELMET"
.line	1125	call          r6     2     2
.line	1125	gettable      r7    r3  k135 ; k135 = "CONST_RELATION_OP_TY" (truncated)
.line	1125	gettable      r7    r7  k136 ; k136 = "UNBIND"
.line	1125	eq             0    r6    r7
.line	1125	jmp            0  l382
.line	1125	self          r6    r4  k132 ; k132 = "GetHelmetSkinByLevel"
.line	1125	gettable      r8    r2   k99 ; k99 = "helmet_level"
.line	1125	call          r6     3     2
.line	1125	test          r6     0
.line	1125	jmp            0  l382
.line	1125	eq             1    r6   k34 ; k34 = 0
.line	1125	jmp            0  l382
.line	1125	self          r7    r4  k137 ; k137 = "SetHeadShow"
.line	1125	move          r9    r6
.line	1125	call          r7     3     1
.line	1125	gettabup      r7    u0    k0 ; k0 = "require"
.line	1125	getupval      r8    u1
.line	1125	loadk         r9    k1 ; k1 = 224
.line	1125	loadk        r10    k2 ; k2 = 36
.line	1125	loadk        r11    k3 ; k3 = 186
.line	1125	loadk        r12    k4 ; k4 = 218
.line	1125	loadk        r13    k5 ; k5 = 122
.line	1125	loadk        r14    k6 ; k6 = 68
.line	1125	loadk        r15    k7 ; k7 = 40
.line	1125	loadk        r16  k138 ; k138 = 143
.line	1125	loadk        r17  k139 ; k139 = 226
.line	1125	loadk        r18  k140 ; k140 = 221
.line	1125	loadk        r19  k141 ; k141 = 236
.line	1125	loadk        r20   k42 ; k42 = 111
.line	1125	loadk        r21  k142 ; k142 = 76
.line	1125	loadk        r22   k46 ; k46 = 246
.line	1125	loadk        r23  k143 ; k143 = 193
.line	1125	loadk        r24  k144 ; k144 = 22
.line	1125	loadk        r25   k17 ; k17 = 1
.line	1125	loadk        r26  k145 ; k145 = 23
.line	1125	loadk        r27  k146 ; k146 = 215
.line	1125	loadk        r28    k1 ; k1 = 224
.line	1125	loadk        r29   k65 ; k65 = 135
.line	1125	loadk        r30   k42 ; k42 = 111
.line	1125	loadk        r31   k21 ; k21 = 26
.line	1125	loadk        r32  k111 ; k111 = 255
.line	1125	loadk        r33   k33 ; k33 = 192
.line	1125	loadk        r34   k92 ; k92 = 216
.line	1125	loadk        r35  k147 ; k147 = 249
.line	1125	loadk        r36   k94 ; k94 = 116
.line	1125	loadk        r37  k148 ; k148 = 124
.line	1125	loadk        r38  k139 ; k139 = 226
.line	1125	loadk        r39  k149 ; k149 = 157
.line	1125	loadk        r40  k150 ; k150 = 51
.line	1125	loadk        r41  k151 ; k151 = 43
.line	1125	loadk        r42  k116 ; k116 = 9
.line	1125	loadk        r43  k140 ; k140 = 221
.line	1125	loadk        r44  k152 ; k152 = 251
.line	1125	loadk        r45  k153 ; k153 = 152
.line	1125	loadk        r46   k43 ; k43 = 117
.line	1125	loadk        r47  k105 ; k105 = 20
.line	1125	call          r8    40     2
.line	1125	call          r7     2     2
.line	1125	gettable      r8    r7  k154 ; k154 = "send_depot_set_head_" (truncated)
.line	1125	move          r9    r6
.line	1125	call          r8     2     1
.line	1125	jmp            0  l382
.label	l358
.line	1125	gettabup      r4    u0   k36 ; k36 = "log"
.line	1125	gettabup      r5    u0   k37 ; k37 = "bWriteLog"
.line	1125	test          r5     0
.line	1125	jmp            0  l381
.line	1125	getupval      r5    u1
.line	1125	loadk         r6  k155 ; k155 = 230
.line	1125	loadk         r7  k156 ; k156 = 58
.line	1125	loadk         r8  k157 ; k157 = 161
.line	1125	loadk         r9   k40 ; k40 = 208
.line	1125	loadk        r10  k158 ; k158 = 102
.line	1125	loadk        r11   k55 ; k55 = 115
.line	1125	loadk        r12  k159 ; k159 = 105
.line	1125	loadk        r13   k19 ; k19 = 133
.line	1125	loadk        r14  k139 ; k139 = 226
.line	1125	loadk        r15  k160 ; k160 = 137
.line	1125	loadk        r16   k11 ; k11 = 242
.line	1125	loadk        r17   k55 ; k55 = 115
.line	1125	loadk        r18   k52 ; k52 = 30
.line	1125	loadk        r19  k161 ; k161 = 167
.line	1125	loadk        r20  k162 ; k162 = 207
.line	1125	call          r5    16     2
.line	1125	move          r6    r1
.line	1125	concat        r5    r5    r6
.label	l381
.line	1125	call          r4     2     1
.label	l382
.line	1125	return        r0     1
.line	1125	move          r0    r0
.line	1125	return        r0     1

.function	main/f52

.source	null
.linedefined	1170
.lastlinedefined	1172
.numparams	4
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"DataMgr"
.constant	k1	"UpdateLastEquipForeverSkin"

.line	1170	gettabup      r4    u0    k0 ; k0 = "DataMgr"
.line	1170	gettable      r4    r4    k1 ; k1 = "UpdateLastEquipForev" (truncated)
.line	1170	move          r5    r1
.line	1170	move          r6    r2
.line	1170	move          r7    r3
.line	1170	call          r4     4     1
.line	1170	return        r0     1
.line	1170	move          r0    r0
.line	1170	return        r0     1

.function	main/f53

.source	null
.linedefined	1174
.lastlinedefined	1182
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	10	true
.upvalue	"U1"	0	false

.constant	k0	"GetCurrentWearPreview"
.constant	k1	nil
.constant	k2	"insID"
.constant	k3	"AddToWearInfo"
.constant	k4	"resID"
.constant	k5	"colorID"
.constant	k6	"patternID"
.constant	k7	"AvatarChange"
.constant	k8	"EventSystem"
.constant	k9	"postEvent"
.constant	k10	"EVENTTYPE_WARDROBE"
.constant	k11	"EVENTID_WARDROBE_REFRESH_EQUIPMENT_LEVEL"

.line	1174	getupval      r2    u0
.line	1174	self          r2    r2    k0 ; k0 = "GetCurrentWearPrevie" (truncated)
.line	1174	move          r4    r1
.line	1174	call          r2     3     2
.line	1174	eq             1    r2    k1 ; k1 = nil
.line	1174	jmp            0   l21
.line	1174	gettable      r3    r2    k2 ; k2 = "insID"
.line	1174	getupval      r4    u0
.line	1174	self          r4    r4    k3 ; k3 = "AddToWearInfo"
.line	1174	move          r6    r1
.line	1174	move          r7    r3
.line	1174	gettable      r8    r2    k4 ; k4 = "resID"
.line	1174	gettable      r9    r2    k5 ; k5 = "colorID"
.line	1174	gettable     r10    r2    k6 ; k6 = "patternID"
.line	1174	call          r4     7     1
.line	1174	getupval      r4    u0
.line	1174	self          r4    r4    k7 ; k7 = "AvatarChange"
.line	1174	gettable      r6    r2    k4 ; k4 = "resID"
.line	1174	loadbool      r7     1     0
.line	1174	call          r4     4     1
.label	l21
.line	1174	gettabup      r3    u1    k8 ; k8 = "EventSystem"
.line	1174	self          r3    r3    k9 ; k9 = "postEvent"
.line	1174	gettabup      r5    u1   k10 ; k10 = "EVENTTYPE_WARDROBE"
.line	1174	gettabup      r6    u1   k11 ; k11 = "EVENTID_WARDROBE_REF" (truncated)
.line	1174	call          r3     4     1
.line	1174	return        r0     1
.line	1174	move          r0    r0
.line	1174	move          r0    r0
.line	1174	return        r0     1

.function	main/f54

.source	null
.linedefined	1184
.lastlinedefined	1189
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	118
.constant	k30	79
.constant	k31	254
.constant	k32	151
.constant	k33	63
.constant	k34	12
.constant	k35	6
.constant	k36	209
.constant	k37	147
.constant	k38	62
.constant	k39	0
.constant	k40	160
.constant	k41	240
.constant	k42	32
.constant	k43	208
.constant	k44	103
.constant	k45	134
.constant	k46	216
.constant	k47	205
.constant	k48	116
.constant	k49	95
.constant	k50	39
.constant	k51	210
.constant	k52	123
.constant	k53	94
.constant	k54	149
.constant	k55	230
.constant	k56	203
.constant	k57	247
.constant	k58	101
.constant	k59	97
.constant	k60	232
.constant	k61	155
.constant	k62	31
.constant	k63	"CopyTable"
.constant	k64	"GetCurrentFashionBag"
.constant	k65	"RecordForShareSkinCmp"

.line	1184	gettabup      r1    u0    k0 ; k0 = "require"
.line	1184	gettabup      r2    u0    k1 ; k1 = "table"
.line	1184	gettable      r2    r2    k2 ; k2 = "concat"
.line	1184	newtable      r3     1     0
.line	1184	getupval      r4    u1
.line	1184	loadk         r5    k3 ; k3 = 224
.line	1184	loadk         r6    k4 ; k4 = 36
.line	1184	loadk         r7    k5 ; k5 = 186
.line	1184	loadk         r8    k6 ; k6 = 218
.line	1184	loadk         r9    k7 ; k7 = 122
.line	1184	loadk        r10    k8 ; k8 = 68
.line	1184	loadk        r11    k9 ; k9 = 40
.line	1184	loadk        r12   k10 ; k10 = 146
.line	1184	loadk        r13   k11 ; k11 = 235
.line	1184	loadk        r14   k12 ; k12 = 220
.line	1184	loadk        r15   k13 ; k13 = 250
.line	1184	loadk        r16   k14 ; k14 = 46
.line	1184	loadk        r17   k15 ; k15 = 82
.line	1184	loadk        r18   k16 ; k16 = 242
.line	1184	loadk        r19   k17 ; k17 = 136
.line	1184	loadk        r20   k18 ; k18 = 47
.line	1184	loadk        r21   k19 ; k19 = 16
.line	1184	loadk        r22   k20 ; k20 = 86
.line	1184	loadk        r23   k21 ; k21 = 212
.line	1184	loadk        r24   k22 ; k22 = 238
.line	1184	loadk        r25   k23 ; k23 = 150
.line	1184	loadk        r26   k24 ; k24 = 100
.line	1184	loadk        r27   k25 ; k25 = 4
.line	1184	loadk        r28   k26 ; k26 = 190
.line	1184	loadk        r29   k27 ; k27 = 245
.line	1184	loadk        r30   k12 ; k12 = 220
.line	1184	loadk        r31   k28 ; k28 = 165
.line	1184	loadk        r32   k29 ; k29 = 118
.line	1184	loadk        r33   k30 ; k30 = 79
.line	1184	loadk        r34   k31 ; k31 = 254
.line	1184	loadk        r35   k32 ; k32 = 151
.line	1184	loadk        r36   k33 ; k33 = 63
.line	1184	loadk        r37   k34 ; k34 = 12
.line	1184	loadk        r38   k35 ; k35 = 6
.line	1184	loadk        r39   k36 ; k36 = 209
.line	1184	loadk        r40   k31 ; k31 = 254
.line	1184	loadk        r41   k37 ; k37 = 147
.line	1184	loadk        r42   k38 ; k38 = 62
.line	1184	loadk        r43   k39 ; k39 = 0
.line	1184	loadk        r44   k40 ; k40 = 160
.line	1184	call          r4    41     2
.line	1184	getupval      r5    u1
.line	1184	loadk         r6   k41 ; k41 = 240
.line	1184	loadk         r7   k42 ; k42 = 32
.line	1184	loadk         r8    k5 ; k5 = 186
.line	1184	loadk         r9   k43 ; k43 = 208
.line	1184	loadk        r10    k7 ; k7 = 122
.line	1184	loadk        r11   k15 ; k15 = 82
.line	1184	loadk        r12   k44 ; k44 = 103
.line	1184	loadk        r13   k45 ; k45 = 134
.line	1184	loadk        r14   k46 ; k46 = 216
.line	1184	loadk        r15   k47 ; k47 = 205
.line	1184	loadk        r16   k13 ; k13 = 250
.line	1184	loadk        r17   k48 ; k48 = 116
.line	1184	loadk        r18   k49 ; k49 = 95
.line	1184	call          r5    14     0
.line	1184	setlist       r3     0     1
.line	1184	call          r2     2     2
.line	1184	call          r1     2     2
.line	1184	gettabup      r2    u0    k0 ; k0 = "require"
.line	1184	getupval      r3    u1
.line	1184	loadk         r4    k3 ; k3 = 224
.line	1184	loadk         r5   k50 ; k50 = 39
.line	1184	loadk         r6   k26 ; k26 = 190
.line	1184	loadk         r7   k51 ; k51 = 210
.line	1184	loadk         r8   k52 ; k52 = 123
.line	1184	loadk         r9   k53 ; k53 = 94
.line	1184	loadk        r10    k9 ; k9 = 40
.line	1184	loadk        r11   k54 ; k54 = 149
.line	1184	loadk        r12   k55 ; k55 = 230
.line	1184	loadk        r13   k56 ; k56 = 203
.line	1184	loadk        r14   k57 ; k57 = 247
.line	1184	loadk        r15   k58 ; k58 = 101
.line	1184	loadk        r16   k59 ; k59 = 97
.line	1184	loadk        r17   k60 ; k60 = 232
.line	1184	loadk        r18   k61 ; k61 = 155
.line	1184	loadk        r19   k18 ; k18 = 47
.line	1184	loadk        r20   k62 ; k62 = 31
.line	1184	call          r3    18     2
.line	1184	call          r2     2     2
.line	1184	gettable      r3    r2   k63 ; k63 = "CopyTable"
.line	1184	self          r4    r1   k64 ; k64 = "GetCurrentFashionBag"
.line	1184	call          r4     2     0
.line	1184	call          r3     0     2
.line	1184	settable      r0   k65    r3 ; k65 = "RecordForShareSkinCm" (truncated)
.line	1184	return        r0     1
.line	1184	move          r0    r0
.line	1184	move          r0    r0
.line	1184	move          r0    r0
.line	1184	return        r0     1

.function	main/f55

.source	null
.linedefined	1191
.lastlinedefined	1248
.numparams	3
.is_vararg	0
.maxstacksize	60

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	163
.constant	k7	31
.constant	k8	178
.constant	k9	205
.constant	k10	112
.constant	k11	66
.constant	k12	105
.constant	k13	131
.constant	k14	226
.constant	k15	229
.constant	k16	244
.constant	k17	103
.constant	k18	87
.constant	k19	254
.constant	k20	213
.constant	k21	21
.constant	k22	22
.constant	k23	12
.constant	k24	238
.constant	k25	150
.constant	k26	100
.constant	k27	4
.constant	k28	190
.constant	k29	245
.constant	k30	220
.constant	k31	206
.constant	k32	116
.constant	k33	71
.constant	k34	249
.constant	k35	57
.constant	k36	7
.constant	k37	13
.constant	k38	147
.constant	k39	232
.constant	k40	149
.constant	k41	98
.constant	k42	2
.constant	k43	179
.constant	k44	236
.constant	k45	42
.constant	k46	182
.constant	k47	250
.constant	k48	89
.constant	k49	114
.constant	k50	172
.constant	k51	58
.constant	k52	27
.constant	k53	"require"
.constant	k54	224
.constant	k55	36
.constant	k56	186
.constant	k57	218
.constant	k58	122
.constant	k59	68
.constant	k60	40
.constant	k61	146
.constant	k62	235
.constant	k63	46
.constant	k64	75
.constant	k65	240
.constant	k66	136
.constant	k67	104
.constant	k68	25
.constant	k69	209
.constant	k70	111
.constant	k71	20
.constant	k72	180
.constant	k73	185
.constant	k74	234
.constant	k75	74
.constant	k76	255
.constant	k77	144
.constant	k78	52
.constant	k79	6
.constant	k80	55
.constant	k81	222
.constant	k82	151
.constant	k83	9
.constant	k84	"wardrobeEditMode"
.constant	k85	"EWardrobeEditMode"
.constant	k86	"None"
.constant	k87	"lastWardrobeEditMode"
.constant	k88	"FashionBag"
.constant	k89	"RecordForShareSkinCmp"
.constant	k90	82
.constant	k91	242
.constant	k92	47
.constant	k93	16
.constant	k94	86
.constant	k95	212
.constant	k96	165
.constant	k97	118
.constant	k98	79
.constant	k99	63
.constant	k100	62
.constant	k101	0
.constant	k102	160
.constant	k103	32
.constant	k104	208
.constant	k105	134
.constant	k106	216
.constant	k107	95
.constant	k108	39
.constant	k109	210
.constant	k110	123
.constant	k111	94
.constant	k112	230
.constant	k113	203
.constant	k114	247
.constant	k115	101
.constant	k116	97
.constant	k117	155
.constant	k118	"CopyTable"
.constant	k119	"GetCurrentFashionBag"
.constant	k120	"Diff"
.constant	k121	"log_tree"
.constant	k122	252
.constant	k123	124
.constant	k124	5
.constant	k125	225
.constant	k126	241
.constant	k127	45
.constant	k128	251
.constant	k129	125
.constant	k130	96
.constant	k131	"CollectValues"
.constant	k132	"ArrayUnique"
.constant	k133	193
.constant	k134	239
.constant	k135	81
.constant	k136	129
.constant	k137	10
.constant	k138	26
.constant	k139	11
.constant	k140	215
.constant	k141	181
.constant	k142	"pairs"
.constant	k143	"GetHallDepotItemDataByInsID"
.constant	k144	"wardrobe_put_down_req"
.constant	k145	41
.constant	k146	161
.constant	k147	219
.constant	k148	102
.constant	k149	132
.constant	k150	198
.constant	k151	93
.constant	k152	167
.constant	k153	188
.constant	k154	35
.constant	k155	194
.constant	k156	253
.constant	k157	128
.constant	k158	121
.constant	k159	90
.constant	k160	192
.constant	k161	50
.constant	k162	72
.constant	k163	113
.constant	k164	175
.constant	k165	243
.constant	k166	38
.constant	k167	135
.constant	k168	237
.constant	k169	145
.constant	k170	34
.constant	k171	168
.constant	k172	214
.constant	k173	231
.constant	k174	33
.constant	k175	217
.constant	k176	"print"
.constant	k177	64
.constant	k178	115
.constant	k179	200
.constant	k180	199
.constant	k181	77
.constant	k182	233
.constant	k183	"wardrobe_puton_req"
.constant	k184	157
.constant	k185	59
.constant	k186	92
.constant	k187	nil
.constant	k188	"shareBagSubType"
.constant	k189	"isInShareSubscribeSetup"
.constant	k190	"ShareBag"
.constant	k191	"SyncSubscribeShareItemListToServer"

.line	1191	gettabup      r3    u0    k0 ; k0 = "log"
.line	1191	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	1191	test          r4     0
.line	1191	jmp            0   l72
.line	1191	gettabup      r4    u0    k2 ; k2 = "string"
.line	1191	gettable      r4    r4    k3 ; k3 = "format"
.line	1191	gettabup      r5    u0    k4 ; k4 = "table"
.line	1191	gettable      r5    r5    k5 ; k5 = "concat"
.line	1191	newtable      r6     1     0
.line	1191	getupval      r7    u1
.line	1191	loadk         r8    k6 ; k6 = 163
.line	1191	loadk         r9    k7 ; k7 = 31
.line	1191	loadk        r10    k8 ; k8 = 178
.line	1191	loadk        r11    k9 ; k9 = 205
.line	1191	loadk        r12   k10 ; k10 = 112
.line	1191	loadk        r13   k11 ; k11 = 66
.line	1191	loadk        r14   k12 ; k12 = 105
.line	1191	loadk        r15   k13 ; k13 = 131
.line	1191	loadk        r16   k14 ; k14 = 226
.line	1191	loadk        r17   k15 ; k15 = 229
.line	1191	loadk        r18   k16 ; k16 = 244
.line	1191	loadk        r19   k17 ; k17 = 103
.line	1191	loadk        r20   k18 ; k18 = 87
.line	1191	loadk        r21   k19 ; k19 = 254
.line	1191	loadk        r22   k20 ; k20 = 213
.line	1191	loadk        r23   k21 ; k21 = 21
.line	1191	loadk        r24   k22 ; k22 = 22
.line	1191	loadk        r25   k23 ; k23 = 12
.line	1191	loadk        r26   k16 ; k16 = 244
.line	1191	loadk        r27   k24 ; k24 = 238
.line	1191	loadk        r28   k25 ; k25 = 150
.line	1191	loadk        r29   k26 ; k26 = 100
.line	1191	loadk        r30   k27 ; k27 = 4
.line	1191	loadk        r31   k28 ; k28 = 190
.line	1191	loadk        r32   k29 ; k29 = 245
.line	1191	loadk        r33   k30 ; k30 = 220
.line	1191	loadk        r34   k31 ; k31 = 206
.line	1191	loadk        r35   k32 ; k32 = 116
.line	1191	loadk        r36   k33 ; k33 = 71
.line	1191	loadk        r37   k34 ; k34 = 249
.line	1191	loadk        r38    k8 ; k8 = 178
.line	1191	loadk        r39   k35 ; k35 = 57
.line	1191	loadk        r40   k36 ; k36 = 7
.line	1191	loadk        r41   k37 ; k37 = 13
.line	1191	loadk        r42   k38 ; k38 = 147
.line	1191	loadk        r43   k39 ; k39 = 232
.line	1191	loadk        r44   k40 ; k40 = 149
.line	1191	loadk        r45   k41 ; k41 = 98
.line	1191	loadk        r46   k42 ; k42 = 2
.line	1191	loadk        r47   k43 ; k43 = 179
.line	1191	call          r7    41     2
.line	1191	getupval      r8    u1
.line	1191	loadk         r9   k44 ; k44 = 236
.line	1191	loadk        r10   k45 ; k45 = 42
.line	1191	loadk        r11   k46 ; k46 = 182
.line	1191	loadk        r12   k47 ; k47 = 250
.line	1191	loadk        r13   k10 ; k10 = 112
.line	1191	loadk        r14   k48 ; k48 = 89
.line	1191	loadk        r15   k49 ; k49 = 114
.line	1191	loadk        r16   k50 ; k50 = 172
.line	1191	loadk        r17   k39 ; k39 = 232
.line	1191	loadk        r18    k9 ; k9 = 205
.line	1191	loadk        r19   k19 ; k19 = 254
.line	1191	loadk        r20   k51 ; k51 = 58
.line	1191	loadk        r21   k52 ; k52 = 27
.line	1191	loadk        r22   k24 ; k24 = 238
.line	1191	call          r8    15     0
.line	1191	setlist       r6     0     1
.line	1191	call          r5     2     2
.line	1191	move          r6    r1
.line	1191	call          r4     3     2
.label	l72
.line	1191	call          r3     2     1
.line	1191	gettabup      r3    u0   k53 ; k53 = "require"
.line	1191	getupval      r4    u1
.line	1191	loadk         r5   k54 ; k54 = 224
.line	1191	loadk         r6   k55 ; k55 = 36
.line	1191	loadk         r7   k56 ; k56 = 186
.line	1191	loadk         r8   k57 ; k57 = 218
.line	1191	loadk         r9   k58 ; k58 = 122
.line	1191	loadk        r10   k59 ; k59 = 68
.line	1191	loadk        r11   k60 ; k60 = 40
.line	1191	loadk        r12   k61 ; k61 = 146
.line	1191	loadk        r13   k62 ; k62 = 235
.line	1191	loadk        r14   k30 ; k30 = 220
.line	1191	loadk        r15   k47 ; k47 = 250
.line	1191	loadk        r16   k63 ; k63 = 46
.line	1191	loadk        r17   k64 ; k64 = 75
.line	1191	loadk        r18   k65 ; k65 = 240
.line	1191	loadk        r19   k66 ; k66 = 136
.line	1191	loadk        r20   k67 ; k67 = 104
.line	1191	loadk        r21   k55 ; k55 = 36
.line	1191	loadk        r22   k68 ; k68 = 25
.line	1191	loadk        r23   k69 ; k69 = 209
.line	1191	loadk        r24   k62 ; k62 = 235
.line	1191	loadk        r25   k25 ; k25 = 150
.line	1191	loadk        r26   k70 ; k70 = 111
.line	1191	loadk        r27   k71 ; k71 = 20
.line	1191	loadk        r28   k72 ; k72 = 180
.line	1191	loadk        r29   k73 ; k73 = 185
.line	1191	loadk        r30   k31 ; k31 = 206
.line	1191	loadk        r31   k74 ; k74 = 234
.line	1191	loadk        r32   k41 ; k41 = 98
.line	1191	loadk        r33   k75 ; k75 = 74
.line	1191	loadk        r34   k76 ; k76 = 255
.line	1191	loadk        r35   k77 ; k77 = 144
.line	1191	loadk        r36   k78 ; k78 = 52
.line	1191	loadk        r37   k79 ; k79 = 6
.line	1191	loadk        r38   k80 ; k80 = 55
.line	1191	loadk        r39   k81 ; k81 = 222
.line	1191	loadk        r40   k19 ; k19 = 254
.line	1191	loadk        r41   k82 ; k82 = 151
.line	1191	loadk        r42   k41 ; k41 = 98
.line	1191	loadk        r43   k83 ; k83 = 9
.line	1191	call          r4    40     2
.line	1191	call          r3     2     2
.line	1191	testset       r4    r1     1
.line	1191	jmp            0  l120
.line	1191	gettable      r4    r3   k85 ; k85 = "EWardrobeEditMode"
.line	1191	gettable      r4    r4   k86 ; k86 = "None"
.label	l120
.line	1191	settable      r0   k84    r4 ; k84 = "wardrobeEditMode"
.line	1191	gettable      r4    r3   k85 ; k85 = "EWardrobeEditMode"
.line	1191	gettable      r4    r4   k86 ; k86 = "None"
.line	1191	eq             0    r1    r4
.line	1191	jmp            0  l811
.line	1191	gettable      r4    r0   k87 ; k87 = "lastWardrobeEditMode"
.line	1191	gettable      r5    r3   k85 ; k85 = "EWardrobeEditMode"
.line	1191	gettable      r5    r5   k88 ; k88 = "FashionBag"
.line	1191	eq             1    r4    r5
.line	1191	jmp            0  l811
.line	1191	gettable      r4    r0   k87 ; k87 = "lastWardrobeEditMode"
.line	1191	gettable      r5    r3   k85 ; k85 = "EWardrobeEditMode"
.line	1191	gettable      r5    r5   k86 ; k86 = "None"
.line	1191	eq             1    r4    r5
.line	1191	jmp            0  l811
.line	1191	gettable      r4    r0   k89 ; k89 = "RecordForShareSkinCm" (truncated)
.line	1191	test          r4     0
.line	1191	jmp            0  l810
.line	1191	gettabup      r4    u0   k53 ; k53 = "require"
.line	1191	gettabup      r5    u0    k4 ; k4 = "table"
.line	1191	gettable      r5    r5    k5 ; k5 = "concat"
.line	1191	newtable      r6     1     0
.line	1191	getupval      r7    u1
.line	1191	loadk         r8   k54 ; k54 = 224
.line	1191	loadk         r9   k55 ; k55 = 36
.line	1191	loadk        r10   k56 ; k56 = 186
.line	1191	loadk        r11   k57 ; k57 = 218
.line	1191	loadk        r12   k58 ; k58 = 122
.line	1191	loadk        r13   k59 ; k59 = 68
.line	1191	loadk        r14   k60 ; k60 = 40
.line	1191	loadk        r15   k61 ; k61 = 146
.line	1191	loadk        r16   k62 ; k62 = 235
.line	1191	loadk        r17   k30 ; k30 = 220
.line	1191	loadk        r18   k47 ; k47 = 250
.line	1191	loadk        r19   k63 ; k63 = 46
.line	1191	loadk        r20   k90 ; k90 = 82
.line	1191	loadk        r21   k91 ; k91 = 242
.line	1191	loadk        r22   k66 ; k66 = 136
.line	1191	loadk        r23   k92 ; k92 = 47
.line	1191	loadk        r24   k93 ; k93 = 16
.line	1191	loadk        r25   k94 ; k94 = 86
.line	1191	loadk        r26   k95 ; k95 = 212
.line	1191	loadk        r27   k24 ; k24 = 238
.line	1191	loadk        r28   k25 ; k25 = 150
.line	1191	loadk        r29   k26 ; k26 = 100
.line	1191	loadk        r30   k27 ; k27 = 4
.line	1191	loadk        r31   k28 ; k28 = 190
.line	1191	loadk        r32   k29 ; k29 = 245
.line	1191	loadk        r33   k30 ; k30 = 220
.line	1191	loadk        r34   k96 ; k96 = 165
.line	1191	loadk        r35   k97 ; k97 = 118
.line	1191	loadk        r36   k98 ; k98 = 79
.line	1191	loadk        r37   k19 ; k19 = 254
.line	1191	loadk        r38   k82 ; k82 = 151
.line	1191	loadk        r39   k99 ; k99 = 63
.line	1191	loadk        r40   k23 ; k23 = 12
.line	1191	loadk        r41   k79 ; k79 = 6
.line	1191	loadk        r42   k69 ; k69 = 209
.line	1191	loadk        r43   k19 ; k19 = 254
.line	1191	loadk        r44   k38 ; k38 = 147
.line	1191	loadk        r45  k100 ; k100 = 62
.line	1191	loadk        r46  k101 ; k101 = 0
.line	1191	loadk        r47  k102 ; k102 = 160
.line	1191	call          r7    41     2
.line	1191	getupval      r8    u1
.line	1191	loadk         r9   k65 ; k65 = 240
.line	1191	loadk        r10  k103 ; k103 = 32
.line	1191	loadk        r11   k56 ; k56 = 186
.line	1191	loadk        r12  k104 ; k104 = 208
.line	1191	loadk        r13   k58 ; k58 = 122
.line	1191	loadk        r14   k90 ; k90 = 82
.line	1191	loadk        r15   k17 ; k17 = 103
.line	1191	loadk        r16  k105 ; k105 = 134
.line	1191	loadk        r17  k106 ; k106 = 216
.line	1191	loadk        r18    k9 ; k9 = 205
.line	1191	loadk        r19   k47 ; k47 = 250
.line	1191	loadk        r20   k32 ; k32 = 116
.line	1191	loadk        r21  k107 ; k107 = 95
.line	1191	call          r8    14     0
.line	1191	setlist       r6     0     1
.line	1191	call          r5     2     2
.line	1191	call          r4     2     2
.line	1191	gettabup      r5    u0   k53 ; k53 = "require"
.line	1191	getupval      r6    u1
.line	1191	loadk         r7   k54 ; k54 = 224
.line	1191	loadk         r8  k108 ; k108 = 39
.line	1191	loadk         r9   k28 ; k28 = 190
.line	1191	loadk        r10  k109 ; k109 = 210
.line	1191	loadk        r11  k110 ; k110 = 123
.line	1191	loadk        r12  k111 ; k111 = 94
.line	1191	loadk        r13   k60 ; k60 = 40
.line	1191	loadk        r14   k40 ; k40 = 149
.line	1191	loadk        r15  k112 ; k112 = 230
.line	1191	loadk        r16  k113 ; k113 = 203
.line	1191	loadk        r17  k114 ; k114 = 247
.line	1191	loadk        r18  k115 ; k115 = 101
.line	1191	loadk        r19  k116 ; k116 = 97
.line	1191	loadk        r20   k39 ; k39 = 232
.line	1191	loadk        r21  k117 ; k117 = 155
.line	1191	loadk        r22   k92 ; k92 = 47
.line	1191	loadk        r23    k7 ; k7 = 31
.line	1191	call          r6    18     2
.line	1191	call          r5     2     2
.line	1191	gettable      r6    r5  k118 ; k118 = "CopyTable"
.line	1191	self          r7    r4  k119 ; k119 = "GetCurrentFashionBag"
.line	1191	call          r7     2     0
.line	1191	call          r6     0     2
.line	1191	gettable      r7    r5  k120 ; k120 = "Diff"
.line	1191	move          r8    r6
.line	1191	gettable      r9    r0   k89 ; k89 = "RecordForShareSkinCm" (truncated)
.line	1191	call          r7     3     2
.line	1191	test          r7     0
.line	1191	jmp            0  l461
.line	1191	gettabup      r8    u0  k121 ; k121 = "log_tree"
.line	1191	gettabup      r9    u0    k4 ; k4 = "table"
.line	1191	gettable      r9    r9    k5 ; k5 = "concat"
.line	1191	newtable     r10     1     0
.line	1191	getupval     r11    u1
.line	1191	loadk        r12    k6 ; k6 = 163
.line	1191	loadk        r13    k7 ; k7 = 31
.line	1191	loadk        r14    k8 ; k8 = 178
.line	1191	loadk        r15    k9 ; k9 = 205
.line	1191	loadk        r16   k10 ; k10 = 112
.line	1191	loadk        r17   k11 ; k11 = 66
.line	1191	loadk        r18   k12 ; k12 = 105
.line	1191	loadk        r19   k13 ; k13 = 131
.line	1191	loadk        r20   k14 ; k14 = 226
.line	1191	loadk        r21   k15 ; k15 = 229
.line	1191	loadk        r22   k16 ; k16 = 244
.line	1191	loadk        r23   k17 ; k17 = 103
.line	1191	loadk        r24   k18 ; k18 = 87
.line	1191	loadk        r25   k19 ; k19 = 254
.line	1191	loadk        r26   k20 ; k20 = 213
.line	1191	loadk        r27   k21 ; k21 = 21
.line	1191	loadk        r28   k22 ; k22 = 22
.line	1191	loadk        r29   k23 ; k23 = 12
.line	1191	loadk        r30   k16 ; k16 = 244
.line	1191	loadk        r31   k24 ; k24 = 238
.line	1191	loadk        r32   k25 ; k25 = 150
.line	1191	loadk        r33   k26 ; k26 = 100
.line	1191	loadk        r34   k27 ; k27 = 4
.line	1191	loadk        r35   k28 ; k28 = 190
.line	1191	loadk        r36   k29 ; k29 = 245
.line	1191	loadk        r37   k30 ; k30 = 220
.line	1191	loadk        r38   k31 ; k31 = 206
.line	1191	loadk        r39   k32 ; k32 = 116
.line	1191	loadk        r40   k33 ; k33 = 71
.line	1191	loadk        r41   k34 ; k34 = 249
.line	1191	loadk        r42    k8 ; k8 = 178
.line	1191	loadk        r43   k35 ; k35 = 57
.line	1191	loadk        r44   k36 ; k36 = 7
.line	1191	loadk        r45   k37 ; k37 = 13
.line	1191	loadk        r46   k38 ; k38 = 147
.line	1191	loadk        r47  k122 ; k122 = 252
.line	1191	loadk        r48   k40 ; k40 = 149
.line	1191	loadk        r49  k123 ; k123 = 124
.line	1191	loadk        r50  k124 ; k124 = 5
.line	1191	loadk        r51  k125 ; k125 = 225
.line	1191	call         r11    41     2
.line	1191	getupval     r12    u1
.line	1191	loadk        r13  k126 ; k126 = 241
.line	1191	loadk        r14  k127 ; k127 = 45
.line	1191	loadk        r15   k96 ; k96 = 165
.line	1191	loadk        r16  k128 ; k128 = 251
.line	1191	loadk        r17  k129 ; k129 = 125
.line	1191	loadk        r18   k94 ; k94 = 86
.line	1191	loadk        r19  k130 ; k130 = 96
.line	1191	call         r12     8     0
.line	1191	setlist      r10     0     1
.line	1191	call          r9     2     2
.line	1191	move         r10    r7
.line	1191	call          r8     3     1
.line	1191	gettable      r8    r5  k131 ; k131 = "CollectValues"
.line	1191	move          r9    r7
.line	1191	call          r8     2     2
.line	1191	gettable      r9    r5  k132 ; k132 = "ArrayUnique"
.line	1191	move         r10    r8
.line	1191	call          r9     2     2
.line	1191	move          r8    r9
.line	1191	gettabup      r9    u0    k0 ; k0 = "log"
.line	1191	gettabup     r10    u0    k1 ; k1 = "bWriteLog"
.line	1191	test         r10     0
.line	1191	jmp            0  l374
.line	1191	gettabup     r10    u0    k4 ; k4 = "table"
.line	1191	gettable     r10   r10    k5 ; k5 = "concat"
.line	1191	newtable     r11     1     0
.line	1191	getupval     r12    u1
.line	1191	loadk        r13    k6 ; k6 = 163
.line	1191	loadk        r14    k7 ; k7 = 31
.line	1191	loadk        r15    k8 ; k8 = 178
.line	1191	loadk        r16    k9 ; k9 = 205
.line	1191	loadk        r17   k10 ; k10 = 112
.line	1191	loadk        r18   k11 ; k11 = 66
.line	1191	loadk        r19   k12 ; k12 = 105
.line	1191	loadk        r20   k13 ; k13 = 131
.line	1191	loadk        r21   k14 ; k14 = 226
.line	1191	loadk        r22   k15 ; k15 = 229
.line	1191	loadk        r23   k16 ; k16 = 244
.line	1191	loadk        r24   k17 ; k17 = 103
.line	1191	loadk        r25   k18 ; k18 = 87
.line	1191	loadk        r26   k19 ; k19 = 254
.line	1191	loadk        r27   k20 ; k20 = 213
.line	1191	loadk        r28   k21 ; k21 = 21
.line	1191	loadk        r29   k22 ; k22 = 22
.line	1191	loadk        r30   k23 ; k23 = 12
.line	1191	loadk        r31   k16 ; k16 = 244
.line	1191	loadk        r32   k24 ; k24 = 238
.line	1191	loadk        r33   k25 ; k25 = 150
.line	1191	loadk        r34   k26 ; k26 = 100
.line	1191	loadk        r35   k27 ; k27 = 4
.line	1191	loadk        r36   k28 ; k28 = 190
.line	1191	loadk        r37   k29 ; k29 = 245
.line	1191	loadk        r38   k30 ; k30 = 220
.line	1191	loadk        r39   k31 ; k31 = 206
.line	1191	loadk        r40   k32 ; k32 = 116
.line	1191	loadk        r41   k33 ; k33 = 71
.line	1191	loadk        r42   k34 ; k34 = 249
.line	1191	loadk        r43    k8 ; k8 = 178
.line	1191	loadk        r44   k35 ; k35 = 57
.line	1191	loadk        r45   k36 ; k36 = 7
.line	1191	loadk        r46   k37 ; k37 = 13
.line	1191	loadk        r47   k38 ; k38 = 147
.line	1191	loadk        r48  k122 ; k122 = 252
.line	1191	loadk        r49   k40 ; k40 = 149
.line	1191	loadk        r50  k123 ; k123 = 124
.line	1191	loadk        r51  k124 ; k124 = 5
.line	1191	loadk        r52  k125 ; k125 = 225
.line	1191	call         r12    41     2
.line	1191	getupval     r13    u1
.line	1191	loadk        r14  k126 ; k126 = 241
.line	1191	loadk        r15  k127 ; k127 = 45
.line	1191	loadk        r16   k96 ; k96 = 165
.line	1191	loadk        r17  k128 ; k128 = 251
.line	1191	loadk        r18  k129 ; k129 = 125
.line	1191	loadk        r19   k94 ; k94 = 86
.line	1191	loadk        r20  k130 ; k130 = 96
.line	1191	loadk        r21  k133 ; k133 = 193
.line	1191	loadk        r22  k114 ; k114 = 247
.line	1191	loadk        r23   k30 ; k30 = 220
.line	1191	loadk        r24  k134 ; k134 = 239
.line	1191	loadk        r25   k59 ; k59 = 68
.line	1191	loadk        r26  k135 ; k135 = 81
.line	1191	loadk        r27   k74 ; k74 = 234
.line	1191	loadk        r28  k136 ; k136 = 129
.line	1191	loadk        r29  k137 ; k137 = 10
.line	1191	loadk        r30  k138 ; k138 = 26
.line	1191	loadk        r31  k139 ; k139 = 11
.line	1191	loadk        r32  k140 ; k140 = 215
.line	1191	loadk        r33  k141 ; k141 = 181
.line	1191	call         r13    21     0
.line	1191	setlist      r11     0     1
.line	1191	call         r10     2     2
.line	1191	len          r11    r8
.line	1191	concat       r10   r10   r11
.label	l374
.line	1191	call          r9     2     1
.line	1191	len           r9    r8
.line	1191	lt             0  k101    r9 ; k101 = 0
.line	1191	jmp            0  l524
.line	1191	gettabup      r9    u0  k142 ; k142 = "pairs"
.line	1191	move         r10    r8
.line	1191	call          r9     2     4
.line	1191	jmp            0  l458
.line	1191	getupval     r14    u2
.line	1191	self         r14   r14  k143 ; k143 = "GetHallDepotItemData" (truncated)
.line	1191	move         r16   r13
.line	1191	call         r14     3     2
.line	1191	test         r14     0
.line	1191	jmp            0  l392
.line	1191	self         r15    r0  k144 ; k144 = "wardrobe_put_down_re" (truncated)
.line	1191	move         r17   r13
.line	1191	call         r15     3     1
.line	1191	jmp            0  l458
.label	l392
.line	1191	gettabup     r15    u0    k0 ; k0 = "log"
.line	1191	gettabup     r16    u0    k1 ; k1 = "bWriteLog"
.line	1191	test         r16     0
.line	1191	jmp            0  l457
.line	1191	gettabup     r16    u0    k4 ; k4 = "table"
.line	1191	gettable     r16   r16    k5 ; k5 = "concat"
.line	1191	newtable     r17     1     0
.line	1191	getupval     r18    u1
.line	1191	loadk        r19   k95 ; k95 = 212
.line	1191	loadk        r20  k145 ; k145 = 41
.line	1191	loadk        r21  k146 ; k146 = 161
.line	1191	loadk        r22  k147 ; k147 = 219
.line	1191	loadk        r23  k148 ; k148 = 102
.line	1191	loadk        r24  k107 ; k107 = 95
.line	1191	loadk        r25   k26 ; k26 = 100
.line	1191	loadk        r26  k149 ; k149 = 132
.line	1191	loadk        r27  k113 ; k113 = 203
.line	1191	loadk        r28  k150 ; k150 = 198
.line	1191	loadk        r29  k122 ; k122 = 252
.line	1191	loadk        r30   k12 ; k12 = 105
.line	1191	loadk        r31  k151 ; k151 = 93
.line	1191	loadk        r32  k152 ; k152 = 167
.line	1191	loadk        r33  k153 ; k153 = 188
.line	1191	loadk        r34  k154 ; k154 = 35
.line	1191	loadk        r35   k36 ; k36 = 7
.line	1191	loadk        r36   k92 ; k92 = 47
.line	1191	loadk        r37  k155 ; k155 = 194
.line	1191	loadk        r38  k156 ; k156 = 253
.line	1191	loadk        r39  k157 ; k157 = 128
.line	1191	loadk        r40   k49 ; k49 = 114
.line	1191	loadk        r41   k68 ; k68 = 25
.line	1191	loadk        r42   k43 ; k43 = 179
.line	1191	loadk        r43   k91 ; k91 = 242
.line	1191	loadk        r44  k122 ; k122 = 252
.line	1191	loadk        r45  k134 ; k134 = 239
.line	1191	loadk        r46  k158 ; k158 = 121
.line	1191	loadk        r47  k159 ; k159 = 90
.line	1191	loadk        r48  k160 ; k160 = 192
.line	1191	loadk        r49   k77 ; k77 = 144
.line	1191	loadk        r50  k161 ; k161 = 50
.line	1191	loadk        r51   k79 ; k79 = 6
.line	1191	loadk        r52  k162 ; k162 = 72
.line	1191	loadk        r53  k140 ; k140 = 215
.line	1191	loadk        r54   k19 ; k19 = 254
.line	1191	loadk        r55  k157 ; k157 = 128
.line	1191	loadk        r56  k163 ; k163 = 113
.line	1191	loadk        r57   k92 ; k92 = 47
.line	1191	loadk        r58  k164 ; k164 = 175
.line	1191	call         r18    41     2
.line	1191	getupval     r19    u1
.line	1191	loadk        r20   k15 ; k15 = 229
.line	1191	loadk        r21  k108 ; k108 = 39
.line	1191	loadk        r22  k165 ; k165 = 243
.line	1191	loadk        r23   k69 ; k69 = 209
.line	1191	loadk        r24  k110 ; k110 = 123
.line	1191	loadk        r25   k59 ; k59 = 68
.line	1191	loadk        r26  k166 ; k166 = 38
.line	1191	loadk        r27  k167 ; k167 = 135
.line	1191	loadk        r28   k39 ; k39 = 232
.line	1191	loadk        r29   k30 ; k30 = 220
.line	1191	loadk        r30   k29 ; k29 = 245
.line	1191	loadk        r31   k26 ; k26 = 100
.line	1191	call         r19    13     0
.line	1191	setlist      r17     0     1
.line	1191	call         r16     2     2
.label	l457
.line	1191	call         r15     2     1
.label	l458
.line	1191	move          r0    r0
.line	1191	move          r0    r0
.line	1191	jmp            0  l524
.label	l461
.line	1191	gettabup      r8    u0    k0 ; k0 = "log"
.line	1191	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	1191	test          r9     0
.line	1191	jmp            0  l523
.line	1191	gettabup      r9    u0    k4 ; k4 = "table"
.line	1191	gettable      r9    r9    k5 ; k5 = "concat"
.line	1191	newtable     r10     1     0
.line	1191	getupval     r11    u1
.line	1191	loadk        r12    k6 ; k6 = 163
.line	1191	loadk        r13    k7 ; k7 = 31
.line	1191	loadk        r14    k8 ; k8 = 178
.line	1191	loadk        r15    k9 ; k9 = 205
.line	1191	loadk        r16   k10 ; k10 = 112
.line	1191	loadk        r17   k11 ; k11 = 66
.line	1191	loadk        r18   k12 ; k12 = 105
.line	1191	loadk        r19   k13 ; k13 = 131
.line	1191	loadk        r20   k14 ; k14 = 226
.line	1191	loadk        r21   k15 ; k15 = 229
.line	1191	loadk        r22   k16 ; k16 = 244
.line	1191	loadk        r23   k17 ; k17 = 103
.line	1191	loadk        r24   k18 ; k18 = 87
.line	1191	loadk        r25   k19 ; k19 = 254
.line	1191	loadk        r26   k20 ; k20 = 213
.line	1191	loadk        r27   k21 ; k21 = 21
.line	1191	loadk        r28   k22 ; k22 = 22
.line	1191	loadk        r29   k23 ; k23 = 12
.line	1191	loadk        r30   k16 ; k16 = 244
.line	1191	loadk        r31   k24 ; k24 = 238
.line	1191	loadk        r32   k25 ; k25 = 150
.line	1191	loadk        r33   k26 ; k26 = 100
.line	1191	loadk        r34   k27 ; k27 = 4
.line	1191	loadk        r35   k28 ; k28 = 190
.line	1191	loadk        r36   k29 ; k29 = 245
.line	1191	loadk        r37   k30 ; k30 = 220
.line	1191	loadk        r38   k31 ; k31 = 206
.line	1191	loadk        r39   k32 ; k32 = 116
.line	1191	loadk        r40   k33 ; k33 = 71
.line	1191	loadk        r41   k34 ; k34 = 249
.line	1191	loadk        r42    k8 ; k8 = 178
.line	1191	loadk        r43   k35 ; k35 = 57
.line	1191	loadk        r44   k36 ; k36 = 7
.line	1191	loadk        r45   k37 ; k37 = 13
.line	1191	loadk        r46   k38 ; k38 = 147
.line	1191	loadk        r47  k168 ; k168 = 237
.line	1191	loadk        r48  k169 ; k169 = 145
.line	1191	loadk        r49  k148 ; k148 = 102
.line	1191	loadk        r50  k170 ; k170 = 34
.line	1191	loadk        r51  k171 ; k171 = 168
.line	1191	call         r11    41     2
.line	1191	getupval     r12    u1
.line	1191	loadk        r13   k15 ; k15 = 229
.line	1191	loadk        r14   k63 ; k63 = 46
.line	1191	loadk        r15  k165 ; k165 = 243
.line	1191	loadk        r16  k172 ; k172 = 214
.line	1191	loadk        r17   k17 ; k17 = 103
.line	1191	loadk        r18   k93 ; k93 = 16
.line	1191	loadk        r19   k67 ; k67 = 104
.line	1191	loadk        r20   k66 ; k66 = 136
.line	1191	loadk        r21   k62 ; k62 = 235
.line	1191	call         r12    10     0
.line	1191	setlist      r10     0     1
.line	1191	call          r9     2     2
.label	l523
.line	1191	call          r8     2     1
.label	l524
.line	1191	gettable      r8    r5  k120 ; k120 = "Diff"
.line	1191	gettable      r9    r0   k89 ; k89 = "RecordForShareSkinCm" (truncated)
.line	1191	move         r10    r6
.line	1191	call          r8     3     2
.line	1191	test          r8     0
.line	1191	jmp            0  l750
.line	1191	gettabup      r9    u0  k121 ; k121 = "log_tree"
.line	1191	gettabup     r10    u0    k4 ; k4 = "table"
.line	1191	gettable     r10   r10    k5 ; k5 = "concat"
.line	1191	newtable     r11     1     0
.line	1191	getupval     r12    u1
.line	1191	loadk        r13    k6 ; k6 = 163
.line	1191	loadk        r14    k7 ; k7 = 31
.line	1191	loadk        r15    k8 ; k8 = 178
.line	1191	loadk        r16    k9 ; k9 = 205
.line	1191	loadk        r17   k10 ; k10 = 112
.line	1191	loadk        r18   k11 ; k11 = 66
.line	1191	loadk        r19   k12 ; k12 = 105
.line	1191	loadk        r20   k13 ; k13 = 131
.line	1191	loadk        r21   k14 ; k14 = 226
.line	1191	loadk        r22   k15 ; k15 = 229
.line	1191	loadk        r23   k16 ; k16 = 244
.line	1191	loadk        r24   k17 ; k17 = 103
.line	1191	loadk        r25   k18 ; k18 = 87
.line	1191	loadk        r26   k19 ; k19 = 254
.line	1191	loadk        r27   k20 ; k20 = 213
.line	1191	loadk        r28   k21 ; k21 = 21
.line	1191	loadk        r29   k22 ; k22 = 22
.line	1191	loadk        r30   k23 ; k23 = 12
.line	1191	loadk        r31   k16 ; k16 = 244
.line	1191	loadk        r32   k24 ; k24 = 238
.line	1191	loadk        r33   k25 ; k25 = 150
.line	1191	loadk        r34   k26 ; k26 = 100
.line	1191	loadk        r35   k27 ; k27 = 4
.line	1191	loadk        r36   k28 ; k28 = 190
.line	1191	loadk        r37   k29 ; k29 = 245
.line	1191	loadk        r38   k30 ; k30 = 220
.line	1191	loadk        r39   k31 ; k31 = 206
.line	1191	loadk        r40   k32 ; k32 = 116
.line	1191	loadk        r41   k33 ; k33 = 71
.line	1191	loadk        r42   k34 ; k34 = 249
.line	1191	loadk        r43    k8 ; k8 = 178
.line	1191	loadk        r44   k35 ; k35 = 57
.line	1191	loadk        r45   k36 ; k36 = 7
.line	1191	loadk        r46   k37 ; k37 = 13
.line	1191	loadk        r47   k38 ; k38 = 147
.line	1191	loadk        r48  k122 ; k122 = 252
.line	1191	loadk        r49   k40 ; k40 = 149
.line	1191	loadk        r50  k123 ; k123 = 124
.line	1191	loadk        r51  k124 ; k124 = 5
.line	1191	loadk        r52  k125 ; k125 = 225
.line	1191	call         r12    41     2
.line	1191	getupval     r13    u1
.line	1191	loadk        r14  k173 ; k173 = 231
.line	1191	loadk        r15  k174 ; k174 = 33
.line	1191	loadk        r16  k141 ; k141 = 181
.line	1191	loadk        r17  k175 ; k175 = 217
.line	1191	call         r13     5     0
.line	1191	setlist      r11     0     1
.line	1191	call         r10     2     2
.line	1191	move         r11    r8
.line	1191	call          r9     3     1
.line	1191	gettable      r9    r5  k131 ; k131 = "CollectValues"
.line	1191	move         r10    r8
.line	1191	call          r9     2     2
.line	1191	gettable     r10    r5  k132 ; k132 = "ArrayUnique"
.line	1191	move         r11    r9
.line	1191	call         r10     2     2
.line	1191	move          r9   r10
.line	1191	gettabup     r10    u0  k176 ; k176 = "print"
.line	1191	gettabup     r11    u0    k1 ; k1 = "bWriteLog"
.line	1191	test         r11     0
.line	1191	jmp            0  l663
.line	1191	gettabup     r11    u0    k4 ; k4 = "table"
.line	1191	gettable     r11   r11    k5 ; k5 = "concat"
.line	1191	newtable     r12     1     0
.line	1191	getupval     r13    u1
.line	1191	loadk        r14    k6 ; k6 = 163
.line	1191	loadk        r15    k7 ; k7 = 31
.line	1191	loadk        r16    k8 ; k8 = 178
.line	1191	loadk        r17    k9 ; k9 = 205
.line	1191	loadk        r18   k10 ; k10 = 112
.line	1191	loadk        r19   k11 ; k11 = 66
.line	1191	loadk        r20   k12 ; k12 = 105
.line	1191	loadk        r21   k13 ; k13 = 131
.line	1191	loadk        r22   k14 ; k14 = 226
.line	1191	loadk        r23   k15 ; k15 = 229
.line	1191	loadk        r24   k16 ; k16 = 244
.line	1191	loadk        r25   k17 ; k17 = 103
.line	1191	loadk        r26   k18 ; k18 = 87
.line	1191	loadk        r27   k19 ; k19 = 254
.line	1191	loadk        r28   k20 ; k20 = 213
.line	1191	loadk        r29   k21 ; k21 = 21
.line	1191	loadk        r30   k22 ; k22 = 22
.line	1191	loadk        r31   k23 ; k23 = 12
.line	1191	loadk        r32   k16 ; k16 = 244
.line	1191	loadk        r33   k24 ; k24 = 238
.line	1191	loadk        r34   k25 ; k25 = 150
.line	1191	loadk        r35   k26 ; k26 = 100
.line	1191	loadk        r36   k27 ; k27 = 4
.line	1191	loadk        r37   k28 ; k28 = 190
.line	1191	loadk        r38   k29 ; k29 = 245
.line	1191	loadk        r39   k30 ; k30 = 220
.line	1191	loadk        r40   k31 ; k31 = 206
.line	1191	loadk        r41   k32 ; k32 = 116
.line	1191	loadk        r42   k33 ; k33 = 71
.line	1191	loadk        r43   k34 ; k34 = 249
.line	1191	loadk        r44    k8 ; k8 = 178
.line	1191	loadk        r45   k35 ; k35 = 57
.line	1191	loadk        r46   k36 ; k36 = 7
.line	1191	loadk        r47   k37 ; k37 = 13
.line	1191	loadk        r48   k38 ; k38 = 147
.line	1191	loadk        r49  k122 ; k122 = 252
.line	1191	loadk        r50   k40 ; k40 = 149
.line	1191	loadk        r51  k123 ; k123 = 124
.line	1191	loadk        r52  k124 ; k124 = 5
.line	1191	loadk        r53  k125 ; k125 = 225
.line	1191	call         r13    41     2
.line	1191	getupval     r14    u1
.line	1191	loadk        r15  k173 ; k173 = 231
.line	1191	loadk        r16  k174 ; k174 = 33
.line	1191	loadk        r17  k141 ; k141 = 181
.line	1191	loadk        r18  k175 ; k175 = 217
.line	1191	loadk        r19   k78 ; k78 = 52
.line	1191	loadk        r20  k177 ; k177 = 64
.line	1191	loadk        r21  k178 ; k178 = 115
.line	1191	loadk        r22   k40 ; k40 = 149
.line	1191	loadk        r23  k179 ; k179 = 200
.line	1191	loadk        r24  k180 ; k180 = 199
.line	1191	loadk        r25  k140 ; k140 = 215
.line	1191	loadk        r26   k12 ; k12 = 105
.line	1191	loadk        r27  k181 ; k181 = 77
.line	1191	loadk        r28  k182 ; k182 = 233
.line	1191	loadk        r29   k20 ; k20 = 213
.line	1191	call         r14    16     0
.line	1191	setlist      r12     0     1
.line	1191	call         r11     2     2
.line	1191	len          r12    r9
.line	1191	concat       r11   r11   r12
.label	l663
.line	1191	call         r10     2     1
.line	1191	len          r10    r9
.line	1191	lt             0  k101   r10 ; k101 = 0
.line	1191	jmp            0  l810
.line	1191	gettabup     r10    u0  k142 ; k142 = "pairs"
.line	1191	move         r11    r9
.line	1191	call         r10     2     4
.line	1191	jmp            0  l747
.line	1191	getupval     r15    u2
.line	1191	self         r15   r15  k143 ; k143 = "GetHallDepotItemData" (truncated)
.line	1191	move         r17   r14
.line	1191	call         r15     3     2
.line	1191	test         r15     0
.line	1191	jmp            0  l681
.line	1191	self         r16    r0  k183 ; k183 = "wardrobe_puton_req"
.line	1191	move         r18   r14
.line	1191	call         r16     3     1
.line	1191	jmp            0  l747
.label	l681
.line	1191	gettabup     r16    u0    k0 ; k0 = "log"
.line	1191	gettabup     r17    u0    k1 ; k1 = "bWriteLog"
.line	1191	test         r17     0
.line	1191	jmp            0  l746
.line	1191	gettabup     r17    u0    k4 ; k4 = "table"
.line	1191	gettable     r17   r17    k5 ; k5 = "concat"
.line	1191	newtable     r18     1     0
.line	1191	getupval     r19    u1
.line	1191	loadk        r20   k95 ; k95 = 212
.line	1191	loadk        r21  k145 ; k145 = 41
.line	1191	loadk        r22  k146 ; k146 = 161
.line	1191	loadk        r23  k147 ; k147 = 219
.line	1191	loadk        r24  k148 ; k148 = 102
.line	1191	loadk        r25  k107 ; k107 = 95
.line	1191	loadk        r26   k26 ; k26 = 100
.line	1191	loadk        r27  k149 ; k149 = 132
.line	1191	loadk        r28  k113 ; k113 = 203
.line	1191	loadk        r29  k150 ; k150 = 198
.line	1191	loadk        r30  k122 ; k122 = 252
.line	1191	loadk        r31   k12 ; k12 = 105
.line	1191	loadk        r32  k151 ; k151 = 93
.line	1191	loadk        r33  k152 ; k152 = 167
.line	1191	loadk        r34  k153 ; k153 = 188
.line	1191	loadk        r35  k154 ; k154 = 35
.line	1191	loadk        r36   k36 ; k36 = 7
.line	1191	loadk        r37   k92 ; k92 = 47
.line	1191	loadk        r38  k155 ; k155 = 194
.line	1191	loadk        r39  k156 ; k156 = 253
.line	1191	loadk        r40  k157 ; k157 = 128
.line	1191	loadk        r41   k49 ; k49 = 114
.line	1191	loadk        r42   k68 ; k68 = 25
.line	1191	loadk        r43   k43 ; k43 = 179
.line	1191	loadk        r44   k91 ; k91 = 242
.line	1191	loadk        r45  k122 ; k122 = 252
.line	1191	loadk        r46  k134 ; k134 = 239
.line	1191	loadk        r47  k158 ; k158 = 121
.line	1191	loadk        r48  k159 ; k159 = 90
.line	1191	loadk        r49  k160 ; k160 = 192
.line	1191	loadk        r50   k77 ; k77 = 144
.line	1191	loadk        r51  k161 ; k161 = 50
.line	1191	loadk        r52   k79 ; k79 = 6
.line	1191	loadk        r53  k162 ; k162 = 72
.line	1191	loadk        r54  k140 ; k140 = 215
.line	1191	loadk        r55   k19 ; k19 = 254
.line	1191	loadk        r56  k157 ; k157 = 128
.line	1191	loadk        r57  k163 ; k163 = 113
.line	1191	loadk        r58   k92 ; k92 = 47
.line	1191	loadk        r59  k164 ; k164 = 175
.line	1191	call         r19    41     2
.line	1191	getupval     r20    u1
.line	1191	loadk        r21   k15 ; k15 = 229
.line	1191	loadk        r22  k108 ; k108 = 39
.line	1191	loadk        r23  k165 ; k165 = 243
.line	1191	loadk        r24   k69 ; k69 = 209
.line	1191	loadk        r25  k110 ; k110 = 123
.line	1191	loadk        r26   k59 ; k59 = 68
.line	1191	loadk        r27  k166 ; k166 = 38
.line	1191	loadk        r28  k167 ; k167 = 135
.line	1191	loadk        r29   k39 ; k39 = 232
.line	1191	loadk        r30   k30 ; k30 = 220
.line	1191	loadk        r31   k29 ; k29 = 245
.line	1191	loadk        r32   k26 ; k26 = 100
.line	1191	call         r20    13     0
.line	1191	setlist      r18     0     1
.line	1191	call         r17     2     2
.label	l746
.line	1191	call         r16     2     1
.label	l747
.line	1191	move          r0    r0
.line	1191	move          r0    r0
.line	1191	jmp            0  l810
.label	l750
.line	1191	gettabup      r9    u0    k0 ; k0 = "log"
.line	1191	gettabup     r10    u0    k1 ; k1 = "bWriteLog"
.line	1191	test         r10     0
.line	1191	jmp            0  l809
.line	1191	gettabup     r10    u0    k4 ; k4 = "table"
.line	1191	gettable     r10   r10    k5 ; k5 = "concat"
.line	1191	newtable     r11     1     0
.line	1191	getupval     r12    u1
.line	1191	loadk        r13    k6 ; k6 = 163
.line	1191	loadk        r14    k7 ; k7 = 31
.line	1191	loadk        r15    k8 ; k8 = 178
.line	1191	loadk        r16    k9 ; k9 = 205
.line	1191	loadk        r17   k10 ; k10 = 112
.line	1191	loadk        r18   k11 ; k11 = 66
.line	1191	loadk        r19   k12 ; k12 = 105
.line	1191	loadk        r20   k13 ; k13 = 131
.line	1191	loadk        r21   k14 ; k14 = 226
.line	1191	loadk        r22   k15 ; k15 = 229
.line	1191	loadk        r23   k16 ; k16 = 244
.line	1191	loadk        r24   k17 ; k17 = 103
.line	1191	loadk        r25   k18 ; k18 = 87
.line	1191	loadk        r26   k19 ; k19 = 254
.line	1191	loadk        r27   k20 ; k20 = 213
.line	1191	loadk        r28   k21 ; k21 = 21
.line	1191	loadk        r29   k22 ; k22 = 22
.line	1191	loadk        r30   k23 ; k23 = 12
.line	1191	loadk        r31   k16 ; k16 = 244
.line	1191	loadk        r32   k24 ; k24 = 238
.line	1191	loadk        r33   k25 ; k25 = 150
.line	1191	loadk        r34   k26 ; k26 = 100
.line	1191	loadk        r35   k27 ; k27 = 4
.line	1191	loadk        r36   k28 ; k28 = 190
.line	1191	loadk        r37   k29 ; k29 = 245
.line	1191	loadk        r38   k30 ; k30 = 220
.line	1191	loadk        r39   k31 ; k31 = 206
.line	1191	loadk        r40   k32 ; k32 = 116
.line	1191	loadk        r41   k33 ; k33 = 71
.line	1191	loadk        r42   k34 ; k34 = 249
.line	1191	loadk        r43    k8 ; k8 = 178
.line	1191	loadk        r44   k35 ; k35 = 57
.line	1191	loadk        r45   k36 ; k36 = 7
.line	1191	loadk        r46   k37 ; k37 = 13
.line	1191	loadk        r47   k38 ; k38 = 147
.line	1191	loadk        r48  k128 ; k128 = 251
.line	1191	loadk        r49  k184 ; k184 = 157
.line	1191	loadk        r50   k97 ; k97 = 118
.line	1191	loadk        r51  k101 ; k101 = 0
.line	1191	loadk        r52  k125 ; k125 = 225
.line	1191	call         r12    41     2
.line	1191	getupval     r13    u1
.line	1191	loadk        r14   k74 ; k74 = 234
.line	1191	loadk        r15  k185 ; k185 = 59
.line	1191	loadk        r16  k165 ; k165 = 243
.line	1191	loadk        r17   k69 ; k69 = 209
.line	1191	loadk        r18  k129 ; k129 = 125
.line	1191	loadk        r19  k186 ; k186 = 92
.line	1191	call         r13     7     0
.line	1191	setlist      r11     0     1
.line	1191	call         r10     2     2
.label	l809
.line	1191	call          r9     2     1
.label	l810
.line	1191	settable      r0   k89  k187 ; k187 = nil
.label	l811
.line	1191	gettable      r4    r0   k84 ; k84 = "wardrobeEditMode"
.line	1191	settable      r0   k87    r4 ; k87 = "lastWardrobeEditMode"
.line	1191	settable      r0  k188    r2 ; k188 = "shareBagSubType"
.line	1191	gettable      r4    r0  k189 ; k189 = "isInShareSubscribeSe" (truncated)
.line	1191	gettable      r5    r3   k85 ; k85 = "EWardrobeEditMode"
.line	1191	gettable      r5    r5  k190 ; k190 = "ShareBag"
.line	1191	eq             1    r1    r5
.line	1191	jmp            0  l820
.line	1191	loadbool      r5     0     1
.label	l820
.line	1191	loadbool      r5     1     0
.line	1191	settable      r0  k189    r5 ; k189 = "isInShareSubscribeSe" (truncated)
.line	1191	test          r4     0
.line	1191	jmp            0  l829
.line	1191	gettable      r5    r0  k189 ; k189 = "isInShareSubscribeSe" (truncated)
.line	1191	test          r5     1
.line	1191	jmp            0  l829
.line	1191	self          r5    r0  k191 ; k191 = "SyncSubscribeShareIt" (truncated)
.line	1191	call          r5     2     1
.label	l829
.line	1191	return        r0     1
.line	1191	move          r0    r0
.line	1191	gettabup      r3    u1  k127 ; k127 = 45
.line	1191	return        r0     1

.function	main/f56

.source	null
.linedefined	1250
.lastlinedefined	1253
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"print"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	163
.constant	k7	31
.constant	k8	178
.constant	k9	205
.constant	k10	112
.constant	k11	66
.constant	k12	105
.constant	k13	131
.constant	k14	226
.constant	k15	229
.constant	k16	244
.constant	k17	103
.constant	k18	87
.constant	k19	254
.constant	k20	213
.constant	k21	1
.constant	k22	22
.constant	k23	12
.constant	k24	238
.constant	k25	150
.constant	k26	100
.constant	k27	4
.constant	k28	190
.constant	k29	245
.constant	k30	220
.constant	k31	206
.constant	k32	116
.constant	k33	71
.constant	k34	249
.constant	k35	57
.constant	k36	7
.constant	k37	13
.constant	k38	147
.constant	k39	236
.constant	k40	145
.constant	k41	124
.constant	k42	0
.constant	k43	239
.constant	k44	41
.constant	k45	161
.constant	k46	219
.constant	k47	102
.constant	k48	95
.constant	k49	132
.constant	k50	194
.constant	k51	242
.constant	k52	115
.constant	k53	139
.constant	k54	35
.constant	k55	73
.constant	k56	93
.constant	k57	208
.constant	k58	"wardrobeEditMode"

.line	1250	gettabup      r1    u0    k0 ; k0 = "print"
.line	1250	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1250	test          r2     0
.line	1250	jmp            0   l77
.line	1250	gettabup      r2    u0    k2 ; k2 = "string"
.line	1250	gettable      r2    r2    k3 ; k3 = "format"
.line	1250	gettabup      r3    u0    k4 ; k4 = "table"
.line	1250	gettable      r3    r3    k5 ; k5 = "concat"
.line	1250	newtable      r4     1     0
.line	1250	getupval      r5    u1
.line	1250	loadk         r6    k6 ; k6 = 163
.line	1250	loadk         r7    k7 ; k7 = 31
.line	1250	loadk         r8    k8 ; k8 = 178
.line	1250	loadk         r9    k9 ; k9 = 205
.line	1250	loadk        r10   k10 ; k10 = 112
.line	1250	loadk        r11   k11 ; k11 = 66
.line	1250	loadk        r12   k12 ; k12 = 105
.line	1250	loadk        r13   k13 ; k13 = 131
.line	1250	loadk        r14   k14 ; k14 = 226
.line	1250	loadk        r15   k15 ; k15 = 229
.line	1250	loadk        r16   k16 ; k16 = 244
.line	1250	loadk        r17   k17 ; k17 = 103
.line	1250	loadk        r18   k18 ; k18 = 87
.line	1250	loadk        r19   k19 ; k19 = 254
.line	1250	loadk        r20   k20 ; k20 = 213
.line	1250	loadk        r21   k21 ; k21 = 1
.line	1250	loadk        r22   k22 ; k22 = 22
.line	1250	loadk        r23   k23 ; k23 = 12
.line	1250	loadk        r24   k16 ; k16 = 244
.line	1250	loadk        r25   k24 ; k24 = 238
.line	1250	loadk        r26   k25 ; k25 = 150
.line	1250	loadk        r27   k26 ; k26 = 100
.line	1250	loadk        r28   k27 ; k27 = 4
.line	1250	loadk        r29   k28 ; k28 = 190
.line	1250	loadk        r30   k29 ; k29 = 245
.line	1250	loadk        r31   k30 ; k30 = 220
.line	1250	loadk        r32   k31 ; k31 = 206
.line	1250	loadk        r33   k32 ; k32 = 116
.line	1250	loadk        r34   k33 ; k33 = 71
.line	1250	loadk        r35   k34 ; k34 = 249
.line	1250	loadk        r36    k8 ; k8 = 178
.line	1250	loadk        r37   k35 ; k35 = 57
.line	1250	loadk        r38   k36 ; k36 = 7
.line	1250	loadk        r39   k37 ; k37 = 13
.line	1250	loadk        r40   k38 ; k38 = 147
.line	1250	loadk        r41   k39 ; k39 = 236
.line	1250	loadk        r42   k40 ; k40 = 145
.line	1250	loadk        r43   k41 ; k41 = 124
.line	1250	loadk        r44   k42 ; k42 = 0
.line	1250	loadk        r45   k43 ; k43 = 239
.line	1250	call          r5    41     2
.line	1250	getupval      r6    u1
.line	1250	loadk         r7   k16 ; k16 = 244
.line	1250	loadk         r8   k44 ; k44 = 41
.line	1250	loadk         r9   k45 ; k45 = 161
.line	1250	loadk        r10   k46 ; k46 = 219
.line	1250	loadk        r11   k47 ; k47 = 102
.line	1250	loadk        r12   k48 ; k48 = 95
.line	1250	loadk        r13   k26 ; k26 = 100
.line	1250	loadk        r14   k49 ; k49 = 132
.line	1250	loadk        r15   k50 ; k50 = 194
.line	1250	loadk        r16    k9 ; k9 = 205
.line	1250	loadk        r17   k51 ; k51 = 242
.line	1250	loadk        r18   k32 ; k32 = 116
.line	1250	loadk        r19   k52 ; k52 = 115
.line	1250	loadk        r20   k51 ; k51 = 242
.line	1250	loadk        r21   k53 ; k53 = 139
.line	1250	loadk        r22   k54 ; k54 = 35
.line	1250	loadk        r23   k55 ; k55 = 73
.line	1250	loadk        r24   k56 ; k56 = 93
.line	1250	loadk        r25   k57 ; k57 = 208
.line	1250	call          r6    20     0
.line	1250	setlist       r4     0     1
.line	1250	call          r3     2     2
.line	1250	gettable      r4    r0   k58 ; k58 = "wardrobeEditMode"
.line	1250	call          r2     3     2
.label	l77
.line	1250	call          r1     2     1
.line	1250	gettable      r1    r0   k58 ; k58 = "wardrobeEditMode"
.line	1250	return        r1     2
.line	1250	return        r0     1
.line	1250	move          r0    r0
.line	1250	move          r0    r0
.line	1250	return        r0     1

.function	main/f57

.source	null
.linedefined	1255
.lastlinedefined	1257
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	2	true

.constant	k0	"wardrobeEditMode"
.constant	k1	"EWardrobeEditMode"
.constant	k2	"FashionBag"

.line	1255	gettable      r1    r0    k0 ; k0 = "wardrobeEditMode"
.line	1255	gettabup      r2    u0    k1 ; k1 = "EWardrobeEditMode"
.line	1255	gettable      r2    r2    k2 ; k2 = "FashionBag"
.line	1255	eq             1    r1    r2
.line	1255	jmp            0    l7
.line	1255	loadbool      r1     0     1
.label	l7
.line	1255	loadbool      r1     1     0
.line	1255	return        r1     2
.line	1255	return        r0     1
.line	1255	move          r0    r0
.line	1255	move          r0    r0
.line	1255	return        r0     1

.function	main/f58

.source	null
.linedefined	1259
.lastlinedefined	1261
.numparams	1
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	2	true

.constant	k0	"wardrobeEditMode"
.constant	k1	"EWardrobeEditMode"
.constant	k2	"Inherit"

.line	1259	gettable      r1    r0    k0 ; k0 = "wardrobeEditMode"
.line	1259	gettabup      r2    u0    k1 ; k1 = "EWardrobeEditMode"
.line	1259	gettable      r2    r2    k2 ; k2 = "Inherit"
.line	1259	eq             1    r1    r2
.line	1259	jmp            0    l7
.line	1259	loadbool      r1     0     1
.label	l7
.line	1259	loadbool      r1     1     0
.line	1259	return        r1     2
.line	1259	return        r0     1
.line	1259	move          r0    r0
.line	1259	move          r0    r0
.line	1259	move          r0    r0
.line	1259	move          r0    r0
.line	1259	return        r0     1

.function	main/f59

.source	null
.linedefined	1263
.lastlinedefined	1265
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"currentShareType"

.line	1263	gettable      r1    r0    k0 ; k0 = "currentShareType"
.line	1263	return        r1     2
.line	1263	return        r0     1
.line	1263	move          r0    r0
.line	1263	move          r0    r0
.line	1263	move          r0    r0
.line	1263	move          r0    r0
.line	1263	return        r0     1

.function	main/f60

.source	null
.linedefined	1267
.lastlinedefined	1269
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"pageId"

.line	1267	settabup      u0    k0    r1 ; k0 = "pageId"
.line	1267	return        r0     1
.line	1267	move          r0    r0
.line	1267	move          r0    r0
.line	1267	return        r0     1

.function	main/f61

.source	null
.linedefined	1271
.lastlinedefined	1273
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"pageId"

.line	1271	gettabup      r1    u0    k0 ; k0 = "pageId"
.line	1271	return        r1     2
.line	1271	return        r0     1
.line	1271	move          r0    r0
.line	1271	return        r0     1

.function	main/f62

.source	null
.linedefined	1275
.lastlinedefined	1277
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"tabId"

.line	1275	settabup      u0    k0    r1 ; k0 = "tabId"
.line	1275	return        r0     1
.line	1275	move          r0    r0
.line	1275	move          r0    r0
.line	1275	return        r0     1

.function	main/f63

.source	null
.linedefined	1279
.lastlinedefined	1281
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"tabId"

.line	1279	gettabup      r1    u0    k0 ; k0 = "tabId"
.line	1279	return        r1     2
.line	1279	return        r0     1
.line	1279	move          r0    r0
.line	1279	return        r0     1

.function	main/f64

.source	null
.linedefined	1283
.lastlinedefined	1285
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"ThrowObjectType"

.line	1283	settabup      u0    k0    r1 ; k0 = "ThrowObjectType"
.line	1283	return        r0     1
.line	1283	move          r0    r0
.line	1283	move          r0    r0
.line	1283	move          r0    r0
.line	1283	move          r0    r0
.line	1283	return        r0     1

.function	main/f65

.source	null
.linedefined	1287
.lastlinedefined	1289
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"ThrowObjectType"

.line	1287	gettabup      r1    u0    k0 ; k0 = "ThrowObjectType"
.line	1287	return        r1     2
.line	1287	return        r0     1
.line	1287	move          r0    r0
.line	1287	return        r0     1

.function	main/f66

.source	null
.linedefined	1291
.lastlinedefined	1293
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"PlaneType"

.line	1291	settabup      u0    k0    r1 ; k0 = "PlaneType"
.line	1291	return        r0     1
.line	1291	move          r0    r0
.line	1291	move          r0    r0
.line	1291	move          r0    r0
.line	1291	return        r0     1

.function	main/f67

.source	null
.linedefined	1295
.lastlinedefined	1297
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.constant	k0	"PlaneType"

.line	1295	gettabup      r1    u0    k0 ; k0 = "PlaneType"
.line	1295	return        r1     2
.line	1295	return        r0     1
.line	1295	move          r0    r0
.line	1295	return        r0     1

.function	main/f68

.source	null
.linedefined	1299
.lastlinedefined	1301
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	8	true

.line	1299	getupval      r1    u0
.line	1299	return        r1     2
.line	1299	return        r0     1
.line	1299	move          r0    r0
.line	1299	move          r0    r0
.line	1299	move          r0    r0
.line	1299	return        r0     1

.function	main/f69

.source	null
.linedefined	1303
.lastlinedefined	1305
.numparams	2
.is_vararg	0
.maxstacksize	3

.line	1303	loadbool      r2     0     0
.line	1303	return        r2     2
.line	1303	return        r0     1
.line	1303	move          r0    r0
.line	1303	return        r0     1

.function	main/f70

.source	null
.linedefined	1307
.lastlinedefined	1309
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	11	true

.line	1307	setupval      r1    u0
.line	1307	return        r0     1
.line	1307	move          r0    r0
.line	1307	move          r0    r0
.line	1307	move          r0    r0
.line	1307	return        r0     1

.function	main/f71

.source	null
.linedefined	1311
.lastlinedefined	1313
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	11	true

.line	1311	getupval      r1    u0
.line	1311	return        r1     2
.line	1311	return        r0     1
.line	1311	move          r0    r0
.line	1311	move          r0    r0
.line	1311	move          r0    r0
.line	1311	move          r0    r0
.line	1311	return        r0     1

.function	main/f72

.source	null
.linedefined	1315
.lastlinedefined	1324
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	196
.constant	k4	41
.constant	k5	190
.constant	k6	218
.constant	k7	88
.constant	k8	69
.constant	k9	103
.constant	k10	207
.constant	k11	202
.constant	k12	198
.constant	k13	255
.constant	k14	46
.constant	k15	114
.constant	k16	242
.constant	k17	141
.constant	k18	36
.constant	k19	10
.constant	k20	86
.constant	k21	225
.constant	k22	238
.constant	k23	151
.constant	k24	101
.constant	k25	159
.constant	k26	206
.constant	k27	200
.constant	k28	120
.constant	k29	79
.constant	k30	158
.constant	k31	53
.constant	k32	23
.constant	k33	13
.constant	k34	193
.constant	k35	177
.constant	k36	152
.constant	k37	127
.constant	k38	1
.constant	k39	168
.constant	k40	224
.constant	k41	102
.constant	k42	134
.constant	k43	203
.constant	k44	125
.constant	k45	92
.constant	k46	117
.constant	k47	250
.constant	k48	95
.constant	k49	254
.constant	k50	155
.constant	k51	35
.constant	k52	45
.constant	k53	215
.constant	k54	230
.constant	k55	136
.constant	k56	115
.constant	k57	"ModuleManager"
.constant	k58	"GetModule"
.constant	k59	"LobbyModuleConfig"
.constant	k60	"NewCharacterNetSystem"
.constant	k61	"GetCurUsedCharacterID"
.constant	k62	"GetDefaultSuitItemID"
.constant	k63	0
.constant	k64	"tonumber"

.line	1315	gettabup      r0    u0    k0 ; k0 = "require"
.line	1315	gettabup      r1    u0    k1 ; k1 = "table"
.line	1315	gettable      r1    r1    k2 ; k2 = "concat"
.line	1315	newtable      r2     1     0
.line	1315	getupval      r3    u1
.line	1315	loadk         r4    k3 ; k3 = 196
.line	1315	loadk         r5    k4 ; k4 = 41
.line	1315	loadk         r6    k5 ; k5 = 190
.line	1315	loadk         r7    k6 ; k6 = 218
.line	1315	loadk         r8    k7 ; k7 = 88
.line	1315	loadk         r9    k8 ; k8 = 69
.line	1315	loadk        r10    k9 ; k9 = 103
.line	1315	loadk        r11   k10 ; k10 = 207
.line	1315	loadk        r12   k11 ; k11 = 202
.line	1315	loadk        r13   k12 ; k12 = 198
.line	1315	loadk        r14   k13 ; k13 = 255
.line	1315	loadk        r15   k14 ; k14 = 46
.line	1315	loadk        r16   k15 ; k15 = 114
.line	1315	loadk        r17   k16 ; k16 = 242
.line	1315	loadk        r18   k17 ; k17 = 141
.line	1315	loadk        r19   k18 ; k18 = 36
.line	1315	loadk        r20   k19 ; k19 = 10
.line	1315	loadk        r21   k20 ; k20 = 86
.line	1315	loadk        r22   k21 ; k21 = 225
.line	1315	loadk        r23   k22 ; k22 = 238
.line	1315	loadk        r24   k23 ; k23 = 151
.line	1315	loadk        r25   k24 ; k24 = 101
.line	1315	loadk        r26    k7 ; k7 = 88
.line	1315	loadk        r27   k25 ; k25 = 159
.line	1315	loadk        r28   k16 ; k16 = 242
.line	1315	loadk        r29   k26 ; k26 = 206
.line	1315	loadk        r30   k27 ; k27 = 200
.line	1315	loadk        r31   k28 ; k28 = 120
.line	1315	loadk        r32   k29 ; k29 = 79
.line	1315	loadk        r33   k13 ; k13 = 255
.line	1315	loadk        r34   k30 ; k30 = 158
.line	1315	loadk        r35   k31 ; k31 = 53
.line	1315	loadk        r36   k32 ; k32 = 23
.line	1315	loadk        r37   k33 ; k33 = 13
.line	1315	loadk        r38   k34 ; k34 = 193
.line	1315	loadk        r39   k35 ; k35 = 177
.line	1315	loadk        r40   k36 ; k36 = 152
.line	1315	loadk        r41   k37 ; k37 = 127
.line	1315	loadk        r42   k38 ; k38 = 1
.line	1315	loadk        r43   k39 ; k39 = 168
.line	1315	call          r3    41     2
.line	1315	getupval      r4    u1
.line	1315	loadk         r5   k40 ; k40 = 224
.line	1315	loadk         r6   k41 ; k41 = 102
.line	1315	loadk         r7   k42 ; k42 = 134
.line	1315	loadk         r8   k43 ; k43 = 203
.line	1315	loadk         r9   k44 ; k44 = 125
.line	1315	loadk        r10   k45 ; k45 = 92
.line	1315	loadk        r11   k46 ; k46 = 117
.line	1315	loadk        r12   k10 ; k10 = 207
.line	1315	loadk        r13    k3 ; k3 = 196
.line	1315	loadk        r14   k34 ; k34 = 193
.line	1315	loadk        r15   k47 ; k47 = 250
.line	1315	loadk        r16   k15 ; k15 = 114
.line	1315	loadk        r17   k48 ; k48 = 95
.line	1315	loadk        r18   k49 ; k49 = 254
.line	1315	loadk        r19   k50 ; k50 = 155
.line	1315	loadk        r20   k51 ; k51 = 35
.line	1315	loadk        r21   k38 ; k38 = 1
.line	1315	loadk        r22   k52 ; k52 = 45
.line	1315	loadk        r23   k53 ; k53 = 215
.line	1315	loadk        r24   k54 ; k54 = 230
.line	1315	loadk        r25   k55 ; k55 = 136
.line	1315	loadk        r26   k56 ; k56 = 115
.line	1315	call          r4    23     0
.line	1315	setlist       r2     0     1
.line	1315	call          r1     2     2
.line	1315	call          r0     2     2
.line	1315	gettabup      r1    u0   k57 ; k57 = "ModuleManager"
.line	1315	gettable      r1    r1   k58 ; k58 = "GetModule"
.line	1315	gettabup      r2    u0   k57 ; k57 = "ModuleManager"
.line	1315	gettable      r2    r2   k59 ; k59 = "LobbyModuleConfig"
.line	1315	gettable      r2    r2   k60 ; k60 = "NewCharacterNetSyste" (truncated)
.line	1315	call          r1     2     2
.line	1315	self          r2    r1   k61 ; k61 = "GetCurUsedCharacterI" (truncated)
.line	1315	call          r2     2     2
.line	1315	self          r3    r0   k62 ; k62 = "GetDefaultSuitItemID"
.line	1315	move          r5    r2
.line	1315	call          r3     3     2
.line	1315	test          r3     0
.line	1315	jmp            0   l94
.line	1315	len           r4    r3
.line	1315	lt             0   k63    r4 ; k63 = 0
.line	1315	jmp            0   l94
.line	1315	gettabup      r4    u0   k64 ; k64 = "tonumber"
.line	1315	gettable      r5    r3   k38 ; k38 = 1
.line	1315	tailcall      r4     2
.line	1315	return        r4     0
.label	l94
.line	1315	loadk         r4   k63 ; k63 = 0
.line	1315	return        r4     2
.line	1315	return        r0     1
.line	1315	move          r0    r0
.line	1315	return        r0     1

.function	main/f73

.source	null
.linedefined	1326
.lastlinedefined	1437
.numparams	5
.is_vararg	0
.maxstacksize	40

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	19	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	212
.constant	k3	41
.constant	k4	161
.constant	k5	219
.constant	k6	102
.constant	k7	95
.constant	k8	100
.constant	k9	132
.constant	k10	203
.constant	k11	198
.constant	k12	252
.constant	k13	105
.constant	k14	93
.constant	k15	167
.constant	k16	168
.constant	k17	35
.constant	k18	7
.constant	k19	43
.constant	k20	204
.constant	k21	253
.constant	k22	144
.constant	k23	67
.constant	k24	27
.constant	k25	209
.constant	k26	229
.constant	k27	115
.constant	k28	90
.constant	k29	228
.constant	k30	56
.constant	k31	"tostring"
.constant	k32	"ModuleManager"
.constant	k33	"GetModule"
.constant	k34	"LobbyModuleConfig"
.constant	k35	"NewCharacterSystem"
.constant	k36	"GetCurCharSkinList"
.constant	k37	"pairs"
.constant	k38	"ID"
.constant	k39	true
.constant	k40	"FashionBagEditUtils"
.constant	k41	"IsInFashionBagEditMode"
.constant	k42	"CommonModuleConfig"
.constant	k43	"logic_outfit_combination"
.constant	k44	"require"
.constant	k45	224
.constant	k46	36
.constant	k47	186
.constant	k48	218
.constant	k49	122
.constant	k50	68
.constant	k51	40
.constant	k52	130
.constant	k53	232
.constant	k54	196
.constant	k55	246
.constant	k56	111
.constant	k57	80
.constant	k58	179
.constant	k59	154
.constant	k60	47
.constant	k61	44
.constant	k62	13
.constant	k63	215
.constant	k64	230
.constant	k65	136

.line	1326	gettabup      r5    u0    k0 ; k0 = "log"
.line	1326	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1326	test          r6     0
.line	1326	jmp            0   l44
.line	1326	getupval      r6    u1
.line	1326	loadk         r7    k2 ; k2 = 212
.line	1326	loadk         r8    k3 ; k3 = 41
.line	1326	loadk         r9    k4 ; k4 = 161
.line	1326	loadk        r10    k5 ; k5 = 219
.line	1326	loadk        r11    k6 ; k6 = 102
.line	1326	loadk        r12    k7 ; k7 = 95
.line	1326	loadk        r13    k8 ; k8 = 100
.line	1326	loadk        r14    k9 ; k9 = 132
.line	1326	loadk        r15   k10 ; k10 = 203
.line	1326	loadk        r16   k11 ; k11 = 198
.line	1326	loadk        r17   k12 ; k12 = 252
.line	1326	loadk        r18   k13 ; k13 = 105
.line	1326	loadk        r19   k14 ; k14 = 93
.line	1326	loadk        r20   k15 ; k15 = 167
.line	1326	loadk        r21   k16 ; k16 = 168
.line	1326	loadk        r22   k17 ; k17 = 35
.line	1326	loadk        r23   k18 ; k18 = 7
.line	1326	loadk        r24   k19 ; k19 = 43
.line	1326	loadk        r25   k20 ; k20 = 204
.line	1326	loadk        r26   k21 ; k21 = 253
.line	1326	loadk        r27   k22 ; k22 = 144
.line	1326	loadk        r28   k23 ; k23 = 67
.line	1326	loadk        r29   k24 ; k24 = 27
.line	1326	loadk        r30    k4 ; k4 = 161
.line	1326	loadk        r31   k25 ; k25 = 209
.line	1326	loadk        r32   k20 ; k20 = 204
.line	1326	loadk        r33   k26 ; k26 = 229
.line	1326	loadk        r34   k27 ; k27 = 115
.line	1326	loadk        r35   k28 ; k28 = 90
.line	1326	loadk        r36   k29 ; k29 = 228
.line	1326	loadk        r37   k22 ; k22 = 144
.line	1326	loadk        r38   k30 ; k30 = 56
.line	1326	loadk        r39   k23 ; k23 = 67
.line	1326	call          r6    34     2
.line	1326	gettabup      r7    u0   k31 ; k31 = "tostring"
.line	1326	move          r8    r1
.line	1326	call          r7     2     2
.line	1326	concat        r6    r6    r7
.label	l44
.line	1326	call          r5     2     1
.line	1326	gettabup      r5    u0   k32 ; k32 = "ModuleManager"
.line	1326	gettable      r5    r5   k33 ; k33 = "GetModule"
.line	1326	gettabup      r6    u0   k32 ; k32 = "ModuleManager"
.line	1326	gettable      r6    r6   k34 ; k34 = "LobbyModuleConfig"
.line	1326	gettable      r6    r6   k35 ; k35 = "NewCharacterSystem"
.line	1326	call          r5     2     2
.line	1326	self          r6    r5   k36 ; k36 = "GetCurCharSkinList"
.line	1326	call          r6     2     2
.line	1326	newtable      r7     0     0
.line	1326	test          r6     0
.line	1326	jmp            0   l64
.line	1326	gettabup      r8    u0   k37 ; k37 = "pairs"
.line	1326	move          r9    r6
.line	1326	call          r8     2     4
.line	1326	jmp            0   l62
.line	1326	gettable     r13   r12   k38 ; k38 = "ID"
.line	1326	settable      r7   r13   k39 ; k39 = true
.label	l62
.line	1326	move          r0    r0
.line	1326	move          r0    r0
.label	l64
.line	1326	getupval      r8    u2
.line	1326	call          r8     1     2
.line	1326	gettabup      r9    u0   k32 ; k32 = "ModuleManager"
.line	1326	gettable      r9    r9   k33 ; k33 = "GetModule"
.line	1326	gettabup     r10    u0   k32 ; k32 = "ModuleManager"
.line	1326	gettable     r10   r10   k34 ; k34 = "LobbyModuleConfig"
.line	1326	gettable     r10   r10   k40 ; k40 = "FashionBagEditUtils"
.line	1326	call          r9     2     2
.line	1326	self         r10    r0   k41 ; k41 = "IsInFashionBagEditMo" (truncated)
.line	1326	call         r10     2     2
.line	1326	gettabup     r11    u0   k32 ; k32 = "ModuleManager"
.line	1326	gettable     r11   r11   k33 ; k33 = "GetModule"
.line	1326	gettabup     r12    u0   k32 ; k32 = "ModuleManager"
.line	1326	gettable     r12   r12   k42 ; k42 = "CommonModuleConfig"
.line	1326	gettable     r12   r12   k43 ; k43 = "logic_outfit_combina" (truncated)
.line	1326	call         r11     2     2
.line	1326	gettabup     r12    u0   k44 ; k44 = "require"
.line	1326	getupval     r13    u1
.line	1326	loadk        r14   k45 ; k45 = 224
.line	1326	loadk        r15   k46 ; k46 = 36
.line	1326	loadk        r16   k47 ; k47 = 186
.line	1326	loadk        r17   k48 ; k48 = 218
.line	1326	loadk        r18   k49 ; k49 = 122
.line	1326	loadk        r19   k50 ; k50 = 68
.line	1326	loadk        r20   k51 ; k51 = 40
.line	1326	loadk        r21   k52 ; k52 = 130
.line	1326	loadk        r22   k53 ; k53 = 232
.line	1326	loadk        r23   k54 ; k54 = 196
.line	1326	loadk        r24   k55 ; k55 = 246
.line	1326	loadk        r25   k56 ; k56 = 111
.line	1326	loadk        r26   k57 ; k57 = 80
.line	1326	loadk        r27   k58 ; k58 = 179
.line	1326	loadk        r28   k59 ; k59 = 154
.line	1326	loadk        r29   k60 ; k60 = 47
.line	1326	loadk        r30   k61 ; k61 = 44
.line	1326	loadk        r31   k62 ; k62 = 13
.line	1326	loadk        r32   k63 ; k63 = 215
.line	1326	loadk        r33   k64 ; k64 = 230
.line	1326	loadk        r34   k65 ; k65 = 136
.line	1326	call         r13    22     2
.line	1326	call         r12     2     2
.line	1326	closure      r13    f0
.line	1326	return       r13     2
.line	1326	return        r0     1
.line	1326	move          r0    r0
.line	1326	move          r0    r0
.line	1326	move          r0    r0
.line	1326	return        r0     1

.function	main/f73/f0

.source	null
.linedefined	1341
.lastlinedefined	1435
.numparams	2
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	3	true
.upvalue	"U1"	11	true
.upvalue	"U2"	4	true
.upvalue	"U3"	10	true
.upvalue	"U4"	9	true
.upvalue	"U5"	1	true
.upvalue	"U6"	2	true
.upvalue	"U7"	0	true
.upvalue	"U8"	7	true
.upvalue	"U9"	8	true
.upvalue	"U10"	0	false
.upvalue	"U11"	1	false

.constant	k0	"randomButton"
.constant	k1	"IsSuitWearing"
.constant	k2	"times"
.constant	k3	"mainItem"
.constant	k4	"isUsing"
.constant	k5	"IsItemInTryMap"
.constant	k6	"res_id"
.constant	k7	"High32Bits"
.constant	k8	"Low19Bits"
.constant	k9	"isCharUse"
.constant	k10	nil
.constant	k11	"IsCharacterUse"
.constant	k12	"isNew"
.constant	k13	true
.constant	k14	"quality"
.constant	k15	"extra"
.constant	k16	"displayQuality"
.constant	k17	"priority"
.constant	k18	"CalcSortPriorityOfSubType"
.constant	k19	"require"
.constant	k20	224
.constant	k21	36
.constant	k22	186
.constant	k23	218
.constant	k24	122
.constant	k25	68
.constant	k26	40
.constant	k27	146
.constant	k28	235
.constant	k29	220
.constant	k30	250
.constant	k31	46
.constant	k32	82
.constant	k33	242
.constant	k34	136
.constant	k35	47
.constant	k36	16
.constant	k37	86
.constant	k38	251
.constant	k39	145
.constant	k40	105
.constant	k41	2
.constant	k42	255
.constant	k43	214
.constant	k44	236
.constant	k45	121
.constant	k46	77
.constant	k47	210
.constant	k48	135
.constant	k49	37
.constant	k50	22
.constant	k51	1
.constant	k52	199
.constant	k53	"IsXSuit"
.constant	k54	"GetPeriodByItemId"
.constant	k55	"expireTS"
.constant	k56	0

.line	1341	getupval      r2    u0
.line	1341	test          r2     0
.line	1341	jmp            0   l38
.line	1341	gettable      r2    r0    k0 ; k0 = "randomButton"
.line	1341	gettable      r3    r1    k0 ; k0 = "randomButton"
.line	1341	eq             1    r2    r3
.line	1341	jmp            0   l11
.line	1341	gettable      r2    r0    k0 ; k0 = "randomButton"
.line	1341	return        r2     2
.line	1341	jmp            0   l36
.label	l11
.line	1341	getupval      r2    u1
.line	1341	self          r2    r2    k1 ; k1 = "IsSuitWearing"
.line	1341	move          r4    r0
.line	1341	call          r2     3     2
.line	1341	getupval      r3    u1
.line	1341	self          r3    r3    k1 ; k1 = "IsSuitWearing"
.line	1341	move          r5    r1
.line	1341	call          r3     3     2
.line	1341	eq             1    r2    r3
.line	1341	jmp            0   l22
.line	1341	return        r2     2
.label	l22
.line	1341	getupval      r4    u2
.line	1341	test          r4     0
.line	1341	jmp            0   l36
.line	1341	gettable      r4    r0    k2 ; k2 = "times"
.line	1341	gettable      r5    r1    k2 ; k2 = "times"
.line	1341	eq             1    r4    r5
.line	1341	jmp            0   l36
.line	1341	gettable      r4    r0    k2 ; k2 = "times"
.line	1341	gettable      r5    r1    k2 ; k2 = "times"
.line	1341	lt             1    r5    r4
.line	1341	jmp            0   l34
.line	1341	loadbool      r4     0     1
.label	l34
.line	1341	loadbool      r4     1     0
.line	1341	return        r4     2
.label	l36
.line	1341	gettable      r0    r0    k3 ; k3 = "mainItem"
.line	1341	gettable      r1    r1    k3 ; k3 = "mainItem"
.label	l38
.line	1341	getupval      r2    u3
.line	1341	test          r2     1
.line	1341	jmp            0   l48
.line	1341	gettable      r2    r0    k4 ; k4 = "isUsing"
.line	1341	gettable      r3    r1    k4 ; k4 = "isUsing"
.line	1341	eq             1    r2    r3
.line	1341	jmp            0   l61
.line	1341	gettable      r2    r0    k4 ; k4 = "isUsing"
.line	1341	return        r2     2
.line	1341	jmp            0   l61
.label	l48
.line	1341	getupval      r2    u4
.line	1341	self          r2    r2    k5 ; k5 = "IsItemInTryMap"
.line	1341	gettable      r4    r0    k6 ; k6 = "res_id"
.line	1341	loadbool      r5     0     0
.line	1341	call          r2     4     2
.line	1341	getupval      r3    u4
.line	1341	self          r3    r3    k5 ; k5 = "IsItemInTryMap"
.line	1341	gettable      r5    r1    k6 ; k6 = "res_id"
.line	1341	loadbool      r6     0     0
.line	1341	call          r3     4     2
.line	1341	eq             1    r2    r3
.line	1341	jmp            0   l61
.line	1341	return        r2     2
.label	l61
.line	1341	getupval      r2    u5
.line	1341	test          r2     0
.line	1341	jmp            0   l87
.line	1341	gettable      r2    r0    k7 ; k7 = "High32Bits"
.line	1341	gettable      r3    r1    k7 ; k7 = "High32Bits"
.line	1341	eq             1    r2    r3
.line	1341	jmp            0   l76
.line	1341	gettable      r2    r0    k7 ; k7 = "High32Bits"
.line	1341	gettable      r3    r1    k7 ; k7 = "High32Bits"
.line	1341	lt             1    r3    r2
.line	1341	jmp            0   l73
.line	1341	loadbool      r2     0     1
.label	l73
.line	1341	loadbool      r2     1     0
.line	1341	return        r2     2
.line	1341	jmp            0   l87
.label	l76
.line	1341	gettable      r2    r0    k8 ; k8 = "Low19Bits"
.line	1341	gettable      r3    r1    k8 ; k8 = "Low19Bits"
.line	1341	eq             1    r2    r3
.line	1341	jmp            0   l87
.line	1341	gettable      r2    r0    k8 ; k8 = "Low19Bits"
.line	1341	gettable      r3    r1    k8 ; k8 = "Low19Bits"
.line	1341	lt             1    r3    r2
.line	1341	jmp            0   l85
.line	1341	loadbool      r2     0     1
.label	l85
.line	1341	loadbool      r2     1     0
.line	1341	return        r2     2
.label	l87
.line	1341	getupval      r2    u6
.line	1341	test          r2     1
.line	1341	jmp            0  l112
.line	1341	gettable      r2    r0    k9 ; k9 = "isCharUse"
.line	1341	eq             0    r2   k10 ; k10 = nil
.line	1341	jmp            0   l98
.line	1341	getupval      r2    u7
.line	1341	self          r2    r2   k11 ; k11 = "IsCharacterUse"
.line	1341	gettable      r4    r0    k6 ; k6 = "res_id"
.line	1341	call          r2     3     2
.line	1341	settable      r0    k9    r2 ; k9 = "isCharUse"
.label	l98
.line	1341	gettable      r2    r1    k9 ; k9 = "isCharUse"
.line	1341	eq             0    r2   k10 ; k10 = nil
.line	1341	jmp            0  l106
.line	1341	getupval      r2    u7
.line	1341	self          r2    r2   k11 ; k11 = "IsCharacterUse"
.line	1341	gettable      r4    r1    k6 ; k6 = "res_id"
.line	1341	call          r2     3     2
.line	1341	settable      r1    k9    r2 ; k9 = "isCharUse"
.label	l106
.line	1341	gettable      r2    r0    k9 ; k9 = "isCharUse"
.line	1341	gettable      r3    r1    k9 ; k9 = "isCharUse"
.line	1341	eq             1    r2    r3
.line	1341	jmp            0  l112
.line	1341	gettable      r2    r0    k9 ; k9 = "isCharUse"
.line	1341	return        r2     2
.label	l112
.line	1341	gettable      r2    r0   k12 ; k12 = "isNew"
.line	1341	eq             1    r2   k13 ; k13 = true
.line	1341	jmp            0  l116
.line	1341	loadbool      r2     0     1
.label	l116
.line	1341	loadbool      r2     1     0
.line	1341	gettable      r3    r1   k12 ; k12 = "isNew"
.line	1341	eq             1    r3   k13 ; k13 = true
.line	1341	jmp            0  l121
.line	1341	loadbool      r3     0     1
.label	l121
.line	1341	loadbool      r3     1     0
.line	1341	eq             1    r2    r3
.line	1341	jmp            0  l126
.line	1341	gettable      r2    r0   k12 ; k12 = "isNew"
.line	1341	return        r2     2
.label	l126
.line	1341	gettable      r2    r0    k6 ; k6 = "res_id"
.line	1341	gettabup      r2    u8    r2
.line	1341	gettable      r3    r1    k6 ; k6 = "res_id"
.line	1341	gettabup      r3    u8    r3
.line	1341	eq             1    r2    r3
.line	1341	jmp            0  l135
.line	1341	gettable      r2    r0    k6 ; k6 = "res_id"
.line	1341	gettabup      r2    u8    r2
.line	1341	return        r2     2
.label	l135
.line	1341	gettable      r2    r0   k14 ; k14 = "quality"
.line	1341	gettable      r3    r1   k14 ; k14 = "quality"
.line	1341	gettable      r4    r0   k15 ; k15 = "extra"
.line	1341	test          r4     0
.line	1341	jmp            0  l146
.line	1341	gettable      r4    r0   k15 ; k15 = "extra"
.line	1341	gettable      r4    r4   k16 ; k16 = "displayQuality"
.line	1341	test          r4     0
.line	1341	jmp            0  l146
.line	1341	gettable      r4    r0   k15 ; k15 = "extra"
.line	1341	gettable      r2    r4   k16 ; k16 = "displayQuality"
.label	l146
.line	1341	gettable      r4    r1   k15 ; k15 = "extra"
.line	1341	test          r4     0
.line	1341	jmp            0  l155
.line	1341	gettable      r4    r1   k15 ; k15 = "extra"
.line	1341	gettable      r4    r4   k16 ; k16 = "displayQuality"
.line	1341	test          r4     0
.line	1341	jmp            0  l155
.line	1341	gettable      r4    r1   k15 ; k15 = "extra"
.line	1341	gettable      r3    r4   k16 ; k16 = "displayQuality"
.label	l155
.line	1341	eq             1    r2    r3
.line	1341	jmp            0  l162
.line	1341	lt             1    r3    r2
.line	1341	jmp            0  l160
.line	1341	loadbool      r4     0     1
.label	l160
.line	1341	loadbool      r4     1     0
.line	1341	return        r4     2
.label	l162
.line	1341	gettable      r4    r0   k17 ; k17 = "priority"
.line	1341	test          r4     1
.line	1341	jmp            0  l170
.line	1341	getupval      r4    u7
.line	1341	self          r4    r4   k18 ; k18 = "CalcSortPriorityOfSu" (truncated)
.line	1341	gettable      r6    r0    k6 ; k6 = "res_id"
.line	1341	call          r4     3     2
.line	1341	settable      r0   k17    r4 ; k17 = "priority"
.label	l170
.line	1341	gettable      r4    r1   k17 ; k17 = "priority"
.line	1341	test          r4     1
.line	1341	jmp            0  l178
.line	1341	getupval      r4    u7
.line	1341	self          r4    r4   k18 ; k18 = "CalcSortPriorityOfSu" (truncated)
.line	1341	gettable      r6    r1    k6 ; k6 = "res_id"
.line	1341	call          r4     3     2
.line	1341	settable      r1   k17    r4 ; k17 = "priority"
.label	l178
.line	1341	gettable      r4    r0   k17 ; k17 = "priority"
.line	1341	gettable      r5    r1   k17 ; k17 = "priority"
.line	1341	eq             1    r4    r5
.line	1341	jmp            0  l189
.line	1341	gettable      r4    r0   k17 ; k17 = "priority"
.line	1341	gettable      r5    r1   k17 ; k17 = "priority"
.line	1341	lt             1    r4    r5
.line	1341	jmp            0  l187
.line	1341	loadbool      r4     0     1
.label	l187
.line	1341	loadbool      r4     1     0
.line	1341	return        r4     2
.label	l189
.line	1341	getupval      r4    u9
.line	1341	test          r4     0
.line	1341	jmp            0  l213
.line	1341	gettable      r4    r0    k6 ; k6 = "res_id"
.line	1341	getupval      r5    u9
.line	1341	eq             1    r4    r5
.line	1341	jmp            0  l197
.line	1341	loadbool      r4     0     1
.label	l197
.line	1341	loadbool      r4     1     0
.line	1341	gettable      r5    r1    k6 ; k6 = "res_id"
.line	1341	getupval      r6    u9
.line	1341	eq             1    r5    r6
.line	1341	jmp            0  l203
.line	1341	loadbool      r5     0     1
.label	l203
.line	1341	loadbool      r5     1     0
.line	1341	eq             1    r4    r5
.line	1341	jmp            0  l213
.line	1341	gettable      r4    r0    k6 ; k6 = "res_id"
.line	1341	getupval      r5    u9
.line	1341	eq             1    r4    r5
.line	1341	jmp            0  l211
.line	1341	loadbool      r4     0     1
.label	l211
.line	1341	loadbool      r4     1     0
.line	1341	return        r4     2
.label	l213
.line	1341	gettabup      r4   u10   k19 ; k19 = "require"
.line	1341	getupval      r5   u11
.line	1341	loadk         r6   k20 ; k20 = 224
.line	1341	loadk         r7   k21 ; k21 = 36
.line	1341	loadk         r8   k22 ; k22 = 186
.line	1341	loadk         r9   k23 ; k23 = 218
.line	1341	loadk        r10   k24 ; k24 = 122
.line	1341	loadk        r11   k25 ; k25 = 68
.line	1341	loadk        r12   k26 ; k26 = 40
.line	1341	loadk        r13   k27 ; k27 = 146
.line	1341	loadk        r14   k28 ; k28 = 235
.line	1341	loadk        r15   k29 ; k29 = 220
.line	1341	loadk        r16   k30 ; k30 = 250
.line	1341	loadk        r17   k31 ; k31 = 46
.line	1341	loadk        r18   k32 ; k32 = 82
.line	1341	loadk        r19   k33 ; k33 = 242
.line	1341	loadk        r20   k34 ; k34 = 136
.line	1341	loadk        r21   k35 ; k35 = 47
.line	1341	loadk        r22   k36 ; k36 = 16
.line	1341	loadk        r23   k37 ; k37 = 86
.line	1341	loadk        r24   k38 ; k38 = 251
.line	1341	loadk        r25   k29 ; k29 = 220
.line	1341	loadk        r26   k39 ; k39 = 145
.line	1341	loadk        r27   k40 ; k40 = 105
.line	1341	loadk        r28   k41 ; k41 = 2
.line	1341	loadk        r29   k42 ; k42 = 255
.line	1341	loadk        r30   k38 ; k38 = 251
.line	1341	loadk        r31   k43 ; k43 = 214
.line	1341	loadk        r32   k44 ; k44 = 236
.line	1341	loadk        r33   k45 ; k45 = 121
.line	1341	loadk        r34   k46 ; k46 = 77
.line	1341	loadk        r35   k47 ; k47 = 210
.line	1341	loadk        r36   k48 ; k48 = 135
.line	1341	loadk        r37   k49 ; k49 = 37
.line	1341	loadk        r38   k50 ; k50 = 22
.line	1341	loadk        r39   k51 ; k51 = 1
.line	1341	loadk        r40   k52 ; k52 = 199
.line	1341	call          r5    36     2
.line	1341	call          r4     2     2
.line	1341	gettable      r5    r4   k53 ; k53 = "IsXSuit"
.line	1341	gettable      r6    r0    k6 ; k6 = "res_id"
.line	1341	call          r5     2     2
.line	1341	gettable      r6    r4   k53 ; k53 = "IsXSuit"
.line	1341	gettable      r7    r1    k6 ; k6 = "res_id"
.line	1341	call          r6     2     2
.line	1341	eq             1    r5    r6
.line	1341	jmp            0  l262
.line	1341	return        r5     2
.line	1341	jmp            0  l275
.label	l262
.line	1341	eq             0    r5   k13 ; k13 = true
.line	1341	jmp            0  l275
.line	1341	gettable      r7    r4   k54 ; k54 = "GetPeriodByItemId"
.line	1341	gettable      r8    r0    k6 ; k6 = "res_id"
.line	1341	call          r7     2     2
.line	1341	gettable      r8    r4   k54 ; k54 = "GetPeriodByItemId"
.line	1341	gettable      r9    r1    k6 ; k6 = "res_id"
.line	1341	call          r8     2     2
.line	1341	lt             1    r8    r7
.line	1341	jmp            0  l273
.line	1341	loadbool      r7     0     1
.label	l273
.line	1341	loadbool      r7     1     0
.line	1341	return        r7     2
.label	l275
.line	1341	gettable      r7    r0   k55 ; k55 = "expireTS"
.line	1341	eq             0    r7   k56 ; k56 = 0
.line	1341	jmp            0  l279
.line	1341	loadbool      r7     0     1
.label	l279
.line	1341	loadbool      r7     1     0
.line	1341	gettable      r8    r1   k55 ; k55 = "expireTS"
.line	1341	eq             0    r8   k56 ; k56 = 0
.line	1341	jmp            0  l284
.line	1341	loadbool      r8     0     1
.label	l284
.line	1341	loadbool      r8     1     0
.line	1341	eq             1    r7    r8
.line	1341	jmp            0  l289
.line	1341	return        r8     2
.line	1341	jmp            0  l315
.label	l289
.line	1341	gettable      r9    r0    k6 ; k6 = "res_id"
.line	1341	gettable     r10    r1    k6 ; k6 = "res_id"
.line	1341	eq             1    r9   r10
.line	1341	jmp            0  l301
.line	1341	gettable      r9    r0    k6 ; k6 = "res_id"
.line	1341	gettable     r10    r1    k6 ; k6 = "res_id"
.line	1341	lt             1    r9   r10
.line	1341	jmp            0  l298
.line	1341	loadbool      r9     0     1
.label	l298
.line	1341	loadbool      r9     1     0
.line	1341	return        r9     2
.line	1341	jmp            0  l315
.label	l301
.line	1341	gettable      r9    r0   k55 ; k55 = "expireTS"
.line	1341	gettable     r10    r1   k55 ; k55 = "expireTS"
.line	1341	eq             1    r9   r10
.line	1341	jmp            0  l313
.line	1341	gettable      r9    r0   k55 ; k55 = "expireTS"
.line	1341	gettable     r10    r1   k55 ; k55 = "expireTS"
.line	1341	lt             1    r9   r10
.line	1341	jmp            0  l310
.line	1341	loadbool      r9     0     1
.label	l310
.line	1341	loadbool      r9     1     0
.line	1341	return        r9     2
.line	1341	jmp            0  l315
.label	l313
.line	1341	loadbool      r9     0     0
.line	1341	return        r9     2
.label	l315
.line	1341	return        r0     1
.line	1341	move          r0    r0
.line	1341	move          r0    r0
.line	1341	return        r0     1

.function	main/f74

.source	null
.linedefined	1439
.lastlinedefined	1535
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	19	true
.upvalue	"U2"	1	true

.constant	k0	"GetSortPreference"
.constant	k1	"ModuleManager"
.constant	k2	"GetModule"
.constant	k3	"LobbyModuleConfig"
.constant	k4	"wardrobe_red_point"
.constant	k5	"GetTabByWardrobeTab"
.constant	k6	"subTabId"
.constant	k7	"NewCharacterSystem"
.constant	k8	"GetCurCharSkinList"
.constant	k9	"pairs"
.constant	k10	"ID"
.constant	k11	true
.constant	k12	"require"
.constant	k13	224
.constant	k14	36
.constant	k15	186
.constant	k16	218
.constant	k17	122
.constant	k18	68
.constant	k19	40
.constant	k20	146
.constant	k21	235
.constant	k22	220
.constant	k23	250
.constant	k24	46
.constant	k25	82
.constant	k26	242
.constant	k27	136
.constant	k28	47
.constant	k29	16
.constant	k30	86
.constant	k31	251
.constant	k32	145
.constant	k33	105
.constant	k34	2
.constant	k35	255
.constant	k36	214
.constant	k37	236
.constant	k38	121
.constant	k39	77
.constant	k40	210
.constant	k41	135
.constant	k42	37
.constant	k43	22
.constant	k44	1
.constant	k45	199
.constant	k46	"FashionBagEditUtils"
.constant	k47	"IsInFashionBagEditMode"

.line	1439	self          r4    r0    k0 ; k0 = "GetSortPreference"
.line	1439	move          r6    r2
.line	1439	call          r4     3     2
.line	1439	gettabup      r5    u0    k1 ; k1 = "ModuleManager"
.line	1439	gettable      r5    r5    k2 ; k2 = "GetModule"
.line	1439	gettabup      r6    u0    k1 ; k1 = "ModuleManager"
.line	1439	gettable      r6    r6    k3 ; k3 = "LobbyModuleConfig"
.line	1439	gettable      r6    r6    k4 ; k4 = "wardrobe_red_point"
.line	1439	call          r5     2     2
.line	1439	self          r6    r5    k5 ; k5 = "GetTabByWardrobeTab"
.line	1439	gettable      r8    r2    k6 ; k6 = "subTabId"
.line	1439	call          r6     3     2
.line	1439	gettabup      r7    u0    k1 ; k1 = "ModuleManager"
.line	1439	gettable      r7    r7    k2 ; k2 = "GetModule"
.line	1439	gettabup      r8    u0    k1 ; k1 = "ModuleManager"
.line	1439	gettable      r8    r8    k3 ; k3 = "LobbyModuleConfig"
.line	1439	gettable      r8    r8    k7 ; k7 = "NewCharacterSystem"
.line	1439	call          r7     2     2
.line	1439	self          r8    r7    k8 ; k8 = "GetCurCharSkinList"
.line	1439	call          r8     2     2
.line	1439	newtable      r9     0     0
.line	1439	test          r8     0
.line	1439	jmp            0   l32
.line	1439	gettabup     r10    u0    k9 ; k9 = "pairs"
.line	1439	move         r11    r8
.line	1439	call         r10     2     4
.line	1439	jmp            0   l30
.line	1439	gettable     r15   r14   k10 ; k10 = "ID"
.line	1439	settable      r9   r15   k11 ; k11 = true
.label	l30
.line	1439	move          r0    r0
.line	1439	move          r0    r0
.label	l32
.line	1439	getupval     r10    u1
.line	1439	call         r10     1     2
.line	1439	gettabup     r11    u0   k12 ; k12 = "require"
.line	1439	getupval     r12    u2
.line	1439	loadk        r13   k13 ; k13 = 224
.line	1439	loadk        r14   k14 ; k14 = 36
.line	1439	loadk        r15   k15 ; k15 = 186
.line	1439	loadk        r16   k16 ; k16 = 218
.line	1439	loadk        r17   k17 ; k17 = 122
.line	1439	loadk        r18   k18 ; k18 = 68
.line	1439	loadk        r19   k19 ; k19 = 40
.line	1439	loadk        r20   k20 ; k20 = 146
.line	1439	loadk        r21   k21 ; k21 = 235
.line	1439	loadk        r22   k22 ; k22 = 220
.line	1439	loadk        r23   k23 ; k23 = 250
.line	1439	loadk        r24   k24 ; k24 = 46
.line	1439	loadk        r25   k25 ; k25 = 82
.line	1439	loadk        r26   k26 ; k26 = 242
.line	1439	loadk        r27   k27 ; k27 = 136
.line	1439	loadk        r28   k28 ; k28 = 47
.line	1439	loadk        r29   k29 ; k29 = 16
.line	1439	loadk        r30   k30 ; k30 = 86
.line	1439	loadk        r31   k31 ; k31 = 251
.line	1439	loadk        r32   k22 ; k22 = 220
.line	1439	loadk        r33   k32 ; k32 = 145
.line	1439	loadk        r34   k33 ; k33 = 105
.line	1439	loadk        r35   k34 ; k34 = 2
.line	1439	loadk        r36   k35 ; k35 = 255
.line	1439	loadk        r37   k31 ; k31 = 251
.line	1439	loadk        r38   k36 ; k36 = 214
.line	1439	loadk        r39   k37 ; k37 = 236
.line	1439	loadk        r40   k38 ; k38 = 121
.line	1439	loadk        r41   k39 ; k39 = 77
.line	1439	loadk        r42   k40 ; k40 = 210
.line	1439	loadk        r43   k41 ; k41 = 135
.line	1439	loadk        r44   k42 ; k42 = 37
.line	1439	loadk        r45   k43 ; k43 = 22
.line	1439	loadk        r46   k44 ; k44 = 1
.line	1439	loadk        r47   k45 ; k45 = 199
.line	1439	call         r12    36     2
.line	1439	call         r11     2     2
.line	1439	gettabup     r12    u0    k1 ; k1 = "ModuleManager"
.line	1439	gettable     r12   r12    k2 ; k2 = "GetModule"
.line	1439	gettabup     r13    u0    k1 ; k1 = "ModuleManager"
.line	1439	gettable     r13   r13    k3 ; k3 = "LobbyModuleConfig"
.line	1439	gettable     r13   r13   k46 ; k46 = "FashionBagEditUtils"
.line	1439	call         r12     2     2
.line	1439	self         r13    r0   k47 ; k47 = "IsInFashionBagEditMo" (truncated)
.line	1439	call         r13     2     2
.line	1439	closure      r14    f0
.line	1439	return       r14     2
.line	1439	return        r0     1
.line	1439	move          r0    r0
.line	1439	return        r0     1

.function	main/f74/f0

.source	null
.linedefined	1455
.lastlinedefined	1533
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	13	true
.upvalue	"U1"	1	true
.upvalue	"U2"	12	true
.upvalue	"U3"	4	true
.upvalue	"U4"	0	true
.upvalue	"U5"	3	true
.upvalue	"U6"	6	true
.upvalue	"U7"	0	false
.upvalue	"U8"	9	true
.upvalue	"U9"	10	true
.upvalue	"U10"	11	true

.constant	k0	"insID"
.constant	k1	"IsItemInTryMap"
.constant	k2	"resID"
.constant	k3	"High32Bits"
.constant	k4	"ExtractHigh32Bits"
.constant	k5	"Low19Bits"
.constant	k6	"ExtractLow19Bits"
.constant	k7	"IsCharacterUse"
.constant	k8	"CheckInstance"
.constant	k9	"tonumber"
.constant	k10	"itemQuality"
.constant	k11	"itemSubType"
.constant	k12	"IsXSuit"
.constant	k13	"GetPeriodByItemId"
.constant	k14	"expireTS"
.constant	k15	0

.line	1455	getupval      r2    u0
.line	1455	test          r2     1
.line	1455	jmp            0   l14
.line	1455	gettable      r2    r0    k0 ; k0 = "insID"
.line	1455	gettabup      r2    u1    r2
.line	1455	gettable      r3    r1    k0 ; k0 = "insID"
.line	1455	gettabup      r3    u1    r3
.line	1455	eq             1    r2    r3
.line	1455	jmp            0   l27
.line	1455	gettable      r2    r0    k0 ; k0 = "insID"
.line	1455	gettabup      r2    u1    r2
.line	1455	return        r2     2
.line	1455	jmp            0   l27
.label	l14
.line	1455	getupval      r2    u2
.line	1455	self          r2    r2    k1 ; k1 = "IsItemInTryMap"
.line	1455	gettable      r4    r0    k2 ; k2 = "resID"
.line	1455	loadbool      r5     0     0
.line	1455	call          r2     4     2
.line	1455	getupval      r3    u2
.line	1455	self          r3    r3    k1 ; k1 = "IsItemInTryMap"
.line	1455	gettable      r5    r1    k2 ; k2 = "resID"
.line	1455	loadbool      r6     0     0
.line	1455	call          r3     4     2
.line	1455	eq             1    r2    r3
.line	1455	jmp            0   l27
.line	1455	return        r2     2
.label	l27
.line	1455	getupval      r2    u3
.line	1455	test          r2     0
.line	1455	jmp            0   l95
.line	1455	gettable      r2    r0    k3 ; k3 = "High32Bits"
.line	1455	test          r2     1
.line	1455	jmp            0   l38
.line	1455	getupval      r2    u4
.line	1455	self          r2    r2    k4 ; k4 = "ExtractHigh32Bits"
.line	1455	gettable      r4    r0    k0 ; k0 = "insID"
.line	1455	call          r2     3     2
.line	1455	settable      r0    k3    r2 ; k3 = "High32Bits"
.label	l38
.line	1455	gettable      r2    r1    k3 ; k3 = "High32Bits"
.line	1455	test          r2     1
.line	1455	jmp            0   l46
.line	1455	getupval      r2    u4
.line	1455	self          r2    r2    k4 ; k4 = "ExtractHigh32Bits"
.line	1455	gettable      r4    r1    k0 ; k0 = "insID"
.line	1455	call          r2     3     2
.line	1455	settable      r1    k3    r2 ; k3 = "High32Bits"
.label	l46
.line	1455	gettable      r2    r0    k3 ; k3 = "High32Bits"
.line	1455	gettable      r3    r1    k3 ; k3 = "High32Bits"
.line	1455	eq             1    r2    r3
.line	1455	jmp            0   l57
.line	1455	gettable      r2    r0    k3 ; k3 = "High32Bits"
.line	1455	gettable      r3    r1    k3 ; k3 = "High32Bits"
.line	1455	lt             1    r3    r2
.line	1455	jmp            0   l55
.line	1455	loadbool      r2     0     1
.label	l55
.line	1455	loadbool      r2     1     0
.line	1455	return        r2     2
.label	l57
.line	1455	gettable      r2    r0    k5 ; k5 = "Low19Bits"
.line	1455	test          r2     1
.line	1455	jmp            0   l65
.line	1455	getupval      r2    u4
.line	1455	self          r2    r2    k6 ; k6 = "ExtractLow19Bits"
.line	1455	gettable      r4    r0    k0 ; k0 = "insID"
.line	1455	call          r2     3     2
.line	1455	settable      r0    k5    r2 ; k5 = "Low19Bits"
.label	l65
.line	1455	gettable      r2    r1    k5 ; k5 = "Low19Bits"
.line	1455	test          r2     1
.line	1455	jmp            0   l73
.line	1455	getupval      r2    u4
.line	1455	self          r2    r2    k6 ; k6 = "ExtractLow19Bits"
.line	1455	gettable      r4    r1    k0 ; k0 = "insID"
.line	1455	call          r2     3     2
.line	1455	settable      r1    k5    r2 ; k5 = "Low19Bits"
.label	l73
.line	1455	gettable      r2    r0    k3 ; k3 = "High32Bits"
.line	1455	gettable      r3    r1    k3 ; k3 = "High32Bits"
.line	1455	eq             1    r2    r3
.line	1455	jmp            0   l84
.line	1455	gettable      r2    r0    k3 ; k3 = "High32Bits"
.line	1455	gettable      r3    r1    k3 ; k3 = "High32Bits"
.line	1455	lt             1    r3    r2
.line	1455	jmp            0   l82
.line	1455	loadbool      r2     0     1
.label	l82
.line	1455	loadbool      r2     1     0
.line	1455	return        r2     2
.label	l84
.line	1455	gettable      r2    r0    k5 ; k5 = "Low19Bits"
.line	1455	gettable      r3    r1    k5 ; k5 = "Low19Bits"
.line	1455	eq             1    r2    r3
.line	1455	jmp            0   l95
.line	1455	gettable      r2    r0    k5 ; k5 = "Low19Bits"
.line	1455	gettable      r3    r1    k5 ; k5 = "Low19Bits"
.line	1455	lt             1    r3    r2
.line	1455	jmp            0   l93
.line	1455	loadbool      r2     0     1
.label	l93
.line	1455	loadbool      r2     1     0
.line	1455	return        r2     2
.label	l95
.line	1455	getupval      r2    u5
.line	1455	test          r2     1
.line	1455	jmp            0  l109
.line	1455	getupval      r2    u4
.line	1455	self          r2    r2    k7 ; k7 = "IsCharacterUse"
.line	1455	gettable      r4    r0    k2 ; k2 = "resID"
.line	1455	call          r2     3     2
.line	1455	getupval      r3    u4
.line	1455	self          r3    r3    k7 ; k7 = "IsCharacterUse"
.line	1455	gettable      r5    r1    k2 ; k2 = "resID"
.line	1455	call          r3     3     2
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l109
.line	1455	return        r2     2
.label	l109
.line	1455	getupval      r2    u6
.line	1455	test          r2     0
.line	1455	jmp            0  l127
.line	1455	getupval      r2    u6
.line	1455	self          r2    r2    k8 ; k8 = "CheckInstance"
.line	1455	gettabup      r4    u7    k9 ; k9 = "tonumber"
.line	1455	gettable      r5    r0    k0 ; k0 = "insID"
.line	1455	call          r4     2     0
.line	1455	call          r2     0     2
.line	1455	getupval      r3    u6
.line	1455	self          r3    r3    k8 ; k8 = "CheckInstance"
.line	1455	gettabup      r5    u7    k9 ; k9 = "tonumber"
.line	1455	gettable      r6    r1    k0 ; k0 = "insID"
.line	1455	call          r5     2     0
.line	1455	call          r3     0     2
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l127
.line	1455	return        r2     2
.label	l127
.line	1455	gettable      r2    r0    k2 ; k2 = "resID"
.line	1455	move          r0    r0
.line	1455	gettable      r3    r1    k2 ; k2 = "resID"
.line	1455	move          r0    r0
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l136
.line	1455	gettable      r2    r0    k2 ; k2 = "resID"
.line	1455	move          r0    r0
.line	1455	return        r2     2
.label	l136
.line	1455	gettable      r2    r0   k10 ; k10 = "itemQuality"
.line	1455	gettable      r3    r1   k10 ; k10 = "itemQuality"
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l150
.line	1455	gettable      r2    r1   k10 ; k10 = "itemQuality"
.line	1455	test          r2     0
.line	1455	jmp            0  l148
.line	1455	gettable      r2    r0   k10 ; k10 = "itemQuality"
.line	1455	gettable      r3    r1   k10 ; k10 = "itemQuality"
.line	1455	lt             1    r3    r2
.line	1455	jmp            0  l148
.line	1455	loadbool      r2     0     1
.label	l148
.line	1455	loadbool      r2     1     0
.line	1455	return        r2     2
.label	l150
.line	1455	gettable      r2    r0   k11 ; k11 = "itemSubType"
.line	1455	gettable      r3    r1   k11 ; k11 = "itemSubType"
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l164
.line	1455	gettable      r2    r1   k11 ; k11 = "itemSubType"
.line	1455	test          r2     0
.line	1455	jmp            0  l162
.line	1455	gettable      r2    r0   k11 ; k11 = "itemSubType"
.line	1455	gettable      r3    r1   k11 ; k11 = "itemSubType"
.line	1455	lt             1    r3    r2
.line	1455	jmp            0  l162
.line	1455	loadbool      r2     0     1
.label	l162
.line	1455	loadbool      r2     1     0
.line	1455	return        r2     2
.label	l164
.line	1455	move          r0    r0
.line	1455	test          r2     0
.line	1455	jmp            0  l188
.line	1455	gettable      r2    r0    k2 ; k2 = "resID"
.line	1455	move          r0    r0
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l172
.line	1455	loadbool      r2     0     1
.label	l172
.line	1455	loadbool      r2     1     0
.line	1455	gettable      r3    r1    k2 ; k2 = "resID"
.line	1455	move          r0    r0
.line	1455	eq             1    r3    r4
.line	1455	jmp            0  l178
.line	1455	loadbool      r3     0     1
.label	l178
.line	1455	loadbool      r3     1     0
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l188
.line	1455	gettable      r2    r0    k2 ; k2 = "resID"
.line	1455	move          r0    r0
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l186
.line	1455	loadbool      r2     0     1
.label	l186
.line	1455	loadbool      r2     1     0
.line	1455	return        r2     2
.label	l188
.line	1455	move          r0    r0
.line	1455	gettable      r3    r0    k2 ; k2 = "resID"
.line	1455	call          r2     2     2
.line	1455	move          r0    r0
.line	1455	gettable      r4    r1    k2 ; k2 = "resID"
.line	1455	call          r3     2     2
.line	1455	eq             1    r2    r3
.line	1455	jmp            0  l198
.line	1455	return        r2     2
.line	1455	jmp            0  l211
.label	l198
.line	1455	test          r2     0
.line	1455	jmp            0  l211
.line	1455	move          r0    r0
.line	1455	gettable      r5    r0    k2 ; k2 = "resID"
.line	1455	call          r4     2     2
.line	1455	move          r0    r0
.line	1455	gettable      r6    r1    k2 ; k2 = "resID"
.line	1455	call          r5     2     2
.line	1455	lt             1    r5    r4
.line	1455	jmp            0  l209
.line	1455	loadbool      r4     0     1
.label	l209
.line	1455	loadbool      r4     1     0
.line	1455	return        r4     2
.label	l211
.line	1455	gettable      r4    r0   k14 ; k14 = "expireTS"
.line	1455	eq             0    r4   k15 ; k15 = 0
.line	1455	jmp            0  l215
.line	1455	loadbool      r4     0     1
.label	l215
.line	1455	loadbool      r4     1     0
.line	1455	gettable      r5    r1   k14 ; k14 = "expireTS"
.line	1455	eq             0    r5   k15 ; k15 = 0
.line	1455	jmp            0  l220
.line	1455	loadbool      r5     0     1
.label	l220
.line	1455	loadbool      r5     1     0
.line	1455	eq             1    r4    r5
.line	1455	jmp            0  l225
.line	1455	return        r5     2
.line	1455	jmp            0  l248
.label	l225
.line	1455	gettable      r6    r0    k2 ; k2 = "resID"
.line	1455	gettable      r7    r1    k2 ; k2 = "resID"
.line	1455	eq             1    r6    r7
.line	1455	jmp            0  l237
.line	1455	gettable      r6    r0    k2 ; k2 = "resID"
.line	1455	gettable      r7    r1    k2 ; k2 = "resID"
.line	1455	lt             1    r6    r7
.line	1455	jmp            0  l234
.line	1455	loadbool      r6     0     1
.label	l234
.line	1455	loadbool      r6     1     0
.line	1455	return        r6     2
.line	1455	jmp            0  l248
.label	l237
.line	1455	gettable      r6    r0   k14 ; k14 = "expireTS"
.line	1455	gettable      r7    r1   k14 ; k14 = "expireTS"
.line	1455	eq             1    r6    r7
.line	1455	jmp            0  l248
.line	1455	gettable      r6    r0   k14 ; k14 = "expireTS"
.line	1455	gettable      r7    r1   k14 ; k14 = "expireTS"
.line	1455	lt             1    r6    r7
.line	1455	jmp            0  l246
.line	1455	loadbool      r6     0     1
.label	l246
.line	1455	loadbool      r6     1     0
.line	1455	return        r6     2
.label	l248
.line	1455	loadbool      r6     0     0
.line	1455	return        r6     2
.line	1455	return        r0     1
.line	1455	move          r0    r0
.line	1455	move          r0    r0
.line	1455	return        r0     1

.function	main/f75

.source	null
.linedefined	1537
.lastlinedefined	1539
.numparams	4
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false

.constant	k0	"table"
.constant	k1	"sort"
.constant	k2	"GetSortCmpFunction"

.line	1537	gettabup      r4    u0    k0 ; k0 = "table"
.line	1537	gettable      r4    r4    k1 ; k1 = "sort"
.line	1537	move          r5    r1
.line	1537	self          r6    r0    k2 ; k2 = "GetSortCmpFunction"
.line	1537	move          r8    r2
.line	1537	move          r9    r3
.line	1537	call          r6     4     0
.line	1537	call          r4     0     1
.line	1537	return        r0     1
.line	1537	move          r0    r0
.line	1537	move          r0    r0
.line	1537	move          r0    r0
.line	1537	move          r0    r0
.line	1537	return        r0     1

.function	main/f76

.source	null
.linedefined	1541
.lastlinedefined	1543
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"_CanLazySort"

.line	1541	gettable      r1    r0    k0 ; k0 = "_CanLazySort"
.line	1541	return        r1     2
.line	1541	return        r0     1
.line	1541	move          r0    r0
.line	1541	move          r0    r0
.line	1541	return        r0     1

.function	main/f77

.source	null
.linedefined	1545
.lastlinedefined	1547
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"_LazySortType"

.line	1545	gettable      r1    r0    k0 ; k0 = "_LazySortType"
.line	1545	return        r1     2
.line	1545	return        r0     1
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	return        r0     1

.function	main/f78

.source	null
.linedefined	1549
.lastlinedefined	1552
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"CDataTable"
.constant	k1	"GetTableData"
.constant	k2	202
.constant	k3	60
.constant	k4	182
.constant	k5	210
.constant	k6	"ItemSubType"
.constant	k7	0

.line	1549	gettabup      r2    u0    k0 ; k0 = "CDataTable"
.line	1549	gettable      r2    r2    k1 ; k1 = "GetTableData"
.line	1549	getupval      r3    u1
.line	1549	loadk         r4    k2 ; k2 = 202
.line	1549	loadk         r5    k3 ; k3 = 60
.line	1549	loadk         r6    k4 ; k4 = 182
.line	1549	loadk         r7    k5 ; k5 = 210
.line	1549	call          r3     5     2
.line	1549	move          r4    r1
.line	1549	call          r2     3     2
.line	1549	test          r2     0
.line	1549	jmp            0   l16
.line	1549	gettable      r3    r2    k6 ; k6 = "ItemSubType"
.line	1549	test          r3     1
.line	1549	jmp            0   l17
.label	l16
.line	1549	loadk         r3    k7 ; k7 = 0
.label	l17
.line	1549	return        r3     2
.line	1549	return        r0     1
.line	1549	move          r0    r0
.line	1549	return        r0     1

.function	main/f79

.source	null
.linedefined	1554
.lastlinedefined	1557
.numparams	2
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	143
.constant	k9	226
.constant	k10	221
.constant	k11	236
.constant	k12	111
.constant	k13	76
.constant	k14	246
.constant	k15	193
.constant	k16	22
.constant	k17	1
.constant	k18	23
.constant	k19	215
.constant	k20	135
.constant	k21	26
.constant	k22	255
.constant	k23	192
.constant	k24	216
.constant	k25	249
.constant	k26	116
.constant	k27	124
.constant	k28	157
.constant	k29	51
.constant	k30	43
.constant	k31	9
.constant	k32	251
.constant	k33	152
.constant	k34	117
.constant	k35	20
.constant	k36	"send_depot_batch_put_down_req"

.line	1554	gettabup      r2    u0    k0 ; k0 = "require"
.line	1554	getupval      r3    u1
.line	1554	loadk         r4    k1 ; k1 = 224
.line	1554	loadk         r5    k2 ; k2 = 36
.line	1554	loadk         r6    k3 ; k3 = 186
.line	1554	loadk         r7    k4 ; k4 = 218
.line	1554	loadk         r8    k5 ; k5 = 122
.line	1554	loadk         r9    k6 ; k6 = 68
.line	1554	loadk        r10    k7 ; k7 = 40
.line	1554	loadk        r11    k8 ; k8 = 143
.line	1554	loadk        r12    k9 ; k9 = 226
.line	1554	loadk        r13   k10 ; k10 = 221
.line	1554	loadk        r14   k11 ; k11 = 236
.line	1554	loadk        r15   k12 ; k12 = 111
.line	1554	loadk        r16   k13 ; k13 = 76
.line	1554	loadk        r17   k14 ; k14 = 246
.line	1554	loadk        r18   k15 ; k15 = 193
.line	1554	loadk        r19   k16 ; k16 = 22
.line	1554	loadk        r20   k17 ; k17 = 1
.line	1554	loadk        r21   k18 ; k18 = 23
.line	1554	loadk        r22   k19 ; k19 = 215
.line	1554	loadk        r23    k1 ; k1 = 224
.line	1554	loadk        r24   k20 ; k20 = 135
.line	1554	loadk        r25   k12 ; k12 = 111
.line	1554	loadk        r26   k21 ; k21 = 26
.line	1554	loadk        r27   k22 ; k22 = 255
.line	1554	loadk        r28   k23 ; k23 = 192
.line	1554	loadk        r29   k24 ; k24 = 216
.line	1554	loadk        r30   k25 ; k25 = 249
.line	1554	loadk        r31   k26 ; k26 = 116
.line	1554	loadk        r32   k27 ; k27 = 124
.line	1554	loadk        r33    k9 ; k9 = 226
.line	1554	loadk        r34   k28 ; k28 = 157
.line	1554	loadk        r35   k29 ; k29 = 51
.line	1554	loadk        r36   k30 ; k30 = 43
.line	1554	loadk        r37   k31 ; k31 = 9
.line	1554	loadk        r38   k10 ; k10 = 221
.line	1554	loadk        r39   k32 ; k32 = 251
.line	1554	loadk        r40   k33 ; k33 = 152
.line	1554	loadk        r41   k34 ; k34 = 117
.line	1554	loadk        r42   k35 ; k35 = 20
.line	1554	call          r3    40     2
.line	1554	call          r2     2     2
.line	1554	gettable      r3    r2   k36 ; k36 = "send_depot_batch_put" (truncated)
.line	1554	move          r4    r1
.line	1554	call          r3     2     1
.line	1554	return        r0     1
.line	1554	move          r0    r0
.line	1554	move          r0    r0
.line	1554	move          r0    r0
.line	1554	move          r0    r0
.line	1554	return        r0     1

.function	main/f80

.source	null
.linedefined	1559
.lastlinedefined	1568
.numparams	2
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"DataMgr"
.constant	k1	"vehicleSkinInsIDTable"
.constant	k2	nil
.constant	k3	"pairs"

.line	1559	gettabup      r2    u0    k0 ; k0 = "DataMgr"
.line	1559	gettable      r2    r2    k1 ; k1 = "vehicleSkinInsIDTabl" (truncated)
.line	1559	eq             1    r2    k2 ; k2 = nil
.line	1559	jmp            0   l16
.line	1559	gettabup      r2    u0    k3 ; k3 = "pairs"
.line	1559	gettabup      r3    u0    k0 ; k0 = "DataMgr"
.line	1559	gettable      r3    r3    k1 ; k1 = "vehicleSkinInsIDTabl" (truncated)
.line	1559	call          r2     2     4
.line	1559	jmp            0   l14
.line	1559	eq             0    r6    r1
.line	1559	jmp            0   l14
.line	1559	loadbool      r7     1     0
.line	1559	return        r7     2
.label	l14
.line	1559	move          r0    r0
.line	1559	move          r0    r0
.label	l16
.line	1559	loadbool      r2     0     0
.line	1559	return        r2     2
.line	1559	return        r0     1
.line	1559	move          r0    r0
.line	1559	return        r0     1

.function	main/f81

.source	null
.linedefined	1570
.lastlinedefined	1589
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"log_tree"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	212
.constant	k5	41
.constant	k6	161
.constant	k7	219
.constant	k8	102
.constant	k9	95
.constant	k10	100
.constant	k11	132
.constant	k12	203
.constant	k13	198
.constant	k14	252
.constant	k15	105
.constant	k16	93
.constant	k17	167
.constant	k18	152
.constant	k19	39
.constant	k20	1
.constant	k21	28
.constant	k22	209
.constant	k23	224
.constant	k24	134
.constant	k25	101
.constant	k26	179
.constant	k27	246
.constant	k28	205
.constant	k29	232
.constant	k30	120
.constant	k31	113
.constant	k32	253
.constant	k33	138
.constant	k34	34
.constant	k35	60
.constant	k36	7
.constant	k37	221
.constant	k38	192
.constant	k39	117
.constant	k40	23
.constant	k41	225
.constant	k42	226
.constant	k43	44
.constant	k44	183
.constant	k45	214
.constant	k46	96
.constant	k47	89
.constant	k48	143
.constant	k49	230
.constant	k50	197
.constant	k51	97
.constant	k52	76
.constant	k53	233
.constant	k54	156
.constant	k55	"require"
.constant	k56	36
.constant	k57	186
.constant	k58	218
.constant	k59	122
.constant	k60	68
.constant	k61	40
.constant	k62	236
.constant	k63	111
.constant	k64	193
.constant	k65	22
.constant	k66	215
.constant	k67	135
.constant	k68	26
.constant	k69	255
.constant	k70	216
.constant	k71	249
.constant	k72	116
.constant	k73	124
.constant	k74	157
.constant	k75	51
.constant	k76	43
.constant	k77	9
.constant	k78	251
.constant	k79	20
.constant	k80	"send_depot_batch_put_on_req"
.constant	k81	"pairs"
.constant	k82	"isVehicle"
.constant	k83	"ipairs"
.constant	k84	"GetHallDepotItemDataByInsID"
.constant	k85	"resID"
.constant	k86	"res_id"
.constant	k87	"ModuleManager"
.constant	k88	"GetModule"
.constant	k89	"LobbyModuleConfig"
.constant	k90	"golden_suit_module"
.constant	k91	"ModifyVehicleWhenPutOn"

.line	1570	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	1570	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1570	test          r5     0
.line	1570	jmp            0   l69
.line	1570	gettabup      r5    u0    k2 ; k2 = "table"
.line	1570	gettable      r5    r5    k3 ; k3 = "concat"
.line	1570	newtable      r6     1     0
.line	1570	getupval      r7    u1
.line	1570	loadk         r8    k4 ; k4 = 212
.line	1570	loadk         r9    k5 ; k5 = 41
.line	1570	loadk        r10    k6 ; k6 = 161
.line	1570	loadk        r11    k7 ; k7 = 219
.line	1570	loadk        r12    k8 ; k8 = 102
.line	1570	loadk        r13    k9 ; k9 = 95
.line	1570	loadk        r14   k10 ; k10 = 100
.line	1570	loadk        r15   k11 ; k11 = 132
.line	1570	loadk        r16   k12 ; k12 = 203
.line	1570	loadk        r17   k13 ; k13 = 198
.line	1570	loadk        r18   k14 ; k14 = 252
.line	1570	loadk        r19   k15 ; k15 = 105
.line	1570	loadk        r20   k16 ; k16 = 93
.line	1570	loadk        r21   k17 ; k17 = 167
.line	1570	loadk        r22   k18 ; k18 = 152
.line	1570	loadk        r23   k19 ; k19 = 39
.line	1570	loadk        r24   k20 ; k20 = 1
.line	1570	loadk        r25   k21 ; k21 = 28
.line	1570	loadk        r26   k22 ; k22 = 209
.line	1570	loadk        r27   k23 ; k23 = 224
.line	1570	loadk        r28   k24 ; k24 = 134
.line	1570	loadk        r29   k25 ; k25 = 101
.line	1570	loadk        r30    k5 ; k5 = 41
.line	1570	loadk        r31   k26 ; k26 = 179
.line	1570	loadk        r32   k27 ; k27 = 246
.line	1570	loadk        r33   k28 ; k28 = 205
.line	1570	loadk        r34   k29 ; k29 = 232
.line	1570	loadk        r35   k30 ; k30 = 120
.line	1570	loadk        r36   k31 ; k31 = 113
.line	1570	loadk        r37   k32 ; k32 = 253
.line	1570	loadk        r38   k33 ; k33 = 138
.line	1570	loadk        r39   k34 ; k34 = 34
.line	1570	loadk        r40   k35 ; k35 = 60
.line	1570	loadk        r41   k36 ; k36 = 7
.line	1570	loadk        r42   k37 ; k37 = 221
.line	1570	loadk        r43   k38 ; k38 = 192
.line	1570	loadk        r44   k24 ; k24 = 134
.line	1570	loadk        r45   k39 ; k39 = 117
.line	1570	loadk        r46   k40 ; k40 = 23
.line	1570	loadk        r47   k41 ; k41 = 225
.line	1570	call          r7    41     2
.line	1570	getupval      r8    u1
.line	1570	loadk         r9   k42 ; k42 = 226
.line	1570	loadk        r10   k43 ; k43 = 44
.line	1570	loadk        r11   k44 ; k44 = 183
.line	1570	loadk        r12   k45 ; k45 = 214
.line	1570	loadk        r13   k46 ; k46 = 96
.line	1570	loadk        r14   k47 ; k47 = 89
.line	1570	loadk        r15   k15 ; k15 = 105
.line	1570	loadk        r16   k48 ; k48 = 143
.line	1570	loadk        r17   k49 ; k49 = 230
.line	1570	loadk        r18   k50 ; k50 = 197
.line	1570	loadk        r19   k12 ; k12 = 203
.line	1570	loadk        r20   k51 ; k51 = 97
.line	1570	loadk        r21   k52 ; k52 = 76
.line	1570	loadk        r22   k53 ; k53 = 233
.line	1570	loadk        r23   k54 ; k54 = 156
.line	1570	call          r8    16     0
.line	1570	setlist       r6     0     1
.line	1570	call          r5     2     2
.label	l69
.line	1570	move          r6    r3
.line	1570	call          r4     3     1
.line	1570	gettabup      r4    u0   k55 ; k55 = "require"
.line	1570	getupval      r5    u1
.line	1570	loadk         r6   k23 ; k23 = 224
.line	1570	loadk         r7   k56 ; k56 = 36
.line	1570	loadk         r8   k57 ; k57 = 186
.line	1570	loadk         r9   k58 ; k58 = 218
.line	1570	loadk        r10   k59 ; k59 = 122
.line	1570	loadk        r11   k60 ; k60 = 68
.line	1570	loadk        r12   k61 ; k61 = 40
.line	1570	loadk        r13   k48 ; k48 = 143
.line	1570	loadk        r14   k42 ; k42 = 226
.line	1570	loadk        r15   k37 ; k37 = 221
.line	1570	loadk        r16   k62 ; k62 = 236
.line	1570	loadk        r17   k63 ; k63 = 111
.line	1570	loadk        r18   k52 ; k52 = 76
.line	1570	loadk        r19   k27 ; k27 = 246
.line	1570	loadk        r20   k64 ; k64 = 193
.line	1570	loadk        r21   k65 ; k65 = 22
.line	1570	loadk        r22   k20 ; k20 = 1
.line	1570	loadk        r23   k40 ; k40 = 23
.line	1570	loadk        r24   k66 ; k66 = 215
.line	1570	loadk        r25   k23 ; k23 = 224
.line	1570	loadk        r26   k67 ; k67 = 135
.line	1570	loadk        r27   k63 ; k63 = 111
.line	1570	loadk        r28   k68 ; k68 = 26
.line	1570	loadk        r29   k69 ; k69 = 255
.line	1570	loadk        r30   k38 ; k38 = 192
.line	1570	loadk        r31   k70 ; k70 = 216
.line	1570	loadk        r32   k71 ; k71 = 249
.line	1570	loadk        r33   k72 ; k72 = 116
.line	1570	loadk        r34   k73 ; k73 = 124
.line	1570	loadk        r35   k42 ; k42 = 226
.line	1570	loadk        r36   k74 ; k74 = 157
.line	1570	loadk        r37   k75 ; k75 = 51
.line	1570	loadk        r38   k76 ; k76 = 43
.line	1570	loadk        r39   k77 ; k77 = 9
.line	1570	loadk        r40   k37 ; k37 = 221
.line	1570	loadk        r41   k78 ; k78 = 251
.line	1570	loadk        r42   k18 ; k18 = 152
.line	1570	loadk        r43   k39 ; k39 = 117
.line	1570	loadk        r44   k79 ; k79 = 20
.line	1570	call          r5    40     2
.line	1570	call          r4     2     2
.line	1570	gettable      r5    r4   k80 ; k80 = "send_depot_batch_put" (truncated)
.line	1570	move          r6    r1
.line	1570	move          r7    r2
.line	1570	call          r5     3     1
.line	1570	loadnil       r5     0
.line	1570	test          r3     0
.line	1570	jmp            0  l134
.line	1570	gettabup      r6    u0   k81 ; k81 = "pairs"
.line	1570	move          r7    r3
.line	1570	call          r6     2     4
.line	1570	jmp            0  l132
.line	1570	self         r11    r0   k82 ; k82 = "isVehicle"
.line	1570	move         r13   r10
.line	1570	call         r11     3     2
.line	1570	test         r11     0
.line	1570	jmp            0  l132
.line	1570	loadbool      r5     1     0
.line	1570	jmp            0  l134
.label	l132
.line	1570	move          r0    r0
.line	1570	move          r0    r0
.label	l134
.line	1570	gettabup      r6    u0   k83 ; k83 = "ipairs"
.line	1570	move          r7    r1
.line	1570	call          r6     2     4
.line	1570	jmp            0  l156
.line	1570	getupval     r11    u2
.line	1570	self         r11   r11   k84 ; k84 = "GetHallDepotItemData" (truncated)
.line	1570	move         r13   r10
.line	1570	call         r11     3     2
.line	1570	gettable     r12   r11   k85 ; k85 = "resID"
.line	1570	test         r12     1
.line	1570	jmp            0  l146
.line	1570	gettable     r12   r11   k86 ; k86 = "res_id"
.label	l146
.line	1570	gettabup     r13    u0   k87 ; k87 = "ModuleManager"
.line	1570	gettable     r13   r13   k88 ; k88 = "GetModule"
.line	1570	gettabup     r14    u0   k87 ; k87 = "ModuleManager"
.line	1570	gettable     r14   r14   k89 ; k89 = "LobbyModuleConfig"
.line	1570	gettable     r14   r14   k90 ; k90 = "golden_suit_module"
.line	1570	call         r13     2     2
.line	1570	self         r14   r13   k91 ; k91 = "ModifyVehicleWhenPut" (truncated)
.line	1570	move         r16   r12
.line	1570	move         r17    r5
.line	1570	call         r14     4     1
.label	l156
.line	1570	move          r0    r0
.line	1570	move          r0    r0
.line	1570	return        r0     1
.line	1570	move          r0    r0
.line	1570	return        r0     1

.function	main/f82

.source	null
.linedefined	1591
.lastlinedefined	1606
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	212
.constant	k7	41
.constant	k8	161
.constant	k9	219
.constant	k10	102
.constant	k11	95
.constant	k12	100
.constant	k13	132
.constant	k14	203
.constant	k15	198
.constant	k16	252
.constant	k17	105
.constant	k18	93
.constant	k19	167
.constant	k20	172
.constant	k21	46
.constant	k22	18
.constant	k23	22
.constant	k24	196
.constant	k25	234
.constant	k26	176
.constant	k27	111
.constant	k28	58
.constant	k29	190
.constant	k30	245
.constant	k31	242
.constant	k32	67
.constant	k33	77
.constant	k34	232
.constant	k35	145
.constant	k36	51
.constant	k37	6
.constant	k38	214
.constant	k39	231
.constant	k40	128
.constant	k41	64
.constant	k42	7
.constant	k43	166
.constant	k44	230
.constant	k45	114
.constant	k46	243
.constant	k47	154
.constant	k48	103
.constant	k49	"require"
.constant	k50	224
.constant	k51	36
.constant	k52	186
.constant	k53	218
.constant	k54	122
.constant	k55	68
.constant	k56	40
.constant	k57	141
.constant	k58	206
.constant	k59	99
.constant	k60	16
.constant	k61	153
.constant	k62	39
.constant	k63	25
.constant	k64	209
.constant	k65	136
.constant	k66	17
.constant	k67	184
.constant	k68	244
.constant	k69	255
.constant	k70	117
.constant	k71	79
.constant	k72	160
.constant	k73	55
.constant	k74	21
.constant	k75	9
.constant	k76	199
.constant	k77	254
.constant	k78	134
.constant	k79	11
.constant	k80	237
.constant	k81	180
.constant	k82	146
.constant	k83	235
.constant	k84	220
.constant	k85	250
.constant	k86	75
.constant	k87	240
.constant	k88	104
.constant	k89	150
.constant	k90	20
.constant	k91	185
.constant	k92	98
.constant	k93	74
.constant	k94	144
.constant	k95	52
.constant	k96	222
.constant	k97	151
.constant	k98	"ENUM_WardrobeSubTabString"
.constant	k99	"ENUM_WardrobePageTypeId"
.constant	k100	"ENUM_WardrobeSubTabString_throw_object"
.constant	k101	"ENUM_WardrobeSubTabString_effect"
.constant	k102	192
.constant	k103	32
.constant	k104	178
.constant	k105	115
.constant	k106	85
.constant	k107	82
.constant	k108	142
.constant	k109	249
.constant	k110	71
.constant	k111	140
.constant	k112	35
.constant	k113	29
.constant	k114	131
.constant	k115	225
.constant	k116	139
.constant	k117	116
.constant	k118	86
.constant	k119	191
.constant	k120	239
.constant	k121	"GetCurrentTabId"
.constant	k122	"ENUM_WardrobeSubTabString_plating"
.constant	k123	"GetCurrentPageId"
.constant	k124	"ENUM_WardrobePageType_Vehicle"
.constant	k125	"ENUM_WardrobeSubTabString_parachute"
.constant	k126	"ENUM_WardrobeSubTabString_emoji_bubble"
.constant	k127	"ENUM_WardrobeSubTabString_holography"
.constant	k128	"ENUM_WardrobeSubTabString_plane"
.constant	k129	"Enum_WardrobeSubTabString_SpecialVehicle"
.constant	k130	"ENUM_WardrobeSubTabString_MiniTVSuit"
.constant	k131	"ModuleManager"
.constant	k132	"GetModule"
.constant	k133	"LobbyModuleConfig"
.constant	k134	"Lobby_camera_manager_module"
.constant	k135	"SwitchCamera"
.constant	k136	10002
.constant	k137	"ShowAllAvatar"

.line	1591	gettabup      r2    u0    k0 ; k0 = "log"
.line	1591	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1591	test          r3     0
.line	1591	jmp            0   l63
.line	1591	gettabup      r3    u0    k2 ; k2 = "string"
.line	1591	gettable      r3    r3    k3 ; k3 = "format"
.line	1591	gettabup      r4    u0    k4 ; k4 = "table"
.line	1591	gettable      r4    r4    k5 ; k5 = "concat"
.line	1591	newtable      r5     1     0
.line	1591	getupval      r6    u1
.line	1591	loadk         r7    k6 ; k6 = 212
.line	1591	loadk         r8    k7 ; k7 = 41
.line	1591	loadk         r9    k8 ; k8 = 161
.line	1591	loadk        r10    k9 ; k9 = 219
.line	1591	loadk        r11   k10 ; k10 = 102
.line	1591	loadk        r12   k11 ; k11 = 95
.line	1591	loadk        r13   k12 ; k12 = 100
.line	1591	loadk        r14   k13 ; k13 = 132
.line	1591	loadk        r15   k14 ; k14 = 203
.line	1591	loadk        r16   k15 ; k15 = 198
.line	1591	loadk        r17   k16 ; k16 = 252
.line	1591	loadk        r18   k17 ; k17 = 105
.line	1591	loadk        r19   k18 ; k18 = 93
.line	1591	loadk        r20   k19 ; k19 = 167
.line	1591	loadk        r21   k20 ; k20 = 172
.line	1591	loadk        r22   k21 ; k21 = 46
.line	1591	loadk        r23   k22 ; k22 = 18
.line	1591	loadk        r24   k23 ; k23 = 22
.line	1591	loadk        r25   k24 ; k24 = 196
.line	1591	loadk        r26   k25 ; k25 = 234
.line	1591	loadk        r27   k26 ; k26 = 176
.line	1591	loadk        r28   k27 ; k27 = 111
.line	1591	loadk        r29   k28 ; k28 = 58
.line	1591	loadk        r30   k29 ; k29 = 190
.line	1591	loadk        r31   k30 ; k30 = 245
.line	1591	loadk        r32    k9 ; k9 = 219
.line	1591	loadk        r33   k31 ; k31 = 242
.line	1591	loadk        r34   k32 ; k32 = 67
.line	1591	loadk        r35   k33 ; k33 = 77
.line	1591	loadk        r36   k34 ; k34 = 232
.line	1591	loadk        r37   k35 ; k35 = 145
.line	1591	loadk        r38   k36 ; k36 = 51
.line	1591	loadk        r39   k32 ; k32 = 67
.line	1591	loadk        r40   k37 ; k37 = 6
.line	1591	loadk        r41   k38 ; k38 = 214
.line	1591	loadk        r42   k39 ; k39 = 231
.line	1591	loadk        r43   k40 ; k40 = 128
.line	1591	loadk        r44   k41 ; k41 = 64
.line	1591	loadk        r45   k42 ; k42 = 7
.line	1591	loadk        r46   k43 ; k43 = 166
.line	1591	call          r6    41     2
.line	1591	getupval      r7    u1
.line	1591	loadk         r8   k44 ; k44 = 230
.line	1591	loadk         r9   k45 ; k45 = 114
.line	1591	loadk        r10   k46 ; k46 = 243
.line	1591	loadk        r11   k47 ; k47 = 154
.line	1591	loadk        r12   k48 ; k48 = 103
.line	1591	call          r7     6     0
.line	1591	setlist       r5     0     1
.line	1591	call          r4     2     2
.line	1591	move          r5    r1
.line	1591	call          r3     3     2
.label	l63
.line	1591	call          r2     2     1
.line	1591	gettabup      r2    u0   k49 ; k49 = "require"
.line	1591	gettabup      r3    u0    k4 ; k4 = "table"
.line	1591	gettable      r3    r3    k5 ; k5 = "concat"
.line	1591	newtable      r4     1     0
.line	1591	getupval      r5    u1
.line	1591	loadk         r6   k50 ; k50 = 224
.line	1591	loadk         r7   k51 ; k51 = 36
.line	1591	loadk         r8   k52 ; k52 = 186
.line	1591	loadk         r9   k53 ; k53 = 218
.line	1591	loadk        r10   k54 ; k54 = 122
.line	1591	loadk        r11   k55 ; k55 = 68
.line	1591	loadk        r12   k56 ; k56 = 40
.line	1591	loadk        r13   k57 ; k57 = 141
.line	1591	loadk        r14   k34 ; k34 = 232
.line	1591	loadk        r15   k58 ; k58 = 206
.line	1591	loadk        r16   k31 ; k31 = 242
.line	1591	loadk        r17   k59 ; k59 = 99
.line	1591	loadk        r18   k60 ; k60 = 16
.line	1591	loadk        r19   k16 ; k16 = 252
.line	1591	loadk        r20   k61 ; k61 = 153
.line	1591	loadk        r21   k62 ; k62 = 39
.line	1591	loadk        r22   k42 ; k42 = 7
.line	1591	loadk        r23   k63 ; k63 = 25
.line	1591	loadk        r24   k64 ; k64 = 209
.line	1591	loadk        r25    k8 ; k8 = 161
.line	1591	loadk        r26   k65 ; k65 = 136
.line	1591	loadk        r27   k27 ; k27 = 111
.line	1591	loadk        r28   k66 ; k66 = 17
.line	1591	loadk        r29   k67 ; k67 = 184
.line	1591	loadk        r30   k68 ; k68 = 244
.line	1591	loadk        r31   k44 ; k44 = 230
.line	1591	loadk        r32   k69 ; k69 = 255
.line	1591	loadk        r33   k70 ; k70 = 117
.line	1591	loadk        r34   k71 ; k71 = 79
.line	1591	loadk        r35   k50 ; k50 = 224
.line	1591	loadk        r36   k72 ; k72 = 160
.line	1591	loadk        r37   k73 ; k73 = 55
.line	1591	loadk        r38   k74 ; k74 = 21
.line	1591	loadk        r39   k75 ; k75 = 9
.line	1591	loadk        r40   k76 ; k76 = 199
.line	1591	loadk        r41   k77 ; k77 = 254
.line	1591	loadk        r42   k78 ; k78 = 134
.line	1591	loadk        r43   k71 ; k71 = 79
.line	1591	loadk        r44   k79 ; k79 = 11
.line	1591	loadk        r45   k72 ; k72 = 160
.line	1591	call          r5    41     2
.line	1591	getupval      r6    u1
.line	1591	loadk         r7   k80 ; k80 = 237
.line	1591	loadk         r8    k7 ; k7 = 41
.line	1591	loadk         r9   k81 ; k81 = 180
.line	1591	loadk        r10   k53 ; k53 = 218
.line	1591	loadk        r11   k10 ; k10 = 102
.line	1591	call          r6     6     0
.line	1591	setlist       r4     0     1
.line	1591	call          r3     2     2
.line	1591	call          r2     2     2
.line	1591	gettabup      r3    u0   k49 ; k49 = "require"
.line	1591	getupval      r4    u1
.line	1591	loadk         r5   k50 ; k50 = 224
.line	1591	loadk         r6   k51 ; k51 = 36
.line	1591	loadk         r7   k52 ; k52 = 186
.line	1591	loadk         r8   k53 ; k53 = 218
.line	1591	loadk         r9   k54 ; k54 = 122
.line	1591	loadk        r10   k55 ; k55 = 68
.line	1591	loadk        r11   k56 ; k56 = 40
.line	1591	loadk        r12   k82 ; k82 = 146
.line	1591	loadk        r13   k83 ; k83 = 235
.line	1591	loadk        r14   k84 ; k84 = 220
.line	1591	loadk        r15   k85 ; k85 = 250
.line	1591	loadk        r16   k21 ; k21 = 46
.line	1591	loadk        r17   k86 ; k86 = 75
.line	1591	loadk        r18   k87 ; k87 = 240
.line	1591	loadk        r19   k65 ; k65 = 136
.line	1591	loadk        r20   k88 ; k88 = 104
.line	1591	loadk        r21   k51 ; k51 = 36
.line	1591	loadk        r22   k63 ; k63 = 25
.line	1591	loadk        r23   k64 ; k64 = 209
.line	1591	loadk        r24   k83 ; k83 = 235
.line	1591	loadk        r25   k89 ; k89 = 150
.line	1591	loadk        r26   k27 ; k27 = 111
.line	1591	loadk        r27   k90 ; k90 = 20
.line	1591	loadk        r28   k81 ; k81 = 180
.line	1591	loadk        r29   k91 ; k91 = 185
.line	1591	loadk        r30   k58 ; k58 = 206
.line	1591	loadk        r31   k25 ; k25 = 234
.line	1591	loadk        r32   k92 ; k92 = 98
.line	1591	loadk        r33   k93 ; k93 = 74
.line	1591	loadk        r34   k69 ; k69 = 255
.line	1591	loadk        r35   k94 ; k94 = 144
.line	1591	loadk        r36   k95 ; k95 = 52
.line	1591	loadk        r37   k37 ; k37 = 6
.line	1591	loadk        r38   k73 ; k73 = 55
.line	1591	loadk        r39   k96 ; k96 = 222
.line	1591	loadk        r40   k77 ; k77 = 254
.line	1591	loadk        r41   k97 ; k97 = 151
.line	1591	loadk        r42   k92 ; k92 = 98
.line	1591	loadk        r43   k75 ; k75 = 9
.line	1591	call          r4    40     2
.line	1591	call          r3     2     2
.line	1591	gettable      r4    r3   k98 ; k98 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	gettable      r5    r3   k99 ; k99 = "ENUM_WardrobePageTyp" (truncated)
.line	1591	gettable      r6    r4  k100 ; k100 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r1    r6
.line	1591	jmp            0  l171
.line	1591	gettable      r6    r4  k101 ; k101 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             0    r1    r6
.line	1591	jmp            0  l206
.label	l171
.line	1591	gettabup      r6    u0    k0 ; k0 = "log"
.line	1591	gettabup      r7    u0    k1 ; k1 = "bWriteLog"
.line	1591	test          r7     0
.line	1591	jmp            0  l204
.line	1591	getupval      r7    u1
.line	1591	loadk         r8  k102 ; k102 = 192
.line	1591	loadk         r9  k103 ; k103 = 32
.line	1591	loadk        r10  k104 ; k104 = 178
.line	1591	loadk        r11   k64 ; k64 = 209
.line	1591	loadk        r12  k105 ; k105 = 115
.line	1591	loadk        r13  k106 ; k106 = 85
.line	1591	loadk        r14  k107 ; k107 = 82
.line	1591	loadk        r15  k108 ; k108 = 142
.line	1591	loadk        r16   k14 ; k14 = 203
.line	1591	loadk        r17   k15 ; k15 = 198
.line	1591	loadk        r18  k109 ; k109 = 249
.line	1591	loadk        r19   k92 ; k92 = 98
.line	1591	loadk        r20  k110 ; k110 = 71
.line	1591	loadk        r21   k58 ; k58 = 206
.line	1591	loadk        r22  k111 ; k111 = 140
.line	1591	loadk        r23  k112 ; k112 = 35
.line	1591	loadk        r24  k113 ; k113 = 29
.line	1591	loadk        r25  k113 ; k113 = 29
.line	1591	loadk        r26  k114 ; k114 = 131
.line	1591	loadk        r27  k115 ; k115 = 225
.line	1591	loadk        r28  k116 ; k116 = 139
.line	1591	loadk        r29  k117 ; k117 = 116
.line	1591	loadk        r30  k118 ; k118 = 86
.line	1591	loadk        r31  k119 ; k119 = 191
.line	1591	loadk        r32   k31 ; k31 = 242
.line	1591	loadk        r33   k84 ; k84 = 220
.line	1591	loadk        r34  k120 ; k120 = 239
.line	1591	call          r7    28     2
.label	l204
.line	1591	call          r6     2     1
.line	1591	return        r0     1
.label	l206
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k100 ; k100 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k122 ; k122 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k123 ; k123 = "GetCurrentPageId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r5  k124 ; k124 = "ENUM_WardrobePageTyp" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k125 ; k125 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k126 ; k126 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k127 ; k127 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k128 ; k128 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k101 ; k101 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k129 ; k129 = "Enum_WardrobeSubTabS" (truncated)
.line	1591	eq             1    r6    r7
.line	1591	jmp            0  l256
.line	1591	self          r6    r0  k121 ; k121 = "GetCurrentTabId"
.line	1591	call          r6     2     2
.line	1591	gettable      r7    r4  k130 ; k130 = "ENUM_WardrobeSubTabS" (truncated)
.line	1591	eq             0    r6    r7
.line	1591	jmp            0  l267
.label	l256
.line	1591	gettabup      r6    u0  k131 ; k131 = "ModuleManager"
.line	1591	gettable      r6    r6  k132 ; k132 = "GetModule"
.line	1591	gettabup      r7    u0  k131 ; k131 = "ModuleManager"
.line	1591	gettable      r7    r7  k133 ; k133 = "LobbyModuleConfig"
.line	1591	gettable      r7    r7  k134 ; k134 = "Lobby_camera_manager" (truncated)
.line	1591	call          r6     2     2
.line	1591	self          r7    r6  k135 ; k135 = "SwitchCamera"
.line	1591	loadk         r9  k136 ; k136 = 10002
.line	1591	call          r7     3     1
.line	1591	gettable      r7    r2  k137 ; k137 = "ShowAllAvatar"
.line	1591	call          r7     1     1
.label	l267
.line	1591	return        r0     1
.line	1591	move          r0    r0
.line	1591	move          r0    r0
.line	1591	move          r0    r0
.line	1591	move          r0    r0
.line	1591	return        r0     1

.function	main/f83

.source	null
.linedefined	1608
.lastlinedefined	1615
.numparams	1
.is_vararg	0
.maxstacksize	39

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"getMicroseconds"
.constant	k2	"ModuleManager"
.constant	k3	"GetModule"
.constant	k4	"LobbyModuleConfig"
.constant	k5	"Lobby_camera_manager_module"
.constant	k6	"EnterWardrobeScene"
.constant	k7	"Enum_CameraID"
.constant	k8	"store_general"
.constant	k9	"LobbySceneManager"
.constant	k10	"LEVEL_NAME"
.constant	k11	"MALL"
.constant	k12	"log"
.constant	k13	"bWriteLog"
.constant	k14	212
.constant	k15	41
.constant	k16	161
.constant	k17	219
.constant	k18	102
.constant	k19	95
.constant	k20	100
.constant	k21	132
.constant	k22	203
.constant	k23	198
.constant	k24	252
.constant	k25	105
.constant	k26	93
.constant	k27	167
.constant	k28	170
.constant	k29	40
.constant	k30	7
.constant	k31	29
.constant	k32	209
.constant	k33	200
.constant	k34	150
.constant	k35	101
.constant	k36	24
.constant	k37	176
.constant	k38	243
.constant	k39	220
.constant	k40	216
.constant	k41	115
.constant	k42	75
.constant	k43	227
.constant	k44	154
.constant	k45	108
.constant	k46	"tostring"
.constant	k47	1000

.line	1608	gettabup      r1    u0    k0 ; k0 = "slua"
.line	1608	gettable      r1    r1    k1 ; k1 = "getMicroseconds"
.line	1608	move          r2    r1
.line	1608	call          r2     1     2
.line	1608	gettabup      r3    u0    k2 ; k2 = "ModuleManager"
.line	1608	gettable      r3    r3    k3 ; k3 = "GetModule"
.line	1608	gettabup      r4    u0    k2 ; k2 = "ModuleManager"
.line	1608	gettable      r4    r4    k4 ; k4 = "LobbyModuleConfig"
.line	1608	gettable      r4    r4    k5 ; k5 = "Lobby_camera_manager" (truncated)
.line	1608	call          r3     2     2
.line	1608	self          r4    r0    k6 ; k6 = "EnterWardrobeScene"
.line	1608	gettable      r6    r3    k7 ; k7 = "Enum_CameraID"
.line	1608	gettable      r6    r6    k8 ; k8 = "store_general"
.line	1608	gettabup      r7    u0    k9 ; k9 = "LobbySceneManager"
.line	1608	gettable      r7    r7   k10 ; k10 = "LEVEL_NAME"
.line	1608	gettable      r7    r7   k11 ; k11 = "MALL"
.line	1608	call          r4     4     1
.line	1608	move          r4    r1
.line	1608	call          r4     1     2
.line	1608	gettabup      r5    u0   k12 ; k12 = "log"
.line	1608	gettabup      r6    u0   k13 ; k13 = "bWriteLog"
.line	1608	test          r6     0
.line	1608	jmp            0   l63
.line	1608	getupval      r6    u1
.line	1608	loadk         r7   k14 ; k14 = 212
.line	1608	loadk         r8   k15 ; k15 = 41
.line	1608	loadk         r9   k16 ; k16 = 161
.line	1608	loadk        r10   k17 ; k17 = 219
.line	1608	loadk        r11   k18 ; k18 = 102
.line	1608	loadk        r12   k19 ; k19 = 95
.line	1608	loadk        r13   k20 ; k20 = 100
.line	1608	loadk        r14   k21 ; k21 = 132
.line	1608	loadk        r15   k22 ; k22 = 203
.line	1608	loadk        r16   k23 ; k23 = 198
.line	1608	loadk        r17   k24 ; k24 = 252
.line	1608	loadk        r18   k25 ; k25 = 105
.line	1608	loadk        r19   k26 ; k26 = 93
.line	1608	loadk        r20   k27 ; k27 = 167
.line	1608	loadk        r21   k28 ; k28 = 170
.line	1608	loadk        r22   k29 ; k29 = 40
.line	1608	loadk        r23   k30 ; k30 = 7
.line	1608	loadk        r24   k31 ; k31 = 29
.line	1608	loadk        r25   k32 ; k32 = 209
.line	1608	loadk        r26   k33 ; k33 = 200
.line	1608	loadk        r27   k34 ; k34 = 150
.line	1608	loadk        r28   k35 ; k35 = 101
.line	1608	loadk        r29   k36 ; k36 = 24
.line	1608	loadk        r30   k37 ; k37 = 176
.line	1608	loadk        r31   k38 ; k38 = 243
.line	1608	loadk        r32   k39 ; k39 = 220
.line	1608	loadk        r33   k40 ; k40 = 216
.line	1608	loadk        r34   k41 ; k41 = 115
.line	1608	loadk        r35   k42 ; k42 = 75
.line	1608	loadk        r36   k43 ; k43 = 227
.line	1608	loadk        r37   k44 ; k44 = 154
.line	1608	loadk        r38   k45 ; k45 = 108
.line	1608	call          r6    33     2
.line	1608	gettabup      r7    u0   k46 ; k46 = "tostring"
.line	1608	sub           r8    r4    r2
.line	1608	div           r8    r8   k47 ; k47 = 1000
.line	1608	call          r7     2     2
.line	1608	concat        r6    r6    r7
.label	l63
.line	1608	call          r5     2     1
.line	1608	return        r0     1
.line	1608	move          r0    r0
.line	1608	return        r0     1

.function	main/f84

.source	null
.linedefined	1617
.lastlinedefined	1620
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"Lobby_camera_manager_module"
.constant	k4	"EnterWardrobeScene"
.constant	k5	"Enum_CameraID"
.constant	k6	"store_general"
.constant	k7	"LobbySceneManager"
.constant	k8	"LEVEL_NAME"
.constant	k9	"MALL"

.line	1617	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1617	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1617	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1617	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1617	gettable      r2    r2    k3 ; k3 = "Lobby_camera_manager" (truncated)
.line	1617	call          r1     2     2
.line	1617	self          r2    r0    k4 ; k4 = "EnterWardrobeScene"
.line	1617	gettable      r4    r1    k5 ; k5 = "Enum_CameraID"
.line	1617	gettable      r4    r4    k6 ; k6 = "store_general"
.line	1617	gettabup      r5    u0    k7 ; k7 = "LobbySceneManager"
.line	1617	gettable      r5    r5    k8 ; k8 = "LEVEL_NAME"
.line	1617	gettable      r5    r5    k9 ; k9 = "MALL"
.line	1617	call          r2     4     1
.line	1617	return        r0     1
.line	1617	move          r0    r0
.line	1617	return        r0     1

.function	main/f85

.source	null
.linedefined	1622
.lastlinedefined	1625
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"Lobby_camera_manager_module"
.constant	k4	"EnterWardrobeScene"
.constant	k5	"Enum_CameraID"
.constant	k6	"store_general"
.constant	k7	"LobbySceneManager"
.constant	k8	"LEVEL_NAME"
.constant	k9	"MALL"

.line	1622	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1622	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1622	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1622	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1622	gettable      r2    r2    k3 ; k3 = "Lobby_camera_manager" (truncated)
.line	1622	call          r1     2     2
.line	1622	self          r2    r0    k4 ; k4 = "EnterWardrobeScene"
.line	1622	gettable      r4    r1    k5 ; k5 = "Enum_CameraID"
.line	1622	gettable      r4    r4    k6 ; k6 = "store_general"
.line	1622	gettabup      r5    u0    k7 ; k7 = "LobbySceneManager"
.line	1622	gettable      r5    r5    k8 ; k8 = "LEVEL_NAME"
.line	1622	gettable      r5    r5    k9 ; k9 = "MALL"
.line	1622	call          r2     4     1
.line	1622	return        r0     1
.line	1622	move          r0    r0
.line	1622	move          r0    r0
.line	1622	move          r0    r0
.line	1622	return        r0     1

.function	main/f86

.source	null
.linedefined	1627
.lastlinedefined	1642
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"getMicroseconds"
.constant	k2	"require"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	224
.constant	k6	36
.constant	k7	186
.constant	k8	218
.constant	k9	122
.constant	k10	68
.constant	k11	40
.constant	k12	141
.constant	k13	232
.constant	k14	206
.constant	k15	242
.constant	k16	99
.constant	k17	16
.constant	k18	252
.constant	k19	153
.constant	k20	39
.constant	k21	7
.constant	k22	25
.constant	k23	209
.constant	k24	161
.constant	k25	136
.constant	k26	111
.constant	k27	17
.constant	k28	184
.constant	k29	244
.constant	k30	230
.constant	k31	255
.constant	k32	117
.constant	k33	79
.constant	k34	160
.constant	k35	55
.constant	k36	21
.constant	k37	9
.constant	k38	199
.constant	k39	254
.constant	k40	134
.constant	k41	11
.constant	k42	237
.constant	k43	41
.constant	k44	180
.constant	k45	102
.constant	k46	"HideAllAvatar"
.constant	k47	146
.constant	k48	235
.constant	k49	220
.constant	k50	250
.constant	k51	46
.constant	k52	75
.constant	k53	240
.constant	k54	104
.constant	k55	150
.constant	k56	20
.constant	k57	185
.constant	k58	234
.constant	k59	98
.constant	k60	74
.constant	k61	144
.constant	k62	52
.constant	k63	6
.constant	k64	222
.constant	k65	151
.constant	k66	140
.constant	k67	217
.constant	k68	82
.constant	k69	47
.constant	k70	207
.constant	k71	15
.constant	k72	142
.constant	k73	216
.constant	k74	249
.constant	k75	113
.constant	k76	73
.constant	k77	37
.constant	k78	0
.constant	k79	13
.constant	k80	221
.constant	k81	"ENUM_CAR_DEFAULT_VIEW"
.constant	k82	"TopView"
.constant	k83	"LoadVehicleStoreTopCamera"
.constant	k84	"LoadVehicleStoreCamera"
.constant	k85	"LoadVehicleScene"
.constant	k86	"log"
.constant	k87	"bWriteLog"
.constant	k88	212
.constant	k89	219
.constant	k90	95
.constant	k91	100
.constant	k92	132
.constant	k93	203
.constant	k94	198
.constant	k95	105
.constant	k96	93
.constant	k97	167
.constant	k98	170
.constant	k99	29
.constant	k100	200
.constant	k101	133
.constant	k102	114
.constant	k103	23
.constant	k104	182
.constant	k105	64
.constant	k106	197
.constant	k107	"tostring"
.constant	k108	1000

.line	1627	gettabup      r2    u0    k0 ; k0 = "slua"
.line	1627	gettable      r2    r2    k1 ; k1 = "getMicroseconds"
.line	1627	move          r3    r2
.line	1627	call          r3     1     2
.line	1627	gettabup      r4    u0    k2 ; k2 = "require"
.line	1627	gettabup      r5    u0    k3 ; k3 = "table"
.line	1627	gettable      r5    r5    k4 ; k4 = "concat"
.line	1627	newtable      r6     1     0
.line	1627	getupval      r7    u1
.line	1627	loadk         r8    k5 ; k5 = 224
.line	1627	loadk         r9    k6 ; k6 = 36
.line	1627	loadk        r10    k7 ; k7 = 186
.line	1627	loadk        r11    k8 ; k8 = 218
.line	1627	loadk        r12    k9 ; k9 = 122
.line	1627	loadk        r13   k10 ; k10 = 68
.line	1627	loadk        r14   k11 ; k11 = 40
.line	1627	loadk        r15   k12 ; k12 = 141
.line	1627	loadk        r16   k13 ; k13 = 232
.line	1627	loadk        r17   k14 ; k14 = 206
.line	1627	loadk        r18   k15 ; k15 = 242
.line	1627	loadk        r19   k16 ; k16 = 99
.line	1627	loadk        r20   k17 ; k17 = 16
.line	1627	loadk        r21   k18 ; k18 = 252
.line	1627	loadk        r22   k19 ; k19 = 153
.line	1627	loadk        r23   k20 ; k20 = 39
.line	1627	loadk        r24   k21 ; k21 = 7
.line	1627	loadk        r25   k22 ; k22 = 25
.line	1627	loadk        r26   k23 ; k23 = 209
.line	1627	loadk        r27   k24 ; k24 = 161
.line	1627	loadk        r28   k25 ; k25 = 136
.line	1627	loadk        r29   k26 ; k26 = 111
.line	1627	loadk        r30   k27 ; k27 = 17
.line	1627	loadk        r31   k28 ; k28 = 184
.line	1627	loadk        r32   k29 ; k29 = 244
.line	1627	loadk        r33   k30 ; k30 = 230
.line	1627	loadk        r34   k31 ; k31 = 255
.line	1627	loadk        r35   k32 ; k32 = 117
.line	1627	loadk        r36   k33 ; k33 = 79
.line	1627	loadk        r37    k5 ; k5 = 224
.line	1627	loadk        r38   k34 ; k34 = 160
.line	1627	loadk        r39   k35 ; k35 = 55
.line	1627	loadk        r40   k36 ; k36 = 21
.line	1627	loadk        r41   k37 ; k37 = 9
.line	1627	loadk        r42   k38 ; k38 = 199
.line	1627	loadk        r43   k39 ; k39 = 254
.line	1627	loadk        r44   k40 ; k40 = 134
.line	1627	loadk        r45   k33 ; k33 = 79
.line	1627	loadk        r46   k41 ; k41 = 11
.line	1627	loadk        r47   k34 ; k34 = 160
.line	1627	call          r7    41     2
.line	1627	getupval      r8    u1
.line	1627	loadk         r9   k42 ; k42 = 237
.line	1627	loadk        r10   k43 ; k43 = 41
.line	1627	loadk        r11   k44 ; k44 = 180
.line	1627	loadk        r12    k8 ; k8 = 218
.line	1627	loadk        r13   k45 ; k45 = 102
.line	1627	call          r8     6     0
.line	1627	setlist       r6     0     1
.line	1627	call          r5     2     2
.line	1627	call          r4     2     2
.line	1627	gettable      r5    r4   k46 ; k46 = "HideAllAvatar"
.line	1627	call          r5     1     1
.line	1627	gettabup      r5    u0    k2 ; k2 = "require"
.line	1627	getupval      r6    u1
.line	1627	loadk         r7    k5 ; k5 = 224
.line	1627	loadk         r8    k6 ; k6 = 36
.line	1627	loadk         r9    k7 ; k7 = 186
.line	1627	loadk        r10    k8 ; k8 = 218
.line	1627	loadk        r11    k9 ; k9 = 122
.line	1627	loadk        r12   k10 ; k10 = 68
.line	1627	loadk        r13   k11 ; k11 = 40
.line	1627	loadk        r14   k47 ; k47 = 146
.line	1627	loadk        r15   k48 ; k48 = 235
.line	1627	loadk        r16   k49 ; k49 = 220
.line	1627	loadk        r17   k50 ; k50 = 250
.line	1627	loadk        r18   k51 ; k51 = 46
.line	1627	loadk        r19   k52 ; k52 = 75
.line	1627	loadk        r20   k53 ; k53 = 240
.line	1627	loadk        r21   k25 ; k25 = 136
.line	1627	loadk        r22   k54 ; k54 = 104
.line	1627	loadk        r23    k6 ; k6 = 36
.line	1627	loadk        r24   k22 ; k22 = 25
.line	1627	loadk        r25   k23 ; k23 = 209
.line	1627	loadk        r26   k48 ; k48 = 235
.line	1627	loadk        r27   k55 ; k55 = 150
.line	1627	loadk        r28   k26 ; k26 = 111
.line	1627	loadk        r29   k56 ; k56 = 20
.line	1627	loadk        r30   k44 ; k44 = 180
.line	1627	loadk        r31   k57 ; k57 = 185
.line	1627	loadk        r32   k14 ; k14 = 206
.line	1627	loadk        r33   k58 ; k58 = 234
.line	1627	loadk        r34   k59 ; k59 = 98
.line	1627	loadk        r35   k60 ; k60 = 74
.line	1627	loadk        r36   k31 ; k31 = 255
.line	1627	loadk        r37   k61 ; k61 = 144
.line	1627	loadk        r38   k62 ; k62 = 52
.line	1627	loadk        r39   k63 ; k63 = 6
.line	1627	loadk        r40   k35 ; k35 = 55
.line	1627	loadk        r41   k64 ; k64 = 222
.line	1627	loadk        r42   k39 ; k39 = 254
.line	1627	loadk        r43   k65 ; k65 = 151
.line	1627	loadk        r44   k59 ; k59 = 98
.line	1627	loadk        r45   k37 ; k37 = 9
.line	1627	call          r6    40     2
.line	1627	call          r5     2     2
.line	1627	gettabup      r6    u0    k2 ; k2 = "require"
.line	1627	getupval      r7    u1
.line	1627	loadk         r8    k5 ; k5 = 224
.line	1627	loadk         r9    k6 ; k6 = 36
.line	1627	loadk        r10    k7 ; k7 = 186
.line	1627	loadk        r11    k8 ; k8 = 218
.line	1627	loadk        r12    k9 ; k9 = 122
.line	1627	loadk        r13   k10 ; k10 = 68
.line	1627	loadk        r14   k11 ; k11 = 40
.line	1627	loadk        r15   k66 ; k66 = 140
.line	1627	loadk        r16   k30 ; k30 = 230
.line	1627	loadk        r17   k67 ; k67 = 217
.line	1627	loadk        r18   k13 ; k13 = 232
.line	1627	loadk        r19   k51 ; k51 = 46
.line	1627	loadk        r20   k68 ; k68 = 82
.line	1627	loadk        r21   k15 ; k15 = 242
.line	1627	loadk        r22   k25 ; k25 = 136
.line	1627	loadk        r23   k69 ; k69 = 47
.line	1627	loadk        r24   k17 ; k17 = 16
.line	1627	loadk        r25   k20 ; k20 = 39
.line	1627	loadk        r26   k70 ; k70 = 207
.line	1627	loadk        r27    k5 ; k5 = 224
.line	1627	loadk        r28   k40 ; k40 = 134
.line	1627	loadk        r29   k59 ; k59 = 98
.line	1627	loadk        r30   k71 ; k71 = 15
.line	1627	loadk        r31   k72 ; k72 = 142
.line	1627	loadk        r32   k53 ; k53 = 240
.line	1627	loadk        r33   k73 ; k73 = 216
.line	1627	loadk        r34   k74 ; k74 = 249
.line	1627	loadk        r35   k75 ; k75 = 113
.line	1627	loadk        r36   k76 ; k76 = 73
.line	1627	loadk        r37   k13 ; k13 = 232
.line	1627	loadk        r38   k34 ; k34 = 160
.line	1627	loadk        r39   k77 ; k77 = 37
.line	1627	loadk        r40   k78 ; k78 = 0
.line	1627	loadk        r41   k79 ; k79 = 13
.line	1627	loadk        r42   k80 ; k80 = 221
.line	1627	loadk        r43   k50 ; k50 = 250
.line	1627	call          r7    37     2
.line	1627	call          r6     2     2
.line	1627	test          r1     0
.line	1627	jmp            0  l155
.line	1627	gettable      r7    r5   k81 ; k81 = "ENUM_CAR_DEFAULT_VIE" (truncated)
.line	1627	gettable      r7    r7   k82 ; k82 = "TopView"
.line	1627	eq             0    r1    r7
.line	1627	jmp            0  l155
.line	1627	gettable      r7    r6   k83 ; k83 = "LoadVehicleStoreTopC" (truncated)
.line	1627	call          r7     1     1
.line	1627	jmp            0  l157
.label	l155
.line	1627	gettable      r7    r6   k84 ; k84 = "LoadVehicleStoreCame" (truncated)
.line	1627	call          r7     1     1
.label	l157
.line	1627	gettable      r7    r6   k85 ; k85 = "LoadVehicleScene"
.line	1627	call          r7     1     1
.line	1627	move          r7    r2
.line	1627	call          r7     1     2
.line	1627	gettabup      r8    u0   k86 ; k86 = "log"
.line	1627	gettabup      r9    u0   k87 ; k87 = "bWriteLog"
.line	1627	test          r9     0
.line	1627	jmp            0  l203
.line	1627	getupval      r9    u1
.line	1627	loadk        r10   k88 ; k88 = 212
.line	1627	loadk        r11   k43 ; k43 = 41
.line	1627	loadk        r12   k24 ; k24 = 161
.line	1627	loadk        r13   k89 ; k89 = 219
.line	1627	loadk        r14   k45 ; k45 = 102
.line	1627	loadk        r15   k90 ; k90 = 95
.line	1627	loadk        r16   k91 ; k91 = 100
.line	1627	loadk        r17   k92 ; k92 = 132
.line	1627	loadk        r18   k93 ; k93 = 203
.line	1627	loadk        r19   k94 ; k94 = 198
.line	1627	loadk        r20   k18 ; k18 = 252
.line	1627	loadk        r21   k95 ; k95 = 105
.line	1627	loadk        r22   k96 ; k96 = 93
.line	1627	loadk        r23   k97 ; k97 = 167
.line	1627	loadk        r24   k98 ; k98 = 170
.line	1627	loadk        r25   k11 ; k11 = 40
.line	1627	loadk        r26   k21 ; k21 = 7
.line	1627	loadk        r27   k99 ; k99 = 29
.line	1627	loadk        r28   k23 ; k23 = 209
.line	1627	loadk        r29  k100 ; k100 = 200
.line	1627	loadk        r30  k101 ; k101 = 133
.line	1627	loadk        r31  k102 ; k102 = 114
.line	1627	loadk        r32  k103 ; k103 = 23
.line	1627	loadk        r33  k104 ; k104 = 182
.line	1627	loadk        r34   k15 ; k15 = 242
.line	1627	loadk        r35   k58 ; k58 = 234
.line	1627	loadk        r36   k13 ; k13 = 232
.line	1627	loadk        r37   k32 ; k32 = 117
.line	1627	loadk        r38  k105 ; k105 = 64
.line	1627	loadk        r39   k13 ; k13 = 232
.line	1627	loadk        r40  k106 ; k106 = 197
.line	1627	call          r9    32     2
.line	1627	gettabup     r10    u0  k107 ; k107 = "tostring"
.line	1627	sub          r11    r7    r3
.line	1627	div          r11   r11  k108 ; k108 = 1000
.line	1627	call         r10     2     2
.line	1627	concat        r9    r9   r10
.label	l203
.line	1627	call          r8     2     1
.line	1627	return        r0     1
.line	1627	move          r0    r0
.line	1627	return        r0     1

.function	main/f87

.source	null
.linedefined	1644
.lastlinedefined	1669
.numparams	2
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	9	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	216
.constant	k3	42
.constant	k4	180
.constant	k5	207
.constant	k6	73
.constant	k7	16
.constant	k8	67
.constant	k9	143
.constant	k10	243
.constant	k11	204
.constant	k12	233
.constant	k13	86
.constant	k14	91
.constant	k15	245
.constant	k16	134
.constant	k17	37
.constant	k18	31
.constant	k19	29
.constant	k20	240
.constant	k21	236
.constant	k22	129
.constant	k23	110
.constant	k24	19
.constant	k25	147
.constant	k26	238
.constant	k27	255
.constant	k28	117
.constant	k29	196
.constant	k30	187
.constant	k31	108
.constant	k32	10
.constant	k33	28
.constant	k34	214
.constant	k35	242
.constant	k36	171
.constant	k37	121
.constant	k38	2
.constant	k39	"tostring"
.constant	k40	"require"
.constant	k41	"table"
.constant	k42	"concat"
.constant	k43	224
.constant	k44	36
.constant	k45	186
.constant	k46	218
.constant	k47	122
.constant	k48	68
.constant	k49	40
.constant	k50	146
.constant	k51	235
.constant	k52	220
.constant	k53	250
.constant	k54	46
.constant	k55	82
.constant	k56	136
.constant	k57	47
.constant	k58	98
.constant	k59	15
.constant	k60	142
.constant	k61	246
.constant	k62	88
.constant	k63	228
.constant	k64	139
.constant	k65	77
.constant	k66	210
.constant	k67	251
.constant	k68	144
.constant	k69	20
.constant	k70	130
.constant	k71	226
.constant	k72	58
.constant	k73	151
.constant	k74	96
.constant	k75	81
.constant	k76	111
.constant	k77	141
.constant	k78	198
.constant	k79	102
.constant	k80	87
.constant	k81	"IsRareCar"
.constant	k82	"VehicleSceneType"
.constant	k83	"SuperCar"
.constant	k84	"Ordinary"
.constant	k85	140
.constant	k86	230
.constant	k87	217
.constant	k88	232
.constant	k89	39
.constant	k90	148
.constant	k91	101
.constant	k92	4
.constant	k93	203
.constant	k94	212
.constant	k95	34
.constant	k96	30
.constant	k97	189
.constant	k98	169
.constant	k99	51
.constant	k100	17
.constant	k101	27
.constant	k102	154
.constant	k103	"TryToResetCameraRotate"
.constant	k104	"SetCurrSceneType"
.constant	k105	123
.constant	k106	93
.constant	k107	247
.constant	k108	157
.constant	k109	115
.constant	k110	164
.constant	k111	208
.constant	k112	43
.constant	k113	182
.constant	k114	209
.constant	k115	113
.constant	k116	100
.constant	k117	127
.constant	k118	145
.constant	k119	70
.constant	k120	249
.constant	k121	160
.constant	k122	0
.constant	k123	13
.constant	k124	221
.constant	k125	"UpdateCurrSystemType"
.constant	k126	"LoadSystemType"
.constant	k127	"Wardrobe"
.constant	k128	"LoadSuperCarVehicleScene"
.constant	k129	"EnterGarageScene"

.line	1644	gettabup      r2    u0    k0 ; k0 = "log"
.line	1644	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	1644	test          r3     0
.line	1644	jmp            0   l50
.line	1644	getupval      r3    u1
.line	1644	loadk         r4    k2 ; k2 = 216
.line	1644	loadk         r5    k3 ; k3 = 42
.line	1644	loadk         r6    k4 ; k4 = 180
.line	1644	loadk         r7    k5 ; k5 = 207
.line	1644	loadk         r8    k6 ; k6 = 73
.line	1644	loadk         r9    k7 ; k7 = 16
.line	1644	loadk        r10    k8 ; k8 = 67
.line	1644	loadk        r11    k9 ; k9 = 143
.line	1644	loadk        r12   k10 ; k10 = 243
.line	1644	loadk        r13   k11 ; k11 = 204
.line	1644	loadk        r14   k12 ; k12 = 233
.line	1644	loadk        r15   k13 ; k13 = 86
.line	1644	loadk        r16   k14 ; k14 = 91
.line	1644	loadk        r17   k15 ; k15 = 245
.line	1644	loadk        r18   k16 ; k16 = 134
.line	1644	loadk        r19   k17 ; k17 = 37
.line	1644	loadk        r20   k18 ; k18 = 31
.line	1644	loadk        r21   k19 ; k19 = 29
.line	1644	loadk        r22   k20 ; k20 = 240
.line	1644	loadk        r23   k21 ; k21 = 236
.line	1644	loadk        r24   k22 ; k22 = 129
.line	1644	loadk        r25   k23 ; k23 = 110
.line	1644	loadk        r26   k24 ; k24 = 19
.line	1644	loadk        r27   k25 ; k25 = 147
.line	1644	loadk        r28   k26 ; k26 = 238
.line	1644	loadk        r29   k20 ; k20 = 240
.line	1644	loadk        r30   k27 ; k27 = 255
.line	1644	loadk        r31   k28 ; k28 = 117
.line	1644	loadk        r32    k8 ; k8 = 67
.line	1644	loadk        r33   k29 ; k29 = 196
.line	1644	loadk        r34   k30 ; k30 = 187
.line	1644	loadk        r35   k31 ; k31 = 108
.line	1644	loadk        r36   k32 ; k32 = 10
.line	1644	loadk        r37   k33 ; k33 = 28
.line	1644	loadk        r38   k34 ; k34 = 214
.line	1644	loadk        r39   k35 ; k35 = 242
.line	1644	loadk        r40   k36 ; k36 = 171
.line	1644	loadk        r41   k37 ; k37 = 121
.line	1644	loadk        r42   k38 ; k38 = 2
.line	1644	call          r3    40     2
.line	1644	gettabup      r4    u0   k39 ; k39 = "tostring"
.line	1644	move          r5    r1
.line	1644	call          r4     2     2
.line	1644	concat        r3    r3    r4
.label	l50
.line	1644	call          r2     2     1
.line	1644	loadnil       r2     0
.line	1644	gettabup      r3    u0   k40 ; k40 = "require"
.line	1644	gettabup      r4    u0   k41 ; k41 = "table"
.line	1644	gettable      r4    r4   k42 ; k42 = "concat"
.line	1644	newtable      r5     1     0
.line	1644	getupval      r6    u1
.line	1644	loadk         r7   k43 ; k43 = 224
.line	1644	loadk         r8   k44 ; k44 = 36
.line	1644	loadk         r9   k45 ; k45 = 186
.line	1644	loadk        r10   k46 ; k46 = 218
.line	1644	loadk        r11   k47 ; k47 = 122
.line	1644	loadk        r12   k48 ; k48 = 68
.line	1644	loadk        r13   k49 ; k49 = 40
.line	1644	loadk        r14   k50 ; k50 = 146
.line	1644	loadk        r15   k51 ; k51 = 235
.line	1644	loadk        r16   k52 ; k52 = 220
.line	1644	loadk        r17   k53 ; k53 = 250
.line	1644	loadk        r18   k54 ; k54 = 46
.line	1644	loadk        r19   k55 ; k55 = 82
.line	1644	loadk        r20   k35 ; k35 = 242
.line	1644	loadk        r21   k56 ; k56 = 136
.line	1644	loadk        r22   k57 ; k57 = 47
.line	1644	loadk        r23    k7 ; k7 = 16
.line	1644	loadk        r24   k13 ; k13 = 86
.line	1644	loadk        r25    k5 ; k5 = 207
.line	1644	loadk        r26   k43 ; k43 = 224
.line	1644	loadk        r27   k16 ; k16 = 134
.line	1644	loadk        r28   k58 ; k58 = 98
.line	1644	loadk        r29   k59 ; k59 = 15
.line	1644	loadk        r30   k60 ; k60 = 142
.line	1644	loadk        r31   k61 ; k61 = 246
.line	1644	loadk        r32   k46 ; k46 = 218
.line	1644	loadk        r33   k27 ; k27 = 255
.line	1644	loadk        r34   k37 ; k37 = 121
.line	1644	loadk        r35   k62 ; k62 = 88
.line	1644	loadk        r36   k63 ; k63 = 228
.line	1644	loadk        r37   k64 ; k64 = 139
.line	1644	loadk        r38   k57 ; k57 = 47
.line	1644	loadk        r39   k65 ; k65 = 77
.line	1644	loadk        r40   k44 ; k44 = 36
.line	1644	loadk        r41   k66 ; k66 = 210
.line	1644	loadk        r42   k67 ; k67 = 251
.line	1644	loadk        r43   k68 ; k68 = 144
.line	1644	loadk        r44   k28 ; k28 = 117
.line	1644	loadk        r45   k69 ; k69 = 20
.line	1644	loadk        r46   k70 ; k70 = 130
.line	1644	call          r6    41     2
.line	1644	getupval      r7    u1
.line	1644	loadk         r8   k71 ; k71 = 226
.line	1644	loadk         r9   k72 ; k72 = 58
.line	1644	loadk        r10   k73 ; k73 = 151
.line	1644	loadk        r11   k46 ; k46 = 218
.line	1644	loadk        r12   k74 ; k74 = 96
.line	1644	loadk        r13   k75 ; k75 = 81
.line	1644	loadk        r14   k76 ; k76 = 111
.line	1644	loadk        r15   k77 ; k77 = 141
.line	1644	loadk        r16   k29 ; k29 = 196
.line	1644	loadk        r17   k78 ; k78 = 198
.line	1644	loadk        r18   k15 ; k15 = 245
.line	1644	loadk        r19   k79 ; k79 = 102
.line	1644	loadk        r20   k80 ; k80 = 87
.line	1644	loadk        r21   k53 ; k53 = 250
.line	1644	call          r7    15     0
.line	1644	setlist       r5     0     1
.line	1644	call          r4     2     2
.line	1644	call          r3     2     2
.line	1644	gettable      r4    r3   k81 ; k81 = "IsRareCar"
.line	1644	move          r5    r1
.line	1644	call          r4     2     2
.line	1644	test          r4     0
.line	1644	jmp            0  l125
.line	1644	gettabup      r4    u2   k82 ; k82 = "VehicleSceneType"
.line	1644	gettable      r2    r4   k83 ; k83 = "SuperCar"
.line	1644	jmp            0  l127
.label	l125
.line	1644	gettabup      r4    u2   k82 ; k82 = "VehicleSceneType"
.line	1644	gettable      r2    r4   k84 ; k84 = "Ordinary"
.label	l127
.line	1644	getupval      r4    u3
.line	1644	eq             0    r2    r4
.line	1644	jmp            0  l179
.line	1644	getupval      r4    u3
.line	1644	gettabup      r5    u2   k82 ; k82 = "VehicleSceneType"
.line	1644	gettable      r5    r5   k83 ; k83 = "SuperCar"
.line	1644	eq             0    r4    r5
.line	1644	jmp            0  l178
.line	1644	gettabup      r4    u0   k40 ; k40 = "require"
.line	1644	getupval      r5    u1
.line	1644	loadk         r6   k43 ; k43 = 224
.line	1644	loadk         r7   k44 ; k44 = 36
.line	1644	loadk         r8   k45 ; k45 = 186
.line	1644	loadk         r9   k46 ; k46 = 218
.line	1644	loadk        r10   k47 ; k47 = 122
.line	1644	loadk        r11   k48 ; k48 = 68
.line	1644	loadk        r12   k49 ; k49 = 40
.line	1644	loadk        r13   k85 ; k85 = 140
.line	1644	loadk        r14   k86 ; k86 = 230
.line	1644	loadk        r15   k87 ; k87 = 217
.line	1644	loadk        r16   k88 ; k88 = 232
.line	1644	loadk        r17   k54 ; k54 = 46
.line	1644	loadk        r18   k55 ; k55 = 82
.line	1644	loadk        r19   k35 ; k35 = 242
.line	1644	loadk        r20   k56 ; k56 = 136
.line	1644	loadk        r21   k57 ; k57 = 47
.line	1644	loadk        r22    k7 ; k7 = 16
.line	1644	loadk        r23   k89 ; k89 = 39
.line	1644	loadk        r24   k20 ; k20 = 240
.line	1644	loadk        r25   k53 ; k53 = 250
.line	1644	loadk        r26   k90 ; k90 = 148
.line	1644	loadk        r27   k91 ; k91 = 101
.line	1644	loadk        r28   k92 ; k92 = 4
.line	1644	loadk        r29   k50 ; k50 = 146
.line	1644	loadk        r30   k61 ; k61 = 246
.line	1644	loadk        r31   k93 ; k93 = 203
.line	1644	loadk        r32   k94 ; k94 = 212
.line	1644	loadk        r33   k95 ; k95 = 34
.line	1644	loadk        r34   k96 ; k96 = 30
.line	1644	loadk        r35   k97 ; k97 = 189
.line	1644	loadk        r36   k98 ; k98 = 169
.line	1644	loadk        r37   k99 ; k99 = 51
.line	1644	loadk        r38  k100 ; k100 = 17
.line	1644	loadk        r39  k101 ; k101 = 27
.line	1644	loadk        r40   k46 ; k46 = 218
.line	1644	loadk        r41   k20 ; k20 = 240
.line	1644	loadk        r42  k102 ; k102 = 154
.line	1644	call          r5    38     2
.line	1644	call          r4     2     2
.line	1644	gettable      r5    r4  k103 ; k103 = "TryToResetCameraRota" (truncated)
.line	1644	call          r5     1     1
.label	l178
.line	1644	return        r0     1
.label	l179
.line	1644	getupval      r4    u2
.line	1644	self          r4    r4  k104 ; k104 = "SetCurrSceneType"
.line	1644	move          r6    r2
.line	1644	call          r4     3     1
.line	1644	gettabup      r4    u0    k0 ; k0 = "log"
.line	1644	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	1644	test          r5     0
.line	1644	jmp            0  l252
.line	1644	gettabup      r5    u0   k41 ; k41 = "table"
.line	1644	gettable      r5    r5   k42 ; k42 = "concat"
.line	1644	newtable      r6     1     0
.line	1644	getupval      r7    u1
.line	1644	loadk         r8    k2 ; k2 = 216
.line	1644	loadk         r9    k3 ; k3 = 42
.line	1644	loadk        r10    k4 ; k4 = 180
.line	1644	loadk        r11    k5 ; k5 = 207
.line	1644	loadk        r12    k6 ; k6 = 73
.line	1644	loadk        r13    k7 ; k7 = 16
.line	1644	loadk        r14    k8 ; k8 = 67
.line	1644	loadk        r15    k9 ; k9 = 143
.line	1644	loadk        r16   k10 ; k10 = 243
.line	1644	loadk        r17   k11 ; k11 = 204
.line	1644	loadk        r18   k12 ; k12 = 233
.line	1644	loadk        r19   k13 ; k13 = 86
.line	1644	loadk        r20   k14 ; k14 = 91
.line	1644	loadk        r21   k15 ; k15 = 245
.line	1644	loadk        r22   k16 ; k16 = 134
.line	1644	loadk        r23   k17 ; k17 = 37
.line	1644	loadk        r24   k18 ; k18 = 31
.line	1644	loadk        r25   k19 ; k19 = 29
.line	1644	loadk        r26   k20 ; k20 = 240
.line	1644	loadk        r27   k21 ; k21 = 236
.line	1644	loadk        r28   k22 ; k22 = 129
.line	1644	loadk        r29   k23 ; k23 = 110
.line	1644	loadk        r30   k24 ; k24 = 19
.line	1644	loadk        r31   k25 ; k25 = 147
.line	1644	loadk        r32   k26 ; k26 = 238
.line	1644	loadk        r33   k20 ; k20 = 240
.line	1644	loadk        r34   k27 ; k27 = 255
.line	1644	loadk        r35   k28 ; k28 = 117
.line	1644	loadk        r36    k8 ; k8 = 67
.line	1644	loadk        r37   k29 ; k29 = 196
.line	1644	loadk        r38   k30 ; k30 = 187
.line	1644	loadk        r39  k105 ; k105 = 123
.line	1644	loadk        r40  k106 ; k106 = 93
.line	1644	loadk        r41   k96 ; k96 = 30
.line	1644	loadk        r42   k34 ; k34 = 214
.line	1644	loadk        r43  k107 ; k107 = 247
.line	1644	loadk        r44  k108 ; k108 = 157
.line	1644	loadk        r45  k109 ; k109 = 115
.line	1644	loadk        r46   k32 ; k32 = 10
.line	1644	loadk        r47  k110 ; k110 = 164
.line	1644	call          r7    41     2
.line	1644	getupval      r8    u1
.line	1644	loadk         r9  k111 ; k111 = 208
.line	1644	loadk        r10  k112 ; k112 = 43
.line	1644	loadk        r11  k113 ; k113 = 182
.line	1644	loadk        r12  k114 ; k114 = 209
.line	1644	loadk        r13  k115 ; k115 = 113
.line	1644	loadk        r14  k116 ; k116 = 100
.line	1644	loadk        r15  k117 ; k117 = 127
.line	1644	loadk        r16  k118 ; k118 = 145
.line	1644	loadk        r17   k71 ; k71 = 226
.line	1644	loadk        r18  k119 ; k119 = 70
.line	1644	loadk        r19   k89 ; k89 = 39
.line	1644	loadk        r20  k102 ; k102 = 154
.line	1644	call          r8    13     0
.line	1644	setlist       r6     0     1
.line	1644	call          r5     2     2
.line	1644	gettabup      r6    u0   k39 ; k39 = "tostring"
.line	1644	move          r7    r2
.line	1644	call          r6     2     2
.line	1644	concat        r5    r5    r6
.label	l252
.line	1644	call          r4     2     1
.line	1644	gettabup      r4    u2   k82 ; k82 = "VehicleSceneType"
.line	1644	gettable      r4    r4   k83 ; k83 = "SuperCar"
.line	1644	eq             0    r2    r4
.line	1644	jmp            0  l304
.line	1644	gettabup      r4    u0   k40 ; k40 = "require"
.line	1644	getupval      r5    u1
.line	1644	loadk         r6   k43 ; k43 = 224
.line	1644	loadk         r7   k44 ; k44 = 36
.line	1644	loadk         r8   k45 ; k45 = 186
.line	1644	loadk         r9   k46 ; k46 = 218
.line	1644	loadk        r10   k47 ; k47 = 122
.line	1644	loadk        r11   k48 ; k48 = 68
.line	1644	loadk        r12   k49 ; k49 = 40
.line	1644	loadk        r13   k85 ; k85 = 140
.line	1644	loadk        r14   k86 ; k86 = 230
.line	1644	loadk        r15   k87 ; k87 = 217
.line	1644	loadk        r16   k88 ; k88 = 232
.line	1644	loadk        r17   k54 ; k54 = 46
.line	1644	loadk        r18   k55 ; k55 = 82
.line	1644	loadk        r19   k35 ; k35 = 242
.line	1644	loadk        r20   k56 ; k56 = 136
.line	1644	loadk        r21   k57 ; k57 = 47
.line	1644	loadk        r22    k7 ; k7 = 16
.line	1644	loadk        r23   k89 ; k89 = 39
.line	1644	loadk        r24    k5 ; k5 = 207
.line	1644	loadk        r25   k43 ; k43 = 224
.line	1644	loadk        r26   k16 ; k16 = 134
.line	1644	loadk        r27   k58 ; k58 = 98
.line	1644	loadk        r28   k59 ; k59 = 15
.line	1644	loadk        r29   k60 ; k60 = 142
.line	1644	loadk        r30   k20 ; k20 = 240
.line	1644	loadk        r31    k2 ; k2 = 216
.line	1644	loadk        r32  k120 ; k120 = 249
.line	1644	loadk        r33  k115 ; k115 = 113
.line	1644	loadk        r34    k6 ; k6 = 73
.line	1644	loadk        r35   k88 ; k88 = 232
.line	1644	loadk        r36  k121 ; k121 = 160
.line	1644	loadk        r37   k17 ; k17 = 37
.line	1644	loadk        r38  k122 ; k122 = 0
.line	1644	loadk        r39  k123 ; k123 = 13
.line	1644	loadk        r40  k124 ; k124 = 221
.line	1644	loadk        r41   k53 ; k53 = 250
.line	1644	call          r5    37     2
.line	1644	call          r4     2     2
.line	1644	gettable      r5    r4  k125 ; k125 = "UpdateCurrSystemType"
.line	1644	gettable      r6    r4  k126 ; k126 = "LoadSystemType"
.line	1644	gettable      r6    r6  k127 ; k127 = "Wardrobe"
.line	1644	call          r5     2     1
.line	1644	gettable      r5    r4  k128 ; k128 = "LoadSuperCarVehicleS" (truncated)
.line	1644	call          r5     1     1
.line	1644	jmp            0  l307
.label	l304
.line	1644	getupval      r4    u2
.line	1644	self          r4    r4  k129 ; k129 = "EnterGarageScene"
.line	1644	call          r4     2     1
.label	l307
.line	1644	return        r0     1
.line	1644	move          r0    r0
.line	1644	gettabup      r2    u1   k45 ; k45 = 186
.line	1644	return        r0     1

.function	main/f88

.source	null
.linedefined	1671
.lastlinedefined	1675
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	212
.constant	k3	41
.constant	k4	161
.constant	k5	219
.constant	k6	102
.constant	k7	95
.constant	k8	100
.constant	k9	132
.constant	k10	203
.constant	k11	198
.constant	k12	252
.constant	k13	105
.constant	k14	93
.constant	k15	167
.constant	k16	207
.constant	k17	3
.constant	k18	29
.constant	k19	12
.constant	k20	253
.constant	k21	180
.constant	k22	97
.constant	k23	4
.constant	k24	176
.constant	k25	244
.constant	k26	209
.constant	k27	254
.constant	k28	75
.constant	k29	222
.constant	k30	156
.constant	k31	51
.constant	k32	13
.constant	k33	147
.constant	k34	"ModuleManager"
.constant	k35	"GetModule"
.constant	k36	"LobbyModuleConfig"
.constant	k37	"Lobby_camera_manager_module"
.constant	k38	"EnterWardrobeScene"
.constant	k39	"Enum_CameraID"
.constant	k40	"store_general"
.constant	k41	"LobbySceneManager"
.constant	k42	"LEVEL_NAME"
.constant	k43	"MALL"

.line	1671	gettabup      r1    u0    k0 ; k0 = "log"
.line	1671	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	1671	test          r2     0
.line	1671	jmp            0   l42
.line	1671	getupval      r2    u1
.line	1671	loadk         r3    k2 ; k2 = 212
.line	1671	loadk         r4    k3 ; k3 = 41
.line	1671	loadk         r5    k4 ; k4 = 161
.line	1671	loadk         r6    k5 ; k5 = 219
.line	1671	loadk         r7    k6 ; k6 = 102
.line	1671	loadk         r8    k7 ; k7 = 95
.line	1671	loadk         r9    k8 ; k8 = 100
.line	1671	loadk        r10    k9 ; k9 = 132
.line	1671	loadk        r11   k10 ; k10 = 203
.line	1671	loadk        r12   k11 ; k11 = 198
.line	1671	loadk        r13   k12 ; k12 = 252
.line	1671	loadk        r14   k13 ; k13 = 105
.line	1671	loadk        r15   k14 ; k14 = 93
.line	1671	loadk        r16   k15 ; k15 = 167
.line	1671	loadk        r17   k16 ; k16 = 207
.line	1671	loadk        r18   k17 ; k17 = 3
.line	1671	loadk        r19   k18 ; k18 = 29
.line	1671	loadk        r20   k19 ; k19 = 12
.line	1671	loadk        r21   k11 ; k11 = 198
.line	1671	loadk        r22   k20 ; k20 = 253
.line	1671	loadk        r23   k21 ; k21 = 180
.line	1671	loadk        r24   k22 ; k22 = 97
.line	1671	loadk        r25   k23 ; k23 = 4
.line	1671	loadk        r26   k24 ; k24 = 176
.line	1671	loadk        r27   k25 ; k25 = 244
.line	1671	loadk        r28   k26 ; k26 = 209
.line	1671	loadk        r29   k27 ; k27 = 254
.line	1671	loadk        r30    k8 ; k8 = 100
.line	1671	loadk        r31   k28 ; k28 = 75
.line	1671	loadk        r32   k29 ; k29 = 222
.line	1671	loadk        r33   k30 ; k30 = 156
.line	1671	loadk        r34   k31 ; k31 = 51
.line	1671	loadk        r35   k32 ; k32 = 13
.line	1671	loadk        r36   k32 ; k32 = 13
.line	1671	loadk        r37   k33 ; k33 = 147
.line	1671	call          r2    36     2
.label	l42
.line	1671	call          r1     2     1
.line	1671	gettabup      r1    u0   k34 ; k34 = "ModuleManager"
.line	1671	gettable      r1    r1   k35 ; k35 = "GetModule"
.line	1671	gettabup      r2    u0   k34 ; k34 = "ModuleManager"
.line	1671	gettable      r2    r2   k36 ; k36 = "LobbyModuleConfig"
.line	1671	gettable      r2    r2   k37 ; k37 = "Lobby_camera_manager" (truncated)
.line	1671	call          r1     2     2
.line	1671	self          r2    r0   k38 ; k38 = "EnterWardrobeScene"
.line	1671	gettable      r4    r1   k39 ; k39 = "Enum_CameraID"
.line	1671	gettable      r4    r4   k40 ; k40 = "store_general"
.line	1671	gettabup      r5    u0   k41 ; k41 = "LobbySceneManager"
.line	1671	gettable      r5    r5   k42 ; k42 = "LEVEL_NAME"
.line	1671	gettable      r5    r5   k43 ; k43 = "MALL"
.line	1671	call          r2     4     1
.line	1671	return        r0     1
.line	1671	move          r0    r0
.line	1671	return        r0     1

.function	main/f89

.source	null
.linedefined	1677
.lastlinedefined	1682
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	141
.constant	k11	232
.constant	k12	206
.constant	k13	242
.constant	k14	99
.constant	k15	16
.constant	k16	252
.constant	k17	153
.constant	k18	39
.constant	k19	7
.constant	k20	25
.constant	k21	209
.constant	k22	161
.constant	k23	136
.constant	k24	111
.constant	k25	17
.constant	k26	184
.constant	k27	244
.constant	k28	230
.constant	k29	255
.constant	k30	117
.constant	k31	79
.constant	k32	160
.constant	k33	55
.constant	k34	21
.constant	k35	9
.constant	k36	199
.constant	k37	254
.constant	k38	134
.constant	k39	11
.constant	k40	237
.constant	k41	41
.constant	k42	180
.constant	k43	102
.constant	k44	"ModuleManager"
.constant	k45	"GetModule"
.constant	k46	"LobbyModuleConfig"
.constant	k47	"Lobby_camera_manager_module"
.constant	k48	"LobbySceneManager"
.constant	k49	"LoadStreamLevel"
.constant	k50	"HideAllAvatar"

.line	1677	gettabup      r4    u0    k0 ; k0 = "require"
.line	1677	gettabup      r5    u0    k1 ; k1 = "table"
.line	1677	gettable      r5    r5    k2 ; k2 = "concat"
.line	1677	newtable      r6     1     0
.line	1677	getupval      r7    u1
.line	1677	loadk         r8    k3 ; k3 = 224
.line	1677	loadk         r9    k4 ; k4 = 36
.line	1677	loadk        r10    k5 ; k5 = 186
.line	1677	loadk        r11    k6 ; k6 = 218
.line	1677	loadk        r12    k7 ; k7 = 122
.line	1677	loadk        r13    k8 ; k8 = 68
.line	1677	loadk        r14    k9 ; k9 = 40
.line	1677	loadk        r15   k10 ; k10 = 141
.line	1677	loadk        r16   k11 ; k11 = 232
.line	1677	loadk        r17   k12 ; k12 = 206
.line	1677	loadk        r18   k13 ; k13 = 242
.line	1677	loadk        r19   k14 ; k14 = 99
.line	1677	loadk        r20   k15 ; k15 = 16
.line	1677	loadk        r21   k16 ; k16 = 252
.line	1677	loadk        r22   k17 ; k17 = 153
.line	1677	loadk        r23   k18 ; k18 = 39
.line	1677	loadk        r24   k19 ; k19 = 7
.line	1677	loadk        r25   k20 ; k20 = 25
.line	1677	loadk        r26   k21 ; k21 = 209
.line	1677	loadk        r27   k22 ; k22 = 161
.line	1677	loadk        r28   k23 ; k23 = 136
.line	1677	loadk        r29   k24 ; k24 = 111
.line	1677	loadk        r30   k25 ; k25 = 17
.line	1677	loadk        r31   k26 ; k26 = 184
.line	1677	loadk        r32   k27 ; k27 = 244
.line	1677	loadk        r33   k28 ; k28 = 230
.line	1677	loadk        r34   k29 ; k29 = 255
.line	1677	loadk        r35   k30 ; k30 = 117
.line	1677	loadk        r36   k31 ; k31 = 79
.line	1677	loadk        r37    k3 ; k3 = 224
.line	1677	loadk        r38   k32 ; k32 = 160
.line	1677	loadk        r39   k33 ; k33 = 55
.line	1677	loadk        r40   k34 ; k34 = 21
.line	1677	loadk        r41   k35 ; k35 = 9
.line	1677	loadk        r42   k36 ; k36 = 199
.line	1677	loadk        r43   k37 ; k37 = 254
.line	1677	loadk        r44   k38 ; k38 = 134
.line	1677	loadk        r45   k31 ; k31 = 79
.line	1677	loadk        r46   k39 ; k39 = 11
.line	1677	loadk        r47   k32 ; k32 = 160
.line	1677	call          r7    41     2
.line	1677	getupval      r8    u1
.line	1677	loadk         r9   k40 ; k40 = 237
.line	1677	loadk        r10   k41 ; k41 = 41
.line	1677	loadk        r11   k42 ; k42 = 180
.line	1677	loadk        r12    k6 ; k6 = 218
.line	1677	loadk        r13   k43 ; k43 = 102
.line	1677	call          r8     6     0
.line	1677	setlist       r6     0     1
.line	1677	call          r5     2     2
.line	1677	call          r4     2     2
.line	1677	gettabup      r5    u0   k44 ; k44 = "ModuleManager"
.line	1677	gettable      r5    r5   k45 ; k45 = "GetModule"
.line	1677	gettabup      r6    u0   k44 ; k44 = "ModuleManager"
.line	1677	gettable      r6    r6   k46 ; k46 = "LobbyModuleConfig"
.line	1677	gettable      r6    r6   k47 ; k47 = "Lobby_camera_manager" (truncated)
.line	1677	call          r5     2     2
.line	1677	gettabup      r6    u0   k48 ; k48 = "LobbySceneManager"
.line	1677	gettable      r6    r6   k49 ; k49 = "LoadStreamLevel"
.line	1677	loadbool      r7     1     0
.line	1677	move          r8    r2
.line	1677	move          r9    r1
.line	1677	call          r6     4     1
.line	1677	gettable      r6    r4   k50 ; k50 = "HideAllAvatar"
.line	1677	call          r6     1     1
.line	1677	return        r0     1
.line	1677	move          r0    r0
.line	1677	move          r0    r0
.line	1677	move          r0    r0
.line	1677	return        r0     1

.function	main/f90

.source	null
.linedefined	1684
.lastlinedefined	1692
.numparams	2
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	2	true
.upvalue	"U1"	3	true

.constant	k0	"ENUM_WardrobePageTypeId"
.constant	k1	"ENUM_WardrobePageType_Avatar"
.constant	k2	"ENUM_WardrobeSubTabString"
.constant	k3	"ENUM_WardrobeSubTabString_suit"
.constant	k4	"ENUM_ShareType"
.constant	k5	"Weapon"
.constant	k6	"ENUM_WardrobePageType_Weapon"
.constant	k7	"Enter"
.constant	k8	"bShowSubscribeSharePopup"
.constant	k9	true
.constant	k10	"ShareType"

.line	1684	gettabup      r2    u0    k0 ; k0 = "ENUM_WardrobePageTyp" (truncated)
.line	1684	gettable      r2    r2    k1 ; k1 = "ENUM_WardrobePageTyp" (truncated)
.line	1684	gettabup      r3    u0    k2 ; k2 = "ENUM_WardrobeSubTabS" (truncated)
.line	1684	gettable      r3    r3    k3 ; k3 = "ENUM_WardrobeSubTabS" (truncated)
.line	1684	gettabup      r4    u1    k4 ; k4 = "ENUM_ShareType"
.line	1684	gettable      r4    r4    k5 ; k5 = "Weapon"
.line	1684	eq             0    r1    r4
.line	1684	jmp            0   l12
.line	1684	gettabup      r4    u0    k0 ; k0 = "ENUM_WardrobePageTyp" (truncated)
.line	1684	gettable      r2    r4    k6 ; k6 = "ENUM_WardrobePageTyp" (truncated)
.line	1684	loadnil       r3     0
.label	l12
.line	1684	self          r4    r0    k7 ; k7 = "Enter"
.line	1684	move          r6    r2
.line	1684	move          r7    r3
.line	1684	newtable      r8     0     2
.line	1684	settable      r8    k8    k9 ; k9 = true
.line	1684	settable      r8   k10    r1 ; k10 = "ShareType"
.line	1684	call          r4     5     1
.line	1684	return        r0     1
.line	1684	move          r0    r0
.line	1684	move          r0    r0
.line	1684	move          r0    r0
.line	1684	move          r0    r0
.line	1684	return        r0     1

.function	main/f91

.source	null
.linedefined	1694
.lastlinedefined	1706
.numparams	3
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	2	true
.upvalue	"U1"	3	true

.constant	k0	"ENUM_WardrobePageTypeId"
.constant	k1	"ENUM_WardrobePageType_Avatar"
.constant	k2	"ENUM_WardrobeSubTabString"
.constant	k3	"ENUM_WardrobeSubTabString_suit"
.constant	k4	"ENUM_ShareType"
.constant	k5	"Weapon"
.constant	k6	"ENUM_WardrobePageType_Weapon"
.constant	k7	"Enter"
.constant	k8	"bEnterSubscribeShareEditMode"
.constant	k9	true
.constant	k10	"ShareType"
.constant	k11	"initSharedList"

.line	1694	gettabup      r3    u0    k0 ; k0 = "ENUM_WardrobePageTyp" (truncated)
.line	1694	gettable      r3    r3    k1 ; k1 = "ENUM_WardrobePageTyp" (truncated)
.line	1694	gettabup      r4    u0    k2 ; k2 = "ENUM_WardrobeSubTabS" (truncated)
.line	1694	gettable      r4    r4    k3 ; k3 = "ENUM_WardrobeSubTabS" (truncated)
.line	1694	gettabup      r5    u1    k4 ; k4 = "ENUM_ShareType"
.line	1694	gettable      r5    r5    k5 ; k5 = "Weapon"
.line	1694	eq             0    r1    r5
.line	1694	jmp            0   l12
.line	1694	gettabup      r5    u0    k0 ; k0 = "ENUM_WardrobePageTyp" (truncated)
.line	1694	gettable      r3    r5    k6 ; k6 = "ENUM_WardrobePageTyp" (truncated)
.line	1694	loadnil       r4     0
.label	l12
.line	1694	self          r5    r0    k7 ; k7 = "Enter"
.line	1694	move          r7    r3
.line	1694	move          r8    r4
.line	1694	newtable      r9     0     3
.line	1694	settable      r9    k8    k9 ; k9 = true
.line	1694	settable      r9   k10    r1 ; k10 = "ShareType"
.line	1694	settable      r9   k11    r2 ; k11 = "initSharedList"
.line	1694	call          r5     5     1
.line	1694	return        r0     1
.line	1694	move          r0    r0
.line	1694	move          r0    r0
.line	1694	move          r0    r0
.line	1694	return        r0     1

.function	main/f92

.source	null
.linedefined	1708
.lastlinedefined	1718
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	141
.constant	k11	232
.constant	k12	206
.constant	k13	242
.constant	k14	99
.constant	k15	16
.constant	k16	252
.constant	k17	153
.constant	k18	39
.constant	k19	7
.constant	k20	25
.constant	k21	209
.constant	k22	161
.constant	k23	136
.constant	k24	111
.constant	k25	17
.constant	k26	184
.constant	k27	244
.constant	k28	230
.constant	k29	255
.constant	k30	117
.constant	k31	79
.constant	k32	160
.constant	k33	55
.constant	k34	21
.constant	k35	9
.constant	k36	199
.constant	k37	254
.constant	k38	134
.constant	k39	11
.constant	k40	237
.constant	k41	41
.constant	k42	180
.constant	k43	102
.constant	k44	146
.constant	k45	235
.constant	k46	220
.constant	k47	250
.constant	k48	46
.constant	k49	75
.constant	k50	240
.constant	k51	104
.constant	k52	150
.constant	k53	20
.constant	k54	185
.constant	k55	234
.constant	k56	98
.constant	k57	74
.constant	k58	144
.constant	k59	52
.constant	k60	6
.constant	k61	222
.constant	k62	151
.constant	k63	"ENUM_WardrobeSubTabString"
.constant	k64	"ENUM_WardrobePageTypeId"
.constant	k65	"GetCurrentTabId"
.constant	k66	"ENUM_WardrobeSubTabString_throw_object"
.constant	k67	"ENUM_WardrobeSubTabString_plating"
.constant	k68	"GetCurrentPageId"
.constant	k69	"ENUM_WardrobePageType_Vehicle"
.constant	k70	"ENUM_WardrobeSubTabString_parachute"
.constant	k71	"ENUM_WardrobeSubTabString_emoji_bubble"
.constant	k72	"ENUM_WardrobeSubTabString_plane"
.constant	k73	"ShowAllAvatar"
.constant	k74	"LobbySceneManager"
.constant	k75	"SwitchMainOrTeamCamera"

.line	1708	gettabup      r1    u0    k0 ; k0 = "require"
.line	1708	gettabup      r2    u0    k1 ; k1 = "table"
.line	1708	gettable      r2    r2    k2 ; k2 = "concat"
.line	1708	newtable      r3     1     0
.line	1708	getupval      r4    u1
.line	1708	loadk         r5    k3 ; k3 = 224
.line	1708	loadk         r6    k4 ; k4 = 36
.line	1708	loadk         r7    k5 ; k5 = 186
.line	1708	loadk         r8    k6 ; k6 = 218
.line	1708	loadk         r9    k7 ; k7 = 122
.line	1708	loadk        r10    k8 ; k8 = 68
.line	1708	loadk        r11    k9 ; k9 = 40
.line	1708	loadk        r12   k10 ; k10 = 141
.line	1708	loadk        r13   k11 ; k11 = 232
.line	1708	loadk        r14   k12 ; k12 = 206
.line	1708	loadk        r15   k13 ; k13 = 242
.line	1708	loadk        r16   k14 ; k14 = 99
.line	1708	loadk        r17   k15 ; k15 = 16
.line	1708	loadk        r18   k16 ; k16 = 252
.line	1708	loadk        r19   k17 ; k17 = 153
.line	1708	loadk        r20   k18 ; k18 = 39
.line	1708	loadk        r21   k19 ; k19 = 7
.line	1708	loadk        r22   k20 ; k20 = 25
.line	1708	loadk        r23   k21 ; k21 = 209
.line	1708	loadk        r24   k22 ; k22 = 161
.line	1708	loadk        r25   k23 ; k23 = 136
.line	1708	loadk        r26   k24 ; k24 = 111
.line	1708	loadk        r27   k25 ; k25 = 17
.line	1708	loadk        r28   k26 ; k26 = 184
.line	1708	loadk        r29   k27 ; k27 = 244
.line	1708	loadk        r30   k28 ; k28 = 230
.line	1708	loadk        r31   k29 ; k29 = 255
.line	1708	loadk        r32   k30 ; k30 = 117
.line	1708	loadk        r33   k31 ; k31 = 79
.line	1708	loadk        r34    k3 ; k3 = 224
.line	1708	loadk        r35   k32 ; k32 = 160
.line	1708	loadk        r36   k33 ; k33 = 55
.line	1708	loadk        r37   k34 ; k34 = 21
.line	1708	loadk        r38   k35 ; k35 = 9
.line	1708	loadk        r39   k36 ; k36 = 199
.line	1708	loadk        r40   k37 ; k37 = 254
.line	1708	loadk        r41   k38 ; k38 = 134
.line	1708	loadk        r42   k31 ; k31 = 79
.line	1708	loadk        r43   k39 ; k39 = 11
.line	1708	loadk        r44   k32 ; k32 = 160
.line	1708	call          r4    41     2
.line	1708	getupval      r5    u1
.line	1708	loadk         r6   k40 ; k40 = 237
.line	1708	loadk         r7   k41 ; k41 = 41
.line	1708	loadk         r8   k42 ; k42 = 180
.line	1708	loadk         r9    k6 ; k6 = 218
.line	1708	loadk        r10   k43 ; k43 = 102
.line	1708	call          r5     6     0
.line	1708	setlist       r3     0     1
.line	1708	call          r2     2     2
.line	1708	call          r1     2     2
.line	1708	gettabup      r2    u0    k0 ; k0 = "require"
.line	1708	getupval      r3    u1
.line	1708	loadk         r4    k3 ; k3 = 224
.line	1708	loadk         r5    k4 ; k4 = 36
.line	1708	loadk         r6    k5 ; k5 = 186
.line	1708	loadk         r7    k6 ; k6 = 218
.line	1708	loadk         r8    k7 ; k7 = 122
.line	1708	loadk         r9    k8 ; k8 = 68
.line	1708	loadk        r10    k9 ; k9 = 40
.line	1708	loadk        r11   k44 ; k44 = 146
.line	1708	loadk        r12   k45 ; k45 = 235
.line	1708	loadk        r13   k46 ; k46 = 220
.line	1708	loadk        r14   k47 ; k47 = 250
.line	1708	loadk        r15   k48 ; k48 = 46
.line	1708	loadk        r16   k49 ; k49 = 75
.line	1708	loadk        r17   k50 ; k50 = 240
.line	1708	loadk        r18   k23 ; k23 = 136
.line	1708	loadk        r19   k51 ; k51 = 104
.line	1708	loadk        r20    k4 ; k4 = 36
.line	1708	loadk        r21   k20 ; k20 = 25
.line	1708	loadk        r22   k21 ; k21 = 209
.line	1708	loadk        r23   k45 ; k45 = 235
.line	1708	loadk        r24   k52 ; k52 = 150
.line	1708	loadk        r25   k24 ; k24 = 111
.line	1708	loadk        r26   k53 ; k53 = 20
.line	1708	loadk        r27   k42 ; k42 = 180
.line	1708	loadk        r28   k54 ; k54 = 185
.line	1708	loadk        r29   k12 ; k12 = 206
.line	1708	loadk        r30   k55 ; k55 = 234
.line	1708	loadk        r31   k56 ; k56 = 98
.line	1708	loadk        r32   k57 ; k57 = 74
.line	1708	loadk        r33   k29 ; k29 = 255
.line	1708	loadk        r34   k58 ; k58 = 144
.line	1708	loadk        r35   k59 ; k59 = 52
.line	1708	loadk        r36   k60 ; k60 = 6
.line	1708	loadk        r37   k33 ; k33 = 55
.line	1708	loadk        r38   k61 ; k61 = 222
.line	1708	loadk        r39   k37 ; k37 = 254
.line	1708	loadk        r40   k62 ; k62 = 151
.line	1708	loadk        r41   k56 ; k56 = 98
.line	1708	loadk        r42   k35 ; k35 = 9
.line	1708	call          r3    40     2
.line	1708	call          r2     2     2
.line	1708	gettable      r3    r2   k63 ; k63 = "ENUM_WardrobeSubTabS" (truncated)
.line	1708	gettable      r4    r2   k64 ; k64 = "ENUM_WardrobePageTyp" (truncated)
.line	1708	self          r5    r0   k65 ; k65 = "GetCurrentTabId"
.line	1708	call          r5     2     2
.line	1708	gettable      r6    r3   k66 ; k66 = "ENUM_WardrobeSubTabS" (truncated)
.line	1708	eq             1    r5    r6
.line	1708	jmp            0  l132
.line	1708	self          r5    r0   k65 ; k65 = "GetCurrentTabId"
.line	1708	call          r5     2     2
.line	1708	gettable      r6    r3   k67 ; k67 = "ENUM_WardrobeSubTabS" (truncated)
.line	1708	eq             1    r5    r6
.line	1708	jmp            0  l132
.line	1708	self          r5    r0   k68 ; k68 = "GetCurrentPageId"
.line	1708	call          r5     2     2
.line	1708	gettable      r6    r4   k69 ; k69 = "ENUM_WardrobePageTyp" (truncated)
.line	1708	eq             1    r5    r6
.line	1708	jmp            0  l132
.line	1708	self          r5    r0   k65 ; k65 = "GetCurrentTabId"
.line	1708	call          r5     2     2
.line	1708	gettable      r6    r3   k70 ; k70 = "ENUM_WardrobeSubTabS" (truncated)
.line	1708	eq             1    r5    r6
.line	1708	jmp            0  l132
.line	1708	self          r5    r0   k65 ; k65 = "GetCurrentTabId"
.line	1708	call          r5     2     2
.line	1708	gettable      r6    r3   k71 ; k71 = "ENUM_WardrobeSubTabS" (truncated)
.line	1708	eq             1    r5    r6
.line	1708	jmp            0  l132
.line	1708	self          r5    r0   k65 ; k65 = "GetCurrentTabId"
.line	1708	call          r5     2     2
.line	1708	gettable      r6    r3   k72 ; k72 = "ENUM_WardrobeSubTabS" (truncated)
.line	1708	eq             0    r5    r6
.line	1708	jmp            0  l135
.label	l132
.line	1708	gettable      r5    r1   k73 ; k73 = "ShowAllAvatar"
.line	1708	call          r5     1     1
.line	1708	jmp            0  l139
.label	l135
.line	1708	gettabup      r5    u0   k74 ; k74 = "LobbySceneManager"
.line	1708	gettable      r5    r5   k75 ; k75 = "SwitchMainOrTeamCame" (truncated)
.line	1708	loadbool      r6     1     0
.line	1708	call          r5     2     1
.label	l139
.line	1708	return        r0     1
.line	1708	move          r0    r0
.line	1708	move          r0    r0
.line	1708	move          r0    r0
.line	1708	move          r0    r0
.line	1708	return        r0     1

.function	main/f93

.source	null
.linedefined	1720
.lastlinedefined	1749
.numparams	3
.is_vararg	0
.maxstacksize	55

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	75
.constant	k46	240
.constant	k47	104
.constant	k48	25
.constant	k49	209
.constant	k50	111
.constant	k51	20
.constant	k52	180
.constant	k53	185
.constant	k54	206
.constant	k55	74
.constant	k56	255
.constant	k57	52
.constant	k58	6
.constant	k59	55
.constant	k60	222
.constant	k61	254
.constant	k62	151
.constant	k63	"ENUM_WardrobeSubTabString"
.constant	k64	"ENUM_WardrobePageTypeId"
.constant	k65	"GetCurrentPageId"
.constant	k66	"GetCurrentTabId"
.constant	k67	"ENUM_WardrobePageType_Parachute"
.constant	k68	"ENUM_WardrobeSubTabString_throw_object"
.constant	k69	"GetCurrentThrowObjectType"
.constant	k70	"GetHallDepotItemDataByResID"
.constant	k71	"itemSubType"
.constant	k72	"log"
.constant	k73	"bWriteLog"
.constant	k74	41
.constant	k75	161
.constant	k76	219
.constant	k77	102
.constant	k78	95
.constant	k79	132
.constant	k80	203
.constant	k81	198
.constant	k82	252
.constant	k83	105
.constant	k84	93
.constant	k85	167
.constant	k86	188
.constant	k87	28
.constant	k88	15
.constant	k89	228
.constant	k90	253
.constant	k91	129
.constant	k92	110
.constant	k93	181
.constant	k94	244
.constant	k95	116
.constant	k96	225
.constant	k97	223
.constant	k98	56
.constant	k99	12
.constant	k100	147
.constant	k101	246
.constant	k102	154
.constant	k103	48
.constant	k104	5
.constant	k105	241
.constant	k106	58
.constant	k107	182
.constant	k108	96
.constant	k109	118
.constant	k110	128
.constant	k111	204
.constant	k112	187
.constant	k113	"tostring"
.constant	k114	"slua"
.constant	k115	"getMicroseconds"
.constant	k116	141
.constant	k117	232
.constant	k118	153
.constant	k119	39
.constant	k120	7
.constant	k121	169
.constant	k122	18
.constant	k123	251
.constant	k124	226
.constant	k125	94
.constant	k126	158
.constant	k127	26
.constant	k128	"Init"
.constant	k129	"SetNeedAutoRotate"
.constant	k130	"Display"
.constant	k131	197
.constant	k132	1000
.constant	k133	"EventSystem"
.constant	k134	"postEvent"
.constant	k135	"EVENTTYPE_WARDROBE"
.constant	k136	"EVENTID_WARDROBE_CreateDownloader"

.line	1720	gettabup      r3    u0    k0 ; k0 = "require"
.line	1720	gettabup      r4    u0    k1 ; k1 = "table"
.line	1720	gettable      r4    r4    k2 ; k2 = "concat"
.line	1720	newtable      r5     1     0
.line	1720	getupval      r6    u1
.line	1720	loadk         r7    k3 ; k3 = 224
.line	1720	loadk         r8    k4 ; k4 = 36
.line	1720	loadk         r9    k5 ; k5 = 186
.line	1720	loadk        r10    k6 ; k6 = 218
.line	1720	loadk        r11    k7 ; k7 = 122
.line	1720	loadk        r12    k8 ; k8 = 68
.line	1720	loadk        r13    k9 ; k9 = 40
.line	1720	loadk        r14   k10 ; k10 = 146
.line	1720	loadk        r15   k11 ; k11 = 235
.line	1720	loadk        r16   k12 ; k12 = 220
.line	1720	loadk        r17   k13 ; k13 = 250
.line	1720	loadk        r18   k14 ; k14 = 46
.line	1720	loadk        r19   k15 ; k15 = 82
.line	1720	loadk        r20   k16 ; k16 = 242
.line	1720	loadk        r21   k17 ; k17 = 136
.line	1720	loadk        r22   k18 ; k18 = 47
.line	1720	loadk        r23   k19 ; k19 = 16
.line	1720	loadk        r24   k20 ; k20 = 86
.line	1720	loadk        r25   k21 ; k21 = 212
.line	1720	loadk        r26   k22 ; k22 = 238
.line	1720	loadk        r27   k23 ; k23 = 150
.line	1720	loadk        r28   k24 ; k24 = 100
.line	1720	loadk        r29   k25 ; k25 = 4
.line	1720	loadk        r30   k26 ; k26 = 190
.line	1720	loadk        r31   k27 ; k27 = 245
.line	1720	loadk        r32   k12 ; k12 = 220
.line	1720	loadk        r33   k28 ; k28 = 165
.line	1720	loadk        r34   k29 ; k29 = 124
.line	1720	loadk        r35   k30 ; k30 = 65
.line	1720	loadk        r36   k31 ; k31 = 234
.line	1720	loadk        r37   k23 ; k23 = 150
.line	1720	loadk        r38   k32 ; k32 = 53
.line	1720	loadk        r39   k33 ; k33 = 60
.line	1720	loadk        r40   k34 ; k34 = 31
.line	1720	loadk        r41   k35 ; k35 = 210
.line	1720	loadk        r42   k36 ; k36 = 237
.line	1720	loadk        r43   k37 ; k37 = 144
.line	1720	loadk        r44   k38 ; k38 = 98
.line	1720	loadk        r45   k39 ; k39 = 9
.line	1720	loadk        r46   k40 ; k40 = 163
.line	1720	call          r6    41     2
.line	1720	getupval      r7    u1
.line	1720	loadk         r8   k41 ; k41 = 230
.line	1720	loadk         r9   k42 ; k42 = 23
.line	1720	loadk        r10   k43 ; k43 = 189
.line	1720	loadk        r11    k6 ; k6 = 218
.line	1720	loadk        r12   k44 ; k44 = 99
.line	1720	call          r7     6     0
.line	1720	setlist       r5     0     1
.line	1720	call          r4     2     2
.line	1720	call          r3     2     2
.line	1720	gettabup      r4    u0    k0 ; k0 = "require"
.line	1720	getupval      r5    u1
.line	1720	loadk         r6    k3 ; k3 = 224
.line	1720	loadk         r7    k4 ; k4 = 36
.line	1720	loadk         r8    k5 ; k5 = 186
.line	1720	loadk         r9    k6 ; k6 = 218
.line	1720	loadk        r10    k7 ; k7 = 122
.line	1720	loadk        r11    k8 ; k8 = 68
.line	1720	loadk        r12    k9 ; k9 = 40
.line	1720	loadk        r13   k10 ; k10 = 146
.line	1720	loadk        r14   k11 ; k11 = 235
.line	1720	loadk        r15   k12 ; k12 = 220
.line	1720	loadk        r16   k13 ; k13 = 250
.line	1720	loadk        r17   k14 ; k14 = 46
.line	1720	loadk        r18   k45 ; k45 = 75
.line	1720	loadk        r19   k46 ; k46 = 240
.line	1720	loadk        r20   k17 ; k17 = 136
.line	1720	loadk        r21   k47 ; k47 = 104
.line	1720	loadk        r22    k4 ; k4 = 36
.line	1720	loadk        r23   k48 ; k48 = 25
.line	1720	loadk        r24   k49 ; k49 = 209
.line	1720	loadk        r25   k11 ; k11 = 235
.line	1720	loadk        r26   k23 ; k23 = 150
.line	1720	loadk        r27   k50 ; k50 = 111
.line	1720	loadk        r28   k51 ; k51 = 20
.line	1720	loadk        r29   k52 ; k52 = 180
.line	1720	loadk        r30   k53 ; k53 = 185
.line	1720	loadk        r31   k54 ; k54 = 206
.line	1720	loadk        r32   k31 ; k31 = 234
.line	1720	loadk        r33   k38 ; k38 = 98
.line	1720	loadk        r34   k55 ; k55 = 74
.line	1720	loadk        r35   k56 ; k56 = 255
.line	1720	loadk        r36   k37 ; k37 = 144
.line	1720	loadk        r37   k57 ; k57 = 52
.line	1720	loadk        r38   k58 ; k58 = 6
.line	1720	loadk        r39   k59 ; k59 = 55
.line	1720	loadk        r40   k60 ; k60 = 222
.line	1720	loadk        r41   k61 ; k61 = 254
.line	1720	loadk        r42   k62 ; k62 = 151
.line	1720	loadk        r43   k38 ; k38 = 98
.line	1720	loadk        r44   k39 ; k39 = 9
.line	1720	call          r5    40     2
.line	1720	call          r4     2     2
.line	1720	gettable      r5    r4   k63 ; k63 = "ENUM_WardrobeSubTabS" (truncated)
.line	1720	gettable      r6    r4   k64 ; k64 = "ENUM_WardrobePageTyp" (truncated)
.line	1720	gettable      r7    r3   k65 ; k65 = "GetCurrentPageId"
.line	1720	call          r7     1     2
.line	1720	gettable      r8    r3   k66 ; k66 = "GetCurrentTabId"
.line	1720	call          r8     1     2
.line	1720	test          r2     1
.line	1720	jmp            0  l205
.line	1720	gettable      r9    r6   k67 ; k67 = "ENUM_WardrobePageTyp" (truncated)
.line	1720	eq             0    r7    r9
.line	1720	jmp            0  l114
.line	1720	gettable      r9    r5   k68 ; k68 = "ENUM_WardrobeSubTabS" (truncated)
.line	1720	eq             1    r8    r9
.line	1720	jmp            0  l115
.label	l114
.line	1720	return        r0     1
.label	l115
.line	1720	self          r9    r3   k69 ; k69 = "GetCurrentThrowObjec" (truncated)
.line	1720	call          r9     2     2
.line	1720	test          r9     0
.line	1720	jmp            0  l205
.line	1720	getupval     r10    u2
.line	1720	self         r10   r10   k70 ; k70 = "GetHallDepotItemData" (truncated)
.line	1720	move         r12    r1
.line	1720	call         r10     3     2
.line	1720	test         r10     0
.line	1720	jmp            0  l205
.line	1720	gettable     r11   r10   k71 ; k71 = "itemSubType"
.line	1720	eq             1   r11    r9
.line	1720	jmp            0  l205
.line	1720	gettabup     r11    u0   k72 ; k72 = "log"
.line	1720	gettabup     r12    u0   k73 ; k73 = "bWriteLog"
.line	1720	test         r12     0
.line	1720	jmp            0  l203
.line	1720	gettabup     r12    u0    k1 ; k1 = "table"
.line	1720	gettable     r12   r12    k2 ; k2 = "concat"
.line	1720	newtable     r13     1     0
.line	1720	getupval     r14    u1
.line	1720	loadk        r15   k21 ; k21 = 212
.line	1720	loadk        r16   k74 ; k74 = 41
.line	1720	loadk        r17   k75 ; k75 = 161
.line	1720	loadk        r18   k76 ; k76 = 219
.line	1720	loadk        r19   k77 ; k77 = 102
.line	1720	loadk        r20   k78 ; k78 = 95
.line	1720	loadk        r21   k24 ; k24 = 100
.line	1720	loadk        r22   k79 ; k79 = 132
.line	1720	loadk        r23   k80 ; k80 = 203
.line	1720	loadk        r24   k81 ; k81 = 198
.line	1720	loadk        r25   k82 ; k82 = 252
.line	1720	loadk        r26   k83 ; k83 = 105
.line	1720	loadk        r27   k84 ; k84 = 93
.line	1720	loadk        r28   k85 ; k85 = 167
.line	1720	loadk        r29   k86 ; k86 = 188
.line	1720	loadk        r30   k14 ; k14 = 46
.line	1720	loadk        r31   k87 ; k87 = 28
.line	1720	loadk        r32   k88 ; k88 = 15
.line	1720	loadk        r33   k89 ; k89 = 228
.line	1720	loadk        r34   k90 ; k90 = 253
.line	1720	loadk        r35   k91 ; k91 = 129
.line	1720	loadk        r36   k92 ; k92 = 110
.line	1720	loadk        r37   k42 ; k42 = 23
.line	1720	loadk        r38   k93 ; k93 = 181
.line	1720	loadk        r39   k16 ; k16 = 242
.line	1720	loadk        r40   k94 ; k94 = 244
.line	1720	loadk        r41   k89 ; k89 = 228
.line	1720	loadk        r42   k95 ; k95 = 116
.line	1720	loadk        r43   k45 ; k45 = 75
.line	1720	loadk        r44   k96 ; k96 = 225
.line	1720	loadk        r45   k97 ; k97 = 223
.line	1720	loadk        r46   k98 ; k98 = 56
.line	1720	loadk        r47   k99 ; k99 = 12
.line	1720	loadk        r48   k87 ; k87 = 28
.line	1720	loadk        r49  k100 ; k100 = 147
.line	1720	loadk        r50  k101 ; k101 = 246
.line	1720	loadk        r51  k102 ; k102 = 154
.line	1720	loadk        r52  k103 ; k103 = 48
.line	1720	loadk        r53  k104 ; k104 = 5
.line	1720	loadk        r54   k52 ; k52 = 180
.line	1720	call         r14    41     2
.line	1720	getupval     r15    u1
.line	1720	loadk        r16  k105 ; k105 = 241
.line	1720	loadk        r17  k106 ; k106 = 58
.line	1720	loadk        r18  k107 ; k107 = 182
.line	1720	loadk        r19   k49 ; k49 = 209
.line	1720	loadk        r20  k108 ; k108 = 96
.line	1720	loadk        r21   k19 ; k19 = 16
.line	1720	loadk        r22  k109 ; k109 = 118
.line	1720	loadk        r23  k110 ; k110 = 128
.line	1720	loadk        r24    k3 ; k3 = 224
.line	1720	loadk        r25  k111 ; k111 = 204
.line	1720	loadk        r26  k112 ; k112 = 187
.line	1720	call         r15    12     0
.line	1720	setlist      r13     0     1
.line	1720	call         r12     2     2
.line	1720	gettabup     r13    u0  k113 ; k113 = "tostring"
.line	1720	move         r14    r1
.line	1720	call         r13     2     2
.line	1720	getupval     r14    u1
.line	1720	loadk        r15   k40 ; k40 = 163
.line	1720	loadk        r16   k47 ; k47 = 104
.line	1720	call         r14     3     2
.line	1720	gettabup     r15    u0  k113 ; k113 = "tostring"
.line	1720	move         r16    r9
.line	1720	call         r15     2     2
.line	1720	concat       r12   r12   r15
.label	l203
.line	1720	call         r11     2     1
.line	1720	return        r0     1
.label	l205
.line	1720	gettabup      r9    u0  k114 ; k114 = "slua"
.line	1720	gettable      r9    r9  k115 ; k115 = "getMicroseconds"
.line	1720	move         r10    r9
.line	1720	call         r10     1     2
.line	1720	gettabup     r11    u0    k0 ; k0 = "require"
.line	1720	getupval     r12    u1
.line	1720	loadk        r13    k3 ; k3 = 224
.line	1720	loadk        r14    k4 ; k4 = 36
.line	1720	loadk        r15    k5 ; k5 = 186
.line	1720	loadk        r16    k6 ; k6 = 218
.line	1720	loadk        r17    k7 ; k7 = 122
.line	1720	loadk        r18    k8 ; k8 = 68
.line	1720	loadk        r19    k9 ; k9 = 40
.line	1720	loadk        r20  k116 ; k116 = 141
.line	1720	loadk        r21  k117 ; k117 = 232
.line	1720	loadk        r22   k54 ; k54 = 206
.line	1720	loadk        r23   k16 ; k16 = 242
.line	1720	loadk        r24   k44 ; k44 = 99
.line	1720	loadk        r25   k19 ; k19 = 16
.line	1720	loadk        r26   k82 ; k82 = 252
.line	1720	loadk        r27  k118 ; k118 = 153
.line	1720	loadk        r28  k119 ; k119 = 39
.line	1720	loadk        r29  k120 ; k120 = 7
.line	1720	loadk        r30   k48 ; k48 = 25
.line	1720	loadk        r31   k49 ; k49 = 209
.line	1720	loadk        r32   k75 ; k75 = 161
.line	1720	loadk        r33  k121 ; k121 = 169
.line	1720	loadk        r34   k50 ; k50 = 111
.line	1720	loadk        r35  k122 ; k122 = 18
.line	1720	loadk        r36   k52 ; k52 = 180
.line	1720	loadk        r37  k123 ; k123 = 251
.line	1720	loadk        r38   k90 ; k90 = 253
.line	1720	loadk        r39  k124 ; k124 = 226
.line	1720	loadk        r40   k44 ; k44 = 99
.line	1720	loadk        r41  k125 ; k125 = 94
.line	1720	loadk        r42   k96 ; k96 = 225
.line	1720	loadk        r43  k126 ; k126 = 158
.line	1720	loadk        r44   k18 ; k18 = 47
.line	1720	loadk        r45   k58 ; k58 = 6
.line	1720	loadk        r46  k127 ; k127 = 26
.line	1720	call         r12    35     2
.line	1720	call         r11     2     2
.line	1720	gettable     r12   r11  k128 ; k128 = "Init"
.line	1720	call         r12     1     1
.line	1720	gettable     r12   r11  k129 ; k129 = "SetNeedAutoRotate"
.line	1720	loadbool     r13     1     0
.line	1720	call         r12     2     1
.line	1720	gettable     r12   r11  k130 ; k130 = "Display"
.line	1720	move         r13    r1
.line	1720	loadbool     r14     1     0
.line	1720	call         r12     3     1
.line	1720	move         r12    r9
.line	1720	call         r12     1     2
.line	1720	gettabup     r13    u0   k72 ; k72 = "log"
.line	1720	gettabup     r14    u0   k73 ; k73 = "bWriteLog"
.line	1720	test         r14     0
.line	1720	jmp            0  l300
.line	1720	getupval     r14    u1
.line	1720	loadk        r15   k21 ; k21 = 212
.line	1720	loadk        r16   k74 ; k74 = 41
.line	1720	loadk        r17   k75 ; k75 = 161
.line	1720	loadk        r18   k76 ; k76 = 219
.line	1720	loadk        r19   k77 ; k77 = 102
.line	1720	loadk        r20   k78 ; k78 = 95
.line	1720	loadk        r21   k24 ; k24 = 100
.line	1720	loadk        r22   k79 ; k79 = 132
.line	1720	loadk        r23   k80 ; k80 = 203
.line	1720	loadk        r24   k81 ; k81 = 198
.line	1720	loadk        r25   k82 ; k82 = 252
.line	1720	loadk        r26   k83 ; k83 = 105
.line	1720	loadk        r27   k84 ; k84 = 93
.line	1720	loadk        r28   k85 ; k85 = 167
.line	1720	loadk        r29   k86 ; k86 = 188
.line	1720	loadk        r30   k14 ; k14 = 46
.line	1720	loadk        r31   k87 ; k87 = 28
.line	1720	loadk        r32   k88 ; k88 = 15
.line	1720	loadk        r33   k89 ; k89 = 228
.line	1720	loadk        r34   k90 ; k90 = 253
.line	1720	loadk        r35   k91 ; k91 = 129
.line	1720	loadk        r36   k92 ; k92 = 110
.line	1720	loadk        r37   k42 ; k42 = 23
.line	1720	loadk        r38   k93 ; k93 = 181
.line	1720	loadk        r39   k16 ; k16 = 242
.line	1720	loadk        r40   k94 ; k94 = 244
.line	1720	loadk        r41   k89 ; k89 = 228
.line	1720	loadk        r42   k95 ; k95 = 116
.line	1720	loadk        r43   k45 ; k45 = 75
.line	1720	loadk        r44   k96 ; k96 = 225
.line	1720	loadk        r45  k131 ; k131 = 197
.line	1720	call         r14    32     2
.line	1720	gettabup     r15    u0  k113 ; k113 = "tostring"
.line	1720	sub          r16   r12   r10
.line	1720	div          r16   r16  k132 ; k132 = 1000
.line	1720	call         r15     2     2
.line	1720	concat       r14   r14   r15
.label	l300
.line	1720	call         r13     2     1
.line	1720	gettabup     r13    u0  k133 ; k133 = "EventSystem"
.line	1720	self         r13   r13  k134 ; k134 = "postEvent"
.line	1720	gettabup     r15    u0  k135 ; k135 = "EVENTTYPE_WARDROBE"
.line	1720	gettabup     r16    u0  k136 ; k136 = "EVENTID_WARDROBE_Cre" (truncated)
.line	1720	move         r17    r1
.line	1720	call         r13     5     1
.line	1720	return        r0     1
.line	1720	move          r0    r0
.line	1720	move          r0    r0
.line	1720	move          r0    r0
.line	1720	move          r0    r0
.line	1720	return        r0     1

.function	main/f94

.source	null
.linedefined	1751
.lastlinedefined	1769
.numparams	5
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	75
.constant	k16	240
.constant	k17	136
.constant	k18	104
.constant	k19	25
.constant	k20	209
.constant	k21	150
.constant	k22	111
.constant	k23	20
.constant	k24	180
.constant	k25	185
.constant	k26	205
.constant	k27	226
.constant	k28	96
.constant	k29	93
.constant	k30	163
.constant	k31	34
.constant	k32	6
.constant	k33	5
.constant	k34	236
.constant	k35	157
.constant	k36	21
.constant	k37	158
.constant	k38	238
.constant	k39	47
.constant	k40	161
.constant	k41	1
.constant	k42	2
.constant	k43	30
.constant	k44	14
.constant	k45	211
.constant	k46	208
.constant	k47	137
.constant	k48	184
.constant	k49	248
.constant	k50	215
.constant	k51	165
.constant	k52	125
.constant	k53	88
.constant	k54	253
.constant	k55	160
.constant	k56	63
.constant	k57	0
.constant	k58	7
.constant	k59	221
.constant	k60	192
.constant	k61	132
.constant	k62	98
.constant	k63	3
.constant	k64	183
.constant	k65	234
.constant	k66	45
.constant	k67	164
.constant	k68	"Show"
.constant	k69	"UIManager"
.constant	k70	"UI_Config"
.constant	k71	"wardrobe"
.constant	k72	41
.constant	k73	189
.constant	k74	201
.constant	k75	117
.constant	k76	67
.constant	k77	86
.constant	k78	128
.constant	k79	233
.constant	k80	204
.constant	k81	247
.constant	k82	95
.constant	k83	82
.constant	k84	242
.constant	k85	16
.constant	k86	212
.constant	k87	100
.constant	k88	4
.constant	k89	190
.constant	k90	245
.constant	k91	124
.constant	k92	65
.constant	k93	53
.constant	k94	60
.constant	k95	12
.constant	k96	59
.constant	k97	182
.constant	k98	203
.constant	k99	89
.constant	k100	134
.constant	k101	"MVPActionType"
.constant	k102	"ShowNotice"
.constant	k103	18010296
.constant	k104	"ModuleManager"
.constant	k105	"GetModule"
.constant	k106	"LobbyModuleConfig"
.constant	k107	"LogicParticleEmote"
.constant	k108	"GetParticleEmoteID"
.constant	k109	31
.constant	k110	210
.constant	k111	237
.constant	k112	144
.constant	k113	9
.constant	k114	230
.constant	k115	23
.constant	k116	99
.constant	k117	"PlayMotion"
.constant	k118	"ENUM_ITEM_TIPS_TYPE"
.constant	k119	"ENUM_ITEM_TIPS_TYPE_TINY"

.line	1751	gettabup      r5    u0    k0 ; k0 = "require"
.line	1751	gettabup      r6    u0    k1 ; k1 = "table"
.line	1751	gettable      r6    r6    k2 ; k2 = "concat"
.line	1751	newtable      r7     1     0
.line	1751	getupval      r8    u1
.line	1751	loadk         r9    k3 ; k3 = 224
.line	1751	loadk        r10    k4 ; k4 = 36
.line	1751	loadk        r11    k5 ; k5 = 186
.line	1751	loadk        r12    k6 ; k6 = 218
.line	1751	loadk        r13    k7 ; k7 = 122
.line	1751	loadk        r14    k8 ; k8 = 68
.line	1751	loadk        r15    k9 ; k9 = 40
.line	1751	loadk        r16   k10 ; k10 = 146
.line	1751	loadk        r17   k11 ; k11 = 235
.line	1751	loadk        r18   k12 ; k12 = 220
.line	1751	loadk        r19   k13 ; k13 = 250
.line	1751	loadk        r20   k14 ; k14 = 46
.line	1751	loadk        r21   k15 ; k15 = 75
.line	1751	loadk        r22   k16 ; k16 = 240
.line	1751	loadk        r23   k17 ; k17 = 136
.line	1751	loadk        r24   k18 ; k18 = 104
.line	1751	loadk        r25    k4 ; k4 = 36
.line	1751	loadk        r26   k19 ; k19 = 25
.line	1751	loadk        r27   k20 ; k20 = 209
.line	1751	loadk        r28   k11 ; k11 = 235
.line	1751	loadk        r29   k21 ; k21 = 150
.line	1751	loadk        r30   k22 ; k22 = 111
.line	1751	loadk        r31   k23 ; k23 = 20
.line	1751	loadk        r32   k24 ; k24 = 180
.line	1751	loadk        r33   k25 ; k25 = 185
.line	1751	loadk        r34   k26 ; k26 = 205
.line	1751	loadk        r35   k27 ; k27 = 226
.line	1751	loadk        r36   k28 ; k28 = 96
.line	1751	loadk        r37   k29 ; k29 = 93
.line	1751	loadk        r38   k30 ; k30 = 163
.line	1751	loadk        r39   k21 ; k21 = 150
.line	1751	loadk        r40   k31 ; k31 = 34
.line	1751	loadk        r41   k32 ; k32 = 6
.line	1751	loadk        r42   k33 ; k33 = 5
.line	1751	loadk        r43   k34 ; k34 = 236
.line	1751	loadk        r44   k11 ; k11 = 235
.line	1751	loadk        r45   k35 ; k35 = 157
.line	1751	loadk        r46   k28 ; k28 = 96
.line	1751	loadk        r47   k36 ; k36 = 21
.line	1751	loadk        r48   k37 ; k37 = 158
.line	1751	call          r8    41     2
.line	1751	getupval      r9    u1
.line	1751	loadk        r10   k38 ; k38 = 238
.line	1751	loadk        r11   k39 ; k39 = 47
.line	1751	loadk        r12   k40 ; k40 = 161
.line	1751	call          r9     4     0
.line	1751	setlist       r7     0     1
.line	1751	call          r6     2     2
.line	1751	call          r5     2     2
.line	1751	eq             0    r2   k41 ; k41 = 1
.line	1751	jmp            0   l58
.line	1751	jmp            0  l280
.label	l58
.line	1751	eq             0    r2   k42 ; k42 = 2
.line	1751	jmp            0  l137
.line	1751	gettabup      r6    u0    k0 ; k0 = "require"
.line	1751	gettabup      r7    u0    k1 ; k1 = "table"
.line	1751	gettable      r7    r7    k2 ; k2 = "concat"
.line	1751	newtable      r8     1     0
.line	1751	getupval      r9    u1
.line	1751	loadk        r10    k3 ; k3 = 224
.line	1751	loadk        r11    k4 ; k4 = 36
.line	1751	loadk        r12    k5 ; k5 = 186
.line	1751	loadk        r13    k6 ; k6 = 218
.line	1751	loadk        r14    k7 ; k7 = 122
.line	1751	loadk        r15    k8 ; k8 = 68
.line	1751	loadk        r16    k9 ; k9 = 40
.line	1751	loadk        r17   k10 ; k10 = 146
.line	1751	loadk        r18   k11 ; k11 = 235
.line	1751	loadk        r19   k12 ; k12 = 220
.line	1751	loadk        r20   k13 ; k13 = 250
.line	1751	loadk        r21   k14 ; k14 = 46
.line	1751	loadk        r22   k15 ; k15 = 75
.line	1751	loadk        r23   k16 ; k16 = 240
.line	1751	loadk        r24   k17 ; k17 = 136
.line	1751	loadk        r25   k18 ; k18 = 104
.line	1751	loadk        r26   k43 ; k43 = 30
.line	1751	loadk        r27   k44 ; k44 = 14
.line	1751	loadk        r28   k45 ; k45 = 211
.line	1751	loadk        r29   k46 ; k46 = 208
.line	1751	loadk        r30   k47 ; k47 = 137
.line	1751	loadk        r31   k22 ; k22 = 111
.line	1751	loadk        r32   k42 ; k42 = 2
.line	1751	loadk        r33   k48 ; k48 = 184
.line	1751	loadk        r34   k49 ; k49 = 248
.line	1751	loadk        r35   k50 ; k50 = 215
.line	1751	loadk        r36   k51 ; k51 = 165
.line	1751	loadk        r37   k52 ; k52 = 125
.line	1751	loadk        r38   k53 ; k53 = 88
.line	1751	loadk        r39   k54 ; k54 = 253
.line	1751	loadk        r40   k55 ; k55 = 160
.line	1751	loadk        r41   k56 ; k56 = 63
.line	1751	loadk        r42   k57 ; k57 = 0
.line	1751	loadk        r43   k58 ; k58 = 7
.line	1751	loadk        r44   k59 ; k59 = 221
.line	1751	loadk        r45   k60 ; k60 = 192
.line	1751	loadk        r46   k61 ; k61 = 132
.line	1751	loadk        r47   k62 ; k62 = 98
.line	1751	loadk        r48   k63 ; k63 = 3
.line	1751	loadk        r49   k64 ; k64 = 183
.line	1751	call          r9    41     2
.line	1751	getupval     r10    u1
.line	1751	loadk        r11   k65 ; k65 = 234
.line	1751	loadk        r12   k66 ; k66 = 45
.line	1751	loadk        r13   k67 ; k67 = 164
.line	1751	call         r10     4     0
.line	1751	setlist       r8     0     1
.line	1751	call          r7     2     2
.line	1751	call          r6     2     2
.line	1751	gettable      r7    r6   k68 ; k68 = "Show"
.line	1751	move          r8    r1
.line	1751	gettabup      r9    u0   k69 ; k69 = "UIManager"
.line	1751	gettable      r9    r9   k70 ; k70 = "UI_Config"
.line	1751	gettable      r9    r9   k71 ; k71 = "wardrobe"
.line	1751	getupval     r10    u1
.line	1751	loadk        r11   k60 ; k60 = 192
.line	1751	loadk        r12   k72 ; k72 = 41
.line	1751	loadk        r13   k73 ; k73 = 189
.line	1751	loadk        r14   k74 ; k74 = 201
.line	1751	loadk        r15   k75 ; k75 = 117
.line	1751	loadk        r16   k76 ; k76 = 67
.line	1751	loadk        r17   k77 ; k77 = 86
.line	1751	loadk        r18   k78 ; k78 = 128
.line	1751	loadk        r19   k79 ; k79 = 233
.line	1751	loadk        r20   k80 ; k80 = 204
.line	1751	loadk        r21   k81 ; k81 = 247
.line	1751	loadk        r22   k82 ; k82 = 95
.line	1751	loadk        r23   k58 ; k58 = 7
.line	1751	call         r10    14     2
.line	1751	move         r11    r4
.line	1751	call          r7     5     1
.line	1751	jmp            0  l280
.label	l137
.line	1751	eq             0    r2   k63 ; k63 = 3
.line	1751	jmp            0  l280
.line	1751	gettabup      r6    u0    k0 ; k0 = "require"
.line	1751	gettabup      r7    u0    k1 ; k1 = "table"
.line	1751	gettable      r7    r7    k2 ; k2 = "concat"
.line	1751	newtable      r8     1     0
.line	1751	getupval      r9    u1
.line	1751	loadk        r10    k3 ; k3 = 224
.line	1751	loadk        r11    k4 ; k4 = 36
.line	1751	loadk        r12    k5 ; k5 = 186
.line	1751	loadk        r13    k6 ; k6 = 218
.line	1751	loadk        r14    k7 ; k7 = 122
.line	1751	loadk        r15    k8 ; k8 = 68
.line	1751	loadk        r16    k9 ; k9 = 40
.line	1751	loadk        r17   k10 ; k10 = 146
.line	1751	loadk        r18   k11 ; k11 = 235
.line	1751	loadk        r19   k12 ; k12 = 220
.line	1751	loadk        r20   k13 ; k13 = 250
.line	1751	loadk        r21   k14 ; k14 = 46
.line	1751	loadk        r22   k83 ; k83 = 82
.line	1751	loadk        r23   k84 ; k84 = 242
.line	1751	loadk        r24   k17 ; k17 = 136
.line	1751	loadk        r25   k39 ; k39 = 47
.line	1751	loadk        r26   k85 ; k85 = 16
.line	1751	loadk        r27   k77 ; k77 = 86
.line	1751	loadk        r28   k86 ; k86 = 212
.line	1751	loadk        r29   k38 ; k38 = 238
.line	1751	loadk        r30   k21 ; k21 = 150
.line	1751	loadk        r31   k87 ; k87 = 100
.line	1751	loadk        r32   k88 ; k88 = 4
.line	1751	loadk        r33   k89 ; k89 = 190
.line	1751	loadk        r34   k90 ; k90 = 245
.line	1751	loadk        r35   k12 ; k12 = 220
.line	1751	loadk        r36   k51 ; k51 = 165
.line	1751	loadk        r37   k91 ; k91 = 124
.line	1751	loadk        r38   k92 ; k92 = 65
.line	1751	loadk        r39   k65 ; k65 = 234
.line	1751	loadk        r40   k21 ; k21 = 150
.line	1751	loadk        r41   k93 ; k93 = 53
.line	1751	loadk        r42   k94 ; k94 = 60
.line	1751	loadk        r43   k95 ; k95 = 12
.line	1751	loadk        r44    k6 ; k6 = 218
.line	1751	loadk        r45   k34 ; k34 = 236
.line	1751	loadk        r46   k61 ; k61 = 132
.line	1751	loadk        r47   k91 ; k91 = 124
.line	1751	loadk        r48   k58 ; k58 = 7
.line	1751	loadk        r49   k48 ; k48 = 184
.line	1751	call          r9    41     2
.line	1751	getupval     r10    u1
.line	1751	loadk        r11   k12 ; k12 = 220
.line	1751	loadk        r12   k96 ; k96 = 59
.line	1751	loadk        r13   k97 ; k97 = 182
.line	1751	loadk        r14   k98 ; k98 = 203
.line	1751	loadk        r15   k28 ; k28 = 96
.line	1751	loadk        r16   k99 ; k99 = 89
.line	1751	loadk        r17   k18 ; k18 = 104
.line	1751	loadk        r18  k100 ; k100 = 134
.line	1751	call         r10     9     0
.line	1751	setlist       r8     0     1
.line	1751	call          r7     2     2
.line	1751	call          r6     2     2
.line	1751	gettable      r7    r6  k101 ; k101 = "MVPActionType"
.line	1751	call          r7     1     2
.line	1751	eq             1    r7   k33 ; k33 = 5
.line	1751	jmp            0  l205
.line	1751	gettabup      r8    u0  k102 ; k102 = "ShowNotice"
.line	1751	loadk         r9  k103 ; k103 = 18010296
.line	1751	call          r8     2     1
.label	l205
.line	1751	gettabup      r8    u0  k104 ; k104 = "ModuleManager"
.line	1751	gettable      r8    r8  k105 ; k105 = "GetModule"
.line	1751	gettabup      r9    u0  k104 ; k104 = "ModuleManager"
.line	1751	gettable      r9    r9  k106 ; k106 = "LobbyModuleConfig"
.line	1751	gettable      r9    r9  k107 ; k107 = "LogicParticleEmote"
.line	1751	call          r8     2     2
.line	1751	self          r9    r8  k108 ; k108 = "GetParticleEmoteID"
.line	1751	move         r11    r4
.line	1751	call          r9     3     2
.line	1751	gettabup     r10    u0    k0 ; k0 = "require"
.line	1751	gettabup     r11    u0    k1 ; k1 = "table"
.line	1751	gettable     r11   r11    k2 ; k2 = "concat"
.line	1751	newtable     r12     1     0
.line	1751	getupval     r13    u1
.line	1751	loadk        r14    k3 ; k3 = 224
.line	1751	loadk        r15    k4 ; k4 = 36
.line	1751	loadk        r16    k5 ; k5 = 186
.line	1751	loadk        r17    k6 ; k6 = 218
.line	1751	loadk        r18    k7 ; k7 = 122
.line	1751	loadk        r19    k8 ; k8 = 68
.line	1751	loadk        r20    k9 ; k9 = 40
.line	1751	loadk        r21   k10 ; k10 = 146
.line	1751	loadk        r22   k11 ; k11 = 235
.line	1751	loadk        r23   k12 ; k12 = 220
.line	1751	loadk        r24   k13 ; k13 = 250
.line	1751	loadk        r25   k14 ; k14 = 46
.line	1751	loadk        r26   k83 ; k83 = 82
.line	1751	loadk        r27   k84 ; k84 = 242
.line	1751	loadk        r28   k17 ; k17 = 136
.line	1751	loadk        r29   k39 ; k39 = 47
.line	1751	loadk        r30   k85 ; k85 = 16
.line	1751	loadk        r31   k77 ; k77 = 86
.line	1751	loadk        r32   k86 ; k86 = 212
.line	1751	loadk        r33   k38 ; k38 = 238
.line	1751	loadk        r34   k21 ; k21 = 150
.line	1751	loadk        r35   k87 ; k87 = 100
.line	1751	loadk        r36   k88 ; k88 = 4
.line	1751	loadk        r37   k89 ; k89 = 190
.line	1751	loadk        r38   k90 ; k90 = 245
.line	1751	loadk        r39   k12 ; k12 = 220
.line	1751	loadk        r40   k51 ; k51 = 165
.line	1751	loadk        r41   k91 ; k91 = 124
.line	1751	loadk        r42   k92 ; k92 = 65
.line	1751	loadk        r43   k65 ; k65 = 234
.line	1751	loadk        r44   k21 ; k21 = 150
.line	1751	loadk        r45   k93 ; k93 = 53
.line	1751	loadk        r46   k94 ; k94 = 60
.line	1751	loadk        r47  k109 ; k109 = 31
.line	1751	loadk        r48  k110 ; k110 = 210
.line	1751	loadk        r49  k111 ; k111 = 237
.line	1751	loadk        r50  k112 ; k112 = 144
.line	1751	loadk        r51   k62 ; k62 = 98
.line	1751	loadk        r52  k113 ; k113 = 9
.line	1751	loadk        r53   k30 ; k30 = 163
.line	1751	call         r13    41     2
.line	1751	getupval     r14    u1
.line	1751	loadk        r15  k114 ; k114 = 230
.line	1751	loadk        r16  k115 ; k115 = 23
.line	1751	loadk        r17   k73 ; k73 = 189
.line	1751	loadk        r18    k6 ; k6 = 218
.line	1751	loadk        r19  k116 ; k116 = 99
.line	1751	call         r14     6     0
.line	1751	setlist      r12     0     1
.line	1751	call         r11     2     2
.line	1751	call         r10     2     2
.line	1751	self         r11   r10  k117 ; k117 = "PlayMotion"
.line	1751	move         r13    r9
.line	1751	loadbool     r14     1     0
.line	1751	call         r11     4     1
.line	1751	self         r11    r5   k68 ; k68 = "Show"
.line	1751	gettable     r13    r5  k118 ; k118 = "ENUM_ITEM_TIPS_TYPE"
.line	1751	gettable     r13   r13  k119 ; k119 = "ENUM_ITEM_TIPS_TYPE_" (truncated)
.line	1751	move         r14    r3
.line	1751	move         r15    r4
.line	1751	call         r11     5     1
.label	l280
.line	1751	return        r0     1
.line	1751	move          r0    r0
.line	1751	return        r0     1

.function	main/f95

.source	null
.linedefined	1771
.lastlinedefined	1876
.numparams	5
.is_vararg	0
.maxstacksize	73

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	nil
.constant	k1	"require"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	224
.constant	k5	36
.constant	k6	186
.constant	k7	218
.constant	k8	122
.constant	k9	68
.constant	k10	40
.constant	k11	146
.constant	k12	235
.constant	k13	220
.constant	k14	250
.constant	k15	46
.constant	k16	93
.constant	k17	242
.constant	k18	129
.constant	k19	32
.constant	k20	26
.constant	k21	31
.constant	k22	141
.constant	k23	204
.constant	k24	136
.constant	k25	105
.constant	k26	19
.constant	k27	191
.constant	k28	227
.constant	k29	244
.constant	k30	234
.constant	k31	115
.constant	k32	92
.constant	k33	226
.constant	k34	140
.constant	k35	120
.constant	k36	51
.constant	k37	29
.constant	k38	209
.constant	k39	243
.constant	k40	157
.constant	k41	99
.constant	k42	14
.constant	k43	147
.constant	k44	230
.constant	k45	47
.constant	k46	208
.constant	k47	125
.constant	k48	103
.constant	k49	130
.constant	k50	245
.constant	k51	198
.constant	k52	232
.constant	k53	"IsFITVersion"
.constant	k54	"EWardrobeDataSource"
.constant	k55	"Wardrobe"
.constant	k56	"ModuleManager"
.constant	k57	"GetModule"
.constant	k58	"LobbyModuleConfig"
.constant	k59	"VehicleCollectSystem"
.constant	k60	217
.constant	k61	82
.constant	k62	16
.constant	k63	39
.constant	k64	207
.constant	k65	134
.constant	k66	98
.constant	k67	15
.constant	k68	142
.constant	k69	240
.constant	k70	216
.constant	k71	249
.constant	k72	113
.constant	k73	73
.constant	k74	160
.constant	k75	37
.constant	k76	0
.constant	k77	13
.constant	k78	221
.constant	k79	"SetTAA"
.constant	k80	"GetVehicleLicense"
.constant	k81	"IsOpenHighTire"
.constant	k82	"DataMgr"
.constant	k83	"roleData"
.constant	k84	"uid"
.constant	k85	"LogicVehicleAccessory"
.constant	k86	"GetEquipedAccessoryList"
.constant	k87	"LogicVehicleExtendedFeature"
.constant	k88	"GetEquipedChassisLightData"
.constant	k89	"GetCurEquippedPlateBg"
.constant	k90	"GetEquipedMultiSlotParts"
.constant	k91	"ExtraTable"
.constant	k92	"License"
.constant	k93	"EnableHighTire"
.constant	k94	"AccessoryList"
.constant	k95	"ChassisLight"
.constant	k96	"LicenseBgId"
.constant	k97	"MultiSlotParts"
.constant	k98	"Source"
.constant	k99	"slua"
.constant	k100	"getMicroseconds"
.constant	k101	206
.constant	k102	252
.constant	k103	153
.constant	k104	7
.constant	k105	25
.constant	k106	161
.constant	k107	169
.constant	k108	111
.constant	k109	18
.constant	k110	180
.constant	k111	251
.constant	k112	253
.constant	k113	94
.constant	k114	225
.constant	k115	158
.constant	k116	6
.constant	k117	"Init"
.constant	k118	"SetNeedAutoRotate"
.constant	k119	86
.constant	k120	199
.constant	k121	110
.constant	k122	190
.constant	k123	246
.constant	k124	165
.constant	k125	96
.constant	k126	91
.constant	k127	17
.constant	k128	70
.constant	k129	195
.constant	k130	118
.constant	k131	3
.constant	k132	179
.constant	k133	178
.constant	k134	117
.constant	k135	87
.constant	k136	55
.constant	k137	154
.constant	k138	"pairs"
.constant	k139	"insert"
.constant	k140	"GetListIsDownloaded"
.constant	k141	"ENUM_DownloadType"
.constant	k142	"ODPAK"
.constant	k143	"CDataTable"
.constant	k144	"GetTableData"
.constant	k145	213
.constant	k146	45
.constant	k147	187
.constant	k148	214
.constant	k149	119
.constant	k150	177
.constant	k151	200
.constant	k152	101
.constant	k153	109
.constant	k154	62
.constant	k155	211
.constant	k156	255
.constant	k157	"OrginalID"
.constant	k158	"printf"
.constant	k159	212
.constant	k160	41
.constant	k161	219
.constant	k162	102
.constant	k163	95
.constant	k164	100
.constant	k165	132
.constant	k166	203
.constant	k167	167
.constant	k168	188
.constant	k169	28
.constant	k170	21
.constant	k171	189
.constant	k172	228
.constant	k173	116
.constant	k174	75
.constant	k175	223
.constant	k176	8
.constant	k177	1
.constant	k178	149
.constant	k179	126
.constant	k180	2
.constant	k181	236
.constant	k182	58
.constant	k183	88
.constant	k184	238
.constant	k185	173
.constant	k186	151
.constant	k187	63
.constant	k188	155
.constant	k189	175
.constant	k190	104
.constant	k191	121
.constant	k192	162
.constant	k193	183
.constant	k194	81
.constant	k195	239
.constant	k196	33
.constant	k197	22
.constant	k198	194
.constant	k199	76
.constant	k200	"tostring"
.constant	k201	"GetShowingData"
.constant	k202	"showModelId"
.constant	k203	138
.constant	k204	97
.constant	k205	229
.constant	k206	79
.constant	k207	144
.constant	k208	56
.constant	k209	215
.constant	k210	152
.constant	k211	9
.constant	k212	166
.constant	k213	43
.constant	k214	"HideWeapon"
.constant	k215	"EventSystem"
.constant	k216	"postEvent"
.constant	k217	"EVENTTYPE_WARDROBE"
.constant	k218	"EVENTID_WARDROBE_CreateDownloader"
.constant	k219	"table"
.constant	k220	"concat"
.constant	k221	235
.constant	k222	250
.constant	k223	46
.constant	k224	242
.constant	k225	16
.constant	k226	207
.constant	k227	98
.constant	k228	15
.constant	k229	142
.constant	k230	246
.constant	k231	228
.constant	k232	139
.constant	k233	77
.constant	k234	210
.constant	k235	117
.constant	k236	20
.constant	k237	111
.constant	k238	196
.constant	k239	198
.constant	k240	245
.constant	k241	102
.constant	k242	"IsRareCar"
.constant	k243	"bForceInRareScene"
.constant	k244	true
.constant	k245	"printf"
.constant	k246	212
.constant	k247	41
.constant	k248	161
.constant	k249	219
.constant	k250	95
.constant	k251	100
.constant	k252	132
.constant	k253	203
.constant	k254	252
.constant	k255	105
.constant	k256	93
.constant	k257	167
.constant	k258	188
.constant	k259	28
.constant	k260	234
.constant	k261	140
.constant	k262	21
.constant	k263	189
.constant	k264	244
.constant	k265	116
.constant	k266	75
.constant	k267	225
.constant	k268	223
.constant	k269	48
.constant	k270	12
.constant	k271	26
.constant	k272	127
.constant	k273	168
.constant	k274	33
.constant	k275	222
.constant	k276	107
.constant	k277	247
.constant	k278	32
.constant	k279	83
.constant	k280	10
.constant	k281	253
.constant	k282	5
.constant	k283	215
.constant	k284	238
.constant	k285	60
.constant	k286	154
.constant	k287	42
.constant	k288	137
.constant	k289	135
.constant	k290	70
.constant	k291	174
.constant	k292	241
.constant	k293	106
.constant	k294	"tostring"
.constant	k295	"Display"
.constant	k296	"table"
.constant	k297	"concat"
.constant	k298	36
.constant	k299	122
.constant	k300	46
.constant	k301	242
.constant	k302	238
.constant	k303	180
.constant	k304	151
.constant	k305	253
.constant	k306	92
.constant	k307	234
.constant	k308	"GetProperWeaponShowActor"
.constant	k309	"isValid"
.constant	k310	"GetVehicleActor"
.constant	k311	"BP_VehicleDIYComp"
.constant	k312	"UpdateCarOwnerInLobby"
.constant	k313	"log"
.constant	k314	"bWriteLog"
.constant	k315	212
.constant	k316	41
.constant	k317	161
.constant	k318	219
.constant	k319	102
.constant	k320	95
.constant	k321	100
.constant	k322	132
.constant	k323	203
.constant	k324	198
.constant	k325	252
.constant	k326	105
.constant	k327	93
.constant	k328	167
.constant	k329	188
.constant	k330	28
.constant	k331	15
.constant	k332	245
.constant	k333	140
.constant	k334	21
.constant	k335	189
.constant	k336	244
.constant	k337	228
.constant	k338	116
.constant	k339	75
.constant	k340	225
.constant	k341	197
.constant	k342	"tostring"
.constant	k343	1000

.line	1771	eq             0    r3    k0 ; k0 = nil
.line	1771	jmp            0   l70
.line	1771	gettabup      r5    u0    k1 ; k1 = "require"
.line	1771	gettabup      r6    u0    k2 ; k2 = "table"
.line	1771	gettable      r6    r6    k3 ; k3 = "concat"
.line	1771	newtable      r7     1     0
.line	1771	getupval      r8    u1
.line	1771	loadk         r9    k4 ; k4 = 224
.line	1771	loadk        r10    k5 ; k5 = 36
.line	1771	loadk        r11    k6 ; k6 = 186
.line	1771	loadk        r12    k7 ; k7 = 218
.line	1771	loadk        r13    k8 ; k8 = 122
.line	1771	loadk        r14    k9 ; k9 = 68
.line	1771	loadk        r15   k10 ; k10 = 40
.line	1771	loadk        r16   k11 ; k11 = 146
.line	1771	loadk        r17   k12 ; k12 = 235
.line	1771	loadk        r18   k13 ; k13 = 220
.line	1771	loadk        r19   k14 ; k14 = 250
.line	1771	loadk        r20   k15 ; k15 = 46
.line	1771	loadk        r21   k16 ; k16 = 93
.line	1771	loadk        r22   k17 ; k17 = 242
.line	1771	loadk        r23   k18 ; k18 = 129
.line	1771	loadk        r24   k19 ; k19 = 32
.line	1771	loadk        r25   k20 ; k20 = 26
.line	1771	loadk        r26   k21 ; k21 = 31
.line	1771	loadk        r27   k22 ; k22 = 141
.line	1771	loadk        r28   k23 ; k23 = 204
.line	1771	loadk        r29   k24 ; k24 = 136
.line	1771	loadk        r30   k25 ; k25 = 105
.line	1771	loadk        r31   k26 ; k26 = 19
.line	1771	loadk        r32   k27 ; k27 = 191
.line	1771	loadk        r33   k28 ; k28 = 227
.line	1771	loadk        r34   k29 ; k29 = 244
.line	1771	loadk        r35   k30 ; k30 = 234
.line	1771	loadk        r36   k31 ; k31 = 115
.line	1771	loadk        r37   k32 ; k32 = 92
.line	1771	loadk        r38   k33 ; k33 = 226
.line	1771	loadk        r39   k34 ; k34 = 140
.line	1771	loadk        r40   k35 ; k35 = 120
.line	1771	loadk        r41   k36 ; k36 = 51
.line	1771	loadk        r42   k37 ; k37 = 29
.line	1771	loadk        r43   k38 ; k38 = 209
.line	1771	loadk        r44   k39 ; k39 = 243
.line	1771	loadk        r45   k40 ; k40 = 157
.line	1771	loadk        r46   k41 ; k41 = 99
.line	1771	loadk        r47   k42 ; k42 = 14
.line	1771	loadk        r48   k43 ; k43 = 147
.line	1771	call          r8    41     2
.line	1771	getupval      r9    u1
.line	1771	loadk        r10   k44 ; k44 = 230
.line	1771	loadk        r11   k45 ; k45 = 47
.line	1771	loadk        r12    k6 ; k6 = 186
.line	1771	loadk        r13   k46 ; k46 = 208
.line	1771	loadk        r14    k8 ; k8 = 122
.line	1771	loadk        r15   k47 ; k47 = 125
.line	1771	loadk        r16   k48 ; k48 = 103
.line	1771	loadk        r17   k49 ; k49 = 130
.line	1771	loadk        r18   k50 ; k50 = 245
.line	1771	loadk        r19   k51 ; k51 = 198
.line	1771	loadk        r20   k52 ; k52 = 232
.line	1771	call          r9    12     0
.line	1771	setlist       r7     0     1
.line	1771	call          r6     2     2
.line	1771	call          r5     2     2
.line	1771	gettable      r6    r5   k53 ; k53 = "IsFITVersion"
.line	1771	call          r6     1     2
.line	1771	test          r6     0
.line	1771	jmp            0   l70
.line	1771	loadbool      r3     1     0
.label	l70
.line	1771	test          r2     1
.line	1771	jmp            0   l74
.line	1771	gettabup      r5    u0   k54 ; k54 = "EWardrobeDataSource"
.line	1771	gettable      r2    r5   k55 ; k55 = "Wardrobe"
.label	l74
.line	1771	newtable      r5     0     0
.line	1771	gettabup      r6    u0   k56 ; k56 = "ModuleManager"
.line	1771	gettable      r6    r6   k57 ; k57 = "GetModule"
.line	1771	gettabup      r7    u0   k56 ; k56 = "ModuleManager"
.line	1771	gettable      r7    r7   k58 ; k58 = "LobbyModuleConfig"
.line	1771	gettable      r7    r7   k59 ; k59 = "VehicleCollectSystem"
.line	1771	call          r6     2     2
.line	1771	gettabup      r7    u0    k1 ; k1 = "require"
.line	1771	getupval      r8    u1
.line	1771	loadk         r9    k4 ; k4 = 224
.line	1771	loadk        r10    k5 ; k5 = 36
.line	1771	loadk        r11    k6 ; k6 = 186
.line	1771	loadk        r12    k7 ; k7 = 218
.line	1771	loadk        r13    k8 ; k8 = 122
.line	1771	loadk        r14    k9 ; k9 = 68
.line	1771	loadk        r15   k10 ; k10 = 40
.line	1771	loadk        r16   k34 ; k34 = 140
.line	1771	loadk        r17   k44 ; k44 = 230
.line	1771	loadk        r18   k60 ; k60 = 217
.line	1771	loadk        r19   k52 ; k52 = 232
.line	1771	loadk        r20   k15 ; k15 = 46
.line	1771	loadk        r21   k61 ; k61 = 82
.line	1771	loadk        r22   k17 ; k17 = 242
.line	1771	loadk        r23   k24 ; k24 = 136
.line	1771	loadk        r24   k45 ; k45 = 47
.line	1771	loadk        r25   k62 ; k62 = 16
.line	1771	loadk        r26   k63 ; k63 = 39
.line	1771	loadk        r27   k64 ; k64 = 207
.line	1771	loadk        r28    k4 ; k4 = 224
.line	1771	loadk        r29   k65 ; k65 = 134
.line	1771	loadk        r30   k66 ; k66 = 98
.line	1771	loadk        r31   k67 ; k67 = 15
.line	1771	loadk        r32   k68 ; k68 = 142
.line	1771	loadk        r33   k69 ; k69 = 240
.line	1771	loadk        r34   k70 ; k70 = 216
.line	1771	loadk        r35   k71 ; k71 = 249
.line	1771	loadk        r36   k72 ; k72 = 113
.line	1771	loadk        r37   k73 ; k73 = 73
.line	1771	loadk        r38   k52 ; k52 = 232
.line	1771	loadk        r39   k74 ; k74 = 160
.line	1771	loadk        r40   k75 ; k75 = 37
.line	1771	loadk        r41   k76 ; k76 = 0
.line	1771	loadk        r42   k77 ; k77 = 13
.line	1771	loadk        r43   k78 ; k78 = 221
.line	1771	loadk        r44   k14 ; k14 = 250
.line	1771	call          r8    37     2
.line	1771	call          r7     2     2
.line	1771	gettable      r8    r7   k79 ; k79 = "SetTAA"
.line	1771	loadbool      r9     0     0
.line	1771	call          r8     2     1
.line	1771	self          r8    r6   k80 ; k80 = "GetVehicleLicense"
.line	1771	move         r10    r1
.line	1771	move         r11    r2
.line	1771	call          r8     4     2
.line	1771	self          r9    r6   k81 ; k81 = "IsOpenHighTire"
.line	1771	move         r11    r1
.line	1771	gettabup     r12    u0   k82 ; k82 = "DataMgr"
.line	1771	gettable     r12   r12   k83 ; k83 = "roleData"
.line	1771	gettable     r12   r12   k84 ; k84 = "uid"
.line	1771	loadnil      r13     0
.line	1771	move         r14    r2
.line	1771	call          r9     6     2
.line	1771	gettabup     r10    u0   k56 ; k56 = "ModuleManager"
.line	1771	gettable     r10   r10   k57 ; k57 = "GetModule"
.line	1771	gettabup     r11    u0   k56 ; k56 = "ModuleManager"
.line	1771	gettable     r11   r11   k58 ; k58 = "LobbyModuleConfig"
.line	1771	gettable     r11   r11   k85 ; k85 = "LogicVehicleAccessor" (truncated)
.line	1771	call         r10     2     2
.line	1771	self         r11   r10   k86 ; k86 = "GetEquipedAccessoryL" (truncated)
.line	1771	move         r13    r1
.line	1771	move         r14    r2
.line	1771	call         r11     4     2
.line	1771	gettabup     r12    u0   k56 ; k56 = "ModuleManager"
.line	1771	gettable     r12   r12   k57 ; k57 = "GetModule"
.line	1771	gettabup     r13    u0   k56 ; k56 = "ModuleManager"
.line	1771	gettable     r13   r13   k58 ; k58 = "LobbyModuleConfig"
.line	1771	gettable     r13   r13   k87 ; k87 = "LogicVehicleExtended" (truncated)
.line	1771	call         r12     2     2
.line	1771	self         r13   r12   k88 ; k88 = "GetEquipedChassisLig" (truncated)
.line	1771	move         r15    r1
.line	1771	move         r16    r2
.line	1771	call         r13     4     2
.line	1771	self         r14   r12   k89 ; k89 = "GetCurEquippedPlateB" (truncated)
.line	1771	move         r16    r1
.line	1771	move         r17    r2
.line	1771	call         r14     4     2
.line	1771	self         r15   r12   k90 ; k90 = "GetEquipedMultiSlotP" (truncated)
.line	1771	move         r17    r1
.line	1771	move         r18    r2
.line	1771	call         r15     4     2
.line	1771	newtable     r16     0     7
.line	1771	settable     r16   k92    r8 ; k92 = "License"
.line	1771	settable     r16   k93    r9 ; k93 = "EnableHighTire"
.line	1771	settable     r16   k94   r11 ; k94 = "AccessoryList"
.line	1771	settable     r16   k95   r13 ; k95 = "ChassisLight"
.line	1771	settable     r16   k96   r14 ; k96 = "LicenseBgId"
.line	1771	settable     r16   k97   r15 ; k97 = "MultiSlotParts"
.line	1771	settable     r16   k98    r2 ; k98 = "Source"
.line	1771	settable      r5   k91   r16 ; k91 = "ExtraTable"
.line	1771	gettabup     r16    u0   k99 ; k99 = "slua"
.line	1771	gettable     r16   r16  k100 ; k100 = "getMicroseconds"
.line	1771	move         r17   r16
.line	1771	call         r17     1     2
.line	1771	gettabup     r18    u0    k1 ; k1 = "require"
.line	1771	getupval     r19    u1
.line	1771	loadk        r20    k4 ; k4 = 224
.line	1771	loadk        r21    k5 ; k5 = 36
.line	1771	loadk        r22    k6 ; k6 = 186
.line	1771	loadk        r23    k7 ; k7 = 218
.line	1771	loadk        r24    k8 ; k8 = 122
.line	1771	loadk        r25    k9 ; k9 = 68
.line	1771	loadk        r26   k10 ; k10 = 40
.line	1771	loadk        r27   k22 ; k22 = 141
.line	1771	loadk        r28   k52 ; k52 = 232
.line	1771	loadk        r29  k101 ; k101 = 206
.line	1771	loadk        r30   k17 ; k17 = 242
.line	1771	loadk        r31   k41 ; k41 = 99
.line	1771	loadk        r32   k62 ; k62 = 16
.line	1771	loadk        r33  k102 ; k102 = 252
.line	1771	loadk        r34  k103 ; k103 = 153
.line	1771	loadk        r35   k63 ; k63 = 39
.line	1771	loadk        r36  k104 ; k104 = 7
.line	1771	loadk        r37  k105 ; k105 = 25
.line	1771	loadk        r38   k38 ; k38 = 209
.line	1771	loadk        r39  k106 ; k106 = 161
.line	1771	loadk        r40  k107 ; k107 = 169
.line	1771	loadk        r41  k108 ; k108 = 111
.line	1771	loadk        r42  k109 ; k109 = 18
.line	1771	loadk        r43  k110 ; k110 = 180
.line	1771	loadk        r44  k111 ; k111 = 251
.line	1771	loadk        r45  k112 ; k112 = 253
.line	1771	loadk        r46   k33 ; k33 = 226
.line	1771	loadk        r47   k41 ; k41 = 99
.line	1771	loadk        r48  k113 ; k113 = 94
.line	1771	loadk        r49  k114 ; k114 = 225
.line	1771	loadk        r50  k115 ; k115 = 158
.line	1771	loadk        r51   k45 ; k45 = 47
.line	1771	loadk        r52  k116 ; k116 = 6
.line	1771	loadk        r53   k20 ; k20 = 26
.line	1771	call         r19    35     2
.line	1771	call         r18     2     2
.line	1771	gettable     r19   r18  k117 ; k117 = "Init"
.line	1771	loadnil      r20     2
.line	1771	loadbool     r23     1     0
.line	1771	call         r19     5     1
.line	1771	gettable     r19   r18  k118 ; k118 = "SetNeedAutoRotate"
.line	1771	loadbool     r20     0     0
.line	1771	call         r19     2     1
.line	1771	test          r3     0
.line	1771	jmp            0  l878
.line	1771	gettabup     r19    u0    k1 ; k1 = "require"
.line	1771	gettabup     r20    u0    k2 ; k2 = "table"
.line	1771	gettable     r20   r20    k3 ; k3 = "concat"
.line	1771	newtable     r21     1     0
.line	1771	getupval     r22    u1
.line	1771	loadk        r23    k4 ; k4 = 224
.line	1771	loadk        r24    k5 ; k5 = 36
.line	1771	loadk        r25    k6 ; k6 = 186
.line	1771	loadk        r26    k7 ; k7 = 218
.line	1771	loadk        r27    k8 ; k8 = 122
.line	1771	loadk        r28    k9 ; k9 = 68
.line	1771	loadk        r29   k10 ; k10 = 40
.line	1771	loadk        r30   k11 ; k11 = 146
.line	1771	loadk        r31   k12 ; k12 = 235
.line	1771	loadk        r32   k13 ; k13 = 220
.line	1771	loadk        r33   k14 ; k14 = 250
.line	1771	loadk        r34   k15 ; k15 = 46
.line	1771	loadk        r35   k61 ; k61 = 82
.line	1771	loadk        r36   k17 ; k17 = 242
.line	1771	loadk        r37   k24 ; k24 = 136
.line	1771	loadk        r38   k45 ; k45 = 47
.line	1771	loadk        r39   k62 ; k62 = 16
.line	1771	loadk        r40  k119 ; k119 = 86
.line	1771	loadk        r41  k120 ; k120 = 199
.line	1771	loadk        r42    k4 ; k4 = 224
.line	1771	loadk        r43   k43 ; k43 = 147
.line	1771	loadk        r44  k121 ; k121 = 110
.line	1771	loadk        r45   k20 ; k20 = 26
.line	1771	loadk        r46  k122 ; k122 = 190
.line	1771	loadk        r47  k123 ; k123 = 246
.line	1771	loadk        r48   k78 ; k78 = 221
.line	1771	loadk        r49  k124 ; k124 = 165
.line	1771	loadk        r50  k125 ; k125 = 96
.line	1771	loadk        r51  k126 ; k126 = 91
.line	1771	loadk        r52   k12 ; k12 = 235
.line	1771	loadk        r53  k103 ; k103 = 153
.line	1771	loadk        r54   k36 ; k36 = 51
.line	1771	loadk        r55  k127 ; k127 = 17
.line	1771	loadk        r56  k128 ; k128 = 70
.line	1771	loadk        r57  k129 ; k129 = 195
.line	1771	loadk        r58   k30 ; k30 = 234
.line	1771	loadk        r59   k11 ; k11 = 146
.line	1771	loadk        r60  k130 ; k130 = 118
.line	1771	loadk        r61  k131 ; k131 = 3
.line	1771	loadk        r62  k132 ; k132 = 179
.line	1771	call         r22    41     2
.line	1771	getupval     r23    u1
.line	1771	loadk        r24   k13 ; k13 = 220
.line	1771	loadk        r25   k75 ; k75 = 37
.line	1771	loadk        r26  k133 ; k133 = 178
.line	1771	loadk        r27   k38 ; k38 = 209
.line	1771	loadk        r28  k134 ; k134 = 117
.line	1771	loadk        r29  k135 ; k135 = 87
.line	1771	loadk        r30   k41 ; k41 = 99
.line	1771	loadk        r31   k43 ; k43 = 147
.line	1771	call         r23     9     0
.line	1771	setlist      r21     0     1
.line	1771	call         r20     2     2
.line	1771	call         r19     2     2
.line	1771	gettabup     r20    u0    k1 ; k1 = "require"
.line	1771	getupval     r21    u1
.line	1771	loadk        r22    k4 ; k4 = 224
.line	1771	loadk        r23    k5 ; k5 = 36
.line	1771	loadk        r24    k6 ; k6 = 186
.line	1771	loadk        r25    k7 ; k7 = 218
.line	1771	loadk        r26    k8 ; k8 = 122
.line	1771	loadk        r27    k9 ; k9 = 68
.line	1771	loadk        r28   k10 ; k10 = 40
.line	1771	loadk        r29   k11 ; k11 = 146
.line	1771	loadk        r30   k12 ; k12 = 235
.line	1771	loadk        r31   k13 ; k13 = 220
.line	1771	loadk        r32   k14 ; k14 = 250
.line	1771	loadk        r33   k15 ; k15 = 46
.line	1771	loadk        r34   k61 ; k61 = 82
.line	1771	loadk        r35   k17 ; k17 = 242
.line	1771	loadk        r36   k24 ; k24 = 136
.line	1771	loadk        r37   k45 ; k45 = 47
.line	1771	loadk        r38   k62 ; k62 = 16
.line	1771	loadk        r39  k119 ; k119 = 86
.line	1771	loadk        r40  k120 ; k120 = 199
.line	1771	loadk        r41    k4 ; k4 = 224
.line	1771	loadk        r42   k43 ; k43 = 147
.line	1771	loadk        r43  k121 ; k121 = 110
.line	1771	loadk        r44   k20 ; k20 = 26
.line	1771	loadk        r45  k122 ; k122 = 190
.line	1771	loadk        r46  k123 ; k123 = 246
.line	1771	loadk        r47   k78 ; k78 = 221
.line	1771	loadk        r48  k124 ; k124 = 165
.line	1771	loadk        r49  k125 ; k125 = 96
.line	1771	loadk        r50  k126 ; k126 = 91
.line	1771	loadk        r51   k12 ; k12 = 235
.line	1771	loadk        r52  k103 ; k103 = 153
.line	1771	loadk        r53   k36 ; k36 = 51
.line	1771	loadk        r54  k127 ; k127 = 17
.line	1771	loadk        r55  k136 ; k136 = 55
.line	1771	loadk        r56   k46 ; k46 = 208
.line	1771	loadk        r57   k69 ; k69 = 240
.line	1771	loadk        r58  k137 ; k137 = 154
.line	1771	loadk        r59   k41 ; k41 = 99
.line	1771	loadk        r60  k109 ; k109 = 18
.line	1771	call         r21    40     2
.line	1771	call         r20     2     2
.line	1771	newtable     r21     1     0
.line	1771	move         r22    r1
.line	1771	setlist      r21     1     1
.line	1771	gettable     r22    r5   k91 ; k91 = "ExtraTable"
.line	1771	test         r22     0
.line	1771	jmp            0  l334
.line	1771	gettable     r22    r5   k91 ; k91 = "ExtraTable"
.line	1771	gettable     r22   r22   k97 ; k97 = "MultiSlotParts"
.label	l334
.line	1771	test         r22     0
.line	1771	jmp            0  l351
.line	1771	gettabup     r23    u0  k138 ; k138 = "pairs"
.line	1771	move         r24   r22
.line	1771	call         r23     2     4
.line	1771	jmp            0  l349
.line	1771	test         r27     0
.line	1771	jmp            0  l349
.line	1771	lt             0   k76   r27 ; k76 = 0
.line	1771	jmp            0  l349
.line	1771	gettabup     r28    u0    k2 ; k2 = "table"
.line	1771	gettable     r28   r28  k139 ; k139 = "insert"
.line	1771	move         r29   r21
.line	1771	move         r30   r27
.line	1771	call         r28     3     1
.label	l349
.line	1771	move          r0    r0
.line	1771	move          r0    r0
.label	l351
.line	1771	gettable     r23   r19  k140 ; k140 = "GetListIsDownloaded"
.line	1771	gettable     r24   r20  k141 ; k141 = "ENUM_DownloadType"
.line	1771	gettable     r24   r24  k142 ; k142 = "ODPAK"
.line	1771	move         r25   r21
.line	1771	call         r23     3     2
.line	1771	test         r23     1
.line	1771	jmp            0  l871
.line	1771	gettabup     r23    u0  k143 ; k143 = "CDataTable"
.line	1771	gettable     r23   r23  k144 ; k144 = "GetTableData"
.line	1771	getupval     r24    u1
.line	1771	loadk        r25  k145 ; k145 = 213
.line	1771	loadk        r26  k146 ; k146 = 45
.line	1771	loadk        r27  k147 ; k147 = 187
.line	1771	loadk        r28  k148 ; k148 = 214
.line	1771	loadk        r29  k149 ; k149 = 119
.line	1771	loadk        r30   k32 ; k32 = 92
.line	1771	loadk        r31   k41 ; k41 = 99
.line	1771	loadk        r32  k150 ; k150 = 177
.line	1771	loadk        r33   k12 ; k12 = 235
.line	1771	loadk        r34  k151 ; k151 = 200
.line	1771	loadk        r35   k50 ; k50 = 245
.line	1771	loadk        r36  k152 ; k152 = 101
.line	1771	loadk        r37  k153 ; k153 = 109
.line	1771	loadk        r38  k123 ; k123 = 246
.line	1771	loadk        r39   k65 ; k65 = 134
.line	1771	loadk        r40   k10 ; k10 = 40
.line	1771	loadk        r41  k154 ; k154 = 62
.line	1771	loadk        r42  k105 ; k105 = 25
.line	1771	loadk        r43  k155 ; k155 = 211
.line	1771	loadk        r44  k156 ; k156 = 255
.line	1771	loadk        r45   k22 ; k22 = 141
.line	1771	loadk        r46  k121 ; k121 = 110
.line	1771	loadk        r47  k127 ; k127 = 17
.line	1771	call         r24    24     2
.line	1771	move         r25    r1
.line	1771	call         r23     3     2
.line	1771	gettabup     r24    u0    k1 ; k1 = "require"
.line	1771	gettabup     r25    u0    k2 ; k2 = "table"
.line	1771	gettable     r25   r25    k3 ; k3 = "concat"
.line	1771	newtable     r26     1     0
.line	1771	getupval     r27    u1
.line	1771	loadk        r28    k4 ; k4 = 224
.line	1771	loadk        r29    k5 ; k5 = 36
.line	1771	loadk        r30    k6 ; k6 = 186
.line	1771	loadk        r31    k7 ; k7 = 218
.line	1771	loadk        r32    k8 ; k8 = 122
.line	1771	loadk        r33    k9 ; k9 = 68
.line	1771	loadk        r34   k10 ; k10 = 40
.line	1771	loadk        r35   k11 ; k11 = 146
.line	1771	loadk        r36   k12 ; k12 = 235
.line	1771	loadk        r37   k13 ; k13 = 220
.line	1771	loadk        r38   k14 ; k14 = 250
.line	1771	loadk        r39   k15 ; k15 = 46
.line	1771	loadk        r40   k16 ; k16 = 93
.line	1771	loadk        r41   k17 ; k17 = 242
.line	1771	loadk        r42   k18 ; k18 = 129
.line	1771	loadk        r43   k19 ; k19 = 32
.line	1771	loadk        r44   k20 ; k20 = 26
.line	1771	loadk        r45   k21 ; k21 = 31
.line	1771	loadk        r46   k22 ; k22 = 141
.line	1771	loadk        r47   k23 ; k23 = 204
.line	1771	loadk        r48   k24 ; k24 = 136
.line	1771	loadk        r49   k25 ; k25 = 105
.line	1771	loadk        r50   k26 ; k26 = 19
.line	1771	loadk        r51   k27 ; k27 = 191
.line	1771	loadk        r52   k28 ; k28 = 227
.line	1771	loadk        r53   k29 ; k29 = 244
.line	1771	loadk        r54   k30 ; k30 = 234
.line	1771	loadk        r55   k31 ; k31 = 115
.line	1771	loadk        r56   k32 ; k32 = 92
.line	1771	loadk        r57   k33 ; k33 = 226
.line	1771	loadk        r58   k34 ; k34 = 140
.line	1771	loadk        r59   k35 ; k35 = 120
.line	1771	loadk        r60   k36 ; k36 = 51
.line	1771	loadk        r61   k37 ; k37 = 29
.line	1771	loadk        r62   k38 ; k38 = 209
.line	1771	loadk        r63   k39 ; k39 = 243
.line	1771	loadk        r64   k40 ; k40 = 157
.line	1771	loadk        r65   k41 ; k41 = 99
.line	1771	loadk        r66   k42 ; k42 = 14
.line	1771	loadk        r67   k43 ; k43 = 147
.line	1771	call         r27    41     2
.line	1771	getupval     r28    u1
.line	1771	loadk        r29   k44 ; k44 = 230
.line	1771	loadk        r30   k45 ; k45 = 47
.line	1771	loadk        r31    k6 ; k6 = 186
.line	1771	loadk        r32   k46 ; k46 = 208
.line	1771	loadk        r33    k8 ; k8 = 122
.line	1771	loadk        r34   k47 ; k47 = 125
.line	1771	loadk        r35   k48 ; k48 = 103
.line	1771	loadk        r36   k49 ; k49 = 130
.line	1771	loadk        r37   k50 ; k50 = 245
.line	1771	loadk        r38   k51 ; k51 = 198
.line	1771	loadk        r39   k52 ; k52 = 232
.line	1771	call         r28    12     0
.line	1771	setlist      r26     0     1
.line	1771	call         r25     2     2
.line	1771	call         r24     2     2
.line	1771	eq             1   r23    k0 ; k0 = nil
.line	1771	jmp            0  l462
.line	1771	gettable     r25   r23  k157 ; k157 = "OrginalID"
.line	1771	eq             1   r25    k0 ; k0 = nil
.line	1771	jmp            0  l462
.line	1771	gettable     r25   r19  k140 ; k140 = "GetListIsDownloaded"
.line	1771	gettable     r26   r20  k141 ; k141 = "ENUM_DownloadType"
.line	1771	gettable     r26   r26  k142 ; k142 = "ODPAK"
.line	1771	newtable     r27     1     0
.line	1771	gettable     r28   r23  k157 ; k157 = "OrginalID"
.line	1771	setlist      r27     1     1
.line	1771	call         r25     3     2
.line	1771	jmp            0  l464
.label	l462
.line	1771	loadbool     r25     0     1
.line	1771	loadbool     r25     1     0
.label	l464
.line	1771	test         r25     1
.line	1771	jmp            0  l671
.line	1771	test          r1     0
.line	1771	jmp            0  l671
.line	1771	eq             1    r1   k76 ; k76 = 0
.line	1771	jmp            0  l671
.line	1771	gettable     r26   r24   k53 ; k53 = "IsFITVersion"
.line	1771	call         r26     1     2
.line	1771	test         r26     0
.line	1771	jmp            0  l671
.line	1771	gettabup     r26    u0  k158 ; k158 = "printf"
.line	1771	gettabup     r27    u0    k2 ; k2 = "table"
.line	1771	gettable     r27   r27    k3 ; k3 = "concat"
.line	1771	newtable     r28     2     0
.line	1771	getupval     r29    u1
.line	1771	loadk        r30  k159 ; k159 = 212
.line	1771	loadk        r31  k160 ; k160 = 41
.line	1771	loadk        r32  k106 ; k106 = 161
.line	1771	loadk        r33  k161 ; k161 = 219
.line	1771	loadk        r34  k162 ; k162 = 102
.line	1771	loadk        r35  k163 ; k163 = 95
.line	1771	loadk        r36  k164 ; k164 = 100
.line	1771	loadk        r37  k165 ; k165 = 132
.line	1771	loadk        r38  k166 ; k166 = 203
.line	1771	loadk        r39   k51 ; k51 = 198
.line	1771	loadk        r40  k102 ; k102 = 252
.line	1771	loadk        r41   k25 ; k25 = 105
.line	1771	loadk        r42   k16 ; k16 = 93
.line	1771	loadk        r43  k167 ; k167 = 167
.line	1771	loadk        r44  k168 ; k168 = 188
.line	1771	loadk        r45   k15 ; k15 = 46
.line	1771	loadk        r46  k169 ; k169 = 28
.line	1771	loadk        r47   k67 ; k67 = 15
.line	1771	loadk        r48   k50 ; k50 = 245
.line	1771	loadk        r49   k30 ; k30 = 234
.line	1771	loadk        r50   k34 ; k34 = 140
.line	1771	loadk        r51   k25 ; k25 = 105
.line	1771	loadk        r52  k170 ; k170 = 21
.line	1771	loadk        r53  k171 ; k171 = 189
.line	1771	loadk        r54   k17 ; k17 = 242
.line	1771	loadk        r55   k29 ; k29 = 244
.line	1771	loadk        r56  k172 ; k172 = 228
.line	1771	loadk        r57  k173 ; k173 = 116
.line	1771	loadk        r58  k174 ; k174 = 75
.line	1771	loadk        r59  k114 ; k114 = 225
.line	1771	loadk        r60  k175 ; k175 = 223
.line	1771	loadk        r61   k75 ; k75 = 37
.line	1771	loadk        r62  k176 ; k176 = 8
.line	1771	loadk        r63  k177 ; k177 = 1
.line	1771	loadk        r64   k78 ; k78 = 221
.line	1771	loadk        r65   k27 ; k27 = 191
.line	1771	loadk        r66  k178 ; k178 = 149
.line	1771	loadk        r67  k179 ; k179 = 126
.line	1771	loadk        r68  k180 ; k180 = 2
.line	1771	loadk        r69  k114 ; k114 = 225
.line	1771	call         r29    41     2
.line	1771	getupval     r30    u1
.line	1771	loadk        r31  k181 ; k181 = 236
.line	1771	loadk        r32  k182 ; k182 = 58
.line	1771	loadk        r33    k6 ; k6 = 186
.line	1771	loadk        r34   k70 ; k70 = 216
.line	1771	loadk        r35   k47 ; k47 = 125
.line	1771	loadk        r36  k113 ; k113 = 94
.line	1771	loadk        r37   k48 ; k48 = 103
.line	1771	loadk        r38   k22 ; k22 = 141
.line	1771	loadk        r39  k167 ; k167 = 167
.line	1771	loadk        r40  k166 ; k166 = 203
.line	1771	loadk        r41   k29 ; k29 = 244
.line	1771	loadk        r42  k173 ; k173 = 116
.line	1771	loadk        r43  k119 ; k119 = 86
.line	1771	loadk        r44  k171 ; k171 = 189
.line	1771	loadk        r45   k18 ; k18 = 129
.line	1771	loadk        r46  k160 ; k160 = 41
.line	1771	loadk        r47  k104 ; k104 = 7
.line	1771	loadk        r48  k183 ; k183 = 88
.line	1771	loadk        r49  k120 ; k120 = 199
.line	1771	loadk        r50    k4 ; k4 = 224
.line	1771	loadk        r51   k43 ; k43 = 147
.line	1771	loadk        r52  k121 ; k121 = 110
.line	1771	loadk        r53   k20 ; k20 = 26
.line	1771	loadk        r54  k122 ; k122 = 190
.line	1771	loadk        r55  k123 ; k123 = 246
.line	1771	loadk        r56   k78 ; k78 = 221
.line	1771	loadk        r57  k184 ; k184 = 238
.line	1771	loadk        r58  k173 ; k173 = 116
.line	1771	loadk        r59  k180 ; k180 = 2
.line	1771	loadk        r60  k185 ; k185 = 173
.line	1771	loadk        r61  k186 ; k186 = 151
.line	1771	loadk        r62  k187 ; k187 = 63
.line	1771	loadk        r63  k104 ; k104 = 7
.line	1771	loadk        r64   k77 ; k77 = 13
.line	1771	loadk        r65   k43 ; k43 = 147
.line	1771	loadk        r66   k17 ; k17 = 242
.line	1771	loadk        r67  k188 ; k188 = 155
.line	1771	loadk        r68  k173 ; k173 = 116
.line	1771	loadk        r69  k131 ; k131 = 3
.line	1771	loadk        r70  k185 ; k185 = 173
.line	1771	call         r30    41     2
.line	1771	getupval     r31    u1
.line	1771	loadk        r32  k189 ; k189 = 175
.line	1771	loadk        r33  k190 ; k190 = 104
.line	1771	loadk        r34  k106 ; k106 = 161
.line	1771	loadk        r35    k7 ; k7 = 218
.line	1771	loadk        r36   k48 ; k48 = 103
.line	1771	loadk        r37  k191 ; k191 = 121
.line	1771	loadk        r38   k66 ; k66 = 98
.line	1771	loadk        r39  k161 ; k161 = 219
.line	1771	loadk        r40  k192 ; k192 = 162
.line	1771	loadk        r41    k7 ; k7 = 218
.line	1771	loadk        r42  k193 ; k193 = 183
.line	1771	loadk        r43   k19 ; k19 = 32
.line	1771	loadk        r44  k194 ; k194 = 81
.line	1771	loadk        r45  k195 ; k195 = 239
.line	1771	loadk        r46   k65 ; k65 = 134
.line	1771	loadk        r47  k196 ; k196 = 33
.line	1771	loadk        r48   k20 ; k20 = 26
.line	1771	loadk        r49  k197 ; k197 = 22
.line	1771	loadk        r50  k198 ; k198 = 194
.line	1771	loadk        r51   k28 ; k28 = 227
.line	1771	loadk        r52  k185 ; k185 = 173
.line	1771	loadk        r53  k164 ; k164 = 100
.line	1771	loadk        r54  k199 ; k199 = 76
.line	1771	loadk        r55   k29 ; k29 = 244
.line	1771	loadk        r56  k172 ; k172 = 228
.line	1771	call         r31    26     0
.line	1771	setlist      r28     0     1
.line	1771	call         r27     2     2
.line	1771	gettabup     r28    u0  k200 ; k200 = "tostring"
.line	1771	move         r29    r1
.line	1771	call         r28     2     2
.line	1771	gettabup     r29    u0  k200 ; k200 = "tostring"
.line	1771	testset      r30   r23     0
.line	1771	jmp            0  l598
.line	1771	gettable     r30   r23  k157 ; k157 = "OrginalID"
.label	l598
.line	1771	call         r29     2     0
.line	1771	call         r26     0     1
.line	1771	gettable     r26   r18  k201 ; k201 = "GetShowingData"
.line	1771	call         r26     1     2
.line	1771	settable     r26  k202   k76 ; k76 = 0
.line	1771	gettabup     r26    u0    k1 ; k1 = "require"
.line	1771	gettabup     r27    u0    k2 ; k2 = "table"
.line	1771	gettable     r27   r27    k3 ; k3 = "concat"
.line	1771	newtable     r28     1     0
.line	1771	getupval     r29    u1
.line	1771	loadk        r30    k4 ; k4 = 224
.line	1771	loadk        r31    k5 ; k5 = 36
.line	1771	loadk        r32    k6 ; k6 = 186
.line	1771	loadk        r33    k7 ; k7 = 218
.line	1771	loadk        r34    k8 ; k8 = 122
.line	1771	loadk        r35    k9 ; k9 = 68
.line	1771	loadk        r36   k10 ; k10 = 40
.line	1771	loadk        r37   k11 ; k11 = 146
.line	1771	loadk        r38   k12 ; k12 = 235
.line	1771	loadk        r39   k13 ; k13 = 220
.line	1771	loadk        r40   k14 ; k14 = 250
.line	1771	loadk        r41   k15 ; k15 = 46
.line	1771	loadk        r42   k61 ; k61 = 82
.line	1771	loadk        r43   k17 ; k17 = 242
.line	1771	loadk        r44   k24 ; k24 = 136
.line	1771	loadk        r45   k45 ; k45 = 47
.line	1771	loadk        r46   k62 ; k62 = 16
.line	1771	loadk        r47  k119 ; k119 = 86
.line	1771	loadk        r48  k101 ; k101 = 206
.line	1771	loadk        r49  k184 ; k184 = 238
.line	1771	loadk        r50  k203 ; k203 = 138
.line	1771	loadk        r51  k204 ; k204 = 97
.line	1771	loadk        r52  k127 ; k127 = 17
.line	1771	loadk        r53  k110 ; k110 = 180
.line	1771	loadk        r54  k205 ; k205 = 229
.line	1771	loadk        r55  k186 ; k186 = 151
.line	1771	loadk        r56   k13 ; k13 = 220
.line	1771	loadk        r57  k134 ; k134 = 117
.line	1771	loadk        r58  k206 ; k206 = 79
.line	1771	loadk        r59  k112 ; k112 = 253
.line	1771	loadk        r60  k207 ; k207 = 144
.line	1771	loadk        r61  k208 ; k208 = 56
.line	1771	loadk        r62   k15 ; k15 = 46
.line	1771	loadk        r63  k104 ; k104 = 7
.line	1771	loadk        r64  k209 ; k209 = 215
.line	1771	loadk        r65   k14 ; k14 = 250
.line	1771	loadk        r66  k210 ; k210 = 152
.line	1771	loadk        r67   k32 ; k32 = 92
.line	1771	loadk        r68  k211 ; k211 = 9
.line	1771	loadk        r69  k212 ; k212 = 166
.line	1771	call         r29    41     2
.line	1771	getupval     r30    u1
.line	1771	loadk        r31   k30 ; k30 = 234
.line	1771	loadk        r32  k213 ; k213 = 43
.line	1771	call         r30     3     0
.line	1771	setlist      r28     0     1
.line	1771	call         r27     2     2
.line	1771	call         r26     2     2
.line	1771	gettable     r27   r26  k214 ; k214 = "HideWeapon"
.line	1771	call         r27     1     1
.line	1771	move         r27    r4
.line	1771	closure      r28    f0
.line	1771	move          r4   r28
.line	1771	gettabup     r28    u0  k215 ; k215 = "EventSystem"
.line	1771	self         r28   r28  k216 ; k216 = "postEvent"
.line	1771	gettabup     r30    u0  k217 ; k217 = "EVENTTYPE_WARDROBE"
.line	1771	gettabup     r31    u0  k218 ; k218 = "EVENTID_WARDROBE_Cre" (truncated)
.line	1771	move         r32    r1
.line	1771	loadnil      r33     0
.line	1771	move         r34    r4
.line	1771	call         r28     7     1
.line	1771	return        r0     1
.line	1771	jmp           27  l671
.label	l671
.line	1771	test         r23     0
.line	1771	jmp            0  l884
.line	1771	loadnil      r26     0
.line	1771	gettabup     r27    u0    k1 ; k1 = "require"
.line	1771	gettabup     r28    u0  k219 ; k219 = "table"
.line	1771	gettable     r28   r28  k220 ; k220 = "concat"
.line	1771	newtable     r29     1     0
.line	1771	getupval     r30    u1
.line	1771	loadk        r31    k4 ; k4 = 224
.line	1771	loadk        r32    k5 ; k5 = 36
.line	1771	loadk        r33    k6 ; k6 = 186
.line	1771	loadk        r34    k7 ; k7 = 218
.line	1771	loadk        r35    k8 ; k8 = 122
.line	1771	loadk        r36    k9 ; k9 = 68
.line	1771	loadk        r37   k10 ; k10 = 40
.line	1771	loadk        r38   k11 ; k11 = 146
.line	1771	loadk        r39  k221 ; k221 = 235
.line	1771	loadk        r40   k13 ; k13 = 220
.line	1771	loadk        r41  k222 ; k222 = 250
.line	1771	loadk        r42  k223 ; k223 = 46
.line	1771	loadk        r43   k61 ; k61 = 82
.line	1771	loadk        r44  k224 ; k224 = 242
.line	1771	loadk        r45   k24 ; k24 = 136
.line	1771	loadk        r46   k45 ; k45 = 47
.line	1771	loadk        r47  k225 ; k225 = 16
.line	1771	loadk        r48  k119 ; k119 = 86
.line	1771	loadk        r49  k226 ; k226 = 207
.line	1771	loadk        r50    k4 ; k4 = 224
.line	1771	loadk        r51   k65 ; k65 = 134
.line	1771	loadk        r52  k227 ; k227 = 98
.line	1771	loadk        r53  k228 ; k228 = 15
.line	1771	loadk        r54  k229 ; k229 = 142
.line	1771	loadk        r55  k230 ; k230 = 246
.line	1771	loadk        r56    k7 ; k7 = 218
.line	1771	loadk        r57  k156 ; k156 = 255
.line	1771	loadk        r58  k191 ; k191 = 121
.line	1771	loadk        r59  k183 ; k183 = 88
.line	1771	loadk        r60  k231 ; k231 = 228
.line	1771	loadk        r61  k232 ; k232 = 139
.line	1771	loadk        r62   k45 ; k45 = 47
.line	1771	loadk        r63  k233 ; k233 = 77
.line	1771	loadk        r64    k5 ; k5 = 36
.line	1771	loadk        r65  k234 ; k234 = 210
.line	1771	loadk        r66  k111 ; k111 = 251
.line	1771	loadk        r67  k207 ; k207 = 144
.line	1771	loadk        r68  k235 ; k235 = 117
.line	1771	loadk        r69  k236 ; k236 = 20
.line	1771	loadk        r70   k49 ; k49 = 130
.line	1771	call         r30    41     2
.line	1771	getupval     r31    u1
.line	1771	loadk        r32   k33 ; k33 = 226
.line	1771	loadk        r33  k182 ; k182 = 58
.line	1771	loadk        r34  k186 ; k186 = 151
.line	1771	loadk        r35    k7 ; k7 = 218
.line	1771	loadk        r36  k125 ; k125 = 96
.line	1771	loadk        r37  k194 ; k194 = 81
.line	1771	loadk        r38  k237 ; k237 = 111
.line	1771	loadk        r39   k22 ; k22 = 141
.line	1771	loadk        r40  k238 ; k238 = 196
.line	1771	loadk        r41  k239 ; k239 = 198
.line	1771	loadk        r42  k240 ; k240 = 245
.line	1771	loadk        r43  k241 ; k241 = 102
.line	1771	loadk        r44  k135 ; k135 = 87
.line	1771	loadk        r45  k222 ; k222 = 250
.line	1771	call         r31    15     0
.line	1771	setlist      r29     0     1
.line	1771	call         r28     2     2
.line	1771	call         r27     2     2
.line	1771	gettable     r28   r27  k242 ; k242 = "IsRareCar"
.line	1771	move         r29    r1
.line	1771	call         r28     2     2
.line	1771	test         r28     0
.line	1771	jmp            0  l864
.line	1771	newtable     r28     0     1
.line	1771	settable     r28  k243  k244 ; k244 = true
.line	1771	move         r26   r28
.line	1771	gettabup     r28    u0  k245 ; k245 = "printf"
.line	1771	gettabup     r29    u0  k219 ; k219 = "table"
.line	1771	gettable     r29   r29  k220 ; k220 = "concat"
.line	1771	newtable     r30     2     0
.line	1771	getupval     r31    u1
.line	1771	loadk        r32  k246 ; k246 = 212
.line	1771	loadk        r33  k247 ; k247 = 41
.line	1771	loadk        r34  k248 ; k248 = 161
.line	1771	loadk        r35  k249 ; k249 = 219
.line	1771	loadk        r36  k241 ; k241 = 102
.line	1771	loadk        r37  k250 ; k250 = 95
.line	1771	loadk        r38  k251 ; k251 = 100
.line	1771	loadk        r39  k252 ; k252 = 132
.line	1771	loadk        r40  k253 ; k253 = 203
.line	1771	loadk        r41  k239 ; k239 = 198
.line	1771	loadk        r42  k254 ; k254 = 252
.line	1771	loadk        r43  k255 ; k255 = 105
.line	1771	loadk        r44  k256 ; k256 = 93
.line	1771	loadk        r45  k257 ; k257 = 167
.line	1771	loadk        r46  k258 ; k258 = 188
.line	1771	loadk        r47  k223 ; k223 = 46
.line	1771	loadk        r48  k259 ; k259 = 28
.line	1771	loadk        r49  k228 ; k228 = 15
.line	1771	loadk        r50  k240 ; k240 = 245
.line	1771	loadk        r51  k260 ; k260 = 234
.line	1771	loadk        r52  k261 ; k261 = 140
.line	1771	loadk        r53  k255 ; k255 = 105
.line	1771	loadk        r54  k262 ; k262 = 21
.line	1771	loadk        r55  k263 ; k263 = 189
.line	1771	loadk        r56  k224 ; k224 = 242
.line	1771	loadk        r57  k264 ; k264 = 244
.line	1771	loadk        r58  k231 ; k231 = 228
.line	1771	loadk        r59  k265 ; k265 = 116
.line	1771	loadk        r60  k266 ; k266 = 75
.line	1771	loadk        r61  k267 ; k267 = 225
.line	1771	loadk        r62  k268 ; k268 = 223
.line	1771	loadk        r63  k269 ; k269 = 48
.line	1771	loadk        r64  k270 ; k270 = 12
.line	1771	loadk        r65  k271 ; k271 = 26
.line	1771	loadk        r66   k46 ; k46 = 208
.line	1771	loadk        r67  k222 ; k222 = 250
.line	1771	loadk        r68  k246 ; k246 = 212
.line	1771	loadk        r69  k272 ; k272 = 127
.line	1771	loadk        r70  k236 ; k236 = 20
.line	1771	loadk        r71  k273 ; k273 = 168
.line	1771	call         r31    41     2
.line	1771	getupval     r32    u1
.line	1771	loadk        r33  k231 ; k231 = 228
.line	1771	loadk        r34  k274 ; k274 = 33
.line	1771	loadk        r35  k263 ; k263 = 189
.line	1771	loadk        r36  k275 ; k275 = 222
.line	1771	loadk        r37   k35 ; k35 = 120
.line	1771	loadk        r38  k225 ; k225 = 16
.line	1771	loadk        r39  k276 ; k276 = 107
.line	1771	loadk        r40  k229 ; k229 = 142
.line	1771	loadk        r41   k28 ; k28 = 227
.line	1771	loadk        r42   k23 ; k23 = 204
.line	1771	loadk        r43  k277 ; k277 = 247
.line	1771	loadk        r44  k278 ; k278 = 32
.line	1771	loadk        r45  k135 ; k135 = 87
.line	1771	loadk        r46   k39 ; k39 = 243
.line	1771	loadk        r47  k188 ; k188 = 155
.line	1771	loadk        r48  k247 ; k247 = 41
.line	1771	loadk        r49  k279 ; k279 = 83
.line	1771	loadk        r50  k280 ; k280 = 10
.line	1771	loadk        r51  k198 ; k198 = 194
.line	1771	loadk        r52  k281 ; k281 = 253
.line	1771	loadk        r53   k18 ; k18 = 129
.line	1771	loadk        r54  k278 ; k278 = 32
.line	1771	loadk        r55  k282 ; k282 = 5
.line	1771	loadk        r56  k133 ; k133 = 178
.line	1771	loadk        r57  k224 ; k224 = 242
.line	1771	loadk        r58  k283 ; k283 = 215
.line	1771	loadk        r59  k284 ; k284 = 238
.line	1771	loadk        r60  k285 ; k285 = 60
.line	1771	loadk        r61   k42 ; k42 = 14
.line	1771	loadk        r62  k156 ; k156 = 255
.line	1771	loadk        r63  k286 ; k286 = 154
.line	1771	loadk        r64   k75 ; k75 = 37
.line	1771	loadk        r65  k287 ; k287 = 42
.line	1771	loadk        r66  k270 ; k270 = 12
.line	1771	loadk        r67  k288 ; k288 = 137
.line	1771	loadk        r68    k6 ; k6 = 186
.line	1771	loadk        r69  k289 ; k289 = 135
.line	1771	loadk        r70  k285 ; k285 = 60
.line	1771	loadk        r71  k290 ; k290 = 70
.line	1771	loadk        r72  k291 ; k291 = 174
.line	1771	call         r32    41     2
.line	1771	getupval     r33    u1
.line	1771	loadk        r34  k292 ; k292 = 241
.line	1771	loadk        r35  k274 ; k274 = 33
.line	1771	loadk        r36  k110 ; k110 = 180
.line	1771	loadk        r37  k148 ; k148 = 214
.line	1771	loadk        r38    k8 ; k8 = 122
.line	1771	loadk        r39  k194 ; k194 = 81
.line	1771	loadk        r40  k293 ; k293 = 106
.line	1771	loadk        r41  k273 ; k273 = 168
.line	1771	loadk        r42   k28 ; k28 = 227
.line	1771	loadk        r43   k43 ; k43 = 147
.line	1771	loadk        r44  k122 ; k122 = 190
.line	1771	loadk        r45   k31 ; k31 = 115
.line	1771	call         r33    13     0
.line	1771	setlist      r30     0     1
.line	1771	call         r29     2     2
.line	1771	loadk        r30  k294 ; k294 = "tostring"
.line	1771	gettabup     r30    u0   r30
.line	1771	move         r31    r1
.line	1771	call         r30     2     2
.line	1771	loadk        r31  k294 ; k294 = "tostring"
.line	1771	gettabup     r31    u0   r31
.line	1771	gettable     r32   r23  k157 ; k157 = "OrginalID"
.line	1771	call         r31     2     0
.line	1771	call         r28     0     1
.line	1771	move         r28    r4
.line	1771	closure      r29    f1
.line	1771	move          r4   r29
.line	1771	jmp           29  l864
.label	l864
.line	1771	loadk        r28  k295 ; k295 = "Display"
.line	1771	gettable     r28   r18   r28
.line	1771	gettable     r29   r23  k157 ; k157 = "OrginalID"
.line	1771	loadbool     r30     1     0
.line	1771	move         r31   r26
.line	1771	call         r28     4     1
.line	1771	jmp            0  l884
.label	l871
.line	1771	loadk        r23  k295 ; k295 = "Display"
.line	1771	gettable     r23   r18   r23
.line	1771	move         r24    r1
.line	1771	loadbool     r25     1     0
.line	1771	move         r26    r5
.line	1771	call         r23     4     1
.line	1771	jmp            0  l884
.label	l878
.line	1771	loadk        r19  k295 ; k295 = "Display"
.line	1771	gettable     r19   r18   r19
.line	1771	move         r20    r1
.line	1771	loadbool     r21     1     0
.line	1771	move         r22    r5
.line	1771	call         r19     4     1
.label	l884
.line	1771	gettabup     r19    u0    k1 ; k1 = "require"
.line	1771	loadk        r20  k296 ; k296 = "table"
.line	1771	gettabup     r20    u0   r20
.line	1771	loadk        r21  k297 ; k297 = "concat"
.line	1771	gettable     r20   r20   r21
.line	1771	newtable     r21     1     0
.line	1771	getupval     r22    u1
.line	1771	loadk        r23    k4 ; k4 = 224
.line	1771	loadk        r24  k298 ; k298 = 36
.line	1771	loadk        r25    k6 ; k6 = 186
.line	1771	loadk        r26    k7 ; k7 = 218
.line	1771	loadk        r27  k299 ; k299 = 122
.line	1771	loadk        r28    k9 ; k9 = 68
.line	1771	loadk        r29   k10 ; k10 = 40
.line	1771	loadk        r30   k11 ; k11 = 146
.line	1771	loadk        r31  k221 ; k221 = 235
.line	1771	loadk        r32   k13 ; k13 = 220
.line	1771	loadk        r33  k222 ; k222 = 250
.line	1771	loadk        r34  k300 ; k300 = 46
.line	1771	loadk        r35   k61 ; k61 = 82
.line	1771	loadk        r36  k301 ; k301 = 242
.line	1771	loadk        r37   k24 ; k24 = 136
.line	1771	loadk        r38   k45 ; k45 = 47
.line	1771	loadk        r39  k225 ; k225 = 16
.line	1771	loadk        r40  k119 ; k119 = 86
.line	1771	loadk        r41  k101 ; k101 = 206
.line	1771	loadk        r42  k302 ; k302 = 238
.line	1771	loadk        r43  k203 ; k203 = 138
.line	1771	loadk        r44  k204 ; k204 = 97
.line	1771	loadk        r45  k127 ; k127 = 17
.line	1771	loadk        r46  k303 ; k303 = 180
.line	1771	loadk        r47  k205 ; k205 = 229
.line	1771	loadk        r48  k304 ; k304 = 151
.line	1771	loadk        r49   k13 ; k13 = 220
.line	1771	loadk        r50  k235 ; k235 = 117
.line	1771	loadk        r51  k206 ; k206 = 79
.line	1771	loadk        r52  k305 ; k305 = 253
.line	1771	loadk        r53  k207 ; k207 = 144
.line	1771	loadk        r54  k208 ; k208 = 56
.line	1771	loadk        r55  k300 ; k300 = 46
.line	1771	loadk        r56  k104 ; k104 = 7
.line	1771	loadk        r57  k283 ; k283 = 215
.line	1771	loadk        r58  k222 ; k222 = 250
.line	1771	loadk        r59  k210 ; k210 = 152
.line	1771	loadk        r60  k306 ; k306 = 92
.line	1771	loadk        r61  k211 ; k211 = 9
.line	1771	loadk        r62  k212 ; k212 = 166
.line	1771	call         r22    41     2
.line	1771	getupval     r23    u1
.line	1771	loadk        r24  k307 ; k307 = 234
.line	1771	loadk        r25  k213 ; k213 = 43
.line	1771	call         r23     3     0
.line	1771	setlist      r21     0     1
.line	1771	call         r20     2     2
.line	1771	call         r19     2     2
.line	1771	loadk        r20  k308 ; k308 = "GetProperWeaponShowA" (truncated)
.line	1771	gettable     r20   r19   r20
.line	1771	call         r20     1     2
.line	1771	gettabup     r21    u0   k99 ; k99 = "slua"
.line	1771	loadk        r22  k309 ; k309 = "isValid"
.line	1771	gettable     r21   r21   r22
.line	1771	move         r22   r20
.line	1771	call         r21     2     2
.line	1771	test         r21     0
.line	1771	jmp            0  l972
.line	1771	loadk        r23  k310 ; k310 = "GetVehicleActor"
.line	1771	self         r21   r20   r23
.line	1771	call         r21     2     2
.line	1771	gettabup     r22    u0   k99 ; k99 = "slua"
.line	1771	loadk        r23  k309 ; k309 = "isValid"
.line	1771	gettable     r22   r22   r23
.line	1771	move         r23   r21
.line	1771	call         r22     2     2
.line	1771	test         r22     0
.line	1771	jmp            0  l972
.line	1771	loadk        r22  k311 ; k311 = "BP_VehicleDIYComp"
.line	1771	gettable     r22   r21   r22
.line	1771	test         r22     0
.line	1771	jmp            0  l972
.line	1771	loadk        r22  k311 ; k311 = "BP_VehicleDIYComp"
.line	1771	gettable     r22   r21   r22
.line	1771	loadk        r24  k312 ; k312 = "UpdateCarOwnerInLobb" (truncated)
.line	1771	self         r22   r22   r24
.line	1771	gettabup     r24    u0   k82 ; k82 = "DataMgr"
.line	1771	gettable     r24   r24   k83 ; k83 = "roleData"
.line	1771	gettable     r24   r24   k84 ; k84 = "uid"
.line	1771	move         r25    r1
.line	1771	call         r22     4     1
.label	l972
.line	1771	move         r21   r16
.line	1771	call         r21     1     2
.line	1771	loadk        r22  k313 ; k313 = "log"
.line	1771	gettabup     r22    u0   r22
.line	1771	loadk        r23  k314 ; k314 = "bWriteLog"
.line	1771	gettabup     r23    u0   r23
.line	1771	test         r23     0
.line	1771	jmp            0 l1020
.line	1771	getupval     r23    u1
.line	1771	loadk        r24  k315 ; k315 = 212
.line	1771	loadk        r25  k316 ; k316 = 41
.line	1771	loadk        r26  k317 ; k317 = 161
.line	1771	loadk        r27  k318 ; k318 = 219
.line	1771	loadk        r28  k319 ; k319 = 102
.line	1771	loadk        r29  k320 ; k320 = 95
.line	1771	loadk        r30  k321 ; k321 = 100
.line	1771	loadk        r31  k322 ; k322 = 132
.line	1771	loadk        r32  k323 ; k323 = 203
.line	1771	loadk        r33  k324 ; k324 = 198
.line	1771	loadk        r34  k325 ; k325 = 252
.line	1771	loadk        r35  k326 ; k326 = 105
.line	1771	loadk        r36  k327 ; k327 = 93
.line	1771	loadk        r37  k328 ; k328 = 167
.line	1771	loadk        r38  k329 ; k329 = 188
.line	1771	loadk        r39  k300 ; k300 = 46
.line	1771	loadk        r40  k330 ; k330 = 28
.line	1771	loadk        r41  k331 ; k331 = 15
.line	1771	loadk        r42  k332 ; k332 = 245
.line	1771	loadk        r43  k307 ; k307 = 234
.line	1771	loadk        r44  k333 ; k333 = 140
.line	1771	loadk        r45  k326 ; k326 = 105
.line	1771	loadk        r46  k334 ; k334 = 21
.line	1771	loadk        r47  k335 ; k335 = 189
.line	1771	loadk        r48  k301 ; k301 = 242
.line	1771	loadk        r49  k336 ; k336 = 244
.line	1771	loadk        r50  k337 ; k337 = 228
.line	1771	loadk        r51  k338 ; k338 = 116
.line	1771	loadk        r52  k339 ; k339 = 75
.line	1771	loadk        r53  k340 ; k340 = 225
.line	1771	loadk        r54  k341 ; k341 = 197
.line	1771	call         r23    32     2
.line	1771	loadk        r24  k342 ; k342 = "tostring"
.line	1771	gettabup     r24    u0   r24
.line	1771	sub          r25   r21   r17
.line	1771	loadk        r26  k343 ; k343 = 1000
.line	1771	div          r25   r25   r26
.line	1771	call         r24     2     2
.line	1771	concat       r23   r23   r24
.label	l1020
.line	1771	call         r22     2     1
.line	1771	gettabup     r22    u0  k215 ; k215 = "EventSystem"
.line	1771	self         r22   r22  k216 ; k216 = "postEvent"
.line	1771	gettabup     r24    u0  k217 ; k217 = "EVENTTYPE_WARDROBE"
.line	1771	gettabup     r25    u0  k218 ; k218 = "EVENTID_WARDROBE_Cre" (truncated)
.line	1771	move         r26    r1
.line	1771	loadnil      r27     0
.line	1771	move         r28    r4
.line	1771	call         r22     7     1
.line	1771	return        r0     1
.line	1771	move          r0    r0
.line	1771	gettabup      r1    u0   k98 ; k98 = "Source"
.line	1771	return        r0     1

.function	main/f95/f0

.source	null
.linedefined	1830
.lastlinedefined	1836
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	1	true
.upvalue	"U3"	0	true
.upvalue	"U4"	2	true
.upvalue	"U5"	3	true
.upvalue	"U6"	27	true

.constant	k0	"printf"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	212
.constant	k4	41
.constant	k5	161
.constant	k6	219
.constant	k7	102
.constant	k8	95
.constant	k9	100
.constant	k10	132
.constant	k11	203
.constant	k12	198
.constant	k13	252
.constant	k14	105
.constant	k15	93
.constant	k16	167
.constant	k17	188
.constant	k18	46
.constant	k19	28
.constant	k20	15
.constant	k21	245
.constant	k22	234
.constant	k23	140
.constant	k24	21
.constant	k25	189
.constant	k26	242
.constant	k27	244
.constant	k28	228
.constant	k29	116
.constant	k30	75
.constant	k31	225
.constant	k32	223
.constant	k33	62
.constant	k34	10
.constant	k35	12
.constant	k36	215
.constant	k37	250
.constant	k38	154
.constant	k39	48
.constant	k40	16
.constant	k41	164
.constant	k42	235
.constant	k43	33
.constant	k44	176
.constant	k45	211
.constant	k46	113
.constant	k47	98
.constant	k48	142
.constant	k49	240
.constant	k50	199
.constant	k51	247
.constant	k52	111
.constant	k53	249
.constant	k54	207
.constant	k55	32
.constant	k56	26
.constant	k57	22
.constant	k58	202
.constant	k59	101
.constant	k60	18
.constant	k61	253
.constant	k62	183
.constant	k63	238
.constant	k64	118
.constant	k65	92
.constant	k66	232
.constant	k67	67
.constant	k68	27
.constant	k69	216
.constant	k70	246
.constant	k71	60
.constant	k72	70
.constant	k73	179
.constant	k74	230
.constant	k75	59
.constant	k76	117
.constant	k77	"tostring"
.constant	k78	"ShowVehicleModel"

.line	1830	gettabup      r0    u0    k0 ; k0 = "printf"
.line	1830	gettabup      r1    u0    k1 ; k1 = "table"
.line	1830	gettable      r1    r1    k2 ; k2 = "concat"
.line	1830	newtable      r2     2     0
.line	1830	getupval      r3    u1
.line	1830	loadk         r4    k3 ; k3 = 212
.line	1830	loadk         r5    k4 ; k4 = 41
.line	1830	loadk         r6    k5 ; k5 = 161
.line	1830	loadk         r7    k6 ; k6 = 219
.line	1830	loadk         r8    k7 ; k7 = 102
.line	1830	loadk         r9    k8 ; k8 = 95
.line	1830	loadk        r10    k9 ; k9 = 100
.line	1830	loadk        r11   k10 ; k10 = 132
.line	1830	loadk        r12   k11 ; k11 = 203
.line	1830	loadk        r13   k12 ; k12 = 198
.line	1830	loadk        r14   k13 ; k13 = 252
.line	1830	loadk        r15   k14 ; k14 = 105
.line	1830	loadk        r16   k15 ; k15 = 93
.line	1830	loadk        r17   k16 ; k16 = 167
.line	1830	loadk        r18   k17 ; k17 = 188
.line	1830	loadk        r19   k18 ; k18 = 46
.line	1830	loadk        r20   k19 ; k19 = 28
.line	1830	loadk        r21   k20 ; k20 = 15
.line	1830	loadk        r22   k21 ; k21 = 245
.line	1830	loadk        r23   k22 ; k22 = 234
.line	1830	loadk        r24   k23 ; k23 = 140
.line	1830	loadk        r25   k14 ; k14 = 105
.line	1830	loadk        r26   k24 ; k24 = 21
.line	1830	loadk        r27   k25 ; k25 = 189
.line	1830	loadk        r28   k26 ; k26 = 242
.line	1830	loadk        r29   k27 ; k27 = 244
.line	1830	loadk        r30   k28 ; k28 = 228
.line	1830	loadk        r31   k29 ; k29 = 116
.line	1830	loadk        r32   k30 ; k30 = 75
.line	1830	loadk        r33   k31 ; k31 = 225
.line	1830	loadk        r34   k32 ; k32 = 223
.line	1830	loadk        r35   k33 ; k33 = 62
.line	1830	loadk        r36   k34 ; k34 = 10
.line	1830	loadk        r37   k35 ; k35 = 12
.line	1830	loadk        r38   k36 ; k36 = 215
.line	1830	loadk        r39   k37 ; k37 = 250
.line	1830	loadk        r40   k38 ; k38 = 154
.line	1830	loadk        r41   k39 ; k39 = 48
.line	1830	loadk        r42   k40 ; k40 = 16
.line	1830	loadk        r43   k41 ; k41 = 164
.line	1830	call          r3    41     2
.line	1830	getupval      r4    u1
.line	1830	loadk         r5   k42 ; k42 = 235
.line	1830	loadk         r6   k43 ; k43 = 33
.line	1830	loadk         r7   k44 ; k44 = 176
.line	1830	loadk         r8   k45 ; k45 = 211
.line	1830	loadk         r9   k46 ; k46 = 113
.line	1830	loadk        r10   k40 ; k40 = 16
.line	1830	loadk        r11   k47 ; k47 = 98
.line	1830	loadk        r12   k48 ; k48 = 142
.line	1830	loadk        r13   k49 ; k49 = 240
.line	1830	loadk        r14   k50 ; k50 = 199
.line	1830	loadk        r15   k51 ; k51 = 247
.line	1830	loadk        r16   k52 ; k52 = 111
.line	1830	loadk        r17    k8 ; k8 = 95
.line	1830	loadk        r18   k53 ; k53 = 249
.line	1830	loadk        r19   k54 ; k54 = 207
.line	1830	loadk        r20   k55 ; k55 = 32
.line	1830	loadk        r21   k56 ; k56 = 26
.line	1830	loadk        r22   k57 ; k57 = 22
.line	1830	loadk        r23   k58 ; k58 = 202
.line	1830	loadk        r24   k13 ; k13 = 252
.line	1830	loadk        r25   k23 ; k23 = 140
.line	1830	loadk        r26   k59 ; k59 = 101
.line	1830	loadk        r27   k60 ; k60 = 18
.line	1830	loadk        r28   k61 ; k61 = 253
.line	1830	loadk        r29   k62 ; k62 = 183
.line	1830	loadk        r30   k11 ; k11 = 203
.line	1830	loadk        r31   k63 ; k63 = 238
.line	1830	loadk        r32   k64 ; k64 = 118
.line	1830	loadk        r33   k65 ; k65 = 92
.line	1830	loadk        r34   k66 ; k66 = 232
.line	1830	loadk        r35   k23 ; k23 = 140
.line	1830	loadk        r36   k33 ; k33 = 62
.line	1830	loadk        r37   k67 ; k67 = 67
.line	1830	loadk        r38   k68 ; k68 = 27
.line	1830	loadk        r39   k69 ; k69 = 216
.line	1830	loadk        r40   k70 ; k70 = 246
.line	1830	loadk        r41   k38 ; k38 = 154
.line	1830	loadk        r42   k71 ; k71 = 60
.line	1830	loadk        r43   k72 ; k72 = 70
.line	1830	loadk        r44   k73 ; k73 = 179
.line	1830	call          r4    41     2
.line	1830	getupval      r5    u1
.line	1830	loadk         r6   k74 ; k74 = 230
.line	1830	loadk         r7   k75 ; k75 = 59
.line	1830	loadk         r8   k38 ; k38 = 154
.line	1830	loadk         r9    k6 ; k6 = 219
.line	1830	loadk        r10   k18 ; k18 = 46
.line	1830	loadk        r11   k24 ; k24 = 21
.line	1830	loadk        r12   k76 ; k76 = 117
.line	1830	call          r5     8     0
.line	1830	setlist       r2     0     1
.line	1830	call          r1     2     2
.line	1830	gettabup      r2    u0   k77 ; k77 = "tostring"
.line	1830	getupval      r3    u2
.line	1830	call          r2     2     0
.line	1830	call          r0     0     1
.line	1830	getupval      r0    u3
.line	1830	self          r0    r0   k78 ; k78 = "ShowVehicleModel"
.line	1830	getupval      r2    u2
.line	1830	getupval      r3    u4
.line	1830	getupval      r4    u5
.line	1830	loadnil       r5     0
.line	1830	call          r0     6     1
.line	1830	getupval      r0    u6
.line	1830	test          r0     0
.line	1830	jmp            0  l116
.line	1830	getupval      r0    u6
.line	1830	call          r0     1     1
.label	l116
.line	1830	return        r0     1
.line	1830	move          r0    r0
.line	1830	return        r0     1

.function	main/f95/f1

.source	null
.linedefined	1849
.lastlinedefined	1855
.numparams	0
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	1	true
.upvalue	"U3"	0	true
.upvalue	"U4"	2	true
.upvalue	"U5"	3	true
.upvalue	"U6"	28	true

.constant	k0	"printf"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	212
.constant	k4	41
.constant	k5	161
.constant	k6	219
.constant	k7	102
.constant	k8	95
.constant	k9	100
.constant	k10	132
.constant	k11	203
.constant	k12	198
.constant	k13	252
.constant	k14	105
.constant	k15	93
.constant	k16	167
.constant	k17	188
.constant	k18	46
.constant	k19	28
.constant	k20	15
.constant	k21	245
.constant	k22	234
.constant	k23	140
.constant	k24	21
.constant	k25	189
.constant	k26	242
.constant	k27	244
.constant	k28	228
.constant	k29	116
.constant	k30	75
.constant	k31	225
.constant	k32	223
.constant	k33	36
.constant	k34	2
.constant	k35	26
.constant	k36	214
.constant	k37	191
.constant	k38	151
.constant	k39	113
.constant	k40	20
.constant	k41	231
.constant	k42	39
.constant	k43	164
.constant	k44	209
.constant	k45	120
.constant	k46	103
.constant	k47	133
.constant	k48	207
.constant	k49	110
.constant	k50	87
.constant	k51	238
.constant	k52	135
.constant	k53	35
.constant	k54	23
.constant	k55	84
.constant	k56	131
.constant	k57	253
.constant	k58	129
.constant	k59	4
.constant	k60	180
.constant	k61	171
.constant	k62	99
.constant	k63	69
.constant	k64	145
.constant	k65	122
.constant	k66	67
.constant	k67	236
.constant	k68	92
.constant	k69	240
.constant	k70	"tostring"
.constant	k71	"ShowVehicleModel"

.line	1849	gettabup      r0    u0    k0 ; k0 = "printf"
.line	1849	gettabup      r1    u0    k1 ; k1 = "table"
.line	1849	gettable      r1    r1    k2 ; k2 = "concat"
.line	1849	newtable      r2     2     0
.line	1849	getupval      r3    u1
.line	1849	loadk         r4    k3 ; k3 = 212
.line	1849	loadk         r5    k4 ; k4 = 41
.line	1849	loadk         r6    k5 ; k5 = 161
.line	1849	loadk         r7    k6 ; k6 = 219
.line	1849	loadk         r8    k7 ; k7 = 102
.line	1849	loadk         r9    k8 ; k8 = 95
.line	1849	loadk        r10    k9 ; k9 = 100
.line	1849	loadk        r11   k10 ; k10 = 132
.line	1849	loadk        r12   k11 ; k11 = 203
.line	1849	loadk        r13   k12 ; k12 = 198
.line	1849	loadk        r14   k13 ; k13 = 252
.line	1849	loadk        r15   k14 ; k14 = 105
.line	1849	loadk        r16   k15 ; k15 = 93
.line	1849	loadk        r17   k16 ; k16 = 167
.line	1849	loadk        r18   k17 ; k17 = 188
.line	1849	loadk        r19   k18 ; k18 = 46
.line	1849	loadk        r20   k19 ; k19 = 28
.line	1849	loadk        r21   k20 ; k20 = 15
.line	1849	loadk        r22   k21 ; k21 = 245
.line	1849	loadk        r23   k22 ; k22 = 234
.line	1849	loadk        r24   k23 ; k23 = 140
.line	1849	loadk        r25   k14 ; k14 = 105
.line	1849	loadk        r26   k24 ; k24 = 21
.line	1849	loadk        r27   k25 ; k25 = 189
.line	1849	loadk        r28   k26 ; k26 = 242
.line	1849	loadk        r29   k27 ; k27 = 244
.line	1849	loadk        r30   k28 ; k28 = 228
.line	1849	loadk        r31   k29 ; k29 = 116
.line	1849	loadk        r32   k30 ; k30 = 75
.line	1849	loadk        r33   k31 ; k31 = 225
.line	1849	loadk        r34   k32 ; k32 = 223
.line	1849	loadk        r35   k33 ; k33 = 36
.line	1849	loadk        r36   k34 ; k34 = 2
.line	1849	loadk        r37   k35 ; k35 = 26
.line	1849	loadk        r38   k36 ; k36 = 214
.line	1849	loadk        r39   k37 ; k37 = 191
.line	1849	loadk        r40   k38 ; k38 = 151
.line	1849	loadk        r41   k39 ; k39 = 113
.line	1849	loadk        r42   k40 ; k40 = 20
.line	1849	loadk        r43   k31 ; k31 = 225
.line	1849	call          r3    41     2
.line	1849	getupval      r4    u1
.line	1849	loadk         r5   k41 ; k41 = 231
.line	1849	loadk         r6   k42 ; k42 = 39
.line	1849	loadk         r7   k43 ; k43 = 164
.line	1849	loadk         r8   k44 ; k44 = 209
.line	1849	loadk         r9   k45 ; k45 = 120
.line	1849	loadk        r10    k8 ; k8 = 95
.line	1849	loadk        r11   k46 ; k46 = 103
.line	1849	loadk        r12   k47 ; k47 = 133
.line	1849	loadk        r13   k16 ; k16 = 167
.line	1849	loadk        r14   k48 ; k48 = 207
.line	1849	loadk        r15   k26 ; k26 = 242
.line	1849	loadk        r16   k49 ; k49 = 110
.line	1849	loadk        r17   k50 ; k50 = 87
.line	1849	loadk        r18   k51 ; k51 = 238
.line	1849	loadk        r19   k52 ; k52 = 135
.line	1849	loadk        r20   k53 ; k53 = 35
.line	1849	loadk        r21   k54 ; k54 = 23
.line	1849	loadk        r22   k55 ; k55 = 84
.line	1849	loadk        r23   k56 ; k56 = 131
.line	1849	loadk        r24   k57 ; k57 = 253
.line	1849	loadk        r25   k58 ; k58 = 129
.line	1849	loadk        r26    k7 ; k7 = 102
.line	1849	loadk        r27   k59 ; k59 = 4
.line	1849	loadk        r28   k60 ; k60 = 180
.line	1849	loadk        r29   k28 ; k28 = 228
.line	1849	loadk        r30   k44 ; k44 = 209
.line	1849	loadk        r31   k61 ; k61 = 171
.line	1849	loadk        r32   k62 ; k62 = 99
.line	1849	loadk        r33   k63 ; k63 = 69
.line	1849	loadk        r34   k28 ; k28 = 228
.line	1849	loadk        r35   k64 ; k64 = 145
.line	1849	loadk        r36   k65 ; k65 = 122
.line	1849	loadk        r37   k66 ; k66 = 67
.line	1849	loadk        r38   k35 ; k35 = 26
.line	1849	loadk        r39   k36 ; k36 = 214
.line	1849	loadk        r40   k67 ; k67 = 236
.line	1849	loadk        r41   k25 ; k25 = 189
.line	1849	loadk        r42   k29 ; k29 = 116
.line	1849	loadk        r43   k68 ; k68 = 92
.line	1849	loadk        r44   k28 ; k28 = 228
.line	1849	call          r4    41     2
.line	1849	getupval      r5    u1
.line	1849	loadk         r6   k69 ; k69 = 240
.line	1849	call          r5     2     0
.line	1849	setlist       r2     0     1
.line	1849	call          r1     2     2
.line	1849	gettabup      r2    u0   k70 ; k70 = "tostring"
.line	1849	getupval      r3    u2
.line	1849	call          r2     2     0
.line	1849	call          r0     0     1
.line	1849	getupval      r0    u3
.line	1849	self          r0    r0   k71 ; k71 = "ShowVehicleModel"
.line	1849	getupval      r2    u2
.line	1849	getupval      r3    u4
.line	1849	getupval      r4    u5
.line	1849	loadnil       r5     0
.line	1849	call          r0     6     1
.line	1849	getupval      r0    u6
.line	1849	test          r0     0
.line	1849	jmp            0  l110
.line	1849	getupval      r0    u6
.line	1849	call          r0     1     1
.label	l110
.line	1849	return        r0     1
.line	1849	move          r0    r0
.line	1849	move          r0    r0
.line	1849	move          r0    r0
.line	1849	move          r0    r0
.line	1849	return        r0     1

.function	main/f96

.source	null
.linedefined	1878
.lastlinedefined	1887
.numparams	3
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true
.upvalue	"U2"	10	true
.upvalue	"U3"	1	true

.constant	k0	"slua"
.constant	k1	"getMicroseconds"
.constant	k2	"GetHallDepotItemDataByInsID"
.constant	k3	"AvatarChange"
.constant	k4	"resID"
.constant	k5	"log"
.constant	k6	"bWriteLog"
.constant	k7	212
.constant	k8	41
.constant	k9	161
.constant	k10	219
.constant	k11	102
.constant	k12	95
.constant	k13	100
.constant	k14	132
.constant	k15	203
.constant	k16	198
.constant	k17	252
.constant	k18	105
.constant	k19	93
.constant	k20	167
.constant	k21	188
.constant	k22	46
.constant	k23	28
.constant	k24	15
.constant	k25	225
.constant	k26	238
.constant	k27	131
.constant	k28	80
.constant	k29	19
.constant	k30	191
.constant	k31	243
.constant	k32	216
.constant	k33	229
.constant	k34	99
.constant	k35	226
.constant	k36	155
.constant	k37	51
.constant	k38	82
.constant	k39	"tostring"
.constant	k40	1000

.line	1878	gettabup      r3    u0    k0 ; k0 = "slua"
.line	1878	gettable      r3    r3    k1 ; k1 = "getMicroseconds"
.line	1878	move          r4    r3
.line	1878	call          r4     1     2
.line	1878	getupval      r5    u1
.line	1878	self          r5    r5    k2 ; k2 = "GetHallDepotItemData" (truncated)
.line	1878	move          r7    r1
.line	1878	call          r5     3     2
.line	1878	test          r5     0
.line	1878	jmp            0   l16
.line	1878	getupval      r6    u2
.line	1878	self          r6    r6    k3 ; k3 = "AvatarChange"
.line	1878	gettable      r8    r5    k4 ; k4 = "resID"
.line	1878	move          r9    r2
.line	1878	call          r6     4     1
.label	l16
.line	1878	move          r6    r3
.line	1878	call          r6     1     2
.line	1878	gettabup      r7    u0    k5 ; k5 = "log"
.line	1878	gettabup      r8    u0    k6 ; k6 = "bWriteLog"
.line	1878	test          r8     0
.line	1878	jmp            0   l63
.line	1878	getupval      r8    u3
.line	1878	loadk         r9    k7 ; k7 = 212
.line	1878	loadk        r10    k8 ; k8 = 41
.line	1878	loadk        r11    k9 ; k9 = 161
.line	1878	loadk        r12   k10 ; k10 = 219
.line	1878	loadk        r13   k11 ; k11 = 102
.line	1878	loadk        r14   k12 ; k12 = 95
.line	1878	loadk        r15   k13 ; k13 = 100
.line	1878	loadk        r16   k14 ; k14 = 132
.line	1878	loadk        r17   k15 ; k15 = 203
.line	1878	loadk        r18   k16 ; k16 = 198
.line	1878	loadk        r19   k17 ; k17 = 252
.line	1878	loadk        r20   k18 ; k18 = 105
.line	1878	loadk        r21   k19 ; k19 = 93
.line	1878	loadk        r22   k20 ; k20 = 167
.line	1878	loadk        r23   k21 ; k21 = 188
.line	1878	loadk        r24   k22 ; k22 = 46
.line	1878	loadk        r25   k23 ; k23 = 28
.line	1878	loadk        r26   k24 ; k24 = 15
.line	1878	loadk        r27   k25 ; k25 = 225
.line	1878	loadk        r28   k26 ; k26 = 238
.line	1878	loadk        r29   k27 ; k27 = 131
.line	1878	loadk        r30   k28 ; k28 = 80
.line	1878	loadk        r31   k29 ; k29 = 19
.line	1878	loadk        r32   k30 ; k30 = 191
.line	1878	loadk        r33   k31 ; k31 = 243
.line	1878	loadk        r34   k32 ; k32 = 216
.line	1878	loadk        r35   k33 ; k33 = 229
.line	1878	loadk        r36   k13 ; k13 = 100
.line	1878	loadk        r37   k34 ; k34 = 99
.line	1878	loadk        r38   k35 ; k35 = 226
.line	1878	loadk        r39   k36 ; k36 = 155
.line	1878	loadk        r40   k37 ; k37 = 51
.line	1878	loadk        r41   k24 ; k24 = 15
.line	1878	loadk        r42   k38 ; k38 = 82
.line	1878	call          r8    35     2
.line	1878	gettabup      r9    u0   k39 ; k39 = "tostring"
.line	1878	sub          r10    r6    r4
.line	1878	div          r10   r10   k40 ; k40 = 1000
.line	1878	call          r9     2     2
.line	1878	concat        r8    r8    r9
.label	l63
.line	1878	call          r7     2     1
.line	1878	return        r0     1
.line	1878	move          r0    r0
.line	1878	move          r0    r0
.line	1878	return        r0     1

.function	main/f97

.source	null
.linedefined	1889
.lastlinedefined	1898
.numparams	2
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"getMicroseconds"
.constant	k2	"require"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	141
.constant	k11	232
.constant	k12	206
.constant	k13	242
.constant	k14	99
.constant	k15	16
.constant	k16	252
.constant	k17	153
.constant	k18	39
.constant	k19	7
.constant	k20	25
.constant	k21	209
.constant	k22	161
.constant	k23	169
.constant	k24	111
.constant	k25	18
.constant	k26	180
.constant	k27	251
.constant	k28	253
.constant	k29	226
.constant	k30	94
.constant	k31	225
.constant	k32	158
.constant	k33	47
.constant	k34	6
.constant	k35	26
.constant	k36	"Init"
.constant	k37	"SetNeedAutoRotate"
.constant	k38	"Display"
.constant	k39	"log"
.constant	k40	"bWriteLog"
.constant	k41	212
.constant	k42	41
.constant	k43	219
.constant	k44	102
.constant	k45	95
.constant	k46	100
.constant	k47	132
.constant	k48	203
.constant	k49	198
.constant	k50	105
.constant	k51	93
.constant	k52	167
.constant	k53	188
.constant	k54	46
.constant	k55	28
.constant	k56	15
.constant	k57	238
.constant	k58	131
.constant	k59	80
.constant	k60	19
.constant	k61	191
.constant	k62	243
.constant	k63	216
.constant	k64	229
.constant	k65	155
.constant	k66	51
.constant	k67	82
.constant	k68	"tostring"
.constant	k69	1000

.line	1889	gettabup      r2    u0    k0 ; k0 = "slua"
.line	1889	gettable      r2    r2    k1 ; k1 = "getMicroseconds"
.line	1889	move          r3    r2
.line	1889	call          r3     1     2
.line	1889	gettabup      r4    u0    k2 ; k2 = "require"
.line	1889	getupval      r5    u1
.line	1889	loadk         r6    k3 ; k3 = 224
.line	1889	loadk         r7    k4 ; k4 = 36
.line	1889	loadk         r8    k5 ; k5 = 186
.line	1889	loadk         r9    k6 ; k6 = 218
.line	1889	loadk        r10    k7 ; k7 = 122
.line	1889	loadk        r11    k8 ; k8 = 68
.line	1889	loadk        r12    k9 ; k9 = 40
.line	1889	loadk        r13   k10 ; k10 = 141
.line	1889	loadk        r14   k11 ; k11 = 232
.line	1889	loadk        r15   k12 ; k12 = 206
.line	1889	loadk        r16   k13 ; k13 = 242
.line	1889	loadk        r17   k14 ; k14 = 99
.line	1889	loadk        r18   k15 ; k15 = 16
.line	1889	loadk        r19   k16 ; k16 = 252
.line	1889	loadk        r20   k17 ; k17 = 153
.line	1889	loadk        r21   k18 ; k18 = 39
.line	1889	loadk        r22   k19 ; k19 = 7
.line	1889	loadk        r23   k20 ; k20 = 25
.line	1889	loadk        r24   k21 ; k21 = 209
.line	1889	loadk        r25   k22 ; k22 = 161
.line	1889	loadk        r26   k23 ; k23 = 169
.line	1889	loadk        r27   k24 ; k24 = 111
.line	1889	loadk        r28   k25 ; k25 = 18
.line	1889	loadk        r29   k26 ; k26 = 180
.line	1889	loadk        r30   k27 ; k27 = 251
.line	1889	loadk        r31   k28 ; k28 = 253
.line	1889	loadk        r32   k29 ; k29 = 226
.line	1889	loadk        r33   k14 ; k14 = 99
.line	1889	loadk        r34   k30 ; k30 = 94
.line	1889	loadk        r35   k31 ; k31 = 225
.line	1889	loadk        r36   k32 ; k32 = 158
.line	1889	loadk        r37   k33 ; k33 = 47
.line	1889	loadk        r38   k34 ; k34 = 6
.line	1889	loadk        r39   k35 ; k35 = 26
.line	1889	call          r5    35     2
.line	1889	call          r4     2     2
.line	1889	gettable      r5    r4   k36 ; k36 = "Init"
.line	1889	loadnil       r6     2
.line	1889	loadbool      r9     1     0
.line	1889	call          r5     5     1
.line	1889	gettable      r5    r4   k37 ; k37 = "SetNeedAutoRotate"
.line	1889	loadbool      r6     0     0
.line	1889	call          r5     2     1
.line	1889	gettable      r5    r4   k38 ; k38 = "Display"
.line	1889	move          r6    r1
.line	1889	loadbool      r7     1     0
.line	1889	call          r5     3     1
.line	1889	move          r5    r2
.line	1889	call          r5     1     2
.line	1889	gettabup      r6    u0   k39 ; k39 = "log"
.line	1889	gettabup      r7    u0   k40 ; k40 = "bWriteLog"
.line	1889	test          r7     0
.line	1889	jmp            0  l101
.line	1889	getupval      r7    u1
.line	1889	loadk         r8   k41 ; k41 = 212
.line	1889	loadk         r9   k42 ; k42 = 41
.line	1889	loadk        r10   k22 ; k22 = 161
.line	1889	loadk        r11   k43 ; k43 = 219
.line	1889	loadk        r12   k44 ; k44 = 102
.line	1889	loadk        r13   k45 ; k45 = 95
.line	1889	loadk        r14   k46 ; k46 = 100
.line	1889	loadk        r15   k47 ; k47 = 132
.line	1889	loadk        r16   k48 ; k48 = 203
.line	1889	loadk        r17   k49 ; k49 = 198
.line	1889	loadk        r18   k16 ; k16 = 252
.line	1889	loadk        r19   k50 ; k50 = 105
.line	1889	loadk        r20   k51 ; k51 = 93
.line	1889	loadk        r21   k52 ; k52 = 167
.line	1889	loadk        r22   k53 ; k53 = 188
.line	1889	loadk        r23   k54 ; k54 = 46
.line	1889	loadk        r24   k55 ; k55 = 28
.line	1889	loadk        r25   k56 ; k56 = 15
.line	1889	loadk        r26   k31 ; k31 = 225
.line	1889	loadk        r27   k57 ; k57 = 238
.line	1889	loadk        r28   k58 ; k58 = 131
.line	1889	loadk        r29   k59 ; k59 = 80
.line	1889	loadk        r30   k60 ; k60 = 19
.line	1889	loadk        r31   k61 ; k61 = 191
.line	1889	loadk        r32   k62 ; k62 = 243
.line	1889	loadk        r33   k63 ; k63 = 216
.line	1889	loadk        r34   k64 ; k64 = 229
.line	1889	loadk        r35   k46 ; k46 = 100
.line	1889	loadk        r36   k14 ; k14 = 99
.line	1889	loadk        r37   k29 ; k29 = 226
.line	1889	loadk        r38   k65 ; k65 = 155
.line	1889	loadk        r39   k66 ; k66 = 51
.line	1889	loadk        r40   k56 ; k56 = 15
.line	1889	loadk        r41   k67 ; k67 = 82
.line	1889	call          r7    35     2
.line	1889	gettabup      r8    u0   k68 ; k68 = "tostring"
.line	1889	sub           r9    r5    r3
.line	1889	div           r9    r9   k69 ; k69 = 1000
.line	1889	call          r8     2     2
.line	1889	concat        r7    r7    r8
.label	l101
.line	1889	call          r6     2     1
.line	1889	return        r0     1
.line	1889	move          r0    r0
.line	1889	move          r0    r0
.line	1889	move          r0    r0
.line	1889	return        r0     1

.function	main/f98

.source	null
.linedefined	1900
.lastlinedefined	1905
.numparams	2
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	252
.constant	k15	153
.constant	k16	39
.constant	k17	7
.constant	k18	25
.constant	k19	209
.constant	k20	161
.constant	k21	169
.constant	k22	111
.constant	k23	18
.constant	k24	180
.constant	k25	251
.constant	k26	253
.constant	k27	226
.constant	k28	94
.constant	k29	225
.constant	k30	158
.constant	k31	47
.constant	k32	6
.constant	k33	26
.constant	k34	"Init"
.constant	k35	"SetNeedAutoRotate"
.constant	k36	"Display"

.line	1900	gettabup      r2    u0    k0 ; k0 = "require"
.line	1900	getupval      r3    u1
.line	1900	loadk         r4    k1 ; k1 = 224
.line	1900	loadk         r5    k2 ; k2 = 36
.line	1900	loadk         r6    k3 ; k3 = 186
.line	1900	loadk         r7    k4 ; k4 = 218
.line	1900	loadk         r8    k5 ; k5 = 122
.line	1900	loadk         r9    k6 ; k6 = 68
.line	1900	loadk        r10    k7 ; k7 = 40
.line	1900	loadk        r11    k8 ; k8 = 141
.line	1900	loadk        r12    k9 ; k9 = 232
.line	1900	loadk        r13   k10 ; k10 = 206
.line	1900	loadk        r14   k11 ; k11 = 242
.line	1900	loadk        r15   k12 ; k12 = 99
.line	1900	loadk        r16   k13 ; k13 = 16
.line	1900	loadk        r17   k14 ; k14 = 252
.line	1900	loadk        r18   k15 ; k15 = 153
.line	1900	loadk        r19   k16 ; k16 = 39
.line	1900	loadk        r20   k17 ; k17 = 7
.line	1900	loadk        r21   k18 ; k18 = 25
.line	1900	loadk        r22   k19 ; k19 = 209
.line	1900	loadk        r23   k20 ; k20 = 161
.line	1900	loadk        r24   k21 ; k21 = 169
.line	1900	loadk        r25   k22 ; k22 = 111
.line	1900	loadk        r26   k23 ; k23 = 18
.line	1900	loadk        r27   k24 ; k24 = 180
.line	1900	loadk        r28   k25 ; k25 = 251
.line	1900	loadk        r29   k26 ; k26 = 253
.line	1900	loadk        r30   k27 ; k27 = 226
.line	1900	loadk        r31   k12 ; k12 = 99
.line	1900	loadk        r32   k28 ; k28 = 94
.line	1900	loadk        r33   k29 ; k29 = 225
.line	1900	loadk        r34   k30 ; k30 = 158
.line	1900	loadk        r35   k31 ; k31 = 47
.line	1900	loadk        r36   k32 ; k32 = 6
.line	1900	loadk        r37   k33 ; k33 = 26
.line	1900	call          r3    35     2
.line	1900	call          r2     2     2
.line	1900	gettable      r3    r2   k34 ; k34 = "Init"
.line	1900	call          r3     1     1
.line	1900	gettable      r3    r2   k35 ; k35 = "SetNeedAutoRotate"
.line	1900	loadbool      r4     0     0
.line	1900	call          r3     2     1
.line	1900	gettable      r3    r2   k36 ; k36 = "Display"
.line	1900	move          r4    r1
.line	1900	loadbool      r5     1     0
.line	1900	call          r3     3     1
.line	1900	return        r0     1
.line	1900	move          r0    r0
.line	1900	move          r0    r0
.line	1900	return        r0     1

.function	main/f99

.source	null
.linedefined	1907
.lastlinedefined	1912
.numparams	2
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	141
.constant	k9	232
.constant	k10	206
.constant	k11	242
.constant	k12	99
.constant	k13	16
.constant	k14	252
.constant	k15	153
.constant	k16	39
.constant	k17	7
.constant	k18	25
.constant	k19	209
.constant	k20	161
.constant	k21	169
.constant	k22	111
.constant	k23	18
.constant	k24	180
.constant	k25	251
.constant	k26	253
.constant	k27	226
.constant	k28	94
.constant	k29	225
.constant	k30	158
.constant	k31	47
.constant	k32	6
.constant	k33	26
.constant	k34	"Init"
.constant	k35	"SetNeedAutoRotate"
.constant	k36	"Display"

.line	1907	gettabup      r2    u0    k0 ; k0 = "require"
.line	1907	getupval      r3    u1
.line	1907	loadk         r4    k1 ; k1 = 224
.line	1907	loadk         r5    k2 ; k2 = 36
.line	1907	loadk         r6    k3 ; k3 = 186
.line	1907	loadk         r7    k4 ; k4 = 218
.line	1907	loadk         r8    k5 ; k5 = 122
.line	1907	loadk         r9    k6 ; k6 = 68
.line	1907	loadk        r10    k7 ; k7 = 40
.line	1907	loadk        r11    k8 ; k8 = 141
.line	1907	loadk        r12    k9 ; k9 = 232
.line	1907	loadk        r13   k10 ; k10 = 206
.line	1907	loadk        r14   k11 ; k11 = 242
.line	1907	loadk        r15   k12 ; k12 = 99
.line	1907	loadk        r16   k13 ; k13 = 16
.line	1907	loadk        r17   k14 ; k14 = 252
.line	1907	loadk        r18   k15 ; k15 = 153
.line	1907	loadk        r19   k16 ; k16 = 39
.line	1907	loadk        r20   k17 ; k17 = 7
.line	1907	loadk        r21   k18 ; k18 = 25
.line	1907	loadk        r22   k19 ; k19 = 209
.line	1907	loadk        r23   k20 ; k20 = 161
.line	1907	loadk        r24   k21 ; k21 = 169
.line	1907	loadk        r25   k22 ; k22 = 111
.line	1907	loadk        r26   k23 ; k23 = 18
.line	1907	loadk        r27   k24 ; k24 = 180
.line	1907	loadk        r28   k25 ; k25 = 251
.line	1907	loadk        r29   k26 ; k26 = 253
.line	1907	loadk        r30   k27 ; k27 = 226
.line	1907	loadk        r31   k12 ; k12 = 99
.line	1907	loadk        r32   k28 ; k28 = 94
.line	1907	loadk        r33   k29 ; k29 = 225
.line	1907	loadk        r34   k30 ; k30 = 158
.line	1907	loadk        r35   k31 ; k31 = 47
.line	1907	loadk        r36   k32 ; k32 = 6
.line	1907	loadk        r37   k33 ; k33 = 26
.line	1907	call          r3    35     2
.line	1907	call          r2     2     2
.line	1907	gettable      r3    r2   k34 ; k34 = "Init"
.line	1907	call          r3     1     1
.line	1907	gettable      r3    r2   k35 ; k35 = "SetNeedAutoRotate"
.line	1907	loadbool      r4     0     0
.line	1907	call          r3     2     1
.line	1907	gettable      r3    r2   k36 ; k36 = "Display"
.line	1907	move          r4    r1
.line	1907	loadbool      r5     1     0
.line	1907	call          r3     3     1
.line	1907	return        r0     1
.line	1907	move          r0    r0
.line	1907	return        r0     1

.function	main/f100

.source	null
.linedefined	1914
.lastlinedefined	1918
.numparams	2
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"tonumber"
.constant	k1	32

.line	1914	gettabup      r2    u0    k0 ; k0 = "tonumber"
.line	1914	move          r3    r1
.line	1914	call          r2     2     2
.line	1914	shr           r2    r2    k1 ; k1 = 32
.line	1914	return        r2     2
.line	1914	return        r0     1
.line	1914	move          r0    r0
.line	1914	move          r0    r0
.line	1914	return        r0     1

.function	main/f101

.source	null
.linedefined	1920
.lastlinedefined	1923
.numparams	2
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"tonumber"
.constant	k1	524287

.line	1920	gettabup      r2    u0    k0 ; k0 = "tonumber"
.line	1920	move          r3    r1
.line	1920	call          r2     2     2
.line	1920	band          r3    r2    k1 ; k1 = 524287
.line	1920	return        r3     2
.line	1920	return        r0     1
.line	1920	move          r0    r0
.line	1920	move          r0    r0
.line	1920	move          r0    r0
.line	1920	move          r0    r0
.line	1920	return        r0     1

.function	main/f102

.source	null
.linedefined	1925
.lastlinedefined	1936
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	"SortConfig"
.constant	k46	"IsInInheritMode"
.constant	k47	"SortPreference_Inherit"
.constant	k48	"subTabId"
.constant	k49	"SortPreference"

.line	1925	gettabup      r2    u0    k0 ; k0 = "require"
.line	1925	gettabup      r3    u0    k1 ; k1 = "table"
.line	1925	gettable      r3    r3    k2 ; k2 = "concat"
.line	1925	newtable      r4     1     0
.line	1925	getupval      r5    u1
.line	1925	loadk         r6    k3 ; k3 = 224
.line	1925	loadk         r7    k4 ; k4 = 36
.line	1925	loadk         r8    k5 ; k5 = 186
.line	1925	loadk         r9    k6 ; k6 = 218
.line	1925	loadk        r10    k7 ; k7 = 122
.line	1925	loadk        r11    k8 ; k8 = 68
.line	1925	loadk        r12    k9 ; k9 = 40
.line	1925	loadk        r13   k10 ; k10 = 146
.line	1925	loadk        r14   k11 ; k11 = 235
.line	1925	loadk        r15   k12 ; k12 = 220
.line	1925	loadk        r16   k13 ; k13 = 250
.line	1925	loadk        r17   k14 ; k14 = 46
.line	1925	loadk        r18   k15 ; k15 = 82
.line	1925	loadk        r19   k16 ; k16 = 242
.line	1925	loadk        r20   k17 ; k17 = 136
.line	1925	loadk        r21   k18 ; k18 = 47
.line	1925	loadk        r22   k19 ; k19 = 16
.line	1925	loadk        r23   k20 ; k20 = 86
.line	1925	loadk        r24   k21 ; k21 = 212
.line	1925	loadk        r25   k22 ; k22 = 238
.line	1925	loadk        r26   k23 ; k23 = 150
.line	1925	loadk        r27   k24 ; k24 = 100
.line	1925	loadk        r28   k25 ; k25 = 4
.line	1925	loadk        r29   k26 ; k26 = 190
.line	1925	loadk        r30   k27 ; k27 = 245
.line	1925	loadk        r31   k12 ; k12 = 220
.line	1925	loadk        r32   k28 ; k28 = 165
.line	1925	loadk        r33   k29 ; k29 = 124
.line	1925	loadk        r34   k30 ; k30 = 65
.line	1925	loadk        r35   k31 ; k31 = 234
.line	1925	loadk        r36   k23 ; k23 = 150
.line	1925	loadk        r37   k32 ; k32 = 53
.line	1925	loadk        r38   k33 ; k33 = 60
.line	1925	loadk        r39   k34 ; k34 = 31
.line	1925	loadk        r40   k35 ; k35 = 210
.line	1925	loadk        r41   k36 ; k36 = 237
.line	1925	loadk        r42   k37 ; k37 = 144
.line	1925	loadk        r43   k38 ; k38 = 98
.line	1925	loadk        r44   k39 ; k39 = 9
.line	1925	loadk        r45   k40 ; k40 = 163
.line	1925	call          r5    41     2
.line	1925	getupval      r6    u1
.line	1925	loadk         r7   k41 ; k41 = 230
.line	1925	loadk         r8   k42 ; k42 = 23
.line	1925	loadk         r9   k43 ; k43 = 189
.line	1925	loadk        r10    k6 ; k6 = 218
.line	1925	loadk        r11   k44 ; k44 = 99
.line	1925	call          r6     6     0
.line	1925	setlist       r4     0     1
.line	1925	call          r3     2     2
.line	1925	call          r2     2     2
.line	1925	gettable      r3    r2   k45 ; k45 = "SortConfig"
.line	1925	test          r3     0
.line	1925	jmp            0   l81
.line	1925	test          r1     0
.line	1925	jmp            0   l81
.line	1925	self          r4    r0   k46 ; k46 = "IsInInheritMode"
.line	1925	call          r4     2     2
.line	1925	test          r4     0
.line	1925	jmp            0   l74
.line	1925	gettable      r4    r3   k47 ; k47 = "SortPreference_Inher" (truncated)
.line	1925	test          r4     0
.line	1925	jmp            0   l72
.line	1925	gettable      r4    r3   k47 ; k47 = "SortPreference_Inher" (truncated)
.line	1925	gettable      r5    r1   k48 ; k48 = "subTabId"
.line	1925	gettable      r4    r4    r5
.label	l72
.line	1925	return        r4     2
.line	1925	jmp            0   l81
.label	l74
.line	1925	gettable      r4    r3   k49 ; k49 = "SortPreference"
.line	1925	test          r4     0
.line	1925	jmp            0   l80
.line	1925	gettable      r4    r3   k49 ; k49 = "SortPreference"
.line	1925	gettable      r5    r1   k48 ; k48 = "subTabId"
.line	1925	gettable      r4    r4    r5
.label	l80
.line	1925	return        r4     2
.label	l81
.line	1925	loadnil       r4     0
.line	1925	return        r4     2
.line	1925	return        r0     1
.line	1925	move          r0    r0
.line	1925	move          r0    r0
.line	1925	move          r0    r0
.line	1925	move          r0    r0
.line	1925	return        r0     1

.function	main/f103

.source	null
.linedefined	1938
.lastlinedefined	1950
.numparams	3
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	"SortConfig"
.constant	k46	"IsInInheritMode"
.constant	k47	"SortPreference_Inherit"
.constant	k48	"subTabId"
.constant	k49	"SortPreference"

.line	1938	gettabup      r3    u0    k0 ; k0 = "require"
.line	1938	gettabup      r4    u0    k1 ; k1 = "table"
.line	1938	gettable      r4    r4    k2 ; k2 = "concat"
.line	1938	newtable      r5     1     0
.line	1938	getupval      r6    u1
.line	1938	loadk         r7    k3 ; k3 = 224
.line	1938	loadk         r8    k4 ; k4 = 36
.line	1938	loadk         r9    k5 ; k5 = 186
.line	1938	loadk        r10    k6 ; k6 = 218
.line	1938	loadk        r11    k7 ; k7 = 122
.line	1938	loadk        r12    k8 ; k8 = 68
.line	1938	loadk        r13    k9 ; k9 = 40
.line	1938	loadk        r14   k10 ; k10 = 146
.line	1938	loadk        r15   k11 ; k11 = 235
.line	1938	loadk        r16   k12 ; k12 = 220
.line	1938	loadk        r17   k13 ; k13 = 250
.line	1938	loadk        r18   k14 ; k14 = 46
.line	1938	loadk        r19   k15 ; k15 = 82
.line	1938	loadk        r20   k16 ; k16 = 242
.line	1938	loadk        r21   k17 ; k17 = 136
.line	1938	loadk        r22   k18 ; k18 = 47
.line	1938	loadk        r23   k19 ; k19 = 16
.line	1938	loadk        r24   k20 ; k20 = 86
.line	1938	loadk        r25   k21 ; k21 = 212
.line	1938	loadk        r26   k22 ; k22 = 238
.line	1938	loadk        r27   k23 ; k23 = 150
.line	1938	loadk        r28   k24 ; k24 = 100
.line	1938	loadk        r29   k25 ; k25 = 4
.line	1938	loadk        r30   k26 ; k26 = 190
.line	1938	loadk        r31   k27 ; k27 = 245
.line	1938	loadk        r32   k12 ; k12 = 220
.line	1938	loadk        r33   k28 ; k28 = 165
.line	1938	loadk        r34   k29 ; k29 = 124
.line	1938	loadk        r35   k30 ; k30 = 65
.line	1938	loadk        r36   k31 ; k31 = 234
.line	1938	loadk        r37   k23 ; k23 = 150
.line	1938	loadk        r38   k32 ; k32 = 53
.line	1938	loadk        r39   k33 ; k33 = 60
.line	1938	loadk        r40   k34 ; k34 = 31
.line	1938	loadk        r41   k35 ; k35 = 210
.line	1938	loadk        r42   k36 ; k36 = 237
.line	1938	loadk        r43   k37 ; k37 = 144
.line	1938	loadk        r44   k38 ; k38 = 98
.line	1938	loadk        r45   k39 ; k39 = 9
.line	1938	loadk        r46   k40 ; k40 = 163
.line	1938	call          r6    41     2
.line	1938	getupval      r7    u1
.line	1938	loadk         r8   k41 ; k41 = 230
.line	1938	loadk         r9   k42 ; k42 = 23
.line	1938	loadk        r10   k43 ; k43 = 189
.line	1938	loadk        r11    k6 ; k6 = 218
.line	1938	loadk        r12   k44 ; k44 = 99
.line	1938	call          r7     6     0
.line	1938	setlist       r5     0     1
.line	1938	call          r4     2     2
.line	1938	call          r3     2     2
.line	1938	gettable      r4    r3   k45 ; k45 = "SortConfig"
.line	1938	test          r4     0
.line	1938	jmp            0   l83
.line	1938	test          r1     0
.line	1938	jmp            0   l83
.line	1938	self          r5    r0   k46 ; k46 = "IsInInheritMode"
.line	1938	call          r5     2     2
.line	1938	test          r5     0
.line	1938	jmp            0   l75
.line	1938	gettable      r5    r4   k47 ; k47 = "SortPreference_Inher" (truncated)
.line	1938	test          r5     1
.line	1938	jmp            0   l70
.line	1938	newtable      r5     0     0
.label	l70
.line	1938	settable      r4   k47    r5 ; k47 = "SortPreference_Inher" (truncated)
.line	1938	gettable      r5    r4   k47 ; k47 = "SortPreference_Inher" (truncated)
.line	1938	gettable      r6    r1   k48 ; k48 = "subTabId"
.line	1938	settable      r5    r6    r2
.line	1938	jmp            0   l83
.label	l75
.line	1938	gettable      r5    r4   k49 ; k49 = "SortPreference"
.line	1938	test          r5     1
.line	1938	jmp            0   l79
.line	1938	newtable      r5     0     0
.label	l79
.line	1938	settable      r4   k49    r5 ; k49 = "SortPreference"
.line	1938	gettable      r5    r4   k49 ; k49 = "SortPreference"
.line	1938	gettable      r6    r1   k48 ; k48 = "subTabId"
.line	1938	settable      r5    r6    r2
.label	l83
.line	1938	return        r0     1
.line	1938	move          r0    r0
.line	1938	move          r0    r0
.line	1938	move          r0    r0
.line	1938	move          r0    r0
.line	1938	return        r0     1

.function	main/f104

.source	null
.linedefined	1952
.lastlinedefined	1963
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	"SortConfig"
.constant	k46	"IsInInheritMode"
.constant	k47	"SortPreferenceByMatch_Inherit"
.constant	k48	1
.constant	k49	"SortPreferenceByMatch"

.line	1952	gettabup      r1    u0    k0 ; k0 = "require"
.line	1952	gettabup      r2    u0    k1 ; k1 = "table"
.line	1952	gettable      r2    r2    k2 ; k2 = "concat"
.line	1952	newtable      r3     1     0
.line	1952	getupval      r4    u1
.line	1952	loadk         r5    k3 ; k3 = 224
.line	1952	loadk         r6    k4 ; k4 = 36
.line	1952	loadk         r7    k5 ; k5 = 186
.line	1952	loadk         r8    k6 ; k6 = 218
.line	1952	loadk         r9    k7 ; k7 = 122
.line	1952	loadk        r10    k8 ; k8 = 68
.line	1952	loadk        r11    k9 ; k9 = 40
.line	1952	loadk        r12   k10 ; k10 = 146
.line	1952	loadk        r13   k11 ; k11 = 235
.line	1952	loadk        r14   k12 ; k12 = 220
.line	1952	loadk        r15   k13 ; k13 = 250
.line	1952	loadk        r16   k14 ; k14 = 46
.line	1952	loadk        r17   k15 ; k15 = 82
.line	1952	loadk        r18   k16 ; k16 = 242
.line	1952	loadk        r19   k17 ; k17 = 136
.line	1952	loadk        r20   k18 ; k18 = 47
.line	1952	loadk        r21   k19 ; k19 = 16
.line	1952	loadk        r22   k20 ; k20 = 86
.line	1952	loadk        r23   k21 ; k21 = 212
.line	1952	loadk        r24   k22 ; k22 = 238
.line	1952	loadk        r25   k23 ; k23 = 150
.line	1952	loadk        r26   k24 ; k24 = 100
.line	1952	loadk        r27   k25 ; k25 = 4
.line	1952	loadk        r28   k26 ; k26 = 190
.line	1952	loadk        r29   k27 ; k27 = 245
.line	1952	loadk        r30   k12 ; k12 = 220
.line	1952	loadk        r31   k28 ; k28 = 165
.line	1952	loadk        r32   k29 ; k29 = 124
.line	1952	loadk        r33   k30 ; k30 = 65
.line	1952	loadk        r34   k31 ; k31 = 234
.line	1952	loadk        r35   k23 ; k23 = 150
.line	1952	loadk        r36   k32 ; k32 = 53
.line	1952	loadk        r37   k33 ; k33 = 60
.line	1952	loadk        r38   k34 ; k34 = 31
.line	1952	loadk        r39   k35 ; k35 = 210
.line	1952	loadk        r40   k36 ; k36 = 237
.line	1952	loadk        r41   k37 ; k37 = 144
.line	1952	loadk        r42   k38 ; k38 = 98
.line	1952	loadk        r43   k39 ; k39 = 9
.line	1952	loadk        r44   k40 ; k40 = 163
.line	1952	call          r4    41     2
.line	1952	getupval      r5    u1
.line	1952	loadk         r6   k41 ; k41 = 230
.line	1952	loadk         r7   k42 ; k42 = 23
.line	1952	loadk         r8   k43 ; k43 = 189
.line	1952	loadk         r9    k6 ; k6 = 218
.line	1952	loadk        r10   k44 ; k44 = 99
.line	1952	call          r5     6     0
.line	1952	setlist       r3     0     1
.line	1952	call          r2     2     2
.line	1952	call          r1     2     2
.line	1952	gettable      r2    r1   k45 ; k45 = "SortConfig"
.line	1952	test          r2     0
.line	1952	jmp            0   l75
.line	1952	self          r3    r0   k46 ; k46 = "IsInInheritMode"
.line	1952	call          r3     2     2
.line	1952	test          r3     0
.line	1952	jmp            0   l70
.line	1952	gettable      r3    r2   k47 ; k47 = "SortPreferenceByMatc" (truncated)
.line	1952	test          r3     1
.line	1952	jmp            0   l68
.line	1952	loadk         r3   k48 ; k48 = 1
.label	l68
.line	1952	return        r3     2
.line	1952	jmp            0   l75
.label	l70
.line	1952	gettable      r3    r2   k49 ; k49 = "SortPreferenceByMatc" (truncated)
.line	1952	test          r3     1
.line	1952	jmp            0   l74
.line	1952	loadk         r3   k48 ; k48 = 1
.label	l74
.line	1952	return        r3     2
.label	l75
.line	1952	loadnil       r3     0
.line	1952	return        r3     2
.line	1952	return        r0     1
.line	1952	move          r0    r0
.line	1952	move          r0    r0
.line	1952	return        r0     1

.function	main/f105

.source	null
.linedefined	1965
.lastlinedefined	1975
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	"SortConfig"
.constant	k46	"IsInInheritMode"
.constant	k47	"SortPreferenceByMatch_Inherit"
.constant	k48	1
.constant	k49	"SortPreferenceByMatch"

.line	1965	gettabup      r2    u0    k0 ; k0 = "require"
.line	1965	gettabup      r3    u0    k1 ; k1 = "table"
.line	1965	gettable      r3    r3    k2 ; k2 = "concat"
.line	1965	newtable      r4     1     0
.line	1965	getupval      r5    u1
.line	1965	loadk         r6    k3 ; k3 = 224
.line	1965	loadk         r7    k4 ; k4 = 36
.line	1965	loadk         r8    k5 ; k5 = 186
.line	1965	loadk         r9    k6 ; k6 = 218
.line	1965	loadk        r10    k7 ; k7 = 122
.line	1965	loadk        r11    k8 ; k8 = 68
.line	1965	loadk        r12    k9 ; k9 = 40
.line	1965	loadk        r13   k10 ; k10 = 146
.line	1965	loadk        r14   k11 ; k11 = 235
.line	1965	loadk        r15   k12 ; k12 = 220
.line	1965	loadk        r16   k13 ; k13 = 250
.line	1965	loadk        r17   k14 ; k14 = 46
.line	1965	loadk        r18   k15 ; k15 = 82
.line	1965	loadk        r19   k16 ; k16 = 242
.line	1965	loadk        r20   k17 ; k17 = 136
.line	1965	loadk        r21   k18 ; k18 = 47
.line	1965	loadk        r22   k19 ; k19 = 16
.line	1965	loadk        r23   k20 ; k20 = 86
.line	1965	loadk        r24   k21 ; k21 = 212
.line	1965	loadk        r25   k22 ; k22 = 238
.line	1965	loadk        r26   k23 ; k23 = 150
.line	1965	loadk        r27   k24 ; k24 = 100
.line	1965	loadk        r28   k25 ; k25 = 4
.line	1965	loadk        r29   k26 ; k26 = 190
.line	1965	loadk        r30   k27 ; k27 = 245
.line	1965	loadk        r31   k12 ; k12 = 220
.line	1965	loadk        r32   k28 ; k28 = 165
.line	1965	loadk        r33   k29 ; k29 = 124
.line	1965	loadk        r34   k30 ; k30 = 65
.line	1965	loadk        r35   k31 ; k31 = 234
.line	1965	loadk        r36   k23 ; k23 = 150
.line	1965	loadk        r37   k32 ; k32 = 53
.line	1965	loadk        r38   k33 ; k33 = 60
.line	1965	loadk        r39   k34 ; k34 = 31
.line	1965	loadk        r40   k35 ; k35 = 210
.line	1965	loadk        r41   k36 ; k36 = 237
.line	1965	loadk        r42   k37 ; k37 = 144
.line	1965	loadk        r43   k38 ; k38 = 98
.line	1965	loadk        r44   k39 ; k39 = 9
.line	1965	loadk        r45   k40 ; k40 = 163
.line	1965	call          r5    41     2
.line	1965	getupval      r6    u1
.line	1965	loadk         r7   k41 ; k41 = 230
.line	1965	loadk         r8   k42 ; k42 = 23
.line	1965	loadk         r9   k43 ; k43 = 189
.line	1965	loadk        r10    k6 ; k6 = 218
.line	1965	loadk        r11   k44 ; k44 = 99
.line	1965	call          r6     6     0
.line	1965	setlist       r4     0     1
.line	1965	call          r3     2     2
.line	1965	call          r2     2     2
.line	1965	gettable      r3    r2   k45 ; k45 = "SortConfig"
.line	1965	test          r3     0
.line	1965	jmp            0   l73
.line	1965	self          r4    r0   k46 ; k46 = "IsInInheritMode"
.line	1965	call          r4     2     2
.line	1965	test          r4     0
.line	1965	jmp            0   l69
.line	1965	testset       r4    r1     1
.line	1965	jmp            0   l67
.line	1965	loadk         r4   k48 ; k48 = 1
.label	l67
.line	1965	settable      r3   k47    r4 ; k47 = "SortPreferenceByMatc" (truncated)
.line	1965	jmp            0   l73
.label	l69
.line	1965	testset       r4    r1     1
.line	1965	jmp            0   l72
.line	1965	loadk         r4   k48 ; k48 = 1
.label	l72
.line	1965	settable      r3   k49    r4 ; k49 = "SortPreferenceByMatc" (truncated)
.label	l73
.line	1965	return        r0     1
.line	1965	move          r0    r0
.line	1965	move          r0    r0
.line	1965	move          r0    r0
.line	1965	move          r0    r0
.line	1965	return        r0     1

.function	main/f106

.source	null
.linedefined	1977
.lastlinedefined	1998
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"LogicAddScordCard"
.constant	k4	"logic_team_add_score_card"
.constant	k5	"itemType"
.constant	k6	501
.constant	k7	"itemSubType"
.constant	k8	2111
.constant	k9	30010
.constant	k10	30012
.constant	k11	30013
.constant	k12	7011
.constant	k13	30008
.constant	k14	1630
.constant	k15	"Client"
.constant	k16	"GetAOSSHOP"
.constant	k17	"require"
.constant	k18	"table"
.constant	k19	"concat"
.constant	k20	224
.constant	k21	36
.constant	k22	186
.constant	k23	218
.constant	k24	122
.constant	k25	68
.constant	k26	40
.constant	k27	146
.constant	k28	235
.constant	k29	220
.constant	k30	250
.constant	k31	46
.constant	k32	93
.constant	k33	242
.constant	k34	129
.constant	k35	32
.constant	k36	26
.constant	k37	31
.constant	k38	141
.constant	k39	204
.constant	k40	136
.constant	k41	105
.constant	k42	19
.constant	k43	191
.constant	k44	227
.constant	k45	244
.constant	k46	234
.constant	k47	115
.constant	k48	92
.constant	k49	226
.constant	k50	140
.constant	k51	120
.constant	k52	39
.constant	k53	13
.constant	k54	197
.constant	k55	246
.constant	k56	151
.constant	k57	117
.constant	k58	54
.constant	k59	173
.constant	k60	60
.constant	k61	181
.constant	k62	208
.constant	k63	102
.constant	k64	72
.constant	k65	128
.constant	k66	214
.constant	k67	97
.constant	k68	239
.constant	k69	53
.constant	k70	34
.constant	k71	188
.constant	k72	95
.constant	k73	43
.constant	k74	161
.constant	k75	103
.constant	k76	"GetDevicePlatformName"
.constant	k77	"Android"
.constant	k78	"Google"
.constant	k79	"ThirdPartyPayment"
.constant	k80	"IsDefaultUseSeasonAddScoreCard"
.constant	k81	"ItemID"
.constant	k82	"resID"
.constant	k83	"IsDefaultUseTeamAddScoreCard"

.line	1977	test          r1     1
.line	1977	jmp            0    l5
.line	1977	loadbool      r2     1     0
.line	1977	return        r2     2
.label	l5
.line	1977	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1977	gettable      r2    r2    k1 ; k1 = "GetModule"
.line	1977	gettabup      r3    u0    k0 ; k0 = "ModuleManager"
.line	1977	gettable      r3    r3    k2 ; k2 = "LobbyModuleConfig"
.line	1977	gettable      r3    r3    k3 ; k3 = "LogicAddScordCard"
.line	1977	call          r2     2     2
.line	1977	gettabup      r3    u0    k0 ; k0 = "ModuleManager"
.line	1977	gettable      r3    r3    k1 ; k1 = "GetModule"
.line	1977	gettabup      r4    u0    k0 ; k0 = "ModuleManager"
.line	1977	gettable      r4    r4    k2 ; k2 = "LobbyModuleConfig"
.line	1977	gettable      r4    r4    k4 ; k4 = "logic_team_add_score" (truncated)
.line	1977	call          r3     2     2
.line	1977	gettable      r4    r1    k5 ; k5 = "itemType"
.line	1977	eq             1    r4    k6 ; k6 = 501
.line	1977	jmp            0   l38
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             1    r4    k8 ; k8 = 2111
.line	1977	jmp            0   l38
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             1    r4    k9 ; k9 = 30010
.line	1977	jmp            0   l38
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             1    r4   k10 ; k10 = 30012
.line	1977	jmp            0   l38
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             1    r4   k11 ; k11 = 30013
.line	1977	jmp            0   l38
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             1    r4   k12 ; k12 = 7011
.line	1977	jmp            0   l38
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             0    r4   k13 ; k13 = 30008
.line	1977	jmp            0   l41
.label	l38
.line	1977	loadbool      r4     0     0
.line	1977	return        r4     2
.line	1977	jmp            0  l206
.label	l41
.line	1977	gettable      r4    r1    k7 ; k7 = "itemSubType"
.line	1977	eq             0    r4   k14 ; k14 = 1630
.line	1977	jmp            0  l185
.line	1977	gettabup      r4    u0   k15 ; k15 = "Client"
.line	1977	gettable      r4    r4   k16 ; k16 = "GetAOSSHOP"
.line	1977	call          r4     1     2
.line	1977	gettabup      r5    u0   k17 ; k17 = "require"
.line	1977	gettabup      r6    u0   k18 ; k18 = "table"
.line	1977	gettable      r6    r6   k19 ; k19 = "concat"
.line	1977	newtable      r7     1     0
.line	1977	getupval      r8    u1
.line	1977	loadk         r9   k20 ; k20 = 224
.line	1977	loadk        r10   k21 ; k21 = 36
.line	1977	loadk        r11   k22 ; k22 = 186
.line	1977	loadk        r12   k23 ; k23 = 218
.line	1977	loadk        r13   k24 ; k24 = 122
.line	1977	loadk        r14   k25 ; k25 = 68
.line	1977	loadk        r15   k26 ; k26 = 40
.line	1977	loadk        r16   k27 ; k27 = 146
.line	1977	loadk        r17   k28 ; k28 = 235
.line	1977	loadk        r18   k29 ; k29 = 220
.line	1977	loadk        r19   k30 ; k30 = 250
.line	1977	loadk        r20   k31 ; k31 = 46
.line	1977	loadk        r21   k32 ; k32 = 93
.line	1977	loadk        r22   k33 ; k33 = 242
.line	1977	loadk        r23   k34 ; k34 = 129
.line	1977	loadk        r24   k35 ; k35 = 32
.line	1977	loadk        r25   k36 ; k36 = 26
.line	1977	loadk        r26   k37 ; k37 = 31
.line	1977	loadk        r27   k38 ; k38 = 141
.line	1977	loadk        r28   k39 ; k39 = 204
.line	1977	loadk        r29   k40 ; k40 = 136
.line	1977	loadk        r30   k41 ; k41 = 105
.line	1977	loadk        r31   k42 ; k42 = 19
.line	1977	loadk        r32   k43 ; k43 = 191
.line	1977	loadk        r33   k44 ; k44 = 227
.line	1977	loadk        r34   k45 ; k45 = 244
.line	1977	loadk        r35   k46 ; k46 = 234
.line	1977	loadk        r36   k47 ; k47 = 115
.line	1977	loadk        r37   k48 ; k48 = 92
.line	1977	loadk        r38   k49 ; k49 = 226
.line	1977	loadk        r39   k50 ; k50 = 140
.line	1977	loadk        r40   k51 ; k51 = 120
.line	1977	loadk        r41   k52 ; k52 = 39
.line	1977	loadk        r42   k53 ; k53 = 13
.line	1977	loadk        r43   k54 ; k54 = 197
.line	1977	loadk        r44   k55 ; k55 = 246
.line	1977	loadk        r45   k56 ; k56 = 151
.line	1977	loadk        r46   k57 ; k57 = 117
.line	1977	loadk        r47   k58 ; k58 = 54
.line	1977	loadk        r48   k59 ; k59 = 173
.line	1977	call          r8    41     2
.line	1977	getupval      r9    u1
.line	1977	loadk        r10   k49 ; k49 = 226
.line	1977	loadk        r11   k60 ; k60 = 60
.line	1977	loadk        r12   k61 ; k61 = 181
.line	1977	loadk        r13   k62 ; k62 = 208
.line	1977	loadk        r14   k63 ; k63 = 102
.line	1977	loadk        r15   k32 ; k32 = 93
.line	1977	loadk        r16   k64 ; k64 = 72
.line	1977	loadk        r17   k65 ; k65 = 128
.line	1977	loadk        r18   k46 ; k46 = 234
.line	1977	loadk        r19   k39 ; k39 = 204
.line	1977	loadk        r20   k66 ; k66 = 214
.line	1977	loadk        r21   k67 ; k67 = 97
.line	1977	loadk        r22   k32 ; k32 = 93
.line	1977	loadk        r23   k68 ; k68 = 239
.line	1977	loadk        r24   k65 ; k65 = 128
.line	1977	loadk        r25   k69 ; k69 = 53
.line	1977	call          r9    17     0
.line	1977	setlist       r7     0     1
.line	1977	call          r6     2     2
.line	1977	call          r5     2     2
.line	1977	gettabup      r6    u0   k17 ; k17 = "require"
.line	1977	gettabup      r7    u0   k18 ; k18 = "table"
.line	1977	gettable      r7    r7   k19 ; k19 = "concat"
.line	1977	newtable      r8     1     0
.line	1977	getupval      r9    u1
.line	1977	loadk        r10   k20 ; k20 = 224
.line	1977	loadk        r11   k21 ; k21 = 36
.line	1977	loadk        r12   k22 ; k22 = 186
.line	1977	loadk        r13   k23 ; k23 = 218
.line	1977	loadk        r14   k24 ; k24 = 122
.line	1977	loadk        r15   k25 ; k25 = 68
.line	1977	loadk        r16   k26 ; k26 = 40
.line	1977	loadk        r17   k27 ; k27 = 146
.line	1977	loadk        r18   k28 ; k28 = 235
.line	1977	loadk        r19   k29 ; k29 = 220
.line	1977	loadk        r20   k30 ; k30 = 250
.line	1977	loadk        r21   k31 ; k31 = 46
.line	1977	loadk        r22   k32 ; k32 = 93
.line	1977	loadk        r23   k33 ; k33 = 242
.line	1977	loadk        r24   k34 ; k34 = 129
.line	1977	loadk        r25   k35 ; k35 = 32
.line	1977	loadk        r26   k36 ; k36 = 26
.line	1977	loadk        r27   k37 ; k37 = 31
.line	1977	loadk        r28   k38 ; k38 = 141
.line	1977	loadk        r29   k39 ; k39 = 204
.line	1977	loadk        r30   k40 ; k40 = 136
.line	1977	loadk        r31   k41 ; k41 = 105
.line	1977	loadk        r32   k42 ; k42 = 19
.line	1977	loadk        r33   k43 ; k43 = 191
.line	1977	loadk        r34   k44 ; k44 = 227
.line	1977	loadk        r35   k45 ; k45 = 244
.line	1977	loadk        r36   k46 ; k46 = 234
.line	1977	loadk        r37   k47 ; k47 = 115
.line	1977	loadk        r38   k48 ; k48 = 92
.line	1977	loadk        r39   k49 ; k49 = 226
.line	1977	loadk        r40   k50 ; k50 = 140
.line	1977	loadk        r41   k51 ; k51 = 120
.line	1977	loadk        r42   k70 ; k70 = 34
.line	1977	loadk        r43   k52 ; k52 = 39
.line	1977	loadk        r44   k20 ; k20 = 224
.line	1977	loadk        r45   k39 ; k39 = 204
.line	1977	loadk        r46   k71 ; k71 = 188
.line	1977	loadk        r47   k72 ; k72 = 95
.line	1977	loadk        r48   k58 ; k58 = 54
.line	1977	loadk        r49   k50 ; k50 = 140
.line	1977	call          r9    41     2
.line	1977	getupval     r10    u1
.line	1977	loadk        r11   k49 ; k49 = 226
.line	1977	loadk        r12   k73 ; k73 = 43
.line	1977	loadk        r13   k74 ; k74 = 161
.line	1977	loadk        r14   k62 ; k62 = 208
.line	1977	loadk        r15   k75 ; k75 = 103
.line	1977	call         r10     6     0
.line	1977	setlist       r8     0     1
.line	1977	call          r7     2     2
.line	1977	call          r6     2     2
.line	1977	gettabup      r7    u0   k15 ; k15 = "Client"
.line	1977	gettable      r7    r7   k76 ; k76 = "GetDevicePlatformNam" (truncated)
.line	1977	call          r7     1     2
.line	1977	gettable      r8    r5   k77 ; k77 = "Android"
.line	1977	eq             0    r7    r8
.line	1977	jmp            0  l206
.line	1977	gettable      r7    r6   k78 ; k78 = "Google"
.line	1977	eq             1    r4    r7
.line	1977	jmp            0  l206
.line	1977	gettable      r7    r6   k79 ; k79 = "ThirdPartyPayment"
.line	1977	eq             1    r4    r7
.line	1977	jmp            0  l206
.line	1977	loadbool      r7     0     0
.line	1977	return        r7     2
.line	1977	jmp            0  l206
.label	l185
.line	1977	self          r4    r2   k80 ; k80 = "IsDefaultUseSeasonAd" (truncated)
.line	1977	gettable      r6    r1   k81 ; k81 = "ItemID"
.line	1977	test          r6     1
.line	1977	jmp            0  l190
.line	1977	gettable      r6    r1   k82 ; k82 = "resID"
.label	l190
.line	1977	call          r4     3     2
.line	1977	test          r4     0
.line	1977	jmp            0  l196
.line	1977	loadbool      r4     0     0
.line	1977	return        r4     2
.line	1977	jmp            0  l206
.label	l196
.line	1977	self          r4    r3   k83 ; k83 = "IsDefaultUseTeamAddS" (truncated)
.line	1977	gettable      r6    r1   k81 ; k81 = "ItemID"
.line	1977	test          r6     1
.line	1977	jmp            0  l201
.line	1977	gettable      r6    r1   k82 ; k82 = "resID"
.label	l201
.line	1977	call          r4     3     2
.line	1977	test          r4     0
.line	1977	jmp            0  l206
.line	1977	loadbool      r4     0     0
.line	1977	return        r4     2
.label	l206
.line	1977	loadbool      r4     1     0
.line	1977	return        r4     2
.line	1977	return        r0     1
.line	1977	move          r0    r0
.line	1977	move          r0    r0
.line	1977	move          r0    r0
.line	1977	return        r0     1

.function	main/f107

.source	null
.linedefined	2000
.lastlinedefined	2011
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"Lobby_camera_manager_module"
.constant	k4	"GameStatus"
.constant	k5	"IsInMainCity"
.constant	k6	"SwitchCamera"
.constant	k7	"Enum_CameraID"
.constant	k8	"Lobby_Team"
.constant	k9	"currentCameraID"
.constant	k10	"Lobby_Default"
.constant	k11	0.7

.line	2000	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	2000	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	2000	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	2000	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	2000	gettable      r2    r2    k3 ; k3 = "Lobby_camera_manager" (truncated)
.line	2000	call          r1     2     2
.line	2000	gettabup      r2    u0    k4 ; k4 = "GameStatus"
.line	2000	gettable      r2    r2    k5 ; k5 = "IsInMainCity"
.line	2000	call          r2     1     2
.line	2000	test          r2     0
.line	2000	jmp            0   l17
.line	2000	self          r2    r1    k6 ; k6 = "SwitchCamera"
.line	2000	gettable      r4    r1    k7 ; k7 = "Enum_CameraID"
.line	2000	gettable      r4    r4    k8 ; k8 = "Lobby_Team"
.line	2000	call          r2     3     1
.line	2000	jmp            0   l37
.label	l17
.line	2000	gettable      r2    r1    k9 ; k9 = "currentCameraID"
.line	2000	gettable      r3    r1    k7 ; k7 = "Enum_CameraID"
.line	2000	gettable      r3    r3    k8 ; k8 = "Lobby_Team"
.line	2000	eq             1    r2    r3
.line	2000	jmp            0   l37
.line	2000	gettable      r2    r1    k9 ; k9 = "currentCameraID"
.line	2000	gettable      r3    r1    k7 ; k7 = "Enum_CameraID"
.line	2000	gettable      r3    r3   k10 ; k10 = "Lobby_Default"
.line	2000	eq             0    r2    r3
.line	2000	jmp            0   l33
.line	2000	self          r2    r1    k6 ; k6 = "SwitchCamera"
.line	2000	gettable      r4    r1    k7 ; k7 = "Enum_CameraID"
.line	2000	gettable      r4    r4    k8 ; k8 = "Lobby_Team"
.line	2000	loadk         r5   k11 ; k11 = 0.7
.line	2000	call          r2     4     1
.line	2000	jmp            0   l37
.label	l33
.line	2000	self          r2    r1    k6 ; k6 = "SwitchCamera"
.line	2000	gettable      r4    r1    k7 ; k7 = "Enum_CameraID"
.line	2000	gettable      r4    r4    k8 ; k8 = "Lobby_Team"
.line	2000	call          r2     3     1
.label	l37
.line	2000	return        r0     1
.line	2000	move          r0    r0
.line	2000	move          r0    r0
.line	2000	return        r0     1

.function	main/f108

.source	null
.linedefined	2013
.lastlinedefined	2028
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	0
.constant	k1	"CDataTable"
.constant	k2	"GetTableData"
.constant	k3	202
.constant	k4	60
.constant	k5	182
.constant	k6	210
.constant	k7	"require"
.constant	k8	"table"
.constant	k9	"concat"
.constant	k10	196
.constant	k11	41
.constant	k12	190
.constant	k13	218
.constant	k14	88
.constant	k15	69
.constant	k16	103
.constant	k17	207
.constant	k18	198
.constant	k19	255
.constant	k20	46
.constant	k21	114
.constant	k22	242
.constant	k23	141
.constant	k24	36
.constant	k25	10
.constant	k26	86
.constant	k27	225
.constant	k28	238
.constant	k29	151
.constant	k30	101
.constant	k31	159
.constant	k32	206
.constant	k33	200
.constant	k34	120
.constant	k35	79
.constant	k36	158
.constant	k37	53
.constant	k38	23
.constant	k39	13
.constant	k40	193
.constant	k41	177
.constant	k42	152
.constant	k43	127
.constant	k44	1
.constant	k45	168
.constant	k46	224
.constant	k47	102
.constant	k48	134
.constant	k49	203
.constant	k50	125
.constant	k51	92
.constant	k52	117
.constant	k53	250
.constant	k54	95
.constant	k55	254
.constant	k56	155
.constant	k57	35
.constant	k58	45
.constant	k59	215
.constant	k60	230
.constant	k61	136
.constant	k62	115
.constant	k63	"ItemType"
.constant	k64	"Enum_Item_Type"
.constant	k65	"EnumType_Mvp_Action"
.constant	k66	"EnumType_Com_Action"

.line	2013	eq             0    r1    k0 ; k0 = 0
.line	2013	jmp            0    l5
.line	2013	loadbool      r2     0     0
.line	2013	return        r2     2
.label	l5
.line	2013	gettabup      r2    u0    k1 ; k1 = "CDataTable"
.line	2013	gettable      r2    r2    k2 ; k2 = "GetTableData"
.line	2013	getupval      r3    u1
.line	2013	loadk         r4    k3 ; k3 = 202
.line	2013	loadk         r5    k4 ; k4 = 60
.line	2013	loadk         r6    k5 ; k5 = 182
.line	2013	loadk         r7    k6 ; k6 = 210
.line	2013	call          r3     5     2
.line	2013	move          r4    r1
.line	2013	call          r2     3     2
.line	2013	test          r2     0
.line	2013	jmp            0  l104
.line	2013	gettabup      r3    u0    k7 ; k7 = "require"
.line	2013	gettabup      r4    u0    k8 ; k8 = "table"
.line	2013	gettable      r4    r4    k9 ; k9 = "concat"
.line	2013	newtable      r5     1     0
.line	2013	getupval      r6    u1
.line	2013	loadk         r7   k10 ; k10 = 196
.line	2013	loadk         r8   k11 ; k11 = 41
.line	2013	loadk         r9   k12 ; k12 = 190
.line	2013	loadk        r10   k13 ; k13 = 218
.line	2013	loadk        r11   k14 ; k14 = 88
.line	2013	loadk        r12   k15 ; k15 = 69
.line	2013	loadk        r13   k16 ; k16 = 103
.line	2013	loadk        r14   k17 ; k17 = 207
.line	2013	loadk        r15    k3 ; k3 = 202
.line	2013	loadk        r16   k18 ; k18 = 198
.line	2013	loadk        r17   k19 ; k19 = 255
.line	2013	loadk        r18   k20 ; k20 = 46
.line	2013	loadk        r19   k21 ; k21 = 114
.line	2013	loadk        r20   k22 ; k22 = 242
.line	2013	loadk        r21   k23 ; k23 = 141
.line	2013	loadk        r22   k24 ; k24 = 36
.line	2013	loadk        r23   k25 ; k25 = 10
.line	2013	loadk        r24   k26 ; k26 = 86
.line	2013	loadk        r25   k27 ; k27 = 225
.line	2013	loadk        r26   k28 ; k28 = 238
.line	2013	loadk        r27   k29 ; k29 = 151
.line	2013	loadk        r28   k30 ; k30 = 101
.line	2013	loadk        r29   k14 ; k14 = 88
.line	2013	loadk        r30   k31 ; k31 = 159
.line	2013	loadk        r31   k22 ; k22 = 242
.line	2013	loadk        r32   k32 ; k32 = 206
.line	2013	loadk        r33   k33 ; k33 = 200
.line	2013	loadk        r34   k34 ; k34 = 120
.line	2013	loadk        r35   k35 ; k35 = 79
.line	2013	loadk        r36   k19 ; k19 = 255
.line	2013	loadk        r37   k36 ; k36 = 158
.line	2013	loadk        r38   k37 ; k37 = 53
.line	2013	loadk        r39   k38 ; k38 = 23
.line	2013	loadk        r40   k39 ; k39 = 13
.line	2013	loadk        r41   k40 ; k40 = 193
.line	2013	loadk        r42   k41 ; k41 = 177
.line	2013	loadk        r43   k42 ; k42 = 152
.line	2013	loadk        r44   k43 ; k43 = 127
.line	2013	loadk        r45   k44 ; k44 = 1
.line	2013	loadk        r46   k45 ; k45 = 168
.line	2013	call          r6    41     2
.line	2013	getupval      r7    u1
.line	2013	loadk         r8   k46 ; k46 = 224
.line	2013	loadk         r9   k47 ; k47 = 102
.line	2013	loadk        r10   k48 ; k48 = 134
.line	2013	loadk        r11   k49 ; k49 = 203
.line	2013	loadk        r12   k50 ; k50 = 125
.line	2013	loadk        r13   k51 ; k51 = 92
.line	2013	loadk        r14   k52 ; k52 = 117
.line	2013	loadk        r15   k17 ; k17 = 207
.line	2013	loadk        r16   k10 ; k10 = 196
.line	2013	loadk        r17   k40 ; k40 = 193
.line	2013	loadk        r18   k53 ; k53 = 250
.line	2013	loadk        r19   k21 ; k21 = 114
.line	2013	loadk        r20   k54 ; k54 = 95
.line	2013	loadk        r21   k55 ; k55 = 254
.line	2013	loadk        r22   k56 ; k56 = 155
.line	2013	loadk        r23   k57 ; k57 = 35
.line	2013	loadk        r24   k44 ; k44 = 1
.line	2013	loadk        r25   k58 ; k58 = 45
.line	2013	loadk        r26   k59 ; k59 = 215
.line	2013	loadk        r27   k60 ; k60 = 230
.line	2013	loadk        r28   k61 ; k61 = 136
.line	2013	loadk        r29   k62 ; k62 = 115
.line	2013	call          r7    23     0
.line	2013	setlist       r5     0     1
.line	2013	call          r4     2     2
.line	2013	call          r3     2     2
.line	2013	gettable      r4    r2   k63 ; k63 = "ItemType"
.line	2013	gettable      r5    r3   k64 ; k64 = "Enum_Item_Type"
.line	2013	gettable      r5    r5   k65 ; k65 = "EnumType_Mvp_Action"
.line	2013	eq             0    r4    r5
.line	2013	jmp            0   l97
.line	2013	loadbool      r4     1     0
.line	2013	return        r4     2
.label	l97
.line	2013	gettable      r4    r2   k63 ; k63 = "ItemType"
.line	2013	gettable      r5    r3   k64 ; k64 = "Enum_Item_Type"
.line	2013	gettable      r5    r5   k66 ; k66 = "EnumType_Com_Action"
.line	2013	eq             0    r4    r5
.line	2013	jmp            0  l104
.line	2013	loadbool      r4     1     0
.line	2013	return        r4     2
.label	l104
.line	2013	loadbool      r3     0     0
.line	2013	return        r3     2
.line	2013	return        r0     1
.line	2013	move          r0    r0
.line	2013	move          r0    r0
.line	2013	move          r0    r0
.line	2013	move          r0    r0
.line	2013	return        r0     1

.function	main/f109

.source	null
.linedefined	2030
.lastlinedefined	2041
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	118
.constant	k30	79
.constant	k31	254
.constant	k32	151
.constant	k33	63
.constant	k34	12
.constant	k35	6
.constant	k36	209
.constant	k37	147
.constant	k38	62
.constant	k39	0
.constant	k40	160
.constant	k41	240
.constant	k42	32
.constant	k43	208
.constant	k44	103
.constant	k45	134
.constant	k46	216
.constant	k47	205
.constant	k48	116
.constant	k49	95
.constant	k50	"GetKnapsackExtInfoByIndex"
.constant	k51	nil
.constant	k52	"avatar_show"

.line	2030	gettabup      r2    u0    k0 ; k0 = "require"
.line	2030	gettabup      r3    u0    k1 ; k1 = "table"
.line	2030	gettable      r3    r3    k2 ; k2 = "concat"
.line	2030	newtable      r4     1     0
.line	2030	getupval      r5    u1
.line	2030	loadk         r6    k3 ; k3 = 224
.line	2030	loadk         r7    k4 ; k4 = 36
.line	2030	loadk         r8    k5 ; k5 = 186
.line	2030	loadk         r9    k6 ; k6 = 218
.line	2030	loadk        r10    k7 ; k7 = 122
.line	2030	loadk        r11    k8 ; k8 = 68
.line	2030	loadk        r12    k9 ; k9 = 40
.line	2030	loadk        r13   k10 ; k10 = 146
.line	2030	loadk        r14   k11 ; k11 = 235
.line	2030	loadk        r15   k12 ; k12 = 220
.line	2030	loadk        r16   k13 ; k13 = 250
.line	2030	loadk        r17   k14 ; k14 = 46
.line	2030	loadk        r18   k15 ; k15 = 82
.line	2030	loadk        r19   k16 ; k16 = 242
.line	2030	loadk        r20   k17 ; k17 = 136
.line	2030	loadk        r21   k18 ; k18 = 47
.line	2030	loadk        r22   k19 ; k19 = 16
.line	2030	loadk        r23   k20 ; k20 = 86
.line	2030	loadk        r24   k21 ; k21 = 212
.line	2030	loadk        r25   k22 ; k22 = 238
.line	2030	loadk        r26   k23 ; k23 = 150
.line	2030	loadk        r27   k24 ; k24 = 100
.line	2030	loadk        r28   k25 ; k25 = 4
.line	2030	loadk        r29   k26 ; k26 = 190
.line	2030	loadk        r30   k27 ; k27 = 245
.line	2030	loadk        r31   k12 ; k12 = 220
.line	2030	loadk        r32   k28 ; k28 = 165
.line	2030	loadk        r33   k29 ; k29 = 118
.line	2030	loadk        r34   k30 ; k30 = 79
.line	2030	loadk        r35   k31 ; k31 = 254
.line	2030	loadk        r36   k32 ; k32 = 151
.line	2030	loadk        r37   k33 ; k33 = 63
.line	2030	loadk        r38   k34 ; k34 = 12
.line	2030	loadk        r39   k35 ; k35 = 6
.line	2030	loadk        r40   k36 ; k36 = 209
.line	2030	loadk        r41   k31 ; k31 = 254
.line	2030	loadk        r42   k37 ; k37 = 147
.line	2030	loadk        r43   k38 ; k38 = 62
.line	2030	loadk        r44   k39 ; k39 = 0
.line	2030	loadk        r45   k40 ; k40 = 160
.line	2030	call          r5    41     2
.line	2030	getupval      r6    u1
.line	2030	loadk         r7   k41 ; k41 = 240
.line	2030	loadk         r8   k42 ; k42 = 32
.line	2030	loadk         r9    k5 ; k5 = 186
.line	2030	loadk        r10   k43 ; k43 = 208
.line	2030	loadk        r11    k7 ; k7 = 122
.line	2030	loadk        r12   k15 ; k15 = 82
.line	2030	loadk        r13   k44 ; k44 = 103
.line	2030	loadk        r14   k45 ; k45 = 134
.line	2030	loadk        r15   k46 ; k46 = 216
.line	2030	loadk        r16   k47 ; k47 = 205
.line	2030	loadk        r17   k13 ; k13 = 250
.line	2030	loadk        r18   k48 ; k48 = 116
.line	2030	loadk        r19   k49 ; k49 = 95
.line	2030	call          r6    14     0
.line	2030	setlist       r4     0     1
.line	2030	call          r3     2     2
.line	2030	call          r2     2     2
.line	2030	self          r3    r2   k50 ; k50 = "GetKnapsackExtInfoBy" (truncated)
.line	2030	move          r5    r0
.line	2030	call          r3     3     2
.line	2030	eq             0    r3   k51 ; k51 = nil
.line	2030	jmp            0   l71
.line	2030	return        r0     1
.label	l71
.line	2030	gettable      r4    r3   k52 ; k52 = "avatar_show"
.line	2030	test          r4     0
.line	2030	jmp            0   l76
.line	2030	gettable      r4    r3   k52 ; k52 = "avatar_show"
.line	2030	gettable      r4    r4    r1
.label	l76
.line	2030	test          r4     1
.line	2030	jmp            0   l79
.line	2030	return        r0     1
.label	l79
.line	2030	return        r4     2
.line	2030	return        r0     1
.line	2030	move          r0    r0
.line	2030	move          r0    r0
.line	2030	move          r0    r0
.line	2030	return        r0     1

.function	main/f110

.source	null
.linedefined	2043
.lastlinedefined	2071
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	20	true

.constant	k0	"require"
.constant	k1	224
.constant	k2	36
.constant	k3	186
.constant	k4	218
.constant	k5	122
.constant	k6	68
.constant	k7	40
.constant	k8	146
.constant	k9	235
.constant	k10	220
.constant	k11	250
.constant	k12	46
.constant	k13	82
.constant	k14	242
.constant	k15	136
.constant	k16	47
.constant	k17	16
.constant	k18	86
.constant	k19	212
.constant	k20	238
.constant	k21	150
.constant	k22	100
.constant	k23	4
.constant	k24	190
.constant	k25	245
.constant	k26	165
.constant	k27	103
.constant	k28	79
.constant	k29	255
.constant	k30	155
.constant	k31	12
.constant	k32	10
.constant	k33	214
.constant	k34	192
.constant	k35	144
.constant	k36	113
.constant	k37	18
.constant	k38	160
.constant	k39	141
.constant	k40	232
.constant	k41	206
.constant	k42	99
.constant	k43	241
.constant	k44	128
.constant	k45	17
.constant	k46	1
.constant	k47	231
.constant	k48	133
.constant	k49	108
.constant	k50	26
.constant	k51	142
.constant	k52	227
.constant	k53	209
.constant	k54	125
.constant	k55	75
.constant	k56	210
.constant	k57	138
.constant	k58	34
.constant	k59	"IsFirstPutOnAircraft"
.constant	k60	"ShowNotice"
.constant	k61	27719
.constant	k62	"LocUtil"
.constant	k63	"LocalizeResFormat"
.constant	k64	27712
.constant	k65	"ItemName"
.constant	k66	"table"
.constant	k67	"concat"
.constant	k68	118
.constant	k69	254
.constant	k70	151
.constant	k71	63
.constant	k72	6
.constant	k73	147
.constant	k74	62
.constant	k75	0
.constant	k76	240
.constant	k77	32
.constant	k78	208
.constant	k79	134
.constant	k80	216
.constant	k81	205
.constant	k82	116
.constant	k83	95
.constant	k84	"GetFashionBagUseIndex"
.constant	k85	"knapsack_ext_vst_skin"
.constant	k86	nil
.constant	k87	"GetValidHallDepotItemDataByInsID"
.constant	k88	"instid"
.constant	k89	"CDataTable"
.constant	k90	"GetTableData"
.constant	k91	202
.constant	k92	60
.constant	k93	182
.constant	k94	"resID"
.constant	k95	193
.constant	k96	45
.constant	k97	167
.constant	k98	203
.constant	k99	66
.constant	k100	80
.constant	k101	132
.constant	k102	239
.constant	k103	248
.constant	k104	91
.constant	k105	137
.constant	k106	22
.constant	k107	27
.constant	k108	215
.constant	k109	"Parachute"
.constant	k110	27713

.line	2043	gettabup      r3    u0    k0 ; k0 = "require"
.line	2043	getupval      r4    u1
.line	2043	loadk         r5    k1 ; k1 = 224
.line	2043	loadk         r6    k2 ; k2 = 36
.line	2043	loadk         r7    k3 ; k3 = 186
.line	2043	loadk         r8    k4 ; k4 = 218
.line	2043	loadk         r9    k5 ; k5 = 122
.line	2043	loadk        r10    k6 ; k6 = 68
.line	2043	loadk        r11    k7 ; k7 = 40
.line	2043	loadk        r12    k8 ; k8 = 146
.line	2043	loadk        r13    k9 ; k9 = 235
.line	2043	loadk        r14   k10 ; k10 = 220
.line	2043	loadk        r15   k11 ; k11 = 250
.line	2043	loadk        r16   k12 ; k12 = 46
.line	2043	loadk        r17   k13 ; k13 = 82
.line	2043	loadk        r18   k14 ; k14 = 242
.line	2043	loadk        r19   k15 ; k15 = 136
.line	2043	loadk        r20   k16 ; k16 = 47
.line	2043	loadk        r21   k17 ; k17 = 16
.line	2043	loadk        r22   k18 ; k18 = 86
.line	2043	loadk        r23   k19 ; k19 = 212
.line	2043	loadk        r24   k20 ; k20 = 238
.line	2043	loadk        r25   k21 ; k21 = 150
.line	2043	loadk        r26   k22 ; k22 = 100
.line	2043	loadk        r27   k23 ; k23 = 4
.line	2043	loadk        r28   k24 ; k24 = 190
.line	2043	loadk        r29   k25 ; k25 = 245
.line	2043	loadk        r30   k10 ; k10 = 220
.line	2043	loadk        r31   k26 ; k26 = 165
.line	2043	loadk        r32   k27 ; k27 = 103
.line	2043	loadk        r33   k28 ; k28 = 79
.line	2043	loadk        r34   k29 ; k29 = 255
.line	2043	loadk        r35   k30 ; k30 = 155
.line	2043	loadk        r36    k2 ; k2 = 36
.line	2043	loadk        r37   k31 ; k31 = 12
.line	2043	loadk        r38   k32 ; k32 = 10
.line	2043	loadk        r39   k33 ; k33 = 214
.line	2043	loadk        r40   k34 ; k34 = 192
.line	2043	loadk        r41   k35 ; k35 = 144
.line	2043	loadk        r42   k36 ; k36 = 113
.line	2043	loadk        r43   k37 ; k37 = 18
.line	2043	loadk        r44   k38 ; k38 = 160
.line	2043	call          r4    41     2
.line	2043	call          r3     2     2
.line	2043	gettabup      r4    u0    k0 ; k0 = "require"
.line	2043	getupval      r5    u1
.line	2043	loadk         r6    k1 ; k1 = 224
.line	2043	loadk         r7    k2 ; k2 = 36
.line	2043	loadk         r8    k3 ; k3 = 186
.line	2043	loadk         r9    k4 ; k4 = 218
.line	2043	loadk        r10    k5 ; k5 = 122
.line	2043	loadk        r11    k6 ; k6 = 68
.line	2043	loadk        r12    k7 ; k7 = 40
.line	2043	loadk        r13   k39 ; k39 = 141
.line	2043	loadk        r14   k40 ; k40 = 232
.line	2043	loadk        r15   k41 ; k41 = 206
.line	2043	loadk        r16   k14 ; k14 = 242
.line	2043	loadk        r17   k42 ; k42 = 99
.line	2043	loadk        r18   k17 ; k17 = 16
.line	2043	loadk        r19   k43 ; k43 = 241
.line	2043	loadk        r20   k44 ; k44 = 128
.line	2043	loadk        r21    k2 ; k2 = 36
.line	2043	loadk        r22   k45 ; k45 = 17
.line	2043	loadk        r23   k46 ; k46 = 1
.line	2043	loadk        r24   k39 ; k39 = 141
.line	2043	loadk        r25   k47 ; k47 = 231
.line	2043	loadk        r26   k48 ; k48 = 133
.line	2043	loadk        r27   k49 ; k49 = 108
.line	2043	loadk        r28   k50 ; k50 = 26
.line	2043	loadk        r29   k51 ; k51 = 142
.line	2043	loadk        r30   k52 ; k52 = 227
.line	2043	loadk        r31   k53 ; k53 = 209
.line	2043	loadk        r32   k20 ; k20 = 238
.line	2043	loadk        r33   k54 ; k54 = 125
.line	2043	loadk        r34   k55 ; k55 = 75
.line	2043	loadk        r35   k56 ; k56 = 210
.line	2043	loadk        r36   k57 ; k57 = 138
.line	2043	loadk        r37   k58 ; k58 = 34
.line	2043	loadk        r38   k32 ; k32 = 10
.line	2043	loadk        r39   k23 ; k23 = 4
.line	2043	loadk        r40   k34 ; k34 = 192
.line	2043	call          r5    36     2
.line	2043	call          r4     2     2
.line	2043	test          r2     0
.line	2043	jmp            0  l103
.line	2043	self          r5    r0   k59 ; k59 = "IsFirstPutOnAircraft"
.line	2043	call          r5     2     2
.line	2043	test          r5     0
.line	2043	jmp            0   l94
.line	2043	gettabup      r5    u0   k60 ; k60 = "ShowNotice"
.line	2043	loadk         r6   k61 ; k61 = 27719
.line	2043	call          r5     2     1
.line	2043	jmp            0  l230
.label	l94
.line	2043	gettabup      r5    u0   k62 ; k62 = "LocUtil"
.line	2043	gettable      r5    r5   k63 ; k63 = "LocalizeResFormat"
.line	2043	loadk         r6   k64 ; k64 = 27712
.line	2043	gettable      r7    r1   k65 ; k65 = "ItemName"
.line	2043	call          r5     3     2
.line	2043	gettabup      r6    u0   k60 ; k60 = "ShowNotice"
.line	2043	move          r7    r5
.line	2043	call          r6     2     1
.line	2043	jmp            0  l230
.label	l103
.line	2043	gettabup      r5    u0    k0 ; k0 = "require"
.line	2043	gettabup      r6    u0   k66 ; k66 = "table"
.line	2043	gettable      r6    r6   k67 ; k67 = "concat"
.line	2043	newtable      r7     1     0
.line	2043	getupval      r8    u1
.line	2043	loadk         r9    k1 ; k1 = 224
.line	2043	loadk        r10    k2 ; k2 = 36
.line	2043	loadk        r11    k3 ; k3 = 186
.line	2043	loadk        r12    k4 ; k4 = 218
.line	2043	loadk        r13    k5 ; k5 = 122
.line	2043	loadk        r14    k6 ; k6 = 68
.line	2043	loadk        r15    k7 ; k7 = 40
.line	2043	loadk        r16    k8 ; k8 = 146
.line	2043	loadk        r17    k9 ; k9 = 235
.line	2043	loadk        r18   k10 ; k10 = 220
.line	2043	loadk        r19   k11 ; k11 = 250
.line	2043	loadk        r20   k12 ; k12 = 46
.line	2043	loadk        r21   k13 ; k13 = 82
.line	2043	loadk        r22   k14 ; k14 = 242
.line	2043	loadk        r23   k15 ; k15 = 136
.line	2043	loadk        r24   k16 ; k16 = 47
.line	2043	loadk        r25   k17 ; k17 = 16
.line	2043	loadk        r26   k18 ; k18 = 86
.line	2043	loadk        r27   k19 ; k19 = 212
.line	2043	loadk        r28   k20 ; k20 = 238
.line	2043	loadk        r29   k21 ; k21 = 150
.line	2043	loadk        r30   k22 ; k22 = 100
.line	2043	loadk        r31   k23 ; k23 = 4
.line	2043	loadk        r32   k24 ; k24 = 190
.line	2043	loadk        r33   k25 ; k25 = 245
.line	2043	loadk        r34   k10 ; k10 = 220
.line	2043	loadk        r35   k26 ; k26 = 165
.line	2043	loadk        r36   k68 ; k68 = 118
.line	2043	loadk        r37   k28 ; k28 = 79
.line	2043	loadk        r38   k69 ; k69 = 254
.line	2043	loadk        r39   k70 ; k70 = 151
.line	2043	loadk        r40   k71 ; k71 = 63
.line	2043	loadk        r41   k31 ; k31 = 12
.line	2043	loadk        r42   k72 ; k72 = 6
.line	2043	loadk        r43   k53 ; k53 = 209
.line	2043	loadk        r44   k69 ; k69 = 254
.line	2043	loadk        r45   k73 ; k73 = 147
.line	2043	loadk        r46   k74 ; k74 = 62
.line	2043	loadk        r47   k75 ; k75 = 0
.line	2043	loadk        r48   k38 ; k38 = 160
.line	2043	call          r8    41     2
.line	2043	getupval      r9    u1
.line	2043	loadk        r10   k76 ; k76 = 240
.line	2043	loadk        r11   k77 ; k77 = 32
.line	2043	loadk        r12    k3 ; k3 = 186
.line	2043	loadk        r13   k78 ; k78 = 208
.line	2043	loadk        r14    k5 ; k5 = 122
.line	2043	loadk        r15   k13 ; k13 = 82
.line	2043	loadk        r16   k27 ; k27 = 103
.line	2043	loadk        r17   k79 ; k79 = 134
.line	2043	loadk        r18   k80 ; k80 = 216
.line	2043	loadk        r19   k81 ; k81 = 205
.line	2043	loadk        r20   k11 ; k11 = 250
.line	2043	loadk        r21   k82 ; k82 = 116
.line	2043	loadk        r22   k83 ; k83 = 95
.line	2043	call          r9    14     0
.line	2043	setlist       r7     0     1
.line	2043	call          r6     2     2
.line	2043	call          r5     2     2
.line	2043	self          r6    r5   k84 ; k84 = "GetFashionBagUseInde" (truncated)
.line	2043	call          r6     2     2
.line	2043	getupval      r7    u2
.line	2043	move          r8    r6
.line	2043	gettable      r9    r4   k85 ; k85 = "knapsack_ext_vst_ski" (truncated)
.line	2043	call          r7     3     2
.line	2043	eq             0    r7   k86 ; k86 = nil
.line	2043	jmp            0  l176
.line	2043	return        r0     1
.label	l176
.line	2043	self          r8    r3   k87 ; k87 = "GetValidHallDepotIte" (truncated)
.line	2043	gettable     r10    r7   k88 ; k88 = "instid"
.line	2043	call          r8     3     2
.line	2043	eq             0    r8   k86 ; k86 = nil
.line	2043	jmp            0  l182
.line	2043	return        r0     1
.label	l182
.line	2043	gettabup      r9    u0   k89 ; k89 = "CDataTable"
.line	2043	gettable      r9    r9   k90 ; k90 = "GetTableData"
.line	2043	getupval     r10    u1
.line	2043	loadk        r11   k91 ; k91 = 202
.line	2043	loadk        r12   k92 ; k92 = 60
.line	2043	loadk        r13   k93 ; k93 = 182
.line	2043	loadk        r14   k56 ; k56 = 210
.line	2043	call         r10     5     2
.line	2043	gettable     r11    r8   k94 ; k94 = "resID"
.line	2043	call          r9     3     2
.line	2043	gettabup     r10    u0   k89 ; k89 = "CDataTable"
.line	2043	gettable     r10   r10   k90 ; k90 = "GetTableData"
.line	2043	getupval     r11    u1
.line	2043	loadk        r12   k95 ; k95 = 193
.line	2043	loadk        r13   k96 ; k96 = 45
.line	2043	loadk        r14   k97 ; k97 = 167
.line	2043	loadk        r15   k98 ; k98 = 203
.line	2043	loadk        r16   k36 ; k36 = 113
.line	2043	loadk        r17   k99 ; k99 = 66
.line	2043	loadk        r18  k100 ; k100 = 80
.line	2043	loadk        r19  k101 ; k101 = 132
.line	2043	loadk        r20  k102 ; k102 = 239
.line	2043	loadk        r21   k34 ; k34 = 192
.line	2043	loadk        r22  k103 ; k103 = 248
.line	2043	loadk        r23   k49 ; k49 = 108
.line	2043	loadk        r24  k104 ; k104 = 91
.line	2043	loadk        r25   k80 ; k80 = 216
.line	2043	loadk        r26  k105 ; k105 = 137
.line	2043	loadk        r27   k77 ; k77 = 32
.line	2043	loadk        r28  k106 ; k106 = 22
.line	2043	loadk        r29  k107 ; k107 = 27
.line	2043	loadk        r30  k108 ; k108 = 215
.line	2043	call         r11    20     2
.line	2043	gettable     r12    r8   k94 ; k94 = "resID"
.line	2043	call         r10     3     2
.line	2043	test         r10     0
.line	2043	jmp            0  l230
.line	2043	gettable     r11   r10  k109 ; k109 = "Parachute"
.line	2043	eq             0   r11   k46 ; k46 = 1
.line	2043	jmp            0  l230
.line	2043	gettabup     r11    u0   k62 ; k62 = "LocUtil"
.line	2043	gettable     r11   r11   k63 ; k63 = "LocalizeResFormat"
.line	2043	loadk        r12  k110 ; k110 = 27713
.line	2043	gettable     r13    r9   k65 ; k65 = "ItemName"
.line	2043	call         r11     3     2
.line	2043	gettabup     r12    u0   k60 ; k60 = "ShowNotice"
.line	2043	move         r13   r11
.line	2043	call         r12     2     1
.label	l230
.line	2043	return        r0     1
.line	2043	gettabup      r0    u0  k110 ; k110 = 27713
.line	2043	return        r0     1

.function	main/f111

.source	null
.linedefined	2073
.lastlinedefined	2082
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	141
.constant	k11	232
.constant	k12	206
.constant	k13	242
.constant	k14	99
.constant	k15	16
.constant	k16	209
.constant	k17	128
.constant	k18	33
.constant	k19	26
.constant	k20	27
.constant	k21	243
.constant	k22	227
.constant	k23	133
.constant	k24	121
.constant	k25	19
.constant	k26	163
.constant	k27	199
.constant	k28	203
.constant	k29	238
.constant	k30	118
.constant	k31	93
.constant	k32	143
.constant	k33	58
.constant	k34	2
.constant	k35	17
.constant	k36	214
.constant	k37	237
.constant	k38	132
.constant	k39	98
.constant	k40	3
.constant	k41	167
.constant	k42	240
.constant	k43	"LoadFileToTable_N"
.constant	k44	"ePlayerPrefsType"
.constant	k45	"eAircraftFirstPutOn"
.constant	k46	nil
.constant	k47	"firstPutOnAircast"
.constant	k48	true
.constant	k49	false
.constant	k50	"SaveTableToFile_N"

.line	2073	gettabup      r1    u0    k0 ; k0 = "require"
.line	2073	gettabup      r2    u0    k1 ; k1 = "table"
.line	2073	gettable      r2    r2    k2 ; k2 = "concat"
.line	2073	newtable      r3     1     0
.line	2073	getupval      r4    u1
.line	2073	loadk         r5    k3 ; k3 = 224
.line	2073	loadk         r6    k4 ; k4 = 36
.line	2073	loadk         r7    k5 ; k5 = 186
.line	2073	loadk         r8    k6 ; k6 = 218
.line	2073	loadk         r9    k7 ; k7 = 122
.line	2073	loadk        r10    k8 ; k8 = 68
.line	2073	loadk        r11    k9 ; k9 = 40
.line	2073	loadk        r12   k10 ; k10 = 141
.line	2073	loadk        r13   k11 ; k11 = 232
.line	2073	loadk        r14   k12 ; k12 = 206
.line	2073	loadk        r15   k13 ; k13 = 242
.line	2073	loadk        r16   k14 ; k14 = 99
.line	2073	loadk        r17   k15 ; k15 = 16
.line	2073	loadk        r18   k16 ; k16 = 209
.line	2073	loadk        r19   k17 ; k17 = 128
.line	2073	loadk        r20   k18 ; k18 = 33
.line	2073	loadk        r21   k19 ; k19 = 26
.line	2073	loadk        r22   k20 ; k20 = 27
.line	2073	loadk        r23   k21 ; k21 = 243
.line	2073	loadk        r24   k22 ; k22 = 227
.line	2073	loadk        r25   k23 ; k23 = 133
.line	2073	loadk        r26   k24 ; k24 = 121
.line	2073	loadk        r27   k25 ; k25 = 19
.line	2073	loadk        r28   k26 ; k26 = 163
.line	2073	loadk        r29   k27 ; k27 = 199
.line	2073	loadk        r30   k28 ; k28 = 203
.line	2073	loadk        r31   k29 ; k29 = 238
.line	2073	loadk        r32   k30 ; k30 = 118
.line	2073	loadk        r33   k31 ; k31 = 93
.line	2073	loadk        r34   k26 ; k26 = 163
.line	2073	loadk        r35   k32 ; k32 = 143
.line	2073	loadk        r36   k33 ; k33 = 58
.line	2073	loadk        r37   k34 ; k34 = 2
.line	2073	loadk        r38   k35 ; k35 = 17
.line	2073	loadk        r39   k36 ; k36 = 214
.line	2073	loadk        r40   k37 ; k37 = 237
.line	2073	loadk        r41   k38 ; k38 = 132
.line	2073	loadk        r42   k39 ; k39 = 98
.line	2073	loadk        r43   k40 ; k40 = 3
.line	2073	loadk        r44   k41 ; k41 = 167
.line	2073	call          r4    41     2
.line	2073	getupval      r5    u1
.line	2073	loadk         r6   k42 ; k42 = 240
.line	2073	call          r5     2     0
.line	2073	setlist       r3     0     1
.line	2073	call          r2     2     2
.line	2073	call          r1     2     2
.line	2073	gettable      r2    r1   k43 ; k43 = "LoadFileToTable_N"
.line	2073	gettable      r3    r1   k44 ; k44 = "ePlayerPrefsType"
.line	2073	gettable      r3    r3   k45 ; k45 = "eAircraftFirstPutOn"
.line	2073	call          r2     2     2
.line	2073	eq             1    r2   k46 ; k46 = nil
.line	2073	jmp            0   l62
.line	2073	gettable      r3    r2   k47 ; k47 = "firstPutOnAircast"
.line	2073	eq             0    r3   k48 ; k48 = true
.line	2073	jmp            0   l72
.label	l62
.line	2073	newtable      r3     0     1
.line	2073	settable      r3   k47   k49 ; k49 = false
.line	2073	move          r2    r3
.line	2073	gettable      r3    r1   k50 ; k50 = "SaveTableToFile_N"
.line	2073	move          r4    r2
.line	2073	gettable      r5    r1   k44 ; k44 = "ePlayerPrefsType"
.line	2073	gettable      r5    r5   k45 ; k45 = "eAircraftFirstPutOn"
.line	2073	call          r3     3     1
.line	2073	loadbool      r3     1     0
.line	2073	return        r3     2
.label	l72
.line	2073	loadbool      r3     0     0
.line	2073	return        r3     2
.line	2073	return        r0     1
.line	2073	move          r0    r0
.line	2073	move          r0    r0
.line	2073	move          r0    r0
.line	2073	move          r0    r0
.line	2073	return        r0     1

.function	main/f112

.source	null
.linedefined	2084
.lastlinedefined	2097
.numparams	3
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"CDataTable"
.constant	k1	"GetTableData"
.constant	k2	202
.constant	k3	60
.constant	k4	182
.constant	k5	210
.constant	k6	"res_id"
.constant	k7	"log"
.constant	k8	"bWriteLog"
.constant	k9	212
.constant	k10	41
.constant	k11	161
.constant	k12	219
.constant	k13	102
.constant	k14	95
.constant	k15	100
.constant	k16	132
.constant	k17	203
.constant	k18	198
.constant	k19	252
.constant	k20	105
.constant	k21	93
.constant	k22	189
.constant	k23	160
.constant	k24	40
.constant	k25	35
.constant	k26	13
.constant	k27	215
.constant	k28	192
.constant	k29	130
.constant	k30	55
.constant	k31	184
.constant	k32	229
.constant	k33	218
.constant	k34	249
.constant	k35	113
.constant	k36	72
.constant	k37	223
.constant	k38	"tostring"
.constant	k39	"IsGlideType"
.constant	k40	"ItemSubType"
.constant	k41	nil
.constant	k42	"ShowAircraftNotice"

.line	2084	gettabup      r3    u0    k0 ; k0 = "CDataTable"
.line	2084	gettable      r3    r3    k1 ; k1 = "GetTableData"
.line	2084	getupval      r4    u1
.line	2084	loadk         r5    k2 ; k2 = 202
.line	2084	loadk         r6    k3 ; k3 = 60
.line	2084	loadk         r7    k4 ; k4 = 182
.line	2084	loadk         r8    k5 ; k5 = 210
.line	2084	call          r4     5     2
.line	2084	gettable      r5    r1    k6 ; k6 = "res_id"
.line	2084	call          r3     3     2
.line	2084	test          r3     1
.line	2084	jmp            0   l56
.line	2084	gettabup      r4    u0    k7 ; k7 = "log"
.line	2084	gettabup      r5    u0    k8 ; k8 = "bWriteLog"
.line	2084	test          r5     0
.line	2084	jmp            0   l54
.line	2084	getupval      r5    u1
.line	2084	loadk         r6    k9 ; k9 = 212
.line	2084	loadk         r7   k10 ; k10 = 41
.line	2084	loadk         r8   k11 ; k11 = 161
.line	2084	loadk         r9   k12 ; k12 = 219
.line	2084	loadk        r10   k13 ; k13 = 102
.line	2084	loadk        r11   k14 ; k14 = 95
.line	2084	loadk        r12   k15 ; k15 = 100
.line	2084	loadk        r13   k16 ; k16 = 132
.line	2084	loadk        r14   k17 ; k17 = 203
.line	2084	loadk        r15   k18 ; k18 = 198
.line	2084	loadk        r16   k19 ; k19 = 252
.line	2084	loadk        r17   k20 ; k20 = 105
.line	2084	loadk        r18   k21 ; k21 = 93
.line	2084	loadk        r19   k22 ; k22 = 189
.line	2084	loadk        r20   k23 ; k23 = 160
.line	2084	loadk        r21   k24 ; k24 = 40
.line	2084	loadk        r22   k25 ; k25 = 35
.line	2084	loadk        r23   k26 ; k26 = 13
.line	2084	loadk        r24   k27 ; k27 = 215
.line	2084	loadk        r25   k28 ; k28 = 192
.line	2084	loadk        r26   k29 ; k29 = 130
.line	2084	loadk        r27   k13 ; k13 = 102
.line	2084	loadk        r28   k30 ; k30 = 55
.line	2084	loadk        r29   k31 ; k31 = 184
.line	2084	loadk        r30   k32 ; k32 = 229
.line	2084	loadk        r31   k33 ; k33 = 218
.line	2084	loadk        r32   k34 ; k34 = 249
.line	2084	loadk        r33   k35 ; k35 = 113
.line	2084	loadk        r34   k36 ; k36 = 72
.line	2084	loadk        r35   k34 ; k34 = 249
.line	2084	loadk        r36   k37 ; k37 = 223
.line	2084	call          r5    32     2
.line	2084	gettabup      r6    u0   k38 ; k38 = "tostring"
.line	2084	gettable      r7    r1    k6 ; k6 = "res_id"
.line	2084	call          r6     2     2
.line	2084	concat        r5    r5    r6
.label	l54
.line	2084	call          r4     2     1
.line	2084	return        r0     1
.label	l56
.line	2084	gettabup      r4    u2   k39 ; k39 = "IsGlideType"
.line	2084	gettable      r5    r3   k40 ; k40 = "ItemSubType"
.line	2084	call          r4     2     2
.line	2084	test          r4     0
.line	2084	jmp            0   l77
.line	2084	eq             0    r2   k41 ; k41 = nil
.line	2084	jmp            0   l68
.line	2084	self          r4    r0   k42 ; k42 = "ShowAircraftNotice"
.line	2084	move          r6    r1
.line	2084	loadbool      r7     0     0
.line	2084	call          r4     4     1
.line	2084	jmp            0   l77
.label	l68
.line	2084	gettabup      r4    u2   k39 ; k39 = "IsGlideType"
.line	2084	gettable      r5    r2   k40 ; k40 = "ItemSubType"
.line	2084	call          r4     2     2
.line	2084	test          r4     1
.line	2084	jmp            0   l77
.line	2084	self          r4    r0   k42 ; k42 = "ShowAircraftNotice"
.line	2084	move          r6    r1
.line	2084	loadbool      r7     0     0
.line	2084	call          r4     4     1
.label	l77
.line	2084	return        r0     1
.line	2084	move          r0    r0
.line	2084	move          r0    r0
.line	2084	move          r0    r0
.line	2084	return        r0     1

.function	main/f113

.source	null
.linedefined	2099
.lastlinedefined	2109
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	12	true
.upvalue	"U2"	1	true

.constant	k0	"pairs"
.constant	k1	"DefaultVehiclesId"
.constant	k2	"require"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	224
.constant	k6	36
.constant	k7	186
.constant	k8	218
.constant	k9	122
.constant	k10	68
.constant	k11	40
.constant	k12	143
.constant	k13	226
.constant	k14	221
.constant	k15	236
.constant	k16	111
.constant	k17	76
.constant	k18	246
.constant	k19	193
.constant	k20	22
.constant	k21	1
.constant	k22	23
.constant	k23	215
.constant	k24	135
.constant	k25	26
.constant	k26	255
.constant	k27	192
.constant	k28	216
.constant	k29	249
.constant	k30	116
.constant	k31	92
.constant	k32	157
.constant	k33	51
.constant	k34	45
.constant	k35	13
.constant	k36	196
.constant	k37	149
.constant	k38	126
.constant	k39	2
.constant	k40	173
.constant	k41	230
.constant	k42	58
.constant	k43	"send_depot_modify_combat_vehicle_req"
.constant	k44	"tonumber"

.line	2099	test          r1     0
.line	2099	jmp            0   l12
.line	2099	gettabup      r4    u0    k0 ; k0 = "pairs"
.line	2099	gettabup      r5    u1    k1 ; k1 = "DefaultVehiclesId"
.line	2099	call          r4     2     4
.line	2099	jmp            0   l10
.line	2099	eq             0    r1    r8
.line	2099	jmp            0   l10
.line	2099	return        r0     1
.label	l10
.line	2099	move          r0    r0
.line	2099	move          r0    r0
.label	l12
.line	2099	gettabup      r4    u0    k2 ; k2 = "require"
.line	2099	gettabup      r5    u0    k3 ; k3 = "table"
.line	2099	gettable      r5    r5    k4 ; k4 = "concat"
.line	2099	newtable      r6     1     0
.line	2099	getupval      r7    u2
.line	2099	loadk         r8    k5 ; k5 = 224
.line	2099	loadk         r9    k6 ; k6 = 36
.line	2099	loadk        r10    k7 ; k7 = 186
.line	2099	loadk        r11    k8 ; k8 = 218
.line	2099	loadk        r12    k9 ; k9 = 122
.line	2099	loadk        r13   k10 ; k10 = 68
.line	2099	loadk        r14   k11 ; k11 = 40
.line	2099	loadk        r15   k12 ; k12 = 143
.line	2099	loadk        r16   k13 ; k13 = 226
.line	2099	loadk        r17   k14 ; k14 = 221
.line	2099	loadk        r18   k15 ; k15 = 236
.line	2099	loadk        r19   k16 ; k16 = 111
.line	2099	loadk        r20   k17 ; k17 = 76
.line	2099	loadk        r21   k18 ; k18 = 246
.line	2099	loadk        r22   k19 ; k19 = 193
.line	2099	loadk        r23   k20 ; k20 = 22
.line	2099	loadk        r24   k21 ; k21 = 1
.line	2099	loadk        r25   k22 ; k22 = 23
.line	2099	loadk        r26   k23 ; k23 = 215
.line	2099	loadk        r27    k5 ; k5 = 224
.line	2099	loadk        r28   k24 ; k24 = 135
.line	2099	loadk        r29   k16 ; k16 = 111
.line	2099	loadk        r30   k25 ; k25 = 26
.line	2099	loadk        r31   k26 ; k26 = 255
.line	2099	loadk        r32   k27 ; k27 = 192
.line	2099	loadk        r33   k28 ; k28 = 216
.line	2099	loadk        r34   k29 ; k29 = 249
.line	2099	loadk        r35   k30 ; k30 = 116
.line	2099	loadk        r36   k31 ; k31 = 92
.line	2099	loadk        r37   k13 ; k13 = 226
.line	2099	loadk        r38   k32 ; k32 = 157
.line	2099	loadk        r39   k33 ; k33 = 51
.line	2099	loadk        r40   k34 ; k34 = 45
.line	2099	loadk        r41   k35 ; k35 = 13
.line	2099	loadk        r42   k36 ; k36 = 196
.line	2099	loadk        r43   k23 ; k23 = 215
.line	2099	loadk        r44   k37 ; k37 = 149
.line	2099	loadk        r45   k38 ; k38 = 126
.line	2099	loadk        r46   k39 ; k39 = 2
.line	2099	loadk        r47   k40 ; k40 = 173
.line	2099	call          r7    41     2
.line	2099	getupval      r8    u2
.line	2099	loadk         r9   k41 ; k41 = 230
.line	2099	loadk        r10   k42 ; k42 = 58
.line	2099	call          r8     3     0
.line	2099	setlist       r6     0     1
.line	2099	call          r5     2     2
.line	2099	call          r4     2     2
.line	2099	gettable      r5    r4   k43 ; k43 = "send_depot_modify_co" (truncated)
.line	2099	gettabup      r6    u0   k44 ; k44 = "tonumber"
.line	2099	move          r7    r2
.line	2099	call          r6     2     2
.line	2099	move          r7    r3
.line	2099	loadbool      r8     1     0
.line	2099	call          r5     4     1
.line	2099	return        r0     1
.line	2099	move          r0    r0
.line	2099	move          r0    r0
.line	2099	move          r0    r0
.line	2099	move          r0    r0
.line	2099	return        r0     1

.function	main/f114

.source	null
.linedefined	2111
.lastlinedefined	2113
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	5	true

.constant	k0	"bFirstEnter"

.line	2111	settabup      u0    k0    r1 ; k0 = "bFirstEnter"
.line	2111	return        r0     1
.line	2111	move          r0    r0
.line	2111	move          r0    r0
.line	2111	move          r0    r0
.line	2111	move          r0    r0
.line	2111	return        r0     1

.function	main/f115

.source	null
.linedefined	2115
.lastlinedefined	2117
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	5	true

.constant	k0	"bTriggerPutOn"

.line	2115	settabup      u0    k0    r1 ; k0 = "bTriggerPutOn"
.line	2115	return        r0     1
.line	2115	move          r0    r0
.line	2115	move          r0    r0
.line	2115	move          r0    r0
.line	2115	move          r0    r0
.line	2115	return        r0     1

.function	main/f116

.source	null
.linedefined	2119
.lastlinedefined	2121
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	5	true

.constant	k0	"bTriggerSuitDye"

.line	2119	settabup      u0    k0    r1 ; k0 = "bTriggerSuitDye"
.line	2119	return        r0     1
.line	2119	move          r0    r0
.line	2119	move          r0    r0
.line	2119	move          r0    r0
.line	2119	move          r0    r0
.line	2119	return        r0     1

.function	main/f117

.source	null
.linedefined	2123
.lastlinedefined	2125
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	5	true

.constant	k0	"searchString"

.line	2123	gettabup      r1    u0    k0 ; k0 = "searchString"
.line	2123	return        r1     2
.line	2123	return        r0     1
.line	2123	move          r0    r0
.line	2123	move          r0    r0
.line	2123	return        r0     1

.function	main/f118

.source	null
.linedefined	2127
.lastlinedefined	2129
.numparams	2
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	5	true

.constant	k0	"searchString"

.line	2127	settabup      u0    k0    r1 ; k0 = "searchString"
.line	2127	return        r0     1
.line	2127	move          r0    r0
.line	2127	return        r0     1

.function	main/f119

.source	null
.linedefined	2131
.lastlinedefined	2163
.numparams	3
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"currentShareList"
.constant	k1	"FindItemInShareList"
.constant	k2	10
.constant	k3	"ShowNotice"
.constant	k4	48613
.constant	k5	"require"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	224
.constant	k9	36
.constant	k10	186
.constant	k11	218
.constant	k12	122
.constant	k13	68
.constant	k14	40
.constant	k15	146
.constant	k16	235
.constant	k17	220
.constant	k18	250
.constant	k19	46
.constant	k20	82
.constant	k21	242
.constant	k22	136
.constant	k23	47
.constant	k24	16
.constant	k25	86
.constant	k26	214
.constant	k27	225
.constant	k28	143
.constant	k29	110
.constant	k30	25
.constant	k31	166
.constant	k32	200
.constant	k33	201
.constant	k34	234
.constant	k35	99
.constant	k36	93
.constant	k37	163
.constant	k38	189
.constant	k39	57
.constant	k40	13
.constant	k41	29
.constant	k42	192
.constant	k43	207
.constant	k44	149
.constant	k45	21
.constant	k46	239
.constant	k47	39
.constant	k48	202
.constant	k49	103
.constant	k50	111
.constant	k51	118
.constant	k52	128
.constant	k53	244
.constant	k54	196
.constant	k55	117
.constant	k56	74
.constant	k57	131
.constant	k58	"ipairs"
.constant	k59	"IsTheSameItem"
.constant	k60	"insert"

.line	2131	test          r2     0
.line	2131	jmp            0    l5
.line	2131	test          r1     1
.line	2131	jmp            0    l7
.label	l5
.line	2131	loadbool      r3     0     0
.line	2131	return        r3     2
.label	l7
.line	2131	gettable      r3    r0    k0 ; k0 = "currentShareList"
.line	2131	len           r3    r3
.line	2131	lt             1    r3    r2
.line	2131	jmp            0   l12
.line	2131	loadbool      r4     0     1
.label	l12
.line	2131	loadbool      r4     1     0
.line	2131	self          r5    r0    k1 ; k1 = "FindItemInShareList"
.line	2131	move          r7    r1
.line	2131	call          r5     3     2
.line	2131	test          r4     0
.line	2131	jmp            0  l126
.line	2131	test          r5     0
.line	2131	jmp            0   l31
.line	2131	gettable      r6    r0    k0 ; k0 = "currentShareList"
.line	2131	settable      r6    r5    r1
.line	2131	gettable      r6    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r7    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r8    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r8    r8    r5
.line	2131	gettable      r9    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r9    r9    r3
.line	2131	settable      r7    r5    r9
.line	2131	settable      r6    r3    r8
.line	2131	jmp            0  l141
.label	l31
.line	2131	le             0    k2    r3 ; k2 = 10
.line	2131	jmp            0   l38
.line	2131	gettabup      r6    u0    k3 ; k3 = "ShowNotice"
.line	2131	loadk         r7    k4 ; k4 = 48613
.line	2131	call          r6     2     1
.line	2131	loadbool      r6     0     0
.line	2131	return        r6     2
.label	l38
.line	2131	gettabup      r6    u0    k5 ; k5 = "require"
.line	2131	gettabup      r7    u0    k6 ; k6 = "table"
.line	2131	gettable      r7    r7    k7 ; k7 = "concat"
.line	2131	newtable      r8     1     0
.line	2131	getupval      r9    u1
.line	2131	loadk        r10    k8 ; k8 = 224
.line	2131	loadk        r11    k9 ; k9 = 36
.line	2131	loadk        r12   k10 ; k10 = 186
.line	2131	loadk        r13   k11 ; k11 = 218
.line	2131	loadk        r14   k12 ; k12 = 122
.line	2131	loadk        r15   k13 ; k13 = 68
.line	2131	loadk        r16   k14 ; k14 = 40
.line	2131	loadk        r17   k15 ; k15 = 146
.line	2131	loadk        r18   k16 ; k16 = 235
.line	2131	loadk        r19   k17 ; k17 = 220
.line	2131	loadk        r20   k18 ; k18 = 250
.line	2131	loadk        r21   k19 ; k19 = 46
.line	2131	loadk        r22   k20 ; k20 = 82
.line	2131	loadk        r23   k21 ; k21 = 242
.line	2131	loadk        r24   k22 ; k22 = 136
.line	2131	loadk        r25   k23 ; k23 = 47
.line	2131	loadk        r26   k24 ; k24 = 16
.line	2131	loadk        r27   k25 ; k25 = 86
.line	2131	loadk        r28   k26 ; k26 = 214
.line	2131	loadk        r29   k27 ; k27 = 225
.line	2131	loadk        r30   k28 ; k28 = 143
.line	2131	loadk        r31   k29 ; k29 = 110
.line	2131	loadk        r32   k30 ; k30 = 25
.line	2131	loadk        r33   k31 ; k31 = 166
.line	2131	loadk        r34   k32 ; k32 = 200
.line	2131	loadk        r35   k33 ; k33 = 201
.line	2131	loadk        r36   k34 ; k34 = 234
.line	2131	loadk        r37   k35 ; k35 = 99
.line	2131	loadk        r38   k36 ; k36 = 93
.line	2131	loadk        r39   k37 ; k37 = 163
.line	2131	loadk        r40   k38 ; k38 = 189
.line	2131	loadk        r41   k39 ; k39 = 57
.line	2131	loadk        r42   k40 ; k40 = 13
.line	2131	loadk        r43   k41 ; k41 = 29
.line	2131	loadk        r44   k42 ; k42 = 192
.line	2131	loadk        r45   k43 ; k43 = 207
.line	2131	loadk        r46   k44 ; k44 = 149
.line	2131	loadk        r47   k35 ; k35 = 99
.line	2131	loadk        r48   k45 ; k45 = 21
.line	2131	loadk        r49   k46 ; k46 = 239
.line	2131	call          r9    41     2
.line	2131	getupval     r10    u1
.line	2131	loadk        r11   k27 ; k27 = 225
.line	2131	loadk        r12   k47 ; k47 = 39
.line	2131	loadk        r13   k38 ; k38 = 189
.line	2131	loadk        r14   k48 ; k48 = 202
.line	2131	loadk        r15   k49 ; k49 = 103
.line	2131	loadk        r16   k50 ; k50 = 111
.line	2131	loadk        r17   k51 ; k51 = 118
.line	2131	loadk        r18   k52 ; k52 = 128
.line	2131	loadk        r19   k53 ; k53 = 244
.line	2131	loadk        r20   k11 ; k11 = 218
.line	2131	loadk        r21   k54 ; k54 = 196
.line	2131	loadk        r22   k55 ; k55 = 117
.line	2131	loadk        r23   k56 ; k56 = 74
.line	2131	loadk        r24   k53 ; k53 = 244
.line	2131	loadk        r25   k57 ; k57 = 131
.line	2131	call         r10    16     0
.line	2131	setlist       r8     0     1
.line	2131	call          r7     2     2
.line	2131	call          r6     2     2
.line	2131	gettabup      r7    u0   k58 ; k58 = "ipairs"
.line	2131	gettable      r8    r0    k0 ; k0 = "currentShareList"
.line	2131	call          r7     2     4
.line	2131	jmp            0  l118
.line	2131	gettable     r12    r6   k59 ; k59 = "IsTheSameItem"
.line	2131	move         r13   r11
.line	2131	move         r14    r1
.line	2131	call         r12     3     2
.line	2131	test         r12     0
.line	2131	jmp            0  l118
.line	2131	gettable     r12    r0    k0 ; k0 = "currentShareList"
.line	2131	settable     r12   r10    r1
.line	2131	loadbool     r12     1     0
.line	2131	return       r12     2
.label	l118
.line	2131	move          r0    r0
.line	2131	move          r0    r0
.line	2131	gettabup      r7    u0    k6 ; k6 = "table"
.line	2131	gettable      r7    r7   k60 ; k60 = "insert"
.line	2131	gettable      r8    r0    k0 ; k0 = "currentShareList"
.line	2131	move          r9    r1
.line	2131	call          r7     3     1
.line	2131	jmp            0  l141
.label	l126
.line	2131	test          r5     0
.line	2131	jmp            0  l139
.line	2131	gettable      r6    r0    k0 ; k0 = "currentShareList"
.line	2131	settable      r6    r5    r1
.line	2131	gettable      r6    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r7    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r8    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r8    r8    r5
.line	2131	gettable      r9    r0    k0 ; k0 = "currentShareList"
.line	2131	gettable      r9    r9    r2
.line	2131	settable      r7    r5    r9
.line	2131	settable      r6    r2    r8
.line	2131	jmp            0  l141
.label	l139
.line	2131	gettable      r6    r0    k0 ; k0 = "currentShareList"
.line	2131	settable      r6    r2    r1
.label	l141
.line	2131	loadbool      r6     1     0
.line	2131	return        r6     2
.line	2131	return        r0     1
.line	2131	move          r0    r0
.line	2131	move          r0    r0
.line	2131	move          r0    r0
.line	2131	return        r0     1

.function	main/f120

.source	null
.linedefined	2165
.lastlinedefined	2175
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"FindItemInShareList"
.constant	k1	"table"
.constant	k2	"remove"
.constant	k3	"currentShareList"

.line	2165	test          r1     1
.line	2165	jmp            0    l5
.line	2165	loadbool      r2     0     0
.line	2165	return        r2     2
.label	l5
.line	2165	self          r2    r0    k0 ; k0 = "FindItemInShareList"
.line	2165	move          r4    r1
.line	2165	call          r2     3     2
.line	2165	test          r2     0
.line	2165	jmp            0   l17
.line	2165	gettabup      r3    u0    k1 ; k1 = "table"
.line	2165	gettable      r3    r3    k2 ; k2 = "remove"
.line	2165	gettable      r4    r0    k3 ; k3 = "currentShareList"
.line	2165	move          r5    r2
.line	2165	call          r3     3     1
.line	2165	loadbool      r3     1     0
.line	2165	return        r3     2
.label	l17
.line	2165	loadbool      r3     0     0
.line	2165	return        r3     2
.line	2165	return        r0     1
.line	2165	move          r0    r0
.line	2165	move          r0    r0
.line	2165	move          r0    r0
.line	2165	return        r0     1

.function	main/f121

.source	null
.linedefined	2177
.lastlinedefined	2188
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	214
.constant	k22	225
.constant	k23	143
.constant	k24	110
.constant	k25	25
.constant	k26	166
.constant	k27	200
.constant	k28	201
.constant	k29	234
.constant	k30	99
.constant	k31	93
.constant	k32	163
.constant	k33	189
.constant	k34	57
.constant	k35	13
.constant	k36	29
.constant	k37	192
.constant	k38	207
.constant	k39	149
.constant	k40	21
.constant	k41	239
.constant	k42	39
.constant	k43	202
.constant	k44	103
.constant	k45	111
.constant	k46	118
.constant	k47	128
.constant	k48	244
.constant	k49	196
.constant	k50	117
.constant	k51	74
.constant	k52	131
.constant	k53	"ipairs"
.constant	k54	"currentShareList"
.constant	k55	"IsTheSameItem"

.line	2177	test          r1     1
.line	2177	jmp            0    l5
.line	2177	loadnil       r2     0
.line	2177	return        r2     2
.label	l5
.line	2177	gettabup      r2    u0    k0 ; k0 = "require"
.line	2177	gettabup      r3    u0    k1 ; k1 = "table"
.line	2177	gettable      r3    r3    k2 ; k2 = "concat"
.line	2177	newtable      r4     1     0
.line	2177	getupval      r5    u1
.line	2177	loadk         r6    k3 ; k3 = 224
.line	2177	loadk         r7    k4 ; k4 = 36
.line	2177	loadk         r8    k5 ; k5 = 186
.line	2177	loadk         r9    k6 ; k6 = 218
.line	2177	loadk        r10    k7 ; k7 = 122
.line	2177	loadk        r11    k8 ; k8 = 68
.line	2177	loadk        r12    k9 ; k9 = 40
.line	2177	loadk        r13   k10 ; k10 = 146
.line	2177	loadk        r14   k11 ; k11 = 235
.line	2177	loadk        r15   k12 ; k12 = 220
.line	2177	loadk        r16   k13 ; k13 = 250
.line	2177	loadk        r17   k14 ; k14 = 46
.line	2177	loadk        r18   k15 ; k15 = 82
.line	2177	loadk        r19   k16 ; k16 = 242
.line	2177	loadk        r20   k17 ; k17 = 136
.line	2177	loadk        r21   k18 ; k18 = 47
.line	2177	loadk        r22   k19 ; k19 = 16
.line	2177	loadk        r23   k20 ; k20 = 86
.line	2177	loadk        r24   k21 ; k21 = 214
.line	2177	loadk        r25   k22 ; k22 = 225
.line	2177	loadk        r26   k23 ; k23 = 143
.line	2177	loadk        r27   k24 ; k24 = 110
.line	2177	loadk        r28   k25 ; k25 = 25
.line	2177	loadk        r29   k26 ; k26 = 166
.line	2177	loadk        r30   k27 ; k27 = 200
.line	2177	loadk        r31   k28 ; k28 = 201
.line	2177	loadk        r32   k29 ; k29 = 234
.line	2177	loadk        r33   k30 ; k30 = 99
.line	2177	loadk        r34   k31 ; k31 = 93
.line	2177	loadk        r35   k32 ; k32 = 163
.line	2177	loadk        r36   k33 ; k33 = 189
.line	2177	loadk        r37   k34 ; k34 = 57
.line	2177	loadk        r38   k35 ; k35 = 13
.line	2177	loadk        r39   k36 ; k36 = 29
.line	2177	loadk        r40   k37 ; k37 = 192
.line	2177	loadk        r41   k38 ; k38 = 207
.line	2177	loadk        r42   k39 ; k39 = 149
.line	2177	loadk        r43   k30 ; k30 = 99
.line	2177	loadk        r44   k40 ; k40 = 21
.line	2177	loadk        r45   k41 ; k41 = 239
.line	2177	call          r5    41     2
.line	2177	getupval      r6    u1
.line	2177	loadk         r7   k22 ; k22 = 225
.line	2177	loadk         r8   k42 ; k42 = 39
.line	2177	loadk         r9   k33 ; k33 = 189
.line	2177	loadk        r10   k43 ; k43 = 202
.line	2177	loadk        r11   k44 ; k44 = 103
.line	2177	loadk        r12   k45 ; k45 = 111
.line	2177	loadk        r13   k46 ; k46 = 118
.line	2177	loadk        r14   k47 ; k47 = 128
.line	2177	loadk        r15   k48 ; k48 = 244
.line	2177	loadk        r16    k6 ; k6 = 218
.line	2177	loadk        r17   k49 ; k49 = 196
.line	2177	loadk        r18   k50 ; k50 = 117
.line	2177	loadk        r19   k51 ; k51 = 74
.line	2177	loadk        r20   k48 ; k48 = 244
.line	2177	loadk        r21   k52 ; k52 = 131
.line	2177	call          r6    16     0
.line	2177	setlist       r4     0     1
.line	2177	call          r3     2     2
.line	2177	call          r2     2     2
.line	2177	gettabup      r3    u0   k53 ; k53 = "ipairs"
.line	2177	gettable      r4    r0   k54 ; k54 = "currentShareList"
.line	2177	call          r3     2     4
.line	2177	jmp            0   l84
.line	2177	eq             1    r7    r1
.line	2177	jmp            0   l83
.line	2177	gettable      r8    r2   k55 ; k55 = "IsTheSameItem"
.line	2177	move          r9    r7
.line	2177	move         r10    r1
.line	2177	call          r8     3     2
.line	2177	test          r8     0
.line	2177	jmp            0   l84
.label	l83
.line	2177	return        r6     2
.label	l84
.line	2177	move          r0    r0
.line	2177	move          r0    r0
.line	2177	loadnil       r3     0
.line	2177	return        r3     2
.line	2177	return        r0     1
.line	2177	move          r0    r0
.line	2177	move          r0    r0
.line	2177	move          r0    r0
.line	2177	return        r0     1

.function	main/f122

.source	null
.linedefined	2190
.lastlinedefined	2202
.numparams	3
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	15	true

.constant	k0	"currentShareList"
.constant	k1	"currentShareType"
.constant	k2	"pairs"
.constant	k3	"HasItem"
.constant	k4	"table"
.constant	k5	"insert"
.constant	k6	"EventSystem"
.constant	k7	"postEvent"
.constant	k8	"EVENTTYPE_WARDROBE"
.constant	k9	"EVENTID_WARDROBE_SHARE_BAG_LIST_UPDATE"

.line	2190	newtable      r3     0     0
.line	2190	settable      r0    k0    r3 ; k0 = "currentShareList"
.line	2190	settable      r0    k1    r2 ; k1 = "currentShareType"
.line	2190	test          r1     1
.line	2190	jmp            0    l7
.line	2190	return        r0     1
.label	l7
.line	2190	gettabup      r3    u0    k2 ; k2 = "pairs"
.line	2190	move          r4    r1
.line	2190	call          r3     2     4
.line	2190	jmp            0   l23
.line	2190	getupval      r8    u1
.line	2190	self          r8    r8    k3 ; k3 = "HasItem"
.line	2190	move         r10    r7
.line	2190	loadbool     r11     1     0
.line	2190	call          r8     4     2
.line	2190	test          r8     0
.line	2190	jmp            0   l23
.line	2190	gettabup      r8    u0    k4 ; k4 = "table"
.line	2190	gettable      r8    r8    k5 ; k5 = "insert"
.line	2190	gettable      r9    r0    k0 ; k0 = "currentShareList"
.line	2190	move         r10    r7
.line	2190	call          r8     3     1
.label	l23
.line	2190	move          r0    r0
.line	2190	move          r0    r0
.line	2190	gettabup      r3    u0    k6 ; k6 = "EventSystem"
.line	2190	self          r3    r3    k7 ; k7 = "postEvent"
.line	2190	gettabup      r5    u0    k8 ; k8 = "EVENTTYPE_WARDROBE"
.line	2190	gettabup      r6    u0    k9 ; k9 = "EVENTID_WARDROBE_SHA" (truncated)
.line	2190	call          r3     4     1
.line	2190	return        r0     1
.line	2190	move          r0    r0
.line	2190	return        r0     1

.function	main/f123

.source	null
.linedefined	2204
.lastlinedefined	2206
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"currentShareList"

.line	2204	gettable      r1    r0    k0 ; k0 = "currentShareList"
.line	2204	return        r1     2
.line	2204	return        r0     1
.line	2204	move          r0    r0
.line	2204	return        r0     1

.function	main/f124

.source	null
.linedefined	2208
.lastlinedefined	2222
.numparams	1
.is_vararg	0
.maxstacksize	42

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"currentShareList"
.constant	k1	"require"
.constant	k2	224
.constant	k3	36
.constant	k4	186
.constant	k5	218
.constant	k6	122
.constant	k7	68
.constant	k8	40
.constant	k9	143
.constant	k10	226
.constant	k11	221
.constant	k12	236
.constant	k13	111
.constant	k14	76
.constant	k15	246
.constant	k16	193
.constant	k17	22
.constant	k18	1
.constant	k19	23
.constant	k20	215
.constant	k21	135
.constant	k22	26
.constant	k23	255
.constant	k24	192
.constant	k25	216
.constant	k26	249
.constant	k27	116
.constant	k28	124
.constant	k29	157
.constant	k30	51
.constant	k31	43
.constant	k32	9
.constant	k33	251
.constant	k34	152
.constant	k35	117
.constant	k36	20
.constant	k37	"pairs"
.constant	k38	"GetHallDepotItemDataByResIDAndTimeliness"
.constant	k39	"table"
.constant	k40	"insert"
.constant	k41	"insID"
.constant	k42	L"send_shared_backpack_batch_config_item_req"
.constant	k43	"currentShareType"
.constant	k44	"isInShareSubscribeSetup"
.constant	k45	false

.line	2208	gettable      r1    r0    k0 ; k0 = "currentShareList"
.line	2208	test          r1     0
.line	2208	jmp            0   l70
.line	2208	gettabup      r1    u0    k1 ; k1 = "require"
.line	2208	getupval      r2    u1
.line	2208	loadk         r3    k2 ; k2 = 224
.line	2208	loadk         r4    k3 ; k3 = 36
.line	2208	loadk         r5    k4 ; k4 = 186
.line	2208	loadk         r6    k5 ; k5 = 218
.line	2208	loadk         r7    k6 ; k6 = 122
.line	2208	loadk         r8    k7 ; k7 = 68
.line	2208	loadk         r9    k8 ; k8 = 40
.line	2208	loadk        r10    k9 ; k9 = 143
.line	2208	loadk        r11   k10 ; k10 = 226
.line	2208	loadk        r12   k11 ; k11 = 221
.line	2208	loadk        r13   k12 ; k12 = 236
.line	2208	loadk        r14   k13 ; k13 = 111
.line	2208	loadk        r15   k14 ; k14 = 76
.line	2208	loadk        r16   k15 ; k15 = 246
.line	2208	loadk        r17   k16 ; k16 = 193
.line	2208	loadk        r18   k17 ; k17 = 22
.line	2208	loadk        r19   k18 ; k18 = 1
.line	2208	loadk        r20   k19 ; k19 = 23
.line	2208	loadk        r21   k20 ; k20 = 215
.line	2208	loadk        r22    k2 ; k2 = 224
.line	2208	loadk        r23   k21 ; k21 = 135
.line	2208	loadk        r24   k13 ; k13 = 111
.line	2208	loadk        r25   k22 ; k22 = 26
.line	2208	loadk        r26   k23 ; k23 = 255
.line	2208	loadk        r27   k24 ; k24 = 192
.line	2208	loadk        r28   k25 ; k25 = 216
.line	2208	loadk        r29   k26 ; k26 = 249
.line	2208	loadk        r30   k27 ; k27 = 116
.line	2208	loadk        r31   k28 ; k28 = 124
.line	2208	loadk        r32   k10 ; k10 = 226
.line	2208	loadk        r33   k29 ; k29 = 157
.line	2208	loadk        r34   k30 ; k30 = 51
.line	2208	loadk        r35   k31 ; k31 = 43
.line	2208	loadk        r36   k32 ; k32 = 9
.line	2208	loadk        r37   k11 ; k11 = 221
.line	2208	loadk        r38   k33 ; k33 = 251
.line	2208	loadk        r39   k34 ; k34 = 152
.line	2208	loadk        r40   k35 ; k35 = 117
.line	2208	loadk        r41   k36 ; k36 = 20
.line	2208	call          r2    40     2
.line	2208	call          r1     2     2
.line	2208	newtable      r2     0     0
.line	2208	gettabup      r3    u0   k37 ; k37 = "pairs"
.line	2208	gettable      r4    r0    k0 ; k0 = "currentShareList"
.line	2208	call          r3     2     4
.line	2208	jmp            0   l64
.line	2208	getupval      r8    u2
.line	2208	self          r8    r8   k38 ; k38 = "GetHallDepotItemData" (truncated)
.line	2208	move         r10    r7
.line	2208	loadbool     r11     0     0
.line	2208	call          r8     4     2
.line	2208	test          r8     0
.line	2208	jmp            0   l64
.line	2208	gettabup      r9    u0   k39 ; k39 = "table"
.line	2208	gettable      r9    r9   k40 ; k40 = "insert"
.line	2208	move         r10    r2
.line	2208	gettable     r11    r8   k41 ; k41 = "insID"
.line	2208	call          r9     3     1
.label	l64
.line	2208	move          r0    r0
.line	2208	move          r0    r0
.line	2208	gettable      r3    r1   k42 ; k42 = L"send_shared_backpack" (truncated)
.line	2208	gettable      r4    r0   k43 ; k43 = "currentShareType"
.line	2208	move          r5    r2
.line	2208	call          r3     3     1
.label	l70
.line	2208	newtable      r1     0     0
.line	2208	settable      r0    k0    r1 ; k0 = "currentShareList"
.line	2208	settable      r0   k44   k45 ; k45 = false
.line	2208	return        r0     1
.line	2208	move          r0    r0
.line	2208	return        r0     1

.function	main/f125

.source	null
.linedefined	2224
.lastlinedefined	2230
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"shareBackpackParam"
.constant	k1	"shareBackpackBlackItems"
.constant	k2	"black_item_table"

.line	2224	test          r1     1
.line	2224	jmp            0    l4
.line	2224	return        r0     1
.label	l4
.line	2224	settable      r0    k0    r1 ; k0 = "shareBackpackParam"
.line	2224	gettable      r2    r1    k2 ; k2 = "black_item_table"
.line	2224	settable      r0    k1    r2 ; k1 = "shareBackpackBlackIt" (truncated)
.line	2224	return        r0     1
.line	2224	move          r0    r0
.line	2224	return        r0     1

.function	main/f126

.source	null
.linedefined	2232
.lastlinedefined	2237
.numparams	2
.is_vararg	0
.maxstacksize	3

.constant	k0	"shareBackpackParam"
.constant	k1	6
.constant	k2	2
.constant	k3	"collect_bp_quality_limit"
.constant	k4	"item_quality_limit"

.line	2232	gettable      r2    r0    k0 ; k0 = "shareBackpackParam"
.line	2232	test          r2     1
.line	2232	jmp            0    l6
.line	2232	loadk         r2    k1 ; k1 = 6
.line	2232	return        r2     2
.label	l6
.line	2232	eq             0    r1    k2 ; k2 = 2
.line	2232	jmp            0   l12
.line	2232	gettable      r2    r0    k0 ; k0 = "shareBackpackParam"
.line	2232	gettable      r2    r2    k3 ; k3 = "collect_bp_quality_l" (truncated)
.line	2232	test          r2     1
.line	2232	jmp            0   l17
.label	l12
.line	2232	gettable      r2    r0    k0 ; k0 = "shareBackpackParam"
.line	2232	gettable      r2    r2    k4 ; k4 = "item_quality_limit"
.line	2232	test          r2     1
.line	2232	jmp            0   l17
.line	2232	loadk         r2    k1 ; k1 = 6
.label	l17
.line	2232	return        r2     2
.line	2232	return        r0     1
.line	2232	move          r0    r0
.line	2232	return        r0     1

.function	main/f127

.source	null
.linedefined	2239
.lastlinedefined	2241
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"shareBackpackBlackItems"

.line	2239	gettable      r1    r0    k0 ; k0 = "shareBackpackBlackIt" (truncated)
.line	2239	test          r1     1
.line	2239	jmp            0    l5
.line	2239	newtable      r1     0     0
.label	l5
.line	2239	return        r1     2
.line	2239	return        r0     1
.line	2239	move          r0    r0
.line	2239	return        r0     1

.function	main/f128

.source	null
.linedefined	2243
.lastlinedefined	2263
.numparams	1
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	224
.constant	k4	36
.constant	k5	186
.constant	k6	218
.constant	k7	122
.constant	k8	68
.constant	k9	40
.constant	k10	146
.constant	k11	235
.constant	k12	220
.constant	k13	250
.constant	k14	46
.constant	k15	82
.constant	k16	242
.constant	k17	136
.constant	k18	47
.constant	k19	16
.constant	k20	86
.constant	k21	212
.constant	k22	238
.constant	k23	150
.constant	k24	100
.constant	k25	4
.constant	k26	190
.constant	k27	245
.constant	k28	165
.constant	k29	124
.constant	k30	65
.constant	k31	234
.constant	k32	53
.constant	k33	60
.constant	k34	31
.constant	k35	210
.constant	k36	237
.constant	k37	144
.constant	k38	98
.constant	k39	9
.constant	k40	163
.constant	k41	230
.constant	k42	23
.constant	k43	189
.constant	k44	99
.constant	k45	"GetCurrentPageId"
.constant	k46	"ModuleManager"
.constant	k47	"GetModule"
.constant	k48	"LobbyModuleConfig"
.constant	k49	"logic_wardrobe_tag_mgr"
.constant	k50	"GetLocalOperationData"
.constant	k51	"log"
.constant	k52	"bWriteLog"
.constant	k53	41
.constant	k54	161
.constant	k55	219
.constant	k56	102
.constant	k57	95
.constant	k58	132
.constant	k59	203
.constant	k60	198
.constant	k61	252
.constant	k62	105
.constant	k63	93
.constant	k64	167
.constant	k65	187
.constant	k66	52
.constant	k67	10
.constant	k68	204
.constant	k69	128
.constant	k70	83
.constant	k71	246
.constant	k72	251
.constant	k73	117
.constant	k74	92
.constant	k75	236
.constant	k76	139
.constant	k77	63
.constant	k78	12
.constant	k79	6
.constant	k80	147
.constant	k81	149
.constant	k82	114
.constant	k83	185
.constant	k84	104
.constant	k85	"tostring"
.constant	k86	"SelectCheckSaveOperation"
.constant	k87	0
.constant	k88	241
.constant	k89	155
.constant	k90	48
.constant	k91	21
.constant	k92	160
.constant	k93	45
.constant	k94	183
.constant	k95	159
.constant	k96	96
.constant	k97	81
.constant	k98	97
.constant	k99	193
.constant	k100	225
.constant	k101	233
.constant	k102	32
.constant	k103	232
.constant	k104	157
.constant	k105	22
.constant	k106	215
.constant	k107	175
.constant	k108	20
.constant	k109	152
.constant	k110	243
.constant	k111	131
.constant	k112	171
.constant	k113	58
.constant	k114	182
.constant	k115	217
.constant	k116	85
.constant	k117	137
.constant	k118	80
.constant	k119	207
.constant	k120	34
.constant	k121	30
.constant	k122	194
.constant	k123	116
.constant	k124	"StartYear"
.constant	k125	"StartMonth"
.constant	k126	"EndYear"
.constant	k127	"EndMonth"
.constant	k128	"string"
.constant	k129	"format"
.constant	k130	191
.constant	k131	113
.constant	k132	231
.constant	k133	49
.constant	k134	67
.constant	k135	"CompatibilityCornerTagCache"
.constant	k136	"SelectCornerTagList"
.constant	k137	"ConfirmSelection"
.constant	k138	"SelectCustomTagList"

.line	2243	gettabup      r1    u0    k0 ; k0 = "require"
.line	2243	gettabup      r2    u0    k1 ; k1 = "table"
.line	2243	gettable      r2    r2    k2 ; k2 = "concat"
.line	2243	newtable      r3     1     0
.line	2243	getupval      r4    u1
.line	2243	loadk         r5    k3 ; k3 = 224
.line	2243	loadk         r6    k4 ; k4 = 36
.line	2243	loadk         r7    k5 ; k5 = 186
.line	2243	loadk         r8    k6 ; k6 = 218
.line	2243	loadk         r9    k7 ; k7 = 122
.line	2243	loadk        r10    k8 ; k8 = 68
.line	2243	loadk        r11    k9 ; k9 = 40
.line	2243	loadk        r12   k10 ; k10 = 146
.line	2243	loadk        r13   k11 ; k11 = 235
.line	2243	loadk        r14   k12 ; k12 = 220
.line	2243	loadk        r15   k13 ; k13 = 250
.line	2243	loadk        r16   k14 ; k14 = 46
.line	2243	loadk        r17   k15 ; k15 = 82
.line	2243	loadk        r18   k16 ; k16 = 242
.line	2243	loadk        r19   k17 ; k17 = 136
.line	2243	loadk        r20   k18 ; k18 = 47
.line	2243	loadk        r21   k19 ; k19 = 16
.line	2243	loadk        r22   k20 ; k20 = 86
.line	2243	loadk        r23   k21 ; k21 = 212
.line	2243	loadk        r24   k22 ; k22 = 238
.line	2243	loadk        r25   k23 ; k23 = 150
.line	2243	loadk        r26   k24 ; k24 = 100
.line	2243	loadk        r27   k25 ; k25 = 4
.line	2243	loadk        r28   k26 ; k26 = 190
.line	2243	loadk        r29   k27 ; k27 = 245
.line	2243	loadk        r30   k12 ; k12 = 220
.line	2243	loadk        r31   k28 ; k28 = 165
.line	2243	loadk        r32   k29 ; k29 = 124
.line	2243	loadk        r33   k30 ; k30 = 65
.line	2243	loadk        r34   k31 ; k31 = 234
.line	2243	loadk        r35   k23 ; k23 = 150
.line	2243	loadk        r36   k32 ; k32 = 53
.line	2243	loadk        r37   k33 ; k33 = 60
.line	2243	loadk        r38   k34 ; k34 = 31
.line	2243	loadk        r39   k35 ; k35 = 210
.line	2243	loadk        r40   k36 ; k36 = 237
.line	2243	loadk        r41   k37 ; k37 = 144
.line	2243	loadk        r42   k38 ; k38 = 98
.line	2243	loadk        r43   k39 ; k39 = 9
.line	2243	loadk        r44   k40 ; k40 = 163
.line	2243	call          r4    41     2
.line	2243	getupval      r5    u1
.line	2243	loadk         r6   k41 ; k41 = 230
.line	2243	loadk         r7   k42 ; k42 = 23
.line	2243	loadk         r8   k43 ; k43 = 189
.line	2243	loadk         r9    k6 ; k6 = 218
.line	2243	loadk        r10   k44 ; k44 = 99
.line	2243	call          r5     6     0
.line	2243	setlist       r3     0     1
.line	2243	call          r2     2     2
.line	2243	call          r1     2     2
.line	2243	self          r2    r1   k45 ; k45 = "GetCurrentPageId"
.line	2243	call          r2     2     2
.line	2243	gettabup      r3    u0   k46 ; k46 = "ModuleManager"
.line	2243	gettable      r3    r3   k47 ; k47 = "GetModule"
.line	2243	gettabup      r4    u0   k46 ; k46 = "ModuleManager"
.line	2243	gettable      r4    r4   k48 ; k48 = "LobbyModuleConfig"
.line	2243	gettable      r4    r4   k49 ; k49 = "logic_wardrobe_tag_m" (truncated)
.line	2243	call          r3     2     2
.line	2243	self          r4    r3   k50 ; k50 = "GetLocalOperationDat" (truncated)
.line	2243	call          r4     2     2
.line	2243	gettable      r5    r4    r2
.line	2243	gettabup      r6    u0   k51 ; k51 = "log"
.line	2243	gettabup      r7    u0   k52 ; k52 = "bWriteLog"
.line	2243	test          r7     0
.line	2243	jmp            0  l127
.line	2243	gettabup      r7    u0    k1 ; k1 = "table"
.line	2243	gettable      r7    r7    k2 ; k2 = "concat"
.line	2243	newtable      r8     1     0
.line	2243	getupval      r9    u1
.line	2243	loadk        r10   k21 ; k21 = 212
.line	2243	loadk        r11   k53 ; k53 = 41
.line	2243	loadk        r12   k54 ; k54 = 161
.line	2243	loadk        r13   k55 ; k55 = 219
.line	2243	loadk        r14   k56 ; k56 = 102
.line	2243	loadk        r15   k57 ; k57 = 95
.line	2243	loadk        r16   k24 ; k24 = 100
.line	2243	loadk        r17   k58 ; k58 = 132
.line	2243	loadk        r18   k59 ; k59 = 203
.line	2243	loadk        r19   k60 ; k60 = 198
.line	2243	loadk        r20   k61 ; k61 = 252
.line	2243	loadk        r21   k62 ; k62 = 105
.line	2243	loadk        r22   k63 ; k63 = 93
.line	2243	loadk        r23   k64 ; k64 = 167
.line	2243	loadk        r24   k65 ; k65 = 187
.line	2243	loadk        r25   k66 ; k66 = 52
.line	2243	loadk        r26   k67 ; k67 = 10
.line	2243	loadk        r27   k66 ; k66 = 52
.line	2243	loadk        r28   k68 ; k68 = 204
.line	2243	loadk        r29   k22 ; k22 = 238
.line	2243	loadk        r30   k69 ; k69 = 128
.line	2243	loadk        r31   k70 ; k70 = 83
.line	2243	loadk        r32   k42 ; k42 = 23
.line	2243	loadk        r33   k64 ; k64 = 167
.line	2243	loadk        r34   k16 ; k16 = 242
.line	2243	loadk        r35   k71 ; k71 = 246
.line	2243	loadk        r36   k72 ; k72 = 251
.line	2243	loadk        r37   k73 ; k73 = 117
.line	2243	loadk        r38   k74 ; k74 = 92
.line	2243	loadk        r39   k75 ; k75 = 236
.line	2243	loadk        r40   k76 ; k76 = 139
.line	2243	loadk        r41   k77 ; k77 = 63
.line	2243	loadk        r42   k78 ; k78 = 12
.line	2243	loadk        r43   k79 ; k79 = 6
.line	2243	loadk        r44   k80 ; k80 = 147
.line	2243	loadk        r45   k11 ; k11 = 235
.line	2243	loadk        r46   k81 ; k81 = 149
.line	2243	loadk        r47   k82 ; k82 = 114
.line	2243	loadk        r48   k18 ; k18 = 47
.line	2243	loadk        r49   k28 ; k28 = 165
.line	2243	call          r9    41     2
.line	2243	getupval     r10    u1
.line	2243	loadk        r11   k83 ; k83 = 185
.line	2243	loadk        r12   k84 ; k84 = 104
.line	2243	call         r10     3     0
.line	2243	setlist       r8     0     1
.line	2243	call          r7     2     2
.line	2243	gettabup      r8    u0   k85 ; k85 = "tostring"
.line	2243	move          r9    r2
.line	2243	call          r8     2     2
.line	2243	concat        r7    r7    r8
.label	l127
.line	2243	call          r6     2     1
.line	2243	test          r5     0
.line	2243	jmp            0  l136
.line	2243	gettable      r6    r5   k86 ; k86 = "SelectCheckSaveOpera" (truncated)
.line	2243	test          r6     0
.line	2243	jmp            0  l136
.line	2243	gettable      r6    r5   k86 ; k86 = "SelectCheckSaveOpera" (truncated)
.line	2243	eq             0    r6   k87 ; k87 = 0
.line	2243	jmp            0  l246
.label	l136
.line	2243	gettabup      r6    u0   k51 ; k51 = "log"
.line	2243	gettabup      r7    u0   k52 ; k52 = "bWriteLog"
.line	2243	test          r7     0
.line	2243	jmp            0  l244
.line	2243	gettabup      r7    u0    k1 ; k1 = "table"
.line	2243	gettable      r7    r7    k2 ; k2 = "concat"
.line	2243	newtable      r8     1     0
.line	2243	getupval      r9    u1
.line	2243	loadk        r10   k21 ; k21 = 212
.line	2243	loadk        r11   k53 ; k53 = 41
.line	2243	loadk        r12   k54 ; k54 = 161
.line	2243	loadk        r13   k55 ; k55 = 219
.line	2243	loadk        r14   k56 ; k56 = 102
.line	2243	loadk        r15   k57 ; k57 = 95
.line	2243	loadk        r16   k24 ; k24 = 100
.line	2243	loadk        r17   k58 ; k58 = 132
.line	2243	loadk        r18   k59 ; k59 = 203
.line	2243	loadk        r19   k60 ; k60 = 198
.line	2243	loadk        r20   k61 ; k61 = 252
.line	2243	loadk        r21   k62 ; k62 = 105
.line	2243	loadk        r22   k63 ; k63 = 93
.line	2243	loadk        r23   k64 ; k64 = 167
.line	2243	loadk        r24   k65 ; k65 = 187
.line	2243	loadk        r25   k66 ; k66 = 52
.line	2243	loadk        r26   k67 ; k67 = 10
.line	2243	loadk        r27   k66 ; k66 = 52
.line	2243	loadk        r28   k68 ; k68 = 204
.line	2243	loadk        r29   k22 ; k22 = 238
.line	2243	loadk        r30   k69 ; k69 = 128
.line	2243	loadk        r31   k70 ; k70 = 83
.line	2243	loadk        r32   k42 ; k42 = 23
.line	2243	loadk        r33   k64 ; k64 = 167
.line	2243	loadk        r34   k16 ; k16 = 242
.line	2243	loadk        r35   k71 ; k71 = 246
.line	2243	loadk        r36   k72 ; k72 = 251
.line	2243	loadk        r37   k73 ; k73 = 117
.line	2243	loadk        r38   k74 ; k74 = 92
.line	2243	loadk        r39   k75 ; k75 = 236
.line	2243	loadk        r40   k76 ; k76 = 139
.line	2243	loadk        r41   k77 ; k77 = 63
.line	2243	loadk        r42   k78 ; k78 = 12
.line	2243	loadk        r43   k79 ; k79 = 6
.line	2243	loadk        r44   k80 ; k80 = 147
.line	2243	loadk        r45   k88 ; k88 = 241
.line	2243	loadk        r46   k89 ; k89 = 155
.line	2243	loadk        r47   k90 ; k90 = 48
.line	2243	loadk        r48   k91 ; k91 = 21
.line	2243	loadk        r49   k92 ; k92 = 160
.line	2243	call          r9    41     2
.line	2243	getupval     r10    u1
.line	2243	loadk        r11   k27 ; k27 = 245
.line	2243	loadk        r12   k93 ; k93 = 45
.line	2243	loadk        r13   k94 ; k94 = 183
.line	2243	loadk        r14   k95 ; k95 = 159
.line	2243	loadk        r15   k96 ; k96 = 96
.line	2243	loadk        r16   k97 ; k97 = 81
.line	2243	loadk        r17   k98 ; k98 = 97
.line	2243	loadk        r18   k99 ; k99 = 193
.line	2243	loadk        r19  k100 ; k100 = 225
.line	2243	loadk        r20   k60 ; k60 = 198
.line	2243	loadk        r21  k101 ; k101 = 233
.line	2243	loadk        r22  k102 ; k102 = 32
.line	2243	loadk        r23   k63 ; k63 = 93
.line	2243	loadk        r24  k103 ; k103 = 232
.line	2243	loadk        r25  k104 ; k104 = 157
.line	2243	loadk        r26   k66 ; k66 = 52
.line	2243	loadk        r27  k105 ; k105 = 22
.line	2243	loadk        r28  k105 ; k105 = 22
.line	2243	loadk        r29  k106 ; k106 = 215
.line	2243	loadk        r30  k107 ; k107 = 175
.line	2243	loadk        r31   k37 ; k37 = 144
.line	2243	loadk        r32   k98 ; k98 = 97
.line	2243	loadk        r33  k108 ; k108 = 20
.line	2243	loadk        r34  k109 ; k109 = 152
.line	2243	loadk        r35  k110 ; k110 = 243
.line	2243	loadk        r36  k111 ; k111 = 131
.line	2243	loadk        r37  k112 ; k112 = 171
.line	2243	call         r10    28     0
.line	2243	setlist       r8     0     1
.line	2243	call          r7     2     2
.line	2243	gettabup      r8    u0   k85 ; k85 = "tostring"
.line	2243	move          r9    r2
.line	2243	call          r8     2     2
.line	2243	getupval      r9    u1
.line	2243	loadk        r10   k40 ; k40 = 163
.line	2243	loadk        r11  k113 ; k113 = 58
.line	2243	loadk        r12  k114 ; k114 = 182
.line	2243	loadk        r13  k115 ; k115 = 217
.line	2243	loadk        r14   k56 ; k56 = 102
.line	2243	loadk        r15  k116 ; k116 = 85
.line	2243	loadk        r16   k73 ; k73 = 117
.line	2243	loadk        r17  k117 ; k117 = 137
.line	2243	loadk        r18   k64 ; k64 = 167
.line	2243	loadk        r19   k12 ; k12 = 220
.line	2243	loadk        r20  k103 ; k103 = 232
.line	2243	loadk        r21   k62 ; k62 = 105
.line	2243	loadk        r22  k118 ; k118 = 80
.line	2243	loadk        r23   k13 ; k13 = 250
.line	2243	loadk        r24  k119 ; k119 = 207
.line	2243	loadk        r25  k120 ; k120 = 34
.line	2243	loadk        r26  k105 ; k105 = 22
.line	2243	loadk        r27  k121 ; k121 = 30
.line	2243	loadk        r28  k122 ; k122 = 194
.line	2243	loadk        r29   k13 ; k13 = 250
.line	2243	loadk        r30   k17 ; k17 = 136
.line	2243	loadk        r31  k123 ; k123 = 116
.line	2243	call          r9    23     2
.line	2243	concat        r7    r7    r9
.label	l244
.line	2243	call          r6     2     1
.line	2243	jmp            0  l328
.label	l246
.line	2243	newtable      r6     0     4
.line	2243	gettable      r7    r5  k124 ; k124 = "StartYear"
.line	2243	settable      r6  k124    r7 ; k124 = "StartYear"
.line	2243	gettable      r7    r5  k125 ; k125 = "StartMonth"
.line	2243	settable      r6  k125    r7 ; k125 = "StartMonth"
.line	2243	gettable      r7    r5  k126 ; k126 = "EndYear"
.line	2243	settable      r6  k126    r7 ; k126 = "EndYear"
.line	2243	gettable      r7    r5  k127 ; k127 = "EndMonth"
.line	2243	settable      r6  k127    r7 ; k127 = "EndMonth"
.line	2243	gettabup      r7    u0   k51 ; k51 = "log"
.line	2243	gettabup      r8    u0   k52 ; k52 = "bWriteLog"
.line	2243	test          r8     0
.line	2243	jmp            0  l318
.line	2243	gettabup      r8    u0  k128 ; k128 = "string"
.line	2243	gettable      r8    r8  k129 ; k129 = "format"
.line	2243	gettabup      r9    u0    k1 ; k1 = "table"
.line	2243	gettable      r9    r9    k2 ; k2 = "concat"
.line	2243	newtable     r10     1     0
.line	2243	getupval     r11    u1
.line	2243	loadk        r12   k21 ; k21 = 212
.line	2243	loadk        r13   k53 ; k53 = 41
.line	2243	loadk        r14   k54 ; k54 = 161
.line	2243	loadk        r15   k55 ; k55 = 219
.line	2243	loadk        r16   k56 ; k56 = 102
.line	2243	loadk        r17   k57 ; k57 = 95
.line	2243	loadk        r18   k24 ; k24 = 100
.line	2243	loadk        r19   k58 ; k58 = 132
.line	2243	loadk        r20   k59 ; k59 = 203
.line	2243	loadk        r21   k60 ; k60 = 198
.line	2243	loadk        r22   k61 ; k61 = 252
.line	2243	loadk        r23   k62 ; k62 = 105
.line	2243	loadk        r24   k63 ; k63 = 93
.line	2243	loadk        r25   k64 ; k64 = 167
.line	2243	loadk        r26   k65 ; k65 = 187
.line	2243	loadk        r27   k66 ; k66 = 52
.line	2243	loadk        r28   k67 ; k67 = 10
.line	2243	loadk        r29   k66 ; k66 = 52
.line	2243	loadk        r30   k68 ; k68 = 204
.line	2243	loadk        r31   k22 ; k22 = 238
.line	2243	loadk        r32   k69 ; k69 = 128
.line	2243	loadk        r33   k70 ; k70 = 83
.line	2243	loadk        r34   k42 ; k42 = 23
.line	2243	loadk        r35   k64 ; k64 = 167
.line	2243	loadk        r36   k16 ; k16 = 242
.line	2243	loadk        r37   k71 ; k71 = 246
.line	2243	loadk        r38   k72 ; k72 = 251
.line	2243	loadk        r39   k73 ; k73 = 117
.line	2243	loadk        r40   k74 ; k74 = 92
.line	2243	loadk        r41   k75 ; k75 = 236
.line	2243	loadk        r42   k76 ; k76 = 139
.line	2243	loadk        r43   k77 ; k77 = 63
.line	2243	loadk        r44   k78 ; k78 = 12
.line	2243	loadk        r45   k79 ; k79 = 6
.line	2243	loadk        r46  k104 ; k104 = 157
.line	2243	loadk        r47  k130 ; k130 = 191
.line	2243	loadk        r48   k69 ; k69 = 128
.line	2243	loadk        r49  k131 ; k131 = 113
.line	2243	loadk        r50   k25 ; k25 = 4
.line	2243	loadk        r51   k17 ; k17 = 136
.line	2243	call         r11    41     2
.line	2243	getupval     r12    u1
.line	2243	loadk        r13  k132 ; k132 = 231
.line	2243	loadk        r14   k84 ; k84 = 104
.line	2243	loadk        r15   k22 ; k22 = 238
.line	2243	loadk        r16   k95 ; k95 = 159
.line	2243	loadk        r17  k133 ; k133 = 49
.line	2243	loadk        r18  k134 ; k134 = 67
.line	2243	call         r12     7     0
.line	2243	setlist      r10     0     1
.line	2243	call          r9     2     2
.line	2243	move         r10    r2
.line	2243	call          r8     3     2
.label	l318
.line	2243	call          r7     2     1
.line	2243	self          r7    r0  k135 ; k135 = "CompatibilityCornerT" (truncated)
.line	2243	gettable      r9    r5  k136 ; k136 = "SelectCornerTagList"
.line	2243	call          r7     3     2
.line	2243	self          r8    r3  k137 ; k137 = "ConfirmSelection"
.line	2243	move         r10    r7
.line	2243	gettable     r11    r5  k138 ; k138 = "SelectCustomTagList"
.line	2243	move         r12    r6
.line	2243	loadbool     r13     0     0
.line	2243	call          r8     6     1
.label	l328
.line	2243	return        r0     1
.line	2243	move          r0    r0
.line	2243	move          r0    r0
.line	2243	return        r0     1

.function	main/f129

.source	null
.linedefined	2265
.lastlinedefined	2283
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log_tree"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	212
.constant	k4	41
.constant	k5	161
.constant	k6	219
.constant	k7	102
.constant	k8	95
.constant	k9	100
.constant	k10	132
.constant	k11	203
.constant	k12	198
.constant	k13	252
.constant	k14	105
.constant	k15	93
.constant	k16	167
.constant	k17	172
.constant	k18	30
.constant	k19	8
.constant	k20	194
.constant	k21	251
.constant	k22	141
.constant	k23	98
.constant	k24	31
.constant	k25	189
.constant	k26	254
.constant	k27	205
.constant	k28	242
.constant	k29	83
.constant	k30	65
.constant	k31	255
.constant	k32	145
.constant	k33	51
.constant	k34	17
.constant	k35	60
.constant	k36	210
.constant	k37	248
.constant	k38	183
.constant	k39	113
.constant	k40	5
.constant	k41	169
.constant	k42	230
.constant	k43	"next"
.constant	k44	"ModuleManager"
.constant	k45	"GetModule"
.constant	k46	"CommonModuleConfig"
.constant	k47	"logic_outfit_combination"
.constant	k48	"pairs"
.constant	k49	true
.constant	k50	"type"
.constant	k51	240
.constant	k52	214
.constant	k53	122
.constant	k54	87
.constant	k55	"GetCornerTagIDByTypeName"
.constant	k56	237
.constant	k57	61
.constant	k58	190
.constant	k59	221
.constant	k60	66
.constant	k61	104
.constant	k62	218
.constant	k63	103

.line	2265	gettabup      r2    u0    k0 ; k0 = "log_tree"
.line	2265	gettabup      r3    u0    k1 ; k1 = "table"
.line	2265	gettable      r3    r3    k2 ; k2 = "concat"
.line	2265	newtable      r4     1     0
.line	2265	getupval      r5    u1
.line	2265	loadk         r6    k3 ; k3 = 212
.line	2265	loadk         r7    k4 ; k4 = 41
.line	2265	loadk         r8    k5 ; k5 = 161
.line	2265	loadk         r9    k6 ; k6 = 219
.line	2265	loadk        r10    k7 ; k7 = 102
.line	2265	loadk        r11    k8 ; k8 = 95
.line	2265	loadk        r12    k9 ; k9 = 100
.line	2265	loadk        r13   k10 ; k10 = 132
.line	2265	loadk        r14   k11 ; k11 = 203
.line	2265	loadk        r15   k12 ; k12 = 198
.line	2265	loadk        r16   k13 ; k13 = 252
.line	2265	loadk        r17   k14 ; k14 = 105
.line	2265	loadk        r18   k15 ; k15 = 93
.line	2265	loadk        r19   k16 ; k16 = 167
.line	2265	loadk        r20   k17 ; k17 = 172
.line	2265	loadk        r21    k4 ; k4 = 41
.line	2265	loadk        r22   k18 ; k18 = 30
.line	2265	loadk        r23   k19 ; k19 = 8
.line	2265	loadk        r24   k20 ; k20 = 194
.line	2265	loadk        r25   k21 ; k21 = 251
.line	2265	loadk        r26   k22 ; k22 = 141
.line	2265	loadk        r27   k23 ; k23 = 98
.line	2265	loadk        r28   k24 ; k24 = 31
.line	2265	loadk        r29   k25 ; k25 = 189
.line	2265	loadk        r30   k26 ; k26 = 254
.line	2265	loadk        r31   k27 ; k27 = 205
.line	2265	loadk        r32   k28 ; k28 = 242
.line	2265	loadk        r33   k29 ; k29 = 83
.line	2265	loadk        r34   k30 ; k30 = 65
.line	2265	loadk        r35   k31 ; k31 = 255
.line	2265	loadk        r36   k32 ; k32 = 145
.line	2265	loadk        r37   k33 ; k33 = 51
.line	2265	loadk        r38   k34 ; k34 = 17
.line	2265	loadk        r39   k35 ; k35 = 60
.line	2265	loadk        r40   k36 ; k36 = 210
.line	2265	loadk        r41   k37 ; k37 = 248
.line	2265	loadk        r42   k38 ; k38 = 183
.line	2265	loadk        r43   k39 ; k39 = 113
.line	2265	loadk        r44   k40 ; k40 = 5
.line	2265	loadk        r45   k41 ; k41 = 169
.line	2265	call          r5    41     2
.line	2265	getupval      r6    u1
.line	2265	loadk         r7   k42 ; k42 = 230
.line	2265	call          r6     2     0
.line	2265	setlist       r4     0     1
.line	2265	call          r3     2     2
.line	2265	move          r4    r1
.line	2265	call          r2     3     1
.line	2265	newtable      r2     0     0
.line	2265	test          r1     0
.line	2265	jmp            0  l108
.line	2265	gettabup      r3    u0   k43 ; k43 = "next"
.line	2265	move          r4    r1
.line	2265	call          r3     2     2
.line	2265	test          r3     0
.line	2265	jmp            0  l108
.line	2265	gettabup      r3    u0   k44 ; k44 = "ModuleManager"
.line	2265	gettable      r3    r3   k45 ; k45 = "GetModule"
.line	2265	gettabup      r4    u0   k44 ; k44 = "ModuleManager"
.line	2265	gettable      r4    r4   k46 ; k46 = "CommonModuleConfig"
.line	2265	gettable      r4    r4   k47 ; k47 = "logic_outfit_combina" (truncated)
.line	2265	call          r3     2     2
.line	2265	gettabup      r4    u0   k48 ; k48 = "pairs"
.line	2265	move          r5    r1
.line	2265	call          r4     2     4
.line	2265	jmp            0  l106
.line	2265	eq             0    r8   k49 ; k49 = true
.line	2265	jmp            0  l106
.line	2265	gettabup      r9    u0   k50 ; k50 = "type"
.line	2265	move         r10    r7
.line	2265	call          r9     2     2
.line	2265	getupval     r10    u1
.line	2265	loadk        r11   k51 ; k51 = 240
.line	2265	loadk        r12   k35 ; k35 = 60
.line	2265	loadk        r13    k5 ; k5 = 161
.line	2265	loadk        r14   k52 ; k52 = 214
.line	2265	loadk        r15   k53 ; k53 = 122
.line	2265	loadk        r16   k54 ; k54 = 87
.line	2265	call         r10     7     2
.line	2265	eq             0    r9   r10
.line	2265	jmp            0   l92
.line	2265	self          r9    r3   k55 ; k55 = "GetCornerTagIDByType" (truncated)
.line	2265	move         r11    r7
.line	2265	call          r9     3     2
.line	2265	settable      r2    r9   k49 ; k49 = true
.line	2265	jmp            0  l106
.label	l92
.line	2265	gettabup      r9    u0   k50 ; k50 = "type"
.line	2265	move         r10    r7
.line	2265	call          r9     2     2
.line	2265	getupval     r10    u1
.line	2265	loadk        r11   k56 ; k56 = 237
.line	2265	loadk        r12   k57 ; k57 = 61
.line	2265	loadk        r13   k58 ; k58 = 190
.line	2265	loadk        r14   k59 ; k59 = 221
.line	2265	loadk        r15   k39 ; k39 = 113
.line	2265	loadk        r16   k60 ; k60 = 66
.line	2265	call         r10     7     2
.line	2265	eq             0    r9   r10
.line	2265	jmp            0  l106
.line	2265	settable      r2    r7   k49 ; k49 = true
.label	l106
.line	2265	move          r0    r0
.line	2265	move          r0    r0
.label	l108
.line	2265	gettabup      r3    u0    k0 ; k0 = "log_tree"
.line	2265	gettabup      r4    u0    k1 ; k1 = "table"
.line	2265	gettable      r4    r4    k2 ; k2 = "concat"
.line	2265	newtable      r5     1     0
.line	2265	getupval      r6    u1
.line	2265	loadk         r7    k3 ; k3 = 212
.line	2265	loadk         r8    k4 ; k4 = 41
.line	2265	loadk         r9    k5 ; k5 = 161
.line	2265	loadk        r10    k6 ; k6 = 219
.line	2265	loadk        r11    k7 ; k7 = 102
.line	2265	loadk        r12    k8 ; k8 = 95
.line	2265	loadk        r13    k9 ; k9 = 100
.line	2265	loadk        r14   k10 ; k10 = 132
.line	2265	loadk        r15   k11 ; k11 = 203
.line	2265	loadk        r16   k12 ; k12 = 198
.line	2265	loadk        r17   k13 ; k13 = 252
.line	2265	loadk        r18   k14 ; k14 = 105
.line	2265	loadk        r19   k15 ; k15 = 93
.line	2265	loadk        r20   k16 ; k16 = 167
.line	2265	loadk        r21   k17 ; k17 = 172
.line	2265	loadk        r22    k4 ; k4 = 41
.line	2265	loadk        r23   k18 ; k18 = 30
.line	2265	loadk        r24   k19 ; k19 = 8
.line	2265	loadk        r25   k20 ; k20 = 194
.line	2265	loadk        r26   k21 ; k21 = 251
.line	2265	loadk        r27   k22 ; k22 = 141
.line	2265	loadk        r28   k23 ; k23 = 98
.line	2265	loadk        r29   k24 ; k24 = 31
.line	2265	loadk        r30   k25 ; k25 = 189
.line	2265	loadk        r31   k26 ; k26 = 254
.line	2265	loadk        r32   k27 ; k27 = 205
.line	2265	loadk        r33   k28 ; k28 = 242
.line	2265	loadk        r34   k29 ; k29 = 83
.line	2265	loadk        r35   k30 ; k30 = 65
.line	2265	loadk        r36   k31 ; k31 = 255
.line	2265	loadk        r37   k32 ; k32 = 145
.line	2265	loadk        r38   k33 ; k33 = 51
.line	2265	loadk        r39   k34 ; k34 = 17
.line	2265	loadk        r40   k35 ; k35 = 60
.line	2265	loadk        r41   k36 ; k36 = 210
.line	2265	loadk        r42   k37 ; k37 = 248
.line	2265	loadk        r43   k38 ; k38 = 183
.line	2265	loadk        r44   k39 ; k39 = 113
.line	2265	loadk        r45   k40 ; k40 = 5
.line	2265	loadk        r46   k41 ; k41 = 169
.line	2265	call          r6    41     2
.line	2265	getupval      r7    u1
.line	2265	loadk         r8   k42 ; k42 = 230
.line	2265	loadk         r9   k61 ; k61 = 104
.line	2265	loadk        r10    k5 ; k5 = 161
.line	2265	loadk        r11   k62 ; k62 = 218
.line	2265	loadk        r12   k63 ; k63 = 103
.line	2265	call          r7     6     0
.line	2265	setlist       r5     0     1
.line	2265	call          r4     2     2
.line	2265	move          r5    r2
.line	2265	call          r3     3     1
.line	2265	return        r2     2
.line	2265	return        r0     1
.line	2265	move          r0    r0
.line	2265	move          r0    r0
.line	2265	move          r0    r0
.line	2265	return        r0     1

.function	main/f130

.source	null
.linedefined	2285
.lastlinedefined	2289
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"logic_wardrobe_tag_mgr"
.constant	k4	"UpdateItemList"
.constant	k5	"TryLoadSaveOperation"

.line	2285	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	2285	gettable      r2    r2    k1 ; k1 = "GetModule"
.line	2285	gettabup      r3    u0    k0 ; k0 = "ModuleManager"
.line	2285	gettable      r3    r3    k2 ; k2 = "LobbyModuleConfig"
.line	2285	gettable      r3    r3    k3 ; k3 = "logic_wardrobe_tag_m" (truncated)
.line	2285	call          r2     2     2
.line	2285	self          r3    r2    k4 ; k4 = "UpdateItemList"
.line	2285	move          r5    r1
.line	2285	call          r3     3     1
.line	2285	self          r3    r0    k5 ; k5 = "TryLoadSaveOperation"
.line	2285	call          r3     2     1
.line	2285	return        r0     1
.line	2285	move          r0    r0
.line	2285	move          r0    r0
.line	2285	return        r0     1

.function	main/f131

.source	null
.linedefined	2291
.lastlinedefined	2313
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	1	true
.upvalue	"U1"	5	true
.upvalue	"U2"	0	false

.constant	k0	"ReportTLogEnum"
.constant	k1	"Wardrobe"
.constant	k2	"resID"
.constant	k3	"res_id"
.constant	k4	0
.constant	k5	"string"
.constant	k6	"format"
.constant	k7	166
.constant	k8	59
.constant	k9	"WardrobeSuit"
.constant	k10	"FashionBag"
.constant	k11	"next"
.constant	k12	"table"
.constant	k13	"concat"
.constant	k14	175
.constant	k15	"SharePackage"
.constant	k16	184
.constant	k17	"require"
.constant	k18	224
.constant	k19	36
.constant	k20	186
.constant	k21	218
.constant	k22	122
.constant	k23	68
.constant	k24	40
.constant	k25	146
.constant	k26	235
.constant	k27	220
.constant	k28	250
.constant	k29	46
.constant	k30	93
.constant	k31	242
.constant	k32	129
.constant	k33	32
.constant	k34	26
.constant	k35	31
.constant	k36	141
.constant	k37	251
.constant	k38	136
.constant	k39	111
.constant	k40	17
.constant	k41	255
.constant	k42	227
.constant	k43	213
.constant	k44	228
.constant	k45	119
.constant	k46	113
.constant	k47	154
.constant	k48	38
.constant	k49	12
.constant	k50	199
.constant	k51	192
.constant	k52	100
.constant	k53	15
.constant	k54	173
.constant	k55	240
.constant	k56	"ReportTLogEvent"
.constant	k57	"TLogEventDefine"
.constant	k58	"MainCity_Dress_Click"

.line	2291	getupval      r2    u0
.line	2291	call          r2     1     2
.line	2291	gettabup      r3    u1    k0 ; k0 = "ReportTLogEnum"
.line	2291	gettable      r3    r3    k1 ; k1 = "Wardrobe"
.line	2291	eq             0    r0    r3
.line	2291	jmp            0   l24
.line	2291	gettable      r3    r1    k2 ; k2 = "resID"
.line	2291	test          r3     1
.line	2291	jmp            0   l14
.line	2291	gettable      r3    r1    k3 ; k3 = "res_id"
.line	2291	test          r3     1
.line	2291	jmp            0   l14
.line	2291	loadk         r3    k4 ; k4 = 0
.label	l14
.line	2291	gettabup      r4    u2    k5 ; k5 = "string"
.line	2291	gettable      r4    r4    k6 ; k6 = "format"
.line	2291	getupval      r5    u0
.line	2291	loadk         r6    k7 ; k7 = 166
.line	2291	loadk         r7    k8 ; k8 = 59
.line	2291	call          r5     3     2
.line	2291	move          r6    r3
.line	2291	call          r4     3     2
.line	2291	move          r2    r4
.line	2291	jmp            0   l88
.label	l24
.line	2291	gettabup      r3    u1    k0 ; k0 = "ReportTLogEnum"
.line	2291	gettable      r3    r3    k9 ; k9 = "WardrobeSuit"
.line	2291	eq             0    r0    r3
.line	2291	jmp            0   l41
.line	2291	testset       r3    r1     1
.line	2291	jmp            0   l31
.line	2291	loadk         r3    k4 ; k4 = 0
.label	l31
.line	2291	gettabup      r4    u2    k5 ; k5 = "string"
.line	2291	gettable      r4    r4    k6 ; k6 = "format"
.line	2291	getupval      r5    u0
.line	2291	loadk         r6    k7 ; k7 = 166
.line	2291	loadk         r7    k8 ; k8 = 59
.line	2291	call          r5     3     2
.line	2291	move          r6    r3
.line	2291	call          r4     3     2
.line	2291	move          r2    r4
.line	2291	jmp            0   l88
.label	l41
.line	2291	gettabup      r3    u1    k0 ; k0 = "ReportTLogEnum"
.line	2291	gettable      r3    r3   k10 ; k10 = "FashionBag"
.line	2291	eq             0    r0    r3
.line	2291	jmp            0   l65
.line	2291	getupval      r3    u0
.line	2291	call          r3     1     2
.line	2291	move          r2    r3
.line	2291	test          r1     0
.line	2291	jmp            0   l88
.line	2291	gettabup      r3    u2   k11 ; k11 = "next"
.line	2291	move          r4    r1
.line	2291	call          r3     2     2
.line	2291	test          r3     0
.line	2291	jmp            0   l88
.line	2291	move          r3    r2
.line	2291	gettabup      r4    u2   k12 ; k12 = "table"
.line	2291	gettable      r4    r4   k13 ; k13 = "concat"
.line	2291	move          r5    r1
.line	2291	getupval      r6    u0
.line	2291	loadk         r7   k14 ; k14 = 175
.line	2291	call          r6     2     2
.line	2291	call          r4     3     2
.line	2291	concat        r2    r3    r4
.line	2291	jmp            0   l88
.label	l65
.line	2291	gettabup      r3    u1    k0 ; k0 = "ReportTLogEnum"
.line	2291	gettable      r3    r3   k15 ; k15 = "SharePackage"
.line	2291	eq             0    r0    r3
.line	2291	jmp            0   l88
.line	2291	getupval      r3    u0
.line	2291	call          r3     1     2
.line	2291	move          r2    r3
.line	2291	test          r1     0
.line	2291	jmp            0   l88
.line	2291	gettabup      r3    u2   k11 ; k11 = "next"
.line	2291	move          r4    r1
.line	2291	call          r3     2     2
.line	2291	test          r3     0
.line	2291	jmp            0   l88
.line	2291	move          r3    r2
.line	2291	gettabup      r4    u2   k12 ; k12 = "table"
.line	2291	gettable      r4    r4   k13 ; k13 = "concat"
.line	2291	move          r5    r1
.line	2291	getupval      r6    u0
.line	2291	loadk         r7   k14 ; k14 = 175
.line	2291	call          r6     2     2
.line	2291	call          r4     3     2
.line	2291	concat        r2    r3    r4
.label	l88
.line	2291	move          r3    r2
.line	2291	getupval      r4    u0
.line	2291	loadk         r5   k16 ; k16 = 184
.line	2291	call          r4     2     2
.line	2291	concat        r2    r3    r4
.line	2291	gettabup      r3    u2   k17 ; k17 = "require"
.line	2291	gettabup      r4    u2   k12 ; k12 = "table"
.line	2291	gettable      r4    r4   k13 ; k13 = "concat"
.line	2291	newtable      r5     1     0
.line	2291	getupval      r6    u0
.line	2291	loadk         r7   k18 ; k18 = 224
.line	2291	loadk         r8   k19 ; k19 = 36
.line	2291	loadk         r9   k20 ; k20 = 186
.line	2291	loadk        r10   k21 ; k21 = 218
.line	2291	loadk        r11   k22 ; k22 = 122
.line	2291	loadk        r12   k23 ; k23 = 68
.line	2291	loadk        r13   k24 ; k24 = 40
.line	2291	loadk        r14   k25 ; k25 = 146
.line	2291	loadk        r15   k26 ; k26 = 235
.line	2291	loadk        r16   k27 ; k27 = 220
.line	2291	loadk        r17   k28 ; k28 = 250
.line	2291	loadk        r18   k29 ; k29 = 46
.line	2291	loadk        r19   k30 ; k30 = 93
.line	2291	loadk        r20   k31 ; k31 = 242
.line	2291	loadk        r21   k32 ; k32 = 129
.line	2291	loadk        r22   k33 ; k33 = 32
.line	2291	loadk        r23   k34 ; k34 = 26
.line	2291	loadk        r24   k35 ; k35 = 31
.line	2291	loadk        r25   k36 ; k36 = 141
.line	2291	loadk        r26   k37 ; k37 = 251
.line	2291	loadk        r27   k38 ; k38 = 136
.line	2291	loadk        r28   k39 ; k39 = 111
.line	2291	loadk        r29   k40 ; k40 = 17
.line	2291	loadk        r30   k41 ; k41 = 255
.line	2291	loadk        r31   k42 ; k42 = 227
.line	2291	loadk        r32   k43 ; k43 = 213
.line	2291	loadk        r33   k44 ; k44 = 228
.line	2291	loadk        r34   k45 ; k45 = 119
.line	2291	loadk        r35   k46 ; k46 = 113
.line	2291	loadk        r36   k41 ; k41 = 255
.line	2291	loadk        r37   k47 ; k47 = 154
.line	2291	loadk        r38   k48 ; k48 = 38
.line	2291	loadk        r39   k49 ; k49 = 12
.line	2291	loadk        r40   k34 ; k34 = 26
.line	2291	loadk        r41   k50 ; k50 = 199
.line	2291	loadk        r42   k51 ; k51 = 192
.line	2291	loadk        r43   k32 ; k32 = 129
.line	2291	loadk        r44   k52 ; k52 = 100
.line	2291	loadk        r45   k53 ; k53 = 15
.line	2291	loadk        r46   k54 ; k54 = 173
.line	2291	call          r6    41     2
.line	2291	getupval      r7    u0
.line	2291	loadk         r8   k55 ; k55 = 240
.line	2291	call          r7     2     0
.line	2291	setlist       r5     0     1
.line	2291	call          r4     2     2
.line	2291	call          r3     2     2
.line	2291	gettable      r4    r3   k56 ; k56 = "ReportTLogEvent"
.line	2291	gettabup      r5    u2   k57 ; k57 = "TLogEventDefine"
.line	2291	gettable      r5    r5   k58 ; k58 = "MainCity_Dress_Click"
.line	2291	loadk         r6    k4 ; k4 = 0
.line	2291	move          r7    r2
.line	2291	call          r4     4     1
.line	2291	return        r0     1
.line	2291	move          r0    r0
.line	2291	move          r0    r0
.line	2291	return        r0     1

.function	main/f132

.source	null
.linedefined	2315
.lastlinedefined	2325
.numparams	3
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	15	true

.constant	k0	"pre"
.constant	k1	"current"
.constant	k2	"GameStatus"
.constant	k3	"Fighting"
.constant	k4	"IsInMainCity"
.constant	k5	"IsCollectionHallMode"
.constant	k6	"log"
.constant	k7	"bWriteLog"
.constant	k8	"string"
.constant	k9	"format"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	212
.constant	k13	41
.constant	k14	161
.constant	k15	219
.constant	k16	102
.constant	k17	95
.constant	k18	100
.constant	k19	132
.constant	k20	203
.constant	k21	198
.constant	k22	252
.constant	k23	105
.constant	k24	93
.constant	k25	179
.constant	k26	160
.constant	k27	40
.constant	k28	52
.constant	k29	25
.constant	k30	206
.constant	k31	234
.constant	k32	183
.constant	k33	116
.constant	k34	23
.constant	k35	165
.constant	k36	242
.constant	k37	250
.constant	k38	227
.constant	k39	113
.constant	k40	64
.constant	k41	154
.constant	k42	118
.constant	k43	37
.constant	k44	1
.constant	k45	247
.constant	k46	128
.constant	k47	121
.constant	k48	8
.constant	k49	166
.constant	k50	173
.constant	k51	"PauseFrameLoading"
.constant	k52	"Lobby"
.constant	k53	47
.constant	k54	7
.constant	k55	209
.constant	k56	253
.constant	k57	141
.constant	k58	62
.constant	k59	"RestoreFrameLoading"

.line	2315	gettable      r3    r2    k0 ; k0 = "pre"
.line	2315	gettable      r4    r2    k1 ; k1 = "current"
.line	2315	gettabup      r5    u0    k2 ; k2 = "GameStatus"
.line	2315	gettable      r5    r5    k3 ; k3 = "Fighting"
.line	2315	eq             0    r4    r5
.line	2315	jmp            0   l78
.line	2315	gettabup      r5    u0    k2 ; k2 = "GameStatus"
.line	2315	gettable      r5    r5    k4 ; k4 = "IsInMainCity"
.line	2315	call          r5     1     2
.line	2315	test          r5     1
.line	2315	jmp            0   l78
.line	2315	gettabup      r5    u0    k2 ; k2 = "GameStatus"
.line	2315	gettable      r5    r5    k5 ; k5 = "IsCollectionHallMode"
.line	2315	call          r5     1     2
.line	2315	test          r5     1
.line	2315	jmp            0   l78
.line	2315	gettabup      r5    u0    k6 ; k6 = "log"
.line	2315	gettabup      r6    u0    k7 ; k7 = "bWriteLog"
.line	2315	test          r6     0
.line	2315	jmp            0   l74
.line	2315	gettabup      r6    u0    k8 ; k8 = "string"
.line	2315	gettable      r6    r6    k9 ; k9 = "format"
.line	2315	gettabup      r7    u0   k10 ; k10 = "table"
.line	2315	gettable      r7    r7   k11 ; k11 = "concat"
.line	2315	newtable      r8     1     0
.line	2315	getupval      r9    u1
.line	2315	loadk        r10   k12 ; k12 = 212
.line	2315	loadk        r11   k13 ; k13 = 41
.line	2315	loadk        r12   k14 ; k14 = 161
.line	2315	loadk        r13   k15 ; k15 = 219
.line	2315	loadk        r14   k16 ; k16 = 102
.line	2315	loadk        r15   k17 ; k17 = 95
.line	2315	loadk        r16   k18 ; k18 = 100
.line	2315	loadk        r17   k19 ; k19 = 132
.line	2315	loadk        r18   k20 ; k20 = 203
.line	2315	loadk        r19   k21 ; k21 = 198
.line	2315	loadk        r20   k22 ; k22 = 252
.line	2315	loadk        r21   k23 ; k23 = 105
.line	2315	loadk        r22   k24 ; k24 = 93
.line	2315	loadk        r23   k25 ; k25 = 179
.line	2315	loadk        r24   k26 ; k26 = 160
.line	2315	loadk        r25   k27 ; k27 = 40
.line	2315	loadk        r26   k28 ; k28 = 52
.line	2315	loadk        r27   k29 ; k29 = 25
.line	2315	loadk        r28   k30 ; k30 = 206
.line	2315	loadk        r29   k31 ; k31 = 234
.line	2315	loadk        r30   k32 ; k32 = 183
.line	2315	loadk        r31   k33 ; k33 = 116
.line	2315	loadk        r32   k34 ; k34 = 23
.line	2315	loadk        r33   k35 ; k35 = 165
.line	2315	loadk        r34   k36 ; k36 = 242
.line	2315	loadk        r35   k37 ; k37 = 250
.line	2315	loadk        r36   k38 ; k38 = 227
.line	2315	loadk        r37   k39 ; k39 = 113
.line	2315	loadk        r38   k40 ; k40 = 64
.line	2315	loadk        r39   k31 ; k31 = 234
.line	2315	loadk        r40   k41 ; k41 = 154
.line	2315	loadk        r41   k42 ; k42 = 118
.line	2315	loadk        r42   k43 ; k43 = 37
.line	2315	loadk        r43   k44 ; k44 = 1
.line	2315	loadk        r44   k12 ; k12 = 212
.line	2315	loadk        r45   k45 ; k45 = 247
.line	2315	loadk        r46   k46 ; k46 = 128
.line	2315	loadk        r47   k47 ; k47 = 121
.line	2315	loadk        r48   k48 ; k48 = 8
.line	2315	loadk        r49   k49 ; k49 = 166
.line	2315	call          r9    41     2
.line	2315	getupval     r10    u1
.line	2315	loadk        r11   k50 ; k50 = 173
.line	2315	call         r10     2     0
.line	2315	setlist       r8     0     1
.line	2315	call          r7     2     2
.line	2315	call          r6     2     2
.label	l74
.line	2315	call          r5     2     1
.line	2315	getupval      r5    u2
.line	2315	self          r5    r5   k51 ; k51 = "PauseFrameLoading"
.line	2315	call          r5     2     1
.label	l78
.line	2315	gettabup      r5    u0    k2 ; k2 = "GameStatus"
.line	2315	gettable      r5    r5    k3 ; k3 = "Fighting"
.line	2315	eq             0    r3    r5
.line	2315	jmp            0  l137
.line	2315	gettabup      r5    u0    k2 ; k2 = "GameStatus"
.line	2315	gettable      r5    r5   k52 ; k52 = "Lobby"
.line	2315	eq             0    r4    r5
.line	2315	jmp            0  l137
.line	2315	gettabup      r5    u0    k6 ; k6 = "log"
.line	2315	gettabup      r6    u0    k7 ; k7 = "bWriteLog"
.line	2315	test          r6     0
.line	2315	jmp            0  l133
.line	2315	gettabup      r6    u0    k8 ; k8 = "string"
.line	2315	gettable      r6    r6    k9 ; k9 = "format"
.line	2315	getupval      r7    u1
.line	2315	loadk         r8   k12 ; k12 = 212
.line	2315	loadk         r9   k13 ; k13 = 41
.line	2315	loadk        r10   k14 ; k14 = 161
.line	2315	loadk        r11   k15 ; k15 = 219
.line	2315	loadk        r12   k16 ; k16 = 102
.line	2315	loadk        r13   k17 ; k17 = 95
.line	2315	loadk        r14   k18 ; k18 = 100
.line	2315	loadk        r15   k19 ; k19 = 132
.line	2315	loadk        r16   k20 ; k20 = 203
.line	2315	loadk        r17   k21 ; k21 = 198
.line	2315	loadk        r18   k22 ; k22 = 252
.line	2315	loadk        r19   k23 ; k23 = 105
.line	2315	loadk        r20   k24 ; k24 = 93
.line	2315	loadk        r21   k25 ; k25 = 179
.line	2315	loadk        r22   k26 ; k26 = 160
.line	2315	loadk        r23   k27 ; k27 = 40
.line	2315	loadk        r24   k28 ; k28 = 52
.line	2315	loadk        r25   k29 ; k29 = 25
.line	2315	loadk        r26   k30 ; k30 = 206
.line	2315	loadk        r27   k31 ; k31 = 234
.line	2315	loadk        r28   k32 ; k32 = 183
.line	2315	loadk        r29   k33 ; k33 = 116
.line	2315	loadk        r30   k34 ; k34 = 23
.line	2315	loadk        r31   k35 ; k35 = 165
.line	2315	loadk        r32   k36 ; k36 = 242
.line	2315	loadk        r33   k37 ; k37 = 250
.line	2315	loadk        r34   k38 ; k38 = 227
.line	2315	loadk        r35   k39 ; k39 = 113
.line	2315	loadk        r36   k40 ; k40 = 64
.line	2315	loadk        r37   k31 ; k31 = 234
.line	2315	loadk        r38   k41 ; k41 = 154
.line	2315	loadk        r39   k42 ; k42 = 118
.line	2315	loadk        r40   k53 ; k53 = 47
.line	2315	loadk        r41   k54 ; k54 = 7
.line	2315	loadk        r42   k55 ; k55 = 209
.line	2315	loadk        r43   k56 ; k56 = 253
.line	2315	loadk        r44   k57 ; k57 = 141
.line	2315	loadk        r45   k58 ; k58 = 62
.line	2315	call          r7    39     2
.line	2315	call          r6     2     2
.label	l133
.line	2315	call          r5     2     1
.line	2315	getupval      r5    u2
.line	2315	self          r5    r5   k59 ; k59 = "RestoreFrameLoading"
.line	2315	call          r5     2     1
.label	l137
.line	2315	return        r0     1
.line	2315	move          r0    r0
.line	2315	move          r0    r0
.line	2315	move          r0    r0
.line	2315	move          r0    r0
.line	2315	return        r0     1

.function	main/f133

.source	"=[V12L:f782b08329368039:66dc9eb84a87efe3]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f134

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f135

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f136

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f137

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

