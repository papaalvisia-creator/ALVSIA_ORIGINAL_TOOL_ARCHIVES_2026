do return {
  PbLoaded = {},
  ["ModIDTransformToShow"] = function(_ARG_0_)
    do
      _ARG_0_ = tostring(_ARG_0_)
      if not _ARG_0_ then
        log_warning(bWriteLog and table.concat({
          U1(149, 61, 157, 186, 201, 45, 117, 246, 211, 206, 214, 53, 91, 194, 39, 217, 121, 43, 179, 176, 55, 11, 34, 244, 135, 247, 253, 48, 67, 223, 27, 250, 65, 10, 244, 185, 39, 44, 25, 228),
          U1(185, 120, 144, 169, 136, 54, 98, 139, 150, 240, 203, 61, 64)
        }))
        return (U1())
      end
      log(bWriteLog and table.concat({
        U1(149, 61, 157, 186, 201, 45, 117, 246, 211, 215, 205, 59, 94, 254, 45, 203, 125, 70, 196, 146, 60, 38, 37, 207, 145, 243, 199, 49, 68, 222, 26, 241, 122, 23, 202, 133, 39, 8, 81, 226),
        U1(170, 120, 196)
      }) .. _ARG_0_)
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if Client.GetCurrentLanguage() == require((table.concat({
        U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 81, 206, 22, 234, 87, 15, 167, 190, 52, 6, 4, 245, 151, 223, 200, 33, 80, 222, 27, 178, 98, 25, 247, 138, 61, 30, 22, 238),
        U1(131, 57, 154, 191, 199, 44)
      }))).AR then
      end
      do return string.format(U1(235, 43, 212, 232, 219, 114, 52, 216), string.sub(string.sub((U1() .. U1(254)) .. _ARG_0_, 7, 9) .. string.sub((U1() .. U1(254)) .. _ARG_0_, 4, 6) .. string.sub((U1() .. U1(254)) .. _ARG_0_, 1, 3), 1, 3), string.sub(string.sub((U1() .. U1(254)) .. _ARG_0_, 7, 9) .. string.sub((U1() .. U1(254)) .. _ARG_0_, 4, 6) .. string.sub((U1() .. U1(254)) .. _ARG_0_, 1, 3), 4, 6), string.sub(string.sub((U1() .. U1(254)) .. _ARG_0_, 7, 9) .. string.sub((U1() .. U1(254)) .. _ARG_0_, 4, 6) .. string.sub((U1() .. U1(254)) .. _ARG_0_, 1, 3), 7)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEditorProMap"] = function(_ARG_0_)
    do
      do return _ARG_0_.setting.use_editor_pro and _ARG_0_.setting.use_editor_pro > 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GotoEditorPro"] = function()
    print(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 201, 197, 214, 38, 93, 228, 28, 229, 74, 7, 251, 173, 42, 0))
    if CDataTable.GetTableData(U1(155, 31, 186, 142, 218, 58, 112, 223, 154, 237, 215, 21, 71, 200, 28, 233, 127, 6, 234, 149, 55, 29, 54, 254, 129, 209, 198, 44, 68, 216, 15), 13) and CDataTable.GetTableData(U1(155, 31, 186, 142, 218, 58, 112, 223, 154, 237, 215, 21, 71, 200, 28, 233, 127, 6, 234, 149, 55, 29, 54, 254, 129, 209, 198, 44, 68, 216, 15), 13)[U1(162, 57, 151, 146) .. Client.GetCurrentLanguage()] ~= nil and CDataTable.GetTableData(U1(155, 31, 186, 142, 218, 58, 112, 223, 154, 237, 215, 21, 71, 200, 28, 233, 127, 6, 234, 149, 55, 29, 54, 254, 129, 209, 198, 44, 68, 216, 15), 13)[U1(162, 57, 151, 146) .. Client.GetCurrentLanguage()] ~= U1() and CDataTable.GetTableData(U1(155, 31, 186, 142, 218, 58, 112, 223, 154, 237, 215, 21, 71, 200, 28, 233, 127, 6, 234, 149, 55, 29, 54, 254, 129, 209, 198, 44, 68, 216, 15), 13)[U1(162, 57, 151, 146) .. Client.GetCurrentLanguage()] ~= U1(227, 105) then
    end
    if CDataTable.GetTableData(U1(155, 31, 186, 142, 218, 58, 112, 223, 154, 237, 215, 21, 71, 200, 28, 233, 127, 6, 234, 149, 55, 29, 54, 254, 129, 209, 198, 44, 68, 216, 15), 13)[U1(162, 57, 151, 146) .. Client.GetCurrentLanguage()] and 0 < #CDataTable.GetTableData(U1(155, 31, 186, 142, 218, 58, 112, 223, 154, 237, 215, 21, 71, 200, 28, 233, 127, 6, 234, 149, 55, 29, 54, 254, 129, 209, 198, 44, 68, 216, 15), 13)[U1(162, 57, 151, 146) .. Client.GetCurrentLanguage()] then
    end
    return
  end,
  ["NewModName"] = function(_ARG_0_)
    do
      while ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):CheckModNameUsed(LocUtil.GetLocalizeResStr(70005) .. 1) do
      end
      if not (require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateConfigByID(_ARG_0_) and require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateConfigByID(_ARG_0_).DefaultCreateName) or require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateConfigByID(_ARG_0_).DefaultCreateName == U1() then
      end
      if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateShowConfigByID(_ARG_0_) and require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateShowConfigByID(_ARG_0_).DefaultCreateName then
        if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateShowConfigByID(_ARG_0_).DefaultCreateName ~= U1() then
        end
      end
      do return require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateShowConfigByID(_ARG_0_).DefaultCreateName end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckModCodeValid"] = function(_ARG_0_)
    do
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckNameValid"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        U1.ShowNotice(70041)
        return false
      end
      if U1.require((_ENV(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true) then
        return false
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen() < U2.GetTextLengthAndSubStr(_ARG_0_, (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen())) then
        return false
      end
      if _ARG_1_ and 63 < U2.GetByteLength(_ARG_0_, 63) then
        return false
      end
      if U2.GetTextLengthAndSubStr(_ARG_0_, (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen())) == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen() and U1.require((_ENV(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true) ~= _ARG_0_ then
        return false
      end
      if U1.require((_ENV(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckStringStartsWithSpace(_ARG_0_) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NormalizeName"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = string.gsub(_ARG_0_, U1(196), (U1()))
      _ARG_0_ = string.gsub(_ARG_0_, U1(195), (U1()))
      if _ARG_1_ then
        if 63 < U2.GetByteLength(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true)), 63) then
          return U2.GetByteLength(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true)), 63)
        end
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen() < U2.GetTextLengthAndSubStr(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true)), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen())) then
        return U2.GetTextLengthAndSubStr(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true)), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModNameMaxLen()))
      end
      do return (require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NormalizeNameByLen"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = string.gsub(_ARG_0_, U1(196), (U1()))
      _ARG_0_ = string.gsub(_ARG_0_, U1(195), (U1()))
      if _ARG_1_ < U2.GetTextLengthAndSubStr(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true)), _ARG_1_) then
        return U2.GetTextLengthAndSubStr(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true)), _ARG_1_)
      end
      do return (require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).RemoveLeadingSpaces(require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckName(_ARG_0_, false, nil, true))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NormalizeDesc"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return (_ENV())
      end
      if U1.string.gsub(_ARG_0_, _ENV(149, 85, 243, 144), (_ENV())) == _ENV() then
        return (_ENV())
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModDescMaxLen() < U2.GetTextLengthAndSubStr(_ARG_0_, (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModDescMaxLen())) then
        _ARG_0_ = U2.GetTextLengthAndSubStr(_ARG_0_, (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetModDescMaxLen()))
      end
      if U2.GetTextLineCount(_ARG_0_) > U3 then
        _ARG_0_ = U2.TruncateTextByLines(_ARG_0_, U3)
      end
      do return U1.require((_ENV(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).CheckNameNew(_ARG_0_, nil, nil, true, true) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NormalizeBlockyLuaStr"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return (_ENV())
      end
      _ARG_0_ = U1.string.gsub(_ARG_0_, _ENV(149, 85, 243, 144, 131), (_ENV()))
      _ARG_0_ = U1.string.gsub(_ARG_0_, _ENV(146, 3, 139, 163, 245), (_ENV()))
      _ARG_0_ = U1.string.gsub(_ARG_0_, _ENV(44, 216, 81), (_ENV()))
      _ARG_0_ = U1.string.gsub(_ARG_0_, _ENV(44, 216, 80), (_ENV()))
      if 512 < U2.GetTextLengthAndSubStr(_ARG_0_, 512) then
        return U2.GetTextLengthAndSubStr(_ARG_0_, 512)
      end
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTextLengthAndSubStr"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return 0, (_ENV())
      end
      _ARG_1_ = _ARG_1_ or 0
      while 1 <= #_ARG_0_ do
        if (function(_ARG_0_)
          do
            if not _ARG_0_ then
              return 0
            elseif 252 <= _ARG_0_ then
              return 6
            elseif 248 <= _ARG_0_ and _ARG_0_ < 252 then
              return 5
            elseif 240 <= _ARG_0_ and _ARG_0_ < 248 then
              return 4
            elseif 224 <= _ARG_0_ and _ARG_0_ < 240 then
              return 3
            elseif 192 <= _ARG_0_ and _ARG_0_ < 224 then
              return 2
            else
              return 1
            end
            do return end
            _ARG_0_ = _ARG_0_
          end
        end)((U1.string.byte(_ARG_0_, 1))) == 1 then
        elseif (function(_ARG_0_)
          do
            if not _ARG_0_ then
              return 0
            elseif 252 <= _ARG_0_ then
              return 6
            elseif 248 <= _ARG_0_ and _ARG_0_ < 252 then
              return 5
            elseif 240 <= _ARG_0_ and _ARG_0_ < 248 then
              return 4
            elseif 224 <= _ARG_0_ and _ARG_0_ < 240 then
              return 3
            elseif 192 <= _ARG_0_ and _ARG_0_ < 224 then
              return 2
            else
              return 1
            end
            do return end
            _ARG_0_ = _ARG_0_
          end
        end)((U1.string.byte(_ARG_0_, 1))) >= 2 then
        end
        if _ARG_1_ <= 0 or _ARG_1_ >= 0 + 1 + 2 then
        end
      end
      do return 0 + 1 + 2, U1.string.sub(_ARG_0_, 1, 1 + (function(_ARG_0_)
        do
          if not _ARG_0_ then
            return 0
          elseif 252 <= _ARG_0_ then
            return 6
          elseif 248 <= _ARG_0_ and _ARG_0_ < 252 then
            return 5
          elseif 240 <= _ARG_0_ and _ARG_0_ < 248 then
            return 4
          elseif 224 <= _ARG_0_ and _ARG_0_ < 240 then
            return 3
          elseif 192 <= _ARG_0_ and _ARG_0_ < 224 then
            return 2
          else
            return 1
          end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)((U1.string.byte(_ARG_0_, 1))) - 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTextLineCount"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return 0
      end
      do return U1.string.gsub(U1.string.gsub(_ARG_0_, _ENV(195, 82), (_ENV(196))), _ENV(149, 82, 244, 144), (_ENV())) + 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TruncateTextByLines"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() or _ARG_1_ <= 0 then
        return (_ENV())
      end
      while 1 <= #_ARG_0_ do
        if U1.string.byte(_ARG_0_, 1) == 10 or U1.string.byte(_ARG_0_, 1) == 13 then
          if _ARG_1_ <= 1 then
            return U1.string.sub(_ARG_0_, 1, 1 - 1)
          end
          if U1.string.byte(_ARG_0_, 1) == 13 and 1 < #_ARG_0_ and U1.string.byte(_ARG_0_, 1 + 1) == 10 then
          end
        end
      end
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetByteLength"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return 0, (_ENV())
      end
      _ARG_1_ = _ARG_1_ or 0
      while 1 <= #_ARG_0_ do
        if _ARG_1_ <= 0 or _ARG_1_ >= 0 + (function(_ARG_0_)
          do
            if not _ARG_0_ then
              return 0
            elseif 252 <= _ARG_0_ then
              return 6
            elseif 248 <= _ARG_0_ and _ARG_0_ < 252 then
              return 5
            elseif 240 <= _ARG_0_ and _ARG_0_ < 248 then
              return 4
            elseif 224 <= _ARG_0_ and _ARG_0_ < 240 then
              return 3
            elseif 192 <= _ARG_0_ and _ARG_0_ < 224 then
              return 2
            else
              return 1
            end
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)((U1.string.byte(_ARG_0_, 1))) then
        end
      end
      do return 0 + (function(_ARG_0_)
        do
          if not _ARG_0_ then
            return 0
          elseif 252 <= _ARG_0_ then
            return 6
          elseif 248 <= _ARG_0_ and _ARG_0_ < 252 then
            return 5
          elseif 240 <= _ARG_0_ and _ARG_0_ < 248 then
            return 4
          elseif 224 <= _ARG_0_ and _ARG_0_ < 240 then
            return 3
          elseif 192 <= _ARG_0_ and _ARG_0_ < 224 then
            return 2
          else
            return 1
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)((U1.string.byte(_ARG_0_, 1))), U1.string.sub(_ARG_0_, 1, 1 + (function(_ARG_0_)
        do
          if not _ARG_0_ then
            return 0
          elseif 252 <= _ARG_0_ then
            return 6
          elseif 248 <= _ARG_0_ and _ARG_0_ < 252 then
            return 5
          elseif 240 <= _ARG_0_ and _ARG_0_ < 248 then
            return 4
          elseif 224 <= _ARG_0_ and _ARG_0_ < 240 then
            return 3
          elseif 192 <= _ARG_0_ and _ARG_0_ < 224 then
            return 2
          else
            return 1
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)((U1.string.byte(_ARG_0_, 1))) - 1) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCThumbUrl"] = function(_ARG_0_, _ARG_1_)
    do
      do return GetUGCAlbumUrl(_ARG_0_.album, _ARG_0_.thumb_index, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCAllViewUrls"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.view_pic_list then
        return {}
      end
      goto lbl_24
      if U1.GetUGCAlbumUrl(_ARG_0_.album, nil, _ARG_1_) ~= U2() then
      end
      ::lbl_24::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCViewUrl"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return (_ENV())
      end
      if not _ARG_0_.view_pic_list then
        return (_ENV())
      end
      if _ARG_1_ <= 0 or _ARG_1_ > #_ARG_0_.view_pic_list then
        return (_ENV())
      end
      do return (U1.GetUGCAlbumUrl(_ARG_0_.album, _ARG_0_.view_pic_list[_ARG_1_], _ARG_2_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCAlbumUrl"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return (_ENV())
      end
      if not _ARG_0_ then
        return (_ENV())
      end
      if _ARG_1_ <= 0 or _ARG_1_ > #_ARG_0_ then
        return (_ENV())
      end
      if _ARG_2_ then
      else
      end
      do return _ARG_0_[_ARG_1_].thumb_url end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCustomUGCAlbum"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_ then
        return
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_[nil][_ARG_2_ and _ENV(161, 42, 144, 170, 193, 49, 78, 222, 129, 238) or _ENV(186, 48, 140, 160, 202, 0, 100, 217, 159)] == _ARG_1_ then
        return _ARG_0_[nil].custom_photo
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllViewImageUrls"] = function(_ARG_0_, _ARG_1_)
    do
      if #GetUGCAllViewUrls(_ARG_0_.setting, _ARG_1_) <= 0 and GetUGCThumbUrl(_ARG_0_.setting, _ARG_1_) and GetUGCThumbUrl(_ARG_0_.setting, _ARG_1_) ~= U1() then
      end
      if #GetUGCAllViewUrls(_ARG_0_.setting, _ARG_1_) <= 0 and U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.LogicUGCTemplate):GetTemplateByIDLocally(_ARG_0_.base.template_id) then
      end
      do return (GetUGCAllViewUrls(_ARG_0_.setting, _ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCoverImageUrl"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (GetUGCThumbUrl(_ARG_0_, _ARG_2_) == U1() or GetUGCThumbUrl(_ARG_0_, _ARG_2_) == nil) and U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.LogicUGCTemplate):GetTemplateByIDLocally(_ARG_1_) then
      end
      do return U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.LogicUGCTemplate):GetTemplateByIDLocally(_ARG_1_).Image end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCoverImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      if _ARG_2_ == nil then
        return
      end
      if not _ARG_0_ or not slua.isValid(_ARG_1_) then
        log_warning(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 220, 38, 113, 206, 14, 233, 76, 33, 228, 156, 63, 10, 65, 238, 138, 208, 200, 49, 71, 145, 7, 238, 14, 15, 240, 137, 47, 26, 5, 171),
          U1(167, 43, 217, 164, 198, 41, 112, 199, 154, 230)
        }))
        return
      end
      if not _ARG_7_ then
        if _ARG_3_ then
          _ARG_7_ = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr):GetDiskCacheTypeEnum().VersionUpdate
        else
          _ARG_7_ = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr):GetDiskCacheTypeEnum().NeverDelete
        end
      end
      log(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 220, 38, 113, 206, 14, 233, 76, 33, 228, 156, 63, 10, 65, 242, 142, 243, 206, 39, 97, 208, 11, 244, 75, 44, 224, 157, 45, 69) .. tostring(_ARG_7_))
      U3[_ARG_1_] = U2.GetCoverImageUrl(_ARG_2_.setting, _ARG_2_.base.template_id, _ARG_3_)
      if not U2.GetCoverImageUrl(_ARG_2_.setting, _ARG_2_.base.template_id, _ARG_3_) or U2.GetCoverImageUrl(_ARG_2_.setting, _ARG_2_.base.template_id, _ARG_3_) == U1() then
        if _ARG_6_ then
        end
        return
      end
      if require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).Starts(tostring((U2.GetCoverImageUrl(_ARG_2_.setting, _ARG_2_.base.template_id, _ARG_3_))), (U1(225, 31, 152, 160, 205))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[205]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_)
    do
      if not _ARG_2_ then
        log_warning(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 220, 38, 103, 230, 59, 197, 83, 9, 238, 152, 120, 26, 19, 247, 195, 251, 218, 98, 76, 216, 4))
        return
      end
      if not _ARG_0_ or not slua.isValid(_ARG_1_) then
        log_warning(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 220, 38, 103, 230, 59, 197, 83, 9, 238, 152, 120, 26, 8, 217, 130, 225, 204, 98, 75, 194, 72, 242, 71, 20))
        return
      end
      _ARG_2_ = tostring(_ARG_2_)
      if not require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).Starts(_ARG_2_, (U1(225, 31, 152, 160, 205))) and not require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 13, 71, 200, 39, 234, 76, 9, 228, 152, 47, 0, 19, 240, 205, 231, 221, 43, 78))).IsOnlineImageUrl(_ARG_2_) then
        _ARG_2_ = require((table.concat({
          U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 228, 146, 53, 10, 15, 239, 205, 254, 198, 37, 75, 210, 55, 241, 65, 21, 252, 131, 60, 32, 25, 238),
          U1(162, 40, 156, 191)
        }))).GetDomain(1) .. _ARG_2_
      end
      _ARG_6_ = _ARG_6_ or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr):GetDiskCacheTypeEnum().VersionUpdate
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCCollectionsImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_ or not slua.isValid(_ARG_1_) then
        log_warning(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 220, 38, 103, 230, 59, 207, 81, 4, 229, 152, 59, 27, 8, 244, 141, 225, 224, 47, 67, 214, 13, 188, 91, 17, 219, 140, 59, 26, 81, 226),
          U1(189, 120, 151, 164, 196)
        }))
        return
      end
      if (not _ARG_2_ or _ARG_2_ == U1()) and _ARG_4_ and _ARG_4_ ~= 0 then
        _ARG_2_ = require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateConfigByID(_ARG_4_) and require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTemplateConfigByID(_ARG_4_).BgImage or nil
      end
      if not _ARG_2_ or _ARG_2_ == U1() then
        U2[_ARG_1_] = nil
        _ARG_0_:SetTexture(_ARG_1_, U3, {bMatchSize = true})
        if _ARG_3_ then
          _ARG_3_()
        end
        return
      end
      U2[_ARG_1_] = _ARG_2_
      if require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).Starts(tostring(_ARG_2_), (U1(225, 31, 152, 160, 205))) then
        if _ARG_3_ then
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLoadingCoverPath"] = function()
    do return _ENV end
    return
  end,
  ["GetModCollectCount"] = function(_ARG_0_)
    do
      do return _ARG_0_ and _ARG_0_.collect_cnt or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModLikeCount"] = function(_ARG_0_)
    do
      do return _ARG_0_ and _ARG_0_.like_cnt or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModPlayCount"] = function(_ARG_0_)
    do
      do return _ARG_0_ and _ARG_0_.play_cnt or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModPlayCountWeekly"] = function(_ARG_0_)
    do
      do return _ARG_0_ and _ARG_0_.play_cnt_week or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModPlayTotalTime"] = function(_ARG_0_)
    do
      if _ARG_0_.play_total_time then
        return _ARG_0_ and require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).FormatNumATWill_KMB(_ARG_0_.play_total_time / 3600, (U1(235, 118, 200, 171))) or 0
      else
        return 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModCompleteTime"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        return require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).FormatNumDecimal_KMB(_ARG_0_.finish_play_total_time / _ARG_0_.game_result_finish_cnt / 60) or 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModCompleteRate"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 197, 220, 38, 127, 206, 28, 207, 81, 5, 249, 145, 61, 27, 4, 201, 130, 230, 204, 98, 79, 222, 12, 213, 64, 30, 246, 195, 47, 30, 28, 238),
          U1(145, 42, 156, 190, 221, 51, 101, 244, 144, 236, 205, 114, 15, 129)
        }) .. _ARG_0_.game_result_cnt)
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 197, 220, 38, 127, 206, 28, 207, 81, 5, 249, 145, 61, 27, 4, 201, 130, 230, 204, 98, 79, 222, 12, 213, 64, 30, 246, 195, 47, 30, 28, 238),
          U1(145, 42, 156, 190, 221, 51, 101, 244, 149, 235, 215, 59, 65, 201, 39, 239, 80, 28, 169, 192, 120)
        }) .. _ARG_0_.game_result_finish_cnt)
        return require((U1(173, 55, 148, 160, 199, 49, 63, 216, 135, 240, 208, 60, 85, 254, 13, 248, 87, 4))).FormatNumDecimal_KMB(_ARG_0_.game_result_finish_cnt / _ARG_0_.game_result_cnt * 100, (U1(235, 118, 201, 171))) or 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEditModHasPlayedCompleted"] = function(_ARG_0_)
    do
      if not _ARG_0_ or not _ARG_0_.setting then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 197, 220, 38, 119, 197, 17, 248, 115, 7, 237, 181, 57, 28, 49, 247, 130, 235, 204, 38, 97, 222, 5, 236, 66, 29, 237, 136, 44, 95, 31, 228),
          U1(238, 61, 157, 164, 220, 18, 126, 207, 186, 236, 223, 61, 18, 206, 10, 172, 77, 13, 253, 137, 49, 1, 6)
        }))
        return true
      end
      log(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 197, 220, 38, 119, 197, 17, 248, 115, 7, 237, 181, 57, 28, 49, 247, 130, 235, 204, 38, 97, 222, 5, 236, 66, 29, 237, 136, 44, 95) .. tostring(_ARG_0_.setting.has_played_completed))
      do return _ARG_0_.setting.has_played_completed or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMinPlayerCount"] = function(_ARG_0_)
    do
      if not _ARG_0_ or not _ARG_0_.setting then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 197, 220, 38, 127, 200, 22, 220, 82, 9, 240, 152, 42, 44, 14, 238, 141, 230, 137, 44, 77, 145, 5, 243, 74, 49, 247, 139, 39, 95, 30, 249),
          U1(238, 43, 156, 185, 220, 54, 127, 204)
        }))
        return 0
      end
      if _ARG_0_.setting.team_size == -1 then
      elseif (_ARG_0_.setting.team_min_size or _ARG_0_.setting.team_size) == nil or _ARG_0_.setting.min_start_team_num == nil then
        return 0
      end
      do return (_ARG_0_.setting.team_min_size or _ARG_0_.setting.team_size) * _ARG_0_.setting.min_start_team_num end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModTeamSize"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ and _ARG_0_.setting and _ARG_0_.setting.team_size and _ARG_0_.setting.team_size == -1 then
      end
      if 0 >= (_ARG_0_.setting.max_num or 0) then
      end
      do return _ARG_1_ or require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 253, 152, 57, 2, 20, 235, 205, 254, 198, 37, 75, 210, 55, 232, 75, 25, 244, 178, 61, 15))).GetDefaultMaxTeamNum() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsTrailMod"] = function(_ARG_0_)
    do
      if not _ARG_0_ or not _ARG_0_.setting then
        log(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 193, 209, 55, 81, 202, 49, 255, 106, 26, 232, 148, 52, 34, 14, 255, 195, 252, 198, 98, 71, 213, 1, 232, 99, 23, 253, 164, 38, 25, 30))
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsModFreeze"] = function(_ARG_0_)
    do
      if type(_ARG_0_) ~= U1(160, 45, 148, 175, 205, 45) then
        return false
      end
      if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetModReasonConfigByID(_ARG_0_) and require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetModReasonConfigByID(_ARG_0_).Type == require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).FreezeType then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsUGCPubItemExpired"] = function(_ARG_0_)
    do
      if gTestItemExpiredUI then
        return true
      end
      if _ARG_0_.theme_obj_close_time and _ARG_0_.theme_obj_close_time ~= 0 and require((U1(173, 52, 144, 168, 198, 43, 63, 200, 156, 239, 212, 61, 92, 143, 12, 229, 83, 13, 214, 136, 44, 6, 13))).GetServerTimeInSec() > _ARG_0_.theme_obj_close_time then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCRedDotState"] = function(_ARG_0_)
    do
      if (require((table.concat({
        U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 237, 23, 235, 87, 11, 217, 145, 57, 22, 4, 233, 179, 224, 204, 36, 81, 159, 24, 240, 79, 1, 252, 159, 56, 13, 20, 237),
        U1(189)
      }))).LoadFileToTable_N(_ARG_0_) or {}).red_dot then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCRedDotLastCheckTime"] = function(_ARG_0_)
    do
      if (require((table.concat({
        U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 237, 23, 235, 87, 11, 217, 145, 57, 22, 4, 233, 179, 224, 204, 36, 81, 159, 24, 240, 79, 1, 252, 159, 56, 13, 20, 237),
        U1(189)
      }))).LoadFileToTable_N(_ARG_0_) or {}) and (require((table.concat({
        U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 237, 23, 235, 87, 11, 217, 145, 57, 22, 4, 233, 179, 224, 204, 36, 81, 159, 24, 240, 79, 1, 252, 159, 56, 13, 20, 237),
        U1(189)
      }))).LoadFileToTable_N(_ARG_0_) or {}).last_check_time then
        return (require((table.concat({
          U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 237, 23, 235, 87, 11, 217, 145, 57, 22, 4, 233, 179, 224, 204, 36, 81, 159, 24, 240, 79, 1, 252, 159, 56, 13, 20, 237),
          U1(189)
        }))).LoadFileToTable_N(_ARG_0_) or {}).last_check_time
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCRedDotState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ then
        ;(require((table.concat({
          U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 237, 23, 235, 87, 11, 217, 145, 57, 22, 4, 233, 179, 224, 204, 36, 81, 159, 24, 240, 79, 1, 252, 159, 56, 13, 20, 237),
          U1(189)
        }))).LoadFileToTable_N(_ARG_0_) or {}).last_check_time = _ARG_1_
      end
      ;(require((table.concat({
        U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 237, 23, 235, 87, 11, 217, 145, 57, 22, 4, 233, 179, 224, 204, 36, 81, 159, 24, 240, 79, 1, 252, 159, 56, 13, 20, 237),
        U1(189)
      }))).LoadFileToTable_N(_ARG_0_) or {}).red_dot = _ARG_2_ or false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurBinaryVersion"] = function()
    if U2.PbLoaded[U3] ~= true then
    end
    do return (require((U1(190, 58))).enum(U1(169, 57, 148, 168, 219, 45, 103, 244, 151, 241, 151, 7, 117, 226, 39, 203, 114, 39, 203, 188, 20, 48, 36, 213, 182, 223), (U1(141, 45, 139, 143, 193, 49, 112, 217, 138, 212, 220, 32, 65, 200, 23, 226)))) end
    return
  end,
  ["IsModVersionValid"] = function(_ARG_0_)
    do
      if not _ARG_0_ or not _ARG_0_.base then
        return false
      end
      do return U1.tonumber((GetCurBinaryVersion())) >= U1.tonumber(_ARG_0_.base.version or 10000) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedShowUpdateTips"] = function(_ARG_0_)
    do
      if not IsModVersionValid(_ARG_0_) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpStrategyGuideUrl"] = function()
    if require((table.concat({
      U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 81, 206, 22, 234, 87, 15, 167, 190, 52, 6, 4, 245, 151, 223, 200, 33, 80, 222, 27, 178, 126, 13, 251, 129, 33, 12, 25, 217),
      U1(171, 63, 144, 162, 198, 18, 112, 200, 129, 237, 202)
    }))).IsJapanOrKorea() then
      if FuncUtil.GetAccountRegionForBP() == U1(132, 8) then
      else
      end
    end
    if CDataTable.GetTableData(U1(155, 31, 186, 138, 221, 54, 117, 206, 166, 240, 213, 17, 93, 207, 30, 229, 89), (U1(157, 44, 139, 172, 220, 58, 118, 210, 180, 247, 208, 54, 87, 224, 28, 232, 76, 13, 250, 142, 7, 36, 51))) then
    end
    return
  end,
  ["ShowUGCChatSharePanel"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil or not next(_ARG_0_) then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 209, 61, 69, 244, 63, 207, 125, 0, 232, 137, 11, 7, 0, 233, 134, 194, 200, 44, 71, 221, 72, 241, 65, 28, 208, 131, 46, 16, 81, 226),
          U1(189, 120, 144, 163, 222, 62, 125, 194, 151)
        }))
        return
      end
      if _ARG_0_.setting.tag and type(_ARG_0_.setting.tag) == U1(186, 57, 155, 161, 205) then
        goto lbl_143
        if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).GetTagConfigByID(155) then
        end
        ::lbl_143::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Reportprotocolassignment"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowUGCSharePanel"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil or not next(_ARG_0_) then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 209, 61, 69, 244, 63, 207, 109, 0, 232, 143, 61, 63, 0, 245, 134, 254, 137, 47, 77, 213, 33, 242, 72, 23, 185, 132, 59, 95, 24, 229),
          U1(184, 57, 149, 164, 204)
        }))
        return
      end
      if {
        capturePath = require((table.concat({
          U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 228, 146, 53, 10, 15, 239, 205, 254, 198, 37, 75, 210, 55, 241, 65, 21, 252, 131, 60, 32, 25, 238),
          U1(162, 40, 156, 191)
        }))).GetDomain(1) .. tostring((require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 20, 239, 138, 254, 246, 55, 69, 210))).GetCoverImageUrl(_ARG_0_.setting, _ARG_0_.base.template_id, true))) or U1(),
        shareTitle = LocUtil.GetLocalizeResStr(80045),
        shareContent = LocUtil.LocalizeResFormat(80046, DataMgr.roleData.nickName, _ARG_0_.setting.name, _ARG_0_.mod_id),
        otherTLog = TLogEventDefine.UGC_Share,
        campaign = U1(187, 63, 154, 146, 197, 48, 117),
        reasonStr = json.encode({
          uid = DataMgr.roleData.uid,
          modID = _ARG_0_.mod_id
        }),
        nItemId = _ARG_0_.mod_id,
        moduleParams = U1(163, 55, 157, 184, 196, 58, 44) .. BP_ENUM_MODULE_MATCH_MODE_SELECTION .. U1(232, 53, 156, 163, 221, 19, 120, 216, 135, 191) .. require((table.concat({
          U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 228, 146, 60, 10, 62, 232, 134, 254, 204, 33, 86, 216, 7, 242, 0, 21, 246, 137, 45, 32, 2, 238),
          U1(162, 61, 154, 185, 193, 48, 127, 244, 158, 227, 218, 32, 93)
        }))).Enum_TabID.UGC .. U1(232, 53, 150, 169, 225, 59, 44) .. _ARG_0_.mod_id
      } then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[204]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowUGCShareCollectionListPanel"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil or not next(_ARG_0_) then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 209, 61, 69, 244, 63, 207, 109, 0, 232, 143, 61, 63, 0, 245, 134, 254, 137, 47, 77, 213, 33, 242, 72, 23, 185, 132, 59, 95, 24, 229),
          U1(184, 57, 149, 164, 204)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCNewbieGuideFinish"] = function(_ARG_0_)
    do
      if not DataMgr.HaveNewbieGuide(require((U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 207, 29, 251, 92, 1, 236, 211, 52, 0, 6, 242, 128, 205, 199, 39, 85, 211, 1, 249))).NEWBIE_GUIDE_MODULE_ID_UGC, _ARG_0_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetUGCNewbieGuideFinish"] = function(_ARG_0_)
    do
      if not DataMgr.HaveNewbieGuide(require((U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 207, 29, 251, 92, 1, 236, 211, 52, 0, 6, 242, 128, 205, 199, 39, 85, 211, 1, 249))).NEWBIE_GUIDE_MODULE_ID_UGC, _ARG_0_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsUGCNewbieGuideFinish"] = function(_ARG_0_)
    do
      do return not DataMgr.HaveNewbieGuide(require((U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 207, 29, 251, 92, 1, 236, 211, 52, 0, 6, 242, 128, 205, 199, 39, 85, 211, 1, 249))).NEWBIE_GUIDE_MODULE_ID_UGC, _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCNewbieGuideVal"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCNewbieGuideVal"] = function(_ARG_0_)
    do
      do return DataMgr.GetNewbieGuideValue(require((U1(173, 52, 144, 168, 198, 43, 63, 199, 156, 229, 208, 49, 28, 207, 29, 251, 92, 1, 236, 211, 52, 0, 6, 242, 128, 205, 199, 39, 85, 211, 1, 249))).NEWBIE_GUIDE_MODULE_ID_UGC, _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLoopAllItemsWithoutTLog"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshModePlayerNum"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_) then
        return
      end
      if not _ARG_0_ or not _ARG_0_.HorizontalBox_Time then
        return
      end
      if not _ARG_0_.TextBlock_PlayTime then
        return
      end
      if not slua.isValid(_ARG_0_.TextBlock_PlayTime) then
        return
      end
      if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetModePlayerNum(_ARG_1_) or 0) >= require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).SimultaneousOnlinePopular then
      elseif (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetModePlayerNum(_ARG_1_) or 0) < require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).SimultaneousOnlinePopular and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetModePlayerNum(_ARG_1_) or 0) >= require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).SimultaneousOnlineModerate then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowAuthorWorkMainUI"] = function(_ARG_0_)
    do
      _ARG_0_ = tonumber(_ARG_0_)
      if not _ARG_0_ then
        return
      end
      if _ARG_0_ == tonumber(DataMgr.roleData.uid) then
        if IsWoWEditor then
          UIManager.AndroidBackToLobby()
        else
          UIManager.ShowUI(UIManager.UI_Config.ugc_mine_main)
        end
      else
        UIManager.ShowUI(UIManager.UI_Config.ugc_guest_work_panel, _ARG_0_)
      end
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_SHOW_GUEST)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModListToArray"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return nil
      end
      goto lbl_15
      ::lbl_15::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCoverList"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return {}
      end
      goto lbl_60
      if ((168).base.state_release or require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).E_PublishState.Not) == require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).E_PublishState.Not then
      end
      ::lbl_60::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DuplicateMod"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_ = _ARG_0_ or _ENV()
      if _ARG_1_ ~= nil then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartEditGame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):IsBanned(true) then
        return
      end
      if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 229, 146, 57, 11, 8, 245, 132, 188, 197, 45, 69, 216, 11, 195, 66, 23, 248, 137, 33, 17, 22))).IsShowing() then
        return
      end
      if not PufferDownloader.CheckAllMapPak(nil, function(_ARG_0_)
        do
          if not _ARG_0_ then
            return
          end
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch).bUseDirectEdit then
            if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 253, 152, 57, 2, 20, 235, 205, 254, 198, 37, 75, 210, 55, 232, 75, 25, 244, 178, 61, 15))).IsInTeam() then
            else
            end
          else
          end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLeaderboardItemByProfile"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = _ARG_2_ or 0
      if _ARG_1_ == nil then
        return
      end
      if not slua.isValid(_ARG_0_) then
        return
      end
      if _ARG_0_.Common_Avatar_BP_C_0 then
        if tonumber(_ARG_2_) == tonumber(DataMgr.roleData.uid) then
        else
        end
      end
      if require((table.concat({
        U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 81, 206, 22, 234, 87, 15, 167, 190, 52, 6, 4, 245, 151, 223, 200, 33, 80, 222, 27, 178, 126, 13, 251, 129, 33, 12, 25, 217),
        U1(171, 63, 144, 162, 198, 18, 112, 200, 129, 237, 202)
      }))).IsBlueholeOperationRegion() then
      else
      end
      if _ARG_0_.SizeBox_WoWPass and _ARG_0_.Image_WowPass then
        if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 20, 239, 138, 254, 246, 55, 69, 210))).WoWPassActive(_ARG_1_) then
          if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):CheckWoWPassDisplay(tonumber(_ARG_2_)) then
          end
        elseif tonumber(_ARG_2_) == tonumber(DataMgr.roleData.uid) then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):GetWOWpassIcon() then
          end
          if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):CheckWoWPassDisplay(tonumber(_ARG_2_)) then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsStandalone"] = function()
    do return import((U1(133, 49, 138, 160, 205, 43, 66, 210, 128, 246, 220, 63, 126, 200, 26, 254, 95, 26, 240))).IsStandalone(CGameMode) == true end
    return
  end,
  ["IsCreativeWow"] = function()
    if not GameStatus.IsInFightingStatus() then
      return false
    end
    if IsEditor then
      return slua.isValid(CGameState) and CGameState.bIsCreativeWoW
    end
    do return (tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game):GetSubModeId()) or 0) == 600091 or (tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game):GetSubModeId()) or 0) == 600092 or (tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game):GetSubModeId()) or 0) == 600093 end
    return
  end,
  ["GetLocalizeResStr"] = function(_ARG_0_, ...)
    do
      if type(_ARG_0_) == U1(189, 44, 139, 164, 198, 56) then
      else
      end
      if _ARG_0_ ~= nil and LocUtil.GetLocalizeResStr(_ARG_0_) ~= nil and LocUtil.GetLocalizeResStr(_ARG_0_) ~= U1() then
        return U2(LocUtil.GetLocalizeResStr(_ARG_0_), ...)
      end
      do return U2(tostring(_ARG_0_), ...) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BufferCompressData"] = function(_ARG_0_)
    do
      if _ARG_0_ ~= nil and _ARG_0_ ~= _ENV() and U1.import((_ENV(157, 59, 139, 164, 216, 43, 86, 202, 158, 231, 201, 62, 83, 216, 43, 248, 95, 28, 224, 158, 43))).ZSTDCompressData(_ARG_0_, _ENV(), 19) then
        _ARG_0_ = U1.import((_ENV(157, 59, 139, 164, 216, 43, 86, 202, 158, 231, 201, 62, 83, 216, 43, 248, 95, 28, 224, 158, 43))).ZSTDCompressData(_ARG_0_, _ENV(), 19)
      end
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DecompressData"] = function(_ARG_0_)
    do
      if _ARG_0_ ~= nil and _ARG_0_ ~= _ENV() and U1.import((_ENV(157, 59, 139, 164, 216, 43, 86, 202, 158, 231, 201, 62, 83, 216, 43, 248, 95, 28, 224, 158, 43))).ZSTDDecompressData(_ARG_0_, (_ENV())) then
        _ARG_0_ = U1.import((_ENV(157, 59, 139, 164, 216, 43, 86, 202, 158, 231, 201, 62, 83, 216, 43, 248, 95, 28, 224, 158, 43))).ZSTDDecompressData(_ARG_0_, (_ENV()))
      end
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPartOfModInfo"] = function()
    if (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil) == nil then
      return {
        setting = {
          album = {}
        },
        base = {},
        ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
      }
    end
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).base.mod_id = ({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).mod_id
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).base.template_id = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 153, 205, 50, 97, 199, 146, 246, 220, 27, 86))).Value
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).base.uid = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(143, 45, 141, 165, 199, 45, 88, 239))).Value
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).base.wow_pass_season_id = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(153, 55, 142, 157, 201, 44, 98, 248, 150, 227, 202, 61, 92, 232, 60))).Value
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).setting.name = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 131, 201, 50, 116))).Value
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).setting.album = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(175, 52, 155, 184, 197, 19, 120, 216, 135))).Value or {}
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).setting.thumb_index = math.ceil((_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(186, 48, 140, 160, 202, 22, 127, 207, 150, 250))).Value)
    ;({
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    }).setting.tag_v2 = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 153, 201, 56, 71, 153))).Value
    do return {
      setting = {
        album = {}
      },
      base = {},
      ["mod_id"] = (_G.GetGameParameterManager ~= nil and _G.GetGameParameterManager() or nil):GetGameParameter((U1(131, 55, 157, 132, 204))).Value
    } end
    return
  end,
  ["LoadFileBinaryData"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(149, 13, 141, 164, 196, 0, 68, 236, 176, 223, 245, 61, 83, 197, 62, 229, 82, 13, 203, 148, 54, 14, 19, 226, 167, 243, 221, 35, 2, 247, 1, 240, 75, 40, 248, 153, 32, 69) .. tostring(_ARG_0_))
      if Client ~= nil then
      end
      if io.open(_ARG_0_, (U1(188, 58))) then
        if not (0 < io.open(_ARG_0_, (U1(188, 58))):seek((U1(171, 54, 157)))) then
        else
          return (io.open(_ARG_0_, (U1(188, 58))):read((io.open(_ARG_0_, (U1(188, 58))):seek((U1(171, 54, 157))))))
        end
      end
      if Client ~= nil then
      end
      if io.open(import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_), (U1(188, 58))) then
        if not (0 < io.open(import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_), (U1(188, 58))):seek((U1(171, 54, 157)))) then
        else
          return (io.open(import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_), (U1(188, 58))):read((io.open(import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_), (U1(188, 58))):seek((U1(171, 54, 157))))))
        end
      else
      end
      if import((U1(141, 42, 156, 172, 220, 54, 103, 206, 190, 237, 221, 55, 112, 205, 13, 233, 78, 26, 224, 147, 44, 35, 8, 249, 145, 243, 219, 59))) then
        if import((U1(141, 42, 156, 172, 220, 54, 103, 206, 190, 237, 221, 55, 112, 205, 13, 233, 78, 26, 224, 147, 44, 35, 8, 249, 145, 243, 219, 59))).LoadFileToArrayByFullPath((import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_))) and 0 < #import((U1(141, 42, 156, 172, 220, 54, 103, 206, 190, 237, 221, 55, 112, 205, 13, 233, 78, 26, 224, 147, 44, 35, 8, 249, 145, 243, 219, 59))).LoadFileToArrayByFullPath((import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_))) then
        else
        end
      end
      do return (import((U1(141, 42, 156, 172, 220, 54, 103, 206, 190, 237, 221, 55, 112, 205, 13, 233, 78, 26, 224, 147, 44, 35, 8, 249, 145, 243, 219, 59))).LoadFileToArrayByFullPath((import((U1(140, 45, 138, 164, 198, 58, 98, 216, 187, 231, 213, 34, 87, 211))).GetMobileBasePath(_ARG_0_)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFilterTextTips"] = function()
    print(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 209, 209, 61, 69, 228, 10, 254, 81, 26, 202, 146, 60, 10, 53, 242, 147, 225))
    return
  end,
  ["WoWPassActive"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 213, 214, 5, 98, 192, 11, 255, 127, 11, 253, 148, 46, 10, 65, 203, 145, 253, 207, 43, 78, 212, 82) .. tostring(_ARG_0_))
      if _ARG_0_ == nil then
        return false
      end
      if _ARG_0_.wow_pass == nil then
        return false
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):CheckWoWPassDisplay(tonumber(_ARG_0_.uid)) then
        return false
      end
      if _ARG_0_.wow_pass.is_buy > require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).Enum_UGCWOWPassBuyType.None then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWoWPassIconPath"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 197, 220, 38, 101, 206, 47, 220, 95, 27, 250, 180, 59, 0, 15, 203, 130, 230, 193, 98, 114, 195, 7, 250, 71, 20, 252, 215) .. tostring(_ARG_0_))
      if _ARG_0_ == nil then
        return (U1())
      end
      if _ARG_0_.wow_pass == nil then
        return (U1())
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):CheckWoWPassDisplay(tonumber(_ARG_0_.uid)) then
        return (U1())
      end
      if _ARG_0_.wow_pass.is_buy > require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 252, 154, 59, 65, 2, 244, 141, 244, 192, 37, 125, 196, 15, 255))).Enum_UGCWOWPassBuyType.None then
        goto lbl_155
        if (_ARG_0_.wow_pass.accumulate_buy_times or 1) >= (201).AccBuyCount then
          if nil == nil then
          elseif (201).AccBuyCount < (201).AccBuyCount then
          end
        end
        ::lbl_155::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if 201 ~= nil then
          return (201).SignIconPath
        end
      end
      do return (U1()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsModWithEvent"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or not next(_ARG_0_) then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 203, 202, 31, 93, 197, 47, 229, 74, 0, 204, 139, 61, 1, 21, 183, 195, 223, 198, 38, 107, 223, 14, 243, 14, 17, 234, 205, 33, 17, 7, 234),
          U1(162, 49, 157)
        }))
        return false
      end
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(155, 44, 144, 161, 247, 10, 86, 232, 221, 203, 202, 31, 93, 197, 47, 229, 74, 0, 204, 139, 61, 1, 21, 183, 195, 215, 223, 39, 76, 197, 45, 240, 75, 21, 252, 131, 60, 54, 53, 248),
          U1(238, 49, 138, 237, 193, 49, 103, 202, 159, 235, 221)
        }))
        return false
      end
      if type(_ARG_1_) ~= U1(186, 57, 155, 161, 205) then
      else
      end
      if _ARG_0_.setting.ds_expired_resource then
        goto lbl_168
        if _ARG_1_[155] then
          return true
        end
        ::lbl_168::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSubModeGameMod"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil then
        return false
      end
      if _ARG_0_.base ~= nil and _ARG_0_.base.template_id ~= nil then
      end
      if CDataTable.GetTableData(U1(155, 31, 186, 153, 205, 50, 97, 199, 146, 246, 220, 17, 93, 207, 30, 229, 89), _ARG_0_.base.template_id) ~= nil and CDataTable.GetTableData(U1(155, 31, 186, 153, 205, 50, 97, 199, 146, 246, 220, 17, 93, 207, 30, 229, 89), _ARG_0_.base.template_id).SubModeID ~= 0 then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReloadCreativeExpiredAssetConfig"] = function()
    if not xpcall(function()
      package.loaded[U1] = nil
      require(U1)
      return
    end, debug.traceback) then
      package.loaded[table.concat({
        U1(137, 57, 148, 168, 228, 42, 112, 133, 190, 237, 221, 124, 112, 192, 11, 233, 115, 7, 237, 211, 31, 14, 12, 254, 179, 254, 200, 59, 12, 242, 7, 242, 72, 17, 254, 195, 11, 13, 20, 234),
        U1(186, 49, 143, 168, 237, 39, 97, 194, 129, 231, 221, 19, 65, 210, 29, 248, 125, 7, 231, 155, 49, 8)
      })] = package.loaded[table.concat({
        U1(137, 57, 148, 168, 228, 42, 112, 133, 190, 237, 221, 124, 112, 192, 11, 233, 115, 7, 237, 211, 31, 14, 12, 254, 179, 254, 200, 59, 12, 242, 7, 242, 72, 17, 254, 195, 11, 13, 20, 234),
        U1(186, 49, 143, 168, 237, 39, 97, 194, 129, 231, 221, 19, 65, 210, 29, 248, 125, 7, 231, 155, 49, 8)
      })], xpcall(function()
        package.loaded[U1] = nil
        require(U1)
        return
      end, debug.traceback)
    end
    do return xpcall(function()
      package.loaded[U1] = nil
      require(U1)
      return
    end, debug.traceback) end
    return
  end,
  ["IsValidModId"] = function(_ARG_0_)
    do
      do return type(_ARG_0_) == U1(160, 45, 148, 175, 205, 45) and 0 < _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CopyWorkCode"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DuplicateWork"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):IsBanned(true) then
        return
      end
      if U1.NeedShowUpdateTips(_ARG_0_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShareWork"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):IsLobbyResCompleted(true) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecommendWork"] = function(_ARG_0_)
    do
      if U1.require((U1.table.concat({
        _ENV(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 81, 206, 22, 234, 87, 15, 167, 190, 52, 6, 4, 245, 151, 223, 200, 33, 80, 222, 27, 178, 126, 13, 251, 129, 33, 12, 25, 217),
        _ENV(171, 63, 144, 162, 198, 18, 112, 200, 129, 237, 202)
      }))).IsCEOperationRegion() then
      elseif not U1.Client.IsReleaseVersion(U1.NetInterface) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenPromotionNotice"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_author_notice) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_author_notice):CheckCanOpenNoticePanel(_ARG_0_) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_author_notice):CheckCanOpenNoticePanel(_ARG_0_) then
        else
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryDuplicatePubModForEdit"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return false
      end
      if _ARG_0_.offline_start_time then
        ShowNotice(81719)
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):IsBanned(true) then
        return false
      end
      if require((U1(173, 55, 148, 160, 199, 49, 63, 223, 146, 224, 213, 55, 109, 212, 12, 229, 82))).CountTable(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):GetModeList()) >= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):GetDraftBoxLimit() then
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetResState(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloaderType.MyWork, _ARG_0_) ~= require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 237, 146, 47, 1, 13, 244, 130, 246, 135, 50, 87, 215, 14, 249, 92, 39, 250, 130, 38, 12, 5))).ENUM_DownloadState.Done then
        return false
      end
      do return true end
      return
    end
  end,
  ["EnterEditFromDuplicate"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or not _ARG_0_.base then
        return
      end
      if require((U1(173, 52, 144, 168, 198, 43, 63, 216, 159, 247, 216, 124, 94, 206, 31, 229, 93, 70, 253, 152, 57, 2, 20, 235, 205, 254, 198, 37, 75, 210, 55, 232, 75, 25, 244, 178, 61, 15))).IsInTeam() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
