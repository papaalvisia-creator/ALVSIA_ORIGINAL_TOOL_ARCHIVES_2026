local logic_active_exchange_entry = {}
local time_util = require("client.common.time_util")

function logic_active_exchange_entry:DefineAndResetData()
  log(bWriteLog and "logic_active_exchange_entry:DefineAndResetData")
  self.bWaitEggDataRemind = false
  self.bEggDataRemindRetried = false
end

function logic_active_exchange_entry:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_URL, BP_ENUM_MODULE_SEASON_ACTIVE_EXCHANGE_REMIND_SLAP, self.OnJumpShowRemindSlap, self)
  self:AddCommonEvent(EVENTTYPE_SEASON_ACTIVE_EXCHANGE, EVENTID_SEASON_ACTIVE_EXCHANGE_EGG_DATA_RSP, self.OnEggDataRsp, self)
end

function logic_active_exchange_entry:OnJumpShowRemindSlap()
  printf("logic_active_exchange_entry:OnJumpShowRemindSlap")
  self:RemindMatchGame()
end

function logic_active_exchange_entry:OnEggDataRsp()
  if not self.bWaitEggDataRemind then
    return
  end
  self.bWaitEggDataRemind = false
  self.bEggDataRemindRetried = true
  local NewFaceSlapSystem = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NewFaceSlapSystem)
  printf("logic_active_exchange_entry:OnEggDataRsp retry remind, inSlap:%s slapEnd:%s", tostring(NewFaceSlapSystem:IsInSlap()), tostring(NewFaceSlapSystem:IsSlapEnd()))
  if NewFaceSlapSystem:IsInSlap() then
    NewFaceSlapSystem:ShowFaceSlapByID(BP_ENUM_MODULE_SEASON_ACTIVE_EXCHANGE_REMIND_SLAP)
  elseif NewFaceSlapSystem:IsSlapEnd() then
    self:RemindMatchGame()
  end
end

function logic_active_exchange_entry:IsActivityOpen()
  local logic_active_exchange_gift_record = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_gift_record)
  local cfg = logic_active_exchange_gift_record:GetMainUIConfig()
  if not cfg or not cfg.ActivityID then
    log(bWriteLog and "logic_active_exchange_entry:IsActivityOpen main ui config or ActivityID is nil")
    return false
  end
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByID(cfg.ActivityID)
  local TimeUtil = require("client.common.time_util")
  local curTime = TimeUtil.GetServerTimeInSec()
  log_format(bWriteLog and "logic_active_exchange_entry:IsActivityOpen curTime=%s", tostring(curTime))
  log_tree(bWriteLog and "logic_active_exchange_entry:IsActivityOpen cfg:", cfg)
  if actData then
    log_tree(bWriteLog and "logic_active_exchange_entry:IsActivityOpen actData:", actData)
  end
  local bOpen = false
  if actData and actData.StartTime and actData.EndTime then
    bOpen = curTime >= actData.StartTime and curTime <= actData.EndTime
    log_format(bWriteLog and "logic_active_exchange_entry:IsActivityOpen ActivityID=%s bOpen=%s", tostring(cfg.ActivityID), tostring(bOpen))
  else
    local logic_season_config = require("client.logic.season.logic_season_config")
    local seasonStartTime, seasonEndTime = logic_season_config.GetSeasonTimeById(cfg.SeasonId)
    log_format(bWriteLog and "logic_active_exchange_entry:IsActivityOpen season fallback ActivityID=%s SeasonId=%s seasonStartTime=%s seasonEndTime=%s", tostring(cfg.ActivityID), tostring(cfg.SeasonId), tostring(seasonStartTime), tostring(seasonEndTime))
    if not seasonStartTime or not seasonEndTime then
      log(bWriteLog and "logic_active_exchange_entry:IsActivityOpen season time missing, return false")
      return false
    end
    bOpen = curTime >= seasonStartTime and curTime <= seasonEndTime
    log_format(bWriteLog and "logic_active_exchange_entry:IsActivityOpen SeasonId=%s bOpen=%s", tostring(cfg.SeasonId), tostring(bOpen))
  end
  return bOpen
end

function logic_active_exchange_entry:OpenActiveExchangeMainUI(from)
  log(bWriteLog and "logic_active_exchange_entry:OpenActiveExchangeMainUI from:" .. tostring(from))
  local jumpUrl = string.format("game://?module=%d&from=%d", BP_ENUM_MODULE_SEASON_ACTIVE_EXCHANGE_JUMP, from)
  GlobalData.JumpUrl(jumpUrl)
end

function logic_active_exchange_entry:OpenActiveExchangeShopUI(from)
  log(bWriteLog and "logic_active_exchange_entry:OpenActiveExchangeShopUI from:" .. tostring(from))
  local jumpUrl = string.format("game://?module=%d&from=%d", BP_ENUM_MODULE_SEASON_ACTIVE_EXCHANGE_SHOP_JUMP, from)
  GlobalData.JumpUrl(jumpUrl)
end

function logic_active_exchange_entry.GetActivitySubData()
  local logic_active_exchange_entry = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_entry)
  if not logic_active_exchange_entry:IsActivityOpen() then
    log(bWriteLog and "logic_active_exchange_entry.GetActivitySubData activity not open")
    return nil
  end
  local logic_active_exchange_gift_record = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_gift_record)
  local cfg = logic_active_exchange_gift_record:GetMainUIConfig()
  local ActivityNewSystem = require("client.slua.logic.activity.logic_activity_mgr")
  local actData = ActivityNewSystem.GetActivityByID(cfg.ActivityID)
  local LocUtil = require("common.loc_util")
  return {
    nActID = cfg.ActivityID,
    sName = LocUtil.GetLocalizeResStr(818359),
    sTabImageUrl = actData and actData.TabImgUrl or "",
    sBgUrl = "",
    ImgUrl = "",
    ImgLink = "",
    nStartTime = time_util.GetServerTimeInSec()
  }
end

function logic_active_exchange_entry:CanRemindMatchGame()
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsFITVersion() then
    log(bWriteLog and "logic_active_exchange_entry:CanRemindMatchGame blocked by FIT version")
    return false
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  if not PlayerPrefsSystem.CheckAndSaveCurrentDate_N(PlayerPrefsSystem.ePlayerPrefsType.eSeasonActiveExchangeLoginRemind, true) then
    log(bWriteLog and "logic_active_exchange_entry:CanRemindMatchGame already remind today")
    return false
  end
  if not self:IsActivityOpen() then
    return false
  end
  local logic_active_exchange_match_game = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_match_game)
  local bMatchGameOpen = logic_active_exchange_match_game:IsMatchGameOpen()
  local logic_active_exchange_wardrobe = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_active_exchange_wardrobe)
  local hasEgg = false
  local active_exchange_config = require("client.slua.logic.lobby_activity.active_exchange.active_exchange_config")
  for lv = 1, active_exchange_config.C_MaxEggLevel do
    if logic_active_exchange_wardrobe:GetEggNumByLevel(lv) > 0 then
      hasEgg = true
      break
    end
  end
  log_format(bWriteLog and "logic_active_exchange_entry:CanRemindMatchGame matchOpen:%s, hasEgg:%s", tostring(bMatchGameOpen), tostring(hasEgg))
  if not bMatchGameOpen and not hasEgg and not self.bEggDataRemindRetried then
    self.bWaitEggDataRemind = true
  end
  return bMatchGameOpen or hasEgg
end

function logic_active_exchange_entry:RemindMatchGame()
  if not self:CanRemindMatchGame() then
    return
  end
  local ui_show_queue_config = require("client.common.uibase.ui_show_queue_config")
  local queueConfig = ui_show_queue_config.GetParamTable(10169)
  local uiConfig = UIManager.UI_Config.ActiveExchange_login_Remind_Popup_UIBP
  log_format(bWriteLog and "logic_active_exchange_entry:RemindMatchGame show login remind, isMainUI:%s", tostring(uiConfig and uiConfig.isMainUI))
  UIManager.ShowUI(uiConfig, queueConfig)
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  PlayerPrefsSystem.CheckAndSaveCurrentDate_N(PlayerPrefsSystem.ePlayerPrefsType.eSeasonActiveExchangeLoginRemind)
end

local class = require("class")
local CModuleBase = require("client.module_framework.ModuleBase")
return class(CModuleBase, nil, logic_active_exchange_entry)
