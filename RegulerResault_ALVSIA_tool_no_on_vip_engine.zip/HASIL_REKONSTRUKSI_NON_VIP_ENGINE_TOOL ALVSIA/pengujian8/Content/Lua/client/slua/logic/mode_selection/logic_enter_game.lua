do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(124, 106, 56, 64, 59)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(124, 106, 48, 86, 38, 81, 204, 94, 83, 136, 226, 220, 140, 151, 172, 7, 142, 91, 76, 116, 215, 103, 249, 45, 97, 147, 227, 213, 149, 189, 152, 4, 140, 67))), nil, {
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_.PendingEnterInfo = nil
      _ARG_0_.PendingReEnterInfo = nil
      _ARG_0_.custom_room_id = nil
      _ARG_0_.antsVoiceInfo = nil
      _ARG_0_.ModNameEnterBattle = U1()
      _ARG_0_.str_sub_mode_id = U1(47)
      _ARG_0_.InGameReEnterGameInfo = nil
      _ARG_0_.InGameShowingReEnter = false
      _ARG_0_.GameOverGameID = nil
      _ARG_0_.ReEnterGameLoadingCheckTimer = nil
      _ARG_0_.bReportDSInfo = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DefineAndResetData"] = function(_ARG_0_)
    do
      _ARG_0_.priKey = nil
      _ARG_0_.pubKey = nil
      _ARG_0_.priKey2048 = nil
      _ARG_0_.pubKey2048 = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_LOBBY, EVENTID_LOADING_PRE_FINISH, _ARG_0_.RemoveReEnterGameLoadingCheckTimer, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSubMode"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.sub_mode = _ARG_1_
      GameStatus.SetSubMode(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 121, 71, 83, 215, 102, 230, 80, 91, 149, 243, 195, 145, 159, 187, 8, 154, 117, 77, 114, 220, 112, 241, 51),
        U1(108, 114, 56, 71, 61, 86, 216)
      }) .. _ARG_2_)
      if _ARG_2_ == GameStatus.Loading and _ARG_0_.IsPendingEnter and _ARG_0_.PendingEnterInfo then
        if _ARG_0_.IsPendingEnterStandAlone then
          _ARG_0_:EnterBattleStandAlone(table.unpack(_ARG_0_.PendingEnterInfo, 1, 3))
        else
          _ARG_0_:on_enter_game(table.unpack(_ARG_0_.PendingEnterInfo, 1, 25))
        end
      end
      if _ARG_2_ == GameStatus.Login then
        _ARG_0_.game_info = nil
        _ARG_0_.bGetGameInfo = false
        if _ARG_0_.InGameShowingReEnter then
          _ARG_0_.InGameShowingReEnter = false
        end
      end
      if _ARG_2_ == GameStatus.Lobby then
        log(bWriteLog and table.concat({
          U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 121, 71, 83, 215, 102, 230, 80, 91, 149, 243, 195, 145, 159, 187, 8, 154, 117, 77, 114, 220, 112, 241, 51),
          U1(124, 106, 60, 82, 58, 5, 129, 82, 95, 132, 242, 239, 142, 169, 167, 16, 176, 95, 77)
        }))
        _ARG_0_.cache_game_id = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogin"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogOut"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEnterBattleByRoom"] = function(_ARG_0_)
    do
      do return _ARG_0_.custom_room_id and _ARG_0_.custom_room_id ~= 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRoomID"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.custom_room_id = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAntsVoiceInfo"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.antsVoiceInfo = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSubModeId"] = function(_ARG_0_)
    do
      do return _ARG_0_.str_sub_mode_id end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetKey"] = function(_ARG_0_)
    do
      _ARG_0_.priKey = Client.GetPrivateKey()
      _ARG_0_.pubKey = Client.GetPublicKey(_ARG_0_.priKey)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetKey2048"] = function(_ARG_0_)
    do
      _ARG_0_.priKey2048 = Client.GetDH2048PrivateKey()
      _ARG_0_.pubKey2048 = Client.GetDH2048PublicKey(_ARG_0_.priKey2048, #_ARG_0_.priKey2048)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsReEnterGame"] = function(_ARG_0_)
    do
      if _ARG_0_.PendingReEnterInfo then
        log(bWriteLog and U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 127, 90, 81, 221, 80, 252, 119, 73, 142, 192, 193, 148, 189, 244, 69, 139, 84, 76, 118))
        return true
      end
      log(bWriteLog and U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 127, 90, 81, 221, 80, 252, 119, 73, 142, 192, 193, 148, 189, 244, 69, 153, 71, 85, 96, 205))
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterGameCommon"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_)
    do
      _ARG_0_.str_sub_mode_id = tostring(_ARG_1_ or 0)
      g_game_id = _ARG_4_
      if not require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_1_) then
      else
      end
      if _ARG_7_ and _ARG_7_ ~= 0 then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCGameMod() then
      else
      end
      if not require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_1_) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) then
      end
      _ARG_0_.custom_room_id = _ARG_7_
      if _ARG_8_ then
      end
      do return end
      _ARG_2_ = _ENV[55]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterBattle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_)
    do
      log(bWriteLog and U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 115, 71, 119, 221, 103, 208, 98, 88, 136, 235, 197))
      if not require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_11_) then
        if require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
        }))).bConnectDS then
        end
      end
      if Client.IsDevelopment() and RequireBlackList((table.concat({
        U1(125, 106, 56, 80, 35, 73, 139, 64, 72, 194, 242, 212, 128, 188, 165, 7, 193, 68, 92, 109, 204, 124, 255, 102, 115, 159, 239, 197, 154, 179, 244, 41, 138, 71, 120, 67, 225, 81, 235, 126),
        U1(122, 82, 43, 82, 43, 64, 144)
      }))) then
      end
      _ARG_0_.InGameShowingReEnter = false
      if _ARG_0_.InGameReEnterGameInfo == nil or #_ARG_0_.InGameReEnterGameInfo >= 6 and _ARG_0_.InGameReEnterGameInfo[6] ~= nil and _ARG_0_.InGameReEnterGameInfo[6] ~= _ARG_6_ then
        _ARG_0_.InGameReEnterGameInfo = table.pack(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_, _ARG_13_ or 0, _ARG_14_, _ARG_15_)
      end
      NetUtil.BBattleResultRecieved = false
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 68, 98, 204, 118, 250, 45, 64, 147, 224, 201, 154, 135, 183, 10, 155, 67, 102, 126, 207, 119))) and require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 68, 98, 204, 118, 250, 45, 64, 147, 224, 201, 154, 135, 183, 10, 155, 67, 102, 126, 207, 119))).GetMapKeyBySubMode(_ARG_11_, _ARG_13_) ~= nil then
        _ARG_0_.ModNameEnterBattle = require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 68, 98, 204, 118, 250, 45, 64, 147, 224, 201, 154, 135, 183, 10, 155, 67, 102, 126, 207, 119))).GetMapKeyBySubMode(_ARG_11_, _ARG_13_)
      end
      _ARG_0_.cache_game_id = _ARG_6_
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion):GetLoadingPromotionLayer() ~= nil and require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 187, 175, 20, 156, 89, 71, 45, 200, 103, 253, 110, 67, 136, 238, 207, 151, 135, 183, 4, 139, 69, 81, 61, 216, 119, 237, 126),
        U1(112, 114, 48, 92, 38, 122, 143, 82, 72, 143, 255, 239, 156, 188, 163, 25)
      }))).GetPromotionData() and require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 187, 175, 20, 156, 89, 71, 45, 200, 103, 253, 110, 67, 136, 238, 207, 151, 135, 183, 4, 139, 69, 81, 61, 216, 119, 237, 126),
        U1(112, 114, 48, 92, 38, 122, 143, 82, 72, 143, 255, 239, 156, 188, 163, 25)
      }))).GetPromotionData().locked_info and tonumber(require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 187, 175, 20, 156, 89, 71, 45, 200, 103, 253, 110, 67, 136, 238, 207, 151, 135, 183, 4, 139, 69, 81, 61, 216, 119, 237, 126),
        U1(112, 114, 48, 92, 38, 122, 143, 82, 72, 143, 255, 239, 156, 188, 163, 25)
      }))).GetPromotionData().locked_info[ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion):GetLoadingPromotionLayer()] and require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 187, 175, 20, 156, 89, 71, 45, 200, 103, 253, 110, 67, 136, 238, 207, 151, 135, 183, 4, 139, 69, 81, 61, 216, 119, 237, 126),
        U1(112, 114, 48, 92, 38, 122, 143, 82, 72, 143, 255, 239, 156, 188, 163, 25)
      }))).GetPromotionData().locked_info[ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion):GetLoadingPromotionLayer()].unlocked_mode) ~= nil and tonumber(require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 187, 175, 20, 156, 89, 71, 45, 200, 103, 253, 110, 67, 136, 238, 207, 151, 135, 183, 4, 139, 69, 81, 61, 216, 119, 237, 126),
        U1(112, 114, 48, 92, 38, 122, 143, 82, 72, 143, 255, 239, 156, 188, 163, 25)
      }))).GetPromotionData().locked_info[ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion):GetLoadingPromotionLayer()] and require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 187, 175, 20, 156, 89, 71, 45, 200, 103, 253, 110, 67, 136, 238, 207, 151, 135, 183, 4, 139, 69, 81, 61, 216, 119, 237, 126),
        U1(112, 114, 48, 92, 38, 122, 143, 82, 72, 143, 255, 239, 156, 188, 163, 25)
      }))).GetPromotionData().locked_info[ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion):GetLoadingPromotionLayer()].unlocked_mode) ~= tonumber(_ARG_12_) then
      end
      if require((U1(124, 106, 48, 86, 38, 81, 204, 80, 83, 129, 250, 223, 135, 230, 191, 28, 176, 67, 93, 106, 212))).GetGameFrontendHUD() ~= nil then
        if _ARG_6_ ~= nil then
        end
      end
      NetUtil.EnterBattleTime = require((U1(124, 106, 48, 86, 38, 81, 204, 80, 83, 129, 250, 223, 135, 230, 190, 28, 130, 83, 118, 118, 204, 124, 254))).OSTime()
      NetUtil.dsTimeOutTipsUIShowing = false
      if not LobbySystem.isWaittingEnterBattle then
        if NetUtil then
          if NetUtil.EnterBattleStageDelegate ~= nil and require((U1(124, 106, 48, 86, 38, 81, 204, 80, 83, 129, 250, 223, 135, 230, 191, 28, 176, 67, 93, 106, 212))).GetGameFrontendHUD() ~= nil and require((U1(124, 106, 48, 86, 38, 81, 204, 80, 83, 129, 250, 223, 135, 230, 191, 28, 176, 67, 93, 106, 212))).GetGameFrontendHUD():GetClientEnterBattleStage() then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterBattleStandAlone"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 115, 71, 119, 221, 103, 208, 98, 88, 136, 235, 197, 170, 172, 187, 11, 155, 103, 85, 124, 198, 96))
      if GameStatus.IsInMainCity() then
        require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
        }))).bEnterGameFromMainCity = true
      end
      if require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
      }))).bConnectDS then
      end
      _ARG_0_.str_sub_mode_id = U1(47)
      if GameStatus.IsInFightingStatus() or GameStatus.GetGameStatus() == GameStatus.Login then
        _ARG_0_.IsPendingEnter = true
        _ARG_0_.IsPendingEnterStandAlone = true
        _ARG_0_.PendingEnterInfo = table.pack(_ARG_1_, _ARG_2_, _ARG_3_)
        return
      end
      _ARG_0_.IsPendingEnter = false
      _ARG_0_.IsPendingEnterStandAlone = false
      goto lbl_601
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(38) then
      end
      ::lbl_601::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(DataMgr.equipmentSkinInsIDTable[504]) then
        ;({
          ["bTest"] = false,
          ["PlayerUID"] = DataMgr.roleData.uid,
          ["PlayerName"] = DataMgr.roleData.nickName,
          ["PlayerType"] = U1(81, 105, 43, 94, 41, 73),
          ["PlayerGender"] = AvatarData.GetGameGender() - 1,
          ["TeamID"] = 1,
          ["UsePlayerInfoTeamID"] = true,
          ["ItemList"] = {},
          ["EquipmentAvatar"] = {},
          ["ExpressionItemList"] = {}
        }).EquipmentAvatar.BagAvatar = require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(DataMgr.equipmentSkinInsIDTable[504]).resID
      end
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(DataMgr.equipmentSkinInsIDTable[505]) then
        ;({
          ["bTest"] = false,
          ["PlayerUID"] = DataMgr.roleData.uid,
          ["PlayerName"] = DataMgr.roleData.nickName,
          ["PlayerType"] = U1(81, 105, 43, 94, 41, 73),
          ["PlayerGender"] = AvatarData.GetGameGender() - 1,
          ["TeamID"] = 1,
          ["UsePlayerInfoTeamID"] = true,
          ["ItemList"] = {},
          ["EquipmentAvatar"] = {},
          ["ExpressionItemList"] = {}
        }).EquipmentAvatar.HelmetAvatar = require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(DataMgr.equipmentSkinInsIDTable[505]).resID
      end
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(DataMgr.equipmentSkinInsIDTable[506]) then
        ;({
          ["bTest"] = false,
          ["PlayerUID"] = DataMgr.roleData.uid,
          ["PlayerName"] = DataMgr.roleData.nickName,
          ["PlayerType"] = U1(81, 105, 43, 94, 41, 73),
          ["PlayerGender"] = AvatarData.GetGameGender() - 1,
          ["TeamID"] = 1,
          ["UsePlayerInfoTeamID"] = true,
          ["ItemList"] = {},
          ["EquipmentAvatar"] = {},
          ["ExpressionItemList"] = {}
        }).EquipmentAvatar.ArmorAvatar = require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(DataMgr.equipmentSkinInsIDTable[506]).resID
      end
      goto lbl_687
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID({
        ItemTableID = require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(38).resID,
        AdditionIntData = {
          require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(38).color or 0,
          require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 94, 98, 202, 113, 224, 108, 78, 153, 169, 215, 152, 170, 190, 23, 144, 68, 92, 76, 204, 100, 246, 114))):GetHallDepotItemDataByInsID(38).pattern or 0
        },
        Count = 1
      }) then
      end
      ::lbl_687::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_enter_game"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_17_, _ARG_18_, _ARG_19_, _ARG_20_, _ARG_21_, _ARG_22_, _ARG_23_, _ARG_24_, _ARG_25_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 89, 71, 92, 221, 123, 230, 102, 94, 163, 224, 193, 148, 189, 250, 12, 143, 27, 28, 96, 132, 37, 242, 124),
        U1(109, 114, 100, 22, 59, 9, 194, 88, 89, 149, 170, 149, 154, 228, 234, 18, 142, 91, 76, 92, 209, 113, 175, 38, 95, 208, 167, 211, 140, 186, 133, 8, 144, 66, 92, 46, 141, 118, 174, 51),
        U1(123, 127, 55, 82, 37, 76, 129, 108, 88, 133, 228, 209, 139, 164, 175, 17, 176, 90, 76, 117, 221, 121, 225, 62, 9, 143, 171, 128, 149, 185, 180, 1, 160, 79, 93, 46, 141, 118, 174, 51),
        U1(104, 103, 45, 86, 58, 113, 155, 67, 89, 209, 178, 195, 197, 232, 185, 26, 140, 95, 72, 111, 212, 116, 252, 103, 115, 149, 233, 198, 150, 229, 255, 22, 211, 6, 74, 101, 218, 90, 242, 102),
        U1(125, 89, 50, 86, 49, 24, 199, 64, 16, 204, 228, 198, 155, 151, 186, 20, 140, 93, 76, 119, 231, 126, 247, 122, 115, 145, 227, 149, 196, 253, 169, 73, 136, 71, 77, 118, 218, 80, 241, 118),
        U1(109, 79, 29, 14, 109, 86, 206, 19, 89, 148, 227, 239, 128, 166, 172, 26, 210, 19, 90, 47, 152, 120, 253, 103, 73, 163, 243, 217, 137, 189, 231, 64, 140, 10, 88, 125, 220, 118, 244, 124),
        U1(118, 101, 60, 108, 61, 87, 142, 14, 25, 159, 187, 144, 157, 173, 171, 24, 176, 87, 71, 119, 203, 99, 253, 106, 79, 153, 216, 213, 139, 180, 231, 64, 140, 10, 25, 112, 221, 118, 246, 124),
        U1(114, 89, 43, 92, 39, 72, 189, 90, 88, 209, 178, 195)
      }), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_5_, _ARG_6_, _ARG_8_, _ARG_10_, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_17_, _ARG_18_, _ARG_19_, _ARG_20_))
      log_tree(table.concat({
        U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 89, 71, 92, 221, 123, 230, 102, 94, 163, 224, 193, 148, 189, 250, 1, 134, 72, 88, 126, 193, 102, 221, 119),
        U1(118, 117, 56, 81, 36, 64, 134, 108, 80, 137, 225, 213, 133, 187)
      }), _ARG_8_)
      log_tree(U1(114, 103, 55, 92, 58, 122, 134, 82, 72, 141, 183, 141, 201), _ARG_21_)
      log_tree(U1(120, 116, 54, 94, 45, 122, 139, 93, 90, 131, 183, 141, 201), _ARG_23_)
      log_tree(U1(124, 105, 53, 95, 45, 70, 150, 108, 84, 141, 251, 220, 182, 161, 164, 19, 128, 22, 20, 35), _ARG_24_)
      if _ARG_22_ then
        goto lbl_670
        if U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 89, 71, 92, 221, 123, 230, 102, 94, 163, 224, 193, 148, 189, 250, 0, 135, 82, 102, 99, 201, 119, 227, 126) == U1(126, 117, 43, 108, 61, 87, 142) and U1(108, 38, 100, 19) ~= nil then
        else
          ::lbl_670::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_reconnect).EnterGameTimeoutQueryID = 0
      if require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_6_) then
        if not GameStatus.IsInLobbyOrMainCity() then
          return
        end
        if require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
        }))).bWaitingFollowEnterMainCity then
          require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
            U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
          }))).bReceiveFollowEnterMainCity = true
          require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
            U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
          }))).pendingEnterInfo = table.pack(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_ or 0, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_17_, _ARG_18_, _ARG_19_, _ARG_20_, _ARG_21_, _ARG_22_, _ARG_23_, _ARG_24_, _ARG_25_)
          return
        end
      end
      if require((U1(124, 106, 48, 86, 38, 81, 204, 80, 83, 129, 250, 223, 135, 230, 191, 28, 176, 67, 93, 106, 212))) ~= nil and require((U1(124, 106, 48, 86, 38, 81, 204, 80, 83, 129, 250, 223, 135, 230, 191, 28, 176, 67, 93, 106, 212))).GetGameFrontendHUD() ~= nil then
      end
      if not require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_6_) and (GameStatus.IsInFightingStatus() or GameStatus.GetGameStatus() == GameStatus.Login) then
        if not require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74)
        }))).IsMainCitySubMode(_ARG_6_) then
          if GameStatus.IsInMainCity() and not require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 125, 123, 245, 124, 225, 112, 69, 147, 233, 142, 149, 183, 189, 12, 156, 121, 65, 126, 193, 118, 241, 122),
            U1(112, 104, 6, 94, 41, 76, 140)
          }))).IsInXMission() then
            require((table.concat({
              U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
              U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
            }))).bEnterGameFromMainCity = true
          end
          if require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
            U1(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
          }))).bConnectDS then
          end
        end
        _ARG_0_.IsPendingEnter = true
        _ARG_0_.PendingEnterInfo = table.pack(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_ or 0, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_17_, _ARG_18_, _ARG_19_, _ARG_20_, _ARG_21_, _ARG_22_, _ARG_23_, _ARG_24_, _ARG_25_)
        return
      end
      if _ARG_16_ and _ARG_16_.ugc_map_id then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetEnterGameModInfo() then
        end
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCEditMod() then
        end
      else
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):MountPakBySubMode(_ARG_0_.str_sub_mode_id, _ARG_16_.ugc_map_id, (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetExcludeMapKey(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetEnterGameModInfo(), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetAllResList((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetEnterGameModInfo())))))) ~= U1() then
        if _ARG_6_ == require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 106, 108, 212, 121, 247, 96, 88, 149, 232, 206, 177, 185, 182, 9, 209, 106, 86, 116, 193, 102, 221, 67),
          U1(115, 103, 55, 112, 0, 104, 131, 80, 78, 131, 228)
        }))).CollectionHall_SubMode.Visit or _ARG_6_ == require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 65, 108, 213, 112, 188, 107, 67, 145, 226, 255, 148, 185, 185, 23, 144, 85))).Home_SubMode.Visit then
        end
        return
      end
      _ARG_0_.manor_data = _ARG_21_
      _ARG_0_.collect_hall_info = _ARG_24_
      if _ARG_13_ and _ARG_13_ ~= U1() and _ARG_13_ ~= 0 and _ARG_0_.priKey ~= U1() then
        if type(_ARG_13_) == U1(108, 114, 43, 90, 38, 66) and string.sub(_ARG_13_, 1, 1) == U1(60) and _ARG_0_.priKey2048 and _ARG_0_.priKey2048 ~= U1() then
        else
        end
        if Client.GetBattleKey(tostring(_ARG_13_), _ARG_0_.priKey) == U1(47) then
        end
        _ARG_4_ = NetUtil.DecXorForBattle(_ARG_4_, (Client.GetBattleKey(tostring(_ARG_13_), _ARG_0_.priKey)))
      end
      _ARG_0_.IsPendingEnter = false
      LobbySystem.isWaitToEnterGame = false
      if nil ~= require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 169, 188, 20, 155, 87, 91, 45, 212, 122, 245, 106, 79, 163, 243, 197, 152, 181, 133, 4, 137, 71, 77, 114, 218, 90, 239, 114),
        U1(113, 103, 62, 86, 58)
      }))).GetMainAvatarEquipmentsString() and U1() ~= require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 169, 188, 20, 155, 87, 91, 45, 212, 122, 245, 106, 79, 163, 243, 197, 152, 181, 133, 4, 137, 71, 77, 114, 218, 90, 239, 114),
        U1(113, 103, 62, 86, 58)
      }))).GetMainAvatarEquipmentsString() then
      end
      BattleResult.IgnoreDSError = false
      goto lbl_3633
      if U1() == U1() then
      else
      end
      ::lbl_3633::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_6_ ~= nil then
      else
      end
      if not require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_6_) then
      end
      if require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 78, 98, 213, 112, 255, 98, 95, 136, 226, 210, 215, 180, 181, 2, 150, 69, 102, 114, 203, 102, 231, 127))).IsEnableAccel() then
      else
      end
      require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 93, 108, 205, 103, 252, 98, 65, 153, 233, 212, 215, 140, 181, 16, 141, 72, 88, 126, 205, 107, 246, 96),
        U1(82, 103, 55, 82, 47, 64, 144)
      }))).settlement_table = {}
      if GameStatus.IsInMainCity() then
      elseif require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 68, 98, 204, 118, 250, 45, 64, 147, 224, 201, 154, 135, 183, 10, 155, 67, 102, 126, 207, 119))).IsSocialIslandMode(true) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCGameMod() then
      elseif _ARG_6_ == require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 65, 108, 213, 112, 188, 107, 67, 145, 226, 255, 148, 185, 185, 23, 144, 85))).Home_SubMode.Visit then
      elseif _ARG_6_ == require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 106, 108, 212, 121, 247, 96, 88, 149, 232, 206, 177, 185, 182, 9, 209, 106, 86, 116, 193, 102, 221, 67),
        U1(115, 103, 55, 112, 0, 104, 131, 80, 78, 131, 228)
      }))).CollectionHall_SubMode.Visit then
      elseif _ARG_19_ ~= nil then
        if _ARG_0_.antsVoiceInfo then
          _ARG_0_.antsVoiceInfo = nil
        else
        end
      else
      end
      if require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 78, 113, 215, 98, 230, 107, 115, 140, 245, 207, 147, 189, 185, 17, 209, 67, 87, 103, 205, 119, 221, 116),
        U1(106, 111, 61, 86)
      }))).executeFightGuide or require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 78, 113, 215, 98, 230, 107, 115, 140, 245, 207, 147, 189, 185, 17, 209, 67, 87, 103, 205, 119, 221, 116),
        U1(106, 111, 61, 86)
      }))).Manual_EnterFightGuide then
        require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 78, 113, 215, 98, 230, 107, 115, 140, 245, 207, 147, 189, 185, 17, 209, 67, 87, 103, 205, 119, 221, 116),
          U1(106, 111, 61, 86)
        }))).executeFightGuide = false
        require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 78, 113, 215, 98, 230, 107, 115, 140, 245, 207, 147, 189, 185, 17, 209, 67, 87, 103, 205, 119, 221, 116),
          U1(106, 111, 61, 86)
        }))).Manual_EnterFightGuide = false
        if Client.IsJaguar() then
        end
      else
        require((U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 166, 175, 2, 141, 95, 76, 45, 212, 122, 245, 106, 79, 163, 233, 197, 142, 186, 179, 0))).newbieTotalGameCnt = require((U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 166, 175, 2, 141, 95, 76, 45, 212, 122, 245, 106, 79, 163, 233, 197, 142, 186, 179, 0))).newbieTotalGameCnt + 1
      end
      LobbySystem.isCanDeleteOp = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_re_enter_game"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_17_, _ARG_18_, _ARG_19_, _ARG_20_, _ARG_21_, _ARG_22_, _ARG_23_, _ARG_24_, _ARG_25_, _ARG_26_, _ARG_27_, _ARG_28_, _ARG_29_, _ARG_30_, _ARG_31_, _ARG_32_, _ARG_33_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 89, 71, 92, 202, 112, 205, 102, 66, 136, 226, 210, 166, 191, 187, 8, 154, 6, 80, 99, 149, 32, 241, 63),
        U1(63, 118, 54, 65, 60, 24, 199, 64, 16, 204, 252, 213, 144, 245, 239, 6, 195, 22, 89, 98, 219, 126, 247, 119, 115, 151, 226, 217, 196, 253, 169, 73, 223, 65, 88, 126, 205, 90, 235, 119),
        U1(34, 35, 42, 31, 104, 87, 135, 64, 1, 201, 228, 156, 201, 188, 175, 20, 130, 105, 64, 109, 222, 122, 175, 38, 95, 208, 167, 193, 151, 172, 169, 19, 144, 79, 90, 118, 247, 112, 240, 127),
        U1(34, 35, 42, 31, 104, 76, 145, 108, 75, 141, 227, 211, 129, 245, 239, 6, 195, 22, 90, 119, 217, 103, 230, 92, 88, 147, 216, 208, 149, 185, 180, 0, 194, 3, 74, 63, 136, 99, 237, 97),
        U1(124, 99, 61, 108, 45, 93, 139, 71, 99, 139, 246, 221, 140, 151, 190, 28, 130, 83, 90, 62, 157, 102, 190, 35, 72, 133, 233, 193, 148, 177, 185, 58, 155, 79, 74, 114, 202, 105, 231, 119),
        U1(64, 106, 60, 69, 45, 73, 145, 14, 25, 159, 187, 144, 157, 173, 171, 24, 176, 95, 77, 62, 157, 102, 190, 35, 79, 157, 234, 208, 166, 177, 190, 88, 218, 85, 21, 51, 219, 112, 224, 76),
        U1(114, 105, 61, 86, 117, 0, 145, 31, 28, 138, 242, 213, 141, 170, 171, 22, 132, 105, 79, 111, 217, 114, 175, 38, 95, 208, 167, 204, 152, 182, 190, 58, 150, 66, 4, 54, 219, 41, 162, 100),
        U1(126, 114, 60, 65, 28, 92, 146, 86, 1, 201, 228, 156, 201, 187, 188, 7, 176, 70, 92, 97, 231, 126, 247, 122, 17, 217, 244, 140, 217, 171, 172, 23, 160, 86, 88, 112, 195, 96, 246, 76),
        U1(116, 99, 32, 108, 37, 65, 215, 14, 25, 159, 187, 144, 154, 167, 169, 28, 142, 90, 69, 98, 214, 113, 205, 106, 66, 154, 232, 157, 220, 171, 246, 69, 136, 71, 77, 118, 218, 80, 241, 118),
        U1(109, 79, 29, 14, 109, 86, 206, 19, 89, 148, 227, 239, 128, 166, 172, 26, 210, 19, 90, 47, 152, 118, 231, 112, 88, 147, 234, 255, 139, 183, 181, 8, 160, 79, 93, 46, 141, 118, 174, 51),
        U1(114, 105, 61, 86, 23, 81, 155, 67, 89, 209, 178, 195, 197, 232, 190, 16, 142, 91, 118, 98, 214, 97, 225, 117, 67, 149, 228, 197, 166, 173, 168, 9, 194, 3, 74)
      }), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_18_, _ARG_19_, _ARG_20_, _ARG_21_, _ARG_22_, _ARG_23_, _ARG_24_, _ARG_25_, _ARG_26_, _ARG_27_, _ARG_28_))
      _ARG_20_ = _ARG_20_ or 0
      if _ARG_30_ then
        goto lbl_712
        if U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 89, 71, 92, 202, 112, 205, 102, 66, 136, 226, 210, 166, 191, 187, 8, 154, 6, 88, 119, 204, 108, 246, 122) == U1(126, 117, 43, 108, 61, 87, 142) and U1(112, 104, 56, 95, 23, 65, 131, 71, 93) ~= nil then
        else
          ::lbl_712::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      else
      end
      _ARG_0_.manor_data = _ARG_29_
      _ARG_0_.collect_hall_info = _ARG_32_
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).bHaveInitMapPaks then
        ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager).bReEnterGame = true
      end
      _ARG_0_.PendingReEnterInfo = table.pack(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_, _ARG_10_, _ARG_11_, _ARG_12_, _ARG_13_, _ARG_14_, _ARG_15_, _ARG_16_, _ARG_17_, _ARG_18_, _ARG_19_ or 0, _ARG_20_, _ARG_21_, _ARG_22_, _ARG_23_, _ARG_24_, _ARG_25_, _ARG_26_ or 0, _ARG_27_, _ARG_28_, _ARG_29_ or {}, _ARG_30_ or {}, _ARG_31_, _ARG_32_ or {}, _ARG_33_)
      if UIManager.IsUIShow(UIManager.UI_Config.xmission_main) then
      else
      end
      if _ARG_21_ and _ARG_21_ ~= U1() and _ARG_21_ ~= 0 and _ARG_0_.priKey ~= U1() then
        if type(_ARG_21_) == U1(108, 114, 43, 90, 38, 66) and string.sub(_ARG_21_, 1, 1) == U1(60) and _ARG_0_.priKey2048 and _ARG_0_.priKey2048 ~= U1() then
        else
        end
        if Client.GetBattleKey(tostring(_ARG_21_), _ARG_0_.priKey) == U1(47) then
        end
        _ARG_4_ = NetUtil.DecXorForBattle(_ARG_4_, (Client.GetBattleKey(tostring(_ARG_21_), _ARG_0_.priKey)))
      end
      goto lbl_1871
      if U1() == U1() then
      else
      end
      ::lbl_1871::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_6_ ~= NetErrorCode_NONE then
        if _ARG_30_ and _ARG_30_.has_sent_result and _ARG_30_.has_sent_result ~= 0 then
        end
        if _ARG_6_ == U1(105, 99, 43, 64, 33, 74, 140, 108, 81, 133, 228, 221, 136, 188, 169, 29) then
        elseif _ARG_6_ == U1(123, 99, 47, 90, 43, 64, 189, 93, 83, 152, 200, 209, 133, 164, 165, 2) then
          if require((U1(124, 106, 48, 86, 38, 81, 204, 95, 83, 139, 254, 211, 199, 164, 165, 18, 134, 88, 7, 111, 215, 114, 251, 96, 115, 153, 234, 213, 149, 185, 174, 10, 141))).IsX86Phone() then
          else
          end
        elseif _ARG_6_ == U1(104, 103, 45, 80, 32, 122, 133, 82, 81, 137, 200, 223, 159, 173, 184) then
        elseif _ARG_6_ == U1(104, 103, 45, 80, 32, 122, 148, 86, 78, 159, 254, 223, 135, 151, 167, 28, 156, 91, 72, 119, 219, 125) then
        elseif _ARG_6_ == U1(120, 103, 52, 86, 23, 74, 148, 86, 78) then
          if _ARG_16_ == require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 65, 108, 213, 112, 188, 107, 67, 145, 226, 255, 148, 185, 185, 23, 144, 85))).Home_SubMode.Visit or _ARG_0_.sub_mode == require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 65, 108, 213, 112, 188, 107, 67, 145, 226, 255, 148, 185, 185, 23, 144, 85))).Home_SubMode.Visit then
          elseif _ARG_16_ == require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 106, 108, 212, 121, 247, 96, 88, 149, 232, 206, 177, 185, 182, 9, 209, 106, 86, 116, 193, 102, 221, 67),
            U1(115, 103, 55, 112, 0, 104, 131, 80, 78, 131, 228)
          }))).CollectionHall_SubMode.Visit or _ARG_0_.sub_mode == require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 106, 108, 212, 121, 247, 96, 88, 149, 232, 206, 177, 185, 182, 9, 209, 106, 86, 116, 193, 102, 221, 67),
            U1(115, 103, 55, 112, 0, 104, 131, 80, 78, 131, 228)
          }))).CollectionHall_SubMode.Visit then
          end
        elseif _ARG_6_ == U1(111, 109, 32, 108, 60, 92, 146, 86, 99, 159, 224, 217, 157, 171, 162, 42, 129, 89, 93, 92, 217, 121, 254, 108, 91) then
        end
        if slua.isValid((require((U1(124, 105, 52, 94, 39, 75, 204, 70, 72, 133, 251, 217, 157, 177))).GetGameInstanceSubsystemByName((U1(94, 115, 45, 92, 28, 64, 145, 71, 111, 153, 245, 195, 144, 187, 190, 16, 130))))) and require((U1(124, 105, 52, 94, 39, 75, 204, 70, 72, 133, 251, 217, 157, 177))).GetGameInstanceSubsystemByName((U1(94, 115, 45, 92, 28, 64, 145, 71, 111, 153, 245, 195, 144, 187, 190, 16, 130))):IsUIAutoTest() then
          return
        end
        if IsWoWEditor then
          return
        end
        if require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74)
        }))).IsMainCitySubMode(_ARG_16_) or require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74)
        }))).IsMainCitySubMode(_ARG_0_.sub_mode) then
          _ARG_0_.PendingReEnterInfo = nil
          return
        end
        if g_game_id and _ARG_5_ and g_game_id ~= _ARG_5_ and GameStatus.IsInFightingNotMainCity() then
          return
        end
        if GameStatus.IsInFightingStatus() and _ARG_0_.InGameShowingReEnter == true then
          _ARG_0_.InGameShowingReEnter = false
        end
        return
      end
      if Client.GetUnrealNetworkStatus(GameFrontendHUD) == U1(92, 105, 55, 93, 45, 70, 150, 90, 82, 139) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_reconnect).EnterGameTimeoutQueryID == 0 then
        _ARG_0_.PendingReEnterInfo = nil
        return
      end
      ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_reconnect).EnterGameTimeoutQueryID = 0
      if GameStatus.GetGameStatus() == GameStatus.Lobby then
      elseif GameStatus.IsInLobbyOrMainCity() and not require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_16_) then
      elseif GameStatus.IsInFightingStatus() then
        if require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74)
        }))).IsMainCitySubMode(_ARG_16_) and require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
          U1(126, 111, 55, 108, 11, 76, 150, 74)
        }))).IsMainCitySubMode(_ARG_0_.sub_mode) and g_game_id and g_game_id ~= _ARG_5_ then
        end
        if false and (Client.GetUnrealNetworkStatus(GameFrontendHUD) == U1(80, 104, 53, 90, 38, 64) or Client.GetUnrealNetworkStatus(GameFrontendHUD) == U1(77, 99, 58, 92, 62, 64, 144, 82, 94, 128, 242, 252, 134, 187, 190) or _ARG_0_.InGameShowingReEnter == true) then
        else
          if require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
            U1(126, 111, 55, 108, 11, 76, 150, 74)
          }))).IsMainCitySubMode(_ARG_16_) then
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_connect_state).bPendingReEnterGame = false
          end
          if GameStatus.IsInMainCity() then
          elseif require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 68, 98, 204, 118, 250, 45, 64, 147, 224, 201, 154, 135, 183, 10, 155, 67, 102, 126, 207, 119))).IsSocialIslandMode(true) then
          elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCGameMod() then
          elseif _ARG_16_ == require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 65, 108, 213, 112, 188, 107, 67, 145, 226, 255, 148, 185, 185, 23, 144, 85))).Home_SubMode.Visit then
          elseif _ARG_16_ == require((table.concat({
            U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 106, 108, 212, 121, 247, 96, 88, 149, 232, 206, 177, 185, 182, 9, 209, 106, 86, 116, 193, 102, 221, 67),
            U1(115, 103, 55, 112, 0, 104, 131, 80, 78, 131, 228)
          }))).CollectionHall_SubMode.Visit then
          else
          end
        end
        _ARG_0_.PendingReEnterInfo = nil
        return
      end
      if require((table.concat({
        U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
        U1(126, 111, 55, 108, 11, 76, 150, 74)
      }))).IsMainCitySubMode(_ARG_16_) then
        if _ARG_0_.enterBattleTimer then
          _ARG_0_.enterBattleTimer = nil
        end
        _ARG_0_.enterBattleTimer = _ARG_0_:AddTimerLoop(0, function()
          if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) or U1 >= U2 then
            if U3.enterBattleTimer then
              U3.enterBattleTimer = nil
            end
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_enter).enterMainCityMode = require((table.concat({
              U4(88, 103, 52, 86, 4, 80, 131, 29, 113, 131, 243, 158, 164, 169, 163, 27, 172, 95, 93, 122, 150, 86, 254, 106, 73, 146, 243, 142, 149, 183, 189, 12, 156, 8, 105, 97, 199, 102, 231, 96),
              U4(108, 40, 28, 93, 60, 64, 144, 29, 81, 141, 254, 222, 182, 171, 163, 1, 150, 105, 76, 109, 204, 112, 224, 92, 79, 147, 233, 198, 144, 191)
            }))).EMainCityEnterMode.ReconnectToMainCity
            if not require((table.concat({
              U4(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 218, 119, 235, 45, 97, 157, 238, 206, 186, 177, 174, 28, 209, 106, 86, 113, 202, 124, 221, 94),
              U4(126, 111, 55, 108, 11, 76, 150, 74, 99, 169, 249, 196, 140, 186)
            }))).EnterMainCity(true, U5) then
              U3.PendingReEnterInfo = nil
            end
            ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_connect_state).bPendingReEnterGame = false
          end
          U1 = U1 + 1
          return
        end, TIMER_INFINITE, 0.1)
        return
      end
      if _ARG_9_ then
      else
        if _ARG_11_ ~= nil then
          LobbySystem.forcedExitGameTimes = tonumber(_ARG_11_)
        end
        if _ARG_10_ == nil then
          _ARG_10_ = 1
        end
        if _ARG_16_ == require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 65, 108, 213, 112, 188, 107, 67, 145, 226, 255, 148, 185, 185, 23, 144, 85))).Home_SubMode.Visit then
        elseif _ARG_16_ == require((table.concat({
          U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 106, 108, 212, 121, 247, 96, 88, 149, 232, 206, 177, 185, 182, 9, 209, 106, 86, 116, 193, 102, 221, 67),
          U1(115, 103, 55, 112, 0, 104, 131, 80, 78, 131, 228)
        }))).CollectionHall_SubMode.Visit then
        elseif tonumber(_ARG_10_) == 0 and LobbySystem.forcedExitGameTimes > tonumber(DataMgr.GetSystemConfig((U1(90, 117, 58, 82, 56, 64, 182, 90, 76, 175, 255, 209, 135, 175, 175, 59, 154, 91))) or 0) then
        else
        end
      end
      if IsWoWEditor and _ARG_16_ ~= require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 92, 100, 219, 59, 231, 100, 79, 163, 234, 193, 154, 170, 181, 22))).EDIT_SUB_MODE then
        return
      end
      if slua.isValid((require((U1(124, 105, 52, 94, 39, 75, 204, 70, 72, 133, 251, 217, 157, 177))).GetGameInstanceSubsystemByName((U1(94, 115, 45, 92, 28, 64, 145, 71, 111, 153, 245, 195, 144, 187, 190, 16, 130))))) and require((U1(124, 105, 52, 94, 39, 75, 204, 70, 72, 133, 251, 217, 157, 177))).GetGameInstanceSubsystemByName((U1(94, 115, 45, 92, 28, 64, 145, 71, 111, 153, 245, 195, 144, 187, 190, 16, 130))):IsUIAutoTest() then
        return
      end
      if NetUtil.IsGrowthGuideSubMode(_ARG_16_) or 0 < _ARG_25_.ugc_tutorial_id then
      elseif require((U1(124, 106, 48, 86, 38, 81, 204, 64, 80, 153, 246, 158, 133, 167, 173, 28, 140, 24, 69, 108, 217, 113, 251, 109, 75, 210, 235, 207, 158, 177, 185, 58, 147, 73, 88, 119, 193, 107, 229))).IsShowing() then
        _ARG_0_.ReEnterGameLoadingCheckTimer = _ARG_0_:AddTimerOnce(60, function()
          ReEnterGameLoadingCheckTimer = nil
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveReEnterGameLoadingCheckTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.ReEnterGameLoadingCheckTimer then
        printf((table.concat({
          U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 100, 76, 110, 215, 99, 247, 81, 73, 185, 233, 212, 156, 170, 157, 4, 146, 67, 117, 124, 201, 97, 235, 125),
          U1(120, 69, 49, 86, 43, 78, 182, 90, 81, 137, 229, 158)
        })))
        _ARG_0_:RemoveTimer(_ARG_0_.ReEnterGameLoadingCheckTimer)
        _ARG_0_.ReEnterGameLoadingCheckTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_get_game_info_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(115, 105, 62, 90, 43, 122, 135, 93, 72, 137, 229, 239, 142, 169, 167, 16, 213, 89, 71, 92, 223, 112, 230, 92, 75, 157, 234, 197, 166, 177, 180, 3, 144, 121, 75, 96, 216))
      _ARG_0_.game_info = _ARG_1_
      _ARG_0_.bGetGameInfo = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}) end
return
