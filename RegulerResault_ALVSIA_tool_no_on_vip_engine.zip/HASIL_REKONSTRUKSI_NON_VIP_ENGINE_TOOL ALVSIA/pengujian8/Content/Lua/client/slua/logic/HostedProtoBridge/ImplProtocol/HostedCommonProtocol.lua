do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(8, 10, 224, 78, 252)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(8, 10, 232, 88, 225, 182, 106, 92, 37, 111, 198, 231, 37, 122, 45, 96, 250, 59, 148, 122, 16, 128, 95, 47, 23, 116, 199, 238, 60, 80, 25, 99, 248, 35))), nil, {
  ["QueryCoinRet"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 81, 163, 65, 100, 40, 98, 224, 244, 57, 91, 9, 103, 255, 124, 193) .. tostring(DataMgr.ticket))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):IsRestrictUC() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUserData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_.content then
        log(bWriteLog and table.concat({
          U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 181, 81, 117, 15, 104, 198, 233, 20, 84, 47, 99, 165, 102, 130, 114, 1, 150, 65, 127),
          U1(31, 70, 232, 78, 175, 172, 45, 93)
        }))
        return
      end
      goto lbl_210
      if U1(31, 70, 232, 78, 175, 172, 45, 93) == U1(9, 3, 237, 82, 225, 165, 45, 95, 45, 66, 215) then
      elseif U1(31, 70, 232, 78, 175, 172, 45, 93) == U1(24, 50, 232, 94, 228, 167, 48) then
      elseif U1(31, 70, 232, 78, 175, 172, 45, 93) == U1(24, 52, 238, 81, 234, 140, 37, 92, 47) then
      elseif U1(31, 70, 232, 78, 175, 172, 45, 93) == U1(3, 3, 224, 89, 218, 176, 40) then
      elseif U1(31, 70, 232, 78, 175, 172, 45, 93) == U1(7, 7, 239, 90, 250, 163, 35, 84) then
      elseif U1(31, 70, 232, 78, 175, 172, 45, 93) == U1(24, 40, 228, 73, 219, 187, 52, 84) then
      else
      end
      ::lbl_210::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if require((U1(8, 10, 232, 88, 225, 182, 106, 82, 37, 102, 222, 228, 46, 11, 62, 123, 196, 35, 133, 100, 19))).GetItemSmallIcon(DataMgr.roleData.cur_avatar_box_id) and require((U1(8, 10, 232, 88, 225, 182, 106, 82, 37, 102, 222, 228, 46, 11, 62, 123, 196, 35, 133, 100, 19))).GetItemSmallIcon(DataMgr.roleData.cur_avatar_box_id) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDateFormat"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHeadCfg"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_61
      ::lbl_61::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CopyToClipBoard"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(U1(75, 70, 187, 126, 224, 178, 61, 101, 37, 72, 223, 226, 48, 103, 36, 115, 233, 50, 209, 105, 30, 134, 85), _ARG_1_)
      if _ARG_1_.word then
        Client.ClipBoardCopy(_ARG_1_.word)
        if _ARG_1_.showTip then
          ShowNotice(_ARG_1_.showTip)
        else
          ShowNotice(105001)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaySound"] = function(_ARG_0_, _ARG_1_)
    do
      if sound_config[_ARG_1_.content] then
      else
      end
      if _ARG_1_.content and _ARG_1_.content ~= U1() then
        if not (require((table.concat({
          U1(8, 10, 232, 88, 225, 182, 106, 93, 37, 108, 218, 232, 110, 68, 61, 115, 239, 55, 131, 35, 19, 157, 83, 104, 57, 68, 215, 254, 49, 88, 4, 99, 253, 39, 149, 124, 29, 189, 73, 112),
          U1(5, 7, 230, 88, 253)
        }))).GetMainAvatar() and require((table.concat({
          U1(8, 10, 232, 88, 225, 182, 106, 93, 37, 108, 218, 232, 110, 68, 61, 115, 239, 55, 131, 35, 19, 157, 83, 104, 57, 68, 215, 254, 49, 88, 4, 99, 253, 39, 149, 124, 29, 189, 73, 112),
          U1(5, 7, 230, 88, 253)
        }))).GetMainAvatar():GetPosition()) then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module):GetLobbyCameraLocationByCameraID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module):GetCurrentCameraID()) then
          else
          end
        end
      end
      do return end
      _ARG_1_ = U1[108]
    end
  end,
  ["StopLobbyBGM"] = function(_ARG_0_)
    do
      GlobalData.StopLobbyBGM()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResumeLobbyBGM"] = function(_ARG_0_)
    do
      GlobalData.RestoreLobbyBGM()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleTips"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_1_.content then
        return
      end
      if type(_ARG_1_.content) ~= U1(24, 18, 243, 84, 225, 165) and type(_ARG_1_.content) ~= U1(5, 19, 236, 95, 234, 176) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpScene"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == HostedType.Pandora and not _ARG_1_.isMount then
      else
        U1.GlobalData.JumpUrl(_ARG_1_.content)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BackLobby"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == HostedType.Pandora and not _ARG_1_.isMount then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["pandoraShowEntrance"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 150, 108, 18, 151, 88, 100, 46, 53, 196, 250, 61, 80, 55, 103, 255, 25, 133, 120, 9, 139, 74, 116))).GameletApp.WOW_BBS then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["pandoraNotifyAppClose"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["pandoraOpenUrl"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpWeb"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_.isneedticket ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseWeb"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      Client.CloseWebView()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["pandoraShowRedpoint"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 189, 90, 81, 59, 117, 199, 244, 34, 84, 8, 106, 228, 49, 179, 120, 11, 146, 75, 120),
        U1(5, 18)
      }), _ARG_1_)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_center) then
      end
      if _ARG_1_.appId == U1(88, 87, 184, 13) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_co_creation_base) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QueryItemRet"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_73
      ::lbl_73::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowItemTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 161, 92, 110, 45, 82, 215, 254, 61, 97, 50, 114, 171), _ARG_1_)
      if not CDataTable.GetTableData(U1(34, 18, 228, 80), (tonumber(_ARG_1_.itemid))) then
        return
      end
      if CDataTable.GetTableData(U1(34, 18, 228, 80), (tonumber(_ARG_1_.itemid))).ItemType == ENUM_ITEM_TYPE.Voice_Pack then
      end
      if tonumber(_ARG_1_.period) == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseItemTip"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 177, 88, 110, 41, 126, 234, 239, 53, 88, 15, 107, 251))
      UIManager.CloseUI(UIManager.UI_Config.itemtips_panel)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowItemGetPanel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == HostedType.Pandora then
      else
        U1.log(U1.bWriteLog and U2(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 161, 92, 110, 45, 82, 215, 254, 61, 114, 62, 118, 219, 39, 143, 120, 3))
        U1.log_tree(U1.table.concat({
          U2(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 161, 92, 110, 45, 82, 215, 254, 61, 114, 62, 118, 219, 39, 143, 120, 3, 194, 64, 112),
          U2(31, 7)
        }), _ARG_1_)
        if #U1.require((U2(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 148, 105, 6, 142, 87))).SplitCommonItemGetData(_ARG_1_.content) > 0 then
          if _ARG_1_.num and _ARG_1_.num ~= U2() then
            if not _ARG_1_.price or _ARG_1_.price == U2() then
            else
            end
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsResDownloaded"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_223
      if require((table.concat({
        U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 149, 98, 8, 156, 88, 110, 59, 127, 141, 235, 37, 83, 61, 103, 249, 104, 145, 104, 9, 132, 65, 99),
        U1(52, 11, 224, 83, 238, 165, 33, 67)
      }))).GetState(require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 149, 98, 8, 156, 88, 110, 59, 127, 141, 235, 37, 83, 61, 103, 249, 25, 130, 114, 1, 145, 80))).ENUM_DownloadType.ODPAK, {
        tonumber(U1(52, 11, 224, 83, 238, 165, 33, 67))
      }) == ENUM_DownloadState.Done then
      else
      end
      ::lbl_223::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIntimacyList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_91
      ;(225).relationName = require((U1(8, 10, 232, 88, 225, 182, 106, 82, 37, 102, 222, 228, 46, 11, 62, 123, 196, 35, 133, 100, 19))).GetIntimacyRelationName((225).relation or 0)
      ::lbl_91::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ARG_1_ or {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemNum"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 181, 81, 117, 19, 111, 198, 246, 30, 64, 54, 34, 239, 39, 149, 124, 79, 223, 4), _ARG_1_)
      if _ARG_1_.onlyForeverItems then
        goto lbl_66
        ::lbl_66::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      goto lbl_140
      ::lbl_140::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ScreenShot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      EventSystem:postEvent(EVENTTYPE_LOBBY, EVENTID_CLICK_ANIMATION_HIDE)
      _ARG_0_.sScreenShotPath = import((U1(56, 5, 243, 88, 234, 172, 55, 89, 37, 127, 254, 234, 43, 64, 57))).MakePicture(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SavePictureHandler"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if IsEditor then
        _ARG_0_.sScreenShotPath = require((U1(8, 9, 236, 80, 224, 172, 106, 66, 62, 121, 218, 229, 39, 122, 62, 102, 242, 58))).StrReplace(_ARG_0_.sScreenShotPath, U1(69, 12, 241, 90), (U1(69, 22, 239, 90)))
      end
      if true then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDeviceLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowPreview"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == U2.HostedType.Pandora and not _ARG_1_.isMount and _ARG_1_.actid and _ARG_1_.actid ~= U1() then
        require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 146, 100, 28, 150, 65, 124))).NPreviewActId = _ARG_1_.actid
      end
      if string.find(_ARG_1_.content, (U1(71))) == nil then
      else
        goto lbl_401
        ::lbl_401::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QueryWarZone"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lbs_select_region):GetMyContinentConfig() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetQRcodeState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QueryPet"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_37
      ::lbl_37::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCoin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      U2 = true
      U3[#U3 + 1] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTicketChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log_tree(table.concat({
        U1(27, 7, 239, 89, 224, 176, 37, 110, 41, 100, 222, 230, 47, 75, 20, 98, 233, 57, 133, 98, 28, 157, 88, 47, 21, 117, 230, 237, 53, 91, 47, 67, 232, 50, 136, 107, 6, 150, 93, 68),
        U1(27, 2, 224, 73, 234, 226, 37, 69, 62, 121, 218, 223, 33, 71, 113, 50)
      }), _ARG_4_)
      if _ARG_4_ and _ARG_4_.recharged_num and _ARG_4_.recharged_num > 0 then
        goto lbl_115
        ::lbl_115::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      U3()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurrency"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_34
      if nil and U2.tonumber(nil) and U2.tonumber(nil) ~= 0 then
      else
        ::lbl_34::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMoneyTable"] = function(_ARG_0_)
    do
      do return {
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.gold] = DataMgr.gold or 0,
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.diamond] = DataMgr.diamond or 0,
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.ticket] = DataMgr.ticket or 0,
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.fp_token] = DataMgr.fp_token or 0,
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.gold_chip] = DataMgr.gold_chip or 0,
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.eternal_diamond] = DataMgr.eternal_diamond or 0,
        [require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).moneyType.battle_coin] = DataMgr.battle_coin or 0
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowExchange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_.appType = _ARG_2_
      UIManager.ShowUI(UIManager.UI_Config.pandora_Exchange, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseExchange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["pandoraGoPandora"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_26
      if nil == U1(10, 22, 241, 109, 238, 165, 33) then
      else
        ;({
          [nil] = nil,
          ["jumpParams"] = {}
        }).jumpParams[nil] = nil, ({
          [nil] = nil,
          ["jumpParams"] = {}
        }).jumpParams
      end
      ::lbl_26::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMargin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      return
    end
  end,
  ["UpdateRedPoint"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_.actid then
        return
      end
      if _ARG_2_ == HostedType.Pandora then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["openRewardResp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 189, 90, 81, 59, 117, 199, 244, 34, 84, 8, 106, 228, 49, 179, 120, 11, 146, 75, 120),
        U1(5, 18)
      }), _ARG_1_)
      if _ARG_2_ == U1(4, 22, 228, 83, 221, 167, 51, 80, 56, 111, 225, 238, 51, 85) and _ARG_1_.appId == U1(88, 87, 184, 13) then
        if _ARG_1_.ret == U1(91) then
          return
        else
          log(bWriteLog and table.concat({
            U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 157, 68, 100, 52, 73, 198, 236, 49, 71, 63, 80, 238, 53, 145, 61, 44, 144, 65, 112),
            U1(31, 15, 238, 83, 175, 171, 55, 17, 47, 121, 193, 228, 50)
          }))
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EagleReplay"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 183, 85, 102, 54, 126, 241, 254, 32, 89, 58, 123, 171, 34, 128, 105, 14), _ARG_1_)
      log_format(bWriteLog and table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 183, 85, 102, 54, 126, 241, 254, 32, 89, 58, 123, 171, 39, 145, 109, 59, 155, 84, 116),
        U1(81, 70, 164, 78)
      }), _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWowUnReadMessageRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 189, 90, 86, 53, 108, 246, 245, 2, 80, 58, 102, 198, 35, 146, 110, 14, 133, 65, 67),
        U1(24, 22)
      }), _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QueryReadyStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_79
      if require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).ActIsReady(88) and require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).ActPakIsReady(88) then
      elseif not require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).ActIsReady(88) and require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 161, 108, 17, 150, 91, 115, 59, 53, 211, 250, 62, 81, 52, 112, 234, 25, 141, 114, 8, 139, 71))).ActPakIsReady(88) then
      else
      end
      ::lbl_79::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_101
      ::lbl_101::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["panameraGetLabelsData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QueryShowTeam"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyShowTeam"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_.content then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MagicTreeStat"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MagicTreePercent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDesktopToolType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if U1.require((U1.table.concat({
        _ENV(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 157, 98, 29, 144, 77, 47, 54, 116, 196, 242, 51, 106, 58, 97, 255, 47, 151, 116, 27, 155, 123, 100),
        _ENV(31, 15, 237)
      }))).GetActivityDesktopToolType() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MagicTreeWaterInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ActivityAllDone"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 179, 87, 117, 51, 109, 202, 239, 41, 116, 55, 110, 207, 41, 143, 120, 79, 131, 84, 97),
        U1(63, 31, 241, 88, 181)
      }) .. tostring(_ARG_2_))
      log_tree(bWriteLog and table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 179, 87, 117, 51, 109, 202, 239, 41, 116, 55, 110, 207, 41, 143, 120, 79, 134, 69, 101),
        U1(10)
      }), _ARG_1_)
      if not _ARG_1_ or not _ARG_1_.actid then
        log(bWriteLog and table.concat({
          U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 179, 87, 117, 51, 109, 202, 239, 41, 116, 55, 110, 207, 41, 143, 120, 79, 207, 4, 92),
          U1(2, 21, 242, 84, 225, 165, 100, 80, 41, 127, 218, 239)
        }))
        return
      end
      if _ARG_2_ == U2.HostedType.Pandora then
      else
      end
      if not require((table.concat({
        U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 150, 108, 18, 151, 88, 100, 46, 53, 239, 244, 55, 92, 56, 69, 234, 43, 132, 113, 10, 150, 118, 116),
        U1(15, 54, 238, 84, 225, 182)
      }))):GetActIdByAppId(_ARG_1_.appId) or require((table.concat({
        U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 150, 108, 18, 151, 88, 100, 46, 53, 239, 244, 55, 92, 56, 69, 234, 43, 132, 113, 10, 150, 118, 116),
        U1(15, 54, 238, 84, 225, 182)
      }))):GetActIdByAppId(_ARG_1_.appId) == 0 then
        return
      end
      if _ARG_2_ == U2.HostedType.Pandora then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShareToClub"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_.imagePath then
        if U1.string.find(_ARG_1_.imagePath, (_ENV(9, 20, 230, 92, 226, 167, 27, 66, 41, 121, 214, 238, 46, 86, 35, 125, 239))) then
        end
      else
        return
      end
      if U1.Client.GetDevicePlatformName() == U1.require((U1.table.concat({
        _ENV(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 35, 74, 37, 116, 242, 49, 223, 78, 19, 155, 81, 111, 46, 86, 194, 248, 34, 90, 40, 44, 207, 35, 151, 116, 12, 135, 116, 125),
        _ENV(10, 18, 231, 82, 253, 175, 10, 80, 39, 110, 254, 234, 35, 87, 36, 97)
      }))).IOS then
      elseif U1.Client.GetDevicePlatformName() == U1.require((U1.table.concat({
        _ENV(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 35, 74, 37, 116, 242, 49, 223, 78, 19, 155, 81, 111, 46, 86, 194, 248, 34, 90, 40, 44, 207, 35, 151, 116, 12, 135, 116, 125),
        _ENV(10, 18, 231, 82, 253, 175, 10, 80, 39, 110, 254, 234, 35, 87, 36, 97)
      }))).Android then
      elseif U1.Client.GetDevicePlatformName() == U1.require((U1.table.concat({
        _ENV(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 35, 74, 37, 116, 242, 49, 223, 78, 19, 155, 81, 111, 46, 86, 194, 248, 34, 90, 40, 44, 207, 35, 151, 116, 12, 135, 116, 125),
        _ENV(10, 18, 231, 82, 253, 175, 10, 80, 39, 110, 254, 234, 35, 87, 36, 97)
      }))).Windows then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWoWMapStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(bWriteLog and table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 181, 81, 117, 13, 116, 244, 214, 49, 69, 8, 118, 234, 50, 148, 110, 79, 134, 69, 101),
        U1(10)
      }), _ARG_1_)
      if tonumber(_ARG_1_.templateId) and tonumber(_ARG_1_.templateId) > 0 then
        return
      end
      if not tonumber(_ARG_1_.content) or tonumber(_ARG_1_.content) <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ModifyPufferDownloadLimit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(bWriteLog and table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 191, 91, 101, 51, 125, 218, 203, 37, 83, 61, 103, 249, 2, 142, 106, 1, 142, 75, 112),
        U1(15, 42, 232, 80, 230, 182, 100, 85, 43, 127, 210)
      }), _ARG_1_)
      if 0 < (tonumber(_ARG_1_ and _ARG_1_.speed) or 0) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DownloadWoWMap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 182, 91, 118, 52, 119, 204, 250, 52, 98, 52, 85, 198, 39, 145, 61, 11, 131, 80, 112), _ARG_1_)
      if tonumber(_ARG_1_.templateId) and tonumber(_ARG_1_.templateId) > 0 then
        return
      end
      if not tonumber(_ARG_1_.content) or 0 >= tonumber(_ARG_1_.content) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PauseWoWMapDownload"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(bWriteLog and table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 162, 85, 116, 41, 126, 244, 244, 7, 120, 58, 114, 207, 41, 150, 115, 3, 141, 69, 117),
        U1(75, 2, 224, 73, 238)
      }), _ARG_1_)
      if not tonumber(_ARG_1_.content) or tonumber(_ARG_1_.content) <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayWoWMap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 162, 88, 96, 35, 76, 204, 204, 29, 84, 43, 34, 239, 39, 149, 124), _ARG_1_)
      if not tonumber(_ARG_1_.content) or tonumber(_ARG_1_.content) <= 0 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomInfoByModID((tonumber(_ARG_1_.content))) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_share) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ReportWoWMapStatusBeforeMatch"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(table.concat({
        U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 173, 102, 100, 42, 116, 209, 239, 7, 90, 12, 79, 234, 54, 178, 105, 14, 150, 81, 98),
        U1(41, 3, 231, 82, 253, 167, 9, 80, 62, 104, 219, 165, 96, 72, 36, 118, 210, 50, 204, 40, 12)
      }), _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ListenPlayHallJoinResponse"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_._playHallJoinResponseEvent then
        _ARG_0_:RemoveCommonEvent(_ARG_0_._playHallJoinResponseEvent)
        _ARG_0_._playHallJoinResponseEvent = nil
      end
      _ARG_0_._playHallJoinResponseEvent = _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PLAYHALL_JOIN_RESPONSE, function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
        do
          if _playHallJoinResponseEvent then
            _ENV:RemoveCommonEvent(_playHallJoinResponseEvent)
            _playHallJoinResponseEvent = nil
          end
          if _ARG_3_ then
          end
          do return end
          _ARG_3_ = _ENV[24]
        end
      end, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NotifyTo"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_1_ and _ARG_1_.send_to) or _ARG_1_.send_to == _ENV() then
        U1.log(U1.bWriteLog and U1.table.concat({
          _ENV(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 188, 91, 117, 51, 125, 218, 207, 63, 27, 123, 102, 234, 50, 128, 61, 6, 145, 4, 127),
          _ENV(2, 10, 161, 82, 253, 226, 32, 80, 62, 106, 157, 255, 47, 5, 34, 97, 187, 56, 152, 97)
        }))
        return
      end
      if U1.string.lower(_ARG_1_.send_to or _ENV()) == U1.string.lower(U2.HostedType.Pandora) then
      elseif U1.string.lower(_ARG_1_.send_to or _ENV()) == U1.string.lower(U2.HostedType.Gamelet) then
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_gamelet_interface):GetAppType(_ARG_1_.toAppId or _ENV()) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_gamelet_interface):GetAppType(_ARG_1_.toAppId or _ENV()) ~= _ENV() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QueryCorpsConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_30
      ::lbl_30::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_1_.actid then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["grobotGoAvatarMotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(48, 53, 216, 96, 199, 173, 55, 69, 47, 111, 240, 228, 45, 72, 36, 124, 203, 36, 158, 121, 16, 145, 91, 109, 96, 124, 209, 244, 50, 90, 47, 69, 228, 7, 151, 124, 27, 131, 86, 92),
        U1(4, 18, 232, 82, 225, 236)
      }))
      log_tree(U1(15, 7, 245, 92), _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["grobotGetOpenArgsRtn"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DownloadMap"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 182, 91, 118, 52, 119, 204, 250, 52, 120, 58, 114))
      log_tree(U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 182, 91, 118, 52, 119, 204, 250, 52, 120, 58, 114, 171, 34, 128, 105, 14), _ARG_1_)
      if not _ARG_1_.content or _ARG_1_.content == U1() then
        return
      end
      if require((table.concat({
        U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 149, 98, 8, 156, 88, 110, 59, 127, 141, 235, 37, 83, 61, 103, 249, 104, 145, 104, 9, 132, 65, 99),
        U1(52, 11, 224, 83, 238, 165, 33, 67)
      }))).GetState(require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 149, 98, 8, 156, 88, 110, 59, 127, 141, 235, 37, 83, 61, 103, 249, 25, 130, 114, 1, 145, 80))).ENUM_DownloadType.MAP, {
        _ARG_1_.content
      }) == require((U1(8, 10, 232, 88, 225, 182, 106, 66, 38, 126, 210, 165, 44, 74, 44, 123, 248, 120, 149, 98, 8, 156, 88, 110, 59, 127, 141, 235, 37, 83, 61, 103, 249, 25, 130, 114, 1, 145, 80))).ENUM_DownloadState.Done then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[128]
    end
  end,
  ["GetMapStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(35, 9, 242, 73, 234, 166, 7, 94, 39, 102, 220, 229, 16, 87, 36, 102, 244, 53, 158, 97, 69, 181, 81, 117, 23, 122, 211, 200, 36, 84, 47, 119, 248))
      log_tree(U1(15, 7, 245, 92), _ARG_1_)
      if not _ARG_1_.content or _ARG_1_.content == U1() then
        return
      end
      return
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_TICKET_CHANGE, _ARG_0_.OnTicketChange, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
