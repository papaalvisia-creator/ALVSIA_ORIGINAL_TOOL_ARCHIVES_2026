do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(159, 35, 184, 118, 84)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 124, 21, 207, 83, 181, 29, 76, 84, 183, 221, 107, 0, 206, 85, 166, 2, 101))), nil, {
  ["DefineAndResetData"] = function(_ARG_0_)
    do
      __super.DefineAndResetData(_ARG_0_)
      _ARG_0_.ReqList = {2, 1}
      _ARG_0_.NewReqList = {2, 1}
      _ARG_0_.AllReqTypeList = {}
      _ARG_0_.currentAuthorIndex = 1
      _ARG_0_.AfterAuthorShowList = {}
      _ARG_0_.BannerShowlist = {}
      _ARG_0_.HotThemeListReqCD = 70
      _ARG_0_.HotThemeUniqueModNum = 3
      _ARG_0_.HotThemeCarouselCD = 120
      _ARG_0_.hot_theme = nil
      _ARG_0_.hot_exposure_theme = {}
      _ARG_0_.ExposureModList = {}
      _ARG_0_.themeScrollOffsetCache = nil
      _ARG_0_.hasReqProfileUidList = nil
      _ARG_0_.themeDataTimeStamp = nil
      _ARG_0_.AutoNextReqBundleID = nil
      _ARG_0_.tableHotTheme = {}
      _ARG_0_.HotAuthorCarouselCD = 300
      _ARG_0_.HotThemeEntryStamp = nil
      _ARG_0_.HotThemeDepartureStamp = nil
      _ARG_0_.report = {}
      _ARG_0_.version = 0
      _ARG_0_.trans_info = {}
      _ARG_0_.white_list = {}
      _ARG_0_.HotThemeReqState = {}
      _ARG_0_.DisplayedThemeModIDList = {}
      _ARG_0_.mixed_banner_list = {}
      _ARG_0_.bannerData = {}
      _ARG_0_.BannerThemeData = {}
      _ARG_0_.newThemeData = {}
      _ARG_0_.activityData = {}
      _ARG_0_.showList = nil
      _ARG_0_.themeIndex = 0
      _ARG_0_.historyPlayList = {}
      _ARG_0_.hot_history_abtest = nil
      _ARG_0_.RecThemeOneIndex = 0
      _ARG_0_.RecThemeTwoIndex = 0
      _ARG_0_.RecThemeThreeIndex = 0
      _ARG_0_.RecThemeFourIndex = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogOut"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 122, 185, 57, 127, 29, 231, 79, 162))
      _ARG_0_:ClearHotThemeCacheData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearHotThemeCacheData"] = function(_ARG_0_)
    do
      _ARG_0_.themeScrollOffsetCache = nil
      _ARG_0_.hasReqProfileUidList = nil
      _ARG_0_.hot_theme = nil
      _ARG_0_.hot_exposure_theme = {}
      _ARG_0_.ExposureModList = {}
      _ARG_0_.themeDataTimeStamp = nil
      _ARG_0_.tableHotTheme = {}
      _ARG_0_.HotThemeEntryStamp = nil
      _ARG_0_.HotThemeDepartureStamp = nil
      _ARG_0_.report = {}
      _ARG_0_.version = 0
      _ARG_0_.trans_info = {}
      _ARG_0_.HotThemeReqState = {}
      _ARG_0_:ClearDisplayedThemeModIDListCache()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 122, 185, 37, 127, 9, 220, 105, 161, 43, 77, 80, 188, 197, 125, 2, 220, 118, 179, 4, 116, 31),
        U1(143, 111, 169, 119, 66, 22, 20, 43, 204, 79, 252)
      }) .. tostring(_ARG_1_) .. U1(220, 33, 188, 125, 83, 22, 20, 43, 204, 79, 252) .. tostring(_ARG_2_))
      if _ARG_2_ == GameStatus.Lobby then
        _ARG_0_:ClearBannerCache()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearBannerCache"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 187, 16, 113, 8, 234, 91, 184, 44, 92, 65, 151, 227, 127, 7, 220))
      _ARG_0_.mixed_banner_list = {}
      _ARG_0_.bannerData = {}
      _ARG_0_.BannerThemeData = {}
      _ARG_0_.activityData = {}
      _ARG_0_.showList = nil
      _ARG_0_.newThemeData = {}
      if not UIManager.GetUI(UIManager.UI_Config.NewUGCMainPanel) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetSelectedTabId() == require((U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 115, 21, 198, 92, 191, 37, 102, 70, 179, 225))).Config_UGC_TabID.HotTheme then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_ugc_gallery_hot_theme_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 90, 185, 42, 101, 29, 203, 101, 177, 35, 85, 95, 177, 240, 101, 48, 209, 74, 179, 58, 116, 2),
        U1(153, 34, 188, 90, 85, 54, 16, 106, 221, 88, 180, 61, 91, 30)
      }), tostring(_ARG_1_))
      goto lbl_107
      if tostring(_ARG_1_).data_type ~= U1(177, 0, 157, 64, 120, 22, 37, 6, 253, 105, 146, 13, 109, 106, 151, 209, 67, 41, 236, 103) then
      end
      ::lbl_107::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_1_ ~= 0 or {} == nil then
        _ARG_0_.TabInfo.theme = nil
        return
      end
      _ARG_0_.TabInfo.Showtheme = _ARG_0_:ProcessHotThemeData({}), _ARG_0_.TabInfo
      _ARG_0_.TabInfo.theme = {}, _ARG_0_:ProcessHotThemeData({}), _ARG_0_.TabInfo
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_ugc_mixed_banner_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 90, 185, 42, 101, 29, 203, 101, 187, 43, 65, 86, 176, 221, 126, 14, 215, 75, 162, 23, 95, 24),
        U1(143, 63, 249, 96, 85, 55, 15, 56, 133)
      }), tostring(_ARG_1_))
      _ARG_0_:UGCBannerDataIntegration(_ARG_2_)
      if _ARG_1_ ~= 0 or _ARG_2_ == nil then
        _ARG_0_.TabInfo.banner = nil
        return
      end
      _ARG_0_.TabInfo.banner = _ARG_2_
      _ARG_0_.BannerShowlist = _ARG_0_.showList
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_history_play_list"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 90, 185, 42, 120, 19, 219, 78, 185, 48, 64, 108, 164, 238, 125, 22, 230, 73, 174, 22, 116, 74),
        U1(148, 38, 170, 113, 72, 55, 25, 26, 212, 75, 191, 30, 64, 80, 176, 178)
      }), _ARG_1_)
      if not _ARG_1_ or not next(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 90, 185, 42, 120, 19, 219, 78, 185, 48, 64, 108, 164, 238, 125, 22, 230, 73, 174, 22, 116, 74),
          U1(148, 38, 170, 113, 72, 55, 25, 26, 212, 75, 191, 30, 64, 80, 176, 178, 101, 12, 137, 91, 190, 25)
        }))
      end
      _ARG_0_.historyPlayList = _ARG_1_
      _ARG_0_.TabInfo.history = _ARG_0_:GetHotHistoryModID(), _ARG_0_.TabInfo
      if _ARG_0_:CheckHotShowHistory() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModInfo"] = function(_ARG_0_)
    do
      _ARG_0_.AllReqTypeList = {}
      if _ARG_0_:CheckHotShowHistory() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TabAllModInfoRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 97, 182, 23, 81, 22, 196, 119, 185, 38, 112, 93, 178, 237, 78, 28, 201) .. tostring(_ARG_1_))
      if _ARG_1_ == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.MixedBanner then
        _ARG_0_.AllReqTypeList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.MixedBanner] = true
      elseif _ARG_1_ == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.HotTheme then
        _ARG_0_.AllReqTypeList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.HotTheme] = true
      elseif _ARG_1_ == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.History then
        _ARG_0_.AllReqTypeList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.History] = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetStringToArry"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) == U1(143, 59, 171, 108, 73, 34) then
        return require((U1(159, 32, 180, 104, 72, 43, 78, 57, 204, 88, 175, 60, 78, 124, 177, 230, 101, 19))).SplitToNum(_ARG_1_, (U1(128)))
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotThemeModIDList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.TabInfo or not _ARG_0_.TabInfo.theme then
        log((table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 88, 21, 220, 110, 190, 39, 84, 86, 153, 237, 120, 38, 253, 105, 174, 22, 116, 74),
          U1(136, 39, 188, 104, 66, 101, 9, 57, 152, 68, 175, 62)
        })))
        return
      end
      if _ARG_0_.TabInfo.theme then
        goto lbl_246
        if U1(136, 39, 188, 104, 66, 101, 9, 57, 152, 68, 175, 62).data_type ~= U1(177, 0, 157, 64, 120, 22, 37, 6, 253, 105, 146, 13, 109, 106, 151, 209, 67, 41, 236, 103) and U1(136, 39, 188, 104, 66, 101, 9, 57, 152, 68, 175, 62).mod_list then
          goto lbl_121
          ::lbl_121::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if U1(136, 39, 188, 104, 66, 101, 9, 57, 152, 68, 175, 62).data_type == U1(189, 26, 141, 77, 104, 23) and U1(136, 39, 188, 104, 66, 101, 9, 57, 152, 68, 175, 62).trans_data and U1(136, 39, 188, 104, 66, 101, 9, 57, 152, 68, 175, 62).trans_data.author_list then
          goto lbl_172
          if (77).mod_list then
            goto lbl_162
            ::lbl_162::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          ::lbl_172::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_246::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return _ARG_1_ or {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotBannerModIDList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.TabInfo or not _ARG_0_.TabInfo.banner then
        log((table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 88, 21, 220, 120, 183, 44, 87, 86, 166, 207, 115, 11, 240, 97, 139, 12, 115, 30),
          U1(220, 45, 184, 107, 73, 32, 18, 106, 209, 89, 230, 60, 64, 79)
        })))
        return
      end
      if _ARG_0_.TabInfo.banner then
        if not _ARG_0_:CheckIsNewBanner() then
          _ARG_0_.BannerShowlist = _ARG_0_:SetSelectThemeBanner()
        end
        if _ARG_0_:GetNeedReqModIDs() then
          goto lbl_145
          ::lbl_145::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return _ARG_1_ or {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotHistoryModID"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetHistoryKeyInfoList() or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetHistoryKeyInfoList())) then
        return
      end
      goto lbl_118
      ::lbl_118::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not ({})[1] then
        return
      end
      if 3 > math.floor((require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec() - (({})[1].play_time or 0)) / 86400) and 180 < ({})[1].total_play_time then
        return ({})[1].mod_id
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckThemeIndex"] = function(_ARG_0_)
    do
      if not _ARG_0_.TabInfo or not _ARG_0_.TabInfo.Showtheme then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_hall):CheckIsOpen() then
      else
      end
      goto lbl_265
      if U1(144, 38, 170, 113, 26).mod_list and #U1(144, 38, 170, 113, 26).mod_list >= 1 then
        goto lbl_174
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByWithoutPubCache(U1(144, 38, 170, 113, 26)) then
        end
        ::lbl_174::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if require((table.concat({
          U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 120, 21, 220, 101, 162, 42, 92, 94, 177, 172, 127, 0, 215, 67, 174, 2, 95, 31),
          U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55)
        }))).ThemeRefreshModNum > 0 + 1 then
        end
      end
      ::lbl_265::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_342
      ::lbl_342::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.TabInfo.Showtheme = _ARG_0_.TabInfo.Showtheme, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC), {}, require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 120, 21, 220, 101, 162, 42, 92, 94, 177, 172, 127, 0, 215, 67, 174, 2, 95, 31),
        U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55)
      }))), require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 120, 21, 220, 101, 162, 42, 92, 94, 177, 172, 127, 0, 215, 67, 174, 2, 95, 31),
        U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55)
      }))).ThemeRefreshModNum, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_hall), _ARG_0_.TabInfo
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotTabInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_.TabInfo then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 88, 21, 220, 110, 183, 32, 112, 93, 178, 237, 60, 59, 216, 71, 142, 11, 102, 5),
          U1(220, 38, 170, 37, 73, 44, 12)
        }))
        return {}
      end
      if _ARG_0_.AllReqTypeList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.MixedBanner] and _ARG_0_.BannerShowlist and next(_ARG_0_.BannerShowlist) then
        if _ARG_0_:CheckIsNewBanner() then
        else
        end
      end
      if _ARG_0_.TabInfo.history and (not (not _ARG_0_.AllReqTypeList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC).C_ModListTypes.MixedBanner] and _ARG_0_.BannerShowlist) or not next(_ARG_0_.BannerShowlist)) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({
          _ARG_0_.TabInfo.history
        }, nil, nil, {bExportArray = true})[1].pub_mod_meta and _ARG_0_:CheckHotShowHistory() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({
          _ARG_0_.TabInfo.history
        }, nil, nil, {bExportArray = true})[1].pub_mod_meta.base.state_release == require((U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 115, 21, 198, 92, 191, 37, 102, 70, 179, 225))).E_PublishState.Published then
        end
      end
      if _ARG_0_.TabInfo.Showtheme then
        goto lbl_465
        ::lbl_465::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTrendingTabInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_.TabInfo or not _ARG_0_.TabInfo.theme then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 68, 8, 205, 84, 178, 43, 87, 84, 128, 227, 126, 38, 215, 67, 168, 69, 115, 15),
          U1(144, 41, 247, 81, 70, 39, 41, 36, 222, 69, 230, 61, 91, 3, 183, 247, 96, 25, 135, 97, 182, 23, 89, 20, 206, 85, 248, 54, 81, 86, 185, 231, 60, 6, 202, 5, 169, 12, 108)
        }))
        return {}
      end
      goto lbl_172
      if (96).base and ((96).base.id == require((U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 115, 21, 198, 92, 191, 37, 102, 70, 179, 225))).REGION_HOT_RECOMMEND_ID or (96).base.id == require((U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 115, 21, 198, 92, 191, 37, 102, 70, 179, 225))).REGION_SELF_TAG_HOT_ID) then
        goto lbl_170
        ::lbl_170::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_172::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAuthorThemeQuantity"] = function(_ARG_0_)
    do
      if not _ARG_0_.TabInfo then
        return
      end
      if _ARG_0_.TabInfo.Showtheme then
        goto lbl_36
        if (nil).data_type == U1(189, 26, 141, 77, 104, 23) and (nil).trans_data and (nil).trans_data.author_list then
          return #(nil).trans_data.author_list
        end
        ::lbl_36::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAllAuthorShow"] = function(_ARG_0_)
    do
      if not _ARG_0_.TabInfo or not _ARG_0_.TabInfo.Showtheme then
        return
      end
      goto lbl_35
      if (nil).data_type == U1(189, 26, 141, 77, 104, 23) and (nil).trans_data and (nil).trans_data.only_config then
        return (nil).trans_data.only_config
      end
      ::lbl_35::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotAuthorList"] = function(_ARG_0_)
    do
      if not _ARG_0_.TabInfo or not _ARG_0_.TabInfo.Showtheme then
        return
      end
      goto lbl_35
      if (nil).data_type == U1(189, 26, 141, 77, 104, 23) and (nil).trans_data and (nil).trans_data.author_list then
        return (nil).trans_data.author_list
      end
      ::lbl_35::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAuthorIndex"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == false and next(_ARG_0_.AfterAuthorShowList) then
        return _ARG_0_.AfterAuthorShowList
      end
      if next(_ARG_0_.AfterAuthorShowList) then
        goto lbl_30
        if (nil).author_uid == _ARG_0_.AfterAuthorShowList[#_ARG_0_.AfterAuthorShowList].author_uid then
        else
          ::lbl_30::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      while 3 > 0 and 0 < #_ARG_1_ do
        if nil + 1 > #_ARG_1_ then
        end
      end
      _ARG_0_.AfterAuthorShowList = {}
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAfterAuthorShowList"] = function(_ARG_0_)
    do
      if _ARG_0_.AfterAuthorShowList then
        return _ARG_0_.AfterAuthorShowList
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckSelfTabInfo"] = function(_ARG_0_)
    do
      if _ARG_0_.TabInfo.banner and _ARG_0_.TabInfo.theme and _ARG_0_:CheckThemeRefresh() then
        return true
      else
        log((table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 251, 95, 186, 36, 109, 82, 182, 203, 114, 9, 214, 5, 165, 4, 110, 4),
          U1(153, 61, 249, 100, 73, 33, 64, 62, 208, 79, 171, 55, 9, 74, 183, 178, 98, 16, 221, 21, 185, 28, 124)
        })))
        _ARG_0_.themeDataTimeStamp = require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec()
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckThemeRefresh"] = function(_ARG_0_)
    do
      do return require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec() <= _ARG_0_.themeDataTimeStamp + _ARG_0_.HotThemeListReqCD end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHotThemeGalleryParams"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 110, 190, 39, 84, 86, 147, 227, 112, 3, 220, 87, 190, 53, 97, 24),
        U1(157, 34, 170)
      }))
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 110, 190, 39, 84, 86, 147, 227, 112, 3, 220, 87, 190, 53, 97, 24),
          U1(157, 34, 170, 37, 64, 36, 12, 38, 221, 88, 191, 2, 72, 81, 165, 255, 79, 16, 199, 83, 190, 18, 48, 19, 219, 26, 184, 43, 85)
        }))
        return
      end
      if _ARG_1_.HotThemeListReqCD and tonumber(_ARG_1_.HotThemeListReqCD) then
        _ARG_0_.HotThemeListReqCD = tonumber(_ARG_1_.HotThemeListReqCD)
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 110, 190, 39, 84, 86, 147, 227, 112, 3, 220, 87, 190, 53, 97, 24),
          U1(157, 34, 170, 37, 84, 32, 12, 44, 150, 98, 169, 38, 125, 75, 161, 255, 105, 51, 192, 70, 163, 39, 117, 11, 235, 126, 236)
        }) .. tostring(_ARG_0_.HotThemeListReqCD))
      end
      if _ARG_1_.HotThemeUniqueModNum and tonumber(_ARG_1_.HotThemeUniqueModNum) then
        _ARG_0_.HotThemeUniqueModNum = tonumber(_ARG_1_.HotThemeUniqueModNum)
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 110, 190, 39, 84, 86, 147, 227, 112, 3, 220, 87, 190, 53, 97, 24),
          U1(157, 34, 170, 37, 84, 32, 12, 44, 150, 98, 169, 38, 125, 75, 161, 255, 105, 42, 199, 92, 166, 0, 117, 55, 199, 94, 152, 55, 84, 9)
        }) .. tostring(_ARG_0_.HotThemeUniqueModNum))
      end
      if _ARG_1_.HotThemeCarouselCD and tonumber(_ARG_1_.HotThemeCarouselCD) then
        _ARG_0_.HotThemeCarouselCD = tonumber(_ARG_1_.HotThemeCarouselCD) or 120
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 110, 190, 39, 84, 86, 147, 227, 112, 3, 220, 87, 190, 53, 97, 24),
          U1(157, 34, 170, 37, 84, 32, 12, 44, 150, 98, 169, 38, 125, 75, 161, 255, 105, 60, 200, 71, 184, 0, 99, 31, 196, 121, 146, 120)
        }) .. tostring(_ARG_0_.HotThemeCarouselCD))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RollKOLTheme"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 184, 25, 124, 49, 231, 118, 130, 42, 92, 94, 177))
      _ARG_0_.hot_theme = _ARG_0_:ProcessHotThemeData(_ARG_0_.cached_raw_hot_theme, true)
      _ARG_0_.TabInfo.Showtheme = _ARG_0_.hot_theme
      goto lbl_135
      if U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).style == require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 120, 21, 220, 101, 162, 42, 92, 94, 177, 172, 127, 0, 215, 67, 174, 2, 95, 31),
        U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55)
      }))).ItemDataType.ModList and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).data_type and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).data_type == U1(183, 0, 149) then
      else
        ::lbl_135::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Clear"] = function(_ARG_0_)
    do
      __super.Clear(_ARG_0_)
      _ARG_0_.AllReqTypeList = {}
      _ARG_0_.AfterAuthorShowList = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearAllReqTypeList"] = function(_ARG_0_)
    do
      _ARG_0_.AllReqTypeList = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UGCHotThemeDataIntegration"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 144, 54, 88, 21, 220, 110, 190, 39, 84, 86, 144, 227, 104, 14, 240, 75, 179, 0, 103, 24),
          U1(157, 59, 176, 106, 73, 101, 8, 37, 204, 117, 178, 58, 76, 78, 161, 178, 101, 12, 137, 91, 190, 25)
        }))
        return
      end
      _ARG_0_.tableHotTheme = {}
      _ARG_0_.themeDataTimeStamp = require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec()
      _ARG_0_.HotThemeReqState = {}
      _ARG_0_.cached_raw_hot_theme = _ARG_1_
      _ARG_0_.hot_theme = _ARG_0_:ProcessHotThemeData(_ARG_1_)
      goto lbl_390
      if (96).data_type == U1(168, 29, 152, 67, 97, 12, 35, 21, 232, 101, 137, 30, 118, 100, 150, 221, 91, 43, 225) or (96).data_type == U1(175, 31, 156, 70, 120, 17, 40, 15, 245, 111) then
        _ARG_0_.version = (96).version or (96).base and (96).base.version or 0
      end
      if (96).data_type == U1(172, 29, 150, 72, 104, 17, 41, 5, 246) then
        _ARG_0_.trans_info = (96).trans_info
      end
      if (96).base and ((96).base.id == require((U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 115, 21, 198, 92, 191, 37, 102, 70, 179, 225))).REGION_SELF_TAG_HOT_ID or (96).base.id == require((U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 115, 21, 198, 92, 191, 37, 102, 70, 179, 225))).REGION_HOT_RECOMMEND_ID) and (96).base.white_list then
        _ARG_0_.white_list = (96).base.white_list
      end
      ::lbl_390::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.AutoNextReqBundleID and 0 < _ARG_0_.AutoNextReqBundleID then
        _ARG_0_.AutoNextReqBundleID = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqOneThemeNextPageModInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_0_.hot_theme) or not _ARG_0_.hot_theme[_ARG_1_] then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 178, 4, 95, 20, 205, 110, 190, 39, 84, 86, 154, 231, 100, 27, 233, 68, 160, 0, 77, 5),
          U1(152, 6, 183, 99, 72, 101, 8, 37, 204, 117, 178, 58, 76, 78, 161, 178, 101, 12, 137, 91, 190, 25)
        }))
        return
      end
      goto lbl_111
      ::lbl_111::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetModBatchReqParam"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return (_ENV(136, 39, 188, 104, 66, 41, 9, 57, 204))
      end
      do return _ENV(136, 39, 188, 104, 66, 104) .. _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetThemeModPlayer"] = function(_ARG_0_)
    do
      if not _ARG_0_.hot_theme then
        return
      end
      goto lbl_25
      if (nil).mod_list and #(nil).mod_list >= 1 then
      end
      ::lbl_25::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProcessHotThemeData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 101, 165, 26, 115, 31, 219, 73, 158, 45, 77, 103, 188, 231, 113, 10, 253, 68, 179, 4, 32, 2),
          U1(147, 59, 134, 113, 79, 32, 13, 47, 152, 67, 181, 114, 71, 74, 168)
        }))
        return
      end
      _ARG_1_ = _ARG_0_:RandomSelectKOL(_ARG_1_, _ARG_2_)
      table.sort(_ARG_1_, function(_ARG_0_, _ARG_1_)
        do
          do return (_ARG_0_.base and _ARG_0_.base.rank_value or 0) < (_ARG_1_.base and _ARG_1_.base.rank_value or 0) end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      goto lbl_97
      if U1(147, 59, 134, 113, 79, 32, 13, 47, 152, 67, 181, 114, 71, 74, 168).base and not U1(147, 59, 134, 113, 79, 32, 13, 47, 152, 67, 181, 114, 71, 74, 168).base.pos then
        U1(147, 59, 134, 113, 79, 32, 13, 47, 152, 67, 181, 114, 71, 74, 168).base.pos = _ARG_2_ + 0.5
      end
      ::lbl_97::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_newbie_guide):IsOngoingStrongGuide() then
        goto lbl_201
        if U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type and U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type == U1(178, 10, 142, 71, 110, 0) then
          U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).base.pos = -9999
        end
        ::lbl_201::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
        goto lbl_228
        if U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type and U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type == U1(178, 10, 142, 71, 110, 0) then
        else
          ::lbl_228::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      goto lbl_292
      if U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type and (U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type == U1(186, 29, 144, 64, 105, 1, 63, 8, 249, 121, 131, 13, 123, 102, 135, 205, 90, 77) or U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).data_type == U1(186, 29, 144, 64, 105, 1, 63, 2, 247, 126, 153, 0, 108, 96, 139, 223, 65, 58, 231, 113)) and _ARG_0_:CheckFriendMod(U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).mod_list) then
        U1(157, 59, 184, 72, 64, 55, 78, 36, 221, 93, 164, 59, 76, 100, 177, 251, 104, 26, 137).base.pos = -999
      end
      ::lbl_292::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.HotThemeUniqueModNum and _ARG_0_.HotThemeUniqueModNum > 0 then
        goto lbl_400
        goto lbl_344
        if #{} < _ARG_0_.HotThemeUniqueModNum then
          if ({
            [tonumber(63)] = 1
          })[tonumber(63)] == nil then
          end
        else
        end
        ::lbl_344::
        _ARG_0_ = _ARG_0_
        _ARG_0_.mod_list, _ARG_0_ = {}, _ARG_0_
        if _ARG_0_.base and #{} >= (_ARG_0_.base and _ARG_0_.base.display_min or 1) or _ARG_0_.data_type and _ARG_0_.data_type == U1(174, 14, 151, 78, 120, 10, 48, 15) or _ARG_0_.data_type and _ARG_0_.data_type == U1(189, 26, 141, 77, 104, 23) then
        end
        ::lbl_400::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = base
    end
  end,
  ["RandomSelectKOL"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      print(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 182, 27, 116, 21, 197, 105, 179, 46, 92, 80, 160, 201, 83, 35))
      goto lbl_67
      if (68).data_type == U1(183, 0, 149) then
      else
      end
      ::lbl_67::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not _ARG_2_ then
        _ARG_0_.LastrandomIndex = nil
        goto lbl_151
        if ({}).base and ({}).base.id == _ARG_0_:GetLastSelectKOLThemeId() then
          _ARG_0_.LastrandomIndex = table.insert({}, 68), {}, print(bWriteLog and table.concat({
            U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 182, 27, 116, 21, 197, 105, 179, 46, 92, 80, 160, 201, 83, 35, 153, 102, 166, 6, 104, 15),
            U1(220, 39, 176, 113, 7)
          }) .. tostring((table.insert({}, 68))))
        else
          ::lbl_151::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if 1 < #{} then
        if _ARG_0_.LastrandomIndex ~= nil then
          if _ARG_2_ then
            if math.random(1, #{} - 1) >= _ARG_0_.LastrandomIndex then
            end
          else
          end
        else
        end
        _ARG_0_.LastrandomIndex = math.random(1, #{})
      elseif #{} == 1 then
        _ARG_0_.LastrandomIndex = 1
      end
      if ({})[math.random(1, #{})] then
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckFriendMod"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 238, 72, 191, 39, 87, 87, 153, 237, 120, 79, 212, 74, 163, 58, 108, 3),
          U1(143, 59, 249, 108, 84, 101, 14, 35, 212)
        }))
        return
      end
      goto lbl_84
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetFriendPlayingModList()[U1(143, 59, 249, 108, 84, 101, 14, 35, 212)] then
        return true
      end
      ::lbl_84::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNewOneThemeShowModData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 94, 31, 223, 117, 184, 39, 109, 91, 177, 239, 121, 60, 209, 74, 176, 40, 111, 14),
          U1(184, 46, 173, 100, 7, 13, 15, 62, 236, 66, 163, 63, 76, 103, 165, 230, 109, 95, 192, 70, 247, 27, 121, 22)
        }))
        return
      end
      log_tree(table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 94, 31, 223, 117, 184, 39, 109, 91, 177, 239, 121, 60, 209, 74, 176, 40, 111, 14),
        U1(184, 46, 173, 100, 7, 13, 15, 62, 236, 66, 163, 63, 76, 103, 165, 230, 109)
      }), _ARG_1_)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_hall):CheckIsOpen() then
      else
      end
      goto lbl_246
      if U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.id == _ARG_1_.base.id then
      else
        ::lbl_246::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.hasReqProfileUidList = _ARG_0_.hasReqProfileUidList or {}
      if not _ARG_2_ then
      elseif _ARG_0_.tableHotTheme[_ARG_1_.base.id] and next(_ARG_0_.tableHotTheme[_ARG_1_.base.id]) then
        goto lbl_464
        if U1(184, 46, 173, 100, 7, 49, 8, 47, 213, 79, 130, 51, 93, 66, 228) == _ARG_0_.tableHotTheme[_ARG_1_.base.id][#_ARG_0_.tableHotTheme[_ARG_1_.base.id]] then
          if U1(184, 46, 173, 100, 7, 49, 8, 47, 213, 79, 130, 51, 93, 66, 228) == #(U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).mod_list or {}) then
          else
            ::lbl_464::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
      end
      if not true then
        if require((table.concat({
          U1(159, 35, 176, 96, 73, 49, 78, 57, 212, 95, 167, 124, 69, 76, 163, 251, 111, 81, 220, 82, 180, 91, 120, 21, 220, 101, 162, 42, 92, 94, 177, 172, 127, 0, 215, 67, 174, 2, 95, 31),
          U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55)
        }))).ThemeRefreshModNum > #{} then
        end
      else
      end
      _ARG_0_.tableHotTheme[_ARG_1_.base.id] = {}
      goto lbl_564
      ::lbl_564::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.ExposureModList[_ARG_1_.base.id] = {}, U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.show_author == 1, {}, U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.id == U2, false, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile), true, U1(184, 46, 173, 100, 7, 49, 8, 47, 213, 79, 130, 51, 93, 66, 228) + 1, function(_ARG_0_)
        do
          if _ENV:GetModByAllCache(U1.tonumber(_ARG_0_)) and _ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta and not _ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.perf_off_banner then
            goto lbl_122
            if U1.tonumber(_ARG_0_).modInfo.mod_id == _ARG_0_ then
              return
            end
            ::lbl_122::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            if not U4.DisplayedThemeModIDList[_ARG_0_] then
              U4.DisplayedThemeModIDList[_ARG_0_] = {}
            end
            U4.DisplayedThemeModIDList[_ARG_0_] = true
            if U8 and _ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.base and _ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.base.uid and not U9:GetLocalProfile(_ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.base.uid) and not U4.hasReqProfileUidList[_ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.base.uid] then
              U4.hasReqProfileUidList[_ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.base.uid] = 1
              U10[_ENV:GetModByAllCache(U1.tonumber(_ARG_0_)).pub_mod_meta.base.uid] = 1
            end
          else
            if not U4.DisplayedThemeModIDList[_ARG_0_] then
              U4.DisplayedThemeModIDList[_ARG_0_] = {}
            end
            U4.DisplayedThemeModIDList[_ARG_0_] = true
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end, function(_ARG_0_)
        do
          log(bWriteLog and table.concat({
            U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 94, 31, 223, 117, 184, 39, 109, 91, 177, 239, 121, 60, 209, 74, 176, 40, 111, 14),
            U1(184, 46, 173, 100, 7, 35, 9, 38, 212, 121, 174, 61, 94, 111, 173, 225, 120, 95, 218, 65, 182, 7, 100, 51, 198, 94, 179, 58, 25, 14, 244)
          }) .. tostring(_ARG_0_))
          goto lbl_100
          if U3.DisplayedThemeModIDList[U1(184, 46, 173, 100, 7, 35, 9, 38, 212, 121, 174, 61, 94, 111, 173, 225, 120, 95, 218, 65, 182, 7, 100, 51, 198, 94, 179, 58, 25, 14, 244)] then
          end
          ::lbl_100::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          if 0 + 1 >= #U2 then
            U4 = true
          end
          _ARG_0_ = _ARG_0_
          if U4 or not U3.DisplayedThemeModIDList[U2[U1(184, 46, 173, 100, 7, 35, 9, 38, 212, 121, 174, 61, 94, 111, 173, 225, 120, 95, 218, 65, 182, 7, 100, 51, 198, 94, 179, 58, 25, 14, 244)]] then
            if 0 + 1 + 1 >= #U2 then
              U4 = true
            end
          end
          if not (#U6 >= U7) then
            _ARG_0_ = _ARG_0_
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end, _ARG_0_.ExposureModList
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNewHotThemeModList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 94, 31, 223, 114, 185, 54, 109, 91, 177, 239, 121, 34, 214, 65, 139, 12, 115, 30),
          U1(220, 7, 182, 113, 115, 45, 5, 39, 221, 110, 167, 38, 72, 3, 173, 225, 44, 17, 192, 89)
        }))
        return
      end
      goto lbl_96
      if U1(220, 7, 182, 113, 115, 45, 5, 39, 221, 110, 167, 38, 72, 3, 173, 225, 44, 17, 192, 89).base.id == _ARG_1_.base.id then
      else
        ::lbl_96::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not (_ARG_0_.tableHotTheme and next(_ARG_0_.tableHotTheme) and _ARG_0_.tableHotTheme[_ARG_1_.base.id]) or not next(_ARG_0_.tableHotTheme[_ARG_1_.base.id]) then
        return
      end
      _ARG_0_.hasReqProfileUidList = _ARG_0_.hasReqProfileUidList or {}
      goto lbl_492
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta.perf_off_banner then
        if U1(220, 7, 182, 113, 115, 45, 5, 39, 221, 110, 167, 38, 72, 3, 173, 225, 44, 17, 192, 89).base and U1(220, 7, 182, 113, 115, 45, 5, 39, 221, 110, 167, 38, 72, 3, 173, 225, 44, 17, 192, 89).base.show_author == 1 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta.base and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta.base.uid and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta.base.uid) and not _ARG_0_.hasReqProfileUidList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta.base.uid] then
          _ARG_0_.hasReqProfileUidList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(220, 59, 177, 96, 74, 32, 36, 43, 204, 75, 230))).pub_mod_meta.base.uid] = 1
        end
      end
      ::lbl_492::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqAuthorProfile"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 178, 4, 81, 15, 220, 82, 185, 48, 105, 65, 187, 228, 117, 3, 220, 5, 178, 12, 100, 38),
          U1(149, 60, 173, 37, 78, 54, 64, 35, 214, 92, 167, 62, 64, 71)
        }))
        return
      end
      goto lbl_87
      ::lbl_87::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotSpecialThemeShowData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 88, 21, 220, 105, 166, 39, 90, 90, 181, 238, 72, 7, 220, 72, 162, 54, 104, 5),
          U1(139, 11, 184, 113, 70, 101, 40, 37, 204, 126, 174, 55, 68, 70, 128, 243, 120, 30, 137, 92, 164, 85, 126, 19, 196)
        }))
        return
      end
      log_tree(table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 88, 21, 220, 105, 166, 39, 90, 90, 181, 238, 72, 7, 220, 72, 162, 54, 104, 5),
        U1(139, 11, 184, 113, 70, 101, 40, 37, 204, 126, 174, 55, 68, 70, 128, 243, 120, 30)
      }), _ARG_1_)
      goto lbl_234
      if U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.id == _ARG_1_.base.id then
      else
        ::lbl_234::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.hasReqProfileUidList = _ARG_0_.hasReqProfileUidList or {}
      goto lbl_473
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.perf_off_banner then
        if U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.show_author == 1 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.base and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.base.uid and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.base.uid) and not _ARG_0_.hasReqProfileUidList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.base.uid] then
          _ARG_0_.hasReqProfileUidList[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.base.uid] = 1
        end
      end
      ::lbl_473::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.tableHotTheme[_ARG_1_.base.id] = {}
      goto lbl_489
      ::lbl_489::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.ExposureModList[_ARG_1_.base.id] = {}, U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.show_author == 1, {
        [ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(U1(139, 11, 184, 113, 70, 101, 20, 34, 221, 71, 163, 22, 72, 87, 165, 178))).pub_mod_meta.base.uid] = 1
      }, U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base and U1(155, 44, 134, 109, 72, 49, 63, 62, 208, 79, 171, 55).base.id == U2, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile), _ARG_0_.ExposureModList
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SaveLastSelectKOLThemeId"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 182, 3, 117, 54, 201, 73, 162, 17, 92, 95, 177, 225, 104, 36, 246, 105, 147, 13, 101, 7),
        U1(153, 6, 189, 37)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLastSelectKOLThemeId"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 92, 27, 219, 78, 133, 39, 85, 86, 183, 246, 87, 32, 245, 113, 175, 0, 109, 15),
        U1(181, 43)
      }))
      do return (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCThemeKOL) or {}).KOLThemeId end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBanGuessYouLikeModId"] = function(_ARG_0_, _ARG_1_)
    do
      print(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 82, 27, 198, 125, 163, 39, 74, 64, 141, 237, 105, 35, 208, 78, 162, 40, 111, 14),
        U1(181, 43, 249)
      }) .. tostring(_ARG_1_))
      if U2((_ARG_0_:GetBanGuessYouLikeModIds())) < U3 then
        _ARG_0_:GetBanGuessYouLikeModIds()[tostring(_ARG_1_)] = true
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBanGuessYouLikeModIds"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 114, 178, 1, 82, 27, 198, 125, 163, 39, 74, 64, 141, 237, 105, 35, 208, 78, 162, 40, 111, 14),
        U1(181, 43, 170)
      }))
      do return (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCGuessULike) or {}).BanModIds or {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHotThemeEntryStamp"] = function(_ARG_0_)
    do
      _ARG_0_.HotThemeEntryStamp = require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHotThemeDepartureStamp"] = function(_ARG_0_)
    do
      _ARG_0_.HotThemeDepartureStamp = require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTimeInterval"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.HotThemeEntryStamp or not _ARG_0_.HotThemeDepartureStamp then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 252, 83, 187, 39, 112, 93, 160, 231, 110, 25, 216, 73, 231, 45, 111, 30),
          U1(168, 39, 188, 104, 66, 0, 14, 62, 202, 83, 149, 38, 72, 78, 180, 178, 99, 13, 137, 125, 184, 1, 68, 18, 205, 87, 179, 6, 92, 67, 181, 240, 104, 26, 203, 64, 148, 17, 97, 7),
          U1(140, 111, 176, 118, 7, 43, 9, 38)
        }))
        return false
      end
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 252, 83, 187, 39, 112, 93, 160, 231, 110, 25, 216, 73, 231, 22, 101, 6),
        U1(154, 97, 145, 106, 83, 17, 8, 47, 213, 79, 131, 60, 93, 81, 189, 193, 120, 30, 196, 69, 247, 72, 48)
      }) .. tostring(_ARG_0_.HotThemeEntryStamp))
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 252, 83, 187, 39, 112, 93, 160, 231, 110, 25, 216, 73, 231, 0, 108, 12),
        U1(210, 7, 182, 113, 115, 45, 5, 39, 221, 110, 163, 34, 72, 81, 176, 231, 126, 26, 250, 65, 182, 24, 96, 90, 149, 26)
      }) .. tostring(_ARG_0_.HotThemeDepartureStamp))
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 252, 83, 187, 39, 112, 93, 160, 231, 110, 25, 216, 73, 231, 23, 101, 30),
        U1(137, 61, 183, 37, 81, 36, 12, 63, 221, 10, 251, 114)
      }) .. tostring(_ARG_0_.HotThemeEntryStamp <= _ARG_0_.HotThemeDepartureStamp + _ARG_0_.HotThemeCarouselCD))
      if _ARG_1_ == 2 then
        return _ARG_0_.HotThemeEntryStamp <= _ARG_0_.HotThemeDepartureStamp + _ARG_0_.HotThemeCarouselCD
      else
        return _ARG_0_.HotThemeEntryStamp <= _ARG_0_.HotThemeDepartureStamp + _ARG_0_.HotAuthorCarouselCD
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Report"] = function(_ARG_0_)
    do
      if not next(_ARG_0_.report) then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 178, 5, 127, 8, 220, 26, 165, 39, 85, 85, 250, 240, 121, 31, 214, 87, 179, 69, 105, 25),
          U1(220, 33, 176, 105)
        }))
        return
      end
      if _ARG_0_.version == 0 then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 178, 5, 127, 8, 220, 26, 165, 39, 85, 85, 250, 244, 121, 29, 202, 76, 168, 11, 32, 3),
          U1(143, 111, 233)
        }))
        return
      end
      log_tree(U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 103, 178, 5, 127, 8, 220, 26, 165, 39, 85, 85, 250, 240, 121, 31, 214, 87, 179), _ARG_0_.report)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearReport"] = function(_ARG_0_)
    do
      _ARG_0_.report = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddReportDetail"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddReport(_ARG_1_, (_ENV(152, 42, 173, 100, 78, 41)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddReportSelect"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddReport(_ARG_1_, (_ENV(143, 42, 181, 96, 68, 49)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddReportCollect"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddReport(_ARG_1_, (_ENV(159, 32, 181, 105, 66, 38, 20)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddReportExpose"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddReport(_ARG_1_, (_ENV(153, 55, 169, 106, 84, 32)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddReport"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.report then
        _ARG_0_.report = {}
      end
      if not _ARG_1_ then
        return
      end
      if not _ARG_0_.report[_ARG_1_] then
        _ARG_0_.report[_ARG_1_] = _ARG_0_:FormatReportItem()
      end
      _ARG_0_.report[_ARG_1_][_ARG_2_] = 1
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FormatReportItem"] = function(_ARG_0_)
    do
      do return {
        detail = 0,
        select = 0,
        match = 0,
        collect = 0,
        expose = 0
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHotThemeReqState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.HotThemeReqState[_ARG_1_.base.id] = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotThemeReqState"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.HotThemeReqState[_ARG_1_.base.id] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearKOLHotThemeCache"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.tableHotTheme[_ARG_1_] = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearDisplayedThemeModIDListCache"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 187, 16, 113, 8, 236, 83, 165, 50, 85, 82, 173, 231, 120, 59, 209, 64, 170, 0, 77, 5),
        U1(152, 6, 157, 73, 78, 54, 20, 9, 217, 73, 174, 55)
      }))
      _ARG_0_.DisplayedThemeModIDList = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotThemeList"] = function(_ARG_0_)
    do
      do return _ARG_0_.hot_theme end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowTableHotTheme"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.tableHotTheme[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotTheme"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil
      end
      if not _ARG_0_.hot_theme then
        return nil
      end
      goto lbl_21
      if (nil).base.id == _ARG_1_ then
        return nil, nil
      end
      ::lbl_21::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHotThemeListNum"] = function(_ARG_0_)
    do
      if not _ARG_0_.hot_theme then
        return 0
      end
      do return #_ARG_0_.hot_theme end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsNewHotThemeOpen"] = function(_ARG_0_)
    do
      if not DataMgr or not DataMgr.ugc_hot_theme then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 225, 73, 152, 39, 78, 123, 187, 246, 72, 7, 220, 72, 162, 42, 112, 15),
          U1(146, 111, 157, 100, 83, 36, 45, 45, 202, 4, 180, 61, 69, 70, 128, 243, 120, 30, 137, 92, 164, 85, 126, 19, 196)
        }))
        return false
      end
      do return DataMgr.ugc_hot_theme == 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSelectHotThemeBundleName"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetHotTheme(_ARG_1_) then
      end
      do return _ARG_0_:GetHotTheme(_ARG_1_).base.name end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSelectThemeBundleModList"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetHotTheme(_ARG_1_) then
        goto lbl_37
        ::lbl_37::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return {}
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHotThemeModListReady"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetHotTheme(_ARG_1_) then
        _ARG_0_.AutoNextReqBundleID = _ARG_1_
        _ARG_0_:send_ugc_gallery_hot_theme_req()
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_ugc_gallery_hot_theme_req"] = function(_ARG_0_)
    do
      if _ARG_0_:CheckThemeDataValid() then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 70, 178, 27, 116, 37, 221, 93, 181, 29, 94, 82, 184, 238, 121, 29, 192, 122, 175, 10, 116, 53),
          U1(136, 39, 188, 104, 66, 26, 18, 47, 201, 10, 162, 51, 93, 66, 146, 243, 96, 22, 205, 21, 185, 26, 48, 20, 205, 95, 178, 98, 77, 92, 244, 240, 121, 30)
        }))
        EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_HOTTHEME_LIST_RSP)
        _ARG_0_:GetThemeModPlayer()
        return
      end
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 70, 178, 27, 116, 37, 221, 93, 181, 29, 94, 82, 184, 238, 121, 29, 192, 122, 175, 10, 116, 53),
        U1(136, 39, 188, 104, 66, 26, 18, 47, 201)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckThemeDataValid"] = function(_ARG_0_)
    do
      if not _ARG_0_.hot_theme or #_ARG_0_.hot_theme <= 0 then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 252, 82, 179, 47, 92, 119, 181, 246, 125, 57, 216, 73, 174, 1, 32, 2),
          U1(147, 59, 134, 113, 79, 32, 13, 47, 152, 67, 181, 114, 71, 74, 168)
        }))
        return false
      end
      if not _ARG_0_.themeDataTimeStamp then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 252, 82, 179, 47, 92, 119, 181, 246, 125, 57, 216, 73, 174, 1, 32, 30),
          U1(148, 42, 180, 96, 99, 36, 20, 43, 236, 67, 171, 55, 122, 87, 165, 255, 124, 95, 192, 70, 247, 27, 121, 22)
        }))
        return false
      end
      do return require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).GetServerTimeInSec() <= _ARG_0_.themeDataTimeStamp + _ARG_0_.HotThemeListReqCD end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSelectBannerBundleName"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetBannerBundle(_ARG_1_) then
      end
      do return _ARG_0_:GetBannerBundle(_ARG_1_).title end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSelectBannerBundleModList"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetBannerBundle(_ARG_1_) then
        goto lbl_121
        ::lbl_121::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return {}
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckBannerModListReady"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetBannerBundle(_ARG_1_) then
        _ARG_0_:send_ugc_mixed_banner_req()
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_ugc_mixed_banner_req"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 135, 70, 178, 27, 116, 37, 221, 93, 181, 29, 84, 90, 172, 231, 120, 48, 219, 68, 169, 11, 101, 24),
        U1(163, 61, 188, 116, 7, 54, 20, 43, 202, 94)
      }))
      if _ARG_0_.showList then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 135, 70, 178, 27, 116, 37, 221, 93, 181, 29, 84, 90, 172, 231, 120, 48, 219, 68, 169, 11, 101, 24),
          U1(163, 61, 188, 116, 7, 45, 1, 60, 221, 10, 162, 51, 93, 66)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 135, 70, 178, 27, 116, 37, 221, 93, 181, 29, 84, 90, 172, 231, 120, 48, 219, 68, 169, 11, 101, 24),
        U1(163, 61, 188, 116, 7, 43, 5, 47, 220, 10, 162, 51, 93, 66)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UGCBannerDataIntegration"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 144, 54, 82, 27, 198, 84, 179, 48, 125, 82, 160, 227, 85, 1, 205, 64, 160, 23, 97, 30),
          U1(149, 32, 183, 37, 74, 44, 24, 47, 220, 117, 164, 51, 71, 77, 161, 224, 83, 19, 192, 70, 163, 85, 45, 90, 198, 83, 186)
        }))
        return
      end
      _ARG_0_.mixed_banner_list = _ARG_1_
      print(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 144, 54, 82, 27, 198, 84, 179, 48, 125, 82, 160, 227, 85, 1, 205, 64, 160, 23, 97, 30),
        U1(149, 32, 183, 37, 4, 40, 9, 50, 221, 78, 153, 48, 72, 77, 170, 247, 126, 32, 197, 92, 164, 1, 48, 71, 136)
      }) .. tostring(#_ARG_1_))
      _ARG_0_:SortNeedShowDataUGC()
      EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_BANNER_LIST)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SortNeedShowDataUGC"] = function(_ARG_0_)
    do
      _ARG_0_.showList = {}
      _ARG_0_.bannerData = {}
      _ARG_0_.BannerThemeData = {}
      _ARG_0_.newThemeData = {}
      _ARG_0_.activityData = nil
      _ARG_0_.AllBannerTypeList = {}
      goto lbl_144
      if (nil).set_type == U1(158, 46, 183, 107, 66, 55) then
        if (nil).mod_list then
          if (nil).mod_list ~= U1() then
            if not _ARG_0_.AllBannerTypeList.mod then
              _ARG_0_.AllBannerTypeList.mod = true
            end
          elseif not _ARG_0_.AllBannerTypeList.collection then
            _ARG_0_.AllBannerTypeList.collection = true
          end
        end
        if (nil).video_url and not _ARG_0_.AllBannerTypeList.video then
          _ARG_0_.AllBannerTypeList.video = true
        end
      elseif (nil).set_type == U1(136, 39, 188, 104, 66) then
        if not _ARG_0_.AllBannerTypeList.theme then
          _ARG_0_.AllBannerTypeList.theme = true
        end
      elseif (nil).set_type == U1(148, 46, 181, 105) then
      elseif (nil).set_type == U1(145, 46, 173, 102, 79) then
        if not _ARG_0_.AllBannerTypeList.match then
          _ARG_0_.AllBannerTypeList.match = true
        end
      elseif (nil).set_type == U1(157, 58, 173, 109, 72, 55) then
        if not _ARG_0_.AllBannerTypeList.author then
          _ARG_0_.AllBannerTypeList.author = true
        end
      elseif not _ARG_0_.AllBannerTypeList.other then
        _ARG_0_.AllBannerTypeList.other = true
      end
      ::lbl_144::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.bannerData = {
        set_type = U1(158, 46, 183, 107, 66, 55),
        showList = {},
        rank_value = ({})[1].rank_value
      }
      if _ARG_0_.BannerThemeData and next(_ARG_0_.BannerThemeData) then
        if _ARG_0_:CheckIsNewBanner() then
        end
      else
      end
      _ARG_0_.newThemeData = {
        set_type = U1(136, 39, 188, 104, 66),
        rank_value = ({})[1].rank_value,
        showList = {}
      }
      if 0 < #{} then
      end
      if 0 < #{} then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNeedReqModIDs"] = function(_ARG_0_)
    do
      if not _ARG_0_.mixed_banner_list or not _ARG_0_.showList then
        return nil
      end
      goto lbl_81
      if (43).mod_list and (43).set_type == U1(136, 39, 188, 104, 66) and (43).mod_list then
        goto lbl_79
        if not _ARG_0_:ValueIsInTable({}, tonumber(104)) then
        else
          ::lbl_79::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_81::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_:CheckIsNewBanner() then
        if _ARG_0_.BannerThemeData[1] and _ARG_0_.BannerThemeData[1].mod_list then
          goto lbl_121
          ::lbl_121::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if _ARG_0_.BannerThemeData[2] and _ARG_0_.BannerThemeData[2].mod_list then
          goto lbl_153
          ::lbl_153::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      goto lbl_194
      goto lbl_192
      if ({}).mod_list then
        goto lbl_190
        ::lbl_190::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_192::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_194::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ValueIsInTable"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if 0 < #_ARG_1_ then
        goto lbl_12
        if nil == _ARG_2_ then
          return true
        end
        ::lbl_12::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBannerThemeData"] = function(_ARG_0_)
    do
      do return _ARG_0_.BannerThemeData end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBannerBundle"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil
      end
      if #_ARG_0_.BannerThemeData == 0 then
        return nil
      end
      goto lbl_19
      if (nil).id == _ARG_1_ then
        return nil
      end
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelectThemeBanner"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 67, 31, 196, 95, 181, 54, 109, 91, 177, 239, 121, 45, 216, 75, 169, 0, 114))
      if 1 <= #_ARG_0_.BannerThemeData then
        _ARG_0_.themeIndex = _ARG_0_.themeIndex + 1
      end
      if _ARG_0_.themeIndex > #_ARG_0_.BannerThemeData then
        _ARG_0_.themeIndex = 1
      end
      goto lbl_95
      if (190).set_type == U1(136, 39, 188, 104, 66) then
        goto lbl_93
        if (188).set_type == U1(136, 39, 188, 104, 66) then
          ;(190).showList[39] = _ARG_0_.BannerThemeData[_ARG_0_.themeIndex]
        end
        ::lbl_93::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_95::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      log_tree(table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 68, 18, 205, 87, 179, 11, 87, 87, 177, 250, 60, 28, 220, 73, 161, 75, 115, 2),
        U1(147, 56, 149, 108, 84, 49, 64, 119, 152)
      }), _ARG_0_.showList)
      do return _ARG_0_.showList end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckBannerModRedDot"] = function(_ARG_0_, _ARG_1_)
    do
      if (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}) ~= nil and (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList and (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList and (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList[_ARG_1_] then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SaveBannerModRedDot"] = function(_ARG_0_, _ARG_1_)
    do
      if not (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList then
        ;(require((table.concat({
          U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
          U1(143)
        }))).LoadFileToTable_N(require((table.concat({
          U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
          U1(143)
        }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList = {}
      end
      if not (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList[_ARG_1_] then
        ;(require((table.concat({
          U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
          U1(143)
        }))).LoadFileToTable_N(require((table.concat({
          U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
          U1(143)
        }))).ePlayerPrefsType.eUGCBannerModsRedDot) or {}).NewProcessList[_ARG_1_] = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHotShowHistory"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 118, 191, 16, 115, 17, 224, 85, 162, 17, 81, 92, 163, 202, 117, 28, 205, 74, 181, 28))
      if not _ARG_0_:CheckIsHotHistoryABTest() then
        return false
      end
      if (require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCHotShowHistory) or {}).show_time and require((U1(159, 35, 176, 96, 73, 49, 78, 41, 215, 71, 171, 61, 71, 13, 176, 251, 97, 26, 246, 64, 163, 28, 124))).IsToday((require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).LoadFileToTable_N(require((table.concat({
        U1(159, 35, 176, 96, 73, 49, 78, 38, 215, 77, 175, 49, 7, 111, 171, 245, 101, 28, 249, 89, 182, 12, 117, 8, 248, 72, 179, 36, 74, 29, 164, 238, 125, 22, 220, 87, 183, 23, 101, 12),
        U1(143)
      }))).ePlayerPrefsType.eUGCHotShowHistory) or {}).show_time) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SaveHotShowHistoryState"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHotHistoryABTest"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 114, 191, 49, 77, 92, 166, 251, 93, 45, 237, 64, 180, 17, 32, 14),
        U1(157, 59, 184, 37, 26)
      }) .. tostring(_ARG_1_))
      _ARG_0_.hot_history_abtest = _ARG_1_
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 88, 21, 220, 114, 191, 49, 77, 92, 166, 251, 93, 45, 237, 64, 180, 17, 32, 25),
        U1(153, 35, 191, 43, 79, 42, 20, 21, 208, 67, 181, 38, 70, 81, 189, 205, 109, 29, 221, 80, 164, 1, 48, 71, 136)
      }) .. tostring(_ARG_0_.hot_history_abtest))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsHotHistoryABTest"] = function(_ARG_0_)
    do
      if not _ARG_0_.hot_history_abtest then
        return false
      end
      do return _ARG_0_.hot_history_abtest == 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsNewBanner"] = function(_ARG_0_)
    do
      if not _ARG_0_.AllBannerTypeList or not next(_ARG_0_.AllBannerTypeList) then
        return false
      end
      goto lbl_47
      if nil == true and nil ~= U1(145, 32, 189) and nil ~= U1(136, 39, 188, 104, 66) then
        return false
      end
      ::lbl_47::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.AllBannerTypeList.mod == true and _ARG_0_.AllBannerTypeList.theme == true then
        return true
      elseif _ARG_0_.AllBannerTypeList.mod == true or _ARG_0_.AllBannerTypeList.theme == true then
        return false
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SortModIdList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_9
      ::lbl_9::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_31
      if ({
        [nil] = true
      })[nil] then
      else
      end
      ::lbl_31::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_44
      ::lbl_44::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_55
      ::lbl_55::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTopRecThemeOneIndex"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 167, 17, 113, 14, 205, 110, 185, 50, 107, 86, 183, 214, 116, 10, 212, 64, 136, 11, 101, 35),
        U1(146, 43, 188, 125)
      }))
      if not _ARG_0_.newThemeData or not _ARG_0_.newThemeData.showList then
        _ARG_0_.RecThemeOneIndex = 1
        return
      end
      _ARG_0_.RecThemeOneIndex = _ARG_0_.RecThemeOneIndex + 1
      if require((U1(159, 32, 180, 104, 72, 43, 78, 62, 217, 72, 170, 55, 118, 86, 176, 251, 96))).CountTable(_ARG_0_.newThemeData.showList[1] and _ARG_0_.newThemeData.showList[1].modInfo_list or {}) < _ARG_0_.RecThemeOneIndex then
        _ARG_0_.RecThemeOneIndex = 1
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTopRecThemeTwoIndex"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 167, 17, 113, 14, 205, 110, 185, 50, 107, 86, 183, 214, 116, 10, 212, 64, 147, 18, 111, 35),
        U1(146, 43, 188, 125)
      }))
      if not _ARG_0_.newThemeData or not _ARG_0_.newThemeData.showList then
        _ARG_0_.RecThemeTwoIndex = 1
        return
      end
      _ARG_0_.RecThemeTwoIndex = _ARG_0_.RecThemeTwoIndex + 1
      if require((U1(159, 32, 180, 104, 72, 43, 78, 62, 217, 72, 170, 55, 118, 86, 176, 251, 96))).CountTable(_ARG_0_.newThemeData.showList[2] and _ARG_0_.newThemeData.showList[2].modInfo_list or {}) < _ARG_0_.RecThemeTwoIndex then
        _ARG_0_.RecThemeTwoIndex = 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTopRecThemeOneIndex"] = function(_ARG_0_)
    do
      do return _ARG_0_.RecThemeOneIndex end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTopRecThemeTwoIndex"] = function(_ARG_0_)
    do
      do return _ARG_0_.RecThemeTwoIndex end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTopRecThemeThreeIndex"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 167, 17, 113, 14, 205, 110, 185, 50, 107, 86, 183, 214, 116, 10, 212, 64, 147, 13, 114, 15),
        U1(153, 6, 183, 97, 66, 61)
      }))
      if not _ARG_0_.newThemeData or not _ARG_0_.newThemeData.showList then
        _ARG_0_.RecThemeThreeIndex = 1
        return
      end
      _ARG_0_.RecThemeThreeIndex = _ARG_0_.RecThemeThreeIndex + 2
      if require((U1(159, 32, 180, 104, 72, 43, 78, 62, 217, 72, 170, 55, 118, 86, 176, 251, 96))).CountTable(_ARG_0_.newThemeData.showList[1] and _ARG_0_.newThemeData.showList[1].modInfo_list or {}) < _ARG_0_.RecThemeThreeIndex then
        _ARG_0_.RecThemeThreeIndex = 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTopRecThemeFourIndex"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 96, 167, 17, 113, 14, 205, 110, 185, 50, 107, 86, 183, 214, 116, 10, 212, 64, 129, 10, 117, 24),
        U1(181, 33, 189, 96, 95)
      }))
      if not _ARG_0_.newThemeData or not _ARG_0_.newThemeData.showList then
        _ARG_0_.RecThemeFourIndex = 2
        return
      end
      _ARG_0_.RecThemeFourIndex = _ARG_0_.RecThemeFourIndex + 2
      if require((U1(159, 32, 180, 104, 72, 43, 78, 62, 217, 72, 170, 55, 118, 86, 176, 251, 96))).CountTable(_ARG_0_.newThemeData.showList[1] and _ARG_0_.newThemeData.showList[1].modInfo_list or {}) < _ARG_0_.RecThemeFourIndex then
        _ARG_0_.RecThemeFourIndex = 2
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTopRecThemeThreeIndex"] = function(_ARG_0_)
    do
      do return _ARG_0_.RecThemeThreeIndex end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTopRecThemeFourIndex"] = function(_ARG_0_)
    do
      do return _ARG_0_.RecThemeFourIndex end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowBanner"] = function(_ARG_0_)
    do
      goto lbl_42
      if (nil).set_type == U1(158, 46, 183, 107, 66, 55) then
        goto lbl_39
        if (183).mod_list ~= U1() then
        end
        ::lbl_39::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_44
        ::lbl_42::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_44::
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({}, nil, nil, {bExportArray = true}) or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({}, nil, nil, {bExportArray = true}))) then
        return false
      end
      if #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):BatchGetModInfo({}, nil, nil, {bExportArray = true}) < 2 then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetModeMABVersion"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not next(_ARG_1_) then
        return
      end
      goto lbl_16
      _ARG_0_.version = (nil).mab_version
      goto lbl_18
      ::lbl_16::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_18::
      log(bWriteLog and table.concat({
        U1(144, 32, 190, 108, 68, 26, 21, 45, 219, 117, 174, 61, 93, 124, 180, 243, 107, 26, 147, 102, 178, 1, 93, 21, 204, 95, 155, 3, 123, 101, 177, 240, 111, 6, 214, 75, 231, 19, 101, 24),
        U1(143, 38, 182, 107, 29)
      }) .. tostring(_ARG_0_.version))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
