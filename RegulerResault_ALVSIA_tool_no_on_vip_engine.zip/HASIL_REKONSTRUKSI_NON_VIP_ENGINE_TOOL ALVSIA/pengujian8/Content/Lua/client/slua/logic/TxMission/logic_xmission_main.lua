do return {
  MONEY_ID_GOLD_FASTENER = 1301,
  TPLAN_TICKET_ID = 1310,
  bHasGetBaseInfo = false,
  metro_cur_profit = 0,
  metro_max_profit = 0,
  profit_awards = {},
  prestige = 0,
  prestige_level = 1,
  moneys = {},
  totalTalentPoint = 0,
  has_auto_show_warpre = false,
  levelUpData = nil,
  waitJoinTeamUID = nil,
  C_Single2NpcLS = 64,
  C_Team2NpcLS = 65,
  C_Npc2SingleLS = 66,
  C_Npc2TeamLS = 67,
  C_MaxPrestigeLevel = nil,
  entry_actor = nil,
  entry_ui = nil,
  bCurBattleGuideIsShow = false,
  bIsReconnect = false,
  bNewMailTips = false,
  BackupShadowQuality = 1,
  BattleResultReason = false,
  banWindowShowTimer = nil,
  banWindowShow = false,
  command_post_reddot_num = 0,
  bCheckCommandPostLevelExtendGuide = false,
  bEnterXMissionReq = false,
  timerResetIsInXMission = nil,
  bEnterXMissionFromScroll = nil,
  cur_select_index = 0,
  oldPrestigeLevel = 1,
  E_ChangeTeamType = {L2X = 1, X2L = 2},
  XMission_Wardrobe_JumpType = {
    QuickJump = (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(21, 60, 216, 197, 150, 15, 26, 211, 178)
  },
  ["LoadCachedLobbySceneType"] = function()
    if (U2.LoadFileToTable_N(U3) and U2.LoadFileToTable_N(U3).lobbySceneType) == require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
      U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
    }))).SceneType.Lobby2D or (U2.LoadFileToTable_N(U3) and U2.LoadFileToTable_N(U3).lobbySceneType) == require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
      U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
    }))).SceneType.Lobby3D then
      return U2.LoadFileToTable_N(U3) and U2.LoadFileToTable_N(U3).lobbySceneType
    end
    do return require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
      U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
    }))).SceneType.Lobby2D end
    return
  end,
  ["SaveCachedLobbySceneType"] = function(_ARG_0_)
    do
      _ARG_0_ = require((table.concat({
        U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
        U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
      }))).NormalizeSceneType(_ARG_0_)
      if (U2.LoadFileToTable_N(U3) or {}).lobbySceneType == _ARG_0_ then
        return
      end
      ;(U2.LoadFileToTable_N(U3) or {}).lobbySceneType = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLobbySceneType"] = function(_ARG_0_)
    do
      U2.lobbySceneType = require((table.concat({
        U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
        U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
      }))).NormalizeSceneType(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLobbySceneType"] = function()
    do return require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
      U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
    }))).NormalizeSceneType(U2.lobbySceneType) end
    return
  end,
  ["IsLobby2D"] = function()
    do return require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
      U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
    }))).IsLobby2D(U2.lobbySceneType) end
    return
  end,
  ["GetMetroLobbyType"] = function()
    do return require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
      U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
    }))).GetMetroLobbyType(U2.lobbySceneType) end
    return
  end,
  ["OnSyncBaseInfoMetroLobbyType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_0_ == true or tonumber(_ARG_0_) == 1) then
        return
      end
      if _ARG_2_ then
        if U2.pendingLobbySceneSwitch then
        end
        U2.awaitingLobbySceneSyncType = nil
        return
      end
      if U2.pendingLobbySceneSwitch then
        if require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
          U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
        }))).GetSceneTypeByMetroLobbyType(_ARG_1_) == U2.pendingLobbySceneSwitch.targetSceneType then
          U2.pendingLobbySceneSwitch.bSyncConfirmed = true
          if U2.awaitingLobbySceneSyncType == require((table.concat({
            U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
            U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
          }))).GetSceneTypeByMetroLobbyType(_ARG_1_) then
            U2.awaitingLobbySceneSyncType = nil
          end
        end
        return
      end
      if U2.awaitingLobbySceneSyncType then
        if require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
          U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
        }))).GetSceneTypeByMetroLobbyType(_ARG_1_) ~= U2.awaitingLobbySceneSyncType then
          return
        end
        U2.awaitingLobbySceneSyncType = nil
      end
      do return end
      _ARG_2_ = _ENV[248]
    end
  end,
  ["ShowXMissionMainUI"] = function(...)
    if not UIManager.UI_Config.xmission_main._pathLobby3D then
      UIManager.UI_Config.xmission_main._pathLobby3D = UIManager.UI_Config.xmission_main.path
    end
    if U1.IsLobby2D() then
      UIManager.UI_Config.xmission_main.path = UIManager.UI_Config.xmission_main.pathLobby2D or UIManager.UI_Config.xmission_main._pathLobby3D
    else
      UIManager.UI_Config.xmission_main.path = UIManager.UI_Config.xmission_main._pathLobby3D
    end
    return
  end,
  ["ApplyLobbyTransitionSideEffects"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return
      end
      if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLobbyTransition"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_ = _ARG_1_ or U2.GetLobbySceneType()
      if require((table.concat({
        U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
        U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
      }))).IsLobby2D(_ARG_1_) then
        if _ARG_2_ then
        end
        return false
      end
      if _ARG_2_ then
        if not UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Opening_Train_UIBP, _ARG_0_, _ARG_2_ and function()
          if _ENV then
            return
          end
          _ENV = true
          if U1 then
            U1()
          end
          return
        end or nil) then
        else
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLobbySceneType"] = function()
    if not pendingLobbySceneSwitch or pendingLobbySceneSwitch.phase ~= U1(39, 40, 223, 197, 152, 41, 3, 219, 166) and pendingLobbySceneSwitch.phase ~= U1(48, 32, 220, 195, 153, 26, 0, 203, 182) then
    end
    awaitingLobbySceneSyncType = nil
    lobbySceneType = nil
    return
  end,
  ["EnterOrSwitchXMissionLobby"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil then
        _ARG_0_ = U2.LoadCachedLobbySceneType()
      else
        _ARG_0_ = require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 127, 22, 29, 62, 215, 0, 190, 232, 81, 10, 109, 252),
          U1(61, 26, 210, 195, 147, 32, 44, 209, 172, 151, 216, 84)
        }))).NormalizeSceneType(_ARG_0_)
      end
      if UIManager.GetUI(UIManager.UI_Config.xmission_main) then
        if U2.GetLobbySceneType() == _ARG_0_ then
          return
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLobbySceneSwitchState"] = function(_ARG_0_)
    do
      if pendingLobbySceneSwitch and pendingLobbySceneSwitch.timeoutTimer then
        pendingLobbySceneSwitch.timeoutTimer = nil
      end
      if pendingLobbySceneSwitch and pendingLobbySceneSwitch.lateRspTimer then
        pendingLobbySceneSwitch.lateRspTimer = nil
      end
      pendingLobbySceneSwitch = nil
      bSwitchingLobbyScene = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelXMissionLobbySceneSwitch"] = function(_ARG_0_)
    do
      if not pendingLobbySceneSwitch then
        return
      end
      if pendingLobbySceneSwitch.phase == U1(39, 40, 223, 197, 152, 41, 3, 219, 166) or pendingLobbySceneSwitch.phase == U1(48, 32, 220, 195, 153, 26, 0, 203, 182) then
        return
      end
      if pendingLobbySceneSwitch.phase == U1(37, 57, 193, 202, 132, 44, 1, 217) then
        return
      end
      pendingLobbySceneSwitch.phase = U1(39, 40, 223, 197, 152, 41, 3, 219, 166)
      bSwitchingLobbyScene = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyXMissionLobbySceneSwitch"] = function(_ARG_0_)
    do
      _ARG_0_.phase = _ENV(37, 57, 193, 202, 132, 44, 1, 217)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSwitchXMissionLobbySceneRsp"] = function(_ARG_0_)
    do
      if not pendingLobbySceneSwitch then
        return false, false
      end
      if pendingLobbySceneSwitch.phase == U1(39, 40, 223, 197, 152, 41, 3, 219, 166) or pendingLobbySceneSwitch.phase == U1(48, 32, 220, 195, 153, 26, 0, 203, 182) then
        return true, true
      end
      if pendingLobbySceneSwitch.phase ~= U1(51, 40, 216, 210, 148, 43, 8, 225, 176, 130, 193) then
        return false, false
      end
      if pendingLobbySceneSwitch.timeoutTimer then
        pendingLobbySceneSwitch.timeoutTimer = nil
      end
      if not (_ARG_0_ == 0 or _ARG_0_ == 100251043) then
        return true, false
      end
      do return true, true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SwitchXMissionLobbyScene"] = function(_ARG_0_)
    do
      if pendingLobbySceneSwitch or bSwitchingLobbyScene then
        return
      end
      if U1.require((U2(39, 37, 216, 195, 147, 49, 65, 208, 167, 133, 198, 92, 69, 32, 74, 62, 219, 20, 172, 184, 67, 16, 107, 195, 179, 143, 192, 68, 66, 41))).HasSendInfo(810119047) then
        return
      end
      if GetLobbySceneType() == _ARG_0_ then
        return
      end
      if not U1.require((U1.table.concat({
        U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
        U2(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213)
      }))).CheckEnterLobbyResReady(_ARG_0_) then
        return
      end
      if not MountXMissionPak(nil, _ARG_0_) then
        return
      end
      bSwitchingLobbyScene = true
      pendingLobbySceneSwitch = {
        sourceSceneType = GetLobbySceneType(),
        targetSceneType = _ARG_0_,
        phase = U2(51, 40, 216, 210, 148, 43, 8, 225, 176, 130, 193),
        ["timeoutTimer"] = U1.require((U2(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimerOnce(U3, function()
          if pendingLobbySceneSwitch ~= U1 or U1.phase ~= U2(51, 40, 216, 210, 148, 43, 8, 225, 176, 130, 193) and U1.phase ~= U2(39, 40, 223, 197, 152, 41, 3, 219, 166) then
            return
          end
          U1.timeoutTimer = nil
          U1.phase = U2(48, 32, 220, 195, 153, 26, 0, 203, 182)
          bSwitchingLobbyScene = false
          U1.lateRspTimer = U4.AddTimerOnce(U5, function()
            if pendingLobbySceneSwitch == U1 and U1.phase == U2(48, 32, 220, 195, 153, 26, 0, 203, 182) then
              U1.lateRspTimer = nil
              ClearLobbySceneSwitchState((U2(40, 40, 197, 195, 162, 55, 10, 205, 178, 158, 223, 64, 82, 20, 3, 47, 213, 26, 164, 201, 121, 28, 114, 235, 189, 148, 213)))
            end
            return
          end)
          return
        end)
      }
      return
    end
  end,
  ["ShouldSkipLobbySubsystemCamera"] = function()
    do return IsLobby2D() end
    return
  end,
  ["SwitchXMissionLobbyCamera"] = function(_ARG_0_)
    do
      if U1.IsLobby2D() then
        return
      end
      if require((U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 181, 243, 108, 24, 106, 254, 252, 141, 206, 68, 78, 56, 43, 57, 193, 8, 188, 217, 104, 21))).GetTeamNum() == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEnterXMissionFrom"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 197, 104, 1, 90, 224, 166, 132, 211, 123, 106, 50, 7, 62, 205, 6, 191, 192, 111, 10, 98, 176),
        U1(100, 47, 195, 201, 144, 120, 74, 205)
      }), tostring(_ARG_0_)))
      U2.bEnterXMissionFromScroll = _ARG_0_ == ENUM_XMISSION_FROM.Scroll
      ;(U3.LoadFileToTable_N(U4) or {}).from = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEnterXMissionFromScroll"] = function()
    log(bWriteLog and table.concat({
      U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 223, 126, 48, 113, 250, 183, 147, 249, 110, 78, 40, 7, 36, 203, 7, 151, 244, 114, 8, 92, 253),
      U1(54, 38, 221, 202, 211, 101, 13, 251, 172, 133, 212, 65, 111, 6, 13, 46, 199, 16, 174, 248, 75, 7, 112, 227, 129, 130, 211, 76, 75, 55)
    }) .. tostring(U2.bEnterXMissionFromScroll))
    if U2.bEnterXMissionFromScroll ~= nil then
      return U2.bEnterXMissionFromScroll
    end
    U2.bEnterXMissionFromScroll = (U3.LoadFileToTable_N(U4) or {}).from == ENUM_XMISSION_FROM.Scroll
    do return (U3.LoadFileToTable_N(U4) or {}).from == ENUM_XMISSION_FROM.Scroll end
    return
  end,
  ["MarkLobbyReturnXmission"] = function()
    log(bWriteLog and table.concat({
      U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 219, 108, 7, 116, 194, 189, 131, 195, 90, 117, 62, 0, 56, 214, 7, 137, 235, 116, 22, 124, 247),
      U1(43, 39)
    }))
    return
  end,
  ["OnPostSwitchGameStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 38, 191, 214, 114, 22, 123, 205),
        U1(51, 32, 197, 197, 149, 2, 14, 211, 167, 162, 197, 82, 67, 62, 23)
      }))
      if _ARG_2_.current == GameStatus.Login then
        U2 = false
        U3.levelUpData = nil
      elseif _ARG_2_.current == GameStatus.Fighting and not GameStatus.IsInMainCity() then
      elseif _ARG_2_.current == GameStatus.Lobby then
        if require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
          U1(43, 39, 238, 200, 152, 50, 13, 215, 167, 174, 215, 95, 88, 60)
        }))).IsSettlementReturnMetro() and GameStatus.IsPostSwitchEnterLobbyOrMainCityFromFighting(_ARG_2_.pre, _ARG_2_.current) then
        end
        if require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
          U1(43, 39, 238, 200, 152, 50, 13, 215, 167, 174, 215, 95, 88, 60)
        }))).IsSettlementReturnMetro() then
        end
        if U3.bIsReconnect then
        elseif (U3.IsInXMission() or require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
          U1(43, 39, 238, 200, 152, 50, 13, 215, 167, 174, 215, 95, 88, 60)
        }))).IsSettlementReturnMetro()) and GameStatus.IsPostSwitchEnterLobbyOrMainCityFromFighting(_ARG_2_.pre, _ARG_2_.current) then
        else
          U2 = false
        end
      end
      U3.banWindowShow = false
      do return end
      _ARG_0_ = U1[108]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsTPlanMode"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return false
      end
      if U1.CDataTable.GetTableData(_ENV(16, 49, 252, 207, 142, 54, 6, 209, 172, 188, 208, 67, 122, 36, 0, 56), _ARG_0_) then
        return true
      end
      if U1.CDataTable.GetTableData(_ENV(6, 29, 252, 201, 153, 32), U1.tonumber(_ARG_0_)) and U1.require((_ENV(39, 38, 220, 203, 146, 43, 65, 205, 182, 131, 216, 93, 80, 20, 17, 41, 221, 21))).StrFind(U1.CDataTable.GetTableData(_ENV(6, 29, 252, 201, 153, 32), U1.tonumber(_ARG_0_)).ModType, (_ENV(16, 25, 221, 199, 147))) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLogin"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 38, 191, 202, 114, 2, 102, 240),
        U1(108, 43, 227, 195, 177, 42, 8, 215, 172, 216)
      }))
      if _ARG_0_ then
        U2.ReconnectXMission()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitOnlyOne"] = function()
    EventSystem:registEvent(EVENTTYPE_TEAMUP, EVENTID_TEAM_PLATFORM_QUIT_TEAM_SUC_AND_APPLY, U1.OnQuitTeamAndNext)
    EventSystem:registEvent(EVENTTYPE_CAMERA, EVENTID_CAMERA_SWITCHED, U1.OnCameraSwitched)
    EventSystem:registEvent(EVENTTYPE_CAMERA, EVENTID_SCREEN_RATIO_CHANGED, U1.OnScreenRatioChanged)
    EventSystem:registEvent(EVENTTYPE_STATE, EVENTID_ON_MODE_POST_SWITCH, U1.OnPostSwitchGameStatus)
    EventSystem:registEvent(EVENTTYPE_SETTING, EVENTID_SETTING_RETURN_TO_LOBBY, U1.MarkLobbyReturnXmission)
    return
  end,
  ["OnScreenRatioChanged"] = function()
    if not IsInXMission() or not IsLobby2D() then
      return
    end
    U1.printf((U1.table.concat({
      U2(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 251, 217, 99, 38, 124, 252, 183, 132, 207, 113, 70, 47, 29, 34, 231, 1, 176, 232, 122, 0, 107, 190),
      U2(54, 44, 208, 214, 141, 41, 22, 158, 174, 158, 211, 81, 78, 121, 0, 125, 215, 24, 172, 243, 127, 20, 63, 239, 188, 133, 129, 80, 83, 58, 26, 41, 215)
    })))
    SwitchXMissionLobbyCamera(0)
    return
  end,
  ["CheckAndDestroyEnterParticleEmitter"] = function()
    if CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), (U1(41, 44, 197, 212, 146, 26, 3, 219, 180, 148, 221, 108, 91, 34, 9, 52, 192))) and CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), (U1(41, 44, 197, 212, 146, 26, 3, 219, 180, 148, 221, 108, 91, 34, 9, 52, 192))).value and tonumber(CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), (U1(41, 44, 197, 212, 146, 26, 3, 219, 180, 148, 221, 108, 91, 34, 9, 52, 192))).value) > 0 and DataMgr.roleData.level < tonumber(CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), (U1(41, 44, 197, 212, 146, 26, 3, 219, 180, 148, 221, 108, 91, 34, 9, 52, 192))).value) then
    end
    if not (LobbySystem.CheckOpen(BP_ENUM_LOBBY_MENU_TXMISSION) and not Client.IsWindowOB() and U2.CheckHallThemeNeedShowEntry()) or true then
    end
    return
  end,
  ["IsBlackMarketSystemOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(41, 40, 195, 205, 152, 49, 48, 209, 178, 148, 223, 108, 91, 61), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMissionSystemOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(41, 32, 194, 213, 148, 42, 1, 225, 173, 129, 212, 93, 104, 39, 18), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPrestigeAwardSystemOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(40, 44, 199, 195, 145, 26, 29, 219, 181, 144, 195, 87, 104, 36, 20, 56, 218, 38, 173, 224), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsTalentSystemOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(41, 40, 194, 210, 152, 55, 22, 225, 173, 129, 212, 93, 104, 39, 18), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCultivateSystemOpen"] = function(_ARG_0_)
    do
      if _ARG_0_ then
        ShowNotice(285000)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsActionManualSystemOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(37, 42, 197, 207, 146, 43, 48, 211, 163, 159, 196, 95, 104, 36, 20, 56, 218, 38, 173, 224), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsConsoleGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(39, 38, 223, 213, 146, 41, 10, 225, 165, 132, 216, 87, 82, 20, 11, 45, 209, 23, 158, 250, 123), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsRPGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(54, 57, 238, 193, 136, 44, 11, 219, 157, 158, 193, 86, 89, 20, 8, 43), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSouvenirsGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(55, 38, 196, 208, 152, 43, 6, 204, 177, 174, 214, 70, 94, 47, 1, 2, 219, 9, 164, 248, 82, 25, 105), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWarPresetGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(51, 40, 195, 249, 141, 55, 10, 205, 167, 133, 238, 84, 66, 34, 0, 56, 235, 22, 177, 243, 99, 42, 115, 248), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsBagExtendGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(38, 40, 214, 249, 152, 61, 27, 219, 172, 149, 238, 84, 66, 34, 0, 56, 235, 22, 177, 243, 99, 42, 115, 248), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAffixOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(37, 47, 215, 207, 133, 26, 0, 206, 167, 159, 238, 95, 65), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsRnakOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(54, 40, 223, 205, 162, 42, 31, 219, 172, 174, 221, 69), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsRepairGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(54, 44, 193, 199, 148, 55, 48, 217, 183, 152, 213, 86, 104, 36, 20, 56, 218, 38, 173, 224), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInsuranceGuideOpen"] = function(_ARG_0_)
    do
      do return IsSubSystemOpen(U1(45, 39, 194, 211, 143, 36, 1, 221, 167, 174, 222, 67, 82, 37, 59, 49, 194), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSubSystemOpen"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), _ARG_0_) then
        return false
      end
      if _ARG_1_ and (tonumber(U2.prestige_level) or 0) < tonumber(CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), _ARG_0_).value) then
      end
      do return (tonumber(U2.prestige_level) or 0) >= tonumber(CDataTable.GetTableData(U1(16, 49, 252, 207, 142, 54, 6, 209, 172, 180, 201, 71, 69, 42), _ARG_0_).value) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInXMission"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return false
      end
      if _ARG_0_ == nil then
        _ARG_0_ = false
      end
      if _ARG_0_ and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_entrance):IsTxMissionOpen() then
        return false
      end
      if U1 then
        log(bWriteLog and table.concat({
          U2(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 32, 162, 207, 115, 61, 66, 247),
          U2(55, 58, 216, 201, 147, 116, 67, 158, 182, 131, 196, 86, 25, 107)
        }))
        return true
      end
      log(bWriteLog and table.concat({
        U2(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 32, 162, 207, 115, 61, 66, 247),
        U2(55, 58, 216, 201, 147, 119, 79, 158, 175, 148, 197, 65, 88, 20, 16, 56, 213, 20, 158, 240, 97, 20, 120)
      }), U3.teamInfo and U3.teamInfo.metro_team_flag)
      if U3.teamInfo and U3.teamInfo.metro_team_flag and U3.GetTeamNum() > 1 then
        log(bWriteLog and table.concat({
          U2(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 32, 162, 207, 115, 61, 66, 247),
          U2(55, 58, 216, 201, 147, 119, 67, 158, 182, 131, 196, 86, 25, 107)
        }))
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInPureXMissionLobby"] = function()
    if not IsInXMission() then
      return false
    end
    goto lbl_19
    if U1.UIManager.IsUIShow((nil).uiconfig) then
      return false
    end
    ::lbl_19::
    do return true end
    return
  end,
  ["GetZoneList"] = function()
    goto lbl_69
    if CDataTable.GetTableData(U1(30, 38, 223, 195, 190, 42, 1, 216, 171, 150), (49).zone_id) then
    end
    ::lbl_69::
    do return {} end
    return
  end,
  ["ReconnectXMission"] = function()
    if IsWoWEditor then
      return
    end
    return
  end,
  ["EnterXMissionByInvite"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(31, 44, 213, 209, 156, 55, 11, 227, 153, 157, 222, 84, 94, 40, 59, 37, 217, 16, 178, 229, 100, 26, 113, 209, 191, 128, 200, 77, 122, 123, 56, 34, 195, 0, 178, 210, 101, 40, 102, 237),
        U1(55, 32, 222, 200, 176, 36, 6, 208, 236, 180, 223, 71, 82, 57, 60, 16, 221, 10, 178, 255, 98, 27, 93, 247, 155, 143, 215, 74, 83, 62)
      }))
      if IsWoWEditor then
        return
      end
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if not _ARG_0_ then
        return
      end
      if not _ARG_0_.metro_team_flag then
        log(bWriteLog and table.concat({
          U1(31, 44, 213, 209, 156, 55, 11, 227, 153, 157, 222, 84, 94, 40, 59, 37, 217, 16, 178, 229, 100, 26, 113, 209, 191, 128, 200, 77, 122, 123, 56, 34, 195, 0, 178, 210, 101, 40, 102, 237),
          U1(55, 32, 222, 200, 176, 36, 6, 208, 236, 180, 223, 71, 82, 57, 60, 16, 221, 10, 178, 255, 98, 27, 93, 247, 155, 143, 215, 74, 83, 62, 88, 109, 201, 12, 165, 244, 114, 58, 123, 251),
          U1(37, 36, 238, 192, 145, 36, 8, 158, 255, 209, 215, 82, 91, 56, 1)
        }))
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):IsRestrictBatlleAll() then
        return
      end
      if not require((table.concat({
        U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
        U1(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213)
      }))).CheckDevice() then
        return
      end
      if U3 then
        if U2.teamInfo and U2.teamInfo.members then
          goto lbl_599
          if tonumber(U1(43, 39, 238, 210, 152, 36, 2)) ~= U2.GetSelfUID() then
          end
          ::lbl_599::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        return
      end
      if _ARG_0_.reconnect and tonumber(_ARG_0_.reconnect) == 1 then
      else
      end
      return
    end
  end,
  ["EnterXMissionSuccess"] = function()
    log(bWriteLog and U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 211, 99, 1, 122, 252, 138, 172, 200, 80, 84, 50, 27, 35, 247, 28, 178, 229, 120, 22, 124))
    U2 = true
    return
  end,
  ["QuitXMission"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if LobbySystem.isInMatch then
        ShowNotice(110017)
        return
      end
      if GameStatus.IsInFightingPHomeMode() then
        return
      end
      if not require((table.concat({
        U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
        U1(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213)
      }))).CheckResHasDownloaded() then
      else
      end
      if 1 < U3.GetTeamNum() then
        if U3.IsTeamLeader() then
          if _ARG_2_ then
          else
          end
        elseif _ARG_2_ then
        else
        end
      elseif _ARG_0_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QuitXMissionByJoinTeam"] = function(_ARG_0_)
    do
      waitJoinTeamUID = _ARG_0_
      QuitXMission(true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["QuitXMissionLocal"] = function()
    log(bWriteLog and U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 199, 120, 28, 107, 214, 159, 136, 210, 80, 78, 52, 26, 1, 203, 10, 176, 234))
    U2.CancelXMissionLobbySceneSwitch((U1(53, 60, 216, 210, 162, 41, 0, 221, 163, 157)))
    U3 = false
    return
  end,
  ["QuitXMissionSuccess"] = function()
    log(bWriteLog and U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 199, 120, 28, 107, 214, 159, 136, 210, 80, 78, 52, 26, 30, 209, 10, 178, 227, 110, 22))
    U2 = false
    return
  end,
  ["ChangeTeamType"] = function(_ARG_0_)
    do
      U2.banWindowShow = true
      if not U2.banWindowShowTimer then
        U2.banWindowShowTimer = require((U1(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimerOnce(3, function()
          banWindowShow = false
          U1.RemoveTimer(banWindowShowTimer)
          banWindowShowTimer = nil
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnQuitTeamAndNext"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      if _ARG_2_ == E_QUIT_TYPE.EnterXMission then
        if U1.require((U1.table.concat({
          U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
          U2(43, 39, 238, 200, 152, 50, 13, 215, 167, 174, 215, 95, 88, 60)
        }))).ConsumePendingNewbieAfterQuit() then
          return
        end
      elseif _ARG_2_ == E_QUIT_TYPE.QuitXMission then
        U3.SendExitXMissionReq()
      end
      do return end
      _ARG_1_ = _ENV[43]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCameraSwitched"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if require((U1(39, 37, 216, 195, 147, 49, 65, 221, 173, 156, 220, 92, 89, 101, 17, 52, 235, 12, 181, 255, 97))).GetGameInstance():GetDeviceLevel() > 0 then
        return
      end
      if not UIManager.IsUIShow(UIManager.UI_Config.loading) then
        return
      end
      if _ARG_2_ ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module).Enum_CameraID.Lobby_Default then
        return
      end
      if not U2.quitTLobbyLoadingTimer then
        return
      end
      U2.quitTLobbyLoadingTimer = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitData"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(bWriteLog and table.concat({
        U1(31, 34, 218, 204, 149, 48, 14, 208, 165, 172, 145, 127, 88, 44, 13, 62, 224, 1, 140, 255, 126, 6, 118, 225, 188, 172, 192, 74, 73, 117, 61, 35, 205, 29, 149, 231, 105, 4, 47, 250),
        U1(33, 57, 222, 210, 162, 38, 14, 206, 163, 146, 216, 71, 78)
      }), _ARG_0_)
      log_tree(bWriteLog and table.concat({
        U1(31, 34, 218, 204, 149, 48, 14, 208, 165, 172, 145, 127, 88, 44, 13, 62, 224, 1, 140, 255, 126, 6, 118, 225, 188, 172, 192, 74, 73, 117, 61, 35, 205, 29, 149, 231, 105, 4, 47, 243),
        U1(33, 61, 195, 201)
      }), _ARG_1_)
      if _ARG_1_ then
        if _ARG_1_.profit then
          U2.metro_cur_profit = _ARG_1_.profit.cur_value or 0
          U2.profit_awards = _ARG_1_.profit.awards or {}
          U2.metro_max_profit = _ARG_1_.profit.max_value or 0
        else
          U2.metro_cur_profit = 0
          U2.profit_awards = {}
          U2.metro_max_profit = 0
        end
        U2.prestige = _ARG_1_.prestige or 0
        U2.prestige_level = _ARG_1_.prestige_level or 1
        U2.moneys = _ARG_1_.moneys or {}
        if _ARG_1_.mastery and _ARG_1_.mastery.total_point then
          U2.totalTalentPoint = _ARG_1_.mastery.total_point
        end
        if _ARG_1_.npc then
        else
        end
        U2.bHasGetBaseInfo = true
        U2.mastery_over_granted = _ARG_1_.mastery_over_granted or 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DestroyData"] = function()
    metro_cur_profit = 0
    metro_max_profit = 0
    profit_awards = {}
    prestige = 0
    prestige_level = 1
    moneys = {}
    has_auto_show_warpre = false
    entry_ui = nil
    entry_actor = nil
    bHasGetBaseInfo = false
    waitJoinTeamUID = nil
    BattleResultReason = false
    return
  end,
  ["GetMoney"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or MONEY_ID_GOLD_FASTENER
      if moneys and moneys[MONEY_ID_GOLD_FASTENER] and U1.tonumber(moneys[MONEY_ID_GOLD_FASTENER]) > 0 then
        return U1.tonumber(moneys[MONEY_ID_GOLD_FASTENER]) or 0
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTicket"] = function()
    do return (require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 80, 58, 6, 61, 214, 12, 255, 234, 114, 2, 102, 253),
      U1(27, 49, 220, 207, 142, 54, 6, 209, 172, 174, 198, 82, 69, 59, 22, 56)
    }))).GetItemNumByItemId(U2.TPLAN_TICKET_ID, true)) end
    return
  end,
  ["CanAffordCost"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_1_ = _ARG_1_ or 0
      if _ARG_1_ > (GetMoney(_ARG_0_) or 0) then
        return false
      else
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWorth"] = function()
    do return (require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
      U1(43, 39, 238, 210, 152, 36, 2)
    }))).GetTeamInfoMetroWorthByUid((tostring(DataMgr.roleData.uid)))) end
    return
  end,
  ["GetCurProfit"] = function()
    do return metro_cur_profit end
    return
  end,
  ["GetMaxProfit"] = function()
    do return metro_max_profit end
    return
  end,
  ["GetPrestigeLevel"] = function()
    do return prestige_level or 0 end
    return
  end,
  ["GetProfitAwards"] = function()
    do return profit_awards or {} end
    return
  end,
  ["ShowOrHidePanel"] = function(_ARG_0_)
    do
      if GameStatus.GetGameStatus() ~= GameStatus.Lobby then
        return
      end
      if Client.IsWindowOB() then
        _ARG_0_ = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckReEnterGame"] = function()
    if LobbySystem.enterGameTimeOutParams then
      log(bWriteLog and table.concat({
        U1(31, 44, 213, 209, 156, 55, 11, 227, 153, 157, 222, 84, 94, 40, 59, 37, 217, 16, 178, 229, 100, 26, 113, 209, 191, 128, 200, 77, 122, 123, 56, 34, 195, 0, 178, 210, 101, 40, 102, 237),
        U1(55, 32, 222, 200, 176, 36, 6, 208, 248, 178, 217, 86, 84, 32, 54, 56, 241, 23, 181, 243, 127, 50, 126, 227, 183, 205, 129, 87, 78, 54, 17, 109, 203, 28, 165, 166, 112, 22, 104, 190),
        U1(38, 38, 201)
      }))
      UnrealNet.HandleNetworkException(table.unpack(LobbySystem.enterGameTimeOutParams))
      return true
    end
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).PendingReEnterInfo then
      return true
    end
    do return false end
    return
  end,
  ["CheckShowLevelUp"] = function()
    if levelUpData then
      oldPrestigeLevel = levelUpData.old_prestige_level
      levelUpData = nil
      return true
    end
    levelUpData = nil
    do return false end
    return
  end,
  ["IsLuckyEggItem"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return false
      end
      do return require((table.concat({
        U1(3, 40, 220, 195, 177, 48, 14, 144, 143, 158, 213, 29, 123, 34, 6, 47, 213, 11, 184, 184, 74, 20, 114, 235, 130, 141, 192, 90, 9, 18, 0, 40, 201, 26, 255, 202, 104, 6, 100, 231),
        U1(1, 46, 214, 136, 177, 48, 12, 213, 187, 180, 214, 84, 116, 36, 10, 59, 221, 30)
      }))) and require((table.concat({
        U1(3, 40, 220, 195, 177, 48, 14, 144, 143, 158, 213, 29, 123, 34, 6, 47, 213, 11, 184, 184, 74, 20, 114, 235, 130, 141, 192, 90, 9, 18, 0, 40, 201, 26, 255, 202, 104, 6, 100, 231),
        U1(1, 46, 214, 136, 177, 48, 12, 213, 187, 180, 214, 84, 116, 36, 10, 59, 221, 30)
      }))).GetLuckyEggItemIDSet() and (require((table.concat({
        U1(3, 40, 220, 195, 177, 48, 14, 144, 143, 158, 213, 29, 123, 34, 6, 47, 213, 11, 184, 184, 74, 20, 114, 235, 130, 141, 192, 90, 9, 18, 0, 40, 201, 26, 255, 202, 104, 6, 100, 231),
        U1(1, 46, 214, 136, 177, 48, 12, 213, 187, 180, 214, 84, 116, 36, 10, 59, 221, 30)
      }))) and require((table.concat({
        U1(3, 40, 220, 195, 177, 48, 14, 144, 143, 158, 213, 29, 123, 34, 6, 47, 213, 11, 184, 184, 74, 20, 114, 235, 130, 141, 192, 90, 9, 18, 0, 40, 201, 26, 255, 202, 104, 6, 100, 231),
        U1(1, 46, 214, 136, 177, 48, 12, 213, 187, 180, 214, 84, 116, 36, 10, 59, 221, 30)
      }))).GetLuckyEggItemIDSet())[_ARG_0_] == true or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowSpecialCollection"] = function()
    log(bWriteLog and table.concat({
      U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 213, 101, 16, 124, 229, 129, 137, 206, 84, 116, 43, 17, 46, 205, 8, 189, 197, 114, 9, 99, 251),
      U1(39, 61, 216, 201, 147)
    }))
    log_tree(bWriteLog and table.concat({
      U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 213, 101, 16, 124, 229, 129, 137, 206, 84, 116, 43, 17, 46, 205, 8, 189, 197, 114, 9, 99, 251),
      U1(39, 61, 216, 201, 147, 101, 3, 215, 177, 133, 140)
    }), U2.SpecialCollectionList)
    if U2.SpecialCollectionList then
      goto lbl_264
      if U2.IsLuckyEggItem(U1(39, 61, 216, 201, 147, 101, 3, 215, 177, 133, 140).item_id) then
      else
      end
      ::lbl_264::
      if next({}) then
        goto lbl_449
        if CDataTable.GetTableData(U1(13, 61, 212, 203), table.insert({}, U1(39, 61, 216, 201, 147, 101, 3, 215, 177, 133, 140)).item_id) then
        end
        ::lbl_449::
      end
    end
    U2.SpecialCollectionList = nil
    return
  end,
  ["CancelTeamPlatformRecruit"] = function()
    return
  end,
  ["CancelMentorWaiting"] = function()
    if require((U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 172, 243, 99, 1, 112, 252, 252, 141, 206, 68, 78, 56, 43, 32, 193, 7, 165, 233, 111))).waiting_status == require((U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 172, 243, 99, 1, 112, 252, 252, 141, 206, 68, 78, 56, 43, 32, 193, 7, 165, 233, 111))).EWaitingStatus.Wait then
    end
    return
  end,
  ["SendEnterXMissionReq"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 197, 104, 27, 123, 203, 188, 149, 196, 81, 127, 22, 29, 62, 215, 0, 190, 232, 79, 0, 126, 190),
        U1(34, 59, 222, 203, 192, 96, 28, 158, 174, 158, 211, 81, 78, 24, 7, 56, 218, 28, 149, 239, 125, 16, 34, 171, 161)
      }), tostring(_ARG_0_), tostring(_ARG_1_)))
      if U2.pendingLobbySceneSwitch then
        return
      end
      if _ARG_1_ ~= nil then
      else
      end
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        return
      end
      U2.banWindowShow = true
      if not U2.banWindowShowTimer then
        U2.banWindowShowTimer = require((U1(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimerOnce(3, function()
          banWindowShow = false
          U1.RemoveTimer(banWindowShowTimer)
          banWindowShowTimer = nil
          return
        end)
      end
      U2.bEnterXMissionReq = true
      if not U2.EnterXMissionReqTimer then
        U2.EnterXMissionReqTimer = require((U1(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimerOnce(3, function()
          bEnterXMissionReq = false
          U1.RemoveTimer(EnterXMissionReqTimer)
          EnterXMissionReqTimer = nil
          return
        end)
      end
      if _ARG_0_ ~= U1(54, 44, 210, 201, 147, 43, 10, 221, 182) and _ARG_0_ ~= U1(34, 32, 214, 206, 137) and _ARG_0_ ~= U1(48, 44, 208, 203) and _ARG_0_ ~= U1(45, 39, 199, 207, 137, 32) then
      end
      U2.SendEnterXMissionFrom = _ARG_0_ or U1()
      _ARG_0_ = _ARG_0_ or U1(42, 32, 221)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendExitXMissionReq"] = function(_ARG_0_)
    do
      CancelXMissionLobbySceneSwitch((U1(55, 44, 223, 194, 162, 32, 23, 215, 182, 174, 195, 86, 70, 62, 1, 46, 192)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckCultivateRedPoint"] = function()
    log(bWriteLog and table.concat({
      U1(31, 42, 198, 251, 221, 9, 0, 217, 171, 146, 229, 75, 122, 34, 23, 46, 221, 22, 175, 219, 108, 28, 113, 160, 145, 137, 196, 64, 76, 24, 1, 33, 208, 0, 167, 231, 105, 0, 93, 251),
      U1(32, 25, 222, 207, 147, 49, 79)
    }))
    return
  end,
  ["IsMaxPrestigeLevel"] = function()
    if not C_MaxPrestigeLevel then
      C_MaxPrestigeLevel = 0
      goto lbl_75
      if 0 <= U1.require((U2(39, 37, 216, 195, 147, 49, 65, 221, 173, 156, 220, 92, 89, 101, 18, 56, 198, 10, 168, 249, 99, 42, 106, 250, 187, 141))).CompareVersionMain(U1.require((U2(39, 37, 216, 195, 147, 49, 65, 221, 173, 156, 220, 92, 89, 101, 18, 56, 198, 10, 168, 249, 99, 42, 106, 250, 187, 141))).GetClientFormat(U1.Client.GetAppVersion()), U1.Client.GetAppVersion().OpenVersion) then
        C_MaxPrestigeLevel = U1.math.max(U1.Client.GetAppVersion().Level, C_MaxPrestigeLevel)
      end
      ::lbl_75::
      if not C_MaxPrestigeLevel or C_MaxPrestigeLevel == 0 then
        C_MaxPrestigeLevel = 45
      end
    end
    do return prestige_level >= C_MaxPrestigeLevel end
    return
  end,
  ["SetShadowQuality"] = function(_ARG_0_, _ARG_1_)
    do
      if import((U1(15, 32, 194, 203, 152, 49, 60, 199, 177, 133, 212, 94, 123, 34, 6, 47, 213, 11, 184))).GetConsoleVariableIntValue((U1(54, 103, 252, 201, 159, 44, 3, 219, 236, 189, 222, 68, 115, 46, 18, 52, 215, 28))) == 1 then
        if _ARG_1_ then
          U2.BackupShadowQuality = import((U1(15, 32, 194, 203, 152, 49, 60, 199, 177, 133, 212, 94, 123, 34, 6, 47, 213, 11, 184))).GetConsoleVariableIntValue((U1(54, 103, 226, 206, 156, 33, 0, 201, 147, 132, 208, 95, 94, 63, 29)))
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = ExecuteConsoleCommand
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterXMissionRsp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 217, 99, 48, 113, 250, 183, 147, 249, 110, 78, 40, 7, 36, 203, 7, 131, 245, 109))
      log_tree(table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 217, 99, 48, 113, 250, 183, 147, 249, 110, 78, 40, 7, 36, 203, 7, 131, 245, 109, 69, 98, 251),
        U1(48, 59, 222, 249, 142, 38, 10, 208, 167, 174, 213, 82, 67, 42, 94)
      }), _ARG_0_)
      log_format(table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 251, 217, 99, 48, 113, 250, 183, 147, 249, 110, 78, 40, 7, 36, 203, 7, 131, 245, 109, 69, 106, 240),
        U1(48, 44, 195, 138, 221, 35, 29, 209, 175, 203, 148, 64, 27, 107, 13, 46, 240, 22, 182, 248, 97, 26, 126, 234, 129, 137, 206, 84, 29, 126, 7, 97, 132, 0, 162, 212, 120, 6, 96, 243),
        U1(41, 44, 223, 194, 185, 32, 3, 219, 182, 148, 226, 91, 88, 60, 94, 120, 199, 85, 225, 255, 126, 45, 114, 231, 161, 146, 200, 76, 73, 22, 21, 36, 202, 58, 185, 233, 106, 95, 42, 237)
      }), tostring(U2.SendEnterXMissionFrom), tostring(UIManager.IsUIShow(UIManager.UI_Config.Download_Main_UIBP)), tostring(UIManager.IsUIShow(UIManager.UI_Config.notify_recommend_delete)), tostring(UIManager.IsUIShow(UIManager.UI_Config.xmission_main)))
      LobbySystem.roleData.is_in_metro = true
      LobbySystem.roleData.metro_lobby_type = U2.GetMetroLobbyType()
      U2.bEnterXMissionReq = false
      if not U2.MountXMissionPak() then
        return
      end
      if GameStatus.IsInMainCityConnectDs() then
        if require((table.concat({
          U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 173, 249, 111, 23, 102, 160, 159, 128, 200, 77, 100, 50, 0, 52, 138, 37, 190, 228, 127, 28, 80, 211),
          U1(37, 32, 223, 249, 190, 44, 27, 199, 157, 180, 223, 71, 82, 57)
        }))).bConnectDS then
        end
      end
      U3 = true
      if UIManager.IsUIShow(UIManager.UI_Config.xmission_main) then
        if UIManager.IsUIShow(UIManager.UI_Config.setting_main) then
          return
        end
        if UIManager.IsUIShow(UIManager.UI_Config.Xmission_Room_UIBP) then
          return
        end
        if U2.SendEnterXMissionFrom == U1(54, 44, 210, 201, 147, 43, 10, 221, 182) then
          if UIManager.IsUIShow(UIManager.UI_Config.ActivityCenter_Main_UIBP) then
            return
          end
          if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ui_navigation_manager):IsHavePandoraUI() then
            return
          end
        end
        return
      end
      if not U2.IsLobby2D() and U2.SendEnterXMissionFrom == U1(34, 32, 214, 206, 137) then
      else
      end
      if not U2.enterTimer then
        U2.enterTimer = require((U1(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimer(0, function()
          if U1.UIManager.GetUI(U1.UIManager.UI_Config.xmission_download) then
            U1.UIManager.GetUI(U1.UIManager.UI_Config.xmission_download).waitForEnter = true
          end
          if not (U1.require((U1.table.concat({
            U2(39, 37, 216, 195, 147, 49, 65, 210, 173, 150, 216, 80, 25, 7, 11, 58, 221, 26, 145, 250, 108, 12, 122, 252, 130, 147, 196, 69, 84, 117, 4, 33, 197, 16, 180, 244, 109, 23, 106, 248),
            U2(55)
          }))).LoadFileToTable_N(U1.require((U1.table.concat({
            U2(39, 37, 216, 195, 147, 49, 65, 210, 173, 150, 216, 80, 25, 7, 11, 58, 221, 26, 145, 250, 108, 12, 122, 252, 130, 147, 196, 69, 84, 117, 4, 33, 197, 16, 180, 244, 109, 23, 106, 248),
            U2(55)
          }))).ePlayerPrefsType.eXMissionEnter) or {}).enter then
            ;(U1.require((U1.table.concat({
              U2(39, 37, 216, 195, 147, 49, 65, 210, 173, 150, 216, 80, 25, 7, 11, 58, 221, 26, 145, 250, 108, 12, 122, 252, 130, 147, 196, 69, 84, 117, 4, 33, 197, 16, 180, 244, 109, 23, 106, 248),
              U2(55)
            }))).LoadFileToTable_N(U1.require((U1.table.concat({
              U2(39, 37, 216, 195, 147, 49, 65, 210, 173, 150, 216, 80, 25, 7, 11, 58, 221, 26, 145, 250, 108, 12, 122, 252, 130, 147, 196, 69, 84, 117, 4, 33, 197, 16, 180, 244, 109, 23, 106, 248),
              U2(55)
            }))).ePlayerPrefsType.eXMissionEnter) or {}).enter = true
          end
          U3.enterTimer = nil
          return
        end)
      end
      U2.rate_up_data = _ARG_1_
      do return end
      _ARG_1_ = U1[108]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MountXMissionPak"] = function(_ARG_0_, _ARG_1_)
    do
      if _G.IsEditor then
        return true
      end
      if _ARG_0_ then
        goto lbl_97
        if U1(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213) == _ARG_0_ then
        else
          ::lbl_97::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if not true then
        end
      end
      goto lbl_117
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_map_manager):MountMapPak(U1(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213)) then
        return false
      end
      ::lbl_117::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterXMissionLoading"] = function(_ARG_0_)
    do
      if U2.teamInfo and U2.teamInfo.members then
        goto lbl_229
        if tonumber(38) ~= U2.GetSelfUID() then
        end
        ::lbl_229::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if UIManager.IsUIShow(UIManager.UI_Config.xmission_main) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeTeamTypeRsp"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ == 0 then
        return
      end
      if _ARG_0_ ~= U2.teamInfo.id then
        log_warning(table.concat({
          U1(31, 44, 213, 209, 156, 55, 11, 227, 153, 189, 222, 84, 94, 40, 48, 37, 249, 16, 178, 229, 100, 26, 113, 195, 179, 136, 207, 126, 7, 3, 57, 36, 215, 26, 184, 233, 115, 54, 118, 237),
          U1(48, 44, 220, 136, 178, 43, 44, 214, 163, 159, 214, 86, 99, 46, 5, 48, 224, 0, 177, 243, 95, 6, 111, 162, 242, 149, 196, 66, 74, 18, 48, 109, 205, 26, 241, 232, 114, 17, 47, 243),
          U1(37, 61, 210, 206, 209, 101, 27, 219, 163, 156, 238, 90, 83, 107, 89, 125)
        }) .. _ARG_0_ .. U1(104, 105, 222, 214, 137, 101, 82, 158) .. _ARG_1_)
        return
      end
      if _ARG_1_ == U3.L2X then
        log(bWriteLog and table.concat({
          U1(31, 44, 213, 209, 156, 55, 11, 227, 153, 189, 222, 84, 94, 40, 48, 37, 249, 16, 178, 229, 100, 26, 113, 195, 179, 136, 207, 126, 7, 3, 57, 36, 215, 26, 184, 233, 115, 54, 118, 237),
          U1(48, 44, 220, 136, 178, 43, 44, 214, 163, 159, 214, 86, 99, 46, 5, 48, 224, 0, 177, 243, 95, 6, 111, 174, 177, 137, 192, 77, 64, 62, 84, 57, 221, 25, 180, 166, 44, 69, 124, 235),
          U1(39, 42, 212, 213, 142, 100, 78, 159)
        }))
        EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_CHANGE_TEAM_TYPE)
      elseif _ARG_1_ == U3.X2L then
        log(bWriteLog and table.concat({
          U1(31, 44, 213, 209, 156, 55, 11, 227, 153, 189, 222, 84, 94, 40, 48, 37, 249, 16, 178, 229, 100, 26, 113, 195, 179, 136, 207, 126, 7, 3, 57, 36, 215, 26, 184, 233, 115, 54, 118, 237),
          U1(48, 44, 220, 136, 178, 43, 44, 214, 163, 159, 214, 86, 99, 46, 5, 48, 224, 0, 177, 243, 95, 6, 111, 174, 177, 137, 192, 77, 64, 62, 84, 57, 221, 25, 180, 166, 47, 69, 124, 235),
          U1(39, 42, 212, 213, 142, 100, 78, 159)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[166]
    end
  end,
  ["OnQuitXMissionLoading"] = function(_ARG_0_)
    do
      if not IsInXMission() or not U1.UIManager.IsUIShow(U1.UIManager.UI_Config.xmission_main) then
        return false
      end
      if IsEnterXMissionFromScroll() and U1.require((U1.table.concat({
        U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 173, 249, 111, 23, 102, 160, 159, 128, 200, 77, 9, 23, 27, 47, 198, 16, 142, 203, 124, 12, 97, 193),
        U2(7, 38, 223, 210, 143, 42, 3)
      }))).ReturnFromTLobbyToPage == nil then
        U1.require((U1.table.concat({
          U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 173, 249, 111, 23, 102, 160, 159, 128, 200, 77, 9, 23, 27, 47, 198, 16, 142, 203, 124, 12, 97, 193),
          U2(7, 38, 223, 210, 143, 42, 3)
        }))).ReturnFromTLobbyToPage = U1.ENUM_LobbyPageType.Mid
      end
      if waitForLoadingCallback then
        return true
      end
      waitForLoadingCallback = true
      ShowLobbyTransition(false)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnQuitXMission"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 217, 99, 36, 106, 231, 166, 185, 236, 74, 84, 40, 29, 34, 202, 71, 241, 227, 101, 12, 123, 193),
        U1(54, 44, 208, 213, 146, 43, 82, 155, 177)
      }), tostring(_ARG_0_)))
      LobbySystem.roleData.is_in_metro = false
      LobbySystem.roleData.metro_lobby_type = nil
      if not UIManager.GetUI(UIManager.UI_Config.xmission_main) then
        log_error((table.concat({
          U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 217, 99, 36, 106, 231, 166, 185, 236, 74, 84, 40, 29, 34, 202, 73, 163, 227, 105, 16, 125, 240),
          U1(100, 43, 212, 197, 156, 48, 28, 219, 226, 156, 208, 90, 89, 107, 49, 20, 148, 23, 174, 226, 45, 19, 112, 251, 188, 133)
        })))
        return
      end
      if U2.OnQuitXMissionLoading(_ARG_0_) then
        return
      end
      U2.OnQuitXMissionToLobby(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnQuitXMissionToLobby"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or _ENV()
      U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_ON_QUIT_PLAN_TNOTIFY)
      U1.log(U1.bWriteLog and U1.table.concat({
        _ENV(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 38, 191, 215, 104, 12, 123, 198),
        _ENV(9, 32, 194, 213, 148, 42, 1)
      }))
      U2 = false
      if U3.teamInfo then
        U3.teamInfo.metro_team_flag = false
      end
      if U1.UIManager.GetUI(U1.UIManager.UI_Config.xmission_main) then
        if U1.require((_ENV(39, 37, 216, 195, 147, 49, 65, 221, 173, 156, 220, 92, 89, 101, 17, 52, 235, 12, 181, 255, 97))).GetGameInstance():GetDeviceLevel() == 0 and U4.IsLobby2D() then
          if not U4.quitTLobbyLoadingTimer then
            U4.quitTLobbyLoadingTimer = U1.require((_ENV(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimerOnce(20, function()
              RefreshLoadPercent(1)
              U1.RemoveTimer(1)
              return
            end)
          end
        else
        end
      end
      if _ARG_0_ and _ARG_0_ ~= _ENV(55, 44, 208, 213, 146, 43, 48, 205, 181, 152, 197, 80, 95) then
      end
      U4.waitJoinTeamUID = nil
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.level_unlock_manager):NeedShowLevelup() then
        if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.NewFaceSlapSystem):IsInSlap() then
        else
        end
      end
      if U4.SendEnterXMissionFrom ~= _ENV(54, 44, 210, 201, 147, 43, 10, 221, 182) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_metro_info_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      InitData(_ARG_0_, _ARG_1_)
      if (_ARG_1_ and _ARG_1_.pve_newbie_game_status) ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_metro_profit_ntfy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      metro_cur_profit = _ARG_2_ or 0
      metro_max_profit = _ARG_3_ or 0
      U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_T_METRO_WORTH_NOTIFY)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTakeWorthAward"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_ == 0 then
        if _ARG_1_ then
          if not U2.profit_awards then
            U2.profit_awards = {}
          end
          U2.profit_awards[_ARG_1_] = 1
        end
        EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_TAKE_WORTH_AWARD)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveAllSettlementGift"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_ == 0 then
        if _ARG_1_ and next(_ARG_1_) then
          U2.profit_awards = _ARG_1_
        end
        EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_TAKE_WORTH_AWARD)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_metro_money_ntfy"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      moneys = moneys or {}
      moneys[_ARG_0_] = _ARG_1_
      U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_T_METRO_MONEY_NOTIFY)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPrestigeChangeNotify"] = function(_ARG_0_, _ARG_1_)
    do
      prestige = _ARG_0_
      prestige_level = _ARG_1_ or 1
      U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_PRESITGE_NOTIFY)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPrestigeLevelChangeNotify"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if UIManager.IsUIShow(UIManager.UI_Config.loading) then
        if U1.levelUpData then
          U1.levelUpData.new_prestige_level = _ARG_1_
          goto lbl_24
          ::lbl_24::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
          U1.levelUpData = {
            old_prestige_level = _ARG_0_,
            new_prestige_level = _ARG_1_,
            award_list = _ARG_2_
          }
        end
      else
        if not GameStatus.IsInLobbyOrMainCity() then
          return
        end
        if not U1.IsInXMission() then
          return
        end
        U1.oldPrestigeLevel = _ARG_0_
        UIManager.ShowUI(UIManager.UI_Config.xmission_levelup, _ARG_0_, _ARG_1_, _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_metro_collection_get_red_point_rsp"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(31, 42, 198, 251, 221, 9, 0, 217, 171, 146, 229, 75, 122, 34, 23, 46, 221, 22, 175, 219, 108, 28, 113, 160, 189, 143, 254, 78, 66, 47, 6, 34, 251, 10, 190, 234, 113, 0, 108, 234),
        U1(45, 38, 223, 249, 154, 32, 27, 225, 176, 148, 213, 108, 71, 36, 13, 51, 192, 38, 179, 229, 125, 93)
      }) .. tostring(_ARG_0_) .. U1(109, 105))
      EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_STORY_ENTRY_RED_POINT_CHANGE, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AdjustWeightAccuracy"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or 0
      _ARG_0_ = _ARG_0_ + FLOAT_NUMBER_TRAIL
      _ARG_0_ = math.modf(_ARG_0_ * 1000)
      _ARG_0_ = _ARG_0_ / 1000
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideLobbyUI"] = function()
    UIManager.CloseUI(UIManager.UI_Config.xmission_wardrobe)
    UIManager.CloseUI(UIManager.UI_Config.Xmission_Store_NewQuickConfigPopup_UIBP)
    UIManager.CloseUI(UIManager.UI_Config.black_market_buy)
    UIManager.CloseUI(UIManager.UI_Config.xmission_season_main)
    UIManager.CloseUI(UIManager.UI_Config.Xmission_Operation_Main_UIBP)
    UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_UIBP)
    UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_Detail_UIBP)
    UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_Friend_UIBP)
    UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_Friend_Detail_UIBP)
    UIManager.CloseUI(UIManager.UI_Config.Prepare_Bage_Programme_Popup_UIBP)
    EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_CLOSE_MEMBER_DETAIL)
    EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_QUIT_LOBBY)
    return
  end,
  ["JumpOutLobby"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.xmission_wardrobe)
      UIManager.CloseUI(UIManager.UI_Config.Xmission_Store_NewQuickConfigPopup_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.black_market_buy)
      UIManager.CloseUI(UIManager.UI_Config.xmission_season_main)
      UIManager.CloseUI(UIManager.UI_Config.Xmission_Operation_Main_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_Detail_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_Friend_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.Xmission_Souvenirs_Friend_Detail_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.Prepare_Bage_Programme_Popup_UIBP)
      EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_CLOSE_MEMBER_DETAIL)
      EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_JUMP_OUT_LOBBY)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowWardrobeMain"] = function(_ARG_0_)
    do
      UIManager.ShowUI(UIManager.UI_Config.xmission_wardrobe, {from = _ARG_0_})
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpTxMission"] = function()
    return
  end,
  ["OnTalentDataChangeNotify"] = function(_ARG_0_)
    do
      if _ARG_0_ and _ARG_0_.new_total_point and _ARG_0_.new_total_point > 0 then
        totalTalentPoint = _ARG_0_.new_total_point
      end
      mastery_over_granted = _ARG_0_.over_granted
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Create3dUIDisplayActor"] = function(_ARG_0_)
    do
      do return (slua_GameFrontendHUD:GetWorld():SpawnActor(import(_ARG_0_), nil, nil, nil)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHallThemeNeedShowEntry"] = function()
    if U2[require((U1(39, 37, 216, 195, 147, 49, 65, 210, 173, 150, 216, 80, 25, 39, 11, 63, 214, 0, 239, 254, 108, 25, 115, 209, 166, 137, 196, 78, 66, 4, 1, 57, 205, 5, 162))).GetCurShowThemeItemId()] then
      return true
    else
      return false
    end
    return
  end,
  ["Update3DUITransform"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ == nil or not slua.isValid(_ARG_0_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Destroy3dUIDisplayActor"] = function(_ARG_0_)
    do
      if _ARG_0_ and slua.isValid(_ARG_0_) then
        _ARG_0_:K2_DestroyActor()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Show3dUIDisplayActor"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        return nil
      end
      if not _ARG_0_.Widget:GetUserWidgetObject() then
        return nil
      end
      do return (require(_ARG_1_.moduleName)()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCurBattleGuide"] = function(_ARG_0_)
    do
      bCurBattleGuideIsShow = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBattleGuide"] = function()
    if bCurBattleGuideIsShow then
      U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_HIDE_BATTLEGUIDE)
    end
    return
  end,
  ["HadXmissionActivity"] = function()
    do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule):GetDataProxy(ActivityDisplayScene.TxMission) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.ActivityCenterModule):GetDataProxy(ActivityDisplayScene.TxMission):HasAnyData() or false end
    return
  end,
  ["HadXmissionActivityRedDot"] = function()
    do return require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 160, 245, 121, 28, 105, 231, 166, 152, 143, 113, 66, 63, 36, 34, 205, 7, 165, 168, 92, 6, 123, 247),
      U1(50, 32, 197, 223, 175, 32, 11, 250, 173, 133)
    }))).GetRedDotData((require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 160, 245, 121, 28, 105, 231, 166, 152, 143, 113, 66, 63, 36, 34, 205, 7, 165, 168, 92, 6, 123, 247),
      U1(50, 32, 197, 223, 175, 32, 11, 250, 173, 133)
    }))).DisplayScene2SystemName(ActivityDisplayScene.TxMission))) and require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 160, 245, 121, 28, 105, 231, 166, 152, 143, 113, 66, 63, 36, 34, 205, 7, 165, 168, 92, 6, 123, 247),
      U1(50, 32, 197, 223, 175, 32, 11, 250, 173, 133)
    }))).GetRedDotData((require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 160, 245, 121, 28, 105, 231, 166, 152, 143, 113, 66, 63, 36, 34, 205, 7, 165, 168, 92, 6, 123, 247),
      U1(50, 32, 197, 223, 175, 32, 11, 250, 173, 133)
    }))).DisplayScene2SystemName(ActivityDisplayScene.TxMission))).newCount > 0 end
    return
  end,
  ["JumpToXmissionActivityCenter"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if U1.HadXmissionActivity(_ARG_2_.DisplayScene or ActivityDisplayScene.TxMission) then
        if require((table.concat({
          U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 160, 245, 121, 28, 105, 231, 166, 152, 143, 79, 72, 60, 29, 46, 251, 8, 178, 242, 116, 19, 102, 234),
          U2(61, 22, 220, 193, 143)
        }))).GetActivityByTypeAndLabel(ActivityType.ACTIVITY_TYPE_AREA_GROUP, ActivitySwitchType.Xmission) then
        else
        end
      end
      return
    end
  end,
  ["JumpToXMissionSelectMode"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if GetTeamNum() == 1 or IsTeamLeader() then
        U1.UIManager.ShowUI(U1.UIManager.UI_Config.xMission_Mode_Select, _ARG_2_)
      else
        U1.ShowNotice(U1.LocUtil.LocalizeResFormat(500062))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpToXMissionCultivate"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if IsCultivateSystemOpen(true) then
        U1.EventSystem:postEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_QUIT_LOBBY)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_metro_enter_notify"] = function()
    log(bWriteLog and table.concat({
      U1(31, 36, 196, 207, 153, 36, 29, 196, 170, 144, 223, 84, 106, 107, 40, 50, 211, 16, 162, 194, 117, 56, 118, 253, 161, 136, 206, 77, 106, 58, 29, 35, 138, 6, 191, 217, 112, 0, 123, 236),
      U1(43, 22, 212, 200, 137, 32, 29, 225, 172, 158, 197, 90, 81, 50)
    }))
    log_format(table.concat({
      U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 251, 249, 99, 42, 114, 235, 166, 147, 206, 124, 66, 53, 0, 40, 214, 54, 191, 233, 105, 12, 105, 231),
      U1(100, 59, 212, 197, 146, 43, 1, 219, 161, 133, 145, 86, 89, 63, 22, 36, 152, 89, 163, 211, 99, 1, 122, 252, 138, 172, 200, 80, 84, 50, 27, 35, 246, 12, 160, 188, 56, 22, 35, 190),
      U1(27, 32, 194, 239, 147, 29, 34, 215, 177, 130, 216, 92, 89, 113, 65, 46)
    }), tostring(U2.bEnterXMissionReq), tostring(U3))
    U2.bIsReconnect = true
    U2.Reconnect()
    return
  end,
  ["Reconnect"] = function()
    if bIsReconnect then
      if U1.IsEditor or U1.require((U1.table.concat({
        U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
        U2(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213)
      }))).GetDownloadStateByKeyList(U1.require((U1.table.concat({
        U2(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
        U2(43, 39, 238, 194, 146, 50, 1, 210, 173, 144, 213)
      }))).GetEnterDownloadKeyList()) == U3.ENUM_DownloadState.Done then
        bEnterXMissionReq = true
        bIsReconnect = false
      else
      end
    end
    return
  end,
  ["IsForbiddenUI"] = function(_ARG_0_)
    do
      do return _ARG_0_ and ForbiddenUIConfig[_ARG_0_] == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UINeedChangeBG"] = function(_ARG_0_)
    do
      do return not _ARG_0_ or not UnchangedBGConfig[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowCommandPostReddot"] = function()
    do return command_post_reddot_num > 0 end
    return
  end,
  ["AddCommandPostReddot"] = function()
    command_post_reddot_num = command_post_reddot_num + 1
    U1.log(U1.bWriteLog and U1.table.concat({
      U2(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 213, 98, 24, 114, 239, 188, 133, 241, 76, 84, 47, 38, 40, 192, 13, 190, 242, 61, 11, 122, 243),
      U2(100, 115)
    }) .. command_post_reddot_num)
    return
  end,
  ["DecCommandPostReddot"] = function()
    command_post_reddot_num = command_post_reddot_num - 1
    if command_post_reddot_num <= 0 then
      command_post_reddot_num = 0
    end
    U1.log(U1.bWriteLog and U1.table.concat({
      U2(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 213, 98, 24, 114, 239, 188, 133, 241, 76, 84, 47, 38, 40, 192, 13, 190, 242, 61, 11, 122, 243),
      U2(100, 115)
    }) .. command_post_reddot_num)
    return
  end,
  ["GetPrestigeGuide"] = function(_ARG_0_)
    do
      do return (DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_T_PRESTIGE, _ARG_0_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPrestigeGuide"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 197, 104, 1, 79, 252, 183, 146, 213, 74, 64, 62, 51, 56, 205, 13, 180, 166, 118, 0, 118, 190),
        U1(121, 105)
      }) .. tostring(_ARG_0_) .. U1(100, 105, 199, 199, 145, 48, 10, 158, 255, 209) .. tostring(_ARG_1_))
      DataMgr.SetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_T_PRESTIGE, _ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowNewPrestige470Guide"] = function()
    return
  end,
  ["GetCheckCommandPostGuide"] = function()
    do return bCheckCommandPostLevelExtendGuide end
    return
  end,
  ["GetCommandPostGuideValue"] = function(_ARG_0_)
    do
      do return (DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_CAMMANDPOST_LEVELEXTEND, _ARG_0_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckComaandPostLevelExtendGuide"] = function()
    if not U2.IsCultivateSystemOpen(false) or not require((table.concat({
      U1(39, 37, 216, 195, 147, 49, 65, 205, 174, 132, 208, 29, 91, 36, 3, 52, 215, 87, 149, 238, 64, 28, 108, 253, 187, 142, 207, 13, 75, 52, 19, 36, 199, 54, 169, 235, 116, 22, 124, 247),
      U1(43, 39, 238, 196, 152, 34, 6, 208, 172, 148, 195, 108, 80, 62, 13, 57, 209)
    }))).HaveFinishedBeginnerGuide() then
      return
    end
    if (DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_CAMMANDPOST_LEVELEXTEND, 1) or 1) == 1 and not U2.bCheckCommandPostLevelExtendGuide then
      U2.bCheckCommandPostLevelExtendGuide = true
    end
    do return 1 < (DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_CAMMANDPOST_LEVELEXTEND, 1) or 1) end
    return
  end,
  ["SetCommandPostGuideValue"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(8, 38, 214, 207, 158, 17, 23, 243, 171, 130, 194, 90, 88, 37, 41, 60, 221, 23, 239, 213, 98, 24, 114, 239, 188, 133, 241, 76, 84, 47, 51, 56, 205, 13, 180, 166, 118, 0, 118, 164),
        U1(100)
      }) .. _ARG_0_ .. U1(100, 63, 208, 202, 136, 32, 85, 158) .. _ARG_1_)
      DataMgr.SetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_CAMMANDPOST_LEVELEXTEND, _ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetResetIsInXmissionTimer"] = function()
    ClearResetIsInXmissionTimer()
    timerResetIsInXMission = U1.require((U2(39, 38, 220, 203, 146, 43, 65, 202, 171, 156, 212, 108, 67, 34, 7, 54, 209, 11))).AddTimerOnce(7, function()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LobbyThemeManager) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LobbyThemeManager).bInXMission then
        U2 = false
      end
      U3.timerResetIsInXMission = nil
      return
    end)
    return
  end,
  ["ClearResetIsInXmissionTimer"] = function()
    if not timerResetIsInXMission then
      return
    end
    timerResetIsInXMission = nil
    return
  end,
  ["HasSettingPickUpGuide"] = function()
    if U2.prestige_level < 4 then
      return false
    end
    if (U3.LoadFileToTable_N(U3.ePlayerPrefsType.eXmissionPickupSettingGuide) or {}) and (U3.LoadFileToTable_N(U3.ePlayerPrefsType.eXmissionPickupSettingGuide) or {})[DataMgr.roleData.uid] then
      return false
    end
    do return true end
    return
  end,
  ["SetSettingPickUpGuide"] = function()
    if (LoadFileToTable_N(ePlayerPrefsType.eXmissionPickupSettingGuide) or {}) and (LoadFileToTable_N(ePlayerPrefsType.eXmissionPickupSettingGuide) or {})[U1.DataMgr.roleData.uid] then
      return false
    end
    ;(LoadFileToTable_N(ePlayerPrefsType.eXmissionPickupSettingGuide) or {})[U1.DataMgr.roleData.uid] = true
    do return true end
    return
  end,
  ["HasSettingTeamDressGuide"] = function()
    if (LoadFileToTable_N(ePlayerPrefsType.eXmissionLobbyDressSettingGuide) or {}) and (LoadFileToTable_N(ePlayerPrefsType.eXmissionLobbyDressSettingGuide) or {})[U1.DataMgr.roleData.uid] then
      return false
    end
    do return true end
    return
  end,
  ["SetSettingTeamDressGuide"] = function()
    if (LoadFileToTable_N(ePlayerPrefsType.eXmissionLobbyDressSettingGuide) or {}) and (LoadFileToTable_N(ePlayerPrefsType.eXmissionLobbyDressSettingGuide) or {})[U1.DataMgr.roleData.uid] then
      return false
    end
    ;(LoadFileToTable_N(ePlayerPrefsType.eXmissionLobbyDressSettingGuide) or {})[U1.DataMgr.roleData.uid] = true
    do return true end
    return
  end,
  ["GetCurSelectIndex"] = function()
    do return cur_select_index end
    return
  end,
  ["SetCurSelectIndex"] = function(_ARG_0_)
    do
      cur_select_index = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
