local logic_chat_channel_friend = require("client.slua.logic.lobby_chat.logic_chat_channel_friend")
local ui_chat_member_list_friend = {}

function ui_chat_member_list_friend:ctor()
  self.uidExistListStatus = {}
  self.uidListNeedStatus = {}
  self.timerHandle = nil
  self.firstFriendNum = 10
  self.lasetTime = 0
  self.nClick = 0
  self._tAllStrangerTagObj = {}
  self._tAllHouseKeeperLvObj = {}
  self.isChatBg = false
  self._bIsScrolling = false
end

function ui_chat_member_list_friend:RegistEvents()
  ui_chat_member_list_friend.__super.RegistEvents(self)
  self.LoopScrollBox_MemberItemList:AddItemWidgetChildEvent("btn_unselected", "OnClicked", self.OnClickItem, self)
  self.LoopScrollBox_MemberItemList:AddItemWidgetChildEvent("Common_Avatar_BP", "OnClickItemCallback", self.DoubleClick, self)
  self:AddCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_ADD_STRANGER, self.OnAddStranger, self)
  self:AddCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_REFRESH_FRIEND_UI, self.OnUpdateFriend, self)
  self:AddCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_FRIEND_AUTO_SELECT, self.OnAutoSelect, self)
  self:AddCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_INTERACT_RSP, self.OnInteract, self)
  self:AddCommonEvent(EVENTTYPE_PLANPH_LOBBY, EVENTID_PLANPH_HKP_DIALOG_LOBBY_ADD_HKP, self.OnAddHouseKeeper, self)
  self:AddCommonEvent(EVENTTYPE_CHAT, EVENTTYPE_CHAT_ROOM_BG_CHANGE, self.UpdateFriendItemByBG, self)
  self:AddControlEventByControl(self.LoopScrollBox_MemberItemList.UIRoot, "OnBeginScroll", self._OnScrollBegin, self)
  self:AddControlEventByControl(self.LoopScrollBox_MemberItemList.UIRoot, "OnEndScroll", self._OnScrollEnd, self)
end

function ui_chat_member_list_friend:OnPostInitialize()
  ui_chat_member_list_friend.__super.OnPostInitialize(self)
  self:_GetTextDefaultColor()
  self.LoopScrollBox_MemberItemList:BindSuperList(logic_chat_channel_friend.FriendList)
  self.toPlay = true
  self.timerPlayAnim = self:AddTimerOnce(0.03, function()
    self:StartAnimation()
  end)
end

function ui_chat_member_list_friend:OnShow()
  ui_chat_member_list_friend.__super.OnShow(self)
  logic_chat_channel_friend.bSnapshotLocked = false
  self:UpdateFriend()
  logic_chat_channel_friend.bSnapshotLocked = true
  log(bWriteLog and "[v_yunjxiang] ui_chat_member_list_friend:OnShow")
  self:FireAndPoke()
end

function ui_chat_member_list_friend:Close()
  self.LoopScrollBox_MemberItemList:UnBindSuperList(logic_chat_channel_friend.FriendList)
  self.uidListNeedStatus = {}
  self.timerHandle = nil
  self.uidExistListStatus = {}
  logic_chat_channel_friend.bSnapshotLocked = false
  ui_chat_member_list_friend.__super.Close(self)
end

function ui_chat_member_list_friend:DoubleClick(widget, index)
  local itemData = self.LoopScrollBox_MemberItemList:GetItemData(index)
  if not itemData then
    return
  end
  log(bWriteLog and "ui_chat_member_list_friend:DoubleClick self.nClick:" .. tostring(self.nClick))
  local TimeUtil = require("client.common.time_util")
  local nowTime = TimeUtil.GetServerTimeInSec()
  local logic_poke = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_poke)
  local intervalTime = tonumber(CDataTable.GetTableData("InteractiveParameterTable", "POKE_RESPONSE_TIME").Value)
  if self.nClick == 0 then
    log(bWriteLog and "ui_chat_member_list_friend:DoubleClick 1")
    self.lasetTime = nowTime
    self.nClick = 1
  elseif intervalTime > nowTime - self.lasetTime then
    log(bWriteLog and "ui_chat_member_list_friend:DoubleClick 2")
    local UIUtil = require("client.common.ui_util")
    UIUtil.PlayWidgetAnimation(widget.Common_Avatar_BP, "Animation_chuo1chuo", 0, 1, 1, 1)
    logic_poke:send_poke_friend_req(itemData.uid)
    self:DoubleClickClearData()
    return
  end
  self.doubleTimer = self:AddTimerOnce(intervalTime, function()
    self:OnClickItem(widget, index)
    self:DoubleClickClearData()
  end)
end

function ui_chat_member_list_friend:DoubleClickClearData()
  log(bWriteLog and "ui_chat_member_list_friend:DoubleClickClearData")
  self.nClick = 0
  self.lasetTime = 0
  if self.doubleTimer then
    self:RemoveTimer(self.doubleTimer)
    self.doubleTimer = nil
  end
end

function ui_chat_member_list_friend:OnAddStranger()
  self.LoopScrollBox_MemberItemList:Select(1)
  self.LoopScrollBox_MemberItemList:ScrollToItem(1)
end

function ui_chat_member_list_friend:OnUpdateFriend()
  if self._bIsScrolling or logic_chat_channel_friend.bSnapshotLocked then
    self:_SyncSelectIndexByCurrentGid()
    self.LoopScrollBox_MemberItemList:RefreshAllItems()
  else
    self:UpdateFriend()
  end
  log(bWriteLog and "[v_yunjxiang] ui_chat_member_list_friend:OnUpdateFriend")
  self:FireAndPoke()
end

function ui_chat_member_list_friend:OnAutoSelect(_, _)
  if #logic_chat_channel_friend.FriendList == 0 then
    log(bWriteLog and " ui_chat_channel_friend:AutoSelectNextFriendItem #FriendList = 0")
    return
  end
  local firstUnreadIndex
  for i, v in ipairs(logic_chat_channel_friend.FriendList) do
    if v.unreadCount and v.unreadCount ~= 0 then
      firstUnreadIndex = i
      break
    end
  end
  local targetIdx
  if not firstUnreadIndex then
    log(bWriteLog and " ui_chat_channel_friend:AutoSelectNextFriendItem all read")
    targetIdx = 1
  else
    targetIdx = firstUnreadIndex
    if logic_chat_channel_friend.CurrentGid ~= "" then
      local curIdx
      for i, v in ipairs(logic_chat_channel_friend.FriendList) do
        if curIdx and v.unreadCount and v.unreadCount ~= 0 then
          targetIdx = i
          break
        end
        if tostring(v.uid) == logic_chat_channel_friend.CurrentGid then
          curIdx = i
        end
      end
    end
  end
  if self.LoopScrollBox_MemberItemList:GetSelectIndex() == targetIdx then
    return
  end
  log(bWriteLog and bWriteLog and string.format(" ui_chat_channel_friend:AutoSelectNextFriendItem   targetIndex:%s", targetIdx))
  self:OnClickItem(nil, targetIdx)
end

function ui_chat_member_list_friend:ResetItem(uObj_widget)
  local cObj_base = ui_chat_member_list_friend.__super
  cObj_base.ResetItem(self, uObj_widget)
  self:SetIsShowStrangerTag(uObj_widget, false)
  self:SetHouseKeeperInfoShow(uObj_widget, false)
end

function ui_chat_member_list_friend:SetIsShowStrangerTag(uObj_widget, bIsShow)
  local sKey = tostring(uObj_widget)
  local cObj_stranger = self._tAllStrangerTagObj[sKey]
  if bIsShow then
    if cObj_stranger then
      return
    end
    cObj_stranger = self:CreateChildWindowWithBpPath(uObj_widget.Stranger, UIManager.UI_Config.ChildUIWithoutBpPathForChat, "/Game/Mod/Lobby/Split/LobbyChat/Item/Chat_MemberListSubItem/Chat_FriendInfo_Stranger_UIBP.Chat_FriendInfo_Stranger_UIBP")
    if not cObj_stranger then
      return
    end
    cObj_stranger:SetAutoSize(true)
    self._tAllStrangerTagObj[sKey] = cObj_stranger
  elseif cObj_stranger then
    cObj_stranger:Close()
    self._tAllStrangerTagObj[sKey] = nil
  end
end

function ui_chat_member_list_friend:_GetTextDefaultColor(uObj_widget, bIsShow, nLevel)
  local NicknameColorManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager)
  self.DefaultTextColor = NicknameColorManager:GetDefaultColorByType(ENUM_NAME_COLOR_UI_TYPE.ChatChannel)
end

function ui_chat_member_list_friend:SetHouseKeeperInfoShow(uObj_widget, bIsShow, nLevel)
  local sKey = tostring(uObj_widget)
  local cObj_houseKeeperLv = self._tAllHouseKeeperLvObj[sKey]
  if bIsShow then
    if cObj_houseKeeperLv then
      cObj_houseKeeperLv.UIRoot.Text_HouseKeeperLv:SetText(LocUtil.LocalizeResFormat(665320, nLevel))
      return
    end
    cObj_houseKeeperLv = self:CreateChildWindowWithBpPath(uObj_widget.CanvasPanel_HouseKeeper, UIManager.UI_Config.ChildUIWithoutBpPathForChat, "/Game/Mod/Lobby/Split/LobbyChat/Item/Chat_MemberListSubItem/Chat_FriendInfo_HouseKeeper_UIBP.Chat_FriendInfo_HouseKeeper_UIBP")
    if not cObj_houseKeeperLv or not cObj_houseKeeperLv.UIRoot then
      return
    end
    cObj_houseKeeperLv.UIRoot.Text_HouseKeeperLv:SetText(LocUtil.LocalizeResFormat(665320, nLevel))
    cObj_houseKeeperLv:SetAutoSize(true)
    self._tAllHouseKeeperLvObj[sKey] = cObj_houseKeeperLv
    if cObj_houseKeeperLv then
      cObj_houseKeeperLv.UIRoot.Text_HouseKeeperLv:SetColorAndOpacity(self.DefaultTextColor)
    end
  elseif cObj_houseKeeperLv then
    cObj_houseKeeperLv:Close()
    self._tAllHouseKeeperLvObj[sKey] = nil
  end
end

function ui_chat_member_list_friend:SetHouseKeeperInfoColor(uObj_widget, isBg)
  local sKey = tostring(uObj_widget)
  local cObj_houseKeeperLv = self._tAllHouseKeeperLvObj[sKey]
  if cObj_houseKeeperLv then
    if isBg then
      cObj_houseKeeperLv.UIRoot.Text_HouseKeeperLv:SetColorAndOpacity(FSlateColor(FLinearColor(1, 1, 1, 1)))
      cObj_houseKeeperLv.UIRoot.TextBlock_3:SetColorAndOpacity(FSlateColor(FLinearColor(1, 1, 1, 1)))
    else
      cObj_houseKeeperLv.UIRoot.Text_HouseKeeperLv:SetColorAndOpacity(self.DefaultTextColor)
      cObj_houseKeeperLv.UIRoot.TextBlock_3:SetColorAndOpacity(self.DefaultTextColor)
    end
  end
end

function ui_chat_member_list_friend:FireAndPoke()
  local level_unlock_util = require("client.logic.level_unlock.util.level_unlock_util")
  local bHaveLockedFeature = level_unlock_util:HaveLockedFeature()
  log(bWriteLog and "ui_chat_member_list_friend:FireAndPoke bHaveLockedFeature = " .. tostring(bHaveLockedFeature))
  if bHaveLockedFeature then
    return
  end
  local leReplaceEvTimeStamp = DataMgr.GetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_CHAT_FIRE, 1)
  if not leReplaceEvTimeStamp then
    local TimeUtil = require("client.common.time_util")
    UIManager.ShowUI(UIManager.UI_Config.Common_Popup_Chat_Poke)
    DataMgr.SetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_CHAT_FIRE, 1, TimeUtil.GetServerTimeInSec())
  end
end

function ui_chat_member_list_friend:OnInteract(eventType, eventID, frd_uid)
  local data = self.LoopScrollBox_MemberItemList:GetSetData()
  for k, v in pairs(data) do
    if v.uid == frd_uid then
      self:AddTimerOnce(0.2, function()
        local widget = self.LoopScrollBox_MemberItemList:GetIndexOfWidget(k)
        self:OnRefreshItem(widget, k)
      end)
    end
  end
end

function ui_chat_member_list_friend:OnRefreshItem(widget, index)
  local itemData = self.LoopScrollBox_MemberItemList:GetItemData(index)
  if not itemData then
    return
  end
  if not widget then
    return
  end
  itemData.hasBg = self.isChatBg
  if itemData.housekeeper then
    self:OnRefreshHouseKeeperItem(widget, index, itemData)
    self:SetWidgetVisible(widget.Image_Scintilla, false)
  else
    local logic_interaction = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction)
    local path, name, score = logic_interaction:GetIconInfoByID(itemData.uid)
    if path and score and 0 < score then
      self:SetWidgetVisible(widget.Image_Scintilla, true)
      self:SetTexture(widget.Image_Scintilla, path)
    else
      self:SetWidgetVisible(widget.Image_Scintilla, false)
    end
    self.firstFriendNum = math.min(self.firstFriendNum, index)
    ui_chat_member_list_friend.__super.OnRefreshItem(self, widget, index)
    local logic_chat_stranger = require("client.slua.logic.lobby_chat.logic_chat_stranger")
    if logic_chat_stranger.IsStranger(itemData.uid) then
      self:SetIsShowStrangerTag(widget, true)
      self:GetStrangerListStatus(itemData.uid)
    end
  end
  self:SetUnrealCount(widget, itemData)
end

function ui_chat_member_list_friend:OnClickItem(widget, index)
  local itemData = self.LoopScrollBox_MemberItemList:GetItemData(index)
  if not itemData then
    return
  end
  local logic_interaction = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction)
  if not itemData.housekeeper then
    logic_interaction:send_get_interact_info_req(itemData.uid)
  end
  itemData.unreadCount = 0
  if itemData.housekeeper then
    self:OnClickHouseKeeperItem(itemData, index)
  else
    ui_chat_member_list_friend.__super.OnClickItem(self, widget, index)
  end
end

function ui_chat_member_list_friend:GetStrangerListStatus(uid)
  if self.uidExistListStatus[uid] then
    return
  else
    table.insert(self.uidListNeedStatus, uid)
    self.uidExistListStatus[uid] = uid
  end
  if not self.timerHandle then
    self.timerHandle = self:AddTimerOnce(0.5, function()
      local logic_chat_stranger = require("client.slua.logic.lobby_chat.logic_chat_stranger")
      logic_chat_stranger.ReqStrangerStatus(self.uidListNeedStatus)
      self.uidListNeedStatus = {}
      self.timerHandle = nil
    end)
  end
end

function ui_chat_member_list_friend:SetUnrealCount(widget, itemData)
  if itemData.unreadCount and itemData.unreadCount > 0 then
    self:SetWidgetVisible(widget.unread_root_anchor, true)
    widget.txt_unread_count:SetText(tostring(itemData.unreadCount))
    widget.txt_unread_count:SetColorAndOpacity(self.DefaultTextColor)
    self:CheckHousekeeperRedPoint(itemData, widget)
  else
    self:SetWidgetVisible(widget.unread_root_anchor, false)
  end
end

function ui_chat_member_list_friend:CheckHousekeeperRedPoint(itemData, widget)
  if itemData.housekeeper then
    local logic_chat_butler_setting = require("client.slua.umg.lobby_chat.logic_chat_butler_setting")
    self:SetWidgetVisible(widget.unread_root_anchor, logic_chat_butler_setting.isOpen)
    if not logic_chat_butler_setting.isOpen then
      widget.txt_unread_count:SetText("")
    end
  end
end

function ui_chat_member_list_friend:UpdateFriend()
  if logic_chat_channel_friend.CurrentGid ~= "" then
    for k, v in pairs(logic_chat_channel_friend.FriendList) do
      if tonumber(v.uid) == tonumber(logic_chat_channel_friend.CurrentGid) then
        self.LoopScrollBox_MemberItemList:ScrollToItem(k)
        self.LoopScrollBox_MemberItemList:Select(k)
        local logic_interaction = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction)
        logic_interaction:send_get_interact_info_req(v.uid)
        break
      end
    end
  end
end

function ui_chat_member_list_friend:OnRefreshHouseKeeperItem(widget, index, itemData)
  self:ResetItem(widget)
  self:SetButtonOnClickStatus(widget, index)
  if self.toPlay and self.deviceLevel then
    self:InsertItemToPlayAnim(widget)
  else
    self:SetWidgetVisible(widget.CanvasPanel_1, true)
  end
  self:SetWidgetVisible(widget.SizeBox_1, false)
  self:SetWidgetVisible(widget.CanvasPanel_2, false)
  self:SetPlayerStatusSwitcherShow(widget, false)
  self:SetWidgetVisible(widget.HorizontalBox_RankInfo1, false)
  widget.WidgetSwitcher_Head:SetActiveWidgetIndex(1)
  local hkpCfg = CDataTable.GetTableData("PlanPH_Housekeeper_cfg", itemData.uid)
  local logic_housekeeper_dialog_lobby = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby)
  local logic_home_housekeeper = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_housekeeper)
  if not hkpCfg or logic_housekeeper_dialog_lobby:IsTestInvalid() then
    widget.TextBlock_Invalid:SetText(LocUtil.LocalizeResFormat(655725))
    self:SetTexture(widget.Image_HouseKeeper, "/Game/UMG/Texture/Lobby_NoAtlas/T_icon_touxiang_invalidHouseKeeper.T_icon_touxiang_invalidHouseKeeper")
    if widget.WidgetSwitcher_House then
      widget.WidgetSwitcher_House:SetActiveWidgetIndex(1)
      self:SetWidgetVisible(widget.CanvasPanel_HKeeperInvalid, true)
    end
    self:SetHouseKeeperInfoShow(widget, false)
  else
    self:SetTexture(widget.Image_HouseKeeper, hkpCfg.Icon, {
      sync = false,
      bNotDownloadTexture = true,
      defaultIcon = "/Game/UMG/Texture/Lobby_NoAtlas/T_icon_touxiang_invalidHouseKeeper.T_icon_touxiang_invalidHouseKeeper"
    })
    local hkName = logic_home_housekeeper:GetHouseKeeperName(itemData.uid)
    widget.txt_friend_name:SetText(hkName)
    if widget.WidgetSwitcher_House then
      widget.WidgetSwitcher_House:SetActiveWidgetIndex(0)
    end
    local nLevel = logic_housekeeper_dialog_lobby:GetCurHousekeeperLv()
    self:SetHouseKeeperInfoShow(widget, true, nLevel)
  end
  local NicknameColorManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager)
  if itemData.hasBg then
    widget.txt_friend_name:SetColorAndOpacity(FSlateColor(FLinearColor(1, 1, 1, 1)))
  else
    widget.txt_friend_name:SetColorAndOpacity(NicknameColorManager:GetColorByUID(itemData.uid, ENUM_NAME_COLOR_UI_TYPE.ChatChannel))
  end
  self:SetHouseKeeperInfoColor(widget, itemData.hasBg)
  local jointInfo = logic_home_housekeeper:GetJointInfo()
  local logic_home_joint = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint)
  local isJoint = logic_home_joint:HasJointHome() and jointInfo and tonumber(jointInfo.belong_uid) ~= tonumber(DataMgr.roleData.uid)
  self:SetWidgetVisible(widget.Image_Cohabit, isJoint)
  widget.TextBlock_Invalid:SetColorAndOpacity(self.DefaultTextColor)
end

function ui_chat_member_list_friend:OnAddHouseKeeper()
  log(bWriteLog and string.format("[v_yunjxiang] ui_chat_member_list_friend:OnAddHouseKeeper"))
  local NewbieGuide = UIManager.GetUI(UIManager.UI_Config.NewbieGuide_UIBP)
  if NewbieGuide then
    log(bWriteLog and string.format("[v_yunjxiang] NewbieGuide:CloseSelf()"))
    NewbieGuide:CloseSelf()
  end
  self:FireAndPoke()
end

function ui_chat_member_list_friend:OnClickHouseKeeperItem(itemData, index)
  self:PlayAudio(sound_config.click_v1)
  self.LoopScrollBox_MemberItemList:Select(index)
  local logic_home_housekeeper = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_housekeeper)
  local hkName = logic_home_housekeeper:GetHouseKeeperName(itemData.uid)
  EventSystem:postEvent(EVENTTYPE_CHAT, EVENTID_CHAT_ON_CLICK_MENBER_ITEM, itemData, hkName)
end

function ui_chat_member_list_friend:UpdateFriendItemByBG(...)
  self.isChatBg = self:getChatMianHasBg()
  self.LoopScrollBox_MemberItemList:RefreshAllItems()
end

function ui_chat_member_list_friend:getChatMianHasBg()
  local hasBG = fasle
  local chat_ui = UIManager.GetUI(UIManager.UI_Config.ui_chat_main)
  if not chat_ui then
    return
  end
  local hasBG = chat_ui:HasBG()
  return hasBG
end

function ui_chat_member_list_friend:_OnScrollBegin()
  self._bIsScrolling = true
end

function ui_chat_member_list_friend:_OnScrollEnd()
  self._bIsScrolling = false
end

function ui_chat_member_list_friend:_SyncSelectIndexByCurrentGid()
  if logic_chat_channel_friend.CurrentGid == "" then
    return
  end
  local curGid = tonumber(logic_chat_channel_friend.CurrentGid)
  for k, v in pairs(logic_chat_channel_friend.FriendList) do
    if tonumber(v.uid) == curGid then
      if self.LoopScrollBox_MemberItemList:GetSelectIndex() ~= k then
        self.LoopScrollBox_MemberItemList:Select(k)
      end
      return
    end
  end
end

local class = require("class")
local ui_base = require("client.slua.umg.lobby_chat.ui_chat_member_list_base")
local CUIChatMemberListFriend = class(ui_base, nil, ui_chat_member_list_friend)
return CUIChatMemberListFriend
