local NewbieGuideWelcome = {}

function NewbieGuideWelcome:ctor(_, isGetUI)
  self.isGetUI = isGetUI
end

function NewbieGuideWelcome:UpdateData()
  self.selectIdx = 1
  self.activeCfg = nil
end

function NewbieGuideWelcome:OnInitialize()
  NewbieGuideWelcome.__super.OnInitialize(self)
  self.util = require("client.slua_ui_framework.util")
  self.TextBlock_0 = self.UIRoot.TextBlock_0
  self.Text_Name = self.UIRoot.Text_Name
  self.UTRichTextBlock_0 = self.UIRoot.UTRichTextBlock_0
  self.TextBlock_3 = self.UIRoot.TextBlock_3
  self.Button_No = self.UIRoot.Button_No
  self.TextBlock_5 = self.UIRoot.TextBlock_5
  self.Button_Yes = self.UIRoot.Button_Yes
  self.TextBlock_4 = self.UIRoot.TextBlock_4
  self.requestMatch = false
  self.readyForMatchRequest = false
  self.startMatching = false
  self.getAwardCallback = false
  self.awardGot = false
end

function NewbieGuideWelcome:RegistEvents()
  NewbieGuideWelcome.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_No, self.SendMsg, self, false)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Yes, self.SendMsg, self, true)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Get, self.OnClickGetAward, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickCloseBtn, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_logoot, self.OnClickSwitchAccount, self)
  self:AddCommonEvent(EVENTTYPE_PUFFER, EVENTID_PUFFER_DOWNLOADFINISH, self.UpdateUIItem, self)
  for i = 1, 3 do
    local name = string.format("Common_Welcome_Item_UIBP_C_%d", i)
    self:AddControlEventByControl(self.UIRoot[name].Button_0, "OnClicked", self.OnClickedItem, self, i)
  end
  for i = 4, 6 do
    local name = string.format("Common_Welcome_Item_UIBP_C_%d", i)
    self:AddControlEventByControl(self.UIRoot[name].Button_0, "OnClicked", self.OnClickedItem, self, i - 3)
  end
  self:SetWidgetVisible(self.UIRoot.BlackMask, true)
end

function NewbieGuideWelcome:LoadDown()
  for _, cfg in pairs(self.activeCfg) do
    local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
    local PufferConst = require("client.slua.logic.download.puffer_const")
    local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
    local extraData = {bAutoDownload = true}
    PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, {
      cfg.itemid
    }, PufferTlog.Enum_TLog_From.Newbie, nil, extraData)
  end
end

function NewbieGuideWelcome:OnPostInitialize()
  NewbieGuideWelcome.__super.OnPostInitialize(self)
  self:UpdateData()
  self:UpdateUI()
  self:UpdateTitle()
end

function NewbieGuideWelcome:UpdateUI()
  if self.isGetUI then
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(1)
  else
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(0)
  end
  self:UpdateFixedTxt()
  self:UpdateUIItem()
  self:LoadDown()
  local LogicNewbie = require("client.logic.newbie.logic_newbie")
  self:SetWidgetVisible(self.UIRoot.Button_logoot, LogicNewbie.IsSwitchAccountEntryOpen(), true)
end

function NewbieGuideWelcome:UpdateUIItem()
  local NewbieActivitySystem = require("client.slua.logic.activity.newbie.logic_newbie_activity")
  local data = NewbieActivitySystem.activity_data
  if not (data and data.newbie_fight_guide_award) or not data.newbie_fight_guide_award.cfg then
    local groupID = LobbySystem.roleData.newbie_groupid or 1
    local reward = CDataTable.GetTableData("NewbieLevelReward", groupID)
    reward = reward or CDataTable.GetTableData("NewbieLevelReward", 1)
    local config = {}
    config[1] = {
      itemid = reward.Item1,
      cnt = reward.ItemCount1,
      valid_hours = reward.ItemValidTime1
    }
    config[2] = {
      itemid = reward.Item2,
      cnt = reward.ItemCount2,
      valid_hours = reward.ItemValidTime2
    }
    config[3] = {
      itemid = reward.Item3,
      cnt = reward.ItemCount3,
      valid_hours = reward.ItemValidTime3
    }
    self.activeCfg = config
  end
  if not self.activeCfg then
    self.activeCfg = data.newbie_fight_guide_award and data.newbie_fight_guide_award.cfg or {}
  end
  log_tree("[qintong] NewbieGuideWelcome:UpdateUIItem", self.activeCfg)
  for i = 1, 3 do
    local cfg = self.activeCfg[i]
    local widget1 = self.UIRoot["Common_Welcome_Item_UIBP_C_" .. i]
    local Lua_CommonItems = widget1.Lua_CommonItems
    Lua_CommonItems:InitView(cfg.itemid, 0, cfg.valid_hours or 0, {bIsShowTip = true})
    Lua_CommonItems:HideQuality()
    widget1.Check:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    local widget2 = self.UIRoot["Common_Welcome_Item_UIBP_C_" .. i + 3]
    local Lua_CommonItems2 = widget2.Lua_CommonItems
    Lua_CommonItems2:InitView(cfg.itemid, 0, cfg.valid_hours or 0, {bIsShowTip = true})
    Lua_CommonItems:HideQuality()
    widget2.Check:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    for j = 1, 3 do
      if i == j then
        widget1["Image_" .. j]:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        widget2["Image_" .. j]:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      else
        widget1["Image_" .. j]:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        widget2["Image_" .. j]:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
    end
    local itemCfg = CDataTable.GetTableData("Item", cfg.itemid)
    local computedQuality = math.max(1, itemCfg.ItemQuality or 0)
    local UIUtil = require("client.common.ui_util")
    local qualityBarPath = UIUtil.GetQualityPath(computedQuality)
    self:SetTexture(widget1.ImageBar, qualityBarPath)
    self:SetTexture(widget2.ImageBar, qualityBarPath)
    if self._type == self.GetUI and i == self.selectIdx then
      widget1.Check:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      widget2.Check:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    end
  end
end

function NewbieGuideWelcome:UpdateFixedTxt()
  if not self.isGetUI then
    self.Text_Name:SetText(DataMgr.roleData.nickName)
    self.TextBlock_5:SetText(LocUtil.GetLocalizeResStr(27312))
    self.TextBlock_4:SetText(LocUtil.GetLocalizeResStr(27313))
    self.UTRichTextBlock_0:SetText(LocUtil.GetLocalizeResStr(18044))
    self.TextBlock_3:SetText(LocUtil.GetLocalizeResStr(18045))
  else
    self.UIRoot.UTRichTextBlock_1:SetText(LocUtil.GetLocalizeResStr(18357))
    self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(18358))
    self.UIRoot.TextBlock_6:SetText(LocUtil.GetLocalizeResStr(18048))
  end
end

function NewbieGuideWelcome:GetFightCnt()
  local LogicNewbie = require("client.logic.newbie.logic_newbie")
  local inGameGuideTb = DataMgr.newbieGuide[LogicNewbie.NEWBIE_GUIDE_MODULE_ID_FIGHT_GUIDE]
  local TableUtil = require("common.table_util")
  local count = TableUtil.CountTable(inGameGuideTb)
  log_tree("[qintong]NewbieGuideWelcome GetFightCnt " .. count, inGameGuideTb)
  return count
end

function NewbieGuideWelcome:OnClickCloseBtn()
  self:PlayAudio(sound_config.click)
  self:OnClickGetAward()
end

function NewbieGuideWelcome:OnClickSwitchAccount()
  local LobbySystem = require("client.logic.login.logic_lobby")
  local bLocalMatching = self.startMatching == true
  local bServerMatch = LobbySystem and LobbySystem.isInMatch
  local BasicDataTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataTLogReport)
  BasicDataTLogReport:ReportImmediate(TLogEventDefine.SwitchAccountEntryClick)
  printf(bWriteLog and "NewbieGuideWelcome:OnClickSwitchAccount localMatching:%s serverMatch:%s", tostring(bLocalMatching), tostring(bServerMatch))
  if bLocalMatching or bServerMatch then
    return
  end
  self:PlayAudio(sound_config.click)
  
  local function OnConfirmSwitch(bDeleteAccount)
    if bDeleteAccount then
      local LogicDeleteAccount = require("client.slua.logic.gdpr.logic_deleteaccount")
      LogicDeleteAccount.DoDirectDeleteWithLogout()
    else
      local SettingAccount = require("client.logic.setting.logic_setting_account")
      SettingAccount.Logout()
    end
  end
  
  UIManager.ShowUI(UIManager.UI_Config.Common_SwitchAccount_UIBP, OnConfirmSwitch)
end

function NewbieGuideWelcome:OnClickGetAward()
  self:PlayAudio(sound_config.click)
  self.data = self.activeCfg[self.selectIdx]
  local PlayerLabelHandler = require("client.network.Protocol.PlayerLabelHandler")
  PlayerLabelHandler.send_newbie_fight_guide_get_reward_req(self.selectIdx, self.data)
  DataMgr.SetNewbieGuideValue(101, -1, self.data.itemid)
  local async = require("client.common.async")
  async.Run(function(co)
    async.AwaitEvent(co, 5, EVENTTYPE_NEWBIE, EVENTID_NEWBIE_GET_AWARD)
    self:OnNewbieGetAwardInGetUI(self.selectIdx)
  end)
end

function NewbieGuideWelcome:OnNewbieGetAwardInGetUI(award_id)
  if self.getAwardCallback then
    return
  end
  log(bWriteLog and "============>NewbieGetAward")
  self.getAwardCallback = true
  local activeCfg = self.activeCfg
  local clothInsID
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  if award_id and activeCfg and activeCfg[award_id] then
    local resID = activeCfg[award_id].itemid
    local itemCfg = wardrobe_data:GetHallDepotItemDataByResID(resID)
    if itemCfg then
      local equiped = wardrobe_data:IsEquitItem(itemCfg.insID)
      if not equiped then
        local WardRobeHandler = require("client.network.Protocol.WardRobeHandler")
        clothInsID = itemCfg.insID
        WardRobeHandler.send_depot_put_on_req(tonumber(itemCfg.insID))
      end
    end
  end
  local rolewear = {}
  if clothInsID then
    local itemInfo = wardrobe_data:GetHallDepotItemDataByInsID(clothInsID)
    if itemInfo and itemInfo.itemType == 4 then
      table.insert(rolewear, AvatarData.CreateAvatarCustom(itemInfo.resID, itemInfo.colorID, itemInfo.patternID))
    end
  else
    local tRoleData = AvatarData.GetRoleWear()
    for _, v in pairs(tRoleData) do
      local itemInfo = wardrobe_data:GetHallDepotItemDataByInsID(v)
      if itemInfo and itemInfo.itemType == 4 then
        table.insert(rolewear, AvatarData.CreateAvatarCustom(itemInfo.resID, itemInfo.colorID, itemInfo.patternID))
      end
    end
  end
  self:CloseSelf()
  local logicCreateRole = require("client.slua.logic.createRole.logic_createRole")
  logicCreateRole.NewbieUpdateAvatar(rolewear)
end

function NewbieGuideWelcome:OnClickedItem(index)
  self:PlayAudio(sound_config.click)
  local startIndex, endIndex
  if not self.isGetUI then
    if self.awardGot then
      ShowNotice(29947)
      return
    end
    startIndex = 1
    endIndex = 3
  else
    startIndex = 4
    endIndex = 6
  end
  self.selectIdx = index
  for i = startIndex, endIndex do
    local widget = self.UIRoot["Common_Welcome_Item_UIBP_C_" .. i]
    if index == i or index == i - 3 then
      widget.Check:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    else
      widget.Check:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
  end
end

function NewbieGuideWelcome:SendMsg(bChoose)
  self:PlayAudio(sound_config.click)
  log(bWriteLog and "send msg: " .. tostring(bChoose))
  local PlayerLabelHandler = require("client.network.Protocol.PlayerLabelHandler")
  local MsgInfo = bChoose and 1 or 0
  PlayerLabelHandler.send_is_choose_novice_level(MsgInfo)
  if bChoose then
    self:StartNewbieLevel()
  else
    self:StartDefaultMatch()
  end
  LobbySystem.roleData.is_first_login = LobbySystem.NewbieRoleState.UpdateRole
  LobbySystem.enterNewbieLevel = bChoose
end

function NewbieGuideWelcome:StartNewbieLevel()
  log(bWriteLog and "start newbie level")
  self.startMatching = true
  self.UIRoot.NewbieMatchingWidgetSwitcher:SetActiveWidgetIndex(1)
  self.UIRoot.NewbieMatching:SetText(LocUtil.GetLocalizeResStr(7502))
  local matchingTime = 0
  local TimeUtil = require("client.common.time_util")
  local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(matchingTime, true)
  local matchingTimeTextBlock = self.UIRoot.Newbie_MatchingTime
  matchingTimeTextBlock:SetText(timeStr)
  self:AddTimerLoop(1, function()
    matchingTime = matchingTime + 1
    timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(matchingTime, true)
    matchingTimeTextBlock:SetText(timeStr)
  end, TIMER_INFINITE, 1)
  self.Button_No:SetIsEnabled(false)
  self.Button_Yes:SetIsEnabled(false)
  self:StartMatch(true)
end

function NewbieGuideWelcome:StartDefaultMatch()
  if self.startMatching then
    return
  end
  log(bWriteLog and "start default match")
  self.UIRoot.MatchingWidgetSwitcher:SetActiveWidgetIndex(1)
  self.UIRoot.TextBlock_Matching:SetText(LocUtil.GetLocalizeResStr(7502))
  local matchingTime = 0
  local TimeUtil = require("client.common.time_util")
  local timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(matchingTime, true)
  local matchingTimeTextBlock = self.UIRoot.TextBlock_MatchingTime
  matchingTimeTextBlock:SetText(timeStr)
  self:AddTimerLoop(1, function()
    matchingTime = matchingTime + 1
    timeStr = TimeUtil.FormatCountDownTime_DH_or_HMS_or_MS(matchingTime, true)
    matchingTimeTextBlock:SetText(timeStr)
  end, TIMER_INFINITE, 1)
  self.Button_No:SetIsEnabled(false)
  self.Button_Yes:SetIsEnabled(false)
  self.startMatching = true
  local MatchModeMgrSystem = require("client.slua.logic.match.logic_mode_mgr")
  MatchModeMgrSystem.nSelectMatchID = 0
  self:StartMatch(false)
end

function NewbieGuideWelcome:StartMatch(bTraining)
  self.bTraining = bTraining
  self:DirectGetAward()
end

function NewbieGuideWelcome:DirectGetAward()
  self:PlayAudio(sound_config.click)
  log(bWriteLog and "direct get award")
  self.data = self.activeCfg[self.selectIdx]
  local PlayerLabelHandler = require("client.network.Protocol.PlayerLabelHandler")
  PlayerLabelHandler.send_newbie_fight_guide_get_reward_req(self.selectIdx, self.data)
  DataMgr.SetNewbieGuideValue(101, -1, self.data.itemid)
  self.awardGot = true
  local selectIndex = self.selectIdx
  local async = require("client.common.async")
  async.Run(function(co)
    async.AwaitEvent(co, 5, EVENTTYPE_NEWBIE, EVENTID_NEWBIE_GET_AWARD)
    self:OnNewbieGetAwardInTipUI(selectIndex)
  end)
end

function NewbieGuideWelcome:OnNewbieGetAwardInTipUI(award_id)
  if self.getAwardCallback then
    return
  end
  log(bWriteLog and "============>NewbieGetAward get award: " .. tostring(award_id))
  self.getAwardCallback = true
  local activeCfg = self.activeCfg
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  if award_id and activeCfg and activeCfg[award_id] then
    local resID = activeCfg[award_id].itemid
    log(bWriteLog and "============>NewbieGetAward current item: " .. tostring(resID))
    local itemCfg = wardrobe_data:GetHallDepotItemDataByResID(resID)
    if itemCfg then
      log(bWriteLog and "============>NewbieGetAward get item: " .. tostring(itemCfg.insID))
      local equiped = wardrobe_data:IsEquitItem(itemCfg.insID)
      if not equiped then
        local WardRobeHandler = require("client.network.Protocol.WardRobeHandler")
        WardRobeHandler.send_depot_put_on_req(tonumber(itemCfg.insID))
      end
    end
  end
  self:AfterGetAward()
end

function NewbieGuideWelcome:AfterGetAward()
  if self.bTraining then
    local enter_guide = require("client.slua.logic.growth_project.enter_guide")
    enter_guide.Version140EnterGuide()
    LobbySystem.WaitForMatchSuccess()
  else
    LobbySystem.DirectStartMatch()
  end
end

function NewbieGuideWelcome:OnPressedItem(index)
  local Data = self.activeCfg[index]
  local widget = self.UIRoot["Common_Welcome_Item_UIBP_C_" .. index]
  local UIUtil = require("client.common.ui_util")
  UIUtil.ShowItemTips(Data.itemid, widget, FVector2D(0, 0), Data.valid_hours)
end

function NewbieGuideWelcome:OnReleasedItem()
  local UIUtil = require("client.common.ui_util")
  UIUtil.CloseItemTips()
end

function NewbieGuideWelcome:UpdateTitle()
  if not self.UIRoot.Image_Title then
    return
  end
  local iconPath = "/Game/UMG/Texture_200/Lobby_NoAtlas/CoMEBACK/Common_Welcome_Title01.Common_Welcome_Title01"
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local isFit = PublishRegionMacros.IsFITVersion()
  if isFit then
    iconPath = "/Game/UMG/Texture_200/Lobby_NoAtlas/CoMEBACK/Common_Welcome_Title02.Common_Welcome_Title02"
  end
  self:SetTexture(self.UIRoot.Image_Title, iconPath)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CNewbieGuideWelcome = class(ui_base, nil, NewbieGuideWelcome)
return CNewbieGuideWelcome
