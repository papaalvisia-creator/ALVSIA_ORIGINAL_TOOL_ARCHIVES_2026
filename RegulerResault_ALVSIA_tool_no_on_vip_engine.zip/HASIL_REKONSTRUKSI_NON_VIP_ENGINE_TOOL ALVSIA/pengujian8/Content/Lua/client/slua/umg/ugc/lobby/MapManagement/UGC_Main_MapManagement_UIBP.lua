local Config_UGC = require("client.slua.logic.ugc.config_ugc")
local Util_UGC = require("client.slua.logic.ugc.util_ugc")
local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
local E_MapTab = {
  Tab1 = 1,
  Tab2 = 2,
  Tab3 = 3,
  Tab4 = 4
}
local MapTabConfig = {
  [E_MapTab.Tab1] = {
    tabControl = "Tab_1",
    textID = 64479,
    subUIKey = "UGC_Overview_MapManagement_UIBP"
  },
  [E_MapTab.Tab2] = {
    tabControl = "Tab_2",
    textID = 68661,
    subUIKey = "UGC_Data_MapManagement_UIBP"
  },
  [E_MapTab.Tab3] = {
    tabControl = "Tab_3",
    textID = 4600203,
    subUIKey = "UGC_Info_MapManagement_UIBP"
  },
  [E_MapTab.Tab4] = {
    tabControl = "Tab_4",
    textID = 8801603,
    subUIKey = "UGC_PromotionCard_MapManagement_UIBP"
  }
}
local TabGuideKeys = {
  [E_MapTab.Tab1] = "UGC_MapMgmt_Guide_Tab1_Overview",
  [E_MapTab.Tab2] = "UGC_MapMgmt_Guide_Tab2_Data",
  [E_MapTab.Tab3] = "UGC_MapMgmt_Guide_Tab3_Suggest",
  [E_MapTab.Tab4] = "UGC_MapMgmt_Guide_Tab4_Promotion"
}
local UGC_Main_MapManagement_UIBP = {}

function UGC_Main_MapManagement_UIBP:ctor(_, modInfo, extendedParams)
  self.modInfo = modInfo
  self.ModId = modInfo and not modInfo.mod_id and modInfo.base and modInfo.base.mod_id
  self.fullModMeta = nil
  self.extendedParams = extendedParams or {}
  self.sourceModule = self.extendedParams.sourceModule
  self.curTab = E_MapTab.Tab1
  self.subUIs = {}
  self.share_challenge_info = {}
  self.rawCommentCount = nil
end

function UGC_Main_MapManagement_UIBP:OnInitialize()
  UGC_Main_MapManagement_UIBP.__super.OnInitialize(self)
  self.UIRoot.TextBlock_Play:SetText(LocUtil.GetLocalizeResStr(82241))
end

function UGC_Main_MapManagement_UIBP:RegistEvents()
  UGC_Main_MapManagement_UIBP.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close2, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close3, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Play, self.OnClickPlay, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Duplicate, self.OnClickDuplicate, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Share, self.OnClickShare, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Recommend, self.OnClickRecommend, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_More, self.OnClickMore, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Message, self.OnClickMessage, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Edit, self.OnClickEdit, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Spread, self.OnClickSpread, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Obtain, self.OnClickObtain, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Warn, self.OnClickWarn, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_USE_EXPOSURE_COUPON, self.UpdateCouponCount, self)
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_HALL_DEPOT_DATA_CHANGE, self.UpdateCouponCount, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_DUPLICATE_MOD, self.OnDuplicateMod, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_COMMENT_REDPOINT_RSP, self.OnCommentRedPointRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_MOD_COMMENT_COUNT_RSP, self.OnGetModCommentCountRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_MOD_DETAIL_COMMENT_RSP, self.UpdateCommentCount, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_COMMENT_REPLY_INFO_RSP, self.UpdateCommentCount, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_APPRECIATIONGROUP_COMMENT_RSP, self.UpdateCommentCount, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_GET_PUBMETA, self.OnPubMetaRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SHOW_OPTIMIZE_GUIDE, self.ShowEditGuide, self)
  self:AddCommonEvent(EVENTTYPE_OLD_WIDGET, EVENTID_ON_ALL_WIDGET_HIDE, self.OnUIHide, self)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_1.Button_Tab, self.OnClickTab, self, E_MapTab.Tab1)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_2.Button_Tab, self.OnClickTab, self, E_MapTab.Tab2)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_3.Button_Tab, self.OnClickTab, self, E_MapTab.Tab3)
  self:AddOnClickedEventByControl(self.UIRoot.Tab_4.Button_Tab, self.OnClickTab, self, E_MapTab.Tab4)
end

function UGC_Main_MapManagement_UIBP:OnPostInitialize()
  UGC_Main_MapManagement_UIBP.__super.OnPostInitialize(self)
  self.UIRoot.Image_Glow:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  if self.modInfo then
    self.state = self.modInfo.base and self.modInfo.base.state_release or Config_UGC.E_PublishState.Not
  end
  self:CheckShowDownloader()
  self:UpdateSelfRecommend()
  self:RequestWorkData()
  self:InitTabText()
  self:ApplyRegionTabShield()
  self:SwitchTab(self.curTab)
  self:UpdateCouponCount()
  self:UpdateCommentCount()
  self:UpdateCommentRedDot(0)
  self:RequestCommentData()
  self:PlayUserWidgetAnimation(self.UIRoot.Auto_Fadein, 0, 1, 0, 1)
  self:AddOnAnimationFinishedEvent("Auto_Fadein", function()
    self:RemoveOnAnimationFinishedEvent("Auto_Fadein")
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_UGC_MAINPANEL_FADEIN_FINISHED)
    if self.bPendingShowEditGuide then
      self.bPendingShowEditGuide = false
      self:ShowEditGuide()
    end
  end)
  if self.extendedParams.bShowOptimizeGuide then
    self:ShowEditGuide()
  end
end

function UGC_Main_MapManagement_UIBP:RequestWorkData()
  local Logic_UGC_DataCenter = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_datacenter)
  if not Logic_UGC_DataCenter then
    return
  end
  local modId = self.ModId
  local cachedMeta = modId and Logic_UGC_DataCenter.ModData and Logic_UGC_DataCenter.ModData[modId]
  if cachedMeta then
    self:OnPubMetaRsp(nil, nil, modId, cachedMeta)
  end
  if modId and (not (cachedMeta and cachedMeta.offline_stat_data) or not next(cachedMeta.offline_stat_data)) then
    local UGCModHandler = require("client.network.Protocol.UGCModHandler")
    UGCModHandler.send_ugc_get_pub_meta_req(modId, "creation_center")
  end
  if modId then
    Logic_UGC_DataCenter.CurSelectModID = modId
    if not self:IsAbnormalState() then
      local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
      LogicUGCWorkDiagnosis:ReqDiagnosisBenchmark(modId)
    end
  end
end

function UGC_Main_MapManagement_UIBP:OnClose()
  self.bPendingShowEditGuide = false
  self:CloseTabGuide()
  self:CloseEditGuide()
  for _, subUI in pairs(self.subUIs) do
    if subUI then
      subUI:Close()
    end
  end
  self.subUIs = {}
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  if LogicUGC.modJumpCacheData then
    if type(LogicUGC.modJumpCacheData) == "number" then
      UIManager.ShowUI(UIManager.UI_Config.ugc_mine_edit_noromal_work, LogicUGC.modJumpCacheData)
    end
    LogicUGC:CacheModJumpData()
  end
  UGC_Main_MapManagement_UIBP.__super.OnClose(self)
end

function UGC_Main_MapManagement_UIBP:GetDataForJumpBack()
  return {
    ctorData = {
      [1] = self:GetCachedPubModMeta(),
      [2] = self.extendedParams
    },
    uiData = {
      curTab = self.curTab
    }
  }
end

function UGC_Main_MapManagement_UIBP:JumpBack(uiData)
  local curTab = uiData and uiData.curTab
  if curTab then
    self:SwitchTab(curTab)
  end
end

function UGC_Main_MapManagement_UIBP:OnClickClose()
  self:PlayAudio(sound_config.click_v1)
  UIManager.CloseUI(UIManager.UI_Config.UGC_Main_MapManagement_UIBP)
end

function UGC_Main_MapManagement_UIBP:OnClickTab(tabIndex)
  self:PlayAudio(sound_config.tab_v1)
  if self.curTab == tabIndex then
    return
  end
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  local str = string.format("requestId=%d", tabIndex)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MapManagement_Tab_Click, 0, str)
  self:SwitchTab(tabIndex, Config_UGC.TabExposeSource.TabSelected)
end

function UGC_Main_MapManagement_UIBP:OnClickPlay()
  self:PlayAudio(sound_config.click_v1)
  local UGCTLogReport = ModuleManager.GetModule(ModuleManager.DataModuleConfig.UGCTLogReport)
  UGCTLogReport:ReportDelay(TLogEventDefine.UGC_MapManagement_OpenDetail_Click)
  if UIManager.IsUIShow(UIManager.UI_Config.UGC_ModDetail_Main) then
    UIManager.CloseUI(UIManager.UI_Config.UGC_ModDetail_Main)
  end
  UIManager.ShowUI(UIManager.UI_Config.UGC_ModDetail_Main, nil, self:GetCachedPubModMeta(), self.extendedParams)
end

function UGC_Main_MapManagement_UIBP:GetCachedPubModMeta()
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local modCache = self.ModId and LogicUGC:GetModByAllCache(self.ModId)
  local listPubModMeta = modCache and modCache.pub_mod_meta
  if listPubModMeta then
    self.modInfo = listPubModMeta
  end
  return listPubModMeta or self.modInfo
end

function UGC_Main_MapManagement_UIBP:CheckInGame()
  return not GameStatus.IsInLobbyOrMainCity()
end

function UGC_Main_MapManagement_UIBP:OnClickDuplicate()
  self:PlayAudio(sound_config.subTab_v1)
  if self:CheckInGame() then
    ShowNotice(655733)
    return
  end
  Util_UGC.DuplicateWork(self:GetCachedPubModMeta())
end

function UGC_Main_MapManagement_UIBP:OnClickShare()
  self:PlayAudio(sound_config.subTab_v1)
  if self:CheckInGame() then
    ShowNotice(655733)
    return
  end
  Util_UGC.ShareWork(self:GetCachedPubModMeta(), self.share_challenge_info)
end

function UGC_Main_MapManagement_UIBP:OnClickRecommend()
  self:PlayAudio(sound_config.subTab_v1)
  Util_UGC.RecommendWork(self:GetCachedPubModMeta())
end

function UGC_Main_MapManagement_UIBP:OnClickMore()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.UGC_MoreSetting_Popup_UIBP, self:GetCachedPubModMeta())
end

function UGC_Main_MapManagement_UIBP:OnClickMessage()
  self:PlayAudio(sound_config.click_v1)
  local modId = self.ModId
  if modId then
    modId = tonumber(modId)
    self:UpdateCommentRedDot(0)
  end
  if IsWoWEditor then
    UIManager.CloseUI(UIManager.UI_Config.UGC_Main_MapManagement_UIBP)
    EventSystem:postEvent(EVENTTYPE_UGC, EVENTID_WOW_EDITOR_TAB_LOCATION, Config_UGC.Config_UGC_MineTabID.MessageCenter, nil, nil, Config_UGC.Config_UGC_MineTabID.Comment, modId)
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.ugc_mine_main, Config_UGC.Config_UGC_MineTabID.MessageCenter, nil, nil, nil, Config_UGC.Config_UGC_MineTabID.Comment, nil, modId)
end

function UGC_Main_MapManagement_UIBP:OnClickEdit()
  self:PlayAudio(sound_config.click_v1)
  if self.LastUpdateBtnClickTime and os.time() - self.LastUpdateBtnClickTime <= 10 then
    ShowNotice(16004103)
    return
  end
  self.LastUpdateBtnClickTime = os.time()
  self.bGotoEdit = Util_UGC.TryDuplicatePubModForEdit(self:GetCachedPubModMeta())
end

function UGC_Main_MapManagement_UIBP:OnPubMetaRsp(_, _, modId, meta)
  if not modId or not meta then
    return
  end
  local curModId = self.ModId
  if tostring(curModId) ~= tostring(modId) then
    return
  end
  if not meta.mod_id and (not meta.base or not meta.base.mod_id) then
    meta.mod_id = modId
  end
  if meta ~= self.fullModMeta then
    self:RefreshByMeta(meta)
  end
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  LogicUGCWorkDiagnosis:RunPreCheck(meta, nil)
end

function UGC_Main_MapManagement_UIBP:RefreshByMeta(meta)
  if not meta then
    return
  end
  self.fullModMeta = meta
  if meta.base then
    self.state = meta.base.state_release or Config_UGC.E_PublishState.Not
  end
  self:CheckShowDownloader()
  self:UpdateCommentCount()
  self:UpdateAbnormalStateButtons()
  self:UpdateWarningState()
  self:UpdateSelfRecommend()
end

function UGC_Main_MapManagement_UIBP:OnDuplicateMod(_, _, slot)
  if not self.bGotoEdit then
    return
  end
  self.bGotoEdit = false
  Util_UGC.EnterEditFromDuplicate(self:GetCachedPubModMeta(), slot)
end

function UGC_Main_MapManagement_UIBP:UpdateSpreadButtonText(state)
  local text
  if state == 1 then
    text = LocUtil.GetLocalizeResStr(8801609)
  elseif state == 2 then
    text = LocUtil.GetLocalizeResStr(8801611)
  elseif state == 3 then
    text = LocUtil.GetLocalizeResStr(4701066)
  end
  if text then
    self.UIRoot.TextBlock_Spread:SetText(text)
  end
end

function UGC_Main_MapManagement_UIBP:OnClickSpread()
  self:PlayAudio(sound_config.click_v1)
  local modId = self.ModId
  if not modId then
    return
  end
  UIManager.ShowUI(UIManager.UI_Config.UGCExposureCouponUsePopupUI, modId)
end

function UGC_Main_MapManagement_UIBP:OnClickObtain()
  self:PlayAudio(sound_config.click_v1)
  local PufferResManager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager)
  if not PufferResManager:IsLobbyResCompleted(true) then
    return
  end
  local LogicUGCExposure = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCExposure)
  local ObtainPathCfg = LogicUGCExposure:GetAvailableCouponObtainPath()
  if not ObtainPathCfg or not ObtainPathCfg.ClickFunc then
    log_warning("UGC_Main_MapManagement_UIBP:OnClickObtain, no available coupon obtain path")
    return
  end
  ObtainPathCfg.ClickFunc()
end

function UGC_Main_MapManagement_UIBP:OnClickWarn()
  self:PlayAudio(sound_config.click_v1)
  local modMeta = self:GetCachedPubModMeta()
  local reason = modMeta and modMeta.base and modMeta.base.state_reason
  local data = Config_UGC.GetModReasonConfigByID(reason)
  local reasonStr = data and data.Desc or ""
  local modName = modMeta and modMeta.setting and modMeta.setting.name
  local title = LocUtil.LocalizeResFormat(70097, modName)
  local content = LocUtil.LocalizeResFormat(70098, modName, reasonStr)
  local extraData = {
    showUIKey = "ugc_mine_edit_reason_detail",
    showModId = self.ModId
  }
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_FOUR, title, content, nil, nil, nil, nil, extraData)
end

function UGC_Main_MapManagement_UIBP:InitTabText()
  for _, config in pairs(MapTabConfig) do
    local tabWidget = self.UIRoot[config.tabControl]
    local text = LocUtil.GetLocalizeResStr(config.textID)
    tabWidget.TextBlock_TabText:SetText(text)
    tabWidget.TextBlock_TabText_2:SetText(text)
  end
end

function UGC_Main_MapManagement_UIBP:ApplyRegionTabShield()
  if not PublishRegionMacros.IsBlueholeOperationRegion() then
    return
  end
  local shieldTabs = {
    [E_MapTab.Tab2] = true
  }
  for tabIndex, tabConfig in pairs(MapTabConfig) do
    if shieldTabs[tabIndex] then
      self:SetWidgetVisible(self.UIRoot[tabConfig.tabControl], false, true)
    end
  end
end

function UGC_Main_MapManagement_UIBP:SwitchTab(tabIndex, source)
  local tabConfig = MapTabConfig[tabIndex]
  if not tabConfig then
    log_warning("UGC_Main_MapManagement_UIBP:SwitchTab, invalid tabIndex = " .. tostring(tabIndex))
    return
  end
  local oldUI = self.subUIs[self.curTab]
  if oldUI and oldUI.UIRoot and slua.isValid(oldUI.UIRoot) then
    oldUI:Collapsed()
  end
  self.curTab = tabIndex
  for curIndex, config in pairs(MapTabConfig) do
    local tabWidget = self.UIRoot[config.tabControl]
    tabWidget.WidgetSwitcher_Select:SetActiveWidgetIndex(curIndex == tabIndex and 0 or 1)
  end
  local subUIKey = tabConfig.subUIKey
  if not subUIKey then
    return
  end
  local newUI = self.subUIs[tabIndex]
  if newUI then
    newUI.exposeSource = source
    newUI:Show()
  else
    local uiConfig = UIManager.UI_Config[subUIKey]
    if uiConfig then
      local pubModMeta = self:GetCachedPubModMeta()
      local childExtendedParams = setmetatable({exposeSource = source, pubModMeta = pubModMeta}, {
        __index = self.extendedParams
      })
      newUI = self:CreateChildWindow(self.UIRoot.Panel_Content, uiConfig, pubModMeta, childExtendedParams)
      self.subUIs[tabIndex] = newUI
    end
  end
  self:UpdateButtonsVisibility(tabIndex)
  self:ShowTabGuide(tabIndex)
end

function UGC_Main_MapManagement_UIBP:UpdateCouponCount()
  local LogicUGCExposure = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCExposure)
  local couponCtn = LogicUGCExposure:GetCouponCtn()
  local couponText = LocUtil.GetLocalizeResStr(4701010)
  if 0 < couponCtn then
    couponText = LocUtil.LocalizeResFormat(4701064, tostring(couponCtn))
  end
  self.UIRoot.UTRichTextBlock_Comment:SetText(couponText)
  self:UpdateSpreadButtonVisibility()
end

function UGC_Main_MapManagement_UIBP:UpdateSpreadButtonVisibility()
  local LogicUGCExposure = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCExposure)
  local couponCtn = LogicUGCExposure:GetCouponCtn()
  local bShow = self.curTab == E_MapTab.Tab4 and 0 < couponCtn and not self:IsAbnormalState()
  self:SetWidgetVisible(self.UIRoot.Button_Spread, bShow, true)
end

function UGC_Main_MapManagement_UIBP:RequestCommentData()
  local modId = tonumber(self.ModId)
  if not modId or self:CheckInGame() then
    return
  end
  local logic_ugc_comment_switch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_switch)
  if not logic_ugc_comment_switch:CheckCommentSwitchOpen() then
    return
  end
  local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
  logic_ugc_new_work_detail_comment:send_ugc_get_mod_comment_count_req(modId)
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  logic_ugc_comment:send_ugc_get_comment_redpoint_req(modId)
  local pubModMeta = self.modInfo
  local logic_ugc_mod_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_detail_comment)
  local lastQuery = logic_ugc_mod_detail_comment.modDetailLastQuery
  local bCommentDataReady = lastQuery and tostring(lastQuery.modID) == tostring(modId) and logic_ugc_mod_detail_comment:HasAllReplyInfo()
  if not bCommentDataReady then
    logic_ugc_mod_detail_comment:SetModInfo(pubModMeta)
    logic_ugc_mod_detail_comment:SendModDetailCommentReq(modId)
  end
  if tostring(logic_ugc_new_work_detail_comment:GetModID()) == tostring(modId) and logic_ugc_new_work_detail_comment.bAppreciationReady then
    return
  end
  logic_ugc_new_work_detail_comment:ResetData()
  logic_ugc_new_work_detail_comment:SetModID(modId)
  local LobbySystem = require("client.logic.login.logic_lobby")
  if pubModMeta and pubModMeta.review_panel_data and pubModMeta.review_panel_data.avg_score and not PublishRegionMacros.IsBlueholeOperationRegion() and LobbySystem.CheckOpen(BP_ENUM_UGC_APPRECIATION_GROUP) then
    logic_ugc_new_work_detail_comment:send_ugc_get_review_panel_comment_info_req(modId)
  else
    logic_ugc_new_work_detail_comment:SetAppreciationNotRequired()
  end
end

function UGC_Main_MapManagement_UIBP:UpdateCommentCount()
  local modId = self.ModId
  if not modId then
    return
  end
  local commentCount = self.rawCommentCount
  if not commentCount then
    local CommentData = self.modInfo and self.modInfo.comment_data
    commentCount = CommentData and CommentData.comment_count or 0
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local modInfo = logic_ugc_comment:GetModInfo(modId)
    if modInfo and modInfo.comment_data and modInfo.comment_data.comment_count then
      commentCount = modInfo.comment_data.comment_count
    end
  end
  local appreciationCount = 0
  local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
  if tostring(logic_ugc_new_work_detail_comment:GetModID()) == tostring(modId) then
    appreciationCount = #logic_ugc_new_work_detail_comment:GetAppreciationCommentList(logic_ugc_new_work_detail_comment:GetAppreciationShowLimit())
  end
  local replyCount = 0
  local logic_ugc_mod_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_detail_comment)
  local lastQuery = logic_ugc_mod_detail_comment.modDetailLastQuery
  local commentModInfo = logic_ugc_mod_detail_comment.modInfo
  if lastQuery and commentModInfo and tostring(lastQuery.modID) == tostring(modId) and tostring(commentModInfo.mod_id) == tostring(modId) then
    replyCount = logic_ugc_mod_detail_comment:GetTotalReplyCount()
  end
  local StringUtil = require("common.string_util")
  local countText = StringUtil.FormatNumWithSpace_KMBT(commentCount + appreciationCount + replyCount, "%.1f")
  self.UIRoot.TextBlock_125:SetText(LocUtil.LocalizeResFormat(4701023, countText))
end

function UGC_Main_MapManagement_UIBP:OnGetModCommentCountRsp(_, _, err_code, count)
  if err_code ~= 0 then
    return
  end
  self.rawCommentCount = count or 0
  self:UpdateCommentCount()
end

function UGC_Main_MapManagement_UIBP:OnCommentRedPointRsp(_, _, modId, redPointCount, clubRedPointCount)
  local curModId = self.ModId
  if not modId or tostring(modId) ~= tostring(curModId) then
    return
  end
  local totalCount = (redPointCount or 0) + (clubRedPointCount or 0)
  self:UpdateCommentRedDot(totalCount)
end

function UGC_Main_MapManagement_UIBP:UpdateCommentRedDot(count)
  local reddot = self.UIRoot.Reddot_Anchor_Item02
  if not reddot then
    return
  end
  if count and 0 < count then
    if reddot.TextBlock_Num then
      reddot.TextBlock_Num:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
    self:SetWidgetVisible(reddot, true, true)
  else
    self:SetWidgetVisible(reddot, false, true)
  end
end

function UGC_Main_MapManagement_UIBP:UpdateButtonsVisibility(tabIndex)
  local bIsPromoTab = tabIndex == E_MapTab.Tab4
  self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_Edit, not bIsPromoTab, true)
  if tabIndex == E_MapTab.Tab1 then
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcherExt_State, true, true)
    self.UIRoot.WidgetSwitcherExt_State:SetActiveWidgetIndex(0)
  elseif tabIndex == E_MapTab.Tab4 then
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcherExt_State, true, true)
    self.UIRoot.WidgetSwitcherExt_State:SetActiveWidgetIndex(1)
    if PublishRegionMacros.IsBlueholeOperationRegion() then
      self:SetWidgetVisible(self.UIRoot.Panel_PromotionCard, false, true)
    end
  else
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcherExt_State, false, true)
  end
  self:UpdateSpreadButtonVisibility()
  self:UpdateAbnormalStateButtons()
  self:UpdateWarningState()
end

function UGC_Main_MapManagement_UIBP:IsAbnormalState()
  local state = self.state
  return state == Config_UGC.E_PublishState.ManualReview or state == Config_UGC.E_PublishState.Rectification
end

function UGC_Main_MapManagement_UIBP:UpdateAbnormalStateButtons()
  if not self:IsAbnormalState() then
    return
  end
  if self.state == Config_UGC.E_PublishState.ManualReview then
    self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_Edit, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_More, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Play, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Duplicate, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Share, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Recommend, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Message, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Spread, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Obtain, false, true)
  end
  if self.state == Config_UGC.E_PublishState.Rectification then
    self:SetWidgetVisible(self.UIRoot.Button_Play, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Duplicate, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Share, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Recommend, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Message, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Spread, false, true)
    self:SetWidgetVisible(self.UIRoot.Button_Obtain, false, true)
  end
end

function UGC_Main_MapManagement_UIBP:UpdateWarningState()
  if self.curTab ~= E_MapTab.Tab1 then
    self.UIRoot.SizeBox_Warning:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  local modMeta = self:GetCachedPubModMeta()
  local base = modMeta and modMeta.base
  local reason = base and base.state_reason
  local bShowWarning = false
  local warnText = ""
  if self.state == Config_UGC.E_PublishState.Rectification then
    local data = Config_UGC.GetModReasonConfigByID(reason)
    if data then
      bShowWarning = true
      warnText = data.Desc
    end
  elseif self.state == Config_UGC.E_PublishState.ManualReview and Util_UGC.IsModFreeze(reason) and reason == 60007 then
    local data = Config_UGC.GetModReasonConfigByID(reason)
    if data then
      bShowWarning = true
      warnText = data.Desc
    end
  end
  if bShowWarning then
    self.UIRoot.SizeBox_Warning:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.TextBlock_Warn:SetText(warnText)
  else
    self.UIRoot.SizeBox_Warning:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UGC_Main_MapManagement_UIBP:UpdateSelfRecommend()
  local bShow = true
  if PublishRegionMacros.IsBlueholeOperationRegion() or PublishRegionMacros.IsJapanOrKorea() then
    bShow = false
  end
  if not LobbySystem.CheckLobbyMenuOpen(BP_ENUM_UGC_SELF_RECOMMEND, false) then
    bShow = false
  end
  if self.state ~= Config_UGC.E_PublishState.Published then
    bShow = false
  end
  self:SetWidgetVisible(self.UIRoot.Button_Recommend, bShow, true)
end

function UGC_Main_MapManagement_UIBP:CheckShowDownloader()
  if not self.modInfo then
    return
  end
  local common_download_handler = require("client.slua.common.common_download_handler")
  local resManager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager)
  common_download_handler.CreateUGCDownloader(resManager.DownloadUIType.EditPubModMapMgmt, resManager.DownloaderType.MyWork, self.modInfo, self.UIRoot.CanvasPanel_Download, self.UIRoot.WidgetSwitcher_Edit, self, {
    UGCDownloadConfirmThreshold = 50,
    LinearColor = FLinearColor(0, 0, 0, 1),
    iconColor = FLinearColor(0, 0, 0, 1)
  })
end

function UGC_Main_MapManagement_UIBP:AdjustTipsToScreenEdge(tabWidget)
  local UIUtil = require("client.common.ui_util")
  local WidgetLayoutLibrary = import("WidgetLayoutLibrary")
  local tipsSlot = WidgetLayoutLibrary.SlotAsCanvasSlot(tabWidget.CanvasPanel_Tips)
  if not tipsSlot then
    return
  end
  local left = 0
  local top = 0
  local bottom = 0
  if tipsSlot.LayoutData and tipsSlot.LayoutData.Offsets then
    left = tipsSlot.LayoutData.Offsets.Left
    top = tipsSlot.LayoutData.Offsets.Top
    bottom = tipsSlot.LayoutData.Offsets.Bottom
  end
  local screenPadding = UIUtil.GetScreenPadding()
  local minPadding = 10
  local newRight = minPadding - screenPadding.Right
  tipsSlot:SetOffsets(FMargin(left, top, newRight, bottom))
end

function UGC_Main_MapManagement_UIBP:ShowTabGuide(tabIndex)
  self:CloseTabGuide()
  local guideKey = TabGuideKeys[tabIndex]
  if not guideKey then
    return
  end
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local prefType = PlayerPrefsSystem.ePlayerPrefsType.eUGCMapMgmtTabGuideShown
  local record = PlayerPrefsSystem.LoadFileToTable_N(prefType) or {}
  if record[guideKey] == true then
    return
  end
  local tabConfig = MapTabConfig[tabIndex]
  if not tabConfig then
    return
  end
  local tabWidget = self.UIRoot[tabConfig.tabControl]
  if not tabWidget then
    return
  end
  local guideTextIDs = {
    [E_MapTab.Tab1] = 4701011,
    [E_MapTab.Tab2] = 4701012,
    [E_MapTab.Tab3] = 4701013,
    [E_MapTab.Tab4] = 4701014
  }
  local text = LocUtil.GetLocalizeResStr(guideTextIDs[tabIndex])
  local ext = {str = text, dir_state = 2}
  self:AdjustTipsToScreenEdge(tabWidget)
  self.tabGuideUI = self:CreateChildWindow(tabWidget.CanvasPanel_Tips, UIManager.UI_Config.Common_Guide_Tips_UIBP, ext)
  self.tabGuideMaskUI = UIManager.ShowUI(UIManager.UI_Config.Common_Mask_UIBP, 0, function()
    self:CloseTabGuide()
  end)
  record[guideKey] = true
  PlayerPrefsSystem.SaveTableToFile_N(record, prefType)
end

function UGC_Main_MapManagement_UIBP:CloseTabGuide()
  if self.tabGuideUI then
    self.tabGuideUI:CloseSelf()
    self.tabGuideUI = nil
  end
  if self.tabGuideMaskUI then
    self.tabGuideMaskUI:CloseSelf()
    self.tabGuideMaskUI = nil
  end
end

function UGC_Main_MapManagement_UIBP:ShowEditGuide()
  if not self.UIRoot.WidgetSwitcher_Edit:IsVisible() then
    return
  end
  if self:IsAnimationPlaying("Auto_Fadein") then
    self.bPendingShowEditGuide = true
    return
  end
  local modId = self.ModId
  local LogicUGCWorkDiagnosis = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_work_diagnosis)
  if LogicUGCWorkDiagnosis and LogicUGCWorkDiagnosis:IsOptimizeGuideShown(modId) then
    return
  end
  self:CloseEditGuide()
  local tipsParam = {
    widget = self.UIRoot.WidgetSwitcher_Edit,
    content = LocUtil.GetLocalizeResStr(4600222),
    ArrowDirection = 2
  }
  UIManager.ShowUI(UIManager.UI_Config.UGC_CommonTextTips_UIBP, tipsParam)
  self.UIRoot.Image_Glow:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  if LogicUGCWorkDiagnosis then
    LogicUGCWorkDiagnosis:MarkOptimizeGuideShown(modId)
  end
end

function UGC_Main_MapManagement_UIBP:CloseEditGuide()
  if UIManager.IsUIShow(UIManager.UI_Config.UGC_CommonTextTips_UIBP) then
    UIManager.CloseUI(UIManager.UI_Config.UGC_CommonTextTips_UIBP)
  end
  self.UIRoot.Image_Glow:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
end

function UGC_Main_MapManagement_UIBP:OnUIHide(_, _, keyName)
  if keyName ~= UIManager.UI_Config.UGC_CommonTextTips_UIBP.keyName then
    return
  end
  self.UIRoot.Image_Glow:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUGC_Main_MapManagement_UIBP = class(ui_base, nil, UGC_Main_MapManagement_UIBP)
return CUGC_Main_MapManagement_UIBP
