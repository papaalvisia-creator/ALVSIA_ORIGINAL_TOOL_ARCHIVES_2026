local Hidden = UEnums.ESlateVisibility.Hidden
local Collapsed = UEnums.ESlateVisibility.Collapsed
local SelfHitTestInvisible = UEnums.ESlateVisibility.SelfHitTestInvisible
local subtab_interactive_action = {}

function subtab_interactive_action:ctor()
end

function subtab_interactive_action:OnShow()
  subtab_interactive_action.__super.OnShow(self)
  local logic_wardrobe_interactive_action = require("client.slua.logic.wardrobe.logic_wardrobe_interactive_action")
  logic_wardrobe_interactive_action.RequestInteractiveActionInfo()
end

function subtab_interactive_action:OnInitialize()
  subtab_interactive_action.__super.OnBeforeInitialize(self, self.UIRoot.LoopScrollGrid_Plating)
  subtab_interactive_action.__super.OnInitialize(self)
  self.LoopScrollGrid_Normal:AddItemWidgetChildEvent("Common_DragDrop_Item", "OnDragReadyToShape", self.OnActionDragReadyToShape, self)
  self.LoopScrollGrid_Normal:AddItemWidgetChildEvent("Common_DragDrop_Item", "OnDragCanCeled", self.OnActionDragCanceled, self)
  self.LoopScrollGridActionSlot = self:InitScrollBox(self.UIRoot.LoopScrollGridPlatingSlot)
  self.LoopScrollGridActionSlot:SetRefreshItemCallback(self.OnRefreshActionSlotItem, self)
  self.LoopScrollGridActionSlot:AddItemWidgetChildEvent("CommonDragDropItem", "OnDragSuccess", self.OnActionSlotDrop, self)
  self.LoopScrollGridActionSlot:AddItemWidgetChildEvent("CommonDragDropItem", "OnDragReadyToShape", self.OnActionSlotDrag, self)
  self.LoopScrollGridActionSlot:AddItemWidgetChildEvent("CommonDragDropItem", "OnDragCanCeled", self.OnActionSlotRemove, self)
  self.UIRoot.UTRichTextBlock_0:SetText(LocUtil.GetLocalizeResStr(10121))
end

function subtab_interactive_action:RegistEvents()
  subtab_interactive_action.__super.RegistEvents(self)
  self:AddCommonEvent(EVENTTYPE_WARDROBE, EVENTID_UPDATE_INTERACTIVE_ACTION_SLOT_LIST, self.OnUpateActionSlotList, self)
end

function subtab_interactive_action:OnDownloadFinish(eventType, eventID, eventData)
  subtab_interactive_action.__super.OnDownloadFinish(self, eventType, eventID, eventData)
  local SlotIcon_IconDownload = require("client.slua.component.item.ItemUtils.SlotIcon_IconDownload")
  if SlotIcon_IconDownload.ConsumeReady(self._tWaitingSlotIconIDs) and self.LoopScrollGridActionSlot then
    self.LoopScrollGridActionSlot:RefreshAllItems()
  end
end

function subtab_interactive_action:OnUpateActionSlotList()
  self:OnWardrobeDataChange()
end

function subtab_interactive_action:RefreshItemList()
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local logic_wardrobe = require("client.slua.logic.wardrobe.logic_wardrobe_new")
  local depotItemList = wardrobe_data:GetArrayHallDepotItemInfo()
  local itemListTable = {}
  local TimeUtil = require("client.common.time_util")
  local serverTime = TimeUtil.GetServerTimeInSec()
  for _, v in pairs(depotItemList) do
    if logic_wardrobe:IsValidCurrentPageItem(self.subTabConfig.pageId, self.subTabConfig.subTabId, v, serverTime) then
      local is_using = self:CheckUsing(v.insID)
      local itemInfo = logic_wardrobe:ArrayHallDepotToCommonItem(v, #itemListTable, is_using, false, false, false, false)
      table.insert(itemListTable, itemInfo)
    end
  end
  local SortPreference = logic_wardrobe:GetSortPreference(self.subTabConfig)
  logic_wardrobe:SortItemTable(itemListTable, SortPreference)
  subtab_interactive_action.__super.UpdateItemList(self, itemListTable)
end

function subtab_interactive_action:CheckUsing(insId)
  local logic_wardrobe_interactive_action = require("client.slua.logic.wardrobe.logic_wardrobe_interactive_action")
  local equipData = logic_wardrobe_interactive_action.GetSlotEquipData()
  for _, v in pairs(equipData) do
    if v == tonumber(insId) then
      return true
    end
  end
  return false
end

function subtab_interactive_action:OnRefreshListItem(widget, index)
  subtab_interactive_action.__super.OnRefreshListItem(self, widget, index)
  local widgetData = self.LoopScrollGrid_Normal:GetItemData(index)
  if widgetData then
    local DragDropItem = widget.Common_DragDrop_Item
    DragDropItem:SetEnable(true)
    DragDropItem:SetDragEnable(true)
    DragDropItem:RegisterDrag(1, 0, 0, widgetData.ins_id)
  end
end

function subtab_interactive_action:OnClickItem(widget, index)
  subtab_interactive_action.__super.OnClickItem(self, widget, index)
  local itemData = self.LoopScrollGrid_Normal:GetItemData(index)
  if itemData and not DataMgr.IsValidTime(itemData.expireTS) then
    ShowNotice(9910101)
    return
  end
  local wardrobe_red_point = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point)
  local tabId = wardrobe_red_point:GetTabIdByRes(itemData.res_id)
  wardrobe_red_point:ProcessOnSelectTab(tabId)
  local tipsMgr = require("client.slua.umg.Wardrobe.tips.item_tips_mgr")
  tipsMgr:Show(tipsMgr.ENUM_ITEM_TIPS_TYPE.ENUM_ITEM_TIPS_TYPE_TINY, itemData.ins_id, itemData.res_id)
  local logic_wardrobe = require("client.slua.logic.wardrobe.logic_wardrobe_new")
  if logic_wardrobe:IsItemIsolated(itemData.res_id) then
    ShowNotice(4987)
  end
end

function subtab_interactive_action:RefreshActionSlot()
  local slotDisplayList = {}
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local logic_wardrobe_interactive_action = require("client.slua.logic.wardrobe.logic_wardrobe_interactive_action")
  local equipData = logic_wardrobe_interactive_action.GetSlotEquipData()
  for _, v in ipairs(equipData) do
    local itemData = wardrobe_data:GetValidHallDepotItemDataByInsID(v)
    if itemData then
      table.insert(slotDisplayList, itemData)
    end
  end
  local deltaSlotCount = logic_wardrobe_interactive_action.GetMaxSlotCount() - logic_wardrobe_interactive_action.GetSlotEquipCount()
  for _ = 1, deltaSlotCount do
    table.insert(slotDisplayList, {})
  end
  self._tWaitingSlotIconIDs = nil
  self.LoopScrollGridActionSlot:SetData(slotDisplayList)
end

function subtab_interactive_action:OnRefreshActionSlotItem(widget, index)
  local widgetData = self.LoopScrollGridActionSlot:GetItemData(index)
  local DragDropItem = widget.CommonDragDropItem
  local logic_wardrobe_interactive_action = require("client.slua.logic.wardrobe.logic_wardrobe_interactive_action")
  local isEquiped = index <= logic_wardrobe_interactive_action.GetSlotEquipCount()
  if isEquiped and widgetData and widgetData.insID then
    DragDropItem:SetDragEnable(true)
    DragDropItem:RegisterDrag(1, 0, 0, widgetData.insID)
  else
    DragDropItem:SetDragEnable(false)
    DragDropItem:RegisterDrag(1, 0, 0, "")
  end
  DragDropItem:SetEnable(true)
  DragDropItem:RegisterDrop(1)
  self:RefreshSlotItem(widget, index, widgetData, isEquiped)
end

function subtab_interactive_action:RefreshSlotItem(widget, index, widgetData, isEquiped)
  local icon = widget.Icon
  local empty = widget.IsEmpty
  widget.TextBlock_Num:SetWidgetVisibility(Collapsed)
  widget.TextBlock_Index:SetWidgetVisibility(Collapsed)
  if isEquiped and widgetData and next(widgetData) ~= nil then
    local itemCfg = CDataTable.GetTableData("Item", widgetData.resID)
    if itemCfg then
      local SlotIcon_IconDownload = require("client.slua.component.item.ItemUtils.SlotIcon_IconDownload")
      self._tWaitingSlotIconIDs = SlotIcon_IconDownload.Paint(self, icon, widgetData.resID, self._tWaitingSlotIconIDs)
      empty:SetWidgetVisibility(Collapsed)
      icon:SetWidgetVisibility(SelfHitTestInvisible)
    end
  else
    icon:SetWidgetVisibility(Collapsed)
    empty:SetWidgetVisibility(SelfHitTestInvisible)
  end
end

function subtab_interactive_action:OnActionDragReadyToShape(DragWidget, Index, GeneratedWidget, DragDropData)
  local widgetData = self.LoopScrollGrid_Normal:GetItemData(Index)
  self:RefreshDragWidget(GeneratedWidget, widgetData)
  self:BeginActionDragHint(1)
end

function subtab_interactive_action:RefreshDragWidget(widget, data)
  local icon = widget.Image_Icon
  local resID = data.resID or data.res_id
  local itemCfg = CDataTable.GetTableData("Item", resID)
  if itemCfg then
    self:SetTexture(icon, itemCfg.ItemSmallIcon, {sync = false})
    icon:SetWidgetVisibility(SelfHitTestInvisible)
  end
end

function subtab_interactive_action:OnActionDragCanceled()
  self:EndActionDragHint()
end

function subtab_interactive_action:OnActionSlotDrag(DragWidget, Index, GeneratedWidget, DragDropData)
  local actionData = self.LoopScrollGridActionSlot:GetItemData(Index)
  self:RefreshDragWidget(GeneratedWidget, actionData)
  self:BeginActionDragHint(0)
end

function subtab_interactive_action:OnActionSlotDrop(DragWidget, Index, DragDropData)
  self:PlayAudio(sound_config.click_v1)
  self:EndActionDragHint()
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local insId = tonumber(DragDropData.dragExtendData)
  local actionData = wardrobe_data:GetHallDepotItemDataByInsID(insId)
  if actionData and not DataMgr.IsValidTime(actionData.expireTS) then
    ShowNotice(9910101)
    self:RefreshItemList()
    return
  end
  local widgetData = self.LoopScrollGridActionSlot:GetItemData(Index)
  if widgetData and widgetData.insID and widgetData.insID ~= "" and widgetData.insID == insId then
    return
  end
  local logic_wardrobe_interactive_action = require("client.slua.logic.wardrobe.logic_wardrobe_interactive_action")
  logic_wardrobe_interactive_action.EquipInteractiveAction(Index, insId)
end

function subtab_interactive_action:OnActionSlotRemove(DragWidget, Index, DragDropData)
  self:PlayAudio(sound_config.click_v1)
  self:EndActionDragHint()
  local logic_wardrobe_interactive_action = require("client.slua.logic.wardrobe.logic_wardrobe_interactive_action")
  logic_wardrobe_interactive_action.UnEquipInteractiveAction(Index)
end

function subtab_interactive_action:BeginActionDragHint(selection)
  local widgetSwitcherDrag = self.UIRoot.WidgetSwitcher_PlatingDrag
  widgetSwitcherDrag:SetWidgetVisibility(SelfHitTestInvisible)
  widgetSwitcherDrag:SetActiveWidgetIndex(selection)
end

function subtab_interactive_action:EndActionDragHint()
  local widgetSwitcherDrag = self.UIRoot.WidgetSwitcher_PlatingDrag
  widgetSwitcherDrag:SetWidgetVisibility(Hidden)
end

function subtab_interactive_action:SortElements()
  local WardrobeLogicManager = require("client.slua.logic.wardrobe.logic_wardrobe_new")
  local SortPreference = WardrobeLogicManager:GetSortPreference(self.subTabConfig)
  local itemList = self.LoopScrollGrid_Normal:GetSetData()
  WardrobeLogicManager:SortItemTable(itemList, SortPreference)
end

function subtab_interactive_action:ReSortItem()
  self:SortElements()
  local itemList = self.LoopScrollGrid_Normal:GetSetData()
  self:UpdateItemListBySort(itemList)
end

function subtab_interactive_action:OnWardrobeDataChange()
  self:RefreshItemList()
  self:RefreshActionSlot()
end

local class = require("class")
local ui_subtab_item_list_base = require("client.slua.umg.Wardrobe.subtab_item_list_base")
local CWardrobeInteractiveAction = class(ui_subtab_item_list_base, nil, subtab_interactive_action)
return CWardrobeInteractiveAction
