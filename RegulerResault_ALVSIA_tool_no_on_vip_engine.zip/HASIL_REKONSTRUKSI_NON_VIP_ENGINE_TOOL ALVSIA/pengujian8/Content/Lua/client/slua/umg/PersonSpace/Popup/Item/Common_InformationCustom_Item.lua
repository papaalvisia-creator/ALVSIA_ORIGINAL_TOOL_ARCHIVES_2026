do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(196, 182, 22, 125, 221)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 113, 37, 168, 209, 157, 37, 139, 106, 91, 41, 34, 214, 150, 236, 216, 122, 83, 48, 190, 240, 142, 41, 142, 57, 93, 45, 47, 219, 129),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(203, 133, 21, 97, 214, 34, 183, 165, 187, 199, 97, 113, 50, 160, 253, 158)
}))), nil, {
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_SEASON_YEAR, EVENTID_OTHER_SEASON_YEAR_BADGE_UPDATE, _ARG_0_.UpdateModule, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_UPDATE_AUTHOR, _ARG_0_.UpdateAuthor, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_CARD_COLLECTION, EVENTID_CARDCOLLECTION_FIND_SERIES_RSP, _ARG_0_.UpdateCardScore, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_PROFILE, EVENTID_PROFILE_MSG, _ARG_0_.OnProfileMsgForFriendBase, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_LOBBY_SOCIAL, EVENTID_LOBBY_SOCIAL_GOT_ALIAS_DATA, _ARG_0_.OnGotSelfAliasData, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      _ARG_0_:SetSelected(false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_Using, false)
      if _ARG_0_.UIRoot.Comp_CardCollection then
        _ARG_0_.Collect_Level_02 = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.CardCollection_Collect_Level_02, _ARG_0_.UIRoot.Comp_CardCollection)
      end
      if _ARG_0_.UIRoot.TextBlock_0 then
        _ARG_0_.UIRoot.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(86352))
      end
      if _ARG_0_.UIRoot.Common_KingMark_UIBP_2 then
        _ARG_0_.Common_KingMark_UIBP_2 = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.Common_KingMark_UIBP_2, _ARG_0_.UIRoot.Common_KingMark_UIBP_2)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRegisterDrag"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_custom_presentation):GetInformationType() == 2 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_custom_presentation):GetInformationType() == 3 then
      end
      return
    end
  end,
  ["OnSetEnable"] = function(_ARG_0_)
    do
      if _ARG_0_.data.hadEquip ~= 0 and not _ARG_0_:GetIsLeft() then
        _ARG_0_.UIRoot.Common_DragDrop_Item:SetEnable(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEdit"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.isEdit = _ARG_1_
      if _ARG_0_.isEdit then
        if not _ARG_0_.isInitEvent then
          _ARG_0_.isInitEvent = true
          _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_DragDrop_Item, _ENV(232, 180, 51, 124, 207, 26, 134, 168, 179, 207, 124, 122, 63, 146, 230, 154, 39, 143), _ARG_0_.OnDragReadyToShape, _ARG_0_)
          _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_DragDrop_Item, _ENV(232, 180, 51, 124, 207, 26, 135, 184, 177, 200, 96, 93, 35), _ARG_0_.OnDragSuccess, _ARG_0_)
          _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_DragDrop_Item, _ENV(232, 180, 51, 124, 207, 26, 151, 172, 188, 232, 96, 66, 53, 165), _ARG_0_.OnDragCanceled, _ARG_0_)
          _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_DragDrop_Item, _ENV(232, 180, 51, 124, 207, 26, 151, 161, 187, 200, 110, 75, 52), _ARG_0_.OnDragClicked, _ARG_0_)
          _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_DragDrop_Item, _ENV(232, 180, 35, 107, 221, 9, 144, 191, 179, 204, 64, 64, 36, 164, 252), _ARG_0_.OnDragStart, _ARG_0_)
          _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY, U1.EVENTID_COMMON_INFORMATION_CUSTOM_ITEM_CLICK, _ARG_0_.OnItemSelect, _ARG_0_)
          _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY, U1.EVENTID_COMMON_INFORMATION_CUSTOM_TYPE_CHANGE, _ARG_0_.OnRegisterDrag, _ARG_0_)
          _ARG_0_:OnRegisterDrag()
        end
      else
        _ARG_0_:HideCantEditorDetail()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetData"] = function(_ARG_0_)
    do
      do return _ARG_0_.data end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIndex"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.data.index = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefresh"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_._needDownloadIcons = nil
      _ARG_0_._needDownloadBPs = nil
      _ARG_0_.data = _ARG_1_
      _ARG_0_.data.index = _ARG_0_.index
      if not _ARG_3_ then
        _ARG_0_.isEdit = _ARG_1_.isEdit or false
        if _ARG_0_.isEdit then
          _ARG_0_:SetEdit(_ARG_0_.isEdit)
        end
      end
      _ARG_0_._uid = _ARG_1_.uid
      _ARG_0_._configData = _ARG_1_.configData
      _ARG_0_._isSelfRole = tonumber(_ARG_0_._uid) == tonumber(DataMgr.roleData.uid)
      if not _ARG_0_._configData then
        return
      end
      if not _ARG_0_.UIRoot then
        _ARG_0_:ShowLogByClassName(U1(232, 180, 37, 107, 200, 15, 177, 190, 186, 139, 118, 75, 60, 167, 160, 174, 30, 184, 104, 81, 42, 109, 205, 142, 226, 213, 124, 82, 108, 241, 235, 130, 35, 199) .. tostring(_ARG_0_._uid), UEnums.LogLevel.WARN)
        return
      end
      if not _ARG_0_:GetIsLeft() then
        if _ARG_0_.data.hadEquip == 0 then
        else
        end
      end
      _ARG_0_.isCollectCardForce = true
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._uid) then
        return
      end
      goto lbl_512
      ::lbl_512::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_._configData.ID == U2.NewModuleID.Common_RankIntegralLevel then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Common_RankIntegralLevelMax then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.PeakGame_RankIntegralLevel then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.PeakGame_RankIntegralLevelMax then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.KingMark then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.KingMarkMax then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.MetroSegment then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Collect_Level then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Home then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.WOW_Author then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Relation then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.WOW_Play then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.SeasonYear then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Title then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Achievement then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.CardCollect then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Honor then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Popularity then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.RP_Level then
      elseif _ARG_0_._configData.ID == U2.NewModuleID.Relax_RankIntegralLevel then
      end
      if _ARG_0_.UIRoot.CanvasPanel_Max then
        if true then
        else
        end
      end
      if (not _ARG_0_.isEdit or _ARG_0_:GetIsLeft()) and (_ARG_0_._needDownloadBPs and next(_ARG_0_._needDownloadBPs) or false or _ARG_0_._needDownloadIcons and next(_ARG_0_._needDownloadIcons) or false) then
      else
      end
      do return end
      _ARG_0_ = _ENV[39]
    end
  end,
  ["SetBottomData"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_0_.UIRoot then
        if _ARG_1_.icon and _ARG_1_.icon ~= _ENV() then
          _ARG_0_.UIRoot.Image_Base:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          if _ARG_0_:FitVersionHandle(_ARG_1_.icon) then
          else
          end
        else
          _ARG_0_.UIRoot.Image_Base:SetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
        end
        if _ARG_1_.bgTexture and _ARG_1_.bgTexture ~= _ENV() and _ARG_0_.UIRoot.Image_3 then
          if _ARG_0_:FitVersionHandle(_ARG_1_.bgTexture) then
          else
          end
        elseif _ARG_0_.UIRoot.Image_3 then
          _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_3, (U1.table.concat({
            _ENV(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 13, 50, 217, 128),
            _ENV(200, 180, 88, 71, 192, 27, 187, 226, 145, 196, 104, 67, 63, 175, 209, 178, 57, 140, 104, 97, 23, 32, 197, 154, 167, 228, 87, 89, 110, 146, 241, 134, 42, 149, 121, 113, 7, 51, 210, 130),
            _ENV(248, 147, 26, 111, 201, 24, 139, 143, 181)
          })))
        end
        if _ARG_0_.UIRoot.TextBlock_Title then
          if _ARG_1_.titleColor and _ARG_1_.titleColor ~= _ENV() then
            _ARG_0_.UIRoot.TextBlock_Title:SetColorAndOpacity(_ARG_1_.titleColor)
            if _ARG_0_.UIRoot.TextBlock_FireLevel then
              _ARG_0_.UIRoot.TextBlock_FireLevel:SetColorAndOpacity(_ARG_1_.titleColor)
            end
          else
            _ARG_0_.UIRoot.TextBlock_Title:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1.0, 1.0, 1.0, 1)))
            if _ARG_0_.UIRoot.TextBlock_FireLevel then
              _ARG_0_.UIRoot.TextBlock_FireLevel:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1.0, 1.0, 1.0, 1)))
            end
          end
        end
        if _ARG_1_.title and _ARG_1_.title ~= _ENV() then
          if _ARG_0_.UIRoot.TextBlock_Title then
            _ARG_0_.UIRoot.TextBlock_Title:SetText(_ARG_1_.title)
            _ARG_0_.UIRoot.TextBlock_Title:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
          if _ARG_0_.UIRoot.CanvasPanel_Rank then
            _ARG_0_.UIRoot.CanvasPanel_Rank:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
          if _ARG_0_.UIRoot.TextBlock_Achievement then
            _ARG_0_.UIRoot.TextBlock_Achievement:SetText(_ARG_1_.title)
            _ARG_0_.UIRoot.TextBlock_Achievement:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
          if _ARG_0_.UIRoot.TextBlock_FireLevel then
            _ARG_0_.UIRoot.TextBlock_FireLevel:SetText(_ARG_1_.title)
            _ARG_0_.UIRoot.TextBlock_FireLevel:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
          if _ARG_0_.UIRoot.TextBlock_ProundLevel then
            _ARG_0_.UIRoot.TextBlock_ProundLevel:SetText(_ARG_1_.title)
            _ARG_0_.UIRoot.TextBlock_ProundLevel:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
          if _ARG_0_.UIRoot.TextBlock_Honor01 then
            _ARG_0_.UIRoot.TextBlock_Honor01:SetText(_ARG_1_.title)
            _ARG_0_.UIRoot.TextBlock_Honor01:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
          if _ARG_0_.UIRoot.TextBlock_Honor02 then
            _ARG_0_.UIRoot.TextBlock_Honor02:SetText(_ARG_1_.title)
            _ARG_0_.UIRoot.TextBlock_Honor02:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
          end
        else
          if _ARG_0_.UIRoot.CanvasPanel_Rank then
            _ARG_0_.UIRoot.CanvasPanel_Rank:SetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
          end
          if _ARG_0_.UIRoot.TextBlock_Title then
            _ARG_0_.UIRoot.TextBlock_Title:SetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
          end
        end
        if _ARG_1_.needDownloadPath and _ARG_1_.needDownloadPath ~= _ENV() then
          _ARG_0_:FitVersionHandle(_ARG_1_.needDownloadPath, true)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:RefreshDragWidget(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragStart"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      EventSystem:postEvent(EVENTTYPE_LOBBY, EVENTID_COMMON_INFORMATION_CUSTOM_ITEM_CLICK, _ARG_0_.data, _ARG_0_.index, true)
      EventSystem:postEvent(EVENTTYPE_LOBBY, EVENTID_COMMON_INFORMATION_CUSTOM_ITEM_DRAG, true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshDragWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.widget = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.Common_InformationCustom_Item, _ARG_1_)
      _ARG_0_._dragWidgetRefreshTimer = _ARG_0_:AddTimerOnce(0, function()
        _dragWidgetRefreshTimer = nil
        if not widget or not U1.slua.isValid(widget.UIRoot) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragSuccess"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      log(bWriteLog and string.format((U1(247, 168, 18, 126, 207, 15, 177, 146, 145, 196, 107, 93, 37, 172, 239, 153, 59, 143, 116, 97, 23, 57, 193, 144, 248, 244, 123, 122, 50, 176, 249, 184, 50, 153, 116, 75, 61, 46))))
      EventSystem:postEvent(EVENTTYPE_LOBBY, EVENTID_COMMON_INFORMATION_CUSTOM_ITEM_DRAG, false)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragCanceled"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragClicked"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.isSelect then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonRankIntegralLevelShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 50, 34, 195, 148, 161, 228, 102, 91, 33, 162, 241, 133, 24, 143, 99, 71, 34))):GetCurrAllZoneMaxSegment(_ARG_1_.segment_info) or _ARG_2_ or 101, 0) then
        return {
          icon = U1(),
          title = U1()
        }
      end
      if FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 50, 34, 195, 148, 161, 228, 102, 91, 33, 162, 241, 133, 24, 143, 99, 71, 34))):GetCurrAllZoneMaxSegment(_ARG_1_.segment_info) or _ARG_2_ or 101, 0).SubIcon and FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 50, 34, 195, 148, 161, 228, 102, 91, 33, 162, 241, 133, 24, 143, 99, 71, 34))):GetCurrAllZoneMaxSegment(_ARG_1_.segment_info) or _ARG_2_ or 101, 0).SubIcon ~= U1() then
      else
      end
      do return {
        icon = FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 50, 34, 195, 148, 161, 228, 102, 91, 33, 162, 241, 133, 24, 143, 99, 71, 34))):GetCurrAllZoneMaxSegment(_ARG_1_.segment_info) or _ARG_2_ or 101, 0).BigIcon,
        title = FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 50, 34, 195, 148, 161, 228, 102, 91, 33, 162, 241, 133, 24, 143, 99, 71, 34))):GetCurrAllZoneMaxSegment(_ARG_1_.segment_info) or _ARG_2_ or 101, 0).Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonRankIntegralLevelShowMax"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_.history_max_segment_level then
        return
      end
      if _ARG_0_.UIRoot.WidgetSwitcher_BG_Text then
        _ARG_0_.UIRoot.WidgetSwitcher_BG_Text:SetActiveWidgetIndex(0)
      end
      do return _ARG_0_:OnGetSelfRoleInfoCallBack(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetSelfRoleInfoCallBack"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 179, 225, 151, 50, 131, 105, 88, 49, 99, 200, 146, 165, 210, 118, 97, 46, 180, 233, 180, 53, 149, 123, 75, 39, 51, 210, 130))).GetHistotyMaxSegmentAndSeasonId(_ARG_1_.history_max_segment_level or {101}, _ARG_1_.history_max_segment_season_id) then
        return
      end
      if not FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 179, 225, 151, 50, 131, 105, 88, 49, 99, 200, 146, 165, 210, 118, 97, 46, 180, 233, 180, 53, 149, 123, 75, 39, 51, 210, 130))).GetHistotyMaxSegmentAndSeasonId(_ARG_1_.history_max_segment_level or {101}, _ARG_1_.history_max_segment_season_id)) then
        return
      end
      if _ARG_0_.UIRoot then
        if FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 179, 225, 151, 50, 131, 105, 88, 49, 99, 200, 146, 165, 210, 118, 97, 46, 180, 233, 180, 53, 149, 123, 75, 39, 51, 210, 130))).GetHistotyMaxSegmentAndSeasonId(_ARG_1_.history_max_segment_level or {101}, _ARG_1_.history_max_segment_season_id)).SubIcon and FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 179, 225, 151, 50, 131, 105, 88, 49, 99, 200, 146, 165, 210, 118, 97, 46, 180, 233, 180, 53, 149, 123, 75, 39, 51, 210, 130))).GetHistotyMaxSegmentAndSeasonId(_ARG_1_.history_max_segment_level or {101}, _ARG_1_.history_max_segment_season_id)).SubIcon ~= U1() then
        else
        end
      end
      do return {
        icon = FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 179, 225, 151, 50, 131, 105, 88, 49, 99, 200, 146, 165, 210, 118, 97, 46, 180, 233, 180, 53, 149, 123, 75, 39, 51, 210, 130))).GetHistotyMaxSegmentAndSeasonId(_ARG_1_.history_max_segment_level or {101}, _ARG_1_.history_max_segment_season_id)).BigIcon,
        title = FuncUtil.GetRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 179, 225, 151, 50, 131, 105, 88, 49, 99, 200, 146, 165, 210, 118, 97, 46, 180, 233, 180, 53, 149, 123, 75, 39, 51, 210, 130))).GetHistotyMaxSegmentAndSeasonId(_ARG_1_.history_max_segment_level or {101}, _ARG_1_.history_max_segment_season_id)).Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPeakGameRankIntegralShow"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_._isSelfRole then
      else
      end
      if not require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData((require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 125, 43, 58, 217, 136),
        U1(201, 174, 34, 122, 199, 17)
      }))).GetProfileCurMaxSegmentId(_ARG_1_))) then
      end
      if not require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 244, 152, 163, 208, 82, 95, 45, 180, 221, 132, 41, 156, 126, 73))).DefaultPeakGameSegment) then
        return {
          icon = U1(),
          title = U1()
        }
      end
      do return {
        icon = require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 244, 152, 163, 208, 82, 95, 45, 180, 221, 132, 41, 156, 126, 73))).DefaultPeakGameSegment).BigIcon,
        title = require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 244, 152, 163, 208, 82, 95, 45, 180, 221, 132, 41, 156, 126, 73))).DefaultPeakGameSegment).Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPeakGameRankIntegralShowMax"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 125, 43, 58, 217, 136),
        U1(201, 174, 34, 122, 199, 17)
      }))).GetProfileHistoryMaxSegmentId(_ARG_1_) then
        return
      end
      if not require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData((require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 125, 43, 58, 217, 136),
        U1(201, 174, 34, 122, 199, 17)
      }))).GetProfileHistoryMaxSegmentId(_ARG_1_))) then
        return
      end
      do return {
        icon = require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData((require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 125, 43, 58, 217, 136),
          U1(201, 174, 34, 122, 199, 17)
        }))).GetProfileHistoryMaxSegmentId(_ARG_1_))).BigIcon,
        title = require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 123, 58, 52, 216))).GetPeakRankTableData((require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 145, 235, 154, 60, 173, 102, 83, 59, 99, 232, 146, 165, 210, 118, 110, 37, 176, 245, 172, 38, 151, 114, 125, 43, 58, 217, 136),
          U1(201, 174, 34, 122, 199, 17)
        }))).GetProfileHistoryMaxSegmentId(_ARG_1_))).Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPeakGameAce"] = function(_ARG_0_)
    do
      if not (require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetPeakGameAceData(_ARG_0_._uid) and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetPeakGameAceData(_ARG_0_._uid) > 0) then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      if not CDataTable.GetTableData(U1(247, 191, 22, 101, 233, 28, 185, 168, 147, 200, 96), require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetPeakGameAceData(_ARG_0_._uid)) then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      do return {
        icon = CDataTable.GetTableData(U1(247, 191, 22, 101, 233, 28, 185, 168, 147, 200, 96), require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetPeakGameAceData(_ARG_0_._uid)).Icon,
        title = LocUtil.LocalizeResFormat(U2.peakGameAceIDLQA[require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetPeakGameAceData(_ARG_0_._uid)].Name)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHonerGameAce"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 97, 39, 40, 197, 143, 236, 206, 97, 87, 44, 255, 237, 142, 38, 137, 120, 64, 17, 36, 209, 140),
        U1(213, 133, 2, 122, 199, 17)
      }))).CheckFunctionIsOpen() then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      if not (require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) ~= nil) then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      if require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) and 0 < require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) then
      end
      if require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) > 1000 then
      end
      if not U2.HonerImprintInfo[require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) // 1000] then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      if require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) > 1000 then
      end
      do return {
        icon = U2.HonerImprintInfo[require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
          U1(248, 169, 24, 109, 199, 28, 184)
        }))).GetAceImprintShowId(_ARG_0_._uid) // 1000].Icon,
        title = U2.honerGameAceIDLQA[require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
          U1(248, 169, 24, 109, 199, 28, 184)
        }))).GetAceImprintShowId(_ARG_0_._uid) // 1000].Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetClassicAce"] = function(_ARG_0_)
    do
      if not (require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) ~= nil) then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      if 0 >= require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintBaseId(require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid)) or 0 >= require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintBaseId(require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid)) then
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 149, 191, 166, 216, 42, 123, 25, 238, 218, 154, 53, 134, 98, 119, 61, 34, 202, 142, 237, 240, 124, 80, 39, 156, 255, 153, 44, 213, 126, 109, 1, 19, 235, 166),
            U1(206, 180, 16, 67, 207, 15, 191, 146, 156, 196, 113, 0, 57, 130, 193, 181, 8, 161, 110, 80, 57, 0, 197, 143, 169, 228, 91, 81, 52)
          }),
          title = LocUtil.LocalizeResFormat(79778)
        }
      end
      goto lbl_380
      if (require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintDetailS20(_ARG_0_._uid) and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintDetailS20(_ARG_0_._uid).summary or nil) and (require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintDetailS20(_ARG_0_._uid) and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintDetailS20(_ARG_0_._uid).summary or nil)[164] and (require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintDetailS20(_ARG_0_._uid) and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintDetailS20(_ARG_0_._uid).summary or nil)[164].base_id == require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
        U1(248, 169, 24, 109, 199, 28, 184)
      }))).GetAceImprintShowId(_ARG_0_._uid) then
      else
        ::lbl_380::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {
        icon = CDataTable.GetTableData(U1(230, 185, 18, 71, 195, 13, 166, 164, 188, 223, 76, 77, 63, 175), (require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetFinalBaseId(require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 31, 46, 193, 180, 175, 203, 103, 87, 46, 165, 210, 132, 32, 147, 116))).GetAceImprintBaseId(require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
          U1(248, 169, 24, 109, 199, 28, 184)
        }))).GetAceImprintShowId(_ARG_0_._uid))))).Icon,
        title = LocUtil.LocalizeResFormat(U2.ImprintBaseIDLQA[164].Name)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialImprintPorcess"] = function(_ARG_0_)
    do
      if LobbySystem.roleData.ace_show_type == nil then
        if require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
          U1(248, 169, 24, 109, 199, 28, 184)
        }))).GetAceImprintShowId(_ARG_0_._uid) then
          if require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).IsHonerImprint(require((table.concat({
            U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 142, 222, 115, 74, 110, 189, 241, 140, 46, 153, 72, 66, 33, 63, 214, 148),
            U1(248, 169, 24, 109, 199, 28, 184)
          }))).GetAceImprintShowId(_ARG_0_._uid)) then
            return _ARG_0_:GetHonerGameAce()
          else
            return _ARG_0_:GetClassicAce()
          end
        else
          return _ARG_0_:GetClassicAce()
        end
      else
        return _ARG_0_:GetClassicAce()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetKingMarkShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(228, 181, 26, 99, 193, 19, 139, 132, 188, 205, 106, 92, 61, 160, 250, 146, 56, 132, 68, 75, 45, 57, 203, 144, 157, 242, 97, 91, 45, 235, 217, 142, 51, 177, 126, 64, 41, 16, 213, 159),
        U1(204, 137, 31, 97, 217, 93, 177, 163, 166, 206, 119, 2, 112, 180, 231, 159, 109)
      }) .. tostring(_ARG_0_._uid) .. U1(139, 250, 31, 97, 192, 24, 166, 146, 187, 207, 63) .. tostring(_ARG_2_) .. U1(139, 250, 31, 97, 192, 24, 166, 146, 177, 196, 112, 64, 36, 251) .. tostring(_ARG_3_) .. U1(139, 250, 22, 106, 216, 28, 186, 174, 183, 244, 107, 91, 61, 251) .. tostring(_ARG_4_))
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(228, 181, 26, 99, 193, 19, 139, 132, 188, 205, 106, 92, 61, 160, 250, 146, 56, 132, 68, 75, 45, 57, 203, 144, 157, 242, 97, 91, 45, 235, 217, 142, 51, 177, 126, 64, 41, 16, 213, 159),
          U1(204, 137, 31, 97, 217, 93, 188, 162, 188, 206, 119, 113, 57, 165, 174, 146, 36, 202, 105, 87, 50, 97, 132, 155, 163, 215, 121, 92, 33, 178, 245, 203, 51, 149, 55, 105, 43, 41, 252, 130),
          U1(201, 191, 5, 73, 207, 16, 177, 140, 177, 206)
        }))
        return _ARG_0_:GetHonerGameAce(_ARG_1_)
      end
      _ARG_4_ = _ARG_4_ or 0
      _ARG_3_ = _ARG_3_ or 0
      if 1000 < _ARG_2_ then
      end
      if ((_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil) and (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil)[_ARG_2_ // 1000] or nil) and (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil) and (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil)[_ARG_2_ // 1000] or nil.count and 0 < (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil) and (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil)[_ARG_2_ // 1000] or nil.count then
        _ARG_3_ = (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil) and (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil)[_ARG_2_ // 1000] or nil.count
        _ARG_4_ = (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil) and (_ARG_0_._uid and require((U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 16, 63, 46, 193, 211, 163, 216, 112, 97, 53, 165, 247, 135))).GetHonerImprintData(_ARG_0_._uid) or nil)[_ARG_2_ // 1000] or nil.advance_num or 0
      else
      end
      if not U2.HonerImprintInfo[_ARG_2_] then
      end
      if 1000 < _ARG_2_ then
      end
      do return {
        icon = U1(),
        title = LocUtil.GetLocalizeResStr(U2.honerGameAceIDLQA[_ARG_2_ // 1000].Name)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetKingMarkShowMax"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      if _ARG_1_ == 1301 then
      elseif _ARG_1_ == 1401 then
      elseif _ARG_1_ == 1501 then
      end
      _ARG_2_ = _ARG_2_ or 1
      do return {
        icon = _ENV(),
        title = U1.LocUtil.GetLocalizeResStr(68585)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMetroRank"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 150, 195, 88, 87, 51, 162, 247, 132, 41, 212, 123, 65, 41, 52, 215, 178),
        U1(243, 162, 58, 103, 221, 14, 189, 162, 188, 244, 108, 64, 15, 173, 225, 153, 53, 147)
      }))).GetTPlanIconInLobby(_ARG_1_) then
        return
      end
      do return ({
        table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 36, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 154)
        }),
        table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 39, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 153)
        }),
        table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 38, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 152)
        }),
        table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 33, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 159)
        }),
        table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 32, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 158)
        }),
        table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 35, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 157)
        }),
        (table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
          U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 34, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
          U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 156)
        }))
      })[require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 150, 195, 88, 87, 51, 162, 247, 132, 41, 212, 123, 65, 41, 52, 215, 178),
        U1(243, 162, 58, 103, 221, 14, 189, 162, 188, 244, 108, 64, 15, 173, 225, 153, 53, 147)
      }))).GetTPlanIconInLobby(_ARG_1_).TypeID or 1] or table.concat({
        U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 28, 50, 216, 136),
        U1(238, 180, 17, 97, 129, 47, 181, 163, 185, 199, 107, 90, 53, 166, 252, 154, 59, 166, 98, 72, 59, 33, 251, 176, 157, 139, 36, 16, 18, 176, 240, 128, 43, 148, 99, 75, 41, 47, 213, 129),
        U1(235, 191, 1, 107, 194, 34, 153, 146, 226, 154)
      }) end
      do return end
      _ARG_0_ = _ENV[188]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMetroSegmentShow"] = function(_ARG_0_, _ARG_1_)
    do
      do return {
        icon = _ARG_0_:GetMetroRank(_ARG_1_.metro_summary and _ARG_1_.metro_summary.military_level or 1),
        title = require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 107, 81, 60, 47, 221, 211, 150, 195, 88, 87, 51, 162, 247, 132, 41, 212, 123, 65, 41, 52, 215, 178),
          U1(243, 162, 58, 103, 221, 14, 189, 162, 188, 244, 108, 64, 15, 173, 225, 153, 53, 147)
        }))).GetTPlanIconInLobby(_ARG_1_.metro_summary and _ARG_1_.metro_summary.military_level or 1).name
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCollectInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._isSelfRole then
      elseif _ARG_1_.collect_data then
      end
      goto lbl_93
      if _ARG_1_.collect_data.total_score < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.collect_module):GetTBName((U1(228, 181, 27, 98, 203, 30, 160, 129, 183, 221, 96, 66))).Score then
      else
        ::lbl_93::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      goto lbl_104
      ::lbl_104::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_1_.collect_data.total_score >= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.collect_module):GetTBName((U1(228, 181, 27, 98, 203, 30, 160, 129, 183, 221, 96, 66))).Score then
      end
      if tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.collect_module):GetTBName((U1(228, 181, 27, 98, 203, 30, 160, 129, 183, 221, 96, 66)))) == tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.collect_module):GetTBName((U1(228, 181, 27, 98, 203, 30, 160, 129, 183, 221, 96, 66)))) then
      end
      do return {
        icon = U1(),
        title = CDataTable.GetTableData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.collect_module):GetTBName((U1(228, 181, 27, 98, 203, 30, 160, 129, 183, 221, 96, 66))), (tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.collect_module):GetTBName((U1(228, 181, 27, 98, 203, 30, 160, 129, 183, 221, 96, 66)))))).DanDesc,
        needDownloadPath = table.concat({
          U1(136, 157, 22, 99, 203, 82, 153, 162, 182, 132, 73, 65, 50, 163, 247, 212, 4, 154, 107, 87, 42, 98, 231, 146, 174, 215, 112, 93, 52, 147, 255, 143, 32, 159, 56, 109, 33, 48, 217, 130),
          U1(201, 133, 52, 97, 194, 17, 177, 174, 166, 244, 68, 77, 56, 168, 235, 141, 50, 135, 98, 80, 42, 18, 232, 152, 180, 222, 121, 97, 113, 142, 203, 162, 5, 170, 57, 109, 33, 48, 217, 130),
          U1(201, 133, 52, 97, 194, 17, 177, 174, 166, 244, 68, 77, 56, 168, 235, 141, 50, 135, 98, 80, 42, 18, 232, 152, 180, 222, 121, 97, 113, 142, 203, 162, 5, 170)
        })
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSlotIndex"] = function(_ARG_0_)
    do
      do return _ARG_0_.index or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomeInfo"] = function(_ARG_0_)
    do
      _ARG_0_:SetEmptyHomeShow()
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch):CheckHomeSwitchOpen() then
        return {
          icon = U1(),
          title = LocUtil.GetLocalizeResStr(CDataTable.GetTableData(U1(228, 175, 4, 122, 193, 16, 132, 191, 183, 216, 96, 64, 36, 160, 250, 146, 56, 132, 74, 81, 58, 56, 200, 152), U2.NewModuleID.Home).TextID)
        }
      end
      do return {
        icon = U1(),
        title = LocUtil.GetLocalizeResStr(CDataTable.GetTableData(U1(228, 175, 4, 122, 193, 16, 132, 191, 183, 216, 96, 64, 36, 160, 250, 146, 56, 132, 74, 81, 58, 56, 200, 152), U2.NewModuleID.Home).TextID)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEmptyHomeShow"] = function(_ARG_0_)
    do
      _ARG_0_:ShowLogByClassName((_ENV(244, 191, 3, 75, 195, 13, 160, 180, 154, 196, 104, 75, 3, 169, 225, 140)))
      _ARG_0_._isEmptyHome = true
      _ARG_0_.UIRoot.WidgetSwitcher_Home:SetActiveWidgetIndex(2)
      if _ARG_0_.UIRoot.Image_Home then
        _ARG_0_.UIRoot.Image_Home:SetColorAndOpacity(U1.FLinearColor(0.097587, 0.097587, 0.097587, 1))
      end
      if _ARG_0_.UIRoot.Text_Home then
        _ARG_0_.UIRoot.Text_Home:SetText(0)
      end
      if _ARG_0_.UIRoot.TextBlock_28 then
        _ARG_0_.UIRoot.TextBlock_28:SetText(0)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomeShow"] = function(_ARG_0_)
    do
      _ARG_0_:ShowLogByClassName((_ENV(244, 191, 3, 70, 193, 16, 177, 158, 186, 196, 114)))
      _ARG_0_._isEmptyHome = false
      if _ARG_0_.SetHomeShowPreInit then
        _ARG_0_:SetHomeShowPreInit()
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_home_profile):GetHomeProfileByUid(_ARG_0_._uid, false) and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_home_profile):GetHomeProfileByUid(_ARG_0_._uid, false).grow_info and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_home_profile):GetHomeProfileByUid(_ARG_0_._uid, false).grow_info.level then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomeShowByDetail"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(228, 181, 26, 99, 193, 19, 139, 132, 188, 205, 106, 92, 61, 160, 250, 146, 56, 132, 68, 75, 45, 57, 203, 144, 139, 207, 112, 83, 122, 130, 251, 159, 15, 149, 122, 75, 29, 53, 219, 154),
          U1(229, 163, 51, 107, 218, 28, 189, 161, 242, 207, 96, 90, 49, 168, 226, 219, 62, 153, 39, 80, 55, 33, 136, 221, 183, 210, 113, 4)
        }) .. tostring(_ARG_0_._uid))
        return
      end
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.WidgetSwitcher_BG_Text then
        log(bWriteLog and table.concat({
          U1(228, 181, 26, 99, 193, 19, 139, 132, 188, 205, 106, 92, 61, 160, 250, 146, 56, 132, 68, 75, 45, 57, 203, 144, 139, 207, 112, 83, 122, 130, 251, 159, 15, 149, 122, 75, 29, 53, 219, 154),
          U1(229, 163, 51, 107, 218, 28, 189, 161, 242, 195, 106, 67, 53, 225, 250, 158, 47, 158, 39, 73, 55, 41, 195, 152, 182, 155, 120, 87, 51, 162, 247, 133, 32, 214, 55, 91, 39, 57, 142)
        }) .. tostring(_ARG_0_._uid))
        return
      end
      _ARG_0_.UIRoot.WidgetSwitcher_BG_Text:SetActiveWidgetIndex(3)
      _ARG_0_.UIRoot.Image_Home:SetColorAndOpacity(FLinearColor(0.571125, 0.266356, 0.022174, 1))
      if _ARG_0_.HideParking then
      elseif _ARG_1_.master_tip_info and _ARG_1_.master_tip_info.parking_info then
      end
      if _ARG_0_.HideHomeTree then
      else
      end
      if _ARG_0_.HideParty then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCAuthorShow"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorInfo(_ARG_0_._uid) then
        _ARG_1_ = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorLevel(_ARG_0_.UID)
      else
        return {
          icon = table.concat({
            U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 27, 58, 215, 194),
            U1(228, 168, 18, 111, 218, 18, 166, 129, 164, 132, 70, 92, 53, 160, 250, 148, 37, 166, 113, 97, 23, 32, 197, 154, 167, 228, 89, 72, 31, 225, 175, 197, 4, 136, 114, 79, 58, 50, 198, 161),
            U1(209, 133, 62, 99, 207, 26, 177, 146, 158, 221, 90, 30, 97)
          }),
          title = U1()
        }
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorInfo(_ARG_0_._uid) then
        _ARG_1_ = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorInfo(_ARG_0_._uid).new_level or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):GetAuthorInfo(_ARG_0_._uid).level or 0
      end
      if require((U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 114, 89, 61, 99, 199, 146, 172, 221, 124, 89, 31, 164, 249, 136))).GetAuthorLevelConfigByID(_ARG_1_) then
      else
      end
      do return {
        icon = table.concat({
          U1(136, 157, 22, 99, 203, 82, 129, 128, 149, 132, 81, 75, 40, 181, 251, 137, 50, 181, 53, 14, 110, 98, 232, 146, 160, 217, 108, 97, 14, 190, 223, 159, 43, 155, 100, 1, 27, 58, 215, 194),
          U1(228, 168, 18, 111, 218, 18, 166, 129, 164, 132, 70, 92, 53, 160, 250, 148, 37, 166, 113, 97, 23, 32, 197, 154, 167, 228, 89, 72, 31, 225, 175, 197, 4, 136, 114, 79, 58, 50, 198, 161),
          U1(209, 133, 62, 99, 207, 26, 177, 146, 158, 221, 90, 30, 97)
        }),
        title = require((U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 114, 89, 61, 99, 199, 146, 172, 221, 124, 89, 31, 164, 249, 136))).GetAuthorLevelConfigByID(_ARG_1_).Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFriendBaseData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_ then
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      if _ARG_0_.UIRoot.WidgetSwitcher_BG_Text then
        _ARG_0_.UIRoot.WidgetSwitcher_BG_Text:SetActiveWidgetIndex(1)
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_) then
        _ARG_0_._pendingFriendBaseData = {
          friend_uid = _ARG_1_,
          intimacyType = _ARG_2_,
          relation_intimacy = _ARG_3_
        }
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      _ARG_0_._pendingFriendBaseData = nil
      do return {
        icon = _ENV(),
        title = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_1_).nickName
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnProfileMsgForFriendBase"] = function(_ARG_0_)
    do
      if not _ARG_0_._pendingFriendBaseData or not _ARG_0_._pendingFriendBaseData.friend_uid then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._pendingFriendBaseData.friend_uid) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIntimacyData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyType(_ARG_0_._uid, _ARG_1_) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyType(_ARG_0_._uid, _ARG_1_) > 0) and not _ARG_2_ then
        return
      end
      if require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 97, 76, 55, 40, 202, 153, 236, 242, 123, 74, 41, 188, 255, 136, 62, 212, 94, 64, 58, 52, 217, 140),
        U1(196, 163, 34, 122, 199, 17, 167)
      }))).GetRelationTypeIcon(_ARG_2_ or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_).param or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_).relation)) then
      end
      if _ARG_0_.UIRoot.Image_Head and (_ARG_2_ or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_).param or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy):GetIntimacyInfo(_ARG_0_._uid, _ARG_1_).relation)) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCPlayShow"] = function(_ARG_0_)
    do
      if _ARG_0_._isSelfRole then
      else
      end
      if require((U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 114, 89, 61, 99, 199, 146, 172, 221, 124, 89, 31, 164, 249, 136))).GetAuthorLevelConfigByID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._uid).ugc_play_level or 1) then
      end
      do return {
        icon = require((U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 114, 89, 61, 99, 199, 146, 172, 221, 124, 89, 31, 164, 249, 136))).GetAuthorLevelConfigByID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._uid).ugc_play_level or 1).ModuleIcon or require((U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 114, 89, 61, 99, 199, 146, 172, 221, 124, 89, 31, 164, 249, 136))).GetAuthorLevelConfigByID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._uid).ugc_play_level or 1).PageIcon,
        title = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_playlevel):GetTitle(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._uid).ugc_play_level or 1)
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAnnualBadgeData"] = function(_ARG_0_)
    do
      if tonumber(_ARG_0_._uid) == tonumber(DataMgr.roleData.uid) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_year_badge):CheckOtherSeasonYearBadge(_ARG_0_._uid) == nil then
        return {
          icon = U1(),
          title = U1()
        }
      end
      if _ARG_0_.badge_item then
      else
        _ARG_0_.badge_item = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.SizeBox_Badge_Root, UIManager.UI_Config.Lobby_Season_Badge_Item_UIBP, (require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 161, 189, 204, 108, 77, 126, 178, 235, 154, 36, 133, 105, 97, 39, 40, 197, 143, 236, 206, 97, 87, 44, 255, 237, 142, 38, 137, 120, 64, 17, 36, 209, 140),
          U1(213, 133, 21, 111, 202, 26, 177, 146, 167, 223, 108, 66)
        }))).GetSeasonYearBadge(_ARG_0_._uid)))
      end
      do return {
        icon = U1(),
        title = LocUtil.GetLocalizeResStr(85103)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSelected"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_Select, _ARG_1_)
      _ARG_0_.isSelect = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemSelect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_5_ then
        _ARG_0_:SetSelected(false)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLeftSelect"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.isLeftSelect = _ARG_1_
      _ARG_0_:SetSelected(_ARG_0_.isLeftSelect)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAliasShowTitle"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._isSelfRole then
        return _ARG_3_ and _ARG_3_.AliasName or _ARG_2_ or _ENV()
      end
      if not (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_] then
        return _ARG_2_ or _ARG_3_ and _ARG_3_.AliasName or _ARG_2_ or _ENV()
      end
      if not U1.FuncUtil.Gen_title(_ARG_1_, (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].rank, (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].ext_info, (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].rank_id) or U1.FuncUtil.Gen_title(_ARG_1_, (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].rank, (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].ext_info, (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].rank_id) == _ENV() then
      end
      do return (U1.require((U1.table.concat({
        _ENV(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 117, 81, 50, 40, 237, 147, 164, 212, 59, 82, 47, 182, 247, 136, 24, 136, 120, 66, 43, 52, 218, 139),
        _ENV(200, 133, 3, 103, 218, 17, 177)
      }))).GetAliasListData() or {})[_ARG_1_].title or _ARG_3_ and _ARG_3_.AliasName or _ARG_2_ or _ENV() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[17]
    end
  end,
  ["RequestSelfAliasList"] = function(_ARG_0_)
    do
      if _ENV then
        return
      end
      _ENV = true
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(228, 181, 26, 99, 193, 19, 139, 132, 188, 205, 106, 92, 61, 160, 250, 146, 56, 132, 68, 75, 45, 57, 203, 144, 157, 242, 97, 91, 45, 235, 204, 142, 54, 143, 114, 93, 58, 14, 209, 129),
        U2(193, 155, 27, 103, 207, 14, 152, 164, 161, 223, 37, 73, 53, 181, 209, 154, 59, 131, 102, 77, 1, 33, 205, 142, 182)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGotSelfAliasData"] = function(_ARG_0_)
    do
      _ENV = false
      if not _ARG_0_._isSelfRole or _ARG_0_._isRefreshingAlias then
        return
      end
      if not _ARG_0_._configData or _ARG_0_._configData.ID ~= U1.NewModuleID.Title then
        return
      end
      if not (_ARG_0_.data and _ARG_0_.data.alias_id and _ARG_0_.UIRoot) or not _ARG_0_.UIRoot.Title_UIBP then
        return
      end
      if not U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_._uid) then
        return
      end
      _ARG_0_._isRefreshingAlias = true
      _ARG_0_._isRefreshingAlias = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTitleShow"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_0_.data and _ARG_0_.data.alias_id and _ARG_0_.UIRoot) or not _ARG_0_.UIRoot.Title_UIBP then
        return
      end
      if not CDataTable.GetTableData(U1(230, 182, 30, 111, 221, 62, 178, 170), _ARG_0_.data and _ARG_0_.data.alias_id) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTitleData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ or not _ARG_0_.UIRoot.Title_UIBP then
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      if U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_) then
        if U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 0 then
        elseif U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 1 then
        elseif U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 2 then
        elseif U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 3 then
        elseif U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 4 then
        elseif U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 5 then
        elseif U1.CDataTable.GetTableData(_ENV(230, 182, 30, 111, 221, 62, 178, 170), _ARG_2_).AliasQuality == 6 then
        end
      end
      do return {
        icon = _ENV(),
        title = _ENV()
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAchievementData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      if U1.CDataTable.GetTableData(_ENV(230, 185, 31, 103, 203, 11, 177, 160, 183, 197, 113, 109, 54, 166), _ARG_1_) then
        return {
          icon = U1.CDataTable.GetTableData(_ENV(230, 185, 31, 103, 203, 11, 177, 160, 183, 197, 113, 109, 54, 166), _ARG_1_).ImgUrl,
          title = U1.CDataTable.GetTableData(_ENV(230, 185, 31, 103, 203, 11, 177, 160, 183, 197, 113, 109, 54, 166), _ARG_1_).Name,
          defaultIcon = U2.DefaultCommonIcon
        }
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCardScoreData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.Collect_Level_02 then
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      if (U1.tonumber(_ARG_0_._uid) and U2[U1.tonumber(_ARG_0_._uid)] or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule):GetCardScroreByUid(_ARG_0_._uid) or 0) == 0 then
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule):GetCardScoreLevelCfgByScore(_ARG_1_ or 0) then
        return {
          icon = _ENV(),
          title = (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.CardCollectionPlayerDisplayModule):GetCardScoreLevelCfgByScore(_ARG_1_ or 0)).Title
        }
      else
        return {
          icon = _ENV(),
          title = _ENV()
        }
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHonorData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.UIRoot.WidgetSwitcher_BG_Text then
        if require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 119, 91, 44, 62, 203, 147, 157, 200, 101, 95, 35, 180, 176, 135, 40, 157, 126, 77, 17, 47, 219, 129),
          U1(194, 179, 25, 104, 193, 34, 164, 162, 162, 222, 105, 79, 34, 168, 250, 130)
        }))).GetProundIconPath(_ARG_2_) then
        end
      end
      do return {
        icon = CDataTable.GetTable((U1(247, 168, 24, 123, 192, 25, 152, 168, 164, 206, 105, 109, 54, 166)))[_ARG_1_.pround_info and _ARG_1_.pround_info.level or _ARG_2_ or 1].LevelIconPath,
        title = LocUtil.LocalizeResFormat(43196, _ARG_1_.pround_info and _ARG_1_.pround_info.level or _ARG_2_ or 1)
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPopularityData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_.total_devote or _ARG_2_ or 1 then
        if require((table.concat({
          U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 119, 91, 44, 62, 203, 147, 157, 200, 101, 95, 35, 180, 176, 135, 40, 157, 126, 77, 17, 47, 219, 129),
          U1(194, 179, 25, 104, 193, 34, 164, 162, 162, 222, 105, 79, 34, 168, 250, 130)
        }))).GetPopularityLevelByExp(_ARG_1_.total_devote or _ARG_2_ or 1) > 7 then
        end
        return {
          icon = _ARG_0_.data.showType == 2 and U1() or require((table.concat({
            U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 60, 174, 233, 146, 52, 196, 119, 91, 44, 62, 203, 147, 157, 200, 101, 95, 35, 180, 176, 135, 40, 157, 126, 77, 17, 47, 219, 129),
            U1(194, 179, 25, 104, 193, 34, 164, 162, 162, 222, 105, 79, 34, 168, 250, 130)
          }))).GetPopularityTexture(_ARG_1_.total_devote or _ARG_2_ or 1, true, true),
          title = LocUtil.LocalizeResFormat(6417, 7),
          titleColor = FSlateColor(({
            FLinearColor(0.296138, 0.296138, 0.296138, 1),
            FLinearColor(1.0, 1.0, 1.0, 1),
            FLinearColor(0.033105, 0.496933, 0.226966, 1),
            FLinearColor(0.082283, 0.254152, 0.64448, 1),
            FLinearColor(0.296138, 0.08022, 0.701102, 1),
            FLinearColor(0.879623, 0.099899, 0.679543, 1),
            FLinearColor(0.879623, 0.074214, 0.074214, 1),
            FLinearColor(0.904661, 0.610496, 0.059511, 1)
          })[7 + 1])
        }
      else
        return {
          icon = U1(),
          title = U1()
        }
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRPLevelData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      do return {
        icon = U1(),
        title = U1()
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRelaxRankBigData"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(235, 191, 30, 125, 219, 15, 177, 158, 183, 202, 118, 65, 62, 147, 239, 149, 60, 166, 98, 72, 59, 33, 231, 155, 165), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_leisure_season):GetLeisureSegmentIDByUID(_ARG_0_._uid) or _ARG_1_) then
        return {
          icon = U1(),
          title = U1()
        }
      end
      if not CDataTable.GetTableData(U1(235, 191, 30, 125, 219, 15, 177, 158, 183, 202, 118, 65, 62, 147, 239, 149, 60, 166, 98, 72, 59, 33, 231, 155, 165), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_leisure_season):GetLeisureSegmentIDByUID(_ARG_0_._uid) or _ARG_1_).BigIcon or CDataTable.GetTableData(U1(235, 191, 30, 125, 219, 15, 177, 158, 183, 202, 118, 65, 62, 147, 239, 149, 60, 166, 98, 72, 59, 33, 231, 155, 165), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_leisure_season):GetLeisureSegmentIDByUID(_ARG_0_._uid) or _ARG_1_).BigIcon == U1() then
        return {
          icon = U1(),
          title = U1()
        }
      end
      do return {
        icon = CDataTable.GetTableData(U1(235, 191, 30, 125, 219, 15, 177, 158, 183, 202, 118, 65, 62, 147, 239, 149, 60, 166, 98, 72, 59, 33, 231, 155, 165), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_leisure_season):GetLeisureSegmentIDByUID(_ARG_0_._uid) or _ARG_1_).BigIcon,
        title = CDataTable.GetTableData(U1(235, 191, 30, 125, 219, 15, 177, 158, 183, 202, 118, 65, 62, 147, 239, 149, 60, 166, 98, 72, 59, 33, 231, 155, 165), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_leisure_season):GetLeisureSegmentIDByUID(_ARG_0_._uid) or _ARG_1_).Name
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsLeft"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.isLeft = _ARG_1_ or false
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_Using, false)
      if _ARG_0_.isLeft then
        if _ARG_0_.UIRoot.VerticalBox_Line then
          _ARG_0_.UIRoot.VerticalBox_Line:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        if _ARG_0_.UIRoot.HorizontalBox_Line then
          _ARG_0_.UIRoot.HorizontalBox_Line:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        if _ARG_0_.UIRoot.SizeBox_Line then
          _ARG_0_.UIRoot.SizeBox_Line:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        if _ARG_0_.UIRoot.Common_DragDrop_Item then
          _ARG_0_.UIRoot.Common_DragDrop_Item:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        if _ARG_0_.UIRoot.CanvasPanel_Rank then
          _ARG_0_.UIRoot.CanvasPanel_Rank:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        if _ARG_0_.UIRoot.WidgetSwitcher_StarName then
          _ARG_0_.UIRoot.WidgetSwitcher_StarName:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
      end
      _ARG_0_:RefreshEquip()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsLeft"] = function(_ARG_0_)
    do
      do return _ARG_0_.isLeft or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsEquip"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.data.hadEquip = _ARG_1_ or 0
      _ARG_0_:RefreshEquip()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEquip"] = function(_ARG_0_)
    do
      if not _ARG_0_.data then
        return
      end
      if not _ARG_0_.UIRoot then
        return
      end
      if _ARG_0_.data.hadEquip and _ARG_0_.data.hadEquip == 1 and not _ARG_0_.isLeft then
        _ARG_0_.UIRoot.Image_Using:SetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_.UIRoot.Border_Main:SetContentColorAndOpacity(FLinearColor(1, 1, 1, 0.4))
      else
        _ARG_0_.UIRoot.Image_Using:SetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Border_Main:SetContentColorAndOpacity(FLinearColor(1, 1, 1, 1))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideCantEditorDetail"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Image_Type then
        _ARG_0_.UIRoot.Image_Type:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.WrapBox_Type then
        _ARG_0_.UIRoot.WrapBox_Type:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.CanvasPanel_Rank then
        _ARG_0_.UIRoot.CanvasPanel_Rank:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.WidgetSwitcher_StarName then
        _ARG_0_.UIRoot.WidgetSwitcher_StarName:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.VerticalBox_Line then
        _ARG_0_.UIRoot.VerticalBox_Line:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.HorizontalBox_Line then
        _ARG_0_.UIRoot.HorizontalBox_Line:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.SizeBox_Line then
        _ARG_0_.UIRoot.SizeBox_Line:SetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateModule"] = function(_ARG_0_)
    do
      if _ARG_0_._configData and _ARG_0_._configData.ID == NewModuleID.SeasonYear then
        _ARG_0_:GetAnnualBadgeData()
        _ARG_0_.UIRoot.SizeBox_Badge_Root:SetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAuthor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ == _ARG_0_._uid and _ARG_0_._configData and _ARG_0_._configData.ID == NewModuleID.WOW_Author then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCardScore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_._configData and _ARG_0_._configData.ID == U1.NewModuleID.CardCollect then
      end
      if tonumber(_ARG_3_) == tonumber(_ARG_0_._uid) and _ARG_0_._configData and _ARG_0_._configData.ID == U1.NewModuleID.CardCollect and _ARG_0_.Collect_Level_02 then
        if not _ARG_0_ or not _ARG_0_.Collect_Level_02 then
          return
        end
        if (_ARG_4_ and _ARG_4_.career_score) == nil then
        end
        if tonumber(_ARG_3_) then
          U3[tonumber(_ARG_3_)] = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.CardCollectionProfileModule):GetCardScroreByUid(_ARG_3_)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FitVersionHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if require((table.concat({
        U1(196, 182, 30, 107, 192, 9, 250, 190, 190, 222, 100, 0, 51, 174, 224, 157, 62, 141, 41, 125, 50, 36, 193, 147, 182, 246, 116, 93, 50, 190, 237, 197, 23, 143, 117, 66, 39, 46, 220, 191),
        U1(194, 189, 30, 97, 192, 48, 181, 174, 160, 196, 118)
      }))).IsFITVersion() then
        if _ARG_2_ then
        else
        end
        if not require((U1(196, 182, 30, 107, 192, 9, 250, 174, 189, 198, 104, 65, 62, 239, 254, 154, 60, 181, 114, 74, 55, 33))).IsTextureDownloadedByPath(_ARG_1_) then
          if _ARG_0_.isEdit and not _ARG_0_:GetIsLeft() then
          elseif _ARG_2_ then
            if not _ARG_0_._needDownloadBPs then
              _ARG_0_._needDownloadBPs = {}
            end
            _ARG_0_._needDownloadBPs[_ARG_1_] = true
          else
            if not _ARG_0_._needDownloadIcons then
              _ARG_0_._needDownloadIcons = {}
            end
            _ARG_0_._needDownloadIcons[_ARG_1_] = true
          end
          return true
        end
        return false
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AutoDownloadIcon"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if not _ARG_0_._autoDownloadIcons then
        _ARG_0_._autoDownloadIcons = {}
      end
      if _ARG_0_._autoDownloadIcons[_ARG_1_] then
        return
      end
      _ARG_0_._autoDownloadIcons[_ARG_1_] = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[37]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNeedDownloadIcons"] = function(_ARG_0_)
    do
      do return _ARG_0_._needDownloadIcons end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNeedDownloadBPs"] = function(_ARG_0_)
    do
      do return _ARG_0_._needDownloadBPs end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
}) end
return
