local Featured_Comment_Item_UIBP = {}
local comment_gradient_helper = require("client.slua.umg.ugc.comment.comment_gradient_helper")
local BASE_COMMENT_COLOR_WIDGETS = {
  "TextBlock_Name",
  "Image_Appreciation",
  "Image_PlayTime01",
  "TextBlock_PlayTime",
  "Image_Good01",
  "TextBlock_Comment",
  "TextBlock_Time",
  "Image_Report01",
  "TextBlock_Support",
  "TextBlock_0",
  "TextBlock_Recommend"
}
local REPLY_COMMENT_COLOR_WIDGETS = {
  "TextBlock_Author_Name",
  "Image_Delete",
  "Image_Report02",
  "TextBlock_Reply_Time",
  "TextBlock_Reply",
  "Image_Report03",
  "TextBlock_Support_Reply"
}
local AUTHOR_COMMENT_COLOR_WIDGETS = {
  "TextBlock_AuthorName",
  "UTRichTextBlock_Comment",
  "TextBlock_Reply_Time"
}

local function IsDarkCommentSkin(skinData)
  return not skinData or tonumber(skinData.TxtColor) == 2
end

local function GetCommentSkinColorIndex(skinData)
  return IsDarkCommentSkin(skinData) and 0 or 1
end

local function GetGoodColorIndex(bIsSkinDark, bIsSupport)
  return (bIsSkinDark and 0 or 2) + (bIsSupport and 1 or 0)
end

function Featured_Comment_Item_UIBP:ctor(_, transComp)
  self.transComp = transComp
  self.comment_score_item = nil
  self.goto_comment_item = nil
  self._isBaseSkinDark = true
  self._isReplySkinDark = true
  self._baseCommentSkinRequestId = 0
  self._replyCommentSkinRequestId = 0
  self._authorAppliedSkinId = nil
  self._authorSkinModId = nil
  
  function self._checkBaseProfileFunc(uid)
    return self:IsCurrentBaseCommentSkinProfile(uid)
  end
  
  function self._checkReplyProfileFunc(uid)
    return self:IsCurrentReplyCommentSkinProfile(uid)
  end
end

function Featured_Comment_Item_UIBP:RegistEvents()
  if self.UIRoot.Button_Support then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Support, self.OnClickButtonSupport, self)
  end
  if self.UIRoot.Button_More then
    self:AddOnClickedEventByControl(self.UIRoot.Button_More, self.OnClickButtonMore, self)
  end
  if self.UIRoot.Button_AuthorCommentMenu then
    self:AddOnClickedEventByControl(self.UIRoot.Button_AuthorCommentMenu, self.OnClickButtonAuthorCommentMenu, self)
  end
  if self.UIRoot.Common_Avatar_BP then
    self:AddControlEventByControl(self.UIRoot.Common_Avatar_BP, "OnClickItemCallback", self.OnClickHeadCallback, self)
  end
  if self.UIRoot.Button_Report then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Report, self.OnClickButtonReport, self)
  end
  if self.UIRoot.Button_Comment then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Comment, self.OnClickNoFeaturedComment, self)
  end
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_REPLY_COMMENT_RSP, self.OnReplyCommentRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_QUERY_COMMENTS_DATA_RSP, self.OnQueryNoFeaturedCommentRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_DELETE_REPLY_COMMENT_RSP, self.OnDeleteReplyComment, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SUPPORT_COMMENT_RES, self.OnSupportCommentRes, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SUPPORT_REPLY_RES, self.OnSupportReplyRes, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_APPRECIATION_SUPPORT_COMMENT_RSP, self.OnSupportAppreciationCommentRes, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_APPRECIATION_SUPPORT_REPLY_RSP, self.OnSupportAppreciationReplyRes, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_REPLY_APPRECIATION_COMMENT_RSP, self.OnReplyAppreciationCommentRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_DELETE_REPLY_APPRECIATION_COMMENT_RSP, self.OnDeleteReplyAppreciationComment, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_TRANSLATE_CUSTOMDATA_CALLBACK, self.OnTranslateCallback, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_TRANSLATE_CUSTOMDATA_STATE_CHANGE, self.OnTransStateChange, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_WOW_PASS_INFO_UPDATE, self.OnWowPassInfoUpdate, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_CAN_FREE_REVIEW_RSP, self.OnCanFreeReviewRsp, self)
end

function Featured_Comment_Item_UIBP:OnPostInitialize()
  Featured_Comment_Item_UIBP.__super.OnPostInitialize(self)
end

function Featured_Comment_Item_UIBP:OnRefresh()
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  self:HideNoFeaturedCommentTips()
  if self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorReply then
    self:UpdateReplyItem()
    return
  end
  local bKeepAuthorSkin = self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorComment and self._authorAppliedSkinId ~= nil and self._authorSkinModId == self.data.mod_id
  if not bKeepAuthorSkin then
    self:ClearCommentSkin()
  end
  self:StopAnimation("Anim_Loop")
  if self.data.data_type == logic_ugc_comment_macro.CommentDataType.Score then
    if not self.comment_score_item then
      local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
      self.comment_score_item = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.Featured_Comment_Item_Score, self.UIRoot, self.data.modInfo)
    end
    self.comment_score_item:OnShow()
  elseif self.data.data_type == logic_ugc_comment_macro.CommentDataType.GotoComment then
    if not self.goto_comment_item then
      local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
      self.goto_comment_item = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.Featured_Comment_Item_Send, self.UIRoot, self.data.modInfo)
    end
    self.goto_comment_item:OnShow()
  elseif self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorComment then
    self:UpdateAuthorComment()
  elseif self.data.data_type == logic_ugc_comment_macro.CommentDataType.Comment then
    self:UpdateCommentItem()
  elseif self.data.data_type == logic_ugc_comment_macro.CommentDataType.More then
    self:UpdateMoreItem()
  elseif self.data.data_type == logic_ugc_comment_macro.CommentDataType.NoFeaturedComment or self.data.data_type == logic_ugc_comment_macro.CommentDataType.NoFeaturedCommentSmall then
    self:UpdateNoFeaturedItem()
  elseif self.data.data_type == logic_ugc_comment_macro.CommentDataType.RecommendVideo then
    self:UpdateRecommendVideoItem()
  end
end

function Featured_Comment_Item_UIBP:OnClose()
  self:StopAnimation("Anim_Loop")
  self:HideNoFeaturedCommentTips()
  self.comment_score_item = nil
  self.goto_comment_item = nil
  self:ClearCommentSkin()
  Featured_Comment_Item_UIBP.__super.OnClose(self)
end

function Featured_Comment_Item_UIBP:OnClickButtonSupport()
  self:PlayAudio(sound_config.click_v1)
  local mod_id = self.commentDetail.mod_id
  local comment_id = self.data.comment_id
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.commentDetail.is_appreciation_comment then
    local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
    local comment_uid = self.commentDetail.uid
    if logic_ugc_new_work_detail_comment:CheckAppreciationCommentSupport(mod_id, comment_uid) then
      logic_ugc_new_work_detail_comment:send_ugc_review_panel_support_comment_req(mod_id, comment_uid, logic_ugc_comment_macro.SupportOptType.CancelSupport, logic_ugc_comment_macro.SupportOptTarget.Comment)
    else
      logic_ugc_new_work_detail_comment:send_ugc_review_panel_support_comment_req(mod_id, comment_uid, logic_ugc_comment_macro.SupportOptType.Support, logic_ugc_comment_macro.SupportOptTarget.Comment)
    end
  else
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local modInfo = logic_ugc_comment:GetModInfo(self.data.comment_info.mod_id)
    local author_uid = modInfo and modInfo.base.uid and tostring(modInfo.base.uid) == tostring(DataMgr.roleData.uid) and DataMgr.roleData.uid or nil
    if logic_ugc_comment:HaveSupportComment(comment_id) then
      logic_ugc_comment:send_ugc_support_comment_req(mod_id, comment_id, logic_ugc_comment_macro.SupportOptType.CancelSupport, logic_ugc_comment_macro.SupportOptTarget.Comment, nil, author_uid)
    else
      logic_ugc_comment:send_ugc_support_comment_req(mod_id, comment_id, logic_ugc_comment_macro.SupportOptType.Support, logic_ugc_comment_macro.SupportOptTarget.Comment, nil, author_uid)
    end
  end
end

function Featured_Comment_Item_UIBP:OnClickButtonSupportReply()
  self:PlayAudio(sound_config.click_v1)
  local mod_id = self.commentDetail.mod_id
  local comment_id = self.data.comment_id
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.commentDetail.is_appreciation_comment then
    local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
    local comment_uid = self.commentDetail.uid
    if logic_ugc_new_work_detail_comment:CheckAppreciationReplySupport(mod_id, comment_uid) then
      logic_ugc_new_work_detail_comment:send_ugc_review_panel_support_comment_req(mod_id, comment_uid, logic_ugc_comment_macro.SupportOptType.CancelSupport, logic_ugc_comment_macro.SupportOptTarget.Reply)
    else
      logic_ugc_new_work_detail_comment:send_ugc_review_panel_support_comment_req(mod_id, comment_uid, logic_ugc_comment_macro.SupportOptType.Support, logic_ugc_comment_macro.SupportOptTarget.Reply)
    end
  else
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local modInfo = logic_ugc_comment:GetModInfo(mod_id)
    local author_uid = modInfo and modInfo.base.uid and tostring(modInfo.base.uid) == tostring(DataMgr.roleData.uid) and DataMgr.roleData.uid or nil
    if logic_ugc_comment:HaveSupportReply(comment_id) then
      logic_ugc_comment:send_ugc_support_comment_req(mod_id, comment_id, logic_ugc_comment_macro.SupportOptType.CancelSupport, logic_ugc_comment_macro.SupportOptTarget.Reply, nil, author_uid)
    else
      logic_ugc_comment:send_ugc_support_comment_req(mod_id, comment_id, logic_ugc_comment_macro.SupportOptType.Support, logic_ugc_comment_macro.SupportOptTarget.Reply, nil, author_uid)
    end
  end
end

function Featured_Comment_Item_UIBP:OnClickButtonMore()
  self:PlayAudio(sound_config.click_v1)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local menuData = {
    comment_id = self.data.comment_id,
    commentDetail = self.commentDetail,
    is_featured_comment = 1,
    namedSlot = self.UIRoot.NamedSlot_1,
    visitorType = self:GetVisitorType(),
    MenuType = logic_ugc_comment_macro.MenuType.GuestComment
  }
  local parentUI = self:GetLoopScrollBoxParentUI()
  if parentUI then
    parentUI:ShowFeaturedCommentMenu(menuData)
  end
end

function Featured_Comment_Item_UIBP:OnClickButtonMoreReply()
  self:PlayAudio(sound_config.click_v1)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorReply then
    local logic_ugc_comment_reply = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_reply)
    local replyDetail = logic_ugc_comment_reply:GetReplyDetail(self.data.reply_id)
    if not replyDetail then
      return
    end
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local bIsSelf = tonumber(replyDetail.uid) == tonumber(DataMgr.roleData.uid)
    local bIsAuthor = logic_ugc_comment:IsAuthor(replyDetail.mod_id)
    local menuData = {
      comment_id = replyDetail.comment_id,
      root_comment_id = self.data.comment_id,
      commentDetail = replyDetail,
      is_reply_item = true,
      namedSlot = self.UIRoot.NamedSlot_MoreReply,
      visitorType = (bIsSelf or bIsAuthor) and logic_ugc_comment_macro.VisitorType.Author or logic_ugc_comment_macro.VisitorType.Passerby,
      MenuType = logic_ugc_comment_macro.MenuType.Reply
    }
    local parentUI = self:GetLoopScrollBoxParentUI()
    if parentUI then
      parentUI:ShowFeaturedCommentMenu(menuData)
    end
    return
  end
  local menuData = {
    comment_id = self.data.comment_id,
    commentDetail = self.commentDetail,
    is_featured_comment = 1,
    namedSlot = self.UIRoot.NamedSlot_MoreReply,
    visitorType = self:GetVisitorType(),
    MenuType = logic_ugc_comment_macro.MenuType.Reply
  }
  local parentUI = self:GetLoopScrollBoxParentUI()
  if parentUI then
    parentUI:ShowFeaturedCommentMenu(menuData)
  end
end

function Featured_Comment_Item_UIBP:OnClickButtonAuthorCommentMenu()
  self:PlayAudio(sound_config.click_v1)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local menuData = {
    mod_id = self.data.mod_id,
    namedSlot = self.UIRoot.NamedSlot_AuthorCommentMenu,
    MenuType = logic_ugc_comment_macro.MenuType.AuthorComment
  }
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  if not logic_ugc_comment:IsAuthor(self.data.mod_id) then
    log(bWriteLog and "Featured_Comment_Item_UIBP:OnClickButtonAuthorCommentMenu not author")
    menuData.visitorType = logic_ugc_comment_macro.VisitorType.Passerby
  else
    menuData.visitorType = logic_ugc_comment_macro.VisitorType.Author
  end
  local parentUI = self:GetLoopScrollBoxParentUI()
  if parentUI then
    parentUI:ShowFeaturedCommentMenu(menuData)
  end
end

function Featured_Comment_Item_UIBP:OnClickHeadCallback()
  self:PlayAudio(sound_config.click_v1)
  local RoleInfoMainSystem = require("client.logic.roleinfo.logic_new_roleinfo")
  if not self.commentDetail then
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local modInfo = logic_ugc_comment:GetModInfo(self.data.mod_id)
    if not modInfo then
      log(bWriteLog and "Featured_Comment_Item_UIBP:OnClickHeadCallback no modInfo")
      return
    end
    RoleInfoMainSystem.Show(RoleInfoMainSystem.WOW, RoleInfoMainSystem.RoleInfoOpenFromType.WoWItem, modInfo.base.uid)
    return
  end
  RoleInfoMainSystem.Show(RoleInfoMainSystem.WOW, RoleInfoMainSystem.RoleInfoOpenFromType.WoWItem, self.commentDetail.uid)
end

function Featured_Comment_Item_UIBP:OnClickButtonReport()
  self:PlayAudio(sound_config.click_v1)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorComment then
    self:OnClickReportAuthorComment()
    return
  end
  local chatMacro = require("client.slua.logic.lobby_chat.chat_macro")
  if not self.commentDetail then
    log(bWriteLog and "Featured_Comment_Item_UIBP:OnClickButtonReport not detail")
    return
  end
  local uid = self.commentDetail.uid
  local commentText = self.commentDetail and self.commentDetail.comment_text
  local cliSourceId = chatMacro.CliSourceId.UGCComment
  if self.data.data_type == logic_ugc_comment_macro.MenuType.Reply then
    uid = self.commentDetail.author_reply_content.author_uid
    commentText = self.commentDetail.author_reply_content.reply_content
    cliSourceId = chatMacro.CliSourceId.UGCCommentAuthorReply
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(uid)
  if not profile then
    log(bWriteLog and "Comment_Menu_UI_Base:OnClickReport no profile")
    return
  end
  local commentID = self.data.comment_id
  local modID = self.commentDetail.mod_id
  if not ((commentID or self.commentDetail.is_appreciation_comment) and modID) or not commentText then
    log(bWriteLog and string.format("Comment_Menu_UI_Base:OnClickReport, commentID:%s,modID:%s,commentText:%s", commentID, modID, commentText))
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  logic_ugc_comment:SetReportDataCache({comment_id = commentID, mod_id = modID})
  local ChatMenuSystem = require("client.slua.logic.lobby_chat.logic_chat_menu")
  ChatMenuSystem.on_report_req(profile.uid, profile.nickName, commentText or "", false, 0, cliSourceId)
end

function Featured_Comment_Item_UIBP:OnClickReportAuthorComment()
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local modID = self.data.mod_id
  local authorCommentText = logic_ugc_comment:GetAuthorCommentText(self.data.mod_id)
  if not modID or not authorCommentText then
    log(bWriteLog and string.format("Comment_Menu_UI_Base:OnClickReportAuthorComment, modID:%s,authorCommentText:%s", modID, authorCommentText))
    return
  end
  local chatMacro = require("client.slua.logic.lobby_chat.chat_macro")
  local modInfo = logic_ugc_comment:GetModInfo(self.data.mod_id)
  local uid = modInfo and modInfo.base and modInfo.base.uid or 0
  local cliSourceId = chatMacro.CliSourceId.UGCCommentAuthor
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(uid)
  if not profile then
    log(bWriteLog and "Comment_Menu_UI_Base:OnClickReportAuthorComment no profile")
    return
  end
  logic_ugc_comment:SetReportDataCache({mod_id = modID})
  local ChatMenuSystem = require("client.slua.logic.lobby_chat.logic_chat_menu")
  ChatMenuSystem.on_report_req(profile.uid, profile.nickName, authorCommentText or "", false, 0, cliSourceId)
end

function Featured_Comment_Item_UIBP:OnClickNoFeaturedComment()
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.data.data_type ~= logic_ugc_comment_macro.CommentDataType.NoFeaturedComment and self.data.data_type ~= logic_ugc_comment_macro.CommentDataType.NoFeaturedCommentSmall then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  if not self.data.modInfo then
    log(bWriteLog and "Featured_Comment_Item_UIBP:OnClickNoFeaturedComment no modInfo")
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local bIsSelfMod = logic_ugc_comment:IsAuthor(self.data.modInfo.mod_id)
  if not bIsSelfMod then
    local logic_ugc_appreciation_group = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_appreciation_group)
    if logic_ugc_appreciation_group:GetCanFreeReview(self.data.modInfo.mod_id) == true then
      UIManager.ShowUI(UIManager.UI_Config.UGC_AppreciationGroup_Evaluate_Popup, self.data.modInfo.mod_id, self.data.modInfo, logic_ugc_appreciation_group.REVIEW_SOURCE.FREE)
      return
    end
  end
  local Featured_Comment_Item_Send = require("client.slua.umg.ugc.comment.Featured_Comment_Item_Send")
  Featured_Comment_Item_Send:OpenCommentUIPanel(self.data.modInfo, bIsSelfMod)
end

function Featured_Comment_Item_UIBP:OnQueryNoFeaturedCommentRsp(_, _, modId)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.data.data_type ~= logic_ugc_comment_macro.CommentDataType.NoFeaturedComment and self.data.data_type ~= logic_ugc_comment_macro.CommentDataType.NoFeaturedCommentSmall then
    return
  end
  if not self.data.modInfo or self.data.modInfo.mod_id ~= modId then
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local bIsSelfMod = logic_ugc_comment:IsAuthor(modId)
  local Featured_Comment_Item_Send = require("client.slua.umg.ugc.comment.Featured_Comment_Item_Send")
  Featured_Comment_Item_Send:OpenCommentUIPanel(self.data.modInfo, bIsSelfMod)
end

function Featured_Comment_Item_UIBP:OnReplyCommentRsp(_, _, comment_id)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnReplyCommentRsp")
  if comment_id ~= self.data.comment_id then
    return
  end
  self:GetLoopScrollBox():RefreshItem(self.index)
end

function Featured_Comment_Item_UIBP:OnDeleteReplyComment(_, _, comment_id)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnDeleteReplyComment")
  if comment_id ~= self.data.comment_id then
    return
  end
  self:GetLoopScrollBox():RefreshItem(self.index)
end

function Featured_Comment_Item_UIBP:OnSupportCommentRes(_, _, comment_id)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnSupportCommentRes")
  if comment_id ~= self.data.comment_id then
    return
  end
  self:RefreshCommentSupport()
end

function Featured_Comment_Item_UIBP:OnSupportReplyRes(_, _, comment_id)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnSupportReplyRes")
  if comment_id ~= self.data.comment_id then
    return
  end
  self:RefreshReplySupport()
end

function Featured_Comment_Item_UIBP:OnSupportAppreciationCommentRes(_, _, mod_id, comment_uid, opt_type, timestamp)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnSupportCommentRes")
  if not self.commentDetail then
    return
  end
  if not self.commentDetail.is_appreciation_comment then
    return
  end
  if comment_uid ~= self.commentDetail.uid then
    return
  end
  self:RefreshCommentSupport()
end

function Featured_Comment_Item_UIBP:OnSupportAppreciationReplyRes(_, _, mod_id, comment_uid, opt_type, timestamp)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnSupportReplyRes")
  if not self.commentDetail then
    return
  end
  if not self.commentDetail.is_appreciation_comment then
    return
  end
  if comment_uid ~= self.commentDetail.uid then
    return
  end
  self:RefreshReplySupport()
end

function Featured_Comment_Item_UIBP:OnReplyAppreciationCommentRsp(_, _, comment_uid)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnReplyCommentRsp")
  if not self.commentDetail then
    return
  end
  if not self.commentDetail.is_appreciation_comment then
    return
  end
  if comment_uid ~= self.commentDetail.uid then
    return
  end
  self:GetLoopScrollBox():RefreshItem(self.index)
end

function Featured_Comment_Item_UIBP:OnDeleteReplyAppreciationComment(_, _, comment_uid)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnDeleteReplyComment")
  if not self.commentDetail then
    return
  end
  if not self.commentDetail.is_appreciation_comment then
    return
  end
  if comment_uid ~= self.commentDetail.uid then
    return
  end
  self:GetLoopScrollBox():RefreshItem(self.index)
end

function Featured_Comment_Item_UIBP:OnTranslateCallback(_, _, moduleName, transOrOrgText, transParamData)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnTranslateCallback")
  if not self.transComp or self.transComp:GetModuleName() ~= moduleName then
    log(bWriteLog and "Featured_Comment_Item_UIBP:OnTranslateCallback not match")
    return
  end
  if not (transParamData and transParamData.index) or transParamData.index ~= self.index then
    log(bWriteLog and "Featured_Comment_Item_UIBP:OnTranslateCallback index not match")
    return
  end
  self:GetLoopScrollBox():RefreshItem(self.index)
end

function Featured_Comment_Item_UIBP:OnTransStateChange(_, _, moduleName)
  log(bWriteLog and "Featured_Comment_Item_UIBP:OnTransStateChange")
  if not self.transComp or self.transComp:GetModuleName() ~= moduleName then
    log(bWriteLog and "Featured_Comment_Item_UIBP:OnTransStateChange not match")
    return
  end
  self:GetLoopScrollBox():RefreshItem(self.index)
end

function Featured_Comment_Item_UIBP:UpdateAuthorComment()
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  if self.UIRoot.TextBlock_Reply_Time then
    self.UIRoot.TextBlock_Reply_Time:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local modInfo = logic_ugc_comment:GetModInfo(self.data.mod_id)
  local AuthorUid = modInfo and modInfo.base and modInfo.base.uid
  self:RefreshAuthorCommentText(self:IsCommentSkinDark(AuthorUid))
  self:RefreshReportBtn()
  local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
  if AuthorUid then
    local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local CachedProfile = logic_profile:GetLocalProfile(AuthorUid)
    if CachedProfile then
      self:UpdateProfile({CachedProfile})
    end
    logic_profile_get_wrap.GetNormalProfiles({AuthorUid}, function(profileList)
      if not slua.isValid(self.UIRoot) or not self:IsCurrentBaseCommentSkinProfile(AuthorUid) then
        log(bWriteLog and "Featured_Comment_Item_UIBP:UpdateAuthorComment profile callback stale, skip")
        return
      end
      self:UpdateProfile(profileList)
    end, Enum_PROFILE_REPORT_CFG.UGC, 0, true)
  end
end

function Featured_Comment_Item_UIBP:UpdateCommentItem()
  if not self.data.comment_info then
    log(bWriteLog and "Featured_Comment_Item_UIBP:UpdateCommentItem no comment_info")
    return
  end
  local bIsAppreciationComment = self.data.comment_info.is_appreciation_comment
  if bIsAppreciationComment then
    local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
    self.commentDetail = logic_ugc_new_work_detail_comment:GetAppreciationComment(self.data.comment_info.uid) or self.data.comment_info
  else
    local logic_ugc_comment_detail = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_detail)
    self.commentDetail = logic_ugc_comment_detail:GetCommentDetail(self.data.comment_id) or self.data.comment_info
  end
  if not self.commentDetail then
    log(bWriteLog and "Featured_Comment_Item_UIBP:UpdateCommentItem no commentDetail")
    return
  end
  self.histort_play_time = self.commentDetail.history_play_time
  self:RefreshVisitor()
  self:RefreshScore()
  self:RefreshComment()
  self:RefreshCommentTime()
  self:RefreshCommentSupport()
  self:RefreshReply()
  self:ReqCommentReplyInfo()
  self:RefreshReportBtn()
  self:RefreshplayTime()
  if self.commentDetail.is_appreciation_comment then
    self:SetWidgetVisible(self.UIRoot.Button_Support, true, true)
    self:SetWidgetVisible(self.UIRoot.SizeBox_Appreciation, true, false)
    self.UIRoot.Image_Appreciation:SetVisibility(UEnums.ESlateVisibility.Visible)
    self:AddControlEventByControl(self.UIRoot.Image_Appreciation, "OnMouseButtonDownEvent", self.OnClickAppreciationIcon, self)
  else
    self:SetWidgetVisible(self.UIRoot.Button_Support, true, true)
    self:SetWidgetVisible(self.UIRoot.SizeBox_Appreciation, false, false)
    self.UIRoot.Image_Appreciation:SetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self.UIRoot:ForceLayoutPrepass()
end

function Featured_Comment_Item_UIBP:OnClickAppreciationIcon(MyGeometry, MouseEvent)
  self:PlayAudio(sound_config.click_v1)
  local ExplanationTabPopupClass = require("client.slua.umg.ugc.AppreciationGroup.UGC_AppreciationGroup_ExplanationTab_Popup_UIBP")
  UIManager.ShowUI(UIManager.UI_Config.UGC_AppreciationGroup_ExplanationTab_Popup_UIBP, ExplanationTabPopupClass.TabIndex.INTRO)
end

function Featured_Comment_Item_UIBP:GetRootCommentID()
  if not self.commentDetail then
    return nil
  end
  return self.commentDetail.root_comment_id or self.data.comment_id
end

function Featured_Comment_Item_UIBP:ReqCommentReplyInfo()
  return
end

function Featured_Comment_Item_UIBP:_ReqCommentReplyInfoByItem()
  local commentId = self:GetRootCommentID()
  if not commentId then
    return
  end
  local logic_ugc_comment_reply = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_reply)
  if logic_ugc_comment_reply:HasReplyInfo(commentId) then
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  logic_ugc_comment:send_batch_get_comment_reply_info_req({commentId}, self.data and self.data.source)
end

function Featured_Comment_Item_UIBP:UpdateReplyItem()
  if not self.reply_item then
    local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
    self.reply_item = UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.Featured_Comment_AuthorReply_Item_UIBP, self.UIRoot, self.transComp)
  end
  self.replyTarget = self.data.reply_id
  
  local function OnExpandReply()
    local pageUI = self:GetLoopScrollBoxParentUI()
    if pageUI and pageUI.OnClickExpandReplyRow then
      pageUI:OnClickExpandReplyRow(self.data.comment_id)
    end
  end
  
  self.reply_item:SetData(self.data.reply_id, self.data.comment_id, self.data.is_last_reply == true, OnExpandReply, self.data.reply_index, self.data.reply_ids, self.data.comment_info)
end

function Featured_Comment_Item_UIBP:RefreshVisitor()
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(self.commentDetail.uid)
  if profile then
    self:RefreshVisitorByProfile()
  else
    local VisitorUid = self.commentDetail.uid
    local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
    logic_profile_get_wrap.GetNormalProfiles({VisitorUid}, function()
      if not slua.isValid(self.UIRoot) or not self:IsCurrentBaseCommentSkinProfile(VisitorUid) then
        log(bWriteLog and "Featured_Comment_Item_UIBP:RefreshVisitor profile callback stale, skip")
        return
      end
      self:RefreshVisitorByProfile()
    end, Enum_PROFILE_REPORT_CFG.UGC_COMMENT, 0, true)
  end
end

function Featured_Comment_Item_UIBP:RefreshVisitorByProfile()
  if not self.commentDetail then
    return
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(self.commentDetail.uid)
  if not profile then
    log(bWriteLog and "Featured_Comment_Item_UIBP:RefreshVisitorByProfile no profile")
    return
  end
  self.UIRoot.Common_Avatar_BP:InitView(1, profile.uid, profile.picUrl, 0, profile.cur_avatar_box_id, 0, false, "")
  self.UIRoot.Common_Avatar_BP:SetFrameHide()
  self.UIRoot.TextBlock_Name:SetText(profile.nickName)
  self:SetWOWpassImage(profile)
  self:RefreshCommentSkinByProfile(profile, self.UIRoot.Image_SkinBg01, self._checkBaseProfileFunc, BASE_COMMENT_COLOR_WIDGETS, false)
end

function Featured_Comment_Item_UIBP:RefreshScore()
  for idx = 1, 5 do
    local UGC_Appraise_Star_Item_UIBP = self.UIRoot.UGC_Appraise_Star_Item02_UIBP["UGC_Appraise_Star_Item_UIBP_" .. tostring(idx)]
    UGC_Appraise_Star_Item_UIBP.WidgetSwitcher_State:SetActiveWidgetIndex(1)
  end
  local comment_score = self.commentDetail.comment_score or 0
  self.UIRoot.WidgetSwitcher_Evaluate:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  if self.commentDetail and self.commentDetail.is_from_club then
    comment_score = 5
  end
  if comment_score == 1 then
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(1)
    self.UIRoot.TextBlock_Recommend:SetText(LocUtil.GetLocalizeResStr(792328))
  else
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(0)
    self.UIRoot.TextBlock_Recommend:SetText(LocUtil.GetLocalizeResStr(4650))
  end
end

function Featured_Comment_Item_UIBP:IsCommentSkinDark(uid)
  uid = tonumber(uid) or self.commentDetail and tonumber(self.commentDetail.uid)
  if not uid then
    return true
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(uid)
  if not profile then
    return true
  end
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local commentSkinList = profile.ugc_personal_dress and profile.ugc_personal_dress[logic_ugc_comment_macro.CommentSkinSubTabID]
  local commentSkinID = tonumber(commentSkinList and commentSkinList[1])
  if not commentSkinID or commentSkinID <= 0 then
    return true
  end
  local logic_ugc_inventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  return IsDarkCommentSkin(logic_ugc_inventory:GetPlayerCommentData(commentSkinID))
end

function Featured_Comment_Item_UIBP:RefreshAuthorCommentText(bIsSkinDark)
  if not slua.isValid(self.UIRoot) or not self.UIRoot.UTRichTextBlock_Comment then
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local authorCommentText = logic_ugc_comment:GetAuthorCommentText(self.data.mod_id)
  if not authorCommentText then
    self.UIRoot.UTRichTextBlock_Comment:SetText("")
    return
  end
  local transText = authorCommentText
  if self.transComp then
    transText = self.transComp:GetTextAndSetOneTranslateData(authorCommentText, {
      index = self.index
    }) or ""
  end
  local prefixId = bIsSkinDark == false and 87271 or 814219
  transText = LocUtil.GetLocalizeResStr(prefixId) .. transText
  self.UIRoot.UTRichTextBlock_Comment:SetText(transText or authorCommentText)
end

function Featured_Comment_Item_UIBP:RefreshComment()
  local comment = self.commentDetail.comment_text
  local transText
  if self.transComp then
    transText = self.transComp:GetTextAndSetOneTranslateData(comment, {
      index = self.index
    })
  end
  local bIsSkinDark = self:IsCommentSkinDark()
  
  local function prefix(idLight, idDark)
    return LocUtil.GetLocalizeResStr(bIsSkinDark and idDark or idLight)
  end
  
  local comment_id = self.data.comment_id
  local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local commentInfo = self.data and self.data.comment_info
  local modInfo = commentInfo and logic_ugc_comment:GetModInfo(commentInfo.mod_id) or nil
  if self.commentDetail.is_appreciation_comment then
    if logic_ugc_new_work_detail_comment:CheckAppreciationCommentTop(self.commentDetail.uid) then
      if transText then
        transText = prefix(87271, 814219) .. transText
      elseif comment then
        comment = prefix(87271, 814219) .. comment
      end
    end
  elseif modInfo and tonumber(modInfo.top_comment_id) == tonumber(comment_id) then
    if transText then
      transText = prefix(87271, 814219) .. transText
    elseif comment then
      comment = prefix(87271, 814219) .. comment
    end
  elseif self.commentDetail.recommend_flag then
    if transText then
      transText = prefix(87272, 814220) .. transText
    elseif comment then
      comment = prefix(87272, 814220) .. comment
    end
  elseif logic_ugc_new_work_detail_comment:IsFirstComment(comment_id) then
    if transText then
      transText = prefix(814214, 814221) .. transText
    elseif comment then
      comment = prefix(814214, 814221) .. comment
    end
  elseif self.commentDetail.author_liked then
    if transText then
      transText = prefix(814215, 814222) .. transText
    else
      comment = comment and prefix(814215, 814222) .. comment
    end
  end
  self.UIRoot.TextBlock_Comment:SetText(transText or comment or "")
  self:ForceLayoutCommentText()
end

function Featured_Comment_Item_UIBP:ForceLayoutCommentText()
  local uiRoot = self.UIRoot
  if not uiRoot then
    return
  end
  local layoutWidgetNames = {
    "TextBlock_Comment",
    "AutoScrollBox_6",
    "SizeBox_8"
  }
  for _, widgetName in ipairs(layoutWidgetNames) do
    local widget = uiRoot[widgetName]
    if widget and slua.isValid(widget) and widget.ForceLayoutPrepass then
      widget:ForceLayoutPrepass()
    end
  end
end

function Featured_Comment_Item_UIBP:RefreshCommentTime()
  local logic_ugc_comment_util = require("client.slua.logic.ugc.comment.logic_ugc_comment_util")
  local timeStr = logic_ugc_comment_util:GetCommentTime(self.commentDetail.comment_time)
  self.UIRoot.TextBlock_Time:SetText(timeStr)
end

function Featured_Comment_Item_UIBP:RefreshCommentSupport()
  if self.UIRoot.WidgetSwitcher_Support then
    self.UIRoot.WidgetSwitcher_Support:SetActiveWidgetIndex(0)
  end
  self:RefreshBaseGoodColor()
  local support_count = 0
  if self.commentDetail then
    if self.commentDetail.is_appreciation_comment then
      local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
      local comment_data = logic_ugc_new_work_detail_comment:GetAppreciationComment(self.commentDetail.uid) or {}
      support_count = comment_data.support_count or 0
    else
      support_count = self.commentDetail.support_count or 0
    end
  end
  if support_count == 0 then
    self:SetWidgetVisible(self.UIRoot.TextBlock_Support, false)
  else
    self:SetWidgetVisible(self.UIRoot.TextBlock_Support, true)
    local StringUtil = require("common.string_util")
    self.UIRoot.TextBlock_Support:SetText(StringUtil.FormatNum_KMB(support_count))
  end
end

function Featured_Comment_Item_UIBP:RefreshReply()
  self:ClearReplyCommentSkin()
end

function Featured_Comment_Item_UIBP:RefreshReplySupport()
  self:RefreshReplyGoodColor()
end

function Featured_Comment_Item_UIBP:RefreshTopInfo()
end

function Featured_Comment_Item_UIBP:UpdateMoreItem()
  self.UIRoot.WidgetSwitcher_More:SetActiveWidgetIndex(1)
  if self.data.isLoading then
    self.UIRoot.TextBlock_More:SetText(LocUtil.GetLocalizeResStr(29677))
  else
    self.UIRoot.TextBlock_More:SetText(LocUtil.GetLocalizeResStr(63102))
  end
end

function Featured_Comment_Item_UIBP:UpdateNoFeaturedItem()
  if not self.data.modInfo then
    log(bWriteLog and "Featured_Comment_Item_UIBP:UpdateNoFeaturedItem no modInfo")
    return
  end
  local logic_ugc_comment_switch = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_switch)
  local Util_UGC = require("client.slua.logic.ugc.util_ugc")
  if not logic_ugc_comment_switch:IsReachThreshold(Util_UGC.GetModPlayCount(self.data.modInfo)) then
    self.UIRoot.TextBlock_Tip:SetText(LocUtil.GetLocalizeResStr(64081))
    self:HideNoFeaturedCommentTips()
    if self.UIRoot.Button_Comment then
      self:SetWidgetVisible(self.UIRoot.Button_Comment, false, true)
    end
    return
  end
  self.UIRoot.TextBlock_Tip:SetText(LocUtil.GetLocalizeResStr(63120))
  local logic_ugc_appreciation_group = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_appreciation_group)
  local bCanFreeReview = logic_ugc_appreciation_group and logic_ugc_appreciation_group:GetCanFreeReview(self.data.modInfo.mod_id)
  self:RefreshLeaveCommentButtonStyle(bCanFreeReview)
  if self.UIRoot.Button_Comment then
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local bIsSelfMod = logic_ugc_comment:IsAuthor(self.data.modInfo.mod_id)
    self:SetWidgetVisible(self.UIRoot.Button_Comment, not bIsSelfMod, true)
    if not bIsSelfMod then
      self:PlayAnimation("Anim_Loop", 0, 0, 0, 1)
    end
  end
  self:TryShowNoFeaturedCommentTips(self:CanShowNoFeaturedCommentTips(bCanFreeReview))
end

function Featured_Comment_Item_UIBP:OnCanFreeReviewRsp(_, _, bCanFreeReview, modId)
  if not (self.data and self.data.modInfo) or self.data.modInfo.mod_id ~= modId then
    return
  end
  self:RefreshLeaveCommentButtonStyle(bCanFreeReview)
  self:TryShowNoFeaturedCommentTips(self:CanShowNoFeaturedCommentTips(bCanFreeReview))
end

function Featured_Comment_Item_UIBP:CanShowNoFeaturedCommentTips(bCanFreeReview)
  if not (bCanFreeReview and self.data) or not self.data.modInfo then
    return false
  end
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.data.data_type ~= logic_ugc_comment_macro.CommentDataType.NoFeaturedComment then
    return false
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  return not logic_ugc_comment:IsAuthor(self.data.modInfo.mod_id)
end

function Featured_Comment_Item_UIBP:TryShowNoFeaturedCommentTips(bCanFreeReview)
  if not bCanFreeReview then
    self:HideNoFeaturedCommentTips()
    return
  end
  self:HideNoFeaturedCommentTips()
  self.NoFeaturedCommentTipsShowTimer = self:AddTimerOnce(0, function()
    if not (self.UIRoot and slua.isValid(self.UIRoot) and self.data) or not self.data.modInfo then
      return
    end
    local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
    if self.data.data_type ~= logic_ugc_comment_macro.CommentDataType.NoFeaturedComment then
      return
    end
    self.NoFeaturedCommentTipsUI = self:CreateChildWindow(self.UIRoot.CanvasPanel_CommentTips, UIManager.UI_Config.Common_Tips_Top_UIBP, LocUtil.GetLocalizeResStr(818707))
    self.NoFeaturedCommentTipsHideTimer = self:AddTimerOnce(5, function()
      self:HideNoFeaturedCommentTips()
    end)
  end)
end

function Featured_Comment_Item_UIBP:HideNoFeaturedCommentTips()
  self:CancelNoFeaturedCommentTipsTimer()
  if self.NoFeaturedCommentTipsUI and self.NoFeaturedCommentTipsUI.IsValid and self.NoFeaturedCommentTipsUI:IsValid() then
    self.NoFeaturedCommentTipsUI:CloseSelf()
  end
  self.NoFeaturedCommentTipsUI = nil
end

function Featured_Comment_Item_UIBP:CancelNoFeaturedCommentTipsTimer()
  if self.NoFeaturedCommentTipsShowTimer then
    self:RemoveTimer(self.NoFeaturedCommentTipsShowTimer)
    self.NoFeaturedCommentTipsShowTimer = nil
  end
  if self.NoFeaturedCommentTipsHideTimer then
    self:RemoveTimer(self.NoFeaturedCommentTipsHideTimer)
    self.NoFeaturedCommentTipsHideTimer = nil
  end
end

function Featured_Comment_Item_UIBP:RefreshLeaveCommentButtonStyle(bCanFreeReview)
  if self.UIRoot.WidgetSwitcher_0 then
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(bCanFreeReview and 1 or 0)
  end
  if self.UIRoot.TextBlock_Comment then
    self.UIRoot.TextBlock_Comment:SetText(LocUtil.GetLocalizeResStr(bCanFreeReview and 818706 or 63019))
  end
end

function Featured_Comment_Item_UIBP:UpdateRecommendVideoItem()
  if self.bInitRecommendVideo then
    log(bWriteLog and "Featured_Comment_Item_UIBP:UpdateRecommendVideoItem already init")
    return
  end
  self.bInitRecommendVideo = true
  local authorUid = self.data.modInfo.base and self.data.modInfo.base.uid
  local bIsSelfMod = authorUid == tonumber(DataMgr.roleData.uid)
  local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
  UIComponentModule:InitWithParentComponent(self, UIComponentModule.Config.UGC_Recommend_Video_UIBP, self.UIRoot, self.data.modInfo, bIsSelfMod)
end

function Featured_Comment_Item_UIBP:IsMyComment()
  if not self.commentDetail then
    return false
  end
  return self.commentDetail.uid == tonumber(DataMgr.roleData.uid)
end

function Featured_Comment_Item_UIBP:GetVisitorType()
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if not self.commentDetail then
    return logic_ugc_comment_macro.VisitorType.Passerby
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  if logic_ugc_comment:IsAuthor(self.commentDetail.mod_id) then
    return logic_ugc_comment_macro.VisitorType.Author
  elseif self:IsMyComment() then
    return logic_ugc_comment_macro.VisitorType.Commentator
  else
    return logic_ugc_comment_macro.VisitorType.Passerby
  end
end

function Featured_Comment_Item_UIBP:RefreshReportBtn()
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local bIsOwnComment = false
  if self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorComment then
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    bIsOwnComment = self.data.mod_id ~= nil and logic_ugc_comment:IsAuthor(self.data.mod_id) or false
  elseif self.commentDetail and self.commentDetail.uid then
    bIsOwnComment = tonumber(self.commentDetail.uid) == tonumber(DataMgr.roleData.uid)
  end
  self:SetWidgetVisible(self.UIRoot.Button_Report, not bIsOwnComment, true)
end

function Featured_Comment_Item_UIBP:RefreshplayTime()
  local bIsAppreciationComment = self.commentDetail and self.commentDetail.is_appreciation_comment
  local StringUtil = require("common.string_util")
  if not (not bIsAppreciationComment and self.histort_play_time) or self.histort_play_time <= 0 then
    if self.UIRoot.TextBlock_PlayTime then
      self.UIRoot.TextBlock_PlayTime:SetText("")
    end
    self.UIRoot.HorizontalBox_PlayTime:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  self.UIRoot.HorizontalBox_PlayTime:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
  if self.UIRoot.TextBlock_PlayTime then
    self.UIRoot.TextBlock_PlayTime:SetText(LocUtil.LocalizeResFormat(66966, StringUtil.FormatNumRound_Up(self.histort_play_time / 3600, 1)))
  end
end

function Featured_Comment_Item_UIBP:UpdateProfile(profileList)
  if not self.UIRoot then
    return
  end
  if not profileList or not next(profileList) then
    self.UIRoot.TextBlock_AuthorName:SetText("")
    return
  end
  for _, profile in pairs(profileList) do
    self.UIRoot.TextBlock_AuthorName:SetText(profile.nickName)
    if self.UIRoot.Common_Avatar_BP and slua.isValid(self.UIRoot.Common_Avatar_BP) then
      self.UIRoot.Common_Avatar_BP:InitView(1, profile.uid, profile.picUrl, nil, profile.cur_avatar_box_id)
      self.UIRoot.Common_Avatar_BP:SetFrameHide()
    end
    self:SetWOWpassImage(profile)
    self:RefreshAuthorCommentText(self:IsCommentSkinDark(profile.uid))
    local SkinId = self:GetProfileCommentSkinId(profile)
    if self._authorAppliedSkinId == nil or self._authorAppliedSkinId ~= SkinId then
      self._authorAppliedSkinId = SkinId
      self._authorSkinModId = self.data and self.data.mod_id
      self:RefreshCommentSkinByProfile(profile, self.UIRoot.Image_SkinBg01, self._checkBaseProfileFunc, AUTHOR_COMMENT_COLOR_WIDGETS, false)
    end
  end
end

function Featured_Comment_Item_UIBP:GetProfileCommentSkinId(profile)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local commentSkinList = profile and profile.ugc_personal_dress and profile.ugc_personal_dress[logic_ugc_comment_macro.CommentSkinSubTabID]
  return tonumber(commentSkinList and commentSkinList[1]) or 0
end

function Featured_Comment_Item_UIBP:ClearCommentSkin()
  self._authorAppliedSkinId = nil
  self._authorSkinModId = nil
  self:_InvalidateCommentSkinRequest(false)
  self:_InvalidateCommentSkinRequest(true)
  if not self.UIRoot then
    return
  end
  self:ClearCommentEffectSkin(self.UIRoot.Image_SkinBg01)
  self:ClearCommentEffectSkin(self.UIRoot.Image_SkinBg02)
  self:SetCommentSkinImage(self.UIRoot.Image_SkinBg01, nil)
  self:SetCommentSkinImage(self.UIRoot.Image_SkinBg02, nil)
  comment_gradient_helper.Hide(self, self.UIRoot.Image_Gradient)
  self:SetCommentSkinIcon(self.UIRoot.Image_Icon, nil)
  self:SetCommentSkinIcon(self.UIRoot.Image_Icon_02, nil)
  self:ApplyColorIndexToWidgets(BASE_COMMENT_COLOR_WIDGETS, 0)
  self:ApplyColorIndexToWidgets(REPLY_COMMENT_COLOR_WIDGETS, 0)
  self:ApplyColorIndexToWidgets(AUTHOR_COMMENT_COLOR_WIDGETS, 0)
  self:UpdateAreaSkinDark(false, true)
  self:UpdateAreaSkinDark(true, true)
end

function Featured_Comment_Item_UIBP:ClearReplyCommentSkin()
  self:_InvalidateCommentSkinRequest(true)
  if not self.UIRoot then
    return
  end
  self:ClearCommentEffectSkin(self.UIRoot.Image_SkinBg02)
  self:SetCommentSkinImage(self.UIRoot.Image_SkinBg02, nil)
  self:SetCommentSkinIcon(self.UIRoot.Image_Icon_02, nil)
  self:ApplyColorIndexToWidgets(REPLY_COMMENT_COLOR_WIDGETS, 0)
  self:UpdateAreaSkinDark(true, true)
end

function Featured_Comment_Item_UIBP:_InvalidateCommentSkinRequest(bIsReply)
  if bIsReply then
    self._replyCommentSkinRequestId = self._replyCommentSkinRequestId + 1
  else
    self._baseCommentSkinRequestId = self._baseCommentSkinRequestId + 1
  end
end

function Featured_Comment_Item_UIBP:_StartCommentSkinRequest(bIsReply)
  self:_InvalidateCommentSkinRequest(bIsReply)
  if bIsReply then
    return self._replyCommentSkinRequestId
  end
  return self._baseCommentSkinRequestId
end

function Featured_Comment_Item_UIBP:_IsCurrentCommentSkinRequest(bIsReply, requestId)
  if bIsReply then
    return self._replyCommentSkinRequestId == requestId
  end
  return self._baseCommentSkinRequestId == requestId
end

function Featured_Comment_Item_UIBP:ClearCommentEffectSkin(imageWidget)
  local effectPanel = imageWidget == self.UIRoot.Image_SkinBg02 and "CanvasPanel_Effect_Reply" or "CanvasPanel_Effect_Base"
  local LogicUGCInventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  LogicUGCInventory:RemoveEffectSkin(self, effectPanel)
end

function Featured_Comment_Item_UIBP:RefreshCommentSkinByProfile(profile, imageWidget, checkProfileFunc, colorTargetWidgetNames, bIsReply)
  if not self.UIRoot then
    return
  end
  local RequestId = self:_StartCommentSkinRequest(bIsReply)
  self:ClearCommentEffectSkin(imageWidget)
  self:SetCommentSkinImage(imageWidget, nil)
  self:ApplyColorIndexToWidgets(colorTargetWidgetNames, 0)
  self:UpdateAreaSkinDark(bIsReply, true)
  if not bIsReply then
    comment_gradient_helper.Hide(self, self.UIRoot.Image_Gradient)
  end
  if not (profile and imageWidget) or not slua.isValid(self.UIRoot) then
    log(bWriteLog and "Featured_Comment_Item_UIBP:RefreshCommentSkinByProfile invalid params")
    return
  end
  local profileUid = tonumber(profile.uid)
  if checkProfileFunc and not checkProfileFunc(profileUid) then
    return
  end
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local commentSkinSubTabID = logic_ugc_comment_macro.CommentSkinSubTabID
  local commentSkinList = profile.ugc_personal_dress and profile.ugc_personal_dress[commentSkinSubTabID]
  local commentSkinID = tonumber(commentSkinList and commentSkinList[1])
  if not commentSkinID or commentSkinID <= 0 then
    return
  end
  local logic_ugc_inventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  local skinData = logic_ugc_inventory:GetPlayerCommentData(commentSkinID)
  self:SetCommentSkinIcon(self:GetCommentSkinIconWidget(bIsReply), skinData)
  local bHasSkinRes = skinData and (skinData.WidgetPath and skinData.WidgetPath ~= "" or skinData.WidgetAniPath and skinData.WidgetAniPath ~= "")
  if not bHasSkinRes then
    log(bWriteLog and string.format("Featured_Comment_Item_UIBP:RefreshCommentSkinByProfile no skinData for ID:%s", tostring(commentSkinID)))
    return
  end
  local skinColorIndex = GetCommentSkinColorIndex(skinData)
  logic_ugc_inventory:AutoDownloadResource(skinData, function()
    if not (slua.isValid(self.UIRoot) and (not checkProfileFunc or checkProfileFunc(profileUid))) or not self:_IsCurrentCommentSkinRequest(bIsReply, RequestId) then
      log(bWriteLog and "Featured_Comment_Item_UIBP:RefreshCommentSkinByProfile download callback stale, skip apply")
      return
    end
    if not bIsReply and self.data and self.data.data_type == logic_ugc_comment_macro.CommentDataType.Comment and logic_ugc_inventory:IsPlayerCommentSkinReady(skinData) then
      local chain = comment_gradient_helper.NewChain(self.data.comment_id, self.data.reply_ids, 1)
      comment_gradient_helper.Apply(self, self.UIRoot.Image_Gradient, skinData, chain)
    end
    self:ApplyCommentSkin(imageWidget, skinData, function()
      if not self:_IsCurrentCommentSkinRequest(bIsReply, RequestId) then
        return
      end
      self:ApplyColorIndexToWidgets(colorTargetWidgetNames, skinColorIndex)
      self:UpdateAreaSkinDark(bIsReply, skinColorIndex == 0)
    end)
    if not self:_IsCurrentCommentSkinRequest(bIsReply, RequestId) then
      return
    end
    self:SetCommentSkinIcon(self:GetCommentSkinIconWidget(bIsReply), skinData)
  end)
end

function Featured_Comment_Item_UIBP:UpdateAreaSkinDark(bIsReply, bIsSkinDark)
  if bIsReply then
    self._isReplySkinDark = bIsSkinDark
    self:RefreshReplyGoodColor()
  else
    self._isBaseSkinDark = bIsSkinDark
    self:RefreshBaseGoodColor()
  end
end

function Featured_Comment_Item_UIBP:RefreshReplyCommentSkin(author_reply_content)
  self:ClearReplyCommentSkin()
  if not self.UIRoot.Image_SkinBg02 then
    return
  end
  local replyUid = author_reply_content and tonumber(author_reply_content.author_uid)
  if not replyUid or replyUid <= 0 then
    log(bWriteLog and "Featured_Comment_Item_UIBP:RefreshReplyCommentSkin invalid replyUid")
    return
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(replyUid)
  if profile then
    self:RefreshCommentSkinByProfile(profile, self.UIRoot.Image_SkinBg02, self._checkReplyProfileFunc, REPLY_COMMENT_COLOR_WIDGETS, true)
    return
  end
  local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
  logic_profile_get_wrap.GetNormalProfiles({replyUid}, function(profileList)
    if not slua.isValid(self.UIRoot) or not self:IsCurrentReplyCommentSkinProfile(replyUid) then
      return
    end
    local replyProfile = profileList and profileList[1]
    if not replyProfile then
      local logic_profile_inner = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
      replyProfile = logic_profile_inner:GetLocalProfile(replyUid)
    end
    self:RefreshCommentSkinByProfile(replyProfile, self.UIRoot.Image_SkinBg02, self._checkReplyProfileFunc, REPLY_COMMENT_COLOR_WIDGETS, true)
  end, Enum_PROFILE_REPORT_CFG.UGC_COMMENT, 0, true)
end

function Featured_Comment_Item_UIBP:IsCurrentBaseCommentSkinProfile(uid)
  uid = tonumber(uid)
  if not uid or not self.data then
    return false
  end
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  if self.data.data_type == logic_ugc_comment_macro.CommentDataType.AuthorComment then
    local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
    local modInfo = logic_ugc_comment:GetModInfo(self.data.mod_id)
    local authorUid = modInfo and modInfo.base and tonumber(modInfo.base.uid)
    return uid == authorUid
  end
  if self.commentDetail then
    return uid == tonumber(self.commentDetail.uid)
  end
  return false
end

function Featured_Comment_Item_UIBP:IsCurrentReplyCommentSkinProfile(uid)
  uid = tonumber(uid)
  local author_reply_content = self.commentDetail and self.commentDetail.author_reply_content
  local replyUid = author_reply_content and tonumber(author_reply_content.author_uid)
  return uid and replyUid and uid == replyUid
end

function Featured_Comment_Item_UIBP:ApplyColorIndexToWidgets(widgetNames, colorIndex)
  if not self.UIRoot or not widgetNames then
    return
  end
  for _, widgetName in ipairs(widgetNames) do
    local widget = self.UIRoot[widgetName]
    if widget and slua.isValid(widget) and widget.SetActiveColorIndex then
      widget:SetActiveColorIndex(colorIndex)
    end
  end
end

function Featured_Comment_Item_UIBP:ApplyGoodColorIndex(goodImageWidget, bIsSkinDark, bIsSupport)
  if not (goodImageWidget and slua.isValid(goodImageWidget)) or not goodImageWidget.SetActiveColorIndex then
    return
  end
  goodImageWidget:SetActiveColorIndex(GetGoodColorIndex(bIsSkinDark, bIsSupport))
end

function Featured_Comment_Item_UIBP:IsBaseCommentSupported()
  if not self.commentDetail then
    return false
  end
  if self.commentDetail.is_appreciation_comment then
    local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
    return logic_ugc_new_work_detail_comment:CheckAppreciationCommentSupport(self.commentDetail.mod_id, self.commentDetail.uid) or false
  end
  if not self.data or not self.data.comment_id then
    return false
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  return logic_ugc_comment:HaveSupportComment(self.data.comment_id) or false
end

function Featured_Comment_Item_UIBP:IsReplyCommentSupported()
  if not self.commentDetail then
    return false
  end
  if self.commentDetail.is_appreciation_comment then
    local logic_ugc_new_work_detail_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_work_detail_comment)
    return logic_ugc_new_work_detail_comment:CheckAppreciationReplySupport(self.commentDetail.mod_id, self.commentDetail.uid) or false
  end
  if not self.data or not self.data.comment_id then
    return false
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  return logic_ugc_comment:HaveSupportReply(self.data.comment_id) or false
end

function Featured_Comment_Item_UIBP:RefreshBaseGoodColor()
  if not self.UIRoot then
    return
  end
  self:ApplyGoodColorIndex(self.UIRoot.Image_Good02, self._isBaseSkinDark, self:IsBaseCommentSupported())
end

function Featured_Comment_Item_UIBP:RefreshReplyGoodColor()
  if not self.UIRoot then
    return
  end
  self:ApplyGoodColorIndex(self.UIRoot.Image_Good03, self._isReplySkinDark, self:IsReplyCommentSupported())
end

function Featured_Comment_Item_UIBP:ApplyCommentSkin(imageWidget, skinData, onTextureLoaded)
  if not skinData or not slua.isValid(self.UIRoot) then
    self:SetCommentSkinImage(imageWidget, nil)
    return
  end
  local WidgetAniPath = skinData.WidgetAniPath
  local WidgetPath = skinData.WidgetPath
  local logic_ugc_inventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  if WidgetAniPath and WidgetAniPath ~= "" then
    local bDressReady = logic_ugc_inventory:IsPlayerCommentSkinReady(skinData)
    if not bDressReady then
      log(bWriteLog and string.format("Featured_Comment_Item_UIBP:ApplyCommentSkin dynamic skin res not ready, skip paint. id=%s", tostring(skinData.ID)))
      self:SetCommentSkinImage(imageWidget, nil)
      return
    end
    self:SetCommentSkinImage(imageWidget, nil)
    local effectPanel = imageWidget == self.UIRoot.Image_SkinBg02 and "CanvasPanel_Effect_Reply" or "CanvasPanel_Effect_Base"
    logic_ugc_inventory:AddEffectSkinByCreateChildWindow(self, WidgetAniPath, effectPanel, "Auto_Loop")
    if onTextureLoaded then
      onTextureLoaded()
    end
  else
    self:ClearCommentEffectSkin(imageWidget)
    self:SetCommentSkinImage(imageWidget, WidgetPath, onTextureLoaded)
  end
end

function Featured_Comment_Item_UIBP:SetCommentSkinImage(imageWidget, widgetPath, onTextureLoaded)
  if not imageWidget or not slua.isValid(imageWidget) then
    return
  end
  local Client = import("ScriptHelperClient")
  if Client.RemoveKnownMissingPackageRefObjectByObj then
    Client.RemoveKnownMissingPackageRefObjectByObj(imageWidget)
  end
  if not widgetPath or widgetPath == "" then
    imageWidget:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  imageWidget:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self:SetTexture(imageWidget, widgetPath, {onDownloadSuccess = onTextureLoaded, defaultIcon = ""})
end

function Featured_Comment_Item_UIBP:GetCommentSkinIconWidget(bIsReply)
  if not self.UIRoot then
    return nil
  end
  if bIsReply then
    return self.UIRoot.Image_Icon_02
  end
  return self.UIRoot.Image_Icon
end

function Featured_Comment_Item_UIBP:SetCommentSkinIcon(iconWidget, skinData)
  if not iconWidget or not slua.isValid(iconWidget) then
    return
  end
  local logic_ugc_inventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  local iconPath = skinData and skinData.IconPath
  local Client = import("ScriptHelperClient")
  if Client.RemoveKnownMissingPackageRefObjectByObj then
    Client.RemoveKnownMissingPackageRefObjectByObj(iconWidget)
  end
  if not iconPath or iconPath == "" or not logic_ugc_inventory:IsIconResReady(iconPath) then
    iconWidget:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  iconWidget:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self:SetTexture(iconWidget, iconPath)
end

function Featured_Comment_Item_UIBP:OnWowPassInfoUpdate()
  self:OnRefresh()
end

function Featured_Comment_Item_UIBP:SetWOWpassImage(profile)
  if not self.UIRoot.SizeBox_WoWPass and not self.UIRoot.Image_WoWPass then
    return
  end
  local IconPath
  if profile.uid == tonumber(DataMgr.roleData.uid) then
    local logic_ugc_WOWPass = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass)
    IconPath = logic_ugc_WOWPass:GetWOWpassIcon()
  else
    local Util_UGC = require("client.slua.logic.ugc.util_ugc")
    if Util_UGC.WoWPassActive(profile) then
      IconPath = Util_UGC.GetWoWPassIconPath(profile)
    end
  end
  local bShowWoWPass = IconPath ~= nil
  self:SetWidgetVisible(self.UIRoot.SizeBox_WoWPass, bShowWoWPass, false)
  if bShowWoWPass then
    local params = {sync = false, bMatchSize = true}
    local CommonUIUtil = require("client.common.ui_util")
    self:SetTexture(self.UIRoot.Image_WoWPass, IconPath, params)
  end
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.component.scroll_box_child_base")
local CFeatured_Comment_Item_UIBP = class(ui_base, nil, Featured_Comment_Item_UIBP)
return CFeatured_Comment_Item_UIBP
