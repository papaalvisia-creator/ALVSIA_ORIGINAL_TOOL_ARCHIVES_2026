do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(76, 169, 73, 50, 211)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 183, 160, 187, 158, 78, 173, 148, 53, 20, 39, 138, 87, 90, 35, 29, 184, 139, 160))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log_tree(U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 28, 173, 151, 183, 226, 188, 87, 171, 172, 38, 7, 47, 213), _ARG_2_)
      _ARG_0_.modInfo = _ARG_2_
      _ARG_0_.ExtendParameters = _ARG_3_ or {}
      _ARG_0_.bHideGameButton = _ARG_0_.ExtendParameters.hideGameButton
      _ARG_0_.resetPaddingTop = _ARG_0_.ExtendParameters.resetPaddingTop
      _ARG_0_.bCollect = false
      _ARG_0_.infoUI = nil
      _ARG_0_.updateTimer = nil
      _ARG_0_.bShowShare = false
      _ARG_0_.source = _ARG_0_.ExtendParameters.sourceModule or U2.Source_Open_Detail.UGCMain
      log(bWriteLog and U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 28, 173, 151, 183, 226, 162, 87, 186, 151, 43, 4, 96, 200, 21) .. tostring(_ARG_0_.source))
      _ARG_0_.bCoauthorOpen = bCoauthorOpen
      if require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).IsSubModeGameMod(_ARG_0_.modInfo) then
        _ARG_0_.canCreateRoom = false
      else
        _ARG_0_.canCreateRoom = true
      end
      _ARG_0_.isShowRoom = false
      _ARG_0_.bIsShowFriends = false
      _ARG_0_.bIsDownload = false
      _ARG_0_.headIcons = {
        [1] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 121, 182, 132, 37, 4, 31, 165, 71, 78),
          U1(73, 172, 68, 36, 255, 228, 103, 57, 51, 46, 176, 137, 184, 183, 158, 120, 173, 154, 62, 24, 60, 128, 122, 0, 63, 71)
        }),
        [2] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 121, 182, 132, 37, 4, 9, 153, 89, 84),
          U1(92, 177, 119, 17, 210, 186, 51, 104, 113, 10, 150, 217, 231, 234, 239, 105, 166, 148, 53, 20, 25, 137, 73, 68, 126, 11, 134, 168, 183, 173, 183, 81, 163, 128, 23, 80, 114, 205)
        }),
        [3] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 124, 174, 139, 44, 0, 36, 148, 91, 126),
          U1(127, 183, 71, 39, 201, 185, 48, 94, 82, 4, 168, 154, 160, 188, 158, 25, 237, 205, 118, 53, 49, 139, 65, 80, 105, 30, 183, 167, 149, 176, 190, 94, 166, 137, 45, 62, 15, 158, 84, 83),
          U1(90, 171, 119, 112, 146, 237)
        }),
        [4] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 50, 36, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 226, 1, 144, 212, 122, 89)
        }),
        [5] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 53, 46, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 229, 11, 144, 212, 122, 89)
        }),
        [6] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 52, 45, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 228, 8, 144, 212, 122, 89)
        }),
        [7] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 52, 44, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 228, 9, 144, 212, 122, 89)
        }),
        [8] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 52, 40, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 228, 13, 144, 212, 122, 89)
        }),
        [9] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 52, 36, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 228, 1, 144, 212, 122, 89)
        }),
        [10] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 55, 47, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 231, 10, 144, 212, 122, 89)
        }),
        [11] = table.concat({
          U1(0, 130, 73, 44, 197, 250, 0, 76, 90, 64, 157, 141, 173, 166, 180, 90, 186, 218, 16, 20, 49, 129, 85, 94, 127, 11, 171, 153, 172, 182, 254, 112, 170, 132, 44, 17, 47, 135, 65, 83),
          U1(78, 172, 92, 30, 147, 228, 101, 57, 43, 48, 248, 218, 237, 252, 137, 77, 190, 145, 40, 30, 34, 145, 87, 80, 100, 11, 134, 203, 244, 242, 233, 14, 144, 212, 122, 89)
        })
      }
      _ARG_0_.RefreshBtnCDTime = 5
      _ARG_0_.bIsTranslated = false
      _ARG_0_.bSelectedFromDetailDownload = false
      _ARG_0_.bSelectingFromDetailDownload = false
      _ARG_0_.share_challenge_info = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[19]
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_.bCollect = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGCSocial):IsCollect(_ARG_0_.modInfo.mod_id)
      if U1.require((U1.table.concat({
        U2(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 182, 189, 175, 78, 182, 146, 118, 50, 60, 140, 64, 95, 121, 50, 184, 155, 183, 173, 162, 22, 159, 144, 42, 13, 41, 134, 93, 115),
        U2(74, 162, 65, 46, 206, 152, 52, 98, 111, 0, 186)
      }))).IsBlueholeOperationRegion() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_StarGame, _ARG_0_.OnClickStartGameNew, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Collect, _ARG_0_.OnClickCollect, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Share, _ARG_0_.OnClickShare, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_ChatShare, _ARG_0_.OnClickChatShare, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_ExtraShare, _ARG_0_.OnClickExtraShare, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Duplicate, _ARG_0_.OnClickDuplicate, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Gift, _ARG_0_.OnClickButtonGift, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Recommend, _ARG_0_.OnClickRecommend, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CLUB, _ARG_0_.OnClickButton_CLUB, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Module, _ARG_0_.OnClickButton_Module, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PlayTogether, _ARG_0_.OnClickButton_PlayTogether, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.New_UGC_TogetherPlay_Tips_UIBP.InviteFriends, _ARG_0_.OnClickInviteFriends, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PlayTogether_Tips, _ARG_0_.OnClickButton_PlayTogether_Tips, _ARG_0_)
      if _ARG_0_.UIRoot.Button_VersionTips then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_VersionTips, _ARG_0_.OnClickVersionTips, _ARG_0_)
      end
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Translation, _ARG_0_.OnClickTranslation, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_UPDATE_COLLECT, _ARG_0_.OnUpdateCollect, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_UPDATE_SHARE, _ARG_0_.OnUpdateShare, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_DUPLICATE_MOD, _ARG_0_.OnDuplicateMod, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_DOWNLOAD_RES_COMPLETE, _ARG_0_.OnDownloadComplete, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_RES_STATUS_CHANGED, _ARG_0_.OnResStatusChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_MINE_MODS, _ARG_0_.OnCollectionModListRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_MOD_HOTSTAT_RSP, _ARG_0_.OnModHotStatRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UPDATE_ROOM_LIST, _ARG_0_.OnUpdateRoomList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CHAT, U1.EVENTID_UGC_TRANSLATE_CALLBACK, _ARG_0_.OnTransRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CHAT, U1.EVENTID_UGC_TRANSLATE_STATE_CHANGE, _ARG_0_.OnTransStateChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_MOD_RANK_LIST, _ARG_0_.OnPlayerRankInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_PLAYER_RANK_INFO, _ARG_0_.OnPlayerRankInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_SHOW_CHALLENGE_TIPS, _ARG_0_.OnShareTipsShow, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_CLOSE_CHALLENGE_TIPS, _ARG_0_.OnShareTipsClose, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_ACTIVITY_ADD_WIDGET_FAILURE, _ARG_0_.OnAddWidgetFailure, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PUFFER, U1.EVENTID_UGC_CLICK_DOWNLOAD, _ARG_0_.OnClickDownload, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:AddTimer(0, function()
        _ENV:PlayUserWidgetAnimation(UIRoot.Auto_Fadein, 0, 1, 0, 1)
        return
      end)
      _ARG_0_:UpdatePublicInfo()
      _ARG_0_:InitInfoUI()
      _ARG_0_:_RefreshDetailDownloadStatus()
      _ARG_0_:InitWidgets()
      _ARG_0_:UpdateCollectState()
      _ARG_0_:InitGameButton()
      _ARG_0_:InitDuplicateState()
      _ARG_0_:InitModuleButtonState()
      _ARG_0_:SetBottomActive(true)
      _ARG_0_:UpdateSelfRecommend()
      _ARG_0_:InitFriendTips()
      _ARG_0_:InitRoomListUIBP()
      if not _ARG_0_.modInfo or not _ARG_0_.modInfo.setting then
        return
      end
      if not U1.IsWoWEditor and 1 < U1.require((U2(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).GetModTeamSize(_ARG_0_.modInfo, 1) then
        _ARG_0_.bInited = false
      end
      _ARG_0_:CheckWowGiftTips()
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGCTrans):GetTransByStrWithState(_ARG_0_.modInfo.setting.name) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGCTrans):GetTransByStrWithState(_ARG_0_.modInfo.setting.name) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGCTrans):GetTransByStrWithState(_ARG_0_.modInfo.setting.name) ~= U2() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if _ARG_0_.checkHotStatTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.checkHotStatTimer)
      end
      _ARG_0_.checkHotStatTimer = nil
      _ARG_0_.hot_stat = nil
      _ARG_0_:CloseModuleTips(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePublicInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_.modInfo then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.modInfo.mod_id)) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.modInfo.mod_id)).pub_mod_meta then
        _ARG_0_.modInfo = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.modInfo.mod_id)).pub_mod_meta
      end
      if _ARG_0_.modInfo.collect_cnt then
      else
      end
      if _ARG_0_.modInfo.share_cnt then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanCreateRoom"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if DataMgr.anchor == 1 then
        return true, false
      end
      if not _ARG_0_.canCreateRoom then
        return false, false
      end
      if _ARG_1_ < 0 then
      elseif _ARG_1_ - require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec() > 0 then
      elseif 0 < _ARG_2_ then
      end
      if not true then
        goto lbl_143
        if U2((206).itemSubType, {
          2103,
          2104,
          2105,
          2113,
          2114
        }) and DataMgr.IsValidTime((206).expireTS) then
          return true, false
        end
        ::lbl_143::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true, true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCreateRoom"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if LobbySystem.isInMatch then
        ShowNotice(110017)
        return
      end
      if require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).GetTeamNum() > 1 and not require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).IsTeamLeader() then
        return
      end
      if _ARG_0_:CanCreateRoom(_ARG_0_:GetUGCRoomCardInfo()) then
        if _ARG_0_.ExtendParameters and _ARG_0_.ExtendParameters.bPromotion then
        else
        end
      elseif _ARG_0_:CanCreateRoom(_ARG_0_:GetUGCRoomCardInfo()) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickStartGameNew"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):TryShowLowMemoryPlayTip(_ARG_0_.modInfo, function()
        if not UIRoot then
          return
        end
        _ENV:OnClickStartGameNew(U1)
        return
      end) then
        return false
      end
      if require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).GetTeamNum() > 1 and not require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).IsTeamLeader() then
        return false
      end
      if require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).IsMemberInSocialLand() then
        return false
      end
      if _ARG_0_.ExtendParameters and _ARG_0_.ExtendParameters.IsNewProcessBannerTheme then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomInfo() then
      else
      end
      do return (_ARG_0_:OnClickStartGame_Internal(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickStartGame_Alternate"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:_IsDetailResChecking() then
        ShowNotice(99010064)
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsInReqRoomCD() then
        return false
      end
      if not _ARG_1_ and (not _ARG_0_.modInfo or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetResState(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloaderType.ModCopy, _ARG_0_.modInfo) ~= require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 136, 176, 164, 183, 93, 189, 186, 43, 14, 46, 134, 65))).ENUM_DownloadState.Done) then
        return false
      end
      if not _ARG_1_ then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickStartGame_Internal"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:_IsDetailResChecking() then
        ShowNotice(99010064)
        return false
      end
      if LobbySystem.isInMatch then
        ShowNotice(110017)
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):ReqChooseModForMatch(_ARG_0_.modInfo.mod_id) then
      end
      if _ARG_1_ then
        ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch).bSelectModBackToLobby = false
      end
      if _ARG_1_ and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):ReqChooseModForMatch(_ARG_0_.modInfo.mod_id) then
        return false
      end
      if not _ARG_1_ then
      end
      if not _ARG_1_ then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_hall):CheckIsOpen() then
          goto lbl_249
          if (123).moduleID == BP_ENUM_MODULE_LOBBY and (123).uiData then
            goto lbl_247
            if (135).config == UIManager.UI_Config.UGC_Hall_UIBP then
            elseif (135).config == UIManager.UI_Config.UGC_RightPage_UIBP then
            else
              ::lbl_247::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
          ::lbl_249::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          if not true then
          end
        else
        end
      end
      if not _ARG_1_ and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsModPanelEntryOpen() and _ARG_0_.hot_stat and _ARG_0_.hot_stat.start_type == U2.Smart then
      else
      end
      do return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):ReqChooseModForMatch(_ARG_0_.modInfo.mod_id)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_.modInfo then
        if _ARG_4_ then
        end
        if not _ARG_2_.bSizeKnown then
        end
        if _ARG_2_ and _ARG_2_.bDownloading then
        end
        if not _ARG_2_.bSizeKnown then
          goto lbl_126
          ::lbl_126::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCanReportMAB"] = function(_ARG_0_)
    do
      if _ARG_0_.source ~= Source_Open_Detail.UGCMain then
        return false
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUGC):GetSelectedTabId() ~= Config_UGC_TabID.FineMod then
        return false
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUgcFilterTag).SlectFineModTag or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.LogicUgcFilterTag).SlectFineModTag.ID ~= 0 then
        return false
      end
      do return (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_ugc_new_map):CheckReportMAB(_ARG_0_.modInfo.mod_id)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCanReportHotTheme"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetSelectedTabId() == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 70, 94, 99, 25, 176, 159, 154, 183, 182, 91))).Config_UGC_TabID.HotTheme and _ARG_0_.ExtendParameters and _ARG_0_.ExtendParameters.data_type and (_ARG_0_.ExtendParameters.data_type == U1(123, 151, 105, 7, 230, 156, 22, 94, 77, 32, 134, 164, 138, 149, 147, 103, 136, 161, 16) or _ARG_0_.ExtendParameters.data_type == U1(124, 149, 109, 2, 255, 129, 29, 68, 80, 42)) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCanReportWhiteList"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetSelectedTabId() == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 70, 94, 99, 25, 176, 159, 154, 183, 182, 91))).Config_UGC_TabID.HotTheme and _ARG_0_.ExtendParameters and _ARG_0_.ExtendParameters.data_id and (_ARG_0_.ExtendParameters.data_id == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 70, 94, 99, 25, 176, 159, 154, 183, 182, 91))).REGION_SELF_TAG_HOT_ID or _ARG_0_.ExtendParameters.data_id == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 70, 94, 99, 25, 176, 159, 154, 183, 182, 91))).REGION_HOT_RECOMMEND_ID) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCollect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if not require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 180, 65, 128, 128, 44, 24, 60))).CanClickNow(require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 180, 65, 128, 128, 44, 24, 60))).ClickFrequencyLimit.StoreCollectionBtn) then
        return
      end
      _ARG_0_.bCollect = not _ARG_0_.bCollect
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_WOWPass):IsBuyElite() then
      end
      if _ARG_0_.bCollect then
        if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCSocial):GetCollectList() and #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCSocial):GetCollectList() or 0) >= U2.MaxModCollectPassOn then
          _ARG_0_.bCollect = false
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickShare"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if _ARG_0_:CheckInGame() then
        ShowNotice(655733)
        return
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.puffer_res_manager):IsLobbyResCompleted(true) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickChatShare"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickExtraShare"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDuplicate"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if _ARG_0_:CheckInGame() then
        ShowDevNotice((U1(12, 230, 11, 164, 29, 70, 176, 136, 144, 138, 85, 82, 51, 75, 110, 204, 103, 126, 190, 230, 240, 3, 150, 164, 235, 236, 84, 28, 120, 94)))
        return
      end
      if require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 158, 172, 182, 255, 84, 160, 130, 33, 2, 31, 147, 92, 85),
        U1(121, 160, 90, 50, 201, 186, 59, 94, 121, 0, 190, 134, 185, 189, 160, 76)
      }))).IfNotFitLobbyResDownloadedShowWindow() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):IsBanned(true) then
        return
      end
      if require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).NeedShowUpdateTips(_ARG_0_.modInfo) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickVersionTips"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      log(bWriteLog and U1(199, 114, 155, 169, 29, 121, 177, 185, 150, 135, 116, 85, 51, 78, 65, 206, 73, 69, 191, 248, 216, 3, 185, 157))
      FuncUtil.JumpToDownloadApp()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRecommend"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Guide, false)
      if require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 182, 189, 175, 78, 182, 146, 118, 50, 60, 140, 64, 95, 121, 50, 184, 155, 183, 173, 162, 22, 159, 144, 42, 13, 41, 134, 93, 115),
        U1(74, 162, 65, 46, 206, 152, 52, 98, 111, 0, 186)
      }))).IsCEOperationRegion() then
      elseif not Client.IsReleaseVersion(NetInterface) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonGift"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_CLUB"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Module"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_PlayTogether"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Tips_3, true)
      if _ARG_0_.isShowRoom then
        log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 187, 169, 171, 178, 83, 141, 144, 60, 21, 47, 155, 106, 113),
          U1(67, 164, 81, 21, 207, 178, 48, 117, 117, 10, 187, 200, 166, 183, 173, 78, 241, 156, 43, 34, 56, 138, 82, 99, 98, 16, 180)
        }))
        _ARG_0_.isShowRoom = false
        _ARG_0_.UIRoot.WidgetSwitcher_Tips_3:SetActiveWidgetIndex(1)
        _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Anim_Tips_Out, 0, 1, 0, 1)
      else
        _ARG_0_.isShowRoom = true
        log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 187, 169, 171, 178, 83, 141, 144, 60, 21, 47, 155, 106, 113),
          U1(67, 164, 81, 21, 207, 178, 48, 117, 117, 10, 187, 200, 187, 189, 181, 8, 172, 144, 52, 23, 126, 140, 86, 98, 101, 16, 174, 170, 170, 173, 188)
        }))
        _ARG_0_.UIRoot.WidgetSwitcher_Tips_3:SetActiveWidgetIndex(1)
        _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Anim_Tips_In, 0, 1, 0, 1)
        if not _ARG_0_.modInfo or not _ARG_0_.modInfo.setting then
          return
        end
        if 1 < require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).GetModTeamSize(_ARG_0_.modInfo, 1) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshRoomList"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 170, 160, 164, 163, 93, 188, 141, 26, 14, 47, 152, 121, 72),
        U1(92, 177)
      }))
      if not _ARG_0_:CheckRoomListValid() then
        log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 170, 160, 164, 163, 93, 188, 141, 26, 14, 47, 152, 121, 72),
          U1(92, 177, 8, 19, 197, 164, 24, 110, 121, 38, 189, 141, 184, 128, 174, 71, 178, 185, 49, 2, 36)
        }))
        _ARG_0_.RoomListTimeStamp = require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_PlayTogether_Tips"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetWOWFriendList(_ARG_0_.modInfo.mod_id, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 165, 93, 174, 136, 61, 17, 31, 134, 92, 69),
        U1(74, 154, 74, 32, 210)
      }))).GetFriends() or {}) or #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetWOWFriendList(_ARG_0_.modInfo.mod_id, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 165, 93, 174, 136, 61, 17, 31, 134, 92, 69),
        U1(74, 154, 74, 32, 210)
      }))).GetFriends() or {}) <= 0 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetOnlinFriendIndex((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetWOWFriendList(_ARG_0_.modInfo.mod_id, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 165, 93, 174, 136, 61, 17, 31, 134, 92, 69),
        U1(74, 154, 74, 32, 210)
      }))).GetFriends() or {}))) == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickInviteFriends"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetWOWFriendList(_ARG_0_.modInfo.mod_id, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 165, 93, 174, 136, 61, 17, 31, 134, 92, 69),
        U1(74, 154, 74, 32, 210)
      }))).GetFriends() or {}) or #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetWOWFriendList(_ARG_0_.modInfo.mod_id, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 165, 93, 174, 136, 61, 17, 31, 134, 92, 69),
        U1(74, 154, 74, 32, 210)
      }))).GetFriends() or {}) <= 0 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetOnlinFriendIndex((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetWOWFriendList(_ARG_0_.modInfo.mod_id, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 165, 93, 174, 136, 61, 17, 31, 134, 92, 69),
        U1(74, 154, 74, 32, 210)
      }))).GetFriends() or {}))) == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = ShowUI
    end
  end,
  ["OnClickTranslation"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 187, 169, 171, 178, 83, 155, 151, 41, 15, 51, 153, 84, 85),
        U1(70, 170, 70)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateCollect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_.modInfo then
        return
      end
      if _ARG_0_.modInfo.mod_id ~= _ARG_3_ then
        return
      end
      _ARG_0_.bCollect = _ARG_4_
      _ARG_0_:UpdateCollectState()
      _ARG_0_:UpdatePublicInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateShare"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(116, 160, 76, 54, 193, 167, 49, 92, 61, 58, 142, 171, 145, 183, 181, 73, 182, 153, 23, 1, 53, 151, 68, 69, 104, 44, 172, 154, 149, 163, 191, 93, 163, 223, 7, 15, 21, 133, 81, 64),
        U1(91, 160, 123, 41, 193, 167, 48, 45, 61, 34, 166, 140, 156, 150, 225, 21, 255)
      }) .. tostring(_ARG_3_))
      if not _ARG_0_.modInfo then
        return
      end
      if _ARG_0_.modInfo.mod_id ~= _ARG_3_ then
        return
      end
      _ARG_0_:UpdatePublicInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCollectionModListRsp"] = function(_ARG_0_)
    do
      _ARG_0_.bCollect = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCSocial):IsCollect(_ARG_0_.modInfo.mod_id)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDuplicateMod"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDownloadComplete"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 188, 170, 181, 191, 84, 160, 132, 44, 34, 47, 152, 69, 77),
        U1(74, 177, 77)
      }))
      EventSystem:postEvent(EVENTTYPE_NEWBIE_GUIDE, EVENTID_NEWBIE_UI_OPEN, (U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 38, 167, 142, 186, 129, 180, 74, 143, 148, 54, 20, 60)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModHotStatRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if IsWoWEditor then
        return
      end
      print(bWriteLog and U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 181, 170, 166, 153, 87, 187, 182, 60, 0, 52, 167, 70, 81), _ARG_3_, _ARG_4_, _ARG_5_.start_type, _ARG_5_.heat_level)
      if _ARG_4_ == _ARG_0_.modInfo.mod_id then
        _ARG_0_.hot_stat = _ARG_5_
        _ARG_0_:RefreshStartType()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateRoomList"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return
      end
      if not _ARG_0_.modInfo then
        return
      end
      if #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCRoom):GetRoomList(U1.GetTemplateConfigByID(_ARG_0_.modInfo.base.template_id).Type) > 0 then
        _ARG_0_.roomList = {}
        goto lbl_153
        if (nil).ugc_room_param.mod_id == _ARG_0_.modInfo.mod_id then
        else
        end
        ::lbl_153::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if 0 < #_ARG_0_.roomList then
          if not _ARG_0_.bInited and not _ARG_0_.bIsShowFriends then
            goto lbl_241
            if (nil).state == U1.IdleState then
              repeat
              until math.random(1, 11) ~= math.random(1, 11)
              if _ARG_0_.headIcons[math.random(1, 11)] and _ARG_0_.headIcons[math.random(1, 11)] then
              end
              _ARG_0_.bShowHead = true
              _ARG_0_.bInited = true
            else
              ::lbl_241::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetRoomModList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_.roomList then
        return
      end
      if not require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).CheckMetaType(_ARG_2_, require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENUM_MODE_TYPE.Room) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTransRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.modInfo then
        return
      end
      if not (_ARG_3_ and _ARG_3_.msg) or _ARG_3_.msg ~= _ARG_0_.modInfo.setting.name then
        return
      end
      _ARG_0_:ReFreshTranslateText()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTransStateChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_.modInfo then
        return
      end
      if not _ARG_3_ or _ARG_3_ ~= _ARG_0_.modInfo.setting.name then
        return
      end
      _ARG_0_:ReFreshTranslateText(_ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayerRankInfoRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.modInfo then
        log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 168, 169, 163, 168, 93, 189, 183, 41, 15, 43, 188, 91, 71),
          U1(64, 151, 91, 49, 128, 187, 58, 117, 61, 28, 172, 132, 179, 252, 172, 71, 187, 188, 54, 23, 63)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 168, 169, 163, 168, 93, 189, 183, 41, 15, 43, 188, 91, 71),
        U1(64, 151, 91, 49, 128, 184, 58, 101, 84, 43, 233, 213, 245)
      }) .. tostring(_ARG_3_) .. U1(3, 229, 91, 36, 204, 179, 123, 108, 114, 11, 128, 134, 179, 189, 239, 69, 176, 145, 7, 24, 52, 197, 24, 17) .. tostring(_ARG_0_.modInfo.mod_id))
      if _ARG_3_ ~= _ARG_0_.modInfo.mod_id then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareTipsShow"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 171, 173, 163, 163, 93, 155, 140, 56, 18, 19, 157, 90, 86))
      _ARG_0_:CloseModuleTips()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareTipsClose"] = function(_ARG_0_)
    do
      _ARG_0_.share_tips_ui = nil
      _ARG_0_:InitModuleButtonState()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAddWidgetFailure"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 48, 183, 185, 161, 166, 134, 81, 171, 130, 45, 21, 6, 148, 92, 77),
        U1(90, 183, 77)
      }))
      _ARG_0_:InitModuleButtonState()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitInfoUI"] = function(_ARG_0_)
    do
      _ARG_0_:CheckShowDownloader()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitWidgets"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCommunityButton"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGiftButton"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCollectState"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitGameButton"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 54, 183, 145, 177, 133, 176, 85, 170, 167, 61, 21, 52, 154, 91))
      if _ARG_0_.bHideGameButton or _ARG_0_.UIRoot.WidgetSwitcher_VersionCheck:GetActiveWidgetIndex() == 1 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsSystemOpen() and not _ARG_0_.checkHotStatTimer then
        _ARG_0_.checkHotStatTimer = _ARG_0_:AddTimerLoop(math.max(math.min(U2.GetServerTimeInSec() - ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetModHotStatByID(_ARG_0_.modInfo.mod_id).time, 60), 0.3), function()
          return
        end, TIMER_INFINITE, 60)
      end
      if not _ARG_0_.canCreateRoom then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshStartType"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsSystemOpen() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetModHotStatByID(_ARG_0_.modInfo.mod_id) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetModHotStatByID(_ARG_0_.modInfo.mod_id).start_type == U2.Smart and not require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).IsSubModeGameMod(_ARG_0_.modInfo) and not _ARG_0_:_ShouldShowDownloadStatus() then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetModHotStatByID(_ARG_0_.modInfo.mod_id) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetModHotStatByID(_ARG_0_.modInfo.mod_id).start_type == U2.Smart then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomMatchInfo() then
        elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsModPanelEntryOpen() then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetStartTypeSelectText"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      if _ARG_0_.UIRoot:GetWidgetFromName((_ENV(123, 160, 80, 53, 226, 185, 58, 98, 118, 48, 154, 141, 185, 183, 162, 92))) then
        if _ARG_0_.UIRoot:GetWidgetFromName((_ENV(123, 160, 80, 53, 226, 185, 58, 98, 118, 48, 154, 141, 185, 183, 162, 92))):GetVisibility() ~= U1.UEnums.ESlateVisibility.Visible and _ARG_0_.UIRoot:GetWidgetFromName((_ENV(123, 160, 80, 53, 226, 185, 58, 98, 118, 48, 154, 141, 185, 183, 162, 92))):GetVisibility() ~= U1.UEnums.ESlateVisibility.HitTestInvisible and _ARG_0_.UIRoot:GetWidgetFromName((_ENV(123, 160, 80, 53, 226, 185, 58, 98, 118, 48, 154, 141, 185, 183, 162, 92))):GetVisibility() ~= U1.UEnums.ESlateVisibility.SelfHitTestInvisible then
        end
      end
      if _ARG_0_.UIRoot.WidgetSwitcher_StartType and _ARG_0_.UIRoot.WidgetSwitcher_StartType:GetVisibility() ~= U1.UEnums.ESlateVisibility.Visible and _ARG_0_.UIRoot.WidgetSwitcher_StartType:GetVisibility() ~= U1.UEnums.ESlateVisibility.HitTestInvisible and _ARG_0_.UIRoot.WidgetSwitcher_StartType:GetVisibility() ~= U1.UEnums.ESlateVisibility.SelfHitTestInvisible then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFreeInOutVisible"] = function(_ARG_0_)
    do
      if _ARG_0_.modInfo and _ARG_0_.modInfo.setting and require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 40, 29, 49, 156, 64, 67, 82, 12, 173, 153, 177, 183, 162, 22, 159, 137, 41, 24, 37, 135, 102, 85),
        U1(78, 177, 93, 50, 245, 161, 60, 109)
      }))).IsFreeInOut(_ARG_0_.modInfo.setting.free_inout) then
        if _ARG_0_.UIRoot.WidgetSwitcher_SmartPlay and not _ARG_0_:_ShouldShowDownloadStatus() then
          if _ARG_0_.UIRoot.TextBlock_Room then
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitDuplicateState"] = function(_ARG_0_)
    do
      if _ARG_0_:CheckInGame() then
        log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 54, 183, 145, 177, 134, 164, 72, 163, 140, 43, 0, 52, 144, 102, 85),
          U1(78, 177, 77, 97, 233, 187, 18, 96, 112, 10)
        }))
        _ARG_0_.UIRoot.Button_Duplicate:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      else
        _ARG_0_.UIRoot.Button_Duplicate:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCAuthor):NewCheckPlayerIsAuthor(DataMgr.roleData.uid) then
      elseif _ARG_0_.modInfo.base.uid ~= tonumber(DataMgr.roleData.uid) and (not _ARG_0_.modInfo.setting.share_switch or _ARG_0_.modInfo.setting.share_switch == 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitModuleButtonState"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 54, 183, 145, 177, 143, 190, 92, 186, 137, 45, 35, 53, 129, 65, 78),
        U1(65, 150, 92, 32, 212, 176, 117, 108, 114, 11, 128, 140, 232)
      }) .. tostring(_ARG_0_.modInfo.mod_id))
      _ARG_0_.UIRoot.TextBlock_Module:SetText(LocUtil.GetLocalizeResStr(4302125))
      if _ARG_0_:ShouldShowModuleButton() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowModuleButton"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 182, 189, 175, 78, 182, 146, 118, 50, 60, 140, 64, 95, 121, 50, 184, 155, 183, 173, 162, 22, 159, 144, 42, 13, 41, 134, 93, 115),
        U1(74, 162, 65, 46, 206, 152, 52, 98, 111, 0, 186)
      }))).IsJapanOrKorea() or require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 182, 189, 175, 78, 182, 146, 118, 50, 60, 140, 64, 95, 121, 50, 184, 155, 183, 173, 162, 22, 159, 144, 42, 13, 41, 134, 93, 115),
        U1(74, 162, 65, 46, 206, 152, 52, 98, 111, 0, 186)
      }))).IsBlueholeOperationRegion() then
        return false
      end
      if not require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 59, 30, 61, 136, 80, 95, 100, 11, 160, 214, 169, 173, 182, 81, 172, 186, 43, 14, 45, 152, 64, 79),
        U1(70, 177, 81)
      }))).GetShowEntry() then
        return false
      end
      if _ARG_0_:IsDesktopModuleInstalled() then
        return false
      end
      if not require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id) then
        return false
      end
      if 0 < require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).TimeStringToUnixstamp(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id).StartTime) and require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).TimeStringToUnixstamp(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id).StartTime) > require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec() then
        return false
      end
      if 0 < require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).TimeStringToUnixstamp(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id).EndTime) and require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).TimeStringToUnixstamp(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id).EndTime) < require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDesktopModuleInstalled"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 176, 91, 187, 140, 62, 8, 52, 140, 106, 84),
        U1(91, 172, 68)
      }))).GetActivityDesktopToolType() and require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 52, 30, 50, 135, 92, 31, 97, 16, 190, 145, 166, 157, 176, 91, 187, 140, 62, 8, 52, 140, 106, 84),
        U1(91, 172, 68)
      }))).GetActivityDesktopToolType() & ActivityDesktopToolType.Friend ~= 0 then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndShowModuleTips"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id) then
        return
      end
      if (require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).LoadFileToTable_N(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).ePlayerPrefsType.eUGCDesktopModuleTips) or {})[_ARG_0_.modInfo.mod_id] then
        return
      end
      if _ARG_0_.UIRoot.CanvasPanel_Guide:GetVisibility() == UEnums.ESlateVisibility.SelfHitTestInvisible then
        return
      end
      _ARG_0_.moduleGuideTips = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_Module, UIManager.UI_Config.Common_Tips_Top_UIBP, require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 65, 84, 121, 30, 176, 148, 235, 183, 182, 91, 144, 129, 45, 18, 43, 129, 90, 81),
        U1(112, 168, 71, 37, 213, 185, 48, 94, 104, 27, 160, 132, 166)
      }))).GetModuleSubModuleConfig(_ARG_0_.modInfo.mod_id).Tips)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseModuleTips"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 60, 181, 151, 182, 167, 156, 87, 171, 144, 36, 4, 20, 156, 69, 82),
        U1(15, 167, 107, 45, 197, 180, 39, 83, 120, 11, 173, 135, 161, 232, 225)
      }) .. tostring(_ARG_1_))
      if _ARG_0_.moduleGuideTips then
        _ARG_0_.moduleGuideTips:CloseSelf()
        _ARG_0_.moduleGuideTips = nil
        if _ARG_1_ then
          log(bWriteLog and table.concat({
            U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 60, 181, 151, 182, 167, 156, 87, 171, 144, 36, 4, 20, 156, 69, 82),
            U1(15, 166, 68, 36, 193, 167, 117, 115, 120, 11, 173, 135, 161)
          }))
          ;(require((table.concat({
            U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
            U1(92)
          }))).LoadFileToTable_N(require((table.concat({
            U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
            U1(92)
          }))).ePlayerPrefsType.eUGCDesktopModuleTips) or {})[_ARG_0_.modInfo.mod_id] = true
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUGCRoomCardInfo"] = function(_ARG_0_)
    do
      if 0 > DataMgr.room_card_info.expire_ts or 0 > DataMgr.room_card_info_wow.expire_ts then
      elseif 0 < DataMgr.room_card_info_wow.rest_times then
      else
      end
      do return math.max(DataMgr.room_card_info.expire_ts, DataMgr.room_card_info_wow.expire_ts), DataMgr.room_card_info.rest_times end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomCardInfo"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBuyRoomCard"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBottomActive"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 44, 188, 140, 135, 173, 165, 76, 160, 136, 9, 2, 52, 156, 67, 68),
        U1(15, 164, 75, 53, 201, 163, 48, 33, 32, 79)
      }) .. tostring(_ARG_1_))
      if _ARG_0_.UIRoot.WidgetSwitcher_Button then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Button, _ARG_1_ and not IsWoWEditor)
      end
      if _ARG_1_ then
        _ARG_0_.UIRoot.WidgetSwitcher_VersionCheck:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_.UIRoot.HorizontalBox_Right:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Room, true)
        log((U1(67, 172, 81, 32, 206, 178, 117, 117, 111, 26, 172)))
      else
        _ARG_0_.UIRoot.WidgetSwitcher_VersionCheck:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.HorizontalBox_Right:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Room, false)
        log((U1(67, 172, 81, 32, 206, 178, 117, 103, 124, 3, 186, 141)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowDownloader"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return
      end
      if (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetDownloadAward() and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetDownloadAward().is_got or false) and _ARG_0_.modInfo.base and _ARG_0_.modInfo.base.template_id and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetUGCMapKeyByTemplateId(_ARG_0_.modInfo.base.template_id) and CDataTable.GetTableData(U1(98, 164, 88, 17, 193, 190, 1, 96, 127, 3, 172), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetUGCMapKeyByTemplateId(_ARG_0_.modInfo.base.template_id))) and (CDataTable.GetTableData(U1(98, 164, 88, 17, 193, 190, 1, 96, 127, 3, 172), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetUGCMapKeyByTemplateId(_ARG_0_.modInfo.base.template_id))).depends == U1() or not string.find(CDataTable.GetTableData(U1(98, 164, 88, 17, 193, 190, 1, 96, 127, 3, 172), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetUGCMapKeyByTemplateId(_ARG_0_.modInfo.base.template_id))).depends, (U1(66, 164, 88, 30, 195, 167, 48, 96, 105, 6, 191, 141, 182, 189, 179, 77)))) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetResState(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloaderType.ModCopy, _ARG_0_.modInfo) == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 136, 176, 164, 183, 93, 189, 186, 43, 14, 46, 134, 65))).ENUM_DownloadState.Done then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetResSnapshot(_ARG_0_.modInfo) == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 136, 176, 164, 183, 93, 189, 186, 43, 14, 46, 134, 65))).ENUM_DownloadState.Not and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetResSnapshot(_ARG_0_.modInfo) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetResSnapshot(_ARG_0_.modInfo) and not _ARG_0_.bWaitingDownloadSize then
          _ARG_0_.bWaitingDownloadSize = true
        end
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetResSnapshot(_ARG_0_.modInfo) == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 136, 176, 164, 183, 93, 189, 186, 43, 14, 46, 134, 65))).ENUM_DownloadState.Not and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetResSnapshot(_ARG_0_.modInfo) < require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).UGC_RES_TIER_THRESHOLD.AUTO_MAX and not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomInfo() ~= nil) and not (1 < require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).GetTeamNum() and not require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).IsTeamLeader()) then
        return
      end
      if _ARG_0_.UGCDownloadUI then
        return
      end
      _ARG_0_.UGCDownloadUI = require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 182, 189, 172, 69, 176, 155, 118, 18, 63, 136, 72, 94, 99, 32, 189, 151, 178, 172, 189, 87, 174, 129, 23, 9, 33, 155, 81, 77),
        U1(74, 183)
      }))).CreateUGCDownloader(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloadUIType.DetailLoadBtn, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloaderType.ModCopy, _ARG_0_.modInfo, _ARG_0_.UIRoot.CanvasPanelDownload, _ARG_0_.UIRoot.WidgetSwitcher_ResState, _ARG_0_, {
        UGCDownloadConfirmThreshold = 50,
        bSpecialStyle = true,
        bUGCDownloadAward = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetDownloadAward() and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetDownloadAward().is_got or false,
        EndDownloadCallback = function()
          if not U2 then
            return
          end
          return
        end,
        TextColor = FSlateColor(FLinearColor(0, 0, 0, 1)),
        LinearColor = FLinearColor(0, 0, 0, 1),
        Source = require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 70, 94, 99, 25, 176, 159, 154, 183, 182, 91))).EnumDownLoadSource.UGCDetailOperateSubPanel,
        iconColor = FLinearColor(0, 0, 0, 1)
      })
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetDownloadAward() and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetDownloadAward().is_got or false then
        if _ARG_0_.UGCDownloadUI then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsAtDownloadStatus"] = function(_ARG_0_)
    do
      do return _ARG_0_.UIRoot.WidgetSwitcher_ResState:GetActiveWidgetIndex() == 1 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckModInfoVersion"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSelfRecommend"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Button_Recommend:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 42, 169, 156, 164, 182, 180, 107, 170, 137, 46, 51, 37, 150, 90, 76),
        U1(66, 160, 70, 37, 128)
      }))
      if not LobbySystem.CheckLobbyMenuOpen(BP_ENUM_UGC_SELF_RECOMMEND, false) then
        _ARG_0_.UIRoot.Button_Recommend:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 42, 169, 156, 164, 182, 180, 107, 170, 137, 46, 51, 37, 150, 90, 76),
        U1(66, 160, 70, 37, 145, 245)
      }))
      if _ARG_0_.modInfo.base.state_release ~= U2.E_PublishState.Published then
        return
      end
      if _ARG_0_.modInfo.base.uid ~= tonumber(DataMgr.roleData.uid) then
        return
      end
      if (require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).LoadFileToTable_N(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).ePlayerPrefsType.eUGCMyModRecommendReddot) or {}).saveVersion ~= require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 183, 77, 173, 134, 49, 30, 62, 186, 80, 69, 100, 19))).GetClientFormat(Client.GetAppVersion()) then
        ;(require((table.concat({
          U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
          U1(92)
        }))).LoadFileToTable_N(require((table.concat({
          U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
          U1(92)
        }))).ePlayerPrefsType.eUGCMyModRecommendReddot) or {}).saveVersion = require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 183, 77, 173, 134, 49, 30, 62, 186, 80, 69, 100, 19))).GetClientFormat(Client.GetAppVersion()), require((table.concat({
          U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
          U1(92)
        }))), require((table.concat({
          U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
          U1(92)
        }))).LoadFileToTable_N(require((table.concat({
          U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
          U1(92)
        }))).ePlayerPrefsType.eUGCMyModRecommendReddot) or {}, log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 42, 169, 156, 164, 182, 180, 107, 170, 137, 46, 51, 37, 150, 90, 76),
          U1(66, 160, 70, 37, 128, 188, 38, 33, 115, 10, 190, 200, 163, 183, 179, 91, 182, 154, 54)
        }))
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitRoomListUIBP"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return
      end
      _ARG_0_.insRoomList = require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 160, 191, 166, 6, 170, 146, 59, 95, 51, 138, 72, 92, 104, 17, 173, 214, 144, 133, 146, 103, 155, 138, 47, 4, 52, 157, 80, 83),
        U1(127, 169, 73, 56, 255, 129, 60, 113, 110, 48, 156, 161, 151, 130)
      })))(_ARG_0_.modInfo), require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 160, 191, 166, 6, 170, 146, 59, 95, 51, 138, 72, 92, 104, 17, 173, 214, 144, 133, 146, 103, 155, 138, 47, 4, 52, 157, 80, 83),
        U1(127, 169, 73, 56, 255, 129, 60, 113, 110, 48, 156, 161, 151, 130)
      })))(_ARG_0_.modInfo):InitWithParentWidget(_ARG_0_, _ARG_0_.UIRoot.New_UGC_TogetherPlay_Tips_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitFriendTips"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsModPlayedByFriend(_ARG_0_.modInfo.mod_id).type == 1 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsModPlayedByFriend(_ARG_0_.modInfo.mod_id).type == 2 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsModPlayedByFriend(_ARG_0_.modInfo.mod_id).type == 3 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsModPlayedByFriend(_ARG_0_.modInfo.mod_id).type == 4 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsModPlayedByFriend(_ARG_0_.modInfo.mod_id).type == 5 then
      end
      if not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetFriendsByType(5, _ARG_0_.modInfo.mod_id))) or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):GetDisplayFriendLabel(_ARG_0_.modInfo.mod_id, _ARG_0_.modInfo.base.uid) == U1() or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode):IsModPlayedByFriend(_ARG_0_.modInfo.mod_id).type == 6 then
        return
      end
      if not _ARG_0_:ShowFriendTips() then
        return
      else
      end
      _ARG_0_.bIsShowFriends = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFriendTips"] = function(_ARG_0_)
    do
      if _ARG_0_.bHideGameButton or _ARG_0_:CheckInGame() or _ARG_0_.UIRoot.WidgetSwitcher_ResState:GetActiveWidgetIndex() == 1 or _ARG_0_.UIRoot.WidgetSwitcher_VersionCheck:GetActiveWidgetIndex() == 1 then
        return false
      else
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSlotSize"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_.Slot.Size.Value = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdataProfile"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ then
      else
      end
      if _ARG_2_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckRoomListValid"] = function(_ARG_0_)
    do
      if not _ARG_0_.RoomListTimeStamp then
        return false
      end
      do return require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec() <= _ARG_0_.RoomListTimeStamp + _ARG_0_.RefreshBtnCDTime end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BlockEntrances"] = function(_ARG_0_)
    do
      if not IsWoWEditor then
        return
      end
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Share, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Report, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Gift, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Recommend, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_CLUB, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_ClubLine, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_VersionCheck, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Room, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Button, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_StarGame, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_VersionTips, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckInGame"] = function(_ARG_0_)
    do
      do return not GameStatus.IsInLobbyOrMainCity() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckWowGiftTips"] = function(_ARG_0_)
    do
      if IsWoWEditor then
        return
      end
      if not _ARG_0_.UIRoot.CanvasPanel_6 then
        return
      end
      if (require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).LoadFileToTable_N(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {}) and (require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).LoadFileToTable_N(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {})[require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby] and (require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).LoadFileToTable_N(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {})[require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby].IsDone then
        return
      end
      if not _ARG_0_:CheckToiletSwitch() then
        return
      end
      if not (require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).LoadFileToTable_N(require((table.concat({
        U1(76, 169, 65, 36, 206, 161, 123, 109, 114, 8, 160, 139, 251, 158, 174, 79, 182, 150, 8, 29, 49, 156, 64, 67, 93, 13, 188, 158, 182, 236, 161, 84, 174, 156, 45, 19, 48, 135, 80, 71),
        U1(92)
      }))).ePlayerPrefsType.eUGCWowGiftTips) or {}) then
      else
      end
      if ({
        [require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby] = {}
      })[require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby].Time and os.time({
        year = os.date(U1(10, 156), (require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec())),
        month = os.date(U1(10, 168), (require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec())),
        day = os.date(U1(10, 161), (require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec())),
        hour = 0,
        min = 0,
        sec = 0
      }) <= ({
        [require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby] = {}
      })[require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby].Time then
      end
      if false then
        ;({
          [require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby] = {}
        })[require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby].Time = require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec(), os.time({
          year = os.date(U1(10, 156), (require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec())),
          month = os.date(U1(10, 168), (require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec())),
          day = os.date(U1(10, 161), (require((U1(76, 169, 65, 36, 206, 161, 123, 98, 114, 2, 164, 135, 187, 252, 181, 65, 178, 144, 7, 4, 36, 140, 73))).GetServerTimeInSec())),
          hour = 0,
          min = 0,
          sec = 0
        }), ({
          [require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby] = {}
        })[require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 63, 24, 54, 145, 11, 86, 100, 25, 173, 167, 166, 173, 191, 75, 187))).EWowPageType.InLobby]
        if not _ARG_0_.tipsUI then
          _ARG_0_.tipsUI = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_6, UIManager.UI_Config.Common_Tips_Top_UIBP, (LocUtil.LocalizeResFormat(68738)))
        end
        if _ARG_0_.tipsTimer then
          _ARG_0_.tipsTimer = nil
        end
        _ARG_0_.tipsTimer = _ARG_0_:AddTimerOnce(3, function()
          _ENV:CloseReturnGiveTips()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[120]
    end
  end,
  ["CloseReturnGiveTips"] = function(_ARG_0_)
    do
      if _ARG_0_.tipsUI then
        _ARG_0_.tipsUI:CloseSelf()
        _ARG_0_.tipsUI = nil
        log(bWriteLog and table.concat({
          U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 60, 177, 157, 166, 169, 134, 87, 184, 162, 33, 7, 52, 161, 92, 81),
          U1(92, 229, 107, 45, 207, 166, 48, 59)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReFreshTranslateText"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTrans):GetTransByStr(_ARG_0_.modInfo.setting.name) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCTrans):GetTransByStr(_ARG_0_.modInfo.setting.name) ~= U1() then
        if not _ARG_1_ then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckToiletSwitch"] = function(_ARG_0_)
    do
      if not LobbySystem.CheckOpen(BP_UGC_Gift_TOILET_SWITCH) and require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).IsModWithEvent(_ARG_0_.modInfo, require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENUM_EventElementID.Skibidi_Toilet) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMySelfClearanceState"] = function(_ARG_0_)
    do
      if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCModRank):CheckUGCRankOpen(_ARG_0_.modInfo) and not _ARG_0_:CheckInGame()) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshShareTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 45, 188, 158, 183, 167, 162, 80, 156, 141, 41, 19, 37, 161, 92, 81),
        U1(92, 229, 69, 56, 242, 180, 59, 106, 61, 82, 233)
      }) .. tostring(_ARG_1_) .. U1(15, 168, 81, 18, 195, 186, 39, 100, 61, 82, 233) .. tostring(_ARG_2_) .. U1(15, 168, 81, 22, 201, 187, 117, 60, 61) .. tostring(_ARG_3_) .. U1(15, 168, 71, 37, 201, 177, 117, 60, 61) .. _ARG_0_.modInfo.mod_id)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Details, false)
      if _ARG_1_ then
      elseif _ARG_2_ then
      elseif _ARG_3_ then
      end
      goto lbl_168
      ::lbl_168::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_179
      ::lbl_179::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_192
      if table.insert({}, (37).ugc_mod_id) == _ARG_0_.modInfo.mod_id then
      else
        ::lbl_192::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.modInfo.base.state_release ~= U2.E_PublishState.Published and _ARG_0_.modInfo.base.state_release ~= U2.E_PublishState.Private then
      end
      if true and false then
        if _ARG_0_.UIRoot.CanvasPanel_Guide:GetVisibility() == UEnums.ESlateVisibility.SelfHitTestInvisible then
        else
          if _ARG_0_.share_tips_ui then
          else
            if not _ARG_0_.show_share_tips_cnt then
              _ARG_0_.show_share_tips_cnt = 0
            end
            _ARG_0_.show_share_tips_cnt = _ARG_0_.show_share_tips_cnt + 1
            if _ARG_0_.show_share_tips_cnt >= 2 then
              return
            end
            _ARG_0_.share_tips_ui = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_Details, UIManager.UI_Config.UGC_ShareChallenge_Tips_Item_UIBP, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.CustomsClearance)
          end
          if _ARG_0_.show_share_tips_cnt >= 2 then
          end
        end
      end
      _ARG_0_.share_challenge_info = {
        clearanceState = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.CustomsClearance,
        rank = _ARG_1_,
        score = _ARG_2_,
        win = _ARG_3_
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDownload"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_3_ then
        return
      end
      if not _ARG_4_ or _ARG_4_ ~= require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 70, 94, 99, 25, 176, 159, 154, 183, 182, 91))).EnumDownLoadSource.UGCDetailOperateSubPanel then
        return
      end
      if not _ARG_3_.mod_id or tonumber(_ARG_3_.mod_id) ~= tonumber(_ARG_0_.modInfo.mod_id) then
        return
      end
      if RoomSystem.CurrentRoomInfo and next(RoomSystem.CurrentRoomInfo) and RoomSystem.CurrentRoomInfo.room_type == U1(90, 162, 75) then
      end
      if require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).GetTeamNum() > 1 and not require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 44, 20, 49, 136, 80, 65, 35, 19, 182, 159, 172, 161, 142, 76, 170, 132, 37, 62, 53, 133))).IsTeamLeader() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus(_ARG_0_.modInfo).bDownloading then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus(_ARG_0_.modInfo).tier ~= require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_RES_TIER.DETAIL_BTN and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus(_ARG_0_.modInfo).tier ~= require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_RES_TIER.DETAIL_BTN_REUSE then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):RecordDownloadTrigger(_ARG_0_.modInfo, require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_DOWNLOAD_TRIGGER.ExplicitButton) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetDownloadTrigger(_ARG_0_.modInfo.mod_id) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):IsModSelected(_ARG_0_.modInfo.mod_id) then
        _ARG_0_.bSelectedFromDetailDownload = true
        return
      end
      if _ARG_0_.bSelectedFromDetailDownload or _ARG_0_.bSelectingFromDetailDownload then
        return
      end
      _ARG_0_.bSelectingFromDetailDownload = true
      _ARG_0_.bSelectingFromDetailDownload = false
      if _ARG_0_:OnClickStartGameNew(true) then
        _ARG_0_.bSelectedFromDetailDownload = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsModStateBlockBottom"] = function(_ARG_0_)
    do
      if not _ARG_0_.modInfo or not _ARG_0_.modInfo.base then
        return false
      end
      if _ARG_0_.modInfo.base.state_release == U2.E_PublishState.ManualReview or _ARG_0_.modInfo.base.state_release == U2.E_PublishState.Rectification then
        return true
      end
      if _ARG_0_.modInfo.base.state_release == U2.E_PublishState.Published and require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 69, 100, 19, 134, 141, 162, 161))).IsUGCPubItemExpired(_ARG_0_.modInfo) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitState"] = function(_ARG_0_)
    do
      if not _ARG_0_.modInfo then
        return
      end
      log(bWriteLog and table.concat({
        U1(122, 130, 107, 5, 197, 161, 52, 104, 113, 32, 185, 141, 167, 179, 181, 77, 140, 128, 58, 33, 49, 139, 64, 93, 55, 54, 183, 145, 177, 145, 165, 89, 187, 128, 104, 18, 37, 153, 83, 15),
        U1(92, 170, 93, 51, 195, 176, 117, 60, 61)
      }) .. tostring(_ARG_0_.source))
      if _ARG_0_.source ~= U2.Source_Open_Detail.UGCAuthorWork and _ARG_0_.source ~= U2.Source_Open_Detail.MineEdit then
        _ARG_0_:SetBottomActive(true)
        return
      end
      if _ARG_0_:_IsModStateBlockBottom() then
        _ARG_0_:SetBottomActive(false)
      elseif _ARG_0_.modInfo.base.state_release == U2.E_PublishState.Published then
        _ARG_0_:SetBottomActive(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsDetailResChecking"] = function(_ARG_0_)
    do
      if not _ARG_0_.modInfo then
        return false
      end
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_DETAIL_DL_STATUS.CHECKING end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetDetailDownloadDisplayInfo"] = function(_ARG_0_)
    do
      if not _ARG_0_.modInfo or not _ARG_0_.UIRoot then
        return false, false, nil, nil
      end
      if _ARG_0_:_IsModStateBlockBottom() then
        return false, false, nil, nil
      end
      do return (_ARG_0_.bSelectedFromDetailDownload or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).bSelected == true) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).bDownloading == true or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).resState == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 136, 176, 164, 183, 93, 189, 186, 43, 14, 46, 134, 65))).ENUM_DownloadState.Pause and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).tier == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_RES_TIER.DETAIL_BTN or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).tier == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_RES_TIER.DETAIL_BTN_REUSE)) or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_DETAIL_DL_STATUS.CHECKING or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_DETAIL_DL_STATUS.REMIND, (_ARG_0_.bSelectedFromDetailDownload or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).bSelected == true) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).bDownloading == true or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).resState == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 60, 30, 39, 139, 73, 94, 108, 27, 247, 136, 176, 164, 183, 93, 189, 186, 43, 14, 46, 134, 65))).ENUM_DownloadState.Pause and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).tier == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_RES_TIER.DETAIL_BTN or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo).tier == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_UGC_RES_TIER.DETAIL_BTN_REUSE)), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus(_ARG_0_.modInfo) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShouldShowDownloadStatus"] = function(_ARG_0_)
    do
      do return (_ARG_0_:_GetDetailDownloadDisplayInfo()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SyncSmartPlayWithDownloadStatus"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      if _ARG_1_ then
        _ARG_0_.UIRoot.WidgetSwitcher_SmartPlay:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      else
        _ARG_0_:RefreshStartType()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshDetailDownloadStatus"] = function(_ARG_0_)
    do
      if not _ARG_0_.modInfo then
        return
      end
      if not _ARG_0_.UIRoot then
        return
      end
      if not _ARG_0_.UIRoot.WidgetSwitcher_DownloadStatus then
        return
      end
      if not _ARG_0_:_GetDetailDownloadDisplayInfo() then
        return
      end
      if _ARG_0_:_GetDetailDownloadDisplayInfo() then
        if _ARG_0_.UIRoot.TextBlock_DS_Match then
        end
      elseif _ARG_0_:_GetDetailDownloadDisplayInfo() == require((U1(76, 169, 65, 36, 206, 161, 123, 114, 113, 26, 168, 198, 185, 189, 166, 65, 188, 219, 45, 22, 51, 203, 80, 86, 110, 32, 180, 153, 166, 176, 190, 75))).ENU_DETAIL_DL_STATUS.CHECKING then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnResStatusChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.modInfo or _ARG_0_.modInfo.mod_id ~= _ARG_3_ then
        return
      end
      if not _ARG_0_.UIRoot then
        return
      end
      _ARG_0_:_RefreshDetailDownloadStatus()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
