local Component_HideUIGroup = {}
local Trait = require("common.trait")
local TComponent_HideUIGroup = Trait(Trait.TraitPrototype, nil, Component_HideUIGroup)

function Component_HideUIGroup:InitHideUIGroup(HideUIGroupConfig, HideUIWidgetConfig)
  self.HideUIGroupConfig = HideUIGroupConfig or {}
  self.HideUIWidgetConfig = HideUIWidgetConfig or {}
  self._widgetHideData = {}
  self:_InitHideUIGroup()
end

function Component_HideUIGroup:ClearHideUIGroup()
  for k, data in pairs(self._widgetHideData) do
    local widget = data.widget
    self:SetWidgetVisible(widget, true, data.isButton)
  end
  self._widgetHideData = {}
end

function Component_HideUIGroup:GetWidgetCanShowWithHideData(name)
  if not self._widgetHideData[name] then
    return true
  end
  local keyList = self._widgetHideData[name].keyList
  return next(keyList) == nil
end

function Component_HideUIGroup:IsHideGroupHidingAnyNode(group, nodeNameList)
  if not group or not nodeNameList then
    return false
  end
  local hideGroup = self.HideUIGroupConfig and self.HideUIGroupConfig[group]
  if not hideGroup then
    return false
  end
  for _, widgetName in ipairs(hideGroup) do
    for _, nodeName in ipairs(nodeNameList) do
      if widgetName == nodeName then
        return true
      end
    end
  end
  return false
end

function Component_HideUIGroup:_InitHideUIGroup()
  local hasReset = {}
  for key, widgetList in pairs(self.HideUIGroupConfig) do
    for _, widgetName in ipairs(widgetList) do
      if not hasReset[widgetName] then
        local widgetConfig = self.HideUIWidgetConfig[widgetName]
        local isButton = widgetConfig and widgetConfig.isButton or false
        self:SetWidgetVisible(self.UIRoot[widgetName], true, isButton)
        hasReset[widgetName] = true
      end
    end
  end
end

function Component_HideUIGroup:_OnClickHideUIGroup(group, isShow)
  self:_RefreshHideUIGroupShow(group, isShow)
end

function Component_HideUIGroup:_RefreshHideUIGroupShow(group, isShow)
  log_format("NewCamera_Photo_UIBP:_RefreshHideUIGroupShow group: %s, isShow: %s", group, isShow)
  local hideUIGroup = self.HideUIGroupConfig[group]
  if hideUIGroup then
    for _, widgetName in ipairs(hideUIGroup) do
      if isShow then
        self:ReshowWidgetVisibleByKey(widgetName, group)
      else
        local widgetConfig = self.HideUIWidgetConfig[widgetName]
        local isButton = widgetConfig and widgetConfig.isButton or false
        self:_HideWidgetVisibleByKey(widgetName, group, isButton)
      end
    end
  end
end

function Component_HideUIGroup:_HideWidgetVisibleByKey(name, key, isButton)
  if not slua.isValid(self.UIRoot) then
    return
  end
  local isUIRoot = name == "UIRoot"
  local widget = isUIRoot and self.UIRoot or self.UIRoot[name]
  if not slua.isValid(widget) then
    return
  end
  if not self._widgetHideData[name] then
    self._widgetHideData[name] = {
      widget = widget,
      isButton = isButton,
      keyList = {}
    }
  end
  local keyList = self._widgetHideData[name].keyList
  keyList[key] = true
  if isUIRoot then
    self:Hide()
  else
    self:SetWidgetVisible(widget, false, isButton)
  end
  log_tree("NewCamera_Photo_UIBP:HideWidgetVisibleByKey - name = " .. tostring(name) .. ". keyList =", keyList)
end

function Component_HideUIGroup:ReshowWidgetVisibleByKey(name, key)
  if not self._widgetHideData[name] then
    return
  end
  local isUIRoot = name == "UIRoot"
  local data = self._widgetHideData[name]
  local widget = data.widget
  if not slua.isValid(widget) then
    return
  end
  local keyList = data.keyList
  keyList[key] = nil
  local canShow = next(keyList) == nil
  if isUIRoot then
    if canShow then
      self:Show()
    else
      self:Hide()
    end
  else
    self:SetWidgetVisible(widget, canShow, data.isButton)
  end
  log_tree("NewCamera_Photo_UIBP:ReshowWidgetVisibleByKey - name = " .. tostring(name) .. ". keyList =", keyList)
end

return TComponent_HideUIGroup
