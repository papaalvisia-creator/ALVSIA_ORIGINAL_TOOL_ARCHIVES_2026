do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(8, 141, 84, 26, 139, 249, 183, 169, 72, 41, 196, 141))).TraitClass(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 166, 104, 55, 190, 174, 233, 179, 36, 34, 99, 200, 155, 134, 4, 58, 220, 154, 104))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log_format(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 248, 166, 38, 53, 58, 135, 154, 136, 70, 62, 232, 160, 48, 107, 130, 244, 171, 165, 43, 54, 125, 138, 220, 142),
        U1(71, 194, 90, 22, 136, 251, 251, 188, 89, 35, 144, 220, 110, 114, 193, 164, 250, 188, 46, 50, 117, 192, 140, 174, 66, 61, 222, 130, 48, 107, 130)
      }), _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
      _ARG_0_.bShowing = false
      _ARG_0_.gray = _ARG_2_ or false
      _ARG_0_.callbackAfterGrayUpdate = _ARG_3_
      _ARG_0_.versionInfo = {}
      _ARG_0_.IsWaitingFitLangDownload = _ARG_4_
      _ARG_0_.retriedUpdateTimes = 0
      _ARG_0_.maxRetryUpdateTimes = 1
      _ARG_0_.haveRetried71X = false
      _ARG_0_.reportedErrorList = {}
      _ARG_0_.cancelUpdateTimes = 0
      _ARG_0_.preStage = U2.Updating
      _ARG_0_.currentStage = U2.Updating
      _ARG_0_.calculateSpeedState = 0
      _ARG_0_.haveDownloadedSize = 0
      _ARG_0_.lastCalculateTime = 0
      _ARG_0_.downloadSpeed = 0
      _ARG_0_.realtimeDownloadSpeedZeroCount = 0
      _ARG_0_.calculateAverageSpeedState = 0
      _ARG_0_.averageDownloadSize = 0
      _ARG_0_.lastCalculateAverageTime = 0
      _ARG_0_.averageDownloadSpeed = 0
      _ARG_0_.speedTimer = nil
      _ARG_0_.CDNImageTimer = nil
      _ARG_0_.CDNImage = {}
      _ARG_0_.CDNImageIndex = 1
      _ARG_0_.CDNNoticeType = U1(93, 208)
      _ARG_0_.checkUpdateWaitTime = 0
      _ARG_0_.checkUpdateTimer = nil
      _ARG_0_.ErrCodeTimeOut = 888888888
      _ARG_0_.retriedUpdateAfterDeleteFileTimes = 0
      _ARG_0_.maxRetryUpdateAfterDeleteFileTimes = 1
      _ARG_0_.showSecondStageReward = false
      _ARG_0_.useNewComp = false
      _ARG_0_.TextBlock_State = nil
      _ARG_0_.TextBlock_DownloadSpeed = nil
      _ARG_0_.TextBlock_SizeInfo = nil
      _ARG_0_.TextBlock_RemainTime = nil
      _ARG_0_.secondDownloadCurSize = 0
      _ARG_0_.secondDownloadTotalSize = 0
      _ARG_0_.secondDownloadCurStage = 0
      _ARG_0_.isResourceUpdate = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 25, 40, 103, 211, 160, 131, 67, 44, 212, 136, 97, 39, 139, 189))
      U2.__super.OnPostInitialize(_ARG_0_)
      if _ARG_0_.gray and not require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 219, 183, 59, 59, 109, 196, 145, 175),
        U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)
      }))).IsFITVersion() then
      end
      if _ARG_0_.gray then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 26, 47, 123, 208))
      U2.__super.OnShow(_ARG_0_)
      _ARG_0_.bShowing = true
      _ARG_0_:InitUIComponent()
      _ARG_0_:RefreshUI()
      log_shipping_client(bWriteLog and U1(25, 131, 80, 25, 196, 231, 235, 178, 92, 33, 193, 156, 61, 8, 132, 186, 232, 187, 38, 41, 65, 215, 141, 140, 94, 61))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 0, 41, 125, 211, 128, 140, 70, 49, 199, 140))
      U2.__super.OnInitialize(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 46, 46, 103, 211, 172, 155, 79, 54, 201, 154))
      U2.__super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_SystemNotify, _ARG_0_.OnClickSystemNotify, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Bulletin, _ARG_0_.OnClickButton_Bulletin, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_2, _ARG_0_.OnClickButton_2, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSystemNotify"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSoundButton"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 206, 162, 45, 38, 96, 194, 186, 130, 95, 54, 217, 171, 120, 58, 133, 183, 229, 236, 121, 53, 87, 216, 140, 147),
        U1(15, 173, 87, 74, 193, 228)
      }), _ARG_1_)
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_10, _ARG_1_ and U2 or U3, {sync = true})
      _ARG_0_:SetCanPlaySound(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCanPlaySound"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 200, 183, 61, 4, 117, 201, 185, 129, 75, 33, 238, 134, 120, 32, 149, 246, 171, 167, 55, 54, 102, 219, 156, 192),
        U1(78, 145)
      }), _ARG_1_)
      _ARG_0_.canPlaySound = _ARG_1_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVideoSound"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 200, 183, 61, 17, 125, 195, 140, 130, 121, 55, 200, 135, 105, 96, 209, 189, 229, 163, 59, 59, 97, 138, 220, 142), _ARG_1_)
      if not _ARG_0_.mediaPlayerOpenSuccess then
        return
      end
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitUIComponent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      printf(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 210, 188, 32, 51, 65, 238, 170, 130, 71, 40, 210, 135, 104, 32, 133, 246, 171, 183, 42, 50, 74, 210, 142, 190),
        U1(4, 143, 73, 74, 193, 228, 181, 253, 73, 32, 194, 142, 79, 59, 150, 169, 233, 182, 116, 98, 103)
      }), tostring(_ARG_1_), tostring(_ARG_2_))
      if not _ARG_1_ then
        _ARG_0_:ClosePlayer()
      end
      _ARG_0_.lastCalculateTime = 0
      _ARG_0_.showSecondStageReward = _ARG_2_
      _ARG_0_.useNewComp = _ARG_1_
      if _ARG_0_.useNewComp then
      end
      if _ARG_2_ then
        goto lbl_582
        if U1(75, 223, 25).Version == require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 151, 173, 233, 161, 32, 40, 122, 248, 156, 153, 67, 52))).GetCurVersionNumber() then
          if CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID1) then
          end
          if CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID2) then
          end
          _ARG_0_.rewardTextTips = LocUtil.LocalizeResFormat(8800603, CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID1).ItemName, U1(75, 223, 25).ItemCount1, CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID2).ItemName, U1(75, 223, 25).ItemCount2)
          _ARG_0_ = _ARG_0_
          if _ARG_0_.UIRoot[U1(57, 135, 78, 22, 150, 243, 208, 169, 95, 37, 238, 150, 104, 48, 149) .. tostring(U1(75, 223, 25).ItemCount1)] and U1(75, 223, 25)[U1(34, 150, 92, 26, 167, 248, 236, 179, 78) .. tostring(U1(75, 223, 25).ItemCount1)] then
          end
          _ARG_0_ = _ARG_0_
        end
        ::lbl_582::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      goto lbl_678
      goto lbl_676
      if _ARG_0_.UIRoot[CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID2).ItemName] then
        if CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID1).ItemName == 2 then
          _ARG_0_[pairs((CDataTable.GetTable((U1(56, 135, 90, 24, 138, 243, 202, 169, 91, 47, 200, 189, 114, 41, 143, 164, 244, 179, 45, 21, 113, 208, 136, 159, 78)))))] = _ARG_0_.UIRoot[CDataTable.GetTableData(U1(34, 150, 92, 26), U1(75, 223, 25).ItemID2).ItemName]
        end
      end
      ::lbl_676::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_678::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_1_ and not _ARG_0_.speedTimer then
        _ARG_0_.speedTimer = _ARG_0_:AddTimerLoop(0, function()
          _ENV:OnRefreshDownloadSpeed()
          return
        end, TIMER_INFINITE, 0.5)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddTextChangeTimer"] = function(_ARG_0_)
    do
      if Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).IOS then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUI"] = function(_ARG_0_)
    do
      if _ARG_0_.bShowing then
        log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 47, 53, 113, 212, 129, 184, 99))
        _ARG_0_.UIRoot.UpdateTips:SetText(LocUtil.GetLocalizeResStr(210018))
        _ARG_0_.TextBlock_DownloadSpeed:SetWidgetVisibility(U2)
        _ARG_0_.TextBlock_RemainTime:SetWidgetVisibility(U3)
        _ARG_0_.UIRoot.VerticalBox_UpdateInfo:SetWidgetVisibility(U4)
        _ARG_0_.UIRoot.TextBlock_SDDLTips:SetText(LocUtil.GetLocalizeResStr(8800602))
        if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module).NeedSkipAppUpdatingInBlueHole and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):NeedSkipAppUpdatingInBlueHole()) and _ARG_0_:GetUpdater() and _ARG_0_:GetUpdater():IsUpdating() then
          if _ARG_0_.gray == true then
          else
          end
          if slua_GameFrontendHUD then
            slua_GameFrontendHUD.bIsWaitingUpdateStateData = false
          end
        elseif _ARG_0_.IsWaitingFitLangDownload then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCEVersionOrThirdParty"] = function(_ARG_0_)
    do
      if Client.GetDevicePlatformName() ~= require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).IOS then
        if require((table.concat({
          U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 219, 183, 59, 59, 109, 196, 145, 175),
          U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)
        }))).IsBlueholeOperationRegion() and import((U1(56, 155, 74, 3, 129, 250, 201, 184, 72, 37, 196, 138, 110, 55, 142, 166, 211, 183, 37, 55, 113, 213))).GetInstance():AndroidHasDefinePermission((table.concat({
          U1(10, 140, 93, 5, 139, 254, 253, 243, 74, 45, 223, 148, 116, 45, 146, 161, 244, 188, 103, 21, 81, 246, 188, 168, 121, 12, 226, 160, 67, 29, 165, 153, 199, 142, 6, 7, 69, 244, 178, 188),
          U1(44, 167, 106)
        }))) then
        end
      end
      do return require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 219, 183, 59, 59, 109, 196, 145, 175),
        U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)
      }))).IsCEOperationRegion() and not import((U1(41, 151, 74, 30, 138, 242, 234, 174, 114, 45, 193, 137, 120, 44))).IsAppFromStore() or Client.GetAOSSHOP() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 202, 141, 10, 4, 76, 248, 169, 176),
        U1(10, 129, 75, 24, 151)
      }))).ThirdPartyPayment or true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecursivePopup"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 42, 50, 102, 212, 128, 155, 79, 8, 210, 153, 120, 62))
      if Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).IOS then
      elseif Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).Android then
        if Client.GetAOSSHOP() == require((table.concat({
          U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 202, 141, 10, 4, 76, 248, 169, 176),
          U1(10, 129, 75, 24, 151)
        }))).Samsung then
        elseif Client.GetAOSSHOP() == require((table.concat({
          U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 202, 141, 10, 4, 76, 248, 169, 176),
          U1(10, 129, 75, 24, 151)
        }))).Amazon then
        elseif Client.GetAOSSHOP() == require((table.concat({
          U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 202, 141, 10, 4, 76, 248, 169, 176),
          U1(10, 129, 75, 24, 151)
        }))).HMS then
        else
        end
      end
      if FuncUtil.IsSpecialBanClient() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1.AddTimerOnce
    end
  end,
  ["OnDolphinVersionInfo"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.versionInfo = _ARG_1_ or {}
      _ARG_0_.isResourceUpdate = false
      if _ARG_1_ and _ARG_1_.needDownloadSize then
        _ARG_0_.versionInfo.needDownloadSize = tonumber(_ARG_1_.needDownloadSize) / require((U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 113, 49, 134, 161, 248, 252, 45, 40, 99, 201, 133, 130, 75, 60, 147, 153, 120, 40, 151, 189, 249, 157, 58, 56, 106, 196, 141))).MB
        if _ARG_0_.versionInfo.isNeedUpdating == U1(90) then
          if _ARG_0_.versionInfo.isAppUpdating == U1(90) then
          elseif _ARG_0_.versionInfo.isAppUpdating == U1(89) then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnApplicationVersionUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 8, 55, 100, 203, 128, 142, 75, 44, 212, 134, 99, 24, 148, 170, 248, 171, 54, 57, 81, 199, 157, 156),
        U1(31, 135)
      }))
      if _ARG_0_.versionInfo.isGrayUpdate == U1(90) then
        if string.len(_ARG_0_.versionInfo.versionString) > 0 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).sIgnoreAppVersion == _ARG_0_.versionInfo.versionString then
          if _ARG_0_:GetUpdater() then
          end
          return
        end
      end
      if _ARG_0_:IsCEVersionOrThirdParty() and 0 < _ARG_0_.versionInfo.needDownloadSize then
      end
      if _ARG_0_.versionInfo.isForcedUpdating == U1(90) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnResourceVersionUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 27, 34, 103, 200, 156, 159, 73, 61, 235, 140, 127, 61, 152, 183, 229, 151, 41, 51, 101, 195, 156))
      _ARG_0_.isResourceUpdate = true
      if _ARG_0_.versionInfo.isGrayUpdate == U1(90) then
        if string.len(_ARG_0_.versionInfo.versionString) > 0 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).sIgnoreResourceVersion == _ARG_0_.versionInfo.versionString then
          return
        end
      end
      if _ARG_0_.versionInfo.needDownloadSize <= 2 then
      else
        if _ARG_0_.versionInfo.isForcedUpdating == U1(90) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):IsShowUpdatePrompt() ~= true then
        end
        if Client.HasActiveWifi() == true then
          if _ARG_0_.versionInfo.isForcedUpdating == U1(90) then
            if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):IsShowUpdatePrompt() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):IsInLoginForceUpdateProgress() == false then
            else
            end
          else
          end
        elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):IsShowUpdatePrompt() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):IsInLoginForceUpdateProgress() == true then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResourceUpdatePopupWindow"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 58, 40, 97, 213, 138, 136, 127, 40, 217, 136, 121, 43, 161, 183, 251, 183, 41, 0, 109, 217, 157, 146),
        U1(28, 206, 25, 3, 141, 231, 234, 253, 7, 104)
      }) .. tostring(_ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 200, 166, 40, 53, 96, 242, 153, 137, 75, 44, 216))
      if not _ARG_0_.bPatchStartReported then
        _ARG_0_.bPatchStartReported = true
      end
      if Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).IOS and _ARG_0_:GetUpdater() then
      end
      if _ARG_0_:GetUpdater() then
      end
      _ARG_0_.speedTimer = _ARG_0_:AddTimerLoop(0, function()
        _ENV:OnRefreshDownloadSpeed()
        return
      end, TIMER_INFINITE, 0.5)
      return
    end
  end,
  ["UpdateBackgroundByCDNImage"] = function(_ARG_0_)
    do
      if _ARG_0_.CDNImageTimer then
        log(bWriteLog and table.concat({
          U1(48, 136, 86, 25, 133, 255, 238, 184, 83, 21, 251, 156, 111, 45, 136, 167, 245, 135, 57, 35, 117, 211, 140, 184, 99, 98, 232, 153, 105, 47, 133, 189, 201, 163, 58, 60, 99, 197, 150, 136),
          U1(5, 134, 123, 14, 167, 211, 215, 148, 87, 41, 202, 156, 49, 126, 133, 189, 235, 190, 32, 36, 117, 211, 140)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 206, 162, 45, 38, 96, 194, 171, 140, 73, 51, 218, 155, 98, 59, 159, 188, 201, 187, 26, 19, 74, 254, 148, 156),
        U1(12, 135)
      }))
      _ARG_0_.CDNImage = {}
      if import((U1(34, 175, 106, 51, 175, 217, 246, 169, 83, 43, 200))).GetInstance() ~= nil and Client.HasNotice(2, _ARG_0_.CDNNoticeType) == true then
        goto lbl_197
        goto lbl_195
        if string.len((200).PicPath) > 0 then
        else
          ::lbl_195::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_197::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if #_ARG_0_.CDNImage > 0 then
        _ARG_0_.CDNImageIndex = 1
        _ARG_0_.CDNImageTimer = _ARG_0_:AddTimerLoop(0, function()
          if CDNImage[CDNImageIndex] ~= nil then
            if CDNImage[CDNImageIndex].downloaded == true then
            else
            end
          end
          return
        end, TIMER_INFINITE, 5)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveRefreshTimer"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 36, 40, 98, 194, 187, 136, 76, 42, 216, 154, 101, 26, 152, 181, 238, 176))
      if _ARG_0_.speedTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.speedTimer)
        _ARG_0_.speedTimer = nil
      end
      if _ARG_0_.CDNImageTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.CDNImageTimer)
        _ARG_0_.CDNImageTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSizeInfo"] = function(_ARG_0_)
    do
      if _ARG_0_.useNewComp then
        return _ARG_0_.secondDownloadCurSize, _ARG_0_.secondDownloadTotalSize
      elseif _ARG_0_:GetUpdater() then
        return _ARG_0_:GetUpdater():GetCurValue(), _ARG_0_:GetUpdater():GetTotalValue()
      else
        return 0, 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshDownloadSpeed"] = function(_ARG_0_)
    do
      if _ARG_0_.calculateSpeedState ~= 0 then
        if _ARG_0_.calculateSpeedState == 1 then
          _ARG_0_.calculateSpeedState = 2
          _ARG_0_.haveDownloadedSize = _ARG_0_:GetSizeInfo()
          _ARG_0_.lastCalculateTime = require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).GetMiliseconds()
          _ARG_0_.downloadSpeed = 0
          _ARG_0_.realtimeDownloadSpeedZeroCount = 0
          _ARG_0_.calculateAverageSpeedState = 1
          _ARG_0_.averageDownloadSize = _ARG_0_.haveDownloadedSize
          _ARG_0_.lastCalculateAverageTime = _ARG_0_.lastCalculateTime
          _ARG_0_.averageDownloadSpeed = 0
        elseif _ARG_0_:GetUpdater() then
          if 0 > _ARG_0_:GetSizeInfo() - _ARG_0_.haveDownloadedSize then
          end
          if 0 > require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).GetMiliseconds() - _ARG_0_.lastCalculateTime then
          end
          if 0 / 1000 == 0 then
            _ARG_0_.downloadSpeed = 0
          else
            _ARG_0_.downloadSpeed = 0 / (0 / 1000)
          end
          if _ARG_0_.downloadSpeed <= 0.01 then
            _ARG_0_.realtimeDownloadSpeedZeroCount = _ARG_0_.realtimeDownloadSpeedZeroCount + 1
          else
            _ARG_0_.realtimeDownloadSpeedZeroCount = 0
          end
          _ARG_0_.lastCalculateTime, _ARG_0_.haveDownloadedSize = require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).GetMiliseconds(), _ARG_0_:GetSizeInfo()
          if 0 > _ARG_0_:GetSizeInfo() - _ARG_0_.averageDownloadSize then
          end
          if 0 > (require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).GetMiliseconds() - _ARG_0_.lastCalculateAverageTime) / 1000 then
          end
          if 0 == 0 then
            _ARG_0_.averageDownloadSpeed = 0
          elseif _ARG_0_.calculateAverageSpeedState == 1 then
            if 0 > 5 then
              _ARG_0_.calculateAverageSpeedState = 2
              _ARG_0_.lastCalculateAverageTime, _ARG_0_.averageDownloadSize, _ARG_0_.averageDownloadSpeed = require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).GetMiliseconds(), _ARG_0_:GetSizeInfo()
            else
              _ARG_0_.averageDownloadSpeed = 0 / 0
            end
          elseif 0 > 5 then
            _ARG_0_.lastCalculateAverageTime, _ARG_0_.averageDownloadSize, _ARG_0_.averageDownloadSpeed = require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).GetMiliseconds(), _ARG_0_:GetSizeInfo()
          end
          if 2 <= _ARG_0_.realtimeDownloadSpeedZeroCount or _ARG_0_.averageDownloadSpeed <= 0.01 then
          elseif _ARG_0_.useNewComp then
            if _ARG_0_.secondDownloadCurStage == PufferInterface.STAGE_FILE_DOWNLOADING or _ARG_0_.secondDownloadCurStage == nil then
            else
            end
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FormatSpeedAndLeftTime"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 221, 189, 59, 42, 117, 211, 186, 157, 79, 61, 217, 168, 99, 42, 189, 189, 237, 182, 13, 62, 105, 210, 213, 221),
        U1(24, 146, 92, 18, 128, 183, 164, 253)
      }) .. tostring(_ARG_1_) .. U1(71, 194, 85, 18, 130, 227, 237, 180, 87, 45, 141, 196, 61) .. tostring(_ARG_2_))
      if 1024 < _ARG_1_ then
        _ARG_1_ = string.format(U1(78, 204, 11, 17), _ARG_1_ / 1024)
        _ARG_1_ = _ARG_1_ .. U1(75, 175, 123, 88, 151)
      else
        _ARG_1_ = string.format(U1(78, 204, 11, 17), _ARG_1_)
        _ARG_1_ = _ARG_1_ .. U1(75, 169, 123, 88, 151)
      end
      _ARG_0_.TextBlock_DownloadSpeed:SetText(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDolphinProgress"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 13, 40, 120, 215, 129, 132, 68, 8, 207, 134, 106, 60, 148, 171, 248, 238, 121, 52, 113, 197, 170, 137),
        U1(10, 133, 92, 87, 217, 183)
      }) .. tostring(_ARG_1_))
      if _ARG_0_.currentStage == U2.Updating then
      end
      if 69 == _ARG_1_ or 71 == _ARG_1_ then
        _ARG_0_.currentStage = U2.GetingVerInfo
      elseif 74 == _ARG_1_ or 75 == _ARG_1_ or 76 == _ARG_1_ or 77 == _ARG_1_ or 79 == _ARG_1_ then
        _ARG_0_.currentStage = U2.CheckingValidity
      elseif 31 == _ARG_1_ then
        _ARG_0_.currentStage = U2.CheckingPatch
      elseif 70 == _ARG_1_ then
        _ARG_0_.currentStage = U2.StartUpdateApk
      elseif 78 == _ARG_1_ then
        _ARG_0_.currentStage = U2.ApkUpdateMergeDiff
      elseif 91 == _ARG_1_ then
        _ARG_0_.currentStage = U2.SourceUpdateDownloadList
      elseif 92 == _ARG_1_ then
        _ARG_0_.currentStage = U2.SourcePrepareUpdate
      elseif 93 == _ARG_1_ then
        _ARG_0_.currentStage = U2.SourceAnalyseDiff
      elseif 95 == _ARG_1_ then
        _ARG_0_.currentStage = U2.Extraing
      elseif 96 == _ARG_1_ then
        _ARG_0_.currentStage = U2.MergeBGDownloadResources
      elseif 99 == _ARG_1_ then
        _ARG_0_.currentStage = U2.Success
      else
        _ARG_0_.currentStage = U2.Downloading
      end
      if _ARG_0_.currentStage ~= _ARG_0_.currentStage then
        if _ARG_0_.currentStage == U2.CheckingValidity then
        elseif _ARG_0_.currentStage == U2.CheckingValidity then
        end
        if _ARG_0_.currentStage == U2.ApkUpdateMergeDiff then
        elseif _ARG_0_.currentStage == U2.ApkUpdateMergeDiff then
        end
        if _ARG_0_.currentStage == U2.Success and not _ARG_0_.bPatchCompletedReported then
          _ARG_0_.bPatchCompletedReported = true
        end
        if _ARG_0_.currentStage == U2.Downloading then
        elseif _ARG_0_.currentStage == U2.Downloading then
        end
      end
      if 94 == _ARG_1_ then
      end
      if _ARG_0_.currentStage == U2.GetingVerInfo then
        if not _ARG_0_.checkUpdateTimer then
          if import((U1(56, 182, 124, 15, 144, 229, 248, 154, 91, 37, 200, 176, 115, 45, 149, 169, 245, 177, 44))).GetInstance():GetDeviceLevel() <= 0 then
          end
          if 0 >= HDmpveRemote.HDmpveRemoteConfigGetInt(U1(47, 141, 85, 7, 140, 254, 247, 154, 95, 60, 251, 156, 111, 23, 143, 174, 244, 133, 40, 46, 96, 243, 128, 128, 79, 20, 210, 158), 35) then
          end
          if _G.IsEditor then
          end
          _ARG_0_.checkUpdateWaitTotalTime, _ARG_0_.checkUpdateWaitTime = 1, 0
          _ARG_0_.checkUpdateTimer = _ARG_0_:AddTimerLoop(0, function()
            if checkUpdateWaitTime < U1 then
              if checkUpdateWaitTime >= 5 then
                _ENV:SetWidgetVisible(TextBlock_RemainTime, not showSecondStageReward)
              else
                TextBlock_RemainTime:SetText((U3()))
              end
              checkUpdateWaitTime = checkUpdateWaitTime + 1
            else
              U2.log(U2.bWriteLog and U2.table.concat({
                U3(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 13, 40, 120, 215, 129, 132, 68, 8, 207, 134, 106, 60, 148, 171, 248, 226, 26, 63, 97, 212, 146, 168),
                U3(27, 134, 88, 3, 129, 183, 205, 180, 87, 45, 141, 188, 115, 58, 205, 232, 221, 187, 39, 46, 103, 207, 188, 157, 78, 57, 201, 140)
              }))
              TextBlock_RemainTime:SetText((U3()))
              UIRoot.ProgressBar_Update:SetPercent(1)
              if U2.Client.HasDownloadedBasePak() then
                U2.PufferDownloader.UpdateGrayStep = U2.PufferDownloader.UpdateGrayStep + 100
                if _ENV:GetUpdater() then
                end
              end
            end
            return
          end, TIMER_INFINITE, 1)
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveCheckUpdateTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.checkUpdateTimer then
        _ARG_0_.TextBlock_RemainTime:SetText((_ENV()))
        _ARG_0_:RemoveTimer(_ARG_0_.checkUpdateTimer)
        _ARG_0_.checkUpdateTimer = nil
        _ARG_0_.checkUpdateWaitTotalTime = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowUIWhenGrayDownloading"] = function(_ARG_0_)
    do
      if _ARG_0_.gray and _ARG_0_.currentStage ~= GetingVerInfo and _ARG_0_.currentStage ~= CheckingValidity and _ARG_0_.currentStage ~= StartUpdateApk and _ARG_0_.currentStage ~= SourcePrepareUpdate and _ARG_0_.currentStage ~= Success then
        U1.EventSystem:postEvent(U1.EVENTTYPE_LOGIN, U1.EVENTID_UPDATE_BACKGROUND_IMAGE, true)
        _ARG_0_.UIRoot.GridPanel_UpdateUI:SetWidgetVisibility(U2)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTextByStage"] = function(_ARG_0_)
    do
      if _ARG_0_.preStage ~= _ARG_0_.currentStage then
        _ARG_0_.preStage = _ARG_0_.currentStage
        _ARG_0_:ShowUIWhenGrayDownloading()
        if _ARG_0_.currentStage == GetingVerInfo then
        elseif _ARG_0_.currentStage == CheckingValidity then
        elseif _ARG_0_.currentStage == CheckingPatch then
        elseif _ARG_0_.currentStage == StartUpdateApk then
        elseif _ARG_0_.currentStage == ApkUpdateMergeDiff then
        elseif _ARG_0_.currentStage == SourceUpdateDownloadList then
        elseif _ARG_0_.currentStage == SourcePrepareUpdate then
        elseif _ARG_0_.currentStage == SourceAnalyseDiff then
        elseif _ARG_0_.currentStage == Downloading then
        elseif _ARG_0_.currentStage == Extraing then
        elseif _ARG_0_.currentStage == MergeBGDownloadResources then
        elseif _ARG_0_.currentStage == Success then
        elseif _ARG_0_.currentStage == ShaderDecompressing then
        elseif _ARG_0_.currentStage == TouchTransMissionStart then
        elseif _ARG_0_.currentStage == TouchTransMissionEnd then
        elseif _ARG_0_.currentStage == TouchTransMissionProgress then
        else
        end
        if _ARG_0_.useNewComp then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSystemNotifyEntry"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_SystemNotify, _ARG_1_, true)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_1, _ARG_1_)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_SysNotify, _ARG_1_)
      _ARG_0_.UIRoot.TextBlock_1:SetText(LocUtil.GetLocalizeResStr(13157))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBulletinEntry"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_Bulletin, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanShowVersionUpdateNotice"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NoticesModule):CanShowNotice(require((U1(8, 142, 80, 18, 138, 227, 183, 177, 85, 47, 196, 154, 51, 16, 142, 188, 242, 177, 44, 105, 90, 200, 157, 132, 73, 61, 206, 170, 98, 32, 130, 172))).Scene.VersionUpdate) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBulletinEntry"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateDownloadProgress"] = function(_ARG_0_)
    do
      if _ARG_0_:GetUpdater() then
        if _ARG_0_.currentStage == GetingVerInfo and _ARG_0_.checkUpdateTimer and _ARG_0_.checkUpdateWaitTotalTime and _ARG_0_.checkUpdateWaitTotalTime > 0 and _ARG_0_:GetUpdater():GetCurPercent() < _ARG_0_.checkUpdateWaitTime / _ARG_0_.checkUpdateWaitTotalTime then
        end
        if _ARG_0_.currentStage == Downloading or _ARG_0_.currentStage == ApkUpdateMergeDiff or _ARG_0_.currentStage == MergeBGDownloadResources then
          if 0 < _ARG_0_:GetUpdater():GetTotalValue() / 1024 then
            if _ARG_0_.currentStage == Downloading then
            else
            end
          else
          end
        elseif _ARG_0_.currentStage == GetingVerInfo then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartCalculateDownloadSpeed"] = function(_ARG_0_)
    do
      if _ARG_0_.currentStage == Downloading then
        if _ARG_0_.calculateSpeedState == 0 then
          _ARG_0_.calculateSpeedState = 1
        end
      else
        _ARG_0_.calculateSpeedState = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDolphinError"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 13, 40, 120, 215, 129, 132, 68, 29, 207, 155, 98, 60, 221, 248, 238, 176, 43, 56, 118, 244, 150, 153),
        U1(14, 194, 4, 87)
      }) .. tostring(_ARG_1_))
      if tonumber(_ARG_1_) == 221249538 then
        return
      end
      if _ARG_1_ == _ARG_0_.ErrCodeTimeOut then
        if _ARG_0_:GetUpdater() then
        end
        return
      end
      if Client.HasDownloadedBasePak() and tonumber(_ARG_1_) ~= 154140709 then
        _ARG_0_.retriedUpdateTimes = _ARG_0_.retriedUpdateTimes + 1
      end
      if tonumber(_ARG_1_) == 689045511 or tonumber(_ARG_1_) == 689045510 or tonumber(_ARG_1_) == 353501190 or tonumber(_ARG_1_) == 353435649 or tonumber(_ARG_1_) == 353501191 or tonumber(_ARG_1_) == 353502185 or tonumber(_ARG_1_) == 353501240 or tonumber(_ARG_1_) == 353501600 or tonumber(_ARG_1_) == 353501588 or tonumber(_ARG_1_) == 353501587 or tonumber(_ARG_1_) == 353501236 or tonumber(_ARG_1_) == 353501207 or tonumber(_ARG_1_) == 353502189 or tonumber(_ARG_1_) == 353501202 or tonumber(_ARG_1_) == 353502085 or tonumber(_ARG_1_) == 353501684 or tonumber(_ARG_1_) == 353501584 or tonumber(_ARG_1_) == 353501687 or tonumber(_ARG_1_) == 353501598 or tonumber(_ARG_1_) == 353501212 or tonumber(_ARG_1_) == 353501686 or tonumber(_ARG_1_) == 353501585 or tonumber(_ARG_1_) == 353501219 or tonumber(_ARG_1_) == 689045908 or tonumber(_ARG_1_) == 689045556 or tonumber(_ARG_1_) == 554827782 or tonumber(_ARG_1_) == 554827832 or tonumber(_ARG_1_) == 554827828 or tonumber(_ARG_1_) == 554828180 or tonumber(_ARG_1_) == 554762241 or tonumber(_ARG_1_) == 554828781 or tonumber(_ARG_1_) == 554827783 or tonumber(_ARG_1_) == 154140673 or tonumber(_ARG_1_) == 154140674 or tonumber(_ARG_1_) == 154140675 or tonumber(_ARG_1_) == 353501185 or tonumber(_ARG_1_) == 154140713 or tonumber(_ARG_1_) == 154140714 or tonumber(_ARG_1_) == 154140715 or tonumber(_ARG_1_) == 154140716 or tonumber(_ARG_1_) == 154140711 or tonumber(_ARG_1_) == 154140712 or tonumber(_ARG_1_) == 154140719 or tonumber(_ARG_1_) == 154140720 or tonumber(_ARG_1_) == 554827804 or tonumber(_ARG_1_) == 689045532 or tonumber(_ARG_1_) == 420610452 or tonumber(_ARG_1_) == 154140706 or tonumber(_ARG_1_) == 87031824 or tonumber(_ARG_1_) >= 154140677 and tonumber(_ARG_1_) <= 154140697 then
        if tonumber(_ARG_1_) == 154140712 or tonumber(_ARG_1_) == 154140713 or tonumber(_ARG_1_) == 154140714 or tonumber(_ARG_1_) == 154140715 or tonumber(_ARG_1_) == 154140716 or tonumber(_ARG_1_) == 154140719 or tonumber(_ARG_1_) == 554827804 or tonumber(_ARG_1_) == 689045532 or tonumber(_ARG_1_) == 554762241 then
          if _ARG_0_.haveRetried71X or Client.HasDownloadedBasePak() and (tonumber(_ARG_1_) == 154140713 or tonumber(_ARG_1_) == 154140716 or tonumber(_ARG_1_) == 154140712 or tonumber(_ARG_1_) == 554827804 or tonumber(_ARG_1_) == 689045532 or tonumber(_ARG_1_) == 554762241) then
            if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).nReportedSkippedError then
              if Client.IsNetworkReachable() == true then
              end
            end
            if Client.HasDownloadedBasePak() then
              if Client.HasDownloadedBasePak() and (tonumber(_ARG_1_) == 154140713 or tonumber(_ARG_1_) == 154140716 or tonumber(_ARG_1_) == 154140712 or tonumber(_ARG_1_) == 554827804 or tonumber(_ARG_1_) == 689045532 or tonumber(_ARG_1_) == 554762241) and _ARG_0_.haveRetried71X ~= true then
                return
              end
            else
            end
          else
            _ARG_0_.haveRetried71X = true
          end
        elseif _ARG_0_.retriedUpdateTimes > _ARG_0_.maxRetryUpdateTimes then
        else
        end
      elseif _ARG_0_.retriedUpdateTimes > _ARG_0_.maxRetryUpdateTimes then
      elseif tonumber(_ARG_1_) == 355471270 or tonumber(_ARG_1_) == 355467269 or tonumber(_ARG_1_) == 355469265 or tonumber(_ARG_1_) == 691011599 or tonumber(_ARG_1_) == 556793868 or tonumber(_ARG_1_) == 556793861 or tonumber(_ARG_1_) == 691011598 then
      elseif tonumber(_ARG_1_) == 353697820 or tonumber(_ARG_1_) == 555745297 or tonumber(_ARG_1_) == 689963036 or tonumber(_ARG_1_) == 689242140 then
      elseif tonumber(_ARG_1_) == 688914441 or tonumber(_ARG_1_) == 556793859 or tonumber(_ARG_1_) == 288358404 or tonumber(_ARG_1_) == 87031823 or tonumber(_ARG_1_) == 691011591 or tonumber(_ARG_1_) == 691011585 or tonumber(_ARG_1_) >= 422576129 and tonumber(_ARG_1_) <= 422576148 or tonumber(_ARG_1_) >= 420478976 and tonumber(_ARG_1_) <= 421527551 or tonumber(_ARG_1_) >= 489684993 and tonumber(_ARG_1_) <= 489685003 or tonumber(_ARG_1_) >= 487587840 and tonumber(_ARG_1_) <= 488636415 or tonumber(_ARG_1_) >= 87031809 and tonumber(_ARG_1_) <= 87031821 then
      elseif tonumber(_ARG_1_) == 154140709 or tonumber(_ARG_1_) == 154140688 then
      elseif tonumber(_ARG_1_) == 353697796 or tonumber(_ARG_1_) == 353697914 or tonumber(_ARG_1_) == 353697822 or tonumber(_ARG_1_) == 353697794 or tonumber(_ARG_1_) == 353697797 or tonumber(_ARG_1_) == 353697805 or tonumber(_ARG_1_) == 556793857 or tonumber(_ARG_1_) == 555745310 or tonumber(_ARG_1_) == 556793874 or tonumber(_ARG_1_) == 289407004 or tonumber(_ARG_1_) == 289406980 or tonumber(_ARG_1_) == 289406993 or tonumber(_ARG_1_) == 289407098 or tonumber(_ARG_1_) == 289407085 or tonumber(_ARG_1_) == 288358406 or tonumber(_ARG_1_) == 289407006 or tonumber(_ARG_1_) == 289407071 or tonumber(_ARG_1_) == 691011585 then
      elseif tonumber(_ARG_1_) == 555745308 or tonumber(_ARG_1_) == 555024412 then
      elseif tonumber(_ARG_1_) == 554828179 then
      elseif tonumber(_ARG_1_) == 555024405 or tonumber(_ARG_1_) == 554828779 then
        if tonumber(_ARG_1_) == 555024405 then
        elseif tonumber(_ARG_1_) == 554828779 then
        end
        if Client.ProjectSavedDir() .. U1(59, 131, 82, 4, 203, 249, 252, 170, 20, 46, 196, 149, 120, 50, 136, 187, 239) ~= U1() and 0 < #(Client.ProjectSavedDir() .. U1(59, 131, 82, 4, 203, 249, 252, 170, 20, 46, 196, 149, 120, 50, 136, 187, 239)) then
        end
        if _ARG_0_.retriedUpdateAfterDeleteFileTimes < _ARG_0_.maxRetryUpdateAfterDeleteFileTimes then
          _ARG_0_.retriedUpdateAfterDeleteFileTimes = _ARG_0_.retriedUpdateAfterDeleteFileTimes + 1
        else
        end
      else
      end
      if false then
        if _ARG_0_:GetUpdater() then
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportIgnoredUpdateError"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 57, 40, 102, 211, 160, 138, 68, 55, 207, 140, 105, 27, 129, 188, 234, 182, 60, 18, 118, 197, 150, 143),
        U1(71, 194, 92, 5, 150, 248, 235, 158, 85, 44, 200, 217, 32, 126)
      }) .. tostring(_ARG_1_))
      if _ARG_1_ ~= nil then
      end
      if _ARG_0_.reportedErrorList ~= nil then
        goto lbl_102
        if U1(71, 194, 92, 5, 150, 248, 235, 158, 85, 44, 200, 217, 32, 126) == tostring(_ARG_1_) then
        else
          ::lbl_102::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if true then
      elseif _ARG_0_.reportedErrorList ~= nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRetryDownloadPanel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.tempTips = _ARG_1_
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.login_module).bEnableCDNGetVersion == true then
      else
      end
      do return end
      _ARG_0_ = _ENV[24]
    end
  end,
  ["ConfirmClickCancelBtn"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 216, 189, 39, 33, 125, 213, 132, 174, 70, 49, 222, 130, 78, 47, 159, 187, 238, 174, 27, 35, 106))
      if _ARG_0_.cancelUpdateTimes >= 5 then
        EventAndroidQuitGame()
      elseif _ARG_0_.cancelUpdateTimes >= 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowCancelPanel"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 200, 186, 38, 48, 87, 198, 135, 142, 79, 52, 237, 136, 99, 43, 157, 244, 171, 182, 48, 39, 119, 151, 196, 221) .. tostring(_ARG_1_))
      if _ARG_0_.versionInfo.isForcedUpdating == U1(90) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowCountDownRetryPanel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 200, 186, 38, 48, 87, 200, 156, 131, 94, 28, 210, 158, 99, 28, 148, 172, 249, 187, 9, 54, 106, 210, 149, 209),
        U1(75, 150, 80, 7, 151, 183, 164, 253)
      }) .. tostring(_ARG_1_) .. U1(71, 194, 90, 24, 145, 249, 237, 185, 85, 63, 195, 173, 116, 51, 132, 232, 166, 242) .. tostring(_ARG_2_) .. U1(71, 194, 80, 25, 144, 242, 235, 171, 91, 36, 141, 196, 61) .. tostring(_ARG_3_))
      if _ARG_3_ == nil then
        _ARG_3_ = 1
      end
      _ARG_0_.tempTips = _ARG_1_
      _ARG_0_.CountDownRetryRefreshedTime = require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 149, 161, 246, 183, 22, 50, 96, 206, 133))).OSTime()
      _ARG_0_.CountDownRetryRefreshPassedTime = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDolphinNoticeInstallApk"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.GridPanel_NoWifiUpdated:SetWidgetVisibility(_ENV)
      _ARG_0_.UIRoot.GridPanel_WifiUpdated:SetWidgetVisibility(_ENV)
      U1.log_format(U1.table.concat({
        U2(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 13, 40, 120, 215, 129, 132, 68, 22, 210, 157, 100, 45, 148, 145, 229, 177, 45, 54, 104, 219, 184, 141),
        U2(0, 206, 25, 20, 145, 229, 235, 184, 84, 60, 254, 141, 124, 57, 132, 232, 166, 242, 108, 52)
      }), _ARG_0_.currentStage)
      if _ARG_0_.currentStage == U3.ApkUpdateMergeDiff then
      end
      if _ARG_1_ then
      else
      end
      do return end
      _ARG_1_ = _ENV[227]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RunLogicOnUpdateFinished"] = function(_ARG_0_)
    do
      if Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).IOS and 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(34, 173, 106, 52, 140, 242, 250, 182, 105, 49, 192, 155, 114, 50, 178, 167, 238, 160, 42, 34), 1) and Client.CheckMemorySymbolSource and Client.CheckMemorySymbolSource() == 1 then
        if io.open(Client.GetPureIOSDocumentsDirectory() .. U1(68, 173, 106, 58, 133, 251, 245, 178, 89, 2, 216, 157, 122, 59, 207, 174, 247, 179, 46), (U1(28))) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateFinished"] = function(_ARG_0_)
    do
      _ARG_0_:ShowSystemNotifyEntry(false)
      _ARG_0_:ShowBulletinEntry(false)
      if require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 219, 183, 59, 59, 109, 196, 145, 175),
        U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)
      }))).IsFITVersion() then
        if string.find(tostring(Client.GetCurrentRHILevel(GameFrontendHUD)), (U1(46, 177, 11))) then
        else
        end
        goto lbl_211
        if require((U1(8, 141, 84, 26, 139, 249, 183, 174, 78, 58, 196, 151, 122, 1, 148, 188, 242, 190))).StrFind(26, require((U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 113, 49, 134, 161, 248, 252, 45, 40, 99, 201, 133, 130, 75, 60, 147, 153, 120, 40, 151, 189, 249, 157, 58, 56, 106, 196, 141))).FIT_ES3SHADER) then
        end
        ::lbl_211::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if not true then
          slua_GameFrontendHUD:GetGameInstance():GetRenderQualityLastSet().RenderQualitySetting = 1
        end
      end
      if _ARG_0_.gray == false then
        if not HDmpveRemote.HDmpveRemoteConfigGetBool(U1(62, 145, 92, 57, 129, 224, 213, 178, 93, 33, 195, 181, 114, 57, 136, 171, 175, 227, 121), true) then
          if HDmpveRemote.HDmpveRemoteConfigGetInt(U1(62, 177, 127, 36, 173, 249, 240, 169, 106, 58, 194, 154, 120, 45, 146, 135, 245, 177, 44, 6, 115, 198, 128, 131), 0) == 1 then
          end
        end
      else
        if 1 <= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):GetGEnableShaderGroupAsync() and Client.GetDevicePlatformName() == require((table.concat({
          U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
          U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
        }))).IOS then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):GetGEnableShaderGroupAsync() == 2 then
          else
          end
        else
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if not HDmpveRemote.HDmpveRemoteConfigGetBool(U1(62, 145, 92, 57, 129, 224, 213, 178, 93, 33, 195, 181, 114, 57, 136, 171, 175, 227, 121), true) then
          if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(46, 140, 88, 21, 136, 242, 207, 180, 72, 60, 216, 152, 113, 19, 132, 186, 252, 183), false) then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AfterFinishedUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 218, 180, 61, 34, 102, 225, 128, 131, 67, 43, 213, 140, 105, 27, 129, 188, 234, 182, 60))
      Client.AddCrashContextData(4, Client.GetAppVersion(), false, 100)
      Client.AddCrashContextData(5, _ARG_0_.gray and U1(90) or U1(91), false, 100)
      Client.CrashLog(NetInterface, 4, U1(39, 141, 94, 30, 138), (U1(62, 146, 93, 22, 144, 242, 223, 180, 84, 33, 222, 145)))
      Client.ReportEventLoadingCompleted()
      if _ARG_0_.showSecondStageReward and Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).Android then
      end
      return
    end
  end,
  ["GoToNextStepLogin"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 220, 189, 29, 40, 90, 194, 145, 153, 121, 44, 216, 153, 65, 33, 150, 177, 229))
      if Client.GetDevicePlatformName() == require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 126, 49, 143, 174, 242, 181, 103, 4, 120, 206, 140, 131, 94, 21, 220, 138, 127, 33, 130, 246, 207, 167, 47, 62, 103, 210, 169, 145),
        U1(10, 150, 95, 24, 150, 250, 215, 188, 87, 45, 224, 152, 126, 44, 142, 187)
      }))).IOS and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.version_up_module):GetGEnableShaderGroupAsync() == 1 then
        if 1 > Client.EnableShaderFinishPersent() then
          return
        end
      end
      if _ARG_0_.gray then
        if _ARG_0_.callbackAfterGrayUpdate then
          _ARG_0_.callbackAfterGrayUpdate = nil
        end
        _ARG_0_.gray = false
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateShaderDecompressing"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 206, 162, 45, 38, 96, 194, 186, 133, 75, 60, 216, 155, 73, 43, 146, 183, 230, 178, 43, 50, 119, 196, 144, 147),
        U1(12)
      }))
      _ARG_0_.currentStage = U2.ShaderDecompressing
      _ARG_0_:UpdateTextByStage()
      _ARG_0_:RemoveCheckUpdateTimer()
      _ARG_0_.shaderDecompressingTimer = _ARG_0_:AddTimerLoop(0, function()
        U1 = U1 + 0.02
        if 1 <= U1 then
          U1 = 0.99
        end
        if Client.EnableShaderFinishPersent() >= 1 then
          U3.shaderDecompressingTimer = nil
          return
        end
        return
      end, TIMER_INFINITE, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRichTextLoadingTip"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 200, 186, 38, 48, 70, 206, 138, 133, 126, 61, 197, 157, 65, 33, 144, 188, 226, 172, 62, 3, 109, 199, 217) .. tostring(_ARG_1_))
      if _ARG_0_.UIRoot.UpdateTips:GetVisibility() ~= U2 then
        _ARG_0_.UIRoot.RichText_LoadingTip:SetWidgetVisibility(U2)
        return
      end
      if _ARG_0_.TextBlock_DownloadSpeed:GetVisibility() == U3 then
        _ARG_0_.UIRoot.RichText_LoadingTip:SetWidgetVisibility(U2)
        return
      end
      if _ARG_1_ then
        _ARG_0_.UIRoot.RichText_LoadingTip:SetWidgetVisibility(U3)
      else
        _ARG_0_.UIRoot.RichText_LoadingTip:SetWidgetVisibility(U2)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStageText"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.TextBlock_State:SetText(_ARG_1_)
      if _ARG_1_ ~= LocUtil.GetLocalizeResStr(201018) then
        _ARG_0_:RemoveCheckUpdateTimer()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateDownloadSpeedSizeInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      printf(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 206, 162, 45, 38, 96, 194, 173, 130, 93, 54, 209, 134, 108, 42, 162, 168, 238, 167, 61, 4, 109, 205, 156, 180),
        U1(5, 132, 86, 89, 196, 249, 246, 170, 105, 33, 215, 156, 32, 123, 146, 228, 187, 166, 38, 51, 117, 203, 186, 132, 80, 61, 128, 204, 126, 98, 209, 187, 254, 176, 10, 35, 101, 208, 156, 192),
        U1(78, 145)
      }), tostring(_ARG_1_), tostring(_ARG_2_), tostring(_ARG_3_))
      if not (_ARG_0_.useNewComp and _ARG_1_) or not _ARG_2_ then
        return
      end
      _ARG_0_.secondDownloadCurStage = _ARG_3_
      _ARG_0_.secondDownloadCurSize = _ARG_1_
      _ARG_0_.secondDownloadTotalSize = _ARG_2_
      if _ARG_0_.calculateSpeedState == 0 then
        _ARG_0_.calculateSpeedState = 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[51]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateProgressBar"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.UIRoot.HorizontalBox_VersionSizeInfo:SetWidgetVisibility(_ENV)
      _ARG_0_.UIRoot.ProgressBar_Update:SetPercent(_ARG_1_ / 100)
      if _ARG_2_ then
        U1.log_warning(U1.bWriteLog and U2(75, 194, 23, 87, 177, 231, 253, 188, 78, 45, 253, 139, 114, 57, 147, 173, 232, 161, 11, 38, 102, 135, 201, 132, 89, 8, 207, 140, 110, 33, 156, 168, 226, 174, 60))
        _ARG_0_:RemoveCheckUpdateTimer()
      end
      if 0 < _ARG_1_ then
        if _ARG_2_ then
          _ARG_0_.UIRoot.CanvasPanel_CarRoot:SetWidgetVisibility(U3)
        else
          _ARG_0_.UIRoot.CanvasPanel_CarRoot:SetWidgetVisibility(U4)
        end
        if _ARG_0_.gray then
          U1.EventSystem:postEvent(U1.EVENTTYPE_LOGIN, U1.EVENTID_UPDATE_BACKGROUND_IMAGE, true)
          _ARG_0_.UIRoot.GridPanel_UpdateUI:SetWidgetVisibility(U3)
        end
        if _ARG_0_.UIRoot.GridPanel_UpdateUI:IsVisible() then
          U1.logic_connection_waiting:Hide(0)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 216, 179, 39, 36, 113, 203, 188, 157, 78, 57, 201, 140))
      if _ARG_0_.versionInfo.isAppUpdating == U1(89) then
        Client.DisableRepairResource(GameFrontendHUD)
        if _ARG_0_.versionInfo.isGrayUpdate ~= U1(90) then
        end
      end
      logic_connection_waiting:Hide(0)
      Client.CrashLog(NetInterface, 4, U1(39, 141, 94, 30, 138), (U1(62, 146, 93, 22, 144, 242, 223, 180, 84, 33, 222, 145)))
      if _ARG_0_:GetUpdater() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUpdater"] = function(_ARG_0_)
    do
      if slua_GameFrontendHUD:GetUpdater() == nil then
      end
      do return (slua_GameFrontendHUD:GetUpdater()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 10, 43, 123, 212, 140))
      _ARG_0_:ClosePlayer()
      logic_connection_waiting:Hide(0)
      _ARG_0_:TryHideNotices()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 1, 46, 112, 194))
      _ARG_0_.bShowing = false
      U2.__super.OnHide(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPufferInitialize"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateBackgroundByCDNImage()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayCurVersionVideo"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      goto lbl_306
      if require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 113, 49, 134, 161, 248, 252, 63, 46, 112, 194, 134, 195, 70, 55, 223, 139, 116, 17, 135, 177, 239, 167, 54, 8, 98, 194, 151, 158),
        U1(31, 139, 86, 25, 187, 251, 240, 191, 72, 41, 223, 128)
      }))).IsVideoFileReady(U1(69, 205, 116, 24, 146, 254, 252, 174, 106, 41, 198, 189, 116, 44, 206, 158, 254, 160, 58, 46, 123, 201, 188, 157, 78, 57, 201, 140, 82) .. tostring(require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 151, 173, 233, 161, 32, 40, 122, 248, 156, 153, 67, 52))).GetCurVersionNumber() - 171 * 100) .. tostring(U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)) .. U1(69, 143, 73, 67)) then
      else
        ::lbl_306::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U1(69, 205, 116, 24, 146, 254, 252, 174, 106, 41, 198, 189, 116, 44, 206, 158, 254, 160, 58, 46, 123, 201, 188, 157, 78, 57, 201, 140, 82) .. tostring(require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 151, 173, 233, 161, 32, 40, 122, 248, 156, 153, 67, 52))).GetCurVersionNumber() - 171 * 100) .. tostring(U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)) .. U1(69, 143, 73, 67) == U1() then
        _ARG_0_ = _ARG_0_
      end
      if U1(69, 205, 116, 24, 146, 254, 252, 174, 106, 41, 198, 189, 116, 44, 206, 158, 254, 160, 58, 46, 123, 201, 188, 157, 78, 57, 201, 140, 82) .. tostring(require((U1(8, 142, 80, 18, 138, 227, 183, 190, 85, 37, 192, 150, 115, 112, 151, 173, 233, 161, 32, 40, 122, 248, 156, 153, 67, 52))).GetCurVersionNumber() - 171 * 100) .. tostring(U1(14, 133, 80, 24, 138, 218, 248, 190, 72, 39, 222)) .. U1(69, 143, 73, 67) == U1() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleDownloadBase"] = function(_ARG_0_)
    do
      if import((U1(56, 182, 124, 15, 144, 229, 248, 154, 91, 37, 200, 176, 115, 45, 149, 169, 245, 177, 44))).GetInstance():GetDeviceLevel() <= 1 then
      end
      if true then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayVideo"] = function(_ARG_0_, _ARG_1_)
    do
      printf(U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 203, 190, 40, 62, 66, 206, 141, 136, 69, 118, 157, 159, 100, 42, 148, 183, 219, 163, 45, 63, 57, 146, 138), tostring(_ARG_1_))
      if require((table.concat({
        U1(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 113, 49, 134, 161, 248, 252, 63, 46, 112, 194, 134, 195, 70, 55, 223, 139, 116, 17, 135, 177, 239, 167, 54, 8, 98, 194, 151, 158),
        U1(31, 139, 86, 25, 187, 251, 240, 191, 72, 41, 223, 128)
      }))).IsVideoFileReady(_ARG_1_) then
        if _ARG_0_:GetNormalLocalVideo() and _ARG_0_:GetNormalLocalVideo().SetLooping then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMediaOpened"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 4, 34, 112, 206, 136, 162, 90, 61, 211, 140, 105, 96, 209, 190, 226, 174, 60, 7, 101, 195, 145, 192),
        U1(78, 145)
      }), _ARG_1_)
      _ARG_0_.mediaPlayerOpenSuccess = true
      _ARG_0_:SetVideoSound(_ARG_0_.canPlaySound)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMediaPlayerOpenFail"] = function(_ARG_0_)
    do
      log_format((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 4, 34, 112, 206, 136, 189, 70, 57, 196, 140, 127, 1, 129, 189, 229, 132, 56, 62, 104, 153)))
      _ARG_0_:ClosePlayer()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMediaOpenFailed"] = function(_ARG_0_)
    do
      log_format((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 4, 34, 112, 206, 136, 162, 90, 61, 211, 175, 108, 39, 157, 189, 239, 236)))
      _ARG_0_:ClosePlayer()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSetMediaContentResolution"] = function(_ARG_0_)
    do
      log_format((table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 26, 34, 96, 234, 140, 137, 67, 57, 254, 134, 99, 58, 148, 182, 255, 144, 60, 36, 107, 219, 140, 137),
        U1(2, 141, 87, 89)
      })))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Details, true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_2"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log_format((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 10, 43, 125, 196, 130, 175, 95, 44, 201, 134, 99, 17, 195, 246)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Bulletin"] = function(_ARG_0_)
    do
      printf((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 212, 188, 10, 43, 125, 196, 130, 175, 95, 44, 201, 134, 99, 17, 179, 173, 231, 174, 60, 35, 109, 217, 215)))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:TryShowNotices()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryShowNotices"] = function(_ARG_0_)
    do
      printf((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 207, 160, 48, 20, 124, 200, 158, 163, 69, 44, 212, 138, 104, 61)))
      if _ARG_0_:CanShowVersionUpdateNotice() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryHideNotices"] = function(_ARG_0_)
    do
      printf((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 207, 160, 48, 15, 125, 195, 140, 163, 69, 44, 212, 138, 104, 61)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PausePlay"] = function(_ARG_0_)
    do
      printf((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 203, 179, 60, 52, 113, 247, 133, 140, 83, 118)))
      _ARG_0_:NormalLocalVideoPause()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResumePlay"] = function(_ARG_0_)
    do
      printf((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 201, 183, 58, 50, 121, 194, 185, 129, 75, 33, 147)))
      _ARG_0_:NormalLocalVideoResume()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClosePlayer"] = function(_ARG_0_)
    do
      printf((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 216, 190, 38, 52, 113, 247, 133, 140, 83, 61, 207, 199)))
      _ARG_0_.mediaPlayerOpenSuccess = false
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Details, false)
      _ARG_0_:ReleaseResource(_ARG_0_.UIRoot.MediaContainer)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TouchTransMissionStart"] = function(_ARG_0_)
    do
      log_format((U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 207, 189, 60, 36, 124, 243, 155, 140, 68, 43, 240, 128, 126, 61, 152, 183, 229, 145, 45, 54, 118, 195)))
      _ARG_0_.currentStage = U2.TouchTransMissionStart
      _ARG_0_.TextBlock_SizeInfo:SetText((U1()))
      _ARG_0_:UpdateTextByStage()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TouchTransMissionProgress"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_format(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 207, 189, 60, 36, 124, 243, 155, 140, 68, 43, 240, 128, 126, 61, 152, 183, 229, 146, 43, 56, 99, 197, 156, 142),
        U1(24, 204, 25, 20, 139, 231, 240, 184, 94, 10, 212, 141, 120, 45, 220, 237, 232, 254, 105, 51, 123, 211, 136, 129, 104, 33, 201, 140, 126, 115, 212, 171)
      }), _ARG_1_, _ARG_2_)
      _ARG_0_.currentStage = U2.TouchTransMissionProgress
      _ARG_0_:UpdateTextByStage()
      if 0 < _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TouchTransMissionEnd"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(table.concat({
        U1(61, 135, 75, 4, 141, 248, 247, 136, 74, 44, 204, 141, 120, 11, 168, 242, 207, 189, 60, 36, 124, 243, 155, 140, 68, 43, 240, 128, 126, 61, 152, 183, 229, 135, 55, 51, 42, 151, 138, 136),
        U1(8, 129, 92, 4, 151, 170, 188, 174)
      }), _ARG_1_)
      _ARG_0_.currentStage = U2.TouchTransMissionEnd
      _ARG_0_:UpdateTextByStage()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}, {
  require(((function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(8, 142, 80, 18, 138, 227, 183, 174, 86, 61, 204, 215, 104, 51, 134, 230, 248, 189, 36, 42, 123, 201, 199, 155, 67, 60, 216, 134, 35, 56, 152, 188, 238, 173, 6, 35, 118, 214, 144, 137)))
})) end
return
