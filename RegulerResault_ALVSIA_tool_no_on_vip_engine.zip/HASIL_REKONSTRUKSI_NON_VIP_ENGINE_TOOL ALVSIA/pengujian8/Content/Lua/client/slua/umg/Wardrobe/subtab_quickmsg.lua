do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(224, 30, 97, 37, 222)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(224, 30, 105, 51, 195, 181, 222, 73, 204, 136, 172, 215, 211, 224, 40, 161, 1, 35, 29, 3, 42, 158, 242, 97, 158, 143, 188, 235, 211))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.settingConfig = {}
      _ARG_0_.subTabConfig = _ARG_2_
      _ARG_0_.args = _ARG_3_
      _ARG_0_.currentSelectActorID = 0
      _ARG_0_.currentSelectType = Unknow
      _ARG_0_.stSearch = U1()
      _ARG_0_.currentVoiceDatas = {}
      _ARG_0_.currentPersonalityVoiceDatas = {}
      _ARG_0_.selectedPersonalityItem = nil
      _ARG_0_.currentSelectVoiceDatas = {}
      _ARG_0_.currentSelectWheelVoiceDatas = {}
      _ARG_0_.selectItem = {}
      _ARG_0_.wheelItemList = {}
      _ARG_0_.currentSelectPlanID = U2.PlayerCurVoicePlanID
      _ARG_0_.preSelectEnterPlayIndex = -1
      _ARG_0_.sortTypeList = {
        [U2.ENUM_SORT_TYPE.DEFAULT] = {
          type = U2.ENUM_SORT_TYPE.DEFAULT,
          text = U3.LocUtil.LocalizeResFormat(13016)
        },
        [U2.ENUM_SORT_TYPE.LATEST] = {
          type = U2.ENUM_SORT_TYPE.LATEST,
          text = U3.LocUtil.LocalizeResFormat(13015)
        },
        [U2.ENUM_SORT_TYPE.OWN] = {
          type = U2.ENUM_SORT_TYPE.OWN,
          text = U3.LocUtil.LocalizeResFormat(13017)
        },
        [U2.ENUM_SORT_TYPE.FAVORITE] = {
          type = U2.ENUM_SORT_TYPE.FAVORITE,
          text = U3.LocUtil.LocalizeResFormat(69270)
        }
      }
      _ARG_0_.ComboBox_ShowType = nil
      _ARG_0_.ComboBox_Language = nil
      _ARG_0_.ComboBox_Plan = nil
      _ARG_0_.planDataList = nil
      _ARG_0_.isFeaturePanelShow = false
      _ARG_0_.highQualityActorList = {}
      _ARG_0_.currentSortType = U2.ENUM_SORT_TYPE.DEFAULT
      _ARG_0_.isFeatureCategoryInited = false
      _ARG_0_.featureVoiceData = nil
      _ARG_0_.featureVoiceSubData = {}
      _ARG_0_.lastVoiceModeTab = 1
      _ARG_0_.nCurSelectPlanIndex = 1
      _ARG_0_.lastClickWheelIndex = nil
      _ARG_0_.lastSelectArea = U4.None
      _ARG_0_.personalityVoiceBroadcastCache = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_:InitVoiceTabList()
      _ARG_0_.Common_Tab_ActorMode = _ARG_0_:InitHorizontalLevelTwoTextTab(_ARG_0_.UIRoot.Common_Tab_ActorMode, nil, {bWarehouse = true})
      _ARG_0_.scrollBoxSelectMsg = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.ScrollBoxSelectMsg)
      _ARG_0_.scrollBoxActorVoice = _ARG_0_:InitExtendedScrollBox(_ARG_0_.UIRoot.ScrollBoxActorVoice)
      _ARG_0_.scrollBoxPersonalityVoice = _ARG_0_:InitExtendedScrollBox(_ARG_0_.UIRoot.ExtendedLoopScrollBox_PersonalityVoice)
      _ARG_0_.LoopScrollBox_Actors = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollBox_Actors)
      _ARG_0_.ScrollGridSelectFeatureMsg = _ARG_0_:InitExtendedScrollGrid(_ARG_0_.UIRoot.ScrollGridSelectFeatureMsg)
      _ARG_0_.ScrollGridFeatureVoice = _ARG_0_:InitExtendedScrollGrid(_ARG_0_.UIRoot.ScrollGridFeatureVoice)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_Search_Item_UIBP02.message_input, U1(204, 28, 84, 51, 213, 181, 179, 82, 193, 147, 170, 237, 194), _ARG_0_.OnInputTextChanged, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_Search_Item_UIBP02.message_input, U1(204, 28, 84, 51, 213, 181, 179, 85, 205, 144, 164, 252, 210, 236, 19), _ARG_0_.OnClickSearchConfirm, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_Search_Item_UIBP02.close, U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnClickCancelSearch, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Get, _ARG_0_.TryGetVoiceItem, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GoShop, _ARG_0_.GetVoicePack, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_QDefault, _ARG_0_.ShowRestoreDefaultConfirm, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_QSure, _ARG_0_.OnClickConfirm, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_QCancel, _ARG_0_.OnClickCancel, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Quickreplace, _ARG_0_.OnClickReplace, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Clear, _ARG_0_.OnClickClear, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Search, _ARG_0_.OnClickSearch, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_BeginSearch, _ARG_0_.OnClickSearch, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Sort_Default, _ARG_0_.OnClickSortDefault, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Sort_Latest, _ARG_0_.OnClickSortLatest, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Sort_Own, _ARG_0_.OnClickSortOwn, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Collect, _ARG_0_.OnClickCollect, _ARG_0_)
      _ARG_0_.LoopScrollBox_Actors:SetRefreshItemCallback(_ARG_0_.OnRefreshActorListItem, _ARG_0_)
      _ARG_0_.LoopScrollBox_Actors:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 115, 212, 152, 160, 219, 195, 229, 17), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnSelectActor, _ARG_0_)
      _ARG_0_.LoopScrollBox_Actors:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 10), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnSelectEnterTeamPlay, _ARG_0_)
      _ARG_0_.LoopScrollBox_Actors:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 121, 207, 145, 161, 237, 197, 253), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnItemCollectClicked, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:SetRefreshItemCallback(_ARG_0_.OnRefreshVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:SetRefreshSubItemCallback(_ARG_0_.OnRefreshUnlockTipsItem, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:AddItemWidgetChildEvent(U1(193, 6, 110, 9, 228, 181, 149, 87, 243, 152, 161, 238), U1(204, 28, 77, 57, 216, 178, 149, 120, 213, 137, 185, 231, 200, 220, 7, 130, 5, 39, 30, 18), _ARG_0_.OnClickVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 162, 95, 193, 153, 180, 220, 201, 218, 31, 166, 3, 39), _ARG_0_.OnDragMsgItemReadyToShape, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 91, 206, 158, 168, 228, 195, 237), _ARG_0_.OnDragMsgItemCanceled, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 86, 201, 158, 166, 237, 194), _ARG_0_.OnClickVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxActorVoice:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 106, 204, 156, 180), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnPlayVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxPersonalityVoice:SetRefreshItemCallback(_ARG_0_.OnRefreshPersonalityVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxPersonalityVoice:AddItemWidgetChildEvent(U1(193, 6, 110, 9, 228, 181, 149, 87, 243, 152, 161, 238), U1(204, 28, 77, 57, 216, 178, 149, 120, 213, 137, 185, 231, 200, 220, 7, 130, 5, 39, 30, 18), _ARG_0_.OnClickPersonalityVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxPersonalityVoice:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 162, 95, 193, 153, 180, 220, 201, 218, 31, 166, 3, 39), _ARG_0_.OnDragPersonalityMsgItemReadyToShape, _ARG_0_)
      _ARG_0_.scrollBoxPersonalityVoice:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 91, 206, 158, 168, 228, 195, 237), _ARG_0_.OnDragPersonalityMsgItemCanceled, _ARG_0_)
      _ARG_0_.scrollBoxPersonalityVoice:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 86, 201, 158, 166, 237, 194), _ARG_0_.OnClickPersonalityVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxPersonalityVoice:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 106, 204, 156, 180), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnPlayPersonalityVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:SetRefreshItemCallback(_ARG_0_.OnRefreshSelectedVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 123, 196, 153), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.SetMsgContent, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 106, 204, 156, 180), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnPlaySelectVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 163, 79, 195, 158, 168, 251, 213), _ARG_0_.OnItemDropOnSelectedItem, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 84, 51, 222, 181, 180, 72, 193, 154, 136, 230, 210, 236, 5), _ARG_0_.OnDragEnterLeaveSelectedItem, _ARG_0_, true)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 84, 51, 222, 181, 180, 72, 193, 154, 129, 237, 199, 255, 18), _ARG_0_.OnDragEnterLeaveSelectedItem, _ARG_0_, false)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 86, 201, 158, 166, 237, 194), _ARG_0_.OnClickSelectVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(193, 6, 110, 9, 228, 181, 149, 87, 243, 152, 161, 238), U1(204, 28, 77, 57, 216, 178, 149, 120, 213, 137, 185, 231, 200, 220, 7, 130, 5, 39, 30, 18), _ARG_0_.OnClickSelectVoiceItem, _ARG_0_)
      _ARG_0_.scrollBoxSelectMsg:AddItemWidgetChildEvent(U1(193, 7, 116, 34, 194, 175, 175, 126, 197, 145, 168, 252, 195), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.DeleteSelectedMsg, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTOR_VOICE, U2.EVENTID_ACTOR_VOICE_ACTOR_CHANGE, _ARG_0_.OnActorChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTOR_VOICE, U2.EVENTID_ACTOR_VOICE_OWN_MESSAGE_CHANGAE, _ARG_0_.OnVoiceChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_JUMP_DATA_RECEIVE, _ARG_0_.SelectDefaultActor, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTOR_VOICE, U2.EVENTID_ACTOR_PERSONALITY_VOICE_FORBIDDEN, _ARG_0_.OnGotVoiceForbiddenEvent, _ARG_0_)
      _ARG_0_:AddOnCheckStateChangedEventByControl(_ARG_0_.UIRoot.ToggleActor, _ARG_0_.OpenOrCloseActorList, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_1, function()
        UIRoot.ToggleActor:SetCheckedState(U1.UEnums.ECheckBoxState.Unchecked)
        _ENV:OpenOrCloseActorList(false)
        return
      end)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Question, _ARG_0_.OnClickQuestionButton, _ARG_0_)
      _ARG_0_:AddOnCheckStateChangedEventByControl(_ARG_0_.UIRoot.CheckBox_SelectFeature, _ARG_0_.OnFeatureSelectStateChanged, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:SetRefreshItemCallback(_ARG_0_.OnRefreshSelectedFeatureCategory, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:SetRefreshSubItemCallback(_ARG_0_.OnRefreshSelectedFeatureItem, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(193, 7, 116, 34, 194, 175, 175, 123, 196, 153), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.SetFeatureMsgContent, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 163, 79, 195, 158, 168, 251, 213), _ARG_0_.OnItemDropOnSelectedFeatureItem, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 84, 51, 222, 181, 180, 72, 193, 154, 136, 230, 210, 236, 5), _ARG_0_.OnDragEnterSelectedFeatureItem, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 84, 51, 222, 181, 180, 72, 193, 154, 129, 237, 199, 255, 18), _ARG_0_.OnDragLeaveSelectedFeatureItem, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 86, 201, 158, 166, 237, 194), _ARG_0_.OnClickSelectVoiceFeatureItem, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(193, 6, 110, 9, 228, 181, 149, 87, 243, 152, 161, 238), U1(204, 28, 77, 57, 216, 178, 149, 120, 213, 137, 185, 231, 200, 220, 7, 130, 5, 39, 30, 18), _ARG_0_.OnClickSelectVoiceFeatureItem, _ARG_0_)
      _ARG_0_.ScrollGridSelectFeatureMsg:AddSubItemEvent(U1(193, 7, 116, 34, 194, 175, 175, 126, 197, 145, 168, 252, 195), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.DeleteSelectedFeatureMsg, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:SetRefreshItemCallback(_ARG_0_.OnRefreshFeatureVoiceCategory, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:SetRefreshSubItemCallback(_ARG_0_.OnRefreshFeatureVoiceItem, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 86, 201, 158, 166, 237, 194), _ARG_0_.OnClickFeatureVoiceItem, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:AddSubItemEvent(U1(193, 6, 110, 9, 228, 181, 149, 87, 243, 152, 161, 238), U1(204, 28, 77, 57, 216, 178, 149, 120, 213, 137, 185, 231, 200, 220, 7, 130, 5, 39, 30, 18), _ARG_0_.OnClickFeatureVoiceItem, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 162, 95, 193, 153, 180, 220, 201, 218, 31, 166, 3, 39), _ARG_0_.OnDragFeatureMsgItemReadyToShape, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:AddSubItemEvent(U1(199, 0, 97, 49, 233, 179, 159, 74, 233, 137, 168, 229), U1(204, 28, 68, 36, 204, 166, 179, 91, 206, 158, 168, 228, 195, 237), _ARG_0_.OnDragFeatureMsgItemCanceled, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:AddSubItemEvent(U1(193, 7, 116, 34, 194, 175, 175, 106, 204, 156, 180), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnPlayFeatureVoiceItem, _ARG_0_)
      _ARG_0_.ScrollGridFeatureVoice:AddSubItemEvent(U1(193, 7, 116, 34, 194, 175, 175, 119, 207, 143, 168), U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnClickFeatureVoiceItemMore, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTOR_VOICE, U2.EVENTID_ACTOR_VOICE_COLLECT_STATE_CHANGE, _ARG_0_.OnActorCollectStateChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTOR_VOICE, U2.EVENTID_ACTOR_PERSONALITY_VOICE_UNLOCK, _ARG_0_.OnPersonalityVoiceUnlocked, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Tactics, _ARG_0_.OnClickTacticsButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Personality, _ARG_0_.OnClickPersonalityButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_UnlockVoice, _ARG_0_.OnClickUnlockVoiceButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PersonalityBeginSearch, _ARG_0_.OnClickPersonalitySearch, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.CommonSearchItem_Personality.close, U1(204, 28, 67, 58, 196, 162, 155, 95, 196), _ARG_0_.OnClickCancelPersonalitySearch, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.CommonSearchItem_Personality.message_input, U1(204, 28, 84, 51, 213, 181, 179, 82, 193, 147, 170, 237, 194), _ARG_0_.OnInputPersonalityTextChanged, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.CommonSearchItem_Personality.message_input, U1(204, 28, 84, 51, 213, 181, 179, 85, 205, 144, 164, 252, 210, 236, 19), _ARG_0_.OnClickPersonalitySearchConfirm, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Team, _ARG_0_.OnClickButton_Team, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Global, _ARG_0_.OnClickButton_Global, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitSelectList"] = function(_ARG_0_)
    do
      _ARG_0_.currentSelectVoiceDatas = {}
      goto lbl_41
      ::lbl_41::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.currentSelectWheelVoiceDatas = {}
      goto lbl_62
      ::lbl_62::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:ResetSearchText()
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 141, 247, 197, 237, 46, 185, 10, 38, 9, 23, 33, 136, 234, 127),
        U2(163, 32, 101, 39, 216, 164, 131, 78, 234, 136, 160, 248, 235, 232, 7, 142, 29, 36, 31)
      }))
      U3.RequestJumpMapInfo()
      _ARG_0_.actorList = U4.GetShowActors(false)
      _ARG_0_.ComboBox_ShowType = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_UIBP, nil, false, {bWarehouse = true})
      _ARG_0_.ComboBox_ShowType:SetRefreshOptionCallback(_ARG_0_.OnRefreshFilterItem, _ARG_0_)
      _ARG_0_.ComboBox_ShowType:SetSelectOptionCallback(_ARG_0_.OnSelectFilterItem, _ARG_0_)
      _ARG_0_.ComboBox_ShowType:SetData(_ARG_0_.sortTypeList)
      _ARG_0_.ComboBox_ShowType:SelectIndex(U4.ENUM_SORT_TYPE.DEFAULT)
      _ARG_0_:PrepareLanguageData()
      _ARG_0_.ComboBox_Language = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.ComboBox_Language, nil, false, {bWarehouse = true})
      _ARG_0_.ComboBox_Language:SetRefreshOptionCallback(_ARG_0_.OnRefreshLanguageItem, _ARG_0_)
      _ARG_0_.ComboBox_Language:SetSelectOptionCallback(_ARG_0_.OnSelectLanguageItem, _ARG_0_)
      _ARG_0_.ComboBox_Language:SetData(_ARG_0_.languageData)
      _ARG_0_.ComboBox_Language:SelectIndex(1)
      if U1.LobbySystem.CheckOpen(U1.BP_EUNM_NEW_ACTOR_VOICE_FEATURES_SWITCH) then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.ComboBox_Plan, true)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_14, true)
        _ARG_0_.planDataList = {}
        _ARG_0_ = _ARG_0_
        _ARG_0_.planDataList[false] = {
          planID = false,
          text = U1.LocUtil.LocalizeResFormat(87090, false)
        }
        _ARG_0_ = _ARG_0_
        _ARG_0_.ComboBox_Plan = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.ComboBox_Plan, nil, false, {bWarehouse = true})
      else
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.ComboBox_Plan, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_14, false)
      end
      _ARG_0_:OnClickPlan(nil, _ARG_0_.currentSelectPlanID, true)
      U1.slua_GameFrontendHUD:BeginModifyUserSettings()
      _ARG_0_.settingConfig = U1.slua_GameFrontendHUD:GetUserSettings()
      _ARG_0_:InitWheelView()
      _ARG_0_:InitSelectList()
      _ARG_0_:SelectDefaultActor()
      _ARG_0_:SetCurrentVoiceDatas(_ARG_0_.currentSelectActorID, U5.Tactics)
      _ARG_0_.scrollBoxSelectMsg:SetData(_ARG_0_.currentSelectVoiceDatas)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_Hint, not _ARG_0_.settingConfig.HaveShowActorHint and #_ARG_0_.actorList > 1)
      _ARG_0_.UIRoot.TextBlock_Title1:SetText(U1.LocUtil.LocalizeResFormat(11075))
      _ARG_0_.UIRoot.TextBlock_Title2:SetText(U1.LocUtil.LocalizeResFormat(11077))
      _ARG_0_.UIRoot.TextBlock_172:SetText(U1.LocUtil.LocalizeResFormat(13014))
      _ARG_0_.UIRoot.Text_Latest:SetText(U1.LocUtil.LocalizeResFormat(13015))
      _ARG_0_.UIRoot.Text_Default:SetText(U1.LocUtil.LocalizeResFormat(13016))
      _ARG_0_.UIRoot.Text_Own:SetText(U1.LocUtil.LocalizeResFormat(13017))
      _ARG_0_.UIRoot.TextBlock_FeatureTips:SetText(U1.LocUtil.LocalizeResFormat(45312))
      _ARG_0_.UIRoot.TextBlock_UnlockVoice:SetText(U1.LocUtil.GetLocalizeResStr(2026051157))
      _ARG_0_:AddTimerOnce(0, function()
        _ENV:RefreshFeatureSwitchPanel()
        _ENV:InitFeatureCategory()
        _ENV:RefreshRightVoicePanel()
        return
      end)
      _ARG_0_:InitPersonalityVoicePanel()
      _ARG_0_:ResetPersonalitySearchText()
      if U1.type(_ARG_0_.args) == U2(247, 19, 98, 58, 200) and _ARG_0_.args.voiceMode == 2 then
        _ARG_0_:SetVoiceMode(U6.Personality)
        _ARG_0_.args.voiceMode = nil
        _ARG_0_:_MarkPersonalityVoiceTabViewed()
      end
      _ARG_0_:TryPostVoiceCoinFirstOpenEvent()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryPostVoiceCoinFirstOpenEvent"] = function(_ARG_0_)
    do
      if (require((table.concat({
        U1(224, 30, 105, 51, 195, 181, 222, 86, 207, 154, 164, 235, 136, 197, 24, 160, 26, 33, 32, 10, 60, 136, 229, 120, 224, 159, 184, 254, 197, 183, 23, 187, 2, 43, 5, 4, 61, 147, 245, 124),
        U1(240)
      }))).LoadFileToTable_N(require((table.concat({
        U1(224, 30, 105, 51, 195, 181, 222, 86, 207, 154, 164, 235, 136, 197, 24, 160, 26, 33, 32, 10, 60, 136, 229, 120, 224, 159, 184, 254, 197, 183, 23, 187, 2, 43, 5, 4, 61, 147, 245, 124),
        U1(240)
      }))).ePlayerPrefsType.eVoiceCoinScanEffectGuide) or {}).hasShown == true then
        return
      end
      ;(require((table.concat({
        U1(224, 30, 105, 51, 195, 181, 222, 86, 207, 154, 164, 235, 136, 197, 24, 160, 26, 33, 32, 10, 60, 136, 229, 120, 224, 159, 184, 254, 197, 183, 23, 187, 2, 43, 5, 4, 61, 147, 245, 124),
        U1(240)
      }))).LoadFileToTable_N(require((table.concat({
        U1(224, 30, 105, 51, 195, 181, 222, 86, 207, 154, 164, 235, 136, 197, 24, 160, 26, 33, 32, 10, 60, 136, 229, 120, 224, 159, 184, 254, 197, 183, 23, 187, 2, 43, 5, 4, 61, 147, 245, 124),
        U1(240)
      }))).ePlayerPrefsType.eVoiceCoinScanEffectGuide) or {}).hasShown = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVoiceTabList"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SelectVoiceList"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.nCurSelectPlanIndex = _ARG_1_ or 1
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVoiceTabShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHorizontalActorTabButton"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:SetCurrentVoiceDatas(_ARG_0_.currentSelectActorID, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHorizontalVoiceTabButton"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:SelectVoiceList(_ARG_1_)
      _ARG_0_:OnChangeSelectVoiceMode(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSelectVoiceMode"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_ML:SetActiveWidgetIndex(_ARG_1_ - 1)
      if _ARG_1_ == List then
        _ARG_0_.scrollBoxSelectMsg:RefreshAllItems(_ARG_0_.currentSelectVoiceDatas)
      elseif _ARG_1_ == Roulette then
        _ARG_0_:RefreshWheelView()
      elseif _ARG_1_ == Feature then
        _ARG_0_:RefreshFeatureView()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectActor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectEnterTeamPlay"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.preSelectEnterPlayIndex ~= -1 and _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_0_.preSelectEnterPlayIndex) then
        _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_0_.preSelectEnterPlayIndex).IsSelectEnterPlay = false
      end
      if _ARG_0_.preSelectEnterPlayIndex ~= _ARG_2_ then
        if not U1.CheckIsActorValid(_ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).ActorID) then
          if _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_0_.preSelectEnterPlayIndex) then
            _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_0_.preSelectEnterPlayIndex).IsSelectEnterPlay = true
          end
          return
        end
        _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).IsSelectEnterPlay = true
      else
        _ARG_0_.preSelectEnterPlayIndex = -1
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCurrentActor"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(213, 29, 105, 53, 200, 128, 147, 78, 207, 143, 142, 238, 193), _ARG_1_) then
      end
      if CDataTable.GetTableData(U1(213, 29, 105, 53, 200, 128, 147, 78, 207, 143, 142, 238, 193), _ARG_1_) and CDataTable.GetTableData(U1(213, 29, 105, 53, 200, 128, 147, 78, 207, 143, 142, 238, 193), _ARG_1_).ActorItemID ~= 0 then
        if CDataTable.GetTableData(U1(202, 6, 101, 59), CDataTable.GetTableData(U1(213, 29, 105, 53, 200, 128, 147, 78, 207, 143, 142, 238, 193), _ARG_1_).ActorItemID) then
          if 0 < CDataTable.GetTableData(U1(202, 6, 101, 59), CDataTable.GetTableData(U1(213, 29, 105, 53, 200, 128, 147, 78, 207, 143, 142, 238, 193), _ARG_1_).ActorItemID).ItemQuality then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCurrentVoiceDatas"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_1_ == _ARG_0_.currentSelectActorID and _ARG_2_ == _ARG_0_.currentSelectType and not _ARG_3_ then
        return
      end
      _ARG_0_.currentSelectActorID = _ARG_1_
      _ARG_0_.currentSelectType = _ARG_2_
      _ARG_0_:RefreshCurrentVoiceDatas(_ARG_1_, _ARG_2_)
      _ARG_0_:RefreshActorScrollBox()
      _ARG_0_:RefreshCurrentCollectState()
      _ARG_0_.scrollBoxActorVoice:Deselect()
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Get, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCurrentVoiceDatas"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.currentVoiceDatas = {}
      if CDataTable.GetTable((U1(213, 29, 105, 53, 200, 136, 180, 121, 198, 154))) then
        goto lbl_156
        if not (_ARG_1_ < (53).ActorID and (53).Key > 0) or not (0 < (53).VoiceID) then
          if (53).ActorID == _ARG_1_ and (53).VoiceType == _ARG_2_ then
          end
          ::lbl_156::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshActorListItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CDataTable.GetTableData(U1(202, 6, 101, 59), _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).ActorItemID) then
      end
      if _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).IsSelectEnterPlay then
        _ARG_0_.preSelectEnterPlayIndex = _ARG_2_
      else
      end
      if U3.GetAssociateItemIDByActorIDList(_ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).ActorID) then
      end
      if U3.CheckIsActorUnLocked(_ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).ActorID) and U3.GetActorExpireDisplay(_ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).ActorID) ~= U3.ENUM_UNLOCK_TYPE.LIMIT then
        if U3.GetActorCollectTS(_ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_).ActorID) ~= nil then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCheckOwnVoice"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:PlayAudio(sound_config.toggle_v1)
      _ARG_0_:SetCurrentVoiceDatas(_ARG_0_.currentSelectActorID, _ARG_0_.currentSelectType, true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRestoreDefaultConfirm"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowNeedDownloadTips"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetActorIDByKey(_ARG_1_) or GetActorIDByKey(_ARG_1_) == 0 then
        return
      end
      if GetAssociateItemIDByActorIDList((GetActorIDByKey(_ARG_1_))) and U1.next((GetAssociateItemIDByActorIDList((GetActorIDByKey(_ARG_1_))))) and U2.GetState(U3.ENUM_DownloadType.ODPAK, (GetAssociateItemIDByActorIDList((GetActorIDByKey(_ARG_1_))))) ~= U3.ENUM_DownloadState.Done then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetSelectList"] = function(_ARG_0_)
    do
      if _ARG_0_.nCurSelectPlanIndex == List then
        if U3.GetVoiceDefaultSetting((U2(199, 23, 102, 55, 216, 173, 132, 106, 204, 156, 180, 237, 212, 202, 31, 166, 7, 19, 5, 15, 62, 154, 212, 111, 200, 153, 148, 220, 250, 240, 20, 163))) == nil then
          return
        end
        if _ARG_0_.settingConfig[U2(211, 30, 97, 47, 200, 179, 179, 82, 193, 137, 156, 253, 207, 234, 28, 147, 22, 58, 4, 47, 51, 151, 239, 70, 217, 158, 169, 199) .. _ARG_0_.currentSelectPlanID] then
          _ARG_0_ = _ARG_0_
          U1.import((U2(192, 26, 97, 34, 252, 180, 153, 89, 203, 169, 168, 240, 210, 192, 25, 161, 28)))().chatTextID = U3.GetDefaultVoice(U3.GetVoiceDefaultSetting((U2(199, 23, 102, 55, 216, 173, 132, 106, 204, 156, 180, 237, 212, 202, 31, 166, 7, 19, 5, 15, 62, 154, 212, 111, 200, 153, 148, 220, 250, 240, 20, 163))):Get(97))
          _ARG_0_ = _ARG_0_
        else
        end
      elseif _ARG_0_.nCurSelectPlanIndex == Roulette then
        if U3.GetVoiceDefaultSetting((U2(199, 23, 102, 55, 216, 173, 132, 106, 204, 156, 180, 237, 212, 222, 31, 162, 22, 46, 51, 14, 60, 133, 209, 127, 217, 142, 182, 204, 211, 225, 19, 158, 39, 30, 9, 5, 57))) == nil then
          return
        end
        if _ARG_0_.settingConfig[U2(211, 30, 97, 47, 200, 179, 167, 82, 197, 152, 161, 203, 206, 232, 3, 150, 6, 43, 19, 13, 9, 148, 248, 126, 249, 131, 187, 247, 250, 240, 20, 163, 60) .. _ARG_0_.currentSelectPlanID] then
          _ARG_0_ = _ARG_0_
          U1.import((U2(192, 26, 97, 34, 252, 180, 153, 89, 203, 169, 168, 240, 210, 192, 25, 161, 28)))().chatTextID = U3.GetDefaultVoice(U3.GetVoiceDefaultSetting((U2(199, 23, 102, 55, 216, 173, 132, 106, 204, 156, 180, 237, 212, 222, 31, 162, 22, 46, 51, 14, 60, 133, 209, 127, 217, 142, 182, 204, 211, 225, 19, 158, 39, 30, 9, 5, 57))):Get(97))
          _ARG_0_ = _ARG_0_
        else
        end
      elseif _ARG_0_.nCurSelectPlanIndex == Feature then
        goto lbl_430
        ::lbl_430::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.nCurSelectPlanIndex ~= Feature then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryGetVoiceItem"] = function(_ARG_0_)
    do
      if _ARG_0_.scrollBoxActorVoice:GetItemData((_ARG_0_.scrollBoxActorVoice:GetSelectIndex())) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.currentVoiceDatas[_ARG_2_] then
        return
      end
      if _ARG_0_.scrollBoxActorVoice:GetSelectIndex() == _ARG_2_ then
        if _ARG_1_.Expire_Making3 then
        end
      else
      end
      if _ARG_1_.HorizontalBox_3 and _ARG_1_.TextBlock_Expire then
        if _ARG_0_.currentVoiceDatas[_ARG_2_].unLock and not CheckIsVoiceNew(_ARG_0_.currentVoiceDatas[_ARG_2_].key) and GetVoiceExpireDisplay(_ARG_0_.currentVoiceDatas[_ARG_2_].key) == ENUM_UNLOCK_TYPE.LIMIT then
        else
        end
      end
      if not _ARG_1_.DragDropItem then
        return
      end
      if U5 and _ARG_3_ ~= true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshUnlockTipsItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_.TextBlock_Tips:SetText(LocUtil.GetLocalizeResStr(38752))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(216, 4, 111, 63, 206, 164, 173, 26, 245, 180, 146, 219, 195, 253, 3, 174, 29, 37, 47, 55, 40, 152, 227, 97, 253, 136, 174, 235, 215, 254, 2, 237, 44, 60, 35, 26, 36, 130, 251, 76),
        U1(236, 27, 99, 51, 228, 181, 149, 87, 140, 221, 164, 230, 194, 236, 15, 253, 86, 49)
      }), _ARG_2_))
      _ARG_0_:SetLastSelectArea(U2.ActorVoice)
      _ARG_0_.selectItem = {
        key = _ARG_0_.currentVoiceDatas[_ARG_2_].key,
        actorID = _ARG_0_.currentVoiceDatas[_ARG_2_].key // 100000,
        voiceListIndex = _ARG_2_
      }
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSelectedListStartIndex"] = function(_ARG_0_)
    do
      if _ARG_0_.scrollBoxSelectMsg.UIRoot:GetScrollOffset() - _ARG_0_.scrollBoxSelectMsg.UIRoot.NavigationScrollPadding > _ARG_0_.scrollBoxSelectMsg.UIRoot.ItemSize then
      end
      do return (math.min(math.floor((_ARG_0_.scrollBoxSelectMsg.UIRoot:GetScrollOffset() - _ARG_0_.scrollBoxSelectMsg.UIRoot.NavigationScrollPadding - _ARG_0_.scrollBoxSelectMsg.UIRoot.ItemSize) / (_ARG_0_.scrollBoxSelectMsg.UIRoot.ItemSize + _ARG_0_.scrollBoxSelectMsg.UIRoot.Padding)) + 1, #_ARG_0_.currentSelectVoiceDatas)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDragNewbieGuide"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 227, 133, 178, 239, 242, 235, 6, 176, 45, 55, 23, 20, 36, 132, 215, 111),
        U1(234, 22, 101, 122, 141, 166, 133, 83, 196, 152, 132, 230, 194, 236, 15, 253, 86, 49)
      }), _ARG_2_))
      if not require((U1(224, 30, 105, 51, 195, 181, 222, 86, 207, 154, 164, 235, 136, 231, 18, 176, 17, 43, 21, 72, 49, 158, 231, 99, 211, 178, 179, 253, 193, 251, 14, 178))).NeedShowNewbieGuide(10100) then
        return
      end
      if _ARG_0_.nCurSelectPlanIndex == U2.List then
      elseif _ARG_0_.nCurSelectPlanIndex == U2.Roulette then
      end
      if not slua.isValid(_ARG_1_) or not slua.isValid(_ARG_0_.UIRoot.Wheelitem_03) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshPersonalityVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_) then
        return
      end
      if not _ARG_1_.DragDropItem then
        return
      end
      if U2 and _ARG_3_ ~= true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPersonalityVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(216, 4, 111, 63, 206, 164, 173, 26, 245, 180, 146, 219, 195, 253, 3, 174, 29, 37, 47, 55, 40, 152, 227, 97, 253, 136, 174, 235, 215, 254, 2, 237, 44, 60, 35, 26, 36, 130, 251, 74),
        U1(230, 0, 115, 57, 195, 160, 156, 83, 212, 132, 155, 231, 207, 234, 18, 142, 7, 39, 29, 74, 125, 152, 238, 110, 213, 149, 231, 189, 197)
      }), _ARG_2_))
      _ARG_0_:SetLastSelectArea(U2.PersonalityVoice)
      if not (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)) then
        return
      end
      _ARG_0_.selectedPersonalityItem, _ARG_0_.selectItem = _ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_), {
        key = (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)).key,
        actorID = (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)).key // 100000,
        voiceListIndex = nil
      }
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayPersonalityVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlaySelectVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.currentSelectVoiceDatas[_ARG_2_].key ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragMsgItemReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 153, 234, 215, 254, 42, 164, 4, 27, 20, 19, 32, 179, 245, 123),
        U1(231, 11, 84, 57, 254, 169, 145, 74, 197, 209, 237, 225, 200, 237, 18, 191, 73, 103, 3)
      }), _ARG_2_))
      _ARG_0_.selectItem = {
        key = _ARG_0_.currentVoiceDatas[_ARG_2_].key,
        actorID = _ARG_0_.currentVoiceDatas[_ARG_2_].key // 100000,
        voiceListIndex = _ARG_2_
      }
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragMsgItemCanceled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.lastEnteredWidget then
        _ARG_0_:SetWidgetVisible(_ARG_0_.lastEnteredWidget.Image_Hover, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragPersonalityMsgItemReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 153, 234, 215, 254, 55, 178, 17, 33, 15, 24, 44, 141, 249, 110),
        U1(250, 63, 115, 49, 228, 181, 149, 87, 242, 152, 172, 236, 223, 221, 24, 148, 27, 35, 0, 3, 113, 209, 233, 100, 212, 136, 165, 162, 147, 234)
      }), _ARG_2_))
      if not (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)) then
        return
      end
      _ARG_0_.selectedPersonalityItem, _ARG_0_.selectItem = _ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_), {
        key = (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)).key,
        actorID = (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_2_)).key // 100000,
        voiceListIndex = _ARG_2_
      }
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragPersonalityMsgItemCanceled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.lastEnteredWidget then
        _ARG_0_:SetWidgetVisible(_ARG_0_.lastEnteredWidget.Image_Hover, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSelectVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(216, 4, 111, 63, 206, 164, 173, 26, 245, 180, 146, 219, 195, 253, 3, 174, 29, 37, 47, 55, 40, 152, 227, 97, 253, 136, 174, 235, 215, 254, 2, 237, 44, 60, 35, 26, 36, 130, 251, 73),
        U1(230, 30, 101, 53, 217, 151, 159, 83, 195, 152, 132, 252, 195, 228, 91, 231, 26, 44, 20, 3, 37, 203, 165, 121)
      }), _ARG_2_))
      _ARG_0_.scrollBoxSelectMsg:Select(_ARG_2_)
      _ARG_0_:SetLastSelectArea(U2.SelectMsg)
      _ARG_0_:OnPlaySelectVoiceItem(_ARG_1_, _ARG_2_)
      _ARG_0_:RefreshPersonalityVoicePanel()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDeleteSelectVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.currentSelectVoiceDatas[_ARG_2_].key = 0
      _ARG_0_.currentSelectVoiceDatas[_ARG_2_].actorID = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshSelectedVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.currentSelectVoiceDatas[_ARG_2_].key ~= 0 then
        if IsPersonalityVoice(_ARG_0_.currentSelectVoiceDatas[_ARG_2_].key) then
        else
        end
        if _ARG_1_.WidgetSwitcher_Scope then
          if IsPersonalityVoice(_ARG_0_.currentSelectVoiceDatas[_ARG_2_].key) then
          else
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActorChange"] = function(_ARG_0_)
    do
      _ARG_0_.actorList = GetShowActors(false)
      _ARG_0_:RefreshCurrentVoiceDatas(_ARG_0_.currentSelectActorID, _ARG_0_.currentSelectType)
      _ARG_0_.scrollBoxActorVoice:RefreshAllItems(_ARG_0_.currentVoiceDatas)
      _ARG_0_.scrollBoxActorVoice:Deselect()
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Get, false)
      _ARG_0_:InitSelectList()
      _ARG_0_.scrollBoxSelectMsg:SetData(_ARG_0_.currentSelectVoiceDatas)
      _ARG_0_:RefreshWheelView()
      if _ARG_0_.nCurSelectPlanIndex == U1.Feature then
        _ARG_0_:RefreshFeatureView()
      end
      _ARG_0_:RefreshHightQualityVoiceData()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVoiceChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ and next(_ARG_3_) then
        goto lbl_22
        if nil and not U1.IsPersonalityVoice(nil) then
        else
          ::lbl_22::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGotVoiceForbiddenEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:RefreshPersonalityVoiceScrollBox()
      _ARG_0_:RefreshPersonalityVoicePanel()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenOrCloseActorList"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 157, 184, 246, 249, 235, 36, 187, 12, 33, 5, 55, 46, 149, 255, 104),
        U1(207, 27, 115, 34, 141, 136, 131, 121, 200, 152, 174, 227, 195, 237, 87, 250, 83)
      }) .. tostring(_ARG_1_))
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_GoShop, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.LoopScrollBox_Actors, true, true)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_PlaySoundHint, false)
        _ARG_0_.UIRoot.Button_1:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
        _ARG_0_.UIRoot.ArrowUp:SetWidgetVisibility(UEnums.ESlateVisibility.HitTestInvisible)
        _ARG_0_.UIRoot.ArrowDown:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.WidgetSwitcher_MR:SetActiveWidgetIndex(1)
        _ARG_0_.UIRoot.CanvasPanel_BG.Slot:SetOffsets(FMargin(0, 0, 0, 0))
      else
      end
      if _ARG_0_.UIRoot.Image_Hint:IsVisible() then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_Hint, false)
        _ARG_0_.settingConfig.HaveShowActorHint = true
        slua_GameFrontendHUD:FinishModifyUserSettings()
      end
      _ARG_0_:PlayAudio(sound_config.popup_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayActorVoice"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 224, 129, 188, 225, 247, 250, 19, 184, 17, 4, 15, 31, 46, 132, 176, 113),
        U1(230, 11, 58, 118)
      }) .. tostring(_ARG_2_))
      U2.PlayMultiLanguageSound(_ARG_2_, _ARG_0_.UIRoot)
      _ARG_0_:ShowNeedDownloadTips(_ARG_2_)
      _ARG_0_:AddTimer(0.1, function()
        if _ENV and WidgetSwitcher_SoundEffect then
          WidgetSwitcher_SoundEffect:SetActiveWidgetIndex(1)
        end
        U1.coroutine.yield(1)
        if _ENV and WidgetSwitcher_SoundEffect then
          WidgetSwitcher_SoundEffect:SetActiveWidgetIndex(0)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.fadein, 0, 1, 0, 1)
      _ARG_0_:ChangeSelectMode(false)
      _ARG_0_:RefreshPersonalityVoiceScrollBox()
      EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_SHOW_ENTRY_ICON, false)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.out, 0, 1, 0, 1)
      ReadAllVoices()
      U1.EventSystem:postEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_SHOW_ENTRY_ICON, true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitWheelView"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(163, 39, 73, 9, 254, 164, 132, 78, 201, 147, 170, 215, 247, 252, 30, 164, 24, 15, 21, 21, 46, 144, 231, 111, 138, 164, 179, 241, 194, 206, 15, 178, 6, 62, 54, 31, 40, 150, 176))
      _ARG_0_.wheelItemList = {}
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot[U1(212, 26, 101, 51, 193, 168, 132, 95, 205, 162, 253) .. 39] ~= nil then
      else
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_:SetWheelSelectIndex(nil)
      return
    end
  end,
  ["RefreshWheelView"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 226, 136, 187, 234, 211, 234, 15, 128, 11, 55, 5, 26, 27, 136, 245, 109))
      goto lbl_437
      if _ARG_0_.currentSelectWheelVoiceDatas[59] ~= nil and next(_ARG_0_.currentSelectWheelVoiceDatas[59]) and _ARG_0_.currentSelectWheelVoiceDatas[59].key ~= 0 then
        ;(95).ContentId = _ARG_0_.currentSelectWheelVoiceDatas[59].key
        ;(95).ActorId = _ARG_0_.currentSelectWheelVoiceDatas[59].actorID
        if U2.IsPersonalityVoice(_ARG_0_.currentSelectWheelVoiceDatas[59].key) then
        else
        end
        if (95).WidgetSwitcher_Scope then
          if U2.IsPersonalityVoice(_ARG_0_.currentSelectWheelVoiceDatas[59].key) then
          else
          end
        end
      else
        ;(95).ContentId = 0
        ;(95).ActorId = 0
      end
      if U4 then
      else
      end
      ;(95).Index = 59, 95, _ARG_0_.currentSelectWheelVoiceDatas[59], (95).DragDropItem:SetEnable(U4)
      ::lbl_437::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickWheelDelect"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickWheelAdd"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickWheelItem"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(216, 4, 111, 63, 206, 164, 173, 26, 245, 180, 146, 219, 195, 253, 3, 174, 29, 37, 47, 55, 40, 152, 227, 97, 253, 136, 174, 235, 215, 254, 2, 237, 44, 60, 35, 26, 36, 130, 251, 77),
        U1(235, 23, 101, 58, 228, 181, 149, 87, 128, 148, 163, 236, 195, 241)
      }) .. _ARG_1_)
      _ARG_0_:SetWheelSelectIndex(_ARG_1_)
      _ARG_0_:SetLastSelectArea(U2.Wheel)
      if _ARG_0_.currentSelectWheelVoiceDatas[_ARG_1_] and _ARG_0_.currentSelectWheelVoiceDatas[_ARG_1_].key ~= 0 then
      end
      return
    end
  end,
  ["SetWheelSelectIndex"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.lastClickWheelIndex = _ARG_1_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot[_ENV(202, 31, 97, 49, 200, 158, 167, 82, 197, 152, 161, 219, 195, 229, 18, 164, 7, 29) .. nil] then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLastSelectArea"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.lastSelectArea = _ARG_1_ or None
      if _ARG_1_ ~= Wheel then
        _ARG_0_:SetWheelSelectIndex(nil)
      end
      if _ARG_1_ ~= SelectMsg and _ARG_0_.scrollBoxSelectMsg then
        _ARG_0_.scrollBoxSelectMsg:Deselect()
      end
      if _ARG_1_ ~= ActorVoice and _ARG_0_.scrollBoxActorVoice then
        _ARG_0_.scrollBoxActorVoice:Deselect()
      end
      if _ARG_1_ ~= PersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice then
        _ARG_0_.scrollBoxPersonalityVoice:Deselect()
        _ARG_0_.selectedPersonalityItem = nil
      end
      _ARG_0_.ScrollGridFeatureVoice:DeselectSub()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 153, 234, 215, 254, 53, 178, 2, 54, 25, 34, 34, 178, 248, 123),
        U1(243, 23)
      }))
      if _ARG_3_ ~= nil and _ARG_3_.DragExtendData ~= nil then
      else
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemDropOnSelectedItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(216, 4, 111, 63, 206, 164, 173, 26, 245, 180, 146, 219, 195, 253, 3, 174, 29, 37, 47, 55, 40, 152, 227, 97, 253, 136, 174, 235, 215, 254, 2, 237, 44, 60, 41, 2, 40, 140, 212, 104),
        U1(236, 2, 79, 56, 254, 164, 156, 95, 195, 137, 168, 236, 239, 253, 18, 170, 83, 43, 30, 2, 56, 137, 186, 42)
      }) .. _ARG_2_)
      _ARG_0_:SetMsgContent(_ARG_1_, _ARG_2_)
      _ARG_0_:OnDragEnterLeaveSelectedItem(false, _ARG_1_, _ARG_2_)
      if _ARG_0_.nCurSelectPlanIndex == U2.Roulette then
      elseif _ARG_0_.nCurSelectPlanIndex == U2.List then
      end
      do return end
      _ARG_1_ = U1[211]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragEnterLeaveSelectedItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.lastEnteredWidget then
        _ARG_0_:SetWidgetVisible(_ARG_0_.lastEnteredWidget.Image_Hover, false)
      end
      if _ARG_1_ then
        _ARG_0_.lastEnteredWidget = _ARG_2_
      end
      _ARG_0_:SetWidgetVisible(_ARG_2_.Image_Hover, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ExchangeItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 245, 149, 190, 240, 215, 247, 0, 178, 42, 38, 5, 27, 109, 136, 254, 126),
        U1(230, 10, 65, 108, 141)
      }) .. _ARG_1_ .. U1(255, 14, 32, 63, 195, 165, 149, 66, 226, 221, 247, 168) .. _ARG_2_)
      if _ARG_0_.nCurSelectPlanIndex == U2.List then
        _ARG_0_.currentSelectVoiceDatas[_ARG_1_] = _ARG_0_.currentSelectVoiceDatas[_ARG_2_]
        _ARG_0_.currentSelectVoiceDatas[_ARG_2_] = _ARG_0_.currentSelectVoiceDatas[_ARG_1_], _ARG_0_.currentSelectVoiceDatas
      elseif _ARG_0_.nCurSelectPlanIndex == U2.Roulette then
        _ARG_0_.currentSelectWheelVoiceDatas[_ARG_1_] = _ARG_0_.currentSelectWheelVoiceDatas[_ARG_2_]
        _ARG_0_.currentSelectWheelVoiceDatas[_ARG_2_] = _ARG_0_.currentSelectWheelVoiceDatas[_ARG_1_], _ARG_0_.currentSelectWheelVoiceDatas
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSortMode"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.currentSortType = _ARG_1_
      SortShowActors(_ARG_0_.actorList, _ARG_1_)
      _ARG_0_:FilterHighQualityActor(_ARG_0_.actorList)
      _ARG_0_:SetActorListData()
      if _ARG_1_ == ENUM_SORT_TYPE.LATEST then
        _ARG_0_.UIRoot.Text_Latest:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 0.64, 0, 1)))
        _ARG_0_.UIRoot.Text_Default:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)))
        _ARG_0_.UIRoot.Text_Own:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)))
      elseif _ARG_1_ == ENUM_SORT_TYPE.OWN then
        _ARG_0_.UIRoot.Text_Own:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 0.64, 0, 1)))
        _ARG_0_.UIRoot.Text_Default:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)))
        _ARG_0_.UIRoot.Text_Latest:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)))
      else
        _ARG_0_.UIRoot.Text_Default:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 0.64, 0, 1)))
        _ARG_0_.UIRoot.Text_Own:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)))
        _ARG_0_.UIRoot.Text_Latest:SetColorAndOpacity(U1.FSlateColor(U1.FLinearColor(1, 1, 1, 1)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDataByIndex"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ < 0 then
        return _ARG_0_.currentVoiceDatas[-_ARG_1_]
      end
      if _ARG_0_.nCurSelectPlanIndex == List then
        return _ARG_0_.currentSelectVoiceDatas[_ARG_1_]
      elseif _ARG_0_.nCurSelectPlanIndex == Roulette then
        return _ARG_0_.currentSelectWheelVoiceDatas[_ARG_1_]
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCancel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ChangeSelectMode(false)
      _ARG_0_:InitSelectList()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickConfirm"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U1.MarkWardrobeVoiceMsgsSavePending()
      _ARG_0_:ChangeSelectMode(false)
      goto lbl_79
      import((U2(192, 26, 97, 34, 252, 180, 153, 89, 203, 169, 168, 240, 210, 192, 25, 161, 28)))().chatTextID = (34).key
      import((U2(192, 26, 97, 34, 252, 180, 153, 89, 203, 169, 168, 240, 210, 192, 25, 161, 28)))().bIncludeAll = (34).bIncludeAll
      ::lbl_79::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_134
      import((U2(192, 26, 97, 34, 252, 180, 153, 89, 203, 169, 168, 240, 210, 192, 25, 161, 28)))().chatTextID = (34).key
      import((U2(192, 26, 97, 34, 252, 180, 153, 89, 203, 169, 168, 240, 210, 192, 25, 161, 28)))().bIncludeAll = (34).bIncludeAll
      ::lbl_134::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_169
      if _ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[34] and _ARG_0_.currentSelectFeatureData[34].subData then
        goto lbl_167
        ;({
          [34] = {}
        })[34][47] = 200 and (200).key or 0
        ::lbl_167::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_169::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickReplace"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ChangeSelectMode(true)
      if not _ARG_0_.isFeaturePanelShow then
        _ARG_0_:ShowDragNewbieGuide(_ARG_0_.scrollBoxActorVoice.UIRoot.CurrentItemsMap:Get(0), 1)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSearch"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.bInSearch then
        _ARG_0_.bInSearch = false
      else
        _ARG_0_.bInSearch = true
      end
      _ARG_0_:UpdateSortMode(_ARG_0_.currentSortType or U1.ENUM_SORT_TYPE.DEFAULT)
      _ARG_0_.UIRoot.WidgetSwitcher_Search:SetActiveWidgetIndex(1)
      _ARG_0_.UIRoot.Common_Search_Item_UIBP02.message_input:SetKeyboardFocus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSearchConfirm"] = function(_ARG_0_)
    do
      _ARG_0_.actorList = GetActorsByName(_ARG_0_.stSearch)
      if _ARG_0_.isFeaturePanelShow then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCancelSearch"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ResetSearchText()
      _ARG_0_.actorList = U1.GetActorsByName(_ARG_0_.stSearch)
      if _ARG_0_.isFeaturePanelShow then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetActorListData"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetSearchText"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_Search:SetActiveWidgetIndex(0)
      if _ARG_0_.UIRoot.Text_NameOrUID then
        _ARG_0_.UIRoot.Text_NameOrUID:SetIsReadOnly(true)
        _ARG_0_.UIRoot.Text_NameOrUID:SetHintText(LocUtil.GetLocalizeResStr(52007))
      end
      _ARG_0_.stSearch = U1()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPlan"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 158, 244, 223, 250, 12, 135, 15, 51, 14, 86, 61, 141, 241, 116),
        U1(202, 54, 58, 118, 136, 178)
      }), _ARG_2_))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_3_ and _ARG_0_.currentSelectPlanID == _ARG_2_ then
        return
      end
      U2.SetCurrentSelectVoicePlanID(_ARG_2_)
      _ARG_0_.currentSelectPlanID = _ARG_2_
      _ARG_0_:InitSelectList()
      _ARG_0_.scrollBoxSelectMsg:SetData(_ARG_0_.currentSelectVoiceDatas)
      _ARG_0_:RefreshWheelView()
      _ARG_0_:RefreshFeatureView()
      do return end
      _ARG_3_ = U1.currentSelectVoiceDatas
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInputTextChanged"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.stSearch = CheckNameRetrunName(_ARG_1_, true, 16, true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSortDefault"] = function(_ARG_0_)
    do
      _ARG_0_:OnClickSortByType(ENUM_SORT_TYPE.DEFAULT)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSortLatest"] = function(_ARG_0_)
    do
      _ARG_0_:OnClickSortByType(ENUM_SORT_TYPE.LATEST)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSortOwn"] = function(_ARG_0_)
    do
      _ARG_0_:OnClickSortByType(ENUM_SORT_TYPE.OWN)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSortByType"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:UpdateSortMode(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickClear"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.nCurSelectPlanIndex == U1.List then
        goto lbl_15
        ;(nil).key = 0
        ;(nil).actorID = 0
        ::lbl_15::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_0_.nCurSelectPlanIndex == U1.Roulette then
        goto lbl_27
        ;(nil).key = 0
        ;(nil).actorID = 0
        ::lbl_27::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_0_.nCurSelectPlanIndex == U1.Feature then
        goto lbl_50
        if nil and (nil).subData then
          goto lbl_48
          ;(nil).key = 0
          ;(nil).actorID = 0
          ::lbl_48::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_50::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCollect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U1.ReqChangeCollectInfo(_ARG_0_.currentSelectActorID)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemCollectClicked"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.LoopScrollBox_Actors:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeSelectMode"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV = _ARG_1_
      U1.printf(U1.table.concat({
        U2(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 243, 133, 188, 246, 209, 252, 52, 178, 15, 55, 3, 2, 0, 142, 244, 127),
        U2(163, 23, 110, 34, 200, 179, 223, 95, 216, 148, 185, 168, 195, 237, 30, 179, 83, 47, 31, 2, 56, 221, 160, 99, 195, 162, 173, 253, 216, 163, 66, 164)
      }), U1.tostring(_ARG_1_))
      if _ARG_1_ then
        _ARG_0_.UIRoot.Button_QSure:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Visible)
        _ARG_0_.UIRoot.Button_Quickreplace:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Button_QCancel:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Visible)
        _ARG_0_.UIRoot.Button_Clear:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Visible)
      else
        _ARG_0_.UIRoot.Button_QSure:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Button_Quickreplace:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Visible)
        _ARG_0_.UIRoot.Button_QCancel:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Button_Clear:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteSelectedMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetDataByIndex(_ARG_2_) then
        _ARG_0_:GetDataByIndex(_ARG_2_).key = 0
        _ARG_0_:GetDataByIndex(_ARG_2_).actorID = 0
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMsgContent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (_ARG_0_.lastSelectArea or None) == PersonalityVoice then
        if not (_ARG_0_:_GetCurrentSelectedVoiceByArea() and _ARG_0_:_GetCurrentSelectedVoiceByArea().key) or _ARG_0_:_GetCurrentSelectedVoiceByArea().key == 0 then
          return
        end
      else
        if not (_ARG_0_.selectItem and _ARG_0_.selectItem.key) or _ARG_0_.selectItem.key == 0 then
          return
        end
        if _ARG_0_.selectItem.bFeatureVoice then
          return
        end
      end
      if not _ARG_0_:CanSetCurrentSelectedItem(_ARG_0_.selectItem.key) then
        return
      end
      if not U3.CheckIsVoiceUnLock(_ARG_0_.selectItem.key) then
        return
      end
      if _ARG_0_:GetDataByIndex(_ARG_2_) then
        _ARG_0_:GetDataByIndex(_ARG_2_).actorID, _ARG_0_:GetDataByIndex(_ARG_2_).key = _ARG_0_.selectItem.actorID, _ARG_0_.selectItem.key
      end
      if not true then
      end
      do return end
      _ARG_0_ = U1[75]
    end
  end,
  ["CanSetCurrentSelectedItem"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.nCurSelectPlanIndex == List then
      elseif _ARG_0_.nCurSelectPlanIndex == Roulette then
      end
      if _ARG_0_.currentSelectWheelVoiceDatas and U1.next(_ARG_0_.currentSelectWheelVoiceDatas) then
        goto lbl_28
        if (nil).key == _ARG_1_ then
          return false
        end
        ::lbl_28::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SelectDefaultActor"] = function(_ARG_0_)
    do
      if _ARG_0_.args then
        if type(_ARG_0_.args) == U1(247, 19, 98, 58, 200) then
        else
        end
        if tonumber(_ARG_0_.args) then
          _ARG_0_ = _ARG_0_
          if _ARG_0_.LoopScrollBox_Actors:GetItemData(98).ActorItemID == tonumber(_ARG_0_.args) then
            return
          end
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_:ResetDefaultActor()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetDefaultActor"] = function(_ARG_0_)
    do
      goto lbl_18
      if (nil).ActorID == GetDefaultActorID() then
        return
      end
      ::lbl_18::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVoicePack"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.LoopScrollBox_Actors:GetItemData((_ARG_0_.LoopScrollBox_Actors:GetSelectIndex())) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshFilterItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.text)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectFilterItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:OnClickSortByType(_ARG_2_.type)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshLanguageItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.text)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectLanguageItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:FilterPersonalityVoiceData(_ARG_0_.currentPersonalityVoiceDatas)
      _ARG_0_.scrollBoxPersonalityVoice:SetData(_ARG_0_.filteredPersonalityVoiceList)
      _ARG_0_.scrollBoxPersonalityVoice:Deselect()
      _ARG_0_.selectedPersonalityItem = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshPlanItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.text)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectPlanItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnClickPlan(_ARG_1_, _ARG_2_.planID, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFeatureSwitchPanel"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 226, 136, 187, 234, 211, 234, 15, 145, 6, 51, 20, 3, 63, 132, 195, 109),
        U1(234, 6, 99, 62, 253, 160, 158, 95, 204)
      }))
      if LobbySystem.CheckOpen(BP_EUNM_NEW_ACTOR_VOICE_FEATURES_SWITCH_V2) then
        _ARG_0_.UIRoot.CanvasPanel_VoiceShow:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        if _ARG_0_.isFeaturePanelShow then
          _ARG_0_.UIRoot.CheckBox_SelectFeature:SetIsChecked(true)
          _ARG_0_:SetVoiceTabShow(3, true)
          _ARG_0_:OnClickHorizontalVoiceTabButton(3)
          _ARG_0_:OnChangeSelectVoiceMode(3)
        else
          _ARG_0_.UIRoot.CheckBox_SelectFeature:SetIsChecked(false)
          _ARG_0_:SetVoiceTabShow(3, false)
          _ARG_0_:OnClickHorizontalVoiceTabButton(1)
          _ARG_0_:OnChangeSelectVoiceMode(1)
        end
      else
        _ARG_0_.UIRoot.CanvasPanel_VoiceShow:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_:SetVoiceTabShow(3, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFeatureSelectStateChanged"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 155, 253, 215, 237, 18, 165, 6, 1, 5, 26, 40, 130, 228, 73),
        U1(247, 19, 116, 51, 238, 169, 145, 84, 199, 152, 169)
      }))
      _ARG_0_.isFeaturePanelShow = not _ARG_0_.isFeaturePanelShow
      _ARG_0_:RefreshFeatureSwitchPanel()
      _ARG_0_:RefreshActorList()
      _ARG_0_:RefreshRightVoicePanel()
      _ARG_0_:RefreshFeatureView()
      _ARG_0_.lastSelectArea = U2.None
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickQuestionButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFeatureView"] = function(_ARG_0_)
    do
      _ARG_0_.ScrollGridSelectFeatureMsg:RefreshAllSubItems()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshSelectedFeatureCategory"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.ScrollGridSelectFeatureMsg:GetItemData(_ARG_2_) then
      end
      if _ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData and U1.next(_ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshSelectedFeatureItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData and (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData)[_ARG_3_]) then
        return
      end
      if (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData and (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData)[_ARG_3_]).key ~= 0 then
        if IsPersonalityVoice((_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData and (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData)[_ARG_3_]).key) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshFeatureVoiceCategory"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.ScrollGridFeatureVoice:GetItemData(_ARG_2_) then
      end
      if _ARG_0_.featureVoiceSubData[_ARG_2_] and U1.next(_ARG_0_.featureVoiceSubData[_ARG_2_]) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshFeatureVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.featureVoiceSubData[_ARG_2_] or not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_] then
        return
      end
      if not _ARG_1_.DragDropItem then
        return
      end
      if U4 then
      end
      if _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].categoryName then
      else
      end
      if _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].unlockType == U5.Normal then
      elseif _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].unlockType == U5.Open then
      elseif _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].unlockType == U5.NotOpen then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FilterHighQualityActor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.highQualityActorList = {}
      if _ARG_1_ and next(_ARG_1_) then
        goto lbl_24
        if (nil).ActorQuality >= U1.ENUM_ACTOR_QUALITY.HIGH then
        end
        ::lbl_24::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshActorList"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateSortMode(_ARG_0_.currentSortType)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshRightVoicePanel"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(209, 23, 102, 36, 200, 178, 152, 104, 201, 154, 165, 252, 240, 230, 30, 164, 22, 18, 17, 8, 56, 157, 160, 121, 213, 129, 187, 182, 223, 234, 33, 178, 2, 38, 21, 4, 40, 177, 241, 116),
        U1(230, 30, 83, 62, 194, 182, 202, 26)
      }) .. tostring(_ARG_0_.isFeaturePanelShow))
      if _ARG_0_.isFeaturePanelShow then
        _ARG_0_.UIRoot.WidgetSwitcher_Voice:SetActiveWidgetIndex(1)
      else
        _ARG_0_.UIRoot.WidgetSwitcher_Voice:SetActiveWidgetIndex(0)
      end
      _ARG_0_:RefreshHightQualityVoiceData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshHightQualityVoiceData"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshCurrentFeatureVoiceData(_ARG_0_.currentSelectActorID)
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCurrentFeatureVoiceData"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.featureVoiceSubData = {}
      if not CDataTable.GetTableData(U1(194, 17, 116, 57, 223, 151, 159, 83, 195, 152, 139, 237, 199, 253, 2, 181, 22, 49), _ARG_1_) then
        return
      end
      if not _ARG_0_.featureVoiceData or not next(_ARG_0_.featureVoiceData) then
        return
      end
      if CDataTable.GetTableByFilter(U1(213, 29, 105, 53, 200, 136, 180, 121, 198, 154), U1(194, 17, 116, 57, 223, 136, 180), _ARG_1_) then
        goto lbl_87
        if (116).VoiceID then
          ;({
            [(116).VoiceID] = {}
          })[(116).VoiceID] or {}[#(({
            [(116).VoiceID] = {}
          })[(116).VoiceID] or {}) + 1] = 116, (116).VoiceID, ({
            [(116).VoiceID] = {}
          })[(116).VoiceID] or {}, #(({
            [(116).VoiceID] = {}
          })[(116).VoiceID] or {}) + 1
        end
        ::lbl_87::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_.featureVoiceSubData[pairs((CDataTable.GetTableByFilter(U1(213, 29, 105, 53, 200, 136, 180, 121, 198, 154), U1(194, 17, 116, 57, 223, 136, 180), _ARG_1_)))] = {}
      if _ARG_0_.featureVoiceData[pairs((CDataTable.GetTableByFilter(U1(213, 29, 105, 53, 200, 136, 180, 121, 198, 154), U1(194, 17, 116, 57, 223, 136, 180), _ARG_1_)))].featureSubTypeInfo then
        goto lbl_184
        if 198 and (198).key and U3.Split(tostring(CDataTable.GetTableData(U1(194, 17, 116, 57, 223, 151, 159, 83, 195, 152, 139, 237, 199, 253, 2, 181, 22, 49), _ARG_1_)[(198).key]), (U1(255))) and next((U3.Split(tostring(CDataTable.GetTableData(U1(194, 17, 116, 57, 223, 151, 159, 83, 195, 152, 139, 237, 199, 253, 2, 181, 22, 49), _ARG_1_)[(198).key]), (U1(255))))) then
          goto lbl_182
          if tonumber(nil) and {
            [(116).VoiceID] = {}
          } and ({
            [(116).VoiceID] = {}
          })[tonumber(nil)] then
            goto lbl_180
            if U4.GetFirstWelcomeVoiceMapByOrigKey((nil).Key) then
            end
            ::lbl_180::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          ::lbl_182::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_184::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickFeatureVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 158, 244, 223, 250, 12, 145, 6, 51, 20, 3, 63, 132, 198, 117),
        U1(234, 17, 101, 31, 217, 164, 157, 26)
      }) .. tostring(_ARG_2_) .. U1(163) .. tostring(_ARG_3_))
      if not _ARG_0_.featureVoiceSubData[_ARG_2_] or not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_] then
        return
      end
      _ARG_0_.selectItem = {
        key = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].originKey or _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].key,
        actorID = (_ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].originKey or _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].key) // 100000,
        groupIndex = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].groupIndex,
        bFeatureVoice = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].bFeatureVoice,
        bFestivalVoice = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].originKey ~= nil
      }
      _ARG_0_.lastSelectArea = U2.None
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragFeatureMsgItemReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 153, 234, 215, 254, 33, 178, 2, 38, 21, 4, 40, 172, 227, 125),
        U1(202, 6, 101, 59, 255, 164, 145, 94, 217, 169, 162, 219, 206, 232, 7, 162, 83)
      }) .. tostring(_ARG_2_) .. U1(163) .. tostring(_ARG_3_) .. U1(163) .. tostring(_ARG_4_))
      if not _ARG_0_.featureVoiceSubData[_ARG_2_] or not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_] then
        return
      end
      _ARG_0_.selectItem = {
        key = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].originKey or _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].key,
        actorID = (_ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].originKey or _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].key) // 100000,
        groupIndex = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].groupIndex,
        bFeatureVoice = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].bFeatureVoice,
        bFestivalVoice = _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].originKey ~= nil
      }
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragFeatureMsgItemCanceled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 153, 234, 215, 254, 33, 178, 2, 38, 21, 4, 40, 172, 227, 125),
        U1(202, 6, 101, 59, 238, 160, 158, 89, 197, 145, 168, 236, 134)
      }) .. tostring(_ARG_2_) .. U1(163) .. tostring(_ARG_3_) .. U1(163) .. tostring(_ARG_4_))
      if _ARG_0_.lastEnteredWidget then
        _ARG_0_:SetWidgetVisible(_ARG_0_.lastEnteredWidget.Image_Hover, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayFeatureVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 141, 244, 215, 224, 33, 178, 2, 38, 21, 4, 40, 183, 255, 115),
        U1(224, 23, 73, 34, 200, 172, 208)
      }) .. tostring(_ARG_2_) .. U1(163) .. tostring(_ARG_3_))
      if not _ARG_0_.featureVoiceSubData[_ARG_2_] or not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_] then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemDropOnSelectedFeatureItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 148, 236, 211, 244, 35, 165, 12, 34, 47, 24, 30, 132, 252, 127),
        U1(224, 6, 101, 50, 235, 164, 145, 78, 213, 143, 168, 193, 210, 236, 26, 231)
      }) .. tostring(_ARG_2_) .. U1(163) .. tostring(_ARG_3_))
      _ARG_0_:SetFeatureMsgContent(_ARG_1_, _ARG_2_, _ARG_3_)
      _ARG_0_:OnDragEnterLeaveSelectedFeatureItemInner(false, _ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragEnterLeaveSelectedFeatureItemInner"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_.lastEnteredWidget then
        _ARG_0_:SetWidgetVisible(_ARG_0_.lastEnteredWidget.Image_Hover, false)
      end
      if _ARG_1_ then
        _ARG_0_.lastEnteredWidget = _ARG_2_
      end
      _ARG_0_:SetWidgetVisible(_ARG_2_.Image_Hover, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSelectVoiceFeatureItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 255, 131, 158, 244, 223, 250, 12, 132, 6, 62, 5, 21, 57, 183, 255, 115),
        U1(224, 23, 70, 51, 204, 181, 133, 72, 197, 180, 185, 237, 203)
      }))
      _ARG_0_.scrollBoxSelectMsg:Select(_ARG_2_)
      _ARG_0_.ScrollGridSelectFeatureMsg:SelectSub(_ARG_2_, _ARG_3_)
      _ARG_0_:OnPlaySelectFeatureVoiceItem(_ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeleteSelectedFeatureMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_) then
        _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_).key = 0
        _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_).actorID = 0
        _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_).groupIndex = nil
        _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_).bFeatureVoice = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlaySelectFeatureVoiceItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData) then
        return
      end
      if (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData)[_ARG_3_] and (_ARG_0_.currentSelectFeatureData[_ARG_2_] and _ARG_0_.currentSelectFeatureData[_ARG_2_].subData)[_ARG_3_].key ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFeatureMsgContent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if (_ARG_0_.lastSelectArea or None) == PersonalityVoice then
        return
      end
      if (_ARG_0_.lastSelectArea or None) == ActorVoice then
        if not (_ARG_0_:_GetCurrentSelectedVoiceByArea() and _ARG_0_:_GetCurrentSelectedVoiceByArea().key) or _ARG_0_:_GetCurrentSelectedVoiceByArea().key == 0 then
          return
        end
      elseif not (_ARG_0_.selectItem and _ARG_0_.selectItem.key) or _ARG_0_.selectItem.key == 0 then
        return
      end
      if not false and not _ARG_0_:IsFeatureGroupMatched(_ARG_0_.selectItem.groupIndex, _ARG_2_) then
        return
      end
      if not _ARG_0_:CanSetCurrentSelectedFeatureItem(_ARG_0_.selectItem.key, _ARG_2_) then
        return
      end
      if not U3.CheckIsVoiceUnLock(_ARG_0_.selectItem.key) then
        return
      end
      if _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_) then
        _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_).actorID, _ARG_0_:GetFeatureDataByIndex(_ARG_2_, _ARG_3_).key = _ARG_0_.selectItem.actorID, _ARG_0_.selectItem.key
      end
      do return end
      _ARG_0_ = U1[228]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFeatureGroupMatched"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        return false
      end
      do return _ARG_1_ == _ARG_2_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanSetCurrentSelectedFeatureItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.nCurSelectPlanIndex ~= Feature then
        return false
      end
      if _ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[_ARG_2_] and (_ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[_ARG_2_]).subData and U1.next(_ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[_ARG_2_] and (_ARG_0_.currentSelectFeatureData and _ARG_0_.currentSelectFeatureData[_ARG_2_]).subData) then
        goto lbl_31
        if (nil).key == _ARG_1_ then
          return false
        end
        ::lbl_31::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFeatureDataByIndex"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.nCurSelectPlanIndex ~= Feature then
        return nil
      end
      if not (_ARG_0_.currentSelectFeatureData[_ARG_1_] and _ARG_0_.currentSelectFeatureData[_ARG_1_].subData) then
        return nil
      end
      do return (_ARG_0_.currentSelectFeatureData[_ARG_1_] and _ARG_0_.currentSelectFeatureData[_ARG_1_].subData)[_ARG_2_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitSelectFeaturePanel"] = function(_ARG_0_)
    do
      _ARG_0_.currentSelectFeatureData = {}
      if CDataTable.GetTable((U1(197, 23, 97, 34, 216, 179, 149, 111, 233, 190, 171, 239))) then
        goto lbl_76
        if tonumber(34) then
          _ARG_0_.currentSelectFeatureData[tonumber(34)] = {
            text = (216).CategoryName,
            key = (216).VoiceKey,
            subData = {}
          }
          if (216).SlotCount and (216).SlotCount > 0 then
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
        ::lbl_76::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitFeatureCategory"] = function(_ARG_0_)
    do
      if _ARG_0_.isFeatureCategoryInited then
        return
      end
      _ARG_0_.isFeatureCategoryInited = true
      _ARG_0_.featureVoiceData = {}
      _ARG_0_ = _ARG_0_
      _ARG_0_.featureVoiceData[nil] = {
        featureType = _ENV[nil].type,
        featureName = U1.LocUtil.GetLocalizeResStr(_ENV[nil].localizeID),
        featureSubTypeInfo = {}
      }
      goto lbl_77
      ::lbl_77::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVoiceUseTime"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_0_.currentVoiceDatas[_ARG_2_] and _ARG_0_.currentVoiceDatas[_ARG_2_].key == _ARG_1_ then
        _ARG_0_.currentVoiceDatas[_ARG_2_].lastUseTime = U2.GetServerTimeInSec(), _ARG_0_.currentVoiceDatas[_ARG_2_]
      end
      ;(require((table.concat({
        U1(224, 30, 105, 51, 195, 181, 222, 86, 207, 154, 164, 235, 136, 197, 24, 160, 26, 33, 32, 10, 60, 136, 229, 120, 224, 159, 184, 254, 197, 183, 43, 184, 4, 59, 3, 38, 33, 128, 233, 127),
        U1(241, 34, 114, 51, 203, 178)
      }))).LoadFileToData_N(require((U1(224, 30, 105, 51, 195, 181, 222, 73, 204, 136, 172, 166, 197, 230, 25, 161, 26, 37, 94, 54, 49, 144, 249, 111, 194, 189, 175, 253, 208, 234, 36, 184, 13, 52, 9, 17))).eQuickMsgUseStatus) or {})[_ARG_1_] = U2.GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResortCurrentVoiceData"] = function(_ARG_0_)
    do
      if not _ARG_0_.currentVoiceDatas or not next(_ARG_0_.currentVoiceDatas) then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_.currentVoiceDatas[nil]._innerIndex = nil, _ARG_0_.currentVoiceDatas[nil]
      _ARG_0_ = _ARG_0_
      table.sort(_ARG_0_.currentVoiceDatas, function(_ARG_0_, _ARG_1_)
        do
          if (_ARG_0_.lastUseTime or 0) > (_ARG_1_.lastUseTime or 0) then
            return true
          end
          if (_ARG_0_.lastUseTime or 0) == (_ARG_1_.lastUseTime or 0) then
            return _ARG_0_._innerIndex < _ARG_1_._innerIndex
          end
          do return false end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshActorScrollBox"] = function(_ARG_0_)
    do
      _ARG_0_:ResortCurrentVoiceData()
      _ARG_0_.scrollBoxActorVoice:SetData(_ARG_0_.currentVoiceDatas)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReselectActorVoiceByKey"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_0_.currentVoiceDatas then
        _ARG_0_.scrollBoxActorVoice:Deselect()
        return
      end
      goto lbl_24
      if nil and (nil).key == _ARG_1_ then
        return
      end
      ::lbl_24::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.scrollBoxActorVoice:Deselect()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPersonalityVoiceScrollBox"] = function(_ARG_0_)
    do
      if not _ARG_0_.scrollBoxPersonalityVoice then
        return
      end
      _ARG_0_.currentPersonalityVoiceDatas = GetPersonalVoiceList() or {}
      _ARG_0_.scrollBoxPersonalityVoice:SetData(_ARG_0_.currentPersonalityVoiceDatas)
      _ARG_0_.scrollBoxPersonalityVoice:Deselect()
      _ARG_0_.selectedPersonalityItem = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragEnterSelectedFeatureItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:OnDragEnterLeaveSelectedFeatureItemInner(true, _ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragLeaveSelectedFeatureItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:OnDragEnterLeaveSelectedFeatureItemInner(false, _ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickFeatureVoiceItemMore"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.featureVoiceSubData[_ARG_2_] or not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_] then
        return
      end
      if not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_] or not _ARG_0_.featureVoiceSubData[_ARG_2_][_ARG_3_].key then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCurrentCollectState"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      if CheckIsActorUnLocked(_ARG_0_.currentSelectActorID) and GetActorExpireDisplay(_ARG_0_.currentSelectActorID) ~= ENUM_UNLOCK_TYPE.LIMIT then
        if GetActorCollectTS(_ARG_0_.currentSelectActorID) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActorCollectStateChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:RefreshCurrentCollectState()
      _ARG_0_.LoopScrollBox_Actors:RefreshAllItems()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVoiceModeTabList"] = function(_ARG_0_)
    do
      if not _ENV() then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.HorizontalBox_VoiceMode, false)
      else
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.HorizontalBox_VoiceMode, true)
      end
      _ARG_0_:RefreshPersonalityVoiceRedDot()
      _ARG_0_.UIRoot.TextBlock_Tactics:SetText(U1.LocUtil.LocalizeResFormat(47420))
      _ARG_0_.UIRoot.TextBlock_Tactics2:SetText(U1.LocUtil.LocalizeResFormat(47420))
      _ARG_0_.UIRoot.TextBlock_Personality:SetText(U1.LocUtil.LocalizeResFormat(45927))
      _ARG_0_.UIRoot.TextBlock_Personality2:SetText(U1.LocUtil.LocalizeResFormat(45927))
      _ARG_0_:SetVoiceMode(U2.Tactics)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPersonalityVoiceRedDot"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVoiceMode"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_0_.voiceMode and _ARG_0_.voiceMode ~= _ARG_1_ and ((_ARG_0_.lastSelectArea or None) == ActorVoice or (_ARG_0_.lastSelectArea or None) == PersonalityVoice) then
        _ARG_0_.selectItem = nil
        _ARG_0_.lastSelectArea = None
      end
      _ARG_0_.voiceMode = _ARG_1_
      if _ARG_1_ == U1.Personality then
        _ARG_0_.UIRoot.WidgetSwitcher_Tactics:SetActiveWidgetIndex(1)
        _ARG_0_.UIRoot.WidgetSwitcher_Personality:SetActiveWidgetIndex(0)
        _ARG_0_.UIRoot.WidgetSwitcher_VoiceMode:SetActiveWidgetIndex(1)
        if _ARG_0_.scrollBoxPersonalityVoice then
          _ARG_0_.scrollBoxPersonalityVoice:RefreshAllItems()
        end
        if _ARG_0_.scrollBoxActorVoice then
          _ARG_0_.scrollBoxActorVoice:Deselect()
        end
      else
        _ARG_0_.UIRoot.WidgetSwitcher_Tactics:SetActiveWidgetIndex(0)
        _ARG_0_.UIRoot.WidgetSwitcher_Personality:SetActiveWidgetIndex(1)
        _ARG_0_.UIRoot.WidgetSwitcher_VoiceMode:SetActiveWidgetIndex(0)
        if _ARG_0_.scrollBoxPersonalityVoice then
          _ARG_0_.scrollBoxPersonalityVoice:Deselect()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTacticsButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:SetVoiceMode(U1.Tactics)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPersonalityButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:SetVoiceMode(U1.Personality)
      _ARG_0_:_MarkPersonalityVoiceTabViewed()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_MarkPersonalityVoiceTabViewed"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      __super.OnClose(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetCurrentSelectedPersionalityVoice"] = function(_ARG_0_)
    do
      if _ARG_0_.selectedPersonalityItem and _ARG_0_.selectedPersonalityItem.key then
        printf(table.concat({
          U1(214, 59, 95, 5, 200, 181, 132, 83, 206, 154, 146, 217, 211, 224, 20, 172, 62, 39, 3, 21, 60, 150, 229, 48, 239, 170, 184, 236, 245, 236, 21, 165, 6, 60, 20, 37, 40, 141, 245, 121),
          U1(247, 23, 100, 6, 200, 179, 131, 83, 207, 147, 172, 228, 207, 253, 14, 145, 28, 43, 19, 3, 125, 129, 233, 105, 219, 205, 187, 234, 217, 244, 71, 164, 13, 51, 16, 5, 37, 142, 228, 54),
          U1(163, 25, 101, 47, 151, 228, 131, 22, 128, 136, 163, 196, 201, 234, 28, 253, 86, 49)
        }), tostring(_ARG_0_.selectedPersonalityItem.key), tostring(_ARG_0_.selectedPersonalityItem.unLock))
        return _ARG_0_.selectedPersonalityItem
      end
      if not (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetSelectIndex()) or (_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetSelectIndex()) <= 0 then
        return nil
      end
      do return (_ARG_0_.scrollBoxPersonalityVoice:GetItemData(_ARG_0_.scrollBoxPersonalityVoice and _ARG_0_.scrollBoxPersonalityVoice:GetSelectIndex())) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetCurrentSelectedVoiceByArea"] = function(_ARG_0_)
    do
      if (_ARG_0_.lastSelectArea or None) == Wheel then
        if _ARG_0_.lastClickWheelIndex and _ARG_0_.currentSelectWheelVoiceDatas then
        end
      elseif (_ARG_0_.lastSelectArea or None) == SelectMsg then
        if _ARG_0_.scrollBoxSelectMsg and _ARG_0_.scrollBoxSelectMsg:GetSelectIndex() and _ARG_0_.scrollBoxSelectMsg:GetSelectIndex() > 0 then
        end
      elseif (_ARG_0_.lastSelectArea or None) == ActorVoice then
        if _ARG_0_.scrollBoxActorVoice and _ARG_0_.scrollBoxActorVoice:GetSelectIndex() and 0 < _ARG_0_.scrollBoxActorVoice:GetSelectIndex() then
        end
      elseif (_ARG_0_.lastSelectArea or None) == PersonalityVoice then
      end
      if _ARG_0_:_GetCurrentSelectedPersionalityVoice() and _ARG_0_:_GetCurrentSelectedPersionalityVoice().key == 0 then
        return nil
      end
      do return (_ARG_0_:_GetCurrentSelectedPersionalityVoice()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPersonalityVoicePanel"] = function(_ARG_0_)
    do
      if not (_ARG_0_:_GetCurrentSelectedVoiceByArea() and _ARG_0_:_GetCurrentSelectedVoiceByArea().key and IsPersonalityVoice(_ARG_0_:_GetCurrentSelectedVoiceByArea().key) or false) then
        return
      end
      if CheckIsVoiceUnLock(_ARG_0_:_GetCurrentSelectedVoiceByArea().key) then
      else
      end
      if U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key) then
      end
      if (U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key) and U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key).Language or nil) and (U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key) and U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key).Language or nil) ~= U2() and U1.CDataTable.GetTableDataByFilter(U1.FuncUtil.GetLanguageTableName(), U2(239, 19, 110, 49, 216, 160, 151, 95, 227, 146, 169, 237), U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key) and U1.CDataTable.GetTableData(U2(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedVoiceByArea().key).Language or nil) then
      end
      if GetPersonalActorNameByVoiceID(_ARG_0_:_GetCurrentSelectedVoiceByArea().key) and GetPersonalActorNameByVoiceID(_ARG_0_:_GetCurrentSelectedVoiceByArea().key) ~= U2() then
      else
      end
      if ((_ARG_0_.lastSelectArea or U3.None) == U3.Wheel or (_ARG_0_.lastSelectArea or U3.None) == U3.SelectMsg) and U4 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Team"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:_SetBroadcastGlobal(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Global"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:_SetBroadcastGlobal(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetBroadcastGlobal"] = function(_ARG_0_, _ARG_1_)
    do
      if (_ARG_0_.lastSelectArea or None) == None or (_ARG_0_.lastSelectArea or None) == ActorVoice then
        return
      end
      if not (_ARG_0_:_GetCurrentSelectedVoiceByArea() and _ARG_0_:_GetCurrentSelectedVoiceByArea().key) or _ARG_0_:_GetCurrentSelectedVoiceByArea().key == 0 then
        return
      end
      if (_ARG_0_.personalityVoiceBroadcastCache[_ARG_0_:_GetCurrentSelectedVoiceByArea().key] or false) == _ARG_1_ and ((_ARG_0_.lastSelectArea or None) == PersonalityVoice or (_ARG_0_:_GetCurrentSelectedVoiceByArea().bIncludeAll or false) == _ARG_1_) then
        return
      end
      _ARG_0_.personalityVoiceBroadcastCache[_ARG_0_:_GetCurrentSelectedVoiceByArea().key] = _ARG_1_
      if (_ARG_0_.lastSelectArea or None) == Wheel then
        _ARG_0_:_GetCurrentSelectedVoiceByArea().bIncludeAll = _ARG_1_
      elseif (_ARG_0_.lastSelectArea or None) == SelectMsg then
        _ARG_0_:_GetCurrentSelectedVoiceByArea().bIncludeAll = _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUnlockVoiceButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_:_GetCurrentSelectedPersionalityVoice() or not _ARG_0_:_GetCurrentSelectedPersionalityVoice().key then
        return
      end
      if _ARG_0_:_GetCurrentSelectedPersionalityVoice().unLock then
        return
      end
      if not CDataTable.GetTableData(U1(211, 23, 114, 37, 194, 175, 145, 86, 201, 137, 180, 222, 201, 224, 20, 162, 48, 36, 23), _ARG_0_:_GetCurrentSelectedPersionalityVoice().key) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetPersonalitySearchText"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_PersonalitySearch:SetActiveWidgetIndex(0)
      if _ARG_0_.UIRoot.EditableTextBox_PersonalityText then
        _ARG_0_.UIRoot.EditableTextBox_PersonalityText:SetIsReadOnly(true)
        _ARG_0_.UIRoot.EditableTextBox_PersonalityText:SetHintText(LocUtil.GetLocalizeResStr(52007))
      end
      _ARG_0_.strPersonalitySearch = U1()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPersonalitySearch"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.bInPersonalitySearch then
        _ARG_0_.bInPersonalitySearch = false
      else
        _ARG_0_.bInPersonalitySearch = true
      end
      _ARG_0_.UIRoot.WidgetSwitcher_PersonalitySearch:SetActiveWidgetIndex(1)
      _ARG_0_.UIRoot.CommonSearchItem_Personality.message_input:SetKeyboardFocus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCancelPersonalitySearch"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ResetPersonalitySearchText()
      _ARG_0_.strPersonalitySearch = U1()
      _ARG_0_:FilterPersonalityVoiceData(_ARG_0_.currentPersonalityVoiceDatas)
      _ARG_0_.scrollBoxPersonalityVoice:SetData(_ARG_0_.filteredPersonalityVoiceList)
      _ARG_0_.scrollBoxPersonalityVoice:Deselect()
      _ARG_0_.selectedPersonalityItem = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInputPersonalityTextChanged"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.strPersonalitySearch = CheckNameRetrunName(_ARG_1_, true, 16, true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FilterPersonalityVoiceData"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.filteredPersonalityVoiceList = _ARG_0_:FilterPersonalityVoiceDataByLanguage((_ARG_0_:FilterPersonalityVoiceDataBySearch(_ARG_1_)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FilterPersonalityVoiceDataBySearch"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and next(_ARG_1_) then
        goto lbl_32
        ::lbl_32::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FilterPersonalityVoiceDataByLanguage"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_0_.ComboBox_Language and _ARG_0_.ComboBox_Language:GetSelectData() and (_ARG_0_.ComboBox_Language and _ARG_0_.ComboBox_Language:GetSelectData()).languageCode) or (_ARG_0_.ComboBox_Language and _ARG_0_.ComboBox_Language:GetSelectData() and (_ARG_0_.ComboBox_Language and _ARG_0_.ComboBox_Language:GetSelectData()).languageCode) == _ENV(226, 30, 108) then
        return _ARG_1_
      end
      if _ARG_1_ and U1.next(_ARG_1_) then
        goto lbl_40
        if (nil).language == (_ARG_0_.ComboBox_Language and _ARG_0_.ComboBox_Language:GetSelectData() and (_ARG_0_.ComboBox_Language and _ARG_0_.ComboBox_Language:GetSelectData()).languageCode) then
        end
        ::lbl_40::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPersonalitySearchConfirm"] = function(_ARG_0_)
    do
      _ARG_0_:FilterPersonalityVoiceData(_ARG_0_.currentPersonalityVoiceDatas)
      _ARG_0_.scrollBoxPersonalityVoice:SetData(_ARG_0_.filteredPersonalityVoiceList)
      _ARG_0_.scrollBoxPersonalityVoice:Deselect()
      _ARG_0_.selectedPersonalityItem = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PrepareLanguageData"] = function(_ARG_0_)
    do
      if _ARG_0_.languageData then
        return
      end
      _ARG_0_.languageData = {}
      goto lbl_69
      if (nil).languageCode ~= U2() then
        if (nil).languageCode == U2(226, 30, 108) then
        elseif CDataTable.GetTableDataByFilter(FuncUtil.GetLanguageTableName(), U2(239, 19, 110, 49, 216, 160, 151, 95, 227, 146, 169, 237), (nil).languageCode) then
        end
        if CDataTable.GetTableDataByFilter(FuncUtil.GetLanguageTableName(), U2(239, 19, 110, 49, 216, 160, 151, 95, 227, 146, 169, 237), (nil).languageCode).DisplayName and CDataTable.GetTableDataByFilter(FuncUtil.GetLanguageTableName(), U2(239, 19, 110, 49, 216, 160, 151, 95, 227, 146, 169, 237), (nil).languageCode).DisplayName ~= U2() then
          _ARG_0_.languageData[#_ARG_0_.languageData + 1] = {
            languageCode = (nil).languageCode,
            text = CDataTable.GetTableDataByFilter(FuncUtil.GetLanguageTableName(), U2(239, 19, 110, 49, 216, 160, 151, 95, 227, 146, 169, 237), (nil).languageCode).DisplayName
          }
        end
      end
      ::lbl_69::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPersonalityVoiceUnlocked"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.scrollBoxPersonalityVoice then
        _ARG_0_ = _ARG_0_
        if _ARG_0_.scrollBoxPersonalityVoice:GetItemData(nil) and _ARG_0_.scrollBoxPersonalityVoice:GetItemData(nil).key == _ARG_3_ then
          _ARG_0_.scrollBoxPersonalityVoice:GetItemData(nil).unLock = true
          if _ARG_0_.scrollBoxPersonalityVoice:GetIndexOfWidget(nil) then
            if _ARG_0_.scrollBoxPersonalityVoice:GetIndexOfWidget(nil).Anim_Refresh then
            end
          end
        else
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_:RefreshPersonalityVoicePanel()
      if _ARG_0_.scrollBoxPersonalityVoice:GetSetData() and next((_ARG_0_.scrollBoxPersonalityVoice:GetSetData())) then
        _ARG_0_ = _ARG_0_
        if _ARG_0_.scrollBoxPersonalityVoice:GetSetData()[_ARG_0_.scrollBoxPersonalityVoice:GetItemData(nil)].key == _ARG_3_ then
          if _ARG_0_.scrollBoxPersonalityVoice:GetIndexOfWidget((_ARG_0_.scrollBoxPersonalityVoice:GetItemData(nil))) and _ARG_0_.scrollBoxPersonalityVoice:GetIndexOfWidget((_ARG_0_.scrollBoxPersonalityVoice:GetItemData(nil))).Anim_Refresh then
          end
        else
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitPersonalityVoicePanel"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.TextBlock_Team:SetText(LocUtil.GetLocalizeResStr(301189))
      _ARG_0_.UIRoot.TextBlock_Team2:SetText(LocUtil.GetLocalizeResStr(301189))
      _ARG_0_.UIRoot.TextBlock_Global:SetText(LocUtil.GetLocalizeResStr(4462))
      _ARG_0_.UIRoot.TextBlock_Global2:SetText(LocUtil.GetLocalizeResStr(4462))
      _ARG_0_.UIRoot.TextBlock_ScopeType:SetText(LocUtil.GetLocalizeResStr(814256))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
