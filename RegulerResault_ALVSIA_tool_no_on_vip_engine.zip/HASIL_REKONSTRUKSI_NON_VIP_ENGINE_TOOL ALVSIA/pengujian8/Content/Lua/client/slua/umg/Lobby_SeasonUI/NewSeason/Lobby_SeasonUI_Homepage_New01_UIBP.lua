do return require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(102, 238, 86, 32, 149)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 15, 246, 177, 18, 104, 135, 211, 42, 6, 97, 8, 208, 164, 11, 22, 130, 51, 246))), nil, {
  ViewMode = 1,
  TeamSize = 1,
  curVersion = nil,
  rewardList = {},
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.slapType = None
      _ARG_0_.seasonTitleSlapStatus = {}
      _ARG_0_.bExpand = false
      _ARG_0_.switchAni = _ARG_2_
      _ARG_0_.bSwitchIsPromo = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_:PlayAudio(U1.sound_config.Season_HomePage_Enter, true)
      _ARG_0_.LoopScrollBox_PromotionProgress = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.LoopScrollBox_PromotionProgress, (U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 246, 181, 42, 32, 185, 221, 37, 1, 111, 56, 241, 170, 68, 7, 140, 46, 198, 129, 115, 80, 128, 213, 4, 22, 103, 4, 221, 177),
        U2(43, 203, 67, 54, 139, 121, 158, 144, 87, 6, 138, 15, 211, 170, 34, 99, 154, 198, 46, 12, 120, 56, 235, 187, 64, 25, 188, 21, 218, 138, 13)
      })))
      _ARG_0_.LoopScrollBox_NewPromotionProgress = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.LoopScrollBox_0, (U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 246, 181, 42, 32, 185, 221, 37, 1, 111, 56, 241, 170, 68, 7, 140, 46, 198, 129, 115, 80, 128, 213, 4, 22, 103, 4, 221, 177),
        U2(43, 203, 67, 54, 139, 121, 158, 144, 87, 6, 138, 15, 211, 170, 34, 99, 154, 198, 46, 12, 120, 56, 235, 187, 64, 25, 188, 21, 218, 138, 13)
      })))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnAnimationStartedEvent(U1(67, 227, 83, 54, 143, 57), _ARG_0_.OnAnimationStarted, _ARG_0_)
      _ARG_0_:AddOnAnimationStartedEvent(U1(68, 236, 94, 62, 185, 4, 165, 150, 65, 7, 155, 4, 226, 186), _ARG_0_.OnAnimationStarted, _ARG_0_)
      _ARG_0_:_AddLeftBottomOnClickEvents()
      _ARG_0_:_AddMidTopOnClickEvents()
      _ARG_0_:_AddMidCenterOnClickEvents()
      _ARG_0_:_AddPromotionOnClickEvents()
      _ARG_0_:_AddTypeEvents()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddLeftBottomOnClickEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Module, _ARG_0_.OnClickButtonModule, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Exchange, _ARG_0_.OnClickExchange, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionGuide, _ARG_0_.OnClickPromotionGuideButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Reward, _ARG_0_.OnClickRewardButton, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_Item_BP, _ENV(74, 236, 116, 63, 143, 52, 185, 182, 65, 1, 158, 19, 226, 180, 33, 108, 148, 209, 44), _ARG_0_.OnClickSegReward, _ARG_0_)
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot[_ENV(70, 237, 90, 62, 137, 57, 141, 182, 65, 1, 158, 15, 193, 136, 18, 77, 170) .. U2.tostring(_ENV(74, 236, 116, 63, 143, 52, 185, 182, 65, 1, 158, 19, 226, 180, 33, 108, 148, 209, 44) - 1)] then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddMidTopOnClickEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Tourist, _ARG_0_.OnClickTouristButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Zone_Details, _ARG_0_.OnClickZoneButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_12, _ARG_0_.OnClickViewChangeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_1, _ARG_0_.OnClickViewButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_0, _ARG_0_.OnClickViewModeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_4, _ARG_0_.OnClickViewModeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_6, _ARG_0_.OnClickSingleMode, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_8, _ARG_0_.OnClickDoubleMode, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_10, _ARG_0_.OnClickTeamMode, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddMidCenterOnClickEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CloseTips, _ARG_0_.OnClickCloseTipsButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Score, _ARG_0_.OnClickSegButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Hide_Tips, _ARG_0_.OnClickHideTipsButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Seg, _ARG_0_.OnClickSegButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Title, _ARG_0_.OnClickSegTitleButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Play, _ARG_0_.OnClickPlay, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddPromotionOnClickEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GoPromotionReward, _ARG_0_.OnClickGoPromotionRewardButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GoPromotion, _ARG_0_.OnClickGoPromotionButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Challenge, _ARG_0_.OnClickChallengeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Promo_Normal_Protect, _ARG_0_.OnClickChallengeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Promo_Challenge, _ARG_0_.OnClickChallengeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Promo_Change_Help, _ARG_0_.OnClickChallengeButton, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionHelp, _ARG_0_.OnClickButtonPromotionHelp, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionHelp_1, _ARG_0_.OnClickButtonPromotionHelp, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionHelp_2, _ARG_0_.OnClickButtonPromotionHelp, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionHelp_3, _ARG_0_.OnClickButtonPromotionHelp, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionSetting, _ARG_0_.OnClickButtonPromotionSetting, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionSetting_1, _ARG_0_.OnClickButtonPromotionSetting, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PromotionProtect, _ARG_0_.OnClickButtonPromotionProtect, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Promo_Switch, _ARG_0_.OnClickButton_Promo_Switch, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AddTypeEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddCommonEvent(EVENTTYPE_ROLEINFO, EVENTID_SEASON_CONQUEROR_INFO, _ARG_0_.OnSeasonConquerorInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_SEASON_CHANGE, _ARG_0_.OnRefreshMainUIInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_SEASON_CONFIG, EVENTID_GET_SEASON_CONFIG, _ARG_0_.OnRefreshSeasonConfig, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_ROLEINFO, EVENTID_SEASON_CHANLLENGE_SCORE, _ARG_0_.OnRefreshChanllengeInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_SEASON_AWARD, EVENTID_SEASON_UPDATE_AWARD, _ARG_0_.OnSeasonAwardUpdate, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_SEGMENT_TITLE, EVENTID_SEGMENT_TITLE_GET_DETAIL_RSP, _ARG_0_.OnGetSegmentTitleData, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_SEGMENT_TITLE, EVENTID_SEGMENT_TITLE_SET_RSP, _ARG_0_.OnRefreshSegmentTitle, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_SEGMENT_TARGET, EVENTID_SEGMENT_TARGET_GET_INFO_RSP, _ARG_0_.OnGetSegmentTargetData, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_COME_BACK, EVENTID_RETURNACTIVITY_MAIN_UI_OPEN, _ARG_0_.OnReturnActivityMainUIOpen, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_COME_BACK, EVENTID_RETURNACTIVITY_MAIN_UI_CLOSE, _ARG_0_.OnReturnActivityMainUIClose, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_WEAPONSTRENGTH, EVENTID_SEASON_WEAPONSTRENGTH_DATA_RSP, _ARG_0_.OnWeaponStrengthDataRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_WEAPONSTRENGTH, EVENTID_SEASON_WEAPONSTRENGTH_WEEKLY_AWARD, _ARG_0_.OnWeaponStrengthWeeklyAward, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_PROMOTION, EVENTID_PROMOTION_BASE_CONFIG, _ARG_0_.OnPromotionBaseConfig, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_UPDATE_HIGH_SEGMENT, _ARG_0_.OnRefreshSegment, _ARG_0_)
      _ARG_0_:AddCommonEvent(EVENTTYPE_ROLEINFO, EVENTID_SEASON_UPDATE, _ARG_0_.OnRefreshRankInfo, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      U1.Enter()
      _ARG_0_:RequestData()
      _ARG_0_:RefreshContentInfo()
      _ARG_0_:InitWidgetState()
      _ARG_0_:RefreshSeasonCoinNum()
      _ARG_0_:RefreshReward()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      U1.log(U1.bWriteLog and U2(86, 231, 86, 32, 137, 57, 135, 182, 106, 44, 156, 61, 230, 168, 44, 105, 144, 237, 9, 6, 97, 87, 147, 144, 112, 61, 161, 16, 169, 135, 51, 77, 141, 205, 32))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_15, false)
      _ARG_0_.UIRoot.Fx_Image_31:SetColorAndOpacity(U1.FLinearColor(1, 1, 1, 0))
      _ARG_0_.UIRoot.WidgetSwitcher_6:SetActiveWidgetIndex(0)
      _ARG_0_:SetSeasonYearImage()
      if _ARG_0_.switchAni then
        _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Anim_SwitchTab, 0, 1, 0, 1)
      else
        _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Fadein, 0, 1, 0, 1)
      end
      _ARG_0_.UIRoot.Button_PromotionHelp:SetColorAndOpacity(U1.FLinearColor(1, 1, 1, 1))
      if _ARG_0_.UIRoot.Image_Bar then
        _ARG_0_.UIRoot.Image_Bar:SetColorAndOpacity(U1.FLinearColor(1, 1, 1, 1))
      end
      _ARG_0_.UIRoot.WidgetSwitcher_3:SetActiveWidgetIndex(0)
      _ARG_0_.UIRoot.WidgetSwitcher_5:SetActiveWidgetIndex(0)
      _ARG_0_:SetRewardIcon()
      _ARG_0_:UpdateUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if UIManager.IsUIShow(UIManager.UI_Config.Lobby_Season_Target_Setting_UIBP) then
        UIManager.CloseUI(UIManager.UI_Config.Lobby_Season_Target_Setting_UIBP)
      end
      _ARG_0_.UIRoot.Button_CloseTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.CanvasPanel_28:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.CanvasPanel_Zone_Tips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickChallengeButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if _ARG_0_.bSwitchIsPromo then
        UIManager.ShowUI(UIManager.UI_Config.Lobby_Season_PromotionProtection_Popup_UIBP)
      else
        _ARG_0_:RefreshChanllengeTips()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCloseTipsButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.UIRoot.Button_CloseTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.CanvasPanel_28:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.CanvasPanel_Zone_Tips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTouristButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      UIManager.ShowUI(UIManager.UI_Config.AccessRestriction)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRewardButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPromotionGuideButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_:RefreshReward()
      _ARG_0_:SetRewardIcon()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoPromotionRewardButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoPromotionButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if _ARG_0_:GetParentUI() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSegButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.UIRoot.CanvasPanel_tip:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      if U3.GetConquerorScore(_ARG_0_.zone_id, U2[_ARG_0_.ViewMode] .. U1[_ARG_0_.TeamSize]) == nil then
        return
      end
      if U5.GetPromotionStartSeasonId() and U5.GetPromotionStartSeasonId() <= DataMgr.season_id then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSegTitleButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):IsSegmentTitleSwitchOpen() and _ARG_0_.rank_level) or _ARG_0_.rank_level < U1 then
        return
      end
      if not (_ARG_0_.TeamSize and _ARG_0_.ViewMode) or not _ARG_0_.zone_id then
        return
      end
      if not (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):ConvertSegmentToShow(_ARG_0_.rank_level) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U5[U4[_ARG_0_.ViewMode] .. U3[_ARG_0_.TeamSize]])) or not next((ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U5[U4[_ARG_0_.ViewMode] .. U3[_ARG_0_.TeamSize]]))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickZoneButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.UIRoot.Button_CloseTips:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      _ARG_0_.UIRoot.CanvasPanel_Zone_Tips:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_.UIRoot.Lobby_Season_Zone_Tips_UIBP.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(44809))
      _ARG_0_.UIRoot.Lobby_Season_Zone_Tips_UIBP.TextBlock_ServeHighest:SetText(LocUtil.GetLocalizeResStr(44810))
      _ARG_0_.UIRoot.Lobby_Season_Zone_Tips_UIBP.TextBlock_Serve:SetText(LocUtil.GetLocalizeResStr(44811))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSegReward"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig() == nil or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig())) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHideTipsButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.UIRoot.CanvasPanel_tip:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickExchange"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      UIManager.ShowUI(UIManager.UI_Config.SeasonAwardMain_UIBP, 4, {
        seasonIndex = U1.ESeasonType.Classic
      })
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonModule"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonGuide"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonPromotionHelp"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonPromotionSetting"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.Lobby_Season_Promotio_Popup_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonPromotionProtect"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 52, 222, 182),
        U1(102, 233, 117, 38, 146, 35, 189, 145, 101, 22, 156, 61, 236, 172, 36, 97, 155, 226, 53, 12, 98, 2, 193, 187)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPlay"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 52, 222, 182),
        U1(102, 233, 103, 63, 135, 46)
      }))
      _ARG_0_:PlayAudio(sound_config.click)
      if not require((U1(102, 238, 94, 54, 136, 35, 252, 156, 90, 9, 158, 63, 237, 246, 56, 103, 170, 199, 51, 10, 122))).CanClickNow(require((U1(102, 238, 94, 54, 136, 35, 252, 156, 90, 9, 158, 63, 237, 246, 56, 103, 170, 199, 51, 10, 122))).ClickFrequencyLimit.ConquerorVideoPlayLimit) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshSeasonConfig"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshMainUIInfo"] = function(_ARG_0_)
    do
      Enter()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshChanllengeInfo"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshChanllengeInfo()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSeasonAwardUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 36, 215, 190),
        U1(118, 237, 89, 18, 145, 54, 160, 155, 96, 20, 151, 49, 247, 189)
      }))
      _ARG_0_:UpdateUI(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshSegmentTitle"] = function(_ARG_0_)
    do
      if U3.FuncUtil.GetRankTableData(_ARG_0_.rank_level, U3.DataMgr.season_id) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetSegmentTitleData"] = function(_ARG_0_)
    do
      if _ARG_0_.slapType ~= None and _ARG_0_.slapType ~= SegmentTitle then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 48, 215, 171),
          U2(86, 231, 80, 62, 131, 57, 166, 171, 92, 16, 159, 53, 199, 185, 57, 111, 213, 218, 38, 16, 54, 8, 214, 167, 64, 6, 182, 9, 179, 187, 49, 127, 149, 199, 51)
        }))
        return
      end
      _ARG_0_:ShowSegmentTitleSlapUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetSegmentTargetData"] = function(_ARG_0_)
    do
      _ARG_0_:ShowSegmentTargetSettingSlapUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReturnActivityMainUIOpen"] = function(_ARG_0_)
    do
      _ARG_0_:Collapsed()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReturnActivityMainUIClose"] = function(_ARG_0_)
    do
      _ARG_0_:SelfHitTestInvisible()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWeaponStrengthDataRsp"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWeaponStrengthWeeklyAward"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 32, 215, 190),
        U1(117, 237, 89, 0, 146, 37, 183, 145, 82, 16, 155, 7, 230, 189, 38, 98, 140, 243, 48, 2, 100, 3)
      }))
      _ARG_0_:ShowWeaponStrengthWeeklyAward()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPromotionBaseConfig"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 39, 192, 176),
        U1(104, 237, 67, 58, 137, 57, 144, 158, 70, 1, 176, 63, 237, 190, 36, 105)
      }))
      if _ARG_0_.topLeftBtns ~= nil then
        _ARG_0_.topLeftBtns:RefreshButtonExpand()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSeasonConquerorInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 36, 215, 190),
        U1(118, 237, 89, 16, 137, 57, 163, 138, 80, 22, 156, 34, 202, 182, 43, 97)
      }))
      if _ARG_3_ and _ARG_3_.rank_no and 0 < _ARG_3_.rank_no then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Play, true, true)
      else
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Play, false, true)
      end
      do return end
      _ARG_2_ = U1[89]
    end
  end,
  ["OnRefreshSegment"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 37, 215, 185),
        U1(119, 231, 68, 59, 181, 50, 181, 146, 80, 10, 135)
      }))
      _ARG_0_:UpdateUI(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshRankInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 37, 215, 185),
        U1(119, 231, 68, 59, 180, 54, 188, 148, 124, 10, 149, 63, 163, 186, 31, 107, 147, 192, 34, 16, 126, 71, 159, 239)
      }) .. tostring(_ARG_3_))
      if _ARG_3_ then
        if U3[U2.GetBestMode()][1] and U3[U2.GetBestMode()][2] and _ARG_0_.ViewMode == U3[U2.GetBestMode()][1] and _ARG_0_.TeamSize == U3[U2.GetBestMode()][2] then
        end
      end
      do return end
      _ARG_3_ = _ENV[149]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickViewChangeButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.popup_v1)
      _ARG_0_:ResetButtonState()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickViewButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ResetButtonState()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetButtonState"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.CanvasPanel_1:GetVisibility() == UEnums.ESlateVisibility.Collapsed then
        _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_1:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      else
        _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickViewModeButton"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.ViewMode = _ARG_0_.ViewMode == 1 and 2 or 1
      _ARG_0_:OnTeamSizeChange()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSingleMode"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.TeamSize = 1
      _ARG_0_:OnTeamSizeChange()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDoubleMode"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.TeamSize = 2
      _ARG_0_:OnTeamSizeChange()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTeamMode"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.TeamSize = 3
      _ARG_0_:OnTeamSizeChange()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamSizeChange"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 38, 118, 19, 211, 171),
        U1(96, 215, 126, 115, 132, 5, 183, 142, 118, 11, 157, 33, 246, 189, 63, 97, 135, 146, 122, 67)
      }) .. tostring(_ARG_1_))
      if _ARG_1_ then
      end
      if _ARG_0_.slapType == U3.None then
      end
      do return end
      _ARG_1_ = U1.ReqConquerorInfo
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestData"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshContentInfo"] = function(_ARG_0_)
    do
      _ARG_0_:InitPromotionInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitWidgetState"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item then
        _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item.Button_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      _ARG_0_.UIRoot.CanvasPanel_tip:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if U2.CheckSeasonCoinExchangeClosed() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitChildUI"] = function(_ARG_0_)
    do
      if not _ARG_0_.seasonTargetUI then
        _ARG_0_.seasonTargetUI = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.Border_8, UIManager.UI_Config.Lobby_Season_Segment_Target_Tips)
      end
      if not _ARG_0_.topLeftBtns then
        _ARG_0_.topLeftBtns = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_ButtonExpand, UIManager.UI_Config.Lobby_SeasonUI_Homepage_TopLeft_UIBP, _ARG_0_.selectMode)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSeasonYearImage"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Image_2026 and require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 60, 111, 2, 195, 189, 11, 1, 151, 41, 255, 230, 46, 123, 132, 209, 56, 29, 89, 14, 215, 190),
        U1(119, 221, 66, 39, 143, 59)
      }))).GetSeasonYearId() and require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 60, 111, 2, 195, 189, 11, 1, 151, 41, 255, 230, 46, 123, 132, 209, 56, 29, 89, 14, 215, 190),
        U1(119, 221, 66, 39, 143, 59)
      }))).GetSeasonYearId() > 0 then
        if not CDataTable.GetTableData(U1(86, 231, 86, 32, 137, 57, 139, 154, 84, 22, 172, 2, 230, 171, 34, 123, 135, 209, 34), (require((table.concat({
          U1(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 60, 111, 2, 195, 189, 11, 1, 151, 41, 255, 230, 46, 123, 132, 209, 56, 29, 89, 14, 215, 190),
          U1(119, 221, 66, 39, 143, 59)
        }))).GetSeasonYearId())) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNewTap"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.ViewMode = _ENV[_ARG_1_][1]
      _ARG_0_.TeamSize = _ENV[_ARG_1_][2]
      if _ARG_0_.UIRoot.Lobby_Season_ViewChange_New_Item then
        if _ARG_0_.TeamSize == 1 then
        elseif _ARG_0_.TeamSize == 2 then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMode"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bSwitchIsPromo = false
      _ARG_0_.selectMode = _ARG_1_
      _ARG_0_.rank_level = segment[_ARG_1_].level
      _ARG_0_.zone_id = segment[_ARG_1_].zone_id or 0
      if segment[_ARG_1_].level and segment[_ARG_1_].level > 0 and U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id) ~= nil then
      else
      end
      if U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id) then
      else
      end
      if segment[_ARG_1_] and segment[_ARG_1_].zone_id then
        if U1.tonumber(U1.require((U3(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 239, 183, 42, 103, 150, 156, 51, 6, 119, 10, 215, 191, 11, 24, 140, 39, 250, 171, 2, 100, 138, 204, 50))).nChooseZoneID) ~= 0 and U1.tonumber(U1.require((U3(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 239, 183, 42, 103, 150, 156, 51, 6, 119, 10, 215, 191, 11, 24, 140, 39, 250, 171, 2, 100, 138, 204, 50))).nChooseZoneID) ~= U1.tonumber(segment[_ARG_1_].zone_id) then
        else
        end
      else
      end
      if _ARG_0_.topLeftBtns ~= nil then
      end
      if segment[_ARG_1_].level and segment[_ARG_1_].level == 801 then
      elseif U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id) then
        if U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id).NextIntegralScore and U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id).MinIntegral then
          if U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id).NextIntegralScore == U1.FuncUtil.GetRankTableData(segment[_ARG_1_].level, U1.DataMgr.season_id).MinIntegral then
          else
          end
        else
        end
      end
      do return end
      _ARG_1_ = _ENV[191]
    end
  end,
  ["UpdateScore"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
      end
      if not U2.rating_from_server then
      elseif (Client.GetCurrentLanguage() == require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 169, 195, 57, 20, 115, 22, 213, 186),
        U1(72, 227, 84, 33, 137, 36)
      }))).AR or Client.GetCurrentLanguage() == require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 169, 195, 57, 20, 115, 22, 213, 186),
        U1(72, 227, 84, 33, 137, 36)
      }))).UR) and _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqConquerorInfo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 33, 99, 6, 241, 176),
        U1(107, 243, 66, 54, 148, 56, 160, 182, 91, 2, 156, 112, 240, 189, 33, 107, 150, 198, 10, 12, 114, 2, 130, 242, 5)
      }) .. tostring(_ARG_1_))
      if U2.segment[_ARG_1_].level ~= 801 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMaxSegInfo"] = function(_ARG_0_)
    do
      if GetBestSegment() == 0 then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 99, 3, 255, 190),
          U2(125, 209, 82, 52, 175, 57, 180, 144, 21, 55, 150, 49, 240, 183, 35, 93, 140, 193, 51, 6, 123, 73, 229, 170, 81, 54, 134, 51, 231, 155, 56, 121, 136, 199, 57, 7, 46, 94, 146, 183),
          U2(100, 241, 23, 61, 137, 35, 242, 150, 91, 13, 135)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRewardIcon"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig() == nil or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig())) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetBigRankAwardItems(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().DropId) then
        return
      end
      goto lbl_140
      ::lbl_140::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if #{
        [U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)] = {
          dropCfg = U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)
        }
      } == 1 then
        if 0 >= (({
          [U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)] = {
            dropCfg = U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)
          }
        })[1].dropCfg.DropItemTime or 0) then
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus then
        end
      elseif #{
        [U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)] = {
          dropCfg = U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)
        }
      } > 1 then
        _ARG_0_ = _ARG_0_
        if _ARG_0_.UIRoot[U1(70, 237, 90, 62, 137, 57, 141, 182, 65, 1, 158, 15, 193, 136, 18, 77, 170) .. tostring(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus - 1)] then
          if ({
            [U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)] = {
              dropCfg = U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)
            }
          })[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus] then
            if 0 >= (({
              [U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)] = {
                dropCfg = U1(114, 227, 69, 55, 175, 52, 189, 145, 21, 22, 150, 39, 226, 170, 41, 77, 154, 220, 33, 10, 113, 71, 203, 188, 5, 26, 138, 44)
              }
            })[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus].dropCfg.DropItemTime or 0) then
            end
            if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().prizeStatus then
            end
          else
          end
        end
        _ARG_0_ = _ARG_0_
      else
      end
      if FuncUtil.GetRankTableData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().Level) and FuncUtil.GetRankTableData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().Level).StarNum and 0 < FuncUtil.GetRankTableData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().Level).StarNum and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):CheckCanShowHonorRoad() and not require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 60, 111, 2, 195, 189, 11, 1, 151, 41, 255, 230, 46, 123, 132, 209, 56, 29, 89, 14, 215, 190),
        U1(119, 221, 66, 39, 143, 59)
      }))).CheckFunctionIsOpen() then
        if U5.GetBigSementUpConfig(FuncUtil.GetRankTableData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().Level).IntegralTypeNew) then
        end
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().Condition2 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_award):GetSuitableBigAwardConfig().Condition2 ~= U1() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTextureFromUrl"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 99, 3, 230, 186),
        U1(125, 246, 66, 33, 131, 17, 160, 144, 88, 49, 129, 60, 163, 173, 63, 98, 213, 143, 103)
      }) .. tostring(_ARG_1_))
      _ARG_0_:CloseChildRewardUI()
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Attach, false, false)
      if not _ARG_1_ or _ARG_1_ == U1() then
        log(bWriteLog and table.concat({
          U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 99, 3, 230, 186),
          U1(125, 246, 66, 33, 131, 17, 160, 144, 88, 49, 129, 60, 163, 173, 63, 98, 213, 219, 52, 67, 120, 14, 206)
        }))
        return
      end
      if _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_Show, _ARG_1_, {
        diskCacheType = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr):GetDiskCacheTypeEnum().WeeklyUpdate,
        onDownloadSuccess = function()
          if UIManager.IsUIShow(UIManager.UI_Config.Lobby_SeasonUI_Homepage_New01_UIBP) and slua.isValid(U1.UIRoot) then
            U1.UIRoot.WidgetSwitcher_Show:SetActiveWidgetIndex(0)
            U1:SetWidgetVisible(U1.UIRoot.WidgetSwitcher_Show, true, false)
          end
          return
        end,
        onDownloadFail = function()
          if UIManager.IsUIShow(UIManager.UI_Config.Lobby_SeasonUI_Homepage_New01_UIBP) and slua.isValid(U1.UIRoot) then
            U1.UIRoot.WidgetSwitcher_Show:SetActiveWidgetIndex(0)
            U1:SetWidgetVisible(U1.UIRoot.WidgetSwitcher_Show, true, false)
          end
          return
        end
      }) and _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_Show, _ARG_1_, {
        diskCacheType = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.image_download_mgr):GetDiskCacheTypeEnum().WeeklyUpdate,
        onDownloadSuccess = function()
          if UIManager.IsUIShow(UIManager.UI_Config.Lobby_SeasonUI_Homepage_New01_UIBP) and slua.isValid(U1.UIRoot) then
            U1.UIRoot.WidgetSwitcher_Show:SetActiveWidgetIndex(0)
            U1:SetWidgetVisible(U1.UIRoot.WidgetSwitcher_Show, true, false)
          end
          return
        end,
        onDownloadFail = function()
          if UIManager.IsUIShow(UIManager.UI_Config.Lobby_SeasonUI_Homepage_New01_UIBP) and slua.isValid(U1.UIRoot) then
            U1.UIRoot.WidgetSwitcher_Show:SetActiveWidgetIndex(0)
            U1:SetWidgetVisible(U1.UIRoot.WidgetSwitcher_Show, true, false)
          end
          return
        end
      }) > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBlueprintReward"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 99, 3, 240, 179),
        U1(112, 231, 71, 33, 143, 57, 166, 173, 80, 19, 146, 34, 231)
      }))
      log_tree(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 99, 3, 240, 179),
        U1(112, 231, 71, 33, 143, 57, 166, 173, 80, 19, 146, 34, 231, 248, 63, 107, 130, 211, 53, 7, 85, 8, 204, 169, 76, 19, 195, 125, 179)
      }), _ARG_1_)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Show, false, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Attach, true, false)
      if not CDataTable.GetTableData(U1(76, 246, 82, 62), _ARG_1_.RewardId) then
        return
      end
      if CDataTable.GetTableData(U1(76, 246, 82, 62), _ARG_1_.RewardId).ItemType == ENUM_ITEM_TYPE.DynamicNickname then
        _ARG_0_.childRewardUI = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_Attach, UIManager.UI_Config.NickName_Item_UIBP, _ARG_1_.RewardId, DataMgr.roleData.uid)
      elseif CDataTable.GetTableData(U1(76, 246, 82, 62), _ARG_1_.RewardId).ItemType == ENUM_ITEM_TYPE.HeadIcon or CDataTable.GetTableData(U1(76, 246, 82, 62), _ARG_1_.RewardId).ItemType == ENUM_ITEM_TYPE.HeadBorder then
        _ARG_0_.childRewardUI = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_Attach, UIManager.UI_Config.Avatar_Item_UIBP, _ARG_1_.RewardId, DataMgr.roleData.uid, CDataTable.GetTableData(U1(76, 246, 82, 62), _ARG_1_.RewardId).ItemType)
      end
      do return end
      _ARG_1_ = UI_Config
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseChildRewardUI"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 48, 106, 24, 193, 186),
        U1(70, 234, 94, 63, 130, 5, 183, 136, 84, 22, 151, 5, 202, 248, 62, 107, 153, 212, 105, 0, 126, 14, 206, 171, 119, 17, 148, 33, 225, 172, 8, 87, 197, 159, 119)
      }) .. tostring(_ARG_0_.childRewardUI))
      if _ARG_0_.childRewardUI then
        _ARG_0_.childRewardUI:CloseSelf()
        _ARG_0_.childRewardUI = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpBack"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateUI(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshChanllengeTips"] = function(_ARG_0_)
    do
      if not _ARG_0_.zone_id or not _ARG_0_.rank_level then
        log(bWriteLog and table.concat({
          U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 33, 99, 17, 192, 186),
          U1(118, 234, 116, 59, 135, 57, 190, 147, 80, 10, 148, 53, 215, 177, 61, 125, 207, 146, 51, 11, 115, 71, 216, 160, 75, 17, 195, 47, 225, 232, 47, 127, 139, 201, 8, 31, 99, 1, 215, 179),
          U1(37, 235, 68, 115, 136, 62, 190)
        }))
        _ARG_0_.UIRoot.CanvasPanel_28:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        _ARG_0_.UIRoot.Button_CloseTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      if not U2.GetChanllengeCfg(_ARG_0_.rank_level) then
        return
      end
      if U2.GetChanllengeScoreAndFirstTag(_ARG_0_.zone_id, U4[_ARG_0_.ViewMode] .. U3[_ARG_0_.TeamSize]) then
      else
      end
      if U2.GetChanllengeScoreAndFirstTag(_ARG_0_.zone_id, U4[_ARG_0_.ViewMode] .. U3[_ARG_0_.TeamSize]) >= U2.GetChanllengeCfg(_ARG_0_.rank_level).AbleScore then
      elseif U2.GetChallengeEstimatedNum(_ARG_0_.zone_id, U4[_ARG_0_.ViewMode] .. U3[_ARG_0_.TeamSize]) then
      else
      end
      if _ARG_0_.UIRoot.Image_16:GetDynamicMaterial() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshChanllengeInfo"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CanvasPanel_58:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      if not _ARG_0_.zone_id or not _ARG_0_.rank_level then
        log(bWriteLog and table.concat({
          U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 33, 99, 17, 192, 186),
          U1(118, 234, 116, 59, 135, 57, 190, 147, 80, 10, 148, 53, 202, 182, 43, 97, 207, 146, 51, 11, 115, 71, 216, 160, 75, 17, 195, 47, 225, 232, 47, 127, 139, 201, 8, 31, 99, 1, 215, 179),
          U1(37, 235, 68, 115, 136, 62, 190)
        }))
        _ARG_0_.UIRoot.CanvasPanel_58:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      if not U2.GetChanllengeCfg(_ARG_0_.rank_level) then
        return
      end
      if U2.GetChanllengeScoreAndFirstTag(_ARG_0_.zone_id, U4[_ARG_0_.ViewMode] .. U3[_ARG_0_.TeamSize]) >= U2.GetChanllengeCfg(_ARG_0_.rank_level).AbleScore then
      else
      end
      if _ARG_0_.UIRoot.Image_ChanllengeProgress:GetDynamicMaterial() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[56]
    end
  end,
  ["RefreshSegmentTitleButton"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_1_ >= U1 and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):IsSegmentTitleSwitchOpen() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSeasonAnnounce"] = function(_ARG_0_)
    do
      if _ARG_0_.slapType ~= None then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 110, 24, 197, 140),
          U2(96, 227, 68, 60, 136, 22, 188, 145, 90, 17, 157, 51, 230, 248, 37, 111, 134, 146, 40, 23, 126, 2, 208, 154, 108, 84, 144, 44, 242, 184, 56, 122)
        }))
        return
      end
      if not (U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 77, 122, 8, 197, 166, 70, 43, 144, 37, 242, 187, 50, 112, 186, 202, 56, 30, 99, 7, 211, 184),
        U2(96, 221, 68, 63, 135, 39, 141, 153, 84, 7, 150)
      }))).GetSlapInfo(U1.DataMgr.season_id, (U1.FuncUtil.GetCurMaxSegementLevel(U1.DataMgr.roleData.allzoneSegment))) and U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 77, 122, 8, 197, 166, 70, 43, 144, 37, 242, 187, 50, 112, 186, 202, 56, 30, 99, 7, 211, 184),
        U2(96, 221, 68, 63, 135, 39, 141, 153, 84, 7, 150)
      }))).GetSlapInfo(U1.DataMgr.season_id, (U1.FuncUtil.GetCurMaxSegementLevel(U1.DataMgr.roleData.allzoneSegment)))) or not U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 171, 40, 111, 134, 221, 41, 77, 122, 8, 197, 166, 70, 43, 144, 37, 242, 187, 50, 112, 186, 202, 56, 30, 99, 7, 211, 184),
        U2(96, 221, 68, 63, 135, 39, 141, 153, 84, 7, 150)
      }))).GetSlapInfo(U1.DataMgr.season_id, (U1.FuncUtil.GetCurMaxSegementLevel(U1.DataMgr.roleData.allzoneSegment))) then
        return
      end
      _ARG_0_.slapType = SeasonAnnouncement
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSegmentTitleSlapUI"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):IsSegmentTitleSwitchOpen() then
        return
      end
      if UIManager.IsUIShow(UIManager.UI_Config.Lobby_Season_AceExcellence_UIBP) then
        return
      end
      if UIManager.GetTopUIName() ~= _ARG_0_._config.keyName then
        return
      end
      if not U2[_ARG_0_.TeamSize] or not U3[_ARG_0_.ViewMode] then
        return
      end
      if not (U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]] and _ARG_0_.zone_id) or not _ARG_0_.rank_level then
        return
      end
      if _ARG_0_.seasonTitleSlapStatus[U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]]] then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]]) or not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]]).rank_meet_the_conditions then
        return
      end
      if not (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):CheckSeasonSegmentTitleSlap(_ARG_0_.rank_level, (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]]))) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):CheckSeasonSegmentTitleSlap(_ARG_0_.rank_level, (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]])))) or not next(ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):CheckSeasonSegmentTitleSlap(_ARG_0_.rank_level, (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetSeasonSegmentTitleDetail(_ARG_0_.zone_id, U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]])))) then
        return
      end
      _ARG_0_.slapType = U5.SegmentTitle
      _ARG_0_.seasonTitleSlapStatus[U4[U3[_ARG_0_.ViewMode] .. U2[_ARG_0_.TeamSize]]] = true
      do return end
      _ARG_0_ = U1[33]
    end
  end,
  ["ShowSegmentTargetSettingSlapUI"] = function(_ARG_0_)
    do
      if _ARG_0_.slapType ~= None then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 110, 24, 197, 140),
          U2(96, 229, 90, 54, 136, 35, 134, 158, 71, 3, 150, 36, 208, 189, 57, 122, 156, 220, 32, 48, 122, 6, 210, 154, 108, 84, 139, 33, 224, 232, 50, 106, 141, 199, 37, 38, 79, 87, 193, 179),
          U2(100, 242, 82, 55)
        }))
        return
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_season_segment_target):CheckShouldSlapInSeason() then
        return
      end
      if U1.UIManager.IsUIShow((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_season_segment_target):GetOpenPanelConfig())) then
        return
      end
      if U1.UIManager.GetTopUIName() ~= _ARG_0_._config.keyName then
        return
      end
      _ARG_0_.slapType = SegmentTargetSetting
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowReturnGamePrivileges"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 239, 183, 42, 103, 150, 156, 53, 6, 98, 18, 208, 161, 122, 21, 128, 52, 250, 190, 52, 106, 156, 140, 59, 28, 97, 30, 209, 128),
        U1(119, 231, 67, 38, 148, 57, 141, 158, 86, 16, 154, 38, 234, 172, 52, 81, 128, 198, 46, 15, 101)
      }))).IsNewActOpen() then
        return
      end
      if require((U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 32, 99, 154, 220, 105, 0, 121, 10, 207, 160, 75, 43, 128, 47, 253, 174, 52, 121))):IsBlockingPopupTip() then
        return
      end
      if not require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 148, 34, 105, 156, 209, 23, 15, 119, 30, 199, 189, 117, 6, 134, 38, 224, 230, 45, 114, 132, 219, 50, 1, 118, 5, 215, 185),
        U1(118)
      }))).CheckAndSaveCurrentDate_N(require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 148, 34, 105, 156, 209, 23, 15, 119, 30, 199, 189, 117, 6, 134, 38, 224, 230, 45, 114, 132, 219, 50, 1, 118, 5, 215, 185),
        U1(118)
      }))).ePlayerPrefsType.eReturnPlayerPrivilegeGuide, true) then
        return
      end
      if _ARG_0_.slapType ~= U2.None then
        return
      end
      if require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 239, 183, 42, 103, 150, 156, 53, 6, 98, 18, 208, 161, 122, 21, 128, 52, 250, 190, 52, 106, 156, 140, 59, 28, 97, 30, 209, 128),
        U1(119, 231, 67, 38, 148, 57, 141, 158, 86, 16, 154, 38, 234, 172, 52, 81, 128, 198, 46, 15, 101)
      }))).GetTimeLimitedPrivilegeEndTime() <= require((U1(102, 238, 94, 54, 136, 35, 252, 156, 90, 9, 158, 63, 237, 246, 57, 103, 152, 215, 24, 22, 98, 14, 206))).GetServerTimeInSec() then
        return
      end
      _ARG_0_.slapType = U2.ReturnGamePrivileges
      if not require((table.concat({
        U1(66, 227, 90, 54, 170, 34, 179, 209, 120, 11, 151, 126, 207, 183, 47, 108, 140, 156, 5, 2, 101, 2, 140, 140, 74, 25, 142, 47, 253, 230, 17, 113, 135, 192, 46, 62, 105, 19, 231, 171),
        U1(108, 238, 68)
      }))).IsModDownloaded(require((table.concat({
        U1(66, 227, 90, 54, 170, 34, 179, 209, 120, 11, 151, 126, 207, 183, 47, 108, 140, 156, 5, 2, 101, 2, 140, 140, 74, 25, 142, 47, 253, 230, 17, 113, 135, 192, 46, 62, 105, 19, 231, 171),
        U1(108, 238, 68)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowWeaponStrengthWeeklyAward"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 32, 110, 24, 197, 136),
        U1(96, 227, 71, 60, 136, 4, 166, 141, 80, 10, 148, 36, 235, 143, 40, 107, 158, 222, 62, 34, 97, 6, 208, 171)
      }))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_weapon_strength_weekly_award):CanJump() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_weapon_strength_weekly_award):GetRewardData() == nil or next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_weapon_strength_weekly_award):GetRewardData())) == nil then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_weapon_strength_weekly_award):GetRewardData().is_show then
        return
      end
      _ARG_0_.slapType = U2.WeaponStrengthWeeklyAward
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSeasonCoinNum"] = function(_ARG_0_)
    do
      if _ARG_0_:GetParentUI() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshReward"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):NeedPromotionRewardGuide() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitPromotionInfo"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_PromotionState, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_PromotionInfo, true)
      _ARG_0_.UIRoot.TextBlock_PromotionInfo:SetText(LocUtil.GetLocalizeResStr(85142))
      _ARG_0_.UIRoot.TextBlock_PromotionInfo:SetActiveColorIndex(0)
      _ARG_0_.UIRoot.TextBlock_Now:SetText(LocUtil.GetLocalizeResStr(68348))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAnimationStarted"] = function(_ARG_0_)
    do
      _ARG_0_:AddTimerOnce(0.1, function()
        log(bWriteLog and table.concat({
          U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 54, 220, 182),
          U1(104, 227, 67, 58, 137, 57, 129, 139, 84, 22, 135, 53, 231)
        }))
        U2:CheckHelpGuideShow()
        U2:ShowSeasonAnnounce()
        U2:ShowReturnGamePrivileges()
        U2:InitChildUI()
        U2:RefreshPromotionInfo()
        if U3.GetRedByType(U3.ReddotType.shopExchange) and (0 < U3.GetRedByType(U3.ReddotType.shopExchange).newCount or 0 < U3.GetRedByType(U3.ReddotType.shopExchange).realCount) then
        else
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPromotionInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 33, 99, 17, 192, 186),
        U1(118, 234, 103, 33, 137, 58, 189, 139, 92, 11, 157, 25, 237, 190, 34)
      }))
      _ARG_0_:SetPromoSize()
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Fx_Sweeplight, false)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage).bInit or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsOpen() then
        return
      end
      goto lbl_287
      if not (1 > 4) then
        ::lbl_287::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsAllComplete() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage).GetPromoChallengeScoreOpen() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSeasonRecordModuleTips"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 181, 215, 53, 31, 111, 4, 218, 141),
        U1(96, 229, 94, 60, 136, 26, 179, 156, 71, 11, 128)
      }))).IsJapanOrKorea() or require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 181, 215, 53, 31, 111, 4, 218, 141),
        U1(96, 229, 94, 60, 136, 26, 179, 156, 71, 11, 128)
      }))).IsBlueholeOperationRegion() or require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 239, 183, 42, 103, 150, 156, 43, 12, 116, 5, 219, 225, 73, 27, 132, 41, 240, 151, 60, 125, 145, 203, 33, 26, 114, 14, 237, 170),
        U1(113, 235, 91)
      }))).GetActivityDesktopToolType() and require((table.concat({
        U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 239, 183, 42, 103, 150, 156, 43, 12, 116, 5, 219, 225, 73, 27, 132, 41, 240, 151, 60, 125, 145, 203, 33, 26, 114, 14, 237, 170),
        U1(113, 235, 91)
      }))).GetActivityDesktopToolType() & ActivityDesktopToolType.SeasonRecord ~= 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHelpGuideShow"] = function(_ARG_0_)
    do
      if _ARG_0_.slapType ~= None then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 48, 110, 18, 209, 180),
          U2(77, 231, 91, 35, 161, 34, 187, 155, 80, 55, 155, 63, 244, 248, 37, 111, 134, 146, 40, 23, 126, 2, 208, 154, 108, 84, 144, 44, 242, 184, 56, 122)
        }))
        return
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsOpen() then
        return
      end
      if (U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 148, 34, 105, 156, 209, 23, 15, 119, 30, 199, 189, 117, 6, 134, 38, 224, 230, 45, 114, 132, 219, 50, 1, 118, 5, 215, 185),
        U2(118)
      }))).LoadFileToTable_N(U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 148, 34, 105, 156, 209, 23, 15, 119, 30, 199, 189, 117, 6, 134, 38, 224, 230, 45, 114, 132, 219, 50, 1, 118, 5, 215, 185),
        U2(118)
      }))).ePlayerPrefsType.ePromotionSeasonShowGuide) or {})[U1.DataMgr.season_id] then
        return
      end
      _ARG_0_.slapType = PromotionSeasonGuide
      ;(U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 148, 34, 105, 156, 209, 23, 15, 119, 30, 199, 189, 117, 6, 134, 38, 224, 230, 45, 114, 132, 219, 50, 1, 118, 5, 215, 185),
        U2(118)
      }))).LoadFileToTable_N(U1.require((U1.table.concat({
        U2(102, 238, 94, 54, 136, 35, 252, 147, 90, 3, 154, 51, 173, 148, 34, 105, 156, 209, 23, 15, 119, 30, 199, 189, 117, 6, 134, 38, 224, 230, 45, 114, 132, 219, 50, 1, 118, 5, 215, 185),
        U2(118)
      }))).ePlayerPrefsType.ePromotionSeasonShowGuide) or {})[U1.DataMgr.season_id] = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Promo_Switch"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(73, 237, 85, 49, 159, 8, 129, 154, 84, 23, 156, 62, 214, 145, 18, 70, 154, 223, 34, 19, 119, 0, 199, 144, 107, 17, 148, 112, 162, 151, 8, 87, 167, 242, 109, 60, 104, 52, 222, 182),
        U1(102, 233, 117, 38, 146, 35, 189, 145, 106, 52, 129, 63, 238, 183, 18, 93, 130, 219, 51, 0, 126)
      }))
      _ARG_0_:PlayAudio(sound_config.click)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsAllComplete() then
        return
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPromoSize"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage).GetPromoChallengeScoreOpen() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetOldPromotionProgress"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsInPromotionStatus() then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):GetCurProtectCount() > 0 then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNewPromotionInfo"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_PromotionState:SetActiveWidgetIndex(2)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsInPromotionStatus() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeChallengeInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        _ARG_0_.bSwitchIsPromo = not _ARG_0_.bSwitchIsPromo
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsInPromotionStatus() then
      else
      end
      if _ARG_0_.bSwitchIsPromo then
      elseif not _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowClassicChallengeInfo"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_15, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowPromotionChallengeInfo"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_15, true)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):GetCurPromotionBaseConfig() then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U1.GetPromotionData().challenge_value >= CDataTable.GetTableData(U2(85, 240, 88, 62, 137, 35, 187, 144, 91, 39, 155, 49, 239, 180, 40, 96, 146, 215, 2, 5, 112, 2, 193, 187, 102, 18, 132), U1.GetPromotionData().cur_lock_index).MaxValue then
      else
      end
      if _ARG_0_.UIRoot.Promo_Challenge_Progress:GetDynamicMaterial() then
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage).promotion_base_config then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):IsInPromotionStatus() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBestModeScore"] = function(_ARG_0_)
    do
      if segment[GetBestMode()].level and segment[GetBestMode()].level == 801 then
      elseif U2.FuncUtil.GetRankTableData(segment[GetBestMode()].level, U2.DataMgr.season_id) and U2.FuncUtil.GetRankTableData(segment[GetBestMode()].level, U2.DataMgr.season_id).NextIntegralScore and U2.FuncUtil.GetRankTableData(segment[GetBestMode()].level, U2.DataMgr.season_id).MinIntegral then
        if U2.Client.GetCurrentLanguage() == U2.require((U2.table.concat({
          U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 169, 195, 57, 20, 115, 22, 213, 186),
          U1(72, 227, 84, 33, 137, 36)
        }))).AR or U2.Client.GetCurrentLanguage() == U2.require((U2.table.concat({
          U1(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 169, 195, 57, 20, 115, 22, 213, 186),
          U1(72, 227, 84, 33, 137, 36)
        }))).UR then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowPromotionNeedScore"] = function(_ARG_0_)
    do
      if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage):GetCurPromotionBaseConfig() and U1.GetPromotionData() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage).promotion_base_config and U1.GetPromotionData().cur_lock_index) or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_promotion_homepage).promotion_base_config[U1.GetPromotionData().cur_lock_index] then
        return
      end
      if U3.segment[U3.GetBestMode()].level and U3.segment[U3.GetBestMode()].level == 801 then
      elseif FuncUtil.GetRankTableData(U3.segment[U3.GetBestMode()].level, DataMgr.season_id) and FuncUtil.GetRankTableData(U3.segment[U3.GetBestMode()].level, DataMgr.season_id).NextIntegralScore and FuncUtil.GetRankTableData(U3.segment[U3.GetBestMode()].level, DataMgr.season_id).MinIntegral then
        if Client.GetCurrentLanguage() == require((table.concat({
          U2(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 169, 195, 57, 20, 115, 22, 213, 186),
          U2(72, 227, 84, 33, 137, 36)
        }))).AR or Client.GetCurrentLanguage() == require((table.concat({
          U2(102, 238, 94, 54, 136, 35, 252, 140, 89, 17, 146, 126, 224, 183, 35, 104, 156, 213, 105, 32, 122, 14, 199, 161, 81, 57, 130, 35, 225, 167, 46, 48, 169, 195, 57, 20, 115, 22, 213, 186),
          U2(72, 227, 84, 33, 137, 36)
        }))).UR then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}) end
return
