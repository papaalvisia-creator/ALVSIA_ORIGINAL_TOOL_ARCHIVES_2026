do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(144, 198, 134, 30, 190)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 80, 251, 209, 21, 84, 251, 229, 57, 79, 30, 68, 153, 14, 43, 186, 3, 65, 231, 196, 116, 122, 254, 226, 32, 114, 13, 95, 159),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(135, 245, 133, 12, 190, 36)
}))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.vehicleList = {}
      _ARG_0_.TypeStringToID = {}
      _ARG_0_.TypeIDToString = {}
      _ARG_0_.vehicleCategory = {}
      _ARG_0_.TabItemCount = {}
      _ARG_0_.curSelectVehicleType = nil
      _ARG_0_.subTabId = _ENV(165, 207, 143, 4, 174, 45, 51)
      _ARG_0_.VehicleSlot = {}
      _ARG_0_.DefaultVehicleInsId = {}
      _ARG_0_.AllItemList = {}
      _ARG_0_.curPutOnInsId = nil
      _ARG_0_._tWaitingIconItemIDs = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      if _ARG_0_:GetVehicleList(1) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowCarSkinList"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CanvasPanel_CarSkinDrag:SetWidgetVisibility(_ENV)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_SHOW_ENTRY_ICON, true)
      EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_SHOW_BG, true)
      U1.__super.OnHide(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if _ARG_0_.redHandle then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetVehiclePage() then
        end
        _ARG_0_.redHandle = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Close"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 74, 244, 254, 41, 84, 16, 74, 149, 90, 61, 245, 34, 89, 233, 213, 78))
      U2.ShowAllAvatar(U2.MUTEX_WARDROBE)
      U2.ReleaseMutex(U2.MUTEX_WARDROBE)
      U3 = 0
      U4 = false
      _ARG_0_.TabItemCount = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 222, 51, 84, 5, 79, 144, 73, 34, 170))
      U2.__super.OnInitialize(_ARG_0_)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_BagMode, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Common_Tab_BagMode, false)
      _ARG_0_.VehicleComboBox = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_GunType, nil, false, {bWarehouse = true})
      _ARG_0_.VehicleComboBox:SetSelectOptionCallback(_ARG_0_.OnSelectVehicleType, _ARG_0_)
      _ARG_0_.VehicleComboBox:SetRefreshOptionCallback(_ARG_0_.OnRefreshVehicleType, _ARG_0_)
      _ARG_0_.LoopScrollGridSkins = _ARG_0_.LoopScrollGrid_Normal
      _ARG_0_.LoopScrollGridVehicles = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.LoopScrollBox_GunList, (table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 80, 251, 209, 21, 84, 251, 229, 57, 79, 30, 68, 153, 14, 17, 187, 4, 88, 168, 241, 74, 97, 238, 245, 34, 79, 4, 105, 171),
        U1(134, 196, 179, 20, 189, 36, 31, 184, 85, 37, 128, 51, 117)
      })))
      _ARG_0_.LoopScrollGridSkins:SetRefreshItemCallback(_ARG_0_.OnRefreshVehicleSkin, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_0, U1(188, 196, 164, 1, 164, 34, 61, 169, 84), _ARG_0_.OnClickButton_ShowTips, _ARG_0_)
      _ARG_0_:InitVehicleList()
      _ARG_0_.LoopScrollGridSkins:AddItemWidgetChildEvent(U1(176, 197, 138, 0, 162, 47, 9, 136, 66, 41, 184, 53, 87, 249, 198, 100, 74, 238, 242, 48), U1(188, 196, 163, 31, 172, 38, 4, 169, 81, 44, 166, 37, 74, 197, 222, 90, 115, 255), _ARG_0_.OnVehicleDragReadyToShape, _ARG_0_)
      _ARG_0_.LoopScrollGridSkins:AddItemWidgetChildEvent(U1(176, 197, 138, 0, 162, 47, 9, 136, 66, 41, 184, 53, 87, 249, 198, 100, 74, 238, 242, 48), U1(188, 196, 163, 31, 172, 38, 21, 173, 94, 11, 186, 29, 64, 242), _ARG_0_.OnVehicleDragCanceled, _ARG_0_)
      _ARG_0_.LoopScrollBox_0 = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollBox_0)
      _ARG_0_.LoopScrollBox_0:SetRefreshItemCallback(_ARG_0_.OnRefreshVehicleSlotItem, _ARG_0_)
      _ARG_0_.LoopScrollBox_0:AddItemWidgetChildEvent(U1(176, 197, 138, 0, 162, 47, 9, 136, 66, 41, 184, 53, 87, 249, 198, 100, 74, 238, 242, 48), U1(188, 196, 163, 31, 172, 38, 5, 185, 83, 43, 186, 2, 86), _ARG_0_.OnVehicleSlotDrop, _ARG_0_)
      _ARG_0_.LoopScrollBox_0:AddItemWidgetChildEvent(U1(176, 197, 138, 0, 162, 47, 9, 136, 66, 41, 184, 53, 87, 249, 198, 100, 74, 238, 242, 48), U1(188, 196, 163, 31, 172, 38, 4, 169, 81, 44, 166, 37, 74, 197, 222, 90, 115, 255), _ARG_0_.OnVehicleSlotDrag, _ARG_0_)
      _ARG_0_.LoopScrollBox_0:AddItemWidgetChildEvent(U1(176, 197, 138, 0, 162, 47, 9, 136, 66, 41, 184, 53, 87, 249, 198, 100, 74, 238, 242, 48), U1(188, 196, 163, 31, 172, 38, 21, 173, 94, 11, 186, 29, 64, 242), _ARG_0_.OnVehicleSlotRemove, _ARG_0_)
      _ARG_0_.UIRoot.TextBlock_0:SetText(LocUtil.LocalizeResFormat(33524))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetVehiclePage() then
        _ARG_0_.redHandle = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetVehiclePage():BindEvent(function(_ARG_0_)
          do
            VehicleComboBox:RefreshOptions()
            LoopScrollGridVehicles:RefreshAllItems()
            _ENV:SetWidgetVisible(UIRoot.Reddot_Anchor, _ARG_0_ ~= 0)
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)
      end
      return
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_VEHICLE_SLOT_DATA_CHANGE, _ARG_0_.OnSlotSkinDataChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY_SCENE, U1.EVENTID_SCENE_LOADED, _ARG_0_.OnVehicleSceneLoaded, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY_SCENE, U1.EVENTID_SCENE_GARAGE_MODEL_READY, _ARG_0_.OnModelReady, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowBigIcon"] = function(_ARG_0_)
    do
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSportsCarFeatureUpdate"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:CloseFeaturePanel()
      if not _ARG_1_ then
        return
      end
      if not CDataTable.GetTableData(U1(181, 207, 134, 25, 184, 51, 51, 191, 121, 60, 186, 28, 86), _ARG_1_) then
        return
      end
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().feature = true
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().superCarDoorSlot = _ARG_2_
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().cavrioletBtnSlot = _ARG_2_
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().car = false
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().videoBtn = false
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().sportCarInstruction = false
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().skipAutoPlayVideo = false
      require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
        U1(183, 207, 147, 12, 164, 45)
      }))).GetDefaultCloseConfig().disableCombinePackage = true
      if not UIManager.GetUI(UIManager.UI_Config.wardrobe) then
        return
      end
      _ARG_0_.widgetDetailComponent = UIManager.GetUI(UIManager.UI_Config.wardrobe):CreateChildWindow(UIManager.GetUI(UIManager.UI_Config.wardrobe).UIRoot.CanvasPanel_Detail, UIManager.UI_Config.DetailComponentMain, {
        switches = require((table.concat({
          U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 81, 228, 215, 82, 119, 233, 185, 25, 88, 5, 71, 149, 76, 27, 160, 12, 69, 233, 200, 78, 125, 254, 169, 14, 66, 15, 69, 152),
          U1(183, 207, 147, 12, 164, 45)
        }))).GetDefaultCloseConfig(),
        offsetInfo = {
          feature = FVector2D(0, 50),
          sportsCarEnter = FVector2D(100, 0)
        },
        ViewCompPadding = FMargin(0, 250, 0, 0)
      })
      goto lbl_253
      ::lbl_253::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[82]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseFeaturePanel"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 64, 246, 248, 46, 88, 55, 67, 157, 84, 45, 189, 4, 101, 231, 200, 78, 127, 170, 167))
      if _ARG_0_.widgetDetailComponent then
        _ARG_0_.widgetDetailComponent:Close()
        _ARG_0_.widgetDetailComponent = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshVehicleType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 197, 56, 91, 3, 67, 143, 72, 14, 170, 9, 92, 229, 202, 78, 71, 243, 247, 40))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetVehicleType(tonumber(_ARG_2_)) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectVehicleType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 196, 56, 81, 20, 69, 136, 118, 61, 167, 8, 86, 234, 195, 127, 106, 250, 226) .. tostring(_ARG_2_))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_:GetTabStringByID(_ARG_2_) ~= nil then
      end
      _ARG_0_.curSelectVehicleType = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeVehicleType"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 64, 242, 246, 51, 90, 20, 112, 153, 72, 49, 172, 13, 80, 210, 223, 91, 118))
      if not _ARG_0_:GetVehicles(_ARG_1_) then
        return
      end
      _ARG_0_.vehicleList = {}
      goto lbl_58
      ::lbl_58::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1.pairs
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehicleTypeComboBox"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 74, 244, 254, 41, 107, 20, 78, 149, 67, 52, 170, 45, 92, 245, 210))
      goto lbl_50
      ::lbl_50::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleList"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 74, 244, 254, 41, 107, 20, 78, 149, 67, 52, 170, 45, 92, 245, 210))
      _ARG_0_.UIRoot.HorizontalBox_Pendant:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      goto lbl_112
      if (9).VehicleDefualtSkinID == DataMgr.defaultWingmanSkinResID then
      elseif _ARG_0_:GetEquipTab((9).WardrobeTab) then
      end
      ::lbl_112::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleSkin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 74, 244, 254, 41, 107, 20, 78, 149, 67, 52, 170, 50, 94, 239, 200))
      if not _ARG_1_ then
        return
      end
      goto lbl_223
      if U5:IsValidCurrentPageItem(U2, _ARG_1_.WardrobeTab, 163, (require((U1(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 194, 82, 110, 255, 200, 40, 73, 24, 74))).GetServerTimeInSec())) then
        if _ARG_0_:IsOnSlotSkinList((U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false))) and not (U4:GetHallDepotItemDataByInsID((U3.GetEquipStates(_ARG_1_.WardrobeTab))) and U4:GetHallDepotItemDataByInsID((U3.GetEquipStates(_ARG_1_.WardrobeTab))).lock_cnt and U4:GetHallDepotItemDataByInsID((U3.GetEquipStates(_ARG_1_.WardrobeTab))).lock_cnt > 0) then
          _ARG_0_.curPutOnInsId = _ARG_0_:IsOnSlotSkinList((U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false))) == 1 and U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false).ins_id or _ARG_0_.curPutOnInsId
          U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false).isUsing = true
        else
          U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false).isUsing = false
        end
        if U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false).res_id ~= U6.DefaultVehiclesId[U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false).itemSubType] then
        else
          _ARG_0_.DefaultVehicleInsId[U5:ArrayHallDepotToCommonItem(163, #{}, DataMgr.vst_skin and DataMgr.vst_skin == (163).insID, false, false, false, false).itemSubType] = (163).insID
        end
      end
      ::lbl_223::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if U4:GetHallDepotItemDataByInsID((U3.GetEquipStates(_ARG_1_.WardrobeTab))) then
        goto lbl_301
        if U4:GetHallDepotItemDataByInsID((U3.GetEquipStates(_ARG_1_.WardrobeTab))).resID == U1(150, 245, 137, 8, 186).res_id then
        else
          ::lbl_301::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if U1(150, 245, 137, 8, 186).lock_cnt and 0 < U1(150, 245, 137, 8, 186).lock_cnt and _ARG_0_.LoopScrollGridVehicles:GetItemData(_ARG_2_) then
        else
        end
      end
      _ARG_0_.AllItemList = {}
      if _ARG_0_:FilterMultiItem((_ARG_0_:DoFilterTags((_ARG_0_:DoSearch({}, U5:GetSearchString()))))) == nil or next((_ARG_0_:FilterMultiItem((_ARG_0_:DoFilterTags((_ARG_0_:DoSearch({}, U5:GetSearchString()))))))) == nil then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowEmptyGunSkinList"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_.UIRoot.WidgetSwitcher_Wardrobe_Empty:SetActiveWidgetIndex(1)
        _ARG_0_.UIRoot.WidgetSwitcher_Wardrobe_Empty:SetWidgetVisibility(_ENV)
      else
        _ARG_0_.UIRoot.WidgetSwitcher_Wardrobe_Empty:SetWidgetVisibility(U1)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGunListItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 212, 49, 84, 18, 77, 153, 68, 14, 170, 9, 92, 229, 202, 78, 71, 235, 229))
      if not require((U1(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 195, 82, 92, 239, 227, 52, 81))).CanClickNow(require((U1(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 195, 82, 92, 239, 227, 52, 81))).ClickFrequencyLimit.WardrobeVehicleTab) then
        return
      end
      if not _ARG_0_:GetVehicleList(_ARG_2_) then
        return
      end
      if _ARG_0_:GetItemInfo((_ARG_0_:GetItemIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))).lock_cnt and _ARG_0_:GetItemInfo((_ARG_0_:GetItemIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))).lock_cnt > 0 then
      end
      if not _ARG_0_:GetInsIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))) or _ARG_0_:GetInsIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))) == 0 or not require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByInsID((_ARG_0_:GetInsIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))) then
      end
      if not (_ARG_0_:GetItemInfo((_ARG_0_:GetItemIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))).lock_cnt and _ARG_0_:GetItemInfo((_ARG_0_:GetItemIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))).lock_cnt > 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChoiceVehicleTab"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 64, 242, 248, 52, 94, 20, 112, 153, 72, 49, 172, 13, 80, 210, 199, 73))
      _ARG_0_:PlayAudio(sound_config.subTab_v1)
      if _ARG_0_:GetVehicleList(_ARG_2_) then
      end
      if _ARG_0_:GetItemInfo((_ARG_0_:GetItemIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))).lock_cnt and _ARG_0_:GetItemInfo((_ARG_0_:GetItemIDByVehocleData((_ARG_0_:GetVehicleList(_ARG_2_))))).lock_cnt > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not require((U1(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 195, 82, 92, 239, 227, 52, 81))).CanClickNow(require((U1(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 195, 82, 92, 239, 227, 52, 81))).ClickFrequencyLimit.WardrobeVehicleItem) then
        return
      end
      if _ARG_0_.LoopScrollGridSkins:GetItemData(_ARG_2_) and _ARG_0_.LoopScrollGridSkins:GetItemData(_ARG_2_).lock_cnt and _ARG_0_.LoopScrollGridSkins:GetItemData(_ARG_2_).lock_cnt > 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClickItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        log_error((table.concat({
          U1(168, 253, 134, 31, 169, 51, 57, 174, 85, 5, 170, 29, 81, 255, 255, 79, 102, 247, 202, 125, 106, 16, 84, 152, 82, 55, 173, 4, 99, 227, 206, 66, 112, 230, 226, 109, 110, 13, 95, 143),
          U1(152, 227, 147, 8, 160, 97, 32, 169, 88, 33, 188, 29, 64, 197, 221, 82, 109, 186, 254, 46, 29, 31, 79, 144, 0)
        })))
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.golden_suit_module):VehicleNeedClothes(_ARG_1_.res_id) ~= 0 then
        return
      end
      if _ARG_1_.ins_id ~= _ARG_0_.curPutOnInsId then
        _ARG_1_.isUsing = false
      end
      if not _ARG_2_ and _ARG_1_.isUsing == true then
        if not _ARG_0_.DefaultVehicleInsId[_ARG_1_.itemSubType] then
          _ARG_0_.DefaultVehicleInsId[_ARG_1_.itemSubType] = require((table.concat({
            U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 13, 90, 225, 207, 72, 76, 253, 230, 63, 73, 19, 89, 142),
            U1(150, 245, 137, 8, 186)
          }))):GetWardrobeInsIdByResId(U2.DefaultVehiclesId[_ARG_1_.itemSubType]), require((table.concat({
            U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 13, 90, 225, 207, 72, 76, 253, 230, 63, 73, 19, 89, 142),
            U1(150, 245, 137, 8, 186)
          }))), _ARG_0_.DefaultVehicleInsId, _ARG_1_.itemSubType
        end
        return
      end
      if not DataMgr.IsValidTime(_ARG_1_.expireTS) then
        return
      end
      if not U3:IsCanUse(U2.DefaultVehiclesId[_ARG_1_.itemSubType]) then
        return
      end
      do return end
      _ARG_1_ = _ENV[129]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleVehicleView"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddTimerOnce(0, function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleSuperCarDoor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddTimerOnce(0, function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandleCabrioletBtn"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:AddTimerOnce(0, function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshGunListItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 197, 56, 91, 3, 67, 143, 72, 14, 170, 9, 92, 229, 202, 78, 96))
      if _ARG_0_:GetVehicleList(_ARG_2_) then
        if U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab) == tonumber(DataMgr.vst_skin) then
        else
        end
        if U3:GetHallDepotItemDataByInsID((U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab))) then
          if require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByResID(U3:GetHallDepotItemDataByInsID((U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab))).resID) and require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByResID(U3:GetHallDepotItemDataByInsID((U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab))).resID).lock_cnt and 0 < require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByResID(U3:GetHallDepotItemDataByInsID((U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab))).resID).lock_cnt then
          else
          end
        elseif _ARG_0_:GetVehicleList(_ARG_2_).VehicleDefualtSkinID then
        end
        if 0 < _ARG_0_:CountDistinctItemOfSubTab((_ARG_0_:GetVehicleList(_ARG_2_))) then
        else
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetTab(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab) then
        end
        if U3:GetHallDepotItemDataByInsID((U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab))) then
          if CDataTable.GetTableData(U1(165, 207, 143, 4, 174, 45, 51, 156, 92, 41, 177, 20, 118, 253, 223, 85, 78, 251, 231, 45, 84, 31, 65), U3:GetHallDepotItemDataByInsID((U2.GetEquipStates(_ARG_0_:GetVehicleList(_ARG_2_).WardrobeTab))).resID) then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVehicleProficiency"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 244, 60, 79, 20, 67, 142, 14, 52, 160, 6, 92, 229, 249, 72, 114, 248, 226, 40, 95))).IsOpen() then
        return
      end
      if not (CDataTable.GetTable((U1(176, 203, 149, 8, 168, 51, 0, 169, 88, 33, 188, 29, 64, 213, 217, 85, 101, 243, 240))) and CDataTable.GetTable((U1(176, 203, 149, 8, 168, 51, 0, 169, 88, 33, 188, 29, 64, 213, 217, 85, 101, 243, 240)))[_ARG_1_.VehicleDefualtSkinID]) or not CDataTable.GetTable((U1(176, 203, 149, 8, 168, 51, 0, 169, 88, 33, 188, 29, 64, 213, 217, 85, 101, 243, 240)))[_ARG_1_.VehicleDefualtSkinID].name then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshVehicleSkin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 197, 56, 91, 3, 67, 143, 72, 14, 170, 9, 92, 229, 202, 78, 64, 225, 238, 35))
      if _ARG_0_:GetVehicleSkins(_ARG_2_) then
        _ARG_0_:GetVehicleSkins(_ARG_2_).isSelected = _ARG_2_ == _ARG_0_.LoopScrollGridSkins:GetSelectIndex()
        if _ARG_0_:GetVehicleSkins(_ARG_2_).isSelected then
        else
        end
        if _ARG_0_:IsOnSlotSkinList((_ARG_0_:GetVehicleSkins(_ARG_2_))) and not (require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByResID(_ARG_0_:GetVehicleSkins(_ARG_2_).res_id) and require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByResID(_ARG_0_:GetVehicleSkins(_ARG_2_).res_id).lock_cnt and 0 < require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetHallDepotItemDataByResID(_ARG_0_:GetVehicleSkins(_ARG_2_).res_id).lock_cnt) then
        else
        end
      end
      if _ARG_0_:GetVehicleSkins(_ARG_2_) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsOnSlotSkinList"] = function(_ARG_0_, _ARG_1_)
    do
      if DataMgr.VehicleSlotList and DataMgr.VehicleSlotList[_ARG_1_.itemSubType] then
        goto lbl_26
        if nil == tonumber(_ARG_1_.ins_id) then
          return true, nil
        end
        ::lbl_26::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsOnSlotSkinListByInsID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return false
      end
      if DataMgr.VehicleSlotList and DataMgr.VehicleSlotList[itemData.itemSubType] then
        goto lbl_32
        if nil == tonumber(itemData.ins_id) then
          return true
        end
        ::lbl_32::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWardrobeDataChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSlotSkinDataChange"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTabIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 81, 255, 241, 47, 88, 2, 78, 168, 65, 58, 134, 2, 90, 232))
      _ARG_0_.LoopScrollGridVehicles:RefreshAllItems()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeItemStatusByInsID"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_:GetVehicleSkins(nil).ins_id == _ARG_1_ then
        _ARG_0_:GetVehicleSkins(nil)[_ARG_3_] = _ARG_2_
      else
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdatePutOnData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_.curPutOnInsId = nil
      if _ARG_4_ ~= nil then
        _ARG_0_:ChangeItemStatusByInsID(_ARG_4_.instid, false, (_ENV(154, 217, 178, 30, 164, 47, 49)))
      end
      if _ARG_3_ ~= nil then
        _ARG_0_.curPutOnInsId = _ARG_3_.instid
        _ARG_0_:RefreshSwitchPanel(_ARG_3_.res_id)
        _ARG_0_:RefreshMultiItem(_ARG_3_.res_id)
        _ARG_0_:ChangeItemStatusByInsID(_ARG_3_.instid, true, (_ENV(154, 217, 178, 30, 164, 47, 49)))
        _ARG_0_:RefreshTabIcon()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicles"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_:GetVehicles(_ARG_1_) == nil then
        _ARG_0_.TabItemCount[_ARG_1_] = {}
        _ARG_0_.vehicleCategory[_ARG_1_] = {}, _ARG_0_.vehicleCategory
        _ARG_0_.TypeStringToID[_ARG_2_] = _ARG_1_
        _ARG_0_.TypeIDToString[_ARG_1_] = _ARG_2_
      end
      _ARG_0_.TabItemCount[_ARG_1_][_ARG_3_.WardrobeTab] = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEquipTab"] = function(_ARG_0_, _ARG_1_)
    do
      do return GetTabEquip(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSkinCount"] = function(_ARG_0_)
    do
      do return _ARG_0_.LoopScrollGridSkins:GetItemCount() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSkin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log_tree(U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 81, 255, 241, 47, 88, 2, 78, 175, 75, 49, 161, 65, 81, 231, 210, 74), _ARG_2_)
      _ARG_0_.LoopScrollGridSkins:RefreshItem(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleSkins"] = function(_ARG_0_)
    do
      _ARG_0_.LoopScrollGridSkins:SetData({})
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleSkins"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(table.concat({
        U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 80, 255, 227, 11, 88, 25, 79, 159, 76, 61, 156, 10, 92, 232, 213, 11, 96, 225, 238, 35, 121, 0, 84, 128),
        U1(150)
      }), _ARG_1_)
      _ARG_0_.LoopScrollGridSkins:SetData(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleSkins"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.LoopScrollGridSkins:GetItemData(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleSlotSkins"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.LoopScrollBox_0:GetItemData(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleSlotSkins"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.LoopScrollBox_0:SetData(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearVehicleList"] = function(_ARG_0_)
    do
      _ARG_0_._tWaitingIconItemIDs = {}
      _ARG_0_.LoopScrollGridVehicles:SetData({})
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleList"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_._tWaitingIconItemIDs = {}
      _ARG_0_.LoopScrollGridVehicles:SetData(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleList"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.LoopScrollGridVehicles:GetItemData(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTabStringByID"] = function(_ARG_0_, _ARG_1_)
    do
      do return LocUtil.GetLocalizeResStr(_ARG_0_.TypeIDToString[tonumber(_ARG_1_)]) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIDByTabString"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.TypeStringToID[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicles"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.vehicleCategory[tonumber(_ARG_1_)] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SortVehicleTab"] = function(_ARG_0_)
    do
      goto lbl_11
      ::lbl_11::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowVehicleInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 80, 242, 248, 42, 107, 20, 78, 149, 67, 52, 170, 40, 91, 224, 201, 11, 96, 225, 238, 35, 127, 4, 69, 165),
        U1(183, 138, 218, 77)
      }) .. tostring(_ARG_2_))
      if _ARG_2_ ~= U2.DefaultVehiclesId[_ARG_3_] and _ARG_0_:GetDataSource() == (require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetItemSource(_ARG_1_) or EWardrobeDataSource.Wardrobe) then
      else
      end
      U4, U3 = require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 224, 60, 79, 21, 84, 147, 66, 61, 225, 22, 84, 244, 194, 89, 124, 232, 226, 18, 73, 0, 66, 141))):GetItemSource(_ARG_1_) or EWardrobeDataSource.Wardrobe, _ARG_2_
      if U5 == true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModelReady"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 116, 41, 171, 16, 104, 247, 216, 90, 100, 255, 229, 115, 114, 31, 107, 147, 68, 61, 163, 51, 80, 231, 194, 82) .. tostring(_ARG_3_))
      if U2(_ARG_3_) then
        _ARG_3_ = U3
      end
      if _ARG_3_ and _ARG_3_ == U3 then
        _ARG_0_:HandleVehicleView(_ARG_3_)
        _ARG_0_:HandleSuperCarDoor(_ARG_3_)
        _ARG_0_:HandleCabrioletBtn(_ARG_3_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleSceneLoaded"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ == LobbySceneManager.LEVEL_NAME.GARAGE or _ARG_3_ == LobbySceneManager.LEVEL_NAME.SUPERCAR then
        U1 = true
        log(bWriteLog and U2(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 21, 76, 244, 193, 56, 85, 24, 69, 144, 69, 11, 172, 4, 91, 227, 234, 68, 114, 238, 226, 41, 23, 65) .. _ARG_3_ .. tostring(U3))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[177]
    end
  end,
  ["CountDistinctItemOfSubTab"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_11
      if (nil)[_ARG_1_.WardrobeTab] then
        return (nil)[_ARG_1_.WardrobeTab]
      end
      ::lbl_11::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleName"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetTabStringByID(_ARG_2_) ~= nil then
        goto lbl_16
        ::lbl_16::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if 0 < 0 + nil then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTabItemCount"] = function(_ARG_0_)
    do
      goto lbl_71
      goto lbl_69
      if (163).mainTabType == _ENV and (37)[(163).subTabType] and ((163).expireTS == 0 or U1.require((U2(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 194, 82, 110, 255, 200, 40, 73, 24, 74))).GetServerTimeInSec() < (163).expireTS) and not _ARG_0_:CheckDefault(163) and not _ARG_0_:CheckIsHighLevelItem((163).resID) then
        ;(37)[(163).subTabType] = (37)[(163).subTabType] + 1
      end
      ::lbl_69::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_71::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckDefault"] = function(_ARG_0_, _ARG_1_)
    do
      do return CDataTable.GetTableDataByFilter(U1(183, 207, 129, 12, 184, 45, 34, 133, 68, 45, 178), U1(154, 206), _ARG_1_.resID) ~= nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsHighLevelItem"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV():IsWardRobeMultiLevelItem(_ARG_1_) then
        return false
      end
      if _ENV():GetMultiItemLevel(_ARG_1_) > 1 then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemIDByFristTab"] = function(_ARG_0_)
    do
      if not _ARG_0_.vehicleCategory or not next(_ARG_0_.vehicleCategory) then
        return 0
      end
      goto lbl_37
      if nil and next(nil) then
        goto lbl_33
        do return _ARG_0_:GetItemIDByVehocleData(nil) or 0 end
        ::lbl_33::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return 0
      end
      ::lbl_37::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemIDByVehocleData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil
      end
      do return (U1:GetHallDepotItemDataByInsID((GetEquipStates(_ARG_1_.WardrobeTab))) or {}).resID end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetInsIDByVehocleData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return nil
      end
      do return (GetEquipStates(_ARG_1_.WardrobeTab)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitVehicleSlotSkin"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 74, 244, 254, 41, 107, 20, 78, 149, 67, 52, 170, 50, 89, 233, 210, 120, 120, 227, 233))
      if not _ARG_1_ then
        return
      end
      if DataMgr.VehicleSlotList[_ARG_1_.ItemSubType] and next(DataMgr.VehicleSlotList[_ARG_1_.ItemSubType]) then
        goto lbl_96
        if U2:GetHallDepotItemDataByInsID(46) and (not U3:ArrayHallDepotToCommonItem(U2:GetHallDepotItemDataByInsID(46), #{}, false, false, false, false, false).lock_cnt or U3:ArrayHallDepotToCommonItem(U2:GetHallDepotItemDataByInsID(46), #{}, false, false, false, false, false).lock_cnt == 0) then
        end
        ::lbl_96::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshVehicleSlotItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 197, 56, 91, 3, 67, 143, 72, 14, 170, 9, 92, 229, 202, 78, 64, 230, 232, 57, 100, 21, 83, 129))
      if _ARG_0_:GetVehicleSlotSkins(_ARG_2_) and next((_ARG_0_:GetVehicleSlotSkins(_ARG_2_))) then
        _ARG_0_:GetVehicleSlotSkins(_ARG_2_).extra = _ARG_0_:GetVehicleSlotSkins(_ARG_2_).extra or {}
        _ARG_0_:GetVehicleSlotSkins(_ARG_2_).extra.bIsSkipDownload = true
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitSlotItemView"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if CDataTable.GetTableData(U1(186, 222, 130, 0), _ARG_3_.resID or _ARG_3_.res_id) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleDragReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and table.concat({
        U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 76, 244, 193, 56, 85, 24, 69, 144, 69, 28, 189, 0, 82, 212, 195, 74, 119, 243, 211, 34, 126, 9, 87, 156),
        U1(150)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BeginVehicleDragHint"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 65, 255, 240, 52, 83, 39, 67, 148, 73, 59, 163, 4, 113, 244, 199, 76, 91, 227, 233, 57))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndVehicleDragHint"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 70, 244, 243, 11, 88, 25, 79, 159, 76, 61, 139, 19, 84, 225, 238, 66, 125, 254))
      do return end
      _ARG_0_ = U1[96]
    end
  end,
  ["InitDragWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if CDataTable.GetTableData(U1(186, 222, 130, 0), _ARG_2_.resID or _ARG_2_.res_id) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleDragCanceled"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 76, 244, 193, 56, 85, 24, 69, 144, 69, 28, 189, 0, 82, 197, 199, 69, 112, 239, 235, 40, 73))
      _ARG_0_:EndVehicleDragHint()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleSlotDrag"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 76, 244, 193, 56, 85, 24, 69, 144, 69, 11, 163, 14, 65, 194, 212, 74, 116))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleSlotDrop"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 1, 76, 244, 193, 56, 85, 24, 69, 144, 69, 11, 163, 14, 65, 194, 212, 68, 99))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:EndVehicleDragHint()
      if not _ARG_0_:GetDataEntity():GetDataByInsID((tonumber(_ARG_3_.dragExtendData))) then
        return
      end
      if _ARG_0_:GetDataEntity():GetDataByInsID((tonumber(_ARG_3_.dragExtendData))) and not DataMgr.IsValidTime(_ARG_0_:GetDataEntity():GetDataByInsID((tonumber(_ARG_3_.dragExtendData))).expireTS) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.golden_suit_module):VehicleNeedClothes(_ARG_0_:GetDataEntity():GetDataByInsID((tonumber(_ARG_3_.dragExtendData))).resID) ~= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EquipSlotVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UnEquipSlotVehicle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleSlotRemove"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:EndVehicleDragHint()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCheckBox"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.toggle_v1)
      if _ARG_0_.UIRoot.CheckBox_Sort:IsChecked() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectSortItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_1_ and _ARG_1_.TextBlock_ItemName then
        _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.text)
      end
      if _ARG_2_.type == _ARG_0_.ENUM_SORT_TYPE.LATEST then
        U1:SetSortPreference(_ARG_0_, true)
      else
        U1:SetSortPreference(_ARG_0_, false)
      end
      _ARG_0_:OnWardrobeDataChange()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCheckBoxState"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.TextBlock_SortViaTime:SetText(LocUtil.LocalizeResFormat(34618))
      if U1:GetSortPreference(_ARG_0_) then
      elseif U1:GetSortPreference(_ARG_0_) == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_ShowTips"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBaseLevel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_:GetItemInfo((U1():GetItemID(_ARG_0_:GetCurrentSelectId(), 1))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHighLevel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_:GetItemInfo((U1():GetItemID(_ARG_0_:GetCurrentSelectId(), 2))) or not next((_ARG_0_:GetItemInfo((U1():GetItemID(_ARG_0_:GetCurrentSelectId(), 2))))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMultiItem"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV():IsWardRobeMultiLevelItem(_ARG_1_) then
        return
      end
      _ENV():UpdateSelectMultiItem(_ARG_1_)
      _ARG_0_ = _ARG_0_
      if _ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).res_id == _ENV():GetItemID(_ARG_1_, 1) or _ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).res_id == _ENV():GetItemID(_ARG_1_, 2) then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemInfo"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_11
      if (nil).res_id == _ARG_1_ then
      else
        ::lbl_11::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitLevelCanvas"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Wardrobe_EventSpin_item_1.CanvasPanel_Lock, false, false)
      _ARG_0_.UIRoot.Wardrobe_EventSpin_item_1.WidgetSwitcher_Level:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Wardrobe_EventSpin_item_1.Image_notUsing, (table.concat({
        U1(220, 237, 134, 0, 168, 110, 27, 163, 84, 103, 147, 30, 71, 244, 207, 20, 65, 251, 228, 56, 18, 38, 71, 142, 68, 42, 160, 3, 80, 169, 231, 95, 127, 235, 244, 98, 122, 0, 68, 136),
        U1(129, 197, 133, 8, 152, 8, 9, 130, 85, 63, 240, 55, 87, 247, 219, 94, 112, 181, 192, 21, 98, 24, 69, 147, 78, 7, 153, 4, 93, 239, 197, 71, 118, 186, 182, 18, 93, 15, 81, 194),
        U1(164, 226, 184, 4, 174, 46, 56, 147, 102, 45, 183, 24, 70, 250, 211, 11, 50, 197, 231, 51, 90)
      })))
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Wardrobe_EventSpin_item_1.Image_using, (table.concat({
        U1(220, 237, 134, 0, 168, 110, 27, 163, 84, 103, 147, 30, 71, 244, 207, 20, 65, 251, 228, 56, 18, 38, 71, 142, 68, 42, 160, 3, 80, 169, 231, 95, 127, 235, 244, 98, 122, 0, 68, 136),
        U1(129, 197, 133, 8, 152, 8, 9, 130, 85, 63, 240, 55, 87, 247, 219, 94, 112, 181, 192, 21, 98, 24, 69, 147, 78, 7, 153, 4, 93, 239, 197, 71, 118, 186, 181, 18, 93, 15, 81, 194),
        U1(164, 226, 184, 4, 174, 46, 56, 147, 102, 45, 183, 24, 70, 250, 211, 11, 49, 197, 231, 51, 90)
      })))
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Wardrobe_EventSpin_item_2.Image_notUsing, (table.concat({
        U1(220, 237, 134, 0, 168, 110, 27, 163, 84, 103, 147, 30, 71, 244, 207, 20, 65, 251, 228, 56, 18, 38, 71, 142, 68, 42, 160, 3, 80, 169, 231, 95, 127, 235, 244, 98, 122, 0, 68, 136),
        U1(129, 197, 133, 8, 152, 8, 9, 130, 85, 63, 240, 55, 87, 247, 219, 94, 112, 181, 192, 21, 98, 24, 69, 147, 78, 7, 153, 4, 93, 239, 197, 71, 118, 186, 180, 18, 93, 15, 81, 194),
        U1(164, 226, 184, 4, 174, 46, 56, 147, 102, 45, 183, 24, 70, 250, 211, 11, 48, 197, 231, 51, 90)
      })))
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Wardrobe_EventSpin_item_2.Image_using, (table.concat({
        U1(220, 237, 134, 0, 168, 110, 27, 163, 84, 103, 147, 30, 71, 244, 207, 20, 65, 251, 228, 56, 18, 38, 71, 142, 68, 42, 160, 3, 80, 169, 231, 95, 127, 235, 244, 98, 122, 0, 68, 136),
        U1(129, 197, 133, 8, 152, 8, 9, 130, 85, 63, 240, 55, 87, 247, 219, 94, 112, 181, 192, 21, 98, 24, 69, 147, 78, 7, 153, 4, 93, 239, 197, 71, 118, 186, 179, 18, 93, 15, 81, 194),
        U1(164, 226, 184, 4, 174, 46, 56, 147, 102, 45, 183, 24, 70, 250, 211, 11, 55, 197, 231, 51, 90)
      })))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurrentSelectId"] = function(_ARG_0_)
    do
      if _ARG_0_.LoopScrollGrid_Normal:GetSelectIndex() < 1 then
        return 0
      end
      if not _ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())) then
        return 0
      end
      do return _ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedShowLevelSwitchCanvas"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetCurrentSelectId() == 0 then
        return false
      end
      do return __super.NeedShowLevelSwitchCanvas(_ARG_0_, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MarkVehicleIconWaitingDownload"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ENV then
        return
      end
      if not _ARG_1_ then
        return
      end
      if not _ARG_0_._tWaitingIconItemIDs then
        _ARG_0_._tWaitingIconItemIDs = {}
      end
      _ARG_0_._tWaitingIconItemIDs[_ARG_1_] = _ARG_2_ and true or nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWaitingVehicleIcons"] = function(_ARG_0_)
    do
      if not _ARG_0_._tWaitingIconItemIDs or not next(_ARG_0_._tWaitingIconItemIDs) then
        return
      end
      if not _ARG_0_:IsShow() then
        return
      end
      goto lbl_52
      ::lbl_52::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_89
      if not (CDataTable.GetTableData(U1(186, 222, 130, 0), (table.insert({}, 163))) and CDataTable.GetTableData(U1(186, 222, 130, 0), (table.insert({}, 163))).ItemSmallIcon) or CDataTable.GetTableData(U1(186, 222, 130, 0), (table.insert({}, 163))).ItemSmallIcon == U1() then
        _ARG_0_._tWaitingIconItemIDs[table.insert({}, 163)] = nil
      elseif require((U1(144, 198, 142, 8, 163, 53, 120, 175, 95, 37, 178, 30, 75, 184, 198, 90, 104, 197, 226, 41, 84, 29))).IsTextureDownloadedByPath(CDataTable.GetTableData(U1(186, 222, 130, 0), (table.insert({}, 163))).ItemSmallIcon) then
        _ARG_0_._tWaitingIconItemIDs[table.insert({}, 163)] = nil
      end
      ::lbl_89::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDownloadFinish"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(164, 203, 149, 9, 191, 46, 52, 169, 102, 45, 183, 24, 70, 250, 211, 27, 76, 244, 211, 50, 74, 31, 74, 147, 65, 60, 137, 8, 91, 239, 213, 67, 51) .. tostring(_ARG_3_ and _ARG_3_.itemID) .. U1(211, 217, 130, 1, 171, 111, 21, 160, 89, 43, 180, 53, 74, 225, 216, 119, 108, 251, 243, 20, 73, 20, 75, 181, 100, 98, 239) .. tostring(_ARG_0_.ClickDownLoadItemID))
      if (_ARG_3_ and _ARG_3_.itemID or 0) == 0 or _ARG_0_.ClickDownLoadItemID ~= (_ARG_3_ and _ARG_3_.itemID or 0) then
        return
      end
      if require((table.concat({
        U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 243, 50, 74, 31, 74, 147, 65, 60, 225, 17, 64, 224, 192, 78, 97, 164, 247, 56, 75, 7, 83, 158),
        U1(172, 199, 134, 3, 172, 38, 51, 190)
      }))).GetState(require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 243, 50, 74, 31, 74, 147, 65, 60, 225, 17, 64, 224, 192, 78, 97, 213, 228, 34, 67, 18, 66))).ENUM_DownloadType.ODPAK, {
        _ARG_0_.ClickDownLoadItemID
      }) == require((U1(144, 198, 142, 8, 163, 53, 120, 191, 92, 61, 190, 95, 73, 249, 209, 82, 96, 180, 243, 50, 74, 31, 74, 147, 65, 60, 225, 17, 64, 224, 192, 78, 97, 213, 228, 34, 67, 18, 66))).ENUM_DownloadState.Done and _ARG_0_.LoopScrollGridSkins:GetSetData() then
        goto lbl_292
        if U1(172, 199, 134, 3, 172, 38, 51, 190).res_id == _ARG_0_.ClickDownLoadItemID then
        else
          ::lbl_292::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
