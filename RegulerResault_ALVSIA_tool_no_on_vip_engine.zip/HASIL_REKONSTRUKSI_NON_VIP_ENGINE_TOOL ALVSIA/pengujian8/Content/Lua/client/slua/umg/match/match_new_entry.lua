do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(33, 193, 105, 187, 133)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 249, 49, 199, 17, 172, 192, 252, 21, 157, 113, 71, 178, 140, 181, 57, 208, 197, 49))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.bShowTextTip = false
      _ARG_0_.hideTipTimer = nil
      _ARG_0_.bClickTipButton = false
      _ARG_0_.resetClickTipTimer = nil
      _ARG_0_.autoTestTimer = nil
      _ARG_0_.reqDataTimer = nil
      _ARG_0_.nConfirmCloseTime = 0
      _ARG_0_.bShowPloyTextTip = false
      _ARG_0_.nSkinID = _ENV
      _ARG_0_.preMatchState = nil
      _ARG_0_.MathInfoState = U1
      _ARG_0_.nMatchPanelState, _ARG_0_ = U1, _ARG_0_
      _ARG_0_.bHighLevelTipsExpanded = false
      _ARG_0_.bDebugTimersSet = false
      _ARG_0_._bLTMatchShown = false
      _ARG_0_._bHighLevelTipsShown = false
      _ARG_0_.bTeammatesMatched = false
      _ARG_0_.bTeammatesMatchedTimerPending = false
      _ARG_0_.bTeammatesMatchedTimer = nil
      _ARG_0_.bShowHistory = false
      _ARG_0_.needRecoverWin = false
      _ARG_0_.LTMatchAnimTimer = nil
      _ARG_0_.bIsNarutoView = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      U1.InitData()
      _ARG_0_.doubelCardUI = _ARG_0_:CreateChildWindow(U2(1, 204, 102, 190, 151, 107, 224, 182, 229, 46, 205, 249, 0, 193, 59, 168, 222, 248, 59, 153, 116, 76), U3.UIManager.UI_Config.lobby_doublecard_entrance)
      U3.log((U2(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 212, 22, 145, 114, 65, 161, 139, 242, 33, 212)))
      _ARG_0_.isInNarutoVersionTime = U3.LobbySystem.IsInNarutoVersionTime()
      if _ARG_0_.isInNarutoVersionTime then
        _ARG_0_.FlameShadow_Start_UIBP = _ARG_0_:CreateChildWindow(U2(1, 204, 102, 190, 151, 107, 224, 182, 229, 46, 205, 249, 16, 198, 43, 167, 215), U3.UIManager.UI_Config.FlameShadow_Start_UIBP)
      end
      _ARG_0_._bLightLoading = false
      _ARG_0_._lightLoadingTimer = nil
      _ARG_0_.bMemberUGCDownloadRequired = false
      _ARG_0_.bAutoReadyAfterMemberDownload = false
      _ARG_0_.nAutoReadyMemberModID = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SelfHitTestInvisible"] = function(_ARG_0_)
    do
      __super.SelfHitTestInvisible(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Entry, _ARG_0_.OnClickEntry, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Expand, _ARG_0_.OnClickExpand, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_0, _ARG_0_.OnClickOpenSettings, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_ArenaWeapon, _ARG_0_.OnClickArenaWeapon, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Mask, _ARG_0_.OnClickCurMode, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Lock, _ARG_0_.OnClickEntryRestrict, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Close, _ARG_0_.OnClickCloseRewardTips, _ARG_0_)
      if _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Button_Click, _ARG_0_.OnClickButton_Click, _ARG_0_)
        if _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Button_0 then
          _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Button_0, _ARG_0_.OnClickPrivateRoomGameplayItemClose, _ARG_0_)
        end
      end
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Anina_Permanent, U1(13, 195, 73, 166, 159, 117, 209, 163, 226, 36, 207, 224, 45, 192, 39, 185, 218, 248, 28), _ARG_0_.LobbyEffectEnd, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_MATCH_MODE_SELECT_CHANGE, _ARG_0_.OnMatchModSelectChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_SWITCHTO_PAGE_START, _ARG_0_.OnSwitchToPageStart, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_SWITCHTO_PAGE_END, _ARG_0_.OnSwitchToPageEnd, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_LOBBY_FADE_IN_ANIM_FINISH, _ARG_0_.OnEnter, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_MATCH_UPDATE_STATUS, _ARG_0_.OnUpdateMatchStatus, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_TEAMUP, U2.EVENTID_TEAMUP_TEAMINFO_SYNC, _ARG_0_.OnUpdateMatchStatus, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_TEAMUP, U2.EVENTID_TEAMUP_CHECK_TEAM_STATE, _ARG_0_.OnCheckTeamMatchState, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MENTOR, U2.EVENTID_MENTOR_TEAM_REQUEST_NOTIFY_OTHERS, _ARG_0_.UpdateMentorTeamWaiting, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MENTOR, U2.EVENTID_MENTOR_PREMATCH_STATE, _ARG_0_.UpdateMentorPrematchState, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_MATCH_UPDATE_TIME, _ARG_0_.OnUpdateMatching, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_ON_MATCH_RES_OK, _ARG_0_.OnMatchResOK, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY_SOCIAL, U2.EVENTID_LOBBY_SOCIAL_EDIT_STATUS, _ARG_0_.UpdateEditingState, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVNETID_MATCH_NEW_GUIDE, U2.EVENTID_MATCH_NEWBIE_CLICK_Entry, _ARG_0_.OnClickEntry, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_ON_MATCH_OPTION_SAVE, _ARG_0_.OnMatchOptionsChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_NEXTDAY, U2.EVENTID_NEXTDAY_ZERO, _ARG_0_.OnNextDayHandler, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTION, U2.EVENTID_START_BTN_ACTION, _ARG_0_.OnStartBtnAction, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTION, U2.EVENTID_GROWTH_PROJECT_DEPOT_GUIDE_MATCH, _ARG_0_.UpdateGrowthDepotGuideReLogin, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTION, U2.EVENTID_HIDE_MATCH_HAND_TIP, _ARG_0_.OnHideMatchHandTip, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTION, U2.EVENTID_ACTION_MATCH_EVENT, _ARG_0_.UpdateCDFinishDepotGuide, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTION, U2.EVENTID_NEWBIE_GUIDE_MATCH_NUM, _ARG_0_.UpdateMatchNumOnCloseBtn, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Animation_Hand, U1(13, 195, 73, 166, 159, 117, 209, 163, 226, 36, 207, 224, 45, 192, 39, 185, 218, 248, 28), _ARG_0_.OnAnimationEnd, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY_SOCIAL, U2.EVENTID_LOBBY_SOCIAL_PHOTO, _ARG_0_.UpdatePhoto, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_LOBBY_SHOW_SELECT_MODE, _ARG_0_.DoClickSelectModeEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_ON_MATCH_LT_GET_DATA, _ARG_0_.OnMatchLTGetData, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_ON_MATCH_LT_SWITCHMODE, _ARG_0_.OnMatchLTSwitchMode, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_LOBBY_COME_BACK_FIRSTBATTLE_START_MATCH, _ARG_0_.ONFBStartMatch, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_MATCH_CROSS_SUCCESS, _ARG_0_.UpDateCrossSuccess, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_MATCH_UGC_AUTOMATCH, _ARG_0_.OnClickEntry, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOGIN, U2.EVENTID_QR_LOGIN_QRCODE_RESTRICT_CHANGE, _ARG_0_.OnQRCodeRestrictChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_OLD_WIDGET, U2.EVENTID_ON_ALL_WIDGET_HIDE, _ARG_0_.OnWidgetHide, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STATE, U2.EVENTID_ON_MODE_POST_SWITCH, _ARG_0_.OnModePostSwitch, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_PLAY_HALL_MATCHMOD_HOT_STAT_CHANGE, _ARG_0_.OnModHotStatChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_PLAY_HALL_ROOM_CREATE, _ARG_0_.OnUGCPlayHallRoomCreate, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_PLAY_HALL_ROOM_EXIT_ALL, _ARG_0_.OnUGCPlayHallRoomExit, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_PLAY_HALL_ROOM_AUTOSTART_INFO_CHANGE, _ARG_0_.OnRoomAutoStartInfoChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_PLAY_HALL_ROOM_PLAYER_CHANGE, _ARG_0_.OnMatchRoomPlayerChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_PENDING_MATCH_CANCEL, _ARG_0_.OnUGCPlayHallPendingMatchCancel, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_CHANGE_MOD_NOTIFY, _ARG_0_.OnMatchModSelectChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_GET_MOD_BATCH, _ARG_0_.OnUGCMatchModInfoReady, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_STARTGAME_NEWPROCESS, _ARG_0_.OnUGCStartGame, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_PUFFER, U2.EVENTID_PUFFER_DOWNLOADFINISH, _ARG_0_.OnMapDownloadFinish, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_DOWNLOAD_RES_COMPLETE, _ARG_0_.OnUGCDownloadResComplete, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_UGC, U2.EVENTID_UGC_RES_STATUS_CHANGED, _ARG_0_.OnResStatusChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_PROMOTION, U2.EVENTID_PROMOTION_SELECT_PROMOTION_RSP, _ARG_0_.OnPromotionSelectChanged, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MATCH, U2.EVENTID_MATCH_VIEW_SELECT_CHANGE, _ARG_0_.OnMatchViewSelectChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_TEAMUP, U2.EVENTID_TEAMUP_NEW_TEAM_MATCH_MODE, _ARG_0_.CheckReturnMatchTips, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY, U2.EVENTID_BACK_USER_MODE_RECOMMEND, _ARG_0_._OnBackUserModeRecommend, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnBackUserModeRecommend"] = function(_ARG_0_)
    do
      print(bWriteLog and string.format(table.concat({
        U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 1, 164, 240, 252, 27, 147, 83, 91, 165, 149, 214, 52, 213, 211, 6, 219, 61, 181, 207, 224, 13, 134, 114, 24, 162, 146),
        U1(33, 219, 36, 232, 131, 107, 213, 165, 200, 39, 206, 213, 33, 202, 115, 239, 193, 177, 88, 144, 103, 91, 147, 143, 244, 44, 223, 139, 113, 205, 114, 250, 192, 236, 11, 131, 91, 87, 180, 146),
        U1(127, 136, 123)
      }), tostring(_ARG_0_._bPrivateRoomGameplayUserClosed), tostring(_ARG_0_._bPrivateRoomGameplayHasShown), tostring(LobbySystem and LobbySystem.backUserRecommendMode)))
      if _ARG_0_._bPrivateRoomGameplayUserClosed or _ARG_0_._bPrivateRoomGameplayHasShown then
        print(bWriteLog and table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 1, 164, 240, 252, 27, 147, 83, 91, 165, 149, 214, 52, 213, 211, 6, 219, 61, 181, 207, 224, 13, 134, 114, 24, 163, 156),
          U1(43, 221, 120, 173, 146, 56, 210, 174, 171, 39, 206, 197, 47, 142, 40, 166, 211, 250, 11)
        }))
        return
      end
      _ARG_0_._bRecommendConsumed = false
      _ARG_0_:RefreshPrivateRoomGameplayItemVisibility()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[177]
    end
  end,
  ["UpdatePhoto"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_:Collapsed()
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch):CheckHomeSwitchOpen() and require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
        U1(1, 194, 102, 188, 132, 119, 220)
      }))).curPage == ENUM_LobbyPageType.Left then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 205, 23, 139, 114, 97, 174, 142, 239, 50, 208, 218, 61, 196, 59))
      U2.__super.OnPostInitialize(_ARG_0_)
      _ARG_0_._needInit = true
      _ARG_0_:SetEnterMetroTxMissionDesc()
      U3(_ARG_0_.UIRoot.Common_Tips_Bg02_UIBP)
      _ARG_0_:CheckReturnMatchTips()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 206, 16, 151, 113))
      if U2.nMatchStatus ~= U3.Matching then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Border_0, false)
        _ARG_0_:_SetLTMatchVisible(false)
        U4(_ARG_0_.UIRoot.SizeBox_top)
        _ARG_0_:_SetHighLevelTipsVisible(false)
        _ARG_0_:UpdateWaitForMatchBackground()
        _ARG_0_.MathInfoState = U5
        _ARG_0_.bHighLevelTipsExpanded = false
        _ARG_0_.nMatchPanelState = U6.Collapsed
        _ARG_0_.UIRoot.Image_13:SetRenderAngle(0)
      end
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_29, false)
      _ARG_0_:RefreshPrivateRoomGameplayItemVisibility()
      if not _ARG_0_.privateRoomGameplayTickTimer and not _ARG_0_._bPrivateRoomGameplayHasShown and not _ARG_0_._bPrivateRoomGameplayUserClosed then
        _ARG_0_.privateRoomGameplayTickTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV:RefreshPrivateRoomGameplayItemVisibility()
          return
        end, 0, 1)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPrivateRoomGameplayItem"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
        return
      end
      if not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Image_bg then
        return
      end
      if not (LobbySystem and LobbySystem.GetBackUserRecommendMode) or not LobbySystem.GetGameplayItemConfig then
        return
      end
      if not LobbySystem.GetGameplayItemConfig((LobbySystem.GetBackUserRecommendMode())) then
        return
      end
      if _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Image_bg and LobbySystem.GetGameplayItemConfig((LobbySystem.GetBackUserRecommendMode())).IconEntry and LobbySystem.GetGameplayItemConfig((LobbySystem.GetBackUserRecommendMode())).IconEntry ~= U1() then
      end
      if _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.TextBlock_0 and LobbySystem.GetGameplayItemConfig((LobbySystem.GetBackUserRecommendMode())).NameLocId and LobbySystem.GetGameplayItemConfig((LobbySystem.GetBackUserRecommendMode())).NameLocId > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PRIVATE_ROOM_RECOMMEND_MIN_LEVEL"] = 5,
  ["PRIVATE_ROOM_RECOMMEND_COOLDOWN"] = 60,
  ["_IsLevelReachRecommend"] = function(_ARG_0_)
    do
      do return DataMgr.roleData.level >= U1.PRIVATE_ROOM_RECOMMEND_MIN_LEVEL end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_HasValidRecommendMode"] = function(_ARG_0_)
    do
      if not LobbySystem or not LobbySystem.backUserRecommendMode then
        return false
      end
      if not LobbySystem.backUserRecommendMode or LobbySystem.backUserRecommendMode <= 0 then
        return false
      end
      if _ARG_0_._bRecommendConsumed then
        return false
      end
      if not LobbySystem.GetGameplayItemConfig or not LobbySystem.GetGameplayItemConfig(LobbySystem.backUserRecommendMode) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsInTeam"] = function(_ARG_0_)
    do
      if _ENV and IsInTeam then
        return IsInTeam() == true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsInMatching"] = function(_ARG_0_)
    do
      do return _ENV and nMatchStatus ~= nil and nMatchStatus ~= U1.Not end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsModeSelectionDeciding"] = function(_ARG_0_)
    do
      if _ARG_0_.new_mode_entry_ui and _ARG_0_.new_mode_entry_ui.UIRoot and _ARG_0_.new_mode_entry_ui.UIRoot and _ARG_0_.new_mode_entry_ui.UIRoot.IsVisible and _ARG_0_.new_mode_entry_ui.UIRoot:IsVisible() then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsInModeConfirmedCooldown"] = function(_ARG_0_)
    do
      if not _ARG_0_._modeConfirmedTs then
        return false
      end
      do return os.time() - _ARG_0_._modeConfirmedTs < U1.PRIVATE_ROOM_RECOMMEND_COOLDOWN end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_HasOtherGuideShowing"] = function(_ARG_0_)
    do
      if _ARG_0_._bLTMatchShown or _ARG_0_._bHighLevelTipsShown then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsInUserActionCooldown"] = function(_ARG_0_)
    do
      if not _ARG_0_._lastUserActionTs then
        return false
      end
      do return os.time() - _ARG_0_._lastUserActionTs < U1.PRIVATE_ROOM_RECOMMEND_COOLDOWN end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CanShowPrivateRoomGameplayItem"] = function(_ARG_0_)
    do
      if _ARG_0_._gmBypassGameplayBannerRestrict then
      elseif Client and not Client.IsJaguar() then
        print(bWriteLog and table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 166, 134, 247, 40, 212, 150, 38, 219, 63, 169, 205, 227, 85, 200, 120, 87, 164, 215),
          U1(11, 222, 66, 169, 145, 109, 209, 165)
        }))
        return false
      end
      if not _ARG_0_._gmBypassGameplayBannerRestrict and not _ARG_0_:_IsLevelReachRecommend() then
        return false
      end
      if not _ARG_0_:_HasValidRecommendMode() then
        return false
      end
      if _ARG_0_:_IsInTeam() then
        print(bWriteLog and table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 166, 134, 247, 40, 212, 150, 38, 219, 63, 169, 205, 227, 85, 161, 120, 108, 181, 150),
          U1(47)
        }))
        return false
      end
      if _ARG_0_:_IsInMatching() then
        print(bWriteLog and string.format(table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 166, 134, 247, 40, 212, 150, 38, 219, 63, 169, 205, 227, 85, 161, 120, 117, 177, 131),
          U1(33, 197, 97, 166, 145, 56, 195, 163, 234, 63, 212, 213, 121, 139, 61)
        }), tostring(U3 and U3.nMatchStatus)))
        return false
      end
      if _ARG_0_:_IsInModeConfirmedCooldown() then
        print(bWriteLog and string.format(table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 166, 134, 247, 40, 212, 150, 38, 219, 63, 169, 205, 227, 85, 165, 121, 92, 181, 180),
          U1(45, 195, 110, 161, 132, 117, 213, 179, 200, 36, 206, 202, 32, 193, 57, 164, 146, 233, 11, 197, 35, 91, 224, 137, 244, 44, 140, 147, 39)
        }), tostring(_ARG_0_._modeConfirmedTs), tostring(os.time())))
        return false
      end
      if _ARG_0_:_HasOtherGuideShowing() then
        print(bWriteLog and string.format(table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 166, 134, 247, 40, 212, 150, 38, 219, 63, 169, 205, 227, 85, 167, 98, 80, 181, 133),
          U1(5, 216, 97, 172, 147, 75, 216, 184, 252, 34, 207, 193, 100, 226, 26, 247, 151, 238, 88, 176, 111, 79, 168, 218, 190, 40)
        }), tostring(_ARG_0_._bLTMatchShown), tostring(_ARG_0_._bHighLevelTipsShown)))
        return false
      end
      if _ARG_0_:_IsInUserActionCooldown() then
        print(bWriteLog and string.format(table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 166, 134, 247, 40, 212, 150, 38, 219, 63, 169, 205, 227, 85, 189, 101, 93, 162, 182),
          U1(33, 217, 97, 167, 152, 91, 223, 184, 231, 47, 206, 209, 42, 142, 58, 185, 143, 184, 11, 216, 104, 71, 183, 218, 190, 40)
        }), tostring(_ARG_0_._lastUserActionTs), tostring(os.time())))
        return false
      end
      print(bWriteLog and table.concat({
        U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 241, 13, 171, 220, 206, 16, 151, 113, 21, 180, 149, 238, 62, 145, 158, 53, 210, 50, 250, 193, 226, 6, 140, 127, 76, 185, 152),
        U1(44, 222, 40, 184, 151, 107, 195, 178, 239, 98)
      }))
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1.time
    end
  end,
  ["RefreshPrivateRoomGameplayItemVisibility"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
        print(bWriteLog and table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 252, 43, 172, 192, 248, 11, 144, 38, 91, 171, 142, 235, 43, 212, 210, 110, 158, 11, 147, 240, 226, 7, 156, 54, 87, 162, 215),
          U1(11, 217, 109, 165, 180, 72, 144, 185, 226, 39)
        }))
        return
      end
      if _ARG_0_._bPrivateRoomGameplayUserClosed then
        print(bWriteLog and U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 252, 43, 172, 192, 248, 11, 144, 38, 91, 171, 142, 235, 43, 212, 210, 110, 158, 43, 169, 199, 255, 43, 132, 121, 75, 181, 147))
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP, false)
        _ARG_0_:_StopPrivateRoomGameplayTickTimer()
        return
      end
      if _ARG_0_._bPrivateRoomGameplayHasShown then
        print(bWriteLog and table.concat({
          U1(25, 253, 90, 143, 151, 117, 213, 167, 231, 42, 216, 251, 100, 252, 43, 172, 192, 248, 11, 144, 38, 91, 171, 142, 235, 43, 212, 210, 110, 158, 54, 187, 209, 222, 0, 135, 97, 86, 240, 155),
          U1(45, 206, 99)
        }))
        _ARG_0_:_StopPrivateRoomGameplayTickTimer()
        return
      end
      if _ARG_0_:_CanShowPrivateRoomGameplayItem() then
        _ARG_0_._bPrivateRoomGameplayHasShown = true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PlayPrivateRoomGameplayFadeIn"] = function(_ARG_0_)
    do
      if _ARG_0_._bPrivateRoomGameplayFadeInPlayed then
        return
      end
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
        return
      end
      if not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Fadein then
        return
      end
      _ARG_0_._bPrivateRoomGameplayFadeInPlayed = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_PlayPrivateRoomGameplayFadeOut"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
        if _ARG_1_ then
          _ARG_1_()
        end
        return
      end
      if not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Fadeout or not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.PlayAnimation then
        if _ARG_1_ then
        end
        return
      end
      if _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP.Fadeout.GetEndTime and pcall(function()
        do return _ENV:GetEndTime() end
        return
      end) and type(pcall(function()
        do return _ENV:GetEndTime() end
        return
      end)) == U1(44, 216, 101, 170, 147, 106) and 0 < pcall(function()
        do return _ENV:GetEndTime() end
        return
      end) then
      end
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetGameplayBannerForGm"] = function(_ARG_0_)
    do
      _ARG_0_._gmBypassGameplayBannerRestrict = true
      _ARG_0_._bRecommendConsumed = false
      _ARG_0_._bPrivateRoomGameplayUserClosed = false
      _ARG_0_._bPrivateRoomGameplayHasShown = false
      _ARG_0_._bPrivateRoomGameplayFadeInPlayed = false
      _ARG_0_._modeConfirmedTs = nil
      _ARG_0_._lastUserActionTs = nil
      _ARG_0_._bLTMatchShown = false
      _ARG_0_._bHighLevelTipsShown = false
      if LobbySystem and LobbySystem.SetBackUserRecommendMode and LobbySystem.GameplayType then
        LobbySystem.SetBackUserRecommendMode(LobbySystem.GameplayType.Metro)
      end
      _ARG_0_:_StopPrivateRoomGameplayTickTimer()
      _ARG_0_:RefreshPrivateRoomGameplayItemVisibility()
      if not _ARG_0_._bPrivateRoomGameplayHasShown and not _ARG_0_.privateRoomGameplayTickTimer then
        _ARG_0_.privateRoomGameplayTickTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV:RefreshPrivateRoomGameplayItemVisibility()
          return
        end, 0, 1)
      end
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 152, 215, 238, 29, 140, 65, 73, 173, 130, 235, 55, 208, 207, 22, 223, 48, 180, 199, 255, 46, 135, 100, 127, 189, 215),
        U1(38, 194, 102, 173)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopPrivateRoomGameplayTickTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.privateRoomGameplayTickTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.privateRoomGameplayTickTimer)
        _ARG_0_.privateRoomGameplayTickTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_MarkUserAction"] = function(_ARG_0_)
    do
      _ARG_0_._lastUserActionTs = os.time()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_MarkModeConfirmed"] = function(_ARG_0_)
    do
      _ARG_0_._modeConfirmedTs = os.time()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEnterMetroTxMissionDesc"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 153, 215, 233, 61, 150, 114, 77, 178, 170, 254, 47, 195, 217, 0, 198, 19, 179, 209, 254, 1, 135, 120, 124, 181, 132),
        U1(33)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModePostSwitch"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 23, 156, 99, 120, 175, 148, 239, 8, 198, 223, 32, 221, 54))
      if not _ARG_0_._needInit then
        return
      end
      _ARG_0_.bShowHistory = false
      _ARG_0_:_MarkModeConfirmed()
      _ARG_0_:RefreshPrivateRoomGameplayItemVisibility()
      _ARG_0_:InitUI()
      _ARG_0_:CheckAndAddEffect()
      _ARG_0_:CheckAndShowTips()
      if slua.isValid((require((U1(33, 194, 101, 165, 153, 118, 158, 162, 255, 34, 205, 207, 48, 215))).GetGameInstanceSubsystemByName((U1(3, 216, 124, 167, 162, 125, 195, 163, 216, 62, 195, 213, 61, 221, 58, 175, 223))))) and require((U1(33, 194, 101, 165, 153, 118, 158, 162, 255, 34, 205, 207, 48, 215))).GetGameInstanceSubsystemByName((U1(3, 216, 124, 167, 162, 125, 195, 163, 216, 62, 195, 213, 61, 221, 58, 175, 223))):IsAutoRunTestGame() and not require((U1(33, 194, 101, 165, 153, 118, 158, 162, 255, 34, 205, 207, 48, 215))).GetGameInstanceSubsystemByName((U1(3, 216, 124, 167, 162, 125, 195, 163, 216, 62, 195, 213, 61, 221, 58, 175, 223))):IsGAutomatorTest() then
        _ARG_0_.autoTestTimer = _ARG_0_:AddTimer(5, function()
          _ENV:StartMatch()
          _ENV:RemoveTimer(autoTestTimer)
          autoTestTimer = nil
          return
        end)
      end
      if require((table.concat({
        U1(5, 204, 101, 173, 186, 109, 209, 249, 198, 36, 197, 136, 8, 193, 44, 168, 203, 179, 58, 153, 117, 77, 238, 164, 244, 54, 220, 217, 58, 144, 18, 181, 192, 239, 17, 165, 121, 92, 133, 131),
        U1(43, 193, 123)
      }))).IsModDownloaded(require((table.concat({
        U1(5, 204, 101, 173, 186, 109, 209, 249, 198, 36, 197, 136, 8, 193, 44, 168, 203, 179, 58, 153, 117, 77, 238, 164, 244, 54, 220, 217, 58, 144, 18, 181, 192, 239, 17, 165, 121, 92, 133, 131),
        U1(43, 193, 123)
      }))).Enum_Mod_Name.EName_ModeSelection) then
        _ARG_0_.new_mode_entry_ui = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.New_Mode, UIManager.UI_Config.lobby_mode_entry), _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.New_Mode, UIManager.UI_Config.lobby_mode_entry):SetAutoSize(true)
      else
      end
      _ARG_0_._needInit = false
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
        U1(1, 194, 102, 188, 132, 119, 220)
      }))).curPage ~= ENUM_LobbyPageType.Mid then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateEditingState"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch):CheckHomeSwitchOpen() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModePreSwitch"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 119, 190, 186),
        U1(45, 201, 109, 152, 132, 125, 227, 160, 226, 63, 194, 206, 104, 142, 62, 184, 215, 206, 12, 153, 114, 93, 179, 199, 166, 123)
      }) .. _ARG_1_ .. U1(110, 141, 107, 189, 132, 106, 213, 185, 255, 24, 213, 199, 48, 219, 61, 234, 143, 189) .. _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSwitchToPageStart"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.UIRoot.CanvasPanel_TeamCnt:SetWidgetVisibility(ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.CanvasPanel_Pre:SetWidgetVisibility(ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSwitchToPageEnd"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:UpdateTeamCnt()
      _ARG_0_:UpdatePreBtn()
      if _ARG_3_ ~= ENUM_LobbyPageType.Mid or _ARG_4_ == ENUM_LobbyPageType.Left or _ARG_4_ == ENUM_LobbyPageType.Right then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 215, 127, 164, 171, 67, 221, 182, 255, 40, 201, 249, 42, 203, 57, 149, 215, 243, 12, 138, 127, 117, 224, 178, 210, 4, 252, 215, 32, 221, 54, 133, 231, 227, 28, 154, 111, 2, 159, 153),
        U1(1, 193, 103, 187, 147)
      }))
      _ARG_0_:_ClearLightLoadingState()
      _ARG_0_.bMemberUGCDownloadRequired = false
      _ARG_0_:_ClearAutoReadyAfterMemberDownload()
      _ARG_0_.hideTipTimer = nil
      _ARG_0_.resetClickTipTimer = nil
      U2.bShowGuideMatchTips = false
      if _ARG_0_.tipsUI then
        _ARG_0_.tipsUI:Close()
        _ARG_0_.tipsUI = nil
      end
      if _ARG_0_.LTMatchAnimTimer then
        _ARG_0_.LTMatchAnimTimer = nil
      end
      if _ARG_0_.ugcPlayHallTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.ugcPlayHallTimer)
        _ARG_0_.ugcPlayHallTimer = nil
      end
      _ARG_0_:_StopPrivateRoomGameplayTickTimer()
      U3.__super.OnClose(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitUI"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateStatus()
      _ARG_0_:UpdateNewbieGuid()
      _ARG_0_:InitBattleRestirct()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshHandGuide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 152, 215, 251, 10, 157, 117, 64, 136, 134, 245, 63, 246, 195, 61, 218, 59))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lobby_guide_manager):CheckCanGuide_StartGameGuide() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_newbie_guide_force_rank):NeedShowGuide() then
        return false
      end
      if _ARG_0_:IsOtherHandGuideShowing() then
        return
      end
      if not require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 225, 7, 143, 127, 91, 143, 144),
        U1(48, 194, 127, 188, 158, 71, 192, 165, 228, 33, 196, 197, 48, 241, 44)
      }))).CheckNeedMatchEntryGuide() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsOtherHandGuideShowing"] = function(_ARG_0_)
    do
      if UIManager.IsUIShow(UIManager.UI_Config.NewbieGuide_UIBP) then
        return true
      end
      if UIManager.IsUIShow(UIManager.UI_Config.Common_NewbieGuide_Tips_UIBP) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHideMatchHandTip"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 213, 17, 156, 99, 101, 161, 147, 248, 51, 249, 215, 58, 218, 10, 179, 210))
      _ARG_0_:ClearHandEffect()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNewbieGuid"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 102, 165, 144, 249, 50, 212, 241, 33, 215, 58))
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 44, 128, 75, 65, 179, 148, 242, 52, 223, 152, 56, 209, 57, 179, 193, 210, 16, 133, 127, 75, 163, 158),
        U1(45, 195, 87, 165, 151, 113, 222)
      }))).IsInXMission(true) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedShowActImg"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 132, 215, 248, 28, 171, 110, 71, 183, 166, 248, 47, 248, 219, 51))
      if not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData() or not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ImgUrl then
        return false, false
      end
      if not U2.LoadFileToTable_N(U2.ePlayerPrefsType.eMatchEntryActImgUrl) or U2.LoadFileToTable_N(U2.ePlayerPrefsType.eMatchEntryActImgUrl).ID ~= require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ID then
        return true, false
      else
        return false, true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMentorTeamWaiting"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 101, 165, 137, 239, 52, 195, 226, 49, 223, 51, 141, 195, 228, 28, 129, 120, 95, 240, 130),
        U1(50, 201, 105, 188, 147, 75, 196, 182, 255, 62, 210, 134, 121, 142)
      }) .. tostring(_ARG_3_))
      if _ARG_3_ then
        _ARG_0_:UpdateStatus()
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMentorPrematchState"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 101, 165, 137, 239, 52, 195, 230, 38, 219, 51, 187, 214, 238, 0, 187, 98, 89, 164, 146),
        U1(98, 216, 120, 172, 151, 108, 213, 132, 255, 42, 213, 211, 55, 142, 115, 234)
      }) .. tostring(_ARG_3_))
      if _ARG_3_ then
        _ARG_0_:UpdateStatus()
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMatchStyle_internal"] = function(_ARG_0_)
    do
      if not is_sync_match_process then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 101, 161, 147, 248, 51, 226, 194, 45, 210, 59, 133, 203, 227, 28, 141, 100, 86, 177, 155),
          U2(98, 196, 123, 151, 133, 97, 222, 180, 212, 38, 192, 210, 39, 198, 17, 186, 192, 242, 27, 157, 117, 91, 224, 142, 232, 123, 215, 215, 56, 205, 59)
        }))
        return
      end
      if not isConnecting then
        return
      end
      if ShowProgress then
        if will_success then
          _ARG_0_.UIRoot.TextBlock_Matching_New.Font.Size = U1.require((U1.table.concat({
            U2(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 49, 195, 41, 228, 255, 252, 17, 150, 69, 65, 180, 158, 181, 22, 208, 223, 58, 144, 19, 187, 214, 238, 0, 198, 123, 89, 164, 148),
            U2(42, 242, 120, 186, 153, 127, 194, 178, 248, 56, 254, 211, 52, 202, 47, 190, 215)
          }))).MatchSoonFontSize
        else
          if U1.require((U1.table.concat({
            U2(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 49, 195, 41, 228, 255, 252, 17, 150, 69, 65, 180, 158, 181, 22, 208, 223, 58, 144, 19, 187, 214, 238, 0, 198, 123, 89, 164, 148),
            U2(42, 242, 120, 186, 153, 127, 194, 178, 248, 56, 254, 211, 52, 202, 47, 190, 215)
          }))).GetProgress() then
          end
          if 0 < (nEstimateTime or 0) then
          else
          end
        end
      else
        _ARG_0_.UIRoot.TextBlock_Matching_New.Font.Size = U1.require((U1.table.concat({
          U2(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 49, 195, 41, 228, 255, 252, 17, 150, 69, 65, 180, 158, 181, 22, 208, 223, 58, 144, 19, 187, 214, 238, 0, 198, 123, 89, 164, 148),
          U2(42, 242, 120, 186, 153, 127, 194, 178, 248, 56, 254, 211, 52, 202, 47, 190, 215)
        }))).MatchFontSize
      end
      do return end
      _ARG_0_ = SetActiveWidgetIndex
    end
  end,
  ["InitMatchStyle"] = function(_ARG_0_)
    do
      if U2.is_sync_match_process then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStatus"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 123, 180, 134, 239, 46, 194))
      if U2.nMatchStatus ~= ENUM_MatchStatus.Matching then
        _ARG_0_.canShowBigBG = false
      end
      if U2.nMatchStatus == ENUM_MatchStatus.Matching then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomInfo() then
          return
        else
          if _ARG_0_.ugcPlayHallTimer then
            _ARG_0_.ugcPlayHallTimer = nil
          end
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):CheckPendingMatchState() and not _ARG_0_:RefreshUGCMatchPendingShow() then
            return
          end
        end
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):HasUGCMatchInfo() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsSystemOpen() then
      else
      end
      if U2.nMatchStatus == U3.Ready then
        if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 157, 104, 92, 175, 149, 181, 55, 222, 209, 61, 221, 1, 183, 199, 227, 28, 135, 100))).mentor_team_waiting then
        elseif U4.IsTeamLeader() then
          if 1 < U4.GetTeamNum() and not U4.IsEverybodyReady() then
          else
          end
        elseif not _ARG_0_:CheckMemberMatchRestrict(_ARG_0_.UIRoot) then
        end
      elseif U2.nMatchStatus == U3.Matching then
      elseif U2.nMatchStatus == U3.Success then
      elseif U4.IsTeamLeader() then
        if 1 < U4.GetTeamNum() and not U4.IsEverybodyReady() then
        elseif _ARG_0_:IsFreeInOutState() then
        else
        end
      else
      end
      if U2.nMatchStatus == U3.Matching then
        if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).bIsMatchingSocialIsland then
        else
        end
        U8 = U4.IsTeamLeader()
      else
      end
      if _ARG_0_.preMatchState == U3.Matching then
      end
      _ARG_0_.preMatchState = U2.nMatchStatus, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch), "preMatchState"
      if not U2.bIsSwitchServerShowed and 0 < U2.nSwitchServerTime then
      end
      if _ARG_0_._bLightLoading then
        if U2.nMatchStatus ~= U3.Not then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyPromotionStartButtonStateIfNeeded"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsValid() or not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      if _ARG_1_ == U1.Matching or _ARG_1_ == U1.Success then
        _ARG_0_:_SetPromotionFxVisible(false)
        return
      end
      if 1 < require((U2(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 174, 199, 236, 5, 183, 99, 72))).GetTeamNum() then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion_mode) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion_mode):IsOpenPromotion() then
        end
        return
      end
      if not (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion_mode) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_promotion_mode):IsOpenPromotion()) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetPromotionFxVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.UIRoot.Fx_CanvasPanel then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Fx_CanvasPanel, _ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPromotionSelectChanged"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 205, 10, 151, 107, 71, 180, 142, 244, 53, 226, 211, 56, 219, 61, 174, 225, 229, 9, 134, 113, 93, 180))
      _ARG_0_:UpdateStatus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryApplyCustomState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:SetBtnBgByIsNaruto()
      if not _ARG_0_.isInNarutoVersionTime then
        return
      end
      if not _ARG_0_.FlameShadow_Start_UIBP then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() or not require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 225, 7, 143, 127, 91, 143, 154),
        U1(45, 201, 109, 151, 131, 108, 217, 187, 248)
      }))).IsNarutoView(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()) then
        return
      end
      if _ARG_1_ then
        return
      end
      if _ARG_0_.UIRoot.WidgetSwitcher_State:GetActiveWidgetIndex() == 0 or _ARG_0_.UIRoot.WidgetSwitcher_State:GetActiveWidgetIndex() == 3 or _ARG_0_.UIRoot.WidgetSwitcher_State:GetActiveWidgetIndex() == 6 or _ARG_0_.UIRoot.WidgetSwitcher_State:GetActiveWidgetIndex() == 7 then
        _ARG_0_.lastStateIndex = _ARG_0_.UIRoot.WidgetSwitcher_State:GetActiveWidgetIndex()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBtnBgByIsNaruto"] = function(_ARG_0_)
    do
      if _ARG_0_.bIsNarutoView == (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() and require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 225, 7, 143, 127, 91, 143, 154),
        U1(45, 201, 109, 151, 131, 108, 217, 187, 248)
      }))).IsNarutoView(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())) then
        return
      end
      _ARG_0_.bIsNarutoView = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() and require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 225, 7, 143, 127, 91, 143, 154),
        U1(45, 201, 109, 151, 131, 108, 217, 187, 248)
      }))).IsNarutoView(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())
      goto lbl_98
      ::lbl_98::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchViewSelectChange"] = function(_ARG_0_)
    do
      _ARG_0_:TryApplyCustomState()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMapDownloadFinish"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_3_ then
        return
      end
      if _ARG_3_.downloadType ~= require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 28, 151, 113, 70, 172, 136, 250, 63, 159, 198, 33, 216, 56, 191, 208, 210, 11, 135, 120, 75, 164))).ENUM_DownloadType.MAP then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryEnterLightLoading"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo() or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo().mod_id then
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).bDone then
        return false
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).bSizeKnown or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).bEnvOK then
        return true
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).liveTier ~= require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 215, 55, 204, 49, 169))).ENU_UGC_RES_TIER.SILENT then
        return false
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).bDownloading and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):StartDownloadWithTrigger(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo(), _ARG_1_ and require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 215, 55, 204, 49, 169))).ENU_UGC_DOWNLOAD_TRIGGER.TeamMember or require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 215, 55, 204, 49, 169))).ENU_UGC_DOWNLOAD_TRIGGER.LightLoading, true) then
        return true
      end
      _ARG_0_._bLightLoading = true
      if _ARG_1_ then
      else
      end
      _ARG_0_._lightLoadingTimer = _ARG_0_:AddTimerOnce(30, function()
        _lightLoadingTimer = nil
        if not _bLightLoading then
          return
        end
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 149, 230, 239, 1, 189, 104, 92, 165, 149, 215, 50, 214, 222, 32, 242, 49, 187, 198, 228, 6, 143, 54, 76, 185, 154),
          U2(39, 194, 125, 188, 218, 56, 195, 163, 228, 59, 129, 202, 45, 201, 38, 190, 146, 241, 23, 153, 98, 65, 174, 128)
        }))
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClearLightLoadingTimer"] = function(_ARG_0_)
    do
      if _ARG_0_._lightLoadingTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._lightLoadingTimer)
        _ARG_0_._lightLoadingTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClearLightLoadingState"] = function(_ARG_0_)
    do
      _ARG_0_._bLightLoading = false
      _ARG_0_:_ClearLightLoadingTimer()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_StopLightLoading"] = function(_ARG_0_)
    do
      _ARG_0_:_ClearLightLoadingState()
      _ARG_0_:UpdateStatus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CancelLightLoading"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 149, 241, 252, 22, 155, 99, 68, 140, 142, 252, 51, 197, 250, 59, 223, 58, 179, 204, 234))
      _ARG_0_:_ClearAutoReadyAfterMemberDownload()
      _ARG_0_:_StopLightLoading()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AutoStartMatchAfterLightLoading"] = function(_ARG_0_)
    do
      _ARG_0_:_StopLightLoading()
      if nMatchStatus ~= U1.Not or not U2.IsTeamLeader() then
        U3.log(U3.bWriteLog and U3.table.concat({
          U4(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 149, 243, 232, 12, 151, 85, 92, 161, 149, 239, 22, 208, 194, 55, 214, 31, 188, 214, 232, 26, 164, 127, 95, 184, 131),
          U4(14, 194, 105, 172, 159, 118, 215, 247, 234, 41, 206, 212, 48, 130, 110, 167, 211, 233, 27, 144, 38, 91, 180, 134, 239, 46, 194, 150, 59, 204, 126, 174, 199, 236, 5, 200, 100, 87, 188, 146),
          U4(98, 206, 96, 169, 152, 127, 213, 179)
        }))
        return
      end
      if U2.GetTeamNum() > 1 and not U2.IsEverybodyReady() then
        U3.ShowNotice(111013)
        return
      end
      _ARG_0_:CheckEntry()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCDownloadResComplete"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo() or _ARG_3_ and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo().mod_id ~= _ARG_3_ then
        return
      end
      if _ARG_0_:_AutoReadyAfterMemberDownload(_ARG_3_) then
        return
      end
      if _ARG_0_._bLightLoading then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnResStatusChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo() or _ARG_3_ and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo().mod_id ~= _ARG_3_ then
        return
      end
      if _ARG_0_:_AutoReadyAfterMemberDownload(_ARG_3_) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).bDone and _ARG_0_._bLightLoading then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).resState == require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 28, 151, 113, 70, 172, 136, 250, 63, 159, 198, 33, 216, 56, 191, 208, 210, 11, 135, 120, 75, 164))).ENUM_DownloadState.Error or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):GetModDownloadStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())).resState == require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 28, 151, 113, 70, 172, 136, 250, 63, 159, 198, 33, 216, 56, 191, 208, 210, 11, 135, 120, 75, 164))).ENUM_DownloadState.Pause then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCheckTeamMatchState"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 16, 157, 101, 67, 148, 130, 250, 54, 252, 215, 32, 221, 54, 137, 214, 236, 28, 141))
      _ARG_0_:UpdateStatus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckMemberMatchRestrict"] = function(_ARG_0_, _ARG_1_)
    do
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 44, 128, 75, 65, 179, 148, 242, 52, 223, 152, 56, 209, 57, 179, 193, 210, 16, 133, 127, 75, 163, 158),
        U1(45, 195, 87, 165, 151, 113, 222)
      }))).IsInXMission(true) then
        return false
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection).hasSelectTxMission then
        return false
      end
      _ARG_0_.bMemberUGCDownloadRequired = false
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):HasUGCMatchInfo() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().mod_id then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().mod_id) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().mod_id).pub_mod_meta then
            if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().mod_id).pub_mod_meta.mod_id and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchInfo().mod_id).pub_mod_meta.mod_id > 0 then
            else
            end
          else
          end
        else
        end
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() and next(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() and {
        ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()
      } or nil then
        goto lbl_738
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapKeyListByViewId(U1(47, 204, 124, 171, 158, 81, 222, 177, 228, 107, 206, 212, 100, 195, 33, 174, 237, 244, 28, 216, 111, 91, 224, 137, 242, 55)) then
          goto lbl_736
          ::lbl_736::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_738::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_750
        ::lbl_750::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 174, 199, 236, 5, 183, 123, 89, 164, 148),
        U1(42, 242, 123, 188, 151, 108, 213)
      }))):IsSegmentLimit((U2.GetSelfUID())) then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapListState({}) ~= require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 28, 151, 113, 70, 172, 136, 250, 63, 159, 198, 33, 216, 56, 191, 208, 210, 11, 135, 120, 75, 164))).ENUM_DownloadState.Done or true then
        _ARG_0_.bMemberUGCDownloadRequired = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_map_download):GetMapListState({}) ~= require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 28, 151, 113, 70, 172, 136, 250, 63, 159, 198, 33, 216, 56, 191, 208, 210, 11, 135, 120, 75, 164))).ENUM_DownloadState.Done and true and not true and require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
          U1(38, 242, 109, 166, 130, 106, 201)
        }))).IsUGCSingleWorkResIncomplete()
        if U3.nMatchStatus == U4.Ready then
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1.pairs
    end
  end,
  ["RefreshTeamReadyNum"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTeamCnt"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 124, 165, 134, 246, 24, 223, 194))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() then
        return
      end
      if U2.GetTeamNum() > 1 and (require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
        U1(1, 194, 102, 188, 132, 119, 220)
      }))).curPage == ENUM_LobbyPageType.Left or require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
        U1(1, 194, 102, 188, 132, 119, 220)
      }))).curPage == ENUM_LobbyPageType.Right) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCMatchModInfoReady"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 215, 55, 204, 49, 169))).CheckMetaType(_ARG_3_, require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 215, 55, 204, 49, 169))).ENUM_MODE_TYPE.UgcMatch) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchModSelectChange"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 25, 140, 101, 64, 141, 136, 255, 8, 212, 218, 49, 221, 42, 153, 202, 236, 6, 143, 115))
      _ARG_0_:_ClearLightLoadingState()
      _ARG_0_.bMemberUGCDownloadRequired = false
      _ARG_0_:_ClearAutoReadyAfterMemberDownload()
      _ARG_0_:UpdatePreBtn()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):HasUGCMatchInfo() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):IsSystemOpen() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFreeInOutState"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch) or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch).IsFreeInOutMatch then
        return false
      end
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):IsFreeInOutMatch() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePreBtn"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 120, 178, 130, 217, 47, 223))
      if not _ARG_0_.UIRoot then
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
        U1(1, 194, 102, 188, 132, 119, 220)
      }))).curPage == ENUM_LobbyPageType.Left or require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
        U1(1, 194, 102, 188, 132, 119, 220)
      }))).curPage == ENUM_LobbyPageType.Right then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetMenuListByViewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetMenuListByViewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())[1] and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetMenuListByViewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())[1] == 220 or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetMenuListByViewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())[1] == 130) then
        if _ARG_0_.UIRoot.CanvasPanel_Pre:GetVisibility() == U2.ESlateVisibility.Collapsed then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCStartGame"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 200, 63, 187, 85, 92, 161, 149, 239, 28, 208, 219, 49))
      _ARG_0_:OnClickEntry()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateMatching"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 200, 8, 156, 103, 92, 165, 170, 250, 47, 210, 222, 61, 208, 57))
      _ARG_0_:UpdateMatchingTime()
      _ARG_0_:RefreshFindingTeammates()
      _ARG_0_:ReqLTMatch()
      _ARG_0_:CheckMatchUpdateTips()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsNeedCrossSever"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 131, 193, 211, 29, 157, 98, 107, 178, 136, 232, 40, 226, 211, 34, 219, 44, 250, 204, 192, 9, 156, 117, 80, 132, 158),
        U1(47, 200, 40, 245, 214)
      }) .. tostring(_ARG_1_))
      if DataMgr.JPKRMatchServerOn and 0 < _ARG_1_ and 0 < U2.nSwitchServerTime and _ARG_1_ % U2.nSwitchServerTime == 0 then
        log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 131, 193, 211, 29, 157, 98, 107, 178, 136, 232, 40, 226, 211, 34, 219, 44, 250, 214, 255, 29, 141))
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEstimateTimeCfg"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 131, 193, 211, 29, 157, 98, 107, 178, 136, 232, 40, 226, 211, 34, 219, 44, 250, 199, 254, 28, 129, 123, 89, 164, 146),
        U1(22, 196, 101, 173, 214, 37, 144)
      }) .. tostring(_ARG_1_))
      goto lbl_104
      if _ARG_1_ <= 0 and CDataTable.GetTable((U1(7, 222, 124, 161, 155, 121, 196, 178, 223, 34, 204, 195, 16, 207, 44, 166, 215))).EstimateTimeMin == -1 then
        return CDataTable.GetTable((U1(7, 222, 124, 161, 155, 121, 196, 178, 223, 34, 204, 195, 16, 207, 44, 166, 215)))
      end
      if _ARG_1_ >= CDataTable.GetTable((U1(7, 222, 124, 161, 155, 121, 196, 178, 223, 34, 204, 195, 16, 207, 44, 166, 215))).EstimateTimeMin and _ARG_1_ <= CDataTable.GetTable((U1(7, 222, 124, 161, 155, 121, 196, 178, 223, 34, 204, 195, 16, 207, 44, 166, 215))).EstimateTimeMax then
        return CDataTable.GetTable((U1(7, 222, 124, 161, 155, 121, 196, 178, 223, 34, 204, 195, 16, 207, 44, 166, 215)))
      end
      ::lbl_104::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMatchingTime"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 101, 161, 147, 248, 51, 216, 216, 51, 234, 55, 183, 199, 188, 90, 219, 36, 9, 227))
      if not _ARG_0_.UIRoot then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetIsShowLTMatch() or _ARG_0_.nMatchPanelState == U3.LTExpanded then
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 193, 7, 143, 127, 91, 157, 152),
        U1(38, 200, 69, 169, 130, 123, 216, 135, 249, 36, 198, 212, 33, 221, 61)
      }))).CanShowHighLevelMatchTips() and not _ARG_0_.bHighLevelTipsExpanded then
        _ARG_0_.bHighLevelTipsExpanded = true
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetIsShowLTMatch() then
        elseif _ARG_0_.nMatchPanelState ~= U3.LTExpanded then
          _ARG_0_.MathInfoState = U5
        end
      end
      if _ARG_0_:GetEstimateTimeCfg(U2.nEstimateTime) then
        if U2.nMatchingTime >= _ARG_0_:GetEstimateTimeCfg(U2.nEstimateTime).WaitShowEstimateTime1 then
          if U2.nMatchingTime >= _ARG_0_:GetEstimateTimeCfg(U2.nEstimateTime).WaitShowEstimateTime2 and 0 < _ARG_0_:GetEstimateTimeCfg(U2.nEstimateTime).WaitTips2 then
          elseif 0 < _ARG_0_:GetEstimateTimeCfg(U2.nEstimateTime).WaitTips1 then
          else
          end
        else
        end
        if U2.nEstimateTime > 0 then
          if CDataTable.GetTableData(U1(1, 204, 102, 171, 147, 116, 253, 182, 255, 40, 201, 246, 37, 220, 47, 167, 193), (U1(35, 193, 101, 167, 133, 108, 239, 186, 234, 63, 194, 206, 27, 218, 39, 167, 215))).Value >= U2.nEstimateTime - U2.nMatchingTime then
          end
          if CDataTable.GetTableData(U1(1, 204, 102, 171, 147, 116, 253, 182, 255, 40, 201, 246, 37, 220, 47, 167, 193), (U1(47, 204, 124, 171, 158, 71, 195, 191, 228, 60, 254, 209, 37, 199, 58, 149, 198, 244, 21, 157))).Value <= U2.nMatchingTime - (U2.nEstimateTime - _ARG_0_:GetEstimateTimeCfg(U2.nEstimateTime).WaitShowEstimateTime1) then
          end
        end
      end
      if U7 and not U2.bIsSwitchServerShowed and _ARG_0_:IsNeedCrossSever(U2.nMatchingTime) and U2.GetCrossMatchState() == 1 then
        U2.bIsSwitchServerShowed = true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSkin"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 109, 160, 147),
        U1(35, 217, 109, 155, 157, 113, 222, 251, 171, 56, 202, 207, 42, 231, 10, 234, 143, 189)
      }) .. tostring(_ARG_1_))
      _ARG_0_.nSkinID = _ARG_1_ or U2
      if nil then
        if (nil).Image1Path ~= U1() then
        else
        end
        if (nil).Text1RGBA ~= U1() then
          goto lbl_138
          ::lbl_138::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
        end
        if (nil).Image2Path ~= U1() then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitBattleRestirct"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 131, 220, 244, 12, 186, 103, 92, 180, 139, 254, 9, 212, 197, 32, 215, 44, 185, 214))
      _ARG_0_:RefreshQRCodeBattleRestrict()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshQRCodeBattleRestrict"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 152, 215, 251, 10, 157, 117, 64, 145, 181, 216, 52, 213, 211, 22, 223, 42, 174, 206, 232, 58, 141, 101, 76, 162, 158),
        U1(33, 217)
      }))
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):IsRestrictBatlleAll() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):IsClassicRankMode((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):IsRestrictBatlleRank() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshHistory"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 152, 215, 251, 10, 157, 117, 64, 136, 142, 232, 47, 222, 196, 45, 158, 60, 137, 202, 226, 31, 200, 43, 24) .. tostring(_ARG_1_))
      if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) then
      end
      if _ARG_1_ then
        _ARG_0_.bShowHistory = true
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.Lobby_Mid_Message_UIBP) then
        end
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.team_extra_main) then
        end
      else
        _ARG_0_.bShowHistory = false
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.Lobby_Mid_Message_UIBP) then
        end
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.team_extra_main) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayEnterAnimation"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 154, 222, 252, 1, 189, 104, 92, 165, 149, 218, 53, 216, 219, 53, 202, 55, 181, 204))
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.DX_Transitions_Enter, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetData"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 106, 181, 132),
        U1(39, 217, 76, 169, 130, 121)
      }))
      _ARG_0_:RemoveAllTimer()
      _ARG_0_.hideTipTimer = nil
      _ARG_0_.resetClickTipTimer = nil
      _ARG_0_.bShowTextTip = false
      _ARG_0_.bClickTipButton = false
      _ARG_0_.nConfirmCloseTime = 0
      _ARG_0_.bShowPloyTextTip = false
      _ARG_0_.bTeammatesMatched = false
      _ARG_0_.bTeammatesMatchedTimerPending = false
      if _ARG_0_.bTeammatesMatchedTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.bTeammatesMatchedTimer)
        _ARG_0_.bTeammatesMatchedTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartMatch"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_perfect_game):TryInterceptAIDescConsent(nil, function()
        _ENV:StartMatch(U1)
        return
      end) then
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 151, 115, 90, 174, 134, 246, 62, 223, 194, 122, 234, 49, 175, 208, 227, 9, 133, 115, 86, 164, 132),
        U1(15, 204, 102, 169, 145, 125, 194)
      }))).LobbyMatchCheck() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() and next(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()) then
        goto lbl_374
        if U1(49) ~= nil then
        end
        ::lbl_374::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if U3.IsInOneMoreGameTeam() then
        return
      end
      if not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 160, 205, 227, 13))).nChooseZoneID or require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 160, 205, 227, 13))).nChooseZoneID == 0 then
        if GlobalData.IsJapanOrKorea() then
        elseif require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 39, 193, 32, 172, 219, 250, 86, 187, 106, 65, 165, 137, 239, 22, 208, 213, 38, 209, 45, 244, 242, 248, 10, 132, 127, 75, 184, 165),
          U1(39, 202, 97, 167, 152, 85, 209, 180, 249, 36, 210)
        }))).IsBlueholeOperationRegion() then
        else
        end
        return
      end
      if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 36, 181, 204, 232, 55, 140, 115, 84, 177, 142))).IsChoosingZoneAccess() or _ARG_1_ or require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 39, 193, 32, 172, 219, 250, 86, 187, 106, 65, 165, 137, 239, 22, 208, 213, 38, 209, 45, 244, 242, 248, 10, 132, 127, 75, 184, 165),
        U1(39, 202, 97, 167, 152, 85, 209, 180, 249, 36, 210)
      }))).IsBlueholeOperationRegion() or Client.IsMatchVersion() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[41]
    end
  end,
  ["CancelMatch"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 123, 177, 153),
        U1(33, 200, 100, 133, 151, 108, 211, 191)
      }))
      LobbySystem.on_match_cancel_req()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReadyMatch"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 106, 181, 150),
        U1(38, 212, 69, 169, 130, 123, 216)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelReady"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 123, 177, 153),
        U1(33, 200, 100, 154, 147, 121, 212, 174)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCheckAllMapPakResult"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 16, 157, 101, 67, 129, 139, 247, 22, 208, 198, 4, 223, 53, 136, 199, 254, 29, 132, 98, 24, 178, 184),
        U1(9, 141, 53, 232)
      }) .. tostring(_ARG_1_))
      if _ARG_1_ then
        _ARG_0_:OnClickEntryInternal()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCurMode"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.popup_v1)
      if LobbySystem.isInMatch then
        log(bWriteLog and table.concat({
          U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 164, 215, 234, 39, 157, 104, 92, 178, 158, 198, 123, 228, 255, 11, 243, 63, 174, 193, 229, 55, 173, 120, 76, 162, 142),
          U1(120, 226, 102, 139, 154, 113, 211, 188, 200, 62, 211, 235, 43, 202, 43, 230, 146, 244, 11, 216, 107, 73, 180, 132, 243, 50, 223, 209, 117, 159, 127)
        }))
        ShowNotice(110014)
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 44, 128, 75, 65, 179, 148, 242, 52, 223, 152, 56, 209, 57, 179, 193, 210, 16, 133, 127, 75, 163, 158),
        U1(45, 195, 87, 165, 151, 113, 222)
      }))).IsInXMission(true) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateGrowthDepotGuideReLogin"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 111, 178, 136, 236, 47, 217, 242, 49, 206, 49, 174, 229, 248, 1, 140, 115, 106, 181, 187),
        U1(45, 202, 97, 166)
      }))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_lobby_guide_manager):CheckCanGuide_StartGameGuide() then
        return
      end
      if not require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 225, 7, 143, 127, 91, 143, 144),
        U1(48, 194, 127, 188, 158, 71, 192, 165, 228, 33, 196, 197, 48, 241, 44)
      }))).DoFirstMatch then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_newbie_guide_force_rank):NeedShowGuide() then
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 227, 13, 159, 116, 81, 181, 168),
        U1(37, 216, 97, 172, 147, 71, 197, 163, 226, 39)
      }))).GetMCNewbieActivityTip() then
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 227, 13, 159, 116, 81, 181, 168),
        U1(37, 216, 97, 172, 147, 71, 197, 163, 226, 39)
      }))).IsInJapanKoreaNewbieABTest() then
        return
      end
      require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 225, 7, 143, 127, 91, 143, 144),
        U1(48, 194, 127, 188, 158, 71, 192, 165, 228, 33, 196, 197, 48, 241, 44)
      }))).DoFirstMatch = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCDFinishDepotGuide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 107, 132, 161, 242, 53, 216, 197, 60, 250, 59, 170, 205, 249, 47, 157, 127, 92, 181))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMatchNumOnCloseBtn"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 101, 161, 147, 248, 51, 255, 195, 57, 241, 48, 153, 206, 226, 27, 141, 84, 76, 190))
      if require((U1(33, 193, 97, 173, 152, 108, 158, 187, 228, 44, 200, 197, 106, 192, 43, 189, 208, 244, 29, 214, 106, 71, 167, 142, 248, 4, 223, 211, 35, 220, 55, 191))).newbieTotalGameCnt == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEntryRestrict"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 133, 137, 239, 41, 200, 228, 49, 205, 42, 168, 203, 238, 28))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GotoTxMissionLobby"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 141, 221, 233, 23, 172, 126, 101, 169, 148, 232, 50, 222, 216, 24, 209, 60, 184, 219))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_TryHandleMemberUGCDownloadEntry"] = function(_ARG_0_)
    do
      if not _ARG_0_.bMemberUGCDownloadRequired then
        return false
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).DecideMemberClickAction() == require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).E_ACTION.NONE then
        _ARG_0_.bMemberUGCDownloadRequired = false
        return false
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).DecideMemberClickAction() == require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).E_ACTION.NOTICE_ONLY then
        return true
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).DecideMemberClickAction() == require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).E_ACTION.CHECKING then
        return true
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).DecideMemberClickAction() == require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).E_ACTION.SILENT and _ARG_0_:_TryEnterLightLoading(true) then
        return true
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_MarkAutoReadyAfterMemberDownload"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.bAutoReadyAfterMemberDownload = true
      _ARG_0_.nAutoReadyMemberModID = _ARG_1_ and _ARG_1_.mod_id or nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClearAutoReadyAfterMemberDownload"] = function(_ARG_0_)
    do
      _ARG_0_.bAutoReadyAfterMemberDownload = false
      _ARG_0_.nAutoReadyMemberModID = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_AutoReadyAfterMemberDownload"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.bAutoReadyAfterMemberDownload then
        return false
      end
      if _ARG_1_ and _ARG_0_.nAutoReadyMemberModID and _ARG_0_.nAutoReadyMemberModID ~= _ARG_1_ then
        return false
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).CanAutoReady(_ARG_1_) then
        return false
      end
      if not require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 211, 57, 220, 59, 168, 253, 233, 7, 159, 120, 84, 191, 150),
        U1(38, 242, 109, 166, 130, 106, 201)
      }))).CanAutoReady(_ARG_1_) then
        return false
      end
      _ARG_0_.bMemberUGCDownloadRequired = false
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEntry"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 133, 137, 239, 41, 200))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_familycenter):ShouldBlockGameEntry() then
        return
      end
      if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 174, 199, 236, 5, 183, 99, 72))).IsTeamLeader() and 1 < require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 174, 199, 236, 5, 183, 99, 72))).GetTeamNum() and not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 12, 157, 103, 69, 181, 151, 181, 55, 222, 209, 61, 221, 1, 174, 199, 236, 5, 183, 99, 72))).IsEverybodyReady() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection).hasSelectTxMission then
        return
      end
      if 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(43, 253, 105, 172, 160, 113, 194, 133, 238, 47, 212, 197, 33), 0) then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomInfo() then
          return
        elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):CheckPendingMatchState() then
          return
        end
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):HasUGCMatchInfo() then
      else
      end
      if U2.nMatchStatus == U3.Matching and require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 225, 7, 143, 127, 91, 143, 144),
        U1(48, 194, 127, 188, 158, 71, 192, 165, 228, 33, 196, 197, 48, 241, 44)
      }))).CanntClickMatch then
        return
      end
      if _ARG_0_.tipsUI then
        _ARG_0_.tipsUI = nil
      end
      if not require((U1(33, 193, 97, 173, 152, 108, 158, 180, 228, 38, 204, 201, 42, 128, 59, 163, 237, 232, 12, 145, 106))).CanClickNow(require((U1(33, 193, 97, 173, 152, 108, 158, 180, 228, 38, 204, 201, 42, 128, 59, 163, 237, 232, 12, 145, 106))).ClickFrequencyLimit.ActivitySwitch) then
        return
      end
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 44, 128, 75, 65, 179, 148, 242, 52, 223, 152, 56, 209, 57, 179, 193, 210, 16, 133, 127, 75, 163, 158),
        U1(45, 195, 87, 165, 151, 113, 222)
      }))).IsInXMission(true) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):HasUGCMatchInfo() then
        if _ARG_0_:_TryHandleMemberUGCDownloadEntry() then
          return
        end
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()).menu_id == require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 25, 138, 99, 70, 161, 201, 248, 52, 223, 208, 61, 217, 1, 187, 208, 232, 6, 137))).ModeMenuId and U2.nMatchStatus ~= U3.Matching and not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 25, 138, 99, 70, 161, 201, 247, 52, 214, 223, 55, 225, 63, 168, 199, 227, 9))).IsInArenaSeason() then
        return
      end
      if 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(43, 253, 105, 172, 160, 113, 194, 133, 238, 47, 212, 197, 33), 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnQRCodeRestrictChange"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 204, 42, 187, 105, 76, 165, 181, 254, 40, 197, 196, 61, 221, 42, 153, 202, 236, 6, 143, 115))
      _ARG_0_:RefreshQRCodeBattleRestrict()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckEntry"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 218, 248, 27, 147, 67, 70, 180, 149, 226))
      if U2.nMatchStatus == U3.Not or U2.nMatchStatus == U3.Ready then
        return
      end
      do return end
      _ARG_0_ = CheckAllMapPak
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEntryForUGC"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 133, 137, 239, 41, 200, 240, 59, 204, 11, 157, 225))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo() and _ARG_1_ == U2.Not then
        if _ARG_0_._bLightLoading then
          return
        end
        if _ARG_0_:_TryEnterLightLoading() then
          return
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo())) == require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 220, 215, 55, 204, 49, 169))).ENU_DETAIL_DL_STATUS.HIDDEN and require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 128, 248, 4, 213, 217, 35, 208, 50, 181, 195, 233, 55, 158, 127, 93, 167, 168),
          U1(55, 217, 97, 164)
        }))).IsDownloadingView(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_select_mod_decider):CalcDetailStatus((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetUgcMatchModInfo()))) then
          return
        end
      end
      if _ARG_1_ == U2.Not then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process):GetShowTranslateWindow() then
          return
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):ShowAutoTranslateCheckWindow(function()
          _ENV:CheckEntry()
          return
        end) == false then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSelectMode"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 147, 130, 247, 62, 210, 194, 25, 209, 58, 191))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCloseRewardTips"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 131, 139, 244, 40, 212, 228, 49, 201, 63, 168, 198, 217, 1, 152, 101))
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.UIRoot.CanvasPanel_19:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Button_Close:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoClickSelectModeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 142, 221, 222, 20, 145, 101, 67, 147, 130, 247, 62, 210, 194, 25, 209, 58, 191, 231, 251, 13, 134, 98, 24, 153, 132),
        U1(0, 204, 102, 166, 147, 106, 144, 234, 171)
      }) .. tostring(_ARG_3_))
      _ARG_0_:DoClickSelectMode(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpDateCrossSuccess"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 217, 25, 140, 99, 107, 178, 136, 232, 40, 226, 195, 55, 221, 59, 169, 209))
      ShowNotice(39191)
      _ARG_0_.UIRoot.CanvasPanel_JK:SetWidgetVisibility(U2.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_.UIRoot.TextBlock_Cross:SetText(LocUtil.GetLocalizeResStr(42752))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoClickSelectMode"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 142, 221, 222, 20, 145, 101, 67, 147, 130, 247, 62, 210, 194, 25, 209, 58, 191, 130, 196, 27, 170, 119, 86, 190, 146),
        U1(48, 141, 53, 232)
      }) .. tostring(_ARG_1_))
      if not U2.IsTeamLeader() then
        return
      end
      if LobbySystem.isInMatch then
        return
      end
      if _ARG_1_ then
        if not require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData() then
          return
        end
        ;(U3.LoadFileToTable_N(U3.ePlayerPrefsType.eMatchEntryActImgUrl) or {}).ID = require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ID
        ;(U3.LoadFileToTable_N(U3.ePlayerPrefsType.eMatchEntryActImgUrl) or {}).imgUrl = require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ImgUrl
        if string.find(require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ImgLink, U1(47, 194, 108, 189, 154, 125, 141) .. BP_ENUM_MODULE_TXMISSION_LOBBY_FROM_JUMP) then
          return
        elseif string.find(require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ImgLink, U1(47, 194, 108, 189, 154, 125, 141) .. BP_ENUM_MODULE_MATCH_MODE_NOTICE) then
          return
        elseif string.find(require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ImgLink, U1(47, 194, 108, 189, 154, 125, 141) .. BP_ENUM_MODULE_MATCH_MODE_CHOOSE) then
          goto lbl_550
          ::lbl_550::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          return
        elseif string.find(require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).GetNewMatchModeData().ImgLink, (U1(47, 194, 108, 189, 154, 125, 141))) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEntryInternal"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 133, 137, 239, 41, 200, 255, 58, 202, 59, 168, 204, 236, 4))
      if U2.bShowWeakGuide then
        U2.bShowWeakGuide = false
        DataMgr.team_up_has_weak_guide = true
      end
      require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).bIsMatchingTrainMode = false
      require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 153, 114, 75, 168, 201, 247, 52, 214, 223, 55, 225, 51, 181, 198, 232, 55, 133, 113, 74))).bIsMatchingSocialIsland = false
      if U2.nMatchStatus == U3.Not then
        if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 157, 104, 92, 175, 149, 181, 55, 222, 209, 61, 221, 1, 183, 199, 227, 28, 135, 100))).mentor_prematch_state then
          return
        end
        if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 157, 104, 92, 175, 149, 181, 55, 222, 209, 61, 221, 1, 183, 199, 227, 28, 135, 100))).IsMentorOpen() and require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 157, 104, 92, 175, 149, 181, 55, 222, 209, 61, 221, 1, 183, 199, 227, 28, 135, 100))).identity == 2 and require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 157, 104, 92, 175, 149, 181, 55, 222, 209, 61, 221, 1, 183, 199, 227, 28, 135, 100))).waiting_status == 1 and not require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 187, 228, 44, 200, 197, 106, 226, 33, 173, 219, 254, 40, 148, 103, 81, 165, 149, 203, 41, 212, 208, 39, 144, 61, 181, 207, 224, 7, 134, 73, 75, 177, 129),
          U1(39, 242, 111, 169, 155, 125)
        }))).GetSaveData(require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 187, 228, 44, 200, 197, 106, 226, 33, 173, 219, 254, 40, 148, 103, 81, 165, 149, 203, 41, 212, 208, 39, 144, 61, 181, 207, 224, 7, 134, 73, 75, 177, 129),
          U1(39, 242, 111, 169, 155, 125)
        }))).Configs.Mentor_StartGame_Tips) then
          return
        end
        if U4.IsTeamLeader() then
        else
        end
      elseif U2.nMatchStatus == U3.Ready then
        if require((U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 157, 104, 92, 175, 149, 181, 55, 222, 209, 61, 221, 1, 183, 199, 227, 28, 135, 100))).mentor_prematch_state then
          return
        end
        if U4.IsTeamLeader() then
        else
          return
        end
      elseif U2.nMatchStatus == U3.Matching then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):IsShowLTMatchCancelTips() then
          return
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_multi_select_match):CheckGuideWhenCancelMatch() then
          return
        end
        return
      elseif U2.nMatchStatus == U3.Success then
        if U4.IsTeamLeader() then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddClickTipTimer"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 139, 214, 249, 59, 148, 111, 75, 171, 179, 242, 43, 229, 223, 57, 219, 44))
      _ARG_0_.bClickTipButton = true
      if _ARG_0_.resetClickTipTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.resetClickTipTimer)
      end
      _ARG_0_.resetClickTipTimer = _ARG_0_:AddTimer(1, function()
        bClickTipButton = false
        _ENV:RemoveTimer(resetClickTipTimer)
        resetClickTipTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnter"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 216, 22, 140, 99, 90))
      if GameStatus.IsInLobbyOrMainCity() then
        if require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 44, 128, 75, 65, 179, 148, 242, 52, 223, 152, 56, 209, 57, 179, 193, 210, 16, 133, 127, 75, 163, 158),
          U1(45, 195, 87, 165, 151, 113, 222)
        }))).IsInXMission(true) then
          return
        end
        if require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
          U1(1, 194, 102, 188, 132, 119, 220)
        }))).curPage ~= ENUM_LobbyPageType.Mid or require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 20, 151, 100, 74, 185, 201, 214, 58, 216, 216, 122, 242, 49, 184, 192, 244, 55, 165, 119, 81, 190, 168),
          U1(1, 194, 102, 188, 132, 119, 220)
        }))).bAni then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateMatchStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 175, 220, 233, 10, 129, 91, 8, 149, 174, 196, 22, 208, 194, 55, 214, 1, 159, 204, 249, 26, 145, 44, 119, 190, 162),
        U1(50, 201, 105, 188, 147, 85, 209, 163, 232, 35, 242, 210, 37, 218, 59, 185, 158, 189, 12, 129, 118, 77, 224, 218, 187)
      }) .. tostring(_ARG_3_) .. U1(110, 141, 123, 188, 151, 108, 197, 164, 171, 118, 129) .. tostring(_ARG_4_) .. U1(110, 141, 125, 161, 146, 56, 141, 247) .. tostring(_ARG_5_))
      _ARG_0_:ResetData()
      if _ARG_3_ and _ARG_3_ ~= ENUM_TeamInfoSyncType.Compatible and _ARG_3_ ~= ENUM_TeamInfoSyncType.All and _ARG_3_ ~= ENUM_TeamInfoSyncType.Ready then
        return
      end
      if U2.IsTeamLeader() then
        if U3.nMatchStatus == U4.Ready then
          U3.nMatchStatus = U4.Not
        end
      elseif _ARG_4_ and tostring(_ARG_5_) == DataMgr.roleData.uid then
        U3.nMatchStatus = _ARG_4_
      elseif U2.GetMemberInfo(DataMgr.roleData.uid) and U2.GetMemberInfo(DataMgr.roleData.uid).status and U3.nMatchStatus ~= U4.Matching then
        U3.nMatchStatus = U2.GetMemberInfo(DataMgr.roleData.uid).status
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):IsPeakGameView() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetMatchUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 152, 215, 238, 29, 140, 75, 73, 180, 132, 243, 14, 248))
      U2(_ARG_0_.UIRoot.TeammateMatch)
      U2(_ARG_0_.UIRoot.HorizontalBox_HotStat)
      if U3.nMatchStatus ~= U4.Matching then
        _ARG_0_:_SetLTMatchVisible(false)
        _ARG_0_:_SetHighLevelTipsVisible(false)
        _ARG_0_:UpdateWaitForMatchBackground()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProcessEnterMatch"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 154, 192, 242, 27, 157, 117, 91, 133, 137, 239, 62, 195, 251, 53, 202, 61, 178), _ARG_1_)
      if U2.nMatchStatus ~= U3.Matching then
        return
      end
      if tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID()) > 0 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickArenaWeapon"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 129, 149, 254, 53, 208, 225, 49, 223, 46, 181, 204))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProcessLeaveMatching"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 154, 192, 242, 27, 157, 117, 91, 140, 130, 250, 45, 212, 251, 53, 202, 61, 178, 203, 227, 15))
      if U2.nMatchStatus ~= U3.Matching then
        if _ARG_0_.LTMatchAnimTimer then
          _ARG_0_.LTMatchAnimTimer = nil
        end
        if _ARG_0_.bTeammatesMatchedTimer then
          _ARG_0_:RemoveTimer(_ARG_0_.bTeammatesMatchedTimer)
          _ARG_0_.bTeammatesMatchedTimer = nil
          _ARG_0_.bTeammatesMatchedTimerPending = false
        end
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Border_0, false)
        _ARG_0_:_SetLTMatchVisible(false)
        U4(_ARG_0_.UIRoot.SizeBox_top)
        _ARG_0_:_SetHighLevelTipsVisible(false)
        _ARG_0_:UpdateWaitForMatchBackground()
        _ARG_0_.UIRoot.Image_13:SetRenderAngle(0)
        _ARG_0_.bHighLevelTipsExpanded = false
        _ARG_0_.nMatchPanelState = U5.Collapsed
        if _ARG_0_.MathInfoState == U6 then
        end
        _ARG_0_.MathInfoState = U7
        _ARG_0_.bDebugTimersSet = false
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) then
        end
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.Lobby_Mid_Message_UIBP) then
        end
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.team_extra_main) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ExpandMatchInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 143, 202, 237, 25, 150, 98, 101, 161, 147, 248, 51, 248, 216, 50, 209))
      if tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID()) > 0 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):IsCreativeWoW() then
        return
      end
      if _ARG_0_.MathInfoState == U2 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShrinkMatchInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 153, 218, 239, 17, 150, 109, 101, 161, 147, 248, 51, 248, 216, 50, 209))
      if _ARG_0_.MathInfoState == U2 then
        _ARG_0_:Driven(U3)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickExpand"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 133, 159, 235, 58, 223, 210))
      _ARG_0_:PlayAudio(sound_config.click)
      if _ARG_0_.MathInfoState == U2 then
        _ARG_0_:Driven(U3)
      else
        _ARG_0_:ExpandMatchInfo()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickShrink"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 147, 143, 233, 50, 223, 221))
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_:ShrinkMatchInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Driven"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(5, 200, 124, 133, 151, 108, 211, 191, 198, 36, 197, 239, 0, 142) .. _ARG_1_)
      _ARG_0_.MathInfoState = _ARG_1_
      if _ARG_1_ == U2 then
        _ARG_0_.UIRoot.Image_13:SetRenderAngle(180)
      else
        _ARG_0_.UIRoot.Image_13:SetRenderAngle(0)
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetIsShowLTMatch() then
        if _ARG_1_ == U2 then
          if not _ARG_0_:_IsLTMatchShown() then
            _ARG_0_.MathInfoState = U3
            if not require((table.concat({
              U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 193, 7, 143, 127, 91, 157, 152),
              U1(38, 200, 69, 169, 130, 123, 216, 135, 249, 36, 198, 212, 33, 221, 61)
            }))).CanShowHighLevelMatchTips() then
            else
            end
          else
            if not require((table.concat({
              U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 193, 7, 143, 127, 91, 157, 152),
              U1(38, 200, 69, 169, 130, 123, 216, 135, 249, 36, 198, 212, 33, 221, 61)
            }))).CanShowHighLevelMatchTips() then
              return
            end
            _ARG_0_.nMatchPanelState = U5.LTExpanded
          end
        elseif _ARG_0_.nMatchPanelState == U5.LTExpanded then
          _ARG_0_.nMatchPanelState = U5.LTOnly
          _ARG_0_.MathInfoState = U2
        else
        end
      else
      end
      if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) then
      end
      if _ARG_1_ == U2 then
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.Lobby_Mid_Message_UIBP) then
        end
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.team_extra_main) then
        end
      else
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.Lobby_Mid_Message_UIBP) then
        end
        if UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetChildUI(UIManager.UI_Config.team_extra_main) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickOpenSettings"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 143, 151, 254, 53, 226, 211, 32, 202, 55, 180, 197, 254))
      _ARG_0_:PlayAudio(sound_config.click)
      UIManager.ShowUI(UIManager.UI_Config.mode_selection_option)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnQRCodeRestrictChange"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 204, 42, 187, 105, 76, 165, 181, 254, 40, 197, 196, 61, 221, 42, 153, 202, 236, 6, 143, 115))
      _ARG_0_:RefreshQRCodeBattleRestrict()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFindingTeammates"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.WidgetSwitcher_State then
        return
      end
      if nMatchStatus ~= U1.Matching then
        return
      end
      if U2.tonumber(U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID()) > 0 or U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.LogicUGCMulti).bIsBundleMatch then
        return
      end
      if U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_mode_asymmertric):GetHasSelectedCamp() and U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.logic_mode_asymmertric):GetCampForMatch() == 1 then
      end
      if U3.IsShowTeammateMatch() and 1 <= U2.math.min(U3.GetTeammateMatchNum(), 1) and not _ARG_0_.bTeammatesMatched and not _ARG_0_.bTeammatesMatchedTimerPending then
        _ARG_0_.bTeammatesMatchedTimerPending = true
        if _ARG_0_.bTeammatesMatchedTimer then
          _ARG_0_.bTeammatesMatchedTimer = nil
        end
        _ARG_0_.bTeammatesMatchedTimer = _ARG_0_:AddTimerOnce(2, function()
          bTeammatesMatchedTimer = nil
          if _ENV and not bTeammatesMatched and UIRoot then
            bTeammatesMatched = true
            bTeammatesMatchedTimerPending = false
            _ENV:RefreshFindingTeammates()
          end
          return
        end)
      end
      if U3.IsShowTeammateMatch() and not _ARG_0_.bTeammatesMatched then
        if _ARG_0_.UIRoot.TextBlock_FindingTeammatesTime then
        end
      elseif waitLine and waitLine.nPos and 0 < waitLine.nPos then
        if _ARG_0_.UIRoot.TextBlock_QueueErrorTime then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnNextDayHandler"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 211, 29, 128, 114, 108, 161, 158, 211, 58, 223, 210, 56, 219, 44))
      if _ARG_0_.reqDataTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.reqDataTimer)
        _ARG_0_.reqDataTimer = nil
      end
      _ARG_0_.reqDataTimer = _ARG_0_:AddTimer(math.random(120), function()
        _ENV:OnTimerNextDayByRandomDelay()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnStartBtnAction"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 206, 12, 153, 116, 92, 130, 147, 245, 26, 210, 194, 61, 209, 48, 250, 195, 238, 28, 188, 111, 72, 181, 215),
        U1(127, 141)
      }) .. _ARG_3_)
      _ARG_0_:CheckAndAddEffect()
      _ARG_0_:CheckAndShowTips()
      _ARG_0_:CheckAndAddHandEffect()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndAddEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 218, 248, 27, 147, 71, 70, 164, 166, 255, 63, 244, 208, 50, 219, 61, 174))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndShowTips"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 218, 248, 27, 147, 71, 70, 164, 180, 243, 52, 198, 226, 61, 206, 45))
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
        U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
      }))).bShowTips and _ARG_0_.tipsUI == nil then
        require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
          U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
        }))).bShowTips = false
        _ARG_0_.tipsUI = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_tips, UIManager.UI_Config.Common_Normal_Tips_UIBP, 2, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndAddHandEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 218, 248, 27, 147, 71, 70, 164, 166, 255, 63, 249, 215, 58, 218, 27, 188, 196, 232, 11, 156))
      if LobbySystem.CheckUseNewGuide() and not require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 225, 7, 143, 127, 91, 143, 144),
        U1(48, 194, 127, 188, 158, 71, 192, 165, 228, 33, 196, 197, 48, 241, 44)
      }))).IsFinishAllNewGuide() then
        if require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 31, 138, 105, 95, 180, 143, 196, 43, 195, 217, 62, 219, 61, 174, 140, 225, 7, 143, 127, 91, 143, 144),
          U1(48, 194, 127, 188, 158, 71, 192, 165, 228, 33, 196, 197, 48, 241, 44)
        }))).CheckGuideStep(require((U1(33, 193, 97, 173, 152, 108, 158, 187, 228, 44, 200, 197, 106, 192, 43, 189, 208, 244, 29, 214, 106, 71, 167, 142, 248, 4, 223, 211, 35, 220, 55, 191))).NEWBIE_GUIDE_MODULE_ID_FIRST_BATTLE_AFTER_TASK, 0) then
        end
        return
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
        U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
      }))).bShowHandEffect then
        require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
          U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
        }))).bShowHandEffect = false
      end
      if require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
        U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
      }))).bThirdlyWeekGuide then
        require((table.concat({
          U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
          U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
        }))).bThirdlyWeekGuide = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearResetDepotGuide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 222, 248, 25, 138, 84, 77, 179, 130, 239, 31, 212, 198, 59, 202, 25, 175, 203, 233, 13))
      _ARG_0_.UIRoot.Canvas_Panel_HandGuide:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Button_Mask:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot:StopAnimation(_ARG_0_.UIRoot.Animation_Hand)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearActionEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 110, 137, 222, 248, 25, 138, 71, 75, 180, 142, 244, 53, 244, 208, 50, 219, 61, 174))
      require((table.concat({
        U1(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 63, 141, 111, 76, 165, 161, 247, 52, 198, 152, 21, 221, 42, 179, 205, 227, 70, 187, 98, 89, 162, 131),
        U1(0, 217, 102, 141, 144, 126, 213, 180, 255, 10, 194, 210, 45, 193, 32)
      }))).bPlayFxEffect = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTimerNextDayByRandomDelay"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(25, 200, 108, 191, 151, 106, 212, 138, 208, 38, 192, 210, 39, 198, 17, 185, 215, 241, 29, 155, 114, 119, 165, 137, 239, 41, 200, 235, 116, 235, 23, 133, 239, 236, 28, 139, 126, 103, 131, 146),
        U1(46, 200, 107, 188, 169, 93, 222, 163, 249, 50, 155, 233, 42, 250, 39, 167, 215, 239, 54, 157, 126, 92, 132, 134, 226, 25, 200, 228, 53, 208, 58, 181, 207, 201, 13, 132, 119, 65)
      }))
      if _ARG_0_.reqDataTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.reqDataTimer)
        _ARG_0_.reqDataTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchOptionsChange"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 25, 140, 101, 64, 143, 151, 239, 50, 222, 216, 39, 253, 54, 187, 204, 234, 13))
      _ARG_0_:OnClickEntryInternal()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAnimationEnd"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 220, 22, 145, 107, 73, 180, 142, 244, 53, 244, 216, 48))
      _ARG_0_.UIRoot.Canvas_Panel_HandGuide:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearHandEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 222, 248, 25, 138, 78, 73, 174, 131, 222, 61, 215, 211, 55, 202))
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Canvas_Panel_HandGuide then
        return
      end
      _ARG_0_.UIRoot.Canvas_Panel_HandGuide:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
      if _ARG_0_.UIRoot.Animation_Hand then
        _ARG_0_.UIRoot:StopAnimation(_ARG_0_.UIRoot.Animation_Hand)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayLobbyEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 154, 222, 252, 1, 180, 105, 74, 162, 158, 222, 61, 215, 211, 55, 202, 126, 187, 204, 228, 33, 134, 98, 93, 162, 129),
        U1(35, 193, 92, 161, 155, 125, 144, 234, 171)
      }) .. tostring(_ARG_1_) .. U1(98, 204, 102, 161, 184, 121, 221, 178, 171, 118, 129) .. tostring(_ARG_2_))
      if _ARG_0_.isPlayingEffect then
        return
      end
      _ARG_0_.isPlayingEffect = true
      _ARG_0_.aniIntervalTime = _ARG_1_ or 2
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Anina_Permanent, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopLobbyEffect"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 137, 222, 248, 25, 138, 78, 73, 174, 131, 222, 61, 215, 211, 55, 202, 126, 187, 204, 228, 38, 137, 123, 93, 240, 202),
        U1(98)
      }) .. tostring(_ARG_1_))
      if not _ARG_0_.isPlayingEffect then
        return
      end
      _ARG_0_.isPlayingEffect = false
      _ARG_0_.aniIntervalTime = 0
      _ARG_0_.UIRoot:StopAnimation(_ARG_0_.UIRoot.Anina_Permanent)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LobbyEffectEnd"] = function(_ARG_0_)
    do
      if not _ARG_0_.isPlayingEffect then
        return
      end
      _ARG_0_:AddTimerOnce(_ARG_0_.aniIntervalTime, function()
        if UIRoot and U1.slua.isValid(UIRoot) then
          _ENV:PlayUserWidgetAnimation(UIRoot.Anina_Permanent, 0, 1, 0, 1)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchLTGetData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 25, 140, 101, 64, 140, 179, 220, 62, 197, 242, 53, 202, 63, 250, 203, 254, 60, 141, 101, 76, 240, 202),
        U1(98)
      }) .. tostring(_ARG_3_))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetLTMatchGuideInfo(U2.SHORTEST) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetLTMatchGuideInfo(U2.VERSION) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetLTMatchGuideInfo(U2.RECENT) and not _ARG_3_ then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not _ARG_3_ then
        _ARG_0_ = _ARG_0_
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetLTMatchGuideInfo(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetRecommendTypeList()[tostring(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())]) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetLTMatchGuideInfo(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):GetRecommendTypeList()[tostring(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo())]).view_id ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo() then
        else
        end
        _ARG_0_ = _ARG_0_
        if 1 + 1 == 1 then
          return
        end
      else
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayExpandLTAnim"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 154, 222, 252, 1, 189, 126, 88, 161, 137, 255, 23, 229, 247, 58, 215, 51, 250, 203, 254, 59, 128, 121, 79, 132, 158),
        U1(50, 222, 40, 245, 214)
      }) .. tostring(_ARG_1_))
      if _ARG_0_.LTMatchAnimTimer then
        _ARG_0_.LTMatchAnimTimer = nil
      end
      _ARG_0_.LTMatchAnimTimer = require((U1(33, 194, 101, 165, 153, 118, 158, 163, 226, 38, 196, 249, 48, 199, 45, 161, 215, 239))).AddTimer(_ARG_0_.UIRoot.Animation_ShrinkAndExpansion:GetEndTime(), function()
        _ENV:SetWidgetVisible(UIRoot.SizeBox_top, true)
        _ENV:_SetLTMatchVisible(true)
        _ENV:UpdateWaitForMatchBackground()
        U1.EventSystem:postEvent(U1.EVENTTYPE_SKILL_SELECTION, U1.EVENTID_SKILL_SELECTION_MODE_OTHER_TIPS_SHOW)
        _ENV:SetWidgetVisible(UIRoot.Border_0, true)
        _ENV:_SetHighLevelTipsVisible(false)
        _ENV:UpdateWaitForMatchBackground()
        _ENV:PlayUserWidgetAnimation(UIRoot.Animation_MatchingGuide, 0, 1, 1, 1)
        MathInfoState = U2
        nMatchPanelState = U3.LTOnly
        if not U1.require((U1.table.concat({
          U4(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 21, 151, 98, 77, 159, 148, 254, 55, 212, 213, 32, 215, 49, 180, 140, 193, 7, 143, 127, 91, 157, 152),
          U4(38, 200, 69, 169, 130, 123, 216, 135, 249, 36, 198, 212, 33, 221, 61)
        }))).CanShowHighLevelMatchTips() then
          MathInfoState = U5
        else
          MathInfoState = U2
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchLTSwitchMode"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 25, 140, 101, 64, 140, 179, 200, 44, 216, 194, 55, 214, 19, 181, 198, 232))
      _ARG_0_:StartMatch(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateLTUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 159, 194, 249, 25, 140, 99, 100, 148, 178, 210))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot[U1(0, 216, 124, 188, 153, 118, 239, 133, 238, 40, 241, 202, 37, 215) .. _ARG_1_], true, true)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot[U1(11, 192, 105, 175, 147, 71, 252, 190, 229, 46) .. _ARG_1_], true)
      if _ARG_2_.rec_type == U2.VERSION then
      elseif _ARG_2_.rec_type == U2.SHORTEST then
      end
      if _ARG_2_.map_info.teamNum == 2 then
      elseif _ARG_2_.map_info.teamNum == 4 then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetFilterInfo().perspective == _ARG_2_.map_info.perspective and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetFilterInfo().teamNum == _ARG_2_.map_info.teamNum then
      end
      if _ARG_2_.map_info.perspective and _ARG_2_.map_info.perspective == 100053 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_RecPlay"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 130, 146, 239, 47, 222, 216, 11, 236, 59, 185, 242, 225, 9, 145))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLTMatchCancelTips"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 153, 218, 242, 15, 180, 82, 101, 161, 147, 248, 51, 242, 215, 58, 221, 59, 182, 246, 228, 24, 155))
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if U2.nEstimateTime > 0 and U2.nMatchingTime + CDataTable.GetTableData(U1(1, 204, 102, 171, 147, 116, 253, 182, 255, 40, 201, 246, 37, 220, 47, 167, 193), (U1(35, 193, 101, 167, 133, 108, 239, 186, 234, 63, 194, 206, 27, 218, 39, 167, 215))).Value - U2.nEstimateTime > 0 and CDataTable.GetTableData(U1(1, 204, 102, 171, 147, 116, 253, 182, 255, 40, 201, 246, 37, 220, 47, 167, 193), (U1(33, 204, 102, 171, 147, 116, 239, 186, 234, 63, 194, 206, 27, 220, 43, 167, 219, 243, 28, 167, 114, 65, 173, 130))).Value >= U2.nMatchingTime + CDataTable.GetTableData(U1(1, 204, 102, 171, 147, 116, 253, 182, 255, 40, 201, 246, 37, 220, 47, 167, 193), (U1(35, 193, 101, 167, 133, 108, 239, 186, 234, 63, 194, 206, 27, 218, 39, 167, 215))).Value - U2.nEstimateTime then
      end
      return
    end
  end,
  ["ReqLTMatch"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 152, 215, 236, 52, 172, 75, 73, 180, 132, 243))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):IsNeedReqLTMatch() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchResOK"] = function(_ARG_0_)
    do
      _ARG_0_.bMatching = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):CheckShowMatchUpdateTips(false)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckMatchUpdateTips"] = function(_ARG_0_)
    do
      if _ARG_0_.bMatching and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_long_time_match):CheckShowMatchUpdateTips(true) then
        _ARG_0_.bMatching = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ONFBStartMatch"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 252, 219, 58, 171, 114, 73, 178, 147, 214, 58, 197, 213, 60))
      _ARG_0_:StartMatch(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWidgetHide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 202, 17, 156, 97, 77, 180, 175, 242, 63, 212))
      _ARG_0_:AddTimerOnce(0, function()
        if not GameStatus.IsInLobbyOrMainCity() then
          return
        end
        if not UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP) or UIManager.GetUI(UIManager.UI_Config.Lobby_Main_UIBP):GetVisibility() == U1.ESlateVisibility.Collapsed then
          return
        end
        if U3.UIRoot.GuidePanel:GetVisibility() ~= U1.ESlateVisibility.Collapsed then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModHotStatChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      print(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 23, 156, 78, 71, 180, 180, 239, 58, 197, 245, 60, 223, 48, 189, 199), _ARG_3_)
      _ARG_0_:InitModHotStatShow(_ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitModHotStatShow"] = function(_ARG_0_, _ARG_1_)
    do
      if FuncUtil.IsInXMission() then
        _ARG_0_.UIRoot.HorizontalBox_HotStat:SetWidgetVisibility(U1.ESlateVisibility.Collapsed)
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection).hasSelectTxMission then
        return
      end
      if _ARG_1_ and _ARG_1_.start_type == require((U2(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 163, 136, 245, 61, 216, 209, 11, 203, 57, 185))).E_UGCGameStartType.Smart and not require((U2(33, 193, 97, 173, 152, 108, 158, 164, 231, 62, 192, 136, 40, 193, 41, 163, 209, 179, 13, 159, 101, 6, 181, 147, 242, 55, 238, 195, 51, 221))).IsSubModeGameMod(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache((tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID()))) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache((tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):GetMatchModID()))).pub_mod_meta) then
        if _ARG_1_.heat_level - 1 == 0 then
        elseif _ARG_1_.heat_level - 1 == 1 then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCPlayHallRoomCreate"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 200, 63, 187, 86, 68, 161, 158, 211, 58, 221, 218, 6, 209, 49, 183, 225, 255, 13, 137, 98, 93))
      _ARG_0_:InitUGCPlayHallRoomShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitUGCPlayHallRoomShow"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_State:SetActiveWidgetIndex(4)
      _ARG_0_.UIRoot.TextBlock_Entry:SetText(LocUtil.LocalizeResFormat(792521))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetMatchNum() > 1 then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetFastestMatchInfo() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetFastestMatchInfo() then
        end
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):GetRoomMatchInfo() then
      end
      _ARG_0_.ugcPlayHallTimer = _ARG_0_:AddTimerLoop(0, function()
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) then
        end
        return
      end, TIMER_INFINITE, 1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRoomAutoStartInfoChange"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 207, 23, 151, 107, 105, 181, 147, 244, 8, 197, 215, 38, 202, 23, 180, 196, 226, 43, 128, 119, 86, 183, 146))
      _ARG_0_:InitUGCPlayHallRoomShow()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchRoomPlayerChange"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 208, 25, 140, 101, 64, 146, 136, 244, 54, 225, 218, 53, 199, 59, 168, 225, 229, 9, 134, 113, 93))
      _ARG_0_:InitUGCPlayHallRoomShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCPlayHallRoomExit"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateStatus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Click"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 130, 146, 239, 47, 222, 216, 11, 253, 50, 179, 193, 230))
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_._bRecommendConsumed = true
      _ARG_0_:_MarkUserAction()
      _ARG_0_:_ClosePrivateRoomGameplayItem()
      UIManager.ShowUI(UIManager.UI_Config.Lobby_Gameplay_Popup, true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPrivateRoomGameplayItemClose"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 222, 20, 145, 101, 67, 144, 149, 242, 45, 208, 194, 49, 236, 49, 181, 207, 202, 9, 133, 115, 72, 188, 150),
        U1(59, 228, 124, 173, 155, 91, 220, 184, 248, 46)
      }))
      _ARG_0_:PlayAudio(sound_config.close)
      _ARG_0_:_ClosePrivateRoomGameplayItem()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClosePrivateRoomGameplayItem"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
        return
      end
      _ARG_0_._bPrivateRoomGameplayUserClosed = true
      _ARG_0_:_StopPrivateRoomGameplayTickTimer()
      _ARG_0_:_PlayPrivateRoomGameplayFadeOut(function()
        if UIRoot and UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP then
          _ENV:SetWidgetVisible(UIRoot.Lobby_PrivateRoom_Gameplay_Item_UIBP, false)
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUGCMatchPendingShow"] = function(_ARG_0_)
    do
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.UGCPlayHallRoom) then
        return
      end
      if nMatchStatus == U3.Matching then
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):CheckPendingMatchState() then
          return false
        else
        end
      else
        if nMatchStatus == U3.Not and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.UGCPlayHallRoom):CheckPendingMatchState() then
          return false
        else
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUGCPlayHallPendingMatchCancel"] = function(_ARG_0_)
    do
      print(bWriteLog and table.concat({
        U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 133, 220, 200, 63, 187, 86, 68, 161, 158, 211, 58, 221, 218, 4, 219, 48, 190, 203, 227, 15, 165, 119, 76, 179, 159),
        U1(1, 204, 102, 171, 147, 116)
      }))
      _ARG_0_:UpdateStatus()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetLTMatchVisible"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_._bLTMatchShown = _ARG_1_ and true or false
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.GridPanel_LTMatch, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetHighLevelTipsVisible"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_._bHighLevelTipsShown = _ARG_1_ and true or false
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_highLeveTips, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsLTMatchShown"] = function(_ARG_0_)
    do
      do return _ARG_0_._bLTMatchShown == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateWaitForMatchBackground"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideGuidePanel"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(23, 228, 87, 133, 151, 108, 211, 191, 212, 14, 207, 210, 54, 215, 116, 130, 219, 249, 29, 191, 115, 65, 164, 130, 203, 58, 223, 211, 56))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.GuidePanel, false)
      _ARG_0_:ClearHandEffect()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckReturnMatchTips"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):IsShowMatchTips() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
