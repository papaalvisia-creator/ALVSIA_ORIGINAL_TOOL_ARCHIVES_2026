do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(92, 62, 214, 112, 0, 108, 3, 50, 12, 97, 150, 3))).TraitClass(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 40, 206, 153, 254, 136, 189, 0, 166, 72, 232, 93, 47, 29, 64, 114, 142, 20, 206))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 168, 89, 240, 64, 125, 2, 15, 114, 166, 3, 139, 221, 145, 219, 172, 93, 251, 89, 230, 81, 61, 10),
        U1(94, 40, 246, 114, 11, 103, 13, 123, 94, 37, 140, 91, 155, 153, 213, 139, 162, 40, 175, 13, 162, 18, 120, 5, 66, 48, 140, 21, 202, 148, 212, 183, 187, 81, 230, 29, 170, 81, 97, 70),
        U1(86, 34, 235, 124, 1, 102, 66, 52, 31, 67, 151, 18, 200, 132, 129, 211, 239, 68, 184, 1, 191, 94, 52, 27, 7, 100, 189, 2, 204, 137, 222, 144, 255, 76, 251, 24, 252, 205, 241, 234),
        U1(31, 2, 206, 109, 31, 110, 84, 4, 56, 105, 141, 4, 207, 163, 201, 129, 184, 65, 246, 13, 186, 65)
      }), _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_, _ARG_9_))
      _ARG_0_.parentFrame = _ARG_2_
      _ARG_0_.bFirstShow = _ARG_9_
      _ARG_0_.bShowing = false
      _ARG_0_.bDataReady = false
      _ARG_0_.tabId = _ARG_3_
      _ARG_0_.displayMode = _ARG_4_
      _ARG_0_.modeOneSwitchIndex = 0
      _ARG_0_.itemId = _ARG_5_
      _ARG_0_.limitRegion = _ARG_8_ or {}
      _ARG_0_.crateId = _ARG_6_ or 0
      _ARG_0_.needShowCustomWithBan = false
      _ARG_0_.haveCustomData = false
      _ARG_0_.banInfo = {}
      _ARG_0_.curOneButtonBGPath = nil
      _ARG_0_.curTenButtonBGPath = nil
      _ARG_0_.rawData = {}
      _ARG_0_.pageInfo = {couponSceneSupplyBuyOne = nil, couponSceneSupplyBuyTen = nil}
      _ARG_0_.itemDataList = {}
      _ARG_0_.showDataList = {}
      _ARG_0_.currentItem = {}
      _ARG_0_.currentItemIndex = 0
      _ARG_0_.leftTimeTimer = nil
      _ARG_0_.secondUpTimeTimer = nil
      _ARG_0_.DailyDiscountTimer = nil
      _ARG_0_.timerEquipedAction = nil
      _ARG_0_.bPlayingVideo = false
      _ARG_0_.deviceLevel = 0
      _ARG_0_.exchangeID = nil
      _ARG_0_.extraBoxSelectItemID = nil
      _ARG_0_.refreshTimer = nil
      _ARG_0_.videoEndPlayEmotionHandle = nil
      _ARG_0_.isChanceChange = false
      _ARG_0_.bIsInPlayAnimation = false
      _ARG_0_.bIsHadShowCouponPopup = false
      do return end
      _ARG_0_ = _ENV[246]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPageInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 153, 72, 249, 64, 56, 5, 6, 64, 142, 0, 206, 192, 197, 159, 189, 56, 191, 29, 178, 2, 104, 21),
        U1(19, 113, 223, 116, 28, 114, 65, 39, 7, 77, 144, 19, 222, 208, 156, 206, 234, 18, 231, 13, 246, 70, 56, 27, 39, 116, 207, 90, 139, 197, 194, 210, 255, 18, 169, 92, 251, 71, 4, 2),
        U1(31, 108, 155, 56, 28, 46, 13, 47, 13, 80, 158, 25, 223, 159, 211, 143, 140, 9, 174, 94, 235, 18, 96, 86, 75, 99)
      }), _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_))
      log_tree(U1(83, 56, 214, 116, 27, 80, 72, 33, 23, 111, 145, 87, 134, 208), _ARG_7_)
      EventSystem:postEvent(EVENTTYPE_SHOP, EVENTID_STORE_CHEST_GO_BACK)
      if _ARG_0_.tabId == _ARG_2_ and not _ARG_4_ then
        _ARG_4_ = _ARG_0_.currentItem.itemId
      end
      _ARG_0_.parentFrame = _ARG_1_
      _ARG_0_.bDataReady = false
      _ARG_0_.tabId = _ARG_2_
      _ARG_0_.displayMode = _ARG_3_
      _ARG_0_.modeOneSwitchIndex = 0
      _ARG_0_.itemId = _ARG_4_
      _ARG_0_.limitRegion = _ARG_7_ or {}
      _ARG_0_.crateId = _ARG_5_ or 0
      _ARG_0_.needShowCustomWithBan = false
      _ARG_0_.haveCustomData = false
      _ARG_0_.banInfo = {}
      _ARG_0_.rawData = {}
      _ARG_0_.pageInfo = {}
      _ARG_0_.itemDataList = {}
      _ARG_0_.showDataList = {}
      _ARG_0_.currentItem = {}
      _ARG_0_.currentItemIndex = 0
      _ARG_0_.bPlayingVideo = false
      _ARG_0_.extraBoxSelectItemID = nil
      _ARG_0_.curOneButtonBGPath = nil
      _ARG_0_.curTenButtonBGPath = nil
      _ARG_0_.videoEndPlayEmotionHandle = nil
      _ARG_0_.isChanceChange = false
      if _ARG_0_.leftTimeTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.leftTimeTimer)
        _ARG_0_.leftTimeTimer = nil
      end
      if _ARG_0_.secondUpTimeTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.secondUpTimeTimer)
        _ARG_0_.secondUpTimeTimer = nil
      end
      if _ARG_0_.DailyDiscountTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.DailyDiscountTimer)
        _ARG_0_.DailyDiscountTimer = nil
      end
      if _ARG_0_.DailyTenDiscountTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.DailyTenDiscountTimer)
        _ARG_0_.DailyTenDiscountTimer = nil
      end
      EventSystem:postEvent(EVENTTYPE_DETAIL_COMPONENT, EVENTID_DETAIL_HIDE_ALL_COMPONENT)
      _ARG_0_:StopDefaultEquipedAction()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGoodLuckCardConfig"] = function(_ARG_0_)
    do
      goto lbl_180
      if U2.GetActivityCard(nil) and type(U2.GetActivityCard(nil).JumpLink) == U3(76, 37, 201, 116, 1, 101) and tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).module) == 1008201 then
        if 0 < (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).crateId) or 0) or 0 < (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).crateId2) or 0) or 0 < (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).crateId3) or 0) then
          if 0 < (tonumber(_ARG_0_.crateId) or 0) and ((tonumber(_ARG_0_.crateId) or 0) == (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).crateId) or 0) or (tonumber(_ARG_0_.crateId) or 0) == (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).crateId2) or 0) or (tonumber(_ARG_0_.crateId) or 0) == (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).crateId3) or 0)) then
            return (U2.GetActivityCard(nil))
          end
        elseif 0 < (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).Tab1) or 0) and (tonumber(_ARG_0_.tabId) or 0) == (tonumber(U4.ParseURLParams(U2.GetActivityCard(nil).JumpLink).Tab1) or 0) then
          return (U2.GetActivityCard(nil))
        end
      end
      ::lbl_180::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearGoodLuckEntry"] = function(_ARG_0_)
    do
      if _ARG_0_.goodLuckEntryFrame then
        _ARG_0_.goodLuckEntryFrame:ClearGoodLuckEntry(_ARG_0_)
        _ARG_0_.goodLuckEntryFrame = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGoodLuckEntryFrame"] = function(_ARG_0_)
    do
      do return _ARG_0_.parentFrame end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGoodLuckEntry"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot and _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard then
      end
      if not _ARG_0_.bShowing then
        return
      end
      if not _ARG_0_:GetGoodLuckEntryFrame() or not (_ARG_0_:GetGoodLuckCardConfig() and tonumber(_ARG_0_:GetGoodLuckCardConfig().CardID)) then
        return
      end
      if _ARG_0_.goodLuckEntryFrame ~= _ARG_0_:GetGoodLuckEntryFrame() then
      end
      _ARG_0_.goodLuckEntryFrame = _ARG_0_:GetGoodLuckEntryFrame(), _ARG_0_:GetGoodLuckCardConfig(), _ARG_0_:GetGoodLuckCardConfig() and tonumber(_ARG_0_:GetGoodLuckCardConfig().CardID), tonumber(_ARG_0_:GetGoodLuckCardConfig().ActivityID) or 0, _ARG_0_:GetGoodLuckEntryFrame():SetGoodLuckEntry(_ARG_0_, 0 < (tonumber(_ARG_0_:GetGoodLuckCardConfig().ActivityID) or 0) and (tonumber(_ARG_0_:GetGoodLuckCardConfig().ActivityID) or 0) or nil, _ARG_0_:GetGoodLuckCardConfig() and tonumber(_ARG_0_:GetGoodLuckCardConfig().CardID))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      U1.EventSystem:postEvent(U1.EVENTTYPE_DETAIL_COMPONENT, U1.EVENTID_DETAIL_HIDE_ALL_COMPONENT)
      U2.BlockPopTip()
      if _ARG_0_.UIRoot.Crate_Exchange_Item_UIBP then
        _ARG_0_.UIRoot.Crate_Exchange_Item_UIBP:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:BindBuyOneEvent()
      _ARG_0_:BindBuyTenEvent()
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_Caption, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickProbabilityDetail, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_Check, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickTitleReturn, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_Return, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickTitleReturn, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_2, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickSwitchDisplay, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_JK_Detail, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickExtraRate, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Box_Entrance_UIBP.Button_Box, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickOptionalBox, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Store_Remind_Btn.Button_0, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickCollectBtn, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Store_Remind_Btn.Button_2, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickCollectBtn, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Store_Discount_Btn_UIBP.Button_Dis, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickDisBtn, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Close_Wish_Tips, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickCloseWishTip, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_9, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickReviseWish, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Crate_JK_Box_Integral.Button_JK_Box_Integral, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickShowCrateExchangeUI, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Store_PROT_Reward_UIBP.Button_1, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickConservationRewards, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Button_0, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickJumpVehicleSp, _ARG_0_)
      _ARG_0_:AddOnAnimationStartedEvent(U1(121, 48, 223, 120, 6, 108), _ARG_0_.OnPlayAnimationStart, _ARG_0_)
      _ARG_0_:AddOnAnimationFinishedEvent(U1(121, 48, 223, 120, 6, 108), _ARG_0_.OnPlayAnimationEnd, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Lobby_DirectPurchase_LimitedTimeGiftSet_Item_2.Button_0, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickSpecialLimitedJump, _ARG_0_)
      if _ARG_0_.UIRoot.Crate_Exchange_Item_UIBP then
        _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Crate_Exchange_Item_UIBP.Button_Exchange, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickExchange, _ARG_0_)
      end
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Crate_Box_Onekey_Entrance_UIBP.Button_Box, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickOneKeyEntranceBtn, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTID_SUPPLY_DATA, U2.EVENTID_CRATE_BAN_CLICK, _ARG_0_.OnClickCustomBan, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_CRATE_BAN_DATA, _ARG_0_.OnCustomCrateInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_CRATE_JPKR_CREDIT, _ARG_0_.OnJPKRCreditInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_COLLECT, _ARG_0_.OnCollectedResult, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_BUY_INFO_CHANGE, _ARG_0_.OnBuyInfoChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_DATA_MGR, U2.EVENTID_DATAMGR_HALL_DEPOT_DATA_CHANGE, _ARG_0_.OnInventoryChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ROLEINFO, U2.EVENTID_ROLEINFO_UPDATE_HEAD_INFO, _ARG_0_.OnInventoryChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ROLEINFO, U2.EVENTID_ROLEINFO_UPDATE_AVATAR_PORTRAIT, _ARG_0_.OnInventoryChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_PET, U2.EVENTID_PET_CHANGE, _ARG_0_.OnInventoryChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_SUPPLY_BUY, _ARG_0_.OnBuySucceeded, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_STORE_CLICK_CLOSE_BOX_PANEL, _ARG_0_.RefreshAllPrice, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_SHOP_BUY_AGAIN_CLICK, _ARG_0_.OnBuyAgain, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_SUPPLY_REF_PRICE, _ARG_0_.RefreshAllPrice, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_UPDATE_OPTIONAL_CHEST, _ARG_0_.OnUpdateOptionalChest, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_BUY, _ARG_0_.OnSuccessBuy, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_AG_LIMIT, _ARG_0_.RefAGBuyBtnHandle, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SUBSCRIBE, U2.EVENTID_SUBSCRIBE_GET_STATUS_DATA, _ARG_0_.RefreshBuyOneBtnInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_CRATE_REFRENCE_TEN_BUY, _ARG_0_.RefreshBuyTenBtnInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_CRATE_COLLECT_STATE_CHANGE, _ARG_0_.OnCollectedCrateChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTIVITY, U2.EVENTID_SUPPLY_DISCOUNT_UPDATE, _ARG_0_.UpdateByActivity, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_WISH_SHOW_TIPS, _ARG_0_.ShowWishTip, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_STORE_CHEST_ITEM_EXTERNAL, _ARG_0_.OnClickItemExternal, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_STORE_CHEST_HIDE_SUPPLY_VIEW, _ARG_0_.HideRightView, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_STORE_CHEST_SHOW_SUPPLY_VIEW, _ARG_0_.ShowRightView, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_STORE_CHEST_CLICK_WISH_ITEM, _ARG_0_.OnClickItemByWish, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_STORE_CHEST_SHOW_RATE_BTN, _ARG_0_.ShowExtraJPRateBtn, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_MALL, U2.EVENTID_BoxDetail_JKRate_URL, _ARG_0_.JumpJKUrl, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_BTNEVENT, U2.EVENTID_STORE_ONCLICK_PREVIEW, _ARG_0_.OnClickFullScreen, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_DATA_MGR, U2.EVNETID_DATAMGR_ACTIVITY_CHANGE, _ARG_0_.OnDataChangeList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTIVITY, U2.EVENTID_ACTIVITY_INFO, _ARG_0_.UpdateCrateActivity, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTIVITY, U2.EVENTID_SUPPLY_ACTIVITY_UPDATE, _ARG_0_.UpdateCrateActivity, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_WISH_BACK, _ARG_0_.RefreshWishInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_VIDEO, U2.EVENTID_STORE_WISH_ITEM_GET, _ARG_0_.CheckWishItemGet, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LUCKAIR_TARGET, U2.EVENTID_LUCKY_AIRDROP_TARGET_SHOW, _ARG_0_.ShowAirDropIcon, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LUCKAIR_TARGET, U2.EVENTID_LUCKY_AIRDROP_TARGET_HIDE, _ARG_0_.HideAirDropIcon, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_SmallKT_Entrance_Item_UIBP.Button_0, U1(112, 63, 248, 113, 6, 97, 70, 35, 26), _ARG_0_.OnClickAirDropIcon, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_SUPPLY_PUT_ON_ITEM, _ARG_0_.OnUpdateItem, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ADVERTISE, U2.EVENTID_ADVERTISE_SHOW_LOBBY_UPDATE, _ARG_0_.OnAdvertiseStateUpdate, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_VIDEO, U2.EVENTID_VIDEO_ENDS, _ARG_0_.OneVideoEndPlayEmotion, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_PUFFER, U2.EVENTID_CLICK_DOWNLOAD, _ARG_0_.OnAvatarClickDownload, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_PUFFER, U2.EVENTID_PUFFER_DOWNLOADFINISH, _ARG_0_.OnAvatarDownloadFinished, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_PUFFER, U2.EVENTID_REMOVE_CLICK_DOWNLOAD, _ARG_0_.OnRemoveAvatarClickDownload, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SHOP, U2.EVENTID_SUPPLY_EXTRA_DRAW, _ARG_0_.RefreshItemList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_STORE_DATA, U2.EVENTID_STORE_REF_ITEM_EQUIPPED, _ARG_0_.UpdateEquipedStateAndReferesh, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTIVITY_BLACK_FRIDAY, U2.EVENTID_ACTIVITY_BLACK_FRIDAY_ACT_CONFIG_UPDATE, _ARG_0_.RefreshGoodLuckEntry, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:InitItemList()
      _ARG_0_:InitSupplyPageData()
      if U1.GlobalData.IsJapanOrKorea() and U1.FuncUtil.GetAccountRegionForBP() == U1.require((U1.table.concat({
        U2(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 216, 159, 207, 136, 166, 6, 229, 110, 243, 91, 56, 24, 26, 93, 142, 4, 217, 143, 194, 208, 158, 18, 184, 82, 250, 76, 57, 52),
        U2(90, 54, 210, 114, 1, 68, 66, 52, 60, 80, 178, 22, 216, 130, 206, 157)
      }))).JP then
      end
      _ARG_0_.deviceLevel = U1.require((U2(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 212, 135, 144, 20, 191, 68, 243))).GetGameInstance():GetDeviceLevel()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      _ARG_0_.bShowing = true
      _ARG_0_:RefreshUI()
      _ARG_0_:RefreshGoodLuckEntry()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsShowJPKRCredit"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPageConfig"] = function(_ARG_0_)
    do
      do return UIManager.UI_Config.SupplyGeneralPage end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckSecondUp"] = function(_ARG_0_)
    do
      if _ARG_0_.pageInfo.startTime2 - GetServerTimeInSec() <= 14400 then
        if _ARG_0_.secondUpTimeTimer ~= nil then
          _ARG_0_.secondUpTimeTimer = nil
        end
        _ARG_0_.secondUpTimeTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV:UpdateUIForSecondUp()
          return
        end, U1.TIMER_INFINITE, 1)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUIForSecondUp"] = function(_ARG_0_)
    do
      if GetServerTimeInSec() > _ARG_0_.pageInfo.startTime2 then
        if _ARG_0_.secondUpTimeTimer ~= nil then
          _ARG_0_.secondUpTimeTimer = nil
        end
        _ARG_0_.pageInfo.chanceUpEndTime = _ARG_0_.rawData[U1.StoreConst.label_shop_index_show_up_end_time_two] or 0
        _ARG_0_.pageInfo.bChanceUp = GetServerTimeInSec() < _ARG_0_.pageInfo.chanceUpEndTime
        _ARG_0_.param = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickOneKeyEntranceBtn"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and U1(112, 63, 222, 86, 10, 123, 23, 5, 18, 105, 156, 28, 244, 158, 196, 165, 170, 24, 142, 67, 235, 64, 60, 24, 13, 117, 173, 19, 197))
      _ARG_0_:GetFrame().OneKey.tabId = _ARG_0_.tabId
      goto lbl_62
      if _ARG_0_:GetFrame().TabPanel:GetTabListData().tabId == _ARG_0_.tabId then
        _ARG_0_:GetFrame().OneKey.tabName = _ARG_0_:GetFrame().TabPanel:GetTabListData().tabName
      else
        ::lbl_62::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.itemDataList then
        _ARG_0_:GetFrame().OneKey.ItemList = _ARG_0_.itemDataList
      else
        _ARG_0_:GetFrame().OneKey.ItemList = {}
      end
      _ARG_0_:GetFrame().OneKey.banInfo = _ARG_0_.banInfo
      _ARG_0_:GetFrame().OneKey.originalPrice = require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 124, 128, 0, 194, 131, 238, 141, 170, 1, 171, 81, 246, 125, 61, 20),
        U1(86, 50, 222, 66, 6, 108, 75, 41)
      }))).GetTenOriginalPericeAndDiscount()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSuccessBuy"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateBuyOneBtnInfo()
      _ARG_0_:UpdateBuyTenBtnInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBuyOneBtnInfo"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBuyTenBtnInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_.firstPrice = _ARG_3_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[6]
    end
  end,
  ["OnAdvertiseStateUpdate"] = function(_ARG_0_)
    do
      if not (_ARG_0_.bShowing and _ARG_0_.bDataReady and _ARG_0_.rawData) or not _ARG_0_.pageInfo then
        printf(table.concat({
          U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 132, 67, 222, 86, 43, 19, 28, 100, 134, 20, 206, 179, 197, 159, 171, 20, 142, 77, 235, 67, 57, 3),
          U1(31, 35, 222, 119, 10, 97, 89, 35, 26, 44, 223, 21, 232, 152, 206, 153, 166, 15, 172, 23, 186, 65, 113, 86, 12, 84, 142, 19, 202, 178, 212, 159, 187, 8, 225, 24, 252, 14, 109, 14),
          U1(94, 34, 233, 124, 24, 70, 76, 50, 31, 58, 218, 4, 151, 208, 201, 143, 188, 49, 170, 74, 250, 123, 51, 16, 1, 42, 202, 20)
        }), _ARG_0_.bShowing, _ARG_0_.bDataReady, _ARG_0_.rawData ~= nil, _ARG_0_.pageInfo ~= nil)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopDefaultEquipedAction"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 50, 191, 66, 239, 118, 56, 16, 15, 101, 131, 19, 238, 145, 196, 151, 175, 20, 191, 124, 236, 86, 36, 9),
        U1(81)
      }))
      if _ARG_0_.timerEquipedAction ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.timerEquipedAction)
        _ARG_0_.timerEquipedAction = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaySelectAnimation"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCustomBan"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSpecialLimitedJump"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDiscountHelp"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 46, 165, 110, 243, 91, 62, 29, 42, 121, 156, 4, 196, 149, 223, 138, 151, 20, 183, 77))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if UIManager.ShowUI(UIManager.UI_Config.Common_HelpTips_UIBP) then
      end
      return
    end
  end,
  ["FilterItemByCondition"] = function(_ARG_0_)
    do
      _ARG_0_.showDataList = {}
      goto lbl_29
      if _ARG_0_.haveCustomData == true then
        ;(nil).ban = _ARG_0_.banInfo.data.banItems[(nil).shopId] or 0
      end
      if (nil).ban == 0 then
      else
        ;(nil).selected = false
      end
      ::lbl_29::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsDefaultWearing"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_10
      if nil == _ARG_1_ then
        return true
      end
      ::lbl_10::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUI"] = function(_ARG_0_)
    do
      if _ARG_0_.bShowing == true and _ARG_0_.bDataReady == true then
        log(bWriteLog and table.concat({
          U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 153, 72, 249, 64, 56, 5, 6, 69, 166, 75, 139, 130, 247, 151, 173, 2, 175, 110, 231, 77, 58, 70),
          U1(2, 113)
        }) .. tostring(_ARG_0_.bFirstShow))
        if _ARG_0_.refreshTimer then
          _ARG_0_:RemoveTimer(_ARG_0_.refreshTimer)
        end
        _ARG_0_.refreshTimer = _ARG_0_:AddTimerOnce(0.1, function()
          _ENV:UpdateAvatar()
          _ENV:UpdateUI()
          _ENV:ChooseTheFirstOrSpecifiedOne()
          _ENV:UpdateBuyOneBtnInfo()
          _ENV:UpdateBuyTenBtnInfo()
          _ENV:UpdateCrateActivityComponent(true)
          _ENV:UpdateCrateCollectedUI()
          _ENV:UpdateCustomCrateInfo()
          _ENV:UpdateJPKRCreditInfo()
          _ENV:UpdateOptionalChestInfo()
          _ENV:UpdateJKDifference()
          _ENV:ShowAirDropIcon()
          if _ENV:CheckChanceUpEndTimeChanged() then
            _ENV:UpdateItemList()
          end
          refreshTimer = nil
          _ENV:PlayFirstAnimation()
          _ENV:UpdateSportNewGuide()
          _ENV:ShowSportsCarDiscountTipsPopup()
          return
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayFirstAnimation"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CanvasPanel_17:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_.UIRoot.Panel_Root:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if GlobalData.IsJapanOrKorea() then
        _ARG_0_.UIRoot.BuyBtn_Root:SetRenderScale(FVector2D(-1, 1))
        _ARG_0_.UIRoot.Border_anniu1:SetRenderScale(FVector2D(-1, 1))
        _ARG_0_.UIRoot.Border_anniu2:SetRenderScale(FVector2D(-1, 1))
      else
        _ARG_0_.UIRoot.BuyBtn_Root:SetRenderScale(FVector2D(1, 1))
        _ARG_0_.UIRoot.Border_anniu1:SetRenderScale(FVector2D(1, 1))
        _ARG_0_.UIRoot.Border_anniu2:SetRenderScale(FVector2D(1, 1))
      end
      if GlobalData.IsJapanOrKorea() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.store_supply_switcher).StoreFirstShow and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.store_supply_switcher).SupplyFirstShow then
          ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.store_supply_switcher).SupplyFirstShow = false
        else
        end
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.store_supply_switcher).SupplyFirstShow then
        ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.store_supply_switcher).SupplyFirstShow = false
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI"] = function(_ARG_0_)
    do
      if _ARG_0_.bShowing == true and _ARG_0_.bDataReady == true then
        _ARG_0_:UpdateCouponIcon()
        _ARG_0_:UpdateBannerModel()
        _ARG_0_:InitPopTitleContent()
        _ARG_0_:UpdateRPTips()
        _ARG_0_:ConservationRewardsShow()
        _ARG_0_:UpdateOnekeyBtn()
        _ARG_0_:RecoverRightView()
        _ARG_0_:UpdateIncreasedChance()
        _ARG_0_:UpdateButtonBG()
        _ARG_0_:InitGraduallyTipWidget()
        _ARG_0_:UpdateSportsCarJumpBtn()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SwitchSupplyDropInfoLogReport"] = function(_ARG_0_, _ARG_1_)
    do
      ReportLobbyClickEvent(SubEventName_SupplyDropInfo, U1.tostring(_ARG_0_.tabId), _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateIncreasedChance"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_3, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_10, false)
      if GlobalData.IsJapanOrKorea() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateButtonBG"] = function(_ARG_0_)
    do
      if not GlobalData.IsJapanOrKorea() and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_advertisement_BlueHole):CheckCanGetAdvertisementData() then
        return
      end
      if _ARG_0_.curOneButtonBGPath ~= require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 99, 154, 23, 219, 140, 200, 161, 187, 24, 189, 91, 234, 80, 40, 8),
        U1(75, 56, 218, 105, 10, 102, 114, 37, 17, 110, 153, 30, 220)
      }))).GetOneButtonBGPath(_ARG_0_.pageInfo.shopId) then
      end
      if _ARG_0_.curTenButtonBGPath ~= require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 99, 154, 23, 219, 140, 200, 161, 187, 24, 189, 91, 234, 80, 40, 8),
        U1(75, 56, 218, 105, 10, 102, 114, 37, 17, 110, 153, 30, 220)
      }))).GetTenButtonBGPath(_ARG_0_.pageInfo.shopId) then
      end
      _ARG_0_.is_AD_BtnShow = _ARG_0_:CheckShowAdvertisementBtn()
      if _ARG_0_.is_AD_BtnShow then
        if _ARG_0_:GetWatchCountByScenceType() and _ARG_0_:GetWatchCountByScenceType() then
        end
      else
      end
      _ARG_0_.curTenButtonBGPath, _ARG_0_.curOneButtonBGPath = require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 99, 154, 23, 219, 140, 200, 161, 187, 24, 189, 91, 234, 80, 40, 8),
        U1(75, 56, 218, 105, 10, 102, 114, 37, 17, 110, 153, 30, 220)
      }))).GetTenButtonBGPath(_ARG_0_.pageInfo.shopId), require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 99, 154, 23, 219, 140, 200, 161, 187, 24, 189, 91, 234, 80, 40, 8),
        U1(75, 56, 218, 105, 10, 102, 114, 37, 17, 110, 153, 30, 220)
      }))).GetOneButtonBGPath(_ARG_0_.pageInfo.shopId), require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 99, 154, 23, 219, 140, 200, 161, 187, 24, 189, 91, 234, 80, 40, 8),
        U1(75, 56, 218, 105, 10, 102, 114, 37, 17, 110, 153, 30, 220)
      }))).GetTenButtonBGPath(_ARG_0_.pageInfo.shopId), _ARG_0_.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateOnekeyBtn"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Crate_Box_Onekey_Entrance_UIBP:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if not _ARG_0_:GetFrame():GetTabListData() then
        return
      end
      goto lbl_73
      if (nil).tabId and (nil).IsSupportOneKey then
        if (nil).tabId == _ARG_0_.tabId and (nil).IsSupportOneKey == 1 then
          goto lbl_75
        end
      elseif (nil).subTabList and next((nil).subTabList) then
        goto lbl_71
        if (nil).tabId == _ARG_0_.tabId and (nil).IsSupportOneKey == 1 then
        else
          ::lbl_71::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      ::lbl_73::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_75::
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDataChangeList"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateCrateActivityComponent(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSportsCarJumpBtn"] = function(_ARG_0_)
    do
      if not GlobalData.IsJapanOrKorea() then
        return
      end
      if not require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey) then
        return
      end
      if CDataTable.GetTableData(U1(117, 36, 214, 109, 42, 122, 78, 46, 31, 110, 152, 18, 238, 130, 205, 173, 160, 15, 173, 68, 248), require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey).KJExchangeItemID) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSportsCarDiscountTipsPopup"] = function(_ARG_0_)
    do
      if _ARG_0_.tabId ~= require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey).KJSuppyTabId or not _ARG_0_.bShowing then
        _ARG_0_.bIsHadShowCouponPopup = false
        return
      end
      if _ARG_0_.bIsHadShowCouponPopup then
        return
      end
      _ARG_0_.bIsHadShowCouponPopup = true
      if require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 95, 171, 72, 233, 68, 40, 20),
        U1(96, 60, 218, 115, 14, 101, 72, 52)
      }))).GetState(require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 46, 184, 82, 225, 81, 57))).ENUM_DownloadType.ODPAK, {
        (_ARG_0_:GetSportCarsExchangeRes())
      }) ~= require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 46, 184, 82, 225, 81, 57))).ENUM_DownloadState.Done then
        return
      end
      if require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetIsPopupDiscountCouponPanelJP() then
        if not require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 163, 14, 169, 79, 230, 109, 60, 21, 26, 121, 153, 14, 223, 153, 159, 173, 175, 30, 169, 73, 252, 97, 44, 20),
          U1(108, 33, 210, 115, 65, 65, 66, 40, 24, 105, 152, 89, 232, 128, 206, 156, 187, 18, 136, 76, 237, 97, 45, 31, 0, 83, 128, 9, 205, 137, 214)
        }))).GetSpinChildElemCfg(require((U1(92, 62, 214, 112, 0, 108, 3, 50, 31, 98, 147, 18, 228, 133, 213, 135, 163))).GetTableValue(require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
          U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
        }))).GetUIConfig(), (U1(73, 52, 201, 110, 6, 109, 67))), (U1(123, 56, 200, 126, 0, 119, 67, 50))) then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSportCarsExchangeRes"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey) then
        return
      end
      if not require((U1(92, 62, 214, 112, 0, 108, 3, 50, 31, 98, 147, 18, 228, 133, 213, 135, 163))).GetTableValue(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey), U1(74, 56, 248, 114, 1, 100, 68, 33, 13), U1(82, 48, 210, 115), (U1(93, 33))) then
        return
      end
      do return (require((U1(92, 62, 214, 112, 0, 108, 3, 50, 31, 98, 147, 18, 228, 133, 213, 135, 163))).GetTableValue(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey), U1(74, 56, 248, 114, 1, 100, 68, 33, 13), U1(82, 48, 210, 115), (U1(93, 33)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSportNewGuide"] = function(_ARG_0_)
    do
      if _ARG_0_.tabId ~= require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey).KJSuppyTabId or not _ARG_0_.bShowing then
        return
      end
      if (require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 42, 17, 103, 150, 20, 149, 188, 206, 137, 166, 2, 155, 65, 254, 75, 56, 4, 62, 98, 138, 1, 216, 206, 193, 146, 190, 8, 190, 79, 255, 80, 40, 0),
        U1(76)
      }))).LoadFileToTable_N(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 42, 17, 103, 150, 20, 149, 188, 206, 137, 166, 2, 155, 65, 254, 75, 56, 4, 62, 98, 138, 1, 216, 206, 193, 146, 190, 8, 190, 79, 255, 80, 40, 0),
        U1(76)
      }))).ePlayerPrefsType.eSupplyJKSportsCarNewGuide) or {}).newGuide then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowSportsCarNewGuide"] = function(_ARG_0_)
    do
      ;(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 42, 17, 103, 150, 20, 149, 188, 206, 137, 166, 2, 155, 65, 254, 75, 56, 4, 62, 98, 138, 1, 216, 206, 193, 146, 190, 8, 190, 79, 255, 80, 40, 0),
        U1(76)
      }))).LoadFileToTable_N(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 42, 17, 103, 150, 20, 149, 188, 206, 137, 166, 2, 155, 65, 254, 75, 56, 4, 62, 98, 138, 1, 216, 206, 193, 146, 190, 8, 190, 79, 255, 80, 40, 0),
        U1(76)
      }))).ePlayerPrefsType.eSupplyJKSportsCarNewGuide) or {}).newGuide = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAvatar"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetDefaultEquip"] = function(_ARG_0_)
    do
      if _ARG_0_.pageInfo and _ARG_0_.pageInfo.defaultEquiped and type(_ARG_0_.pageInfo.defaultEquiped) == U1(75, 48, 217, 113, 10) and next(_ARG_0_.pageInfo.defaultEquiped) then
        goto lbl_262
        if _ARG_0_.itemId == nil or _ARG_0_.itemId ~= U1(96, 53, 218, 105, 14) then
          if CDataTable.GetTableData(U1(118, 37, 222, 112), U1(96, 53, 218, 105, 14)) ~= nil then
            if not false then
              if U2.IsCharacterItemID(_ARG_0_.crateId) then
              else
              end
            end
          else
          end
        end
        ::lbl_262::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowAdvertisementBtn"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_advertisement_BlueHole):CheckCanGetAdvertisementData() then
        return false
      end
      if not CDataTable.GetTableData(U1(126, 21, 248, 124, 29, 118, 72, 34, 58, 97, 139, 22), (require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 215, 139, 189, 18, 162, 66, 241, 109, 40, 2, 7, 124))).GetMainFormat((Client.GetAppVersion())))) then
        return false
      end
      if _ARG_0_.crateId ~= CDataTable.GetTableData(U1(126, 21, 248, 124, 29, 118, 72, 34, 58, 97, 139, 22), (require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 215, 139, 189, 18, 162, 66, 241, 109, 40, 2, 7, 124))).GetMainFormat((Client.GetAppVersion())))).ID and _ARG_0_.crateId ~= CDataTable.GetTableData(U1(126, 21, 248, 124, 29, 118, 72, 34, 58, 97, 139, 22), (require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 215, 139, 189, 18, 162, 66, 241, 109, 40, 2, 7, 124))).GetMainFormat((Client.GetAppVersion())))).SOLIDER_ID then
        return false
      end
      if _ARG_0_.crateId == CDataTable.GetTableData(U1(126, 21, 248, 124, 29, 118, 72, 34, 58, 97, 139, 22), (require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 215, 139, 189, 18, 162, 66, 241, 109, 40, 2, 7, 124))).GetMainFormat((Client.GetAppVersion())))).ID then
      elseif _ARG_0_.crateId == CDataTable.GetTableData(U1(126, 21, 248, 124, 29, 118, 72, 34, 58, 97, 139, 22), (require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 215, 139, 189, 18, 162, 66, 241, 109, 40, 2, 7, 124))).GetMainFormat((Client.GetAppVersion())))).SOLIDER_ID then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_advertisement_BlueHole):CheckMaxWatchCountByScenceType(require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 170, 73, 233, 87, 47, 2, 7, 99, 138, 10, 206, 142, 197, 208, 158, 53, 132, 80, 238, 65, 63, 9))).ENUM_SCENCE_TYPE.SOLDIERS) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_advertisement_BlueHole):CheckWatchTimeByScenceType(require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 170, 73, 233, 87, 47, 2, 7, 99, 138, 10, 206, 142, 197, 208, 158, 53, 132, 80, 238, 65, 63, 9))).ENUM_SCENCE_TYPE.SOLDIERS) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWatchCountByScenceType"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_advertisement_BlueHole):GetWatchCountByScenceType((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_advertisement_BlueHole):GetScenceType())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayDefautEmotionByDefaultEquipList"] = function(_ARG_0_)
    do
      if not _ARG_0_.pageInfo or not _ARG_0_.pageInfo.defaultEquiped then
        return
      end
      goto lbl_17
      ::lbl_17::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayDefaultEquipedEmotion"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 55, 116, 154, 26, 200), _ARG_1_) then
        _ARG_1_ = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.ItemUpgradeModule):GetMaxLevelItem(_ARG_1_)
        if _ARG_1_ ~= -1 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckEnterExpression"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_.EnterExpressionID > 0 then
        if GlobalData.IsJapanOrKorea() then
        else
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FeatureExecution"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ and not require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 46, 168, 74, 230, 86, 46, 14))).CanAutoDownload() then
        if require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 95, 171, 72, 233, 68, 40, 20),
          U1(96, 60, 218, 115, 14, 101, 72, 52)
        }))).GetState(require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 46, 184, 82, 225, 81, 57))).ENUM_DownloadType.ODPAK, {_ARG_2_}) ~= require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 175, 66, 232, 92, 49, 25, 15, 116, 193, 23, 222, 134, 215, 155, 173, 46, 184, 82, 225, 81, 57))).ENUM_DownloadState.Done then
          return
        end
      end
      goto lbl_483
      if not CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))) or U2.CheckExcludeForCurRegion((CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))))) then
      elseif CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))).FeatureType == ENUM_FeatureType.Video and require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 189, 68, 251, 87, 50, 88, 2, 127, 141, 5, 210, 191, 199, 151, 187, 20, 180, 98, 233, 87, 35, 5),
        U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14)
      }))).IsCanPlayVideo() then
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_store_enter_feature):FeatureAutoplayHasBeenTriggeredToday(CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))).ID) then
        elseif require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 189, 68, 251, 87, 50, 88, 2, 127, 141, 5, 210, 191, 199, 151, 187, 20, 180, 98, 233, 87, 35, 5),
          U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14)
        }))).IsCanVideoFileAndReady(CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))).Video) then
        end
      elseif CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))).FeatureType == ENUM_FeatureType.Emotion and _ARG_0_.bPlayingVideo == false and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_store_enter_feature):CheckEmotionAutoPlay(CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))).DescID, nil and (nil).DescID or 0, (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_store_enter_feature):GetAutoEmotionWeightConfig())) then
      end
      ::lbl_483::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))) then
        if CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))) then
        end
      elseif CDataTable.GetTableData(U1(121, 52, 218, 105, 26, 112, 72, 53, 61, 111, 145, 17, 210, 151), tonumber(U1(75, 56, 212, 115, 48, 110, 68, 36, 12, 97, 141, 14))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OneVideoEndPlayEmotion"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.videoEndPlayEmotionHandle and _ARG_3_ == _ARG_0_.videoEndPlayEmotionHandle.videoPath then
        _ARG_0_.videoEndPlayEmotionHandle.playHandle()
      end
      _ARG_0_.videoEndPlayEmotionHandle = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCustomCrateInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log_tree(table.concat({
        U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 46, 165, 110, 234, 65, 41, 25, 3, 83, 157, 6, 223, 133, 248, 144, 185, 30, 247, 29, 255, 67, 63, 7),
        U1(82, 113, 134, 61)
      }), _ARG_3_)
      if _ARG_3_ ~= nil and _ARG_3_.crateId == _ARG_0_.crateId then
        _ARG_0_.banInfo = _ARG_3_
        _ARG_0_.haveCustomData = true
        if _ARG_0_.bShowing == true and _ARG_0_.bDataReady == true then
          _ARG_0_:FilterItemByCondition()
          _ARG_0_:UpdateUI()
          _ARG_0_:UpdateCustomCrateInfo()
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnJPKRCreditInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:UpdateJPKRCreditInfo()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateJPKRCreditInfo"] = function(_ARG_0_)
    do
      if _ARG_0_.bShowing == true and _ARG_0_.bDataReady == true then
        if require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 124, 128, 0, 194, 131, 238, 141, 170, 1, 171, 81, 246, 125, 61, 20),
          U1(86, 50, 222, 66, 6, 108, 75, 41)
        }))).CanAddCredit() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_credit_manager):GetJPKRCreditInfo().haveData == true then
          if U2.GetCreditConfigByTime() ~= nil then
            goto lbl_115
            if U1(86, 50, 222, 66, 6, 108, 75, 41).state == ActivityProgressStatus.Done then
            else
              if U1(86, 50, 222, 66, 6, 108, 75, 41).state == ActivityProgressStatus.Not and 1 == 0 then
              end
              ::lbl_115::
              _ARG_0_ = _ARG_0_
              _ARG_0_ = _ARG_0_
            end
            if false then
            end
            if require((table.concat({
              U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 170, 78, 235, 91, 43, 31, 26, 105, 193, 11, 196, 135, 216, 157, 128, 16, 184, 73, 230, 84, 36, 18),
              U1(70, 14, 214, 122, 29)
            }))).GetActivityByType(153) and require((table.concat({
              U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 170, 78, 235, 91, 43, 31, 26, 105, 193, 11, 196, 135, 216, 157, 128, 16, 184, 73, 230, 84, 36, 18),
              U1(70, 14, 214, 122, 29)
            }))).GetActivityByType(153).EndTime >= U3.GetServerTimeInSec() then
            end
            if CDataTable.GetTableData(U1(118, 37, 222, 112), U2.GetCreditConfigByTime().List[#U2.GetCreditConfigByTime().List].awardID) ~= nil then
            end
          else
          end
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowIntegralByJKCrate"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_1_ then
        return
      end
      _ARG_1_.WidgetSwitcher_0:SetActiveWidgetIndex(0)
      if _ARG_2_ then
        _ARG_1_:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_1_.ProgressBar_0:SetPercent(_ARG_3_)
        if _ARG_3_ < 1 then
          _ARG_1_.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
          _ARG_1_:StopAnimation(_ARG_1_.chufa)
        elseif _ARG_5_ then
          _ARG_1_:StopAnimation(_ARG_1_.chufa)
          _ARG_1_.WidgetSwitcher_0:SetActiveWidgetIndex(1)
          _ARG_1_.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        else
          _ARG_1_.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
          _ARG_1_:PlayUserWidgetAnimation(_ARG_1_.chufa, 0, 1, 0, 1)
        end
        if _ARG_4_ then
          _ARG_1_.Panel_Act:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
          if require((table.concat({
            U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 170, 78, 235, 91, 43, 31, 26, 105, 193, 11, 196, 135, 216, 157, 128, 16, 184, 73, 230, 84, 36, 18),
            U1(70, 14, 214, 122, 29)
          }))).GetActivityByType(153) and require((table.concat({
            U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 170, 78, 235, 91, 43, 31, 26, 105, 193, 11, 196, 135, 216, 157, 128, 16, 184, 73, 230, 84, 36, 18),
            U1(70, 14, 214, 122, 29)
          }))).GetActivityByType(153).EndTime - U2.GetServerTimeInSec() <= 300 then
          end
        else
          _ARG_1_.Panel_Act:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
      else
        _ARG_1_:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCollectedResult"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBuyInfoChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpJKUrl"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickFullScreen"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_:GetFrame() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInventoryChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.itemDataList ~= nil then
        goto lbl_26
        if (nil).have == false then
          if (nil).limitFlag then
            ;(nil).have = false
          else
            ;(nil).have = U1:CheckHaveForSupply((nil).itemId)
            if (nil).have == true then
            end
          end
        end
        ::lbl_26::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBuySucceeded"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 46, 165, 111, 234, 75, 14, 3, 13, 115, 138, 2, 207, 133, 213, 210, 255, 2, 179, 82, 255, 107, 41, 70),
        U1(2, 113)
      }) .. tostring(_ARG_3_) .. U1(19, 113, 210, 115, 9, 109, 13, 123, 94) .. tostring(_ARG_4_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshAllPrice"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 51, 174, 75, 237, 87, 46, 30, 47, 124, 131, 55, 217, 137, 210, 155))
      _ARG_0_:UpdateBuyOneBtnInfo()
      _ARG_0_:UpdateBuyTenBtnInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBuyAgain"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 46, 165, 111, 234, 75, 28, 17, 15, 121, 129, 75, 139, 144, 208, 140, 190, 28, 251, 0, 175) .. tostring(_ARG_3_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBackgroundByURL"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if _ARG_2_ ~= U1() then
        if require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 40, 206, 153, 254, 136, 189, 0, 166, 72, 232, 93, 47, 29, 64, 101, 155, 14, 199))).IsOnlineImageUrl(_ARG_2_) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBuyOneBtnInfo"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshOneButtonContent()
      EventSystem:postEvent(EVENTTYPE_STORE_DATA, EVENTID_CRATE_UPDATE_VOUCHER_NUM)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefAGBuyBtnHandle"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsKorJpNeedJumpBox"] = function(_ARG_0_)
    do
      if GlobalData.IsJapanOrKorea() then
        if _ARG_0_:GetFrame():GetParentTabID(_ARG_0_.tabId) == 102 and not next(require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 124, 128, 0, 194, 131, 238, 141, 170, 1, 171, 81, 246, 125, 61, 20),
          U1(86, 50, 222, 66, 6, 108, 75, 41)
        }))).GetTenPrice()) and not next(require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 184, 88, 239, 66, 49, 15, 64, 124, 128, 0, 194, 131, 238, 141, 170, 1, 171, 81, 246, 125, 61, 20),
          U1(86, 50, 222, 66, 6, 108, 75, 41)
        }))).GetOnePrice()) and next(_ARG_0_.rawData[StoreConst.label_shop_index_exchange_list] or {}) then
          return true
        end
        return false
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetExchangeButtonName"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.UTRichTextBlock_8:SetText((_ENV()))
      if not _ARG_0_:IsKorJpNeedJumpBox() then
        return
      end
      goto lbl_42
      if U1.CDataTable.GetTableData(_ENV(118, 37, 222, 112), nil) then
        goto lbl_44
        ::lbl_42::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_44::
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateJKDifference"] = function(_ARG_0_)
    do
      _ARG_0_:SetExchangeButtonName()
      _ARG_0_:ShowExtraJPRateBtn(nil, nil, false)
      if _ARG_0_.pageInfo.limited_special_info then
        _ARG_0_.UIRoot.Lobby_DirectPurchase_LimitedTimeGiftSet_Item_2:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_.UIRoot.Lobby_DirectPurchase_LimitedTimeGiftSet_Item_2.UTRichTextBlock_0:SetText(LocUtil.GetLocalizeResStr(512296))
      else
        _ARG_0_.UIRoot.Lobby_DirectPurchase_LimitedTimeGiftSet_Item_2:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateBuyTenBtnInfo"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshTenButtonContent()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickShowCrateExchangeUI"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U1.ShowCrateCreditExchangeUI()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDisBtn"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCrateActivity"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateCrateActivityComponent(false)
      _ARG_0_:UpdateCustomCrateInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCrateActivityComponent"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.bShowing ~= true or _ARG_0_.bDataReady ~= true then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowOrHideCrateActivityUI"] = function(_ARG_0_, _ARG_1_)
    do
      if GlobalData.IsJapanOrKorea() then
        if _ARG_1_ then
        else
        end
      elseif _ARG_1_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanCustomBanByDisplayMode"] = function(_ARG_0_)
    do
      if GlobalData.IsJapanOrKorea() then
        if _ARG_0_.displayMode == StoreConst.label_show_mode_two then
          return true
        else
          return false
        end
      elseif _ARG_0_.displayMode == StoreConst.label_show_mode_one then
        return true
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NeedShowCustomInfo"] = function(_ARG_0_)
    do
      if _ARG_0_:CanCustomBanByDisplayMode() and CanCustomBanByConfig(_ARG_0_.crateId, _ARG_0_.limitRegion) then
      end
      if _ARG_0_:GetFrame() ~= nil and _ARG_0_:GetFrame().RefreshNeedShowCustom ~= nil then
      end
      _ARG_0_.needShowCustomWithBan, _ARG_0_.haveCustomData = true, false
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCustomCrateInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 52, 187, 73, 254, 70, 56, 53, 27, 99, 155, 8, 198, 163, 195, 159, 171, 20, 146, 83, 233, 77, 97, 70),
        U1(76, 52, 215, 123, 65, 108, 72, 35, 26, 83, 151, 24, 204, 179, 212, 157, 187, 14, 166, 13, 162, 18)
      }) .. tostring(_ARG_0_.needShowCustomWithBan))
      if _ARG_0_.needShowCustomWithBan and #ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):GetActInfoBySupplyID(_ARG_0_.pageInfo.shopId, _ARG_0_.pageInfo.itemId) == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RevertItemExternal"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and 0 < _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 51, 174, 91, 250, 64, 41, 63, 26, 117, 130, 34, 211, 148, 212, 140, 177, 16, 183, 17, 175, 75, 57, 3),
          U1(82, 24, 255, 61, 82, 34)
        }) .. tostring(_ARG_1_))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoopEmotion"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 45, 164, 66, 239, 119, 48, 25, 26, 121, 128, 9))
      if _ARG_1_.ExpressionID and _ARG_1_.ExpressionID > 0 then
        if GlobalData.IsJapanOrKorea() and 0 < _ARG_1_.FightExpressionID then
        else
        end
        if _ARG_1_.ExpressionID == 12219068 or _ARG_1_.ExpressionID == 12219090 or _ARG_1_.ExpressionID == 12219029 then
        else
        end
        if _ARG_1_.ExpressionCD and 0 < _ARG_1_.ExpressionCD then
          _ARG_0_.timerEquipedAction = _ARG_0_:AddTimerOnce(_ARG_1_.ExpressionCD, function()
            _ENV:LoopEmotion(U1)
            return
          end)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChooseTheFirstOrSpecifiedOne"] = function(_ARG_0_)
    do
      if _ARG_0_.bShowing == true and _ARG_0_.bDataReady == true then
        if next(_ARG_0_.pageInfo.defaultEquiped) == nil then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFrame"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.store_supply_switcher):GetSupplySystem(), StoreConst.supply_tab end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUIRoot"] = function(_ARG_0_)
    do
      do return _ARG_0_.UIRoot end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideRightView"] = function(_ARG_0_)
    do
      _ARG_0_:PutOffAircast()
      _ARG_0_.UIRoot.Border_MainList:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.CanvasPanel_2:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_:ShowTitleReturnBtn()
      _ARG_0_:HideFameStyle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRightView"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Border_MainList:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_.UIRoot.CanvasPanel_2:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_.extraBoxSelectItemID = nil
      if _ARG_0_.currentItemIndex > 0 then
        _ARG_0_:OnClickItem(nil, _ARG_0_.currentItemIndex, true)
      else
        _ARG_0_:UpdateAvatar()
        _ARG_0_:ChooseTheFirstOrSpecifiedOne()
      end
      _ARG_0_:UpdateItemEquippedState(_ARG_0_.showDataList)
      _ARG_0_:RefreshItemList()
      _ARG_0_:RefreshTopTitle()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecoverRightView"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Border_MainList:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_.UIRoot.CanvasPanel_2:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PutOffAircast"] = function(_ARG_0_)
    do
      if _ARG_0_.currentItemIndex == nil or _ARG_0_.currentItemIndex == 0 then
        return
      end
      if _ARG_0_:GetItemDataByIndex(_ARG_0_.currentItemIndex) == nil then
        return
      end
      if not require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 188, 76, 237, 86, 47, 25, 12, 117, 193, 16, 202, 146, 213, 140, 176, 19, 190, 98, 235, 67, 57, 7))).IsAirCastType(_ARG_0_:GetItemDataByIndex(_ARG_0_.currentItemIndex).subType) then
        return
      end
      if U2.IsEquippedByItemId(_ARG_0_:GetItemDataByIndex(_ARG_0_.currentItemIndex).itemId) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItemExternal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:StopDefaultEquipedAction()
      if IsEquippedByItemId(_ARG_3_) and _ARG_4_ ~= true then
      else
      end
      _ARG_0_.extraBoxSelectItemID = _ARG_3_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearItemPreview"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateOptionalChestInfo"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CP_Box_Entrance:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if _ARG_0_.pageInfo and _ARG_0_.pageInfo.optionalCnt and _ARG_0_.pageInfo.optionalCnt > 0 and _ARG_0_.pageInfo.buyCnt then
        _ARG_0_.UIRoot.CP_Box_Entrance:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_.UIRoot.Box_Entrance_UIBP.Text_OpenTip:SetText(LocUtil.LocalizeResFormat(8464))
        if _ARG_0_.pageInfo.buyCnt >= _ARG_0_.pageInfo.optionalCnt then
          _ARG_0_.UIRoot.Box_Entrance_UIBP.WidgetSwitcher_0:SetActiveWidgetIndex(1)
        else
          _ARG_0_.UIRoot.Box_Entrance_UIBP.WidgetSwitcher_0:SetActiveWidgetIndex(0)
          _ARG_0_.UIRoot.Box_Entrance_UIBP.Text_OpenNum:SetText(LocUtil.LocalizeResFormat(10280, _ARG_0_.pageInfo.buyCnt, _ARG_0_.pageInfo.optionalCnt))
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickOptionalBox"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.pageInfo and _ARG_0_.pageInfo.optionalCnt and _ARG_0_.pageInfo.optionalCnt > 0 and _ARG_0_.pageInfo.buyCnt and _ARG_0_.pageInfo.buyCnt >= _ARG_0_.pageInfo.optionalCnt then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateOptionalChest"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_.pageInfo.buyCnt = _ARG_4_
      _ARG_0_:UpdateOptionalChestInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCrateCollectedUI"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Store_Remind_Btn, false)
      if not LobbySystem.CheckOpen(BP_ENUM_CRATE_COLLECT_SWITCH) then
        return
      end
      if ((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_collect_chest_manager):GetShopTabInfoByShopId(_ARG_0_.pageInfo.shopId) or {}).end_time or 0) == 0 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_collect_chest_manager):IsNewArrivalsCollect() then
        _ARG_0_.collectTimer = _ARG_0_:AddTimerOnce(5, function()
          _ENV:SetWidgetVisible(UIRoot.Store_Remind_Btn.CanvasPanel_4, false)
          _ENV:RemoveCollectTimer()
          U1:RecordNewArrivalsCollect()
          return
        end)
      end
      _ARG_0_.bIsArrivalCollect = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_collect_chest_manager):IsNewArrivalsCollect()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveCollectTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.collectTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.collectTimer)
        _ARG_0_.collectTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCollectBtn"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 212, 135, 144, 20, 191, 68, 243))).CanClickNow(require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 212, 135, 144, 20, 191, 68, 243))).ClickFrequencyLimit.CrateCollectionBtn) == false then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_collect_chest_manager):GetCrateCollectedState(_ARG_0_.pageInfo.shopId) == StoreConst.crate_collect_state_true then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCollectedCrateChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log_tree(table.concat({
        U1(100, 50, 211, 104, 13, 95, 126, 50, 17, 114, 154, 36, 194, 131, 213, 139, 162, 79, 167, 66, 248, 109, 18, 24, 45, 127, 131, 11, 206, 131, 197, 155, 187, 50, 169, 92, 251, 71, 14, 14),
        U1(94, 63, 220, 120, 67, 34, 73, 39, 10, 97, 223, 74, 155)
      }), _ARG_3_)
      log(bWriteLog and U1(100, 50, 211, 104, 13, 95, 65, 41, 25, 95, 140, 18, 215, 150, 143, 158, 174, 6, 174, 100, 241, 84, 50, 88, 29, 120, 128, 23, 226, 132, 145, 195, 255) .. _ARG_0_.pageInfo.shopId)
      if _ARG_3_.nShopId ~= _ARG_0_.pageInfo.shopId then
        log(bWriteLog and table.concat({
          U1(100, 50, 211, 104, 13, 95, 65, 41, 25, 95, 155, 22, 207, 145, 143, 128, 156, 9, 164, 93, 214, 86, 125, 8, 83, 48, 156, 2, 199, 134, 159, 142, 190, 22, 190, 116, 225, 68, 34, 72),
          U1(76, 57, 212, 109, 38, 102)
        }))
        return
      end
      _ARG_0_.UIRoot.Store_Remind_Btn.WidgetSwitcher_0:SetActiveWidgetIndex(_ARG_3_.nNowState == StoreConst.crate_collect_state_true and 0 or 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateByActivity"] = function(_ARG_0_)
    do
      printf(table.concat({
        U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 158, 93, 251, 83, 41, 19, 44, 105, 174, 4, 223, 137, 199, 151, 171, 8, 251, 79, 234, 68, 63, 3),
        U1(76, 57, 155, 109, 29, 107, 78, 35, 82, 32, 140, 31, 212, 128, 232, 138, 245, 68, 184)
      }), tostring(_ARG_0_.pageInfo and _ARG_0_.pageInfo.shopId))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Close"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 34, 167, 66, 236, 87))
      _ARG_0_.bShowing = false
      _ARG_0_:ClearGoodLuckEntry()
      _ARG_0_.currentItemIndex = 0
      if _ARG_0_.leftTimeTimer ~= nil then
        _ARG_0_.leftTimeTimer = nil
      end
      if _ARG_0_.secondUpTimeTimer ~= nil then
        _ARG_0_.secondUpTimeTimer = nil
      end
      if _ARG_0_.ResultPanelActTimer then
        _ARG_0_.ResultPanelActTimer = nil
      end
      if _ARG_0_.DailyDiscountTimer ~= nil then
        _ARG_0_.DailyDiscountTimer = nil
      end
      if _ARG_0_.DailyTenDiscountTimer ~= nil then
        _ARG_0_.DailyTenDiscountTimer = nil
      end
      _ARG_0_.banInfo = nil
      _ARG_0_.rawData = nil
      _ARG_0_.pageInfo = nil
      _ARG_0_.itemDataList = nil
      _ARG_0_.showDataList = nil
      _ARG_0_.currentItem = nil
      _ARG_0_.param = nil
      _ARG_0_.bIsArrivalCollect = nil
      _ARG_0_.curOneButtonBGPath = nil
      _ARG_0_.curTenButtonBGPath = nil
      _ARG_0_.graduallyTip = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(124, 35, 218, 105, 10, 69, 72, 40, 27, 114, 158, 27, 235, 145, 198, 139, 245, 46, 165, 101, 246, 86, 56))
      _ARG_0_.bShowing = false
      _ARG_0_:ClearGoodLuckEntry()
      if _ARG_0_.leftTimeTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.leftTimeTimer)
        _ARG_0_.leftTimeTimer = nil
      end
      if _ARG_0_.secondUpTimeTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.secondUpTimeTimer)
        _ARG_0_.secondUpTimeTimer = nil
      end
      if _ARG_0_.DailyDiscountTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.DailyDiscountTimer)
        _ARG_0_.DailyDiscountTimer = nil
      end
      if _ARG_0_.DailyTenDiscountTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.DailyTenDiscountTimer)
        _ARG_0_.DailyTenDiscountTimer = nil
      end
      U2.__super.OnHide(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCouponIcon"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Store_Discount_Btn_UIBP:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if GlobalData.IsJapanOrKorea() then
        return
      end
      if U1.GetSupplyCouponScene(_ARG_0_.tabId) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCouponRedDot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ then
        if _ARG_2_ then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitGraduallyTipWidget"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):IsGraduallyActShow(_ARG_0_.tabId, _ARG_0_.currentItem) then
        return
      end
      _ARG_0_.graduallyTip = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.gradually_act_tip_widget, _ARG_0_.UIRoot.Crate_Reward_Tips_UIBP, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):IsGraduallyActShow(_ARG_0_.tabId, _ARG_0_.currentItem))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitPopTitleContent"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Text_Title:SetText(LocUtil.LocalizeResFormat(7209))
      _ARG_0_:SetSupplyLeftTime()
      _ARG_0_:SetFameStyle()
      _ARG_0_:RefreshTopTitle()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTopTitle"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_Title:SetActiveWidgetIndex(_ARG_0_.modeOneSwitchIndex)
      _ARG_0_.UIRoot.Title_Info:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_JK_Detail, false)
      if _ARG_0_.displayMode == StoreConst.label_show_mode_one then
        _ARG_0_.UIRoot.WidgetSwitcher_Title:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      else
        _ARG_0_.UIRoot.WidgetSwitcher_Title:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowTitleReturnBtn"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_Title:SetActiveWidgetIndex(1)
      _ARG_0_.UIRoot.Title_Info:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.WidgetSwitcher_Title:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickProbabilityDetail"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 132, 67, 220, 94, 52, 21, 5, 64, 157, 8, 201, 129, 211, 151, 179, 24, 175, 68, 203, 71, 57, 7),
        U1(86, 61)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if GlobalData.IsJapanOrKorea() then
        if not _ARG_0_.bShowing then
          return
        end
        if _ARG_0_.pageInfo.is_have_drop and _ARG_0_.pageInfo.is_have_drop == 1 then
        else
        end
      else
        if _ARG_0_:GetFrame():GetCurrentTabData() then
        end
        goto lbl_276
        ::lbl_276::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickExtraRate"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if GlobalData.IsJapanOrKorea() then
        EventSystem:postEvent(EVENTTYPE_SHOP, EVENTID_STORE_CHEST_SHOW_RATE)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowExtraJPRateBtn"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and table.concat({
        U1(100, 2, 226, 64, 60, 119, 93, 54, 18, 121, 184, 18, 213, 149, 211, 143, 163, 49, 170, 74, 250, 8, 14, 30, 1, 103, 170, 31, 223, 146, 208, 180, 143, 35, 186, 73, 234, 96, 57, 8),
        U1(17)
      }) .. tostring(_ARG_3_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFameStyle"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetFrame() then
        return
      end
      _ARG_0_.frameStyle = _ARG_0_:GetFrame():GetFrameStyleByTabID(_ARG_0_.tabId)
      if _ARG_0_.frameStyle == 0 or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.store_supply_manager):GetSupplyFrameStylePath(_ARG_0_.frameStyle) == U1() then
        if U2.IsVanguardSupplyForGlobal(_ARG_0_.pageInfo.shopId) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideFameStyle"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CanvasPanel_FameStyle:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Image_bg:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Image_HomePage:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Image_JianBin:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Image_Frame:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.Image_Basic:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSwitchDisplay"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.modeOneSwitchIndex == 0 then
        _ARG_0_.modeOneSwitchIndex = 1
        _ARG_0_:SwitchSupplyDropInfoLogReport(1)
      else
        _ARG_0_.modeOneSwitchIndex = 0
        _ARG_0_:SwitchSupplyDropInfoLogReport(0)
      end
      DataMgr.SetNewbieGuide(DataMgr.NEWBIE_GUIDE_MODULE_ID_ACTIVITY_SHOP, 1)
      _ARG_0_:UpdateUI()
      log(bWriteLog and string.format(table.concat({
        U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 132, 67, 220, 94, 52, 21, 5, 67, 152, 14, 223, 131, 217, 186, 182, 2, 171, 81, 238, 91, 97, 70),
        U1(94, 55, 207, 120, 29, 34, 94, 49, 23, 116, 156, 31, 155, 153, 207, 138, 170, 25, 235, 16, 191, 23, 46)
      }), _ARG_0_.modeOneSwitchIndex))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTitleReturn"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):GetTitleReturnMark() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSupplyLeftTime"] = function(_ARG_0_)
    do
      if _ARG_0_.leftTimeTimer ~= nil then
        _ARG_0_:RemoveTimer(_ARG_0_.leftTimeTimer)
        _ARG_0_.leftTimeTimer = nil
      end
      if _ARG_0_.pageInfo == nil or _ARG_0_.pageInfo.detailEndTime == 0 then
        log(bWriteLog and table.concat({
          U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 152, 72, 235, 97, 40, 6, 30, 124, 150, 43, 206, 134, 197, 170, 182, 28, 190, 29, 235, 71, 57, 7),
          U1(86, 61, 254, 115, 11, 86, 68, 43, 27, 32, 194, 74, 155, 192)
        }))
        _ARG_0_.UIRoot.Title_Limit:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      if _ARG_0_.pageInfo.detailEndTime - U2.GetServerTimeInSec() <= 86400 then
        _ARG_0_.leftTimeTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV:OnRefreshLeftTime()
          return
        end, TIMER_INFINITE, 1)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshLeftTime"] = function(_ARG_0_)
    do
      if _ARG_0_.bShowing == true and _ARG_0_.bDataReady == true then
        if _ARG_0_.pageInfo.detailEndTime - GetServerTimeInSec() < 0 then
          if _ARG_0_.leftTimeTimer ~= nil then
            _ARG_0_.leftTimeTimer = nil
          end
          if _ARG_0_:GetFrame() and _ARG_0_:GetFrame():GetTabPanel() then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRPTips"] = function(_ARG_0_)
    do
      if _ARG_0_.pageInfo.score ~= 0 then
        _ARG_0_.UIRoot.TextBlock_RP_Tips:SetText(LocUtil.LocalizeResFormat(6492, _ARG_0_.pageInfo.score))
        _ARG_0_.UIRoot.TextBlock_RP_Tips:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      elseif 0 < _ARG_0_.pageInfo.leftTimesForLegendary then
        _ARG_0_.UIRoot.TextBlock_RP_Tips:SetText(LocUtil.LocalizeResFormat(6492, _ARG_0_.pageInfo.score))
        _ARG_0_.UIRoot.TextBlock_RP_Tips:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      else
        _ARG_0_.UIRoot.TextBlock_RP_Tips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConservationRewardsShow"] = function(_ARG_0_)
    do
      if not GlobalData.IsJapanOrKorea() then
        return
      end
      if _ARG_0_.pageInfo.guaranteeItemId == 0 then
        _ARG_0_.UIRoot.Store_PROT_Reward_UIBP:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      _ARG_0_.UIRoot.Store_PROT_Reward_UIBP:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickConservationRewards"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U1.ShowGuaranteeAwardInfo(_ARG_0_.pageInfo.guaranteeItemId)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickJumpVehicleSp"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if CDataTable.GetTableData(U1(117, 36, 214, 109, 42, 122, 78, 46, 31, 110, 152, 18, 238, 130, 205, 173, 160, 15, 173, 68, 248), require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).GetUIConfig(require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
        U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
      }))).defaultShowingUIKey).KJExchangeItemID) then
        if require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
          U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
        }))).IsOpen((tonumber(string.match(CDataTable.GetTableData(U1(117, 36, 214, 109, 42, 122, 78, 46, 31, 110, 152, 18, 238, 130, 205, 173, 160, 15, 173, 68, 248), require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
          U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
        }))).GetUIConfig(require((table.concat({
          U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 66, 253, 80, 36, 41, 15, 115, 155, 14, 221, 137, 197, 135, 241, 29, 180, 90, 230, 65, 18, 10),
          U1(94, 53, 223, 120, 29, 93, 73, 52, 31, 119)
        }))).defaultShowingUIKey).KJExchangeItemID).JumpExchangeUrl, (U1(94, 50, 207, 116, 25, 107, 89, 63, 23, 100, 194, 95, 158, 148, 138, 199)))))) then
          if _ARG_0_.itemId then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayAnimationStart"] = function(_ARG_0_)
    do
      _ARG_0_.bIsInPlayAnimation = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPlayAnimationEnd"] = function(_ARG_0_)
    do
      _ARG_0_.bIsInPlayAnimation = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateExchangeShow"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 158, 93, 251, 83, 41, 19, 43, 104, 140, 15, 202, 142, 214, 155, 140, 25, 180, 74))
      if not _ARG_0_.UIRoot.Crate_Exchange_Item_UIBP then
        log(bWriteLog and table.concat({
          U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 158, 93, 251, 83, 41, 19, 43, 104, 140, 15, 202, 142, 214, 155, 140, 25, 180, 74, 163, 2, 35, 9),
          U1(75, 113, 200, 120, 3, 100, 3, 19, 55, 82, 144, 24, 207, 222, 226, 156, 174, 21, 174, 114, 218, 74, 62, 30, 15, 126, 136, 2, 244, 169, 197, 155, 178, 46, 142, 116, 205, 114, 99, 70)
        }))
        return
      end
      if not _ARG_0_.exchangeID then
        return
      end
      if _ARG_0_.currentItem and next(_ARG_0_.currentItem) then
        return
      end
      if require((U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 188, 76, 237, 86, 47, 25, 12, 117, 193, 16, 202, 146, 213, 140, 176, 19, 190, 98, 235, 67, 57, 7))):GetHallDepotItemDataByResIDAndValidExpireTime(_ARG_0_.exchangeID) ~= nil then
      end
      if require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 212, 135, 144, 20, 191, 68, 243))).GetItemSmallIcon(_ARG_0_.exchangeID) and require((U1(92, 61, 210, 120, 1, 118, 3, 37, 17, 109, 146, 24, 213, 222, 212, 135, 144, 20, 191, 68, 243))).GetItemSmallIcon(_ARG_0_.exchangeID) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickExchange"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U1.JumpToCommonExchangeStore(_ARG_0_.exchangeID)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowWishTip"] = function(_ARG_0_)
    do
      if not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):GetWishInfo())) or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):GetWishInfo().item_id then
        return
      end
      if CDataTable.GetTableData(U1(118, 37, 222, 112), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.supply_activity_manager):GetWishInfo().item_id) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCloseWishTip"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_.UIRoot.Panel_Root:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItemByWish"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if _ARG_0_:CheckIfSelectBox(_ARG_5_) then
        log(bWriteLog and table.concat({
          U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 132, 67, 220, 94, 52, 21, 5, 89, 155, 2, 198, 162, 200, 169, 182, 2, 179, 17, 175, 97, 37, 3),
          U1(92, 58, 242, 123, 60, 103, 65, 35, 29, 116, 189, 24, 195)
        }))
      end
      _ARG_0_:StopDefaultEquipedAction()
      _ARG_0_:PlaySelectAnimation(_ARG_4_, _ARG_5_)
      _ARG_0_:PutOnOrOffSupplyClothes(_ARG_5_, _ARG_6_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWishInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      log(bWriteLog and U1(100, 61, 209, 106, 50, 34, 72, 52, 12) .. tostring(_ARG_3_))
      if _ARG_3_ == 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickReviseWish"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateWishLevel"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 158, 93, 251, 83, 41, 19, 57, 121, 156, 15, 231, 133, 199, 155, 179), _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckWishItemGet"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log_tree(U1(100, 61, 209, 106, 50, 34, 76, 52, 12, 121, 187, 22, 207, 145), _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateItem"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshItemList()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TreasureBoxPageDiffHandle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ and _ARG_2_.JP == 1 then
        if _ARG_1_ == 1512761 then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[244]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowAirDropIcon"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(108, 57, 212, 106, 46, 107, 95, 2, 12, 111, 143, 62, 216, 159, 207, 206))
      if require((table.concat({
        U1(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 215, 159, 198, 135, 172, 79, 167, 88, 252, 89, 2, 23, 7, 98, 139, 21, 196, 144, 159, 146, 176, 22, 178, 94, 208, 78, 56, 5),
        U1(84, 14, 218, 116, 29, 93, 73, 52, 17, 112)
      }))).CheckHasAirDropByScene(2) then
        if not _ARG_0_.AirdropTicker then
          _ARG_0_.AirdropTicker = _ARG_0_:AddTimerLoop(0.0, function()
            if target_airdrop_data[2] then
              if target_airdrop_data[2].end_time - U1.GetServerTimeInSec() > 0 then
              else
              end
              if target_airdrop_data[2].end_time - U1.GetServerTimeInSec() <= 0 then
                U2.AirdropTicker = nil
              end
            end
            return
          end, TIMER_INFINITE, 0.2)
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[78]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickAirDropIcon"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.SmallKT_UIBP, 2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideAirDropIcon"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(108, 36, 203, 109, 3, 123, 106, 35, 16, 101, 141, 22, 215, 160, 192, 137, 170, 91, 131, 68, 251, 87, 28, 31, 28, 84, 157, 8, 219, 169, 210, 145, 177))
      _ARG_0_.UIRoot.Common_SmallKT_Entrance_Item_UIBP:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if _ARG_0_.AirdropTicker then
        _ARG_0_:RemoveTimer(_ARG_0_.AirdropTicker)
        _ARG_0_.AirdropTicker = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurrentItemInfo"] = function(_ARG_0_)
    do
      do return _ARG_0_.currentItem end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetExtraBoxSelectItemID"] = function(_ARG_0_)
    do
      do return _ARG_0_.extraBoxSelectItemID end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PutOnOrOffSupplyClothes"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetFrame() or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.StoreDetailManager):GetShowVehicleIDByCaretID(_ARG_1_ and (_ARG_1_.itemId or _ARG_1_.DropItemID)) then
        return
      end
      if _ARG_1_.selected == false or _ARG_1_.equiped == false or _ARG_2_ then
        _ARG_0_.itemId = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.StoreDetailManager):GetShowVehicleIDByCaretID(_ARG_1_ and (_ARG_1_.itemId or _ARG_1_.DropItemID)), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.StoreDetailManager), _ARG_0_:GetFrame():PutOnClothes((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.StoreDetailManager):GetShowVehicleIDByCaretID(_ARG_1_ and (_ARG_1_.itemId or _ARG_1_.DropItemID))))
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateItemSelectEquippedState"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_4_ and next(_ARG_4_) then
        goto lbl_32
        goto lbl_30
        if ((nil).itemId or (nil).DropItemID) == nil then
          ;(nil).equiped = U1.IsEquippedByItemId(nil)
        else
          ::lbl_30::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        ::lbl_32::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        return
      end
      goto lbl_63
      if nil == _ARG_2_ then
        ;(nil).selected = true
        ;(nil).equiped = U1.IsEquippedByItemId((nil).itemId or (nil).DropItemID)
      else
        ;(nil).selected = false
        if ((nil).itemId or (nil).DropItemID) == _ARG_3_ then
          ;(nil).equiped = false
        else
          ;(nil).equiped = (nil).equiped and U1.IsEquippedByItemId((nil).itemId or (nil).DropItemID)
        end
      end
      ::lbl_63::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateItemEquippedState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      goto lbl_16
      ;(nil).equiped = U1.IsEquippedByItemId((nil).itemId or (nil).DropItemID)
      ::lbl_16::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateEquipedStateAndReferesh"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_.showDataList or not next(_ARG_0_.showDataList) then
        return
      end
      if _ARG_4_ and _ARG_4_.bWear ~= false then
        return
      end
      goto lbl_32
      if (nil).itemId == _ARG_3_ then
        ;(nil).equiped = U1.IsEquippedByItemId((nil).itemId)
      else
        ::lbl_32::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
}, {
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 174, 212, 137, 140, 5, 180, 79, 234, 111, 34, 16),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(90, 127, 216, 114, 2, 114, 66, 40, 27, 110, 139, 89, 239, 175, 226, 129, 162, 12, 164, 67, 192, 118, 56, 2, 15, 121, 131, 56, 236, 143, 222, 154, 172, 46, 146, 83, 230, 86)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 180, 195, 159, 182, 5, 168, 19, 220, 87, 61, 22),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(83, 40, 149, 127, 26, 123, 3, 18, 45, 117, 143, 7, 215, 137, 227, 155, 182, 46, 165, 72)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 180, 195, 159, 182, 5, 168, 19, 220, 87, 61, 22),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(83, 40, 149, 127, 26, 123, 3, 18, 45, 117, 143, 7, 215, 137, 227, 155, 182, 53, 174, 67)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 176, 208, 153, 186, 2, 245, 105, 253, 67, 36, 18),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(76, 127, 239, 78, 27, 109, 95, 35, 46, 97, 152, 18, 232, 132, 192, 154, 170)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 176, 208, 153, 186, 2, 245, 105, 253, 67, 36, 18),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(76, 127, 232, 104, 31, 114, 65, 63, 80, 84, 172, 2, 203, 128, 205, 151, 159, 0, 172, 72, 214, 70, 56, 27, 34, 121, 156, 19)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 176, 208, 153, 186, 2, 245, 105, 253, 67, 36, 18),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(76, 127, 232, 104, 31, 114, 65, 63, 80, 84, 172, 2, 203, 128, 205, 151, 159, 0, 172, 72, 219, 83, 41, 23)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 176, 208, 153, 186, 2, 245, 105, 253, 67, 36, 18),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(76, 127, 232, 104, 31, 114, 65, 63, 80, 84, 172, 2, 203, 128, 205, 151, 159, 0, 172, 72, 214, 70, 56, 27, 58, 92, 128, 0)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 207, 130, 192, 135, 187, 18, 229, 105, 250, 70, 60, 31, 2, 83, 128, 10, 219, 143, 223, 155, 177, 5, 245, 121, 234, 86, 44, 15),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(83, 5, 201, 124, 6, 118, 94, 104, 58, 101, 139, 22, 210, 156, 229, 129, 184, 15, 167, 66, 254, 86)
  }))),
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(92, 61, 210, 120, 1, 118, 3, 53, 18, 117, 158, 89, 206, 157, 198, 192, 129, 4, 188, 126, 235, 93, 47, 19, 56, 34, 215, 87, 133, 163, 222, 147, 175, 30, 181, 88, 225, 86, 62, 72),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(108, 37, 212, 111, 10, 81, 88, 54, 14, 108, 134, 51, 212, 135, 207, 130, 160, 0, 175, 110, 240, 95, 45, 25, 0, 117, 129, 19)
  })))
})) end
return
