local Operation_CustomJoystick = {}
local Trait = require("common.trait")
local GameplayData = require("GameLua.GameCore.Data.GameplayData")
local EPawnState = import("EPawnState")
local SprintForwardSinThreshold = 0.5
local TOperation_CustomJoystick = Trait(Trait.TraitPrototype, nil, Operation_CustomJoystick)

function Operation_CustomJoystick:RegistCustomJoystick(JoystickWidget)
  if not slua.isValid(JoystickWidget) then
    log_warning("Operation_CustomJoystick:RegistCustomJoystick JoystickWidget invalid")
    return
  end
  self.CustomJoystick = JoystickWidget
  self.bCustomJoystickTouching = false
  self:AddControlEventByControl(JoystickWidget, "OnCircleMoveTouchStart", self._HandleCircleMoveTouchStart, self)
  self:AddControlEventByControl(JoystickWidget, "OnCircleMoveInput", self._HandleCircleMoveInput, self)
  self:AddControlEventByControl(JoystickWidget, "OnCircleMoveTouchEnd", self._HandleCircleMoveTouchEnd, self)
  self:AddControlEventByControl(JoystickWidget, "OnCircleMoveSprint", self._HandleCircleMoveSprint, self)
end

function Operation_CustomJoystick:StopCustomJoystick(bForceReleaseCapture)
  self:ClearVehicleMoveInput()
  if not slua.isValid(self.CustomJoystick) then
    return
  end
  if bForceReleaseCapture == nil then
    bForceReleaseCapture = true
  end
  self.bCustomJoystickTouching = false
  log(bWriteLog and "Operation_CustomJoystick:StopCustomJoystick - bForceReleaseCapture = " .. tostring(bForceReleaseCapture))
  self.CustomJoystick:EndTouchEvent(bForceReleaseCapture)
end

function Operation_CustomJoystick:IsCustomJoystickDragging()
  if not slua.isValid(self.CustomJoystick) then
    return false
  end
  if self.CustomJoystick.IsCircleMoveDragging then
    return self.CustomJoystick:IsCircleMoveDragging()
  end
  return self.bCustomJoystickTouching == true
end

function Operation_CustomJoystick:_HandleCircleMoveTouchStart()
  log(bWriteLog and "Operation_CustomJoystick:_HandleCircleMoveTouchStart")
  self.bCustomJoystickTouching = true
  if self.OnCustomJoystickTouchStart then
    self:OnCustomJoystickTouchStart()
  end
end

function Operation_CustomJoystick:_HandleCircleMoveInput(input)
  log(bWriteLog and "Operation_CustomJoystick:_HandleCircleMoveInput - input = " .. tostring(input))
  if not input then
    return
  end
  if (input.X ~= 0 or input.Y ~= 0) and self.OnCustomJoystickActive then
    self:OnCustomJoystickActive()
  end
  self.CustomJoystickLastInput = input
  self:_RefreshSprint()
  local pc = GameplayData.GetPlayerController()
  local bVehicleHandled = false
  if slua.isValid(pc) then
    local VehicleUserComponent = pc:GetVehicleUserComp()
    if slua.isValid(VehicleUserComponent) and VehicleUserComponent.GetVehicleUserState then
      local ESTExtraVehicleUserState = import("ESTExtraVehicleUserState")
      if VehicleUserComponent:GetVehicleUserState() == ESTExtraVehicleUserState.EVUS_AsDriver and VehicleUserComponent.AxisMoveForwardFreezed then
        VehicleUserComponent:MoveVehicleForward(-input.Y)
        VehicleUserComponent:MoveVehicleRight(input.X)
        bVehicleHandled = true
      end
    end
  end
  if not bVehicleHandled then
    local UCircleMoveUserWidget = import("CircleMoveUserWidget")
    if UCircleMoveUserWidget and UCircleMoveUserWidget.InjectLeftStickAxis then
      UCircleMoveUserWidget.InjectLeftStickAxis(input)
    end
  end
end

function Operation_CustomJoystick:_HandleCircleMoveTouchEnd()
  log(bWriteLog and "Operation_CustomJoystick:_HandleCircleMoveTouchEnd")
  self.bCustomJoystickTouching = false
  self.CustomJoystickLastInput = nil
  self.bCustomJoystickSprintDistanceReady = false
  self:_RefreshSprint()
  if self.OnCustomJoystickTouchEnd then
    self:OnCustomJoystickTouchEnd()
  end
end

function Operation_CustomJoystick:_HandleCircleMoveSprint(bSprint)
  log(bWriteLog and "Operation_CustomJoystick:_HandleCircleMoveSprint - bSprint = " .. tostring(bSprint))
  self.bCustomJoystickSprintDistanceReady = bSprint == true
  self:_RefreshSprint()
end

function Operation_CustomJoystick:_RefreshSprint()
  local bShouldSprint = self.bCustomJoystickSprintDistanceReady == true
  if bShouldSprint then
    local input = self.CustomJoystickLastInput
    local magnitude = input and math.sqrt(input.X * input.X + input.Y * input.Y) or 0
    bShouldSprint = 0 < magnitude and -input.Y / magnitude >= SprintForwardSinThreshold
  end
  if bShouldSprint then
    local playerCharacter = GameplayData.GetPlayerCharacter()
    if slua.isValid(playerCharacter) and playerCharacter.HasState and (playerCharacter:HasState(EPawnState.DriveVehicle) or playerCharacter:HasState(EPawnState.InVehicle)) then
      bShouldSprint = false
    end
  end
  if bShouldSprint == self.bCustomJoystickSprintApplied then
    return
  end
  self.bCustomJoystickSprintApplied = bShouldSprint
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    return
  end
  playerController:JoystickTriggerSprint(bShouldSprint)
end

function Operation_CustomJoystick:ClearVehicleMoveInput()
  local playerController = GameplayData.GetPlayerController()
  if not slua.isValid(playerController) then
    log_warning(bWriteLog and "Operation_CustomJoystick:ClearVehicleMoveInput - playerController is invalid")
    return
  end
  local vehicleUserComponent = playerController:GetVehicleUserComp()
  if not (slua.isValid(vehicleUserComponent) and vehicleUserComponent.GetVehicleUserState and vehicleUserComponent.MoveVehicleForward) or not vehicleUserComponent.MoveVehicleRight then
    log_warning(bWriteLog and "Operation_CustomJoystick:ClearVehicleMoveInput - vehicleUserComponent is invalid")
    return
  end
  local ESTExtraVehicleUserState = import("ESTExtraVehicleUserState")
  if vehicleUserComponent:GetVehicleUserState() ~= ESTExtraVehicleUserState.EVUS_AsDriver then
    log_warning(bWriteLog and "Operation_CustomJoystick:ClearVehicleMoveInput - vehicleUserComponent is not driver")
    return
  end
  log(bWriteLog and "Operation_CustomJoystick:ClearVehicleMoveInput - ClearVehicleMoveInput")
  vehicleUserComponent:MoveVehicleForward(0)
  vehicleUserComponent:MoveVehicleRight(0)
end

return TOperation_CustomJoystick
