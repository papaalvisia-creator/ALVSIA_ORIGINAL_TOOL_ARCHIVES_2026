local UI_Pet_Main = {}
local JumpUtils = require("client.logic.store.jump_utils")
local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
local PufferConst = require("client.slua.logic.download.puffer_const")
local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
local TimeTicker = require("common.time_ticker")
local TimeUtil = require("client.common.time_util")
local DEFAULT_MIDDLE_POSITION = {
  X = -10000,
  Y = -434,
  Z = -14433.0,
  rx = 0,
  ry = 0,
  rz = 90
}
local tlog_report_utils = require("client.slua.config.tlog.tlog_report_utils")
local PetHandler = require("client.network.Protocol.PetHandler")
local ViewedReddot = {}
local NameQualityPath_Long = {
  [4] = "/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_04_1_png.T_icon_Airquality_04_1_png",
  [5] = "/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_05_1_png.T_icon_Airquality_05_1_png",
  [6] = "/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_06_1_png.T_icon_Airquality_06_1_png",
  [7] = "/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_07_1_png.T_icon_Airquality_07_1_png",
  [8] = "/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_08_1_png.T_icon_Airquality_08_1_png"
}

function UI_Pet_Main:ctor(type, PetInsIDOrDressID, extraParam)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  self.bJustShowPet = true
  self.nCurLevel = 1
  if not PetInsIDOrDressID or PetInsIDOrDressID == 0 then
    PetInsIDOrDressID = logic_pet:GetEquipedPetInsID()
  end
  self.nCurPetInsID = PetInsIDOrDressID
  self.nCurPetItemID = logic_pet:ConvertToPetID(self.nCurPetInsID)
  self.nCurPetActionID = 0
  self.nCurDressItemID = 0
  self.nCurDressCardID = 0
  self.ArrayActionList = {}
  self.ArrayDressList = {}
  self.BigPetModel = nil
  self.nJumpPetInsId = logic_pet:GetJumpPetID(PetInsIDOrDressID)
  self.showingAvatar = nil
  self.equipedDress = {}
  self.petTimerHandles = {}
  self.lastRealPutOn = true
  self.lastRealPutOff = true
  self.AutoPlayActionTimer = nil
  self.extraParam = extraParam
  self.bIsInPortalSubUI = false
  self.bShowMiniTvInFightingSwitcher = false
end

function UI_Pet_Main:OnInitialize()
  UI_Pet_Main.__super.OnInitialize(self)
  local UIUtil = require("client.common.ui_util")
  UIUtil.SetAdaptation(self.UIRoot.CanvasPanel_Root)
  self.LSBActionList = self:InitScrollBox(self.UIRoot.LSBActionList)
  self.LSBDressList = self:InitScrollBox(self.UIRoot.LSBDressList)
  self.LSBActionList:SetRefreshItemCallback(self.OnRefreshActionListItem, self)
  self.LSBDressList:SetRefreshItemCallback(self.OnRefreshDressListItem, self)
  self.Btn_DressAccess = self.UIRoot.Btn_DressAccess
  self.WS_DressAccess = self.UIRoot.WS_DressAccess
  self.LoopScrollBox_PetCarry = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_PetCarry, "client.slua.umg.pet.Pet_Item.Pet_Carry_Item_UIBP")
  local CPet_Equip_Item_UIBP = require("client.slua.umg.pet.Pet_Item.Pet_Equip_Item_UIBP")
  self.Equip_Pet_Item = CPet_Equip_Item_UIBP()
  self.Equip_Pet_Item:InitWithParentWidget(self, self.UIRoot.Equip_Pet_Item)
  if not self.vng18IconUI then
    local UIUtil = require("client.common.ui_util")
    self.vng18IconUI = UIUtil.InitChildWindow18Logo(self, "CanvasPanel_Root", 0.15, 0, 0, -20, 100)
  end
end

function UI_Pet_Main:RegistEvents()
  UI_Pet_Main.__super.RegistEvents(self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_UNEQUIP_PET_SUCCESS, self.OnRspUnequipPet, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_EQUIP_PET_SUCCESS, self.OnRspEquipPet, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_ADD_EXP_SUCCESS, self.OnRspAddExp, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_LEVEL_UP_CLOSE, self.PlayActionUnlockAnimation, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_RENAME, self.OnRspRename, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_DRESS_CHANGE, self.OnPetDressChange, self, true)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_GET_PET_DATA, self.OnGetPetData, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_TIME_GET_PET, self.OnGetPetTimeLimt, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_CHANGE_SELECT, self.ChoosePet, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_System_Closed, self.OnSystemClosed, self)
  self:AddCommonEvent(EVENTTYPE_DOWNLOAD, EVENTID_PET_DOWNLOAD_FINISH, self.UpdateCurPet, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_PET_EXPIRED, self.HasPetExpired, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_PET_UPDATE_EXPIRATION_STATE, self.UpdatePetExpirationState, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_DRESS_EXPIRED, self.HasDressExpired, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_DRESS_UPDATE_EXPIRATION_STATE, self.UpdateDressExpirationState, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_PET_ITEM_DECOMPOSED, self.HasItemDecomposed, self)
  self:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED, self.OnApplicationReactivated, self)
  self:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED_EX, self.OnApplicationReactivated, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_AVATAR_REFRESHED, self.OnAvatarRefreshed, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_SELF_PET_LEVEL_UP, self.OnLevelUp, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_CARRY_LIST_CHANGE, self.OnCarryPetListChanged, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_DRESS_TIME_INFO_UPDATE, self.OnPetDressTimeInfoChange, self)
  self:AddOnClickedEventByControl(self.UIRoot.BtnHelp, self.OnClickedHelp, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickedClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_PetAccess, self.OnClickedPetAccess, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Freeze, self.OnClickedPetFrozen, self)
  self.LSBActionList:AddItemWidgetChildEvent("Btn_PlayAction", "OnClicked", self.OnClickedActionItem, self)
  self.LSBDressList:AddItemWidgetChildEvent("Btn_DressItem", "OnClicked", self.OnClickedDressItem, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_EquipPet, self.OnClickedEquipPet, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_UnequipPet, self.OnClickedUnequipPet, self)
  self:AddOnClickedEventByControl(self.UIRoot.BtnRename, self.OnClickedRename, self)
  self:AddOnClickedEventByControl(self.UIRoot.BtnChangeToSmallPet, self.OnClickedChangeCamera, self)
  self:AddOnClickedEventByControl(self.UIRoot.BtnChangeToBigPet, self.OnClickedChangeCamera, self)
  self:AddOnClickedEventByControl(self.UIRoot.BtnShare, self.OnClickShare, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Feature, self.OnClickedPetFeature, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_EatFood, self.OnClickedEatFood, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_FoodAccess, self.OnClickedEatFood, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_Action, self.OnClickedActionTag, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_Setting, self.OnClickedSetting, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_8, self.OnClickedChoosePet, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_2, self.OnClickedChoosePrePet, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_5, self.OnClickedChooseNextPet, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_Dress, self.OnClickedDressTag, self)
  self:AddOnClickedEventByControl(self.UIRoot.Btn_DressAccess, self.OnClickedDressAccess, self)
  self:AddOnClickedEventByControl(self.UIRoot.AttachedAction.Btn_PlayAction, self.OnClickedAttachedAction, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Change, self.OnClickedChangeCarryPets, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Enlarge, self.OnClickedPetEnlarge, self)
  self:AddSettingOptionEvent("ShowMiniTvInFighting", function(bShowMiniTvInFighting)
    print(bWriteLog and "UI_Pet_Main ShowMiniTvInFighting Changed New Value: " .. tostring(bShowMiniTvInFighting))
    self.bShowMiniTvInFightingSwitcher = bShowMiniTvInFighting
    if self.BigPetModel then
      self.BigPetModel:SetMiniTvShow(bShowMiniTvInFighting)
    end
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    local SmallPet = ModelDisplayer.GetShowingAvatar() and ModelDisplayer.GetShowingAvatar():GetPet()
    if SmallPet then
      SmallPet:SetMiniTvShow(bShowMiniTvInFighting)
    end
  end, true)
end

function UI_Pet_Main:OnPostInitialize()
  UI_Pet_Main.__super.OnPostInitialize(self)
  log(bWriteLog and "UI_Pet_Main:OnPostInitialize RequestJumpMapInfo")
  JumpUtils.RequestJumpMapInfo()
  PetHandler.send_get_pet_switch_effect_req()
  self:CheckAndShowGuide()
  if self.extraParam and self.extraParam.bOpenPortal then
    self:SwitchToPortal()
  else
    self:SwitchToNormal()
  end
end

function UI_Pet_Main:Close()
  log(bWriteLog and "  UI_Pet_Main:Close.  ")
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  Lobby_camera_manager_module:LevelSequence_Stop()
  UI_Pet_Main.__super.Close(self)
end

function UI_Pet_Main:OnClose()
  LobbySceneManager.LoadStreamLevel(false, LobbySceneManager.LEVEL_NAME.PET)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  ModelDisplayer.Destroy()
  if self.BigPetModel then
    self.BigPetModel:Destroy()
  end
  local reddotPet = require("client.slua.logic.pet.reddot_pet")
  reddotPet:ClearAllReddot()
  local LobbyAvatarManager = require("client.logic.avatar.LobbyAvatarManager")
  LobbyAvatarManager.UpdateMyPetDress()
  local pet_pawn_pool = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.pet_pawn_pool)
  pet_pawn_pool:ReleasePool()
  local SettingModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.SettingModule)
  SettingModule:RemoveOptionValueChangeEvent("ShowMiniTvInFighting")
  UI_Pet_Main.__super.OnClose(self)
end

function UI_Pet_Main:OnClickedClose()
  self:PlayAudio(sound_config.close_v1)
  self:CloseSelf()
end

function UI_Pet_Main:OnShow()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if logic_pet.PetSystemClosed then
    ShowNotice(6891)
    self:CloseSelf()
    return
  end
  if logic_pet.orderPetList == nil or next(logic_pet.orderPetList) == nil then
    PetHandler.send_get_pet_tab_info_req()
  else
    self:AddTimerOnce(TimeTicker.MINIMUM_STEP_TIME, function()
      logic_pet:SetCurrentSelectPet()
    end)
  end
  PetHandler.send_pet_decompose_list_req()
  if logic_pet.PetDressShopData == nil or next(logic_pet.PetDressShopData) == nil then
    PetHandler.send_query_pet_dress_shop_info_req()
  end
  self:PlayPetBGM()
  self:AddTimer(TimeTicker.MINIMUM_STEP_TIME, function()
    local LogicLobby = require("client.slua.logic.lobby.logic_lobby_main")
    LogicLobby.HideLobbyUI()
    self:InitScene()
    coroutine.yield(TimeTicker.NEXT_FRAME)
    self:InitAvatar()
    coroutine.yield(TimeTicker.NEXT_FRAME)
    self:InitPetTips()
    self:InitUI()
    self:ShowOfflineExpiredPets()
    coroutine.yield(TimeTicker.NEXT_FRAME)
    self:UpdateCarryPets()
    self:UpdateEquipPetSlot()
  end)
end

function UI_Pet_Main:PlayActionByBtn(Id)
  if not self.UIRoot then
    return
  end
  local allData = self.LSBActionList:GetSetData()
  for i, v in ipairs(allData) do
    if v.PetActionID == Id then
      self:SelectActionByIndex(i)
      break
    end
  end
end

function UI_Pet_Main:OnDownloadFinish()
  self:AddTimerOnce(0.1, function()
    self:UpdateCurPet()
  end)
end

function UI_Pet_Main:InitUI()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if not logic_pet.orderPetList then
    return
  end
  self:OnClickedActionTag(true)
  if UIManager.IsUIShow(UIManager.UI_Config.pet_choosepet) then
    UIManager.CloseUI(UIManager.UI_Config.pet_choosepet)
  end
  self:InitEquipedDressData()
end

function UI_Pet_Main:InitEquipedDressData()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local PetData = logic_pet:GetPetDataIncludeInherit()
  if PetData then
    for ins_id, data in pairs(PetData) do
      self.equipedDress[ins_id] = self.equipedDress[ins_id] or {}
      if data.dress then
        for itemID, _ in pairs(data.dress) do
          self.equipedDress[ins_id][itemID] = true
        end
      end
    end
  end
end

function UI_Pet_Main:InitAvatar()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local MultipleAvatarEnum = require("client.logic.avatar.MultipleAvatarEnum")
  ModelDisplayer.Init()
  ModelDisplayer.GetShowingAvatar():CopyMyEquipments(true)
  ModelDisplayer.GetShowingAvatar():SetShowPosition(-9995, -383, -14344.0)
  ModelDisplayer.GetShowingAvatar():HideAvatar(MultipleAvatarEnum.Enum_VisibilitySource.Pet)
  local EAvatarSlotType = import("EAvatarSlotType")
  local model = ModelDisplayer.GetShowingAvatar() and ModelDisplayer.GetShowingAvatar():GetModel()
  if model then
    local PendantItemID = model:GetEquipmentInfoBySlot(EAvatarSlotType.EAvatarSlotType_BackPack_PendantSlot)
    if ModelDisplayer.GetShowingAvatar() and PendantItemID ~= 0 then
      ModelDisplayer.GetShowingAvatar():PutoffEquipment(PendantItemID)
    end
  end
  ModelDisplayer.GetShowingAvatar():PutoffSubtype(504)
  ModelDisplayer.GetShowingAvatar():PutoffSubtype(501)
  self.showingAvatar = ModelDisplayer.GetShowingAvatar()
end

function UI_Pet_Main:InitScene()
  LobbySceneManager.LoadStreamLevel(true, LobbySceneManager.LEVEL_NAME.PET, 10121)
end

function UI_Pet_Main:InitPetTips()
  local common_config = require("client.slua.common.common_config")
  if common_config:IsBlockingPopupTip() then
    log(bWriteLog and "UI_Pet_Main:InitPetTips UI responsiveness testing")
    return false
  end
  local show = false
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local table = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.ePetTips)
  if table == nil then
    show = true
  else
    local NeedShowPetTips = table.NeedShowPetTips
    if NeedShowPetTips then
      show = true
    else
      show = false
    end
  end
  table = {}
  table.NeedShowPetTips = false
  PlayerPrefsSystem.SaveTableToFile_N(table, PlayerPrefsSystem.ePlayerPrefsType.ePetTips)
  if show then
    UIManager.ShowUI(UIManager.UI_Config.pet_main_tips)
  end
end

function UI_Pet_Main:UpdateCurPet()
  log(bWriteLog and "UI_Pet_Main:UpdateCurPet curPetID: " .. tostring(self.nCurPetItemID))
  if self.nCurPetItemID == 0 then
    log(bWriteLog and "UI_Pet_Main:UpdateCurPet curPetID = 0")
    return
  end
  self:AddTimerOnce(0, function()
    self:UpdateCurPetModel()
    self:UpdateCurPetInfo()
    self:UpdateCurPetBtn()
    self:UpdateSwtichBtn()
    self:UpdateCurPetFood()
    self:UpdateCurPetDownload()
  end)
end

function UI_Pet_Main:UpdateSwtichBtn()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  self:SetWidgetVisible(self.UIRoot.Panel_middle, not logic_pet:IsInheritPet(self.nCurPetInsID))
end

function UI_Pet_Main:UpdateCurPetDownload()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local DependentResource = logic_pet:GetPetDependResource(self.nCurPetItemID)
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, DependentResource)
  local MasterActionDownloaded = state == PufferConst.ENUM_DownloadState.Done
  if not MasterActionDownloaded then
    PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, DependentResource, PufferTlog.Enum_TLog_From.Pet, nil, {bAutoDownload = true})
  end
  local params = {
    showGray = true,
    hideMask = true,
    showSize = true,
    size = 50
  }
  DependentResource[#DependentResource + 1] = self.nCurPetItemID
  local common_download_handler = require("client.slua.common.common_download_handler")
  common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, DependentResource, self, self.UIRoot.Panel_Download, params)
end

function UI_Pet_Main:UpdateCurCameraMode()
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local needDress = logic_pet:GetCurDressItemsByInsID(self.nCurPetInsID) or {}
  local petCfg = CDataTable.GetTableData("PetTable", self.nCurPetItemID)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local MultipleAvatarEnum = require("client.logic.avatar.MultipleAvatarEnum")
  if self.bJustShowPet then
    if petCfg then
      local cameraID = petCfg.OnlyPetCamera
      Lobby_camera_manager_module:SwitchCamera(cameraID)
    end
    self.UIRoot.SwitcherCamera:SetActiveWidgetIndex(0)
    if ModelDisplayer.GetShowingAvatar() then
      ModelDisplayer.GetShowingAvatar():HideAvatar(MultipleAvatarEnum.Enum_VisibilitySource.Pet)
      ModelDisplayer.GetShowingAvatar():StopPetAction()
    end
    if self.BigPetModel then
      self.BigPetModel:SetPosition(-10000, -434, -14433)
      logic_pet:AdjustPetDress(self.BigPetModel, needDress, self.BigPetModel:GetEquipedDress())
    end
  else
    if petCfg then
      local cameraID = petCfg.PetAndAvatarCamera
      Lobby_camera_manager_module:SwitchCamera(cameraID)
    end
    self.UIRoot.SwitcherCamera:SetActiveWidgetIndex(1)
    if ModelDisplayer.GetShowingAvatar() then
      ModelDisplayer.GetShowingAvatar():PutoffSubtype(ENUM_ITEM_SUBTYPE.Helmet)
      ModelDisplayer.GetShowingAvatar():PutoffSubtype(ENUM_ITEM_SUBTYPE.Helmet_NoLevel)
      ModelDisplayer.GetShowingAvatar():ShowAvatar(MultipleAvatarEnum.Enum_VisibilitySource.Pet)
      local _pet = ModelDisplayer.GetShowingAvatar():GetPet()
      if _pet then
        logic_pet:AdjustPetDress(_pet, needDress, _pet:GetEquipedDress())
      end
    end
    if self.BigPetModel then
      self.BigPetModel:SetPosition(-10000, -434, 0)
      self.BigPetModel:StopAction()
    end
  end
  Lobby_camera_manager_module:ResetLobbyCamera()
end

function UI_Pet_Main:UpdateCurPetModel(diff)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local pet_info = logic_pet:GetPetDataByInsID(self.nCurPetInsID)
  local PetData = logic_pet:FormatPetDataByServerInfo(0, pet_info)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  if not ModelDisplayer.GetShowingAvatar() then
    log(bWriteLog and "[HZA]There is no avatar!!!")
    self:InitAvatar()
  end
  if not self.bJustShowPet then
    if pet_info and logic_pet:HasPetIncludeInherit(self.nCurPetInsID) then
      ModelDisplayer.GetShowingAvatar():RefreshOrCreatePet(PetData, false, false, {
        uid = DataMgr.roleData.uid
      })
    else
      local FakePetData = logic_pet:FormatPetData(0, self.nCurPetItemID)
      ModelDisplayer.GetShowingAvatar():RefreshOrCreatePet(FakePetData)
    end
    ModelDisplayer.GetShowingAvatar():EnablePetClickRandomAction(true)
    local SmallPet = ModelDisplayer.GetShowingAvatar():GetPet()
    if SmallPet then
      SmallPet:SetMiniTvShow(self.bShowMiniTvInFightingSwitcher)
    end
  end
  log(bWriteLog and "[ZH] UpdateCurPetModel()1")
  local pet_manager = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.pet_manager)
  if self.bJustShowPet then
    if pet_info and logic_pet:HasPetIncludeInherit(self.nCurPetInsID) then
      self.BigPetModel = pet_manager:RefreshOrCreatePet(PetData, false, false, self.BigPetModel, diff)
      self.BigPetModel:SetPetShowType(logic_pet.ENUM_PetShowType.Workshop)
    else
      local FakePetData = logic_pet:FormatPetData(0, self.nCurPetItemID)
      self.BigPetModel = pet_manager:RefreshOrCreatePet(FakePetData, nil, nil, self.BigPetModel, diff)
      self.BigPetModel:SetPetShowType(logic_pet.ENUM_PetShowType.Workshop)
    end
    self.BigPetModel:SetMiniTvShow(self.bShowMiniTvInFightingSwitcher)
    self.BigPetModel:SetPosition(-10000, -434, 0)
    self.BigPetModel:SetRotation(0, 0, 90)
    self.BigPetModel:EnableClickRandomAction(true)
  end
  local petType = self.nCurPetItemID
  local ScaleConfig = CDataTable.GetTableData("PetScaleTable", petType)
  local Scale
  if ScaleConfig and ScaleConfig.WorkshopScale_f and ScaleConfig.BaseScale_f then
    Scale = ScaleConfig.WorkshopScale_f * ScaleConfig.BaseScale_f
  end
  if self.bJustShowPet then
    if Scale then
      self.BigPetModel:SetScale(Scale, Scale, Scale)
    end
    self.BigPetModel:EnableRotation(true)
  else
    ModelDisplayer.GetShowingAvatar():EnablePetRotation(true)
    ModelDisplayer.StopAction()
  end
  self:UpdateCurCameraMode()
  if not logic_pet:IsNotGyrfalcon(self.nCurPetItemID) then
    EventSystem:postEvent(EVENTTYPE_PET, EVENTID_PET_AVATAR_REFRESHED)
  end
end

function UI_Pet_Main:OnAvatarRefreshed(_, _, _, id)
  if self.AutoPlayActionTimer then
    self:RemoveTimer(self.AutoPlayActionTimer)
    self.AutoPlayActionTimer = nil
  end
  local isSamePet = id and id == self.nCurPetItemID
  log(bWriteLog and "  UI_Pet_Main:OnAvatarRefreshed. isSamePet: " .. tostring(isSamePet))
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  log(bWriteLog and "  UI_Pet_Main:OnAvatarRefreshed. id: " .. tostring(id))
  
  local function refreshLater()
    if Lobby_camera_manager_module.currentCameraID ~= 10121 then
      return
    end
    if isSamePet then
      return
    end
    local EquipedDress
    if self.bJustShowPet then
      if self.BigPetModel then
        EquipedDress = self.BigPetModel:GetEquipedDress()
      end
    else
      local avatar = ModelDisplayer.GetShowingAvatar()
      local pet = avatar and avatar:GetPet()
      if pet then
        EquipedDress = pet:GetEquipedDress()
      end
    end
    if EquipedDress and next(EquipedDress) then
      for _, itemID in pairs(EquipedDress) do
        local DressAction = logic_pet:GetDressAttachedAction(itemID)
        if DressAction then
          local actionCfg = CDataTable.GetTableData("PetActionTable", DressAction)
          if self.bJustShowPet then
            self.BigPetModel:StopAction()
            if not self.bIsInPortalSubUI then
              self:PlayActionByBtn(DressAction)
            end
            if actionCfg and actionCfg.PetLevelSequence and actionCfg.PetLevelSequence ~= "" then
              Lobby_camera_manager_module:LevelSequence_Stop()
              if not self.bIsInPortalSubUI then
                Lobby_camera_manager_module:LevelSequence_Play(actionCfg.PetLevelSequence)
              end
            end
          else
            local showingAvatar = ModelDisplayer.GetShowingAvatar()
            if showingAvatar then
              showingAvatar:StopPetAction()
              if not self.bIsInPortalSubUI then
                showingAvatar:PlayPetAction(DressAction)
              end
            end
            if actionCfg and actionCfg.MasterLevelSequence and actionCfg.MasterLevelSequence ~= "" then
              Lobby_camera_manager_module:LevelSequence_Stop()
              if not self.bIsInPortalSubUI then
                Lobby_camera_manager_module:LevelSequence_Play(actionCfg.MasterLevelSequence)
              end
            end
          end
          return
        end
      end
    end
    local petCfg = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
    if not petCfg then
      log(bWriteLog and "not petCfg, itemID = " .. tostring(self.nCurPetItemID))
      return
    end
    local actionCfg = CDataTable.GetTableData("PetActionTable", petCfg.DefaultAction)
    if PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {
      petCfg.DefaultAction
    }) ~= PufferConst.ENUM_DownloadState.Done then
      PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, {
        petCfg.DefaultAction
      }, PufferTlog.Enum_TLog_From.Pet, nil, {bAutoDownload = true})
      return
    end
    if self.bJustShowPet then
      if self.BigPetModel then
        self.BigPetModel:StopAction()
      end
      log(bWriteLog and "[ZH] petCfg.DefaultAction: " .. tostring(petCfg.DefaultAction))
      if not self.bIsInPortalSubUI then
        self:PlayActionByBtn(petCfg.DefaultAction)
        if actionCfg and actionCfg.PetLevelSequence ~= nil then
          Lobby_camera_manager_module:LevelSequence_Play(actionCfg.PetLevelSequence)
        end
      end
    else
      log(bWriteLog and "petCfg.DefaultAction 2: " .. tostring(petCfg.DefaultAction))
      ModelDisplayer.GetShowingAvatar():StopPetAction()
      if not self.bIsInPortalSubUI then
        ModelDisplayer.GetShowingAvatar():PlayPetAction(petCfg.DefaultAction)
        if actionCfg and actionCfg.MasterLevelSequence ~= nil then
          Lobby_camera_manager_module:LevelSequence_Play(actionCfg.MasterLevelSequence)
        end
      end
    end
  end
  
  self.AutoPlayActionTimer = self:AddTimerOnce(0.15, refreshLater)
end

function UI_Pet_Main:UpdateCurPetInfo(bPlayLevelAnimation)
  local petID = self.nCurPetItemID
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local curPetData = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if curPetData == nil then
    log(bWriteLog and "UI_Pet_Main:UpdateCurPetInfo curPetData is nil curPetItemID = " .. tostring(self.nCurPetItemID))
    return
  end
  local itemInfo = CDataTable.GetTableData("Item", petID)
  local petName = logic_pet:GetPetNameLocal(self.nCurPetInsID)
  if petName then
    self.UIRoot.Text_CurPetName:SetText(petName)
  elseif itemInfo ~= nil then
    self.UIRoot.Text_CurPetName:SetText(itemInfo.ItemName)
  end
  if itemInfo ~= nil then
    local path = NameQualityPath_Long[itemInfo.itemQuality]
    self:SetTexture(self.UIRoot.ImgQuality1, path, {sync = false})
  end
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  local sBrandLogo = curPetData.BrandLogo
  if GlobalData.IsBLUEHOLE() then
    local petCfg = CDataTable.GetTableData("PetTable", petID)
    if petCfg then
      sBrandLogo = petCfg.BrandLogoBlueHole
    end
  end
  if sBrandLogo ~= nil and sBrandLogo ~= "" then
    local itemDesc = itemInfo and itemInfo.itemDesc or ""
    self.UIRoot.Text_Desc:SetText(itemDesc)
    self.UIRoot.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.Image_logo:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.CanvasPanel_logo:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self:SetTexture(self.UIRoot.Image_logo, sBrandLogo, {sync = false, defaultIcon = ""})
  else
    self.UIRoot.Text_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.Image_logo:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.CanvasPanel_logo:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  if not logic_pet:HasPet(curPetData.PetID) or logic_pet:IsInheritPet(self.nCurPetInsID) then
    self.UIRoot.BtnRename:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.Image_Rename:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    self.UIRoot.BtnRename:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
    self.UIRoot.Image_Rename:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
  if logic_pet:HasPetIncludeInherit(self.nCurPetInsID) then
    local petData = logic_pet:GetPetDataByInsID(self.nCurPetInsID)
    if petData ~= nil then
      if petData.name ~= nil then
        self.UIRoot.Text_CurPetName:SetText(petData.name)
      end
      local curLevel = logic_pet:GetPetLevelByExp(petData.id, petData.exp)
      self.nCurLevel = curLevel
      self:UpdatePetLevelAndExp(petData.id, petData.exp, bPlayLevelAnimation)
    end
  else
    local curPetLevelData = logic_pet:GetPetLevelItemCfg(self.nCurPetItemID, 1)
    if curPetLevelData == nil then
      log(bWriteLog and "UI_Pet_Main:UpdateCurPetInfo curPetLevelData is nil curPetID = " .. tostring(self.nCurPetItemID))
      return
    end
    local strLevel = LocUtil.LocalizeResFormat("6417", 1)
    self.UIRoot.Text_CurPetLevel:SetText(strLevel)
    self.UIRoot.Text_AniCurPetLevel:SetText(strLevel)
    self.UIRoot.Text_CurPetExp:SetText("0/" .. tostring(curPetLevelData.PetNeedExp))
    self.UIRoot.ProgressBar_PetExp:SetPercent(0)
  end
  self:UpdateNewPetUI()
end

function UI_Pet_Main:UpdateNewPetUI()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local bIsTimeLimitedOwning, _ = logic_pet:IsPetTimeLimitedOwning(self.nCurPetItemID)
  if logic_pet:IsUpgradablePet(self.nCurPetItemID) and not bIsTimeLimitedOwning then
    log(bWriteLog and "[ZH] \228\184\141\233\154\144\232\151\143\231\187\143\233\170\140\230\157\161")
    self.UIRoot.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    log(bWriteLog and "[ZH] \233\154\144\232\151\143\231\187\143\233\170\140\230\157\161")
    self.UIRoot.CanvasPanel_1:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_Pet_Main:UpdatePetLevelAndExp(petID, exp, bPlayLevelAnimation)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local curPetData = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if curPetData == nil then
    log(bWriteLog and "UI_Pet_Main:UpdatePetLevelAndExp curPetData is nil petID = " .. tostring(petID))
    return
  end
  local level = logic_pet:GetPetLevelByExp(petID, exp)
  if level == curPetData.PetMaxLevel then
    local str = LocUtil.LocalizeResFormat("4608")
    self.UIRoot.Text_CurPetLevel:SetText(str)
    self.UIRoot.Text_AniCurPetLevel:SetText(str)
    self.UIRoot.Text_CurPetExp:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    local strLevel = LocUtil.LocalizeResFormat("6417", level)
    self.UIRoot.Text_CurPetLevel:SetText(strLevel)
    self.UIRoot.Text_AniCurPetLevel:SetText(strLevel)
    self.UIRoot.Text_CurPetExp:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
  local curLevelExp = logic_pet:GetCurLevelExp(petID, exp)
  local curLevel = logic_pet:GetPetLevelByExp(petID, exp)
  local curPetLevelData = logic_pet:GetPetLevelItemCfg(petID, curLevel)
  local strExp = LocUtil.LocalizeResFormat("6830", curLevelExp, curPetLevelData.PetNeedExp)
  self.UIRoot.Text_CurPetExp:SetText(strExp)
  local percent = 0
  if curPetLevelData.PetNeedExp > 0 then
    percent = curLevelExp / curPetLevelData.PetNeedExp
  end
  if level == curPetData.PetMaxLevel then
    self.UIRoot.ProgressBar_PetExp:SetPercent(1)
  else
    self.UIRoot.ProgressBar_PetExp:SetPercent(percent)
  end
  local posX = -50 + percent * 212
  local pos = FVector2D(0, 0)
  pos.X = posX
  pos.Y = -10
  local isUpgradable = logic_pet:IsUpgradablePet(self.nCurPetItemID)
  if isUpgradable and bPlayLevelAnimation then
    self.UIRoot.UIParticle_Exp.Slot:SetPosition(pos)
    self.UIRoot.UIParticle_Exp:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self:PlayUserWidgetAnimation(self.UIRoot.ParticleEmiteer, 0, 1, 0, 1)
  else
    self.UIRoot.UIParticle_Exp:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_Pet_Main:UpdateCurPetBtn()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if logic_pet:HasPetIncludeInherit(self.nCurPetInsID) then
    if logic_pet:IsPetEquip(self.nCurPetInsID) then
      self.UIRoot.Switcher_Equip:SetActiveWidgetIndex(0)
    else
      self.UIRoot.Switcher_Equip:SetActiveWidgetIndex(1)
    end
    if logic_pet:IsPetFrozen(self.nCurPetInsID) then
      self.UIRoot.Switcher_Equip:SetActiveWidgetIndex(3)
    end
  else
    self.UIRoot.Switcher_Equip:SetActiveWidgetIndex(2)
  end
  if logic_pet:HasPet(self.nCurPetItemID) and not logic_pet:IsInheritPet(self.nCurPetInsID) then
    self.UIRoot.BtnShare:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
  else
    self.UIRoot.BtnShare:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self:SetWidgetVisible(self.UIRoot.Button_Feature, logic_pet:EnablePetFeature(self.nCurPetItemID), true)
  self:SetWidgetVisible(self.UIRoot.Button_Enlarge, logic_pet:IsPetEnlargeEnabled(self.nCurPetItemID), true)
end

function UI_Pet_Main:UpdateCurPetFood()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local curPetData = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if curPetData == nil then
    log(bWriteLog and "UI_Pet_Main:UpdateCurPetFood curPetData is nil curPetID = " .. tostring(self.nCurPetItemID))
    return
  end
  self.UIRoot.Img_FoodTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  local timeLimitedOwning, _ = logic_pet:IsPetTimeLimitedOwning(self.nCurPetItemID)
  if logic_pet:HasPet(self.nCurPetItemID) and logic_pet:IsUpgradablePet(self.nCurPetItemID) and not timeLimitedOwning and not logic_pet:IsMaxLevel(self.nCurPetItemID) and not logic_pet:IsInheritPet(self.nCurPetInsID) then
    self.UIRoot.CP_PetEatFood:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    local addExp = logic_pet:GetAddExpByFoodID(curPetData.Foods[1])
    local strExp = LocUtil.LocalizeResFormat("6852", addExp)
    self.UIRoot.Text_ProvideExp:SetText(strExp)
    local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
    local foodWardrobeData = wardrobe_data:GetHallDepotItemDataByResID(curPetData.Foods[1])
    if foodWardrobeData == nil or foodWardrobeData.count == 0 then
      self.UIRoot.SwitcherFood:SetActiveWidgetIndex(1)
      local str = LocUtil.LocalizeResFormat("7172", 0, 1)
      self.UIRoot.RichTextFoodCnt:SetText(str)
    else
      if logic_pet:IsPetFrozen(self.nCurPetInsID) then
        self.UIRoot.SwitcherFood:SetActiveWidgetIndex(2)
      end
      self.UIRoot.SwitcherFood:SetActiveWidgetIndex(0)
      local str = LocUtil.LocalizeResFormat("6830", foodWardrobeData.count, 1)
      self.UIRoot.RichTextFoodCnt:SetText(str)
      local level = logic_pet:GetMyPetLevel(self.nCurPetItemID)
      if level < curPetData.PetMaxLevel then
        self.UIRoot.Img_FoodTips:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      end
    end
  else
    self.UIRoot.CP_PetEatFood:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_Pet_Main:UpdateActionList(animationList)
  log(bWriteLog and "[ZH] UpdateActionLis111t")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local PetActionCfg = logic_pet:GetPetActionCfg()
  self.ArrayActionList = {}
  local nowTime = TimeUtil.GetServerTimeInSec()
  local ActionDressMap = logic_pet:GetActionDressMap()
  for i, v in pairs(PetActionCfg) do
    if self.nCurPetItemID == v.PetID then
      local actionItemData = {}
      actionItemData.PetID = v.PetID
      actionItemData.PetActionID = v.PetActionID
      actionItemData.PetActionName = v.PetActionName
      actionItemData.PetActionQuality = v.PetActionQuality
      actionItemData.PetActionDes = v.PetActionDes
      actionItemData.NeedLevel = logic_pet:GetUnlockActionNeedLevel(v.PetID, v.PetActionID)
      actionItemData.PetActionIcon = v.PetActionIcon
      actionItemData.AnimationUnlock = false
      if animationList then
        for _, v in pairs(animationList) do
          if v == tostring(actionItemData.PetActionID) then
            actionItemData.AnimationUnlock = true
          end
        end
      end
      if ActionDressMap and ActionDressMap[v.PetActionID] and next(ActionDressMap[v.PetActionID]) then
        local hasActionDress, actionDressItemID = logic_pet:HasPetActionDress(self.nCurPetInsID, v.PetActionID)
        if hasActionDress and logic_pet:IsInDress(self.nCurPetInsID, actionDressItemID) and logic_pet.DressTimeUrl[actionDressItemID] and logic_pet.DressTimeUrl[actionDressItemID].launch_time and logic_pet.DressTimeUrl[actionDressItemID].open_time and logic_pet.DressTimeUrl[actionDressItemID].end_time and nowTime > logic_pet.DressTimeUrl[actionDressItemID].launch_time then
          actionItemData.NeedLevel = 0
          table.insert(self.ArrayActionList, 1, actionItemData)
        end
      else
        table.insert(self.ArrayActionList, actionItemData)
      end
    end
  end
  self.LSBActionList:SetData(self.ArrayActionList)
  self.LSBActionList:Select(1)
  self:UpdateCurActionInfo()
end

function UI_Pet_Main:UpdateCurActionInfo()
  if self.nCurPetActionID == 0 then
    self.UIRoot.PetTips_Action:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  self.UIRoot.PetTips_Action:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  local actionData = CDataTable.GetTableData("PetActionTable", self.nCurPetActionID)
  self.UIRoot.Text_Tips_Name_Action:SetText(actionData.PetActionName)
  self.UIRoot.Text_Tips_Desc_Action:SetText(actionData.PetActionDes)
end

function UI_Pet_Main:UpdateCurDressInfo()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if self.nCurDressItemID == 0 or logic_pet.DressPetMap and logic_pet.DressPetMap[self.nCurDressItemID] and logic_pet.DressPetMap[self.nCurDressItemID] ~= self.nCurPetItemID then
    self.UIRoot.PetTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.PetTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self.UIRoot.AttachedActionPanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    return
  end
  local itemCfg = CDataTable.GetTableData("Item", self.nCurDressItemID)
  self.UIRoot.PetTips:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self.UIRoot.Text_Tips_Name:SetText(itemCfg.ItemName)
  self.UIRoot.Text_Tips_Desc:SetText(itemCfg.ItemDesc)
  local DressActionMap = logic_pet:GetDressActionMap()
  local DressAttachedActionCfg = DressActionMap[self.nCurDressItemID]
  if DressAttachedActionCfg ~= nil then
    self.UIRoot.AttachedActionPanel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    if logic_pet:HasPetDress(self.nCurPetInsID, self.nCurDressItemID) then
      self.UIRoot.AttachedAction.CP_PetActionLock:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      self.UIRoot.AttachedAction.AnimationUnLock:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    else
      self.UIRoot.AttachedAction.CP_PetActionLock:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self.UIRoot.AttachedAction.AnimationUnLock:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    end
    self.UIRoot.AttachedAction.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    local UIUtil = require("client.common.ui_util")
    local path = UIUtil.GetBgQualityPath(DressAttachedActionCfg.PetActionQuality)
    self:SetTexture(self.UIRoot.AttachedAction.ImgQuality, path, {sync = false})
    self.UIRoot.AttachedAction.ImgSelected:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    self:SetTexture(self.UIRoot.AttachedAction.ImgActionIcon, UIUtil.GetItemSmallIcon(DressAttachedActionCfg.PetActionID), {sync = false})
    self.UIRoot.AttachedAction_Name:SetText(DressAttachedActionCfg.PetActionName)
    self.UIRoot.AttachedAction_Desc:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    self.UIRoot.AttachedActionPanel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self:UpdateDressExpirationState()
end

function UI_Pet_Main:PlayActionUnlockAnimation(eventType, eventID, petData)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local curPetLevelData = logic_pet:GetPetLevelItemCfg(petData.PetID, petData.NewLevel)
  local oldPetLevelData = logic_pet:GetPetLevelItemCfg(petData.PetID, petData.OldLevel)
  local StringUtil = require("common.string_util")
  local oldLevelAllAction = StringUtil.Split(oldPetLevelData.AllAction, "|")
  local curLevelAllAction = StringUtil.Split(curPetLevelData.AllAction, "|")
  local diffAction = logic_pet:GetActionDiff(oldLevelAllAction, curLevelAllAction)
  local unlockActionID = 0
  local index = 1
  for i1, v1 in pairs(self.ArrayActionList) do
    for _, v2 in pairs(diffAction) do
      if tostring(v1.PetActionID) == v2 then
        unlockActionID = v1.PetActionID
        v1.AnimationUnlock = true
        if index == 1 then
          index = i1
        end
      end
    end
  end
  self.LSBActionList:ScrollToItem(index)
  if 0 < unlockActionID then
    if self.bJustShowPet then
      if self.BigPetModel then
        self.BigPetModel:StopAction()
        self:PlayActionByBtn(unlockActionID)
      end
      if unlockActionID == 50001011 then
        if self.BigPetModel then
          self.BigPetModel:SetRotation(0, 0, 90)
        end
      else
        local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
        Lobby_camera_manager_module:ResetLobbyCamera()
      end
    else
      local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
      ModelDisplayer.GetShowingAvatar():StopPetAction()
      ModelDisplayer.GetShowingAvatar():PlayPetAction(unlockActionID)
    end
  end
  self.LSBActionList:RefreshAllItems(self.ArrayActionList)
end

function UI_Pet_Main:OnRefreshActionListItem(widget, index)
  local itemData = self.LSBActionList:GetItemData(index)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local UIUtil = require("client.common.ui_util")
  local icon, bHasAddKnownMissing = UIUtil.GetItemSmallIcon(itemData.PetActionID, widget.ImgActionIcon)
  local params = {sync = false, bHasAddKnownMissing = bHasAddKnownMissing}
  self:SetTexture(widget.ImgActionIcon, icon, params)
  if logic_pet:IsActionUnLock(self.nCurPetInsID, itemData.PetActionID) then
    widget.CP_PetActionLock:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    widget.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    widget.ImgActionIcon:SetColorAndOpacity(FLinearColor(1, 1, 1, 1))
  else
    widget.CP_PetActionLock:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    local isUpgradable = logic_pet:IsUpgradablePet(self.nCurPetItemID)
    if isUpgradable then
      local strLevel = LocUtil.LocalizeResFormat("6417", itemData.NeedLevel)
      widget.Text_NeedLevel:SetText(strLevel)
      widget.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      local red = FSlateColor(FLinearColor(1, 0, 0, 1))
      widget.Text_NeedLevel:SetColorAndOpacity(red)
    else
      widget.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
    widget.ImgActionIcon:SetColorAndOpacity(FLinearColor(1, 1, 1, 0.3))
  end
  local path = UIUtil.GetBgQualityPath(itemData.PetActionQuality)
  self:SetTexture(widget.ImgQuality, path, {sync = false})
  if itemData.PetActionID == self.nCurPetActionID then
    widget.ImgSelected:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.ImgSelected:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  if itemData.AnimationUnlock and (itemData.bPlayingUnlockAni == nil or itemData.bPlayingUnlockAni == false) then
    widget.AnimationUnLock:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.bPlayingUnlockAni = true
    self:PlayWidgetAnimation(widget, widget.unlock_ani, 0, 1, 0, 1)
    self:AddTimerOnce(1.5, function()
      itemData.AnimationUnlock = false
      itemData.bPlayingUnlockAni = false
    end)
  end
  if itemData.AnimationUnlock == false then
    widget.AnimationUnLock:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local common_download_handler = require("client.slua.common.common_download_handler")
  common_download_handler.CreateDownloadUI(PufferConst.ENUM_DownloadType.ODPAK, {
    self.nCurPetItemID,
    itemData.PetActionID
  }, widget.Panel_Download)
end

function UI_Pet_Main:OnRspUnequipPet()
  self.UIRoot.Switcher_Equip:SetActiveWidgetIndex(1)
  local BasicDataAvatarWearInfo = ModuleManager.GetModule(ModuleManager.DataModuleConfig.BasicDataAvatarWearInfo)
  BasicDataAvatarWearInfo:GetOrReqData(DataMgr.roleData.uid, nil, {bForceReq = true}, Enum_AvatarShowSource.Partner_Preview_UIBP)
  self:UpdateEquipPetSlot()
end

function UI_Pet_Main:OnRspEquipPet(eventType, eventID, PetInsID)
  if PetInsID == self.nCurPetInsID then
    self.UIRoot.Switcher_Equip:SetActiveWidgetIndex(0)
  end
  self:UpdateEquipPetSlot()
end

function UI_Pet_Main:OnRspAddExp(eventType, eventID, petData)
  self:AddTimer(0, function()
    local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
    local curLevel = logic_pet:GetPetLevelByExp(petData.PetID, petData.PetExp)
    if curLevel > self.nCurLevel then
      local strLevel = LocUtil.LocalizeResFormat("6417", curLevel)
      self.UIRoot.Text_CurPetLevel:SetText(strLevel)
      self.UIRoot.Text_AniCurPetLevel:SetText(strLevel)
      self.UIRoot.ProgressBar_PetExp:SetPercent(1)
      local curPetLevelData = logic_pet:GetPetLevelItemCfg(petData.PetID, self.nCurLevel)
      local strExp = LocUtil.LocalizeResFormat("6830", curPetLevelData.PetNeedExp, curPetLevelData.PetNeedExp)
      self.UIRoot.Text_CurPetExp:SetText(strExp)
      petData.NewLevel = curLevel
      petData.OldLevel = self.nCurLevel
      self.nCurLevel = curLevel
      self.UIRoot.UIParticle_Exp:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      coroutine.yield(0.4)
      self.UIRoot.Img_ExpFull:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self:PlayUserWidgetAnimation(self.UIRoot.liuguang_ani, 0, 1, 0, 1)
      coroutine.yield(0.4)
      self.UIRoot.Img_LevelUpLight:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self:PlayUserWidgetAnimation(self.UIRoot.LV_ani, 0, 1, 0, 1)
      coroutine.yield(0.3)
      strExp = LocUtil.LocalizeResFormat("6852", petData.PetAddExp)
      self.UIRoot.TxtAddExp1:SetText(strExp)
      self.UIRoot.TxtAddExp2:SetText(strExp)
      self.UIRoot.CPAniAddExp:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self:PlayUserWidgetAnimation(self.UIRoot.Exp_ani, 0, 1, 0, 1)
      UIManager.ShowUI(UIManager.UI_Config.pet_levelup, petData)
      coroutine.yield(0.3)
      self.UIRoot.Img_LevelUpLight:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      self.UIRoot.Img_ExpFull:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    else
      local strExp = LocUtil.LocalizeResFormat("6852", petData.PetAddExp)
      self.UIRoot.TxtAddExp1:SetText(strExp)
      self.UIRoot.TxtAddExp2:SetText(strExp)
      self.UIRoot.CPAniAddExp:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      self:PlayUserWidgetAnimation(self.UIRoot.Exp_ani, 0, 1, 0, 1)
    end
    self:UpdateCurPetInfo(true)
    self:UpdateCurPetFood()
    self.UIRoot.UIParticle_Exp:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end)
end

function UI_Pet_Main:OnRspRename(_, _, petData)
  if tostring(petData.UID) == DataMgr.roleData.uid then
    self:UpdateCurPetInfo()
  end
end

function UI_Pet_Main:OnPurchase()
  self.LSBDressList:RefreshAllItems(self.ArrayDressList[self.nCurPetItemID])
  self:UpdateCurDressInfo()
end

function UI_Pet_Main:OnGetPetTimeLimt()
  self:InitUI()
end

function UI_Pet_Main:OnClickedActionItem(_, index)
  self:PlayAudio(sound_config.click_v1)
  local itemData = self.LSBActionList:GetItemData(index)
  if not itemData then
    log_error("UI_Pet_Main:OnClickedActionItem itemData is nil, but which is impossible")
    return
  end
  self:SelectActionByIndex(index)
  ClientSendBAReport(TLogEventDefine.PetPlayAction, 0)
end

function UI_Pet_Main:OnClickedEquipPet()
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.LobbyBtn) then
    return
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  logic_pet:equip_pet_req(self.nCurPetInsID)
end

function UI_Pet_Main:OnClickedUnequipPet()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  logic_pet:unequip_pet_req()
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedPetFrozen()
  self:PlayAudio(sound_config.click_v1)
  ShowNotice(3000016)
end

function UI_Pet_Main:OnClickedPetAccess()
  self:PlayAudio(sound_config.click_v1)
  local StoreUtils = require("client.slua.logic.store.utils.store_utils")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if logic_pet:HasJumpUrl(self.nCurPetItemID) then
    if logic_pet:IsPetInAccessibleTime(self.nCurPetItemID) then
      if UIManager then
        local url = logic_pet:GetPetJumpUrl(self.nCurPetItemID)
        GlobalData.JumpUrl(url)
      end
    else
      ShowNotice(6430)
    end
    return
  end
  if JumpUtils.FindJumpInfoAll(self.nCurPetItemID) == nil then
    if TimeUtil.GetServerTimeInSec() < 1574611199 then
      GlobalData.JumpUrl("game://?module=1001300&id=18102201")
    else
      ShowNotice(7083)
    end
    return
  end
  local curPetData = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if curPetData == nil then
    log(bWriteLog and "UI_Pet_Access:InitAccessList curPetData is nil curPetID = " .. tostring(self.nCurPetItemID))
    return
  end
  if curPetData.JumpType == logic_pet.Enum_PetJumpType.EnumJumpToStore then
    local params = {}
    params.moduleId = JumpUtils.MODEL_ID_STORE
    params.itemId = curPetData.PetID
    params.Tab1 = 0
    params.Tab2 = 0
    local jump_utils = require("client.logic.store.jump_utils")
    jump_utils.OpenJumpModule(BP_ENUM_MODULE_MALL_CHILD, params)
  elseif curPetData.JumpType == logic_pet.Enum_PetJumpType.EnumJumpToSupply then
    local params = {}
    params.moduleId = JumpUtils.MODEL_ID_SUPPLY
    params.itemId = curPetData.PetID
    params.Tab1 = 0
    params.Tab2 = 0
    local jump_utils = require("client.logic.store.jump_utils")
    jump_utils.OpenJumpModule(BP_ENUM_MODULE_SUPPLY, params)
  end
end

function UI_Pet_Main:OnClickedEatFood()
  self:PlayAudio(sound_config.click_v1)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local curPetData = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if curPetData == nil then
    log(bWriteLog and "UI_Pet_Main:OnClickedEatFood curPetData is nil curPetID = " .. tostring(self.nCurPetItemID))
    return
  end
  if logic_pet:IsPetFrozen(self.nCurPetItemID) then
    ShowNotice(3000016)
    return
  end
  if self:HasFood() then
    if logic_pet:IsMaxLevel(self.nCurPetItemID) then
      ShowNotice(530007)
      return
    end
    UIManager.ShowUI(UIManager.UI_Config.pet_feed, self.nCurPetItemID, curPetData.Foods[1], self)
  else
    UIManager.ShowUI(UIManager.UI_Config.pet_access, self.nCurPetItemID, curPetData.Foods[1], logic_pet.Enum_AccessType.EnumFood)
  end
end

function UI_Pet_Main:HasFood()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local petCfg = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if not petCfg then
    return false
  end
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local foodWardrobeData = wardrobe_data:GetHallDepotItemDataByResID(petCfg.Foods[1])
  if foodWardrobeData and foodWardrobeData.count > 0 then
    return true
  end
  return false
end

function UI_Pet_Main:FeedAction()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local petCfg = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if petCfg == nil then
    log(bWriteLog and "UI_Pet_Main:OnClickedFood petCfg is nil curPetID = " .. tostring(self.nCurPetItemID))
    return
  end
  local actionCfg = CDataTable.GetTableData("PetActionTable", petCfg.EatAction)
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  if self.bJustShowPet then
    if self.BigPetModel and not self.BigPetModel:IsPlayingAction() then
      self.BigPetModel:StopAction()
      self:PlayActionByBtn(petCfg.EatAction)
      Lobby_camera_manager_module:LevelSequence_Play(actionCfg.PetLevelSequence)
    end
  else
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    local petAvatar = ModelDisplayer.GetShowingAvatar():GetPet()
    if not petAvatar:IsPlayingAction() then
      ModelDisplayer.GetShowingAvatar():StopPetAction()
      ModelDisplayer.GetShowingAvatar():PlayPetAction(petCfg.EatAction)
      Lobby_camera_manager_module:LevelSequence_Play(actionCfg.MasterLevelSequence)
    end
  end
end

function UI_Pet_Main:OnClickedChangeCamera()
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.LobbyModel) then
    return
  end
  self.bJustShowPet = not self.bJustShowPet
  log(bWriteLog and "  UI_Pet_Main:OnClickedChangeCamera. self.bJustShowPet: " .. tostring(self.bJustShowPet))
  if self.BigPetModel then
    self.BigPetModel:SetPosition(DEFAULT_MIDDLE_POSITION.X, DEFAULT_MIDDLE_POSITION.Y, DEFAULT_MIDDLE_POSITION.Z)
  end
  self:UpdateCurPetModel()
  self:UpdateCurCameraMode()
  local lastModel, curModel
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local showingAvatar = ModelDisplayer.GetShowingAvatar()
  if self.bJustShowPet then
    if showingAvatar then
      lastModel = showingAvatar:GetPet()
    end
    curModel = self.BigPetModel
  else
    lastModel = self.BigPetModel
    if showingAvatar then
      curModel = showingAvatar:GetPet()
    end
  end
  if curModel and lastModel and lastModel:HasEquiped(self.nCurDressItemID) then
    curModel:PutOnOrPutOff(self.nCurDressItemID, true)
  end
  if curModel and lastModel then
    lastModel:StopPetFeature()
    curModel:StopPetFeature()
    curModel:PlayAction(0)
    curModel:HideActor(true)
    self:AddTimer(0, function()
      curModel:HideActor(false)
      if lastModel.ActionID ~= 0 then
        curModel:PlayAction(lastModel.ActionID)
      end
      if self.bJustShowPet and showingAvatar then
        print(bWriteLog and "UI_Pet_Main:OnClickedChangeCamera - Destroying pet to clean up bird clothing residue")
        showingAvatar:DestroyPet()
      end
    end)
  end
  self:UpdateDressList()
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedRename()
  if UIManager then
    UIManager.ShowUI(UIManager.UI_Config.pet_rename)
    UIManager.GetUI(UIManager.UI_Config.pet_rename):SetData(self.nCurPetItemID)
  end
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickShare()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local cfg = logic_pet:GetPetItemCfgByPetItemID(self.nCurPetItemID)
  if not cfg then
    return
  end
  self.shareURL = cfg.ShareBgUrl
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBlueholeOperationRegion() and cfg.IndiaShareBgUrl and cfg.IndiaShareBgUrl ~= "" then
    self.shareURL = cfg.IndiaShareBgUrl
  end
  if logic_pet:HasPet(self.nCurPetItemID) then
    local Util = require("client.slua_ui_framework.util")
    local shareCfg = {
      campaign = "pet",
      isOld = true,
      share_type = ShareBtnTLogShareTypeDefine.PetInterface,
      reasonStr = json.encode({
        uid = DataMgr.roleData.uid,
        petId = self.nCurPetItemID
      })
    }
    Util.ShowShare(shareCfg, UIManager.UI_Config.pet_share_choose, self.shareURL)
    tlog_report_utils.ReportTLogEvent(TLogEventDefine.PetShare, self.nCurPetItemID, "Share_pet_" .. tostring(self.nCurPetItemID))
    local ShareMgr = require("client.logic.share.share_logic")
    ShareMgr.ShareBtnReq(1, ShareBtnTLogShareTypeDefine.PetInterface, nil, nil)
  else
    ShowNotice(6484)
  end
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedPetFeature()
  self:PlayAudio(sound_config.click_v1)
  if self.bJustShowPet then
    if self.BigPetModel then
      self.BigPetModel:PlayPetFeature(false)
    end
  else
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    ModelDisplayer.GetShowingAvatar():PlayPetFeature(false)
  end
end

function UI_Pet_Main:OnClickedHelp()
  local title = LocUtil.GetLocalizeResStr(6067)
  local context = LocUtil.GetLocalizeStrConcatenation(29820)
  context = string.gsub(context, "\\n", "\n")
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, context)
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedCloseTips()
  self.UIRoot.CP_PetTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedSetting()
  if UIManager then
    UIManager.ShowUI(UIManager.UI_Config.pet_setting)
  end
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedChoosePet()
  self:PlayAudio(sound_config.click)
  log(bWriteLog and "[ZH] OnClickedChoosePet")
  self:PlayAudio(sound_config.click_v1)
  if UIManager then
    UIManager.ShowUI(UIManager.UI_Config.pet_choosepet)
  end
end

local function _GetRemainTimeString(ValidSec)
  local timeString = ""
  if ValidSec <= 0 then
    ValidSec = 1
  end
  local WardrobeLogicManager = require("client.slua.logic.wardrobe.logic_wardrobe_new")
  local tmpStr = WardrobeLogicManager:GetTimeStr(ValidSec)
  if tmpStr and tmpStr ~= "" then
    timeString = LocUtil.LocalizeResFormat(2000017, tmpStr)
  end
  return timeString
end

function UI_Pet_Main:UpdatePetExpirationState(_, _)
  for k, v in pairs(self.petTimerHandles) do
    if v.petUpdateHandle then
      self:RemoveTimer(v.petUpdateHandle)
      v.petUpdateHandle = nil
    end
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local petExpireTime = logic_pet:GetPetExpireTime(self.nCurPetItemID)
  local petExpirationSate = logic_pet:GetPetExpirationStateByPetItemID(self.nCurPetItemID)
  if petExpireTime ~= nil then
    self.petTimerHandles[self.nCurPetItemID] = self.petTimerHandles[self.nCurPetItemID] or {}
    if self.petTimerHandles[self.nCurPetItemID].petExpirationHandle then
      self:RemoveTimer(self.petTimerHandles[self.nCurPetItemID].petExpirationHandle)
    end
    self.UIRoot.WidgetSwitcher_PetExpiration:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.WidgetSwitcher_PetExpiration:SetActiveWidgetIndex(1)
    local valid_sec = petExpireTime - TimeUtil.GetServerTimeInSec()
    if 0 < valid_sec then
      local RemainTimeStr = _GetRemainTimeString(valid_sec)
      self.UIRoot.PetLimitedTime:SetText(RemainTimeStr)
      local nPetID = self.nCurPetItemID
      self.petTimerHandles[self.nCurPetItemID].petExpirationHandle = self:AddTimerOnce(valid_sec + 1, function()
        if self.nCurPetItemID and nPetID ~= self.nCurPetItemID then
          logic_pet:get_pet_data_req()
        end
      end)
      self.petTimerHandles[self.nCurPetItemID].petUpdateHandle = self:AddTimer(0, function()
        while true do
          if self and self.UIRoot and slua.isValid(self.UIRoot) then
            local new_valid_sec = petExpireTime - TimeUtil.GetServerTimeInSec()
            if 0 < new_valid_sec then
              local countDownDressRemainTimeStr = _GetRemainTimeString(new_valid_sec)
              self.UIRoot.PetLimitedTime:SetText(countDownDressRemainTimeStr)
              coroutine.yield(59)
            else
              break
            end
          end
        end
      end)
    else
      logic_pet:get_pet_data_req()
      self.UIRoot.WidgetSwitcher_PetExpiration:SetActiveWidgetIndex(0)
    end
  elseif petExpirationSate == logic_pet.Enum_PetExpirationState.EnumExpired then
    self.UIRoot.WidgetSwitcher_PetExpiration:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.Expired:SetText(LocUtil.GetLocalizeResStr(433021))
    self.UIRoot.WidgetSwitcher_PetExpiration:SetActiveWidgetIndex(0)
  else
    self.UIRoot.WidgetSwitcher_PetExpiration:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_Pet_Main:UpdateDressExpirationState(_, _)
  for k, v in pairs(self.petTimerHandles) do
    if v.dressUpdateHandle then
      self:RemoveTimer(v.dressUpdateHandle)
      v.dressUpdateHandle = nil
    end
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local dressExpireTime = logic_pet:GetDressExpireTime(self.nCurPetInsID, self.nCurDressItemID)
  if dressExpireTime ~= nil then
    self.petTimerHandles[self.nCurPetItemID] = self.petTimerHandles[self.nCurPetItemID] or {}
    if self.petTimerHandles[self.nCurPetItemID].dressExpirationHandle then
      self:RemoveTimer(self.petTimerHandles[self.nCurPetItemID].dressExpirationHandle)
    end
    local valid_sec = dressExpireTime - TimeUtil.GetServerTimeInSec()
    if 0 < valid_sec then
      self.UIRoot.DressLimitedTime:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      local DressRemainTimeStr = _GetRemainTimeString(valid_sec)
      self.UIRoot.DressLimitedTime:SetText(DressRemainTimeStr)
      self.petTimerHandles[self.nCurPetItemID].dressExpirationHandle = self:AddTimerOnce(valid_sec + 1, function()
        logic_pet:get_pet_data_req()
      end)
      self.petTimerHandles[self.nCurPetItemID].dressUpdateHandle = self:AddTimer(0, function()
        while true do
          if self and self.UIRoot and slua.isValid(self.UIRoot) then
            local new_valid_sec = dressExpireTime - TimeUtil.GetServerTimeInSec()
            if 0 < new_valid_sec then
              local countDownDressRemainTimeStr = _GetRemainTimeString(new_valid_sec)
              self.UIRoot.DressLimitedTime:SetText(countDownDressRemainTimeStr)
              coroutine.yield(59)
            end
          end
        end
      end)
    else
      logic_pet:get_pet_data_req()
      self.UIRoot.DressLimitedTime:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
  else
    self.UIRoot.DressLimitedTime:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_Pet_Main:HasItemDecomposed(_, _, filteredDecomposeList)
  UIManager.ShowUI(UIManager.UI_Config.pet_decompose_notice, filteredDecomposeList)
end

function UI_Pet_Main:HasPetExpired(_, _, expired_pets)
  if expired_pets[self.nCurPetInsID] then
    self:ChoosePet(_, _, self.nCurPetInsID)
  end
  self:ShowExpirationNotice(expired_pets)
end

function UI_Pet_Main:HasDressExpired(_, _, expired_dresses)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if expired_dresses[self.nCurDressItemID] and logic_pet.DressPetMap[self.nCurDressItemID] == self.nCurPetItemID then
    self:UpdateDressList()
    local needDress = logic_pet:GetCurDressItemsByInsID(self.nCurPetInsID) or {}
    if self.bJustShowPet then
      logic_pet:AdjustPetDress(self.BigPetModel, needDress, self.BigPetModel:GetEquipedDress())
    else
      local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
      if ModelDisplayer.GetShowingAvatar() then
        local _pet = ModelDisplayer.GetShowingAvatar():GetPet()
        logic_pet:AdjustPetDress(_pet, needDress, _pet:GetEquipedDress())
      end
    end
  end
  self:ShowExpirationNotice(expired_dresses)
end

function UI_Pet_Main:ChoosePet(_, _, PetInsID)
  log(bWriteLog and "UI_Pet_Main:ChoosePet. " .. tostring(PetInsID))
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  self.nCurPetItemID = logic_pet:ConvertToPetID(PetInsID)
  log(bWriteLog and "  UI_Pet_Main:ChoosePet. self.nCurPetItemID: " .. tostring(self.nCurPetItemID))
  self.nCurPetInsID = PetInsID
  if self.nJumpPetInsId and self.nJumpPetInsId ~= 0 then
    log_tree("[ZH] self.nJumpPetInsId", self.nJumpPetInsId)
    self.nCurPetItemID = logic_pet:ConvertToPetID(self.nJumpPetInsId)
    log(bWriteLog and "  UI_Pet_Main:ChoosePet. self.nCurPetItemID: " .. tostring(self.nCurPetItemID))
    self.nCurPetInsID = self.nJumpPetInsId
    self.nJumpPetInsId = nil
  end
  if self.BigPetModel then
    self.BigPetModel:Destroy()
    self.BigPetModel = nil
  end
  self:AddTimer(0, function()
    local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
    Lobby_camera_manager_module:LevelSequence_Stop()
    self:UpdateCurPet()
    self.LSBActionList:ScrollToItem(1)
    self:UpdateActionList()
    self:UpdateDressList()
    self.LSBDressList:ScrollToItem(1)
    coroutine.yield(TimeTicker.NEXT_FRAME)
    self:OnClickedActionTag(true)
    local curPetDress = logic_pet:GetCurDressItemsByInsID(self.nCurPetInsID)
    if curPetDress and next(curPetDress) then
      self.nCurDressItemID = next(curPetDress)
    else
      self.nCurDressItemID = 0
    end
    local path = logic_pet:GetChooseBtnPic(self.nCurPetItemID)
    if path then
      log(bWriteLog and "[ZH] path: " .. tostring(path))
      self:SetTexture(self.UIRoot.Image_20, path, {sync = false})
    end
    self:UpdatePetExpirationState()
    self.LoopScrollBox_PetCarry:RefreshAllItems()
    self:UpdateEquipPetSlot()
  end)
end

function UI_Pet_Main:OnClickedChoosePrePet()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "[ZH] OnClickedChoosePrePet")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local prePetId = logic_pet:GetPrePetId(self.nCurPetItemID)
  if not prePetId then
    return
  end
  local PetInsID = logic_pet:ConvertToInsID(prePetId, EPetSource.Self)
  self:ChoosePet(nil, nil, PetInsID)
end

function UI_Pet_Main:OnClickedChooseNextPet()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "[ZH] OnClickedChooseNextPet")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local nextPetId = logic_pet:GetNextPetId(self.nCurPetItemID)
  if not nextPetId then
    return
  end
  log(bWriteLog and "[ZH] nextPetId: " .. tostring(nextPetId))
  local PetInsID = logic_pet:ConvertToInsID(nextPetId, EPetSource.Self)
  self:ChoosePet(nil, nil, PetInsID)
end

function UI_Pet_Main:OnClickedActionTag(BlockSound)
  self.UIRoot.PetTips:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self.UIRoot.Dress:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self.UIRoot.Action:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self.UIRoot.WS_ActionBtnBg:SetActiveWidgetIndex(1)
  self.UIRoot.WS_DressBtnBg:SetActiveWidgetIndex(0)
  local petID = self.nCurPetItemID
  if self.ArrayDressList[petID] == nil or next(self.ArrayDressList[petID]) == nil then
    self.UIRoot.WS_ActionBtnBg:SetActiveWidgetIndex(0)
  end
  self.nCurPetActionID = 0
  local _, firstAction = next(self.ArrayActionList)
  if firstAction ~= nil then
    self.nCurPetActionID = firstAction.PetActionID
  end
  self:UpdateActionList()
  self:UpdateCurActionInfo()
  if not BlockSound then
    self:PlayAudio(sound_config.click_v1)
  end
end

function UI_Pet_Main:OnClickedDressAccess()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local DressTimeUrlConfig = logic_pet.DressTimeUrl[self.nCurDressItemID]
  if DressTimeUrlConfig and TimeUtil.UnixTimeBetween(DressTimeUrlConfig.open_time, DressTimeUrlConfig.end_time) == 0 then
    if GlobalData.IsJapanOrKorea() then
      if DressTimeUrlConfig.jump_url and DressTimeUrlConfig.jump_url ~= "" then
        GlobalData.JumpUrl(DressTimeUrlConfig.jump_url)
      else
        local jump_utils = require("client.logic.store.jump_utils")
        jump_utils.OpenJumpModule(BP_ENUM_MODULE_SUPPLY)
      end
    elseif logic_pet.DressTimeUrl[self.nCurDressItemID].jump_url then
      GlobalData.JumpUrl(logic_pet.DressTimeUrl[self.nCurDressItemID].jump_url)
    end
  end
  self:PlayAudio(sound_config.click_v1)
end

function UI_Pet_Main:OnClickedDressTag()
  self:PlayAudio(sound_config.click_v1)
  self.UIRoot.Dress:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self.UIRoot.Action:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self.LSBDressList:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  self.UIRoot.WS_ActionBtnBg:SetActiveWidgetIndex(0)
  self.UIRoot.WS_DressBtnBg:SetActiveWidgetIndex(1)
  self:UpdateDressList()
  self:UpdateCurDressInfo()
  self.LSBDressList:ScrollToItem(1)
end

function UI_Pet_Main:OnRefreshDressListItem(widget, index)
  local itemData = self.LSBDressList:GetItemData(index)
  local common_download_handler = require("client.slua.common.common_download_handler")
  common_download_handler.CreateDownloadUI(PufferConst.ENUM_DownloadType.ODPAK, {
    self.nCurPetItemID,
    itemData.DressItemID
  }, widget.Panel_Download)
  local UIUtil = require("client.common.ui_util")
  self:SetTexture(widget.Img_DressIcon, UIUtil.GetItemBigIcon(itemData.DressItemID), {sync = false})
  if itemData.DressItemID == self.nCurDressItemID then
    widget.Img_Selected:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.Img_Selected:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if ViewedReddot[itemData.DressItemID] == true then
    widget.Img_New:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    if logic_pet.NewDresses and logic_pet.NewDresses[self.nCurPetInsID] and logic_pet.NewDresses[self.nCurPetInsID][itemData.DressItemID] then
      logic_pet.NewDresses[self.nCurPetInsID][itemData.DressItemID] = nil
      local reddotPet = require("client.slua.logic.pet.reddot_pet")
      reddotPet:ClearPetDressReddot(itemData.DressItemID)
    end
  end
  if logic_pet.NewDresses and logic_pet.NewDresses[self.nCurPetInsID] and logic_pet.NewDresses[self.nCurPetInsID][itemData.DressItemID] then
    widget.Img_New:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    ViewedReddot[itemData.DressItemID] = true
  else
    widget.Img_New:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  if self.equipedDress[self.nCurPetInsID] and self.equipedDress[self.nCurPetInsID][itemData.DressItemID] and logic_pet:HasPetIncludeInherit(self.nCurPetInsID) and logic_pet:HasPetDress(self.nCurPetInsID, itemData.DressItemID) then
    widget.Img_Equiped:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    if self.equipedDress[self.nCurPetInsID] then
      self.equipedDress[self.nCurPetInsID][itemData.DressItemID] = nil
    end
    widget.Img_Equiped:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local itemCfg = CDataTable.GetTableData("Item", itemData.DressItemID)
  self:SetTexture(widget.Img_Quality, UIUtil.GetBgQualityPath(itemCfg.ItemQuality), {sync = false})
  self:SetWidgetVisible(widget.CanvasPanel_Disable, false)
  if logic_pet:HasPetDress(self.nCurPetInsID, itemData.DressItemID) then
    widget.CP_DressLock:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    widget.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    if logic_pet:IsPetDressFrozen(self.nCurPetInsID, itemData.DressItemID) then
      self:SetWidgetVisible(widget.CanvasPanel_Disable, true)
      return
    end
  else
    widget.CP_DressLock:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    if itemData.DressNeedLevel == "" or itemData.DressNeedLevel == 0 then
      widget.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    else
      widget.Text_NeedLevel:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      local strLevel = LocUtil.LocalizeResFormat("6417", itemData.DressNeedLevel)
      widget.Text_NeedLevel:SetText(strLevel)
    end
  end
  local bLimitedOwning, expireTime = logic_pet:IsDressTimeLimitedOwning(itemData.DressItemID)
  if bLimitedOwning and expireTime then
    widget.LimitedTime:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  else
    widget.LimitedTime:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function UI_Pet_Main:UpdateDressList()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if logic_pet.NewDresses[self.nCurPetItemID] and next(logic_pet.NewDresses[self.nCurPetItemID]) then
    self.UIRoot.CP_Reddot:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    self.UIRoot.Dress_Reddot:UnBind()
    local GeneralLabReddotData = require("client.slua.logic.lobby.lab.general_lab_reddot_data")
    local PetReddotData = GeneralLabReddotData.GetData(GeneralLabReddotData.ENUM_LAB_SYSTEMS.Companions)
    if PetReddotData and PetReddotData[3] then
      self.UIRoot.Dress_Reddot:Bind(PetReddotData[3])
    end
  else
    self.UIRoot.Dress_Reddot:UnBind()
    self.UIRoot.CP_Reddot:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  self:UpdateCurDressInfo()
  local petID = self.nCurPetItemID
  if self.ArrayDressList[petID] == nil then
    self.ArrayDressList[petID] = {}
    local PetDressCfg = logic_pet:GetPetDressCfg()
    local nowTime = TimeUtil.GetServerTimeInSec()
    for i, v in pairs(PetDressCfg) do
      if petID == v.PetID then
        local dressItemData = {
          PetID = v.PetID,
          DressBPID = v.DressBPID,
          DressItemID = v.DressItemID,
          ActionID = v.ActionID,
          DressNeedLevel = v.DressNeedLevel
        }
        if logic_pet.DressTimeUrl[dressItemData.DressItemID] and logic_pet.DressTimeUrl[dressItemData.DressItemID].launch_time and logic_pet.DressTimeUrl[dressItemData.DressItemID].open_time and logic_pet.DressTimeUrl[dressItemData.DressItemID].end_time and nowTime > logic_pet.DressTimeUrl[dressItemData.DressItemID].launch_time then
          table.insert(self.ArrayDressList[petID], dressItemData)
        end
      end
    end
    
    local function sort(a, b)
      local itemCfgA = CDataTable.GetTableData("Item", a.DressItemID)
      local itemCfgB = CDataTable.GetTableData("Item", b.DressItemID)
      local hasDressA = logic_pet:HasPetDress(self.nCurPetInsID, a.DressItemID)
      local hasDressB = logic_pet:HasPetDress(self.nCurPetInsID, b.DressItemID)
      if hasDressA and not hasDressB then
        return true
      end
      if hasDressB and not hasDressA then
        return false
      end
      if hasDressB == hasDressA then
        return itemCfgA.ItemQuality > itemCfgB.ItemQuality
      end
      return true
    end
    
    table.sort(self.ArrayDressList[petID], sort)
    self.LSBDressList:SetData(self.ArrayDressList[petID])
  end
  self.LSBDressList:SetData(self.ArrayDressList[petID])
  self:RefreshDressAccessButton(self.nCurDressItemID)
  if next(self.ArrayDressList[petID]) == nil then
    self.UIRoot.Btn_Dress:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    self.UIRoot.Btn_Dress:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
  end
end

function UI_Pet_Main:OnClickedDressItem(widget, index)
  log(bWriteLog and string.format("[debug][pet][action] UI_Pet_Main:OnClickedDressItem. widget=%s, index=%s", tostring(widget), tostring(index)))
  local itemData = self.LSBDressList:GetItemData(index)
  local itemID = self.nCurDressItemID
  self.nCurDressItemID = itemData.DressItemID
  self:PlayAudio(sound_config.click_v1)
  if not self.BigPetModel or not self.BigPetModel.AlreadyDownload then
    return
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, logic_pet:GetDownloadList(self.nCurDressItemID))
  if state ~= PufferConst.ENUM_DownloadState.Done then
    PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, {
      self.nCurDressItemID
    }, PufferTlog.Enum_TLog_From.Pet, nil, {bAutoDownload = false})
    ShowNotice(33650)
    return
  end
  if logic_pet.NewDresses and logic_pet.NewDresses[self.nCurPetItemID] and logic_pet.NewDresses[self.nCurPetItemID][itemData.DressItemID] then
    widget.Img_New:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    logic_pet.NewDresses[self.nCurPetItemID][itemData.DressItemID] = nil
    local reddotPet = require("client.slua.logic.pet.reddot_pet")
    reddotPet:ClearPetDressReddot(itemData.DressItemID)
  end
  local realPutOn = false
  local realPutOff = false
  self.equipedDress[self.nCurPetInsID] = self.equipedDress[self.nCurPetInsID] or {}
  if logic_pet:HasPetIncludeInherit(self.nCurPetInsID) and logic_pet:HasPetDress(self.nCurPetInsID, itemData.DressItemID) then
    if logic_pet:IsPetDressFrozen(self.nCurPetInsID, self.nCurDressItemID) then
      ShowNotice(3000016)
      return
    end
    if logic_pet:IsInDress(self.nCurPetInsID, itemData.DressItemID) and itemID == self.nCurDressItemID then
      logic_pet:pet_unload_dress_req(self.nCurPetInsID, itemData.DressItemID)
      self.equipedDress[self.nCurPetInsID][itemData.DressItemID] = nil
      realPutOff = true
      tlog_report_utils.ReportTLogEvent(TLogEventDefine.PetPutOffDress, itemData.DressItemID, "Put_off_dress_" .. tostring(itemData.DressItemID))
    else
      logic_pet:pet_used_dress_req(self.nCurPetInsID, itemData.DressItemID)
      self.equipedDress[self.nCurPetInsID][itemData.DressItemID] = true
      realPutOn = true
      tlog_report_utils.ReportTLogEvent(TLogEventDefine.PetPutOnDress, itemData.DressItemID, "Put_on_dress_" .. tostring(itemData.DressItemID))
    end
  end
  self:RefreshDressAccessButton(itemData.DressItemID)
  self:UpdateCurDressInfo()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local SmallPet = ModelDisplayer.GetShowingAvatar():GetPet()
  local SmallPetActor = SmallPet and SmallPet:GetModel()
  if not realPutOn then
    local BigPetActor = self.BigPetModel:GetModel()
    if slua.isValid(BigPetActor) then
      BigPetActor:DestroyPetPermanentParticle()
    end
    if slua.isValid(SmallPetActor) then
      SmallPetActor:DestroyPetPermanentParticle()
    end
  end
  if not (self.lastRealPutOn or self.lastRealPutOff) or not realPutOn and not realPutOff then
    self.BigPetModel:PutOnOrPutOff(self.nCurDressItemID)
    if SmallPet then
      SmallPet:PutOnOrPutOff(self.nCurDressItemID)
    end
  end
  self.lastRealPutOn = realPutOn
  self.lastRealPutOff = realPutOff
  self.LSBDressList:RefreshAllItems(self.ArrayDressList[self.nCurPetItemID])
  if self.DelayRefreshDressTimer then
    self:RemoveTimer(self.DelayRefreshDressTimer)
    self.DelayRefreshDressTimer = nil
  end
  self.DelayRefreshDressTimer = self:AddTimerOnce(0.3, function()
    self:OnPetDressChange(false)
  end)
end

function UI_Pet_Main:RefreshDressAccessButton(itemID)
  log(bWriteLog and "UI_Pet_Main:RefreshDressAccessButton. itemID: " .. tostring(itemID))
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if logic_pet:HasPetDress(self.nCurPetInsID, itemID) or self.nCurDressItemID == 0 then
    self.UIRoot.DressAccess:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  else
    local nowTime = TimeUtil.GetServerTimeInSec()
    self.UIRoot.DressAccess:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
    if logic_pet.DressTimeUrl[itemID] and logic_pet.DressTimeUrl[itemID].open_time and logic_pet.DressTimeUrl[itemID].end_time and TimeUtil.UnixTimeBetween(logic_pet.DressTimeUrl[itemID].open_time, logic_pet.DressTimeUrl[itemID].end_time) == 0 and logic_pet.DressTimeUrl[itemID].jump_url and logic_pet.DressTimeUrl[itemID].jump_url ~= "" then
      self.WS_DressAccess:SetActiveWidgetIndex(0)
    else
      self.WS_DressAccess:SetActiveWidgetIndex(1)
    end
  end
end

function UI_Pet_Main:OnPressDressItem(widget, index)
  local itemData = self.LSBDressList:GetItemData(index)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if logic_pet:HasPetDress(self.nCurPetInsID, itemData) then
    local UIUtil = require("client.common.ui_util")
    UIUtil.ShowItemTips(itemData.DressItemID, widget, FVector2D(0, 0), logic_pet:GetDressExpireTime(self.nCurPetInsID, itemData.DressItemID))
  else
    local UIUtil = require("client.common.ui_util")
    UIUtil.ShowItemTips(itemData.DressItemID, widget)
  end
end

function UI_Pet_Main:OnReleasedDressItem(widget, index)
  local UIUtil = require("client.common.ui_util")
  UIUtil.CloseItemTips()
end

function UI_Pet_Main:OnSystemClosed()
  local content = LocUtil.LocalizeResFormat(6891)
  ShowNotice(content)
  self:CloseSelf()
end

function UI_Pet_Main:OnGetPetData()
  self:OnPetDressChange(false)
  self:UpdateCurPetBtn()
end

function UI_Pet_Main:OnPetDressChange(bRefreshModel, _, _)
  log(bWriteLog and "UI_Pet_Main:OnPetDressChange")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local data = logic_pet:GetPetDataByInsID(self.nCurPetInsID)
  self.equipedDress[self.nCurPetInsID] = {}
  if data and data.dress then
    for itemID, _ in pairs(data.dress) do
      self.equipedDress[self.nCurPetInsID][itemID] = true
    end
  end
  self:UpdateActionList()
  self:UpdateDressList()
  if bRefreshModel then
    self:UpdateCurPetModel()
  end
end

function UI_Pet_Main:OnClickedAttachedAction()
  self:PlayAudio(sound_config.click_v1)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local DressActionMap = logic_pet:GetDressActionMap()
  local DressAttachedActionCfg = DressActionMap[self.nCurDressItemID]
  if not DressAttachedActionCfg and not DressAttachedActionCfg.PetActionID then
    return
  end
  local DressAttachedActionID = DressAttachedActionCfg.PetActionID
  local actionCfg = CDataTable.GetTableData("PetActionTable", DressAttachedActionCfg.PetActionID)
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  if self.bJustShowPet then
    if not self.BigPetModel:HasEquiped(self.nCurDressItemID) then
      ShowNotice(32531)
      return
    end
    self.BigPetModel:StopAction()
    self:PlayActionByBtn(DressAttachedActionID)
    if actionCfg and actionCfg.PetLevelSequence and actionCfg.PetLevelSequence ~= "" then
      Lobby_camera_manager_module:LevelSequence_Stop()
      Lobby_camera_manager_module:LevelSequence_Play(actionCfg.PetLevelSequence)
    end
  else
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    local SmallPet = ModelDisplayer.GetShowingAvatar():GetPet()
    if SmallPet and not SmallPet:HasEquiped(self.nCurDressItemID) then
      ShowNotice(32531)
      return
    end
    ModelDisplayer.GetShowingAvatar():StopPetAction()
    ModelDisplayer.GetShowingAvatar():PlayPetAction(DressAttachedActionID)
    if actionCfg and actionCfg.MasterLevelSequence and actionCfg.MasterLevelSequence ~= "" then
      Lobby_camera_manager_module:LevelSequence_Stop()
      Lobby_camera_manager_module:LevelSequence_Play(actionCfg.MasterLevelSequence)
    end
  end
end

function UI_Pet_Main:PlayPetBGM()
  local SettingConfig = slua_GameFrontendHUD:GetUserSettings()
  if SettingConfig.BGMVolumSwitcher then
    self:PlayMusic(1000002)
  end
end

function UI_Pet_Main:StopPetBGM()
end

function UI_Pet_Main:GetDataForJumpBack()
  return {
    ctorData = {
      [1] = self.nCurPetItemID
    }
  }
end

function UI_Pet_Main:ShowExpirationNotice(expiredItems)
  for id, _ in pairs(expiredItems) do
    local itemName = CDataTable.GetTableData("Item", id).ItemName
    ShowNotice(LocUtil.LocalizeResFormat(33238, itemName))
  end
end

function UI_Pet_Main:OnApplicationReactivated()
end

function UI_Pet_Main:ShowOfflineExpiredPets()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if not logic_pet.HasPetExpiredOffline and not logic_pet.HasDressExpiredOffline then
    return
  end
  local expiredPets = logic_pet.ExpiredPetsOffline
  local expiredDresses = logic_pet.ExpiredDressesOffline
  logic_pet.HasPetExpiredOffline = false
  logic_pet.HasDressExpiredOffline = false
  self:ShowExpirationNotice(expiredPets)
  self:ShowExpirationNotice(expiredDresses)
end

function UI_Pet_Main:SelectActionByIndex(index)
  log(bWriteLog and "  UI_Pet_Main:SelectActionByIndex. index: " .. tostring(index))
  local itemData = self.LSBActionList:GetItemData(index)
  if not itemData then
    log_error("UI_Pet_Main:SelectActionByIndex itemData is nil, but which is impossible")
    return
  end
  local actionCfg = CDataTable.GetTableData("PetActionTable", itemData.PetActionID)
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  if self.bJustShowPet then
    if self.BigPetModel then
      if self.nCurPetActionID ~= itemData.PetActionID then
        self.BigPetModel:StopAction()
      end
      self.BigPetModel:PlayAction(itemData.PetActionID)
    end
    if actionCfg and actionCfg.PetLevelSequence and actionCfg.PetLevelSequence ~= "" then
      Lobby_camera_manager_module:LevelSequence_Stop()
      Lobby_camera_manager_module:LevelSequence_Play(actionCfg.PetLevelSequence)
    end
  else
    if self.nCurPetActionID ~= itemData.PetActionID then
      ModelDisplayer.GetShowingAvatar():StopPetAction()
    end
    ModelDisplayer.GetShowingAvatar():PlayPetAction(itemData.PetActionID)
    if actionCfg and actionCfg.MasterLevelSequence and actionCfg.MasterLevelSequence ~= "" then
      Lobby_camera_manager_module:LevelSequence_Stop()
      Lobby_camera_manager_module:LevelSequence_Play(actionCfg.MasterLevelSequence)
    end
  end
  self.nCurPetActionID = itemData.PetActionID
  self.LSBActionList:Select(index)
  self:UpdateCurActionInfo()
end

function UI_Pet_Main:OnLevelUp(_, _, data)
  log(bWriteLog and "[levelup] UI_Pet_Main:OnLevelUp data.PetID: " .. tostring(data.PetID) .. " self.nCurPetItemID: " .. tostring(self.nCurPetItemID))
  if data.PetID == self.nCurPetItemID and tostring(data.UID) == tostring(DataMgr.roleData.uid) then
    self:SelectActionByIndex(1)
  end
end

function UI_Pet_Main:UpdateCarryPets()
  if not self.LoopScrollBox_PetCarry then
    return
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  self.LoopScrollBox_PetCarry:SetData(logic_pet:GetCurrentCarryPets())
end

function UI_Pet_Main:OnClickedChangeCarryPets()
  self:PlayAudio(sound_config.click_v1)
  local logic_pet_privilege_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pet_privilege_guide)
  logic_pet_privilege_guide:SetGuideHasShown(logic_pet_privilege_guide.Enum_PetGuideType.Share, 1)
  self:_UpdateSharePrivilegeGuide()
  if UIManager then
    UIManager.ShowUIWithCheckLight(UIManager.UI_Config.pet_carry_select)
  end
end

function UI_Pet_Main:GetCurPetInsID()
  return self.nCurPetInsID
end

function UI_Pet_Main:OnCarryPetListChanged()
  self:UpdateCarryPets()
end

function UI_Pet_Main:OnClickedPetEnlarge()
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.PetChangeSize) then
    return
  end
  if self.bJustShowPet then
    if self.BigPetModel then
      self.BigPetModel:ChangePetEnlargingStateDirect()
    end
  else
    local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
    ModelDisplayer.GetShowingAvatar():PlayEnlargeAction()
  end
end

function UI_Pet_Main:OnPetDressTimeInfoChange(_, _)
  self:InvalidatePetDressListCache()
end

function UI_Pet_Main:InvalidatePetDressListCache()
  self.ArrayDressList = {}
end

function UI_Pet_Main:UpdateEquipPetSlot()
  log(bWriteLog and "UI_Pet_Main:UpdateEquipPetSlot. ")
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  self.Equip_Pet_Item:SetData(logic_pet:GetEquipedPetInsID(), self:GetCurPetInsID())
end

function UI_Pet_Main:CheckAndShowGuide()
  self:_UpdateSharePrivilegeGuide()
  self:_UpdateSlotPrivilegeGuide()
end

function UI_Pet_Main:_UpdateSharePrivilegeGuide()
  local logic_pet_privilege_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pet_privilege_guide)
  if logic_pet_privilege_guide:IsCanShowGuide(logic_pet_privilege_guide.Enum_PetGuideType.Share, 1) then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_ShareTips, true, false)
    self.UIRoot.TextBlock_ShareTips:SetText(LocUtil.GetLocalizeResStr(76835))
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_ShareTips, false, false)
  end
end

function UI_Pet_Main:_UpdateSlotPrivilegeGuide()
  if self._autoClearSlotTipTimer then
    self:RemoveTimer(self._autoClearSlotTipTimer)
    self._autoClearSlotTipTimer = nil
  end
  local logic_pet_privilege_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pet_privilege_guide)
  if logic_pet_privilege_guide:IsCanShowGuide(logic_pet_privilege_guide.Enum_PetGuideType.Slot, 1) then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_SlotTips, true, false)
    self.UIRoot.TextBlock_10:SetText(LocUtil.GetLocalizeResStr(76840))
    self._autoClearSlotTipTimer = self:AddTimer(2.5, function()
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_SlotTips, false, false)
      logic_pet_privilege_guide:SetGuideHasShown(logic_pet_privilege_guide.Enum_PetGuideType.Slot, 1)
    end)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_SlotTips, false, false)
  end
end

function UI_Pet_Main:OnSlotItemClicked()
  self:ClearSlotGuide()
end

function UI_Pet_Main:ClearSlotGuide()
  local logic_pet_privilege_guide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pet_privilege_guide)
  if logic_pet_privilege_guide:IsCanShowGuide(logic_pet_privilege_guide.Enum_PetGuideType.Slot, 1) then
    logic_pet_privilege_guide:SetGuideHasShown(logic_pet_privilege_guide.Enum_PetGuideType.Slot, 1)
  end
  self:_UpdateSlotPrivilegeGuide()
end

function UI_Pet_Main:SwitchToNormal()
  self.UIRoot.WidgetSwitcher_Content:SetActiveWidgetIndex(0)
end

function UI_Pet_Main:SwitchToPortal()
  self.UIRoot.WidgetSwitcher_Content:SetActiveWidgetIndex(1)
  self.bIsInPortalSubUI = true
  if not self.portalUI then
    self.portalUI = self:CreateChildWindow(self.UIRoot.CanvasPanel_Portal, UIManager.UI_Config.Pet_Portal_UIBP)
  end
  self.portalUI:PlaySwitchEffect()
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local equipedPet = logic_pet:HasEquipedPet()
  local equipedPetResID = logic_pet:ConvertToPetID(equipedPet)
  if equipedPet and logic_pet:IsNotGyrfalcon(equipedPetResID) then
    self:ChoosePet(nil, nil, equipedPet)
  else
    if self.BigPetModel then
      self.BigPetModel:StopAction()
      self.BigPetModel:Release()
    end
    local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
    Lobby_camera_manager_module:LevelSequence_Stop()
  end
end

function UI_Pet_Main:ExitPortal()
  self.bIsInPortalSubUI = false
  if self.extraParam and self.extraParam.bOpenPortal then
    self:CloseSelf()
  else
    self:SwitchToNormal()
    local diff
    local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
    local equipedPet = logic_pet:HasEquipedPet()
    local equipedPetResID = logic_pet:ConvertToPetID(equipedPet)
    if not equipedPet or not logic_pet:IsNotGyrfalcon(equipedPetResID) then
      diff = true
    end
    self:UpdateCurPetModel(diff)
  end
end

function UI_Pet_Main:GetBigModel()
  if not self.BigPetModel then
    return
  end
  return self.BigPetModel:GetModel()
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CUIPet_Main = class(ui_base, nil, UI_Pet_Main)
return CUIPet_Main
