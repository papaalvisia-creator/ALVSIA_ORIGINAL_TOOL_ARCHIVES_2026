local LogicCollectionUpload = require("client.slua.logic.ugc.PrefabMall.LogicUGCPrefabMallCollectionUpload")
local Util_UGC = require("client.slua.logic.ugc.util_ugc")
local PrefabMallConfig = require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_config")
local UgcCustomPhotoHelper = require("client.slua.umg.ugc.creator.personal.UgcCustomPhotoHelper")
local CreativeModePrefabMallUploadCollectionUI = {}

function CreativeModePrefabMallUploadCollectionUI:ctor(_, CollectionData)
  self.CurAssetFilterIndex = 1
  self.CurAssetType = nil
  self.CollectionData = CollectionData
  self.CollectionId = CollectionData and CollectionData.id or nil
  self.Name = CollectionData and CollectionData.name or ""
  self.Desc = CollectionData and CollectionData.desc or ""
end

function CreativeModePrefabMallUploadCollectionUI:OnInitialize()
  self.logic_ugc_prefab_mall = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_ugc_prefab_mall)
  self.UIRoot.Common_UGC_Popup_Large_UIBP_0.close:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
  self.UIRoot.Common_UGC_Popup_Large_UIBP_0.Title:SetText(LocUtil.GetLocalizeResStr(2026034016))
  self.ResourceLoopScrollGrid = self:InitChildClassScrollBox(self.UIRoot.LoopScrollGrid_Resources, "client.slua.umg.ugc.lobby.UGCPrefabMall.Item.CreativeModePrefabMallUploadCollectionResourceItem")
  self.AssetFilterBox = self:InitCommonComboBoxNew(self.UIRoot.Common_ComboBox_UIBP, nil, true)
  local ExistCoverUrl = self.CollectionData and self.CollectionData.cover_url
  self.CoverImageUrl = ExistCoverUrl ~= nil and ExistCoverUrl ~= "" and ExistCoverUrl or nil
  if self.CollectionData and self.CollectionData.prefab_id_list then
    LogicCollectionUpload:SetSelectedPrefabIdList(self.CollectionData.prefab_id_list)
  end
  self.UIRoot.Input_Title:SetHintText(LocUtil.GetLocalizeResStr(2026034023))
  self.UIRoot.MultiLineEditableText_Dec:SetHintText(LocUtil.GetLocalizeResStr(2026034024))
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBLUEHOLE() then
    self.UIRoot.CanvasPanel_EditCover:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
end

function CreativeModePrefabMallUploadCollectionUI:GetNameControl()
  return self.UIRoot.Input_Title
end

function CreativeModePrefabMallUploadCollectionUI:GetDescControl()
  return self.UIRoot.MultiLineEditableText_Dec
end

function CreativeModePrefabMallUploadCollectionUI:GetDescCurrentLenControl()
  return self.UIRoot.TextBlock_DecCurrentLen
end

function CreativeModePrefabMallUploadCollectionUI:GetDescMaxLenControl()
  return self.UIRoot.TextBlock_DecMaxLen
end

function CreativeModePrefabMallUploadCollectionUI:GetMaxDescLen()
  return 100
end

function CreativeModePrefabMallUploadCollectionUI:RegistEvents()
  CreativeModePrefabMallUploadCollectionUI.__super.RegistEvents(self)
  self:AddOnClickedEventByControl(self.UIRoot.Common_UGC_Popup_Large_UIBP_0.close, self.OnClickButtonClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ChangeCover, self.OnClickButtonChangeCover, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Save, self.OnClickButtonSave, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Release, self.OnClickButtonRelease, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Delete, self.OnClickButtonDelete, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_CREATIVE_PREFAB_MALL_COLLECTION_UPLOAD_SELECT_UPDATE, self.RefreshResourceList, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_META_SILENT_UPDATES, self.RefreshResourceList, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_PRIVATE_META_UPDATES, self.RefreshResourceList, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_MINE_SHOW_COLLECTION_UPLOAD_SELECT, self.OnRequestShowResourceSelect, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_PREFAB_MALL_MINE_RETURN_DISPLAY_STATE, self.OnReturnFromResourceSelect, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_CREATIVE_PREFAB_MALL_COLLECTION_SAVE_RSP, self.OnSaveCollectionRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_CREATIVE_PREFAB_MALL_COLLECTION_PUBLISH_RSP, self.OnPublishCollectionRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_CREATIVE_PREFAB_MALL_COLLECTION_DELETE_RSP, self.OnDeleteCollectionRsp, self)
  self.AssetFilterBox:SetSelectOptionCallback(self.OnSelectAssetFilterBox, self)
end

function CreativeModePrefabMallUploadCollectionUI:OnPostInitialize()
  CreativeModePrefabMallUploadCollectionUI.__super.OnPostInitialize(self)
  self:RefreshAssetFilterBox()
  self:RefreshResourceList()
  self:RefreshCoverUI()
  self:RefreshSaveReleaseButtonState()
  self:RefreshDeleteButtonState()
  self.InitEditSnapshot = self:BuildEditSnapshot()
end

function CreativeModePrefabMallUploadCollectionUI:OnClose()
  LogicCollectionUpload:ClearSelection()
  self.logic_ugc_prefab_mall = nil
  self.ResourceLoopScrollGrid = nil
  self.AssetFilterBox = nil
  self.CoverImageUrl = nil
  self.bPendingCreate = nil
  self.InitEditSnapshot = nil
end

function CreativeModePrefabMallUploadCollectionUI:BuildEditSnapshot()
  local PrefabIdList = LogicCollectionUpload:GetSelectedPrefabIdList()
  table.sort(PrefabIdList, function(A, B)
    return tostring(A) < tostring(B)
  end)
  return {
    Name = tostring(self:GetNameControl():GetText() or ""),
    Desc = tostring(self:GetDescControl():GetText() or ""),
    Cover = self.CoverImageUrl and tostring(self.CoverImageUrl) or "",
    Ids = table.concat(PrefabIdList, ",")
  }
end

function CreativeModePrefabMallUploadCollectionUI:HasUnsavedChanges()
  if not self:IsEditable() or not self.InitEditSnapshot then
    return false
  end
  local Cur = self:BuildEditSnapshot()
  local Init = self.InitEditSnapshot
  return Cur.Name ~= Init.Name or Cur.Desc ~= Init.Desc or Cur.Cover ~= Init.Cover or Cur.Ids ~= Init.Ids
end

function CreativeModePrefabMallUploadCollectionUI:OnClickButtonClose()
  self:PlayAudio(sound_config.close_v1)
  if not self:HasUnsavedChanges() then
    self:CloseSelf()
    return
  end
  local Title = LocUtil.GetLocalizeResStr(5077)
  local Msg = LocUtil.GetLocalizeResStr(2026034029)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, Title, Msg, function()
    if self and slua.isValid(self.UIRoot) then
      self:CloseSelf()
    end
  end)
end

function CreativeModePrefabMallUploadCollectionUI:OnRequestShowResourceSelect()
  self:Collapsed()
end

function CreativeModePrefabMallUploadCollectionUI:OnReturnFromResourceSelect()
  self:Show()
end

function CreativeModePrefabMallUploadCollectionUI:OnClickButtonChangeCover()
  local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
  if PublishRegionMacros.IsBLUEHOLE() then
    return
  end
  self:PlayAudio(sound_config.click_v1)
  if not self:IsEditable() then
    return
  end
  
  local function UploadCallback(pic_url, thumb_url)
    if not slua.isValid(self.UIRoot) then
      return
    end
    self.CoverImageUrl = thumb_url or pic_url
    self:RefreshCoverUI()
  end
  
  UgcCustomPhotoHelper.PickImageAndOpenEditPanel(nil, nil, UploadCallback)
end

function CreativeModePrefabMallUploadCollectionUI:OnSelectAssetFilterBox(_, data, index)
  self:PlayAudio(sound_config.click_v1)
  if self.CurAssetFilterIndex == index then
    return
  end
  self.CurAssetFilterIndex = index
  self.CurAssetType = data.Type
  self:RefreshResourceList()
end

function CreativeModePrefabMallUploadCollectionUI:CheckCanSave()
  if not self:IsEditable() then
    return true
  end
  if not self:ConfirmNameAndDesc() then
    return true
  end
  local PrefabIdList = LogicCollectionUpload:GetSelectedPrefabIdList()
  if not PrefabIdList or #PrefabIdList == 0 then
    ShowNotice(LocUtil.GetLocalizeResStr(2026034020))
    return true
  end
end

function CreativeModePrefabMallUploadCollectionUI:OnClickButtonSave()
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.PrefabMallCollectionSave, true) then
    return
  end
  if not self.CollectionData then
    self:TLogReportCollectionAction(TLogEventDefine.UGC_PrefabMall_Collection_Create_Save_Click)
  end
  if self:CheckCanSave() then
    return
  end
  local PrefabIdList = LogicCollectionUpload:GetSelectedPrefabIdList()
  self.bPendingCreate = self.CollectionId == nil
  local CoverUrl = self.CoverImageUrl and tostring(self.CoverImageUrl) or ""
  local logic_ugc_prefab_mall_official = require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_official")
  if self.CollectionId then
    logic_ugc_prefab_mall_official:ReqModifyCollection(self.CollectionId, self.Name, self.Desc, CoverUrl, PrefabIdList)
  else
    logic_ugc_prefab_mall_official:ReqCreateCollection(self.Name, self.Desc, CoverUrl, PrefabIdList)
  end
end

function CreativeModePrefabMallUploadCollectionUI:OnClickButtonRelease()
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.PrefabMallCollectionRelease, true) then
    return
  end
  local State = self.CollectionData and self.CollectionData.state
  if not self.CollectionData then
    self:TLogReportCollectionAction(TLogEventDefine.UGC_PrefabMall_Collection_Create_Upload_Click)
  elseif State == PrefabMallConfig.ECollectionState.DRAFT then
    self:TLogReportCollectionAction(TLogEventDefine.UGC_PrefabMall_Collection_Draft_Upload_Click)
  end
  if self:CheckCanSave() then
    return
  end
  if not self.CollectionId then
    ShowNotice(LocUtil.GetLocalizeResStr(2026034018))
    return
  end
  local logic_ugc_prefab_mall_official = require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_official")
  logic_ugc_prefab_mall_official:ReqPublishCollection(self.CollectionId)
end

function CreativeModePrefabMallUploadCollectionUI:OnClickButtonDelete()
  self:PlayAudio(sound_config.click_v1)
  local UIUtil = require("client.common.ui_util")
  if not UIUtil.CanClickNow(UIUtil.ClickFrequencyLimit.PrefabMallCollectionDelete, true) then
    return
  end
  if not self:IsDeletable() then
    return
  end
  local State = self.CollectionData and self.CollectionData.state
  if State == PrefabMallConfig.ECollectionState.REJECT then
    self:TLogReportCollectionAction(TLogEventDefine.UGC_PrefabMall_Collection_Reject_Delete_Click)
  end
  local Title = LocUtil.GetLocalizeResStr(5077)
  local Msg = LocUtil.GetLocalizeResStr(2026034028)
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(CommonMsgBoxMgr.SHOW_TYPE_TWO, Title, Msg, function()
    if not (self and slua.isValid(self.UIRoot)) or not self.CollectionId then
      return
    end
    local logic_ugc_prefab_mall_official = require("client.slua.logic.ugc.PrefabMall.logic_ugc_prefab_mall_official")
    logic_ugc_prefab_mall_official:ReqDeleteCollection(self.CollectionId)
  end)
end

function CreativeModePrefabMallUploadCollectionUI:OnSaveCollectionRsp(_, _, ErrCode, PrefabCollectionId)
  local bPendingCreate = self.bPendingCreate
  self.bPendingCreate = nil
  if ErrCode ~= 0 then
    return
  end
  if PrefabCollectionId then
    self.CollectionId = PrefabCollectionId
  end
  if bPendingCreate then
    ShowNotice(LocUtil.GetLocalizeResStr(2026034021))
    self:CloseSelf()
    return
  end
  ShowNotice(LocUtil.GetLocalizeResStr(2026034022))
  self:CloseSelf()
end

function CreativeModePrefabMallUploadCollectionUI:OnPublishCollectionRsp(_, _, ErrCode, PrefabCollectionId)
  if not (ErrCode == 0 and self.CollectionId) or PrefabCollectionId ~= self.CollectionId then
    return
  end
  ShowNotice(LocUtil.GetLocalizeResStr(2026034025))
  self:CloseSelf()
end

function CreativeModePrefabMallUploadCollectionUI:OnDeleteCollectionRsp(_, _, ErrCode, PrefabCollectionId)
  if not (ErrCode == 0 and self.CollectionId) or PrefabCollectionId ~= self.CollectionId then
    return
  end
  self:CloseSelf()
end

function CreativeModePrefabMallUploadCollectionUI:TLogReportCollectionAction(EventId)
  if not self.logic_ugc_prefab_mall then
    return
  end
  self.logic_ugc_prefab_mall:TLogReportCollectionAction(EventId, self.CollectionId)
end

function CreativeModePrefabMallUploadCollectionUI:RefreshAssetFilterBox()
  local displayConfig = {
    {
      Text = PrefabMallConfig.TypeNameConfig.All,
      AssetType = nil
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.Prefab,
      AssetType = PrefabMallConfig.EAssetType.PREFAB
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.Code,
      AssetType = PrefabMallConfig.EAssetType.CODE
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.Anim,
      AssetType = PrefabMallConfig.EAssetType.ANIM
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.Sound,
      AssetType = PrefabMallConfig.EAssetType.SOUND
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.Image,
      AssetType = PrefabMallConfig.EAssetType.IMAGE
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.CustomUI,
      AssetType = PrefabMallConfig.EAssetType.CUSTOMUI
    },
    {
      Text = PrefabMallConfig.TypeNameConfig.StaticMesh,
      AssetType = PrefabMallConfig.EAssetType.STATICMESH
    }
  }
  local comboBoxData = {}
  for _, config in ipairs(displayConfig) do
    table.insert(comboBoxData, {
      text = LocUtil.GetLocalizeResStr(config.Text),
      Type = config.AssetType
    })
  end
  self.CurAssetFilterIndex = 1
  self.CurAssetType = nil
  self.AssetFilterBox:SetData(comboBoxData, self.CurAssetFilterIndex, true)
end

function CreativeModePrefabMallUploadCollectionUI:RefreshResourceList()
  if not self.ResourceLoopScrollGrid or not self.logic_ugc_prefab_mall then
    return
  end
  local ShowList = {
    {IsUploadItem = true}
  }
  local PrefabIdList = LogicCollectionUpload:GetSelectedPrefabIdList()
  if PrefabIdList and next(PrefabIdList) then
    local MetaList = self.logic_ugc_prefab_mall:GetPrefabMetaList(PrefabIdList, true)
    for _, Meta in ipairs(MetaList) do
      if not self.CurAssetType or Meta.Meta and Meta.Meta.PrefabType == self.CurAssetType then
        table.insert(ShowList, Meta)
      end
    end
  end
  self.ResourceLoopScrollGrid:SetData(ShowList)
  self.UIRoot.TextBlock_Resources:SetText(LocUtil.GetLocalizeResStr(7752))
  if not LocUtil.IsClientTextMirror() then
    self.UIRoot.WidgetSwitcher_Translate:SetActiveWidgetIndex(0)
    self.UIRoot.TextBlock_ResourcesCurrentLen:SetText(tostring(LogicCollectionUpload:GetCount()))
    self.UIRoot.TextBlock_ResourcesArgue:SetText("/")
    self.UIRoot.TextBlock_ResourcesMaxLen:SetText(tostring(LogicCollectionUpload:GetMaxCount()))
  else
    self.UIRoot.WidgetSwitcher_Translate:SetActiveWidgetIndex(1)
    self.UIRoot.TextBlock_ResourcesCurrentLen01:SetText(tostring(LogicCollectionUpload:GetCount()))
    self.UIRoot.TextBlock_ResourcesArgue01:SetText("/")
    self.UIRoot.TextBlock_ResourcesMaxLen01:SetText(tostring(LogicCollectionUpload:GetMaxCount()))
  end
  self.UIRoot.TextBlock_ChangeCover:SetText(LocUtil.GetLocalizeResStr(64774))
end

function CreativeModePrefabMallUploadCollectionUI:RefreshCoverUI()
  if not self.UIRoot.WidgetSwitcher_CoverImage then
    return
  end
  if self.CoverImageUrl then
    self.UIRoot.WidgetSwitcher_CoverImage:SetActiveWidgetIndex(1)
    Util_UGC.SetUGCImage(self, self.UIRoot.Image_Cover, self.CoverImageUrl, true)
  else
    self.UIRoot.WidgetSwitcher_CoverImage:SetActiveWidgetIndex(0)
  end
end

function CreativeModePrefabMallUploadCollectionUI:IsEditable()
  if not self.CollectionId then
    return true
  end
  local State = self.CollectionData and self.CollectionData.state
  return PrefabMallConfig.IsCollectionEditableState(State)
end

function CreativeModePrefabMallUploadCollectionUI:IsDeletable()
  if not self.CollectionId then
    return false
  end
  local State = self.CollectionData and self.CollectionData.state
  return PrefabMallConfig.IsCollectionDeletableState(State)
end

function CreativeModePrefabMallUploadCollectionUI:RefreshDeleteButtonState()
  self:SetWidgetVisible(self.UIRoot.Button_Delete, self:IsDeletable(), true)
end

function CreativeModePrefabMallUploadCollectionUI:RefreshSaveReleaseButtonState()
  local bEditable = self:IsEditable()
  if self.UIRoot.WidgetSwitcher_SaveBtn then
    self.UIRoot.WidgetSwitcher_SaveBtn:SetActiveWidgetIndex(bEditable and 0 or 1)
  end
  if self.UIRoot.WidgetSwitcher_ReleaseBtn then
    self.UIRoot.WidgetSwitcher_ReleaseBtn:SetActiveWidgetIndex(self.CollectionData and bEditable and 0 or 1)
  end
  if self.CollectionData then
    self.UIRoot.TextBlock_Save01:SetText(LocUtil.GetLocalizeResStr(70025))
    self.UIRoot.TextBlock_Save02:SetText(LocUtil.GetLocalizeResStr(70025))
  else
    self.UIRoot.TextBlock_Save01:SetText(LocUtil.GetLocalizeResStr(110038))
    self.UIRoot.TextBlock_Save02:SetText(LocUtil.GetLocalizeResStr(110038))
  end
  self.UIRoot.TextBlock_Release01:SetText(LocUtil.GetLocalizeResStr(70024))
  self.UIRoot.TextBlock_Release02:SetText(LocUtil.GetLocalizeResStr(70024))
end

local class = require("class")
local Base = require("client.slua.umg.ugc.lobby.UGCPrefabMall.CreativeModePrefabMallItemModifyPopup")
local CCreativeModePrefabMallUploadCollectionUI = class(Base, nil, CreativeModePrefabMallUploadCollectionUI)
return CCreativeModePrefabMallUploadCollectionUI
