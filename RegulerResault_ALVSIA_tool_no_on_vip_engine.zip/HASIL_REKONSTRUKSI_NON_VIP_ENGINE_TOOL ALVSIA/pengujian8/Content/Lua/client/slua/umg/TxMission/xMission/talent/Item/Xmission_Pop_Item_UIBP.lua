local Xmission_Pop_Item_UIBP = {}

function Xmission_Pop_Item_UIBP:ctor()
end

function Xmission_Pop_Item_UIBP:RegistEvents()
end

function Xmission_Pop_Item_UIBP:OnRefresh(data, selectIndex)
  if not self.UIRoot or not data then
    return
  end
  local effect = data.effect
  if type(effect) ~= "string" then
    effect = effect and tostring(effect) or ""
  end
  if self.UIRoot.TextBlock_0 then
    self.UIRoot.TextBlock_0:SetText(effect)
  end
  local para = tonumber(data.para)
  local showType = tonumber(data.showType) or 1
  if self.UIRoot.TextBlock_1 then
    if para and showType ~= 0 then
      if showType ~= 1 then
        self.UIRoot.TextBlock_1:SetText(LocUtil.LocalizeResFormat(35135, para))
      else
        self.UIRoot.TextBlock_1:SetText("+" .. tostring(para))
      end
      self:SetWidgetVisible(self.UIRoot.TextBlock_1, true)
    else
      self.UIRoot.TextBlock_1:SetText("")
      self:SetWidgetVisible(self.UIRoot.TextBlock_1, false)
    end
  end
end

local class = require("class")
local scroll_box_child_base = require("client.slua_ui_framework.component.scroll_box_child_base")
return class(scroll_box_child_base, nil, Xmission_Pop_Item_UIBP)
