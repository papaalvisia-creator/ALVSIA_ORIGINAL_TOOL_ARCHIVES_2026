local JumpUtils = require("client.logic.store.jump_utils")
local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
local PufferConst = require("client.slua.logic.download.puffer_const")
local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
local xsuit_config_and_cache = require("client.slua.logic.XSuit.xsuit_config_and_cache")
local XSuitHandler = require("client.network.Protocol.XSuitHandler")
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local XSuit_Workshop_Main_UIBP = {
  MaxPeriod = 0,
  ItemResID = 0,
  CurItemLevel = 0,
  SwitchItemLevel = 0,
  CurState = nil,
  CurItemMaxLevel = 1,
  TimerSubTab = nil,
  TimerMeshEffect = nil,
  CurUpgradeInfo = nil,
  CurBaseInfo = nil,
  limitMoneyList = nil,
  enterActionID = nil
}
local defaultState = 2
local dft_nPoseSwitch = 1
local dft_nSlideIdx = 1
local ui_base = require("client.slua_ui_framework.base")
local Trait = require("common.trait")
local Traits = {
  require("client.slua.umg.XSuit_Workshop.Traits.XSuit_Workshop_Tab_Component"),
  require("client.slua.logic.XSuit.Traits.xsuit_scene"),
  require("client.slua.logic.XSuit.Traits.xsuit_money"),
  require("client.slua.umg.XSuit_Workshop.Traits.XSuit_Workshop_Glide_Component"),
  require("client.slua.umg.XSuit_Workshop.Traits.Xsuit_Avatar_Component"),
  require("client.slua.umg.XSuit_Workshop.Traits.XSuit_Workshop_Switch_Component"),
  require("client.slua.umg.XSuit_Workshop.Traits.XSuit_Workshop_Upgrade_Component"),
  require("client.slua.umg.XSuit_Workshop.Traits.XSuit_Workshop_Branch_Component")
}
local CGolden_Suit_Upgrade = Trait.TraitClass(ui_base, nil, XSuit_Workshop_Main_UIBP, Traits)

function XSuit_Workshop_Main_UIBP:ctor(_, period, branchId, itemId, state, featureIndex, schemeIndex)
  branchId = branchId or 0
  self.jumpInfo = {selectBranchId = branchId}
  if itemId then
    local itemPeriod = LogicXSuit.GetPeriodByItemId(itemId)
    if itemPeriod then
      self.jumpInfo.selectPeriod = itemPeriod
      self.jumpInfo.selectLevel = LogicXSuit.GetLevelByItemId(itemId) or -1
      self.jumpInfo.selectBranchId = LogicXSuit.GetBranchByItemId(itemId)
    end
  elseif period and 0 < period then
    self.jumpInfo.selectPeriod = period
  else
    self.jumpInfo.selectPeriod = LogicXSuit.GetMaxPeriod()
  end
  self.CurState = state
  self.jumpInfo.selectFeatureIndex = featureIndex
  if type(schemeIndex) == "number" and 0 < schemeIndex then
    self.jumpInfo.selectSchemeIndex = schemeIndex
  end
  log_error(string.format("XSuit_Workshop_Main_UIBP:ctor period=%s branchId=%s itemId=%s schemeIndex=%s", tostring(period), tostring(branchId), tostring(itemId), tostring(schemeIndex)))
  self.clickHelpTitle = ""
  self.clickHelpDesc = ""
  self.clickHelpImage = nil
  self.clickHelpUI = nil
  self.nPoseSwitch = dft_nPoseSwitch
  self.nSlideIdx = dft_nSlideIdx
  self.SpecialGlideID = 0
  self.SpecialGlideIDLeft = 0
  self.canSetting = true
  self.schemeIndex = 1
  local UnLockFeatureType = require("GameLua.Activity.Commercialize.GamePlay.XSuit.UnLockFeatureType")
  self.unLockFeatureMap = {
    [2] = {
      [3] = UnLockFeatureType.TeamEnterAction2,
      [4] = UnLockFeatureType.SprintShow
    }
  }
  self.enum_featureType = LogicXSuit.GetConfig("Enum_FeatureType")
  self.enum_effect = LogicXSuit.GetConfig("Enum_Effect")
  self.changeStateActionId = nil
  self.changeStateConfig = {}
end

function XSuit_Workshop_Main_UIBP:OnInitialize()
  XSuit_Workshop_Main_UIBP.__super.OnInitialize(self)
  if not self.vng18IconUI then
    local UIUtil = require("client.common.ui_util")
    self.vng18IconUI = UIUtil.InitChildWindow18Logo(self, "CanvasPanel_0", 0, 0, 550, -20, 100)
  end
  self:InitLevelTabComponent()
end

function XSuit_Workshop_Main_UIBP:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_GOLDEN_SUIT, EVENTID_GOLDEN_SUIT_UPGRADE_SUCCESS, self.OnUpgradeRspCallBack, self)
  self:AddCommonEvent(EVENTTYPE_APPLICATION_ACTIVE_STATE, EVENTID_APPLICATION_REACTIVATED, self.OnApplicationReactivated, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_DRAW_ACTIVITY_UPDATE, self.OnDrawActivityUpdate, self)
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_HALL_DEPOT_DATA_CHANGE, self.OnHallDepotChange, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_FEATURE_GET, self.OnFeatureGet, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_COLLECT_INFO_UPDATE, self.OnCollectInfoUpdate, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_LUCKYBACK_EXCHANGE_REFRESH, self.OnExchangeDataRsp, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVENTID_ACTION_PALY_END, self.OnActionStop, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVENTID_ACTION_PLAY_START, self.OnFeatureActionPlayStart, self)
  self:AddCommonEvent(EVENTTYPE_SHARECOMPONENT, EVENTID_SHARECOMPONENT_UPDATE_SHARE_TIME, self.UpdateShareTime, self)
  self:AddCommonEvent(EVENTTYPE_STORE_DATA, EVENTID_STORE_JUMP_DATA_REFRESH, self.UpdateMaterialWithData, self)
  self:AddCommonEvent(EVENTTYPE_VIDEO_PURE, EVENTID_VIDEO_PURE_CLOSE, self.VideoEndHandler, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Close, self.OnClickClose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Share, self.OnClickShare, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Detail, self.OnClickDetail, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Mask, self.OnClickMask, self)
  if self.UIRoot.Button_0 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_0, self.OnClickChangeStateButton, self, true)
  end
  if self.UIRoot.Button_3 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_3, self.OnClickChangeStateButton, self, false)
  end
  self:AddOnClickedEventByControl(self.UIRoot.Button_01, self.OnClickChangeColorButton, self, 1)
  self:AddOnClickedEventByControl(self.UIRoot.Button_02, self.OnClickChangeColorButton, self, 2)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Switch1, self.OnClickChangeColorButton, self, 1)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Switch2, self.OnClickChangeColorButton, self, 2)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Switch3, self.OnClickChangeColorButton, self, 3)
  self:AddOnClickedEventByControl(self.UIRoot.Button_sex, self.OnClickSex, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_2, self.OnClick_SwitchPose, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_5, self.OnClick_Help, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_7, self.OnClick_Guide, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Lock_Star, self.OnClickCollectTips, self)
  self:InitGlideComponent()
  self:InitFeatureComponent()
  self:InitUpgradeComponent()
  self:InitBranchComponent()
end

function XSuit_Workshop_Main_UIBP:OnPostInitialize()
  XSuit_Workshop_Main_UIBP.__super.OnPostInitialize(self)
  self:TryInitData()
  self:SetAsyncLoadingTimeLimit(100)
  self:InitBanner()
end

function XSuit_Workshop_Main_UIBP:InitBanner()
  if not self.UIRoot.Border_Banner then
    return
  end
  local bannerConfig = UIManager.UI_Config.XSuit_Mid_Binner_More_UIBP
  if not bannerConfig then
    log_error("XSuit_Mid_Binner_More_UIBP config not found!")
    return
  end
  self.BannerUI = self:CreateChildWindow(self.UIRoot.Border_Banner, bannerConfig, 1, self.selectPeriod)
end

function XSuit_Workshop_Main_UIBP:OnClose()
  self:RestoreAsyncLoadingTimeLimit()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:PlaySpinAudio_BG(0, self.selectPeriod)
  XSuit_Workshop_Main_UIBP.__super.OnClose(self)
  self:RemoveAllTimer()
  self.TimerSubTab = nil
  self.TimerMeshEffect = nil
  self.TimerDelayShowAvatar = nil
  self.bWaitFeatureActionStart = nil
  self:OnCloseMoneyComponent()
  self:UnbindAvatarMeshLoadedEvent()
  local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
  self:OnCloseScene(ConstAvatarDislay.ESceneType.XSuitWorkshop)
  self:LoadGlideScene(false, true)
  local ui = UIManager.GetUI(UIManager.UI_Config.item_upgrade_effect)
  if ui then
    ui:HideGoldenSuitEffect()
    UIManager.CloseUI(UIManager.UI_Config.item_upgrade_effect)
  end
  GlobalData.RestoreLobbyBGM()
  local VideoLibrary = require("client.slua.logic.video.lobby_video_function_library")
  VideoLibrary.StopVideoPure()
end

function XSuit_Workshop_Main_UIBP:GetDataForJumpBack()
  return {
    ctorData = {
      [1] = self.selectPeriod,
      [2] = self.selectBranchId,
      [3] = self.ItemResID,
      [4] = self.CurState
    }
  }
end

function XSuit_Workshop_Main_UIBP:TryInitData()
  self.UIRoot.Image_BG:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self:AddTimerOnce(0.01, function()
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:TryInitData RequestJumpMapInfo")
    JumpUtils.RequestJumpMapInfo()
  end)
  self.MaxPeriod = LogicXSuit.GetMaxPeriod()
  if self.MaxPeriod > 0 then
    self:InitData()
    self:InitWithDataReady()
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Root, true)
  else
    log(bWriteLog and "XSuitHandler.send_get_rise_star_info_req=====XSuit_Workshop_Main_UIBP")
    self._get_rise_star_info_timer = self:AddTimerOnce(1, function()
      ShowNotice(301226)
      self:CloseSelf()
    end)
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Root, false)
    XSuitHandler.send_get_rise_star_info_req()
  end
  XSuitHandler.send_gold_dress_get_collect_info_req()
  XSuitHandler.send_gold_dress_task_info_req()
  XSuitHandler.send_gold_dress_get_branch_switch_info_req()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:SetExchangeData(nil)
  logic_xsuit_activity:RequestExchangeData()
end

function XSuit_Workshop_Main_UIBP:InitData()
  self.MaxPeriod = LogicXSuit.GetMaxPeriod()
  if self.selectPeriod > self.MaxPeriod or self.selectPeriod == 0 then
    self.selectPeriod = self.MaxPeriod
    log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:InitData self.selectPeriod" .. tostring(self.selectPeriod))
  end
  if not self.CurState then
    local serState = LogicXSuit.GetCurStateByPeriod(self.selectPeriod)
    if serState then
      self.CurState = serState
    elseif LogicXSuit.CheckUnlockState(self.selectPeriod, 1) then
      self.CurState = 1
    elseif LogicXSuit.CheckUnlockState(self.selectPeriod, 2) then
      self.CurState = 2
    else
      self.CurState = defaultState
    end
  end
end

function XSuit_Workshop_Main_UIBP:UpdateShareTime()
  if self._get_rise_star_info_timer then
    self:RemoveTimer(self._get_rise_star_info_timer)
    self._get_rise_star_info_timer = nil
  end
  self:CacheCurXSuitInfo()
  self:SetPeriodTabData()
end

function XSuit_Workshop_Main_UIBP:UpdateData(isInit)
  self.AllUpgradeInfo = LogicXSuit.GetUpgradeInfo(self.selectPeriod)
  log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:UpdateData self.selectPeriod " .. tostring(self.selectPeriod))
  if not self.AllUpgradeInfo then
    return false
  end
  self.AllBaseInfo, self.bBranch = LogicXSuit.GetBaseInfo(self.selectPeriod)
  if self.bBranch then
    self.CurUpgradeInfo = self.AllUpgradeInfo[self.selectBranchId]
    self.CurBaseInfo = self.AllBaseInfo and self.AllBaseInfo[self.selectBranchId]
  else
    self.CurUpgradeInfo = self.AllUpgradeInfo
    self.CurBaseInfo = self.AllBaseInfo
  end
  if not self.CurUpgradeInfo or not self.CurBaseInfo then
    log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateData no branch data, period:%s, branch:%s, bBranch:%s", tostring(self.selectPeriod), tostring(self.selectBranchId), tostring(self.bBranch)))
    return false
  end
  self.CurItemMaxLevel = self.CurBaseInfo.max_level
  self.CurItemLevel = LogicXSuit.GetLevelByPeriodSelf(self.selectPeriod, self.selectBranchId) or 0
  self.SwitchItemLevel = LogicXSuit.GetSwitchLevelByPeriod(self.selectPeriod, self.selectBranchId)
  self.nPoseSwitch = dft_nPoseSwitch
  self.nSlideIdx = dft_nSlideIdx
  if isInit and self.selectLevel == 0 then
    self.selectLevel = self.CurItemLevel + 1
    if self.selectLevel > self.CurItemMaxLevel then
      self.selectLevel = self.CurItemMaxLevel
    end
    self.schemeIndex = 1
  end
  local curLevelInfo = self.CurUpgradeInfo[self.selectLevel]
  if not curLevelInfo then
    local fallbackLevel
    for level = 1, self.CurItemMaxLevel or 0 do
      if self.CurUpgradeInfo[level] then
        fallbackLevel = level
        break
      end
    end
    log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateData invalid selectLevel:%s, period:%s, branch:%s, fallback:%s", tostring(self.selectLevel), tostring(self.selectPeriod), tostring(self.selectBranchId), tostring(fallbackLevel)))
    if not fallbackLevel then
      return false
    end
    self.selectLevel = fallbackLevel
    curLevelInfo = self.CurUpgradeInfo[fallbackLevel]
  end
  self.ItemResID = curLevelInfo.item_id
  return true
end

function XSuit_Workshop_Main_UIBP:InitWithDataReady()
  self:UpdateScene()
  self.initData = {
    initEquipList = {}
  }
  table.insert(self.initData.initEquipList, {
    self.ItemResID
  })
  local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
  self.curScene = ConstAvatarDislay.ESceneType.XSuitWorkshop
  self:InitComponent_Avatar()
  self:HideAvatar()
  self:BindAvatarMeshLoadedEvent()
  self:SetPeriodTabData()
  local jumpSchemeIndex = self.jumpInfo.selectSchemeIndex
  self.jumpInfo.selectSchemeIndex = nil
  self:ApplyJumpSchemeIndex(jumpSchemeIndex)
  self:PlayUserWidgetAnimation(self.UIRoot.Fadein, 0, 1, 0, 1)
  self:InitDownloadBtn()
  local maxPeriod = LogicXSuit.GetMaxPeriod()
  if maxPeriod < 16 then
    self:SetWidgetVisible(self.UIRoot.Button_7, false, true)
  else
    self:SetWidgetVisible(self.UIRoot.Button_7, true, true)
  end
end

function XSuit_Workshop_Main_UIBP:ApplyJumpSchemeIndex(schemeIndex)
  if not schemeIndex or schemeIndex <= 1 then
    return
  end
  local collectCfg = LogicXSuit.GetXSuitWorkshopCollectCfg(self.selectPeriod, self.selectFeatureIndex, self.selectLevel, self.selectBranchId)
  local itemId = collectCfg and collectCfg[string.format("ItemID%d", schemeIndex)]
  if not itemId or itemId <= 0 then
    log_error(string.format("XSuit_Workshop_Main_UIBP:ApplyJumpSchemeIndex invalid schemeIndex=%s period=%s level=%s branch=%s", tostring(schemeIndex), tostring(self.selectPeriod), tostring(self.selectLevel), tostring(self.selectBranchId)))
    return
  end
  self.schemeIndex = schemeIndex
  self._bChangingSchemeByClick = true
  self:UpdateChangeBranch()
  self:UpdateChangeBranchLock()
  self._bChangingSchemeByClick = nil
  self:_UpdateSchemeId()
  if self._targetRelateItem and 0 < self._targetRelateItem then
    self:TryShowEffect(false, true)
  else
    self:_ApplySchemeId()
  end
end

function XSuit_Workshop_Main_UIBP:UpdateScene()
  self:StopEmotion()
  if self:IsGlideShow() then
    log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:UpdateScene skip, glide showing. period:%s, level:%s, feature:%s", tostring(self.selectPeriod), tostring(self.selectLevel), tostring(self.selectFeatureIndex)))
    return
  end
  local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
  local sceneType = ConstAvatarDislay.ESceneType.XSuitWorkshop
  local lastSceneName = self.LastSceneNameByType and self.LastSceneNameByType[sceneType]
  self:TryUpdateScene(self.selectPeriod or 1, UIManager.UI_Config.XSuit_Workshop_Main_UIBP, sceneType, nil, true, function()
    if not self:TryPlayEnterAction() then
      self:TryShowEffect()
    end
  end)
  local newSceneName = self.LastSceneNameByType and self.LastSceneNameByType[sceneType]
  if newSceneName and lastSceneName and newSceneName == lastSceneName then
    self:AddTimerOnce(0, function()
      if not slua.isValid(self.UIRoot) then
        return
      end
      self:TryPlayEnterAction()
    end)
  elseif not newSceneName then
    log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:UpdateScene no scene name, skip replay. period:%s, lastScene:%s", tostring(self.selectPeriod), tostring(lastSceneName)))
  end
end

function XSuit_Workshop_Main_UIBP:UpdateCamera(bDownLoad)
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  local bRiding, bGlide = self:IsSelectGlide()
  if bDownLoad and (bRiding or bGlide) then
    Lobby_camera_manager_module:SwitchCamera(Lobby_camera_manager_module.Enum_CameraID.XsuitWorkshopGlide)
    return
  end
  Lobby_camera_manager_module:SwitchCamera(Lobby_camera_manager_module.Enum_CameraID.XsuitWorkshop)
end

function XSuit_Workshop_Main_UIBP:InitMoneyComponent()
  if self.moneyTimer then
    self:RemoveTimer(self.moneyTimer)
    self.moneyTimer = nil
  end
  self.coinExtraCountMap = nil
  local TableUtil = require("common.table_util")
  local moneys = LogicXSuit.GetConfig("XSuit_Material")
  local moneyList = TableUtil.FastCopyTable(moneys)
  local curUpgradeInfo = self.CurUpgradeInfo
  local config = curUpgradeInfo and curUpgradeInfo[2] and curUpgradeInfo[2].cfg
  if not config then
    log_error(string.format("XSuit_Workshop_Main_UIBP:InitMoneyComponent no upgrade cfg, period:%s, branch:%s", tostring(self.selectPeriod), tostring(self.selectBranchId)))
    self:UpdateCurGroup(moneyList)
    return
  end
  local bDrawing, endTime = self:CheckXsuitDrawing()
  if bDrawing and self.CurUpgradeInfo then
    table.insert(moneyList, config.LimitMatID1)
    table.insert(moneyList, config.LimitMatID2)
    self.limitMoneyList = {
      config.LimitMatID1,
      config.LimitMatID2
    }
    local TimeUtil = require("client.common.time_util")
    self.moneyTimer = self:AddTimerOnce(endTime - TimeUtil.GetServerTimeInSec(), nil, function()
      self.limitMoneyList = nil
      self:InitMoneyComponent()
    end)
  end
  if self.MaxPeriod >= 16 then
    if config.ActiveID2 > 0 and 0 < config.ActiveID1 then
      table.insert(moneyList, config.ActiveID1)
      table.insert(moneyList, config.ActiveID2)
    end
    self.coinExtraCountMap = {
      [moneyList[1]] = config.BackID1,
      [moneyList[2]] = config.BackID2
    }
  end
  self:UpdateCurGroup(moneyList)
end

function XSuit_Workshop_Main_UIBP:OnXSuitMoneyCoinClick(itemId, itemWidget)
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.XSuit_Limited_Time_Token_UIBP, self.selectPeriod, self.selectBranchId, itemId)
end

function XSuit_Workshop_Main_UIBP:UpdateUI(isInit)
  if self.MaxPeriod == 0 then
    return false
  end
  if not self:UpdateData(isInit) then
    return false
  end
  self:UpdateCurXSuitInfo()
  self:UpdateChangeStateButton()
  self:UpdatePoseButton()
  self:UpdateSlideButton()
  self:UpdateUnlockFeatureButton(false)
  if self.BannerUI then
    self.BannerUI:UpdateUI(self.selectPeriod)
  end
  return true
end

function XSuit_Workshop_Main_UIBP:RefreshUpgradeReddots()
  self:RefreshUpgradeButtonReddot()
  self:RefreshTrialReddot()
  self:RefreshPeriodTabReddots()
end

function XSuit_Workshop_Main_UIBP:RefreshPeriodTabReddots()
  if not self.ExtendedLoopScrollBox_Period then
    return
  end
  local xsuit_trial_reddot = require("client.slua.logic.XSuit.xsuit_trial_reddot")
  local lastShown = self.upgradeReddotPeriods or {}
  local curShown = {}
  for _, data in ipairs(self.periodList or {}) do
    local period = data.period
    if period and 0 < period then
      local bShow = xsuit_trial_reddot.IsPeriodUpgradeReddotShow(period)
      if bShow then
        curShown[period] = true
      end
      if bShow ~= (lastShown[period] == true) then
        self:RefreshOnePeriodTab(period)
      end
    end
  end
  self.upgradeReddotPeriods = curShown
  self.ExtendedLoopScrollBox_Period:RefreshAllSubItems()
end

function XSuit_Workshop_Main_UIBP:UpdateCurXSuitInfo()
  local curLevelInfo = self.CurUpgradeInfo and self.CurUpgradeInfo[self.selectLevel]
  if not curLevelInfo then
    for level = 1, self.CurItemMaxLevel or 0 do
      if self.CurUpgradeInfo and self.CurUpgradeInfo[level] then
        self.selectLevel = level
        curLevelInfo = self.CurUpgradeInfo[level]
        break
      end
    end
  end
  if not curLevelInfo then
    log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateCurXSuitInfo no level info, period:%s, branch:%s, selectLevel:%s", tostring(self.selectPeriod), tostring(self.selectBranchId), tostring(self.selectLevel)))
    return
  end
  local cfgStr = ""
  local index = 1
  for i, v in ipairs(curLevelInfo.tab_desc_array or {}) do
    if index == self.selectFeatureIndex then
      cfgStr = v
      break
    else
      index = index + 1
    end
  end
  local StringUtil = require("common.string_util")
  local cfgArray = StringUtil.Split(cfgStr, "|")
  if cfgArray[1] and cfgArray[1] ~= "0" then
    self.clickHelpTitle = LocUtil.GetLocalizeResStr(cfgArray[1])
    self.UIRoot.Text_SimpleText:SetText(self.clickHelpTitle)
    self:SetWidgetVisible(self.UIRoot.Text_SimpleText, true)
  else
    self:SetWidgetVisible(self.UIRoot.Text_SimpleText, false)
  end
  if cfgArray[2] and cfgArray[2] ~= "0" then
    self:SetWidgetVisible(self.UIRoot.Button_5, true, true)
    self.clickHelpDesc = LocUtil.GetLocalizeResStr(cfgArray[2])
  else
    self:SetWidgetVisible(self.UIRoot.Button_5, false)
  end
  self.clickHelpImage = cfgArray[3]
  local clothID = LogicXSuit.ChangeItemIDByState(self.ItemResID, self.CurState)
  local itemCfg = clothID and CDataTable.GetTableData("Item", clothID)
  if itemCfg and self.UIRoot.Text_Title1 then
    self.UIRoot.Text_Title1:SetText(itemCfg.ItemName)
  else
    log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateCurXSuitInfo invalid cloth item, clothID:%s, ItemResID:%s, state:%s", tostring(clothID), tostring(self.ItemResID), tostring(self.CurState)))
  end
  self.UIRoot.Text_Prograss:SetText(LocUtil.LocalizeResFormat(18141226, self.CurItemLevel, self.CurItemMaxLevel))
  self:UpdateChangeBranch()
  self:UpdateChangeBranchLock()
  self:UpdateShareButton()
  print(bWriteLog and string.format(" XSuit_Workshop_Main_UIBP:UpdateMainUI self.selectPeriod:%s self.selectLevel:%s", self.selectPeriod, self.selectLevel))
  self:SetWidgetVisible(self.UIRoot.Panel_Effect, self.selectPeriod == 1)
  self:SetWidgetVisible(self.UIRoot.WidgetSwitcher_0, false)
  self:SetWidgetVisible(self.UIRoot.Button_4, false)
  local activeBranchId = LogicXSuit.GetActiveBranchIdByPeriod(self.selectPeriod)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_30, activeBranchId == self.selectBranchId)
end

function XSuit_Workshop_Main_UIBP:_GetEquippedSchemeIndex(collectCfg)
  if not collectCfg then
    return nil
  end
  local period, branchId = self.selectPeriod, self.selectBranchId
  local showNum = collectCfg.ItemID3 and collectCfg.ItemID3 > 0 and 3 or 2
  local defaultIndex
  for index = 1, showNum do
    local itemId = collectCfg[string.format("ItemID%d", index)]
    if itemId and 0 < itemId then
      local schemeCfg = self:_GetCustomSchemeByItemId(itemId, collectCfg.CFeatureID)
      if schemeCfg then
        local equippedSchemeId = LogicXSuit.GetSchemeIdByFeature(period, branchId, schemeCfg.FeatureID)
        if equippedSchemeId and 0 < equippedSchemeId and tonumber(equippedSchemeId) == tonumber(schemeCfg.SchemeID) then
          return index
        end
        if schemeCfg.IsDefaultColor == 1 and not defaultIndex then
          defaultIndex = index
        end
      end
    end
  end
  return defaultIndex
end

function XSuit_Workshop_Main_UIBP:ResolveSchemeIndex(jumpSchemeIndex)
  if jumpSchemeIndex and 0 < jumpSchemeIndex then
    return jumpSchemeIndex
  end
  local collectCfg = LogicXSuit.GetXSuitWorkshopCollectCfg(self.selectPeriod, self.selectFeatureIndex, self.selectLevel, self.selectBranchId)
  if not collectCfg then
    return 1
  end
  local rememberedIndex = self:_GetRememberedSchemeIndex(collectCfg)
  if rememberedIndex then
    return rememberedIndex
  end
  return self:_GetEquippedSchemeIndex(collectCfg) or 1
end

function XSuit_Workshop_Main_UIBP:UpdateChangeBranch()
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Switch2, false)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Switch3, false)
  if self.bBranch then
    local periodIndex = self.MaxPeriod - self.selectPeriod + 1
    local periodList = LogicXSuit.GetWorkshopTabData()
    local periodItem = periodList and periodList[periodIndex]
    local branchList = periodItem and periodItem.branchList
    if not branchList then
      log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateChangeBranch no branch list, period:%s, periodIndex:%s", tostring(self.selectPeriod), tostring(periodIndex)))
      return
    end
    local curProgress, maxProgress = 0, 0
    if branchList then
      local branchItemName = "XSuit_Branch_Count_Item_UIBP_%d"
      local imageCanvasName = "CanvasPanel_Switch%d"
      local imageButtonName = "Image_Switch%d"
      local branchData = branchList[self.selectBranchId + 1]
      local collectCfg = LogicXSuit.GetXSuitWorkshopCollectCfg(self.selectPeriod, self.selectFeatureIndex, self.selectLevel, self.selectBranchId)
      self.collectItemId = 0
      local showNum = 0
      if collectCfg then
        local rememberedIndex = self:_GetRememberedSchemeIndex(collectCfg)
        if rememberedIndex then
          self.schemeIndex = rememberedIndex
        elseif not self._bChangingSchemeByClick then
          local equippedIndex = self:_GetEquippedSchemeIndex(collectCfg)
          if equippedIndex then
            log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:UpdateChangeBranch use equippedSchemeIndex=%s, period:%s, feature:%s, level:%s, branch:%s", tostring(equippedIndex), tostring(self.selectPeriod), tostring(self.selectFeatureIndex), tostring(self.selectLevel), tostring(self.selectBranchId)))
            self.schemeIndex = equippedIndex
          end
        end
        self.collectItemId = collectCfg[string.format("ItemID%d", self.schemeIndex)]
        showNum = collectCfg.ItemID3 and 0 < collectCfg.ItemID3 and 3 or 2
        local changeCanvasCtr = self:GetXSuitChangeCtr(imageCanvasName, showNum)
        local changeImageCtr = self:GetXSuitChangeCtr(imageButtonName, showNum)
        if self.collectItemId and 0 < self.collectItemId then
          if changeCanvasCtr then
            self:SetWidgetVisible(changeCanvasCtr, true)
          end
          if changeImageCtr then
            local imagePath = string.format(collectCfg.ButtonIcon, self.selectBranchId, self.schemeIndex, self.selectBranchId, self.schemeIndex)
            log_error(" XSuit_Workshop_Main_UIBP:UpdateChangeBranch imagePath", imagePath)
            self:SetTexture(changeImageCtr, imagePath)
          end
        elseif changeCanvasCtr then
          self:SetWidgetVisible(changeCanvasCtr, false)
        end
        if self.collectItemId and 0 < self.collectItemId then
          self:_UpdateSchemeId()
        end
      end
      local itemMissionData
      if self.collectItemId and 0 < self.collectItemId then
        itemMissionData = LogicXSuit.GetBranchMissionItemData(self.selectPeriod, self.collectItemId)
      end
      self:SetTexture(self.UIRoot.XSuit_Branch_Count_Item_UIBP.Image_Icon_01, branchData.branchCountIcon)
      self.UIRoot.XSuit_Branch_Count_Item_UIBP.UTRichTextBlock_Number:SetText(LocUtil.LocalizeResFormat(18141397, self.CurItemLevel, self.CurItemMaxLevel))
      for index, config in ipairs(branchList) do
        local itemCtr = self:GetXSuitChangeCtr(branchItemName, index)
        if itemCtr then
          local branchId = index - 1
          maxProgress = itemMissionData and itemMissionData.conditions[branchId] or 0
          if not maxProgress or maxProgress <= 0 then
            maxProgress = 0
          end
          curProgress = LogicXSuit.GetLevelByPeriodSelf(self.selectPeriod, branchId) or 0
          self:SetWidgetVisible(itemCtr, 0 < maxProgress, 0 < maxProgress)
          self:SetWidgetVisible(itemCtr.TextBlock_Text, false)
          self:SetTexture(itemCtr.Image_Icon_01, config.branchCountIcon)
          itemCtr.UTRichTextBlock_Number:SetText(LocUtil.LocalizeResFormat(18141397, curProgress, maxProgress))
        end
      end
    else
      self:SetWidgetVisible(self.UIRoot.XSuit_Branch_Count_Item_UIBP, false)
    end
  end
end

function XSuit_Workshop_Main_UIBP:_IsBaseChangeColor(itemId)
  if not itemId or itemId <= 0 then
    return false
  end
  local schemeCfg = CDataTable.GetTableDataByFilter("XSuitCustomScheme", "ItemID", itemId)
  return schemeCfg ~= nil and schemeCfg.IsDefaultColor == 1
end

function XSuit_Workshop_Main_UIBP:_IsChangeColorUnlocked(itemId)
  if not itemId or itemId <= 0 then
    return false
  end
  if not LogicXSuit.GetBranchMissionItemData(self.selectPeriod, itemId) then
    return LogicXSuit.IsBranchUnlocked(self.selectPeriod, self.selectBranchId)
  end
  if LogicXSuit.IsItemCollected(self.selectPeriod, itemId) then
    return true
  end
  local StoreUtils = require("client.slua.logic.store.utils.store_utils")
  return StoreUtils.HasItem(itemId)
end

function XSuit_Workshop_Main_UIBP:UpdateChangeBranchLock()
  local collectCfg = LogicXSuit.GetXSuitWorkshopCollectCfg(self.selectPeriod, self.selectFeatureIndex, self.selectLevel, self.selectBranchId)
  local lockItemName = "Image_Lock%d_%d"
  if collectCfg then
    local showNum = collectCfg.ItemID3 and collectCfg.ItemID3 > 0 and 3 or 2
    for i = 1, showNum do
      local lockItemCtr = self:GetXSuitChangeCtr(lockItemName, showNum, i)
      if lockItemCtr then
        local _id = collectCfg[string.format("ItemID%d", i)]
        self:SetWidgetVisible(lockItemCtr, not self:_IsChangeColorUnlocked(_id), false)
      end
    end
  end
  if self.bBranch then
    local bShowTopEntry = false
    if collectCfg and self.collectItemId and 0 < self.collectItemId and not self:_IsBaseChangeColor(self.collectItemId) then
      bShowTopEntry = not self:_IsChangeColorUnlocked(self.collectItemId)
    end
    if self.UIRoot.Image_Lock_Star then
      self:SetWidgetVisible(self.UIRoot.Image_Lock_Star, bShowTopEntry, false)
    end
    if self.UIRoot.Button_Lock_Star then
      self:SetWidgetVisible(self.UIRoot.Button_Lock_Star, bShowTopEntry, bShowTopEntry)
    end
  end
end

function XSuit_Workshop_Main_UIBP:GetXSuitChangeCtr(name, ...)
  if select("#", ...) <= 0 then
    return self.UIRoot[name]
  end
  return self.UIRoot[string.format(name, ...)]
end

function XSuit_Workshop_Main_UIBP:UpdateShareButton()
  local _bShow = self.CurItemLevel == self.selectLevel
  self:SetWidgetVisible(self.UIRoot.Panel_Share, _bShow)
end

function XSuit_Workshop_Main_UIBP:PlayEnterAction(action)
  self:ShowAvatarDisplay(action, {bWear = true, enableCameraAnim = true})
  self.enterActionID = action
end

function XSuit_Workshop_Main_UIBP:TryPlayEnterAction()
  self.enterActionID = nil
  local action = LogicXSuit.GetEnterActionByPeriod(self.selectPeriod, self.CurState, self.selectBranchId)
  log(bWriteLog and string.format("[XSuitEnterAction] period=%s branch=%s state=%s action=%s", tostring(self.selectPeriod), tostring(self.selectBranchId), tostring(self.CurState), tostring(action)))
  if not action then
    return false
  end
  if not self:CheckAndDownload(action, true) then
    return false
  end
  local clothID = LogicXSuit.ChangeItemIDByState(self.ItemResID, self.CurState)
  if not clothID or clothID <= 0 then
    self:PlayEnterAction(action)
    return true
  end
  log(bWriteLog and string.format("[XSuitEnterAction] wear clothID=%s, ItemResID=%s, period=%s, branch=%s", tostring(clothID), tostring(self.ItemResID), tostring(self.selectPeriod), tostring(self.selectBranchId)))
  self:ShowAvatarDisplay(clothID, {bWear = true, bNotShowSexInMall = true})
  
  local function WaitAndPlayEnterAction()
    if not slua.isValid(self.UIRoot) then
      return
    end
    if LogicXSuit.GetEnterActionByPeriod(self.selectPeriod, self.CurState, self.selectBranchId) ~= action then
      return
    end
    if self.widgetAvatarDisplay and self.widgetAvatarDisplay:IsAsyncLoading() then
      self:AddTimerOnce(0.1, WaitAndPlayEnterAction)
      return
    end
    self:PlayEnterAction(action)
  end
  
  self:AddTimerOnce(0, WaitAndPlayEnterAction)
  return true
end

function XSuit_Workshop_Main_UIBP:TryShowEffect(changeState, sync)
  local downList, downloadState = self:GetDownloadListAndStatus(self.selectPeriod, self.selectBranchId)
  log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect downloadState: " .. tostring(downloadState) .. " || self.canSetting: " .. tostring(self.canSetting))
  if not self.canSetting then
    return
  end
  self:LoadGlideScene(false)
  self:StopEmotion()
  if not changeState then
    self:HideAvatar()
  end
  local VideoLibrary = require("client.slua.logic.video.lobby_video_function_library")
  VideoLibrary.StopVideoPure()
  if self.SpecialGlideID and self:CheckAndDownload(self.SpecialGlideID, false) then
    log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:TryShowEffect self.SpecialGlideID == " .. tostring(self.SpecialGlideID))
    self:ShowAvatarDisplay(self.SpecialGlideID, {bWear = false})
  end
  if sync then
    self:UpdateCamera(downloadState == PufferConst.ENUM_DownloadState.Done)
    self:ShowEffect(changeState, downloadState)
    self:UpdateSexButton()
  else
    self:AddTimerOnce(0, function()
      if not slua.isValid(self.UIRoot) then
        return
      end
      self:UpdateCamera(downloadState == PufferConst.ENUM_DownloadState.Done)
      self:ShowEffect(changeState, downloadState)
      self:UpdateSexButton()
    end)
  end
end

function XSuit_Workshop_Main_UIBP:ShowEffect(changeState, downloadState)
  if not self.CurUpgradeInfo then
    return
  end
  log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect self.selectPeriod = " .. tostring(self.selectPeriod) .. " || self.CurState = " .. tostring(self.CurState) .. "")
  if self.TimerSubTab then
    self:RemoveTimer(self.TimerSubTab)
    self.TimerSubTab = nil
  end
  if self.TimerMeshEffect then
    self:RemoveTimer(self.TimerMeshEffect)
    self.TimerMeshEffect = nil
  end
  if self.actionTimer then
    self:RemoveTimer(self.actionTimer)
    self.actionTimer = nil
  end
  if self.TimerDelayShowAvatar then
    self:RemoveTimer(self.TimerDelayShowAvatar)
    self.TimerDelayShowAvatar = nil
  end
  if downloadState ~= PufferConst.ENUM_DownloadState.Done then
    log("xcc XSuit_Workshop_Main_UIBP:ShowEffect XSuit is not download")
    return
  end
  local bReplayEnterAction = self._bReplayEnterAction
  self._bReplayEnterAction = nil
  self._nAvatarMeshApplyCount = 0
  local clothID = LogicXSuit.ChangeItemIDByState(self.ItemResID, self.CurState)
  local bRiding, bGlide = self:IsSelectGlide()
  if bRiding or bGlide then
    self:LoadGlideScene(true)
  end
  local effectID = 0
  local effectIdArray = {}
  local featureCount = 0
  for i, v in ipairs(self.CurUpgradeInfo[self.selectLevel].effect_id_array) do
    table.insert(effectIdArray, v)
    featureCount = featureCount + (v ~= 0 and 1 or 0)
  end
  print(bWriteLog and " XSuit_Workshop_Main_UIBP:ShowEffect featureCount = " .. tostring(featureCount))
  effectID = effectIdArray[self.selectFeatureIndex]
  local ui_item_upgrade_effect = UIManager.GetUI(UIManager.UI_Config.item_upgrade_effect)
  if ui_item_upgrade_effect then
    ui_item_upgrade_effect:ClearAll()
  else
    ui_item_upgrade_effect = UIManager.ShowUI(UIManager.UI_Config.item_upgrade_effect)
  end
  local needPlayID = 0
  local meshEffect = 0
  local modifyTime = 0
  local needShowAvatar = true
  if effectID ~= 0 then
    local effectInfo = CDataTable.GetTableData("GoldenSuitEffectCfg", effectID)
    if effectInfo then
      log(bWriteLog and "XSuit_Workshop_Main_UIBP:ShowEffect Type = " .. tostring(effectInfo.Type) .. " || ActionID = " .. tostring(effectInfo.ActionID))
      if effectInfo.Type == self.enum_effect.action then
        needPlayID = effectInfo.ActionID
      elseif effectInfo.Type == self.enum_effect.kill_broadcast then
        self:HideAvatar()
        ui_item_upgrade_effect:ShowGoldenSuitEffect(clothID)
        ui_item_upgrade_effect:SetKillInfoPostion(true)
        needShowAvatar = false
      elseif effectInfo.Type == self.enum_effect.elimination_king_override then
        self:HideAvatar()
        ui_item_upgrade_effect:ShowEliminationKingEffect(clothID)
        ui_item_upgrade_effect:SetKillInfoPostion(true)
        needShowAvatar = false
      elseif effectInfo.Type == self.enum_effect.shoot_effect then
        meshEffect = 1
        self:StopEmotion()
        modifyTime = effectInfo.Time
      elseif effectInfo.Type == self.enum_effect.kill_frenzy then
        meshEffect = 2
        needPlayID = effectInfo.ActionID
        modifyTime = effectInfo.Time
      elseif effectInfo.Type == self.enum_effect.mount_effect then
        self:HideAvatar()
        ui_item_upgrade_effect:ShowAttachUI(effectInfo, self.selectPeriod, self.selectBranchId)
        ui_item_upgrade_effect:SetKillInfoPostion(true)
        needShowAvatar = false
      elseif effectInfo.Type == self.enum_effect.glide_effect then
        meshEffect = 3
        needPlayID = effectInfo.ActionID
        modifyTime = 0.1
      elseif effectInfo.Type == self.enum_effect.video then
        local VideoLibrary = require("client.slua.logic.video.lobby_video_function_library")
        VideoLibrary.StopVideoPure()
        local EStretch = import("EStretch")
        local result = VideoLibrary.PlayVideoPure(effectInfo.ResPath, {
          ScaleToFit = EStretch.ScaleToFill,
          HideLogo = true
        })
        if result then
          local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
          logic_xsuit_activity:PlaySpinAudio_BG(0)
          self:SetVolume(false)
          self:ShowAvatarDisplay(clothID, {
            bWear = true,
            bIsClearWearingEquip = true,
            bNotShowSexInMall = true
          })
          self:HideAvatar()
          self:StopEmotion()
          needShowAvatar = false
        end
      end
      if effectInfo.Time ~= 0 and effectInfo.Type ~= self.enum_effect.shoot_effect and effectInfo.Type ~= self.enum_effect.kill_frenzy then
        log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect effectInfo.Time" .. tostring(effectInfo.Time))
        self.TimerSubTab = self:AddTimerOnce(effectInfo.Time, function()
          if self.UIRoot then
            self.selectFeatureIndex = self.selectFeatureIndex >= featureCount and 1 or self.selectFeatureIndex + 1
            self:SelectOneFeatureTab(self.selectFeatureIndex)
            if self.clickHelpUI then
              self.clickHelpUI:CloseSelf()
            end
          end
        end)
      end
    end
  end
  log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect effectID" .. tostring(effectID))
  self.changeStateActionId = nil
  if needShowAvatar then
    self:_ApplySchemeId()
    if self.CurState == 1 and changeState and self.changeStateConfig[self.ItemResID] and self.changeStateConfig[self.ItemResID].changeBackActionId then
      needPlayID = self.changeStateConfig[self.ItemResID].changeBackActionId
      self.changeStateActionId = not self.changeStateConfig[self.ItemResID].bOrder2 and needPlayID
    elseif self.CurState == 2 and changeState and self.changeStateConfig[self.ItemResID] and self.changeStateConfig[self.ItemResID].changeActionId then
      needPlayID = self.changeStateConfig[self.ItemResID].changeActionId
      self.changeStateActionId = not self.changeStateConfig[self.ItemResID].bOrder1 and needPlayID
    else
      local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
      needPlayID = multi_state_manager:ChangeEmoteByState(needPlayID, self.CurState)
    end
    log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect needPlayID" .. tostring(needPlayID))
    if not self.changeStateActionId then
      self:ShowAvatarDisplay(clothID, {
        bWear = true,
        bIsClearWearingEquip = true,
        bNotShowSexInMall = true,
        bForceHideBeforeEmote = true
      })
    end
    if xsuit_config_and_cache.GetPutOnRelicConfigByPeriod(self.selectPeriod) and self.selectLevel >= LogicXSuit.GetConfig("LEVEL_SHOW_RELIC") then
      self:ShowAvatarDisplay(self.CurBaseInfo.relic_id, {bWear = true, bNotShowSexInMall = true})
    end
    if self.SpecialGlideID ~= 0 then
      needPlayID = 0
      self:UpdateGlideDisplay()
    end
    if needPlayID ~= 0 and self:CheckAndDownload(needPlayID, true) then
      log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect needPlayID 1" .. tostring(needPlayID))
      needPlayID = self:TryHighLevelAction(needPlayID)
      log(bWriteLog and "xcc XSuit_Workshop_Main_UIBP:ShowEffect needPlayID 2" .. tostring(needPlayID))
      if needPlayID then
        local curFeatureId = self.CurUpgradeInfo[self.selectLevel].tab_name_array[self.selectFeatureIndex]
        if curFeatureId ~= self.enum_featureType.run then
          local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
          local avatar = ModelDisplayer.GetShowingAvatar()
          local _ = avatar and avatar:SetCanRotate(false)
        end
        needPlayID = self:GetRealFeatureByScheme(needPlayID) or needPlayID
        self:ShowAvatarDisplay(needPlayID, {
          bWear = false,
          enableCameraAnim = true,
          bNotShowSexInMall = true,
          bForceHideBeforeEmote = true
        })
        self:HideAvatarBeforeActionStart()
        self:SetVolume(false)
      else
        ShowNotice(7421)
      end
    else
      self:ShowAvatar()
      self:SetVolume(true)
      if self._targetSchemeId then
        self:_ApplySchemeId()
      end
    end
    self:BindAvatarMeshLoadedEvent()
    local curAvatar = self:GetShowingAvatar()
    EventSystem:postEvent(EVENTTYPE_CHARACTER_EFFECT, EVENTID_CHARACTER_EFFECT_CLEAR, curAvatar:GetModel())
    self:_LogClothSchemeDebug("showEffectEnd")
    if meshEffect ~= 0 and modifyTime ~= 0 then
      local ECharacterEffectTriggerCondition = import("ECharacterEffectTriggerCondition")
      local effectType
      if meshEffect == 1 then
        effectType = ECharacterEffectTriggerCondition.LobbyDisplay_PressShooting
      elseif meshEffect == 2 then
        effectType = ECharacterEffectTriggerCondition.LobbyDisplay_HeadShot
      elseif meshEffect == 3 then
        effectType = ECharacterEffectTriggerCondition.LobbyFreeFalling
      end
      self.TimerMeshEffect = self:AddTimerOnce(modifyTime, function()
        if effectType == ECharacterEffectTriggerCondition.LobbyFreeFalling and self.nSlideIdx == 1 then
          return
        end
        EventSystem:postEvent(EVENTTYPE_CHARACTER_EFFECT, EVENTID_CHARACTER_EFFECT_APPLY, curAvatar:GetModel(), effectType)
      end)
    end
    if bReplayEnterAction then
      self:TryPlayEnterAction()
    end
  end
end

function XSuit_Workshop_Main_UIBP:HideAvatarBeforeActionStart()
  self.bWaitFeatureActionStart = true
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local MultipleAvatarEnum = require("client.logic.avatar.MultipleAvatarEnum")
  local avatar = ModelDisplayer.GetShowingAvatar()
  local _ = avatar and avatar:HideAvatar(MultipleAvatarEnum.Enum_VisibilitySource.XSuitWorkshop)
  if self.TimerDelayShowAvatar then
    self:RemoveTimer(self.TimerDelayShowAvatar)
    self.TimerDelayShowAvatar = nil
  end
  self.TimerDelayShowAvatar = self:AddTimerOnce(1, function()
    self.TimerDelayShowAvatar = nil
    self:ShowAvatarAfterActionStart()
  end)
end

function XSuit_Workshop_Main_UIBP:OnFeatureActionPlayStart()
  if not self.bWaitFeatureActionStart then
    return
  end
  self.bWaitFeatureActionStart = false
  if self.TimerDelayShowAvatar then
    self:RemoveTimer(self.TimerDelayShowAvatar)
    self.TimerDelayShowAvatar = nil
  end
  self:AddTimerOnce(0, function()
    self:ShowAvatarAfterActionStart()
  end)
end

function XSuit_Workshop_Main_UIBP:ShowAvatarAfterActionStart()
  self.bWaitFeatureActionStart = false
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local MultipleAvatarEnum = require("client.logic.avatar.MultipleAvatarEnum")
  local avatar = ModelDisplayer.GetShowingAvatar()
  local _ = avatar and avatar:ShowAvatar(MultipleAvatarEnum.Enum_VisibilitySource.XSuitWorkshop)
  if self._targetSchemeId then
    self:_ApplySchemeId()
  end
end

function XSuit_Workshop_Main_UIBP:UpdateChangeStateButton()
  local canSwitchState = false
  local multiCfg = xsuit_config_and_cache.GetMultiTypeUnlockConfigByPeriod(self.selectPeriod)
  if multiCfg and multiCfg.unlock_level and self.selectLevel >= multiCfg.unlock_level then
    canSwitchState = true
  end
  if canSwitchState and LogicXSuit.IsMultiStateCloth(self.ItemResID) then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_12, true)
    self:SetWidgetVisible(self.UIRoot.Image_Switch_Button_2, true)
    self:SetWidgetVisible(self.UIRoot.Image_person_3, false)
    local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
    local icon = multi_state_manager:GetDetailIcon(self.ItemResID, self.CurState)
    if icon then
      self:SetTexture(self.UIRoot.Image_2, icon, {sync = false})
    else
      log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateChangeStateButton icon not found! item = %s, state = %s", tostring(self.curItemID), tostring(self.CurState)))
    end
    if multiCfg then
      self:SetWidgetVisible(self.UIRoot.Image_57, not LogicXSuit.CheckUnlockState(self.selectPeriod, multiCfg.left_index))
      self:SetWidgetVisible(self.UIRoot.Image_87, not LogicXSuit.CheckUnlockState(self.selectPeriod, multiCfg.right_index))
    else
      log_error("XSuit_Workshop_Main_UIBP:UpdateChangeStateButton not lock location config")
    end
    local stateNameID = multi_state_manager:GetStateName(self.ItemResID, self.CurState)
    if stateNameID and stateNameID ~= 0 then
      local stateName = LocUtil.GetLocalizeResStr(stateNameID)
      if LogicXSuit.CheckUnlockState(self.selectPeriod, self.CurState) then
        self.UIRoot.TextBlock_StateName:SetText(stateName)
      else
        self.UIRoot.TextBlock_StateName:SetText(LocUtil.LocalizeResFormat(44674, stateName))
      end
    end
    self:SetWidgetVisible(self.UIRoot.TextBlock_StateName, true)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_12, false)
    self:SetWidgetVisible(self.UIRoot.TextBlock_StateName, false)
  end
end

function XSuit_Workshop_Main_UIBP:UpdateChangeColorTowButton()
  local canSwitchState = false
  local multiCfg = xsuit_config_and_cache.GetMultiTypeUnlockConfigByPeriod(self.selectPeriod)
  if multiCfg and multiCfg.unlock_level and self.selectLevel >= multiCfg.unlock_level then
    canSwitchState = true
  end
  if canSwitchState and LogicXSuit.IsMultiStateCloth(self.ItemResID) then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_12, true)
    self:SetWidgetVisible(self.UIRoot.Image_Switch_Button_2, true)
    self:SetWidgetVisible(self.UIRoot.Image_person_3, false)
    local multi_state_manager = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.multi_state_manager)
    local icon = multi_state_manager:GetDetailIcon(self.ItemResID, self.CurState)
    if icon then
      self:SetTexture(self.UIRoot.Image_2, icon, {sync = false})
    else
      log_error(string.format("XSuit_Workshop_Main_UIBP:UpdateChangeStateButton icon not found! item = %s, state = %s", tostring(self.curItemID), tostring(self.CurState)))
    end
    if multiCfg then
      self:SetWidgetVisible(self.UIRoot.Image_57, not LogicXSuit.CheckUnlockState(self.selectPeriod, multiCfg.left_index))
      self:SetWidgetVisible(self.UIRoot.Image_87, not LogicXSuit.CheckUnlockState(self.selectPeriod, multiCfg.right_index))
    else
      log_error("XSuit_Workshop_Main_UIBP:UpdateChangeStateButton not lock location config")
    end
    local stateNameID = multi_state_manager:GetStateName(self.ItemResID, self.CurState)
    if stateNameID and stateNameID ~= 0 then
      local stateName = LocUtil.GetLocalizeResStr(stateNameID)
      if LogicXSuit.CheckUnlockState(self.selectPeriod, self.CurState) then
        self.UIRoot.TextBlock_StateName:SetText(stateName)
      else
        self.UIRoot.TextBlock_StateName:SetText(LocUtil.LocalizeResFormat(44674, stateName))
      end
    end
    self:SetWidgetVisible(self.UIRoot.TextBlock_StateName, true)
  else
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_12, false)
    self:SetWidgetVisible(self.UIRoot.TextBlock_StateName, false)
  end
end

function XSuit_Workshop_Main_UIBP:UpdateSexButton()
  local bShow = true
  if not self.bShowAvatar then
    bShow = false
  end
  print(bWriteLog and string.format(" XSuit_Workshop_Main_UIBP:UpdateSexButton self.selectPeriod:%s", self.selectPeriod))
  if xsuit_config_and_cache.IsBanSwitchGenderByPeriod(self.selectPeriod) then
    bShow = false
  end
  if false == bShow then
    self.nSexIdx = 1
    self:SetWidgetVisible(self.UIRoot.Button_sex, false, true)
    return
  end
  local curAvatar = self:GetShowingAvatar()
  if curAvatar then
    self.nSexIdx = curAvatar:GetSex() - 1
    self:SetWidgetVisible(self.UIRoot.Button_sex, true, true)
    self.UIRoot.WidgetSwitcher_sex:SetActiveWidgetIndex(self.nSexIdx == 0 and 1 or 0)
  end
end

function XSuit_Workshop_Main_UIBP:UpdateSlideButton()
  local bRiding, bGlide = self:IsSelectGlide()
  if bRiding or bGlide then
    self.SpecialGlideID = 0
    local data = self.CurUpgradeInfo[self.selectLevel].cfg
    local XSuitId = data.ItemID
    local Cfg = CDataTable.GetTableDataByFilter("XSuitGlideCfg", "XSuitID7", XSuitId)
    if Cfg and Cfg.SpecialGlideID then
      self:TryGetDRGlideId()
      self.SpecialGlideID = self.DRConfig and self.DRConfig.DRGlideID or Cfg.SpecialGlideID
    end
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:UpdateSlideButton  SpecialGlideID = " .. tostring(self.SpecialGlideID))
    if 0 == self.SpecialGlideID then
      self:SetWidgetVisible(self.UIRoot.CanvasPanel_22, false)
      return
    end
    local SpecialGlideIDLeft = 0
    local effectInfo = CDataTable.GetTableData("GoldenSuitEffectCfg", data.Effect1)
    if effectInfo then
      SpecialGlideIDLeft = effectInfo.ActionID
    else
      SpecialGlideIDLeft = 0
    end
    self.SpecialGlideIDLeft = SpecialGlideIDLeft
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_22, false, false)
  else
    self.SpecialGlideID = 0
    self.SpecialGlideIDLeft = 0
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_22, false)
  end
end

function XSuit_Workshop_Main_UIBP:UpdatePoseButton()
  local levelInfo = self.CurUpgradeInfo and self.CurUpgradeInfo[self.selectLevel]
  local data = levelInfo and levelInfo.cfg
  if not data then
    print(bWriteLog and " XSuit_Workshop_Main_UIBP:UpdatePoseButton data is nil")
    return
  end
  local PoseID = data.PoseID
  local bShow = false
  if PoseID ~= 0 then
    local effectID = data["Effect" .. self.selectFeatureIndex]
    local effectInfo = CDataTable.GetTableData("GoldenSuitEffectCfg", effectID)
    if effectInfo then
      bShow = effectInfo.Type ~= self.enum_effect.kill_broadcast and effectInfo.Type ~= self.enum_effect.mount_effect
    else
      bShow = true
    end
  end
  if bShow then
    self:SetWidgetVisible(self.UIRoot.Button_2, true, true)
    self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(self.nPoseSwitch)
  else
    self:SetWidgetVisible(self.UIRoot.Button_2, false)
  end
end

function XSuit_Workshop_Main_UIBP:UpdateGlideDisplay()
  local ECharacterEffectTriggerCondition = import("ECharacterEffectTriggerCondition")
  local effectType = ECharacterEffectTriggerCondition.LobbyFreeFalling
  local curAvatar = self:GetShowingAvatar()
  if self.nSlideIdx == 1 then
    if curAvatar then
      EventSystem:postEvent(EVENTTYPE_CHARACTER_EFFECT, EVENTID_CHARACTER_EFFECT_CLEAR, curAvatar:GetModel(), effectType)
    end
    if not self:CheckAndDownload(self.SpecialGlideID, true) then
      return
    end
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_12, false)
    log(bWriteLog and "[jinqiang] XSuit_Workshop_Main_UIBP:self.SpecialGlideID == " .. tostring(self.SpecialGlideID))
    self:ShowAvatarDisplay(self.SpecialGlideID, {bWear = true})
  else
    if curAvatar then
      EventSystem:postEvent(EVENTTYPE_CHARACTER_EFFECT, EVENTID_CHARACTER_EFFECT_APPLY, curAvatar:GetModel(), effectType)
    end
    self:ShowAvatarDisplay(self.SpecialGlideIDLeft, {bWear = true})
  end
end

function XSuit_Workshop_Main_UIBP:OnClickMask()
  self:PlayAudio(sound_config.click_v1)
  self.UIRoot.Panel_Mask:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
end

function XSuit_Workshop_Main_UIBP:OnClickClose()
  self:PlayAudio(sound_config.close_v1)
  self:CloseSelf()
end

function XSuit_Workshop_Main_UIBP:OnClickShare()
  self:PlayAudio(sound_config.click_v1)
  LogicXSuit.ShowGoldSuitShareUI(self.ItemResID)
end

function XSuit_Workshop_Main_UIBP:OnClickDetail()
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.XSuit_Workshop_Detail_UIBP, self.selectPeriod, self.selectBranchId)
end

function XSuit_Workshop_Main_UIBP:OnClickChangeColorButton(schemeIndex)
  self:PlayAudio(sound_config.click_v1)
  log_error("XSuit_Workshop_Main_UIBP:OnClickChangeColorButton schemeIndex=" .. tostring(schemeIndex) .. " curSchemeIndex=" .. tostring(self.schemeIndex))
  if self.schemeIndex == schemeIndex then
    self:_ApplySchemeId()
    return
  end
  self.schemeIndex = schemeIndex
  self._bChangingSchemeByClick = true
  self:UpdateChangeBranch()
  self:UpdateChangeBranchLock()
  self._bChangingSchemeByClick = nil
  self:_UpdateSchemeId()
  if self._targetRelateItem and self._targetRelateItem > 0 then
    self:TryShowEffect(false, true)
  else
    self:_ApplySchemeId()
  end
end

function XSuit_Workshop_Main_UIBP:_ClearTargetSchemeId()
  self._targetSchemeId = nil
  self._targetSchemeFeatureId = nil
  self._targetRelateItem = nil
end

function XSuit_Workshop_Main_UIBP:_GetCustomSchemeByItemId(itemId, featureId)
  if not itemId or itemId <= 0 then
    return nil
  end
  local period, branchId = self.selectPeriod, self.selectBranchId
  featureId = tonumber(featureId) or 0
  if 0 < featureId then
    local schemeCfg = CDataTable.GetTableDataByFilter("XSuitCustomScheme", "ItemID", itemId, "Period", period, "Branch", branchId, "FeatureID", featureId)
    if schemeCfg then
      return schemeCfg
    end
  end
  return CDataTable.GetTableDataByFilter("XSuitCustomScheme", "ItemID", itemId, "Period", period, "Branch", branchId)
end

function XSuit_Workshop_Main_UIBP:_UpdateSchemeId()
  local period = self.selectPeriod
  local branchId = self.selectBranchId
  local schemeIndex = self.schemeIndex or 1
  local collectCfg = LogicXSuit.GetXSuitWorkshopCollectCfg(period, self.selectFeatureIndex, self.selectLevel, branchId)
  if not collectCfg then
    log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_UpdateSchemeId no collectCfg, clear scheme. period:%s, feature:%s, level:%s, branch:%s", tostring(period), tostring(self.selectFeatureIndex), tostring(self.selectLevel), tostring(branchId)))
    self:_ClearTargetSchemeId()
    return
  end
  local itemId = collectCfg[string.format("ItemID%d", schemeIndex)]
  if not itemId or itemId <= 0 then
    log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_UpdateSchemeId itemId invalid, clear scheme. schemeIndex:%s, period:%s", tostring(schemeIndex), tostring(period)))
    self:_ClearTargetSchemeId()
    return
  end
  local schemeCfg = self:_GetCustomSchemeByItemId(itemId, collectCfg.CFeatureID)
  if not schemeCfg then
    log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_UpdateSchemeId schemeCfg not found, clear scheme. itemId:%s, period:%s", tostring(itemId), tostring(period)))
    self:_ClearTargetSchemeId()
    return
  end
  self._targetSchemeId = schemeCfg.SchemeID
  self._targetSchemeFeatureId = schemeCfg.FeatureID
  self._targetRelateItem = schemeCfg.RelateItem
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_UpdateSchemeId targetSchemeId=%s featureId=%s relateItem=%s", tostring(self._targetSchemeId), tostring(self._targetSchemeFeatureId), tostring(self._targetRelateItem)))
end

function XSuit_Workshop_Main_UIBP:_GetPreviewGroupKey()
  return string.format("%s_%s", tostring(self.selectPeriod), tostring(self.selectBranchId))
end

function XSuit_Workshop_Main_UIBP:_GetRememberedSchemeIndex(collectCfg)
  if self._bChangingSchemeByClick then
    return nil
  end
  local previewMap = self:_GetPreviewSchemeMap()
  if not collectCfg or not next(previewMap) then
    return nil
  end
  for index = 1, 3 do
    local itemId = collectCfg[string.format("ItemID%d", index)]
    if itemId and 0 < itemId then
      local schemeCfg = self:_GetCustomSchemeByItemId(itemId, collectCfg.CFeatureID)
      if schemeCfg and previewMap[schemeCfg.FeatureID] == schemeCfg.SchemeID then
        return index
      end
    end
  end
end

function XSuit_Workshop_Main_UIBP:_GetPreviewSchemeMap()
  local groupKey = self:_GetPreviewGroupKey()
  if self._previewGroupKey ~= groupKey then
    self._previewSchemeMap = {}
    self._previewGroupKey = groupKey
  end
  self._previewSchemeMap = self._previewSchemeMap or {}
  self._previewSchemeMap[groupKey] = self._previewSchemeMap[groupKey] or {}
  return self._previewSchemeMap[groupKey]
end

function XSuit_Workshop_Main_UIBP:_BuildClothSchemeList()
  local featureSchemeMap = {}
  local equippedSchemeList = LogicXSuit.GetSchemeIdByBranch(self.selectPeriod, self.selectBranchId)
  for featureId, schemeId in pairs(equippedSchemeList or {}) do
    if schemeId and 0 < schemeId then
      featureSchemeMap[featureId] = schemeId
    end
  end
  for featureId, schemeId in pairs(self:_GetPreviewSchemeMap()) do
    if schemeId and 0 < schemeId then
      featureSchemeMap[featureId] = schemeId
    end
  end
  local schemeList = {}
  for _, schemeId in pairs(featureSchemeMap) do
    table.insert(schemeList, schemeId)
  end
  return schemeList
end

function XSuit_Workshop_Main_UIBP:_ApplySchemeId()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  local groupKey = self:_GetPreviewGroupKey()
  if self._schemeAppliedGroupKey ~= groupKey then
    if avatar and avatar.SetClothSchemeIDList then
      avatar:SetClothSchemeIDList({})
      self._schemeAppliedGroupKey = groupKey
    else
      log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_ApplySchemeId avatar not ready, defer scheme clear. period:%s, branch:%s", tostring(self.selectPeriod), tostring(self.selectBranchId)))
    end
  end
  if not self._targetSchemeId then
    log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_ApplySchemeId no targetSchemeId, apply equipped only. period:%s, feature:%s", tostring(self.selectPeriod), tostring(self.selectFeatureIndex)))
    self:_ClearTargetSchemeId()
    self:_ApplyEquippedSchemeOnly()
    return
  end
  if not avatar or not avatar.SetClothSchemeIDList then
    log_error("XSuit_Workshop_Main_UIBP:_ApplySchemeId avatar is nil")
    return
  end
  local featureKey = self._targetSchemeFeatureId or math.floor(self._targetSchemeId / 100) % 100
  self:_GetPreviewSchemeMap()[featureKey] = self._targetSchemeId
  self:RemoveClothSchemeID(self._targetSchemeId)
  local schemeList = self:_BuildClothSchemeList()
  avatar:SetClothSchemeIDList(schemeList)
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_ApplySchemeId applied schemeId=%s featureKey=%s listCount=%s", tostring(self._targetSchemeId), tostring(featureKey), tostring(#schemeList)))
  self:_RefreshAvatarEffectCfg()
  self:_LogClothSchemeDebug("apply")
end

function XSuit_Workshop_Main_UIBP:_ApplyEquippedSchemeOnly()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  if not avatar or not avatar.SetClothSchemeIDList then
    return
  end
  local schemeList = self:_BuildClothSchemeList()
  if not schemeList or #schemeList <= 0 then
    return
  end
  avatar:SetClothSchemeIDList(schemeList)
  self:_RefreshAvatarEffectCfg()
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_ApplyEquippedSchemeOnly listCount=%s, period:%s, feature:%s", tostring(#schemeList), tostring(self.selectPeriod), tostring(self.selectFeatureIndex)))
  self:_LogClothSchemeDebug("equippedOnly")
end

function XSuit_Workshop_Main_UIBP:_RefreshAvatarEffectCfg()
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  local avatarComp = avatar and avatar.GetModelAvatarComp and avatar:GetModelAvatarComp()
  if not slua.isValid(avatarComp) then
    log_error("[XSuitScheme]RefreshEffectCfg avatarComp invalid")
    return false
  end
  local effectMgr = avatarComp.EffectManager or avatarComp.ChracterAvatarEffectMgr
  if not effectMgr or not effectMgr.RefreshEffectCfg then
    log_error("[XSuitScheme]RefreshEffectCfg effectMgr invalid")
    return false
  end
  effectMgr:RefreshEffectCfg()
  log(bWriteLog and "[XSuitScheme]RefreshEffectCfg done")
  return true
end

function XSuit_Workshop_Main_UIBP:BindAvatarMeshLoadedEvent()
  local avatar = self:GetShowingAvatar()
  local model = avatar and avatar.GetModel and avatar:GetModel()
  if not slua.isValid(model) or self._avatarMeshLoadedModel == model then
    return
  end
  self:UnbindAvatarMeshLoadedEvent()
  self:AddControlEventByControl(model, "OnAvatarComponentAllMeshLoaded", self.OnAvatarMeshLoadedReapplyScheme, self)
  self._avatarMeshLoadedModel = model
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:BindAvatarMeshLoadedEvent model=%s", tostring(model)))
end

function XSuit_Workshop_Main_UIBP:UnbindAvatarMeshLoadedEvent()
  local model = self._avatarMeshLoadedModel
  if slua.isValid(model) then
    self:RemoveControlEventByControl(model, "OnAvatarComponentAllMeshLoaded")
  end
  self._avatarMeshLoadedModel = nil
end

function XSuit_Workshop_Main_UIBP:OnAvatarMeshLoadedReapplyScheme()
  local count = self._nAvatarMeshApplyCount or 0
  if 3 <= count then
    log_error(string.format("XSuit_Workshop_Main_UIBP:OnAvatarMeshLoadedReapplyScheme too many times(%s), skip. period:%s, feature:%s", tostring(count), tostring(self.selectPeriod), tostring(self.selectFeatureIndex)))
    return
  end
  self._nAvatarMeshApplyCount = count + 1
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:OnAvatarMeshLoadedReapplyScheme apply target=%s, period:%s, feature:%s", tostring(self._targetSchemeId), tostring(self.selectPeriod), tostring(self.selectFeatureIndex)))
  self:_ApplySchemeId()
end

function XSuit_Workshop_Main_UIBP:_LogClothSchemeDebug(tag)
  if not bWriteLog then
    return
  end
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  local avatarComp
  if avatar then
    if avatar.GetModelAvatarComp then
      avatarComp = avatar:GetModelAvatarComp()
    else
      local model = avatar:GetModel()
      avatarComp = model and model.CharacterAvatarComp2_BP
    end
  end
  local idStr, count = "", 0
  if slua.isValid(avatarComp) and avatarComp.ClothSchemeIDMap then
    for id, _ in pairs(avatarComp.ClothSchemeIDMap) do
      idStr = idStr .. string.format("%08d", id) .. ","
      count = count + 1
    end
  end
  local previewStr = ""
  for featureKey, schemeId in pairs(self:_GetPreviewSchemeMap()) do
    previewStr = previewStr .. string.format("%s:%08d,", tostring(featureKey), schemeId)
  end
  log_error(string.format("[XSuitScheme]%s widget=%s avatar=%s comp=%s target=%s preview={%s} setCount=%s set={%s}", tostring(tag), tostring(self.widgetAvatarDisplay ~= nil), tostring(avatar ~= nil), tostring(slua.isValid(avatarComp)), tostring(self._targetSchemeId), previewStr, tostring(count), idStr))
end

function XSuit_Workshop_Main_UIBP:OnClickChangeStateButton(isLeft)
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnClickChangeStateButton" .. tostring(isLeft))
  local multiCfg = xsuit_config_and_cache.GetMultiTypeUnlockConfigByPeriod(self.selectPeriod)
  if multiCfg and isLeft == (multiCfg.left_index == self.CurState) then
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnClickChangeStateButton same side")
    return
  end
  if LogicXSuit.IsMultiStateCloth(self.ItemResID) then
    self.CurState = 3 - self.CurState
    self:UpdateCurXSuitInfo()
    self:UpdateChangeStateButton()
    self:UpdateButtonGroup()
    self:UpdateMaterial()
    self:RefreshFeatureComponent()
    self:TryShowEffect(true)
  else
    ShowNotice(7421)
  end
end

function XSuit_Workshop_Main_UIBP:OnClick_Help()
  self:PlayAudio(sound_config.click_v1)
  local guide_config = require("client.slua.umg.newbie_guide.multiple_guide_config")
  local id = tonumber(string.format("%d%d", self.ItemResID, self.selectFeatureIndex))
  local guideCfg = guide_config.GetGuidCfgById(id)
  local bRiding = self:IsSelectGlide()
  if bRiding and guideCfg and next(guideCfg) then
    UIManager.ShowUI(UIManager.UI_Config.ModeSelection_Guide_UIBP, id, 1, false, true)
    return
  end
  local UIUtil = require("client.common.ui_util")
  local pos = UIUtil.GetWidgetViewportPos(self.UIRoot.Button_5)
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnClick_Help:" .. pos.X .. "," .. pos.Y)
  if self.clickHelpImage then
    UIManager.ShowUI(UIManager.UI_Config.XSuit_Workshop_Help_UIBP, self.clickHelpTitle, self.clickHelpDesc, self.clickHelpImage)
    return
  end
  self.clickHelpUI = UIManager.ShowUI(UIManager.UI_Config.common_float_tips)
  local TipsParam = {
    offsetX = 0,
    offsetY = -50,
    wrapWidthType = 1,
    bgOffset = {
      -15,
      -10,
      -15,
      -10
    }
  }
  self.clickHelpUI:SetTips(self.UIRoot.Button_5, self.clickHelpDesc, TipsParam)
end

function XSuit_Workshop_Main_UIBP:OnClickSex()
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnClickSex")
  self:PlayAudio(sound_config.click_v1)
  local StoreUtils = require("client.slua.logic.store.utils.store_utils")
  if not StoreUtils.IsCanSwitchSex(self.ItemResID) then
    ShowNotice(LocUtil.LocalizeResFormat(8797))
    return
  end
  if self.nSexIdx == 0 then
    self.nSexIdx = 1
  else
    self.nSexIdx = 0
  end
  self.UIRoot.WidgetSwitcher_sex:SetActiveWidgetIndex(self.nSexIdx == 0 and 1 or 0)
  local curAvatar = self:GetShowingAvatar()
  if curAvatar then
    curAvatar:SwitchSex()
  end
end

function XSuit_Workshop_Main_UIBP:OnClick_SwitchSlide()
  self:PlayAudio(sound_config.click_v1)
  self.nSlideIdx = 1 - self.nSlideIdx
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnClick_SwitchSlide " .. tostring(self.nSlideIdx))
  self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(self.nSlideIdx)
  self:UpdateSlideButton()
  self:TryShowEffect(true)
end

function XSuit_Workshop_Main_UIBP:OnClick_SwitchPose()
  self:PlayAudio(sound_config.click_v1)
  self.nPoseSwitch = 1 - self.nPoseSwitch
  print(bWriteLog and string.format(" XSuit_Workshop_Main_UIBP:OnClick_SwitchPose self.nPoseSwitch:%s", self.nPoseSwitch))
  self.UIRoot.WidgetSwitcher_1:SetActiveWidgetIndex(self.nPoseSwitch)
  local levelInfo = self.CurUpgradeInfo and self.CurUpgradeInfo[self.selectLevel]
  local data = levelInfo and levelInfo.cfg
  if not data then
    print(bWriteLog and " XSuit_Workshop_Main_UIBP:OnClick_SwitchPose data is nil")
    return
  end
  local PoseID = data.PoseID
  if self.nPoseSwitch == 0 then
    local curAvatar = self:GetShowingAvatar()
    if curAvatar then
      curAvatar(PoseID)
    else
      print(bWriteLog and " XSuit_Workshop_Main_UIBP:OnClick_SwitchPose curAvatar is nil")
    end
  else
    self:StopEmotion()
  end
end

function XSuit_Workshop_Main_UIBP:OnAndroidBack()
  self:CloseSelf()
end

function XSuit_Workshop_Main_UIBP:OnClick_Guide()
  self:PlayAudio(sound_config.click_v1)
  local guideCfg = require("client.slua.umg.XSuit_Workshop.Config.XSuit_Guide_Config")
  guideCfg.ShowGuide("Workshop", true)
end

function XSuit_Workshop_Main_UIBP:OnClickCollectTips()
  self:PlayAudio(sound_config.click_v1)
  if not self.CollectTipUI then
    self.CollectTipUI = self:CreateChildWindowWithLuaAndBpPath(self.UIRoot.CanvasPanel_Tips, UIManager.UI_Config.XSuit_Branch_Tips_UIBP, "client.slua.umg.XSuit_Workshop.Popup.XSuit_Branch_Tips_UIBP", "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Item/XSuit_Branch_Tips_UIBP.XSuit_Branch_Tips_UIBP", self.UIRoot.Button_Lock_Star, {X = 0, Y = -10}, self.collectItemId, self.selectPeriod, self.selectBranchId)
    self.showCollectTip = true
  else
    self.showCollectTip = not self.showCollectTip
    if self.showCollectTip then
      self.CollectTipUI:Update(self.collectItemId, self.selectPeriod)
      self:AddTimerOnce(0.01, function()
        if self.CollectTipUI and self.CollectTipUI.UpdatePosition then
          self.CollectTipUI:UpdatePosition()
        end
      end)
    end
  end
  self.CollectTipUI:SetMoreBtnVisible(true)
  self.CollectTipUI:SetTrigger(self.UIRoot.Button_Lock_Star, self.selectBranchId)
  self:SetWidgetVisible(self.CollectTipUI, self.showCollectTip)
end

function XSuit_Workshop_Main_UIBP:OnDrawActivityUpdate()
  self:InitMoneyComponent()
  self:UpdateButtonGroup()
  self:RefreshGlideComponent()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  if not logic_xsuit_activity:GetExchangeData() then
    log(bWriteLog and "RequestExchangeData OnDrawActivityUpdate")
    logic_xsuit_activity:RequestExchangeData()
  end
end

function XSuit_Workshop_Main_UIBP:OnExchangeDataRsp()
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnExchangeDataRsp")
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  local luckybackactivity_mgr = require("client.slua.logic.lobby_activity.logic_luckyback_activity")
  logic_xsuit_activity:SetExchangeData(luckybackactivity_mgr.exchangeItemList)
  self.upgradeMaterialInfo = {}
  self:UpdateMaterial()
  self:InitMoneyComponent()
  self.ExtendedLoopScrollBox_Level:RefreshAllSubItems()
end

function XSuit_Workshop_Main_UIBP:OnApplicationReactivated()
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnApplicationReactivated")
  self:UpdateScene()
end

function XSuit_Workshop_Main_UIBP:OnUpgradeRspCallBack(_, _, cur_level, period, branch_id)
  self.upgradeMaterialInfo = {}
  self:StopEmotion()
  self:CacheCurXSuitInfo()
  self:SetPeriodTabData()
end

function XSuit_Workshop_Main_UIBP:IsMoneyCoinResID(resID)
  if not resID then
    return false
  end
  for _, coinId in ipairs(self.coinIDList or {}) do
    if coinId == resID then
      return true
    end
  end
  for _, extraId in pairs(self.coinExtraCountMap or {}) do
    if extraId == resID then
      return true
    end
  end
  return false
end

function XSuit_Workshop_Main_UIBP:OnHallDepotChange(_, _, tChangeData)
  if not tChangeData or not self.UIRoot then
    return
  end
  for _, v in pairs(tChangeData) do
    if self:IsMoneyCoinResID(v.res_id) then
      self:InitMoneyComponent()
      break
    end
  end
  local materialList = self.MaterialComp and self.MaterialComp:GetMaterialList()
  if not materialList then
    return
  end
  local bHit = false
  for _, v in pairs(tChangeData) do
    for _, material in ipairs(materialList) do
      if v.res_id == material.resID then
        bHit = true
        break
      end
    end
    if bHit then
      break
    end
  end
  if not bHit then
    return
  end
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnHallDepotChange refresh upgrade material")
  self.upgradeMaterialInfo = {}
  self:UpdateMaterial()
  self:RefreshUpgradeReddots()
end

function XSuit_Workshop_Main_UIBP:OnFeatureGet(_, _, resid)
  if self._IsClosed or not self.UIRoot then
    return
  end
  printf("XSuit_Workshop_Main_UIBP:OnFeatureGet resid:%s", tostring(resid))
  self:UpdateChangeBranch()
  self:UpdateChangeBranchLock()
  self:RefreshBranchCollectRewardReddot()
end

function XSuit_Workshop_Main_UIBP:OnCollectInfoUpdate(_, _)
  if self._IsClosed or not self.UIRoot then
    return
  end
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnCollectInfoUpdate refresh collect reward reddot")
  self:RefreshBranchCollectRewardReddot()
  self:UpdateChangeBranch()
  self:UpdateChangeBranchLock()
end

function XSuit_Workshop_Main_UIBP:OnActionStop(eventType, eventID, actionID)
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:OnActionStop eventType=%s eventID=%s actionID=%s enterActionID=%s", tostring(eventType), tostring(eventID), tostring(actionID), tostring(self.enterActionID)))
  if self.enterActionID == actionID then
    self.enterActionID = nil
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnActionStop enterActionID matched, tryShowEffect")
    self:TryShowEffect()
  elseif self.changeStateActionId == actionID then
    self.changeStateActionId = nil
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:OnActionStop changeStateActionId matched, tryShowEffect")
    self:TryShowEffect()
  end
  self:SetVolume(true)
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local avatar = ModelDisplayer.GetShowingAvatar()
  local _ = avatar and avatar:SetCanRotate(true)
end

function XSuit_Workshop_Main_UIBP:UpdateMaterialWithData()
  LogicXSuit.jumpList = {}
  self:UpdateMaterial()
end

function XSuit_Workshop_Main_UIBP:VideoEndHandler()
  self:ShowAvatar()
  self:SetVolume(true)
  if self._targetSchemeId then
    self:_ApplySchemeId()
  end
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:PlaySpinAudio_BG(1, self.selectPeriod)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Root, true)
end

function XSuit_Workshop_Main_UIBP:TryHighLevelAction(actionId)
  local newActionId = actionId
  local limitScene = xsuit_config_and_cache.GetLimitSceneConfigByActionId(actionId)
  if limitScene then
    if limitScene.sceneName and limitScene.scenePath and (_G.IsEditor or PufferDownloader.PufferJsonDownloadReturn) then
      local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {
        limitScene.scenePath
      })
      if state == PufferConst.ENUM_DownloadState.Done then
        newActionId = limitScene.newAction
      end
    end
    local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
    local preScene = self.LastSceneNameByType[ConstAvatarDislay.ESceneType.XSuitWorkshop]
    if newActionId == actionId and limitScene.showLimit and (not preScene or not limitScene.showLimit[preScene]) then
      newActionId = nil
    end
  end
  return newActionId
end

function XSuit_Workshop_Main_UIBP:CheckXsuitDrawing()
  local TimeUtil = require("client.common.time_util")
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  local endTime = logic_xsuit_activity:GetDrawEndTime()
  if endTime and endTime > TimeUtil.GetServerTimeInSec() then
    return true, endTime
  end
  return false
end

function XSuit_Workshop_Main_UIBP:ChekckIsLimitCoin(currency)
  for _, coinId in ipairs(self.limitMoneyList or {}) do
    if coinId == currency then
      return true
    end
  end
  return false
end

function XSuit_Workshop_Main_UIBP:GetDownloadListAndStatus(period, branchId)
  if not self.downListByPeriod then
    self.downListByPeriod = {}
  end
  if period and not self.downListByPeriod[period] then
    local LogicKillInfo = require("client.slua.logic.kill_info.logic_killinfo")
    local cfg = LogicXSuit.GetUpgradeUIInfo(period)
    local upgradeInfo, bBranch = LogicXSuit.GetUpgradeInfo(period)
    local periodCfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", period, "IsBranch", 0)
    for _branchId, config in pairs(not bBranch and {
      [0] = upgradeInfo
    } or upgradeInfo) do
      local branchDownList = {}
      local addList = {}
      for _level, levelInfo in ipairs(config) do
        self:AddDownloadList(branchDownList, addList, levelInfo.item_id)
        local itemCfg = CDataTable.GetTableData("Item", levelInfo.item_id)
        if not itemCfg then
          break
        end
        self:AddDownloadList(branchDownList, addList, itemCfg.Preview)
        self:AddDownloadList(branchDownList, addList, itemCfg.ItemBigIcon2)
        self:AddDownloadList(branchDownList, addList, itemCfg.ItemBigIcon)
        self:AddDownloadList(branchDownList, addList, levelInfo.cfg.UpgradeSuccessIcon)
        self.changeStateConfig[levelInfo.item_id] = {}
        local changeConfig = CDataTable.GetTableDataByFilter("StateChangeActionConfig", "BeforeClothID", levelInfo.item_id)
        if changeConfig then
          self:AddDownloadList(branchDownList, addList, changeConfig.ActionID)
          self.changeStateConfig[levelInfo.item_id].changeActionId = changeConfig.ActionID
          self.changeStateConfig[levelInfo.item_id].bOrder1 = changeConfig.IsPlayAnimAfterTransform == 1
        end
        local changeBackConfig = CDataTable.GetTableDataByFilter("StateChangeActionConfig", "AfterClothID", levelInfo.item_id)
        if changeBackConfig then
          self:AddDownloadList(branchDownList, addList, changeBackConfig.ActionID)
          self.changeStateConfig[levelInfo.item_id].changeBackActionId = changeBackConfig.ActionID
          self.changeStateConfig[levelInfo.item_id].bOrder2 = changeBackConfig.IsPlayAnimAfterTransform == 1
        end
        for _, effectId in ipairs(levelInfo.effect_id_array) do
          if 0 < tonumber(effectId) then
            local effectInfo = CDataTable.GetTableData("GoldenSuitEffectCfg", tonumber(effectId))
            if effectInfo and 0 < effectInfo.ActionID then
              self:AddDownloadList(branchDownList, addList, effectInfo.ActionID)
            end
            if effectInfo and effectInfo.Type == self.enum_effect.kill_broadcast then
              local killBroadList = LogicKillInfo.GetXSuitKillInfoAssetList(levelInfo.item_id)
              for _, bp in ipairs(killBroadList) do
                self:AddDownloadList(branchDownList, addList, bp)
              end
            elseif effectInfo and effectInfo.Type == self.enum_effect.video then
              self:AddDownloadList(branchDownList, addList, DataMgr.GetVideoDownloadPath(effectInfo.ResPath))
            end
          end
        end
        if _level == #config then
          local glideCfg = CDataTable.GetTableDataByFilter("XSuitGlideCfg", "XSuitID7", levelInfo.item_id)
          if glideCfg then
            self:AddDownloadList(branchDownList, addList, glideCfg.GlideID)
            self:AddDownloadList(branchDownList, addList, glideCfg.SpecialGlideID)
          end
          local DRConfig = xsuit_config_and_cache.GetDRGlideByXSuit7(levelInfo.item_id)
          if DRConfig then
            self:AddDownloadList(branchDownList, addList, DRConfig.DRGlideID)
            self:AddDownloadList(branchDownList, addList, DRConfig.GlideID)
          end
        end
      end
      local branchCfg = LogicXSuit.GetUpgradeUIInfoByBranchId(period, _branchId)
      self:AddDownloadList(branchDownList, addList, branchCfg and branchCfg.UpgradeSpecialShow)
      self:AddDownloadList(branchDownList, addList, periodCfg and periodCfg.UpgradeSpecialShow)
      if cfg.ScenePath and cfg.ScenePath ~= "" then
        self:AddDownloadList(branchDownList, addList, cfg.ScenePath)
      end
      self.downListByPeriod[period] = self.downListByPeriod[period] or {}
      self.downListByPeriod[period][_branchId] = branchDownList
    end
  end
  local downList = {}
  if period and branchId then
    downList = self.downListByPeriod[period][branchId]
  elseif period then
    for _branchId, branchDownList in pairs(self.downListByPeriod[period]) do
      for _, value in pairs(branchDownList) do
        table.insert(downList, value)
      end
    end
  end
  return downList, PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, downList) or PufferConst.ENUM_DownloadState.Done
end

function XSuit_Workshop_Main_UIBP:AddDownloadList(downloadList, addList, idOrPath)
  if not idOrPath or idOrPath == "" or idOrPath == 0 then
    return
  end
  if addList[idOrPath] then
    return
  end
  table.insert(downloadList, idOrPath)
  addList[idOrPath] = true
end

function XSuit_Workshop_Main_UIBP:LoadGlideScene(bLoad, bSkipRestoreScene)
  local GlideSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GlideSystem)
  if bLoad then
    local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
    GlideSystem:EnterGlideScene(ConstAvatarDislay.ESceneType.XSuitWorkshop, self:GetShowingAvatar())
    self:SetVolume(false)
  else
    GlideSystem:ExitGlideScene()
    self:SetVolume(true)
    if not bSkipRestoreScene then
      self:AddTimerOnce(0, function()
        if not slua.isValid(self.UIRoot) then
          return
        end
        if self:IsGlideShow() then
          return
        end
        self:UpdateScene()
      end)
    end
  end
end

function XSuit_Workshop_Main_UIBP:CheckAndDownload(actionID, bShowNotice)
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:CheckAndDownload " .. tostring(actionID) .. "bShowNotice" .. tostring(bShowNotice))
  if not actionID or actionID == 0 then
    return false
  end
  local state = PufferManager.GetState(PufferConst.ENUM_DownloadType.ODPAK, {actionID})
  if state ~= PufferConst.ENUM_DownloadState.Done then
    log(bWriteLog and "CheckAndDownload not download")
    local PufferSwitch = require("client.slua.logic.download.puffer_switch")
    if bShowNotice and PufferSwitch.CanAutoDownload() then
      ShowNotice(7421)
    end
    PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, {actionID}, PufferTlog.Enum_TLog_From.Emote, nil, {bAutoDownload = true})
    return false
  end
  return true
end

function XSuit_Workshop_Main_UIBP:IsSelectGlide()
  if not self.CurUpgradeInfo then
    return false, false
  end
  local curFeatureId = self.CurUpgradeInfo[self.selectLevel].tab_name_array[self.selectFeatureIndex]
  if curFeatureId == self.enum_featureType.riding or curFeatureId == self.enum_featureType.glideEx then
    return true, false
  end
  if curFeatureId == self.enum_featureType.glide then
    return false, true
  end
  return false
end

function XSuit_Workshop_Main_UIBP:IsGlideShow()
  if not (self.CurUpgradeInfo and self.selectLevel) or not self.selectFeatureIndex then
    return false
  end
  local levelInfo = self.CurUpgradeInfo[self.selectLevel]
  if not levelInfo or not levelInfo.tab_name_array then
    return false
  end
  local bRiding, bGlide = self:IsSelectGlide()
  return (bRiding or bGlide) and true or false
end

function XSuit_Workshop_Main_UIBP:SetVolume(bUp)
  if not self.canSetting then
    return
  end
  local audio_util = require("client.common.audio_util")
  local userSettings = slua_GameFrontendHUD:GetUserSettings()
  if userSettings.BGMVolumSwitcher then
    audio_util.SetRTPCValue("VolumeControl_Music", bUp and userSettings.BGMVolumValue * 100 or 30, 200)
  end
end

function XSuit_Workshop_Main_UIBP:SetAsyncLoadingTimeLimit(nNewValue)
  if not HDmpveRemote.HDmpveRemoteConfigGetBool("EnableStoreAsyncLoadingTimeLimit", true) then
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:_SetAsyncLoadingTimeLimit - Disabled by remote config")
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local gameInstance = STExtraGameInstance.GetInstance()
  if not gameInstance then
    log(bWriteLog and "XSuit_Workshop_Main_UIBP:_SetAsyncLoadingTimeLimit - GameInstance is nil")
    return
  end
  if self.cachedAsyncLoadingTimeLimit == nil then
    self.cachedAsyncLoadingTimeLimit = gameInstance:GetAsyncLoadingTimeLimit()
  end
  gameInstance:SetAsyncLoadingTimeLimit(nNewValue)
  log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:_SetAsyncLoadingTimeLimit - Set AsyncLoadingTimeLimit to %s, cached original: %s", tostring(nNewValue), tostring(self.cachedAsyncLoadingTimeLimit)))
end

function XSuit_Workshop_Main_UIBP:RestoreAsyncLoadingTimeLimit()
  if self.cachedAsyncLoadingTimeLimit ~= nil then
    local STExtraGameInstance = import("STExtraGameInstance")
    local gameInstance = STExtraGameInstance.GetInstance()
    if gameInstance then
      gameInstance:SetAsyncLoadingTimeLimit(self.cachedAsyncLoadingTimeLimit)
      log(bWriteLog and string.format("XSuit_Workshop_Main_UIBP:RestoreAsyncLoadingTimeLimit - Restored AsyncLoadingTimeLimit to %s", tostring(self.cachedAsyncLoadingTimeLimit)))
    end
    self.cachedAsyncLoadingTimeLimit = nil
  end
end

function XSuit_Workshop_Main_UIBP:InitDownloadBtn()
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:InitDownloadBtn")
  local common_download_handler = require("client.slua.common.common_download_handler")
  local extra = {
    showSize = true,
    hideMask = true,
    size = 50,
    callback = function()
      log(bWriteLog and "XSuit_Workshop_Main_UIBP:InitDownloadBtn - callback" .. tostring(self.bBranch))
      if self.bBranch then
        self:RefreshOnePeriodTab(self.selectPeriod)
        self:RefreshOneBranchTab(self.selectBranchId)
        self:SelectOneBranchTab(self.selectBranchId)
        self:UpdateScene()
      else
        self:RefreshOnePeriodTab(self.selectPeriod)
        self:SelectOnePeriodTab(self.selectPeriod)
      end
    end
  }
  local tItemList = self:GetDownloadListAndStatus(self.selectPeriod, self.selectBranchId)
  local size = 0
  local _, totalSize = PufferManager.GetSize(PufferConst.ENUM_DownloadType.ODPAK, tItemList)
  size = math.floor(totalSize / PufferConst.MB * 100) / 100
  log(bWriteLog and "XSuit_Workshop_Main_UIBP:InitDownloadBtn - size: " .. size)
  extra.showAlertSize = true
  common_download_handler.CreateDownloadUIReturnUIBase(PufferConst.ENUM_DownloadType.ODPAK, tItemList, self, self.UIRoot.Panel_Download, extra)
end

function XSuit_Workshop_Main_UIBP:GetRealFeatureByScheme(feature)
  local customCfg = CDataTable.GetTableDataByFilter("XSuitCustomScheme", "RelateItem", feature)
  if customCfg then
    local previewCfg = self._targetSchemeId and CDataTable.GetTableDataByFilter("XSuitCustomScheme", "SchemeID", self._targetSchemeId)
    if previewCfg and previewCfg.FeatureID == customCfg.FeatureID and previewCfg.RelateItem and previewCfg.RelateItem > 0 then
      return previewCfg.RelateItem
    end
    local schemeList = LogicXSuit.GetSchemeIdByBranch(self.selectPeriod, self.selectBranchId)
    local realSchemeId = schemeList and schemeList[customCfg.FeatureID]
    if realSchemeId then
      local realSchemeCfg = CDataTable.GetTableData("XSuitCustomScheme", realSchemeId)
      return realSchemeCfg and realSchemeCfg.RelateItem > 0 and realSchemeCfg.RelateItem
    end
  end
end

return CGolden_Suit_Upgrade
