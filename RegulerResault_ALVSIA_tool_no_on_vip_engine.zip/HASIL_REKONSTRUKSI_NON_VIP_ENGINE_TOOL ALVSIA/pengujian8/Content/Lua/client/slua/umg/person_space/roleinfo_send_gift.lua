do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(114, 225, 89, 198, 49)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 133, 17, 162, 72, 147, 147, 220, 37, 224, 197, 106, 97, 92, 99, 228, 126, 185, 17))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 230, 198, 106, 97))
      _ARG_0_.SendCount = 1
      _ARG_0_.Msg = U1()
      _ARG_0_.GiftSource = _ARG_2_ or U2.GiftSourceType.PersonSpace
      _ARG_0_.receiver_uid = _ARG_5_
      _ARG_0_.forbidGiftMap = _ARG_3_
      _ARG_0_.PageType = U3.EPageType.Normal
      if _ARG_6_ and _ARG_6_.PageType then
        _ARG_0_.PageType = _ARG_6_.PageType
      end
      if _ARG_0_.PageType == U3.EPageType.Wow and not LobbySystem.CheckOpen(BP_ENUM_WOW_CREATIVITY_SWITCH) then
        _ARG_0_.PageType = U3.EPageType.Normal
      end
      _ARG_0_.StoreGiftUI = nil
      _ARG_0_.LongAddHandle = nil
      _ARG_0_.LongSubHandle = nil
      _ARG_0_.LongAdd10Handle = nil
      _ARG_0_.hasNoticeLimit = false
      _ARG_0_.ShouldClearNew = false
      _ARG_0_.LimitedTimeTipsUI = nil
      _ARG_0_.battle_id = _ARG_4_
      _ARG_0_.MaxWordCount = 40
      _ARG_0_.timeLimitGiftTimerMap = {}
      _ARG_0_.extParams = _ARG_6_
      _ARG_0_.CachedResourcesReady = {}
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_.GiftScrollBox = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Space)
      _ARG_0_.UIRoot.RedPoint_Arrow_Right:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.RedPoint_Arrow_Left:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.StoreGiftUI = U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.UIComponentModule).Config.send_store_gift, _ARG_0_.UIRoot, _ARG_0_.GiftSource, _ARG_0_.receiver_uid)
      _ARG_0_.CSelectedColor = _ARG_0_.UIRoot.BPColorTabSelect
      _ARG_0_.CUnselectedColor = _ARG_0_.UIRoot.BPColorTabNormal
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_PARTY_GET_USED_ITEMS, _ARG_0_.OnPartyGetUsedItems, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_GET_GIFT_RECORD_RSP, _ARG_0_.CheckRefreshUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_PSPACE_GIFT_CONFIG_RSP, _ARG_0_.CheckRefreshUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_PSPACE_SEND_GIFT_RSP, _ARG_0_.CheckRefreshUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CHAT, U1.EVENTTYPE_CHAT_EMOJI_CLICK_INDEX, _ARG_0_.ChatEmoji, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_SEND_GIFT, _ARG_0_.ToSendGift, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_GIFT_GET_COUPON_DISCOUNT_DATA, _ARG_0_.OnGetDiscountInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_GIFT_DISCOUNT_UI_CLOSE, _ARG_0_.OnDiscountUIClose, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_BYBLACKLIST_UPDATE, _ARG_0_.OnByBlackListUpdate, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_APPLICATION_ACTIVE_STATE, U1.EVENTID_APPLICATION_REACTIVATED, _ARG_0_.OnApplicationReactivated, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_APPLICATION_ACTIVE_STATE, U1.EVENTID_APPLICATION_REACTIVATED_EX, _ARG_0_.OnApplicationReactivated, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_GIFT_POPULARITY_FILTER_SET, _ARG_0_.OnPopularityFilterSet, _ARG_0_)
      if U1.EVENTTYPE_PLANPH_NORMAL and U1.EVENTID_PARTY_STATE_END then
        _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PLANPH_NORMAL, U1.EVENTID_PARTY_STATE_END, _ARG_0_.HandlePartyEnd, _ARG_0_)
      end
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.out, U2(94, 227, 121, 219, 43, 88, 2, 115, 52, 249, 97, 156, 13, 165, 126, 134, 137, 216, 44), _ARG_0_.OnAnimationFinished, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.fadein, U2(94, 227, 121, 219, 43, 88, 2, 115, 52, 249, 97, 156, 13, 165, 126, 134, 137, 216, 44), function()
        if GiftScrollBox and GiftScrollBox:GetSelectIndex() ~= 0 then
        end
        return
      end)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Image_3, U2(94, 227, 117, 218, 55, 70, 6, 69, 40, 226, 123, 181, 10, 143, 120, 130, 143, 248, 62, 224, 220, 113), function()
        if UIManager then
          U1:PlayAudio(sound_config.close_v1)
          U1:PlayUserWidgetAnimation(U1.UIRoot.out, 0, 1, 0, 1)
          return import((U2(70, 228, 92, 210, 39, 65, 33, 107, 40, 243, 127, 168, 13, 165, 99, 185, 136, 223, 58, 228, 192, 124))).Handled()
        end
        return
      end)
      _ARG_0_.GiftScrollBox:SetRefreshItemCallback(_ARG_0_.OnUpdateGiftItem, _ARG_0_)
      _ARG_0_.GiftScrollBox:AddItemWidgetChildEvent(U2(83, 248, 76, 193, 45, 91, 60, 84, 40, 244, 91, 187, 6), U2(94, 227, 123, 217, 43, 86, 8, 98, 57), _ARG_0_.OnClickGiftItem, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.btn_emoji, function()
        _ENV:PlayAudio(U1.sound_config.click_v1)
        U1.UIManager.ShowUI(U1.UIManager.UI_Config.chat_emoji)
        return
      end)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.message_input, U2(94, 227, 108, 208, 58, 65, 32, 104, 48, 251, 102, 174, 16, 174, 115), function(_ARG_0_, _ARG_1_)
        do
          log(bWriteLog and U1(94, 227, 108, 208, 58, 65, 32, 104, 48, 251, 102, 174, 16, 174, 115))
          U2.Msg = U3.CheckNameRetrunName(_ARG_0_, nil, U2.MaxWordCount, true)
          U2.UIRoot.message_input:SetText(U2.Msg)
          U2:SetHinTextStatus()
          U2:UpdateTextCount()
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.message_input, U2(94, 227, 108, 208, 58, 65, 32, 111, 60, 248, 104, 191, 0), function(_ARG_0_, _ARG_1_)
        do
          log(bWriteLog and U1(94, 227, 108, 208, 58, 65, 32, 111, 60, 248, 104, 191, 0))
          U2.Msg = U3.CheckNameRetrunName(_ARG_0_, nil, U2.MaxWordCount, true)
          U2.UIRoot.message_input:SetText(U2.Msg)
          U2:SetHinTextStatus()
          U2:UpdateTextCount()
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.MultiLineEditableTextBox_Count, U2(94, 227, 108, 208, 58, 65, 32, 104, 48, 251, 102, 174, 16, 174, 115), function(_ARG_0_, _ARG_1_)
        do
          log(bWriteLog and U1(94, 227, 108, 208, 58, 65, 32, 104, 48, 251, 102, 174, 16, 174, 115))
          if math.type(tonumber(_ARG_0_)) ~= U1(120, 227, 76, 208, 37, 80, 17) then
          elseif _ARG_0_ == U1() or tonumber(_ARG_0_) <= 0 then
            U2.SendCount = 1
          else
            U2.SendCount = tonumber(_ARG_0_)
          end
          U2:ClipSendCount()
          U2:RefreshMain()
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.MultiLineEditableTextBox_Count, U2(94, 227, 108, 208, 58, 65, 32, 111, 60, 248, 104, 191, 0), function(_ARG_0_, _ARG_1_)
        do
          log(bWriteLog and U1(94, 227, 108, 208, 58, 65, 32, 111, 60, 248, 104, 191, 0))
          if math.type(tonumber(_ARG_0_)) ~= U1(120, 227, 76, 208, 37, 80, 17) then
          elseif _ARG_0_ == U1() or 0 >= tonumber(_ARG_0_) then
            U2.SendCount = 1
          else
            U2.SendCount = tonumber(_ARG_0_)
          end
          U2:ClipSendCount()
          U2:RefreshMain()
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Tip, function()
        if CanShowGiftGuide() then
          U1.DataMgr.SetNewbieGuide(U1.DataMgr.NEWBIE_GUIDE_MODULE_ID_PSPACE_GIFT, 1)
        end
        U2:RefreshTips()
        return
      end)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Send, _ARG_0_.OnSend, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Add, _ARG_0_.AddClicked, _ARG_0_)
      _ARG_0_:AddOnPressedEventByControl(_ARG_0_.UIRoot.Button_Add, _ARG_0_.AddPressed, _ARG_0_)
      _ARG_0_:AddOnReleasedEventByControl(_ARG_0_.UIRoot.Button_Add, _ARG_0_.AddReleased, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Sub, _ARG_0_.SubClicked, _ARG_0_)
      _ARG_0_:AddOnPressedEventByControl(_ARG_0_.UIRoot.Button_Sub, _ARG_0_.SubPressed, _ARG_0_)
      _ARG_0_:AddOnReleasedEventByControl(_ARG_0_.UIRoot.Button_Sub, _ARG_0_.SubReleased, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Add10, _ARG_0_.Add10Clicked, _ARG_0_)
      _ARG_0_:AddOnPressedEventByControl(_ARG_0_.UIRoot.Button_Add10, _ARG_0_.Add10Pressed, _ARG_0_)
      _ARG_0_:AddOnReleasedEventByControl(_ARG_0_.UIRoot.Button_Add10, _ARG_0_.Add10Released, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Arrow_Right, _ARG_0_.OnMouseButtonDownEvent_Right, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Arrow_Left, _ARG_0_.OnMouseButtonDownEvent_Left, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Law, _ARG_0_.OnClickLaw, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.LoopScrollGrid_Space, U2(94, 227, 109, 198, 39, 71, 48, 100, 47, 249, 99, 182, 1, 175), _ARG_0_.OnUserScrolled, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_1, _ARG_0_.OnClickPround, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Restrict, _ARG_0_.OnClickRestrict, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Filter, _ARG_0_.OnClickButton_Filter, _ARG_0_)
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHinTextStatus"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 214, 215, 113, 91, 94, 35, 210, 122, 178, 0, 136, 115, 132, 133, 216, 43))
      if _ARG_0_.UIRoot.message_input:GetText() == U1() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTextCount"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 208, 194, 97, 114, 67, 40, 210, 122, 178, 0, 152, 104, 144, 159, 217))
      if U2.get_utf8_blen(_ARG_0_.UIRoot.message_input:GetText() or U1()) >= _ARG_0_.MaxWordCount then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAnimationFinished"] = function(_ARG_0_)
    do
      _ARG_0_:AddTimerOnce(0, function()
        _ENV:CloseSelf()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_.receiver_uid) then
        return
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsByBlacklist(_ARG_0_.receiver_uid) then
        return
      end
      if U1.tostring(U3.CurRecordUID) == U1.tostring(_ARG_0_.receiver_uid) and U3.gift_config and _ARG_0_.GiftSource ~= U4.GiftSourceType.TeamCompetionResultRebot then
      elseif _ARG_0_.GiftSource == U4.GiftSourceType.TeamCompetionResultRebot then
        if U1.BattleResultUI and U1.BattleResultUI.AlreadyUpvotedUID and U1.BattleResultUI.AlreadyUpvotedUID[U1.tostring(_ARG_0_.receiver_uid)] then
        else
        end
      else
      end
      if U1.GameStatus.IsInFightingPHomeMode() then
      end
      if _ARG_0_.UIRoot.SizeBox_ThematicGift then
        if _ARG_0_.GiftSource ~= U4.GiftSourceType.PlanCH_RankPK then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      ResetPopularityFilter()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTabAndText"] = function(_ARG_0_)
    do
      if GameStatus.IsInFightingPHomeMode() and _ARG_0_.GiftSource ~= U3.GiftSourceType.GiftExchange then
        _ARG_0_.PageType = U2.EPageType.Home
      elseif _ARG_0_.GiftSource == U3.GiftSourceType.PopularHomePK then
        _ARG_0_.PageType = U2.EPageType.Home
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshActivityTab"] = function(_ARG_0_)
    do
      if _ARG_0_.GiftSource == GiftSourceType.PopularHomePK then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Normal, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Guard, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Home, true)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Activity, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Intimacy, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_UGC, false)
        return
      end
      goto lbl_119
      if _ARG_0_:IsGiftResourcesReady(nil) then
        if (nil).GiftType == U3.EGiftType.Normal then
        elseif (nil).GiftType == U3.EGiftType.Guard then
        elseif (nil).GiftType == U3.EGiftType.Home then
        elseif (nil).GiftType == U3.EGiftType.Activity or (nil).GiftType == U3.EGiftType.Heat then
        elseif (nil).GiftType == U3.EGiftType.Intimacy then
        elseif (nil).GiftType == U3.EGiftType.Wow and U2.LobbySystem.CheckOpen(U2.BP_ENUM_WOW_CREATIVITY_SWITCH) then
          if _ARG_0_.extParams and _ARG_0_.extParams.shield == U3.EPageType.Wow then
          else
          end
        end
      end
      ::lbl_119::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUI"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshActivityTab()
      _ARG_0_:RefreshGiftItems()
      _ARG_0_:RefreshMsg()
      _ARG_0_:RefreshProundLabel()
      _ARG_0_:RefreshPopularityFilter()
      _ARG_0_:ShowEmptyTabNoticeIfNeeded()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMsg"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.message_input:SetText(_ARG_0_.Msg)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLaw"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CanvasPanel_Law:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if GlobalData.IsJapanOrKorea() and FuncUtil.GetAccountRegionForBP() == require((table.concat({
        U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 7, 164, 121, 147, 136, 218, 102, 198, 222, 108, 118, 89, 57, 203, 126, 169, 6, 180, 116, 203, 176, 206, 59, 250, 215, 123, 119, 117),
        U1(116, 234, 81, 218, 44, 115, 12, 117, 31, 198, 66, 187, 7, 185, 120, 134)
      }))).KR and _ARG_0_.GiftScrollBox:GetSelectIndex() ~= 0 and (_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 2 or _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 4 or _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).PriceType == 2) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClipSendCount"] = function(_ARG_0_)
    do
      _ARG_0_.SendCount = math.max(_ARG_0_.SendCount, 1)
      if _ARG_0_.GiftScrollBox:GetSelectIndex() ~= 0 then
        _ARG_0_.SendCount = math.min(_ARG_0_.SendCount, (U1.GetRemainCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId, _ARG_0_.receiver_uid)))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChatEmoji"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.Msg = _ARG_0_.Msg .. _ENV(52) .. U1.tostring(_ARG_3_)
      _ARG_0_:RefreshMsg()
      U1.UIManager.CloseUI(U1.UIManager.UI_Config.chat_emoji)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUserScrolled"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_14
      if U1.IsGiftNew(_ARG_0_.GiftScrollBox:GetSetData().GiftId) then
      end
      ::lbl_14::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_102
      if _ARG_0_.UIRoot.LoopScrollGrid_Space:GetScrollOffset() > (slua.IndexReference(_ARG_0_.UIRoot.LoopScrollGrid_Space, (U2(88, 249, 93, 216, 17, 92, 25, 98))).X + slua.IndexReference(_ARG_0_.UIRoot.LoopScrollGrid_Space, (U2(65, 236, 92, 209, 43, 91, 4))).X) * 100 then
      end
      if _ARG_0_.UIRoot.LoopScrollGrid_Space:GetScrollOffset() + require((U2(114, 225, 81, 208, 44, 65, 77, 100, 50, 251, 98, 181, 10, 229, 98, 156, 190, 200, 60, 236, 222))).GetLocalSize(_ARG_0_.UIRoot.LoopScrollGrid_Space).X < (slua.IndexReference(_ARG_0_.UIRoot.LoopScrollGrid_Space, (U2(88, 249, 93, 216, 17, 92, 25, 98))).X + slua.IndexReference(_ARG_0_.UIRoot.LoopScrollGrid_Space, (U2(65, 236, 92, 209, 43, 91, 4))).X) * (100 - 1) then
      end
      ::lbl_102::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMouseButtonDownEvent_Right"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMouseButtonDownEvent_Left"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Add10Clicked"] = function(_ARG_0_)
    do
      _ARG_0_.SendCount = _ARG_0_.SendCount + 10
      _ARG_0_:CheckLimitTips()
      _ARG_0_:ClipSendCount()
      _ARG_0_:RefreshMain()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckLimitTips"] = function(_ARG_0_)
    do
      if _ARG_0_.GiftScrollBox:GetSelectIndex() == 0 then
        return
      end
      if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).MaxDevote ~= MaxSendCount then
        return
      end
      if _ARG_0_.SendCount > MaxSingleSendCount and not _ARG_0_.hasNoticeLimit then
        _ARG_0_.hasNoticeLimit = true
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Add10Pressed"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.hasNoticeLimit = false
      _ARG_0_.LongAdd10Handle = _ARG_0_:AddTimerLoop(0.1, function()
        _ENV = _ENV + 0.1
        U1.SendCount = U2 + 10 * (nil)(_ENV)
        U1:CheckLimitTips()
        U1:ClipSendCount()
        U1:RefreshMain()
        return
      end, TIMER_INFINITE, 0.1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Add10Released"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddClicked"] = function(_ARG_0_)
    do
      _ARG_0_.SendCount = _ARG_0_.SendCount + 1
      _ARG_0_:CheckLimitTips()
      _ARG_0_:ClipSendCount()
      _ARG_0_:RefreshMain()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddPressed"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.hasNoticeLimit = false
      _ARG_0_.LongAddHandle = _ARG_0_:AddTimerLoop(0.1, function()
        _ENV = _ENV + 0.1
        U1.SendCount = U2 + (nil)(_ENV)
        U1:CheckLimitTips()
        U1:ClipSendCount()
        U1:RefreshMain()
        return
      end, TIMER_INFINITE, 0.1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddReleased"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SubClicked"] = function(_ARG_0_)
    do
      _ARG_0_.SendCount = _ARG_0_.SendCount - 1
      _ARG_0_:ClipSendCount()
      _ARG_0_:RefreshMain()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SubPressed"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.LongSubHandle = _ARG_0_:AddTimerLoop(0.1, function()
        _ENV = _ENV + 0.1
        U1.SendCount = U2 - (nil)(_ENV)
        U1:ClipSendCount()
        U1:RefreshMain()
        return
      end, TIMER_INFINITE, 0.1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SubReleased"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshPage"] = function(_ARG_0_)
    do
      if GlobalData.IsJapanOrKorea() and FuncUtil.GetAccountRegionForBP() == require((table.concat({
        U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 7, 164, 121, 147, 136, 218, 102, 198, 222, 108, 118, 89, 57, 203, 126, 169, 6, 180, 116, 203, 176, 206, 59, 250, 215, 123, 119, 117),
        U1(116, 234, 81, 218, 44, 115, 12, 117, 31, 198, 66, 187, 7, 185, 120, 134)
      }))).KR then
      end
      if _ARG_0_.PageType ~= U2.EPageType.Store then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsGiftResourcesReady"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId] ~= nil then
        return _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId]
      end
      if tonumber(_ARG_1_.GiftId) == 301 and not LobbySystem.CheckOpen(20254) then
        _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId] = false
        return false
      end
      if require((U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 8, 164, 112, 156, 130, 147, 47, 236, 212, 113, 61, 91, 34, 225, 118, 169, 43, 168, 98, 139, 149, 242, 63, 252, 196, 97))).GetLimitTime(_ARG_1_.GiftId) == 0 then
        _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId] = false
        return false
      end
      if not require((U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 8, 164, 112, 156, 130, 147, 47, 236, 212, 113, 61, 91, 34, 225, 118, 169, 43, 173, 110, 129, 148, 194, 7, 242, 203, 115, 119))).IsVideoGift(_ARG_1_.GiftId) then
        _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId] = true
        return true
      end
      if require((U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 8, 164, 112, 156, 130, 147, 47, 236, 212, 113, 61, 91, 34, 225, 118, 169, 43, 173, 110, 129, 148, 194, 7, 242, 203, 115, 119))).IsGiftVideoDownloaded(_ARG_1_.GiftId) then
        _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId] = true
        return true
      end
      _ARG_0_.CachedResourcesReady[_ARG_1_.GiftId] = _ARG_1_.GiftAni and _ARG_1_.GiftAni ~= U1(), _ARG_0_.CachedResourcesReady, _ARG_1_.GiftId
      do return _ARG_1_.GiftAni and _ARG_1_.GiftAni ~= U1() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshSubPage"] = function(_ARG_0_)
    do
      goto lbl_48
      if _ARG_0_.GiftSource ~= U2.GiftSourceType.PlanCH_RankPK then
        if (nil).GiftId == U3.PlanCH_CollectRankGift then
        end
      elseif not IsPlanCHRankPKOpenTime() and (nil).GiftId == U3.PlanCH_CollectRankGift then
      end
      ::lbl_48::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.PageType == 4 then
      end
      if 1 <= #{} then
        _ARG_0_.bDefaultSelect = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSend"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckGiftRestrict() then
        return
      end
      if _ARG_0_.PageType == U2.EPageType.Store then
        return
      end
      if not require((table.concat({
        U1(114, 225, 81, 208, 44, 65, 77, 107, 50, 241, 102, 185, 74, 168, 120, 152, 140, 210, 38, 171, 222, 106, 116, 94, 46, 217, 126, 169, 23, 190, 116, 150, 174, 223, 61, 230, 214, 103, 106, 68),
        U1(101, 228, 87, 219)
      }))).CheckAccessAndPopTips(require((table.concat({
        U1(114, 225, 81, 208, 44, 65, 77, 107, 50, 241, 102, 185, 74, 168, 120, 152, 140, 210, 38, 171, 222, 106, 116, 94, 46, 217, 126, 169, 23, 190, 116, 150, 174, 223, 61, 230, 214, 103, 106, 68),
        U1(101, 228, 87, 219)
      }))).EAccessType.SpaceGift) then
        return
      end
      if _ARG_0_.GiftScrollBox:GetSelectIndex() ~= 0 then
        if 0 < _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).Price and U3.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId) < _ARG_0_.SendCount and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):CheckUCRestrict() then
          return
        end
        if U3.CheckCanDevote(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId, _ARG_0_.receiver_uid) then
          if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 0 or _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 3 then
            if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).Price == 0 then
            else
            end
          elseif _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).ItemID ~= 0 then
            if 0 < _ARG_0_.SendCount and U3.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId) >= _ARG_0_.SendCount then
            else
              if GameStatus.IsInLobbyOrMainCity() then
                if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).JumpModule ~= U1() then
                elseif GlobalData.CheckCanJumpByTypeID(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).ItemID, require((U1(114, 225, 81, 208, 44, 65, 77, 107, 50, 241, 102, 185, 74, 184, 99, 154, 147, 216, 102, 239, 199, 104, 99, 104, 56, 242, 118, 166, 7))).ENUM_JUMP_TYPE.Store) then
                else
                end
              elseif _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 4 then
              else
              end
              return
            end
          end
        elseif _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId == 11 or _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId == 667 then
        else
        end
      end
      do return end
      _ARG_0_ = U1.OnSend
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndSendGift"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_.PriceType == 1 then
      elseif _ARG_1_.PriceType == 2 then
      end
      if 7171 ~= 0 then
        if _ARG_1_.PriceType == 2 then
          if U2.GetHallDepotGiftCount(_ARG_1_.GiftId) >= _ARG_0_.SendCount then
          end
          if _ARG_1_.HornConfig == 2 then
            return
          end
          if LobbySystem.CheckOpen(BP_ENUM_CHAT_HORN_SWITCH) and _ARG_1_.HornConfig == 0 then
            if U2.GetGiftEffectParam(_ARG_1_.GiftId, _ARG_0_.SendCount, U3.PopularityEffectType.MessageBroadcast) then
            end
          else
          end
        elseif _ARG_1_.PriceType == 1 then
          if U2.GetHallDepotGiftCount(_ARG_1_.GiftId) >= _ARG_0_.SendCount then
            return
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PopHornSendGiftPannel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if 10066 == _ARG_3_ then
      end
      if DataMgr.IsMoneyEnough(StoreConst.label_price_type_uc, _ARG_2_) then
        if _ARG_0_.GiftSource == U2.GiftSourceType.PopularTSLPK then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PopNormalGiftPannel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if 10066 == _ARG_3_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendGifts"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 214, 215, 107, 119, 112, 36, 224, 107, 185))
      log_tree(U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 214, 215, 107, 119, 112, 36, 224, 107, 185), _ARG_1_)
      if _ARG_0_.GiftSource == U2.GiftSourceType.PopularTSLPK then
        return
      end
      if _ARG_1_.GiftId == 11 or _ARG_1_.GiftId == 667 then
        if _ARG_0_.GiftSource == U2.GiftSourceType.TeamCompetionResult or _ARG_0_.GiftSource == U2.GiftSourceType.TeamCompetionResultRebot then
        else
          BP_RecordUpvoteTeammateUID = tostring(_ARG_0_.receiver_uid)
          if tonumber(_ARG_0_.receiver_uid) ~= nil then
            if BattleResultUI.AlreadyUpvotedUID then
              BattleResultUI.AlreadyUpvotedUID[tostring((tonumber(_ARG_0_.receiver_uid)))] = true
            end
          end
        end
      elseif _ARG_0_.GiftSource ~= U2.GiftSourceType.TeamCompetionResultRebot then
        if GameStatus.IsInFightingPHomeMode() then
        end
      end
      if _ARG_0_.GiftSource == U2.GiftSourceType.ReturnGuide then
      end
      if true and _ARG_0_.GiftSource == U2.GiftSourceType.MainCityInfoCard then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SwitchMsgOpen"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(66, 250, 81, 193, 33, 93, 46, 116, 58, 217, 127, 191, 10, 241) .. tostring(_ARG_0_.IsOpenQuikMsg))
      _ARG_0_.IsOpenQuikMsg = not _ARG_0_.IsOpenQuikMsg
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMain"] = function(_ARG_0_)
    do
      if _ARG_0_.PageType == EPageType.Store then
        return
      end
      if _ARG_0_.GiftScrollBox:GetSelectIndex() ~= 0 then
        if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).CreativeScore and 0 < _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).CreativeScore then
        end
        if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftType ~= 2 then
        else
        end
        if _ARG_0_.GiftSource == U4.GiftSourceType.PopularTSLPK and _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).PriceType == 2 and U1.LobbySystem.CheckOpen(U1.BP_ENUM_CHAT_HORN_SWITCH) and _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).HornConfig == 0 then
        else
        end
        if 2 >= _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).PriceType then
        end
        if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 0 or _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySource == 3 then
          if _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).Price == 0 then
          elseif U3.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId) >= _ARG_0_.SendCount then
          elseif U1.DataMgr.IsMoneyEnough(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).PriceType, _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).Price * (_ARG_0_.SendCount - U3.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId))) then
          else
          end
        elseif 0 <= _ARG_0_.SendCount and U3.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId) >= _ARG_0_.SendCount and U3.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).GiftId) >= 1 then
        elseif _ARG_0_.GiftScrollBox:GetItemData((_ARG_0_.GiftScrollBox:GetSelectIndex())).BuySourceDesc == 0 then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPartyGetUsedItems"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 202, 220, 85, 114, 69, 57, 255, 88, 175, 0, 142, 116, 128, 149, 228, 44, 240, 207, 102))
      _ARG_0_:AddTimerOnce(0, function()
        _ENV:CheckRefreshUI()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckRefreshUI"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 198, 218, 96, 112, 92, 31, 227, 121, 184, 17, 168, 111, 176, 184, 141, 63, 240, 214, 74, 115, 72),
        U1(97, 248, 84, 212, 48, 92, 23, 126, 103, 179, 124)
      }), U2.CachedUid.get_popularity))
      log(bWriteLog and string.format(U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 198, 199, 119, 70, 126, 9, 166, 37, 239, 7), _ARG_0_.receiver_uid))
      if tostring(U3.CurRecordUID) == tostring(_ARG_0_.receiver_uid) and U3.gift_config then
        _ARG_0_:RefreshUI()
        _ARG_0_:OnUserScrolled(_ARG_0_.UIRoot.LoopScrollGrid_Space:GetScrollOffset(), true)
        U3.ReqTitleProfile()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateGiftItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_1_.HorizontalBox_0, true)
      if not _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_) then
        return
      end
      if #U2.Split(_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).NoticeParam, (U1(43))) == 1 then
      elseif tonumber(U2.Split(_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).NoticeParam, (U1(43)))[1]) == 1 then
      else
      end
      if _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).BuySource == 0 or _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).BuySource == 3 then
        if _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).Price == 0 then
        else
        end
      else
      end
      if 2 >= _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).PriceType then
      end
      if 0 < U3.GetLimitTime(_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId) then
        if _ARG_0_.timeLimitGiftTimerMap[_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId] then
          _ARG_0_.timeLimitGiftTimerMap[_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId] = nil
        end
        _ARG_0_.timeLimitGiftTimerMap[_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId] = _ARG_0_:AddTimerLoop(0, function()
          if U2.require((U3(114, 225, 81, 208, 44, 65, 77, 100, 50, 251, 98, 181, 10, 229, 99, 156, 140, 216, 23, 240, 198, 108, 127))).FormatCountDownTime_DH_or_HM((GetLimitTime(U1.GiftId))) == U3() then
            U4.timeLimitGiftTimerMap[U1.GiftId] = nil
          end
          return
        end, TIMER_INFINITE, 1)
      end
      if _ARG_0_.GiftScrollBox:GetSelectIndex() == _ARG_2_ then
        if not _ARG_1_:isAnimationPlaying(_ARG_1_.fadein_Title) then
        end
      else
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_gift_download):IsGiftResourceDownloaded(_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[243]
    end
  end,
  ["RefreshGiftItemsForDownloaded"] = function(_ARG_0_)
    do
      if not _ARG_0_ or not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      if not (_ARG_0_.GiftScrollBox and _ARG_0_.GiftScrollBox:GetSetData()) or #(_ARG_0_.GiftScrollBox and _ARG_0_.GiftScrollBox:GetSetData()) == 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[206]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLimitedTimeTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 214, 218, 106, 100, 123, 36, 235, 118, 190, 17, 191, 83, 140, 156, 200, 12, 252, 210, 102))
      if not _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_) then
        return
      end
      if _ARG_0_.UIRoot:isAnimationPlaying(_ARG_0_.UIRoot.fadein) then
        return
      end
      if U2.GetHallDepotGiftCount(_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId) > 0 then
        if _ARG_0_.LimitedTimeTipsUI then
        else
          _ARG_0_.LimitedTimeTipsUI = _ARG_0_:CreateChildWindowWithLuaAndBpPath(U1(82, 236, 86, 195, 35, 70, 51, 102, 51, 243, 99, 133, 45, 155, 79), nil, table.concat({
            U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 17, 166, 112, 219, 145, 216, 58, 246, 221, 107, 76, 68, 61, 231, 124, 175, 90, 169, 104, 137, 148, 196, 54, 243, 205, 74, 100, 78),
            U1(119, 249, 103, 217, 43, 88, 10, 115, 56, 242, 80, 174, 13, 166, 114, 170, 149, 212, 56, 246)
          }), (table.concat({
            U1(62, 202, 89, 216, 39, 26, 54, 74, 26, 185, 90, 147, 59, 137, 71, 218, 177, 216, 58, 246, 221, 107, 64, 71, 44, 229, 122, 229, 29, 175, 98, 136, 222, 225, 55, 247, 192, 108, 92, 117),
            U1(126, 225, 93, 252, 44, 83, 12, 88, 17, 255, 98, 179, 16, 174, 115, 161, 136, 208, 45, 218, 230, 108, 99, 68, 18, 211, 86, 136, 36, 245, 75, 138, 147, 207, 33, 202, 240, 122, 111, 66),
            U1(88, 227, 94, 218, 29, 121, 10, 106, 52, 226, 106, 190, 48, 162, 122, 144, 190, 233, 33, 245, 193, 90, 70, 126, 15, 214)
          })))
        end
      else
      end
      do return end
      _ARG_0_ = LimitedTimeTipsUI
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideLimitedTimeTips"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 205, 219, 97, 118, 123, 36, 235, 118, 190, 17, 191, 83, 140, 156, 200, 12, 252, 210, 102))
      if _ARG_0_.LimitedTimeTipsUI then
        _ARG_0_.LimitedTimeTipsUI:Close()
        _ARG_0_.LimitedTimeTipsUI = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGiftItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_gift_download):IsGiftResourceDownloaded(_ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId) then
        if GameStatus.IsInFightingNotSocialNotMainCityNotHome() and PufferDownloader.BattleDownloadSwitch then
        else
        end
        return
      end
      if _ARG_0_.GiftScrollBox:GetSelectIndex() ~= _ARG_2_ or _ARG_0_.bDefaultSelect then
        _ARG_0_.bDefaultSelect = false
        _ARG_0_.SendCount = 1
        if _ARG_0_:IsCurPopularityDataMatch() then
          goto lbl_279
          if U1(126, 250, 86, 217, 45, 84, 7, 39, 36, 243, 123) == _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_).GiftId and U1(126, 250, 86, 217, 45, 84, 7, 39, 36, 243, 123).provide_uid then
          else
            ::lbl_279::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
        if require((table.concat({
          U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 8, 164, 112, 156, 130, 147, 36, 234, 208, 103, 106, 25, 1, 227, 121, 190, 90, 183, 104, 130, 152, 206, 7, 249, 205, 119, 97, 94),
          U1(78, 254, 87, 214, 43, 84, 15)
        }))).GetProfileByUID(U1(126, 250, 86, 217, 45, 84, 7, 39, 36, 243, 123).provide_uid) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayClickGiftAni"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 213, 222, 100, 106, 116, 33, 239, 124, 161, 51, 178, 97, 145, 176, 195, 49, 167))
      if not _ARG_0_.GiftScrollBox:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearGiftItems"] = function(_ARG_0_)
    do
      if not _ARG_0_.GiftScrollBox then
        return
      end
      _ARG_0_.GiftScrollBox:SetData({})
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGiftItems"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 232, 94, 199, 39, 70, 11, 64, 52, 240, 123, 147, 16, 174, 122, 134, 219) .. tostring(_ARG_0_.tabType))
      _ARG_0_:OnRefreshSubPage()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTips"] = function(_ARG_0_)
    do
      if _ARG_0_.GiftSource == U2.GiftSourceType.PopularTSLPK then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToSendGift"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      useRadio = _ARG_4_
      chatContent = _ARG_5_
      bIsHornFree = _ARG_6_
      _ARG_0_:SendGifts(_ARG_3_, _ARG_7_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickLaw"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPround"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(74, 255, 87, 217, 39, 92, 13, 97, 50, 201, 124, 191, 10, 175, 72, 146, 136, 219, 60, 216, 146, 74, 125, 116, 33, 239, 124, 161, 36, 169, 104, 144, 159, 201))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.Lobby_RoleInfo_Pround_Popup_UIBP, DataMgr.roleData.uid)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRestrict"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(74, 255, 87, 217, 39, 92, 13, 97, 50, 201, 124, 191, 10, 175, 72, 146, 136, 219, 60, 216, 146, 74, 125, 116, 33, 239, 124, 161, 38, 190, 116, 145, 131, 196, 59, 225))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Filter"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(74, 255, 87, 217, 39, 92, 13, 97, 50, 201, 124, 191, 10, 175, 72, 146, 136, 219, 60, 216, 146, 74, 125, 116, 33, 239, 124, 161, 54, 174, 115, 145, 158, 195, 7, 211, 203, 121, 119, 66),
        U1(99)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U2.GetPopularityFilter() and not U2.GetPopularityFilter() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeTab"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.PageType ~= _ARG_1_ and _ARG_2_ then
        _ARG_0_:PlayAudio(sound_config.click_v1)
      end
      _ARG_0_ = _ARG_0_
      if _ARG_1_ == nil then
      else
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.PageType == _ARG_1_ and _ARG_2_ then
        _ARG_0_:ShowEmptyTabNoticeIfNeeded()
        return
      end
      _ARG_0_.SendCount = 1
      _ARG_0_.PageType = _ARG_1_
      _ARG_0_:OnRefreshPage()
      if _ARG_2_ then
        _ARG_0_:ShowEmptyTabNoticeIfNeeded()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowEmptyTabNoticeIfNeeded"] = function(_ARG_0_)
    do
      if _ARG_0_.PageType == EPageType.Store then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Empty, false)
        return
      end
      if #_ARG_0_.GiftScrollBox:GetSetData() == 0 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Empty, true)
        _ARG_0_.UIRoot.TextBlock_Empty:SetText(U1.LocUtil.GetLocalizeResStr(18010219))
      else
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Empty, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshProundLabel"] = function(_ARG_0_)
    do
      if DataMgr.roleData.pround_info and DataMgr.roleData.pround_info.level and DataMgr.roleData.pround_info.level > 0 then
        if _ARG_0_.UIRoot.Pround_Level_Icon_UIBP then
          _ARG_0_.UIRoot.Pround_Level_Icon_UIBP:SetData(DataMgr.roleData.uid)
        end
        _ARG_0_.UIRoot.TextBlock_1:SetText(LocUtil.LocalizeResFormat(43187))
      else
        if _ARG_0_.UIRoot.Pround_Level_Icon_UIBP then
          _ARG_0_.UIRoot.Pround_Level_Icon_UIBP:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        _ARG_0_.UIRoot.TextBlock_1:SetText(LocUtil.LocalizeResFormat(43188))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPopularityFilter"] = function(_ARG_0_)
    do
      if not GetPopularityFilter() and not GetPopularityFilter() then
      elseif GetPopularityFilter() and GetPopularityFilter() then
      elseif GetPopularityFilter() then
      elseif GetPopularityFilter() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGiftRestrict"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateGiftDiscountActEntrance"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_space_gift_discount_packet):GetDiscountData() and GameStatus.IsInLobbyOrMainCity() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDiscountActEntrance"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_space_gift_discount_packet):IsCanShowActEntrance() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_space_gift_discount_packet):IsNeedShowAnim((U1(97, 225, 89, 204, 3, 64, 23, 104, 18, 230, 106, 180, 37, 165, 126, 152))) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetDiscountInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(74, 251, 103, 194, 46, 89, 20, 114, 0, 182, 93, 181, 8, 174, 94, 155, 135, 210, 27, 224, 220, 97, 84, 94, 43, 242, 74, 131, 78, 148, 105, 162, 148, 217, 28, 252, 209, 118, 108, 82),
        U1(127, 249, 113, 219, 36, 90)
      }))
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDiscountUIClose"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(74, 251, 103, 194, 46, 89, 20, 114, 0, 182, 93, 181, 8, 174, 94, 155, 135, 210, 27, 224, 220, 97, 84, 94, 43, 242, 74, 131, 78, 148, 105, 161, 152, 222, 59, 250, 215, 123, 119, 114),
        U1(88, 206, 84, 218, 49, 80)
      }))
      if UIManager.GetUI(UIManager.UI_Config.SpaceGift_DiscountPacket_Entrance_UIBP) then
        return
      end
      _ARG_0_:ShowDiscountActEntrance()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnByBlackListUpdate"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 202, 220, 71, 106, 117, 33, 231, 124, 161, 56, 178, 116, 145, 164, 221, 60, 244, 214, 112))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsByBlacklist(_ARG_0_.receiver_uid) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnApplicationReactivated"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 202, 220, 68, 99, 71, 33, 239, 124, 171, 0, 178, 104, 139, 163, 200, 57, 246, 214, 124, 117, 70),
        U1(101, 232, 92)
      }))
      _ARG_0_:CloseSelf()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPopularityFilterSet"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 202, 220, 85, 124, 71, 56, 234, 126, 184, 29, 175, 126, 163, 152, 193, 44, 240, 208, 70, 102, 83))
      _ARG_0_.SendCount = 1
      _ARG_0_:RefreshUI()
      _ARG_0_:OnUserScrolled(_ARG_0_.UIRoot.LoopScrollGrid_Space:GetScrollOffset(), true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HandlePartyEnd"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 205, 211, 107, 119, 91, 40, 214, 126, 184, 0, 162, 66, 139, 149))
      _ARG_0_:CloseSelf()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Close"] = function(_ARG_0_)
    do
      _ARG_0_.StoreGiftUI = nil
      _ARG_0_:ClearGiftItems()
      if _ARG_0_.ShouldClearNew then
        ClearAllGiftNew()
        _ARG_0_.ShouldClearNew = false
      end
      U1.EventSystem:postEvent(U1.EVENTTYPE_PERSON_SPACE, U1.EVENTID_POPULARITY_SEND_GIFT_CLOSE)
      U2.__super.Close(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCurPopularityDataMatch"] = function(_ARG_0_)
    do
      do return tostring(U1.CurPopularityDataUID) == tostring(_ARG_0_.receiver_uid) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitLightBoardGift"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitChatRoomGiftList"] = function(_ARG_0_)
    do
      if not _ARG_0_.giftListIns then
        _ARG_0_.giftListIns = require((table.concat({
          U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 17, 166, 112, 219, 141, 210, 42, 231, 203, 90, 112, 95, 44, 242, 49, 169, 28, 186, 115, 151, 158, 194, 53, 187, 225, 125, 98, 83),
          U1(67, 226, 87, 216, 29, 114, 10, 97, 41, 201, 67, 179, 23, 191, 72, 160, 168, 255, 24)
        })))(), require((table.concat({
          U1(114, 225, 81, 208, 44, 65, 77, 116, 49, 227, 110, 244, 17, 166, 112, 219, 141, 210, 42, 231, 203, 90, 112, 95, 44, 242, 49, 169, 28, 186, 115, 151, 158, 194, 53, 187, 225, 125, 98, 83),
          U1(67, 226, 87, 216, 29, 114, 10, 97, 41, 201, 67, 179, 23, 191, 72, 160, 168, 255, 24)
        })))():InitWithParentWidget(_ARG_0_, _ARG_0_.UIRoot.ChatRoom_Gift_List_UIBP)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowChatRoomGiftList"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 214, 218, 106, 100, 116, 37, 231, 107, 152, 27, 180, 106, 162, 152, 203, 44, 217, 203, 102, 119))
      if not _ARG_0_.giftListIns then
        log(bWriteLog and table.concat({
          U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 214, 218, 106, 100, 116, 37, 231, 107, 152, 27, 180, 106, 162, 152, 203, 44, 217, 203, 102, 119, 7),
          U1(127, 226, 24, 210, 43, 83, 23, 75, 52, 229, 123, 147, 10, 184)
        }))
        return
      end
      if _ARG_0_.GiftSource == U2.GiftSourceType.ChatRoom then
        _ARG_0_.giftListIns:ShowGiftList(_ARG_0_.receiver_uid)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.LightBoard_Gift_UIBP, false)
      else
        _ARG_0_.giftListIns:HideGiftList()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitSendGiftPlayer"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 204, 220, 108, 103, 100, 40, 232, 123, 141, 29, 189, 115, 181, 157, 204, 33, 240, 208))
      if not _ARG_0_.extParams or not _ARG_0_.extParams.bShowPlayerList then
        log(bWriteLog and table.concat({
          U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 204, 220, 108, 103, 100, 40, 232, 123, 141, 29, 189, 115, 181, 157, 204, 33, 240, 208, 53, 109, 72),
          U1(101, 173, 86, 208, 39, 81, 67, 119, 49, 247, 118, 191, 22, 235, 123, 156, 146, 201)
        }))
        return
      end
      if not GameStatus.IsInFightingPHomeMode() then
        log(bWriteLog and table.concat({
          U1(67, 226, 84, 208, 11, 91, 5, 104, 14, 243, 97, 190, 35, 162, 113, 129, 180, 244, 114, 204, 220, 108, 103, 100, 40, 232, 123, 141, 29, 189, 115, 181, 157, 204, 33, 240, 208, 53, 109, 72),
          U1(101, 173, 81, 219, 98, 93, 12, 106, 56)
        }))
        return
      end
      if #ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint):GetMemberList() < 2 then
        return
      end
      return
    end
  end
})) end
return
