do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(200, 13, 93, 94, 236)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 165, 33, 14, 180, 59, 41, 48, 33, 120, 24, 157, 140, 72, 234, 70, 238, 153, 33))), nil, {
  is_owner = false,
  isPasswordHidden = false,
  cur_select_widget = nil,
  cur_select_index = 0,
  room_type = ({
    NORMAL = 1,
    ALLSTAR = 2,
    TOURNAMENT = 3
  }).NORMAL,
  room_mode = ({
    SINGLE = 1,
    DOUBLE = 2,
    TEAM = 3
  }).SINGLE,
  my_team_widget = nil,
  my_team_teamItem_index = 0,
  isOnlyShow = true,
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.last_change_pos_time = 0
      _ARG_0_.is_asia = _ARG_2_ or false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_:InitializeWidgetDiff()
      _ARG_0_.is_owner = U1.RoomSystem.isRoomOwner()
      _ARG_0_.isPasswordHidden = true
      if _ARG_0_.UIRoot.WBP_EyePasswordButton then
        _ARG_0_.EyePasswordButton = U1.require((U1.table.concat({
          U2(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 33, 10, 140, 115, 41, 62, 35, 112, 65, 155, 138, 70, 169, 10, 216, 168, 20, 40, 190, 52, 46, 17, 61, 126, 12, 149, 129, 65),
          U2(207, 35, 73, 89, 235, 173, 224)
        })))()
      end
      _ARG_0_.cur_select_widget = nil
      _ARG_0_.cur_select_index = 0
      _ARG_0_.room_type = U3.NORMAL
      _ARG_0_.room_mode = U4.SINGLE
      _ARG_0_.my_team_widget = nil
      _ARG_0_.my_team_teamItem_index = 0
      _ARG_0_.isOnlyShow = true
      _ARG_0_.UIRoot.WidgetSwitcher_2:SetActiveWidgetIndex(0)
      _ARG_0_.loopGridSingle = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Single)
      _ARG_0_.loopGridSingle:SetRefreshItemCallback(_ARG_0_.OnSingleItemInit, _ARG_0_)
      _ARG_0_.loopGridSingle:AddItemWidgetChildEvent(U2(233, 20, 72, 89, 240, 172, 209, 64, 177, 88, 250, 153, 32, 2, 143), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnItemSelect, _ARG_0_)
      _ARG_0_.loopGridSingle:AddItemWidgetChildEvent(U2(233, 20, 72, 89, 240, 172, 209, 88, 189, 87, 244), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnItemKick, _ARG_0_)
      _ARG_0_.loopGridSingle:AddItemWidgetChildEvent(U2(233, 20, 72, 89, 240, 172, 209, 95, 187, 87, 244), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridDouble = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Double)
      _ARG_0_.loopGridDouble:SetRefreshItemCallback(_ARG_0_.OnDoubleItemInit, _ARG_0_)
      _ARG_0_.loopGridDouble:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 203, 122, 37, 158, 41, 47, 62, 34, 66, 60, 151, 146, 70, 167, 80, 234, 142), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnDoubleItemSelect1, _ARG_0_)
      _ARG_0_.loopGridDouble:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 203, 122, 37, 158, 41, 47, 62, 34, 66, 36, 155, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnDoubleItemKick1, _ARG_0_)
      _ARG_0_.loopGridDouble:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 200, 122, 37, 158, 41, 47, 62, 34, 66, 60, 151, 146, 70, 167, 80, 234, 142), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnDoubleItemSelect2, _ARG_0_)
      _ARG_0_.loopGridDouble:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 200, 122, 37, 158, 41, 47, 62, 34, 66, 36, 155, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnDoubleItemKick2, _ARG_0_)
      _ARG_0_.loopGridDouble:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 203, 122, 37, 158, 41, 47, 62, 34, 66, 35, 157, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridDouble:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 200, 122, 37, 158, 41, 47, 62, 34, 66, 35, 157, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridTeam = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Team)
      _ARG_0_.loopGridTeam:SetRefreshItemCallback(_ARG_0_.OnTeamItemInit, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 203, 122, 37, 158, 41, 47, 62, 34, 66, 60, 151, 146, 70, 167, 80, 234, 142), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemSelect1, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 203, 122, 37, 158, 41, 47, 62, 34, 66, 36, 155, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemKick1, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 200, 122, 37, 158, 41, 47, 62, 34, 66, 60, 151, 146, 70, 167, 80, 234, 142), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemSelect2, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 200, 122, 37, 158, 41, 47, 62, 34, 66, 36, 155, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemKick2, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 201, 122, 37, 158, 41, 47, 62, 34, 66, 60, 151, 146, 70, 167, 80, 234, 142), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemSelect3, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 201, 122, 37, 158, 41, 47, 62, 34, 66, 36, 155, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemKick3, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 206, 122, 37, 158, 41, 47, 62, 34, 66, 60, 151, 146, 70, 167, 80, 234, 142), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnDoubleItemSelect4, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 206, 122, 37, 158, 41, 47, 62, 34, 66, 36, 155, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnTeamItemKick4, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 203, 122, 37, 158, 41, 47, 62, 34, 66, 35, 157, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 200, 122, 37, 158, 41, 47, 62, 34, 66, 35, 157, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 201, 122, 37, 158, 41, 47, 62, 34, 66, 35, 157, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridTeam:AddItemWidgetMultilevelChildEvent(U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192, 206, 122, 37, 158, 41, 47, 62, 34, 66, 35, 157, 157, 72), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnLockClick, _ARG_0_)
      _ARG_0_.loopGridTeam8v8 = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_8perpon)
      if _ARG_0_.loopGridTeam8v8 then
        _ARG_0_.loopGridTeam8v8:SetRefreshItemCallback(_ARG_0_.OnTeam8v8ItemInit, _ARG_0_)
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.UIRoot.AllStar_Rank_FriendItem then
        _ARG_0_.menuItemList = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.AllStar_Rank_FriendItem.LoopScrollBox_0)
        _ARG_0_.menuItemList:SetRefreshItemCallback(_ARG_0_.OnRefreshMenuItem, _ARG_0_)
        _ARG_0_.menuItemList:AddItemWidgetChildEvent(U2(233, 20, 72, 89, 240, 172, 209, 71, 181, 86), U2(228, 15, 127, 65, 246, 161, 229, 118, 176), _ARG_0_.OnClickMenuItem, _ARG_0_)
      end
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_ADD_CAR_TEAM, _ARG_0_.AddCarTeamInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_ROOM_INFO, _ARG_0_.UpdateRoomInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_RESET_ROOM_INFO, _ARG_0_.UpdateUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_MEMBER, _ARG_0_.UpdateRoomMember_Increment, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_MEMBER_UPDATE, _ARG_0_.UpdateRoomMember_Increment, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_OB_RETURN, _ARG_0_.ShowObButton, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_GET_NEW_CHAT_MSG, _ARG_0_.OnGetNewMsg, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_PASSWORD, _ARG_0_.UpdatePassWord, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_PosArranging, _ARG_0_.UpdateShowWaitingTips, _ARG_0_)
      _ARG_0_:HideUIsOnInit()
      if U1.RoomSystem.CurrentRoomInfo and U1.RoomSystem.CurrentRoomInfo.room_type == U2(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
      end
      if _ARG_0_.is_owner then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CloseInRoomList, _ARG_0_.OnButton_CloseInRoomListClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.But_Room_Setting, _ARG_0_.OnBut_Room_SettingClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_kick, _ARG_0_.OnButton_kickClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_KickFromResult, _ARG_0_.OnButton_KickFromResultClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_StartFighting, _ARG_0_.OnButton_StartFightingClick, _ARG_0_)
      if _ARG_0_.UIRoot.Button_CancelSearch then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CancelSearch, _ARG_0_.OnButton_CancelSearchClick, _ARG_0_)
      end
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.But_RoomWatching, _ARG_0_.OnBut_RoomWatchingClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_0, _ARG_0_.ShowFriendPanel, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_OpenChat, _ARG_0_.OpenChatPanel, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_pswd, _ARG_0_.OnPswdBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.roomOpenChatBtn, _ARG_0_.OpenChatPanel, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GM, _ARG_0_.OpenGmPanel, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Detail, _ARG_0_.OnButtonDetailClick, _ARG_0_)
      _ARG_0_.RoomHomeBtn = _ARG_0_.UIRoot.Buf_Room_Home or _ARG_0_.UIRoot.But_Room_Home
      if _ARG_0_.RoomHomeBtn then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.RoomHomeBtn, _ARG_0_.OnClickRoomHomeItem, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_RoomSetting then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_RoomSetting, _ARG_0_.OnButtonRoomSettingClick, _ARG_0_)
      end
      if _ARG_0_:IsVoiceRoom() then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Mic, _ARG_0_.OnClickButton_Mic, _ARG_0_)
        _ARG_0_:AddOnPressedEventByControl(_ARG_0_.UIRoot.Button_Mic, _ARG_0_.OnPressButton_Mic, _ARG_0_)
        _ARG_0_:AddOnReleasedEventByControl(_ARG_0_.UIRoot.Button_Mic, _ARG_0_.OnReleaseButton_Mic, _ARG_0_)
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Spk, _ARG_0_.OnClickButton_Spk, _ARG_0_)
        if _ARG_0_.selfSpeakingTimer then
          _ARG_0_:RemoveTimer(_ARG_0_.selfSpeakingTimer)
        end
        _ARG_0_.selfSpeakingTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV:SelfSpeakingCheckTick()
          return
        end, U1.TIMER_INFINITE, 0.2)
      end
      _ARG_0_:RegistEventsDiff()
      if _ARG_0_.UIRoot.Button_SubWindowBg then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_SubWindowBg, _ARG_0_.HideMenu, _ARG_0_, true)
      end
      if _ARG_0_.UIRoot.Button_QuitRoom then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_QuitRoom, _ARG_0_.OnButton_CloseInRoomListClick, _ARG_0_)
      end
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_STATE, _ARG_0_.UpdateStartBtn, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_TIME, _ARG_0_.UpdateStartTime, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_ENTRY_UPDATE_TIPS, _ARG_0_.AddPlayerToUpRoomAnima, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_END_ANIMATION_ROOMTIPS, _ARG_0_.EndAnimationRoomTips, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CR_SVR_SEL_CHANGE, _ARG_0_.OnCrSvrSelChange, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomHomeBtn"] = function(_ARG_0_)
    do
      if not _ARG_0_.RoomHomeBtn then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCrSvrSelChange"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateRoomHomeBtn()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRoomHomeItem"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not RoomSystem.IsCrSvrSelEnable() then
        return
      end
      if UIManager.IsUIShow(UIManager.UI_Config.Room_Home_Item) then
        UIManager.CloseUI(UIManager.UI_Config.Room_Home_Item)
        return
      end
      UIManager.ShowUI(UIManager.UI_Config.Room_Home_Item, _ARG_0_.UIRoot.CanvasPanel_tips, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:UpdateUI()
      _ARG_0_:UpdateRoomHomeBtn()
      if U1.Client.IsShipping() and U1.global_package_make_time_map.SODA_AutoBuild ~= U2(248, 10, 85, 93) and U1.global_package_make_time_map.SODA_AutoBuild ~= U2(251, 19, 89) then
      else
      end
      if not U1.require((U1.table.concat({
        U2(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 55, 8, 133, 59, 50, 54, 98, 94, 3, 155, 155, 77, 176, 105, 238, 137, 54, 24, 136, 99, 27, 52, 62, 97, 22, 145, 134, 97),
        U2(206, 6, 85, 66, 241, 143, 239, 112, 166, 91, 236)
      }))).IsCEOperationRegion() then
        return
      end
      if U1.Client.IsShipping() then
      elseif _ARG_0_.is_owner then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_ROOM, EVENTID_ROOM_WAITING_OPEN)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      UIManager.CloseUI(UIManager.UI_Config.ui_room_ob)
      UIManager.CloseUI(UIManager.UI_Config.Room_Microphone_UIBP)
      UIManager.CloseUI(UIManager.UI_Config.Room_Speaker_UIBP)
      EventSystem:postEvent(EVENTTYPE_ROOM, EVENTID_ROOM_WAITING_CLOSE)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenGmPanel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.Lobby_GM)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateRoomInfo()
      _ARG_0_:AddTimerOnce(0.2, function()
        _ENV:UpdateRoomMember()
        return
      end)
      _ARG_0_:UpdateStartTime()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomInfo"] = function(_ARG_0_)
    do
      _ARG_0_:InitRoomTypeAndMode()
      if RoomSystem.CurrentRoomInfo.name and RoomSystem.CurrentRoomInfo.name ~= U1() then
      else
      end
      if RoomSystem.CurrentRoomInfo.room_type == U1(202, 5, 74, 76, 241, 161, 235, 119) or RoomSystem.CurrentRoomInfo.room_type == U1(198, 0, 72, 78, 247) then
      else
      end
      if _ARG_0_.is_owner then
      else
      end
      if _ARG_0_.is_owner and RoomSystem.GetMaxTeamPlayerNum() == 4 and (RoomSystem.CurrentRoomInfo.room_type == U1(202, 5, 74, 76, 241, 161, 235, 119) or RoomSystem.CurrentRoomInfo.room_type == U1(198, 0, 72, 78, 247)) then
      else
      end
      if RoomSystem.CurrentRoomInfo.room_type == U1(198, 0, 72, 78, 247) then
        if _ARG_0_.is_owner then
        else
        end
      else
      end
      if _ARG_0_.room_type == U2.NORMAL then
      elseif _ARG_0_.room_type == U2.TOURNAMENT then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStartBtn"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot.WidgetSwitcher_Start then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStartTime"] = function(_ARG_0_)
    do
      if _ARG_0_.startCountTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.startCountTimer)
        _ARG_0_.startCountTimer = nil
      end
      if RoomSystem.CurrentRoomInfo.state ~= U1(219, 19, 89, 93, 254, 176, 231, 125, 179) then
        return
      end
      if require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 159, 52, 54, 52, 19, 104, 27, 155, 146))).GetServerTimeInSec() < (RoomSystem.CurrentRoomInfo.start_time or 0) then
        if math.max(0, (RoomSystem.CurrentRoomInfo.start_time or 0) - require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 159, 52, 54, 52, 19, 104, 27, 155, 146))).GetServerTimeInSec()) <= 3600 then
        else
        end
        _ARG_0_.startCountTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV = U1.GetServerTimeInSec()
          U2 = U3.math.max(0, nil - _ENV)
          if U3.math.max(0, nil - _ENV).TextBlock_StartCount then
            U3.math.max(0, nil - _ENV).TextBlock_StartCount.TextBlock_StartCount:SetText(U1.FormatCountDownTime_D_or_HMS(U2))
          end
          if U2 == 0 and U2 then
            U2:RemoveTimer(U1.FormatCountDownTime_D_or_HMS(U2))
          end
          return
        end, TIMER_INFINITE, 1)
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCEModeUI"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.CanvasPanel_CE then
        if not RoomSystem.CurrentRoomInfo.gm_turing then
          _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_CE, false)
        else
        end
      end
      if _ARG_0_.UIRoot.TextBlock_12 then
        if not RoomSystem.CurrentRoomInfo.gm_turing then
          if RoomSystem.CurrentRoomInfo.gm_turing == nil then
            _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_12, false)
          else
            _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_12, true)
            _ARG_0_.UIRoot.TextBlock_12:SetText((U1(78, 250, 130, 202, 30, 119, 104, 166, 95, 220, 48, 111, 177, 208, 89, 184, 222, 226, 165, 138, 194)))
          end
        else
          _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_12, true)
          _ARG_0_.UIRoot.TextBlock_12:SetText((U1(78, 250, 130, 202, 30, 119, 104, 166, 95, 220, 48, 111, 177, 208, 89, 184, 231, 209, 169, 141, 192)))
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitRoomTypeAndMode"] = function(_ARG_0_)
    do
      if RoomSystem.CurrentRoomInfo.roomType then
        _ARG_0_.room_type = RoomSystem.CurrentRoomInfo.roomType
      elseif (RoomSystem.CurrentRoomInfo.id or 0) < 10000000 then
        _ARG_0_.room_type = U1.NORMAL
      elseif (RoomSystem.CurrentRoomInfo.id or 0) < 100000000 then
        _ARG_0_.room_type = U1.TOURNAMENT
      else
        _ARG_0_.room_type = U1.NORMAL
      end
      if RoomSystem.CurrentRoomInfo.room_type == U2(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
        _ARG_0_.room_type = U1.NORMAL
      end
      if RoomSystem.CurrentRoomInfo.group_type == 1 then
        _ARG_0_.room_mode = U3.SINGLE
      elseif RoomSystem.CurrentRoomInfo.group_type == 2 then
        _ARG_0_.room_mode = U3.DOUBLE
      else
        _ARG_0_.room_mode = U3.TEAM
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePassWord"] = function(_ARG_0_)
    do
      goto lbl_22
      if (nil).openid == DataMgr.roleData.uid and (nil).pos > 100 then
      else
        ::lbl_22::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not true then
        if RoomSystem.CurrentRoomInfo.password then
          if _ARG_0_.isPasswordHidden then
          else
          end
          if _ARG_0_.UIRoot.WBP_EyePasswordButton then
          end
        elseif _ARG_0_.UIRoot.WBP_EyePasswordButton then
        end
      elseif RoomSystem.CurrentRoomInfo.password then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddPlayerToUpRoomAnima"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:SetUpRoomAnima(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomDelay"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot.WidgetSwitcher_Network then
        return
      end
      if require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 33, 124, 27, 145, 150, 13, 168, 75, 232, 131, 39, 40, 129, 34, 37, 36, 3, 105, 26, 142, 143, 74))).GetCurRoomDelay(10000, 10000) < 10000 and require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 33, 124, 27, 145, 150, 13, 168, 75, 232, 131, 39, 40, 129, 34, 37, 36, 3, 105, 26, 142, 143, 74))).GetCurRoomDelay(10000, 10000) ~= 0 then
        if 200 >= require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 33, 124, 27, 145, 150, 13, 168, 75, 232, 131, 39, 40, 129, 34, 37, 36, 3, 105, 26, 142, 143, 74))).GetCurRoomDelay(10000, 10000) then
        elseif require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 33, 124, 27, 145, 150, 13, 168, 75, 232, 131, 39, 40, 129, 34, 37, 36, 3, 105, 26, 142, 143, 74))).GetCurRoomDelay(10000, 10000) <= 500 then
        else
        end
        if Client.HasActiveWifi() then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomMember"] = function(_ARG_0_)
    do
      _ARG_0_.my_team_teamItem_index = 0
      _ENV = {}
      if U1.RoomSystem.CurrentRoomInfo.MemberInfoList then
        goto lbl_20
        _ENV[_ARG_0_:Convert2ShowIndex((nil).pos)] = nil, nil, _ARG_0_:Convert2ShowIndex((nil).pos)
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.room_mode == U2.SINGLE then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_0_.room_mode == U2.DOUBLE then
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      elseif _ARG_0_.room_mode == U2.TEAM then
        if U1.require((U1.table.concat({
          U3(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
          U3(198)
        }))).GetMapSpeicialConfig(U1.RoomSystem.CurrentRoomInfo.map_id) then
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        elseif not _ARG_0_:CheckTeamModeIsMulti(U1.RoomSystem.CurrentRoomInfo.map_id) then
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        else
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomMember_Increment"] = function(_ARG_0_)
    do
      _ENV = {}
      goto lbl_13
      _ENV[_ARG_0_:Convert2ShowIndex((nil).pos)] = nil, nil, _ARG_0_:Convert2ShowIndex((nil).pos)
      ::lbl_13::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.room_mode == U2.SINGLE then
        _ARG_0_.loopGridSingle:RefreshAllItems()
      elseif _ARG_0_.room_mode == U2.DOUBLE then
        _ARG_0_.loopGridDouble:RefreshAllItems()
      elseif _ARG_0_.room_mode == U2.TEAM then
        if U1.RoomSystem.CurrentRoomInfo.room_type == U3(222, 6, 95) then
          if (U1.RoomSystem.CurrentRoomInfo and U1.RoomSystem.CurrentRoomInfo.ugc_room_param or {}).team_size == -1 then
          end
          if 0 >= ((U1.RoomSystem.CurrentRoomInfo and U1.RoomSystem.CurrentRoomInfo.ugc_room_param or {}).max_num or 0) then
          end
          if U1.require((U3(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 56, 120, 14, 159, 139, 83, 234, 72, 224, 141, 45, 20, 164, 57, 46, 32, 49, 82, 10, 146))).GetDefaultMaxTeamNum() > 4 then
          else
          end
        elseif not _ARG_0_:CheckTeamModeIsMulti(U1.RoomSystem.CurrentRoomInfo.map_id) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTeamVoiceUI"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice).team_id and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice).team_id >= 0 then
        if _ARG_0_.room_mode == U2.DOUBLE then
        elseif _ARG_0_.room_mode == U2.TEAM then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnOwnerSpeaking"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 18, 53, 30, 59, 115, 10, 128, 173, 83, 161, 69, 228, 131, 42, 16, 219, 47, 2, 50, 15, 125, 26, 131, 133, 90),
        U1(197, 6, 28, 16, 191)
      }) .. tostring(_ARG_1_))
      if _ARG_1_ and not _ARG_0_.is_owner and math.abs(require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 159, 52, 54, 52, 19, 104, 27, 155, 146))).GetServerTimeInSec() - (_ARG_0_.lastTips or 0)) > 5 then
        _ARG_0_.lastTips = require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 159, 52, 54, 52, 19, 104, 27, 155, 146))).GetServerTimeInSec(), ShowNotice(LocUtil.GetLocalizeResStr(46880167))
      end
      _ARG_0_:UpdateRoomVoiceUI(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateRoomVoiceUI"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 8, 43, 53, 45, 105, 10, 160, 145, 76, 169, 114, 224, 131, 39, 18, 174, 4, 107, 35, 21, 126, 44, 146, 139, 82),
        U1(192, 8, 82, 74, 191, 255, 174)
      }) .. tostring(_ARG_1_))
      if _ARG_0_:CanUseRoomVoiceControl() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice):IsMatchRoomOwner() then
        else
        end
        if _ARG_0_.UIRoot.WidgetSwitcher_Mic then
        end
      else
      end
      if _ARG_0_.UIRoot.New_InRoomItem_02_UIBP and _ARG_0_:IsVoiceRoom() then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(RoomSystem.CurrentRoomInfo.owner_id) then
        else
        end
        if _ARG_1_ ~= nil then
          if _ARG_0_.UIRoot.New_InRoomItem_02_UIBP.CanvasPanel_Voice then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVoiceRoom"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice):IsVoiceRoom() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanUseRoomVoiceControl"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice):CanUseVoice() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsVoiceRoomOwner"] = function(_ARG_0_)
    do
      do return _ARG_0_:IsVoiceRoom() and _ARG_0_.is_owner end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Mic"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 18, 53, 18, 32, 116, 12, 153, 188, 86, 176, 80, 224, 132, 27, 58, 146, 46))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPressButton_Mic"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 18, 53, 1, 62, 120, 28, 129, 188, 86, 176, 80, 224, 132, 27, 58, 146, 46))
      if not _ARG_0_:CanUseRoomVoiceControl() then
        ShowNotice(468890119)
        return
      end
      if UIManager.GetUI(UIManager.UI_Config.Room_Microphone_UIBP) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice):GetMicAndSpk() == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice).eMicType.Inter then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReleaseButton_Mic"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 18, 53, 3, 41, 113, 10, 147, 141, 70, 134, 81, 251, 158, 43, 25, 164, 0, 34, 34))
      if not _ARG_0_:CanUseRoomVoiceControl() then
        return
      end
      if not _ARG_0_.isTalkingInterphone then
        if not UIManager.GetUI(UIManager.UI_Config.Room_Microphone_UIBP) then
        else
        end
      end
      _ARG_0_:TryStopInterphone()
      _ARG_0_.isTalkingInterphone = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Spk"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 18, 53, 18, 32, 116, 12, 153, 188, 86, 176, 80, 224, 132, 27, 36, 139, 38))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_:CanUseRoomVoiceControl() or _ARG_0_:IsVoiceRoomOwner() then
        ShowNotice(468890119)
        return
      end
      if UIManager.GetUI(UIManager.UI_Config.Room_Speaker_UIBP) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryStartInterphone"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 9, 41, 40, 31, 105, 14, 128, 138, 106, 170, 80, 234, 152, 52, 31, 148, 35, 46))
      if not require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 158, 52, 4, 36, 56, 116, 3))).GetGameFrontendHUD():GetVoiceSDKInterface() then
        return
      end
      if not require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 158, 52, 4, 36, 56, 116, 3))).GetGameFrontendHUD():GetVoiceSDKInterface():IsInterphoneMode() then
        return
      end
      _ARG_0_.pressInterphoneTimer = _ARG_0_:AddTimerOnce(0.7, function()
        log(bWriteLog and table.concat({
          U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 9, 41, 40, 31, 105, 14, 128, 138, 106, 170, 80, 234, 152, 52, 31, 148, 35, 46, 97, 19, 125, 26, 140, 206, 122),
          U1(197, 21, 89, 95, 239, 170, 225, 125, 177)
        }))
        U2:StartInterphone()
        U3.isTalkingInterphone = true
        U3.pressInterphoneTimer = nil
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryStopInterphone"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 9, 41, 40, 31, 105, 0, 130, 183, 77, 176, 65, 253, 154, 44, 24, 149, 40))
      if not require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 158, 52, 4, 36, 56, 116, 3))).GetGameFrontendHUD():GetVoiceSDKInterface() then
        return
      end
      if _ARG_0_.isTalkingInterphone then
        _ARG_0_.isTalkingInterphone = false
      end
      if _ARG_0_.pressInterphoneTimer then
        _ARG_0_.pressInterphoneTimer = nil
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsInterphoneTalking"] = function(_ARG_0_)
    do
      do return _ARG_0_.isTalkingInterphone end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSingleItemInit"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not RoomSystem.CurrentRoomInfo.MemberInfoList then
        return
      end
      if RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]] then
        if _ARG_0_.room_type == U3.ALLSTAR and not _ARG_3_ then
          RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].head_url = U1()
          RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].name = U1()
          RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].frame_level = 0
        end
        if RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].is_qrcode_limit then
          if _ARG_1_.Button_Lock then
          end
        else
        end
        if not RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].device_type or RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].device_type == 1 then
        end
        if _ARG_3_ and _ARG_0_:IsVoiceRoom() then
          if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_room_match_voice):IsTeamMemberMicOpen(tonumber(RoomSystem.CurrentRoomInfo.MemberInfoList[U2[_ARG_2_]].openid)) then
          else
          end
        end
      end
      do return end
      _ARG_2_ = U1[167]
    end
  end,
  ["CheckSlotLock"] = function(_ARG_0_, _ARG_1_)
    do
      if RoomSystem.CurrentRoomInfo.max_room_player and _ARG_1_ > RoomSystem.CurrentRoomInfo.max_room_player then
        return true
      else
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Convert2RealIndex"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Convert2ShowIndex"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGridSlotStride"] = function(_ARG_0_)
    do
      do return RoomSystem.GetMaxTeamPlayerNum() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearPos2KeyMap"] = function(_ARG_0_)
    do
      _ENV = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddPosAndKey"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ENV[_ARG_1_] = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetKeyWithPos"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ENV[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUpRoomAnima"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndAnimationRoomTips"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetKickButton"] = function(_ARG_0_)
    do
      if _ARG_0_.is_owner and RoomSystem.CurrentRoomInfo.room_type == U1(198, 0, 72, 78, 247) then
        _ARG_0_.UIRoot.Button_kick:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemSelect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not RoomSystem.CurrentRoomInfo.MemberInfoList then
        return
      end
      if _ARG_0_:CheckSlotLock(_ARG_2_) then
        return
      end
      if _ARG_0_.room_type == U2.NORMAL then
        if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]] then
          if Client.IsWindowOB() then
            return
          end
          if (RoomSystem.CurrentRoomInfo.room_type == U3(202, 18, 85, 76, 241, 157, 233, 114, 185, 81, 236) or _ARG_0_.is_asia) and RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]].openid == DataMgr.roleData.uid then
            return
          end
        elseif not _ARG_1_.IsLocked then
          if RoomSystem.CurrentRoomInfo.room_type and RoomSystem.CurrentRoomInfo.room_type == U3(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
            return
          end
          if _ARG_2_ == _ARG_0_.cur_select_index and not _ARG_0_:IsVoiceRoomOwner() then
            if require((U3(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 159, 52, 54, 52, 19, 104, 27, 155, 146))).GetServerTimeInSec() - _ARG_0_.last_change_pos_time < U4 then
              return
            end
            _ARG_0_.last_change_pos_time = require((U3(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 159, 52, 54, 52, 19, 104, 27, 155, 146))).GetServerTimeInSec()
            if RoomSystem.CheckNewPosCanChange((_ARG_0_:Convert2RealIndex(_ARG_2_))) then
            end
          else
            _ARG_0_.cur_select_index = _ARG_2_
            if _ARG_0_:IsVoiceRoomOwner() then
              return
            end
            _ARG_0_.cur_select_widget = _ARG_1_
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnItemKick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not RoomSystem.CurrentRoomInfo.MemberInfoList then
        return
      end
      if not RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]] then
        return
      end
      if _ARG_0_:CheckSlotLock(_ARG_2_) then
        return
      end
      if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]].state == U2(204, 0, 81, 68, 241, 165) and RoomSystem.CurrentRoomInfo.state == U2(204, 0, 81, 68, 241, 165) then
      elseif not _ARG_0_.is_owner then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLockClick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]] and RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]].is_qrcode_limit then
        if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[_ARG_2_]].openid == DataMgr.roleData.uid then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEnterPersonClick"] = function(_ARG_0_)
    do
      _ARG_0_:HideMenu()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEditNickNameClick"] = function(_ARG_0_)
    do
      _ARG_0_:HideMenu()
      UIManager.ShowUI(UIManager.UI_Config.ui_room_change_name)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCarTeamInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.is_asia or RoomSystem.CurrentRoomInfo.room_type == U1(202, 18, 85, 76, 241, 157, 233, 114, 185, 81, 236) then
        _ARG_1_.Image_2:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_0_:ShowNationFlag(_ARG_1_, _ARG_2_)
      end
      _ARG_1_.Panel_carteamInfo:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if not _ARG_1_.Image_0 or not _ARG_1_.Image_1 then
        return
      end
      if not require((table.concat({
        U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
        U1(198)
      }))).GetMapSpeicialConfig(RoomSystem.CurrentRoomInfo.map_id) then
      elseif _ARG_2_ % 2 == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowNationFlag"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not RoomSystem.CurrentRoomInfo.MemberInfoList then
        return
      end
      _ARG_0_ = _ARG_0_
      if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[nil]] and RoomSystem.CurrentRoomInfo.MemberInfoList[U1[nil]].country then
      else
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshMyTeamBg"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ and not require((table.concat({
        U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
        U1(198)
      }))).GetMapSpeicialConfig(RoomSystem.CurrentRoomInfo.map_id) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleItemInit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.MemberInfoList then
        _ARG_0_ = _ARG_0_
        if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[nil]] and RoomSystem.CurrentRoomInfo.MemberInfoList[U1[nil]].openid == DataMgr.roleData.uid then
        else
          _ARG_0_ = _ARG_0_
        end
      end
      if not RoomSystem.CurrentRoomInfo.MemberInfoList then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleItemSelect1"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:OnItemSelect(_ARG_1_.InRoomItem_1, 2 * _ARG_2_ - 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleItemKick1"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:OnItemKick(_ARG_1_.InRoomItem_1, 2 * _ARG_2_ - 1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleItemSelect2"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:OnItemSelect(_ARG_1_.InRoomItem_2, 2 * _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleItemKick2"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:OnItemKick(_ARG_1_.InRoomItem_2, 2 * _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemInit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if require((table.concat({
        U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
        U1(198)
      }))).GetMapSpeicialConfig(RoomSystem.CurrentRoomInfo.map_id) then
      else
      end
      _ARG_0_ = _ARG_0_
      if RoomSystem.CurrentRoomInfo.MemberInfoList[U2[LocUtil.LocalizeResFormat(6440, _ARG_2_)]] and RoomSystem.CurrentRoomInfo.MemberInfoList[U2[LocUtil.LocalizeResFormat(6440, _ARG_2_)]].openid == DataMgr.roleData.uid then
      else
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemSelect1"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemSelect(_ARG_1_.InRoomItem_1, 4 * _ARG_2_ - 3)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemKick1"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemKick(_ARG_1_.InRoomItem_1, 4 * _ARG_2_ - 3)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemSelect2"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemSelect(_ARG_1_.InRoomItem_2, 4 * _ARG_2_ - 2)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemKick2"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemKick(_ARG_1_.InRoomItem_2, 4 * _ARG_2_ - 2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemSelect3"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemSelect(_ARG_1_.InRoomItem_3, 4 * _ARG_2_ - 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemKick3"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemKick(_ARG_1_.InRoomItem_3, 4 * _ARG_2_ - 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDoubleItemSelect4"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemSelect(_ARG_1_.InRoomItem_4, 4 * _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeamItemKick4"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      _ARG_0_:OnItemKick(_ARG_1_.InRoomItem_4, 4 * _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeam8v8ItemInit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_.TextBlock_TeamIdx:SetText(LocUtil.LocalizeResFormat(6440, _ARG_2_))
      _ARG_0_ = _ARG_0_
      if RoomSystem.CurrentRoomInfo.MemberInfoList[U1[LocUtil.LocalizeResFormat(6440, _ARG_2_)]] and RoomSystem.CurrentRoomInfo.MemberInfoList[U1[LocUtil.LocalizeResFormat(6440, _ARG_2_)]].openid == DataMgr.roleData.uid then
      else
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_ = _ARG_0_
      if _ARG_1_[U2(226, 15, 110, 66, 240, 175, 199, 103, 177, 89, 192) .. tostring(true)] then
        if _ARG_0_:GetGridSlotStride() >= true then
        else
        end
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeam8v8ItemSelect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeam8v8ItemKick"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTeam8v8ItemLockClick"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddCarTeamInfo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.room_mode == TEAM then
        if _ARG_3_ <= _ARG_0_.loopGridTeam:GetItemCount() and 0 < _ARG_3_ then
          _ARG_0_.loopGridTeam:RefreshItem(_ARG_3_, _ARG_3_)
        end
      elseif _ARG_0_.room_mode == DOUBLE and _ARG_3_ <= _ARG_0_.loopGridDouble:GetItemCount() and 0 < _ARG_3_ then
        _ARG_0_.loopGridDouble:RefreshItem(_ARG_3_, _ARG_3_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateWeather"] = function(_ARG_0_)
    do
      if RoomSystem.GetRoomWeather() then
        if require((table.concat({
          U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 33, 124, 31, 173, 137, 70, 165, 80, 231, 143, 54, 89, 152, 34, 37, 39, 53, 106, 32, 143, 143, 67),
          U1(244, 22, 89, 76, 235, 170, 235, 97)
        }))).GetWeatherLevelConfig(RoomSystem.GetRoomWeather().level) then
        elseif #require((table.concat({
          U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 33, 124, 31, 173, 137, 70, 165, 80, 231, 143, 54, 89, 152, 34, 37, 39, 53, 106, 32, 143, 143, 67),
          U1(244, 22, 89, 76, 235, 170, 235, 97)
        }))).GetMapWeatherList(RoomSystem.CurrentRoomInfo.map_id) == 1 then
        elseif RoomSystem.GetRoomWeather().id == 0 then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckNotGaming"] = function(_ARG_0_)
    do
      if RoomSystem.CurrentRoomInfo.state == U1(194, 5, 80, 72) then
        return true
      else
        ShowNotice(110130)
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_CloseInRoomListClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if RoomSystem.CurrentRoomInfo.state == U1(219, 19, 89, 93, 254, 176, 231, 125, 179) then
        ShowNotice(655593)
        return
      end
      if _ARG_0_.is_owner then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBut_Room_SettingClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_0Click"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshMenuItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.menuItemList:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickMenuItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.menuItemList:GetItemData(_ARG_2_) then
        return
      end
      if _ARG_1_ then
      end
      if _ARG_2_ == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideAllComboBox"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowMenu"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Button_SubWindowBg then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_SubWindowBg, true, true)
      end
      if _ARG_0_.UIRoot.AllStar_Rank_FriendItem then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.AllStar_Rank_FriendItem, true)
      end
      if _ARG_0_.menuItemList then
        _ARG_0_.menuItemList:SetData(_ENV)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideMenu"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ then
        _ARG_0_:PlayAudio(sound_config.click_v1)
      end
      if _ARG_0_.UIRoot.AllStar_Rank_FriendItem then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.AllStar_Rank_FriendItem, false)
      end
      if _ARG_0_.UIRoot.Button_SubWindowBg then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_SubWindowBg, false, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMenuPos"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      if (require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 158, 52, 4, 36, 56, 116, 3))).GetWidgetViewportPos(_ARG_1_).Y + _ARG_0_.UIRoot.AllStar_Rank_FriendItem.windowBG.Slot:GetSize().Y) * require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 158, 52, 4, 36, 56, 116, 3))).GetViewportScale() <= require((U1(200, 13, 85, 72, 241, 182, 160, 112, 187, 89, 242, 149, 58, 73, 158, 52, 4, 36, 56, 116, 3))).GetViewportSize().Y then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_HideWatchingClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBut_RoomWatchingClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.ui_room_ob)
      _ARG_0_.UIRoot.WidgetSwitcher_2:SetActiveWidgetIndex(1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowObButton"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_2:SetActiveWidgetIndex(0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetNewMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_3_ ~= require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 32, 114, 13, 144, 135, 124, 167, 76, 238, 158, 106, 20, 147, 44, 63, 30, 49, 108, 28, 144, 129))).Channel.WaitingRoom then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_EditClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_ReturnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWhiteListTick"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(221, 62, 91, 93, 246, 172, 233, 113, 181, 90, 178, 215, 121, 74, 198, 112, 118, 124, 97, 48, 66, 223, 211, 14, 233, 9, 192, 132, 19, 31, 146, 57, 46, 13, 53, 126, 11, 182, 135, 80),
        U1(192)
      }))
      goto lbl_129
      if 182 and (182).openid and tostring((182).openid) ~= U1() then
      end
      ::lbl_129::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_kickClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      goto lbl_60
      if (nil).openid and tostring((nil).openid) ~= U1() and (nil).openid ~= DataMgr.roleData.uid or ((nil).device_type or 0) == 1 then
      end
      ::lbl_60::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if U1() .. (U1() == U1() and U1() or U1(72, 225, 189)) .. (nil).name == U1() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_StartFightingClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id) and U2.GetState(U3.ENUM_DownloadType.MAP, {
        CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).MapKey
      }) ~= ENUM_DownloadState.Done then
        return
      end
      if _ARG_0_:CheckBattleRestrict() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_CancelSearchClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.is_owner then
        ShowNotice(110098)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_KickFromResultClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 18, 53, 19, 57, 105, 27, 157, 144, 124, 143, 77, 236, 129, 2, 5, 148, 32, 25, 36, 47, 120, 19, 150, 173, 95),
        U1(194, 2, 87)
      }))
      if _ARG_0_:CheckNotGaming() then
        _ARG_0_.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(0)
        RoomSystem.SendPullBackFromResult()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckBattleRestrict"] = function(_ARG_0_)
    do
      if next((RoomSystem.GetRoomMemberList())) then
        goto lbl_20
        if (nil).is_qrcode_limit then
        end
        ::lbl_20::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if 0 + 1 == 1 and (nil).name then
      end
      if 1 < 0 + 1 then
      end
      do return 0 < 0 + 1 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeIsOnlyShow"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.isOnlyShow = _ARG_1_
      if _ARG_1_ == true then
        _ARG_0_:SelfHitTestInvisible()
      else
        _ARG_0_:Collapsed()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecoverStatus"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:ChangeIsOnlyShow(_ARG_1_.isOnlyShow)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetStatus"] = function(_ARG_0_)
    do
      do return {
        isOnlyShow = _ARG_0_.isOnlyShow
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideUIsOnInit"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowFriendPanel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if RoomSystem.CurrentRoomInfo.room_type == U1(222, 6, 95) then
        if not (RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.ugc_room_param) then
          return
        end
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache((RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.ugc_room_param).mod_id) then
          return
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenChatPanel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPswdBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if RoomSystem.CurrentRoomInfo.password then
      else
        UIManager.ShowUI(UIManager.UI_Config.ui_room_change_pswd)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEyeBtnClick"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.isPasswordHidden = _ARG_1_
      _ARG_0_:UpdatePassWord()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonDetailClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonRoomSettingClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      RoomSystem.req_set_pos_arranging_request()
      UIManager.ShowUI(UIManager.UI_Config.Room_Owner_Setting_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateShowWaitingTips"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(139, 52, 117, 114, 205, 173, 225, 126, 131, 85, 246, 142, 61, 9, 140, 103, 14, 33, 40, 124, 27, 151, 173, 75, 171, 83, 216, 139, 45, 3, 146, 35, 44, 21, 53, 125, 12, 194, 188, 92),
        U1(196, 12, 111, 84, 236, 182, 235, 126, 250, 119, 234, 136, 38, 2, 133, 41, 9, 62, 35, 112, 38, 156, 152, 76, 234, 84, 224, 153, 27, 22, 137, 63, 42, 47, 59, 100, 17, 133, 206, 90),
        U1(216, 65)
      }) .. tostring(RoomSystem.CurrentRoomInfo.pos_arranging))
      log(bWriteLog and table.concat({
        U1(139, 52, 117, 114, 205, 173, 225, 126, 131, 85, 246, 142, 61, 9, 140, 103, 14, 33, 40, 124, 27, 151, 173, 75, 171, 83, 216, 139, 45, 3, 146, 35, 44, 21, 53, 125, 12, 194, 135, 64),
        U1(139, 20, 85, 114, 236, 170, 225, 100, 244)
      }) .. tostring(UIManager.IsUIShow(UIManager.UI_Config.Room_Owner_Waiting_Tips_UIBP)))
      if not _ARG_0_.is_owner then
        if RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.pos_arranging then
          UIManager.ShowUI(UIManager.UI_Config.Room_Owner_Waiting_Tips_UIBP)
        else
          UIManager.CloseUI(UIManager.UI_Config.Room_Owner_Waiting_Tips_UIBP)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateShowOwnerSettingPanel"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(139, 52, 117, 114, 205, 173, 225, 126, 131, 85, 246, 142, 61, 9, 140, 103, 14, 33, 40, 124, 27, 151, 173, 75, 171, 83, 192, 157, 42, 18, 137, 30, 46, 53, 40, 100, 17, 133, 190, 82),
        U1(197, 4, 80, 13, 205, 173, 225, 126, 135, 77, 236, 142, 49, 10, 197, 30, 46, 35, 62, 120, 1, 134, 172, 76, 171, 73, 198, 132, 34, 24, 213, 61, 36, 50, 3, 108, 13, 144, 143, 93),
        U1(204, 8, 82, 74, 191, 171, 253, 51)
      }) .. tostring(RoomSystem.CurrentRoomInfo.pos_arranging))
      log(bWriteLog and table.concat({
        U1(139, 52, 117, 114, 205, 173, 225, 126, 131, 85, 246, 142, 61, 9, 140, 103, 14, 33, 40, 124, 27, 151, 173, 75, 171, 83, 192, 157, 42, 18, 137, 30, 46, 53, 40, 100, 17, 133, 190, 82),
        U1(197, 4, 80, 13, 246, 177, 174, 102, 189, 107, 236, 146, 59, 16, 203)
      }) .. tostring(UIManager.IsUIShow(UIManager.UI_Config.Room_Owner_Setting_UIBP)))
      if _ARG_0_.is_owner then
        if RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.pos_arranging then
          UIManager.ShowUI(UIManager.UI_Config.Room_Owner_Setting_UIBP)
        else
          UIManager.CloseUI(UIManager.UI_Config.Room_Owner_Setting_UIBP)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAndroidBack"] = function(_ARG_0_)
    do
      _ARG_0_:OnButton_CloseInRoomListClick()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      EventSystem:postEvent(EVENTTYPE_WARDROBE, EVENTID_WARDROBE_AVATAR_RESET_CLOSE)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTeamModeIsMulti"] = function(_ARG_0_, _ARG_1_)
    do
      if require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 79, 171, 67, 230, 137, 27, 20, 137, 40, 42, 53, 57, 82, 13, 141, 129, 94))) then
      end
      do return require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 79, 171, 67, 230, 137, 27, 20, 137, 40, 42, 53, 57, 82, 13, 141, 129, 94))).GetTeamModeMaxPlayerNum(_ARG_1_) > 4 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDataForJumpBack"] = function(_ARG_0_)
    do
      do return {
        uiData = {
          isShow_teamup_side_bar = UIManager.GetUI(UIManager.UI_Config.Lobby_InviteFriend_BP)
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpBack"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_1_.isShow_teamup_side_bar then
        _ARG_0_:ShowFriendPanel()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitializeWidgetDiff"] = function(_ARG_0_)
    do
      _ARG_0_.Common_ComboBox_Mode = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_ModeList)
      _ARG_0_.Common_ComboBox_Map = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_MapList)
      _ARG_0_.Common_ComboBox_Server = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_ServerList)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEventsDiff"] = function(_ARG_0_)
    do
      _ARG_0_.Common_ComboBox_Mode:SetRefreshOptionCallback(_ARG_0_.OnRefreshComboBoxItem_Mode, _ARG_0_)
      _ARG_0_.Common_ComboBox_Mode:SetSelectOptionCallback(_ARG_0_.OnSelectComboBoxItem_Mode, _ARG_0_)
      _ARG_0_.Common_ComboBox_Mode:SetOpenStateChangedCallback(_ARG_0_.OnOpening, _ARG_0_, Mode)
      _ARG_0_.Common_ComboBox_Map:SetRefreshOptionCallback(_ARG_0_.OnRefreshComboBoxItem_Map, _ARG_0_)
      _ARG_0_.Common_ComboBox_Map:SetSelectOptionCallback(_ARG_0_.OnSelectComboBoxItem_Map, _ARG_0_)
      _ARG_0_.Common_ComboBox_Map:SetOpenStateChangedCallback(_ARG_0_.OnOpening, _ARG_0_, Map)
      _ARG_0_.Common_ComboBox_Server:SetRefreshOptionCallback(_ARG_0_.OnRefreshComboBoxItem_Server, _ARG_0_)
      _ARG_0_.Common_ComboBox_Server:SetSelectOptionCallback(_ARG_0_.OnSelectComboBoxItem_Server, _ARG_0_)
      _ARG_0_.Common_ComboBox_Server:SetOpenStateChangedCallback(_ARG_0_.OnOpening, _ARG_0_, Server)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnOpening"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ == Mode then
      elseif _ARG_1_ == Map then
      elseif _ARG_1_ == Server then
      end
      if not _ARG_0_.Common_ComboBox_Server then
        return
      end
      if not _ARG_0_.Common_ComboBox_Server:GetSetData() then
        return
      end
      if _ARG_1_ == Mode then
        return
      end
      goto lbl_165
      if _ARG_1_ == Map then
        if U1.RoomSystem.CurrentRoomInfo.map_id == (99).ResId then
          goto lbl_167
        end
      elseif _ARG_1_ == Server and U1.RoomSystem.RoomZoneId == (99).zone_id then
        goto lbl_167
      end
      ::lbl_165::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_167::
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitMapList"] = function(_ARG_0_)
    do
      if not CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id) then
        return
      end
      if (require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 79, 171, 67, 230, 137, 27, 20, 137, 40, 42, 53, 57, 82, 13, 141, 129, 94))).IsESportMatchRoomCard(RoomSystem.CurrentRoomInfo.card_id) or RoomSystem.CurrentRoomInfo.room_type == U1(198, 0, 72, 78, 247)) and not require((table.concat({
        U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
        U1(198)
      }))).GetMapSpeicialConfig(RoomSystem.CurrentRoomInfo.map_id) then
        if not CDataTable.GetTableData(U1(238, 18, 76, 66, 237, 182, 253, 94, 181, 68), RoomSystem.CurrentRoomInfo.map_id) then
        else
        end
      end
      if CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).IsObEnable == 1 and _ARG_0_.room_type == U2.NORMAL then
      else
      end
      if RoomSystem.CurrentRoomInfo.room_type and RoomSystem.CurrentRoomInfo.room_type == U1(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
      end
      if _ARG_0_.is_asia then
      else
      end
      if require((table.concat({
        U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
        U1(198)
      }))).GetMapSpeicialConfig(RoomSystem.CurrentRoomInfo.map_id) then
      else
      end
      return
    end
  end,
  ["InitMapDropList"] = function(_ARG_0_)
    do
      if not CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id) then
        return
      end
      if not (require((U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 79, 171, 67, 230, 137, 27, 20, 137, 40, 42, 53, 57, 82, 13, 141, 129, 94))).IsESportMatchRoomCard(RoomSystem.CurrentRoomInfo.card_id) or RoomSystem.CurrentRoomInfo.room_type == U1(198, 0, 72, 78, 247)) then
        goto lbl_189
        if U2.GetState(U3.ENUM_DownloadType.MAP, {
          U1(198).MapKey
        }) == U3.ENUM_DownloadState.Done and not require((table.concat({
          U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
          U1(198)
        }))).GetMapSpeicialConfig(U1(198).ResId) then
        end
        if RoomSystem.CurrentRoomInfo.map_id == U1(198).ResId then
        end
        ::lbl_189::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
        goto lbl_349
        if U2.GetState(U3.ENUM_DownloadType.MAP, {
          U1(198).MapKey
        }) == U3.ENUM_DownloadState.Done then
          if not CDataTable.GetTableData(U1(238, 18, 76, 66, 237, 182, 253, 94, 181, 68), U1(198).ResId) then
          else
          end
        end
        if RoomSystem.CurrentRoomInfo.map_id == U1(198).ResId then
        end
        ::lbl_349::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitAsianGamesMapDropList"] = function(_ARG_0_)
    do
      if CDataTable.GetTableData(U1(202, 18, 85, 76, 241, 157, 233, 114, 185, 81, 236, 165, 57, 14, 152, 62, 4, 37, 45, 127, 3, 151), (U1(200, 20, 79, 89, 240, 175, 209, 97, 187, 91, 242, 165, 57, 6, 155, 46))) and CDataTable.GetTableData(U1(202, 18, 85, 76, 241, 157, 233, 114, 185, 81, 236, 165, 57, 14, 152, 62, 4, 37, 45, 127, 3, 151), (U1(200, 20, 79, 89, 240, 175, 209, 97, 187, 91, 242, 165, 57, 6, 155, 46))).value then
        goto lbl_83
        ::lbl_83::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        goto lbl_96
        if RoomSystem.CurrentRoomInfo.map_id == CDataTable.GetTableData(U1(230, 0, 76), tonumber(142)).ResId then
        end
        ::lbl_96::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitServerList"] = function(_ARG_0_)
    do
      _ARG_0_.isServerInit = false
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_multiple_area):GetDisplayNameByZoneID(RoomSystem.RoomZoneId) == U1() then
      end
      if (_ARG_0_:InitServerDropList() or U1()) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetServerSelectName"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ARG_0_.Common_ComboBox_Server then
        return
      end
      if not _ARG_0_.Common_ComboBox_Server.UIRoot or not _ARG_0_.Common_ComboBox_Server.UIRoot.NamedSlot_Content then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitServerDropList"] = function(_ARG_0_)
    do
      if _ARG_0_.isServerInit then
        return (_ENV())
      end
      _ARG_0_.isServerInit = true
      goto lbl_94
      if 6 == U1.RoomSystem.RoomZoneId then
        if 6 == (241).zone_id then
        end
      elseif 6 ~= (241).zone_id then
      end
      if (241).zone_id == U1.RoomSystem.RoomZoneId then
      end
      ::lbl_94::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return ({})[#{}] and ({})[#{}].zone_name or _ENV() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitModeList"] = function(_ARG_0_)
    do
      _ARG_0_:SetModeName()
      _ARG_0_:InitModeDropList()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetModeName"] = function(_ARG_0_)
    do
      if CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id) then
        if RoomSystem.CurrentRoomInfo.group_type == 1 then
        elseif RoomSystem.CurrentRoomInfo.group_type == 2 then
        else
        end
        if LocUtil.GetLocalizeResStr(U2[CDataTable.GetTableData(U1(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).IsTeamValid).MaxTeamPlayerNum].mode_name_localize_id) ~= U1() then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitModeDropList"] = function(_ARG_0_)
    do
      _ARG_0_.isModeInit = true
      _ARG_0_ = _ARG_0_
      if U1() then
        if U2.CDataTable.GetTableData(U3(248, 8, 91, 67, 254, 174, 195, 124, 176, 102, 240, 149, 57, 36, 132, 51, 61, 56, 43), U2.RoomSystem.CurrentRoomInfo.map_id) then
          if nil == 1 and U2.CDataTable.GetTableData(U3(248, 8, 91, 67, 254, 174, 195, 124, 176, 102, 240, 149, 57, 36, 132, 51, 61, 56, 43), U2.RoomSystem.CurrentRoomInfo.map_id).SubModeSingle > 0 or nil == 2 and 0 < U2.CDataTable.GetTableData(U3(248, 8, 91, 67, 254, 174, 195, 124, 176, 102, 240, 149, 57, 36, 132, 51, 61, 56, 43), U2.RoomSystem.CurrentRoomInfo.map_id).SubModeDuo or nil == 3 and 0 < U2.CDataTable.GetTableData(U3(248, 8, 91, 67, 254, 174, 195, 124, 176, 102, 240, 149, 57, 36, 132, 51, 61, 56, 43), U2.RoomSystem.CurrentRoomInfo.map_id).SubModeSquad then
          end
        else
        end
      else
      end
      if true then
      end
      if U2.RoomSystem.CurrentRoomInfo.group_type == _ENV[nil].group_type then
        if U2.RoomSystem.CurrentRoomInfo.group_type == 4 then
          if not U2.CDataTable.GetTableData(U3(230, 0, 76), U2.RoomSystem.CurrentRoomInfo.map_id) then
          elseif U2.CDataTable.GetTableData(U3(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), U2.CDataTable.GetTableData(U3(230, 0, 76), U2.RoomSystem.CurrentRoomInfo.map_id).IsTeamValid) and _ENV[nil].team_size == U2.CDataTable.GetTableData(U3(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), U2.CDataTable.GetTableData(U3(230, 0, 76), U2.RoomSystem.CurrentRoomInfo.map_id).IsTeamValid).MaxTeamPlayerNum then
          end
        else
        end
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBoxItem_Mode"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBoxItem_Mode"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not _ARG_0_.is_owner then
        ShowNotice(110098)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModeItemClick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if RoomSystem.CurrentRoomInfo.room_type and RoomSystem.CurrentRoomInfo.room_type == U1(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
        return
      end
      if CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id) then
        if _ARG_1_ == 1 then
        elseif _ARG_1_ == 2 then
        elseif _ARG_1_ == 4 then
        end
        if CDataTable.GetTableData(U1(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).IsTeamValid) then
          if CDataTable.GetTableData(U1(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).IsTeamValid).MaxTeamPlayerNum ~= _ARG_2_ then
            return
          end
        else
          return
        end
      else
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBoxItem_Map"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.MapName)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBoxItem_Map"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if RoomSystem.CurrentRoomInfo then
        goto lbl_76
        if U1(198) == require((table.concat({
          U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
          U1(198)
        }))).C_RoomPrivilegeMap.Circle then
        end
        ::lbl_76::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if true then
        return
      end
      if not _ARG_0_.is_owner then
        return
      end
      if require((table.concat({
        U1(200, 13, 85, 72, 241, 182, 160, 96, 184, 65, 254, 212, 56, 8, 140, 52, 56, 127, 62, 114, 0, 159, 208, 64, 171, 74, 233, 131, 35, 40, 152, 63, 46, 32, 40, 104, 32, 144, 129, 92),
        U1(198)
      }))).GetMapSpeicialConfig(_ARG_2_.ResId) then
        return
      end
      if _ARG_0_.is_asia or RoomSystem.CurrentRoomInfo.room_type == U1(202, 18, 85, 76, 241, 157, 233, 114, 185, 81, 236) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMapItemClick"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(240, 56, 101, 112, 205, 167, 253, 90, 176, 9, 173, 200, 105, 90) .. _ARG_1_)
      if RoomSystem.CurrentRoomInfo.room_type and RoomSystem.CurrentRoomInfo.room_type == U1(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
        return
      end
      RoomSystem.req_change_room_map(RoomSystem.CurrentRoomInfo.id, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAsianGamesMapItemClick"] = function(_ARG_0_, _ARG_1_)
    do
      if RoomSystem.CurrentRoomInfo.room_type and RoomSystem.CurrentRoomInfo.room_type == U1(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBoxItem_Server"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        return
      end
      if _ARG_1_.TextBlock_ItemName then
        _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.zone_name)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBoxItem_Server"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not _ARG_2_ then
        return
      end
      if not _ARG_0_.is_owner then
        ShowNotice(110098)
        return
      end
      if _ARG_1_ then
        if _ARG_1_.Text_Name then
          _ARG_1_.Text_Name:SetText(_ARG_2_.zone_name)
        end
        if _ARG_1_.Image_Delay then
          _ARG_1_.Image_Delay:SetColorAndOpacity(FLinearColor(0, 0, 0, 0.7))
        end
      end
      log(bWriteLog and U1(240, 56, 101, 112, 208, 172, 221, 118, 166, 66, 250, 136, 29, 19, 142, 48, 24, 61, 37, 126, 4, 207, 195, 30, 249) .. tostring(_ARG_2_.zone_id))
      _ARG_0_:OnServerItemClick(_ARG_2_.zone_id)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnServerItemClick"] = function(_ARG_0_, _ARG_1_)
    do
      if RoomSystem.CurrentRoomInfo.room_type and RoomSystem.CurrentRoomInfo.room_type == U1(200, 14, 81, 93, 250, 182, 235, 76, 164, 88, 254, 142) then
        return
      end
      log(bWriteLog and U1(240, 56, 101, 112, 208, 172, 221, 118, 166, 66, 250, 136, 29, 19, 142, 48, 24, 61, 37, 126, 4, 207, 195, 30, 249) .. tostring(_ARG_1_))
      RoomSystem.on_select_zone_req(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetModeSelectIndex"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(254, 40, 99, 127, 240, 173, 227, 68, 181, 93, 235, 147, 58, 0, 209, 15, 62, 34, 41, 105, 34, 157, 154, 70, 151, 65, 227, 143, 39, 3, 178, 35, 47, 36, 36))
      if not CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id) then
        return
      end
      goto lbl_182
      if U1(194, 15, 90, 66, 191, 171, 253, 51, 186, 93, 243).group_type == RoomSystem.CurrentRoomInfo.group_type then
        if RoomSystem.CurrentRoomInfo.group_type == 4 then
          if CDataTable.GetTableData(U1(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).IsTeamValid) and U1(194, 15, 90, 66, 191, 171, 253, 51, 186, 93, 243).team_size == CDataTable.GetTableData(U1(230, 0, 72, 78, 247, 143, 225, 119, 177, 96, 254, 152, 56, 2), CDataTable.GetTableData(U1(230, 0, 76), RoomSystem.CurrentRoomInfo.map_id).IsTeamValid).MaxTeamPlayerNum then
            goto lbl_184
          end
        else
          goto lbl_184
        end
      end
      ::lbl_182::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_184::
      if not true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
