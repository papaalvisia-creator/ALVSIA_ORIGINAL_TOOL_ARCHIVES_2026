local XSuit_Box_Select_UIBP = {}
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local GRATING_CARD_PERIODS = {
  [17] = true
}
local _source = {
  [1] = "lottery",
  [2] = "gift",
  [3] = "energy"
}
local _title = {
  [16] = "200000818",
  [17] = "18141466"
}
local _tip = {
  [16] = "18141470",
  [17] = "18141469"
}

function XSuit_Box_Select_UIBP:ctor(_, boxId, callback, source, skipLoadScene)
  self.boxId = boxId
  self.source = source
  self.callback = callback
  self.skipLoadScene = skipLoadScene
  self.selectItemId = nil
  self.selectBranchId = nil
  self.bConfirm = false
end

function XSuit_Box_Select_UIBP:OnInitialize()
  XSuit_Box_Select_UIBP.__super.OnInitialize(self)
  local boxCfg = CDataTable.GetTableData("XSuitBranchChest", self.boxId)
  self.ScenePath = boxCfg.ScenePath
  self.period = boxCfg.Period
  self.skipLoadScene = GRATING_CARD_PERIODS[self.period] == true
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:OnInitialize period:%s skipLoadScene:%s", tostring(self.period), tostring(self.skipLoadScene)))
  self.periodCommonCfg = nil
  self.branchCommonCfgs = {}
  local UIConfigs = CDataTable.GetTableByFilter("XSuitCommonBranch", "Period", self.period)
  for index, config in pairs(UIConfigs) do
    if config.IsBranch == 1 then
      local branchId = config.BranchId
      self.branchCommonCfgs[branchId] = config
    else
      self.periodCommonCfg = config
    end
  end
  self.animationList = {}
  self.animationList = {
    self.UIRoot.Anim_First_Branch,
    self.UIRoot.Anim_Second_Branch,
    self.UIRoot.Anim_Third_Branch
  }
end

function XSuit_Box_Select_UIBP:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_BRANCH_BOX_OPEN, self.OpenBoxHandler, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVENTID_ACTION_PALY_END, self.OnActionStop, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Confirm, self.OnButtonClick_Confirm, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_ShareConfirm, self.OnButtonClick_ShareConfirm, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Share, self.OnButtonClick_Share, self)
end

function XSuit_Box_Select_UIBP:ResetPooledUIState()
  local UIRoot = self.UIRoot
  if not UIRoot then
    return
  end
  if UIRoot.Fadein then
    self:StopAnimation("Fadein")
  elseif UIRoot.SetRenderOpacity then
    UIRoot:SetRenderOpacity(1)
  end
  if UIRoot.Fadeout then
    self:StopAnimation("Fadeout")
  end
  if UIRoot.CanvasPanel_Choose then
    self:SetWidgetVisible(UIRoot.CanvasPanel_Choose, true)
  else
    log_error("XSuit_Box_Select_UIBP:ResetPooledUIState CanvasPanel_Choose not found")
  end
  if UIRoot.CanvasPanel_Share then
    self:SetWidgetVisible(UIRoot.CanvasPanel_Share, false)
  end
  if UIRoot.ScaleBox_Draw then
    self:SetWidgetVisible(UIRoot.ScaleBox_Draw, false)
  end
  local bgWidgets = {
    UIRoot.Border_BG,
    UIRoot.Border_BG2,
    UIRoot.XSuit_Choose_Bg_02,
    UIRoot.XSuit_Choose_Bg_Mask_01
  }
  
  local function ResetRenderOpacity(widget, depth)
    if not widget or 2 < depth then
      return
    end
    if widget.SetRenderOpacity then
      widget:SetRenderOpacity(1)
    end
    if widget.GetChildrenCount and widget.GetChildAt then
      local count = widget:GetChildrenCount() or 0
      for i = 0, count - 1 do
        ResetRenderOpacity(widget:GetChildAt(i), depth + 1)
      end
    end
  end
  
  for _, widget in ipairs(bgWidgets) do
    if widget then
      self:SetWidgetVisible(widget, true)
      ResetRenderOpacity(widget, 0)
    end
  end
  if UIRoot.HorizontalBox_BranchList then
    self:SetWidgetVisible(UIRoot.HorizontalBox_BranchList, true)
  end
  self.bFadeoutClosing = false
  self._isPlayingCloseAnim = false
  self.bConfirm = false
  self.selectItemId = nil
  self.selectBranchId = nil
  self.decomposeItemId = 0
  self.decomposeItemNum = nil
  self.branchList = {}
  self.bSceneInited = false
  self.curScene = nil
end

function XSuit_Box_Select_UIBP:HideWardrobeUnderScene()
  local wardrobeUI = UIManager.GetUI(UIManager.UI_Config.wardrobe)
  if not wardrobeUI or not wardrobeUI.UIRoot then
    return
  end
  self.wardrobeUI = wardrobeUI
  self.wardrobeUIPrevVisibility = wardrobeUI.UIRoot.GetVisibility and wardrobeUI.UIRoot:GetVisibility() or nil
  wardrobeUI.UIRoot:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:HideWardrobeUnderScene prevVisibility:%s", tostring(self.wardrobeUIPrevVisibility)))
end

function XSuit_Box_Select_UIBP:CacheSceneBeforeLoad()
  local lobby_scene_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.lobby_scene_module)
  self.prevSceneName = lobby_scene_module and lobby_scene_module.CurScene or LobbySceneManager.LatestScene
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  self.prevCameraID = Lobby_camera_manager_module and Lobby_camera_manager_module:GetCurrentCameraID()
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:CacheSceneBeforeLoad scene:%s camera:%s", tostring(self.prevSceneName), tostring(self.prevCameraID)))
end

function XSuit_Box_Select_UIBP:ClearOtherScenesBeforeLoad()
  if not self.ScenePath then
    return
  end
  local LobbySceneModule = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.lobby_scene_module)
  local loadingScene = LobbySceneModule and LobbySceneModule.LoadingScene
  if loadingScene and loadingScene ~= "" and loadingScene ~= self.ScenePath then
    LobbySceneModule:UnloadStreamLevel(loadingScene)
    log(bWriteLog and string.format("XSuit_Box_Select_UIBP:ClearOtherScenesBeforeLoad unload loading scene:%s", tostring(loadingScene)))
  end
  LobbySceneManager.UnLoadSpecialStreamLevel()
  local unloadSceneName = LobbySceneModule and LobbySceneModule.CurScene or self.prevSceneName
  if not unloadSceneName or unloadSceneName == "" or unloadSceneName == self.ScenePath then
    unloadSceneName = nil
  end
  self.unloadSceneName = unloadSceneName
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:ClearOtherScenesBeforeLoad scene:%s unloadScene:%s", tostring(self.ScenePath), tostring(unloadSceneName)))
end

function XSuit_Box_Select_UIBP:BeginBranchScene(onReady)
  if self.bSceneInited then
    if onReady then
      onReady()
    end
    return
  end
  if self.skipLoadScene or not self.ScenePath then
    log_error(string.format("XSuit_Box_Select_UIBP:BeginBranchScene no scene to load. period:%s skip:%s scene:%s", tostring(self.period), tostring(self.skipLoadScene), tostring(self.ScenePath)))
    if onReady then
      onReady()
    end
    return
  end
  self.bSceneInited = true
  self:HideWardrobeUnderScene()
  self:CacheSceneBeforeLoad()
  local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
  self.curScene = ConstAvatarDislay.ESceneType.XSuitBranchSelect
  self:InitComponent_Avatar()
  self:HideAvatar()
  self:Hide2DUI()
  self:ClearOtherScenesBeforeLoad()
  local cameraId = ConstAvatarDislay.GetCameraIDByScene(ConstAvatarDislay.ESceneType.XSuitBranchSelect)
  LobbySceneManager.LoadStreamLevel(true, self.ScenePath, cameraId, nil, {
    UnloadLevelName = self.unloadSceneName,
    Callback = function()
      if not slua.isValid(self.UIRoot) then
        return
      end
      log(bWriteLog and string.format("XSuit_Box_Select_UIBP:BeginBranchScene scene loaded:%s period:%s", tostring(self.ScenePath), tostring(self.period)))
      if not onReady then
        return
      end
      self:AddTimerOnce(0, function()
        if not slua.isValid(self.UIRoot) then
          return
        end
        onReady()
      end)
    end
  })
end

function XSuit_Box_Select_UIBP:RestoreSceneAfterClose()
  if not (not self.skipLoadScene and self.ScenePath) or not self.bSceneInited then
    return
  end
  LobbySceneManager.LoadStreamLevel(false, self.ScenePath, nil, nil, {bForceUnload = true})
  local prevSceneName = self.prevSceneName
  local prevCameraID = self.prevCameraID
  self.prevSceneName = nil
  self.prevCameraID = nil
  self.unloadSceneName = nil
  local bRestoredScene = false
  if prevSceneName and prevSceneName ~= "" and prevSceneName ~= self.ScenePath then
    LobbySceneManager.LoadStreamLevel(true, prevSceneName, prevCameraID)
    bRestoredScene = true
  end
  if self.wardrobeUI and slua.isValid(self.wardrobeUI) then
    local WardrobeLogicManager = require("client.slua.logic.wardrobe.logic_wardrobe_new")
    WardrobeLogicManager:SwitchCameraInWardrobe()
  elseif not bRestoredScene and prevCameraID then
    local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
    if Lobby_camera_manager_module then
      Lobby_camera_manager_module:SwitchCamera(prevCameraID)
    end
  end
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:RestoreSceneAfterClose unload:%s restore:%s camera:%s", tostring(self.ScenePath), tostring(prevSceneName), tostring(prevCameraID)))
end

function XSuit_Box_Select_UIBP:RestoreWardrobeUnderScene()
  local wardrobeUI = self.wardrobeUI
  local prevVisibility = self.wardrobeUIPrevVisibility
  self.wardrobeUI = nil
  self.wardrobeUIPrevVisibility = nil
  if wardrobeUI and wardrobeUI.UIRoot then
    wardrobeUI.UIRoot:SetWidgetVisibility(prevVisibility or UEnums.ESlateVisibility.SelfHitTestInvisible)
    log(bWriteLog and string.format("XSuit_Box_Select_UIBP:RestoreWardrobeUnderScene visibility:%s", tostring(prevVisibility)))
  end
end

function XSuit_Box_Select_UIBP:OnPostInitialize()
  self:ResetPooledUIState()
  EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_BRANCH_BOX_SHOW)
  self.initData = {
    initEquipList = {},
    switches = {noDefaultEquip = true}
  }
  self.UIRoot.TextBlock_Confirm:SetText(LocUtil.GetLocalizeResStr(200000766))
  self.UIRoot.TextBlock_ShareConfirm:SetText(LocUtil.GetLocalizeResStr(8139))
  self.UIRoot.TextBlock_Share:SetText(LocUtil.GetLocalizeResStr(4975))
  local title = _title[self.period] and _title[self.period] or _title[17]
  self.UIRoot.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(title))
  self.UIRoot.TextBlock_Desc:SetText(LocUtil.GetLocalizeResStr(200000765))
  self:InitBranchItems()
  if self.UIRoot.HorizontalBox_BranchList then
    self:SetWidgetVisible(self.UIRoot.HorizontalBox_BranchList, true)
  end
  if self.UIRoot.Image_3 then
    self:SetWidgetVisible(self.UIRoot.Image_3, false)
  end
  self:PlayFadein()
end

function XSuit_Box_Select_UIBP:PlayFadein()
  if not self.UIRoot or not self.UIRoot.Fadein then
    log_error(string.format("XSuit_Box_Select_UIBP:PlayFadein Fadein not found, period:%s", tostring(self.period)))
    return
  end
  self:StopAnimation("Fadein")
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:PlayFadein period:%s", tostring(self.period)))
  self:PlayUserWidgetAnimation(self.UIRoot.Fadein, 0, 1, 0, 1)
end

function XSuit_Box_Select_UIBP:PlayFadeoutAndClose()
  if self.bFadeoutClosing then
    if self.IsShow and self:IsShow() then
      log_error(string.format("XSuit_Box_Select_UIBP:PlayFadeoutAndClose already closing but still shown, force close. period:%s", tostring(self.period)))
      self:CloseSelf()
    end
    return
  end
  self.bFadeoutClosing = true
  if self.skipLoadScene and self.UIRoot and self.UIRoot.Fadeout then
    log(bWriteLog and string.format("XSuit_Box_Select_UIBP:PlayFadeoutAndClose play Fadeout. period:%s", tostring(self.period)))
    self._isPlayingCloseAnim = false
    if not self:CloseSelfWithAnim(self.UIRoot.Fadeout) then
      log_error(string.format("XSuit_Box_Select_UIBP:PlayFadeoutAndClose CloseSelfWithAnim refused, force close. period:%s", tostring(self.period)))
      self:CloseSelf()
    end
    return
  end
  self:Hide2DUI()
  self:CloseSelf()
end

local BRANCH_ITEM_WIDGETS = {
  "XSuit_Choose_Item_UIBP_01",
  "XSuit_Choose_Item_UIBP_02",
  "XSuit_Choose_Item_UIBP_03"
}

function XSuit_Box_Select_UIBP:GetBranchIds()
  local branchIds = {}
  for branchId in pairs(self.branchCommonCfgs or {}) do
    table.insert(branchIds, branchId)
  end
  table.sort(branchIds)
  return branchIds
end

function XSuit_Box_Select_UIBP:GetBranchSuitItemId(branchId)
  local baseInfo = LogicXSuit.GetBaseInfo(self.period, true, branchId)
  if baseInfo and baseInfo.item_id then
    return baseInfo.item_id
  end
  return LogicXSuit.GetItemIDByLevel(self.period, 1, branchId)
end

function XSuit_Box_Select_UIBP:InitBranchItems()
  self.branchList = {}
  local UIComponentModule = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule)
  local componentCfg = UIComponentModule and UIComponentModule.Config.XSuit_Choose_Branch_Item
  if not componentCfg then
    log_error("XSuit_Box_Select_UIBP:InitBranchItems no component cfg [XSuit_Choose_Branch_Item]")
    return
  end
  local branchIds = self:GetBranchIds()
  for index, widgetName in ipairs(BRANCH_ITEM_WIDGETS) do
    local widget = self.UIRoot[widgetName]
    local branchId = branchIds[index]
    local config = branchId ~= nil and self.branchCommonCfgs[branchId] or nil
    if not widget or not config then
      log_error(string.format("XSuit_Box_Select_UIBP:InitBranchItems invalid item. index:%s widget:%s branchId:%s", tostring(index), tostring(widgetName), tostring(branchId)))
    else
      self.branchList[branchId] = UIComponentModule:InitWithParentComponent(self, componentCfg, widget, config)
      log(bWriteLog and string.format("XSuit_Box_Select_UIBP:InitBranchItems branchId:%s widget:%s", tostring(branchId), tostring(widgetName)))
    end
  end
end

function XSuit_Box_Select_UIBP:OnShow()
  if self.skipLoadScene then
    return
  end
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:OnShow skip enter action. period:%s", tostring(self.period)))
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:PlaySpinAudio_BG(1, self.period)
end

function XSuit_Box_Select_UIBP:OnClose()
  self:RestoreSceneAfterClose()
  self:RestoreWardrobeUnderScene()
  if self.callback then
    self.callback(self.selectItemId and self.selectItemId > 0 and {
      itemid = self.selectItemId,
      count = 1,
      resid = self.selectItemId
    }, self.decomposeItemId and 0 < self.decomposeItemId and {
      itemid = self.decomposeItemId,
      count = self.decomposeItemNum or 1,
      resid = self.decomposeItemId
    })
  end
  self:Hide2DUI()
  for branchId, branchItem in pairs(self.branchList or {}) do
    if branchItem then
      if branchItem._config then
        branchItem:CloseSelf()
      elseif branchItem.Close then
        branchItem:Close()
      end
    end
  end
  self.branchList = nil
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:PlaySpinAudio_BG(-1, self.period)
  local bDecompose = self.decomposeItemId and 0 < self.decomposeItemId
  if self.bConfirm and not bDecompose and self.selectItemId and self.selectItemId > 0 then
    LogicXSuit.CheckStimulusCollection(self.period, self.selectBranchId, LogicXSuit.GetLevelByItemId(self.selectItemId))
  end
end

function XSuit_Box_Select_UIBP:OnAndroidBack()
  if not self.bConfirm then
    self.decomposeItemId = 0
    self.selectItemId = 0
  end
  self:PlayFadeoutAndClose()
end

function XSuit_Box_Select_UIBP:Hide2DUI()
  if self.UIRoot.CanvasPanel_Share then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Share, false)
  end
  if self.UIRoot.CanvasPanel_Choose then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Choose, false)
  end
end

function XSuit_Box_Select_UIBP:OnButtonClick_Branch(branchId)
  if self.bConfirm then
    log("XSuit_Box_Select_UIBP:OpenBoxHandler, OnButtonClick_Branch")
    return
  end
  self.selectItemId = self:GetBranchSuitItemId(branchId)
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:OnButtonClick_Branch period:%s, branchId:%s, selectItemId:%s", tostring(self.period), tostring(branchId), tostring(self.selectItemId)))
  local lastUI = self.branchList and self.branchList[self.selectBranchId or -1]
  if lastUI then
    lastUI:OnUnSelectHandle()
  end
  self.selectBranchId = branchId
  local ui = self.branchList and self.branchList[branchId]
  if ui then
    ui:OnSelectHandle()
  end
  self:SetWidgetVisible(self.UIRoot.Image_3, true)
  if self.skipLoadScene then
    return
  end
  if not self.bSceneInited then
    return
  end
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local showingAvatar = ModelDisplayer.GetShowingAvatar()
  local _ = showingAvatar and showingAvatar:SetAvatarSync(true)
  self:ShowAvatarDisplay(self.selectItemId, {bWear = true})
  self:HideAvatar()
end

function XSuit_Box_Select_UIBP:OnButtonClick_Confirm()
  if self.bConfirm then
    log("XSuit_Box_Select_UIBP:OpenBoxHandler, OnButtonClick_Confirm")
    return
  end
  self:PlayAudio(sound_config.click_v1)
  local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
  local itemData = wardrobe_data:GetHallDepotItemDataByResID(self.boxId)
  if not itemData then
    self.decomposeItemId = 0
    self.selectItemId = 0
    ShowNotice(68484)
    self:CloseSelf()
    return
  end
  if not self.selectItemId or not self.selectBranchId then
    ShowNotice(660001)
    return
  end
  local _, all_flag = LogicXSuit.IsGetAllXSuitByPeriod(self.period)
  local tip = _tip[self.period] and LocUtil.LocalizeResFormat(_tip[self.period]) or LocUtil.LocalizeResFormat(_tip[17])
  if not all_flag then
    local itemId = self:GetBranchSuitItemId(self.selectBranchId)
    local itemCfg = itemId and CDataTable.GetTableData("Item", itemId)
    local suitName = itemCfg and itemCfg.ItemName
    tip = LocUtil.LocalizeResFormat("18141468", suitName)
  end
  local title = LocUtil.LocalizeResFormat("101001")
  local CommonMsgBoxMgr = require("client.slua.logic.common.logic_common_msg_box")
  CommonMsgBoxMgr.Show(2, title, tip, function()
    self.itemData = itemData
    self:SendOpenGoldDressBranchBox()
  end)
end

function XSuit_Box_Select_UIBP:SendOpenGoldDressBranchBox()
  if not self.itemData then
    return
  end
  local XSuitHandler = require("client.network.Protocol.XSuitHandler")
  XSuitHandler.send_open_gold_dress_branch_box_req(self.itemData.insID, self.selectItemId, self.source)
  self.itemData = nil
end

function XSuit_Box_Select_UIBP:OpenBoxHandler(_, _, itemData)
  if self.bConfirm then
    log("XSuit_Box_Select_UIBP:OpenBoxHandler, bConfirm")
    return
  end
  self.selectItemId = itemData.resid
  self.decomposeItemId = itemData.decompose_item_id
  self.decomposeItemNum = itemData.decompose_item_num
  self.selectBranchId = LogicXSuit.GetBranchByItemId(self.selectItemId)
  self.videoPath = ""
  local xsuit_config_and_cache = require("client.slua.logic.XSuit.xsuit_config_and_cache")
  local videoName = string.format("XSuit_Rate_Item_%d", self.boxId)
  local videoCfg = xsuit_config_and_cache.GetSpinVideoPathByVideoName(videoName)
  if videoCfg then
    local videoPathList = {
      videoCfg.bFirst_video_path,
      videoCfg.bSecond_video_path,
      videoCfg.bThird_video_path
    }
    self.videoPath = videoPathList[self.selectBranchId + 1]
  end
  self.bConfirm = true
  if not self.decomposeItemId or self.decomposeItemId == 0 then
    if self.skipLoadScene then
      self:PlayUserWidgetAnimation(self.UIRoot.Fadeout, 0, 1, 0, 1)
      self:PlayerBranchVideo()
    else
      self:Hide2DUI()
      self:BeginBranchScene(function()
        if self.selectItemId and self.selectItemId > 0 then
          self:ShowAvatarDisplay(self.selectItemId, {bWear = true})
        end
        self:PlayBranchAction()
      end)
    end
  else
    if not self.callback then
      local Logic_CommonItemGet = require("client.slua.logic.common.CommonItemGet.Logic_CommonItemGet")
      Logic_CommonItemGet.ShowPanel_DecomposeStyle({itemData}, {
        self.decomposeItemId and {
          itemid = itemData.decompose_item_id,
          count = itemData.decompose_item_num
        }
      })
    end
    self:PlayFadeoutAndClose()
  end
  local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
  local showingAvatar = ModelDisplayer.GetShowingAvatar()
  local _ = showingAvatar and showingAvatar:SetAvatarSync(false)
end

function XSuit_Box_Select_UIBP:PlayerBranchVideo()
  if self.showListTimer then
    self:RemoveTimer(self.showListTimer)
    self.showListTimer = nil
  end
  local config = self.branchCommonCfgs and self.branchCommonCfgs[self.selectBranchId]
  if config and config.ChestBranchAction > 0 then
    self.actionId = config.ChestBranchAction
  else
    self:PlayFadeoutAndClose()
    return
  end
  self:PlayUserWidgetAnimation(self.UIRoot.Fadeout, 0, 1, 0, 1)
  if self.videoPath and self.videoPath ~= "" then
    self.showListTimer = self:AddTimer(0, function()
      local EStretch = import("EStretch")
      UIManager.ShowUI(UIManager.UI_Config.xsuit_spin_video_player_system, self.videoPath, {
        bRestoreLobbyMusic = false,
        ScaleToFit = EStretch.ScaleToFill,
        bKeepLobbyBgm = true,
        bDoNotChangeCameraSetting = true
      })
      self:SetWidgetVisible(self.UIRoot.ScaleBox_Draw, true)
      local ui = UIManager.GetUI(UIManager.UI_Config.xsuit_spin_video_player_system)
      while ui and (ui:IsShow() or ui:IsAsyncLoading()) do
        coroutine.yield(0.1)
      end
      self:OnActionStop(_, _, self.actionId)
    end)
  else
    self:PlayFadeoutAndClose()
  end
end

function XSuit_Box_Select_UIBP:PlayBranchAction()
  local config = self.branchCommonCfgs and self.branchCommonCfgs[self.selectBranchId]
  if config and config.ChestBranchAction > 0 then
    self.actionId = config.ChestBranchAction
    self:ShowAvatarDisplay(self.actionId, {
      bForceHideBeforeEmote = true,
      extraWearList = self.selectItemId and 0 < self.selectItemId and {
        self.selectItemId
      } or nil
    })
  else
    self:PlayFadeoutAndClose()
  end
end

function XSuit_Box_Select_UIBP:OnButtonClick_ShareConfirm()
  self:PlayAudio(sound_config.click_v1)
  self:PlayFadeoutAndClose()
end

function XSuit_Box_Select_UIBP:OnButtonClick_Share()
  self:PlayAudio(sound_config.click_v1)
  LogicXSuit.ShowGoldSuitShareUI(self.selectItemId, nil, function()
    self:PlayFadeoutAndClose()
  end)
end

function XSuit_Box_Select_UIBP:OnActionStop(_, _, actionId)
  log(bWriteLog and "XSuit_Box_Select_UIBP:OnActionStop" .. tostring(actionId))
  if self.periodCommonCfg and actionId == self.periodCommonCfg.ChestBranchAction then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Choose, true)
    self:HideAvatar()
    self:PlayUserWidgetAnimation(self.UIRoot.Fadein, 0, 1, 0, 1)
  elseif self.actionId and self.actionId == actionId then
    if GRATING_CARD_PERIODS[self.period] and not LogicXSuit.IsGratingCardShown(self.period, self.selectBranchId) then
      self:ShowGratingCard()
      return
    end
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Share, true)
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Share, 0, 1, 0, 1)
    local config = LogicXSuit.GetUpgradeUIInfoByBranchId(self.period, self.selectBranchId)
    local _ = config and self:SetTexture(self.UIRoot.Image_Share, config.ChestBranchShareIcon, {sync = false})
    local itemCfg = CDataTable.GetTableData("Item", self.selectItemId)
    self.UIRoot.TextBlock_8:SetText(itemCfg.ItemName)
  end
end

function XSuit_Box_Select_UIBP:ShowGratingCard()
  local itemId = self.selectItemId
  if not itemId or itemId <= 0 then
    log_error(string.format("XSuit_Box_Select_UIBP:ShowGratingCard invalid itemId:%s, period:%s", tostring(itemId), tostring(self.period)))
    self:CloseSelf()
    return
  end
  
  local function closeSelf()
    self:CloseSelf()
  end
  
  local ui = UIManager.ShowUI(UIManager.UI_Config.XSuit_Congratulations_Role, itemId, self.selectBranchId, closeSelf)
  if ui then
    ui.closeCallback = closeSelf
  end
  LogicXSuit.MarkGratingCardShown(self.period, self.selectBranchId)
  log(bWriteLog and string.format("XSuit_Box_Select_UIBP:ShowGratingCard period:%s, itemId:%s", tostring(self.period), tostring(itemId)))
end

local ui_base = require("client.slua_ui_framework.base")
local Trait = require("common.trait")
local Traits = {
  require("client.slua.umg.XSuit_Workshop.Traits.Xsuit_Avatar_Component")
}
local CXSuit_Box_Select_UIBP = Trait.TraitClass(ui_base, nil, XSuit_Box_Select_UIBP, Traits)
return CXSuit_Box_Select_UIBP
