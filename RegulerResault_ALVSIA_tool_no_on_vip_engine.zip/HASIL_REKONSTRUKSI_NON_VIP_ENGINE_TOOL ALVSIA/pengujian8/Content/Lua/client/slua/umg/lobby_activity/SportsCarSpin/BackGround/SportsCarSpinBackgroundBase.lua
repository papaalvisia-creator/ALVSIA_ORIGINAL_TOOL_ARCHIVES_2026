local SportsCarSpinBackgroundBase = {}
local Trait = require("common.trait")
local PufferTlog = require("client.slua.logic.download.report.puffer_tlog")
local SportsCarUIBase = require("client.slua.umg.lobby_activity.SportsCarSpin.SportsCarUIBase")
local Traits = {
  require("client.slua.umg.common.video.video_trait")
}
local s_keptNormalLocalVideoSession
local CSportsCarSpinBackgroundBase = Trait.TraitClass(SportsCarUIBase, nil, SportsCarSpinBackgroundBase, Traits)

function SportsCarSpinBackgroundBase:ctor(_, bIsLowLevel, bIsJumpReturn)
  log(bWriteLog and "SportsCarSpinBackgroundBase:ctor bIsLowLevel: " .. tostring(bIsLowLevel) .. ", bIsJumpReturn: " .. tostring(bIsJumpReturn))
  self.bIsLowLevel = bIsLowLevel
  self.bIsJumpReturn = bIsJumpReturn
end

function SportsCarSpinBackgroundBase:RegistEvents()
  SportsCarSpinBackgroundBase.__super.RegistEvents(self)
  if self.UIRoot.Button_EasterEggs then
    self:AddControlEventByControl(self.UIRoot.Button_EasterEggs, "OnClicked", self.OnClickButton, self)
  end
  self:AddCommonEvent(EVENTTYPE_VIDEO, EVENTID_VIDEO_RETRY_PLAY, self.TryToPlayLoopAnim, self)
  self:AddCommonEvent(EVENTTYPE_VIDEO, EVENTID_VIDEO_STARTS, self.OnOtherVideoStart, self)
  self:AddCommonEvent(EVENTTYPE_LADDER_DRAW, EVENTID_LADDER_DRAW_MAIN_UI_CLOSING, self.ReleaseVideoForManualClose, self)
end

function SportsCarSpinBackgroundBase:OnOtherVideoStart()
  log(bWriteLog and "[sports_car] SportsCarSpinBackgroundBase:OnOtherVideoStart")
  self:SetNormalLocalVideoLoop(false)
end

function SportsCarSpinBackgroundBase:OnPostInitialize()
  log(bWriteLog and "SportsCarSpinBackgroundBase:OnPostInitialize")
  SportsCarSpinBackgroundBase.__super.OnPostInitialize(self)
  EventSystem:postEvent(EVENTTYPE_ACTIVITY, EVENTID_LUCKYSPINE_BG_FINISH)
end

function SportsCarSpinBackgroundBase:ReleaseVideoForManualClose()
  log(bWriteLog and "[sports_car] SportsCarSpinBackgroundBase:ReleaseVideoForManualClose")
  if s_keptNormalLocalVideoSession then
    self:ReleaseNormalLocalVideoSession(s_keptNormalLocalVideoSession)
    s_keptNormalLocalVideoSession = nil
  end
  if self.UIRoot and slua.isValid(self.UIRoot) then
    self:ReleaseResource(self.UIRoot.Image_Car_Video)
  end
end

function SportsCarSpinBackgroundBase:OnClose()
  self._loopVideoPath = nil
  self:SetNormalLocalVideoLoop(false)
  if s_keptNormalLocalVideoSession then
    self:ReleaseNormalLocalVideoSession(s_keptNormalLocalVideoSession)
    s_keptNormalLocalVideoSession = nil
  end
  s_keptNormalLocalVideoSession = self:DetachNormalLocalVideoSession()
  if not s_keptNormalLocalVideoSession then
    self:ReleaseResource(self.UIRoot.Image_Car_Video)
  end
  SportsCarSpinBackgroundBase.__super.OnClose(self)
end

function SportsCarSpinBackgroundBase:TryToPlayEnterAnim()
  log(bWriteLog and "SportsCarSpinBackgroundBase:TryToPlayEnterAnim1111 self.bIsLowLevel: " .. tostring(self.bIsLowLevel))
  if not slua.isValid(self.UIRoot) then
    return
  end
  local entryAnimName = self:GetUIConfigValue("animationCfg", "Background", "EntryAnim")
  log(bWriteLog and "SportsCarSpinBackgroundBase:TryToPlayEnterAnim get animation1111: " .. tostring(entryAnimName))
  if entryAnimName and slua.isValid(self.UIRoot[entryAnimName]) then
    log(bWriteLog and "SportsCarSpinBackgroundBase:TryToPlayEnterAnim play animation: " .. tostring(entryAnimName))
    self:PlayUserWidgetAnimation(self.UIRoot[entryAnimName], 0, 1, 0, 1)
  end
  local bCanPlayVideo = self:TryToPlayLoopAnim()
  log(bWriteLog and "SportsCarSpinBackgroundBase:TryToPlayEnterAnim bCanPlayVideo: " .. tostring(bCanPlayVideo))
  if slua.isValid(self.UIRoot.WidgetSwitcher_CarMode) then
    self.UIRoot.WidgetSwitcher_CarMode:SetActiveWidgetIndex(bCanPlayVideo and 1 or 0)
  end
end

function SportsCarSpinBackgroundBase:TryToPlayLoopAnim(bIgnoreDownload)
  log(bWriteLog and "SportsCarSpinBackgroundBase:TryToPlayLoopAnim")
  if self.bIsLowLevel then
    return false
  end
  if not self.UIRoot.Image_Car_Video then
    return false
  end
  local version = self:GetVersion()
  local SportsCarSpinConfig = require("client.slua.umg.lobby_activity.SportsCarSpin.Config.SportsCarSpinConfig")
  local backgroundVideoCfg = SportsCarSpinConfig.GetSpinChildElemCfg(version, "BackgroundVideo")
  if not (backgroundVideoCfg and backgroundVideoCfg.videoPath) or not backgroundVideoCfg.mediaPlayerPath then
    return false
  end
  local playVideoMatPath = backgroundVideoCfg.playVideoMatPathIOS
  local strPlatform = Client.GetDevicePlatformName()
  local DevicePlatformNameMacros = require("client.slua.config.ClientMacros.DevicePlatformNameMacros")
  if strPlatform == DevicePlatformNameMacros.Android then
    playVideoMatPath = backgroundVideoCfg.playVideoMatPathAndroid
  end
  if not playVideoMatPath then
    return false
  end
  local VideoLibrary = require("client.slua.logic.video.lobby_video_function_library")
  if not VideoLibrary.IsVideoFileReady(backgroundVideoCfg.videoPath) then
    if not bIgnoreDownload then
      local PufferManager = require("client.slua.logic.download.puffer.puffer_manager")
      local PufferConst = require("client.slua.logic.download.puffer_const")
      local videoDownloadPath = DataMgr.GetVideoDownloadPath(backgroundVideoCfg.videoPath)
      if videoDownloadPath ~= "" then
        local PublishRegionMacros = require("client.slua.config.ClientMacros.PublishRegionMacros")
        log(bWriteLog and "[sports_car] SportsCarSpinBackgroundBase:TryToPlayLoopAnim videoDownloadPath = " .. videoDownloadPath)
        PufferManager.Download(PufferConst.ENUM_DownloadType.ODPAK, {videoDownloadPath}, PufferTlog.Enum_TLog_From.Vehicle, function()
          self:TryToPlayEnterAnim(true)
        end, {
          bFirst = true,
          bAutoDownload = PublishRegionMacros.IsFITVersion()
        })
      end
    end
    return false
  end
  if s_keptNormalLocalVideoSession and not self.bIsJumpReturn then
    self:ReleaseNormalLocalVideoSession(s_keptNormalLocalVideoSession)
    s_keptNormalLocalVideoSession = nil
  end
  if s_keptNormalLocalVideoSession then
    local session = s_keptNormalLocalVideoSession
    s_keptNormalLocalVideoSession = nil
    if session.videoPath == backgroundVideoCfg.videoPath then
      self:SetMediaTextureAutoClear(backgroundVideoCfg.mediaTexturePath, false)
      if self:ResumeNormalLocalVideoSession(session, self.UIRoot.Image_Car_Video, nil, true, not self.bIsJumpReturn) then
        log(bWriteLog and "[sports_car] SportsCarSpinBackgroundBase:TryToPlayLoopAnim resume kept session.")
        self._loopVideoPath = backgroundVideoCfg.videoPath
        self:SetNormalLocalVideoLoop(true)
        self:SetCanPlayVideoShow(true)
        return true
      end
    else
      self:ReleaseNormalLocalVideoSession(session)
    end
  end
  if self._loopVideoPath == backgroundVideoCfg.videoPath and self:NormalLocalVideoIsReady() then
    log(bWriteLog and "[sports_car] SportsCarSpinBackgroundBase:TryToPlayLoopAnim already playing, skip reopen.")
    self:SetNormalLocalVideoLoop(true)
    self:SetCanPlayVideoShow(true)
    return true
  end
  self._loopVideoPath = backgroundVideoCfg.videoPath
  self:SetMediaTextureAutoClear(backgroundVideoCfg.mediaTexturePath, false)
  self:PlayNormalLocalVideo(self.UIRoot.Image_Car_Video, backgroundVideoCfg.videoPath, backgroundVideoCfg.mediaPlayerPath, playVideoMatPath, nil, true, true)
  return true
end

function SportsCarSpinBackgroundBase:OnClickButton()
  log(bWriteLog and "SportsCarSpinBackgroundBase:OnClickButton")
  self:PlayAudio("/Game/WwiseEvent/Activity/Activity_230/Maserati_Drift_230/Play_Maserati_Drift_Acclerate.Play_Maserati_Drift_Acclerate")
  local animEasterEggsName = self:GetUIConfigValue("animationCfg", "Background", "EasterEggsAnim")
  if not animEasterEggsName or not slua.isValid(self.UIRoot[animEasterEggsName]) then
    return
  end
  self:PlayUserWidgetAnimation(self.UIRoot[animEasterEggsName], 0, 1, 0, 1)
  self.UIRoot.Button_EasterEggs:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self:AddTimerOnce(self.UIRoot[animEasterEggsName]:GetEndTime(), function()
    self.UIRoot.Button_EasterEggs:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
  end)
end

function SportsCarSpinBackgroundBase:OnEndReached()
  log(bWriteLog and "[YY]SportsCarSpinBackgroundBase:OnEndReached")
  self:AddTimerOnce(0.1, function()
    if not slua.isValid(self.UIRoot) then
      return
    end
    if self:IsNormalLocalVideoPlaying() then
      return
    end
    log(bWriteLog and "[sports_car] SportsCarSpinBackgroundBase:OnEndReached loop not working, replay.")
    self:ReplayNormalLocalMedia()
  end)
end

function SportsCarSpinBackgroundBase:OnMediaOpenFailed()
  log(bWriteLog and "[YY]SportsCarSpinBackgroundBase:OnMediaOpenFailed")
  self:SetCanPlayVideoShow(false)
  self:ReplayNormalLocalMedia()
end

function SportsCarSpinBackgroundBase:OnMediaOpened()
  log(bWriteLog and "[YY]SportsCarSpinBackgroundBase:OnMediaOpened")
  self:SetCanPlayVideoShow(true)
end

function SportsCarSpinBackgroundBase:OnMediaClosed()
  log(bWriteLog and "[YY]SportsCarSpinBackgroundBase:OnMediaClosed")
end

function SportsCarSpinBackgroundBase:SetCanPlayVideoShow(bVisible)
  bVisible = bVisible or false
  self:SetWidgetVisible(self.UIRoot.Image_Car_Video, bVisible)
  if slua.isValid(self.UIRoot.WidgetSwitcher_CarMode) then
    self.UIRoot.WidgetSwitcher_CarMode:SetActiveWidgetIndex(bVisible and 1 or 0)
  end
end

return CSportsCarSpinBackgroundBase
