.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	56

.upvalue	"_ENV"	0	true

.constant	k0	190
.constant	k1	203
.constant	k2	97
.constant	k3	101
.constant	k4	133
.constant	k5	154
.constant	k6	126
.constant	k7	29
.constant	k8	129
.constant	k9	37
.constant	k10	119
.constant	k11	201
.constant	k12	178
.constant	k13	3
.constant	k14	145
.constant	k15	14
.constant	k16	"require"
.constant	k17	218
.constant	k18	130
.constant	k19	73
.constant	k20	108
.constant	k21	105
.constant	k22	86
.constant	k23	137
.constant	k24	12
.constant	k25	90
.constant	k26	35
.constant	k27	225
.constant	k28	77
.constant	k29	100
.constant	k30	104
.constant	k31	76
.constant	k32	142
.constant	k33	18
.constant	k34	78
.constant	k35	43
.constant	k36	202
.constant	k37	188
.constant	k38	240
.constant	k39	176
.constant	k40	59
.constant	k41	57
.constant	k42	84
.constant	k43	103
.constant	k44	189
.constant	k45	166
.constant	k46	64
.constant	k47	106
.constant	k48	52
.constant	k49	236
.constant	k50	180
.constant	k51	232
.constant	k52	175
.constant	k53	54
.constant	k54	163
.constant	k55	6
.constant	k56	149
.constant	k57	125
.constant	k58	"table"
.constant	k59	"concat"
.constant	k60	187
.constant	k61	244
.constant	k62	79
.constant	k63	248
.constant	k64	7
.constant	k65	184
.constant	k66	98
.constant	k67	168
.constant	k68	56
.constant	k69	25
.constant	k70	181
.constant	k71	247
.constant	k72	217
.constant	k73	89
.constant	k74	161
.constant	k75	60
.constant	k76	117
.constant	k77	148
.constant	k78	121
.constant	k79	182
.constant	k80	169
.constant	k81	195
.constant	k82	112
.constant	k83	82
.constant	k84	114
.constant	k85	87
.constant	k86	205
.constant	k87	152
.constant	k88	46
.constant	k89	45
.constant	k90	237
.constant	k91	162
.constant	k92	44
.constant	k93	74
.constant	k94	211
.constant	k95	42
.constant	k96	62
.constant	k97	250
.constant	k98	252
.constant	k99	120
.constant	k100	183
.constant	k101	16
.constant	k102	80
.constant	k103	69
.constant	k104	147
.constant	k105	131
.constant	k106	164
.constant	k107	95
.constant	k108	246
.constant	k109	10
.constant	k110	83
.constant	k111	153
.constant	k112	160
.constant	k113	124
.constant	k114	13
.constant	k115	0
.constant	k116	234
.constant	k117	123
.constant	k118	158
.constant	k119	93
.constant	k120	171
.constant	k121	41
.constant	k122	68
.constant	k123	136
.constant	k124	172
.constant	k125	243
.constant	k126	75
.constant	k127	115
.constant	k128	99
.constant	k129	107
.constant	k130	141
.constant	k131	51
.constant	k132	209
.constant	k133	238
.constant	k134	70
.constant	k135	186
.constant	k136	38
.constant	k137	48
.constant	k138	191
.constant	k139	241
.constant	k140	"TraitClass"
.constant	k141	17
.constant	k142	92
.constant	k143	231
.constant	k144	185
.constant	k145	122
.constant	k146	91
.constant	k147	146
.constant	k148	27
.constant	k149	233
.constant	k150	170
.constant	k151	165
.constant	k152	39
.constant	k153	227
.constant	k154	167
.constant	k155	33
.constant	k156	177
.constant	k157	3000225
.constant	k158	"ctor"
.constant	k159	"GetPageConfig"
.constant	k160	"RefreshPageInfo"
.constant	k161	"RegistEvents"
.constant	k162	"OnPostInitialize"
.constant	k163	"OnShow"
.constant	k164	"PreviewTimeTLog"
.constant	k165	"OnClickSendGift"
.constant	k166	"OnClickBuy"
.constant	k167	"OnClickSubscribeBuy"
.constant	k168	"OnClickDisBtn"
.constant	k169	"OnClickJump"
.constant	k170	"UpdateScrollviewSelectedIndex"
.constant	k171	"RefreshPageContent"
.constant	k172	"OnGetDirectPriceInfo"
.constant	k173	"OnGetLocalPriceInfo"
.constant	k174	"RefreshUI"
.constant	k175	"FilterItemByCondition"
.constant	k176	"SortPriceByCurrency"
.constant	k177	"OnCollectedResult"
.constant	k178	"OnSubscirbeResult"
.constant	k179	"OnBuyInfoChange"
.constant	k180	"OnBuyResult"
.constant	k181	"OnSubscribeGiftBuyResult"
.constant	k182	"OnInventoryChange"
.constant	k183	"RefreshPetItemsHave"
.constant	k184	"OnPriceChanged"
.constant	k185	"UpdateUI"
.constant	k186	"ChooseCrystalForRegional"
.constant	k187	"GetClothShowTabIcon"
.constant	k188	"JumpItemByShopID"
.constant	k189	"_ClearJumpInfoDelay"
.constant	k190	"ChooseTheFirstOrSpecifiedOne"
.constant	k191	"ShowDefaultScene"
.constant	k192	"IsFirstItemResReady"
.constant	k193	"GetGiftResIdListForReadyCheck"
.constant	k194	"RequestFirstGiftInfoForReadyCheck"
.constant	k195	"IfNeedChooseTheFirstOne"
.constant	k196	"GetFrame"
.constant	k197	"OnClose"
.constant	k198	"OnHide"
.constant	k199	"GetIsShowCoupon"
.constant	k200	"RestoreCurUseCharacter"
.constant	k201	"ResetHide"
.constant	k202	"ResetShow"
.constant	k203	"SetTitleData"
.constant	k204	"UpdateNewCollectBtn"
.constant	k205	"UpdateLimitedSubscribeBtn"
.constant	k206	"UpdateNewGiftBtn"
.constant	k207	"UpdateNewBuyBtn"
.constant	k208	"OnChestInfoUpdate"
.constant	k209	"RefreshSubDailyGiftItem"
.constant	k210	"GetSubscribeDailyPackCfg"
.constant	k211	"SetSubTabOffsetByJK"
.constant	k212	"OnScreenSizeChanged"
.constant	k213	"SetTaggedPointLightHidden"
.constant	k214	"PutOnOrOffStoreClothes"
.constant	k215	"UpdateItemSelectEquippedState"
.constant	k216	"UpdateEquipedStateAndReferesh"
.constant	k217	"UpdateWearWithAutoDownload"
.constant	k218	"SetModelRotation"
.constant	k219	"UpdateLeftItemSelectEquippedState"
.constant	k220	"OnClickFullScreen"
.constant	k221	"BanDefaultWearForDailyPack"

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 190
.line	0	loadk         r2    k1 ; k1 = 203
.line	0	loadk         r3    k2 ; k2 = 97
.line	0	loadk         r4    k3 ; k3 = 101
.line	0	loadk         r5    k4 ; k4 = 133
.line	0	loadk         r6    k5 ; k5 = 154
.line	0	loadk         r7    k6 ; k6 = 126
.line	0	loadk         r8    k7 ; k7 = 29
.line	0	loadk         r9    k8 ; k8 = 129
.line	0	loadk        r10    k9 ; k9 = 37
.line	0	loadk        r11   k10 ; k10 = 119
.line	0	loadk        r12   k11 ; k11 = 201
.line	0	loadk        r13   k12 ; k12 = 178
.line	0	loadk        r14   k13 ; k13 = 3
.line	0	loadk        r15   k14 ; k14 = 145
.line	0	loadk        r16   k15 ; k15 = 14
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	newtable      r2     0     0
.line	0	gettabup      r3    u0   k16 ; k16 = "require"
.line	0	move          r4    r1
.line	0	loadk         r5   k17 ; k17 = 218
.line	0	loadk         r6   k18 ; k18 = 130
.line	0	loadk         r7   k19 ; k19 = 73
.line	0	loadk         r8   k20 ; k20 = 108
.line	0	loadk         r9   k21 ; k21 = 105
.line	0	loadk        r10   k22 ; k22 = 86
.line	0	loadk        r11   k14 ; k14 = 145
.line	0	loadk        r12   k23 ; k23 = 137
.line	0	loadk        r13   k24 ; k24 = 12
.line	0	loadk        r14   k25 ; k25 = 90
.line	0	loadk        r15   k26 ; k26 = 35
.line	0	loadk        r16   k27 ; k27 = 225
.line	0	call          r4    13     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k16 ; k16 = "require"
.line	0	move          r5    r1
.line	0	loadk         r6   k17 ; k17 = 218
.line	0	loadk         r7    k8 ; k8 = 129
.line	0	loadk         r8   k28 ; k28 = 77
.line	0	loadk         r9   k29 ; k29 = 100
.line	0	loadk        r10   k30 ; k30 = 104
.line	0	loadk        r11   k31 ; k31 = 76
.line	0	loadk        r12   k14 ; k14 = 145
.line	0	loadk        r13   k32 ; k32 = 142
.line	0	loadk        r14   k33 ; k33 = 18
.line	0	loadk        r15   k34 ; k34 = 78
.line	0	loadk        r16   k35 ; k35 = 43
.line	0	loadk        r17   k36 ; k36 = 202
.line	0	loadk        r18   k37 ; k37 = 188
.line	0	loadk        r19   k38 ; k38 = 240
.line	0	loadk        r20   k10 ; k10 = 119
.line	0	loadk        r21   k39 ; k39 = 176
.line	0	loadk        r22   k40 ; k40 = 59
.line	0	loadk        r23   k37 ; k37 = 188
.line	0	loadk        r24   k41 ; k41 = 57
.line	0	loadk        r25   k42 ; k42 = 84
.line	0	loadk        r26    k8 ; k8 = 129
.line	0	loadk        r27   k43 ; k43 = 103
.line	0	loadk        r28   k44 ; k44 = 189
.line	0	loadk        r29   k45 ; k45 = 166
.line	0	loadk        r30   k46 ; k46 = 64
.line	0	loadk        r31   k47 ; k47 = 106
.line	0	loadk        r32   k48 ; k48 = 52
.line	0	loadk        r33   k49 ; k49 = 236
.line	0	loadk        r34   k50 ; k50 = 180
.line	0	loadk        r35   k51 ; k51 = 232
.line	0	loadk        r36   k31 ; k31 = 76
.line	0	loadk        r37   k52 ; k52 = 175
.line	0	loadk        r38   k53 ; k53 = 54
.line	0	loadk        r39   k54 ; k54 = 163
.line	0	loadk        r40   k55 ; k55 = 6
.line	0	loadk        r41   k46 ; k46 = 64
.line	0	loadk        r42   k56 ; k56 = 149
.line	0	loadk        r43   k57 ; k57 = 125
.line	0	call          r5    39     2
.line	0	call          r4     2     2
.line	0	newtable      r5     6     0
.line	0	gettabup      r6    u0   k16 ; k16 = "require"
.line	0	gettabup      r7    u0   k58 ; k58 = "table"
.line	0	gettable      r7    r7   k59 ; k59 = "concat"
.line	0	newtable      r8     1     0
.line	0	move          r9    r1
.line	0	loadk        r10   k17 ; k17 = 218
.line	0	loadk        r11    k8 ; k8 = 129
.line	0	loadk        r12   k28 ; k28 = 77
.line	0	loadk        r13   k29 ; k29 = 100
.line	0	loadk        r14   k30 ; k30 = 104
.line	0	loadk        r15   k31 ; k31 = 76
.line	0	loadk        r16   k14 ; k14 = 145
.line	0	loadk        r17   k32 ; k32 = 142
.line	0	loadk        r18   k33 ; k33 = 18
.line	0	loadk        r19   k34 ; k34 = 78
.line	0	loadk        r20   k35 ; k35 = 43
.line	0	loadk        r21   k60 ; k60 = 187
.line	0	loadk        r22   k37 ; k37 = 188
.line	0	loadk        r23   k61 ; k61 = 244
.line	0	loadk        r24   k62 ; k62 = 79
.line	0	loadk        r25   k63 ; k63 = 248
.line	0	loadk        r26   k64 ; k64 = 7
.line	0	loadk        r27   k65 ; k65 = 184
.line	0	loadk        r28   k26 ; k26 = 35
.line	0	loadk        r29   k66 ; k66 = 98
.line	0	loadk        r30   k18 ; k18 = 130
.line	0	loadk        r31   k43 ; k43 = 103
.line	0	loadk        r32   k44 ; k44 = 189
.line	0	loadk        r33   k67 ; k67 = 168
.line	0	loadk        r34   k68 ; k68 = 56
.line	0	loadk        r35   k69 ; k69 = 25
.line	0	loadk        r36   k66 ; k66 = 98
.line	0	loadk        r37   k70 ; k70 = 181
.line	0	loadk        r38   k71 ; k71 = 247
.line	0	loadk        r39   k72 ; k72 = 217
.line	0	loadk        r40   k73 ; k73 = 89
.line	0	loadk        r41   k74 ; k74 = 161
.line	0	loadk        r42   k75 ; k75 = 60
.line	0	loadk        r43    k0 ; k0 = 190
.line	0	loadk        r44   k47 ; k47 = 106
.line	0	loadk        r45   k76 ; k76 = 117
.line	0	loadk        r46   k77 ; k77 = 148
.line	0	loadk        r47   k78 ; k78 = 121
.line	0	loadk        r48   k79 ; k79 = 182
.line	0	loadk        r49   k80 ; k80 = 169
.line	0	call          r9    41     2
.line	0	move         r10    r1
.line	0	loadk        r11   k36 ; k36 = 202
.line	0	loadk        r12   k81 ; k81 = 195
.line	0	loadk        r13   k82 ; k82 = 112
.line	0	loadk        r14   k83 ; k83 = 82
.line	0	loadk        r15   k84 ; k84 = 114
.line	0	loadk        r16   k85 ; k85 = 87
.line	0	loadk        r17   k86 ; k86 = 205
.line	0	loadk        r18   k87 ; k87 = 152
.line	0	loadk        r19   k88 ; k88 = 46
.line	0	loadk        r20   k25 ; k25 = 90
.line	0	loadk        r21   k89 ; k89 = 45
.line	0	loadk        r22   k38 ; k38 = 240
.line	0	loadk        r23    k5 ; k5 = 154
.line	0	loadk        r24   k90 ; k90 = 237
.line	0	loadk        r25   k19 ; k19 = 73
.line	0	loadk        r26   k91 ; k91 = 162
.line	0	loadk        r27   k92 ; k92 = 44
.line	0	call         r10    18     0
.line	0	setlist       r8     0     1
.line	0	call          r7     2     2
.line	0	call          r6     2     2
.line	0	gettabup      r7    u0   k16 ; k16 = "require"
.line	0	gettabup      r8    u0   k58 ; k58 = "table"
.line	0	gettable      r8    r8   k59 ; k59 = "concat"
.line	0	newtable      r9     1     0
.line	0	move         r10    r1
.line	0	loadk        r11   k17 ; k17 = 218
.line	0	loadk        r12    k8 ; k8 = 129
.line	0	loadk        r13   k28 ; k28 = 77
.line	0	loadk        r14   k29 ; k29 = 100
.line	0	loadk        r15   k30 ; k30 = 104
.line	0	loadk        r16   k31 ; k31 = 76
.line	0	loadk        r17   k14 ; k14 = 145
.line	0	loadk        r18   k32 ; k32 = 142
.line	0	loadk        r19   k33 ; k33 = 18
.line	0	loadk        r20   k34 ; k34 = 78
.line	0	loadk        r21   k35 ; k35 = 43
.line	0	loadk        r22   k60 ; k60 = 187
.line	0	loadk        r23   k37 ; k37 = 188
.line	0	loadk        r24   k61 ; k61 = 244
.line	0	loadk        r25   k62 ; k62 = 79
.line	0	loadk        r26   k63 ; k63 = 248
.line	0	loadk        r27   k64 ; k64 = 7
.line	0	loadk        r28   k65 ; k65 = 184
.line	0	loadk        r29   k26 ; k26 = 35
.line	0	loadk        r30   k66 ; k66 = 98
.line	0	loadk        r31   k18 ; k18 = 130
.line	0	loadk        r32   k43 ; k43 = 103
.line	0	loadk        r33   k44 ; k44 = 189
.line	0	loadk        r34   k67 ; k67 = 168
.line	0	loadk        r35   k68 ; k68 = 56
.line	0	loadk        r36   k69 ; k69 = 25
.line	0	loadk        r37   k66 ; k66 = 98
.line	0	loadk        r38   k70 ; k70 = 181
.line	0	loadk        r39   k71 ; k71 = 247
.line	0	loadk        r40   k72 ; k72 = 217
.line	0	loadk        r41   k73 ; k73 = 89
.line	0	loadk        r42   k74 ; k74 = 161
.line	0	loadk        r43   k75 ; k75 = 60
.line	0	loadk        r44    k0 ; k0 = 190
.line	0	loadk        r45   k47 ; k47 = 106
.line	0	loadk        r46   k76 ; k76 = 117
.line	0	loadk        r47   k77 ; k77 = 148
.line	0	loadk        r48   k78 ; k78 = 121
.line	0	loadk        r49   k79 ; k79 = 182
.line	0	loadk        r50   k80 ; k80 = 169
.line	0	call         r10    41     2
.line	0	move         r11    r1
.line	0	loadk        r12   k36 ; k36 = 202
.line	0	loadk        r13   k81 ; k81 = 195
.line	0	loadk        r14   k10 ; k10 = 119
.line	0	loadk        r15   k76 ; k76 = 117
.line	0	loadk        r16   k21 ; k21 = 105
.line	0	loadk        r17   k93 ; k93 = 74
.line	0	loadk        r18   k17 ; k17 = 218
.line	0	loadk        r19   k94 ; k94 = 211
.line	0	loadk        r20   k95 ; k95 = 42
.line	0	loadk        r21   k30 ; k30 = 104
.line	0	loadk        r22   k96 ; k96 = 62
.line	0	loadk        r23   k97 ; k97 = 250
.line	0	loadk        r24   k60 ; k60 = 187
.line	0	loadk        r25   k98 ; k98 = 252
.line	0	loadk        r26   k99 ; k99 = 120
.line	0	loadk        r27  k100 ; k100 = 183
.line	0	loadk        r28   k88 ; k88 = 46
.line	0	loadk        r29   k65 ; k65 = 184
.line	0	loadk        r30  k101 ; k101 = 16
.line	0	loadk        r31  k102 ; k102 = 80
.line	0	loadk        r32   k18 ; k18 = 130
.line	0	loadk        r33   k21 ; k21 = 105
.line	0	call         r11    23     0
.line	0	setlist       r9     0     1
.line	0	call          r8     2     2
.line	0	call          r7     2     2
.line	0	gettabup      r8    u0   k16 ; k16 = "require"
.line	0	gettabup      r9    u0   k58 ; k58 = "table"
.line	0	gettable      r9    r9   k59 ; k59 = "concat"
.line	0	newtable     r10     1     0
.line	0	move         r11    r1
.line	0	loadk        r12   k17 ; k17 = 218
.line	0	loadk        r13    k8 ; k8 = 129
.line	0	loadk        r14   k28 ; k28 = 77
.line	0	loadk        r15   k29 ; k29 = 100
.line	0	loadk        r16   k30 ; k30 = 104
.line	0	loadk        r17   k31 ; k31 = 76
.line	0	loadk        r18   k14 ; k14 = 145
.line	0	loadk        r19   k32 ; k32 = 142
.line	0	loadk        r20   k33 ; k33 = 18
.line	0	loadk        r21   k34 ; k34 = 78
.line	0	loadk        r22   k35 ; k35 = 43
.line	0	loadk        r23   k60 ; k60 = 187
.line	0	loadk        r24   k37 ; k37 = 188
.line	0	loadk        r25   k61 ; k61 = 244
.line	0	loadk        r26   k62 ; k62 = 79
.line	0	loadk        r27   k63 ; k63 = 248
.line	0	loadk        r28   k64 ; k64 = 7
.line	0	loadk        r29   k65 ; k65 = 184
.line	0	loadk        r30   k26 ; k26 = 35
.line	0	loadk        r31   k66 ; k66 = 98
.line	0	loadk        r32   k18 ; k18 = 130
.line	0	loadk        r33   k43 ; k43 = 103
.line	0	loadk        r34   k44 ; k44 = 189
.line	0	loadk        r35   k67 ; k67 = 168
.line	0	loadk        r36   k68 ; k68 = 56
.line	0	loadk        r37   k69 ; k69 = 25
.line	0	loadk        r38   k66 ; k66 = 98
.line	0	loadk        r39   k70 ; k70 = 181
.line	0	loadk        r40   k71 ; k71 = 247
.line	0	loadk        r41   k72 ; k72 = 217
.line	0	loadk        r42   k73 ; k73 = 89
.line	0	loadk        r43   k74 ; k74 = 161
.line	0	loadk        r44   k75 ; k75 = 60
.line	0	loadk        r45    k0 ; k0 = 190
.line	0	loadk        r46   k47 ; k47 = 106
.line	0	loadk        r47   k76 ; k76 = 117
.line	0	loadk        r48   k77 ; k77 = 148
.line	0	loadk        r49   k78 ; k78 = 121
.line	0	loadk        r50   k79 ; k79 = 182
.line	0	loadk        r51   k80 ; k80 = 169
.line	0	call         r11    41     2
.line	0	move         r12    r1
.line	0	loadk        r13   k36 ; k36 = 202
.line	0	loadk        r14   k81 ; k81 = 195
.line	0	loadk        r15   k10 ; k10 = 119
.line	0	loadk        r16   k76 ; k76 = 117
.line	0	loadk        r17   k21 ; k21 = 105
.line	0	loadk        r18   k93 ; k93 = 74
.line	0	loadk        r19   k17 ; k17 = 218
.line	0	loadk        r20   k94 ; k94 = 211
.line	0	loadk        r21   k95 ; k95 = 42
.line	0	loadk        r22   k30 ; k30 = 104
.line	0	loadk        r23   k96 ; k96 = 62
.line	0	loadk        r24   k97 ; k97 = 250
.line	0	loadk        r25   k60 ; k60 = 187
.line	0	loadk        r26   k98 ; k98 = 252
.line	0	loadk        r27   k99 ; k99 = 120
.line	0	loadk        r28  k100 ; k100 = 183
.line	0	loadk        r29   k88 ; k88 = 46
.line	0	loadk        r30   k65 ; k65 = 184
.line	0	loadk        r31    k7 ; k7 = 29
.line	0	loadk        r32  k103 ; k103 = 69
.line	0	loadk        r33  k104 ; k104 = 147
.line	0	loadk        r34    k3 ; k3 = 101
.line	0	loadk        r35  k105 ; k105 = 131
.line	0	loadk        r36  k106 ; k106 = 164
.line	0	loadk        r37    k7 ; k7 = 29
.line	0	loadk        r38  k107 ; k107 = 95
.line	0	call         r12    27     0
.line	0	setlist      r10     0     1
.line	0	call          r9     2     2
.line	0	call          r8     2     2
.line	0	gettabup      r9    u0   k16 ; k16 = "require"
.line	0	gettabup     r10    u0   k58 ; k58 = "table"
.line	0	gettable     r10   r10   k59 ; k59 = "concat"
.line	0	newtable     r11     1     0
.line	0	move         r12    r1
.line	0	loadk        r13   k17 ; k17 = 218
.line	0	loadk        r14    k8 ; k8 = 129
.line	0	loadk        r15   k28 ; k28 = 77
.line	0	loadk        r16   k29 ; k29 = 100
.line	0	loadk        r17   k30 ; k30 = 104
.line	0	loadk        r18   k31 ; k31 = 76
.line	0	loadk        r19   k14 ; k14 = 145
.line	0	loadk        r20   k32 ; k32 = 142
.line	0	loadk        r21   k33 ; k33 = 18
.line	0	loadk        r22   k34 ; k34 = 78
.line	0	loadk        r23   k35 ; k35 = 43
.line	0	loadk        r24   k60 ; k60 = 187
.line	0	loadk        r25   k37 ; k37 = 188
.line	0	loadk        r26   k61 ; k61 = 244
.line	0	loadk        r27   k62 ; k62 = 79
.line	0	loadk        r28   k63 ; k63 = 248
.line	0	loadk        r29   k64 ; k64 = 7
.line	0	loadk        r30   k65 ; k65 = 184
.line	0	loadk        r31   k26 ; k26 = 35
.line	0	loadk        r32   k66 ; k66 = 98
.line	0	loadk        r33   k18 ; k18 = 130
.line	0	loadk        r34   k43 ; k43 = 103
.line	0	loadk        r35   k44 ; k44 = 189
.line	0	loadk        r36   k67 ; k67 = 168
.line	0	loadk        r37   k68 ; k68 = 56
.line	0	loadk        r38   k69 ; k69 = 25
.line	0	loadk        r39   k66 ; k66 = 98
.line	0	loadk        r40   k70 ; k70 = 181
.line	0	loadk        r41   k71 ; k71 = 247
.line	0	loadk        r42   k72 ; k72 = 217
.line	0	loadk        r43   k73 ; k73 = 89
.line	0	loadk        r44   k74 ; k74 = 161
.line	0	loadk        r45   k75 ; k75 = 60
.line	0	loadk        r46    k0 ; k0 = 190
.line	0	loadk        r47   k47 ; k47 = 106
.line	0	loadk        r48   k76 ; k76 = 117
.line	0	loadk        r49   k77 ; k77 = 148
.line	0	loadk        r50   k78 ; k78 = 121
.line	0	loadk        r51   k79 ; k79 = 182
.line	0	loadk        r52   k80 ; k80 = 169
.line	0	call         r12    41     2
.line	0	move         r13    r1
.line	0	loadk        r14   k36 ; k36 = 202
.line	0	loadk        r15   k81 ; k81 = 195
.line	0	loadk        r16   k82 ; k82 = 112
.line	0	loadk        r17   k83 ; k83 = 82
.line	0	loadk        r18   k84 ; k84 = 114
.line	0	loadk        r19   k85 ; k85 = 87
.line	0	loadk        r20   k86 ; k86 = 205
.line	0	loadk        r21   k87 ; k87 = 152
.line	0	loadk        r22   k88 ; k88 = 46
.line	0	loadk        r23   k25 ; k25 = 90
.line	0	loadk        r24   k89 ; k89 = 45
.line	0	loadk        r25   k38 ; k38 = 240
.line	0	loadk        r26    k5 ; k5 = 154
.line	0	loadk        r27  k108 ; k108 = 246
.line	0	loadk        r28   k25 ; k25 = 90
.line	0	loadk        r29   k91 ; k91 = 162
.line	0	loadk        r30  k109 ; k109 = 10
.line	0	loadk        r31   k12 ; k12 = 178
.line	0	loadk        r32   k41 ; k41 = 57
.line	0	loadk        r33  k110 ; k110 = 83
.line	0	loadk        r34  k111 ; k111 = 153
.line	0	loadk        r35   k93 ; k93 = 74
.line	0	loadk        r36  k112 ; k112 = 160
.line	0	loadk        r37   k70 ; k70 = 181
.line	0	call         r13    25     0
.line	0	setlist      r11     0     1
.line	0	call         r10     2     2
.line	0	call          r9     2     2
.line	0	gettabup     r10    u0   k16 ; k16 = "require"
.line	0	gettabup     r11    u0   k58 ; k58 = "table"
.line	0	gettable     r11   r11   k59 ; k59 = "concat"
.line	0	newtable     r12     1     0
.line	0	move         r13    r1
.line	0	loadk        r14   k17 ; k17 = 218
.line	0	loadk        r15    k8 ; k8 = 129
.line	0	loadk        r16   k28 ; k28 = 77
.line	0	loadk        r17   k29 ; k29 = 100
.line	0	loadk        r18   k30 ; k30 = 104
.line	0	loadk        r19   k31 ; k31 = 76
.line	0	loadk        r20   k14 ; k14 = 145
.line	0	loadk        r21   k32 ; k32 = 142
.line	0	loadk        r22   k33 ; k33 = 18
.line	0	loadk        r23   k34 ; k34 = 78
.line	0	loadk        r24   k35 ; k35 = 43
.line	0	loadk        r25   k60 ; k60 = 187
.line	0	loadk        r26   k37 ; k37 = 188
.line	0	loadk        r27   k61 ; k61 = 244
.line	0	loadk        r28   k62 ; k62 = 79
.line	0	loadk        r29   k63 ; k63 = 248
.line	0	loadk        r30   k64 ; k64 = 7
.line	0	loadk        r31   k65 ; k65 = 184
.line	0	loadk        r32   k26 ; k26 = 35
.line	0	loadk        r33   k66 ; k66 = 98
.line	0	loadk        r34   k18 ; k18 = 130
.line	0	loadk        r35   k43 ; k43 = 103
.line	0	loadk        r36   k44 ; k44 = 189
.line	0	loadk        r37   k67 ; k67 = 168
.line	0	loadk        r38   k68 ; k68 = 56
.line	0	loadk        r39   k69 ; k69 = 25
.line	0	loadk        r40   k66 ; k66 = 98
.line	0	loadk        r41   k70 ; k70 = 181
.line	0	loadk        r42   k71 ; k71 = 247
.line	0	loadk        r43   k72 ; k72 = 217
.line	0	loadk        r44   k73 ; k73 = 89
.line	0	loadk        r45   k74 ; k74 = 161
.line	0	loadk        r46   k75 ; k75 = 60
.line	0	loadk        r47    k0 ; k0 = 190
.line	0	loadk        r48   k47 ; k47 = 106
.line	0	loadk        r49   k76 ; k76 = 117
.line	0	loadk        r50   k77 ; k77 = 148
.line	0	loadk        r51   k78 ; k78 = 121
.line	0	loadk        r52   k79 ; k79 = 182
.line	0	loadk        r53   k80 ; k80 = 169
.line	0	call         r13    41     2
.line	0	move         r14    r1
.line	0	loadk        r15   k36 ; k36 = 202
.line	0	loadk        r16   k81 ; k81 = 195
.line	0	loadk        r17   k10 ; k10 = 119
.line	0	loadk        r18   k76 ; k76 = 117
.line	0	loadk        r19   k21 ; k21 = 105
.line	0	loadk        r20   k93 ; k93 = 74
.line	0	loadk        r21   k17 ; k17 = 218
.line	0	loadk        r22   k94 ; k94 = 211
.line	0	loadk        r23   k95 ; k95 = 42
.line	0	loadk        r24   k30 ; k30 = 104
.line	0	loadk        r25   k96 ; k96 = 62
.line	0	loadk        r26   k97 ; k97 = 250
.line	0	loadk        r27   k60 ; k60 = 187
.line	0	loadk        r28   k98 ; k98 = 252
.line	0	loadk        r29   k99 ; k99 = 120
.line	0	loadk        r30  k100 ; k100 = 183
.line	0	loadk        r31   k88 ; k88 = 46
.line	0	loadk        r32   k65 ; k65 = 184
.line	0	loadk        r33   k55 ; k55 = 6
.line	0	loadk        r34   k42 ; k42 = 84
.line	0	loadk        r35    k4 ; k4 = 133
.line	0	loadk        r36  k113 ; k113 = 124
.line	0	loadk        r37   k44 ; k44 = 189
.line	0	loadk        r38  k106 ; k106 = 164
.line	0	loadk        r39  k114 ; k114 = 13
.line	0	loadk        r40  k107 ; k107 = 95
.line	0	loadk        r41  k115 ; k115 = 0
.line	0	loadk        r42  k116 ; k116 = 234
.line	0	loadk        r43  k100 ; k100 = 183
.line	0	loadk        r44   k49 ; k49 = 236
.line	0	call         r14    31     0
.line	0	setlist      r12     0     1
.line	0	call         r11     2     2
.line	0	call         r10     2     2
.line	0	gettabup     r11    u0   k16 ; k16 = "require"
.line	0	gettabup     r12    u0   k58 ; k58 = "table"
.line	0	gettable     r12   r12   k59 ; k59 = "concat"
.line	0	newtable     r13     1     0
.line	0	move         r14    r1
.line	0	loadk        r15   k17 ; k17 = 218
.line	0	loadk        r16    k8 ; k8 = 129
.line	0	loadk        r17   k28 ; k28 = 77
.line	0	loadk        r18   k29 ; k29 = 100
.line	0	loadk        r19   k30 ; k30 = 104
.line	0	loadk        r20   k31 ; k31 = 76
.line	0	loadk        r21   k14 ; k14 = 145
.line	0	loadk        r22   k32 ; k32 = 142
.line	0	loadk        r23   k33 ; k33 = 18
.line	0	loadk        r24   k34 ; k34 = 78
.line	0	loadk        r25   k35 ; k35 = 43
.line	0	loadk        r26   k60 ; k60 = 187
.line	0	loadk        r27   k37 ; k37 = 188
.line	0	loadk        r28   k61 ; k61 = 244
.line	0	loadk        r29   k62 ; k62 = 79
.line	0	loadk        r30   k63 ; k63 = 248
.line	0	loadk        r31   k64 ; k64 = 7
.line	0	loadk        r32   k65 ; k65 = 184
.line	0	loadk        r33   k26 ; k26 = 35
.line	0	loadk        r34   k66 ; k66 = 98
.line	0	loadk        r35   k18 ; k18 = 130
.line	0	loadk        r36   k43 ; k43 = 103
.line	0	loadk        r37   k44 ; k44 = 189
.line	0	loadk        r38   k67 ; k67 = 168
.line	0	loadk        r39   k68 ; k68 = 56
.line	0	loadk        r40   k69 ; k69 = 25
.line	0	loadk        r41   k66 ; k66 = 98
.line	0	loadk        r42   k70 ; k70 = 181
.line	0	loadk        r43   k71 ; k71 = 247
.line	0	loadk        r44   k72 ; k72 = 217
.line	0	loadk        r45   k73 ; k73 = 89
.line	0	loadk        r46   k74 ; k74 = 161
.line	0	loadk        r47   k75 ; k75 = 60
.line	0	loadk        r48    k0 ; k0 = 190
.line	0	loadk        r49   k47 ; k47 = 106
.line	0	loadk        r50   k76 ; k76 = 117
.line	0	loadk        r51   k77 ; k77 = 148
.line	0	loadk        r52   k78 ; k78 = 121
.line	0	loadk        r53   k79 ; k79 = 182
.line	0	loadk        r54   k80 ; k80 = 169
.line	0	call         r14    41     2
.line	0	move         r15    r1
.line	0	loadk        r16   k36 ; k36 = 202
.line	0	loadk        r17   k81 ; k81 = 195
.line	0	loadk        r18   k10 ; k10 = 119
.line	0	loadk        r19   k76 ; k76 = 117
.line	0	loadk        r20   k21 ; k21 = 105
.line	0	loadk        r21   k93 ; k93 = 74
.line	0	loadk        r22   k17 ; k17 = 218
.line	0	loadk        r23   k94 ; k94 = 211
.line	0	loadk        r24   k95 ; k95 = 42
.line	0	loadk        r25   k30 ; k30 = 104
.line	0	loadk        r26   k96 ; k96 = 62
.line	0	loadk        r27   k97 ; k97 = 250
.line	0	loadk        r28   k60 ; k60 = 187
.line	0	loadk        r29   k98 ; k98 = 252
.line	0	loadk        r30  k117 ; k117 = 123
.line	0	loadk        r31   k54 ; k54 = 163
.line	0	loadk        r32   k35 ; k35 = 43
.line	0	loadk        r33  k118 ; k118 = 158
.line	0	loadk        r34   k40 ; k40 = 59
.line	0	loadk        r35  k119 ; k119 = 93
.line	0	loadk        r36  k105 ; k105 = 131
.line	0	loadk        r37    k3 ; k3 = 101
.line	0	loadk        r38   k74 ; k74 = 161
.line	0	call         r15    24     0
.line	0	setlist      r13     0     1
.line	0	call         r12     2     2
.line	0	call         r11     2     2
.line	0	gettabup     r12    u0   k16 ; k16 = "require"
.line	0	gettabup     r13    u0   k58 ; k58 = "table"
.line	0	gettable     r13   r13   k59 ; k59 = "concat"
.line	0	newtable     r14     1     0
.line	0	move         r15    r1
.line	0	loadk        r16   k17 ; k17 = 218
.line	0	loadk        r17    k8 ; k8 = 129
.line	0	loadk        r18   k28 ; k28 = 77
.line	0	loadk        r19   k29 ; k29 = 100
.line	0	loadk        r20   k30 ; k30 = 104
.line	0	loadk        r21   k31 ; k31 = 76
.line	0	loadk        r22   k14 ; k14 = 145
.line	0	loadk        r23   k32 ; k32 = 142
.line	0	loadk        r24   k33 ; k33 = 18
.line	0	loadk        r25   k34 ; k34 = 78
.line	0	loadk        r26   k35 ; k35 = 43
.line	0	loadk        r27   k60 ; k60 = 187
.line	0	loadk        r28   k37 ; k37 = 188
.line	0	loadk        r29   k61 ; k61 = 244
.line	0	loadk        r30   k62 ; k62 = 79
.line	0	loadk        r31   k63 ; k63 = 248
.line	0	loadk        r32   k64 ; k64 = 7
.line	0	loadk        r33   k65 ; k65 = 184
.line	0	loadk        r34   k26 ; k26 = 35
.line	0	loadk        r35   k66 ; k66 = 98
.line	0	loadk        r36   k18 ; k18 = 130
.line	0	loadk        r37   k43 ; k43 = 103
.line	0	loadk        r38   k44 ; k44 = 189
.line	0	loadk        r39   k67 ; k67 = 168
.line	0	loadk        r40   k68 ; k68 = 56
.line	0	loadk        r41   k69 ; k69 = 25
.line	0	loadk        r42   k66 ; k66 = 98
.line	0	loadk        r43   k70 ; k70 = 181
.line	0	loadk        r44   k71 ; k71 = 247
.line	0	loadk        r45   k36 ; k36 = 202
.line	0	loadk        r46   k85 ; k85 = 87
.line	0	loadk        r47  k120 ; k120 = 171
.line	0	loadk        r48  k121 ; k121 = 41
.line	0	loadk        r49   k91 ; k91 = 162
.line	0	loadk        r50   k95 ; k95 = 42
.line	0	loadk        r51  k122 ; k122 = 68
.line	0	loadk        r52  k123 ; k123 = 136
.line	0	loadk        r53   k20 ; k20 = 108
.line	0	loadk        r54  k124 ; k124 = 172
.line	0	loadk        r55  k125 ; k125 = 243
.line	0	call         r15    41     2
.line	0	move         r16    r1
.line	0	loadk        r17  k116 ; k116 = 234
.line	0	loadk        r18  k111 ; k111 = 153
.line	0	loadk        r19  k126 ; k126 = 75
.line	0	loadk        r20  k127 ; k127 = 115
.line	0	loadk        r21  k128 ; k128 = 99
.line	0	loadk        r22  k129 ; k129 = 107
.line	0	loadk        r23   k36 ; k36 = 202
.line	0	loadk        r24  k130 ; k130 = 141
.line	0	loadk        r25   k15 ; k15 = 14
.line	0	loadk        r26   k85 ; k85 = 87
.line	0	loadk        r27  k131 ; k131 = 51
.line	0	loadk        r28  k132 ; k132 = 209
.line	0	loadk        r29   k45 ; k45 = 166
.line	0	loadk        r30  k133 ; k133 = 238
.line	0	loadk        r31  k134 ; k134 = 70
.line	0	loadk        r32  k135 ; k135 = 186
.line	0	loadk        r33  k136 ; k136 = 38
.line	0	loadk        r34   k37 ; k37 = 188
.line	0	loadk        r35  k137 ; k137 = 48
.line	0	loadk        r36   k84 ; k84 = 114
.line	0	loadk        r37  k111 ; k111 = 153
.line	0	loadk        r38    k3 ; k3 = 101
.line	0	loadk        r39  k138 ; k138 = 191
.line	0	loadk        r40   k91 ; k91 = 162
.line	0	loadk        r41  k115 ; k115 = 0
.line	0	loadk        r42   k34 ; k34 = 78
.line	0	loadk        r43   k48 ; k48 = 52
.line	0	loadk        r44  k139 ; k139 = 241
.line	0	call         r16    29     0
.line	0	setlist      r14     0     1
.line	0	call         r13     2     2
.line	0	call         r12     2     0
.line	0	setlist       r5     0     1
.line	0	gettable      r6    r3  k140 ; k140 = "TraitClass"
.line	0	move          r7    r4
.line	0	loadnil       r8     0
.line	0	move          r9    r2
.line	0	move         r10    r5
.line	0	call          r6     5     2
.line	0	gettabup      r7    u0   k16 ; k16 = "require"
.line	0	move          r8    r1
.line	0	loadk         r9   k17 ; k17 = 218
.line	0	loadk        r10    k8 ; k8 = 129
.line	0	loadk        r11   k28 ; k28 = 77
.line	0	loadk        r12   k29 ; k29 = 100
.line	0	loadk        r13   k30 ; k30 = 104
.line	0	loadk        r14   k31 ; k31 = 76
.line	0	loadk        r15   k14 ; k14 = 145
.line	0	loadk        r16   k14 ; k14 = 145
.line	0	loadk        r17  k141 ; k141 = 17
.line	0	loadk        r18  k142 ; k142 = 92
.line	0	loadk        r19   k26 ; k26 = 35
.line	0	loadk        r20  k108 ; k108 = 246
.line	0	loadk        r21  k143 ; k143 = 231
.line	0	loadk        r22  k116 ; k116 = 234
.line	0	loadk        r23  k142 ; k142 = 92
.line	0	loadk        r24  k144 ; k144 = 185
.line	0	loadk        r25   k40 ; k40 = 59
.line	0	loadk        r26   k65 ; k65 = 184
.line	0	loadk        r27  k145 ; k145 = 122
.line	0	loadk        r28  k146 ; k146 = 91
.line	0	loadk        r29  k105 ; k105 = 131
.line	0	loadk        r30    k3 ; k3 = 101
.line	0	loadk        r31  k138 ; k138 = 191
.line	0	loadk        r32  k147 ; k147 = 146
.line	0	loadk        r33  k148 ; k148 = 27
.line	0	loadk        r34  k107 ; k107 = 95
.line	0	loadk        r35  k131 ; k131 = 51
.line	0	loadk        r36  k149 ; k149 = 233
.line	0	loadk        r37  k150 ; k150 = 170
.line	0	call          r8    30     2
.line	0	call          r7     2     2
.line	0	gettabup      r8    u0   k16 ; k16 = "require"
.line	0	gettabup      r9    u0   k58 ; k58 = "table"
.line	0	gettable      r9    r9   k59 ; k59 = "concat"
.line	0	newtable     r10     1     0
.line	0	move         r11    r1
.line	0	loadk        r12   k17 ; k17 = 218
.line	0	loadk        r13    k8 ; k8 = 129
.line	0	loadk        r14   k28 ; k28 = 77
.line	0	loadk        r15   k29 ; k29 = 100
.line	0	loadk        r16   k30 ; k30 = 104
.line	0	loadk        r17   k31 ; k31 = 76
.line	0	loadk        r18   k14 ; k14 = 145
.line	0	loadk        r19   k32 ; k32 = 142
.line	0	loadk        r20   k33 ; k33 = 18
.line	0	loadk        r21   k34 ; k34 = 78
.line	0	loadk        r22   k35 ; k35 = 43
.line	0	loadk        r23   k60 ; k60 = 187
.line	0	loadk        r24  k151 ; k151 = 165
.line	0	loadk        r25  k108 ; k108 = 246
.line	0	loadk        r26   k62 ; k62 = 79
.line	0	loadk        r27  k138 ; k138 = 191
.line	0	loadk        r28   k95 ; k95 = 42
.line	0	loadk        r29  k125 ; k125 = 243
.line	0	loadk        r30  k152 ; k152 = 39
.line	0	loadk        r31  k103 ; k103 = 69
.line	0	loadk        r32  k111 ; k111 = 153
.line	0	loadk        r33  k145 ; k145 = 122
.line	0	loadk        r34  k150 ; k150 = 170
.line	0	loadk        r35  k153 ; k153 = 227
.line	0	loadk        r36  k148 ; k148 = 27
.line	0	loadk        r37  k107 ; k107 = 95
.line	0	loadk        r38  k131 ; k131 = 51
.line	0	loadk        r39  k149 ; k149 = 233
.line	0	loadk        r40  k150 ; k150 = 170
.line	0	loadk        r41  k154 ; k154 = 167
.line	0	loadk        r42  k126 ; k126 = 75
.line	0	loadk        r43   k12 ; k12 = 178
.line	0	loadk        r44   k53 ; k53 = 54
.line	0	loadk        r45  k138 ; k138 = 191
.line	0	loadk        r46  k155 ; k155 = 33
.line	0	loadk        r47    k6 ; k6 = 126
.line	0	loadk        r48  k104 ; k104 = 147
.line	0	loadk        r49   k20 ; k20 = 108
.line	0	loadk        r50   k79 ; k79 = 182
.line	0	loadk        r51  k156 ; k156 = 177
.line	0	call         r11    41     2
.line	0	move         r12    r1
.line	0	loadk        r13   k36 ; k36 = 202
.line	0	call         r12     2     0
.line	0	setlist      r10     0     1
.line	0	call          r9     2     2
.line	0	call          r8     2     2
.line	0	loadk         r9  k157 ; k157 = 3000225
.line	0	closure      r10    f1
.line	0	settable      r2  k158   r10 ; k158 = "ctor"
.line	0	loadk        r10  k115 ; k115 = 0
.line	0	loadk        r11  k115 ; k115 = 0
.line	0	closure      r12    f2
.line	0	settable      r2  k159   r12 ; k159 = "GetPageConfig"
.line	0	closure      r12    f3
.line	0	settable      r2  k160   r12 ; k160 = "RefreshPageInfo"
.line	0	closure      r12    f4
.line	0	settable      r2  k161   r12 ; k161 = "RegistEvents"
.line	0	closure      r12    f5
.line	0	settable      r2  k162   r12 ; k162 = "OnPostInitialize"
.line	0	closure      r12    f6
.line	0	settable      r2  k163   r12 ; k163 = "OnShow"
.line	0	closure      r12    f7
.line	0	settable      r2  k164   r12 ; k164 = "PreviewTimeTLog"
.line	0	closure      r12    f8
.line	0	settable      r2  k165   r12 ; k165 = "OnClickSendGift"
.line	0	closure      r12    f9
.line	0	settable      r2  k166   r12 ; k166 = "OnClickBuy"
.line	0	closure      r12   f10
.line	0	settable      r2  k167   r12 ; k167 = "OnClickSubscribeBuy"
.line	0	closure      r12   f11
.line	0	settable      r2  k168   r12 ; k168 = "OnClickDisBtn"
.line	0	closure      r12   f12
.line	0	settable      r2  k169   r12 ; k169 = "OnClickJump"
.line	0	closure      r12   f13
.line	0	settable      r2  k170   r12 ; k170 = "UpdateScrollviewSele" (truncated)
.line	0	closure      r12   f14
.line	0	settable      r2  k171   r12 ; k171 = "RefreshPageContent"
.line	0	closure      r12   f15
.line	0	settable      r2  k172   r12 ; k172 = "OnGetDirectPriceInfo"
.line	0	closure      r12   f16
.line	0	settable      r2  k173   r12 ; k173 = "OnGetLocalPriceInfo"
.line	0	closure      r12   f17
.line	0	settable      r2  k174   r12 ; k174 = "RefreshUI"
.line	0	closure      r12   f18
.line	0	settable      r2  k175   r12 ; k175 = "FilterItemByConditio" (truncated)
.line	0	closure      r12   f19
.line	0	settable      r2  k176   r12 ; k176 = "SortPriceByCurrency"
.line	0	closure      r12   f20
.line	0	settable      r2  k177   r12 ; k177 = "OnCollectedResult"
.line	0	closure      r12   f21
.line	0	settable      r2  k178   r12 ; k178 = "OnSubscirbeResult"
.line	0	closure      r12   f22
.line	0	settable      r2  k179   r12 ; k179 = "OnBuyInfoChange"
.line	0	closure      r12   f23
.line	0	settable      r2  k180   r12 ; k180 = "OnBuyResult"
.line	0	closure      r12   f24
.line	0	settable      r2  k181   r12 ; k181 = "OnSubscribeGiftBuyRe" (truncated)
.line	0	closure      r12   f25
.line	0	settable      r2  k182   r12 ; k182 = "OnInventoryChange"
.line	0	closure      r12   f26
.line	0	settable      r2  k183   r12 ; k183 = "RefreshPetItemsHave"
.line	0	closure      r12   f27
.line	0	settable      r2  k184   r12 ; k184 = "OnPriceChanged"
.line	0	closure      r12   f28
.line	0	settable      r2  k185   r12 ; k185 = "UpdateUI"
.line	0	closure      r12   f29
.line	0	settable      r2  k186   r12 ; k186 = "ChooseCrystalForRegi" (truncated)
.line	0	closure      r12   f30
.line	0	settable      r2  k187   r12 ; k187 = "GetClothShowTabIcon"
.line	0	closure      r12   f31
.line	0	settable      r2  k188   r12 ; k188 = "JumpItemByShopID"
.line	0	closure      r12   f32
.line	0	settable      r2  k189   r12 ; k189 = "_ClearJumpInfoDelay"
.line	0	closure      r12   f33
.line	0	settable      r2  k190   r12 ; k190 = "ChooseTheFirstOrSpec" (truncated)
.line	0	closure      r12   f34
.line	0	settable      r2  k191   r12 ; k191 = "ShowDefaultScene"
.line	0	closure      r12   f35
.line	0	settable      r2  k192   r12 ; k192 = "IsFirstItemResReady"
.line	0	closure      r12   f36
.line	0	settable      r2  k193   r12 ; k193 = "GetGiftResIdListForR" (truncated)
.line	0	closure      r12   f37
.line	0	settable      r2  k194   r12 ; k194 = "RequestFirstGiftInfo" (truncated)
.line	0	closure      r12   f38
.line	0	settable      r2  k195   r12 ; k195 = "IfNeedChooseTheFirst" (truncated)
.line	0	closure      r12   f39
.line	0	settable      r2  k196   r12 ; k196 = "GetFrame"
.line	0	closure      r12   f40
.line	0	settable      r2  k197   r12 ; k197 = "OnClose"
.line	0	closure      r12   f41
.line	0	settable      r2  k198   r12 ; k198 = "OnHide"
.line	0	closure      r12   f42
.line	0	settable      r2  k199   r12 ; k199 = "GetIsShowCoupon"
.line	0	closure      r12   f43
.line	0	settable      r2  k200   r12 ; k200 = "RestoreCurUseCharact" (truncated)
.line	0	closure      r12   f44
.line	0	settable      r2  k201   r12 ; k201 = "ResetHide"
.line	0	closure      r12   f45
.line	0	settable      r2  k202   r12 ; k202 = "ResetShow"
.line	0	closure      r12   f46
.line	0	settable      r2  k203   r12 ; k203 = "SetTitleData"
.line	0	closure      r12   f47
.line	0	settable      r2  k204   r12 ; k204 = "UpdateNewCollectBtn"
.line	0	closure      r12   f48
.line	0	settable      r2  k205   r12 ; k205 = "UpdateLimitedSubscri" (truncated)
.line	0	closure      r12   f49
.line	0	settable      r2  k206   r12 ; k206 = "UpdateNewGiftBtn"
.line	0	closure      r12   f50
.line	0	settable      r2  k207   r12 ; k207 = "UpdateNewBuyBtn"
.line	0	closure      r12   f51
.line	0	settable      r2  k208   r12 ; k208 = "OnChestInfoUpdate"
.line	0	closure      r12   f52
.line	0	settable      r2  k209   r12 ; k209 = "RefreshSubDailyGiftI" (truncated)
.line	0	closure      r12   f53
.line	0	settable      r2  k210   r12 ; k210 = "GetSubscribeDailyPac" (truncated)
.line	0	closure      r12   f54
.line	0	settable      r2  k211   r12 ; k211 = "SetSubTabOffsetByJK"
.line	0	closure      r12   f55
.line	0	settable      r2  k212   r12 ; k212 = "OnScreenSizeChanged"
.line	0	closure      r12   f56
.line	0	settable      r2  k213   r12 ; k213 = "SetTaggedPointLightH" (truncated)
.line	0	closure      r12   f57
.line	0	settable      r2  k214   r12 ; k214 = "PutOnOrOffStoreCloth" (truncated)
.line	0	closure      r12   f58
.line	0	settable      r2  k215   r12 ; k215 = "UpdateItemSelectEqui" (truncated)
.line	0	closure      r12   f59
.line	0	settable      r2  k216   r12 ; k216 = "UpdateEquipedStateAn" (truncated)
.line	0	closure      r12   f60
.line	0	settable      r2  k217   r12 ; k217 = "UpdateWearWithAutoDo" (truncated)
.line	0	closure      r12   f61
.line	0	settable      r2  k218   r12 ; k218 = "SetModelRotation"
.line	0	closure      r12   f62
.line	0	settable      r2  k219   r12 ; k219 = "UpdateLeftItemSelect" (truncated)
.line	0	closure      r12   f63
.line	0	settable      r2  k220   r12 ; k220 = "OnClickFullScreen"
.line	0	closure      r12   f64
.line	0	settable      r2  k221   r12 ; k221 = "BanDefaultWearForDai" (truncated)
.line	0	return        r6     2
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	gettabup      r0    u1  k125 ; k125 = 243
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	41
.lastlinedefined	51
.numparams	5
.is_vararg	0
.maxstacksize	39

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	190
.constant	k18	32
.constant	k19	94
.constant	k20	132
.constant	k21	36
.constant	k22	239
.constant	k23	11
.constant	k24	71
.constant	k25	60
.constant	k26	208
.constant	k27	144
.constant	k28	169
.constant	k29	5
.constant	k30	230
.constant	k31	"tostring"
.constant	k32	149
.constant	k33	205
.constant	k34	84
.constant	k35	96
.constant	k36	116
.constant	k37	93
.constant	k38	209
.constant	k39	137
.constant	k40	56
.constant	k41	172
.constant	k42	185
.constant	k43	21
.constant	k44	246
.constant	k45	80
.constant	k46	100
.constant	k47	113
.constant	k48	219
.constant	k49	221
.constant	k50	67
.constant	k51	87
.constant	k52	108
.constant	k53	222
.constant	k54	159
.constant	k55	55
.constant	k56	95
.constant	k57	106
.constant	k58	168
.constant	k59	233
.constant	k60	"parentFrame"
.constant	k61	"tabId"
.constant	k62	"subTabId"
.constant	k63	"pageConfig"
.constant	k64	"UIManager"
.constant	k65	"UI_Config"
.constant	k66	"StoreGeneralPage"
.constant	k67	"currIndex"
.constant	k68	1
.constant	k69	"sortTypeByGlobal"
.constant	k70	"ItemSortType"
.constant	k71	"Default"
.constant	k72	"curTitleTextList"
.constant	k73	nil
.constant	k74	"bIsWear"
.constant	k75	false

.line	41	gettabup      r5    u0    k0 ; k0 = "log"
.line	41	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	41	test          r6     0
.line	41	jmp            0   l97
.line	41	getupval      r6    u1
.line	41	loadk         r7    k2 ; k2 = 234
.line	41	loadk         r8    k3 ; k3 = 153
.line	41	loadk         r9    k4 ; k4 = 75
.line	41	loadk        r10    k5 ; k5 = 115
.line	41	loadk        r11    k6 ; k6 = 99
.line	41	loadk        r12    k7 ; k7 = 127
.line	41	loadk        r13    k8 ; k8 = 218
.line	41	loadk        r14    k9 ; k9 = 147
.line	41	loadk        r15   k10 ; k10 = 27
.line	41	loadk        r16   k11 ; k11 = 73
.line	41	loadk        r17   k12 ; k12 = 43
.line	41	loadk        r18   k13 ; k13 = 249
.line	41	loadk        r19    k3 ; k3 = 153
.line	41	loadk        r20   k14 ; k14 = 248
.line	41	loadk        r21   k15 ; k15 = 79
.line	41	loadk        r22   k16 ; k16 = 179
.line	41	loadk        r23    k5 ; k5 = 115
.line	41	loadk        r24   k17 ; k17 = 190
.line	41	loadk        r25   k18 ; k18 = 32
.line	41	loadk        r26   k19 ; k19 = 94
.line	41	loadk        r27   k20 ; k20 = 132
.line	41	loadk        r28   k21 ; k21 = 36
.line	41	loadk        r29   k22 ; k22 = 239
.line	41	loadk        r30   k17 ; k17 = 190
.line	41	loadk        r31   k23 ; k23 = 11
.line	41	loadk        r32   k24 ; k24 = 71
.line	41	loadk        r33   k25 ; k25 = 60
.line	41	loadk        r34   k26 ; k26 = 208
.line	41	loadk        r35   k27 ; k27 = 144
.line	41	loadk        r36   k28 ; k28 = 169
.line	41	loadk        r37   k29 ; k29 = 5
.line	41	loadk        r38   k30 ; k30 = 230
.line	41	call          r6    33     2
.line	41	gettabup      r7    u0   k31 ; k31 = "tostring"
.line	41	move          r8    r1
.line	41	call          r7     2     2
.line	41	getupval      r8    u1
.line	41	loadk         r9   k32 ; k32 = 149
.line	41	loadk        r10   k33 ; k33 = 205
.line	41	loadk        r11   k34 ; k34 = 84
.line	41	loadk        r12   k35 ; k35 = 96
.line	41	loadk        r13   k36 ; k36 = 116
.line	41	loadk        r14   k37 ; k37 = 93
.line	41	loadk        r15   k38 ; k38 = 209
.line	41	loadk        r16   k39 ; k39 = 137
.line	41	loadk        r17   k40 ; k40 = 56
.line	41	loadk        r18   k11 ; k11 = 73
.line	41	loadk        r19   k12 ; k12 = 43
.line	41	loadk        r20   k14 ; k14 = 248
.line	41	loadk        r21   k41 ; k41 = 172
.line	41	loadk        r22   k42 ; k42 = 185
.line	41	loadk        r23   k43 ; k43 = 21
.line	41	loadk        r24   k44 ; k44 = 246
.line	41	call          r8    17     2
.line	41	gettabup      r9    u0   k31 ; k31 = "tostring"
.line	41	move         r10    r2
.line	41	call          r9     2     2
.line	41	getupval     r10    u1
.line	41	loadk        r11   k32 ; k32 = 149
.line	41	loadk        r12   k33 ; k33 = 205
.line	41	loadk        r13   k45 ; k45 = 80
.line	41	loadk        r14   k35 ; k35 = 96
.line	41	loadk        r15   k46 ; k46 = 100
.line	41	loadk        r16   k47 ; k47 = 113
.line	41	loadk        r17   k48 ; k48 = 219
.line	41	loadk        r18   k49 ; k49 = 221
.line	41	loadk        r19   k50 ; k50 = 67
.line	41	loadk        r20   k10 ; k10 = 27
.line	41	call         r10    11     2
.line	41	gettabup     r11    u0   k31 ; k31 = "tostring"
.line	41	move         r12    r3
.line	41	call         r11     2     2
.line	41	getupval     r12    u1
.line	41	loadk        r13   k32 ; k32 = 149
.line	41	loadk        r14   k33 ; k33 = 205
.line	41	loadk        r15   k51 ; k51 = 87
.line	41	loadk        r16   k36 ; k36 = 116
.line	41	loadk        r17   k46 ; k46 = 100
.line	41	loadk        r18   k52 ; k52 = 108
.line	41	loadk        r19   k53 ; k53 = 222
.line	41	loadk        r20   k54 ; k54 = 159
.line	41	loadk        r21   k55 ; k55 = 55
.line	41	loadk        r22   k56 ; k56 = 95
.line	41	loadk        r23   k57 ; k57 = 106
.line	41	loadk        r24   k58 ; k58 = 168
.line	41	loadk        r25   k59 ; k59 = 233
.line	41	call         r12    14     2
.line	41	gettabup     r13    u0   k31 ; k31 = "tostring"
.line	41	move         r14    r4
.line	41	call         r13     2     2
.line	41	concat        r6    r6   r13
.label	l97
.line	41	call          r5     2     1
.line	41	settable      r0   k60    r2 ; k60 = "parentFrame"
.line	41	settable      r0   k61    r3 ; k61 = "tabId"
.line	41	settable      r0   k62    r4 ; k62 = "subTabId"
.line	41	gettabup      r5    u0   k64 ; k64 = "UIManager"
.line	41	gettable      r5    r5   k65 ; k65 = "UI_Config"
.line	41	gettable      r5    r5   k66 ; k66 = "StoreGeneralPage"
.line	41	settable      r0   k63    r5 ; k63 = "pageConfig"
.line	41	settable      r0   k67   k68 ; k68 = 1
.line	41	gettabup      r5    u2   k70 ; k70 = "ItemSortType"
.line	41	gettable      r5    r5   k71 ; k71 = "Default"
.line	41	settable      r0   k69    r5 ; k69 = "sortTypeByGlobal"
.line	41	settable      r0   k72   k73 ; k73 = nil
.line	41	settable      r0   k74   k75 ; k75 = false
.line	41	return        r0     1
.line	41	move          r0    r0
.line	41	move          r0    r0
.line	41	move          r0    r0
.line	41	return        r0     1

.function	main/f2

.source	null
.linedefined	56
.lastlinedefined	58
.numparams	1
.is_vararg	0
.maxstacksize	2

.constant	k0	"pageConfig"

.line	56	gettable      r1    r0    k0 ; k0 = "pageConfig"
.line	56	return        r1     2
.line	56	return        r0     1
.line	56	move          r0    r0
.line	56	move          r0    r0
.line	56	move          r0    r0
.line	56	return        r0     1

.function	main/f3

.source	null
.linedefined	60
.lastlinedefined	83
.numparams	4
.is_vararg	0
.maxstacksize	34

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	143
.constant	k18	49
.constant	k19	87
.constant	k20	132
.constant	k21	109
.constant	k22	188
.constant	k23	165
.constant	k24	62
.constant	k25	74
.constant	k26	61
.constant	k27	224
.constant	k28	149
.constant	k29	205
.constant	k30	84
.constant	k31	96
.constant	k32	116
.constant	k33	93
.constant	k34	209
.constant	k35	137
.constant	k36	56
.constant	k37	172
.constant	k38	185
.constant	k39	21
.constant	k40	246
.constant	k41	"tostring"
.constant	k42	80
.constant	k43	100
.constant	k44	113
.constant	k45	219
.constant	k46	221
.constant	k47	67
.constant	k48	108
.constant	k49	222
.constant	k50	159
.constant	k51	55
.constant	k52	95
.constant	k53	106
.constant	k54	168
.constant	k55	233
.constant	k56	"SetPageDataReady"
.constant	k57	"tabId"
.constant	k58	"subTabId"
.constant	k59	"ResetPageItemListData"
.constant	k60	"ClearStorePageData"
.constant	k61	"ModuleManager"
.constant	k62	"GetModule"
.constant	k63	"CommonModuleConfig"
.constant	k64	"store_supply_manager"
.constant	k65	"store_collect_data"
.constant	k66	"GetCollectDataByPageId"
.constant	k67	"GetFrame"
.constant	k68	"StoreConst"
.constant	k69	"give_tab"
.constant	k70	"IsCollectTab"
.constant	k71	"RefreshPageContent"
.constant	k72	"Page_New_ID_Car"
.constant	k73	"Page_New_ID_Weapon"
.constant	k74	"genreItemList"
.constant	k75	"GetTabData"
.constant	k76	"store_tab"
.constant	k77	"Page_New_ID_Cloth"
.constant	k78	"subtype_new_cloth_bac"

.line	60	gettabup      r4    u0    k0 ; k0 = "log"
.line	60	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	60	test          r5     0
.line	60	jmp            0   l90
.line	60	getupval      r5    u1
.line	60	loadk         r6    k2 ; k2 = 234
.line	60	loadk         r7    k3 ; k3 = 153
.line	60	loadk         r8    k4 ; k4 = 75
.line	60	loadk         r9    k5 ; k5 = 115
.line	60	loadk        r10    k6 ; k6 = 99
.line	60	loadk        r11    k7 ; k7 = 127
.line	60	loadk        r12    k8 ; k8 = 218
.line	60	loadk        r13    k9 ; k9 = 147
.line	60	loadk        r14   k10 ; k10 = 27
.line	60	loadk        r15   k11 ; k11 = 73
.line	60	loadk        r16   k12 ; k12 = 43
.line	60	loadk        r17   k13 ; k13 = 249
.line	60	loadk        r18    k3 ; k3 = 153
.line	60	loadk        r19   k14 ; k14 = 248
.line	60	loadk        r20   k15 ; k15 = 79
.line	60	loadk        r21   k16 ; k16 = 179
.line	60	loadk        r22    k5 ; k5 = 115
.line	60	loadk        r23   k17 ; k17 = 143
.line	60	loadk        r24   k18 ; k18 = 49
.line	60	loadk        r25   k19 ; k19 = 87
.line	60	loadk        r26   k20 ; k20 = 132
.line	60	loadk        r27   k21 ; k21 = 109
.line	60	loadk        r28   k22 ; k22 = 188
.line	60	loadk        r29   k23 ; k23 = 165
.line	60	loadk        r30   k24 ; k24 = 62
.line	60	loadk        r31   k25 ; k25 = 74
.line	60	loadk        r32   k26 ; k26 = 61
.line	60	loadk        r33   k27 ; k27 = 224
.line	60	call          r5    29     2
.line	60	getupval      r6    u1
.line	60	loadk         r7   k28 ; k28 = 149
.line	60	loadk         r8   k29 ; k29 = 205
.line	60	loadk         r9   k30 ; k30 = 84
.line	60	loadk        r10   k31 ; k31 = 96
.line	60	loadk        r11   k32 ; k32 = 116
.line	60	loadk        r12   k33 ; k33 = 93
.line	60	loadk        r13   k34 ; k34 = 209
.line	60	loadk        r14   k35 ; k35 = 137
.line	60	loadk        r15   k36 ; k36 = 56
.line	60	loadk        r16   k11 ; k11 = 73
.line	60	loadk        r17   k12 ; k12 = 43
.line	60	loadk        r18   k14 ; k14 = 248
.line	60	loadk        r19   k37 ; k37 = 172
.line	60	loadk        r20   k38 ; k38 = 185
.line	60	loadk        r21   k39 ; k39 = 21
.line	60	loadk        r22   k40 ; k40 = 246
.line	60	call          r6    17     2
.line	60	gettabup      r7    u0   k41 ; k41 = "tostring"
.line	60	move          r8    r1
.line	60	call          r7     2     2
.line	60	getupval      r8    u1
.line	60	loadk         r9   k28 ; k28 = 149
.line	60	loadk        r10   k29 ; k29 = 205
.line	60	loadk        r11   k42 ; k42 = 80
.line	60	loadk        r12   k31 ; k31 = 96
.line	60	loadk        r13   k43 ; k43 = 100
.line	60	loadk        r14   k44 ; k44 = 113
.line	60	loadk        r15   k45 ; k45 = 219
.line	60	loadk        r16   k46 ; k46 = 221
.line	60	loadk        r17   k47 ; k47 = 67
.line	60	loadk        r18   k10 ; k10 = 27
.line	60	call          r8    11     2
.line	60	gettabup      r9    u0   k41 ; k41 = "tostring"
.line	60	move         r10    r2
.line	60	call          r9     2     2
.line	60	getupval     r10    u1
.line	60	loadk        r11   k28 ; k28 = 149
.line	60	loadk        r12   k29 ; k29 = 205
.line	60	loadk        r13   k19 ; k19 = 87
.line	60	loadk        r14   k32 ; k32 = 116
.line	60	loadk        r15   k43 ; k43 = 100
.line	60	loadk        r16   k48 ; k48 = 108
.line	60	loadk        r17   k49 ; k49 = 222
.line	60	loadk        r18   k50 ; k50 = 159
.line	60	loadk        r19   k51 ; k51 = 55
.line	60	loadk        r20   k52 ; k52 = 95
.line	60	loadk        r21   k53 ; k53 = 106
.line	60	loadk        r22   k54 ; k54 = 168
.line	60	loadk        r23   k55 ; k55 = 233
.line	60	call         r10    14     2
.line	60	gettabup     r11    u0   k41 ; k41 = "tostring"
.line	60	move         r12    r3
.line	60	call         r11     2     2
.line	60	concat        r5    r5   r11
.label	l90
.line	60	call          r4     2     1
.line	60	self          r4    r0   k56 ; k56 = "SetPageDataReady"
.line	60	loadbool      r6     0     0
.line	60	call          r4     3     1
.line	60	settable      r0   k57    r2 ; k57 = "tabId"
.line	60	settable      r0   k58    r3 ; k58 = "subTabId"
.line	60	self          r4    r0   k59 ; k59 = "ResetPageItemListDat" (truncated)
.line	60	call          r4     2     1
.line	60	self          r4    r0   k60 ; k60 = "ClearStorePageData"
.line	60	call          r4     2     1
.line	60	gettabup      r4    u0   k61 ; k61 = "ModuleManager"
.line	60	gettable      r4    r4   k62 ; k62 = "GetModule"
.line	60	gettabup      r5    u0   k61 ; k61 = "ModuleManager"
.line	60	gettable      r5    r5   k63 ; k63 = "CommonModuleConfig"
.line	60	gettable      r5    r5   k64 ; k64 = "store_supply_manager"
.line	60	call          r4     2     2
.line	60	gettabup      r5    u0   k61 ; k61 = "ModuleManager"
.line	60	gettable      r5    r5   k62 ; k62 = "GetModule"
.line	60	gettabup      r6    u0   k61 ; k61 = "ModuleManager"
.line	60	gettable      r6    r6   k63 ; k63 = "CommonModuleConfig"
.line	60	gettable      r6    r6   k65 ; k65 = "store_collect_data"
.line	60	call          r5     2     2
.line	60	self          r6    r5   k66 ; k66 = "GetCollectDataByPage" (truncated)
.line	60	gettable      r8    r0   k57 ; k57 = "tabId"
.line	60	call          r6     3     1
.line	60	self          r6    r0   k67 ; k67 = "GetFrame"
.line	60	call          r6     2     3
.line	60	gettabup      r8    u0   k68 ; k68 = "StoreConst"
.line	60	gettable      r8    r8   k69 ; k69 = "give_tab"
.line	60	eq             1    r7    r8
.line	60	jmp            0  l122
.line	60	loadbool      r8     0     1
.label	l122
.line	60	loadbool      r8     1     0
.line	60	gettabup      r9    u2   k70 ; k70 = "IsCollectTab"
.line	60	gettable     r10    r0   k57 ; k57 = "tabId"
.line	60	gettable     r11    r0   k58 ; k58 = "subTabId"
.line	60	call          r9     3     2
.line	60	test          r9     0
.line	60	jmp            0  l132
.line	60	self          r9    r0   k71 ; k71 = "RefreshPageContent"
.line	60	call          r9     2     1
.line	60	jmp            0  l179
.label	l132
.line	60	gettable      r9    r0   k57 ; k57 = "tabId"
.line	60	gettabup     r10    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r10   r10   k72 ; k72 = "Page_New_ID_Car"
.line	60	eq             1    r9   r10
.line	60	jmp            0  l142
.line	60	gettable      r9    r0   k57 ; k57 = "tabId"
.line	60	gettabup     r10    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r10   r10   k73 ; k73 = "Page_New_ID_Weapon"
.line	60	eq             0    r9   r10
.line	60	jmp            0  l152
.label	l142
.line	60	newtable      r9     0     0
.line	60	settable      r0   k74    r9 ; k74 = "genreItemList"
.line	60	self          r9    r4   k75 ; k75 = "GetTabData"
.line	60	gettabup     r11    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r11   r11   k76 ; k76 = "store_tab"
.line	60	gettable     r12    r0   k57 ; k57 = "tabId"
.line	60	loadnil      r13     0
.line	60	move         r14    r8
.line	60	call          r9     6     1
.line	60	jmp            0  l179
.label	l152
.line	60	gettable      r9    r0   k57 ; k57 = "tabId"
.line	60	gettabup     r10    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r10   r10   k77 ; k77 = "Page_New_ID_Cloth"
.line	60	eq             0    r9   r10
.line	60	jmp            0  l172
.line	60	gettable      r9    r0   k58 ; k58 = "subTabId"
.line	60	gettabup     r10    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r10   r10   k78 ; k78 = "subtype_new_cloth_ba" (truncated)
.line	60	eq             0    r9   r10
.line	60	jmp            0  l172
.line	60	newtable      r9     0     0
.line	60	settable      r0   k74    r9 ; k74 = "genreItemList"
.line	60	self          r9    r4   k75 ; k75 = "GetTabData"
.line	60	gettabup     r11    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r11   r11   k76 ; k76 = "store_tab"
.line	60	gettable     r12    r0   k57 ; k57 = "tabId"
.line	60	loadnil      r13     0
.line	60	move         r14    r8
.line	60	call          r9     6     1
.line	60	jmp            0  l179
.label	l172
.line	60	self          r9    r4   k75 ; k75 = "GetTabData"
.line	60	gettabup     r11    u0   k68 ; k68 = "StoreConst"
.line	60	gettable     r11   r11   k76 ; k76 = "store_tab"
.line	60	gettable     r12    r0   k57 ; k57 = "tabId"
.line	60	loadnil      r13     0
.line	60	move         r14    r8
.line	60	call          r9     6     1
.label	l179
.line	60	return        r0     1
.line	60	move          r0    r0
.line	60	move          r0    r0
.line	60	return        r0     1

.function	main/f4

.source	null
.linedefined	85
.lastlinedefined	112
.numparams	1
.is_vararg	0
.maxstacksize	32

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	143
.constant	k18	49
.constant	k19	86
.constant	k20	159
.constant	k21	123
.constant	k22	187
.constant	k23	136
.constant	k24	24
.constant	k25	78
.constant	k26	52
.constant	k27	241
.constant	k28	170
.constant	k29	"__super"
.constant	k30	"RegistEvents"
.constant	k31	"AddCommonEvent"
.constant	k32	"EVENTTYPE_RECHARGE"
.constant	k33	"EVENTID_RECHARGE_PURCHASE_GET_INFO"
.constant	k34	"OnGetDirectPriceInfo"
.constant	k35	"EVENTTYPE_CENTAURI_NOTIFY"
.constant	k36	L"EVENTID_CENTAURI_GET_GOODS_PRODUCT_INFO_NOTIFY"
.constant	k37	"OnGetLocalPriceInfo"
.constant	k38	"EVENTTYPE_STORE_DATA"
.constant	k39	"EVENTID_STORE_COLLECT"
.constant	k40	"OnCollectedResult"
.constant	k41	"EVENTID_STORE_SUBSCRIBE"
.constant	k42	"OnSubscirbeResult"
.constant	k43	"EVENTID_STORE_BUY_INFO_CHANGE"
.constant	k44	"OnBuyInfoChange"
.constant	k45	"EVENTID_STORE_BUY"
.constant	k46	"OnBuyResult"
.constant	k47	"EVENTID_STORE_SUBSCRIBE_BUY"
.constant	k48	"OnSubscribeGiftBuyResult"
.constant	k49	"EVENTTYPE_DATA_MGR"
.constant	k50	"EVENTID_DATAMGR_HALL_DEPOT_DATA_CHANGE"
.constant	k51	"OnInventoryChange"
.constant	k52	"EVENTTYPE_ROLEINFO"
.constant	k53	"EVENTID_ROLEINFO_UPDATE_HEAD_INFO"
.constant	k54	"EVENTID_ROLEINFO_UPDATE_AVATAR_PORTRAIT"
.constant	k55	"EVENTTYPE_PET"
.constant	k56	"EVENTID_PET_CHANGE"
.constant	k57	"EVENTTYPE_WARDROBE"
.constant	k58	"EVENTID_WARDROBE_REFRESH_CURRENT_TAB"
.constant	k59	"EVENTID_ITEM_PREVIEW_RESET_OPEN"
.constant	k60	"ResetHide"
.constant	k61	"EVENTID_ITEM_PREVIEW_RESET_CLOSE"
.constant	k62	"ResetShow"
.constant	k63	"EVENTID_STORE_CHEST_IS_PROSSESSED"
.constant	k64	"OnPriceChanged"
.constant	k65	"EVENTID_STORE_SELECT_CRYSTALS"
.constant	k66	"ChooseCrystalForRegional"
.constant	k67	"EVENTID_STORE_CHEST_INFO"
.constant	k68	"OnChestInfoUpdate"
.constant	k69	"EVENTTYPE_SUBSCRIBE"
.constant	k70	"EVENTID_SUBSCRIBE_GET_STATUS_DATA"
.constant	k71	"RefreshSubDailyGiftItem"
.constant	k72	"EVENTTYPE_SETTING"
.constant	k73	"EVENTID_VIEWPORT_SIZE_CHANGED"
.constant	k74	"OnScreenSizeChanged"
.constant	k75	"EVENTID_STORE_REF_ITEM_EQUIPPED"
.constant	k76	"UpdateEquipedStateAndReferesh"
.constant	k77	"EVENTID_STORE_WEAR_AUTO_DOWNLOAD"
.constant	k78	"UpdateWearWithAutoDownload"
.constant	k79	"EVENTTYPE_STORE_BTNEVENT"
.constant	k80	"EVENTID_STORE_ONCLICK_PREVIEW"
.constant	k81	"OnClickFullScreen"
.constant	k82	"EVENTTYPE_DETAIL_COMPONENT"
.constant	k83	"EVENTID_DETAIL_LOAD_COMPLETED"
.constant	k84	"RefreshUI"
.constant	k85	"BindSubColumEvent"

.line	85	gettabup      r1    u0    k0 ; k0 = "log"
.line	85	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	85	test          r2     0
.line	85	jmp            0   l36
.line	85	getupval      r2    u1
.line	85	loadk         r3    k2 ; k2 = 234
.line	85	loadk         r4    k3 ; k3 = 153
.line	85	loadk         r5    k4 ; k4 = 75
.line	85	loadk         r6    k5 ; k5 = 115
.line	85	loadk         r7    k6 ; k6 = 99
.line	85	loadk         r8    k7 ; k7 = 127
.line	85	loadk         r9    k8 ; k8 = 218
.line	85	loadk        r10    k9 ; k9 = 147
.line	85	loadk        r11   k10 ; k10 = 27
.line	85	loadk        r12   k11 ; k11 = 73
.line	85	loadk        r13   k12 ; k12 = 43
.line	85	loadk        r14   k13 ; k13 = 249
.line	85	loadk        r15    k3 ; k3 = 153
.line	85	loadk        r16   k14 ; k14 = 248
.line	85	loadk        r17   k15 ; k15 = 79
.line	85	loadk        r18   k16 ; k16 = 179
.line	85	loadk        r19    k5 ; k5 = 115
.line	85	loadk        r20   k17 ; k17 = 143
.line	85	loadk        r21   k18 ; k18 = 49
.line	85	loadk        r22   k19 ; k19 = 86
.line	85	loadk        r23   k20 ; k20 = 159
.line	85	loadk        r24   k21 ; k21 = 123
.line	85	loadk        r25   k22 ; k22 = 187
.line	85	loadk        r26   k23 ; k23 = 136
.line	85	loadk        r27   k24 ; k24 = 24
.line	85	loadk        r28   k25 ; k25 = 78
.line	85	loadk        r29   k26 ; k26 = 52
.line	85	loadk        r30   k27 ; k27 = 241
.line	85	loadk        r31   k28 ; k28 = 170
.line	85	call          r2    30     2
.label	l36
.line	85	call          r1     2     1
.line	85	gettabup      r1    u2   k29 ; k29 = "__super"
.line	85	gettable      r1    r1   k30 ; k30 = "RegistEvents"
.line	85	move          r2    r0
.line	85	call          r1     2     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k32 ; k32 = "EVENTTYPE_RECHARGE"
.line	85	gettabup      r4    u0   k33 ; k33 = "EVENTID_RECHARGE_PUR" (truncated)
.line	85	gettable      r5    r0   k34 ; k34 = "OnGetDirectPriceInfo"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k35 ; k35 = "EVENTTYPE_CENTAURI_N" (truncated)
.line	85	gettabup      r4    u0   k36 ; k36 = L"EVENTID_CENTAURI_GET" (truncated)
.line	85	gettable      r5    r0   k37 ; k37 = "OnGetLocalPriceInfo"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k39 ; k39 = "EVENTID_STORE_COLLEC" (truncated)
.line	85	gettable      r5    r0   k40 ; k40 = "OnCollectedResult"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k41 ; k41 = "EVENTID_STORE_SUBSCR" (truncated)
.line	85	gettable      r5    r0   k42 ; k42 = "OnSubscirbeResult"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k43 ; k43 = "EVENTID_STORE_BUY_IN" (truncated)
.line	85	gettable      r5    r0   k44 ; k44 = "OnBuyInfoChange"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k45 ; k45 = "EVENTID_STORE_BUY"
.line	85	gettable      r5    r0   k46 ; k46 = "OnBuyResult"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k47 ; k47 = "EVENTID_STORE_SUBSCR" (truncated)
.line	85	gettable      r5    r0   k48 ; k48 = "OnSubscribeGiftBuyRe" (truncated)
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k49 ; k49 = "EVENTTYPE_DATA_MGR"
.line	85	gettabup      r4    u0   k50 ; k50 = "EVENTID_DATAMGR_HALL" (truncated)
.line	85	gettable      r5    r0   k51 ; k51 = "OnInventoryChange"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k52 ; k52 = "EVENTTYPE_ROLEINFO"
.line	85	gettabup      r4    u0   k53 ; k53 = "EVENTID_ROLEINFO_UPD" (truncated)
.line	85	gettable      r5    r0   k51 ; k51 = "OnInventoryChange"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k52 ; k52 = "EVENTTYPE_ROLEINFO"
.line	85	gettabup      r4    u0   k54 ; k54 = "EVENTID_ROLEINFO_UPD" (truncated)
.line	85	gettable      r5    r0   k51 ; k51 = "OnInventoryChange"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k55 ; k55 = "EVENTTYPE_PET"
.line	85	gettabup      r4    u0   k56 ; k56 = "EVENTID_PET_CHANGE"
.line	85	gettable      r5    r0   k51 ; k51 = "OnInventoryChange"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k57 ; k57 = "EVENTTYPE_WARDROBE"
.line	85	gettabup      r4    u0   k58 ; k58 = "EVENTID_WARDROBE_REF" (truncated)
.line	85	gettable      r5    r0   k51 ; k51 = "OnInventoryChange"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k57 ; k57 = "EVENTTYPE_WARDROBE"
.line	85	gettabup      r4    u0   k59 ; k59 = "EVENTID_ITEM_PREVIEW" (truncated)
.line	85	gettable      r5    r0   k60 ; k60 = "ResetHide"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k57 ; k57 = "EVENTTYPE_WARDROBE"
.line	85	gettabup      r4    u0   k61 ; k61 = "EVENTID_ITEM_PREVIEW" (truncated)
.line	85	gettable      r5    r0   k62 ; k62 = "ResetShow"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k63 ; k63 = "EVENTID_STORE_CHEST_" (truncated)
.line	85	gettable      r5    r0   k64 ; k64 = "OnPriceChanged"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k65 ; k65 = "EVENTID_STORE_SELECT" (truncated)
.line	85	gettable      r5    r0   k66 ; k66 = "ChooseCrystalForRegi" (truncated)
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k67 ; k67 = "EVENTID_STORE_CHEST_" (truncated)
.line	85	gettable      r5    r0   k68 ; k68 = "OnChestInfoUpdate"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k69 ; k69 = "EVENTTYPE_SUBSCRIBE"
.line	85	gettabup      r4    u0   k70 ; k70 = "EVENTID_SUBSCRIBE_GE" (truncated)
.line	85	gettable      r5    r0   k71 ; k71 = "RefreshSubDailyGiftI" (truncated)
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k72 ; k72 = "EVENTTYPE_SETTING"
.line	85	gettabup      r4    u0   k73 ; k73 = "EVENTID_VIEWPORT_SIZ" (truncated)
.line	85	gettable      r5    r0   k74 ; k74 = "OnScreenSizeChanged"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k75 ; k75 = "EVENTID_STORE_REF_IT" (truncated)
.line	85	gettable      r5    r0   k76 ; k76 = "UpdateEquipedStateAn" (truncated)
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k38 ; k38 = "EVENTTYPE_STORE_DATA"
.line	85	gettabup      r4    u0   k77 ; k77 = "EVENTID_STORE_WEAR_A" (truncated)
.line	85	gettable      r5    r0   k78 ; k78 = "UpdateWearWithAutoDo" (truncated)
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k79 ; k79 = "EVENTTYPE_STORE_BTNE" (truncated)
.line	85	gettabup      r4    u0   k80 ; k80 = "EVENTID_STORE_ONCLIC" (truncated)
.line	85	gettable      r5    r0   k81 ; k81 = "OnClickFullScreen"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k31 ; k31 = "AddCommonEvent"
.line	85	gettabup      r3    u0   k82 ; k82 = "EVENTTYPE_DETAIL_COM" (truncated)
.line	85	gettabup      r4    u0   k83 ; k83 = "EVENTID_DETAIL_LOAD_" (truncated)
.line	85	gettable      r5    r0   k84 ; k84 = "RefreshUI"
.line	85	move          r6    r0
.line	85	call          r1     6     1
.line	85	self          r1    r0   k85 ; k85 = "BindSubColumEvent"
.line	85	call          r1     2     1
.line	85	return        r0     1
.line	85	move          r0    r0
.line	85	move          r0    r0
.line	85	move          r0    r0
.line	85	move          r0    r0
.line	85	return        r0     1

.function	main/f5

.source	null
.linedefined	114
.lastlinedefined	132
.numparams	1
.is_vararg	0
.maxstacksize	36

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	97
.constant	k20	123
.constant	k21	187
.constant	k22	132
.constant	k23	0
.constant	k24	66
.constant	k25	46
.constant	k26	236
.constant	k27	184
.constant	k28	229
.constant	k29	81
.constant	k30	188
.constant	k31	60
.constant	k32	"__super"
.constant	k33	"OnPostInitialize"
.constant	k34	"InitStorePageData"
.constant	k35	"InitItemList"
.constant	k36	"InitPageState"
.constant	k37	"InitRestrictZoneByTabId"
.constant	k38	"tabId"
.constant	k39	"subTabId"
.constant	k40	"InitSortComboBox"
.constant	k41	"ModuleManager"
.constant	k42	"GetModule"
.constant	k43	"CommonModuleConfig"
.constant	k44	"store_collect_data"
.constant	k45	"GetCollectDataByPageId"
.constant	k46	"GetFrame"
.constant	k47	"StoreConst"
.constant	k48	"give_tab"
.constant	k49	"store_supply_manager"
.constant	k50	"GetTabData"
.constant	k51	"store_tab"
.constant	k52	"UIRoot"
.constant	k53	"CanvasPanel_17"
.constant	k54	"SetWidgetVisibility"
.constant	k55	"UEnums"
.constant	k56	"ESlateVisibility"
.constant	k57	"Collapsed"
.constant	k58	"TextBlock_Empty"
.constant	k59	"SetText"
.constant	k60	"LocUtil"
.constant	k61	"GetLocalizeResStr"
.constant	k62	4491

.line	114	gettabup      r1    u0    k0 ; k0 = "log"
.line	114	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	114	test          r2     0
.line	114	jmp            0   l40
.line	114	getupval      r2    u1
.line	114	loadk         r3    k2 ; k2 = 234
.line	114	loadk         r4    k3 ; k3 = 153
.line	114	loadk         r5    k4 ; k4 = 75
.line	114	loadk         r6    k5 ; k5 = 115
.line	114	loadk         r7    k6 ; k6 = 99
.line	114	loadk         r8    k7 ; k7 = 127
.line	114	loadk         r9    k8 ; k8 = 218
.line	114	loadk        r10    k9 ; k9 = 147
.line	114	loadk        r11   k10 ; k10 = 27
.line	114	loadk        r12   k11 ; k11 = 73
.line	114	loadk        r13   k12 ; k12 = 43
.line	114	loadk        r14   k13 ; k13 = 249
.line	114	loadk        r15    k3 ; k3 = 153
.line	114	loadk        r16   k14 ; k14 = 248
.line	114	loadk        r17   k15 ; k15 = 79
.line	114	loadk        r18   k16 ; k16 = 179
.line	114	loadk        r19    k5 ; k5 = 115
.line	114	loadk        r20   k17 ; k17 = 146
.line	114	loadk        r21   k18 ; k18 = 58
.line	114	loadk        r22   k19 ; k19 = 97
.line	114	loadk        r23    k3 ; k3 = 153
.line	114	loadk        r24   k20 ; k20 = 123
.line	114	loadk        r25   k21 ; k21 = 187
.line	114	loadk        r26   k22 ; k22 = 132
.line	114	loadk        r27   k23 ; k23 = 0
.line	114	loadk        r28   k24 ; k24 = 66
.line	114	loadk        r29   k25 ; k25 = 46
.line	114	loadk        r30   k26 ; k26 = 236
.line	114	loadk        r31   k27 ; k27 = 184
.line	114	loadk        r32   k28 ; k28 = 229
.line	114	loadk        r33   k29 ; k29 = 81
.line	114	loadk        r34   k30 ; k30 = 188
.line	114	loadk        r35   k31 ; k31 = 60
.line	114	call          r2    34     2
.label	l40
.line	114	call          r1     2     1
.line	114	gettabup      r1    u2   k32 ; k32 = "__super"
.line	114	gettable      r1    r1   k33 ; k33 = "OnPostInitialize"
.line	114	move          r2    r0
.line	114	call          r1     2     1
.line	114	self          r1    r0   k34 ; k34 = "InitStorePageData"
.line	114	call          r1     2     1
.line	114	self          r1    r0   k35 ; k35 = "InitItemList"
.line	114	call          r1     2     1
.line	114	self          r1    r0   k36 ; k36 = "InitPageState"
.line	114	call          r1     2     1
.line	114	self          r1    r0   k37 ; k37 = "InitRestrictZoneByTa" (truncated)
.line	114	gettable      r3    r0   k38 ; k38 = "tabId"
.line	114	gettable      r4    r0   k39 ; k39 = "subTabId"
.line	114	call          r1     4     1
.line	114	self          r1    r0   k40 ; k40 = "InitSortComboBox"
.line	114	call          r1     2     1
.line	114	gettabup      r1    u0   k41 ; k41 = "ModuleManager"
.line	114	gettable      r1    r1   k42 ; k42 = "GetModule"
.line	114	gettabup      r2    u0   k41 ; k41 = "ModuleManager"
.line	114	gettable      r2    r2   k43 ; k43 = "CommonModuleConfig"
.line	114	gettable      r2    r2   k44 ; k44 = "store_collect_data"
.line	114	call          r1     2     2
.line	114	self          r2    r1   k45 ; k45 = "GetCollectDataByPage" (truncated)
.line	114	gettable      r4    r0   k38 ; k38 = "tabId"
.line	114	call          r2     3     1
.line	114	self          r2    r0   k46 ; k46 = "GetFrame"
.line	114	call          r2     2     3
.line	114	gettabup      r4    u0   k47 ; k47 = "StoreConst"
.line	114	gettable      r4    r4   k48 ; k48 = "give_tab"
.line	114	eq             1    r3    r4
.line	114	jmp            0   l73
.line	114	loadbool      r4     0     1
.label	l73
.line	114	loadbool      r4     1     0
.line	114	gettabup      r5    u0   k41 ; k41 = "ModuleManager"
.line	114	gettable      r5    r5   k42 ; k42 = "GetModule"
.line	114	gettabup      r6    u0   k41 ; k41 = "ModuleManager"
.line	114	gettable      r6    r6   k43 ; k43 = "CommonModuleConfig"
.line	114	gettable      r6    r6   k49 ; k49 = "store_supply_manager"
.line	114	call          r5     2     2
.line	114	self          r6    r5   k50 ; k50 = "GetTabData"
.line	114	gettabup      r8    u0   k47 ; k47 = "StoreConst"
.line	114	gettable      r8    r8   k51 ; k51 = "store_tab"
.line	114	gettable      r9    r0   k38 ; k38 = "tabId"
.line	114	loadnil      r10     0
.line	114	move         r11    r4
.line	114	call          r6     6     1
.line	114	gettable      r6    r0   k52 ; k52 = "UIRoot"
.line	114	gettable      r6    r6   k53 ; k53 = "CanvasPanel_17"
.line	114	self          r6    r6   k54 ; k54 = "SetWidgetVisibility"
.line	114	gettabup      r8    u0   k55 ; k55 = "UEnums"
.line	114	gettable      r8    r8   k56 ; k56 = "ESlateVisibility"
.line	114	gettable      r8    r8   k57 ; k57 = "Collapsed"
.line	114	call          r6     3     1
.line	114	gettable      r6    r0   k52 ; k52 = "UIRoot"
.line	114	gettable      r6    r6   k58 ; k58 = "TextBlock_Empty"
.line	114	test          r6     0
.line	114	jmp            0  l106
.line	114	gettable      r6    r0   k52 ; k52 = "UIRoot"
.line	114	gettable      r6    r6   k58 ; k58 = "TextBlock_Empty"
.line	114	self          r6    r6   k59 ; k59 = "SetText"
.line	114	gettabup      r8    u0   k60 ; k60 = "LocUtil"
.line	114	gettable      r8    r8   k61 ; k61 = "GetLocalizeResStr"
.line	114	loadk         r9   k62 ; k62 = 4491
.line	114	call          r8     2     0
.line	114	call          r6     0     1
.label	l106
.line	114	return        r0     1
.line	114	move          r0    r0
.line	114	move          r0    r0
.line	114	move          r0    r0
.line	114	move          r0    r0
.line	114	return        r0     1

.function	main/f6

.source	null
.linedefined	134
.lastlinedefined	151
.numparams	1
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"store_supply_switcher"
.constant	k4	"GlobalData"
.constant	k5	"IsJapanOrKorea"
.constant	k6	"StoreFirstShow"
.constant	k7	"SupplyFirstShow"
.constant	k8	"EventSystem"
.constant	k9	"postEvent"
.constant	k10	"EVENTTYPE_SUPPLY"
.constant	k11	"EVENTID_SHOW_SUPPLY"
.constant	k12	"__super"
.constant	k13	"OnShow"
.constant	k14	"PlayUserWidgetAnimation"
.constant	k15	"UIRoot"
.constant	k16	"open_Tab"
.constant	k17	0
.constant	k18	1
.constant	k19	false
.constant	k20	"SetPageShowing"
.constant	k21	"RefreshUI"

.line	134	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	134	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	134	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	134	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	134	gettable      r2    r2    k3 ; k3 = "store_supply_switche" (truncated)
.line	134	call          r1     2     2
.line	134	gettabup      r2    u0    k4 ; k4 = "GlobalData"
.line	134	gettable      r2    r2    k5 ; k5 = "IsJapanOrKorea"
.line	134	call          r2     1     2
.line	134	test          r2     0
.line	134	jmp            0   l37
.line	134	gettable      r2    r1    k6 ; k6 = "StoreFirstShow"
.line	134	test          r2     0
.line	134	jmp            0   l28
.line	134	gettable      r2    r1    k7 ; k7 = "SupplyFirstShow"
.line	134	test          r2     0
.line	134	jmp            0   l28
.line	134	gettabup      r2    u0    k8 ; k8 = "EventSystem"
.line	134	self          r2    r2    k9 ; k9 = "postEvent"
.line	134	gettabup      r4    u0   k10 ; k10 = "EVENTTYPE_SUPPLY"
.line	134	gettabup      r5    u0   k11 ; k11 = "EVENTID_SHOW_SUPPLY"
.line	134	call          r2     4     1
.line	134	gettabup      r2    u1   k12 ; k12 = "__super"
.line	134	gettable      r2    r2   k13 ; k13 = "OnShow"
.line	134	move          r3    r0
.line	134	call          r2     2     1
.line	134	jmp            0   l53
.label	l28
.line	134	self          r2    r0   k14 ; k14 = "PlayUserWidgetAnimat" (truncated)
.line	134	gettable      r4    r0   k15 ; k15 = "UIRoot"
.line	134	gettable      r4    r4   k16 ; k16 = "open_Tab"
.line	134	loadk         r5   k17 ; k17 = 0
.line	134	loadk         r6   k18 ; k18 = 1
.line	134	loadk         r7   k17 ; k17 = 0
.line	134	loadk         r8   k18 ; k18 = 1
.line	134	call          r2     7     1
.line	134	jmp            0   l53
.label	l37
.line	134	gettable      r2    r1    k6 ; k6 = "StoreFirstShow"
.line	134	test          r2     0
.line	134	jmp            0   l45
.line	134	gettabup      r2    u1   k12 ; k12 = "__super"
.line	134	gettable      r2    r2   k13 ; k13 = "OnShow"
.line	134	move          r3    r0
.line	134	call          r2     2     1
.line	134	jmp            0   l53
.label	l45
.line	134	self          r2    r0   k14 ; k14 = "PlayUserWidgetAnimat" (truncated)
.line	134	gettable      r4    r0   k15 ; k15 = "UIRoot"
.line	134	gettable      r4    r4   k16 ; k16 = "open_Tab"
.line	134	loadk         r5   k17 ; k17 = 0
.line	134	loadk         r6   k18 ; k18 = 1
.line	134	loadk         r7   k17 ; k17 = 0
.line	134	loadk         r8   k18 ; k18 = 1
.line	134	call          r2     7     1
.label	l53
.line	134	settable      r1    k6   k19 ; k19 = false
.line	134	self          r2    r0   k20 ; k20 = "SetPageShowing"
.line	134	loadbool      r4     1     0
.line	134	call          r2     3     1
.line	134	self          r2    r0   k21 ; k21 = "RefreshUI"
.line	134	call          r2     2     1
.line	134	return        r0     1
.line	134	move          r0    r0
.line	134	move          r0    r0
.line	134	return        r0     1

.function	main/f7

.source	null
.linedefined	153
.lastlinedefined	181
.numparams	2
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	10	true
.upvalue	"U3"	11	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"string"
.constant	k3	"format"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	234
.constant	k7	153
.constant	k8	75
.constant	k9	115
.constant	k10	99
.constant	k11	127
.constant	k12	218
.constant	k13	147
.constant	k14	27
.constant	k15	73
.constant	k16	43
.constant	k17	249
.constant	k18	248
.constant	k19	79
.constant	k20	179
.constant	k21	141
.constant	k22	38
.constant	k23	84
.constant	k24	128
.constant	k25	97
.constant	k26	170
.constant	k27	186
.constant	k28	58
.constant	k29	66
.constant	k30	55
.constant	k31	224
.constant	k32	197
.constant	k33	87
.constant	k34	161
.constant	k35	117
.constant	k36	237
.constant	k37	45
.constant	k38	85
.constant	k39	131
.constant	k40	150
.constant	k41	185
.constant	k42	200
.constant	k43	"require"
.constant	k44	129
.constant	k45	77
.constant	k46	100
.constant	k47	104
.constant	k48	76
.constant	k49	145
.constant	k50	158
.constant	k51	17
.constant	k52	86
.constant	k53	39
.constant	k54	250
.constant	k55	167
.constant	k56	183
.constant	k57	92
.constant	k58	191
.constant	k59	36
.constant	k60	184
.constant	k61	11
.constant	k62	68
.constant	k63	130
.constant	k64	163
.constant	k65	"LobbySystem"
.constant	k66	"CheckOpen"
.constant	k67	"BP_ENUM_STORE_PREVIEW_TIME"
.constant	k68	0
.constant	k69	"GetMiliseconds"
.constant	k70	3000
.constant	k71	142
.constant	k72	18
.constant	k73	78
.constant	k74	187
.constant	k75	246
.constant	k76	70
.constant	k77	176
.constant	k78	32
.constant	k79	122
.constant	k80	69
.constant	k81	154
.constant	k82	103
.constant	k83	168
.constant	k84	227
.constant	k85	26
.constant	k86	71
.constant	k87	53
.constant	k88	226
.constant	k89	134
.constant	k90	251
.constant	k91	93
.constant	k92	182
.constant	k93	54
.constant	k94	48
.constant	k95	126
.constant	k96	108
.constant	k97	177
.constant	k98	202
.constant	k99	"event_name"
.constant	k100	113
.constant	k101	203
.constant	k102	152
.constant	k103	19
.constant	k104	231
.constant	k105	172
.constant	k106	239
.constant	k107	65
.constant	k108	62
.constant	k109	"preview_time"
.constant	k110	"item_id"
.constant	k111	"tab_id"
.constant	k112	"tabId"
.constant	k113	"sub_tab_Id"
.constant	k114	"subTabId"
.constant	k115	"json"
.constant	k116	"encode"
.constant	k117	"ReportTLogEvent"
.constant	k118	"TLogEventDefine"
.constant	k119	"StoreItem_Preview"
.constant	k120	102
.constant	k121	138
.constant	k122	94
.constant	k123	37
.constant	k124	164
.constant	k125	105
.constant	k126	132
.constant	k127	109
.constant	k128	136
.constant	k129	40
.constant	k130	228
.constant	k131	181
.constant	k132	217
.constant	k133	89
.constant	k134	60
.constant	k135	247
.constant	k136	20
.constant	k137	83
.constant	k138	110
.constant	k139	206
.constant	k140	243
.constant	k141	146
.constant	k142	25
.constant	k143	23
.constant	k144	106
.constant	k145	91
.constant	k146	253
.constant	k147	"tostring"
.constant	k148	159
.constant	k149	96
.constant	k150	209
.constant	k151	174
.constant	k152	10
.constant	k153	175
.constant	k154	233

.line	153	gettabup      r2    u0    k0 ; k0 = "log"
.line	153	gettabup      r3    u0    k1 ; k1 = "bWriteLog"
.line	153	test          r3     0
.line	153	jmp            0   l61
.line	153	gettabup      r3    u0    k2 ; k2 = "string"
.line	153	gettable      r3    r3    k3 ; k3 = "format"
.line	153	gettabup      r4    u0    k4 ; k4 = "table"
.line	153	gettable      r4    r4    k5 ; k5 = "concat"
.line	153	newtable      r5     1     0
.line	153	getupval      r6    u1
.line	153	loadk         r7    k6 ; k6 = 234
.line	153	loadk         r8    k7 ; k7 = 153
.line	153	loadk         r9    k8 ; k8 = 75
.line	153	loadk        r10    k9 ; k9 = 115
.line	153	loadk        r11   k10 ; k10 = 99
.line	153	loadk        r12   k11 ; k11 = 127
.line	153	loadk        r13   k12 ; k12 = 218
.line	153	loadk        r14   k13 ; k13 = 147
.line	153	loadk        r15   k14 ; k14 = 27
.line	153	loadk        r16   k15 ; k15 = 73
.line	153	loadk        r17   k16 ; k16 = 43
.line	153	loadk        r18   k17 ; k17 = 249
.line	153	loadk        r19    k7 ; k7 = 153
.line	153	loadk        r20   k18 ; k18 = 248
.line	153	loadk        r21   k19 ; k19 = 79
.line	153	loadk        r22   k20 ; k20 = 179
.line	153	loadk        r23    k9 ; k9 = 115
.line	153	loadk        r24   k21 ; k21 = 141
.line	153	loadk        r25   k22 ; k22 = 38
.line	153	loadk        r26   k23 ; k23 = 84
.line	153	loadk        r27   k24 ; k24 = 128
.line	153	loadk        r28   k25 ; k25 = 97
.line	153	loadk        r29   k26 ; k26 = 170
.line	153	loadk        r30   k27 ; k27 = 186
.line	153	loadk        r31   k28 ; k28 = 58
.line	153	loadk        r32   k29 ; k29 = 66
.line	153	loadk        r33   k30 ; k30 = 55
.line	153	loadk        r34   k31 ; k31 = 224
.line	153	loadk        r35   k21 ; k21 = 141
.line	153	loadk        r36   k32 ; k32 = 197
.line	153	loadk        r37   k33 ; k33 = 87
.line	153	loadk        r38   k34 ; k34 = 161
.line	153	loadk        r39   k35 ; k35 = 117
.line	153	loadk        r40   k36 ; k36 = 237
.line	153	loadk        r41   k37 ; k37 = 45
.line	153	loadk        r42   k38 ; k38 = 85
.line	153	loadk        r43   k39 ; k39 = 131
.line	153	loadk        r44   k35 ; k35 = 117
.line	153	loadk        r45   k40 ; k40 = 150
.line	153	loadk        r46   k41 ; k41 = 185
.line	153	call          r6    41     2
.line	153	getupval      r7    u1
.line	153	loadk         r8   k39 ; k39 = 131
.line	153	loadk         r9   k42 ; k42 = 200
.line	153	loadk        r10   k33 ; k33 = 87
.line	153	call          r7     4     0
.line	153	setlist       r5     0     1
.line	153	call          r4     2     2
.line	153	move          r5    r1
.line	153	call          r3     3     2
.label	l61
.line	153	call          r2     2     1
.line	153	gettabup      r2    u0   k43 ; k43 = "require"
.line	153	getupval      r3    u1
.line	153	loadk         r4   k12 ; k12 = 218
.line	153	loadk         r5   k44 ; k44 = 129
.line	153	loadk         r6   k45 ; k45 = 77
.line	153	loadk         r7   k46 ; k46 = 100
.line	153	loadk         r8   k47 ; k47 = 104
.line	153	loadk         r9   k48 ; k48 = 76
.line	153	loadk        r10   k49 ; k49 = 145
.line	153	loadk        r11   k50 ; k50 = 158
.line	153	loadk        r12   k51 ; k51 = 17
.line	153	loadk        r13   k52 ; k52 = 86
.line	153	loadk        r14   k53 ; k53 = 39
.line	153	loadk        r15   k54 ; k54 = 250
.line	153	loadk        r16   k55 ; k55 = 167
.line	153	loadk        r17   k56 ; k56 = 183
.line	153	loadk        r18   k57 ; k57 = 92
.line	153	loadk        r19   k58 ; k58 = 191
.line	153	loadk        r20   k59 ; k59 = 36
.line	153	loadk        r21   k60 ; k60 = 184
.line	153	loadk        r22   k61 ; k61 = 11
.line	153	loadk        r23   k62 ; k62 = 68
.line	153	loadk        r24   k63 ; k63 = 130
.line	153	loadk        r25   k25 ; k25 = 97
.line	153	loadk        r26   k64 ; k64 = 163
.line	153	call          r3    24     2
.line	153	call          r2     2     2
.line	153	gettabup      r3    u0   k65 ; k65 = "LobbySystem"
.line	153	gettable      r3    r3   k66 ; k66 = "CheckOpen"
.line	153	gettabup      r4    u0   k67 ; k67 = "BP_ENUM_STORE_PREVIE" (truncated)
.line	153	call          r3     2     2
.line	153	test          r3     0
.line	153	jmp            0  l305
.line	153	getupval      r3    u2
.line	153	eq             1    r3   k68 ; k68 = 0
.line	153	jmp            0  l298
.line	153	getupval      r3    u2
.line	153	eq             1    r3    r1
.line	153	jmp            0  l298
.line	153	gettable      r3    r2   k69 ; k69 = "GetMiliseconds"
.line	153	call          r3     1     2
.line	153	getupval      r4    u3
.line	153	test          r4     0
.line	153	jmp            0  l304
.line	153	getupval      r4    u3
.line	153	sub           r4    r3    r4
.line	153	setupval      r3    u3
.line	153	lt             0   k70    r4 ; k70 = 3000
.line	153	jmp            0  l304
.line	153	gettabup      r5    u0   k43 ; k43 = "require"
.line	153	gettabup      r6    u0    k4 ; k4 = "table"
.line	153	gettable      r6    r6    k5 ; k5 = "concat"
.line	153	newtable      r7     1     0
.line	153	getupval      r8    u1
.line	153	loadk         r9   k12 ; k12 = 218
.line	153	loadk        r10   k44 ; k44 = 129
.line	153	loadk        r11   k45 ; k45 = 77
.line	153	loadk        r12   k46 ; k46 = 100
.line	153	loadk        r13   k47 ; k47 = 104
.line	153	loadk        r14   k48 ; k48 = 76
.line	153	loadk        r15   k49 ; k49 = 145
.line	153	loadk        r16   k71 ; k71 = 142
.line	153	loadk        r17   k72 ; k72 = 18
.line	153	loadk        r18   k73 ; k73 = 78
.line	153	loadk        r19   k16 ; k16 = 43
.line	153	loadk        r20   k74 ; k74 = 187
.line	153	loadk        r21   k26 ; k26 = 170
.line	153	loadk        r22   k75 ; k75 = 246
.line	153	loadk        r23   k76 ; k76 = 70
.line	153	loadk        r24   k77 ; k77 = 176
.line	153	loadk        r25   k78 ; k78 = 32
.line	153	loadk        r26   k27 ; k27 = 186
.line	153	loadk        r27   k79 ; k79 = 122
.line	153	loadk        r28   k80 ; k80 = 69
.line	153	loadk        r29   k81 ; k81 = 154
.line	153	loadk        r30   k82 ; k82 = 103
.line	153	loadk        r31   k83 ; k83 = 168
.line	153	loadk        r32   k84 ; k84 = 227
.line	153	loadk        r33   k85 ; k85 = 26
.line	153	loadk        r34   k86 ; k86 = 71
.line	153	loadk        r35   k87 ; k87 = 53
.line	153	loadk        r36   k88 ; k88 = 226
.line	153	loadk        r37   k89 ; k89 = 134
.line	153	loadk        r38   k90 ; k90 = 251
.line	153	loadk        r39   k91 ; k91 = 93
.line	153	loadk        r40   k92 ; k92 = 182
.line	153	loadk        r41   k93 ; k93 = 54
.line	153	loadk        r42   k58 ; k58 = 191
.line	153	loadk        r43   k94 ; k94 = 48
.line	153	loadk        r44   k95 ; k95 = 126
.line	153	loadk        r45   k13 ; k13 = 147
.line	153	loadk        r46   k96 ; k96 = 108
.line	153	loadk        r47   k92 ; k92 = 182
.line	153	loadk        r48   k97 ; k97 = 177
.line	153	call          r8    41     2
.line	153	getupval      r9    u1
.line	153	loadk        r10   k98 ; k98 = 202
.line	153	call          r9     2     0
.line	153	setlist       r7     0     1
.line	153	call          r6     2     2
.line	153	call          r5     2     2
.line	153	newtable      r6     0     5
.line	153	getupval      r7    u1
.line	153	loadk         r8    k6 ; k6 = 234
.line	153	loadk         r9    k7 ; k7 = 153
.line	153	loadk        r10    k8 ; k8 = 75
.line	153	loadk        r11    k9 ; k9 = 115
.line	153	loadk        r12   k10 ; k10 = 99
.line	153	loadk        r13  k100 ; k100 = 113
.line	153	loadk        r14  k101 ; k101 = 203
.line	153	loadk        r15  k102 ; k102 = 152
.line	153	loadk        r16  k103 ; k103 = 19
.line	153	loadk        r17   k46 ; k46 = 100
.line	153	loadk        r18   k85 ; k85 = 26
.line	153	loadk        r19  k104 ; k104 = 231
.line	153	loadk        r20  k105 ; k105 = 172
.line	153	loadk        r21  k106 ; k106 = 239
.line	153	loadk        r22  k107 ; k107 = 65
.line	153	loadk        r23   k20 ; k20 = 179
.line	153	loadk        r24  k108 ; k108 = 62
.line	153	call          r7    18     2
.line	153	settable      r6   k99    r7 ; k99 = "event_name"
.line	153	settable      r6  k109    r4 ; k109 = "preview_time"
.line	153	getupval      r7    u2
.line	153	settable      r6  k110    r7 ; k110 = "item_id"
.line	153	gettable      r7    r0  k112 ; k112 = "tabId"
.line	153	settable      r6  k111    r7 ; k111 = "tab_id"
.line	153	gettable      r7    r0  k114 ; k114 = "subTabId"
.line	153	settable      r6  k113    r7 ; k113 = "sub_tab_Id"
.line	153	gettabup      r7    u0  k115 ; k115 = "json"
.line	153	gettable      r7    r7  k116 ; k116 = "encode"
.line	153	move          r8    r6
.line	153	call          r7     2     2
.line	153	gettable      r8    r5  k117 ; k117 = "ReportTLogEvent"
.line	153	gettabup      r9    u0  k118 ; k118 = "TLogEventDefine"
.line	153	gettable      r9    r9  k119 ; k119 = "StoreItem_Preview"
.line	153	loadk        r10   k68 ; k68 = 0
.line	153	move         r11    r7
.line	153	call          r8     4     1
.line	153	gettabup      r8    u0    k0 ; k0 = "log"
.line	153	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	153	test          r9     0
.line	153	jmp            0  l296
.line	153	gettabup      r9    u0    k4 ; k4 = "table"
.line	153	gettable      r9    r9    k5 ; k5 = "concat"
.line	153	newtable     r10     1     0
.line	153	getupval     r11    u1
.line	153	loadk        r12   k36 ; k36 = 237
.line	153	loadk        r13   k34 ; k34 = 161
.line	153	loadk        r14    k8 ; k8 = 75
.line	153	loadk        r15  k120 ; k120 = 102
.line	153	loadk        r16   k22 ; k22 = 38
.line	153	loadk        r17   k52 ; k52 = 86
.line	153	loadk        r18   k12 ; k12 = 218
.line	153	loadk        r19  k121 ; k121 = 138
.line	153	loadk        r20  k122 ; k122 = 94
.line	153	loadk        r21   k91 ; k91 = 93
.line	153	loadk        r22  k123 ; k123 = 37
.line	153	loadk        r23  k104 ; k104 = 231
.line	153	loadk        r24  k124 ; k124 = 164
.line	153	loadk        r25   k18 ; k18 = 248
.line	153	loadk        r26   k57 ; k57 = 92
.line	153	loadk        r27   k54 ; k54 = 250
.line	153	loadk        r28  k125 ; k125 = 105
.line	153	loadk        r29   k71 ; k71 = 142
.line	153	loadk        r30   k78 ; k78 = 32
.line	153	loadk        r31  k122 ; k122 = 94
.line	153	loadk        r32  k126 ; k126 = 132
.line	153	loadk        r33  k127 ; k127 = 109
.line	153	loadk        r34  k128 ; k128 = 136
.line	153	loadk        r35   k83 ; k83 = 168
.line	153	loadk        r36   k68 ; k68 = 0
.line	153	loadk        r37   k73 ; k73 = 78
.line	153	loadk        r38  k129 ; k129 = 40
.line	153	loadk        r39  k130 ; k130 = 228
.line	153	loadk        r40  k131 ; k131 = 181
.line	153	loadk        r41  k132 ; k132 = 217
.line	153	loadk        r42  k133 ; k133 = 89
.line	153	loadk        r43   k34 ; k34 = 161
.line	153	loadk        r44  k134 ; k134 = 60
.line	153	loadk        r45  k135 ; k135 = 247
.line	153	loadk        r46  k136 ; k136 = 20
.line	153	loadk        r47  k137 ; k137 = 83
.line	153	loadk        r48   k39 ; k39 = 131
.line	153	loadk        r49  k138 ; k138 = 110
.line	153	loadk        r50   k92 ; k92 = 182
.line	153	loadk        r51   k60 ; k60 = 184
.line	153	call         r11    41     2
.line	153	getupval     r12    u1
.line	153	loadk        r13  k139 ; k139 = 206
.line	153	loadk        r14   k41 ; k41 = 185
.line	153	loadk        r15   k45 ; k45 = 77
.line	153	loadk        r16   k96 ; k96 = 108
.line	153	loadk        r17   k10 ; k10 = 99
.line	153	loadk        r18   k96 ; k96 = 108
.line	153	loadk        r19  k140 ; k140 = 243
.line	153	loadk        r20  k141 ; k141 = 146
.line	153	loadk        r21  k142 ; k142 = 25
.line	153	loadk        r22  k143 ; k143 = 23
.line	153	loadk        r23  k144 ; k144 = 106
.line	153	loadk        r24  k104 ; k104 = 231
.line	153	loadk        r25  k105 ; k105 = 172
.line	153	loadk        r26   k18 ; k18 = 248
.line	153	loadk        r27  k145 ; k145 = 91
.line	153	loadk        r28   k41 ; k41 = 185
.line	153	loadk        r29   k53 ; k53 = 39
.line	153	loadk        r30  k146 ; k146 = 253
.line	153	loadk        r31  k138 ; k138 = 110
.line	153	loadk        r32   k51 ; k51 = 17
.line	153	call         r12    21     0
.line	153	setlist      r10     0     1
.line	153	call          r9     2     2
.line	153	gettabup     r10    u0  k147 ; k147 = "tostring"
.line	153	loadk        r11   k68 ; k68 = 0
.line	153	call         r10     2     2
.line	153	getupval     r11    u1
.line	153	loadk        r12    k7 ; k7 = 153
.line	153	loadk        r13  k148 ; k148 = 159
.line	153	loadk        r14  k107 ; k107 = 65
.line	153	loadk        r15  k149 ; k149 = 96
.line	153	loadk        r16   k35 ; k35 = 117
.line	153	loadk        r17   k33 ; k33 = 87
.line	153	loadk        r18  k150 ; k150 = 209
.line	153	loadk        r19  k151 ; k151 = 174
.line	153	loadk        r20  k152 ; k152 = 10
.line	153	loadk        r21   k15 ; k15 = 73
.line	153	loadk        r22  k144 ; k144 = 106
.line	153	loadk        r23  k153 ; k153 = 175
.line	153	loadk        r24  k154 ; k154 = 233
.line	153	call         r11    14     2
.line	153	gettabup     r12    u0  k147 ; k147 = "tostring"
.line	153	move         r13    r7
.line	153	call         r12     2     2
.line	153	concat        r9    r9   r12
.label	l296
.line	153	call          r8     2     1
.line	153	jmp            0  l304
.label	l298
.line	153	getupval      r3    u3
.line	153	eq             0    r3   k68 ; k68 = 0
.line	153	jmp            0  l304
.line	153	gettable      r3    r2   k69 ; k69 = "GetMiliseconds"
.line	153	call          r3     1     2
.line	153	setupval      r3    u3
.label	l304
.line	153	setupval      r1    u2
.label	l305
.line	153	return        r0     1
.line	153	move          r0    r0
.line	153	move          r0    r0
.line	153	return        r0     1

.function	main/f8

.source	null
.linedefined	183
.lastlinedefined	210
.numparams	1
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click"
.constant	k3	"rawItemInfo"
.constant	k4	"StoreConst"
.constant	k5	"label_item_index_price_list"
.constant	k6	"pairs"
.constant	k7	"label_price_index_price_type"
.constant	k8	true
.constant	k9	"label_price_type_uc"
.constant	k10	"label_price_type_diamond"
.constant	k11	"label_price_type_iap"
.constant	k12	"require"
.constant	k13	"table"
.constant	k14	"concat"
.constant	k15	218
.constant	k16	129
.constant	k17	77
.constant	k18	100
.constant	k19	104
.constant	k20	76
.constant	k21	145
.constant	k22	142
.constant	k23	18
.constant	k24	78
.constant	k25	43
.constant	k26	187
.constant	k27	165
.constant	k28	246
.constant	k29	79
.constant	k30	191
.constant	k31	42
.constant	k32	243
.constant	k33	29
.constant	k34	69
.constant	k35	147
.constant	k36	101
.constant	k37	136
.constant	k38	164
.constant	k39	24
.constant	k40	27
.constant	k41	235
.constant	k42	189
.constant	k43	200
.constant	k44	75
.constant	k45	173
.constant	k46	119
.constant	k47	70
.constant	k48	143
.constant	k49	123
.constant	k50	128
.constant	k51	148
.constant	k52	205
.constant	k53	73
.constant	k54	111
.constant	k55	188
.constant	k56	16
.constant	k57	95
.constant	k58	11
.constant	k59	230
.constant	k60	162
.constant	k61	71
.constant	k62	184
.constant	k63	58
.constant	k64	169
.constant	k65	155
.constant	k66	203
.constant	k67	132
.constant	k68	65
.constant	k69	98
.constant	k70	127
.constant	k71	214
.constant	k72	10
.constant	k73	107
.constant	k74	37
.constant	k75	229
.constant	k76	233
.constant	k77	190
.constant	k78	38
.constant	k79	170
.constant	k80	204
.constant	k81	92
.constant	k82	174
.constant	k83	"StoreDataConvertToGiftData"
.constant	k84	"Enum_GiveGiftType"
.constant	k85	"Store"
.constant	k86	"ShowOnlyGiveFriendGift"
.constant	k87	"nItemId"

.line	183	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	183	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	183	gettable      r3    r3    k2 ; k2 = "click"
.line	183	call          r1     3     1
.line	183	gettable      r1    r0    k3 ; k3 = "rawItemInfo"
.line	183	test          r1     1
.line	183	jmp            0    l9
.line	183	return        r0     1
.label	l9
.line	183	gettable      r1    r0    k3 ; k3 = "rawItemInfo"
.line	183	gettabup      r2    u0    k4 ; k4 = "StoreConst"
.line	183	gettable      r2    r2    k5 ; k5 = "label_item_index_pri" (truncated)
.line	183	gettable      r2    r1    r2
.line	183	newtable      r3     0     0
.line	183	gettabup      r4    u0    k6 ; k6 = "pairs"
.line	183	move          r5    r2
.line	183	call          r4     2     4
.line	183	jmp            0   l22
.line	183	gettabup      r9    u0    k4 ; k4 = "StoreConst"
.line	183	gettable      r9    r9    k7 ; k7 = "label_price_index_pr" (truncated)
.line	183	gettable      r9    r8    r9
.line	183	settable      r3    r9    k8 ; k8 = true
.label	l22
.line	183	move          r0    r0
.line	183	move          r0    r0
.line	183	gettabup      r4    u0    k4 ; k4 = "StoreConst"
.line	183	gettable      r4    r4    k9 ; k9 = "label_price_type_uc"
.line	183	gettabup      r5    u0    k4 ; k4 = "StoreConst"
.line	183	gettable      r5    r5   k10 ; k10 = "label_price_type_dia" (truncated)
.line	183	gettabup      r6    u0    k4 ; k4 = "StoreConst"
.line	183	gettable      r6    r6   k11 ; k11 = "label_price_type_iap"
.line	183	move          r7    r4
.line	183	gettabup      r8    u0    k6 ; k6 = "pairs"
.line	183	move          r9    r3
.line	183	call          r8     2     4
.line	183	jmp            0   l43
.line	183	eq             1   r11    r4
.line	183	jmp            0   l41
.line	183	eq             1   r11    r5
.line	183	jmp            0   l41
.line	183	eq             0   r11    r6
.line	183	jmp            0   l43
.label	l41
.line	183	move          r7   r11
.line	183	jmp            0   l45
.label	l43
.line	183	move          r0    r0
.line	183	move          r0    r0
.label	l45
.line	183	gettabup      r8    u0   k12 ; k12 = "require"
.line	183	gettabup      r9    u0   k13 ; k13 = "table"
.line	183	gettable      r9    r9   k14 ; k14 = "concat"
.line	183	newtable     r10     1     0
.line	183	getupval     r11    u1
.line	183	loadk        r12   k15 ; k15 = 218
.line	183	loadk        r13   k16 ; k16 = 129
.line	183	loadk        r14   k17 ; k17 = 77
.line	183	loadk        r15   k18 ; k18 = 100
.line	183	loadk        r16   k19 ; k19 = 104
.line	183	loadk        r17   k20 ; k20 = 76
.line	183	loadk        r18   k21 ; k21 = 145
.line	183	loadk        r19   k22 ; k22 = 142
.line	183	loadk        r20   k23 ; k23 = 18
.line	183	loadk        r21   k24 ; k24 = 78
.line	183	loadk        r22   k25 ; k25 = 43
.line	183	loadk        r23   k26 ; k26 = 187
.line	183	loadk        r24   k27 ; k27 = 165
.line	183	loadk        r25   k28 ; k28 = 246
.line	183	loadk        r26   k29 ; k29 = 79
.line	183	loadk        r27   k30 ; k30 = 191
.line	183	loadk        r28   k31 ; k31 = 42
.line	183	loadk        r29   k32 ; k32 = 243
.line	183	loadk        r30   k33 ; k33 = 29
.line	183	loadk        r31   k34 ; k34 = 69
.line	183	loadk        r32   k35 ; k35 = 147
.line	183	loadk        r33   k36 ; k36 = 101
.line	183	loadk        r34   k37 ; k37 = 136
.line	183	loadk        r35   k38 ; k38 = 164
.line	183	loadk        r36   k39 ; k39 = 24
.line	183	loadk        r37   k24 ; k24 = 78
.line	183	loadk        r38   k40 ; k40 = 27
.line	183	loadk        r39   k41 ; k41 = 235
.line	183	loadk        r40   k42 ; k42 = 189
.line	183	loadk        r41   k43 ; k43 = 200
.line	183	loadk        r42   k44 ; k44 = 75
.line	183	loadk        r43   k45 ; k45 = 173
.line	183	loadk        r44   k46 ; k46 = 119
.line	183	loadk        r45   k16 ; k16 = 129
.line	183	loadk        r46   k25 ; k25 = 43
.line	183	loadk        r47   k47 ; k47 = 70
.line	183	loadk        r48   k48 ; k48 = 143
.line	183	loadk        r49   k49 ; k49 = 123
.line	183	loadk        r50   k50 ; k50 = 128
.line	183	loadk        r51   k51 ; k51 = 148
.line	183	call         r11    41     2
.line	183	getupval     r12    u1
.line	183	loadk        r13   k52 ; k52 = 205
.line	183	loadk        r14   k37 ; k37 = 136
.line	183	loadk        r15   k53 ; k53 = 73
.line	183	loadk        r16   k47 ; k47 = 70
.line	183	loadk        r17   k54 ; k54 = 111
.line	183	loadk        r18   k24 ; k24 = 78
.line	183	loadk        r19   k15 ; k15 = 218
.line	183	loadk        r20   k55 ; k55 = 188
.line	183	loadk        r21   k56 ; k56 = 16
.line	183	loadk        r22   k57 ; k57 = 95
.line	183	loadk        r23   k58 ; k58 = 11
.line	183	loadk        r24   k59 ; k59 = 230
.line	183	loadk        r25   k60 ; k60 = 162
.line	183	loadk        r26   k15 ; k15 = 218
.line	183	loadk        r27   k61 ; k61 = 71
.line	183	loadk        r28   k62 ; k62 = 184
.line	183	loadk        r29   k63 ; k63 = 58
.line	183	loadk        r30   k64 ; k64 = 169
.line	183	call         r12    19     0
.line	183	setlist      r10     0     1
.line	183	call          r9     2     2
.line	183	call          r8     2     2
.line	183	gettabup      r9    u0   k12 ; k12 = "require"
.line	183	gettabup     r10    u0   k13 ; k13 = "table"
.line	183	gettable     r10   r10   k14 ; k14 = "concat"
.line	183	newtable     r11     1     0
.line	183	getupval     r12    u1
.line	183	loadk        r13   k15 ; k15 = 218
.line	183	loadk        r14   k16 ; k16 = 129
.line	183	loadk        r15   k17 ; k17 = 77
.line	183	loadk        r16   k18 ; k18 = 100
.line	183	loadk        r17   k19 ; k19 = 104
.line	183	loadk        r18   k20 ; k20 = 76
.line	183	loadk        r19   k21 ; k21 = 145
.line	183	loadk        r20   k22 ; k22 = 142
.line	183	loadk        r21   k23 ; k23 = 18
.line	183	loadk        r22   k24 ; k24 = 78
.line	183	loadk        r23   k25 ; k25 = 43
.line	183	loadk        r24   k26 ; k26 = 187
.line	183	loadk        r25   k27 ; k27 = 165
.line	183	loadk        r26   k28 ; k28 = 246
.line	183	loadk        r27   k29 ; k29 = 79
.line	183	loadk        r28   k30 ; k30 = 191
.line	183	loadk        r29   k31 ; k31 = 42
.line	183	loadk        r30   k32 ; k32 = 243
.line	183	loadk        r31   k33 ; k33 = 29
.line	183	loadk        r32   k34 ; k34 = 69
.line	183	loadk        r33   k35 ; k35 = 147
.line	183	loadk        r34   k36 ; k36 = 101
.line	183	loadk        r35   k37 ; k37 = 136
.line	183	loadk        r36   k38 ; k38 = 164
.line	183	loadk        r37   k39 ; k39 = 24
.line	183	loadk        r38   k24 ; k24 = 78
.line	183	loadk        r39   k40 ; k40 = 27
.line	183	loadk        r40   k41 ; k41 = 235
.line	183	loadk        r41   k42 ; k42 = 189
.line	183	loadk        r42   k43 ; k43 = 200
.line	183	loadk        r43   k44 ; k44 = 75
.line	183	loadk        r44   k45 ; k45 = 173
.line	183	loadk        r45   k46 ; k46 = 119
.line	183	loadk        r46   k16 ; k16 = 129
.line	183	loadk        r47   k25 ; k25 = 43
.line	183	loadk        r48   k47 ; k47 = 70
.line	183	loadk        r49   k48 ; k48 = 143
.line	183	loadk        r50   k49 ; k49 = 123
.line	183	loadk        r51   k50 ; k50 = 128
.line	183	loadk        r52   k65 ; k65 = 155
.line	183	call         r12    41     2
.line	183	getupval     r13    u1
.line	183	loadk        r14   k66 ; k66 = 203
.line	183	loadk        r15   k67 ; k67 = 132
.line	183	loadk        r16   k68 ; k68 = 65
.line	183	loadk        r17   k54 ; k54 = 111
.line	183	loadk        r18   k69 ; k69 = 98
.line	183	loadk        r19   k70 ; k70 = 127
.line	183	loadk        r20   k71 ; k71 = 214
.line	183	loadk        r21   k65 ; k65 = 155
.line	183	loadk        r22   k72 ; k72 = 10
.line	183	loadk        r23   k73 ; k73 = 107
.line	183	loadk        r24   k74 ; k74 = 37
.line	183	loadk        r25   k75 ; k75 = 229
.line	183	loadk        r26   k55 ; k55 = 188
.line	183	loadk        r27   k76 ; k76 = 233
.line	183	loadk        r28   k49 ; k49 = 123
.line	183	loadk        r29   k77 ; k77 = 190
.line	183	loadk        r30   k78 ; k78 = 38
.line	183	loadk        r31   k79 ; k79 = 170
.line	183	call         r13    19     0
.line	183	setlist      r11     0     1
.line	183	call         r10     2     2
.line	183	call          r9     2     2
.line	183	gettabup     r10    u0   k12 ; k12 = "require"
.line	183	gettabup     r11    u0   k13 ; k13 = "table"
.line	183	gettable     r11   r11   k14 ; k14 = "concat"
.line	183	newtable     r12     1     0
.line	183	getupval     r13    u1
.line	183	loadk        r14   k15 ; k15 = 218
.line	183	loadk        r15   k16 ; k16 = 129
.line	183	loadk        r16   k17 ; k17 = 77
.line	183	loadk        r17   k18 ; k18 = 100
.line	183	loadk        r18   k19 ; k19 = 104
.line	183	loadk        r19   k20 ; k20 = 76
.line	183	loadk        r20   k21 ; k21 = 145
.line	183	loadk        r21   k22 ; k22 = 142
.line	183	loadk        r22   k23 ; k23 = 18
.line	183	loadk        r23   k24 ; k24 = 78
.line	183	loadk        r24   k25 ; k25 = 43
.line	183	loadk        r25   k26 ; k26 = 187
.line	183	loadk        r26   k27 ; k27 = 165
.line	183	loadk        r27   k28 ; k28 = 246
.line	183	loadk        r28   k29 ; k29 = 79
.line	183	loadk        r29   k30 ; k30 = 191
.line	183	loadk        r30   k31 ; k31 = 42
.line	183	loadk        r31   k32 ; k32 = 243
.line	183	loadk        r32   k33 ; k33 = 29
.line	183	loadk        r33   k34 ; k34 = 69
.line	183	loadk        r34   k35 ; k35 = 147
.line	183	loadk        r35   k36 ; k36 = 101
.line	183	loadk        r36   k37 ; k37 = 136
.line	183	loadk        r37   k38 ; k38 = 164
.line	183	loadk        r38   k39 ; k39 = 24
.line	183	loadk        r39   k24 ; k24 = 78
.line	183	loadk        r40   k40 ; k40 = 27
.line	183	loadk        r41   k41 ; k41 = 235
.line	183	loadk        r42   k42 ; k42 = 189
.line	183	loadk        r43   k43 ; k43 = 200
.line	183	loadk        r44   k44 ; k44 = 75
.line	183	loadk        r45   k45 ; k45 = 173
.line	183	loadk        r46   k46 ; k46 = 119
.line	183	loadk        r47   k16 ; k16 = 129
.line	183	loadk        r48   k25 ; k25 = 43
.line	183	loadk        r49   k47 ; k47 = 70
.line	183	loadk        r50   k48 ; k48 = 143
.line	183	loadk        r51   k49 ; k49 = 123
.line	183	loadk        r52   k50 ; k50 = 128
.line	183	loadk        r53   k51 ; k51 = 148
.line	183	call         r13    41     2
.line	183	getupval     r14    u1
.line	183	loadk        r15   k52 ; k52 = 205
.line	183	loadk        r16   k37 ; k37 = 136
.line	183	loadk        r17   k53 ; k53 = 73
.line	183	loadk        r18   k47 ; k47 = 70
.line	183	loadk        r19   k54 ; k54 = 111
.line	183	loadk        r20   k24 ; k24 = 78
.line	183	loadk        r21   k15 ; k15 = 218
.line	183	loadk        r22   k55 ; k55 = 188
.line	183	loadk        r23   k56 ; k56 = 16
.line	183	loadk        r24   k57 ; k57 = 95
.line	183	loadk        r25   k58 ; k58 = 11
.line	183	loadk        r26   k59 ; k59 = 230
.line	183	loadk        r27   k60 ; k60 = 162
.line	183	loadk        r28   k80 ; k80 = 204
.line	183	loadk        r29   k81 ; k81 = 92
.line	183	loadk        r30   k30 ; k30 = 191
.line	183	loadk        r31   k74 ; k74 = 37
.line	183	loadk        r32   k82 ; k82 = 174
.line	183	call         r14    19     0
.line	183	setlist      r12     0     1
.line	183	call         r11     2     2
.line	183	call         r10     2     2
.line	183	gettable     r11   r10   k83 ; k83 = "StoreDataConvertToGi" (truncated)
.line	183	move         r12    r1
.line	183	loadnil      r13     0
.line	183	move         r14    r7
.line	183	loadbool     r15     1     0
.line	183	call         r11     5     2
.line	183	gettable     r12    r8   k84 ; k84 = "Enum_GiveGiftType"
.line	183	gettable     r12   r12   k85 ; k85 = "Store"
.line	183	gettable     r13    r9   k86 ; k86 = "ShowOnlyGiveFriendGi" (truncated)
.line	183	move         r14   r12
.line	183	gettable     r15   r11   k87 ; k87 = "nItemId"
.line	183	move         r16   r11
.line	183	call         r13     4     1
.line	183	return        r0     1
.line	183	move          r0    r0
.line	183	move          r0    r0
.line	183	move          r0    r0
.line	183	move          r0    r0
.line	183	return        r0     1

.function	main/f9

.source	null
.linedefined	212
.lastlinedefined	272
.numparams	3
.is_vararg	0
.maxstacksize	55

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true
.upvalue	"U3"	7	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	114
.constant	k20	154
.constant	k21	97
.constant	k22	172
.constant	k23	166
.constant	k24	44
.constant	k25	94
.constant	k26	35
.constant	k27	"GetFrame"
.constant	k28	"StoreConst"
.constant	k29	"give_tab"
.constant	k30	"OnClickSendGift"
.constant	k31	false
.constant	k32	"PlayAudio"
.constant	k33	"sound_config"
.constant	k34	"click_v1"
.constant	k35	"rawItemInfo"
.constant	k36	"tabId"
.constant	k37	"Page_New_ID_Other"
.constant	k38	"subTabId"
.constant	k39	"subtype_new_other_pre"
.constant	k40	"ModuleManager"
.constant	k41	"GetModule"
.constant	k42	"LobbyModuleConfig"
.constant	k43	"level_unlock_manager"
.constant	k44	"IsFeatureUnlocked"
.constant	k45	"featureDef"
.constant	k46	"workshopPet"
.constant	k47	"ShowNotice"
.constant	k48	"GetLockTip"
.constant	k49	"rawItemInfo"
.constant	k50	"label_item_index_id"
.constant	k51	"GetJumpToChestItemId"
.constant	k52	"GetCurItemAndIndex"
.constant	k53	"require"
.constant	k54	"table"
.constant	k55	"concat"
.constant	k56	129
.constant	k57	77
.constant	k58	100
.constant	k59	104
.constant	k60	76
.constant	k61	145
.constant	k62	142
.constant	k63	18
.constant	k64	78
.constant	k65	187
.constant	k66	165
.constant	k67	246
.constant	k68	191
.constant	k69	42
.constant	k70	243
.constant	k71	55
.constant	k72	155
.constant	k73	101
.constant	k74	160
.constant	k75	163
.constant	k76	64
.constant	k77	71
.constant	k78	53
.constant	k79	226
.constant	k80	176
.constant	k81	103
.constant	k82	54
.constant	k83	41
.constant	k84	136
.constant	k85	178
.constant	k86	174
.constant	k87	222
.constant	k88	70
.constant	k89	110
.constant	k90	126
.constant	k91	"LocUtil"
.constant	k92	"GetLocalizeResStr"
.constant	k93	101001
.constant	k94	-1
.constant	k95	"CheckCanShowJumpChestByTabId"
.constant	k96	"tabId"
.constant	k97	6899
.constant	k98	6900
.constant	k99	"Show"
.constant	k100	2
.constant	k101	"skipPathCfg"
.constant	k102	"LobbySystem"
.constant	k103	"CheckUrlCanJump"
.constant	k104	"jump"
.constant	k105	"log_tree"
.constant	k106	193
.constant	k107	33
.constant	k108	91
.constant	k109	220
.constant	k110	221
.constant	k111	45
.constant	k112	37
.constant	k113	231
.constant	k114	184
.constant	k115	175
.constant	k116	93
.constant	k117	105
.constant	k118	168
.constant	k119	84
.constant	k120	52
.constant	k121	198
.constant	k122	181
.constant	k123	224
.constant	k124	173
.constant	k125	61
.constant	k126	1
.constant	k127	3
.constant	k128	141
.constant	k129	89
.constant	k130	56
.constant	k131	38
.constant	k132	195
.constant	k133	208
.constant	k134	11
.constant	k135	80
.constant	k136	150
.constant	k137	143
.constant	k138	113
.constant	k139	112
.constant	k140	192
.constant	k141	250
.constant	k142	233
.constant	k143	157
.constant	k144	66705
.constant	k145	23796
.constant	k146	"RefreshSortComboBox"

.line	212	gettabup      r3    u0    k0 ; k0 = "log"
.line	212	gettabup      r4    u0    k1 ; k1 = "bWriteLog"
.line	212	test          r4     0
.line	212	jmp            0   l34
.line	212	getupval      r4    u1
.line	212	loadk         r5    k2 ; k2 = 234
.line	212	loadk         r6    k3 ; k3 = 153
.line	212	loadk         r7    k4 ; k4 = 75
.line	212	loadk         r8    k5 ; k5 = 115
.line	212	loadk         r9    k6 ; k6 = 99
.line	212	loadk        r10    k7 ; k7 = 127
.line	212	loadk        r11    k8 ; k8 = 218
.line	212	loadk        r12    k9 ; k9 = 147
.line	212	loadk        r13   k10 ; k10 = 27
.line	212	loadk        r14   k11 ; k11 = 73
.line	212	loadk        r15   k12 ; k12 = 43
.line	212	loadk        r16   k13 ; k13 = 249
.line	212	loadk        r17    k3 ; k3 = 153
.line	212	loadk        r18   k14 ; k14 = 248
.line	212	loadk        r19   k15 ; k15 = 79
.line	212	loadk        r20   k16 ; k16 = 179
.line	212	loadk        r21    k5 ; k5 = 115
.line	212	loadk        r22   k17 ; k17 = 146
.line	212	loadk        r23   k18 ; k18 = 58
.line	212	loadk        r24   k19 ; k19 = 114
.line	212	loadk        r25   k20 ; k20 = 154
.line	212	loadk        r26   k21 ; k21 = 97
.line	212	loadk        r27   k22 ; k22 = 172
.line	212	loadk        r28   k23 ; k23 = 166
.line	212	loadk        r29   k24 ; k24 = 44
.line	212	loadk        r30   k25 ; k25 = 94
.line	212	loadk        r31   k26 ; k26 = 35
.line	212	call          r4    28     2
.label	l34
.line	212	call          r3     2     1
.line	212	self          r3    r0   k27 ; k27 = "GetFrame"
.line	212	call          r3     2     3
.line	212	gettabup      r5    u0   k28 ; k28 = "StoreConst"
.line	212	gettable      r5    r5   k29 ; k29 = "give_tab"
.line	212	eq             0    r4    r5
.line	212	jmp            0   l44
.line	212	self          r5    r0   k30 ; k30 = "OnClickSendGift"
.line	212	call          r5     2     1
.line	212	return        r0     1
.label	l44
.line	212	eq             1    r1   k31 ; k31 = false
.line	212	jmp            0   l50
.line	212	self          r5    r0   k32 ; k32 = "PlayAudio"
.line	212	gettabup      r7    u0   k33 ; k33 = "sound_config"
.line	212	gettable      r7    r7   k34 ; k34 = "click_v1"
.line	212	call          r5     3     1
.label	l50
.line	212	gettable      r5    r0   k35 ; k35 = "rawItemInfo"
.line	212	test          r5     1
.line	212	jmp            0   l54
.line	212	return        r0     1
.label	l54
.line	212	gettable      r5    r0   k36 ; k36 = "tabId"
.line	212	gettabup      r6    u0   k28 ; k28 = "StoreConst"
.line	212	gettable      r6    r6   k37 ; k37 = "Page_New_ID_Other"
.line	212	eq             0    r5    r6
.line	212	jmp            0   l83
.line	212	gettable      r5    r0   k38 ; k38 = "subTabId"
.line	212	gettabup      r6    u0   k28 ; k28 = "StoreConst"
.line	212	gettable      r6    r6   k39 ; k39 = "subtype_new_other_pr" (truncated)
.line	212	eq             0    r5    r6
.line	212	jmp            0   l83
.line	212	gettabup      r5    u0   k40 ; k40 = "ModuleManager"
.line	212	gettable      r5    r5   k41 ; k41 = "GetModule"
.line	212	gettabup      r6    u0   k40 ; k40 = "ModuleManager"
.line	212	gettable      r6    r6   k42 ; k42 = "LobbyModuleConfig"
.line	212	gettable      r6    r6   k43 ; k43 = "level_unlock_manager"
.line	212	call          r5     2     2
.line	212	self          r6    r5   k44 ; k44 = "IsFeatureUnlocked"
.line	212	gettable      r8    r5   k45 ; k45 = "featureDef"
.line	212	gettable      r8    r8   k46 ; k46 = "workshopPet"
.line	212	call          r6     3     2
.line	212	test          r6     1
.line	212	jmp            0   l83
.line	212	gettabup      r6    u0   k47 ; k47 = "ShowNotice"
.line	212	self          r7    r5   k48 ; k48 = "GetLockTip"
.line	212	gettable      r9    r5   k45 ; k45 = "featureDef"
.line	212	gettable      r9    r9   k46 ; k46 = "workshopPet"
.line	212	call          r7     3     0
.line	212	call          r6     0     1
.line	212	return        r0     1
.label	l83
.line	212	closure       r5    f0
.line	212	gettable      r6    r0   k49 ; k49 = "rawItemInfo"
.line	212	gettabup      r7    u0   k28 ; k28 = "StoreConst"
.line	212	gettable      r7    r7   k50 ; k50 = "label_item_index_id"
.line	212	gettable      r6    r6    r7
.line	212	gettabup      r7    u3   k51 ; k51 = "GetJumpToChestItemId"
.line	212	move          r8    r6
.line	212	call          r7     2     2
.line	212	self          r8    r0   k52 ; k52 = "GetCurItemAndIndex"
.line	212	call          r8     2     2
.line	212	gettabup      r9    u0   k53 ; k53 = "require"
.line	212	gettabup     r10    u0   k54 ; k54 = "table"
.line	212	gettable     r10   r10   k55 ; k55 = "concat"
.line	212	newtable     r11     1     0
.line	212	getupval     r12    u1
.line	212	loadk        r13    k8 ; k8 = 218
.line	212	loadk        r14   k56 ; k56 = 129
.line	212	loadk        r15   k57 ; k57 = 77
.line	212	loadk        r16   k58 ; k58 = 100
.line	212	loadk        r17   k59 ; k59 = 104
.line	212	loadk        r18   k60 ; k60 = 76
.line	212	loadk        r19   k61 ; k61 = 145
.line	212	loadk        r20   k62 ; k62 = 142
.line	212	loadk        r21   k63 ; k63 = 18
.line	212	loadk        r22   k64 ; k64 = 78
.line	212	loadk        r23   k12 ; k12 = 43
.line	212	loadk        r24   k65 ; k65 = 187
.line	212	loadk        r25   k66 ; k66 = 165
.line	212	loadk        r26   k67 ; k67 = 246
.line	212	loadk        r27   k15 ; k15 = 79
.line	212	loadk        r28   k68 ; k68 = 191
.line	212	loadk        r29   k69 ; k69 = 42
.line	212	loadk        r30   k70 ; k70 = 243
.line	212	loadk        r31   k71 ; k71 = 55
.line	212	loadk        r32   k25 ; k25 = 94
.line	212	loadk        r33   k72 ; k72 = 155
.line	212	loadk        r34   k73 ; k73 = 101
.line	212	loadk        r35   k74 ; k74 = 160
.line	212	loadk        r36   k75 ; k75 = 163
.line	212	loadk        r37   k76 ; k76 = 64
.line	212	loadk        r38   k77 ; k77 = 71
.line	212	loadk        r39   k78 ; k78 = 53
.line	212	loadk        r40   k79 ; k79 = 226
.line	212	loadk        r41   k80 ; k80 = 176
.line	212	loadk        r42    k2 ; k2 = 234
.line	212	loadk        r43   k81 ; k81 = 103
.line	212	loadk        r44   k66 ; k66 = 165
.line	212	loadk        r45   k82 ; k82 = 54
.line	212	loadk        r46   k74 ; k74 = 160
.line	212	loadk        r47   k83 ; k83 = 41
.line	212	loadk        r48   k64 ; k64 = 78
.line	212	loadk        r49   k84 ; k84 = 136
.line	212	loadk        r50   k77 ; k77 = 71
.line	212	loadk        r51   k85 ; k85 = 178
.line	212	loadk        r52   k86 ; k86 = 174
.line	212	call         r12    41     2
.line	212	getupval     r13    u1
.line	212	loadk        r14   k87 ; k87 = 222
.line	212	loadk        r15   k85 ; k85 = 178
.line	212	loadk        r16   k88 ; k88 = 70
.line	212	loadk        r17   k89 ; k89 = 110
.line	212	loadk        r18   k90 ; k90 = 126
.line	212	call         r13     6     0
.line	212	setlist      r11     0     1
.line	212	call         r10     2     2
.line	212	call          r9     2     2
.line	212	gettabup     r10    u0   k91 ; k91 = "LocUtil"
.line	212	gettable     r10   r10   k92 ; k92 = "GetLocalizeResStr"
.line	212	loadk        r11   k93 ; k93 = 101001
.line	212	call         r10     2     2
.line	212	eq             1    r7   k94 ; k94 = -1
.line	212	jmp            0  l178
.line	212	gettabup     r11    u2   k95 ; k95 = "CheckCanShowJumpChes" (truncated)
.line	212	gettable     r12    r0   k96 ; k96 = "tabId"
.line	212	call         r11     2     2
.line	212	test         r11     0
.line	212	jmp            0  l178
.line	212	closure      r11    f1
.line	212	gettabup     r12    u0   k91 ; k91 = "LocUtil"
.line	212	gettable     r12   r12   k92 ; k92 = "GetLocalizeResStr"
.line	212	loadk        r13   k97 ; k97 = 6899
.line	212	call         r12     2     2
.line	212	gettabup     r13    u0   k91 ; k91 = "LocUtil"
.line	212	gettable     r13   r13   k92 ; k92 = "GetLocalizeResStr"
.line	212	loadk        r14   k98 ; k98 = 6900
.line	212	call         r13     2     2
.line	212	gettable     r14    r9   k99 ; k99 = "Show"
.line	212	loadk        r15  k100 ; k100 = 2
.line	212	move         r16   r10
.line	212	move         r17   r12
.line	212	move         r18   r11
.line	212	move         r19    r5
.line	212	move         r20   r13
.line	212	call         r14     7     1
.line	212	jmp            0  l281
.label	l178
.line	212	test          r8     0
.line	212	jmp            0  l279
.line	212	gettable     r11    r8  k101 ; k101 = "skipPathCfg"
.line	212	test         r11     0
.line	212	jmp            0  l279
.line	212	gettabup     r11    u0  k102 ; k102 = "LobbySystem"
.line	212	gettable     r11   r11  k103 ; k103 = "CheckUrlCanJump"
.line	212	gettable     r12    r8  k104 ; k104 = "jump"
.line	212	call         r11     2     2
.line	212	test         r11     0
.line	212	jmp            0  l279
.line	212	gettabup     r11    u0  k105 ; k105 = "log_tree"
.line	212	gettabup     r12    u0   k54 ; k54 = "table"
.line	212	gettable     r12   r12   k55 ; k55 = "concat"
.line	212	newtable     r13     1     0
.line	212	getupval     r14    u1
.line	212	loadk        r15  k106 ; k106 = 193
.line	212	loadk        r16   k62 ; k62 = 142
.line	212	loadk        r17   k77 ; k77 = 71
.line	212	loadk        r18  k107 ; k107 = 33
.line	212	loadk        r19   k90 ; k90 = 126
.line	212	loadk        r20  k108 ; k108 = 91
.line	212	loadk        r21  k109 ; k109 = 220
.line	212	loadk        r22  k110 ; k110 = 221
.line	212	loadk        r23  k111 ; k111 = 45
.line	212	loadk        r24   k15 ; k15 = 79
.line	212	loadk        r25  k112 ; k112 = 37
.line	212	loadk        r26  k113 ; k113 = 231
.line	212	loadk        r27   k22 ; k22 = 172
.line	212	loadk        r28   k87 ; k87 = 222
.line	212	loadk        r29   k57 ; k57 = 77
.line	212	loadk        r30  k114 ; k114 = 184
.line	212	loadk        r31   k24 ; k24 = 44
.line	212	loadk        r32  k115 ; k115 = 175
.line	212	loadk        r33   k78 ; k78 = 53
.line	212	loadk        r34  k116 ; k116 = 93
.line	212	loadk        r35   k23 ; k23 = 166
.line	212	loadk        r36  k117 ; k117 = 105
.line	212	loadk        r37  k118 ; k118 = 168
.line	212	loadk        r38  k118 ; k118 = 168
.line	212	loadk        r39  k119 ; k119 = 84
.line	212	loadk        r40   k58 ; k58 = 100
.line	212	loadk        r41  k120 ; k120 = 52
.line	212	loadk        r42  k121 ; k121 = 198
.line	212	loadk        r43  k122 ; k122 = 181
.line	212	loadk        r44  k123 ; k123 = 224
.line	212	loadk        r45  k108 ; k108 = 91
.line	212	loadk        r46  k124 ; k124 = 173
.line	212	loadk        r47   k10 ; k10 = 27
.line	212	loadk        r48  k114 ; k114 = 184
.line	212	loadk        r49  k125 ; k125 = 61
.line	212	loadk        r50  k126 ; k126 = 1
.line	212	loadk        r51  k127 ; k127 = 3
.line	212	loadk        r52  k128 ; k128 = 141
.line	212	loadk        r53  k129 ; k129 = 89
.line	212	loadk        r54  k130 ; k130 = 56
.line	212	call         r14    41     2
.line	212	getupval     r15    u1
.line	212	loadk        r16  k131 ; k131 = 38
.line	212	loadk        r17    k6 ; k6 = 99
.line	212	loadk        r18  k132 ; k132 = 195
.line	212	loadk        r19   k20 ; k20 = 154
.line	212	loadk        r20   k85 ; k85 = 178
.line	212	loadk        r21  k133 ; k133 = 208
.line	212	loadk        r22  k134 ; k134 = 11
.line	212	loadk        r23  k135 ; k135 = 80
.line	212	loadk        r24  k136 ; k136 = 150
.line	212	loadk        r25  k137 ; k137 = 143
.line	212	loadk        r26  k113 ; k113 = 231
.line	212	loadk        r27  k138 ; k138 = 113
.line	212	loadk        r28  k139 ; k139 = 112
.line	212	loadk        r29   k83 ; k83 = 41
.line	212	loadk        r30  k140 ; k140 = 192
.line	212	loadk        r31   k21 ; k21 = 97
.line	212	loadk        r32  k141 ; k141 = 250
.line	212	loadk        r33   k78 ; k78 = 53
.line	212	loadk        r34  k142 ; k142 = 233
.line	212	loadk        r35  k143 ; k143 = 157
.line	212	call         r15    21     0
.line	212	setlist      r13     0     1
.line	212	call         r12     2     2
.line	212	gettable     r13    r8  k104 ; k104 = "jump"
.line	212	call         r11     3     1
.line	212	closure      r11    f2
.line	212	gettabup     r12    u0   k91 ; k91 = "LocUtil"
.line	212	gettable     r12   r12   k92 ; k92 = "GetLocalizeResStr"
.line	212	loadk        r13  k144 ; k144 = 66705
.line	212	call         r12     2     2
.line	212	gettabup     r13    u0   k91 ; k91 = "LocUtil"
.line	212	gettable     r13   r13   k92 ; k92 = "GetLocalizeResStr"
.line	212	loadk        r14  k145 ; k145 = 23796
.line	212	call         r13     2     2
.line	212	gettable     r14    r9   k99 ; k99 = "Show"
.line	212	loadk        r15  k100 ; k100 = 2
.line	212	move         r16   r10
.line	212	move         r17   r12
.line	212	move         r18   r11
.line	212	move         r19    r5
.line	212	move         r20   r13
.line	212	call         r14     7     1
.line	212	jmp            0  l281
.label	l279
.line	212	move         r11    r5
.line	212	call         r11     1     1
.label	l281
.line	212	self         r11    r0  k146 ; k146 = "RefreshSortComboBox"
.line	212	call         r11     2     1
.line	212	return        r0     1
.line	212	move          r0    r0
.line	212	move          r0    r0
.line	212	move          r0    r0
.line	212	move          r0    r0
.line	212	return        r0     1

.function	main/f9/f0

.source	null
.linedefined	232
.lastlinedefined	244
.numparams	0
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	2	false
.upvalue	"U1"	0	true
.upvalue	"U2"	2	true

.constant	k0	"ConvertToShopInfo"
.constant	k1	"rawItemInfo"
.constant	k2	"tabId"
.constant	k3	"subTabId"
.constant	k4	"GetCurItemAndIndex"
.constant	k5	"discountLimit"
.constant	k6	"disCountPrice"
.constant	k7	"discountDisplay"
.constant	k8	"CheckIsChest"
.constant	k9	"item_id"
.constant	k10	"money1_price"
.constant	k11	"finalPrice"
.constant	k12	"PurchaseItem"

.line	232	gettabup      r0    u0    k0 ; k0 = "ConvertToShopInfo"
.line	232	gettabup      r1    u1    k1 ; k1 = "rawItemInfo"
.line	232	gettabup      r2    u1    k2 ; k2 = "tabId"
.line	232	gettabup      r3    u1    k3 ; k3 = "subTabId"
.line	232	call          r0     4     2
.line	232	getupval      r1    u1
.line	232	self          r1    r1    k4 ; k4 = "GetCurItemAndIndex"
.line	232	call          r1     2     2
.line	232	gettable      r2    r1    k5 ; k5 = "discountLimit"
.line	232	settable      r0    k5    r2 ; k5 = "discountLimit"
.line	232	gettable      r2    r1    k6 ; k6 = "disCountPrice"
.line	232	settable      r0    k6    r2 ; k6 = "disCountPrice"
.line	232	gettable      r2    r1    k7 ; k7 = "discountDisplay"
.line	232	settable      r0    k7    r2 ; k7 = "discountDisplay"
.line	232	gettabup      r2    u0    k8 ; k8 = "CheckIsChest"
.line	232	gettable      r3    r0    k9 ; k9 = "item_id"
.line	232	call          r2     2     2
.line	232	test          r2     0
.line	232	jmp            0   l28
.line	232	gettable      r2    r1   k11 ; k11 = "finalPrice"
.line	232	settable      r0   k10    r2 ; k10 = "money1_price"
.line	232	gettabup      r2    u0   k12 ; k12 = "PurchaseItem"
.line	232	move          r3    r0
.line	232	loadnil       r4     0
.line	232	getupval      r5    u2
.line	232	call          r2     4     1
.line	232	jmp            0   l33
.label	l28
.line	232	gettabup      r2    u0   k12 ; k12 = "PurchaseItem"
.line	232	move          r3    r0
.line	232	loadnil       r4     0
.line	232	getupval      r5    u2
.line	232	call          r2     4     1
.label	l33
.line	232	return        r0     1
.line	232	move          r0    r0
.line	232	move          r0    r0
.line	232	move          r0    r0
.line	232	return        r0     1

.function	main/f9/f1

.source	null
.linedefined	251
.lastlinedefined	256
.numparams	0
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	false
.upvalue	"U2"	7	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"CommonModuleConfig"
.constant	k3	"store_supply_manager"
.constant	k4	"GetCurrentFrame"
.constant	k5	"FindJumpInfoFirst"
.constant	k6	"MODEL_ID_STORE"
.constant	k7	"GotoSpecifiedTabAndItem"
.constant	k8	"Tab1"
.constant	k9	"Tab2"
.constant	k10	"itemId"

.line	251	gettabup      r0    u0    k0 ; k0 = "ModuleManager"
.line	251	gettable      r0    r0    k1 ; k1 = "GetModule"
.line	251	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	251	gettable      r1    r1    k2 ; k2 = "CommonModuleConfig"
.line	251	gettable      r1    r1    k3 ; k3 = "store_supply_manager"
.line	251	call          r0     2     2
.line	251	self          r1    r0    k4 ; k4 = "GetCurrentFrame"
.line	251	call          r1     2     2
.line	251	gettabup      r2    u1    k5 ; k5 = "FindJumpInfoFirst"
.line	251	getupval      r3    u2
.line	251	gettabup      r4    u1    k6 ; k6 = "MODEL_ID_STORE"
.line	251	call          r2     3     2
.line	251	self          r3    r1    k7 ; k7 = "GotoSpecifiedTabAndI" (truncated)
.line	251	gettable      r5    r2    k8 ; k8 = "Tab1"
.line	251	gettable      r6    r2    k9 ; k9 = "Tab2"
.line	251	gettable      r7    r2   k10 ; k10 = "itemId"
.line	251	call          r3     5     1
.line	251	return        r0     1
.line	251	move          r0    r0
.line	251	move          r0    r0
.line	251	return        r0     1

.function	main/f9/f2

.source	null
.linedefined	262
.lastlinedefined	264
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"OnClickJump"

.line	262	getupval      r0    u0
.line	262	self          r0    r0    k0 ; k0 = "OnClickJump"
.line	262	call          r0     2     1
.line	262	return        r0     1
.line	262	move          r0    r0
.line	262	return        r0     1

.function	main/f10

.source	null
.linedefined	274
.lastlinedefined	293
.numparams	1
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	218
.constant	k7	129
.constant	k8	77
.constant	k9	100
.constant	k10	104
.constant	k11	76
.constant	k12	145
.constant	k13	142
.constant	k14	18
.constant	k15	78
.constant	k16	43
.constant	k17	187
.constant	k18	165
.constant	k19	246
.constant	k20	79
.constant	k21	191
.constant	k22	42
.constant	k23	243
.constant	k24	39
.constant	k25	68
.constant	k26	148
.constant	k27	123
.constant	k28	172
.constant	k29	7
.constant	k30	73
.constant	k31	63
.constant	k32	171
.constant	k33	181
.constant	k34	230
.constant	k35	95
.constant	k36	175
.constant	k37	58
.constant	k38	146
.constant	k39	55
.constant	k40	84
.constant	k41	132
.constant	k42	107
.constant	k43	188
.constant	k44	208
.constant	k45	143
.constant	k46	65
.constant	k47	94
.constant	k48	110
.constant	k49	89
.constant	k50	209
.constant	k51	153
.constant	k52	56
.constant	k53	"GetSubscribeModuleObj"
.constant	k54	"IsBuyPrime"
.constant	k55	"LocUtil"
.constant	k56	"GetLocalizeResStr"
.constant	k57	301185
.constant	k58	"CDataTable"
.constant	k59	"GetTableData"
.constant	k60	240
.constant	k61	108
.constant	k62	"Get_Discount_ITemID"
.constant	k63	"ItemName"
.constant	k64	"Get_Discount_Item_Info"
.constant	k65	"LocalizeResFormat"
.constant	k66	301374
.constant	k67	"tonumber"
.constant	k68	"sale_price"
.constant	k69	155
.constant	k70	101
.constant	k71	160
.constant	k72	163
.constant	k73	64
.constant	k74	71
.constant	k75	53
.constant	k76	226
.constant	k77	176
.constant	k78	234
.constant	k79	103
.constant	k80	54
.constant	k81	41
.constant	k82	136
.constant	k83	178
.constant	k84	174
.constant	k85	222
.constant	k86	70
.constant	k87	126
.constant	k88	"Show"
.constant	k89	2
.constant	k90	140
.constant	k91	60
.constant	k92	23
.constant	k93	144
.constant	k94	194
.constant	k95	19
.constant	k96	46
.constant	k97	224
.constant	k98	252
.constant	k99	21
.constant	k100	231
.constant	k101	121
.constant	k102	237
.constant	k103	0
.constant	k104	198
.constant	k105	82
.constant	k106	130
.constant	k107	97
.constant	k108	185
.constant	k109	164
.constant	k110	26
.constant	k111	116
.constant	k112	233
.constant	k113	182
.constant	k114	238
.constant	k115	81
.constant	k116	6
.constant	k117	85
.constant	k118	169
.constant	k119	192
.constant	k120	102
.constant	k121	"JumpUrl"

.line	274	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	274	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	274	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	274	call          r1     3     1
.line	274	gettabup      r1    u0    k3 ; k3 = "require"
.line	274	gettabup      r2    u0    k4 ; k4 = "table"
.line	274	gettable      r2    r2    k5 ; k5 = "concat"
.line	274	newtable      r3     1     0
.line	274	getupval      r4    u1
.line	274	loadk         r5    k6 ; k6 = 218
.line	274	loadk         r6    k7 ; k7 = 129
.line	274	loadk         r7    k8 ; k8 = 77
.line	274	loadk         r8    k9 ; k9 = 100
.line	274	loadk         r9   k10 ; k10 = 104
.line	274	loadk        r10   k11 ; k11 = 76
.line	274	loadk        r11   k12 ; k12 = 145
.line	274	loadk        r12   k13 ; k13 = 142
.line	274	loadk        r13   k14 ; k14 = 18
.line	274	loadk        r14   k15 ; k15 = 78
.line	274	loadk        r15   k16 ; k16 = 43
.line	274	loadk        r16   k17 ; k17 = 187
.line	274	loadk        r17   k18 ; k18 = 165
.line	274	loadk        r18   k19 ; k19 = 246
.line	274	loadk        r19   k20 ; k20 = 79
.line	274	loadk        r20   k21 ; k21 = 191
.line	274	loadk        r21   k22 ; k22 = 42
.line	274	loadk        r22   k23 ; k23 = 243
.line	274	loadk        r23   k24 ; k24 = 39
.line	274	loadk        r24   k25 ; k25 = 68
.line	274	loadk        r25   k26 ; k26 = 148
.line	274	loadk        r26   k27 ; k27 = 123
.line	274	loadk        r27   k28 ; k28 = 172
.line	274	loadk        r28   k21 ; k21 = 191
.line	274	loadk        r29   k29 ; k29 = 7
.line	274	loadk        r30   k30 ; k30 = 73
.line	274	loadk        r31   k31 ; k31 = 63
.line	274	loadk        r32   k32 ; k32 = 171
.line	274	loadk        r33   k33 ; k33 = 181
.line	274	loadk        r34   k34 ; k34 = 230
.line	274	loadk        r35   k35 ; k35 = 95
.line	274	loadk        r36   k36 ; k36 = 175
.line	274	loadk        r37   k37 ; k37 = 58
.line	274	loadk        r38   k38 ; k38 = 146
.line	274	loadk        r39   k39 ; k39 = 55
.line	274	loadk        r40   k40 ; k40 = 84
.line	274	loadk        r41   k41 ; k41 = 132
.line	274	loadk        r42   k42 ; k42 = 107
.line	274	loadk        r43   k43 ; k43 = 188
.line	274	loadk        r44   k36 ; k36 = 175
.line	274	call          r4    41     2
.line	274	getupval      r5    u1
.line	274	loadk         r6   k44 ; k44 = 208
.line	274	loadk         r7   k45 ; k45 = 143
.line	274	loadk         r8   k46 ; k46 = 65
.line	274	loadk         r9   k47 ; k47 = 94
.line	274	loadk        r10   k48 ; k48 = 110
.line	274	loadk        r11   k49 ; k49 = 89
.line	274	loadk        r12   k50 ; k50 = 209
.line	274	loadk        r13   k51 ; k51 = 153
.line	274	loadk        r14   k14 ; k14 = 18
.line	274	loadk        r15   k47 ; k47 = 94
.line	274	loadk        r16   k52 ; k52 = 56
.line	274	call          r5    12     0
.line	274	setlist       r3     0     1
.line	274	call          r2     2     2
.line	274	call          r1     2     2
.line	274	gettable      r2    r1   k53 ; k53 = "GetSubscribeModuleOb" (truncated)
.line	274	call          r2     1     2
.line	274	self          r3    r2   k54 ; k54 = "IsBuyPrime"
.line	274	call          r3     2     2
.line	274	test          r3     0
.line	274	jmp            0  l168
.line	274	gettabup      r3    u0   k55 ; k55 = "LocUtil"
.line	274	gettable      r3    r3   k56 ; k56 = "GetLocalizeResStr"
.line	274	loadk         r4   k57 ; k57 = 301185
.line	274	call          r3     2     2
.line	274	gettabup      r4    u0   k58 ; k58 = "CDataTable"
.line	274	gettable      r4    r4   k59 ; k59 = "GetTableData"
.line	274	getupval      r5    u1
.line	274	loadk         r6   k60 ; k60 = 240
.line	274	loadk         r7   k51 ; k51 = 153
.line	274	loadk         r8   k46 ; k46 = 65
.line	274	loadk         r9   k61 ; k61 = 108
.line	274	call          r5     5     2
.line	274	self          r6    r2   k62 ; k62 = "Get_Discount_ITemID"
.line	274	call          r6     2     0
.line	274	call          r4     0     2
.line	274	test          r4     0
.line	274	jmp            0   l93
.line	274	gettable      r5    r4   k63 ; k63 = "ItemName"
.line	274	test          r5     1
.line	274	jmp            0   l95
.label	l93
.line	274	getupval      r5    u1
.line	274	call          r5     1     2
.label	l95
.line	274	self          r6    r2   k64 ; k64 = "Get_Discount_Item_In" (truncated)
.line	274	call          r6     2     2
.line	274	gettabup      r7    u0   k55 ; k55 = "LocUtil"
.line	274	gettable      r7    r7   k65 ; k65 = "LocalizeResFormat"
.line	274	loadk         r8   k66 ; k66 = 301374
.line	274	gettabup      r9    u0   k67 ; k67 = "tonumber"
.line	274	gettable     r10    r6   k68 ; k68 = "sale_price"
.line	274	call          r9     2     2
.line	274	move         r10    r5
.line	274	call          r7     4     2
.line	274	gettabup      r8    u0    k3 ; k3 = "require"
.line	274	gettabup      r9    u0    k4 ; k4 = "table"
.line	274	gettable      r9    r9    k5 ; k5 = "concat"
.line	274	newtable     r10     1     0
.line	274	getupval     r11    u1
.line	274	loadk        r12    k6 ; k6 = 218
.line	274	loadk        r13    k7 ; k7 = 129
.line	274	loadk        r14    k8 ; k8 = 77
.line	274	loadk        r15    k9 ; k9 = 100
.line	274	loadk        r16   k10 ; k10 = 104
.line	274	loadk        r17   k11 ; k11 = 76
.line	274	loadk        r18   k12 ; k12 = 145
.line	274	loadk        r19   k13 ; k13 = 142
.line	274	loadk        r20   k14 ; k14 = 18
.line	274	loadk        r21   k15 ; k15 = 78
.line	274	loadk        r22   k16 ; k16 = 43
.line	274	loadk        r23   k17 ; k17 = 187
.line	274	loadk        r24   k18 ; k18 = 165
.line	274	loadk        r25   k19 ; k19 = 246
.line	274	loadk        r26   k20 ; k20 = 79
.line	274	loadk        r27   k21 ; k21 = 191
.line	274	loadk        r28   k22 ; k22 = 42
.line	274	loadk        r29   k23 ; k23 = 243
.line	274	loadk        r30   k39 ; k39 = 55
.line	274	loadk        r31   k47 ; k47 = 94
.line	274	loadk        r32   k69 ; k69 = 155
.line	274	loadk        r33   k70 ; k70 = 101
.line	274	loadk        r34   k71 ; k71 = 160
.line	274	loadk        r35   k72 ; k72 = 163
.line	274	loadk        r36   k73 ; k73 = 64
.line	274	loadk        r37   k74 ; k74 = 71
.line	274	loadk        r38   k75 ; k75 = 53
.line	274	loadk        r39   k76 ; k76 = 226
.line	274	loadk        r40   k77 ; k77 = 176
.line	274	loadk        r41   k78 ; k78 = 234
.line	274	loadk        r42   k79 ; k79 = 103
.line	274	loadk        r43   k18 ; k18 = 165
.line	274	loadk        r44   k80 ; k80 = 54
.line	274	loadk        r45   k71 ; k71 = 160
.line	274	loadk        r46   k81 ; k81 = 41
.line	274	loadk        r47   k15 ; k15 = 78
.line	274	loadk        r48   k82 ; k82 = 136
.line	274	loadk        r49   k74 ; k74 = 71
.line	274	loadk        r50   k83 ; k83 = 178
.line	274	loadk        r51   k84 ; k84 = 174
.line	274	call         r11    41     2
.line	274	getupval     r12    u1
.line	274	loadk        r13   k85 ; k85 = 222
.line	274	loadk        r14   k83 ; k83 = 178
.line	274	loadk        r15   k86 ; k86 = 70
.line	274	loadk        r16   k48 ; k48 = 110
.line	274	loadk        r17   k87 ; k87 = 126
.line	274	call         r12     6     0
.line	274	setlist      r10     0     1
.line	274	call          r9     2     2
.line	274	call          r8     2     2
.line	274	gettable      r9    r8   k88 ; k88 = "Show"
.line	274	loadk        r10   k89 ; k89 = 2
.line	274	move         r11    r3
.line	274	move         r12    r7
.line	274	closure      r13    f0
.line	274	call          r9     5     1
.line	274	jmp            0  l251
.label	l168
.line	274	getupval      r3    u1
.line	274	loadk         r4   k85 ; k85 = 222
.line	274	loadk         r5   k90 ; k90 = 140
.line	274	loadk         r6   k30 ; k30 = 73
.line	274	loadk         r7    k9 ; k9 = 100
.line	274	loadk         r8   k91 ; k91 = 60
.line	274	loadk         r9   k92 ; k92 = 23
.line	274	loadk        r10   k93 ; k93 = 144
.line	274	loadk        r11   k94 ; k94 = 194
.line	274	loadk        r12   k95 ; k95 = 19
.line	274	loadk        r13   k40 ; k40 = 84
.line	274	loadk        r14   k96 ; k96 = 46
.line	274	loadk        r15   k97 ; k97 = 224
.line	274	loadk        r16   k18 ; k18 = 165
.line	274	loadk        r17   k98 ; k98 = 252
.line	274	loadk        r18   k99 ; k99 = 21
.line	274	loadk        r19  k100 ; k100 = 231
.line	274	loadk        r20  k101 ; k101 = 121
.line	274	loadk        r21  k102 ; k102 = 237
.line	274	loadk        r22   k61 ; k61 = 108
.line	274	loadk        r23  k103 ; k103 = 0
.line	274	loadk        r24  k104 ; k104 = 198
.line	274	loadk        r25   k52 ; k52 = 56
.line	274	call          r3    23     2
.line	274	gettabup      r4    u0    k3 ; k3 = "require"
.line	274	gettabup      r5    u0    k4 ; k4 = "table"
.line	274	gettable      r5    r5    k5 ; k5 = "concat"
.line	274	newtable      r6     1     0
.line	274	getupval      r7    u1
.line	274	loadk         r8    k6 ; k6 = 218
.line	274	loadk         r9    k7 ; k7 = 129
.line	274	loadk        r10    k8 ; k8 = 77
.line	274	loadk        r11    k9 ; k9 = 100
.line	274	loadk        r12   k10 ; k10 = 104
.line	274	loadk        r13   k11 ; k11 = 76
.line	274	loadk        r14   k12 ; k12 = 145
.line	274	loadk        r15   k13 ; k13 = 142
.line	274	loadk        r16   k14 ; k14 = 18
.line	274	loadk        r17   k15 ; k15 = 78
.line	274	loadk        r18   k16 ; k16 = 43
.line	274	loadk        r19   k17 ; k17 = 187
.line	274	loadk        r20   k18 ; k18 = 165
.line	274	loadk        r21   k19 ; k19 = 246
.line	274	loadk        r22   k20 ; k20 = 79
.line	274	loadk        r23   k21 ; k21 = 191
.line	274	loadk        r24   k22 ; k22 = 42
.line	274	loadk        r25   k23 ; k23 = 243
.line	274	loadk        r26   k75 ; k75 = 53
.line	274	loadk        r27  k105 ; k105 = 82
.line	274	loadk        r28  k106 ; k106 = 130
.line	274	loadk        r29  k107 ; k107 = 97
.line	274	loadk        r30  k108 ; k108 = 185
.line	274	loadk        r31  k109 ; k109 = 164
.line	274	loadk        r32  k110 ; k110 = 26
.line	274	loadk        r33  k105 ; k105 = 82
.line	274	loadk        r34  k111 ; k111 = 116
.line	274	loadk        r35  k112 ; k112 = 233
.line	274	loadk        r36  k113 ; k113 = 182
.line	274	loadk        r37  k114 ; k114 = 238
.line	274	loadk        r38  k115 ; k115 = 81
.line	274	loadk        r39   k18 ; k18 = 165
.line	274	loadk        r40  k116 ; k116 = 6
.line	274	loadk        r41   k28 ; k28 = 172
.line	274	loadk        r42   k24 ; k24 = 39
.line	274	loadk        r43  k117 ; k117 = 85
.line	274	loadk        r44   k45 ; k45 = 143
.line	274	loadk        r45   k48 ; k48 = 110
.line	274	loadk        r46  k113 ; k113 = 182
.line	274	loadk        r47  k118 ; k118 = 169
.line	274	call          r7    41     2
.line	274	getupval      r8    u1
.line	274	loadk         r9  k119 ; k119 = 192
.line	274	loadk        r10   k83 ; k83 = 178
.line	274	loadk        r11   k30 ; k30 = 73
.line	274	loadk        r12  k120 ; k120 = 102
.line	274	loadk        r13  k111 ; k111 = 116
.line	274	call          r8     6     0
.line	274	setlist       r6     0     1
.line	274	call          r5     2     2
.line	274	call          r4     2     2
.line	274	gettable      r5    r4  k121 ; k121 = "JumpUrl"
.line	274	move          r6    r3
.line	274	call          r5     2     1
.label	l251
.line	274	return        r0     1
.line	274	move          r0    r0
.line	274	move          r0    r0
.line	274	move          r0    r0
.line	274	return        r0     1

.function	main/f10/f0

.source	null
.linedefined	285
.lastlinedefined	287
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	2	true

.constant	k0	"send_buy_discount_sale_item"
.constant	k1	"Get_uniq_id"

.line	285	getupval      r0    u0
.line	285	self          r0    r0    k0 ; k0 = "send_buy_discount_sa" (truncated)
.line	285	getupval      r2    u0
.line	285	self          r2    r2    k1 ; k1 = "Get_uniq_id"
.line	285	call          r2     2     0
.line	285	call          r0     0     1
.line	285	return        r0     1
.line	285	move          r0    r0
.line	285	move          r0    r0
.line	285	move          r0    r0
.line	285	return        r0     1

.function	main/f11

.source	null
.linedefined	295
.lastlinedefined	302
.numparams	1
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"logic_coupon_shop"
.constant	k4	"GetCurShopScene"
.constant	k5	"IsKrJpTreasure"
.constant	k6	"require"
.constant	k7	218
.constant	k8	129
.constant	k9	77
.constant	k10	100
.constant	k11	104
.constant	k12	76
.constant	k13	145
.constant	k14	142
.constant	k15	18
.constant	k16	78
.constant	k17	43
.constant	k18	187
.constant	k19	165
.constant	k20	246
.constant	k21	79
.constant	k22	191
.constant	k23	42
.constant	k24	243
.constant	k25	55
.constant	k26	94
.constant	k27	131
.constant	k28	120
.constant	k29	160
.constant	k30	163
.constant	k31	64
.constant	k32	71
.constant	k33	53
.constant	k34	226
.constant	k35	176
.constant	k36	234
.constant	k37	103
.constant	k38	54
.constant	k39	184
.constant	k40	52
.constant	k41	136
.constant	k42	"UIManager"
.constant	k43	"ShowUI"
.constant	k44	"UI_Config"
.constant	k45	"ui_crate_voucher"
.constant	k46	"FromModule"
.constant	k47	"store"
.constant	k48	"RefreshSortComboBox"

.line	295	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	295	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	295	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	295	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	295	gettable      r2    r2    k3 ; k3 = "logic_coupon_shop"
.line	295	call          r1     2     2
.line	295	self          r2    r1    k4 ; k4 = "GetCurShopScene"
.line	295	call          r2     2     2
.line	295	self          r3    r1    k5 ; k5 = "IsKrJpTreasure"
.line	295	call          r3     2     2
.line	295	gettabup      r4    u0    k6 ; k6 = "require"
.line	295	getupval      r5    u1
.line	295	loadk         r6    k7 ; k7 = 218
.line	295	loadk         r7    k8 ; k8 = 129
.line	295	loadk         r8    k9 ; k9 = 77
.line	295	loadk         r9   k10 ; k10 = 100
.line	295	loadk        r10   k11 ; k11 = 104
.line	295	loadk        r11   k12 ; k12 = 76
.line	295	loadk        r12   k13 ; k13 = 145
.line	295	loadk        r13   k14 ; k14 = 142
.line	295	loadk        r14   k15 ; k15 = 18
.line	295	loadk        r15   k16 ; k16 = 78
.line	295	loadk        r16   k17 ; k17 = 43
.line	295	loadk        r17   k18 ; k18 = 187
.line	295	loadk        r18   k19 ; k19 = 165
.line	295	loadk        r19   k20 ; k20 = 246
.line	295	loadk        r20   k21 ; k21 = 79
.line	295	loadk        r21   k22 ; k22 = 191
.line	295	loadk        r22   k23 ; k23 = 42
.line	295	loadk        r23   k24 ; k24 = 243
.line	295	loadk        r24   k25 ; k25 = 55
.line	295	loadk        r25   k26 ; k26 = 94
.line	295	loadk        r26   k27 ; k27 = 131
.line	295	loadk        r27   k28 ; k28 = 120
.line	295	loadk        r28   k29 ; k29 = 160
.line	295	loadk        r29   k30 ; k30 = 163
.line	295	loadk        r30   k31 ; k31 = 64
.line	295	loadk        r31   k32 ; k32 = 71
.line	295	loadk        r32   k33 ; k33 = 53
.line	295	loadk        r33   k34 ; k34 = 226
.line	295	loadk        r34   k35 ; k35 = 176
.line	295	loadk        r35   k36 ; k36 = 234
.line	295	loadk        r36   k37 ; k37 = 103
.line	295	loadk        r37   k19 ; k19 = 165
.line	295	loadk        r38   k38 ; k38 = 54
.line	295	loadk        r39   k39 ; k39 = 184
.line	295	loadk        r40   k40 ; k40 = 52
.line	295	loadk        r41   k16 ; k16 = 78
.line	295	loadk        r42   k41 ; k41 = 136
.line	295	call          r5    38     2
.line	295	call          r4     2     2
.line	295	gettabup      r5    u0   k42 ; k42 = "UIManager"
.line	295	gettable      r5    r5   k43 ; k43 = "ShowUI"
.line	295	gettabup      r6    u0   k42 ; k42 = "UIManager"
.line	295	gettable      r6    r6   k44 ; k44 = "UI_Config"
.line	295	gettable      r6    r6   k45 ; k45 = "ui_crate_voucher"
.line	295	move          r7    r2
.line	295	gettable      r8    r4   k46 ; k46 = "FromModule"
.line	295	gettable      r8    r8   k47 ; k47 = "store"
.line	295	move          r9    r3
.line	295	call          r5     5     1
.line	295	self          r5    r0   k48 ; k48 = "RefreshSortComboBox"
.line	295	call          r5     2     1
.line	295	return        r0     1
.line	295	move          r0    r0
.line	295	move          r0    r0
.line	295	move          r0    r0
.line	295	move          r0    r0
.line	295	return        r0     1

.function	main/f12

.source	null
.linedefined	304
.lastlinedefined	365
.numparams	1
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	7	true
.upvalue	"U3"	8	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"GetCurItemAndIndex"
.constant	k4	"log"
.constant	k5	"bWriteLog"
.constant	k6	234
.constant	k7	153
.constant	k8	75
.constant	k9	115
.constant	k10	99
.constant	k11	127
.constant	k12	218
.constant	k13	147
.constant	k14	27
.constant	k15	73
.constant	k16	43
.constant	k17	249
.constant	k18	248
.constant	k19	79
.constant	k20	179
.constant	k21	146
.constant	k22	58
.constant	k23	114
.constant	k24	154
.constant	k25	97
.constant	k26	172
.constant	k27	166
.constant	k28	36
.constant	k29	94
.constant	k30	55
.constant	k31	245
.constant	k32	169
.constant	k33	81
.constant	k34	168
.constant	k35	61
.constant	k36	60
.constant	k37	1
.constant	k38	219
.constant	k39	56
.constant	k40	"tostring"
.constant	k41	"currIndex"
.constant	k42	132
.constant	k43	87
.constant	k44	33
.constant	k45	105
.constant	k46	77
.constant	k47	203
.constant	k48	221
.constant	k49	17
.constant	k50	93
.constant	k51	106
.constant	k52	231
.constant	k53	247
.constant	k54	"log_tree"
.constant	k55	82
.constant	k56	52
.constant	k57	189
.constant	k58	100
.constant	k59	28
.constant	k60	198
.constant	k61	"jump"
.constant	k62	"GetFrame"
.constant	k63	"bBackToLobby"
.constant	k64	true
.constant	k65	"type"
.constant	k66	205
.constant	k67	140
.constant	k68	70
.constant	k69	109
.constant	k70	"StoreConst"
.constant	k71	"store_tab"
.constant	k72	"moduleId"
.constant	k73	"MODEL_ID_STORE"
.constant	k74	"EventSystem"
.constant	k75	"postEvent"
.constant	k76	"EVENTTYPE_STORE_BTNEVENT"
.constant	k77	"EVENTID_STORE_FULLSCREEN_PREVIEW_QUIT"
.constant	k78	"GotoSpecifiedTabAndItem"
.constant	k79	"Tab1"
.constant	k80	"Tab2"
.constant	k81	"itemId"
.constant	k82	"MODEL_ID_SUPPLY"
.constant	k83	"from"
.constant	k84	"source_StoreJumpToCrate"
.constant	k85	false
.constant	k86	"supply_tab"
.constant	k87	"GlobalData"
.constant	k88	"IsJapanOrKorea"
.constant	k89	"ModuleManager"
.constant	k90	"GetModule"
.constant	k91	"LobbyModuleConfig"
.constant	k92	"store_jump_manager"
.constant	k93	"GetCreditJumpTabInfo"
.constant	k94	"give_tab"
.constant	k95	202
.constant	k96	86
.constant	k97	104
.constant	k98	95
.constant	k99	"string"
.constant	k100	"find"
.constant	k101	"format"
.constant	k102	212
.constant	k103	130
.constant	k104	64
.constant	k105	116
.constant	k106	216
.constant	k107	26
.constant	k108	"BP_ENUM_MODULE_MALL_CHILD"
.constant	k109	"JumpUrl"
.constant	k110	"JumpByInfo"
.constant	k111	"RefreshSortComboBox"
.constant	k112	"DropItemID"
.constant	k113	"require"
.constant	k114	"table"
.constant	k115	"concat"
.constant	k116	129
.constant	k117	76
.constant	k118	145
.constant	k119	142
.constant	k120	18
.constant	k121	78
.constant	k122	187
.constant	k123	170
.constant	k124	246
.constant	k125	176
.constant	k126	32
.constant	k127	186
.constant	k128	122
.constant	k129	69
.constant	k130	103
.constant	k131	227
.constant	k132	71
.constant	k133	53
.constant	k134	226
.constant	k135	134
.constant	k136	251
.constant	k137	182
.constant	k138	54
.constant	k139	191
.constant	k140	48
.constant	k141	126
.constant	k142	108
.constant	k143	177
.constant	k144	"json"
.constant	k145	"encode"
.constant	k146	"event_name"
.constant	k147	113
.constant	k148	152
.constant	k149	19
.constant	k150	0
.constant	k151	224
.constant	k152	164
.constant	k153	233
.constant	k154	124
.constant	k155	185
.constant	k156	14
.constant	k157	184
.constant	k158	"item_id"
.constant	k159	"tab_id"
.constant	k160	"tabId"
.constant	k161	"sub_tab_id"
.constant	k162	"subTabId"
.constant	k163	"jumpInfo"
.constant	k164	"ReportTLogEvent"
.constant	k165	"TLogEventDefine"
.constant	k166	"StoreItem_JumpToGet"
.constant	k167	237
.constant	k168	161
.constant	k169	102
.constant	k170	38
.constant	k171	138
.constant	k172	37
.constant	k173	92
.constant	k174	250
.constant	k175	136
.constant	k176	40
.constant	k177	228
.constant	k178	181
.constant	k179	217
.constant	k180	89
.constant	k181	11
.constant	k182	165
.constant	k183	190
.constant	k184	210
.constant	k185	167
.constant	k186	118
.constant	k187	20
.constant	k188	159
.constant	k189	143
.constant	k190	90
.constant	k191	57
.constant	k192	65
.constant	k193	96
.constant	k194	117
.constant	k195	209
.constant	k196	174
.constant	k197	10
.constant	k198	175

.line	304	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	304	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	304	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	304	call          r1     3     1
.line	304	self          r1    r0    k3 ; k3 = "GetCurItemAndIndex"
.line	304	call          r1     2     2
.line	304	test          r1     1
.line	304	jmp            0   l77
.line	304	gettabup      r2    u0    k4 ; k4 = "log"
.line	304	gettabup      r3    u0    k5 ; k5 = "bWriteLog"
.line	304	test          r3     0
.line	304	jmp            0   l75
.line	304	getupval      r3    u1
.line	304	loadk         r4    k6 ; k6 = 234
.line	304	loadk         r5    k7 ; k7 = 153
.line	304	loadk         r6    k8 ; k8 = 75
.line	304	loadk         r7    k9 ; k9 = 115
.line	304	loadk         r8   k10 ; k10 = 99
.line	304	loadk         r9   k11 ; k11 = 127
.line	304	loadk        r10   k12 ; k12 = 218
.line	304	loadk        r11   k13 ; k13 = 147
.line	304	loadk        r12   k14 ; k14 = 27
.line	304	loadk        r13   k15 ; k15 = 73
.line	304	loadk        r14   k16 ; k16 = 43
.line	304	loadk        r15   k17 ; k17 = 249
.line	304	loadk        r16    k7 ; k7 = 153
.line	304	loadk        r17   k18 ; k18 = 248
.line	304	loadk        r18   k19 ; k19 = 79
.line	304	loadk        r19   k20 ; k20 = 179
.line	304	loadk        r20    k9 ; k9 = 115
.line	304	loadk        r21   k21 ; k21 = 146
.line	304	loadk        r22   k22 ; k22 = 58
.line	304	loadk        r23   k23 ; k23 = 114
.line	304	loadk        r24   k24 ; k24 = 154
.line	304	loadk        r25   k25 ; k25 = 97
.line	304	loadk        r26   k26 ; k26 = 172
.line	304	loadk        r27   k27 ; k27 = 166
.line	304	loadk        r28   k28 ; k28 = 36
.line	304	loadk        r29   k29 ; k29 = 94
.line	304	loadk        r30   k30 ; k30 = 55
.line	304	loadk        r31   k31 ; k31 = 245
.line	304	loadk        r32   k31 ; k31 = 245
.line	304	loadk        r33   k32 ; k32 = 169
.line	304	loadk        r34   k33 ; k33 = 81
.line	304	loadk        r35   k34 ; k34 = 168
.line	304	loadk        r36   k35 ; k35 = 61
.line	304	loadk        r37   k34 ; k34 = 168
.line	304	loadk        r38   k36 ; k36 = 60
.line	304	loadk        r39   k37 ; k37 = 1
.line	304	loadk        r40   k38 ; k38 = 219
.line	304	loadk        r41   k39 ; k39 = 56
.line	304	call          r3    39     2
.line	304	gettabup      r4    u0   k40 ; k40 = "tostring"
.line	304	gettable      r5    r0   k41 ; k41 = "currIndex"
.line	304	call          r4     2     2
.line	304	getupval      r5    u1
.line	304	loadk         r6    k7 ; k7 = 153
.line	304	loadk         r7   k42 ; k42 = 132
.line	304	loadk         r8   k43 ; k43 = 87
.line	304	loadk         r9   k44 ; k44 = 33
.line	304	loadk        r10   k45 ; k45 = 105
.line	304	loadk        r11   k46 ; k46 = 77
.line	304	loadk        r12   k47 ; k47 = 203
.line	304	loadk        r13   k48 ; k48 = 221
.line	304	loadk        r14   k49 ; k49 = 17
.line	304	loadk        r15   k50 ; k50 = 93
.line	304	loadk        r16   k51 ; k51 = 106
.line	304	loadk        r17   k52 ; k52 = 231
.line	304	loadk        r18   k34 ; k34 = 168
.line	304	loadk        r19   k53 ; k53 = 247
.line	304	loadk        r20   k19 ; k19 = 79
.line	304	loadk        r21   k20 ; k20 = 179
.line	304	call          r5    17     2
.line	304	concat        r3    r3    r5
.label	l75
.line	304	call          r2     2     1
.line	304	return        r0     1
.label	l77
.line	304	gettabup      r2    u0   k54 ; k54 = "log_tree"
.line	304	getupval      r3    u1
.line	304	loadk         r4    k6 ; k6 = 234
.line	304	loadk         r5    k7 ; k7 = 153
.line	304	loadk         r6    k8 ; k8 = 75
.line	304	loadk         r7    k9 ; k9 = 115
.line	304	loadk         r8   k10 ; k10 = 99
.line	304	loadk         r9   k11 ; k11 = 127
.line	304	loadk        r10   k12 ; k12 = 218
.line	304	loadk        r11   k13 ; k13 = 147
.line	304	loadk        r12   k14 ; k14 = 27
.line	304	loadk        r13   k15 ; k15 = 73
.line	304	loadk        r14   k16 ; k16 = 43
.line	304	loadk        r15   k17 ; k17 = 249
.line	304	loadk        r16    k7 ; k7 = 153
.line	304	loadk        r17   k18 ; k18 = 248
.line	304	loadk        r18   k19 ; k19 = 79
.line	304	loadk        r19   k20 ; k20 = 179
.line	304	loadk        r20    k9 ; k9 = 115
.line	304	loadk        r21   k21 ; k21 = 146
.line	304	loadk        r22   k22 ; k22 = 58
.line	304	loadk        r23   k23 ; k23 = 114
.line	304	loadk        r24   k24 ; k24 = 154
.line	304	loadk        r25   k25 ; k25 = 97
.line	304	loadk        r26   k26 ; k26 = 172
.line	304	loadk        r27   k27 ; k27 = 166
.line	304	loadk        r28   k28 ; k28 = 36
.line	304	loadk        r29   k29 ; k29 = 94
.line	304	loadk        r30   k30 ; k30 = 55
.line	304	loadk        r31   k31 ; k31 = 245
.line	304	loadk        r32   k31 ; k31 = 245
.line	304	loadk        r33   k32 ; k32 = 169
.line	304	loadk        r34   k55 ; k55 = 82
.line	304	loadk        r35   k20 ; k20 = 179
.line	304	loadk        r36   k56 ; k56 = 52
.line	304	loadk        r37   k57 ; k57 = 189
.line	304	loadk        r38   k58 ; k58 = 100
.line	304	loadk        r39   k59 ; k59 = 28
.line	304	loadk        r40   k60 ; k60 = 198
.line	304	call          r3    38     2
.line	304	gettable      r4    r1   k61 ; k61 = "jump"
.line	304	call          r2     3     1
.line	304	loadbool      r2     1     0
.line	304	self          r3    r0   k62 ; k62 = "GetFrame"
.line	304	call          r3     2     3
.line	304	settable      r3   k63   k64 ; k64 = true
.line	304	gettabup      r5    u0   k65 ; k65 = "type"
.line	304	gettable      r6    r1   k61 ; k61 = "jump"
.line	304	call          r5     2     2
.line	304	getupval      r6    u1
.line	304	loadk         r7   k66 ; k66 = 205
.line	304	loadk         r8   k67 ; k67 = 140
.line	304	loadk         r9   k68 ; k68 = 70
.line	304	loadk        r10   k69 ; k69 = 109
.line	304	loadk        r11   k10 ; k10 = 99
.line	304	call          r6     6     2
.line	304	eq             0    r5    r6
.line	304	jmp            0  l235
.line	304	gettabup      r5    u0   k70 ; k70 = "StoreConst"
.line	304	gettable      r5    r5   k71 ; k71 = "store_tab"
.line	304	eq             0    r4    r5
.line	304	jmp            0  l170
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettable      r5    r5   k72 ; k72 = "moduleId"
.line	304	gettabup      r6    u2   k73 ; k73 = "MODEL_ID_STORE"
.line	304	eq             0    r5    r6
.line	304	jmp            0  l159
.line	304	loadbool      r2     0     0
.line	304	gettabup      r5    u0   k74 ; k74 = "EventSystem"
.line	304	self          r5    r5   k75 ; k75 = "postEvent"
.line	304	gettabup      r7    u0   k76 ; k76 = "EVENTTYPE_STORE_BTNE" (truncated)
.line	304	gettabup      r8    u0   k77 ; k77 = "EVENTID_STORE_FULLSC" (truncated)
.line	304	call          r5     4     1
.line	304	self          r5    r3   k78 ; k78 = "GotoSpecifiedTabAndI" (truncated)
.line	304	gettable      r7    r1   k61 ; k61 = "jump"
.line	304	gettable      r7    r7   k79 ; k79 = "Tab1"
.line	304	gettable      r8    r1   k61 ; k61 = "jump"
.line	304	gettable      r8    r8   k80 ; k80 = "Tab2"
.line	304	gettable      r9    r1   k61 ; k61 = "jump"
.line	304	gettable      r9    r9   k81 ; k81 = "itemId"
.line	304	call          r5     5     1
.line	304	jmp            0  l274
.label	l159
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettable      r5    r5   k72 ; k72 = "moduleId"
.line	304	gettabup      r6    u2   k82 ; k82 = "MODEL_ID_SUPPLY"
.line	304	eq             0    r5    r6
.line	304	jmp            0  l274
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettabup      r6    u0   k70 ; k70 = "StoreConst"
.line	304	gettable      r6    r6   k84 ; k84 = "source_StoreJumpToCr" (truncated)
.line	304	settable      r5   k83    r6 ; k83 = "from"
.line	304	settable      r3   k63   k85 ; k85 = false
.line	304	jmp            0  l274
.label	l170
.line	304	gettabup      r5    u0   k70 ; k70 = "StoreConst"
.line	304	gettable      r5    r5   k86 ; k86 = "supply_tab"
.line	304	eq             0    r4    r5
.line	304	jmp            0  l219
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettable      r5    r5   k72 ; k72 = "moduleId"
.line	304	gettabup      r6    u2   k82 ; k82 = "MODEL_ID_SUPPLY"
.line	304	eq             0    r5    r6
.line	304	jmp            0  l212
.line	304	gettabup      r5    u0   k87 ; k87 = "GlobalData"
.line	304	gettable      r5    r5   k88 ; k88 = "IsJapanOrKorea"
.line	304	call          r5     1     2
.line	304	test          r5     0
.line	304	jmp            0  l202
.line	304	loadbool      r2     1     0
.line	304	gettabup      r5    u0   k89 ; k89 = "ModuleManager"
.line	304	gettable      r5    r5   k90 ; k90 = "GetModule"
.line	304	gettabup      r6    u0   k89 ; k89 = "ModuleManager"
.line	304	gettable      r6    r6   k91 ; k91 = "LobbyModuleConfig"
.line	304	gettable      r6    r6   k92 ; k92 = "store_jump_manager"
.line	304	call          r5     2     2
.line	304	self          r6    r5   k93 ; k93 = "GetCreditJumpTabInfo"
.line	304	gettable      r8    r1   k61 ; k61 = "jump"
.line	304	gettable      r8    r8   k79 ; k79 = "Tab1"
.line	304	call          r6     3     4
.line	304	test          r6     0
.line	304	jmp            0  l203
.line	304	gettable      r9    r1   k61 ; k61 = "jump"
.line	304	settable      r9   k79    r7 ; k79 = "Tab1"
.line	304	gettable      r9    r1   k61 ; k61 = "jump"
.line	304	settable      r9   k80    r8 ; k80 = "Tab2"
.line	304	jmp            0  l203
.label	l202
.line	304	loadbool      r2     0     0
.label	l203
.line	304	self          r5    r3   k78 ; k78 = "GotoSpecifiedTabAndI" (truncated)
.line	304	gettable      r7    r1   k61 ; k61 = "jump"
.line	304	gettable      r7    r7   k79 ; k79 = "Tab1"
.line	304	gettable      r8    r1   k61 ; k61 = "jump"
.line	304	gettable      r8    r8   k80 ; k80 = "Tab2"
.line	304	gettable      r9    r1   k61 ; k61 = "jump"
.line	304	gettable      r9    r9   k81 ; k81 = "itemId"
.line	304	call          r5     5     1
.line	304	jmp            0  l274
.label	l212
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettable      r5    r5   k72 ; k72 = "moduleId"
.line	304	gettabup      r6    u2   k73 ; k73 = "MODEL_ID_STORE"
.line	304	eq             0    r5    r6
.line	304	jmp            0  l274
.line	304	settable      r3   k63   k85 ; k85 = false
.line	304	jmp            0  l274
.label	l219
.line	304	gettabup      r5    u0   k70 ; k70 = "StoreConst"
.line	304	gettable      r5    r5   k94 ; k94 = "give_tab"
.line	304	eq             0    r4    r5
.line	304	jmp            0  l274
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettable      r5    r5   k72 ; k72 = "moduleId"
.line	304	gettabup      r6    u2   k73 ; k73 = "MODEL_ID_STORE"
.line	304	eq             1    r5    r6
.line	304	jmp            0  l233
.line	304	gettable      r5    r1   k61 ; k61 = "jump"
.line	304	gettable      r5    r5   k72 ; k72 = "moduleId"
.line	304	gettabup      r6    u2   k82 ; k82 = "MODEL_ID_SUPPLY"
.line	304	eq             0    r5    r6
.line	304	jmp            0  l274
.label	l233
.line	304	settable      r3   k63   k85 ; k85 = false
.line	304	jmp            0  l274
.label	l235
.line	304	gettabup      r5    u0   k65 ; k65 = "type"
.line	304	gettable      r6    r1   k61 ; k61 = "jump"
.line	304	call          r5     2     2
.line	304	getupval      r6    u1
.line	304	loadk         r7   k95 ; k95 = 202
.line	304	loadk         r8    k7 ; k7 = 153
.line	304	loadk         r9   k96 ; k96 = 86
.line	304	loadk        r10   k97 ; k97 = 104
.line	304	loadk        r11   k97 ; k97 = 104
.line	304	loadk        r12   k98 ; k98 = 95
.line	304	call          r6     7     2
.line	304	eq             0    r5    r6
.line	304	jmp            0  l274
.line	304	gettabup      r5    u0   k99 ; k99 = "string"
.line	304	gettable      r5    r5  k100 ; k100 = "find"
.line	304	gettable      r6    r1   k61 ; k61 = "jump"
.line	304	gettabup      r7    u0   k99 ; k99 = "string"
.line	304	gettable      r7    r7  k101 ; k101 = "format"
.line	304	getupval      r8    u1
.line	304	loadk         r9  k102 ; k102 = 212
.line	304	loadk        r10  k103 ; k103 = 130
.line	304	loadk        r11  k104 ; k104 = 64
.line	304	loadk        r12  k105 ; k105 = 116
.line	304	loadk        r13   k51 ; k51 = 106
.line	304	loadk        r14   k50 ; k50 = 93
.line	304	loadk        r15  k103 ; k103 = 130
.line	304	loadk        r16  k106 ; k106 = 216
.line	304	loadk        r17  k107 ; k107 = 26
.line	304	call          r8    10     2
.line	304	gettabup      r9    u0  k108 ; k108 = "BP_ENUM_MODULE_MALL_" (truncated)
.line	304	call          r7     3     0
.line	304	call          r5     0     2
.line	304	test          r5     0
.line	304	jmp            0  l274
.line	304	loadbool      r2     0     0
.line	304	gettabup      r5    u0   k87 ; k87 = "GlobalData"
.line	304	gettable      r5    r5  k109 ; k109 = "JumpUrl"
.line	304	gettable      r6    r1   k61 ; k61 = "jump"
.line	304	call          r5     2     1
.label	l274
.line	304	eq             0    r2   k64 ; k64 = true
.line	304	jmp            0  l280
.line	304	gettabup      r5    u3  k110 ; k110 = "JumpByInfo"
.line	304	gettable      r6    r1   k61 ; k61 = "jump"
.line	304	call          r5     2     1
.line	304	jmp            0  l282
.label	l280
.line	304	self          r5    r0  k111 ; k111 = "RefreshSortComboBox"
.line	304	call          r5     2     1
.label	l282
.line	304	gettable      r5    r1  k112 ; k112 = "DropItemID"
.line	304	test          r5     1
.line	304	jmp            0  l286
.line	304	gettable      r5    r1   k81 ; k81 = "itemId"
.label	l286
.line	304	gettabup      r6    u0  k113 ; k113 = "require"
.line	304	gettabup      r7    u0  k114 ; k114 = "table"
.line	304	gettable      r7    r7  k115 ; k115 = "concat"
.line	304	newtable      r8     1     0
.line	304	getupval      r9    u1
.line	304	loadk        r10   k12 ; k12 = 218
.line	304	loadk        r11  k116 ; k116 = 129
.line	304	loadk        r12   k46 ; k46 = 77
.line	304	loadk        r13   k58 ; k58 = 100
.line	304	loadk        r14   k97 ; k97 = 104
.line	304	loadk        r15  k117 ; k117 = 76
.line	304	loadk        r16  k118 ; k118 = 145
.line	304	loadk        r17  k119 ; k119 = 142
.line	304	loadk        r18  k120 ; k120 = 18
.line	304	loadk        r19  k121 ; k121 = 78
.line	304	loadk        r20   k16 ; k16 = 43
.line	304	loadk        r21  k122 ; k122 = 187
.line	304	loadk        r22  k123 ; k123 = 170
.line	304	loadk        r23  k124 ; k124 = 246
.line	304	loadk        r24   k68 ; k68 = 70
.line	304	loadk        r25  k125 ; k125 = 176
.line	304	loadk        r26  k126 ; k126 = 32
.line	304	loadk        r27  k127 ; k127 = 186
.line	304	loadk        r28  k128 ; k128 = 122
.line	304	loadk        r29  k129 ; k129 = 69
.line	304	loadk        r30   k24 ; k24 = 154
.line	304	loadk        r31  k130 ; k130 = 103
.line	304	loadk        r32   k34 ; k34 = 168
.line	304	loadk        r33  k131 ; k131 = 227
.line	304	loadk        r34  k107 ; k107 = 26
.line	304	loadk        r35  k132 ; k132 = 71
.line	304	loadk        r36  k133 ; k133 = 53
.line	304	loadk        r37  k134 ; k134 = 226
.line	304	loadk        r38  k135 ; k135 = 134
.line	304	loadk        r39  k136 ; k136 = 251
.line	304	loadk        r40   k50 ; k50 = 93
.line	304	loadk        r41  k137 ; k137 = 182
.line	304	loadk        r42  k138 ; k138 = 54
.line	304	loadk        r43  k139 ; k139 = 191
.line	304	loadk        r44  k140 ; k140 = 48
.line	304	loadk        r45  k141 ; k141 = 126
.line	304	loadk        r46   k13 ; k13 = 147
.line	304	loadk        r47  k142 ; k142 = 108
.line	304	loadk        r48  k137 ; k137 = 182
.line	304	loadk        r49  k143 ; k143 = 177
.line	304	call          r9    41     2
.line	304	getupval     r10    u1
.line	304	loadk        r11   k95 ; k95 = 202
.line	304	call         r10     2     0
.line	304	setlist       r8     0     1
.line	304	call          r7     2     2
.line	304	call          r6     2     2
.line	304	gettabup      r7    u0  k144 ; k144 = "json"
.line	304	gettable      r7    r7  k145 ; k145 = "encode"
.line	304	newtable      r8     0     5
.line	304	getupval      r9    u1
.line	304	loadk        r10    k6 ; k6 = 234
.line	304	loadk        r11    k7 ; k7 = 153
.line	304	loadk        r12    k8 ; k8 = 75
.line	304	loadk        r13    k9 ; k9 = 115
.line	304	loadk        r14   k10 ; k10 = 99
.line	304	loadk        r15  k147 ; k147 = 113
.line	304	loadk        r16   k47 ; k47 = 203
.line	304	loadk        r17  k148 ; k148 = 152
.line	304	loadk        r18  k149 ; k149 = 19
.line	304	loadk        r19   k58 ; k58 = 100
.line	304	loadk        r20  k150 ; k150 = 0
.line	304	loadk        r21  k151 ; k151 = 224
.line	304	loadk        r22  k152 ; k152 = 164
.line	304	loadk        r23  k153 ; k153 = 233
.line	304	loadk        r24  k154 ; k154 = 124
.line	304	loadk        r25  k155 ; k155 = 185
.line	304	loadk        r26  k156 ; k156 = 14
.line	304	loadk        r27  k157 ; k157 = 184
.line	304	loadk        r28  k126 ; k126 = 32
.line	304	call          r9    20     2
.line	304	settable      r8  k146    r9 ; k146 = "event_name"
.line	304	settable      r8  k158    r5 ; k158 = "item_id"
.line	304	gettable      r9    r0  k160 ; k160 = "tabId"
.line	304	settable      r8  k159    r9 ; k159 = "tab_id"
.line	304	gettable      r9    r0  k162 ; k162 = "subTabId"
.line	304	settable      r8  k161    r9 ; k161 = "sub_tab_id"
.line	304	gettable      r9    r1   k61 ; k61 = "jump"
.line	304	settable      r8  k163    r9 ; k163 = "jumpInfo"
.line	304	call          r7     2     2
.line	304	gettable      r8    r6  k164 ; k164 = "ReportTLogEvent"
.line	304	gettabup      r9    u0  k165 ; k165 = "TLogEventDefine"
.line	304	gettable      r9    r9  k166 ; k166 = "StoreItem_JumpToGet"
.line	304	loadk        r10  k150 ; k150 = 0
.line	304	move         r11    r7
.line	304	call          r8     4     1
.line	304	gettabup      r8    u0    k4 ; k4 = "log"
.line	304	gettabup      r9    u0    k5 ; k5 = "bWriteLog"
.line	304	test          r9     0
.line	304	jmp            0  l468
.line	304	gettabup      r9    u0  k114 ; k114 = "table"
.line	304	gettable      r9    r9  k115 ; k115 = "concat"
.line	304	newtable     r10     1     0
.line	304	getupval     r11    u1
.line	304	loadk        r12  k167 ; k167 = 237
.line	304	loadk        r13  k168 ; k168 = 161
.line	304	loadk        r14    k8 ; k8 = 75
.line	304	loadk        r15  k169 ; k169 = 102
.line	304	loadk        r16  k170 ; k170 = 38
.line	304	loadk        r17   k96 ; k96 = 86
.line	304	loadk        r18   k12 ; k12 = 218
.line	304	loadk        r19  k171 ; k171 = 138
.line	304	loadk        r20   k29 ; k29 = 94
.line	304	loadk        r21   k50 ; k50 = 93
.line	304	loadk        r22  k172 ; k172 = 37
.line	304	loadk        r23   k52 ; k52 = 231
.line	304	loadk        r24  k152 ; k152 = 164
.line	304	loadk        r25   k18 ; k18 = 248
.line	304	loadk        r26  k173 ; k173 = 92
.line	304	loadk        r27  k174 ; k174 = 250
.line	304	loadk        r28   k45 ; k45 = 105
.line	304	loadk        r29  k119 ; k119 = 142
.line	304	loadk        r30  k126 ; k126 = 32
.line	304	loadk        r31   k29 ; k29 = 94
.line	304	loadk        r32   k42 ; k42 = 132
.line	304	loadk        r33   k69 ; k69 = 109
.line	304	loadk        r34  k175 ; k175 = 136
.line	304	loadk        r35   k34 ; k34 = 168
.line	304	loadk        r36  k150 ; k150 = 0
.line	304	loadk        r37  k121 ; k121 = 78
.line	304	loadk        r38  k176 ; k176 = 40
.line	304	loadk        r39  k177 ; k177 = 228
.line	304	loadk        r40  k178 ; k178 = 181
.line	304	loadk        r41  k179 ; k179 = 217
.line	304	loadk        r42  k180 ; k180 = 89
.line	304	loadk        r43  k168 ; k168 = 161
.line	304	loadk        r44   k36 ; k36 = 60
.line	304	loadk        r45   k53 ; k53 = 247
.line	304	loadk        r46  k181 ; k181 = 11
.line	304	loadk        r47   k19 ; k19 = 79
.line	304	loadk        r48  k182 ; k182 = 165
.line	304	loadk        r49  k105 ; k105 = 116
.line	304	loadk        r50  k137 ; k137 = 182
.line	304	loadk        r51  k183 ; k183 = 190
.line	304	call         r11    41     2
.line	304	getupval     r12    u1
.line	304	loadk        r13  k184 ; k184 = 210
.line	304	loadk        r14  k185 ; k185 = 167
.line	304	loadk        r15   k33 ; k33 = 81
.line	304	loadk        r16  k142 ; k142 = 108
.line	304	loadk        r17  k186 ; k186 = 118
.line	304	loadk        r18  k187 ; k187 = 20
.line	304	loadk        r19  k188 ; k188 = 159
.line	304	loadk        r20  k189 ; k189 = 143
.line	304	loadk        r21   k14 ; k14 = 27
.line	304	loadk        r22  k190 ; k190 = 90
.line	304	loadk        r23  k191 ; k191 = 57
.line	304	loadk        r24  k174 ; k174 = 250
.line	304	loadk        r25  k185 ; k185 = 167
.line	304	loadk        r26  k155 ; k155 = 185
.line	304	loadk        r27  k120 ; k120 = 18
.line	304	loadk        r28  k124 ; k124 = 246
.line	304	call         r12    17     0
.line	304	setlist      r10     0     1
.line	304	call          r9     2     2
.line	304	gettabup     r10    u0   k40 ; k40 = "tostring"
.line	304	loadk        r11  k150 ; k150 = 0
.line	304	call         r10     2     2
.line	304	getupval     r11    u1
.line	304	loadk        r12    k7 ; k7 = 153
.line	304	loadk        r13  k188 ; k188 = 159
.line	304	loadk        r14  k192 ; k192 = 65
.line	304	loadk        r15  k193 ; k193 = 96
.line	304	loadk        r16  k194 ; k194 = 117
.line	304	loadk        r17   k43 ; k43 = 87
.line	304	loadk        r18  k195 ; k195 = 209
.line	304	loadk        r19  k196 ; k196 = 174
.line	304	loadk        r20  k197 ; k197 = 10
.line	304	loadk        r21   k15 ; k15 = 73
.line	304	loadk        r22   k51 ; k51 = 106
.line	304	loadk        r23  k198 ; k198 = 175
.line	304	loadk        r24  k153 ; k153 = 233
.line	304	call         r11    14     2
.line	304	gettabup     r12    u0   k40 ; k40 = "tostring"
.line	304	move         r13    r7
.line	304	call         r12     2     2
.line	304	concat        r9    r9   r12
.label	l468
.line	304	call          r8     2     1
.line	304	return        r0     1
.line	304	move          r0    r0
.line	304	move          r0    r0
.line	304	gettabup      r1    u0   k64 ; k64 = true
.line	304	move          r0    r0
.line	304	return        r0     1

.function	main/f13

.source	null
.linedefined	367
.lastlinedefined	376
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	234
.constant	k5	153
.constant	k6	75
.constant	k7	115
.constant	k8	99
.constant	k9	127
.constant	k10	218
.constant	k11	147
.constant	k12	27
.constant	k13	73
.constant	k14	43
.constant	k15	249
.constant	k16	248
.constant	k17	79
.constant	k18	179
.constant	k19	136
.constant	k20	36
.constant	k21	85
.constant	k22	151
.constant	k23	124
.constant	k24	170
.constant	k25	158
.constant	k26	13
.constant	k27	89
.constant	k28	53
.constant	k29	233
.constant	k30	181
.constant	k31	255
.constant	k32	81
.constant	k33	163
.constant	k34	46
.constant	k35	33
.constant	k36	77
.constant	k37	131
.constant	k38	123
.constant	k39	171
.constant	k40	184
.constant	k41	221
.constant	k42	164
.constant	k43	74
.constant	k44	101
.constant	k45	64
.constant	k46	"showDataList"
.constant	k47	"pairs"
.constant	k48	"selected"
.constant	k49	true
.constant	k50	"SetCurItemAndIndex"

.line	367	gettabup      r1    u0    k0 ; k0 = "log"
.line	367	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	367	test          r2     0
.line	367	jmp            0   l60
.line	367	gettabup      r2    u0    k2 ; k2 = "table"
.line	367	gettable      r2    r2    k3 ; k3 = "concat"
.line	367	newtable      r3     1     0
.line	367	getupval      r4    u1
.line	367	loadk         r5    k4 ; k4 = 234
.line	367	loadk         r6    k5 ; k5 = 153
.line	367	loadk         r7    k6 ; k6 = 75
.line	367	loadk         r8    k7 ; k7 = 115
.line	367	loadk         r9    k8 ; k8 = 99
.line	367	loadk        r10    k9 ; k9 = 127
.line	367	loadk        r11   k10 ; k10 = 218
.line	367	loadk        r12   k11 ; k11 = 147
.line	367	loadk        r13   k12 ; k12 = 27
.line	367	loadk        r14   k13 ; k13 = 73
.line	367	loadk        r15   k14 ; k14 = 43
.line	367	loadk        r16   k15 ; k15 = 249
.line	367	loadk        r17    k5 ; k5 = 153
.line	367	loadk        r18   k16 ; k16 = 248
.line	367	loadk        r19   k17 ; k17 = 79
.line	367	loadk        r20   k18 ; k18 = 179
.line	367	loadk        r21    k7 ; k7 = 115
.line	367	loadk        r22   k19 ; k19 = 136
.line	367	loadk        r23   k20 ; k20 = 36
.line	367	loadk        r24   k21 ; k21 = 85
.line	367	loadk        r25   k22 ; k22 = 151
.line	367	loadk        r26   k23 ; k23 = 124
.line	367	loadk        r27   k24 ; k24 = 170
.line	367	loadk        r28   k25 ; k25 = 158
.line	367	loadk        r29   k26 ; k26 = 13
.line	367	loadk        r30   k27 ; k27 = 89
.line	367	loadk        r31   k28 ; k28 = 53
.line	367	loadk        r32   k29 ; k29 = 233
.line	367	loadk        r33   k30 ; k30 = 181
.line	367	loadk        r34   k31 ; k31 = 255
.line	367	loadk        r35   k32 ; k32 = 81
.line	367	loadk        r36   k33 ; k33 = 163
.line	367	loadk        r37   k34 ; k34 = 46
.line	367	loadk        r38   k25 ; k25 = 158
.line	367	loadk        r39   k35 ; k35 = 33
.line	367	loadk        r40   k36 ; k36 = 77
.line	367	loadk        r41   k37 ; k37 = 131
.line	367	loadk        r42   k38 ; k38 = 123
.line	367	loadk        r43   k39 ; k39 = 171
.line	367	loadk        r44   k40 ; k40 = 184
.line	367	call          r4    41     2
.line	367	getupval      r5    u1
.line	367	loadk         r6   k41 ; k41 = 221
.line	367	loadk         r7   k42 ; k42 = 164
.line	367	loadk         r8   k43 ; k43 = 74
.line	367	loadk         r9   k44 ; k44 = 101
.line	367	loadk        r10    k8 ; k8 = 99
.line	367	loadk        r11   k45 ; k45 = 64
.line	367	call          r5     7     0
.line	367	setlist       r3     0     1
.line	367	call          r2     2     2
.label	l60
.line	367	call          r1     2     1
.line	367	gettable      r1    r0   k46 ; k46 = "showDataList"
.line	367	test          r1     1
.line	367	jmp            0   l65
.line	367	newtable      r1     0     0
.label	l65
.line	367	gettabup      r2    u0   k47 ; k47 = "pairs"
.line	367	move          r3    r1
.line	367	call          r2     2     4
.line	367	jmp            0   l77
.line	367	gettable      r7    r6   k48 ; k48 = "selected"
.line	367	eq             0    r7   k49 ; k49 = true
.line	367	jmp            0   l77
.line	367	self          r7    r0   k50 ; k50 = "SetCurItemAndIndex"
.line	367	move          r9    r6
.line	367	move         r10    r5
.line	367	call          r7     4     1
.line	367	return        r0     1
.label	l77
.line	367	move          r0    r0
.line	367	move          r0    r0
.line	367	return        r0     1
.line	367	move          r0    r0
.line	367	return        r0     1

.function	main/f14

.source	null
.linedefined	378
.lastlinedefined	383
.numparams	1
.is_vararg	0
.maxstacksize	38

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	143
.constant	k18	49
.constant	k19	87
.constant	k20	132
.constant	k21	109
.constant	k22	188
.constant	k23	165
.constant	k24	62
.constant	k25	74
.constant	k26	61
.constant	k27	224
.constant	k28	154
.constant	k29	230
.constant	k30	86
.constant	k31	178
.constant	k32	60
.constant	k33	163
.constant	k34	48
.constant	k35	"sortTypeByGlobal"
.constant	k36	"ItemSortType"
.constant	k37	"Default"
.constant	k38	"EventSystem"
.constant	k39	"postEvent"
.constant	k40	"EVENTTYPE_STORE_DATA"
.constant	k41	"EVENTID_STORE_HIDE_JUMP_TP_CHEST"
.constant	k42	"RefreshUI"

.line	378	gettabup      r1    u0    k0 ; k0 = "log"
.line	378	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	378	test          r2     0
.line	378	jmp            0   l42
.line	378	getupval      r2    u1
.line	378	loadk         r3    k2 ; k2 = 234
.line	378	loadk         r4    k3 ; k3 = 153
.line	378	loadk         r5    k4 ; k4 = 75
.line	378	loadk         r6    k5 ; k5 = 115
.line	378	loadk         r7    k6 ; k6 = 99
.line	378	loadk         r8    k7 ; k7 = 127
.line	378	loadk         r9    k8 ; k8 = 218
.line	378	loadk        r10    k9 ; k9 = 147
.line	378	loadk        r11   k10 ; k10 = 27
.line	378	loadk        r12   k11 ; k11 = 73
.line	378	loadk        r13   k12 ; k12 = 43
.line	378	loadk        r14   k13 ; k13 = 249
.line	378	loadk        r15    k3 ; k3 = 153
.line	378	loadk        r16   k14 ; k14 = 248
.line	378	loadk        r17   k15 ; k15 = 79
.line	378	loadk        r18   k16 ; k16 = 179
.line	378	loadk        r19    k5 ; k5 = 115
.line	378	loadk        r20   k17 ; k17 = 143
.line	378	loadk        r21   k18 ; k18 = 49
.line	378	loadk        r22   k19 ; k19 = 87
.line	378	loadk        r23   k20 ; k20 = 132
.line	378	loadk        r24   k21 ; k21 = 109
.line	378	loadk        r25   k22 ; k22 = 188
.line	378	loadk        r26   k23 ; k23 = 165
.line	378	loadk        r27   k24 ; k24 = 62
.line	378	loadk        r28   k25 ; k25 = 74
.line	378	loadk        r29   k26 ; k26 = 61
.line	378	loadk        r30   k27 ; k27 = 224
.line	378	loadk        r31   k28 ; k28 = 154
.line	378	loadk        r32   k29 ; k29 = 230
.line	378	loadk        r33   k30 ; k30 = 86
.line	378	loadk        r34   k31 ; k31 = 178
.line	378	loadk        r35   k32 ; k32 = 60
.line	378	loadk        r36   k33 ; k33 = 163
.line	378	loadk        r37   k34 ; k34 = 48
.line	378	call          r2    36     2
.label	l42
.line	378	call          r1     2     1
.line	378	gettabup      r1    u2   k36 ; k36 = "ItemSortType"
.line	378	gettable      r1    r1   k37 ; k37 = "Default"
.line	378	settable      r0   k35    r1 ; k35 = "sortTypeByGlobal"
.line	378	gettabup      r1    u0   k38 ; k38 = "EventSystem"
.line	378	self          r1    r1   k39 ; k39 = "postEvent"
.line	378	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_STORE_DATA"
.line	378	gettabup      r4    u0   k41 ; k41 = "EVENTID_STORE_HIDE_J" (truncated)
.line	378	call          r1     4     1
.line	378	self          r1    r0   k42 ; k42 = "RefreshUI"
.line	378	call          r1     2     1
.line	378	return        r0     1
.line	378	move          r0    r0
.line	378	move          r0    r0
.line	378	move          r0    r0
.line	378	move          r0    r0
.line	378	return        r0     1

.function	main/f15

.source	null
.linedefined	385
.lastlinedefined	402
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log_tree"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	234
.constant	k4	153
.constant	k5	75
.constant	k6	115
.constant	k7	99
.constant	k8	127
.constant	k9	218
.constant	k10	147
.constant	k11	27
.constant	k12	73
.constant	k13	43
.constant	k14	249
.constant	k15	248
.constant	k16	79
.constant	k17	179
.constant	k18	146
.constant	k19	58
.constant	k20	118
.constant	k21	124
.constant	k22	139
.constant	k23	164
.constant	k24	28
.constant	k25	78
.constant	k26	57
.constant	k27	241
.constant	k28	137
.constant	k29	251
.constant	k30	81
.constant	k31	165
.constant	k32	60
.constant	k33	132
.constant	k34	42
.constant	k35	71
.constant	k36	52
.constant	k37	255
.constant	k38	177
.constant	k39	208
.constant	k40	158
.constant	k41	80
.constant	k42	33
.constant	k43	59
.constant	k44	24
.constant	k45	"directPurchaseList"
.constant	k46	"pairs"
.constant	k47	"CentauriProductId"
.constant	k48	"productid"
.constant	k49	"CentauriCountry"
.constant	k50	"country"
.constant	k51	"CentauriCurrency"
.constant	k52	"curency_unit"
.constant	k53	"Currency"
.constant	k54	"currency"
.constant	k55	"CentauriPrice"
.constant	k56	"tonumber"
.constant	k57	0
.constant	k58	10
.constant	k59	"CentauriPayItem"
.constant	k60	"payItem"
.constant	k61	"priceDesc"
.constant	k62	"CentauriManager"
.constant	k63	"GetPriceByProductId"
.constant	k64	"tostring"
.constant	k65	"GetCurItemAndIndex"
.constant	k66	"UpdateNewBuyBtn"
.constant	k67	"RefreshAllItemWithClick"

.line	385	gettabup      r4    u0    k0 ; k0 = "log_tree"
.line	385	gettabup      r5    u0    k1 ; k1 = "table"
.line	385	gettable      r5    r5    k2 ; k2 = "concat"
.line	385	newtable      r6     1     0
.line	385	getupval      r7    u1
.line	385	loadk         r8    k3 ; k3 = 234
.line	385	loadk         r9    k4 ; k4 = 153
.line	385	loadk        r10    k5 ; k5 = 75
.line	385	loadk        r11    k6 ; k6 = 115
.line	385	loadk        r12    k7 ; k7 = 99
.line	385	loadk        r13    k8 ; k8 = 127
.line	385	loadk        r14    k9 ; k9 = 218
.line	385	loadk        r15   k10 ; k10 = 147
.line	385	loadk        r16   k11 ; k11 = 27
.line	385	loadk        r17   k12 ; k12 = 73
.line	385	loadk        r18   k13 ; k13 = 43
.line	385	loadk        r19   k14 ; k14 = 249
.line	385	loadk        r20    k4 ; k4 = 153
.line	385	loadk        r21   k15 ; k15 = 248
.line	385	loadk        r22   k16 ; k16 = 79
.line	385	loadk        r23   k17 ; k17 = 179
.line	385	loadk        r24    k6 ; k6 = 115
.line	385	loadk        r25   k18 ; k18 = 146
.line	385	loadk        r26   k19 ; k19 = 58
.line	385	loadk        r27   k20 ; k20 = 118
.line	385	loadk        r28   k10 ; k10 = 147
.line	385	loadk        r29   k21 ; k21 = 124
.line	385	loadk        r30   k22 ; k22 = 139
.line	385	loadk        r31   k23 ; k23 = 164
.line	385	loadk        r32   k24 ; k24 = 28
.line	385	loadk        r33   k25 ; k25 = 78
.line	385	loadk        r34   k26 ; k26 = 57
.line	385	loadk        r35   k27 ; k27 = 241
.line	385	loadk        r36   k28 ; k28 = 137
.line	385	loadk        r37   k29 ; k29 = 251
.line	385	loadk        r38   k30 ; k30 = 81
.line	385	loadk        r39   k31 ; k31 = 165
.line	385	loadk        r40   k32 ; k32 = 60
.line	385	loadk        r41   k33 ; k33 = 132
.line	385	loadk        r42   k34 ; k34 = 42
.line	385	loadk        r43   k35 ; k35 = 71
.line	385	loadk        r44   k28 ; k28 = 137
.line	385	loadk        r45   k36 ; k36 = 52
.line	385	loadk        r46   k37 ; k37 = 255
.line	385	loadk        r47   k38 ; k38 = 177
.line	385	call          r7    41     2
.line	385	getupval      r8    u1
.line	385	loadk         r9   k39 ; k39 = 208
.line	385	loadk        r10   k40 ; k40 = 158
.line	385	loadk        r11   k41 ; k41 = 80
.line	385	loadk        r12   k42 ; k42 = 33
.line	385	loadk        r13   k43 ; k43 = 59
.line	385	loadk        r14   k44 ; k44 = 24
.line	385	call          r8     7     0
.line	385	setlist       r6     0     1
.line	385	call          r5     2     2
.line	385	move          r6    r3
.line	385	call          r4     3     1
.line	385	newtable      r4     0     0
.line	385	settable      r0   k45    r4 ; k45 = "directPurchaseList"
.line	385	gettabup      r4    u0   k46 ; k46 = "pairs"
.line	385	move          r5    r3
.line	385	call          r4     2     4
.line	385	jmp            0  l100
.line	385	newtable      r9     0     0
.line	385	gettable     r10    r8   k48 ; k48 = "productid"
.line	385	settable      r9   k47   r10 ; k47 = "CentauriProductId"
.line	385	gettable     r10    r8   k50 ; k50 = "country"
.line	385	settable      r9   k49   r10 ; k49 = "CentauriCountry"
.line	385	gettable     r10    r8   k52 ; k52 = "curency_unit"
.line	385	settable      r9   k51   r10 ; k51 = "CentauriCurrency"
.line	385	gettable     r10    r8   k54 ; k54 = "currency"
.line	385	settable      r9   k53   r10 ; k53 = "Currency"
.line	385	gettabup     r10    u0   k56 ; k56 = "tonumber"
.line	385	gettable     r11    r8   k55 ; k55 = "CentauriPrice"
.line	385	call         r10     2     2
.line	385	test         r10     1
.line	385	jmp            0   l80
.line	385	loadk        r10   k57 ; k57 = 0
.label	l80
.line	385	div          r10   r10   k58 ; k58 = 10
.line	385	settable      r9   k55   r10 ; k55 = "CentauriPrice"
.line	385	gettable     r10    r8   k60 ; k60 = "payItem"
.line	385	settable      r9   k59   r10 ; k59 = "CentauriPayItem"
.line	385	gettabup     r10    u0   k62 ; k62 = "CentauriManager"
.line	385	gettable     r10   r10   k63 ; k63 = "GetPriceByProductId"
.line	385	gettable     r11    r9   k47 ; k47 = "CentauriProductId"
.line	385	gettable     r12    r9   k51 ; k51 = "CentauriCurrency"
.line	385	gettabup     r13    u0   k64 ; k64 = "tostring"
.line	385	gettable     r14    r9   k53 ; k53 = "Currency"
.line	385	call         r13     2     2
.line	385	gettabup     r14    u0   k64 ; k64 = "tostring"
.line	385	gettable     r15    r9   k55 ; k55 = "CentauriPrice"
.line	385	call         r14     2     2
.line	385	concat       r13   r13   r14
.line	385	loadbool     r14     1     0
.line	385	call         r10     5     2
.line	385	settable      r9   k61   r10 ; k61 = "priceDesc"
.line	385	gettable     r10    r0   k45 ; k45 = "directPurchaseList"
.line	385	settable     r10    r7    r9
.label	l100
.line	385	move          r0    r0
.line	385	move          r0    r0
.line	385	self          r4    r0   k65 ; k65 = "GetCurItemAndIndex"
.line	385	call          r4     2     2
.line	385	self          r5    r0   k66 ; k66 = "UpdateNewBuyBtn"
.line	385	move          r7    r4
.line	385	call          r5     3     1
.line	385	self          r5    r0   k67 ; k67 = "RefreshAllItemWithCl" (truncated)
.line	385	call          r5     2     1
.line	385	return        r0     1
.line	385	move          r0    r0
.line	385	move          r0    r0
.line	385	gettabup      r1    u0   k44 ; k44 = 24
.line	385	move          r0    r0
.line	385	return        r0     1

.function	main/f16

.source	null
.linedefined	404
.lastlinedefined	411
.numparams	1
.is_vararg	0
.maxstacksize	39

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	118
.constant	k20	124
.constant	k21	131
.constant	k22	162
.constant	k23	13
.constant	k24	74
.constant	k25	54
.constant	k26	213
.constant	k27	171
.constant	k28	224
.constant	k29	91
.constant	k30	163
.constant	k31	16
.constant	k32	34
.constant	k33	78
.constant	k34	"pairs"
.constant	k35	"directPurchaseList"
.constant	k36	"priceDesc"
.constant	k37	"CentauriManager"
.constant	k38	"GetPriceByProductId"
.constant	k39	"midasProduCentauriProductIdctId"
.constant	k40	"Currency"
.constant	k41	"tostring"
.constant	k42	"CentauriPrice"
.constant	k43	"GetCurItemAndIndex"
.constant	k44	"UpdateNewBuyBtn"

.line	404	gettabup      r1    u0    k0 ; k0 = "log"
.line	404	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	404	test          r2     0
.line	404	jmp            0   l43
.line	404	getupval      r2    u1
.line	404	loadk         r3    k2 ; k2 = 234
.line	404	loadk         r4    k3 ; k3 = 153
.line	404	loadk         r5    k4 ; k4 = 75
.line	404	loadk         r6    k5 ; k5 = 115
.line	404	loadk         r7    k6 ; k6 = 99
.line	404	loadk         r8    k7 ; k7 = 127
.line	404	loadk         r9    k8 ; k8 = 218
.line	404	loadk        r10    k9 ; k9 = 147
.line	404	loadk        r11   k10 ; k10 = 27
.line	404	loadk        r12   k11 ; k11 = 73
.line	404	loadk        r13   k12 ; k12 = 43
.line	404	loadk        r14   k13 ; k13 = 249
.line	404	loadk        r15    k3 ; k3 = 153
.line	404	loadk        r16   k14 ; k14 = 248
.line	404	loadk        r17   k15 ; k15 = 79
.line	404	loadk        r18   k16 ; k16 = 179
.line	404	loadk        r19    k5 ; k5 = 115
.line	404	loadk        r20   k17 ; k17 = 146
.line	404	loadk        r21   k18 ; k18 = 58
.line	404	loadk        r22   k19 ; k19 = 118
.line	404	loadk        r23    k9 ; k9 = 147
.line	404	loadk        r24   k20 ; k20 = 124
.line	404	loadk        r25   k21 ; k21 = 131
.line	404	loadk        r26   k22 ; k22 = 162
.line	404	loadk        r27   k23 ; k23 = 13
.line	404	loadk        r28   k24 ; k24 = 74
.line	404	loadk        r29   k25 ; k25 = 54
.line	404	loadk        r30   k26 ; k26 = 213
.line	404	loadk        r31   k27 ; k27 = 171
.line	404	loadk        r32   k28 ; k28 = 224
.line	404	loadk        r33   k29 ; k29 = 91
.line	404	loadk        r34   k30 ; k30 = 163
.line	404	loadk        r35   k31 ; k31 = 16
.line	404	loadk        r36   k30 ; k30 = 163
.line	404	loadk        r37   k32 ; k32 = 34
.line	404	loadk        r38   k33 ; k33 = 78
.line	404	call          r2    37     2
.label	l43
.line	404	call          r1     2     1
.line	404	gettabup      r1    u0   k34 ; k34 = "pairs"
.line	404	gettable      r2    r0   k35 ; k35 = "directPurchaseList"
.line	404	call          r1     2     4
.line	404	jmp            0   l61
.line	404	gettabup      r6    u0   k37 ; k37 = "CentauriManager"
.line	404	gettable      r6    r6   k38 ; k38 = "GetPriceByProductId"
.line	404	gettable      r7    r5   k39 ; k39 = "midasProduCentauriPr" (truncated)
.line	404	gettable      r8    r5   k40 ; k40 = "Currency"
.line	404	gettabup      r9    u0   k41 ; k41 = "tostring"
.line	404	gettable     r10    r5   k40 ; k40 = "Currency"
.line	404	call          r9     2     2
.line	404	gettabup     r10    u0   k41 ; k41 = "tostring"
.line	404	gettable     r11    r5   k42 ; k42 = "CentauriPrice"
.line	404	call         r10     2     2
.line	404	concat        r9    r9   r10
.line	404	call          r6     4     2
.line	404	settable      r5   k36    r6 ; k36 = "priceDesc"
.label	l61
.line	404	move          r0    r0
.line	404	move          r0    r0
.line	404	self          r1    r0   k43 ; k43 = "GetCurItemAndIndex"
.line	404	call          r1     2     2
.line	404	self          r2    r0   k44 ; k44 = "UpdateNewBuyBtn"
.line	404	move          r4    r1
.line	404	call          r2     3     1
.line	404	return        r0     1
.line	404	move          r0    r0
.line	404	return        r0     1

.function	main/f17

.source	null
.linedefined	413
.lastlinedefined	423
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"IsPageShowing"
.constant	k1	"IsPageDataReady"
.constant	k2	"UIRoot"
.constant	k3	"CanvasPanel_17"
.constant	k4	"SetWidgetVisibility"
.constant	k5	"UEnums"
.constant	k6	"ESlateVisibility"
.constant	k7	"SelfHitTestInvisible"
.constant	k8	"RestoreCurUseCharacter"
.constant	k9	"ResetDropDownData"
.constant	k10	"SetTitleData"
.constant	k11	"UpdateUI"
.constant	k12	"SetSubTabOffsetByJK"
.constant	k13	"ChooseTheFirstOrSpecifiedOne"

.line	413	self          r1    r0    k0 ; k0 = "IsPageShowing"
.line	413	call          r1     2     2
.line	413	test          r1     0
.line	413	jmp            0   l28
.line	413	self          r1    r0    k1 ; k1 = "IsPageDataReady"
.line	413	call          r1     2     2
.line	413	test          r1     0
.line	413	jmp            0   l28
.line	413	gettable      r1    r0    k2 ; k2 = "UIRoot"
.line	413	gettable      r1    r1    k3 ; k3 = "CanvasPanel_17"
.line	413	self          r1    r1    k4 ; k4 = "SetWidgetVisibility"
.line	413	gettabup      r3    u0    k5 ; k5 = "UEnums"
.line	413	gettable      r3    r3    k6 ; k6 = "ESlateVisibility"
.line	413	gettable      r3    r3    k7 ; k7 = "SelfHitTestInvisible"
.line	413	call          r1     3     1
.line	413	self          r1    r0    k8 ; k8 = "RestoreCurUseCharact" (truncated)
.line	413	call          r1     2     1
.line	413	self          r1    r0    k9 ; k9 = "ResetDropDownData"
.line	413	call          r1     2     1
.line	413	self          r1    r0   k10 ; k10 = "SetTitleData"
.line	413	call          r1     2     1
.line	413	self          r1    r0   k11 ; k11 = "UpdateUI"
.line	413	call          r1     2     1
.line	413	self          r1    r0   k12 ; k12 = "SetSubTabOffsetByJK"
.line	413	call          r1     2     1
.line	413	self          r1    r0   k13 ; k13 = "ChooseTheFirstOrSpec" (truncated)
.line	413	call          r1     2     1
.label	l28
.line	413	return        r0     1
.line	413	move          r0    r0
.line	413	return        r0     1

.function	main/f18

.source	null
.linedefined	425
.lastlinedefined	428
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	"showDataList"
.constant	k1	"SortItemListByFilter"

.line	425	testset       r2    r1     1
.line	425	jmp            0    l4
.line	425	newtable      r2     0     0
.label	l4
.line	425	settable      r0    k0    r2 ; k0 = "showDataList"
.line	425	self          r2    r0    k1 ; k1 = "SortItemListByFilter"
.line	425	call          r2     2     1
.line	425	return        r0     1
.line	425	move          r0    r0
.line	425	return        r0     1

.function	main/f19

.source	null
.linedefined	430
.lastlinedefined	470
.numparams	5
.is_vararg	0
.maxstacksize	13

.upvalue	"_ENV"	0	false
.upvalue	"U1"	8	true

.constant	k0	"ipairs"
.constant	k1	"lowestPriceList"
.constant	k2	"currency"
.constant	k3	nil
.constant	k4	"DefaultSortAlgorithm"
.constant	k5	"discountPrice"
.constant	k6	1
.constant	k7	0

.line	430	loadnil       r5     1
.line	430	gettabup      r7    u0    k0 ; k0 = "ipairs"
.line	430	gettable      r8    r1    k1 ; k1 = "lowestPriceList"
.line	430	call          r7     2     4
.line	430	jmp            0   l11
.line	430	gettable     r12   r11    k2 ; k2 = "currency"
.line	430	eq             0   r12    r3
.line	430	jmp            0   l11
.line	430	move          r5   r10
.line	430	jmp            0   l13
.label	l11
.line	430	move          r0    r0
.line	430	move          r0    r0
.label	l13
.line	430	gettabup      r7    u0    k0 ; k0 = "ipairs"
.line	430	gettable      r8    r2    k1 ; k1 = "lowestPriceList"
.line	430	call          r7     2     4
.line	430	jmp            0   l22
.line	430	gettable     r12   r11    k2 ; k2 = "currency"
.line	430	eq             0   r12    r3
.line	430	jmp            0   l22
.line	430	move          r6   r10
.line	430	jmp            0   l24
.label	l22
.line	430	move          r0    r0
.line	430	move          r0    r0
.label	l24
.line	430	eq             0    r6    k3 ; k3 = nil
.line	430	jmp            0   l37
.line	430	eq             0    r5    k3 ; k3 = nil
.line	430	jmp            0   l34
.line	430	gettabup      r7    u1    k4 ; k4 = "DefaultSortAlgorithm"
.line	430	move          r8    r1
.line	430	move          r9    r2
.line	430	tailcall      r7     3
.line	430	return        r7     0
.line	430	jmp            0   l41
.label	l34
.line	430	loadbool      r7     1     0
.line	430	return        r7     2
.line	430	jmp            0   l41
.label	l37
.line	430	eq             0    r5    k3 ; k3 = nil
.line	430	jmp            0   l41
.line	430	loadbool      r7     0     0
.line	430	return        r7     2
.label	l41
.line	430	gettable      r7    r1    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r5
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	gettable      r8    r2    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r8    r8    r6
.line	430	gettable      r8    r8    k5 ; k5 = "discountPrice"
.line	430	eq             0    r7    r8
.line	430	jmp            0   l55
.line	430	gettabup      r7    u1    k4 ; k4 = "DefaultSortAlgorithm"
.line	430	move          r8    r1
.line	430	move          r9    r2
.line	430	tailcall      r7     3
.line	430	return        r7     0
.line	430	jmp            0  l112
.label	l55
.line	430	eq             0    r4    k6 ; k6 = 1
.line	430	jmp            0   l85
.line	430	gettable      r7    r1    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r5
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	eq             0    r7    k7 ; k7 = 0
.line	430	jmp            0   l65
.line	430	loadbool      r7     0     0
.line	430	return        r7     2
.line	430	jmp            0  l112
.label	l65
.line	430	gettable      r7    r2    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r6
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	eq             0    r7    k7 ; k7 = 0
.line	430	jmp            0   l73
.line	430	loadbool      r7     1     0
.line	430	return        r7     2
.line	430	jmp            0  l112
.label	l73
.line	430	gettable      r7    r1    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r5
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	gettable      r8    r2    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r8    r8    r6
.line	430	gettable      r8    r8    k5 ; k5 = "discountPrice"
.line	430	lt             1    r7    r8
.line	430	jmp            0   l82
.line	430	loadbool      r7     0     1
.label	l82
.line	430	loadbool      r7     1     0
.line	430	return        r7     2
.line	430	jmp            0  l112
.label	l85
.line	430	gettable      r7    r1    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r5
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	eq             0    r7    k7 ; k7 = 0
.line	430	jmp            0   l93
.line	430	loadbool      r7     0     0
.line	430	return        r7     2
.line	430	jmp            0  l112
.label	l93
.line	430	gettable      r7    r2    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r6
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	eq             0    r7    k7 ; k7 = 0
.line	430	jmp            0  l101
.line	430	loadbool      r7     1     0
.line	430	return        r7     2
.line	430	jmp            0  l112
.label	l101
.line	430	gettable      r7    r1    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r7    r7    r5
.line	430	gettable      r7    r7    k5 ; k5 = "discountPrice"
.line	430	gettable      r8    r2    k1 ; k1 = "lowestPriceList"
.line	430	gettable      r8    r8    r6
.line	430	gettable      r8    r8    k5 ; k5 = "discountPrice"
.line	430	lt             1    r8    r7
.line	430	jmp            0  l110
.line	430	loadbool      r7     0     1
.label	l110
.line	430	loadbool      r7     1     0
.line	430	return        r7     2
.label	l112
.line	430	return        r0     1
.line	430	move          r0    r0
.line	430	return        r0     1

.function	main/f20

.source	null
.linedefined	472
.lastlinedefined	479
.numparams	4
.is_vararg	0
.maxstacksize	40

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	114
.constant	k20	100
.constant	k21	163
.constant	k22	168
.constant	k23	13
.constant	k24	95
.constant	k25	63
.constant	k26	225
.constant	k27	139
.constant	k28	236
.constant	k29	53
.constant	k30	185
.constant	k31	"ModuleManager"
.constant	k32	"GetModule"
.constant	k33	"CommonModuleConfig"
.constant	k34	"store_collect_data"
.constant	k35	"currentItem"
.constant	k36	"itemId"
.constant	k37	"collected"
.constant	k38	"IsCollectedByItemID"
.constant	k39	"UpdateNewCollectBtn"

.line	472	gettabup      r4    u0    k0 ; k0 = "log"
.line	472	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	472	test          r5     0
.line	472	jmp            0   l41
.line	472	getupval      r5    u1
.line	472	loadk         r6    k2 ; k2 = 234
.line	472	loadk         r7    k3 ; k3 = 153
.line	472	loadk         r8    k4 ; k4 = 75
.line	472	loadk         r9    k5 ; k5 = 115
.line	472	loadk        r10    k6 ; k6 = 99
.line	472	loadk        r11    k7 ; k7 = 127
.line	472	loadk        r12    k8 ; k8 = 218
.line	472	loadk        r13    k9 ; k9 = 147
.line	472	loadk        r14   k10 ; k10 = 27
.line	472	loadk        r15   k11 ; k11 = 73
.line	472	loadk        r16   k12 ; k12 = 43
.line	472	loadk        r17   k13 ; k13 = 249
.line	472	loadk        r18    k3 ; k3 = 153
.line	472	loadk        r19   k14 ; k14 = 248
.line	472	loadk        r20   k15 ; k15 = 79
.line	472	loadk        r21   k16 ; k16 = 179
.line	472	loadk        r22    k5 ; k5 = 115
.line	472	loadk        r23   k17 ; k17 = 146
.line	472	loadk        r24   k18 ; k18 = 58
.line	472	loadk        r25   k19 ; k19 = 114
.line	472	loadk        r26    k3 ; k3 = 153
.line	472	loadk        r27   k20 ; k20 = 100
.line	472	loadk        r28   k21 ; k21 = 163
.line	472	loadk        r29   k22 ; k22 = 168
.line	472	loadk        r30   k23 ; k23 = 13
.line	472	loadk        r31   k24 ; k24 = 95
.line	472	loadk        r32   k25 ; k25 = 63
.line	472	loadk        r33   k26 ; k26 = 225
.line	472	loadk        r34   k27 ; k27 = 139
.line	472	loadk        r35   k28 ; k28 = 236
.line	472	loadk        r36    k4 ; k4 = 75
.line	472	loadk        r37   k16 ; k16 = 179
.line	472	loadk        r38   k29 ; k29 = 53
.line	472	loadk        r39   k30 ; k30 = 185
.line	472	call          r5    35     2
.label	l41
.line	472	call          r4     2     1
.line	472	gettabup      r4    u0   k31 ; k31 = "ModuleManager"
.line	472	gettable      r4    r4   k32 ; k32 = "GetModule"
.line	472	gettabup      r5    u0   k31 ; k31 = "ModuleManager"
.line	472	gettable      r5    r5   k33 ; k33 = "CommonModuleConfig"
.line	472	gettable      r5    r5   k34 ; k34 = "store_collect_data"
.line	472	call          r4     2     2
.line	472	gettable      r5    r0   k35 ; k35 = "currentItem"
.line	472	test          r5     0
.line	472	jmp            0   l64
.line	472	gettable      r5    r0   k35 ; k35 = "currentItem"
.line	472	gettable      r5    r5   k36 ; k36 = "itemId"
.line	472	test          r5     0
.line	472	jmp            0   l64
.line	472	gettable      r5    r0   k35 ; k35 = "currentItem"
.line	472	self          r6    r4   k38 ; k38 = "IsCollectedByItemID"
.line	472	gettable      r8    r0   k35 ; k35 = "currentItem"
.line	472	gettable      r8    r8   k36 ; k36 = "itemId"
.line	472	call          r6     3     2
.line	472	settable      r5   k37    r6 ; k37 = "collected"
.line	472	self          r5    r0   k39 ; k39 = "UpdateNewCollectBtn"
.line	472	gettable      r7    r0   k35 ; k35 = "currentItem"
.line	472	call          r5     3     1
.label	l64
.line	472	return        r0     1
.line	472	move          r0    r0
.line	472	return        r0     1

.function	main/f21

.source	null
.linedefined	481
.lastlinedefined	487
.numparams	5
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false

.constant	k0	"rawItemInfo"
.constant	k1	"ModuleManager"
.constant	k2	"GetModule"
.constant	k3	"LobbyModuleConfig"
.constant	k4	"store_limited_subscribe_data"
.constant	k5	"ReceivedTempLimitedSubscribeData"
.constant	k6	"UpdateLimitedSubscribeBtn"
.constant	k7	"currentItem"

.line	481	test          r4     0
.line	481	jmp            0   l16
.line	481	gettable      r5    r0    k0 ; k0 = "rawItemInfo"
.line	481	test          r5     0
.line	481	jmp            0   l16
.line	481	gettabup      r5    u0    k1 ; k1 = "ModuleManager"
.line	481	gettable      r5    r5    k2 ; k2 = "GetModule"
.line	481	gettabup      r6    u0    k1 ; k1 = "ModuleManager"
.line	481	gettable      r6    r6    k3 ; k3 = "LobbyModuleConfig"
.line	481	gettable      r6    r6    k4 ; k4 = "store_limited_subscr" (truncated)
.line	481	call          r5     2     2
.line	481	self          r6    r5    k5 ; k5 = "ReceivedTempLimitedS" (truncated)
.line	481	move          r8    r3
.line	481	gettable      r9    r0    k0 ; k0 = "rawItemInfo"
.line	481	call          r6     4     1
.label	l16
.line	481	self          r5    r0    k6 ; k6 = "UpdateLimitedSubscri" (truncated)
.line	481	gettable      r7    r0    k7 ; k7 = "currentItem"
.line	481	call          r5     3     1
.line	481	return        r0     1
.line	481	move          r0    r0
.line	481	move          r0    r0
.line	481	move          r0    r0
.line	481	return        r0     1

.function	main/f22

.source	null
.linedefined	489
.lastlinedefined	546
.numparams	4
.is_vararg	0
.maxstacksize	51

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	131
.constant	k20	113
.constant	k21	134
.constant	k22	163
.constant	k23	8
.constant	k24	68
.constant	k25	25
.constant	k26	237
.constant	k27	184
.constant	k28	231
.constant	k29	95
.constant	k30	"rawItemInfo"
.constant	k31	"StoreConst"
.constant	k32	"label_item_index_buy_limit"
.constant	k33	"currentItem"
.constant	k34	"next"
.constant	k35	nil
.constant	k36	"purchaseLimitType"
.constant	k37	"purchaseLimitNum"
.constant	k38	"GetBuyInfo"
.constant	k39	"shopId"
.constant	k40	"label_buy_limit_type_daily"
.constant	k41	"hasPurchaseNum"
.constant	k42	"daily_buy_cnt"
.constant	k43	"label_buy_limit_type_week"
.constant	k44	"week_buy_cnt"
.constant	k45	"label_buy_limit_type_permanent"
.constant	k46	"permanet_buy_cnt"
.constant	k47	"isSoldOut"
.constant	k48	"IsSoldOut"
.constant	k49	0
.constant	k50	false
.constant	k51	"require"
.constant	k52	"table"
.constant	k53	"concat"
.constant	k54	129
.constant	k55	77
.constant	k56	100
.constant	k57	104
.constant	k58	76
.constant	k59	145
.constant	k60	142
.constant	k61	18
.constant	k62	78
.constant	k63	187
.constant	k64	165
.constant	k65	246
.constant	k66	191
.constant	k67	42
.constant	k68	243
.constant	k69	39
.constant	k70	69
.constant	k71	122
.constant	k72	170
.constant	k73	227
.constant	k74	29
.constant	k75	53
.constant	k76	247
.constant	k77	188
.constant	k78	214
.constant	k79	59
.constant	k80	190
.constant	k81	83
.constant	k82	143
.constant	k83	171
.constant	k84	130
.constant	k85	221
.constant	k86	140
.constant	k87	80
.constant	k88	96
.constant	k89	"UpdateSubscriptData"
.constant	k90	"tabId"
.constant	k91	"subTabId"
.constant	k92	"UpdateNewBuyBtn"
.constant	k93	"RefreshAllItemWithClick"
.constant	k94	"currentTabID"
.constant	k95	"currentSubTabId"
.constant	k96	"itemEndTime"
.constant	k97	"endTime"
.constant	k98	"bEquip"
.constant	k99	"equiped"
.constant	k100	"discountLimit"
.constant	k101	"disCountPrice"
.constant	k102	"discountDisplay"
.constant	k103	"bIsShowAskTips"
.constant	k104	true
.constant	k105	"sAskTips"
.constant	k106	"LocUtil"
.constant	k107	"GetLocalizeResStr"
.constant	k108	12060003
.constant	k109	"limitBuyInfo"
.constant	k110	"have"
.constant	k111	"discountPrice"
.constant	k112	"finalPrice"
.constant	k113	"showDiscountDesc"
.constant	k114	"isShowLeft"
.constant	k115	"itemValidTime"
.constant	k116	"validTime"
.constant	k117	"ModuleManager"
.constant	k118	"GetModule"
.constant	k119	"LobbyModuleConfig"
.constant	k120	"StoreDetailManager"
.constant	k121	"SetSelectItemDetailInfo"
.constant	k122	"itemId"

.line	489	gettabup      r4    u0    k0 ; k0 = "log"
.line	489	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	489	test          r5     0
.line	489	jmp            0   l39
.line	489	getupval      r5    u1
.line	489	loadk         r6    k2 ; k2 = 234
.line	489	loadk         r7    k3 ; k3 = 153
.line	489	loadk         r8    k4 ; k4 = 75
.line	489	loadk         r9    k5 ; k5 = 115
.line	489	loadk        r10    k6 ; k6 = 99
.line	489	loadk        r11    k7 ; k7 = 127
.line	489	loadk        r12    k8 ; k8 = 218
.line	489	loadk        r13    k9 ; k9 = 147
.line	489	loadk        r14   k10 ; k10 = 27
.line	489	loadk        r15   k11 ; k11 = 73
.line	489	loadk        r16   k12 ; k12 = 43
.line	489	loadk        r17   k13 ; k13 = 249
.line	489	loadk        r18    k3 ; k3 = 153
.line	489	loadk        r19   k14 ; k14 = 248
.line	489	loadk        r20   k15 ; k15 = 79
.line	489	loadk        r21   k16 ; k16 = 179
.line	489	loadk        r22    k5 ; k5 = 115
.line	489	loadk        r23   k17 ; k17 = 146
.line	489	loadk        r24   k18 ; k18 = 58
.line	489	loadk        r25    k5 ; k5 = 115
.line	489	loadk        r26   k19 ; k19 = 131
.line	489	loadk        r27   k20 ; k20 = 113
.line	489	loadk        r28   k21 ; k21 = 134
.line	489	loadk        r29   k22 ; k22 = 163
.line	489	loadk        r30   k23 ; k23 = 8
.line	489	loadk        r31   k24 ; k24 = 68
.line	489	loadk        r32   k25 ; k25 = 25
.line	489	loadk        r33   k26 ; k26 = 237
.line	489	loadk        r34   k27 ; k27 = 184
.line	489	loadk        r35   k28 ; k28 = 231
.line	489	loadk        r36   k29 ; k29 = 95
.line	489	loadk        r37   k22 ; k22 = 163
.line	489	call          r5    33     2
.label	l39
.line	489	call          r4     2     1
.line	489	newtable      r4     0     0
.line	489	gettable      r5    r0   k30 ; k30 = "rawItemInfo"
.line	489	test          r5     0
.line	489	jmp            0   l52
.line	489	gettable      r5    r0   k30 ; k30 = "rawItemInfo"
.line	489	gettabup      r6    u0   k31 ; k31 = "StoreConst"
.line	489	gettable      r6    r6   k32 ; k32 = "label_item_index_buy" (truncated)
.line	489	gettable      r5    r5    r6
.line	489	testset       r4    r5     1
.line	489	jmp            0   l52
.line	489	newtable      r5     0     0
.line	489	move          r4    r5
.label	l52
.line	489	gettable      r5    r0   k33 ; k33 = "currentItem"
.line	489	test          r5     1
.line	489	jmp            0   l56
.line	489	return        r0     1
.label	l56
.line	489	gettabup      r5    u0   k34 ; k34 = "next"
.line	489	move          r6    r4
.line	489	call          r5     2     3
.line	489	eq             1    r5   k35 ; k35 = nil
.line	489	jmp            0  l108
.line	489	gettable      r7    r0   k33 ; k33 = "currentItem"
.line	489	settable      r7   k36    r5 ; k36 = "purchaseLimitType"
.line	489	gettable      r7    r0   k33 ; k33 = "currentItem"
.line	489	settable      r7   k37    r6 ; k37 = "purchaseLimitNum"
.line	489	gettabup      r7    u2   k38 ; k38 = "GetBuyInfo"
.line	489	gettable      r8    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r8    r8   k39 ; k39 = "shopId"
.line	489	call          r7     2     2
.line	489	gettabup      r8    u0   k31 ; k31 = "StoreConst"
.line	489	gettable      r8    r8   k40 ; k40 = "label_buy_limit_type" (truncated)
.line	489	eq             0    r8    r5
.line	489	jmp            0   l77
.line	489	gettable      r8    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r7   k42 ; k42 = "daily_buy_cnt"
.line	489	settable      r8   k41    r9 ; k41 = "hasPurchaseNum"
.line	489	jmp            0   l92
.label	l77
.line	489	gettabup      r8    u0   k31 ; k31 = "StoreConst"
.line	489	gettable      r8    r8   k43 ; k43 = "label_buy_limit_type" (truncated)
.line	489	eq             0    r8    r5
.line	489	jmp            0   l85
.line	489	gettable      r8    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r7   k44 ; k44 = "week_buy_cnt"
.line	489	settable      r8   k41    r9 ; k41 = "hasPurchaseNum"
.line	489	jmp            0   l92
.label	l85
.line	489	gettabup      r8    u0   k31 ; k31 = "StoreConst"
.line	489	gettable      r8    r8   k45 ; k45 = "label_buy_limit_type" (truncated)
.line	489	eq             0    r8    r5
.line	489	jmp            0   l92
.line	489	gettable      r8    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r7   k46 ; k46 = "permanet_buy_cnt"
.line	489	settable      r8   k41    r9 ; k41 = "hasPurchaseNum"
.label	l92
.line	489	gettable      r8    r0   k33 ; k33 = "currentItem"
.line	489	gettabup      r9    u2   k48 ; k48 = "IsSoldOut"
.line	489	gettable     r10    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r10   r10   k39 ; k39 = "shopId"
.line	489	gettabup     r11    u0   k31 ; k31 = "StoreConst"
.line	489	gettable     r11   r11   k40 ; k40 = "label_buy_limit_type" (truncated)
.line	489	gettable     r11    r4   r11
.line	489	gettabup     r12    u0   k31 ; k31 = "StoreConst"
.line	489	gettable     r12   r12   k43 ; k43 = "label_buy_limit_type" (truncated)
.line	489	gettable     r12    r4   r12
.line	489	gettabup     r13    u0   k31 ; k31 = "StoreConst"
.line	489	gettable     r13   r13   k45 ; k45 = "label_buy_limit_type" (truncated)
.line	489	gettable     r13    r4   r13
.line	489	call          r9     5     2
.line	489	settable      r8   k47    r9 ; k47 = "isSoldOut"
.line	489	jmp            0  l116
.label	l108
.line	489	gettable      r7    r0   k33 ; k33 = "currentItem"
.line	489	settable      r7   k36   k49 ; k49 = 0
.line	489	gettable      r7    r0   k33 ; k33 = "currentItem"
.line	489	settable      r7   k37   k49 ; k49 = 0
.line	489	gettable      r7    r0   k33 ; k33 = "currentItem"
.line	489	settable      r7   k41   k49 ; k49 = 0
.line	489	gettable      r7    r0   k33 ; k33 = "currentItem"
.line	489	settable      r7   k47   k50 ; k50 = false
.label	l116
.line	489	gettabup      r7    u0   k51 ; k51 = "require"
.line	489	gettabup      r8    u0   k52 ; k52 = "table"
.line	489	gettable      r8    r8   k53 ; k53 = "concat"
.line	489	newtable      r9     1     0
.line	489	getupval     r10    u1
.line	489	loadk        r11    k8 ; k8 = 218
.line	489	loadk        r12   k54 ; k54 = 129
.line	489	loadk        r13   k55 ; k55 = 77
.line	489	loadk        r14   k56 ; k56 = 100
.line	489	loadk        r15   k57 ; k57 = 104
.line	489	loadk        r16   k58 ; k58 = 76
.line	489	loadk        r17   k59 ; k59 = 145
.line	489	loadk        r18   k60 ; k60 = 142
.line	489	loadk        r19   k61 ; k61 = 18
.line	489	loadk        r20   k62 ; k62 = 78
.line	489	loadk        r21   k12 ; k12 = 43
.line	489	loadk        r22   k63 ; k63 = 187
.line	489	loadk        r23   k64 ; k64 = 165
.line	489	loadk        r24   k65 ; k65 = 246
.line	489	loadk        r25   k15 ; k15 = 79
.line	489	loadk        r26   k66 ; k66 = 191
.line	489	loadk        r27   k67 ; k67 = 42
.line	489	loadk        r28   k68 ; k68 = 243
.line	489	loadk        r29   k69 ; k69 = 39
.line	489	loadk        r30   k70 ; k70 = 69
.line	489	loadk        r31    k3 ; k3 = 153
.line	489	loadk        r32   k71 ; k71 = 122
.line	489	loadk        r33   k72 ; k72 = 170
.line	489	loadk        r34   k73 ; k73 = 227
.line	489	loadk        r35   k74 ; k74 = 29
.line	489	loadk        r36   k29 ; k29 = 95
.line	489	loadk        r37   k75 ; k75 = 53
.line	489	loadk        r38   k76 ; k76 = 247
.line	489	loadk        r39   k77 ; k77 = 188
.line	489	loadk        r40   k78 ; k78 = 214
.line	489	loadk        r41    k4 ; k4 = 75
.line	489	loadk        r42   k16 ; k16 = 179
.line	489	loadk        r43   k79 ; k79 = 59
.line	489	loadk        r44   k80 ; k80 = 190
.line	489	loadk        r45   k69 ; k69 = 39
.line	489	loadk        r46   k81 ; k81 = 83
.line	489	loadk        r47   k82 ; k82 = 143
.line	489	loadk        r48   k57 ; k57 = 104
.line	489	loadk        r49   k83 ; k83 = 171
.line	489	loadk        r50   k84 ; k84 = 130
.line	489	call         r10    41     2
.line	489	getupval     r11    u1
.line	489	loadk        r12   k85 ; k85 = 221
.line	489	loadk        r13   k86 ; k86 = 140
.line	489	loadk        r14   k87 ; k87 = 80
.line	489	loadk        r15   k88 ; k88 = 96
.line	489	call         r11     5     0
.line	489	setlist       r9     0     1
.line	489	call          r8     2     2
.line	489	call          r7     2     2
.line	489	gettable      r8    r7   k89 ; k89 = "UpdateSubscriptData"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9   k39 ; k39 = "shopId"
.line	489	gettable     r10    r0   k90 ; k90 = "tabId"
.line	489	gettable     r11    r0   k91 ; k91 = "subTabId"
.line	489	gettable     r12    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r12   r12   k47 ; k47 = "isSoldOut"
.line	489	call          r8     5     1
.line	489	self          r8    r0   k92 ; k92 = "UpdateNewBuyBtn"
.line	489	gettable     r10    r0   k33 ; k33 = "currentItem"
.line	489	call          r8     3     1
.line	489	self          r8    r0   k93 ; k93 = "RefreshAllItemWithCl" (truncated)
.line	489	loadbool     r10     1     0
.line	489	call          r8     3     1
.line	489	newtable      r8     0    11
.line	489	gettable      r9    r0   k90 ; k90 = "tabId"
.line	489	settable      r8   k94    r9 ; k94 = "currentTabID"
.line	489	gettable      r9    r0   k91 ; k91 = "subTabId"
.line	489	settable      r8   k95    r9 ; k95 = "currentSubTabId"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9   k97 ; k97 = "endTime"
.line	489	settable      r8   k96    r9 ; k96 = "itemEndTime"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9   k99 ; k99 = "equiped"
.line	489	settable      r8   k98    r9 ; k98 = "bEquip"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9   k39 ; k39 = "shopId"
.line	489	settable      r8   k39    r9 ; k39 = "shopId"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k100 ; k100 = "discountLimit"
.line	489	settable      r8  k100    r9 ; k100 = "discountLimit"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k101 ; k101 = "disCountPrice"
.line	489	settable      r8  k101    r9 ; k101 = "disCountPrice"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k102 ; k102 = "discountDisplay"
.line	489	settable      r8  k102    r9 ; k102 = "discountDisplay"
.line	489	settable      r8  k103  k104 ; k104 = true
.line	489	gettabup      r9    u0  k106 ; k106 = "LocUtil"
.line	489	gettable      r9    r9  k107 ; k107 = "GetLocalizeResStr"
.line	489	loadk        r10  k108 ; k108 = 12060003
.line	489	call          r9     2     2
.line	489	settable      r8  k105    r9 ; k105 = "sAskTips"
.line	489	newtable      r9     0     3
.line	489	gettable     r10    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r10   r10   k36 ; k36 = "purchaseLimitType"
.line	489	settable      r9   k36   r10 ; k36 = "purchaseLimitType"
.line	489	gettable     r10    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r10   r10   k37 ; k37 = "purchaseLimitNum"
.line	489	settable      r9   k37   r10 ; k37 = "purchaseLimitNum"
.line	489	gettable     r10    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r10   r10   k41 ; k41 = "hasPurchaseNum"
.line	489	settable      r9   k41   r10 ; k41 = "hasPurchaseNum"
.line	489	settable      r8  k109    r9 ; k109 = "limitBuyInfo"
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9   k47 ; k47 = "isSoldOut"
.line	489	eq             1    r9  k104 ; k104 = true
.line	489	jmp            0  l240
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k110 ; k110 = "have"
.line	489	eq             1    r9  k104 ; k104 = true
.line	489	jmp            0  l240
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k111 ; k111 = "discountPrice"
.line	489	gettable     r10    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r10   r10  k112 ; k112 = "finalPrice"
.line	489	eq             1    r9   r10
.line	489	jmp            0  l240
.line	489	settable      r8  k113  k104 ; k104 = true
.label	l240
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k114 ; k114 = "isShowLeft"
.line	489	test          r9     0
.line	489	jmp            0  l247
.line	489	gettable      r9    r0   k33 ; k33 = "currentItem"
.line	489	gettable      r9    r9  k116 ; k116 = "validTime"
.line	489	settable      r8  k115    r9 ; k115 = "itemValidTime"
.label	l247
.line	489	gettabup      r9    u0  k117 ; k117 = "ModuleManager"
.line	489	gettable      r9    r9  k118 ; k118 = "GetModule"
.line	489	gettabup     r10    u0  k117 ; k117 = "ModuleManager"
.line	489	gettable     r10   r10  k119 ; k119 = "LobbyModuleConfig"
.line	489	gettable     r10   r10  k120 ; k120 = "StoreDetailManager"
.line	489	call          r9     2     2
.line	489	self         r10    r9  k121 ; k121 = "SetSelectItemDetailI" (truncated)
.line	489	gettable     r12    r0   k33 ; k33 = "currentItem"
.line	489	gettable     r12   r12  k122 ; k122 = "itemId"
.line	489	move         r13    r8
.line	489	call         r10     4     1
.line	489	return        r0     1
.line	489	move          r0    r0
.line	489	gettabup      r3    u0  k108 ; k108 = 12060003
.line	489	move          r0    r0
.line	489	return        r0     1

.function	main/f23

.source	null
.linedefined	548
.lastlinedefined	607
.numparams	4
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	131
.constant	k20	113
.constant	k21	157
.constant	k22	168
.constant	k23	29
.constant	k24	94
.constant	k25	54
.constant	k26	241
.constant	k27	"info"
.constant	k28	"pairs"
.constant	k29	"CheckIsChest"
.constant	k30	"StoreConst"
.constant	k31	"label_buy_rsp_item_id"
.constant	k32	false
.constant	k33	"res_id"
.constant	k34	"count"
.constant	k35	"label_buy_rsp_item_count"
.constant	k36	"valid_hours"
.constant	k37	"label_buy_rsp_item_valid"
.constant	k38	"expire_ts"
.constant	k39	0
.constant	k40	"color_id"
.constant	k41	"pattern_id"
.constant	k42	"ShowUseTime"
.constant	k43	true
.constant	k44	"table"
.constant	k45	"insert"
.constant	k46	"ModuleManager"
.constant	k47	"GetModule"
.constant	k48	"LobbyModuleConfig"
.constant	k49	"logic_theme_system"
.constant	k50	"require"
.constant	k51	129
.constant	k52	77
.constant	k53	100
.constant	k54	104
.constant	k55	76
.constant	k56	145
.constant	k57	17
.constant	k58	92
.constant	k59	35
.constant	k60	246
.constant	k61	231
.constant	k62	185
.constant	k63	59
.constant	k64	184
.constant	k65	122
.constant	k66	86
.constant	k67	101
.constant	k68	144
.constant	k69	191
.constant	k70	11
.constant	k71	91
.constant	k72	53
.constant	k73	247
.constant	k74	173
.constant	k75	214
.constant	k76	178
.constant	k77	48
.constant	k78	161
.constant	k79	55
.constant	k80	"concat"
.constant	k81	162
.constant	k82	32
.constant	k83	171
.constant	k84	61
.constant	k85	69
.constant	k86	143
.constant	k87	38
.constant	k88	163
.constant	k89	9
.constant	k90	66
.constant	k91	57
.constant	k92	175
.constant	k93	47
.constant	k94	164
.constant	k95	88
.constant	k96	106
.constant	k97	186
.constant	k98	216
.constant	k99	65
.constant	k100	142
.constant	k101	18
.constant	k102	78
.constant	k103	187
.constant	k104	165
.constant	k105	42
.constant	k106	243
.constant	k107	155
.constant	k108	160
.constant	k109	64
.constant	k110	232
.constant	k111	180
.constant	k112	230
.constant	k113	45
.constant	k114	41
.constant	k115	102
.constant	k116	108
.constant	k117	138
.constant	k118	98
.constant	k119	89
.constant	k120	123
.constant	k121	208
.constant	k122	19
.constant	k123	84
.constant	k124	36
.constant	k125	220
.constant	k126	189
.constant	k127	252
.constant	k128	44
.constant	k129	169
.constant	k130	56
.constant	k131	148
.constant	k132	182
.constant	k133	15
.constant	k134	72
.constant	k135	46
.constant	k136	236
.constant	k137	224
.constant	k138	119
.constant	k139	70
.constant	k140	128
.constant	k141	177
.constant	k142	137
.constant	k143	116
.constant	k144	103
.constant	k145	219
.constant	k146	31
.constant	k147	"IsRebateBuyItem"
.constant	k148	"market_id"
.constant	k149	"ShowPanel_TwoBtnStyle"
.constant	k150	"LocUtil"
.constant	k151	"GetLocalizeResStr"
.constant	k152	7660
.constant	k153	"CheckThemeOfflineChest"
.constant	k154	"ShowPanel_DefaultStyle"
.constant	k155	"fCloseCallback"
.constant	k156	"IsShowSportsCarGet"
.constant	k157	1
.constant	k158	"ShowSportsCarGet"
.constant	k159	"subTabId"
.constant	k160	"label_subtype_voice_chip"
.constant	k161	"GlobalData"
.constant	k162	"IsJapanOrKorea"
.constant	k163	"currentItem"
.constant	k164	"have"
.constant	k165	"RefreshItemWithClick"
.constant	k166	"currIndex"
.constant	k167	"tabId"
.constant	k168	"Page_New_ID_Treasure"
.constant	k169	"IsKrJpTreasure"
.constant	k170	"SortItemListByFilter"
.constant	k171	"RefreshAllItemWithClick"
.constant	k172	"subTab"
.constant	k173	"label_subtype_lucky_bag"
.constant	k174	"require"
.constant	k175	"table"
.constant	k176	"concat"
.constant	k177	218
.constant	k178	129
.constant	k179	77
.constant	k180	100
.constant	k181	104
.constant	k182	76
.constant	k183	145
.constant	k184	142
.constant	k185	18
.constant	k186	78
.constant	k187	43
.constant	k188	187
.constant	k189	170
.constant	k190	246
.constant	k191	70
.constant	k192	176
.constant	k193	32
.constant	k194	186
.constant	k195	122
.constant	k196	69
.constant	k197	154
.constant	k198	103
.constant	k199	168
.constant	k200	227
.constant	k201	26
.constant	k202	71
.constant	k203	53
.constant	k204	226
.constant	k205	134
.constant	k206	251
.constant	k207	93
.constant	k208	182
.constant	k209	54
.constant	k210	191
.constant	k211	48
.constant	k212	126
.constant	k213	147
.constant	k214	108
.constant	k215	177
.constant	k216	202
.constant	k217	"ReportTLogEvent"
.constant	k218	"TLogEventDefine"
.constant	k219	"Store_Lucky_Bag"
.constant	k220	"shopId"
.constant	k221	"UpdateNewBuyBtn"
.constant	k222	"itemId"
.constant	k223	"OnBuyInfoChange"

.line	548	gettabup      r4    u0    k0 ; k0 = "log"
.line	548	gettabup      r5    u0    k1 ; k1 = "bWriteLog"
.line	548	test          r5     0
.line	548	jmp            0   l35
.line	548	getupval      r5    u1
.line	548	loadk         r6    k2 ; k2 = 234
.line	548	loadk         r7    k3 ; k3 = 153
.line	548	loadk         r8    k4 ; k4 = 75
.line	548	loadk         r9    k5 ; k5 = 115
.line	548	loadk        r10    k6 ; k6 = 99
.line	548	loadk        r11    k7 ; k7 = 127
.line	548	loadk        r12    k8 ; k8 = 218
.line	548	loadk        r13    k9 ; k9 = 147
.line	548	loadk        r14   k10 ; k10 = 27
.line	548	loadk        r15   k11 ; k11 = 73
.line	548	loadk        r16   k12 ; k12 = 43
.line	548	loadk        r17   k13 ; k13 = 249
.line	548	loadk        r18    k3 ; k3 = 153
.line	548	loadk        r19   k14 ; k14 = 248
.line	548	loadk        r20   k15 ; k15 = 79
.line	548	loadk        r21   k16 ; k16 = 179
.line	548	loadk        r22    k5 ; k5 = 115
.line	548	loadk        r23   k17 ; k17 = 146
.line	548	loadk        r24   k18 ; k18 = 58
.line	548	loadk        r25    k5 ; k5 = 115
.line	548	loadk        r26   k19 ; k19 = 131
.line	548	loadk        r27   k20 ; k20 = 113
.line	548	loadk        r28   k21 ; k21 = 157
.line	548	loadk        r29   k22 ; k22 = 168
.line	548	loadk        r30   k23 ; k23 = 29
.line	548	loadk        r31   k24 ; k24 = 94
.line	548	loadk        r32   k25 ; k25 = 54
.line	548	loadk        r33   k26 ; k26 = 241
.line	548	call          r5    29     2
.label	l35
.line	548	call          r4     2     1
.line	548	gettable      r4    r3   k27 ; k27 = "info"
.line	548	newtable      r5     0     0
.line	548	gettabup      r6    u0   k28 ; k28 = "pairs"
.line	548	move          r7    r4
.line	548	call          r6     2     4
.line	548	jmp            0   l71
.line	548	gettabup     r11    u2   k29 ; k29 = "CheckIsChest"
.line	548	gettabup     r12    u0   k30 ; k30 = "StoreConst"
.line	548	gettable     r12   r12   k31 ; k31 = "label_buy_rsp_item_i" (truncated)
.line	548	gettable     r12   r10   r12
.line	548	call         r11     2     2
.line	548	eq             0   r11   k32 ; k32 = false
.line	548	jmp            0   l71
.line	548	newtable     r11     0     7
.line	548	gettabup     r12    u0   k30 ; k30 = "StoreConst"
.line	548	gettable     r12   r12   k31 ; k31 = "label_buy_rsp_item_i" (truncated)
.line	548	gettable     r12   r10   r12
.line	548	settable     r11   k33   r12 ; k33 = "res_id"
.line	548	gettabup     r12    u0   k30 ; k30 = "StoreConst"
.line	548	gettable     r12   r12   k35 ; k35 = "label_buy_rsp_item_c" (truncated)
.line	548	gettable     r12   r10   r12
.line	548	settable     r11   k34   r12 ; k34 = "count"
.line	548	gettabup     r12    u0   k30 ; k30 = "StoreConst"
.line	548	gettable     r12   r12   k37 ; k37 = "label_buy_rsp_item_v" (truncated)
.line	548	gettable     r12   r10   r12
.line	548	settable     r11   k36   r12 ; k36 = "valid_hours"
.line	548	settable     r11   k38   k39 ; k39 = 0
.line	548	settable     r11   k40   k39 ; k39 = 0
.line	548	settable     r11   k41   k39 ; k39 = 0
.line	548	settable     r11   k42   k43 ; k43 = true
.line	548	gettabup     r12    u0   k44 ; k44 = "table"
.line	548	gettable     r12   r12   k45 ; k45 = "insert"
.line	548	move         r13    r5
.line	548	move         r14   r11
.line	548	call         r12     3     1
.label	l71
.line	548	move          r0    r0
.line	548	move          r0    r0
.line	548	gettabup      r6    u0   k46 ; k46 = "ModuleManager"
.line	548	gettable      r6    r6   k47 ; k47 = "GetModule"
.line	548	gettabup      r7    u0   k46 ; k46 = "ModuleManager"
.line	548	gettable      r7    r7   k48 ; k48 = "LobbyModuleConfig"
.line	548	gettable      r7    r7   k49 ; k49 = "logic_theme_system"
.line	548	call          r6     2     2
.line	548	len           r7    r5
.line	548	lt             0   k39    r7 ; k39 = 0
.line	548	jmp            0  l347
.line	548	gettabup      r7    u0   k50 ; k50 = "require"
.line	548	getupval      r8    u1
.line	548	loadk         r9    k8 ; k8 = 218
.line	548	loadk        r10   k51 ; k51 = 129
.line	548	loadk        r11   k52 ; k52 = 77
.line	548	loadk        r12   k53 ; k53 = 100
.line	548	loadk        r13   k54 ; k54 = 104
.line	548	loadk        r14   k55 ; k55 = 76
.line	548	loadk        r15   k56 ; k56 = 145
.line	548	loadk        r16   k56 ; k56 = 145
.line	548	loadk        r17   k57 ; k57 = 17
.line	548	loadk        r18   k58 ; k58 = 92
.line	548	loadk        r19   k59 ; k59 = 35
.line	548	loadk        r20   k60 ; k60 = 246
.line	548	loadk        r21   k61 ; k61 = 231
.line	548	loadk        r22    k2 ; k2 = 234
.line	548	loadk        r23   k58 ; k58 = 92
.line	548	loadk        r24   k62 ; k62 = 185
.line	548	loadk        r25   k63 ; k63 = 59
.line	548	loadk        r26   k64 ; k64 = 184
.line	548	loadk        r27   k65 ; k65 = 122
.line	548	loadk        r28   k66 ; k66 = 86
.line	548	loadk        r29    k9 ; k9 = 147
.line	548	loadk        r30   k67 ; k67 = 101
.line	548	loadk        r31   k68 ; k68 = 144
.line	548	loadk        r32   k69 ; k69 = 191
.line	548	loadk        r33   k70 ; k70 = 11
.line	548	loadk        r34   k71 ; k71 = 91
.line	548	loadk        r35   k72 ; k72 = 53
.line	548	loadk        r36   k73 ; k73 = 247
.line	548	loadk        r37   k74 ; k74 = 173
.line	548	loadk        r38   k75 ; k75 = 214
.line	548	loadk        r39   k52 ; k52 = 77
.line	548	loadk        r40   k76 ; k76 = 178
.line	548	loadk        r41   k77 ; k77 = 48
.line	548	loadk        r42   k78 ; k78 = 161
.line	548	loadk        r43   k79 ; k79 = 55
.line	548	call          r8    36     2
.line	548	call          r7     2     2
.line	548	gettabup      r8    u0   k50 ; k50 = "require"
.line	548	gettabup      r9    u0   k44 ; k44 = "table"
.line	548	gettable      r9    r9   k80 ; k80 = "concat"
.line	548	newtable     r10     1     0
.line	548	getupval     r11    u1
.line	548	loadk        r12    k8 ; k8 = 218
.line	548	loadk        r13   k51 ; k51 = 129
.line	548	loadk        r14   k52 ; k52 = 77
.line	548	loadk        r15   k53 ; k53 = 100
.line	548	loadk        r16   k54 ; k54 = 104
.line	548	loadk        r17   k55 ; k55 = 76
.line	548	loadk        r18   k56 ; k56 = 145
.line	548	loadk        r19   k56 ; k56 = 145
.line	548	loadk        r20   k57 ; k57 = 17
.line	548	loadk        r21   k58 ; k58 = 92
.line	548	loadk        r22   k59 ; k59 = 35
.line	548	loadk        r23   k60 ; k60 = 246
.line	548	loadk        r24   k61 ; k61 = 231
.line	548	loadk        r25   k14 ; k14 = 248
.line	548	loadk        r26    k4 ; k4 = 75
.line	548	loadk        r27   k81 ; k81 = 162
.line	548	loadk        r28   k82 ; k82 = 32
.line	548	loadk        r29   k83 ; k83 = 171
.line	548	loadk        r30   k84 ; k84 = 61
.line	548	loadk        r31   k85 ; k85 = 69
.line	548	loadk        r32   k86 ; k86 = 143
.line	548	loadk        r33   k87 ; k87 = 38
.line	548	loadk        r34   k88 ; k88 = 163
.line	548	loadk        r35   k81 ; k81 = 162
.line	548	loadk        r36   k89 ; k89 = 9
.line	548	loadk        r37   k90 ; k90 = 66
.line	548	loadk        r38   k91 ; k91 = 57
.line	548	loadk        r39    k8 ; k8 = 218
.line	548	loadk        r40   k64 ; k64 = 184
.line	548	loadk        r41    k2 ; k2 = 234
.line	548	loadk        r42   k55 ; k55 = 76
.line	548	loadk        r43   k92 ; k92 = 175
.line	548	loadk        r44   k93 ; k93 = 47
.line	548	loadk        r45   k94 ; k94 = 164
.line	548	loadk        r46   k77 ; k77 = 48
.line	548	loadk        r47   k95 ; k95 = 88
.line	548	loadk        r48   k62 ; k62 = 185
.line	548	loadk        r49   k96 ; k96 = 106
.line	548	loadk        r50   k97 ; k97 = 186
.line	548	loadk        r51   k69 ; k69 = 191
.line	548	call         r11    41     2
.line	548	getupval     r12    u1
.line	548	loadk        r13   k98 ; k98 = 216
.line	548	loadk        r14    k3 ; k3 = 153
.line	548	loadk        r15   k99 ; k99 = 65
.line	548	call         r12     4     0
.line	548	setlist      r10     0     1
.line	548	call          r9     2     2
.line	548	call          r8     2     2
.line	548	gettabup      r9    u0   k50 ; k50 = "require"
.line	548	gettabup     r10    u0   k44 ; k44 = "table"
.line	548	gettable     r10   r10   k80 ; k80 = "concat"
.line	548	newtable     r11     1     0
.line	548	getupval     r12    u1
.line	548	loadk        r13    k8 ; k8 = 218
.line	548	loadk        r14   k51 ; k51 = 129
.line	548	loadk        r15   k52 ; k52 = 77
.line	548	loadk        r16   k53 ; k53 = 100
.line	548	loadk        r17   k54 ; k54 = 104
.line	548	loadk        r18   k55 ; k55 = 76
.line	548	loadk        r19   k56 ; k56 = 145
.line	548	loadk        r20  k100 ; k100 = 142
.line	548	loadk        r21  k101 ; k101 = 18
.line	548	loadk        r22  k102 ; k102 = 78
.line	548	loadk        r23   k12 ; k12 = 43
.line	548	loadk        r24  k103 ; k103 = 187
.line	548	loadk        r25  k104 ; k104 = 165
.line	548	loadk        r26   k60 ; k60 = 246
.line	548	loadk        r27   k15 ; k15 = 79
.line	548	loadk        r28   k69 ; k69 = 191
.line	548	loadk        r29  k105 ; k105 = 42
.line	548	loadk        r30  k106 ; k106 = 243
.line	548	loadk        r31   k79 ; k79 = 55
.line	548	loadk        r32   k24 ; k24 = 94
.line	548	loadk        r33  k107 ; k107 = 155
.line	548	loadk        r34   k67 ; k67 = 101
.line	548	loadk        r35  k108 ; k108 = 160
.line	548	loadk        r36   k88 ; k88 = 163
.line	548	loadk        r37  k109 ; k109 = 64
.line	548	loadk        r38   k54 ; k54 = 104
.line	548	loadk        r39   k72 ; k72 = 53
.line	548	loadk        r40  k110 ; k110 = 232
.line	548	loadk        r41  k111 ; k111 = 180
.line	548	loadk        r42  k112 ; k112 = 230
.line	548	loadk        r43   k66 ; k66 = 86
.line	548	loadk        r44   k86 ; k86 = 143
.line	548	loadk        r45  k113 ; k113 = 45
.line	548	loadk        r46   k22 ; k22 = 168
.line	548	loadk        r47  k114 ; k114 = 41
.line	548	loadk        r48  k115 ; k115 = 102
.line	548	loadk        r49   k19 ; k19 = 131
.line	548	loadk        r50  k116 ; k116 = 108
.line	548	loadk        r51   k26 ; k26 = 241
.line	548	loadk        r52   k56 ; k56 = 145
.line	548	call         r12    41     2
.line	548	getupval     r13    u1
.line	548	loadk        r14   k75 ; k75 = 214
.line	548	loadk        r15  k117 ; k117 = 138
.line	548	loadk        r16   k52 ; k52 = 77
.line	548	loadk        r17  k118 ; k118 = 98
.line	548	loadk        r18  k119 ; k119 = 89
.line	548	loadk        r19  k120 ; k120 = 123
.line	548	loadk        r20  k121 ; k121 = 208
.line	548	loadk        r21   k68 ; k68 = 144
.line	548	loadk        r22  k122 ; k122 = 19
.line	548	loadk        r23  k123 ; k123 = 84
.line	548	loadk        r24  k124 ; k124 = 36
.line	548	loadk        r25  k125 ; k125 = 220
.line	548	loadk        r26  k126 ; k126 = 189
.line	548	loadk        r27  k127 ; k127 = 252
.line	548	loadk        r28   k85 ; k85 = 69
.line	548	loadk        r29   k56 ; k56 = 145
.line	548	loadk        r30  k128 ; k128 = 44
.line	548	loadk        r31  k129 ; k129 = 169
.line	548	call         r13    19     0
.line	548	setlist      r11     0     1
.line	548	call         r10     2     2
.line	548	call          r9     2     2
.line	548	gettabup     r10    u0   k50 ; k50 = "require"
.line	548	gettabup     r11    u0   k44 ; k44 = "table"
.line	548	gettable     r11   r11   k80 ; k80 = "concat"
.line	548	newtable     r12     1     0
.line	548	getupval     r13    u1
.line	548	loadk        r14    k8 ; k8 = 218
.line	548	loadk        r15   k51 ; k51 = 129
.line	548	loadk        r16   k52 ; k52 = 77
.line	548	loadk        r17   k53 ; k53 = 100
.line	548	loadk        r18   k54 ; k54 = 104
.line	548	loadk        r19   k55 ; k55 = 76
.line	548	loadk        r20   k56 ; k56 = 145
.line	548	loadk        r21  k100 ; k100 = 142
.line	548	loadk        r22  k101 ; k101 = 18
.line	548	loadk        r23  k102 ; k102 = 78
.line	548	loadk        r24   k12 ; k12 = 43
.line	548	loadk        r25  k103 ; k103 = 187
.line	548	loadk        r26  k104 ; k104 = 165
.line	548	loadk        r27   k60 ; k60 = 246
.line	548	loadk        r28   k15 ; k15 = 79
.line	548	loadk        r29   k69 ; k69 = 191
.line	548	loadk        r30  k105 ; k105 = 42
.line	548	loadk        r31  k106 ; k106 = 243
.line	548	loadk        r32  k130 ; k130 = 56
.line	548	loadk        r33   k24 ; k24 = 94
.line	548	loadk        r34  k131 ; k131 = 148
.line	548	loadk        r35   k96 ; k96 = 106
.line	548	loadk        r36  k132 ; k132 = 182
.line	548	loadk        r37   k17 ; k17 = 146
.line	548	loadk        r38  k133 ; k133 = 15
.line	548	loadk        r39  k134 ; k134 = 72
.line	548	loadk        r40  k135 ; k135 = 46
.line	548	loadk        r41  k136 ; k136 = 236
.line	548	loadk        r42   k92 ; k92 = 175
.line	548	loadk        r43  k137 ; k137 = 224
.line	548	loadk        r44   k55 ; k55 = 76
.line	548	loadk        r45   k69 ; k69 = 191
.line	548	loadk        r46  k138 ; k138 = 119
.line	548	loadk        r47   k78 ; k78 = 161
.line	548	loadk        r48   k12 ; k12 = 43
.line	548	loadk        r49  k139 ; k139 = 70
.line	548	loadk        r50   k86 ; k86 = 143
.line	548	loadk        r51  k120 ; k120 = 123
.line	548	loadk        r52  k140 ; k140 = 128
.line	548	loadk        r53  k141 ; k141 = 177
.line	548	call         r13    41     2
.line	548	getupval     r14    u1
.line	548	loadk        r15   k98 ; k98 = 216
.line	548	loadk        r16  k142 ; k142 = 137
.line	548	loadk        r17  k109 ; k109 = 64
.line	548	loadk        r18   k53 ; k53 = 100
.line	548	loadk        r19  k143 ; k143 = 116
.line	548	loadk        r20  k144 ; k144 = 103
.line	548	loadk        r21  k145 ; k145 = 219
.line	548	loadk        r22   k86 ; k86 = 143
.line	548	loadk        r23  k146 ; k146 = 31
.line	548	loadk        r24   k55 ; k55 = 76
.line	548	call         r14    11     0
.line	548	setlist      r12     0     1
.line	548	call         r11     2     2
.line	548	call         r10     2     2
.line	548	gettable     r11    r8  k147 ; k147 = "IsRebateBuyItem"
.line	548	gettable     r12    r3  k148 ; k148 = "market_id"
.line	548	call         r11     2     2
.line	548	test         r11     0
.line	548	jmp            0  l319
.line	548	gettable     r11    r9  k149 ; k149 = "ShowPanel_TwoBtnStyl" (truncated)
.line	548	move         r12    r5
.line	548	gettabup     r13    u0  k150 ; k150 = "LocUtil"
.line	548	gettable     r13   r13  k151 ; k151 = "GetLocalizeResStr"
.line	548	loadk        r14  k152 ; k152 = 7660
.line	548	call         r13     2     2
.line	548	closure      r14    f0
.line	548	call         r11     4     1
.line	548	jmp            8  l347
.label	l319
.line	548	self         r11    r6  k153 ; k153 = "CheckThemeOfflineChe" (truncated)
.line	548	move         r13    r5
.line	548	call         r11     3     2
.line	548	test         r11     0
.line	548	jmp            0  l333
.line	548	gettable     r11    r9  k154 ; k154 = "ShowPanel_DefaultSty" (truncated)
.line	548	move         r12    r5
.line	548	loadnil      r13     0
.line	548	loadbool     r14     0     0
.line	548	newtable     r15     0     1
.line	548	closure      r16    f1
.line	548	settable     r15  k155   r16 ; k155 = "fCloseCallback"
.line	548	call         r11     5     1
.line	548	jmp            8  l347
.label	l333
.line	548	gettable     r11   r10  k156 ; k156 = "IsShowSportsCarGet"
.line	548	gettable     r12    r5  k157 ; k157 = 1
.line	548	gettable     r12   r12   k33 ; k33 = "res_id"
.line	548	call         r11     2     2
.line	548	test         r11     0
.line	548	jmp            0  l343
.line	548	gettable     r11   r10  k158 ; k158 = "ShowSportsCarGet"
.line	548	move         r12    r5
.line	548	call         r11     2     1
.line	548	jmp            8  l347
.label	l343
.line	548	gettable     r11    r9  k154 ; k154 = "ShowPanel_DefaultSty" (truncated)
.line	548	move         r12    r5
.line	548	call         r11     2     1
.line	548	jmp            8  l347
.label	l347
.line	548	gettable      r7    r0  k159 ; k159 = "subTabId"
.line	548	gettabup      r8    u0   k30 ; k30 = "StoreConst"
.line	548	gettable      r8    r8  k160 ; k160 = "label_subtype_voice_" (truncated)
.line	548	eq             0    r7    r8
.line	548	jmp            0  l364
.line	548	gettabup      r7    u0  k161 ; k161 = "GlobalData"
.line	548	gettable      r7    r7  k162 ; k162 = "IsJapanOrKorea"
.line	548	call          r7     1     2
.line	548	test          r7     0
.line	548	jmp            0  l364
.line	548	gettable      r7    r0  k163 ; k163 = "currentItem"
.line	548	settable      r7  k164   k43 ; k43 = true
.line	548	self          r7    r0  k165 ; k165 = "RefreshItemWithClick"
.line	548	gettable      r9    r0  k166 ; k166 = "currIndex"
.line	548	loadbool     r10     1     0
.line	548	call          r7     4     1
.line	548	jmp            0  l379
.label	l364
.line	548	gettable      r7    r0  k167 ; k167 = "tabId"
.line	548	gettabup      r8    u0   k30 ; k30 = "StoreConst"
.line	548	gettable      r8    r8  k168 ; k168 = "Page_New_ID_Treasure"
.line	548	eq             1    r7    r8
.line	548	jmp            0  l374
.line	548	gettabup      r7    u2  k169 ; k169 = "IsKrJpTreasure"
.line	548	gettable      r8    r0  k167 ; k167 = "tabId"
.line	548	call          r7     2     2
.line	548	test          r7     0
.line	548	jmp            0  l379
.label	l374
.line	548	self          r7    r0  k170 ; k170 = "SortItemListByFilter"
.line	548	call          r7     2     1
.line	548	self          r7    r0  k171 ; k171 = "RefreshAllItemWithCl" (truncated)
.line	548	loadbool      r9     1     0
.line	548	call          r7     3     1
.label	l379
.line	548	gettable      r7    r0  k163 ; k163 = "currentItem"
.line	548	gettable      r7    r7  k172 ; k172 = "subTab"
.line	548	gettabup      r8    u0   k30 ; k30 = "StoreConst"
.line	548	gettable      r8    r8  k173 ; k173 = "label_subtype_lucky_" (truncated)
.line	548	eq             0    r7    r8
.line	548	jmp            0  l450
.line	548	gettabup      r7    u0  k161 ; k161 = "GlobalData"
.line	548	gettable      r7    r7  k162 ; k162 = "IsJapanOrKorea"
.line	548	call          r7     1     2
.line	548	test          r7     0
.line	548	jmp            0  l450
.line	548	gettabup      r7    u0  k174 ; k174 = "require"
.line	548	gettabup      r8    u0  k175 ; k175 = "table"
.line	548	gettable      r8    r8  k176 ; k176 = "concat"
.line	548	newtable      r9     1     0
.line	548	getupval     r10    u1
.line	548	loadk        r11  k177 ; k177 = 218
.line	548	loadk        r12  k178 ; k178 = 129
.line	548	loadk        r13  k179 ; k179 = 77
.line	548	loadk        r14  k180 ; k180 = 100
.line	548	loadk        r15  k181 ; k181 = 104
.line	548	loadk        r16  k182 ; k182 = 76
.line	548	loadk        r17  k183 ; k183 = 145
.line	548	loadk        r18  k184 ; k184 = 142
.line	548	loadk        r19  k185 ; k185 = 18
.line	548	loadk        r20  k186 ; k186 = 78
.line	548	loadk        r21  k187 ; k187 = 43
.line	548	loadk        r22  k188 ; k188 = 187
.line	548	loadk        r23  k189 ; k189 = 170
.line	548	loadk        r24  k190 ; k190 = 246
.line	548	loadk        r25  k191 ; k191 = 70
.line	548	loadk        r26  k192 ; k192 = 176
.line	548	loadk        r27  k193 ; k193 = 32
.line	548	loadk        r28  k194 ; k194 = 186
.line	548	loadk        r29  k195 ; k195 = 122
.line	548	loadk        r30  k196 ; k196 = 69
.line	548	loadk        r31  k197 ; k197 = 154
.line	548	loadk        r32  k198 ; k198 = 103
.line	548	loadk        r33  k199 ; k199 = 168
.line	548	loadk        r34  k200 ; k200 = 227
.line	548	loadk        r35  k201 ; k201 = 26
.line	548	loadk        r36  k202 ; k202 = 71
.line	548	loadk        r37  k203 ; k203 = 53
.line	548	loadk        r38  k204 ; k204 = 226
.line	548	loadk        r39  k205 ; k205 = 134
.line	548	loadk        r40  k206 ; k206 = 251
.line	548	loadk        r41  k207 ; k207 = 93
.line	548	loadk        r42  k208 ; k208 = 182
.line	548	loadk        r43  k209 ; k209 = 54
.line	548	loadk        r44  k210 ; k210 = 191
.line	548	loadk        r45  k211 ; k211 = 48
.line	548	loadk        r46  k212 ; k212 = 126
.line	548	loadk        r47  k213 ; k213 = 147
.line	548	loadk        r48  k214 ; k214 = 108
.line	548	loadk        r49  k208 ; k208 = 182
.line	548	loadk        r50  k215 ; k215 = 177
.line	548	call         r10    41     2
.line	548	getupval     r11    u1
.line	548	loadk        r12  k216 ; k216 = 202
.line	548	call         r11     2     0
.line	548	setlist       r9     0     1
.line	548	call          r8     2     2
.line	548	call          r7     2     2
.line	548	gettable      r8    r7  k217 ; k217 = "ReportTLogEvent"
.line	548	gettabup      r9    u0  k218 ; k218 = "TLogEventDefine"
.line	548	gettable      r9    r9  k219 ; k219 = "Store_Lucky_Bag"
.line	548	gettable     r10    r0  k163 ; k163 = "currentItem"
.line	548	gettable     r10   r10  k220 ; k220 = "shopId"
.line	548	gettable     r11    r5  k157 ; k157 = 1
.line	548	gettable     r11   r11   k34 ; k34 = "count"
.line	548	call          r8     4     1
.label	l450
.line	548	self          r7    r0  k221 ; k221 = "UpdateNewBuyBtn"
.line	548	gettable      r9    r0  k163 ; k163 = "currentItem"
.line	548	call          r7     3     1
.line	548	gettabup      r7    u2   k29 ; k29 = "CheckIsChest"
.line	548	gettable      r8    r0  k163 ; k163 = "currentItem"
.line	548	gettable      r8    r8  k222 ; k222 = "itemId"
.line	548	call          r7     2     2
.line	548	test          r7     0
.line	548	jmp            0  l464
.line	548	self          r7    r0  k223 ; k223 = "OnBuyInfoChange"
.line	548	move          r9    r1
.line	548	move         r10    r2
.line	548	move         r11    r3
.line	548	call          r7     5     1
.label	l464
.line	548	return        r0     1
.line	548	gettabup      r1    u0  k154 ; k154 = "ShowPanel_DefaultSty" (truncated)
.line	548	return        r0     1

.function	main/f23/f0

.source	null
.linedefined	573
.lastlinedefined	579
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false
.upvalue	"U2"	7	true

.constant	k0	"EventSystem"
.constant	k1	"postEvent"
.constant	k2	"EVENTTYPE_STORE"
.constant	k3	"EVENTID_STORE_CRATE_CLOSE"
.constant	k4	"GlobalData"
.constant	k5	"JumpUrl"
.constant	k6	222
.constant	k7	140
.constant	k8	73
.constant	k9	100
.constant	k10	60
.constant	k11	23
.constant	k12	144
.constant	k13	194
.constant	k14	19
.constant	k15	84
.constant	k16	46
.constant	k17	224
.constant	k18	165
.constant	k19	252
.constant	k20	21
.constant	k21	231
.constant	k22	121
.constant	k23	237
.constant	k24	101
.constant	k25	2
.constant	k26	198
.constant	k27	56
.constant	k28	233
.constant	k29	164
.constant	k30	10
.constant	k31	22
.constant	k32	104
.constant	k33	181
.constant	k34	232
.constant	k35	176
.constant	k36	8
.constant	k37	254
.constant	k38	105
.constant	k39	244
.constant	k40	125
.constant	k41	24
.constant	k42	"ReportBtnClickEvent"
.constant	k43	"SubEventName_Rebate_GoToActivity"
.constant	k44	"require"
.constant	k45	"table"
.constant	k46	"concat"
.constant	k47	218
.constant	k48	129
.constant	k49	77
.constant	k50	76
.constant	k51	145
.constant	k52	142
.constant	k53	18
.constant	k54	78
.constant	k55	43
.constant	k56	187
.constant	k57	170
.constant	k58	246
.constant	k59	70
.constant	k60	32
.constant	k61	186
.constant	k62	122
.constant	k63	69
.constant	k64	154
.constant	k65	103
.constant	k66	168
.constant	k67	227
.constant	k68	26
.constant	k69	71
.constant	k70	53
.constant	k71	226
.constant	k72	134
.constant	k73	251
.constant	k74	93
.constant	k75	182
.constant	k76	54
.constant	k77	191
.constant	k78	48
.constant	k79	126
.constant	k80	147
.constant	k81	108
.constant	k82	177
.constant	k83	202
.constant	k84	"ReportTLogEvent"
.constant	k85	"TLogEventDefine"
.constant	k86	"Rebate_GoToActivity"

.line	573	gettabup      r0    u0    k0 ; k0 = "EventSystem"
.line	573	self          r0    r0    k1 ; k1 = "postEvent"
.line	573	gettabup      r2    u0    k2 ; k2 = "EVENTTYPE_STORE"
.line	573	gettabup      r3    u0    k3 ; k3 = "EVENTID_STORE_CRATE_" (truncated)
.line	573	call          r0     4     1
.line	573	gettabup      r0    u0    k4 ; k4 = "GlobalData"
.line	573	gettable      r0    r0    k5 ; k5 = "JumpUrl"
.line	573	getupval      r1    u1
.line	573	loadk         r2    k6 ; k6 = 222
.line	573	loadk         r3    k7 ; k7 = 140
.line	573	loadk         r4    k8 ; k8 = 73
.line	573	loadk         r5    k9 ; k9 = 100
.line	573	loadk         r6   k10 ; k10 = 60
.line	573	loadk         r7   k11 ; k11 = 23
.line	573	loadk         r8   k12 ; k12 = 144
.line	573	loadk         r9   k13 ; k13 = 194
.line	573	loadk        r10   k14 ; k14 = 19
.line	573	loadk        r11   k15 ; k15 = 84
.line	573	loadk        r12   k16 ; k16 = 46
.line	573	loadk        r13   k17 ; k17 = 224
.line	573	loadk        r14   k18 ; k18 = 165
.line	573	loadk        r15   k19 ; k19 = 252
.line	573	loadk        r16   k20 ; k20 = 21
.line	573	loadk        r17   k21 ; k21 = 231
.line	573	loadk        r18   k22 ; k22 = 121
.line	573	loadk        r19   k23 ; k23 = 237
.line	573	loadk        r20   k24 ; k24 = 101
.line	573	loadk        r21   k25 ; k25 = 2
.line	573	loadk        r22   k26 ; k26 = 198
.line	573	loadk        r23   k27 ; k27 = 56
.line	573	loadk        r24   k28 ; k28 = 233
.line	573	loadk        r25   k29 ; k29 = 164
.line	573	loadk        r26   k30 ; k30 = 10
.line	573	loadk        r27   k31 ; k31 = 22
.line	573	loadk        r28   k32 ; k32 = 104
.line	573	loadk        r29   k33 ; k33 = 181
.line	573	loadk        r30   k34 ; k34 = 232
.line	573	loadk        r31   k35 ; k35 = 176
.line	573	loadk        r32   k36 ; k36 = 8
.line	573	loadk        r33   k37 ; k37 = 254
.line	573	loadk        r34   k38 ; k38 = 105
.line	573	loadk        r35   k39 ; k39 = 244
.line	573	loadk        r36   k40 ; k40 = 125
.line	573	loadk        r37   k41 ; k41 = 24
.line	573	call          r1    37     2
.line	573	call          r0     2     1
.line	573	gettabup      r0    u2   k42 ; k42 = "ReportBtnClickEvent"
.line	573	gettabup      r1    u2   k43 ; k43 = "SubEventName_Rebate_" (truncated)
.line	573	call          r0     2     1
.line	573	gettabup      r0    u0   k44 ; k44 = "require"
.line	573	gettabup      r1    u0   k45 ; k45 = "table"
.line	573	gettable      r1    r1   k46 ; k46 = "concat"
.line	573	newtable      r2     1     0
.line	573	getupval      r3    u1
.line	573	loadk         r4   k47 ; k47 = 218
.line	573	loadk         r5   k48 ; k48 = 129
.line	573	loadk         r6   k49 ; k49 = 77
.line	573	loadk         r7    k9 ; k9 = 100
.line	573	loadk         r8   k32 ; k32 = 104
.line	573	loadk         r9   k50 ; k50 = 76
.line	573	loadk        r10   k51 ; k51 = 145
.line	573	loadk        r11   k52 ; k52 = 142
.line	573	loadk        r12   k53 ; k53 = 18
.line	573	loadk        r13   k54 ; k54 = 78
.line	573	loadk        r14   k55 ; k55 = 43
.line	573	loadk        r15   k56 ; k56 = 187
.line	573	loadk        r16   k57 ; k57 = 170
.line	573	loadk        r17   k58 ; k58 = 246
.line	573	loadk        r18   k59 ; k59 = 70
.line	573	loadk        r19   k35 ; k35 = 176
.line	573	loadk        r20   k60 ; k60 = 32
.line	573	loadk        r21   k61 ; k61 = 186
.line	573	loadk        r22   k62 ; k62 = 122
.line	573	loadk        r23   k63 ; k63 = 69
.line	573	loadk        r24   k64 ; k64 = 154
.line	573	loadk        r25   k65 ; k65 = 103
.line	573	loadk        r26   k66 ; k66 = 168
.line	573	loadk        r27   k67 ; k67 = 227
.line	573	loadk        r28   k68 ; k68 = 26
.line	573	loadk        r29   k69 ; k69 = 71
.line	573	loadk        r30   k70 ; k70 = 53
.line	573	loadk        r31   k71 ; k71 = 226
.line	573	loadk        r32   k72 ; k72 = 134
.line	573	loadk        r33   k73 ; k73 = 251
.line	573	loadk        r34   k74 ; k74 = 93
.line	573	loadk        r35   k75 ; k75 = 182
.line	573	loadk        r36   k76 ; k76 = 54
.line	573	loadk        r37   k77 ; k77 = 191
.line	573	loadk        r38   k78 ; k78 = 48
.line	573	loadk        r39   k79 ; k79 = 126
.line	573	loadk        r40   k80 ; k80 = 147
.line	573	loadk        r41   k81 ; k81 = 108
.line	573	loadk        r42   k75 ; k75 = 182
.line	573	loadk        r43   k82 ; k82 = 177
.line	573	call          r3    41     2
.line	573	getupval      r4    u1
.line	573	loadk         r5   k83 ; k83 = 202
.line	573	call          r4     2     0
.line	573	setlist       r2     0     1
.line	573	call          r1     2     2
.line	573	call          r0     2     2
.line	573	gettable      r1    r0   k84 ; k84 = "ReportTLogEvent"
.line	573	gettabup      r2    u0   k85 ; k85 = "TLogEventDefine"
.line	573	gettable      r2    r2   k86 ; k86 = "Rebate_GoToActivity"
.line	573	call          r1     2     1
.line	573	return        r0     1
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	return        r0     1

.function	main/f23/f1

.source	null
.linedefined	582
.lastlinedefined	584
.numparams	0
.is_vararg	0
.maxstacksize	34

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false

.constant	k0	"GlobalData"
.constant	k1	"JumpUrl"
.constant	k2	222
.constant	k3	140
.constant	k4	73
.constant	k5	100
.constant	k6	60
.constant	k7	23
.constant	k8	144
.constant	k9	194
.constant	k10	19
.constant	k11	84
.constant	k12	46
.constant	k13	224
.constant	k14	165
.constant	k15	252
.constant	k16	21
.constant	k17	231
.constant	k18	121
.constant	k19	237
.constant	k20	102
.constant	k21	4
.constant	k22	199
.constant	k23	62
.constant	k24	233
.constant	k25	185
.constant	k26	15
.constant	k27	103
.constant	k28	230
.constant	k29	177
.constant	k30	236
.constant	k31	75
.constant	k32	178

.line	582	gettabup      r0    u0    k0 ; k0 = "GlobalData"
.line	582	gettable      r0    r0    k1 ; k1 = "JumpUrl"
.line	582	getupval      r1    u1
.line	582	loadk         r2    k2 ; k2 = 222
.line	582	loadk         r3    k3 ; k3 = 140
.line	582	loadk         r4    k4 ; k4 = 73
.line	582	loadk         r5    k5 ; k5 = 100
.line	582	loadk         r6    k6 ; k6 = 60
.line	582	loadk         r7    k7 ; k7 = 23
.line	582	loadk         r8    k8 ; k8 = 144
.line	582	loadk         r9    k9 ; k9 = 194
.line	582	loadk        r10   k10 ; k10 = 19
.line	582	loadk        r11   k11 ; k11 = 84
.line	582	loadk        r12   k12 ; k12 = 46
.line	582	loadk        r13   k13 ; k13 = 224
.line	582	loadk        r14   k14 ; k14 = 165
.line	582	loadk        r15   k15 ; k15 = 252
.line	582	loadk        r16   k16 ; k16 = 21
.line	582	loadk        r17   k17 ; k17 = 231
.line	582	loadk        r18   k18 ; k18 = 121
.line	582	loadk        r19   k19 ; k19 = 237
.line	582	loadk        r20   k20 ; k20 = 102
.line	582	loadk        r21   k21 ; k21 = 4
.line	582	loadk        r22   k22 ; k22 = 199
.line	582	loadk        r23   k23 ; k23 = 62
.line	582	loadk        r24   k24 ; k24 = 233
.line	582	loadk        r25   k25 ; k25 = 185
.line	582	loadk        r26   k26 ; k26 = 15
.line	582	loadk        r27    k4 ; k4 = 73
.line	582	loadk        r28   k27 ; k27 = 103
.line	582	loadk        r29   k28 ; k28 = 230
.line	582	loadk        r30   k29 ; k29 = 177
.line	582	loadk        r31   k30 ; k30 = 236
.line	582	loadk        r32   k31 ; k31 = 75
.line	582	loadk        r33   k32 ; k32 = 178
.line	582	call          r1    33     2
.line	582	call          r0     2     1
.line	582	return        r0     1
.line	582	move          r0    r0
.line	582	move          r0    r0
.line	582	move          r0    r0
.line	582	move          r0    r0
.line	582	return        r0     1

.function	main/f24

.source	null
.linedefined	609
.lastlinedefined	610
.numparams	1
.is_vararg	0
.maxstacksize	2

.line	609	return        r0     1
.line	609	move          r0    r0
.line	609	move          r0    r0
.line	609	move          r0    r0
.line	609	return        r0     1

.function	main/f25

.source	null
.linedefined	612
.lastlinedefined	648
.numparams	4
.is_vararg	0
.maxstacksize	64

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"store_commodity_manager"
.constant	k4	"currentItem"
.constant	k5	"LoopScrollGrid_0"
.constant	k6	"CheckAlreadyOwnByType"
.constant	k7	"type"
.constant	k8	"subType"
.constant	k9	"itemId"
.constant	k10	"log"
.constant	k11	"bWriteLog"
.constant	k12	"table"
.constant	k13	"concat"
.constant	k14	234
.constant	k15	153
.constant	k16	75
.constant	k17	115
.constant	k18	99
.constant	k19	127
.constant	k20	218
.constant	k21	147
.constant	k22	27
.constant	k23	73
.constant	k24	43
.constant	k25	249
.constant	k26	248
.constant	k27	79
.constant	k28	179
.constant	k29	146
.constant	k30	58
.constant	k31	120
.constant	k32	152
.constant	k33	126
.constant	k34	170
.constant	k35	163
.constant	k36	26
.constant	k37	68
.constant	k38	40
.constant	k39	252
.constant	k40	154
.constant	k41	225
.constant	k42	89
.constant	k43	168
.constant	k44	62
.constant	k45	104
.constant	k46	1
.constant	k47	142
.constant	k48	121
.constant	k49	169
.constant	k50	184
.constant	k51	208
.constant	k52	4
.constant	k53	"tostring"
.constant	k54	true
.constant	k55	"have"
.constant	k56	"UpdateNewBuyBtn"
.constant	k57	"RefreshItem"
.constant	k58	"currIndex"
.constant	k59	"showDataList"
.constant	k60	"next"
.constant	k61	205
.constant	k62	140
.constant	k63	70
.constant	k64	109
.constant	k65	"EVENTID_PET_CHANGE"
.constant	k66	"RefreshPetItemsHave"
.constant	k67	"slua"
.constant	k68	"getMiliseconds"
.constant	k69	"pairs"
.constant	k70	"res_id"
.constant	k71	1620361
.constant	k72	1516107
.constant	k73	"CDataTable"
.constant	k74	"GetTableData"
.constant	k75	240
.constant	k76	65
.constant	k77	108
.constant	k78	"ItemType"
.constant	k79	"ItemSubType"
.constant	k80	"printf"
.constant	k81	100
.constant	k82	77
.constant	k83	123
.constant	k84	180
.constant	k85	164
.constant	k86	69
.constant	k87	98
.constant	k88	24
.constant	k89	216
.constant	k90	148
.constant	k91	106
.constant	k92	231
.constant	k93	172
.constant	k94	255
.constant	k95	90
.constant	k96	181
.constant	k97	49
.constant	k98	85
.constant	k99	189
.constant	k100	29
.constant	k101	191
.constant	k102	250
.constant	k103	20
.constant	k104	230
.constant	k105	48
.constant	k106	185
.constant	k107	33
.constant	k108	76
.constant	k109	175
.constant	k110	124
.constant	k111	229
.constant	k112	202
.constant	k113	193
.constant	k114	105
.constant	k115	103
.constant	k116	78
.constant	k117	199
.constant	k118	91
.constant	k119	72
.constant	k120	"RefreshItemWithClick"
.constant	k121	226
.constant	k122	111
.constant	k123	97
.constant	k124	80
.constant	k125	222
.constant	k126	22
.constant	k127	23
.constant	k128	237
.constant	k129	71
.constant	k130	44
.constant	k131	95
.constant	k132	122
.constant	k133	174
.constant	k134	161
.constant	k135	74
.constant	k136	61
.constant	k137	224
.constant	k138	227
.constant	k139	198
.constant	k140	86
.constant	k141	143
.constant	k142	55
.constant	k143	187
.constant	k144	119
.constant	k145	173
.constant	k146	133
.constant	k147	93
.constant	k148	145
.constant	k149	221
.constant	k150	84
.constant	k151	57
.constant	k152	233
.constant	k153	244
.constant	k154	186
.constant	k155	32
.constant	k156	82
.constant	k157	214
.constant	k158	53
.constant	k159	239

.line	612	gettabup      r4    u0    k0 ; k0 = "ModuleManager"
.line	612	gettable      r4    r4    k1 ; k1 = "GetModule"
.line	612	gettabup      r5    u0    k0 ; k0 = "ModuleManager"
.line	612	gettable      r5    r5    k2 ; k2 = "LobbyModuleConfig"
.line	612	gettable      r5    r5    k3 ; k3 = "store_commodity_mana" (truncated)
.line	612	call          r4     2     2
.line	612	gettable      r5    r0    k4 ; k4 = "currentItem"
.line	612	test          r5     0
.line	612	jmp            0   l93
.line	612	gettable      r5    r0    k5 ; k5 = "LoopScrollGrid_0"
.line	612	test          r5     0
.line	612	jmp            0   l93
.line	612	self          r5    r4    k6 ; k6 = "CheckAlreadyOwnByTyp" (truncated)
.line	612	gettable      r7    r0    k4 ; k4 = "currentItem"
.line	612	gettable      r7    r7    k7 ; k7 = "type"
.line	612	gettable      r8    r0    k4 ; k4 = "currentItem"
.line	612	gettable      r8    r8    k8 ; k8 = "subType"
.line	612	gettable      r9    r0    k4 ; k4 = "currentItem"
.line	612	gettable      r9    r9    k9 ; k9 = "itemId"
.line	612	call          r5     5     2
.line	612	gettabup      r6    u0   k10 ; k10 = "log"
.line	612	gettabup      r7    u0   k11 ; k11 = "bWriteLog"
.line	612	test          r7     0
.line	612	jmp            0   l81
.line	612	gettabup      r7    u0   k12 ; k12 = "table"
.line	612	gettable      r7    r7   k13 ; k13 = "concat"
.line	612	newtable      r8     1     0
.line	612	getupval      r9    u1
.line	612	loadk        r10   k14 ; k14 = 234
.line	612	loadk        r11   k15 ; k15 = 153
.line	612	loadk        r12   k16 ; k16 = 75
.line	612	loadk        r13   k17 ; k17 = 115
.line	612	loadk        r14   k18 ; k18 = 99
.line	612	loadk        r15   k19 ; k19 = 127
.line	612	loadk        r16   k20 ; k20 = 218
.line	612	loadk        r17   k21 ; k21 = 147
.line	612	loadk        r18   k22 ; k22 = 27
.line	612	loadk        r19   k23 ; k23 = 73
.line	612	loadk        r20   k24 ; k24 = 43
.line	612	loadk        r21   k25 ; k25 = 249
.line	612	loadk        r22   k15 ; k15 = 153
.line	612	loadk        r23   k26 ; k26 = 248
.line	612	loadk        r24   k27 ; k27 = 79
.line	612	loadk        r25   k28 ; k28 = 179
.line	612	loadk        r26   k17 ; k17 = 115
.line	612	loadk        r27   k29 ; k29 = 146
.line	612	loadk        r28   k30 ; k30 = 58
.line	612	loadk        r29   k31 ; k31 = 120
.line	612	loadk        r30   k32 ; k32 = 152
.line	612	loadk        r31   k33 ; k33 = 126
.line	612	loadk        r32   k34 ; k34 = 170
.line	612	loadk        r33   k35 ; k35 = 163
.line	612	loadk        r34   k36 ; k36 = 26
.line	612	loadk        r35   k37 ; k37 = 68
.line	612	loadk        r36   k38 ; k38 = 40
.line	612	loadk        r37   k39 ; k39 = 252
.line	612	loadk        r38   k40 ; k40 = 154
.line	612	loadk        r39   k41 ; k41 = 225
.line	612	loadk        r40   k42 ; k42 = 89
.line	612	loadk        r41   k43 ; k43 = 168
.line	612	loadk        r42   k44 ; k44 = 62
.line	612	loadk        r43   k43 ; k43 = 168
.line	612	loadk        r44   k45 ; k45 = 104
.line	612	loadk        r45   k46 ; k46 = 1
.line	612	loadk        r46   k47 ; k47 = 142
.line	612	loadk        r47   k48 ; k48 = 121
.line	612	loadk        r48   k49 ; k49 = 169
.line	612	loadk        r49   k50 ; k50 = 184
.line	612	call          r9    41     2
.line	612	getupval     r10    u1
.line	612	loadk        r11   k15 ; k15 = 153
.line	612	loadk        r12   k51 ; k51 = 208
.line	612	loadk        r13   k52 ; k52 = 4
.line	612	call         r10     4     0
.line	612	setlist       r8     0     1
.line	612	call          r7     2     2
.line	612	gettabup      r8    u0   k53 ; k53 = "tostring"
.line	612	move          r9    r5
.line	612	call          r8     2     2
.line	612	concat        r7    r7    r8
.label	l81
.line	612	call          r6     2     1
.line	612	eq             0    r5   k54 ; k54 = true
.line	612	jmp            0   l93
.line	612	gettable      r6    r0    k4 ; k4 = "currentItem"
.line	612	settable      r6   k55   k54 ; k54 = true
.line	612	self          r6    r0   k56 ; k56 = "UpdateNewBuyBtn"
.line	612	gettable      r8    r0    k4 ; k4 = "currentItem"
.line	612	call          r6     3     1
.line	612	gettable      r6    r0    k5 ; k5 = "LoopScrollGrid_0"
.line	612	self          r6    r6   k57 ; k57 = "RefreshItem"
.line	612	gettable      r8    r0   k58 ; k58 = "currIndex"
.line	612	call          r6     3     1
.label	l93
.line	612	gettable      r5    r0   k59 ; k59 = "showDataList"
.line	612	test          r5     0
.line	612	jmp            0  l101
.line	612	gettabup      r5    u0   k60 ; k60 = "next"
.line	612	gettable      r6    r0   k59 ; k59 = "showDataList"
.line	612	call          r5     2     2
.line	612	test          r5     1
.line	612	jmp            0  l102
.label	l101
.line	612	return        r0     1
.label	l102
.line	612	test          r3     0
.line	612	jmp            0  l121
.line	612	gettabup      r5    u0    k7 ; k7 = "type"
.line	612	move          r6    r3
.line	612	call          r5     2     2
.line	612	getupval      r6    u1
.line	612	loadk         r7   k61 ; k61 = 205
.line	612	loadk         r8   k62 ; k62 = 140
.line	612	loadk         r9   k63 ; k63 = 70
.line	612	loadk        r10   k64 ; k64 = 109
.line	612	loadk        r11   k18 ; k18 = 99
.line	612	call          r6     6     2
.line	612	eq             0    r5    r6
.line	612	jmp            0  l121
.line	612	gettabup      r5    u0   k60 ; k60 = "next"
.line	612	move          r6    r3
.line	612	call          r5     2     2
.line	612	test          r5     1
.line	612	jmp            0  l127
.label	l121
.line	612	gettabup      r5    u0   k65 ; k65 = "EVENTID_PET_CHANGE"
.line	612	eq             0    r2    r5
.line	612	jmp            0  l126
.line	612	self          r5    r0   k66 ; k66 = "RefreshPetItemsHave"
.line	612	call          r5     2     1
.label	l126
.line	612	return        r0     1
.label	l127
.line	612	gettabup      r5    u0   k67 ; k67 = "slua"
.line	612	gettable      r5    r5   k68 ; k68 = "getMiliseconds"
.line	612	call          r5     1     2
.line	612	gettabup      r6    u0   k69 ; k69 = "pairs"
.line	612	move          r7    r3
.line	612	call          r6     2     4
.line	612	jmp            0  l298
.line	612	gettabup     r11    u0   k69 ; k69 = "pairs"
.line	612	gettable     r12    r0   k59 ; k59 = "showDataList"
.line	612	call         r11     2     4
.line	612	jmp            0  l296
.line	612	gettable     r16   r10   k70 ; k70 = "res_id"
.line	612	gettable     r17   r15    k9 ; k9 = "itemId"
.line	612	eq             1   r16   r17
.line	612	jmp            0  l143
.line	612	loadbool     r16     0     1
.label	l143
.line	612	loadbool     r16     1     0
.line	612	gettable     r17   r10   k70 ; k70 = "res_id"
.line	612	eq             0   r17   k71 ; k71 = 1620361
.line	612	jmp            0  l150
.line	612	gettable     r17   r15    k9 ; k9 = "itemId"
.line	612	eq             1   r17   k72 ; k72 = 1516107
.line	612	jmp            0  l151
.label	l150
.line	612	loadbool     r17     0     1
.label	l151
.line	612	loadbool     r17     1     0
.line	612	gettable     r18   r10   k70 ; k70 = "res_id"
.line	612	test         r18     0
.line	612	jmp            0  l296
.line	612	test         r16     1
.line	612	jmp            0  l159
.line	612	test         r17     0
.line	612	jmp            0  l296
.label	l159
.line	612	gettable     r18   r15   k55 ; k55 = "have"
.line	612	test         r18     1
.line	612	jmp            0  l296
.line	612	gettabup     r18    u0   k73 ; k73 = "CDataTable"
.line	612	gettable     r18   r18   k74 ; k74 = "GetTableData"
.line	612	getupval     r19    u1
.line	612	loadk        r20   k75 ; k75 = 240
.line	612	loadk        r21   k15 ; k15 = 153
.line	612	loadk        r22   k76 ; k76 = 65
.line	612	loadk        r23   k77 ; k77 = 108
.line	612	call         r19     5     2
.line	612	gettable     r20   r15    k9 ; k9 = "itemId"
.line	612	call         r18     3     2
.line	612	self         r19    r4    k6 ; k6 = "CheckAlreadyOwnByTyp" (truncated)
.line	612	gettable     r21   r18   k78 ; k78 = "ItemType"
.line	612	gettable     r22   r18   k79 ; k79 = "ItemSubType"
.line	612	gettable     r23   r15    k9 ; k9 = "itemId"
.line	612	call         r19     5     2
.line	612	settable     r15   k55   r19 ; k55 = "have"
.line	612	test         r17     0
.line	612	jmp            0  l292
.line	612	gettabup     r19    u0   k80 ; k80 = "printf"
.line	612	gettabup     r20    u0   k12 ; k12 = "table"
.line	612	gettable     r20   r20   k13 ; k13 = "concat"
.line	612	newtable     r21     2     0
.line	612	getupval     r22    u1
.line	612	loadk        r23   k14 ; k14 = 234
.line	612	loadk        r24   k15 ; k15 = 153
.line	612	loadk        r25   k16 ; k16 = 75
.line	612	loadk        r26   k17 ; k17 = 115
.line	612	loadk        r27   k18 ; k18 = 99
.line	612	loadk        r28   k19 ; k19 = 127
.line	612	loadk        r29   k20 ; k20 = 218
.line	612	loadk        r30   k21 ; k21 = 147
.line	612	loadk        r31   k22 ; k22 = 27
.line	612	loadk        r32   k23 ; k23 = 73
.line	612	loadk        r33   k24 ; k24 = 43
.line	612	loadk        r34   k25 ; k25 = 249
.line	612	loadk        r35   k15 ; k15 = 153
.line	612	loadk        r36   k26 ; k26 = 248
.line	612	loadk        r37   k27 ; k27 = 79
.line	612	loadk        r38   k28 ; k28 = 179
.line	612	loadk        r39   k17 ; k17 = 115
.line	612	loadk        r40   k29 ; k29 = 146
.line	612	loadk        r41   k30 ; k30 = 58
.line	612	loadk        r42   k31 ; k31 = 120
.line	612	loadk        r43   k32 ; k32 = 152
.line	612	loadk        r44   k33 ; k33 = 126
.line	612	loadk        r45   k34 ; k34 = 170
.line	612	loadk        r46   k35 ; k35 = 163
.line	612	loadk        r47   k36 ; k36 = 26
.line	612	loadk        r48   k37 ; k37 = 68
.line	612	loadk        r49   k38 ; k38 = 40
.line	612	loadk        r50   k39 ; k39 = 252
.line	612	loadk        r51   k40 ; k40 = 154
.line	612	loadk        r52   k41 ; k41 = 225
.line	612	loadk        r53   k42 ; k42 = 89
.line	612	loadk        r54   k43 ; k43 = 168
.line	612	loadk        r55   k44 ; k44 = 62
.line	612	loadk        r56   k43 ; k43 = 168
.line	612	loadk        r57   k81 ; k81 = 100
.line	612	loadk        r58   k82 ; k82 = 77
.line	612	loadk        r59   k21 ; k21 = 147
.line	612	loadk        r60   k83 ; k83 = 123
.line	612	loadk        r61   k84 ; k84 = 180
.line	612	loadk        r62   k85 ; k85 = 164
.line	612	call         r22    41     2
.line	612	getupval     r23    u1
.line	612	loadk        r24   k15 ; k15 = 153
.line	612	loadk        r25   k47 ; k47 = 142
.line	612	loadk        r26   k86 ; k86 = 69
.line	612	loadk        r27   k17 ; k17 = 115
.line	612	loadk        r28   k87 ; k87 = 98
.line	612	loadk        r29   k88 ; k88 = 24
.line	612	loadk        r30   k89 ; k89 = 216
.line	612	loadk        r31   k90 ; k90 = 148
.line	612	loadk        r32   k88 ; k88 = 24
.line	612	loadk        r33   k27 ; k27 = 79
.line	612	loadk        r34   k91 ; k91 = 106
.line	612	loadk        r35   k92 ; k92 = 231
.line	612	loadk        r36   k93 ; k93 = 172
.line	612	loadk        r37   k94 ; k94 = 255
.line	612	loadk        r38   k95 ; k95 = 90
.line	612	loadk        r39   k28 ; k28 = 179
.line	612	loadk        r40   k30 ; k30 = 58
.line	612	loadk        r41   k96 ; k96 = 181
.line	612	loadk        r42   k97 ; k97 = 49
.line	612	loadk        r43   k98 ; k98 = 85
.line	612	loadk        r44   k20 ; k20 = 218
.line	612	loadk        r45   k38 ; k38 = 40
.line	612	loadk        r46   k99 ; k99 = 189
.line	612	loadk        r47   k43 ; k43 = 168
.line	612	loadk        r48  k100 ; k100 = 29
.line	612	loadk        r49   k87 ; k87 = 98
.line	612	loadk        r50   k44 ; k44 = 62
.line	612	loadk        r51  k101 ; k101 = 191
.line	612	loadk        r52   k39 ; k39 = 252
.line	612	loadk        r53  k102 ; k102 = 250
.line	612	loadk        r54  k103 ; k103 = 20
.line	612	loadk        r55  k104 ; k104 = 230
.line	612	loadk        r56  k105 ; k105 = 48
.line	612	loadk        r57  k106 ; k106 = 185
.line	612	loadk        r58  k107 ; k107 = 33
.line	612	loadk        r59  k108 ; k108 = 76
.line	612	loadk        r60  k109 ; k109 = 175
.line	612	loadk        r61  k110 ; k110 = 124
.line	612	loadk        r62  k111 ; k111 = 229
.line	612	loadk        r63   k26 ; k26 = 248
.line	612	call         r23    41     2
.line	612	getupval     r24    u1
.line	612	loadk        r25  k112 ; k112 = 202
.line	612	loadk        r26  k113 ; k113 = 193
.line	612	loadk        r27   k52 ; k52 = 4
.line	612	loadk        r28  k114 ; k114 = 105
.line	612	loadk        r29  k115 ; k115 = 103
.line	612	loadk        r30  k116 ; k116 = 78
.line	612	loadk        r31   k20 ; k20 = 218
.line	612	loadk        r32  k117 ; k117 = 199
.line	612	loadk        r33  k118 ; k118 = 91
.line	612	loadk        r34  k119 ; k119 = 72
.line	612	call         r24    11     0
.line	612	setlist      r21     0     1
.line	612	call         r20     2     2
.line	612	gettabup     r21    u0   k53 ; k53 = "tostring"
.line	612	gettable     r22   r10   k70 ; k70 = "res_id"
.line	612	call         r21     2     2
.line	612	gettabup     r22    u0   k53 ; k53 = "tostring"
.line	612	gettable     r23   r15    k9 ; k9 = "itemId"
.line	612	call         r22     2     2
.line	612	gettabup     r23    u0   k53 ; k53 = "tostring"
.line	612	gettable     r24   r15   k55 ; k55 = "have"
.line	612	call         r23     2     0
.line	612	call         r19     0     1
.label	l292
.line	612	self         r19    r0  k120 ; k120 = "RefreshItemWithClick"
.line	612	move         r21   r14
.line	612	loadbool     r22     1     0
.line	612	call         r19     4     1
.label	l296
.line	612	move          r0    r0
.line	612	move          r0    r0
.label	l298
.line	612	move          r0    r0
.line	612	move          r0    r0
.line	612	gettabup      r6    u0   k10 ; k10 = "log"
.line	612	gettabup      r7    u0   k11 ; k11 = "bWriteLog"
.line	612	test          r7     0
.line	612	jmp            0  l383
.line	612	gettabup      r7    u0   k12 ; k12 = "table"
.line	612	gettable      r7    r7   k13 ; k13 = "concat"
.line	612	newtable      r8     1     0
.line	612	getupval      r9    u1
.line	612	loadk        r10  k121 ; k121 = 226
.line	612	loadk        r11   k15 ; k15 = 153
.line	612	loadk        r12   k82 ; k82 = 77
.line	612	loadk        r13  k122 ; k122 = 111
.line	612	loadk        r14  k123 ; k123 = 97
.line	612	loadk        r15  k124 ; k124 = 80
.line	612	loadk        r16  k125 ; k125 = 222
.line	612	loadk        r17   k29 ; k29 = 146
.line	612	loadk        r18  k126 ; k126 = 22
.line	612	loadk        r19  k116 ; k116 = 78
.line	612	loadk        r20  k127 ; k127 = 23
.line	612	loadk        r21   k96 ; k96 = 181
.line	612	loadk        r22   k40 ; k40 = 154
.line	612	loadk        r23  k128 ; k128 = 237
.line	612	loadk        r24  k129 ; k129 = 71
.line	612	loadk        r25   k85 ; k85 = 164
.line	612	loadk        r26  k130 ; k130 = 44
.line	612	loadk        r27   k40 ; k40 = 154
.line	612	loadk        r28   k97 ; k97 = 49
.line	612	loadk        r29  k131 ; k131 = 95
.line	612	loadk        r30   k21 ; k21 = 147
.line	612	loadk        r31  k132 ; k132 = 122
.line	612	loadk        r32  k133 ; k133 = 174
.line	612	loadk        r33  k134 ; k134 = 161
.line	612	loadk        r34   k44 ; k44 = 62
.line	612	loadk        r35  k135 ; k135 = 74
.line	612	loadk        r36  k136 ; k136 = 61
.line	612	loadk        r37  k137 ; k137 = 224
.line	612	loadk        r38  k138 ; k138 = 227
.line	612	loadk        r39  k139 ; k139 = 198
.line	612	loadk        r40  k140 ; k140 = 86
.line	612	loadk        r41  k141 ; k141 = 143
.line	612	loadk        r42  k142 ; k142 = 55
.line	612	loadk        r43  k143 ; k143 = 187
.line	612	loadk        r44  k107 ; k107 = 33
.line	612	loadk        r45   k27 ; k27 = 79
.line	612	loadk        r46   k29 ; k29 = 146
.line	612	loadk        r47  k144 ; k144 = 119
.line	612	loadk        r48  k145 ; k145 = 173
.line	612	loadk        r49   k85 ; k85 = 164
.line	612	call          r9    41     2
.line	612	getupval     r10    u1
.line	612	loadk        r11  k102 ; k102 = 250
.line	612	loadk        r12  k146 ; k146 = 133
.line	612	loadk        r13   k86 ; k86 = 69
.line	612	loadk        r14  k122 ; k122 = 111
.line	612	loadk        r15  k123 ; k123 = 97
.line	612	loadk        r16  k147 ; k147 = 93
.line	612	loadk        r17  k148 ; k148 = 145
.line	612	loadk        r18  k149 ; k149 = 221
.line	612	loadk        r19  k100 ; k100 = 29
.line	612	loadk        r20  k150 ; k150 = 84
.line	612	loadk        r21  k151 ; k151 = 57
.line	612	loadk        r22   k41 ; k41 = 225
.line	612	loadk        r23  k152 ; k152 = 233
.line	612	loadk        r24  k153 ; k153 = 244
.line	612	loadk        r25   k76 ; k76 = 65
.line	612	loadk        r26  k154 ; k154 = 186
.line	612	loadk        r27  k155 ; k155 = 32
.line	612	loadk        r28   k47 ; k47 = 142
.line	612	loadk        r29   k97 ; k97 = 49
.line	612	loadk        r30  k156 ; k156 = 82
.line	612	loadk        r31  k157 ; k157 = 214
.line	612	loadk        r32  k158 ; k158 = 53
.line	612	loadk        r33  k159 ; k159 = 239
.line	612	call         r10    24     0
.line	612	setlist       r8     0     1
.line	612	call          r7     2     2
.line	612	gettabup      r8    u0   k53 ; k53 = "tostring"
.line	612	gettabup      r9    u0   k67 ; k67 = "slua"
.line	612	gettable      r9    r9   k68 ; k68 = "getMiliseconds"
.line	612	call          r9     1     2
.line	612	sub           r9    r9    r5
.line	612	call          r8     2     2
.line	612	concat        r7    r7    r8
.label	l383
.line	612	call          r6     2     1
.line	612	return        r0     1
.line	612	move          r0    r0
.line	612	gettabup      r0    u0  k151 ; k151 = 57
.line	612	return        r0     1

.function	main/f26

.source	null
.linedefined	650
.lastlinedefined	672
.numparams	1
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"showDataList"
.constant	k1	"next"
.constant	k2	"ModuleManager"
.constant	k3	"GetModule"
.constant	k4	"LobbyModuleConfig"
.constant	k5	"store_commodity_manager"
.constant	k6	"ipairs"
.constant	k7	"type"
.constant	k8	"ENUM_ITEM_TYPE"
.constant	k9	"Buddy"
.constant	k10	"Buddy_New"
.constant	k11	"CheckAlreadyOwnByType"
.constant	k12	"subType"
.constant	k13	"itemId"
.constant	k14	"have"
.constant	k15	"RefreshItemWithClick"
.constant	k16	"currentItem"
.constant	k17	"printf"
.constant	k18	"table"
.constant	k19	"concat"
.constant	k20	234
.constant	k21	153
.constant	k22	75
.constant	k23	115
.constant	k24	99
.constant	k25	127
.constant	k26	218
.constant	k27	147
.constant	k28	27
.constant	k29	73
.constant	k30	43
.constant	k31	249
.constant	k32	248
.constant	k33	79
.constant	k34	179
.constant	k35	143
.constant	k36	49
.constant	k37	87
.constant	k38	132
.constant	k39	109
.constant	k40	188
.constant	k41	165
.constant	k42	62
.constant	k43	78
.constant	k44	46
.constant	k45	204
.constant	k46	173
.constant	k47	236
.constant	k48	85
.constant	k49	181
.constant	k50	17
.constant	k51	172
.constant	k52	50
.constant	k53	68
.constant	k54	198
.constant	k55	104
.constant	k56	186
.constant	k57	169
.constant	k58	133
.constant	k59	69
.constant	k60	119
.constant	k61	24
.constant	k62	220
.constant	k63	149
.constant	k64	31
.constant	k65	45
.constant	k66	240
.constant	k67	8
.constant	k68	191
.constant	k69	61
.constant	k70	184
.constant	k71	57
.constant	k72	120
.constant	k73	146
.constant	k74	190
.constant	k75	66
.constant	k76	11
.constant	k77	41
.constant	k78	237
.constant	k79	182
.constant	k80	113
.constant	k81	162
.constant	k82	232
.constant	k83	55
.constant	k84	13
.constant	k85	112
.constant	k86	171
.constant	k87	215
.constant	k88	1
.constant	k89	114
.constant	k90	"tostring"
.constant	k91	"shopId"
.constant	k92	"UpdateNewBuyBtn"

.line	650	gettable      r1    r0    k0 ; k0 = "showDataList"
.line	650	test          r1     0
.line	650	jmp            0    l9
.line	650	gettabup      r1    u0    k1 ; k1 = "next"
.line	650	gettable      r2    r0    k0 ; k0 = "showDataList"
.line	650	call          r1     2     2
.line	650	test          r1     1
.line	650	jmp            0   l10
.label	l9
.line	650	return        r0     1
.label	l10
.line	650	gettabup      r1    u0    k2 ; k2 = "ModuleManager"
.line	650	gettable      r1    r1    k3 ; k3 = "GetModule"
.line	650	gettabup      r2    u0    k2 ; k2 = "ModuleManager"
.line	650	gettable      r2    r2    k4 ; k4 = "LobbyModuleConfig"
.line	650	gettable      r2    r2    k5 ; k5 = "store_commodity_mana" (truncated)
.line	650	call          r1     2     2
.line	650	loadbool      r2     0     0
.line	650	gettabup      r3    u0    k6 ; k6 = "ipairs"
.line	650	gettable      r4    r0    k0 ; k0 = "showDataList"
.line	650	call          r3     2     4
.line	650	jmp            0  l159
.line	650	gettable      r8    r7    k7 ; k7 = "type"
.line	650	gettabup      r9    u0    k8 ; k8 = "ENUM_ITEM_TYPE"
.line	650	gettable      r9    r9    k9 ; k9 = "Buddy"
.line	650	eq             1    r8    r9
.line	650	jmp            0   l31
.line	650	gettable      r8    r7    k7 ; k7 = "type"
.line	650	gettabup      r9    u0    k8 ; k8 = "ENUM_ITEM_TYPE"
.line	650	gettable      r9    r9   k10 ; k10 = "Buddy_New"
.line	650	eq             0    r8    r9
.line	650	jmp            0  l159
.label	l31
.line	650	self          r8    r1   k11 ; k11 = "CheckAlreadyOwnByTyp" (truncated)
.line	650	gettable     r10    r7    k7 ; k7 = "type"
.line	650	gettable     r11    r7   k12 ; k12 = "subType"
.line	650	gettable     r12    r7   k13 ; k13 = "itemId"
.line	650	call          r8     5     2
.line	650	gettable      r9    r7   k14 ; k14 = "have"
.line	650	eq             1    r8    r9
.line	650	jmp            0  l159
.line	650	settable      r7   k14    r8 ; k14 = "have"
.line	650	self          r9    r0   k15 ; k15 = "RefreshItemWithClick"
.line	650	move         r11    r6
.line	650	loadbool     r12     1     0
.line	650	call          r9     4     1
.line	650	gettable      r9    r0   k16 ; k16 = "currentItem"
.line	650	test          r9     0
.line	650	jmp            0   l53
.line	650	gettable      r9    r0   k16 ; k16 = "currentItem"
.line	650	gettable      r9    r9   k13 ; k13 = "itemId"
.line	650	gettable     r10    r7   k13 ; k13 = "itemId"
.line	650	eq             0    r9   r10
.line	650	jmp            0   l53
.line	650	loadbool      r2     1     0
.label	l53
.line	650	gettabup      r9    u0   k17 ; k17 = "printf"
.line	650	gettabup     r10    u0   k18 ; k18 = "table"
.line	650	gettable     r10   r10   k19 ; k19 = "concat"
.line	650	newtable     r11     2     0
.line	650	getupval     r12    u1
.line	650	loadk        r13   k20 ; k20 = 234
.line	650	loadk        r14   k21 ; k21 = 153
.line	650	loadk        r15   k22 ; k22 = 75
.line	650	loadk        r16   k23 ; k23 = 115
.line	650	loadk        r17   k24 ; k24 = 99
.line	650	loadk        r18   k25 ; k25 = 127
.line	650	loadk        r19   k26 ; k26 = 218
.line	650	loadk        r20   k27 ; k27 = 147
.line	650	loadk        r21   k28 ; k28 = 27
.line	650	loadk        r22   k29 ; k29 = 73
.line	650	loadk        r23   k30 ; k30 = 43
.line	650	loadk        r24   k31 ; k31 = 249
.line	650	loadk        r25   k21 ; k21 = 153
.line	650	loadk        r26   k32 ; k32 = 248
.line	650	loadk        r27   k33 ; k33 = 79
.line	650	loadk        r28   k34 ; k34 = 179
.line	650	loadk        r29   k23 ; k23 = 115
.line	650	loadk        r30   k35 ; k35 = 143
.line	650	loadk        r31   k36 ; k36 = 49
.line	650	loadk        r32   k37 ; k37 = 87
.line	650	loadk        r33   k38 ; k38 = 132
.line	650	loadk        r34   k39 ; k39 = 109
.line	650	loadk        r35   k40 ; k40 = 188
.line	650	loadk        r36   k41 ; k41 = 165
.line	650	loadk        r37   k42 ; k42 = 62
.line	650	loadk        r38   k43 ; k43 = 78
.line	650	loadk        r39   k44 ; k44 = 46
.line	650	loadk        r40   k45 ; k45 = 204
.line	650	loadk        r41   k46 ; k46 = 173
.line	650	loadk        r42   k47 ; k47 = 236
.line	650	loadk        r43   k48 ; k48 = 85
.line	650	loadk        r44   k49 ; k49 = 181
.line	650	loadk        r45   k50 ; k50 = 17
.line	650	loadk        r46   k51 ; k51 = 172
.line	650	loadk        r47   k52 ; k52 = 50
.line	650	loadk        r48   k53 ; k53 = 68
.line	650	loadk        r49   k54 ; k54 = 198
.line	650	loadk        r50   k55 ; k55 = 104
.line	650	loadk        r51   k56 ; k56 = 186
.line	650	loadk        r52   k57 ; k57 = 169
.line	650	call         r12    41     2
.line	650	getupval     r13    u1
.line	650	loadk        r14   k21 ; k21 = 153
.line	650	loadk        r15   k58 ; k58 = 133
.line	650	loadk        r16   k59 ; k59 = 69
.line	650	loadk        r17   k60 ; k60 = 119
.line	650	loadk        r18   k24 ; k24 = 99
.line	650	loadk        r19   k61 ; k61 = 24
.line	650	loadk        r20   k62 ; k62 = 220
.line	650	loadk        r21   k63 ; k63 = 149
.line	650	loadk        r22   k64 ; k64 = 31
.line	650	loadk        r23   k48 ; k48 = 85
.line	650	loadk        r24   k65 ; k65 = 45
.line	650	loadk        r25   k66 ; k66 = 240
.line	650	loadk        r26   k46 ; k46 = 173
.line	650	loadk        r27   k49 ; k49 = 181
.line	650	loadk        r28   k67 ; k67 = 8
.line	650	loadk        r29   k68 ; k68 = 191
.line	650	loadk        r30   k69 ; k69 = 61
.line	650	loadk        r31   k70 ; k70 = 184
.line	650	loadk        r32   k71 ; k71 = 57
.line	650	loadk        r33   k72 ; k72 = 120
.line	650	loadk        r34   k73 ; k73 = 146
.line	650	loadk        r35   k52 ; k52 = 50
.line	650	loadk        r36   k20 ; k20 = 234
.line	650	loadk        r37   k74 ; k74 = 190
.line	650	loadk        r38   k75 ; k75 = 66
.line	650	loadk        r39   k76 ; k76 = 11
.line	650	loadk        r40   k77 ; k77 = 41
.line	650	loadk        r41   k78 ; k78 = 237
.line	650	loadk        r42   k79 ; k79 = 182
.line	650	loadk        r43   k31 ; k31 = 249
.line	650	loadk        r44   k80 ; k80 = 113
.line	650	loadk        r45   k81 ; k81 = 162
.line	650	loadk        r46   k24 ; k24 = 99
.line	650	loadk        r47   k82 ; k82 = 232
.line	650	loadk        r48   k83 ; k83 = 55
.line	650	loadk        r49   k84 ; k84 = 13
.line	650	loadk        r50   k54 ; k54 = 198
.line	650	loadk        r51   k85 ; k85 = 112
.line	650	loadk        r52   k74 ; k74 = 190
.line	650	loadk        r53   k86 ; k86 = 171
.line	650	call         r13    41     2
.line	650	getupval     r14    u1
.line	650	loadk        r15   k62 ; k62 = 220
.line	650	loadk        r16   k87 ; k87 = 215
.line	650	loadk        r17   k88 ; k88 = 1
.line	650	loadk        r18   k89 ; k89 = 114
.line	650	call         r14     5     0
.line	650	setlist      r11     0     1
.line	650	call         r10     2     2
.line	650	gettabup     r11    u0   k90 ; k90 = "tostring"
.line	650	gettable     r12    r7   k13 ; k13 = "itemId"
.line	650	call         r11     2     2
.line	650	gettabup     r12    u0   k90 ; k90 = "tostring"
.line	650	gettable     r13    r7   k91 ; k91 = "shopId"
.line	650	call         r12     2     2
.line	650	gettabup     r13    u0   k90 ; k90 = "tostring"
.line	650	move         r14    r8
.line	650	call         r13     2     0
.line	650	call          r9     0     1
.label	l159
.line	650	move          r0    r0
.line	650	move          r0    r0
.line	650	test          r2     0
.line	650	jmp            0  l166
.line	650	self          r3    r0   k92 ; k92 = "UpdateNewBuyBtn"
.line	650	gettable      r5    r0   k16 ; k16 = "currentItem"
.line	650	call          r3     3     1
.label	l166
.line	650	return        r0     1
.line	650	move          r0    r0
.line	650	return        r0     1

.function	main/f27

.source	null
.linedefined	674
.lastlinedefined	680
.numparams	4
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	8	true

.constant	k0	"IsDirectBuyTab"
.constant	k1	"tabId"
.constant	k2	1
.constant	k3	"currentItem"
.constant	k4	"itemId"
.constant	k5	"have"
.constant	k6	2
.constant	k7	"finalPrice"
.constant	k8	3
.constant	k9	"UpdateNewBuyBtn"

.line	674	gettabup      r4    u0    k0 ; k0 = "IsDirectBuyTab"
.line	674	gettable      r5    r0    k1 ; k1 = "tabId"
.line	674	call          r4     2     2
.line	674	test          r4     0
.line	674	jmp            0   l28
.line	674	gettable      r4    r3    k2 ; k2 = 1
.line	674	gettable      r5    r0    k3 ; k3 = "currentItem"
.line	674	gettable      r5    r5    k4 ; k4 = "itemId"
.line	674	eq             0    r4    r5
.line	674	jmp            0   l28
.line	674	gettable      r4    r0    k3 ; k3 = "currentItem"
.line	674	gettable      r5    r3    k6 ; k6 = 2
.line	674	test          r5     1
.line	674	jmp            0   l17
.line	674	gettable      r5    r0    k3 ; k3 = "currentItem"
.line	674	gettable      r5    r5    k5 ; k5 = "have"
.label	l17
.line	674	settable      r4    k5    r5 ; k5 = "have"
.line	674	gettable      r4    r0    k3 ; k3 = "currentItem"
.line	674	gettable      r5    r3    k8 ; k8 = 3
.line	674	test          r5     1
.line	674	jmp            0   l24
.line	674	gettable      r5    r0    k3 ; k3 = "currentItem"
.line	674	gettable      r5    r5    k7 ; k7 = "finalPrice"
.label	l24
.line	674	settable      r4    k7    r5 ; k7 = "finalPrice"
.line	674	self          r4    r0    k9 ; k9 = "UpdateNewBuyBtn"
.line	674	gettable      r6    r0    k3 ; k3 = "currentItem"
.line	674	call          r4     3     1
.label	l28
.line	674	return        r0     1
.line	674	move          r0    r0
.line	674	move          r0    r0
.line	674	move          r0    r0
.line	674	move          r0    r0
.line	674	return        r0     1

.function	main/f28

.source	null
.linedefined	682
.lastlinedefined	703
.numparams	1
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"IsPageShowing"
.constant	k1	"IsPageDataReady"
.constant	k2	"log"
.constant	k3	"bWriteLog"
.constant	k4	234
.constant	k5	153
.constant	k6	75
.constant	k7	115
.constant	k8	99
.constant	k9	127
.constant	k10	218
.constant	k11	147
.constant	k12	27
.constant	k13	73
.constant	k14	43
.constant	k15	249
.constant	k16	248
.constant	k17	79
.constant	k18	179
.constant	k19	136
.constant	k20	36
.constant	k21	85
.constant	k22	151
.constant	k23	124
.constant	k24	170
.constant	k25	152
.constant	k26	39
.constant	k27	"GlobalData"
.constant	k28	"IsJapanOrKorea"
.constant	k29	"UIRoot"
.constant	k30	"CanvasPanel_Filter"
.constant	k31	"SetWidgetVisibility"
.constant	k32	"UEnums"
.constant	k33	"ESlateVisibility"
.constant	k34	"Collapsed"
.constant	k35	"showDataList"
.constant	k36	0
.constant	k37	"WidgetSwitcher_2"
.constant	k38	"SetActiveWidgetIndex"
.constant	k39	"SetPageItemListData"
.constant	k40	"tabId"
.constant	k41	"StoreConst"
.constant	k42	"Page_ID_Exchange"
.constant	k43	"subTabId"
.constant	k44	"label_subtype_voice_chip"
.constant	k45	"EventSystem"
.constant	k46	"postEvent"
.constant	k47	"EVENTTYPE_STORE_DATA"
.constant	k48	"EVENTID_SUPPLY_SWITCH_SUB_TAB_SHOW"
.constant	k49	1
.constant	k50	"EVENTTYPE_DETAIL_COMPONENT"
.constant	k51	"EVENTID_DETAIL_HIDE_ALL_COMPONENT"

.line	682	self          r1    r0    k0 ; k0 = "IsPageShowing"
.line	682	call          r1     2     2
.line	682	test          r1     0
.line	682	jmp            0  l119
.line	682	self          r1    r0    k1 ; k1 = "IsPageDataReady"
.line	682	call          r1     2     2
.line	682	test          r1     0
.line	682	jmp            0  l119
.line	682	gettabup      r1    u0    k2 ; k2 = "log"
.line	682	gettabup      r2    u0    k3 ; k3 = "bWriteLog"
.line	682	test          r2     0
.line	682	jmp            0   l40
.line	682	getupval      r2    u1
.line	682	loadk         r3    k4 ; k4 = 234
.line	682	loadk         r4    k5 ; k5 = 153
.line	682	loadk         r5    k6 ; k6 = 75
.line	682	loadk         r6    k7 ; k7 = 115
.line	682	loadk         r7    k8 ; k8 = 99
.line	682	loadk         r8    k9 ; k9 = 127
.line	682	loadk         r9   k10 ; k10 = 218
.line	682	loadk        r10   k11 ; k11 = 147
.line	682	loadk        r11   k12 ; k12 = 27
.line	682	loadk        r12   k13 ; k13 = 73
.line	682	loadk        r13   k14 ; k14 = 43
.line	682	loadk        r14   k15 ; k15 = 249
.line	682	loadk        r15    k5 ; k5 = 153
.line	682	loadk        r16   k16 ; k16 = 248
.line	682	loadk        r17   k17 ; k17 = 79
.line	682	loadk        r18   k18 ; k18 = 179
.line	682	loadk        r19    k7 ; k7 = 115
.line	682	loadk        r20   k19 ; k19 = 136
.line	682	loadk        r21   k20 ; k20 = 36
.line	682	loadk        r22   k21 ; k21 = 85
.line	682	loadk        r23   k22 ; k22 = 151
.line	682	loadk        r24   k23 ; k23 = 124
.line	682	loadk        r25   k24 ; k24 = 170
.line	682	loadk        r26   k25 ; k25 = 152
.line	682	loadk        r27   k26 ; k26 = 39
.line	682	call          r2    26     2
.label	l40
.line	682	call          r1     2     1
.line	682	gettabup      r1    u0   k27 ; k27 = "GlobalData"
.line	682	gettable      r1    r1   k28 ; k28 = "IsJapanOrKorea"
.line	682	call          r1     1     2
.line	682	test          r1     0
.line	682	jmp            0   l53
.line	682	gettable      r1    r0   k29 ; k29 = "UIRoot"
.line	682	gettable      r1    r1   k30 ; k30 = "CanvasPanel_Filter"
.line	682	self          r1    r1   k31 ; k31 = "SetWidgetVisibility"
.line	682	gettabup      r3    u0   k32 ; k32 = "UEnums"
.line	682	gettable      r3    r3   k33 ; k33 = "ESlateVisibility"
.line	682	gettable      r3    r3   k34 ; k34 = "Collapsed"
.line	682	call          r1     3     1
.label	l53
.line	682	gettable      r1    r0   k35 ; k35 = "showDataList"
.line	682	test          r1     1
.line	682	jmp            0   l57
.line	682	newtable      r1     0     0
.label	l57
.line	682	len           r2    r1
.line	682	lt             0   k36    r2 ; k36 = 0
.line	682	jmp            0   l89
.line	682	gettable      r2    r0   k29 ; k29 = "UIRoot"
.line	682	gettable      r2    r2   k37 ; k37 = "WidgetSwitcher_2"
.line	682	self          r2    r2   k38 ; k38 = "SetActiveWidgetIndex"
.line	682	loadk         r4   k36 ; k36 = 0
.line	682	call          r2     3     1
.line	682	self          r2    r0   k39 ; k39 = "SetPageItemListData"
.line	682	move          r4    r1
.line	682	call          r2     3     1
.line	682	gettable      r2    r0   k40 ; k40 = "tabId"
.line	682	gettabup      r3    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r3    r3   k42 ; k42 = "Page_ID_Exchange"
.line	682	eq             0    r2    r3
.line	682	jmp            0  l119
.line	682	gettable      r2    r0   k43 ; k43 = "subTabId"
.line	682	gettabup      r3    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r3    r3   k44 ; k44 = "label_subtype_voice_" (truncated)
.line	682	eq             0    r2    r3
.line	682	jmp            0  l119
.line	682	gettabup      r2    u0   k45 ; k45 = "EventSystem"
.line	682	self          r2    r2   k46 ; k46 = "postEvent"
.line	682	gettabup      r4    u0   k47 ; k47 = "EVENTTYPE_STORE_DATA"
.line	682	gettabup      r5    u0   k48 ; k48 = "EVENTID_SUPPLY_SWITC" (truncated)
.line	682	gettabup      r6    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r6    r6   k42 ; k42 = "Page_ID_Exchange"
.line	682	gettabup      r7    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r7    r7   k44 ; k44 = "label_subtype_voice_" (truncated)
.line	682	loadbool      r8     1     0
.line	682	call          r2     7     1
.line	682	jmp            0  l119
.label	l89
.line	682	gettable      r2    r0   k29 ; k29 = "UIRoot"
.line	682	gettable      r2    r2   k37 ; k37 = "WidgetSwitcher_2"
.line	682	self          r2    r2   k38 ; k38 = "SetActiveWidgetIndex"
.line	682	loadk         r4   k49 ; k49 = 1
.line	682	call          r2     3     1
.line	682	gettabup      r2    u0   k45 ; k45 = "EventSystem"
.line	682	self          r2    r2   k46 ; k46 = "postEvent"
.line	682	gettabup      r4    u0   k50 ; k50 = "EVENTTYPE_DETAIL_COM" (truncated)
.line	682	gettabup      r5    u0   k51 ; k51 = "EVENTID_DETAIL_HIDE_" (truncated)
.line	682	call          r2     4     1
.line	682	gettable      r2    r0   k40 ; k40 = "tabId"
.line	682	gettabup      r3    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r3    r3   k42 ; k42 = "Page_ID_Exchange"
.line	682	eq             0    r2    r3
.line	682	jmp            0  l119
.line	682	gettable      r2    r0   k43 ; k43 = "subTabId"
.line	682	gettabup      r3    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r3    r3   k44 ; k44 = "label_subtype_voice_" (truncated)
.line	682	eq             0    r2    r3
.line	682	jmp            0  l119
.line	682	gettabup      r2    u0   k45 ; k45 = "EventSystem"
.line	682	self          r2    r2   k46 ; k46 = "postEvent"
.line	682	gettabup      r4    u0   k47 ; k47 = "EVENTTYPE_STORE_DATA"
.line	682	gettabup      r5    u0   k48 ; k48 = "EVENTID_SUPPLY_SWITC" (truncated)
.line	682	gettabup      r6    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r6    r6   k42 ; k42 = "Page_ID_Exchange"
.line	682	gettabup      r7    u0   k41 ; k41 = "StoreConst"
.line	682	gettable      r7    r7   k44 ; k44 = "label_subtype_voice_" (truncated)
.line	682	loadbool      r8     0     0
.line	682	call          r2     7     1
.label	l119
.line	682	return        r0     1
.line	682	move          r0    r0
.line	682	move          r0    r0
.line	682	return        r0     1

.function	main/f29

.source	null
.linedefined	705
.lastlinedefined	736
.numparams	4
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	218
.constant	k4	129
.constant	k5	77
.constant	k6	100
.constant	k7	104
.constant	k8	76
.constant	k9	145
.constant	k10	142
.constant	k11	18
.constant	k12	78
.constant	k13	43
.constant	k14	187
.constant	k15	165
.constant	k16	246
.constant	k17	79
.constant	k18	191
.constant	k19	42
.constant	k20	243
.constant	k21	39
.constant	k22	69
.constant	k23	153
.constant	k24	122
.constant	k25	170
.constant	k26	227
.constant	k27	2
.constant	k28	68
.constant	k29	61
.constant	k30	236
.constant	k31	186
.constant	k32	214
.constant	k33	85
.constant	k34	169
.constant	k35	55
.constant	k36	168
.constant	k37	126
.constant	k38	133
.constant	k39	119
.constant	k40	178
.constant	k41	173
.constant	k42	131
.constant	k43	65
.constant	k44	111
.constant	k45	114
.constant	k46	"GetCrystalsID"
.constant	k47	"tabId"
.constant	k48	"subTabId"
.constant	k49	"showDataList"
.constant	k50	"pairs"
.constant	k51	"itemId"
.constant	k52	"shopId"
.constant	k53	"GetItemInfoByShopId"
.constant	k54	"ConvertToShopInfo"
.constant	k55	"UIManager"
.constant	k56	"IsUIShow"
.constant	k57	"UI_Config"
.constant	k58	"Common_Exchange_Confirm_UIBP"
.constant	k59	"CloseUI"
.constant	k60	"Store_Buy_Slua_BP"
.constant	k61	"AddTimerOnce"
.constant	k62	0

.line	705	gettabup      r4    u0    k0 ; k0 = "require"
.line	705	gettabup      r5    u0    k1 ; k1 = "table"
.line	705	gettable      r5    r5    k2 ; k2 = "concat"
.line	705	newtable      r6     1     0
.line	705	getupval      r7    u1
.line	705	loadk         r8    k3 ; k3 = 218
.line	705	loadk         r9    k4 ; k4 = 129
.line	705	loadk        r10    k5 ; k5 = 77
.line	705	loadk        r11    k6 ; k6 = 100
.line	705	loadk        r12    k7 ; k7 = 104
.line	705	loadk        r13    k8 ; k8 = 76
.line	705	loadk        r14    k9 ; k9 = 145
.line	705	loadk        r15   k10 ; k10 = 142
.line	705	loadk        r16   k11 ; k11 = 18
.line	705	loadk        r17   k12 ; k12 = 78
.line	705	loadk        r18   k13 ; k13 = 43
.line	705	loadk        r19   k14 ; k14 = 187
.line	705	loadk        r20   k15 ; k15 = 165
.line	705	loadk        r21   k16 ; k16 = 246
.line	705	loadk        r22   k17 ; k17 = 79
.line	705	loadk        r23   k18 ; k18 = 191
.line	705	loadk        r24   k19 ; k19 = 42
.line	705	loadk        r25   k20 ; k20 = 243
.line	705	loadk        r26   k21 ; k21 = 39
.line	705	loadk        r27   k22 ; k22 = 69
.line	705	loadk        r28   k23 ; k23 = 153
.line	705	loadk        r29   k24 ; k24 = 122
.line	705	loadk        r30   k25 ; k25 = 170
.line	705	loadk        r31   k26 ; k26 = 227
.line	705	loadk        r32   k27 ; k27 = 2
.line	705	loadk        r33   k28 ; k28 = 68
.line	705	loadk        r34   k29 ; k29 = 61
.line	705	loadk        r35   k30 ; k30 = 236
.line	705	loadk        r36   k31 ; k31 = 186
.line	705	loadk        r37   k32 ; k32 = 214
.line	705	loadk        r38   k33 ; k33 = 85
.line	705	loadk        r39   k34 ; k34 = 169
.line	705	loadk        r40   k35 ; k35 = 55
.line	705	loadk        r41   k36 ; k36 = 168
.line	705	loadk        r42   k29 ; k29 = 61
.line	705	loadk        r43   k37 ; k37 = 126
.line	705	loadk        r44   k38 ; k38 = 133
.line	705	loadk        r45   k39 ; k39 = 119
.line	705	loadk        r46   k40 ; k40 = 178
.line	705	loadk        r47   k41 ; k41 = 173
.line	705	call          r7    41     2
.line	705	getupval      r8    u1
.line	705	loadk         r9   k32 ; k32 = 214
.line	705	loadk        r10   k42 ; k42 = 131
.line	705	loadk        r11   k43 ; k43 = 65
.line	705	loadk        r12   k44 ; k44 = 111
.line	705	loadk        r13   k45 ; k45 = 114
.line	705	call          r8     6     0
.line	705	setlist       r6     0     1
.line	705	call          r5     2     2
.line	705	call          r4     2     2
.line	705	gettable      r5    r4   k46 ; k46 = "GetCrystalsID"
.line	705	gettable      r6    r0   k47 ; k47 = "tabId"
.line	705	gettable      r7    r0   k48 ; k48 = "subTabId"
.line	705	call          r5     3     2
.line	705	test          r5     1
.line	705	jmp            0   l64
.line	705	return        r0     1
.label	l64
.line	705	eq             1    r5    r3
.line	705	jmp            0   l67
.line	705	return        r0     1
.label	l67
.line	705	loadnil       r6     1
.line	705	gettable      r8    r0   k49 ; k49 = "showDataList"
.line	705	test          r8     0
.line	705	jmp            0   l82
.line	705	gettabup      r8    u0   k50 ; k50 = "pairs"
.line	705	gettable      r9    r0   k49 ; k49 = "showDataList"
.line	705	call          r8     2     4
.line	705	jmp            0   l80
.line	705	gettable     r13   r12   k51 ; k51 = "itemId"
.line	705	eq             0   r13    r5
.line	705	jmp            0   l80
.line	705	gettable      r6   r12   k52 ; k52 = "shopId"
.line	705	jmp            0   l82
.label	l80
.line	705	move          r0    r0
.line	705	move          r0    r0
.label	l82
.line	705	self          r8    r0   k53 ; k53 = "GetItemInfoByShopId"
.line	705	move         r10    r6
.line	705	call          r8     3     2
.line	705	move          r7    r8
.line	705	test          r7     0
.line	705	jmp            0  l126
.line	705	gettabup      r8    u2   k54 ; k54 = "ConvertToShopInfo"
.line	705	move          r9    r7
.line	705	gettable     r10    r0   k47 ; k47 = "tabId"
.line	705	gettable     r11    r0   k48 ; k48 = "subTabId"
.line	705	call          r8     4     2
.line	705	gettabup      r9    u0   k55 ; k55 = "UIManager"
.line	705	gettable      r9    r9   k56 ; k56 = "IsUIShow"
.line	705	gettabup     r10    u0   k55 ; k55 = "UIManager"
.line	705	gettable     r10   r10   k57 ; k57 = "UI_Config"
.line	705	gettable     r10   r10   k58 ; k58 = "Common_Exchange_Conf" (truncated)
.line	705	call          r9     2     2
.line	705	test          r9     0
.line	705	jmp            0  l107
.line	705	gettabup      r9    u0   k55 ; k55 = "UIManager"
.line	705	gettable      r9    r9   k59 ; k59 = "CloseUI"
.line	705	gettabup     r10    u0   k55 ; k55 = "UIManager"
.line	705	gettable     r10   r10   k57 ; k57 = "UI_Config"
.line	705	gettable     r10   r10   k58 ; k58 = "Common_Exchange_Conf" (truncated)
.line	705	call          r9     2     1
.label	l107
.line	705	gettabup      r9    u0   k55 ; k55 = "UIManager"
.line	705	gettable      r9    r9   k56 ; k56 = "IsUIShow"
.line	705	gettabup     r10    u0   k55 ; k55 = "UIManager"
.line	705	gettable     r10   r10   k57 ; k57 = "UI_Config"
.line	705	gettable     r10   r10   k60 ; k60 = "Store_Buy_Slua_BP"
.line	705	call          r9     2     2
.line	705	test          r9     0
.line	705	jmp            0  l121
.line	705	gettabup      r9    u0   k55 ; k55 = "UIManager"
.line	705	gettable      r9    r9   k59 ; k59 = "CloseUI"
.line	705	gettabup     r10    u0   k55 ; k55 = "UIManager"
.line	705	gettable     r10   r10   k57 ; k57 = "UI_Config"
.line	705	gettable     r10   r10   k60 ; k60 = "Store_Buy_Slua_BP"
.line	705	call          r9     2     1
.label	l121
.line	705	self          r9    r0   k61 ; k61 = "AddTimerOnce"
.line	705	loadk        r11   k62 ; k62 = 0
.line	705	closure      r12    f0
.line	705	call          r9     4     1
.line	705	jmp            9  l126
.label	l126
.line	705	return        r0     1
.line	705	move          r0    r0
.line	705	move          r0    r0
.line	705	return        r0     1

.function	main/f29/f0

.source	null
.linedefined	732
.lastlinedefined	734
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	2	false
.upvalue	"U1"	8	true

.constant	k0	"PurchaseItem"

.line	732	gettabup      r0    u0    k0 ; k0 = "PurchaseItem"
.line	732	getupval      r1    u1
.line	732	call          r0     2     1
.line	732	return        r0     1
.line	732	move          r0    r0
.line	732	move          r0    r0
.line	732	move          r0    r0
.line	732	return        r0     1

.function	main/f30

.source	null
.linedefined	738
.lastlinedefined	750
.numparams	2
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"tabId"
.constant	k1	"StoreConst"
.constant	k2	"Page_New_ID_Cloth"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	218
.constant	k7	129
.constant	k8	77
.constant	k9	100
.constant	k10	104
.constant	k11	76
.constant	k12	145
.constant	k13	142
.constant	k14	18
.constant	k15	78
.constant	k16	43
.constant	k17	187
.constant	k18	165
.constant	k19	246
.constant	k20	79
.constant	k21	191
.constant	k22	42
.constant	k23	243
.constant	k24	39
.constant	k25	69
.constant	k26	153
.constant	k27	122
.constant	k28	170
.constant	k29	227
.constant	k30	29
.constant	k31	95
.constant	k32	53
.constant	k33	247
.constant	k34	188
.constant	k35	214
.constant	k36	91
.constant	k37	54
.constant	k38	185
.constant	k39	44
.constant	k40	126
.constant	k41	125
.constant	k42	190
.constant	k43	175
.constant	k44	230
.constant	k45	137
.constant	k46	117
.constant	k47	103
.constant	k48	"GetCurWearData"
.constant	k49	"subTabId"
.constant	k50	0

.line	738	test          r1     0
.line	738	jmp            0    l4
.line	738	return        r1     2
.label	l4
.line	738	gettable      r2    r0    k0 ; k0 = "tabId"
.line	738	gettabup      r3    u0    k1 ; k1 = "StoreConst"
.line	738	gettable      r3    r3    k2 ; k2 = "Page_New_ID_Cloth"
.line	738	eq             0    r2    r3
.line	738	jmp            0   l71
.line	738	gettabup      r2    u0    k3 ; k3 = "require"
.line	738	gettabup      r3    u0    k4 ; k4 = "table"
.line	738	gettable      r3    r3    k5 ; k5 = "concat"
.line	738	newtable      r4     1     0
.line	738	getupval      r5    u1
.line	738	loadk         r6    k6 ; k6 = 218
.line	738	loadk         r7    k7 ; k7 = 129
.line	738	loadk         r8    k8 ; k8 = 77
.line	738	loadk         r9    k9 ; k9 = 100
.line	738	loadk        r10   k10 ; k10 = 104
.line	738	loadk        r11   k11 ; k11 = 76
.line	738	loadk        r12   k12 ; k12 = 145
.line	738	loadk        r13   k13 ; k13 = 142
.line	738	loadk        r14   k14 ; k14 = 18
.line	738	loadk        r15   k15 ; k15 = 78
.line	738	loadk        r16   k16 ; k16 = 43
.line	738	loadk        r17   k17 ; k17 = 187
.line	738	loadk        r18   k18 ; k18 = 165
.line	738	loadk        r19   k19 ; k19 = 246
.line	738	loadk        r20   k20 ; k20 = 79
.line	738	loadk        r21   k21 ; k21 = 191
.line	738	loadk        r22   k22 ; k22 = 42
.line	738	loadk        r23   k23 ; k23 = 243
.line	738	loadk        r24   k24 ; k24 = 39
.line	738	loadk        r25   k25 ; k25 = 69
.line	738	loadk        r26   k26 ; k26 = 153
.line	738	loadk        r27   k27 ; k27 = 122
.line	738	loadk        r28   k28 ; k28 = 170
.line	738	loadk        r29   k29 ; k29 = 227
.line	738	loadk        r30   k30 ; k30 = 29
.line	738	loadk        r31   k31 ; k31 = 95
.line	738	loadk        r32   k32 ; k32 = 53
.line	738	loadk        r33   k33 ; k33 = 247
.line	738	loadk        r34   k34 ; k34 = 188
.line	738	loadk        r35   k35 ; k35 = 214
.line	738	loadk        r36   k36 ; k36 = 91
.line	738	loadk        r37   k28 ; k28 = 170
.line	738	loadk        r38   k37 ; k37 = 54
.line	738	loadk        r39   k38 ; k38 = 185
.line	738	loadk        r40   k39 ; k39 = 44
.line	738	loadk        r41   k40 ; k40 = 126
.line	738	loadk        r42   k12 ; k12 = 145
.line	738	loadk        r43   k41 ; k41 = 125
.line	738	loadk        r44   k42 ; k42 = 190
.line	738	loadk        r45   k43 ; k43 = 175
.line	738	call          r5    41     2
.line	738	getupval      r6    u1
.line	738	loadk         r7   k44 ; k44 = 230
.line	738	loadk         r8   k45 ; k45 = 137
.line	738	loadk         r9   k25 ; k25 = 69
.line	738	loadk        r10   k46 ; k46 = 117
.line	738	loadk        r11   k47 ; k47 = 103
.line	738	call          r6     6     0
.line	738	setlist       r4     0     1
.line	738	call          r3     2     2
.line	738	call          r2     2     2
.line	738	gettable      r3    r2   k48 ; k48 = "GetCurWearData"
.line	738	gettable      r4    r0   k49 ; k49 = "subTabId"
.line	738	call          r3     2     2
.line	738	eq             1    r3   k50 ; k50 = 0
.line	738	jmp            0   l71
.line	738	return        r3     2
.label	l71
.line	738	return        r1     2
.line	738	return        r0     1
.line	738	move          r0    r0
.line	738	move          r0    r0
.line	738	return        r0     1

.function	main/f31

.source	null
.linedefined	752
.lastlinedefined	766
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false

.constant	k0	"showDataList"
.constant	k1	"pairs"
.constant	k2	"shopId"
.constant	k3	"OnClickItemHandle"
.constant	k4	"LoopScrollGrid_0"
.constant	k5	"ScrollToItem"
.constant	k6	"SetBanAutoDownloadList"
.constant	k7	"itemId"
.constant	k8	"StoreConst"
.constant	k9	"store_tab"

.line	752	gettable      r2    r0    k0 ; k0 = "showDataList"
.line	752	test          r2     1
.line	752	jmp            0    l5
.line	752	return        r0     1
.label	l5
.line	752	gettabup      r2    u0    k1 ; k1 = "pairs"
.line	752	gettable      r3    r0    k0 ; k0 = "showDataList"
.line	752	call          r2     2     4
.line	752	jmp            0   l30
.line	752	gettable      r7    r6    k2 ; k2 = "shopId"
.line	752	eq             0    r7    r1
.line	752	jmp            0   l30
.line	752	self          r7    r0    k3 ; k3 = "OnClickItemHandle"
.line	752	move          r9    r6
.line	752	move         r10    r5
.line	752	loadbool     r11     1     0
.line	752	call          r7     5     1
.line	752	gettable      r7    r0    k4 ; k4 = "LoopScrollGrid_0"
.line	752	self          r7    r7    k5 ; k5 = "ScrollToItem"
.line	752	move          r9    r5
.line	752	call          r7     3     1
.line	752	self          r7    r0    k6 ; k6 = "SetBanAutoDownloadLi" (truncated)
.line	752	newtable      r9     1     0
.line	752	gettable     r10    r6    k7 ; k7 = "itemId"
.line	752	setlist       r9     1     1
.line	752	loadnil      r10     0
.line	752	gettabup     r11    u0    k8 ; k8 = "StoreConst"
.line	752	gettable     r11   r11    k9 ; k9 = "store_tab"
.line	752	call          r7     5     1
.line	752	return        r0     1
.label	l30
.line	752	move          r0    r0
.line	752	move          r0    r0
.line	752	return        r0     1
.line	752	move          r0    r0
.line	752	move          r0    r0
.line	752	move          r0    r0
.line	752	return        r0     1

.function	main/f32

.source	null
.linedefined	768
.lastlinedefined	776
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"_clearTimer"
.constant	k1	"RemoveTimer"
.constant	k2	"AddTimerOnce"

.line	768	gettable      r2    r0    k0 ; k0 = "_clearTimer"
.line	768	test          r2     0
.line	768	jmp            0    l7
.line	768	self          r2    r0    k1 ; k1 = "RemoveTimer"
.line	768	gettable      r4    r0    k0 ; k0 = "_clearTimer"
.line	768	call          r2     3     1
.label	l7
.line	768	self          r2    r0    k2 ; k2 = "AddTimerOnce"
.line	768	move          r4    r1
.line	768	closure       r5    f0
.line	768	call          r2     4     2
.line	768	settable      r0    k0    r2 ; k0 = "_clearTimer"
.line	768	return        r0     1
.line	768	move          r0    r0
.line	768	return        r0     1

.function	main/f32/f0

.source	null
.linedefined	772
.lastlinedefined	775
.numparams	0
.is_vararg	0
.maxstacksize	3

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"store_jump_manager"
.constant	k4	"ClearJumpInfo"

.line	772	gettabup      r0    u0    k0 ; k0 = "ModuleManager"
.line	772	gettable      r0    r0    k1 ; k1 = "GetModule"
.line	772	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	772	gettable      r1    r1    k2 ; k2 = "LobbyModuleConfig"
.line	772	gettable      r1    r1    k3 ; k3 = "store_jump_manager"
.line	772	call          r0     2     2
.line	772	self          r1    r0    k4 ; k4 = "ClearJumpInfo"
.line	772	call          r1     2     1
.line	772	return        r0     1
.line	772	move          r0    r0
.line	772	move          r0    r0
.line	772	move          r0    r0
.line	772	return        r0     1

.function	main/f33

.source	null
.linedefined	778
.lastlinedefined	837
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"IsPageShowing"
.constant	k1	"IsPageDataReady"
.constant	k2	"ModuleManager"
.constant	k3	"GetModule"
.constant	k4	"LobbyModuleConfig"
.constant	k5	"store_jump_manager"
.constant	k6	"GetItemIdByJumpInfo"
.constant	k7	"GetShopIdByJumpInfo"
.constant	k8	"log"
.constant	k9	"bWriteLog"
.constant	k10	"string"
.constant	k11	"format"
.constant	k12	"table"
.constant	k13	"concat"
.constant	k14	234
.constant	k15	153
.constant	k16	75
.constant	k17	115
.constant	k18	99
.constant	k19	127
.constant	k20	218
.constant	k21	147
.constant	k22	27
.constant	k23	73
.constant	k24	43
.constant	k25	249
.constant	k26	248
.constant	k27	79
.constant	k28	179
.constant	k29	158
.constant	k30	60
.constant	k31	94
.constant	k32	123
.constant	k33	170
.constant	k34	6
.constant	k35	78
.constant	k36	28
.constant	k37	236
.constant	k38	171
.constant	k39	250
.constant	k40	76
.constant	k41	137
.constant	k42	52
.constant	k43	68
.constant	k44	133
.constant	k45	113
.constant	k46	185
.constant	k47	180
.constant	k48	220
.constant	k49	107
.constant	k50	111
.constant	k51	24
.constant	k52	213
.constant	k53	136
.constant	k54	19
.constant	k55	3
.constant	k56	225
.constant	k57	172
.constant	k58	244
.constant	k59	97
.constant	k60	146
.constant	k61	105
.constant	k62	224
.constant	k63	116
.constant	k64	20
.constant	k65	36
.constant	k66	239
.constant	k67	167
.constant	k68	70
.constant	k69	42
.constant	k70	214
.constant	k71	177
.constant	k72	230
.constant	k73	72
.constant	k74	143
.constant	k75	29
.constant	k76	237
.constant	k77	121
.constant	k78	4
.constant	k79	149
.constant	k80	"showDataList"
.constant	k81	0
.constant	k82	nil
.constant	k83	"JumpItemByShopID"
.constant	k84	"_ClearJumpInfoDelay"
.constant	k85	1
.constant	k86	"GetClothShowTabIcon"
.constant	k87	"pairs"
.constant	k88	"itemId"
.constant	k89	"OnClickItemHandle"
.constant	k90	"ScrollToItem"
.constant	k91	"SetBanAutoDownloadList"
.constant	k92	"StoreConst"
.constant	k93	"store_tab"
.constant	k94	false
.constant	k95	"preItemMap"
.constant	k96	"next"
.constant	k97	"IfNeedChooseTheFirstOne"
.constant	k98	"ShowDefaultScene"

.line	778	self          r1    r0    k0 ; k0 = "IsPageShowing"
.line	778	call          r1     2     2
.line	778	test          r1     0
.line	778	jmp            0  l263
.line	778	self          r1    r0    k1 ; k1 = "IsPageDataReady"
.line	778	call          r1     2     2
.line	778	test          r1     0
.line	778	jmp            0  l263
.line	778	gettabup      r1    u0    k2 ; k2 = "ModuleManager"
.line	778	gettable      r1    r1    k3 ; k3 = "GetModule"
.line	778	gettabup      r2    u0    k2 ; k2 = "ModuleManager"
.line	778	gettable      r2    r2    k4 ; k4 = "LobbyModuleConfig"
.line	778	gettable      r2    r2    k5 ; k5 = "store_jump_manager"
.line	778	call          r1     2     2
.line	778	self          r2    r1    k6 ; k6 = "GetItemIdByJumpInfo"
.line	778	call          r2     2     2
.line	778	self          r3    r1    k7 ; k7 = "GetShopIdByJumpInfo"
.line	778	call          r3     2     2
.line	778	gettabup      r4    u0    k8 ; k8 = "log"
.line	778	gettabup      r5    u0    k9 ; k9 = "bWriteLog"
.line	778	test          r5     0
.line	778	jmp            0  l114
.line	778	gettabup      r5    u0   k10 ; k10 = "string"
.line	778	gettable      r5    r5   k11 ; k11 = "format"
.line	778	gettabup      r6    u0   k12 ; k12 = "table"
.line	778	gettable      r6    r6   k13 ; k13 = "concat"
.line	778	newtable      r7     1     0
.line	778	getupval      r8    u1
.line	778	loadk         r9   k14 ; k14 = 234
.line	778	loadk        r10   k15 ; k15 = 153
.line	778	loadk        r11   k16 ; k16 = 75
.line	778	loadk        r12   k17 ; k17 = 115
.line	778	loadk        r13   k18 ; k18 = 99
.line	778	loadk        r14   k19 ; k19 = 127
.line	778	loadk        r15   k20 ; k20 = 218
.line	778	loadk        r16   k21 ; k21 = 147
.line	778	loadk        r17   k22 ; k22 = 27
.line	778	loadk        r18   k23 ; k23 = 73
.line	778	loadk        r19   k24 ; k24 = 43
.line	778	loadk        r20   k25 ; k25 = 249
.line	778	loadk        r21   k15 ; k15 = 153
.line	778	loadk        r22   k26 ; k26 = 248
.line	778	loadk        r23   k27 ; k27 = 79
.line	778	loadk        r24   k28 ; k28 = 179
.line	778	loadk        r25   k17 ; k17 = 115
.line	778	loadk        r26   k29 ; k29 = 158
.line	778	loadk        r27   k30 ; k30 = 60
.line	778	loadk        r28   k31 ; k31 = 94
.line	778	loadk        r29   k15 ; k15 = 153
.line	778	loadk        r30   k32 ; k32 = 123
.line	778	loadk        r31   k33 ; k33 = 170
.line	778	loadk        r32   k15 ; k15 = 153
.line	778	loadk        r33   k34 ; k34 = 6
.line	778	loadk        r34   k35 ; k35 = 78
.line	778	loadk        r35   k36 ; k36 = 28
.line	778	loadk        r36   k37 ; k37 = 236
.line	778	loadk        r37   k38 ; k38 = 171
.line	778	loadk        r38   k39 ; k39 = 250
.line	778	loadk        r39   k40 ; k40 = 76
.line	778	loadk        r40   k41 ; k41 = 137
.line	778	loadk        r41   k24 ; k24 = 43
.line	778	loadk        r42   k29 ; k29 = 158
.line	778	loadk        r43   k42 ; k42 = 52
.line	778	loadk        r44   k43 ; k43 = 68
.line	778	loadk        r45   k44 ; k44 = 133
.line	778	loadk        r46   k45 ; k45 = 113
.line	778	loadk        r47   k46 ; k46 = 185
.line	778	loadk        r48   k47 ; k47 = 180
.line	778	call          r8    41     2
.line	778	getupval      r9    u1
.line	778	loadk        r10   k48 ; k48 = 220
.line	778	loadk        r11   k41 ; k41 = 137
.line	778	loadk        r12   k49 ; k49 = 107
.line	778	loadk        r13   k50 ; k50 = 111
.line	778	loadk        r14   k18 ; k18 = 99
.line	778	loadk        r15   k51 ; k51 = 24
.line	778	loadk        r16   k52 ; k52 = 213
.line	778	loadk        r17   k53 ; k53 = 136
.line	778	loadk        r18   k54 ; k54 = 19
.line	778	loadk        r19   k16 ; k16 = 75
.line	778	loadk        r20   k55 ; k55 = 3
.line	778	loadk        r21   k56 ; k56 = 225
.line	778	loadk        r22   k57 ; k57 = 172
.line	778	loadk        r23   k58 ; k58 = 244
.line	778	loadk        r24   k59 ; k59 = 97
.line	778	loadk        r25   k60 ; k60 = 146
.line	778	loadk        r26   k61 ; k61 = 105
.line	778	loadk        r27   k62 ; k62 = 224
.line	778	loadk        r28   k63 ; k63 = 116
.line	778	loadk        r29   k64 ; k64 = 20
.line	778	loadk        r30   k44 ; k44 = 133
.line	778	loadk        r31   k65 ; k65 = 36
.line	778	loadk        r32   k66 ; k66 = 239
.line	778	loadk        r33   k67 ; k67 = 167
.line	778	loadk        r34   k22 ; k22 = 27
.line	778	loadk        r35   k68 ; k68 = 70
.line	778	loadk        r36   k69 ; k69 = 42
.line	778	loadk        r37   k70 ; k70 = 214
.line	778	loadk        r38   k71 ; k71 = 177
.line	778	loadk        r39   k72 ; k72 = 230
.line	778	loadk        r40   k73 ; k73 = 72
.line	778	loadk        r41   k74 ; k74 = 143
.line	778	loadk        r42   k75 ; k75 = 29
.line	778	loadk        r43   k76 ; k76 = 237
.line	778	loadk        r44   k77 ; k77 = 121
.line	778	loadk        r45   k78 ; k78 = 4
.line	778	loadk        r46   k79 ; k79 = 149
.line	778	call          r9    38     0
.line	778	setlist       r7     0     1
.line	778	call          r6     2     2
.line	778	move          r7    r2
.line	778	move          r8    r3
.line	778	call          r5     4     2
.label	l114
.line	778	call          r4     2     1
.line	778	gettable      r4    r0   k80 ; k80 = "showDataList"
.line	778	len           r4    r4
.line	778	lt             0   k81    r4 ; k81 = 0
.line	778	jmp            0  l258
.line	778	eq             1    r3   k82 ; k82 = nil
.line	778	jmp            0  l130
.line	778	eq             1    r3   k81 ; k81 = 0
.line	778	jmp            0  l130
.line	778	self          r4    r0   k83 ; k83 = "JumpItemByShopID"
.line	778	move          r6    r3
.line	778	call          r4     3     1
.line	778	self          r4    r0   k84 ; k84 = "_ClearJumpInfoDelay"
.line	778	loadk         r6   k85 ; k85 = 1
.line	778	call          r4     3     1
.line	778	return        r0     1
.label	l130
.line	778	self          r4    r0   k86 ; k86 = "GetClothShowTabIcon"
.line	778	move          r6    r2
.line	778	call          r4     3     2
.line	778	move          r2    r4
.line	778	eq             1    r2   k82 ; k82 = nil
.line	778	jmp            0  l230
.line	778	loadbool      r4     0     0
.line	778	gettabup      r5    u0   k87 ; k87 = "pairs"
.line	778	gettable      r6    r0   k80 ; k80 = "showDataList"
.line	778	call          r5     2     4
.line	778	jmp            0  l165
.line	778	gettable     r10    r9   k88 ; k88 = "itemId"
.line	778	eq             0   r10    r2
.line	778	jmp            0  l165
.line	778	self         r10    r0   k89 ; k89 = "OnClickItemHandle"
.line	778	move         r12    r9
.line	778	move         r13    r8
.line	778	loadbool     r14     1     0
.line	778	call         r10     5     1
.line	778	self         r10    r0   k90 ; k90 = "ScrollToItem"
.line	778	move         r12    r8
.line	778	call         r10     3     1
.line	778	loadbool      r4     1     0
.line	778	self         r10    r0   k84 ; k84 = "_ClearJumpInfoDelay"
.line	778	loadk        r12   k85 ; k85 = 1
.line	778	call         r10     3     1
.line	778	self         r10    r0   k91 ; k91 = "SetBanAutoDownloadLi" (truncated)
.line	778	newtable     r12     1     0
.line	778	gettable     r13    r9   k88 ; k88 = "itemId"
.line	778	setlist      r12     1     1
.line	778	loadnil      r13     0
.line	778	gettabup     r14    u0   k92 ; k92 = "StoreConst"
.line	778	gettable     r14   r14   k93 ; k93 = "store_tab"
.line	778	call         r10     5     1
.line	778	return        r0     1
.label	l165
.line	778	move          r0    r0
.line	778	move          r0    r0
.line	778	eq             0    r4   k94 ; k94 = false
.line	778	jmp            0  l205
.line	778	gettable      r5    r0   k95 ; k95 = "preItemMap"
.line	778	test          r5     0
.line	778	jmp            0  l205
.line	778	gettabup      r5    u0   k96 ; k96 = "next"
.line	778	gettable      r6    r0   k95 ; k95 = "preItemMap"
.line	778	call          r5     2     2
.line	778	eq             1    r5   k82 ; k82 = nil
.line	778	jmp            0  l205
.line	778	gettabup      r5    u0   k87 ; k87 = "pairs"
.line	778	gettable      r6    r0   k80 ; k80 = "showDataList"
.line	778	call          r5     2     4
.line	778	jmp            0  l203
.line	778	gettable     r10    r0   k95 ; k95 = "preItemMap"
.line	778	gettable     r11    r9   k88 ; k88 = "itemId"
.line	778	gettable     r10   r10   r11
.line	778	eq             0   r10    r2
.line	778	jmp            0  l203
.line	778	self         r10    r0   k89 ; k89 = "OnClickItemHandle"
.line	778	move         r12    r9
.line	778	move         r13    r8
.line	778	call         r10     4     1
.line	778	self         r10    r0   k90 ; k90 = "ScrollToItem"
.line	778	move         r12    r8
.line	778	call         r10     3     1
.line	778	loadbool      r4     1     0
.line	778	self         r10    r0   k91 ; k91 = "SetBanAutoDownloadLi" (truncated)
.line	778	newtable     r12     1     0
.line	778	gettable     r13    r9   k88 ; k88 = "itemId"
.line	778	setlist      r12     1     1
.line	778	loadnil      r13     0
.line	778	gettabup     r14    u0   k92 ; k92 = "StoreConst"
.line	778	gettable     r14   r14   k93 ; k93 = "store_tab"
.line	778	call         r10     5     1
.line	778	jmp            0  l205
.label	l203
.line	778	move          r0    r0
.line	778	move          r0    r0
.label	l205
.line	778	eq             0    r4   k94 ; k94 = false
.line	778	jmp            0  l260
.line	778	self          r5    r0   k89 ; k89 = "OnClickItemHandle"
.line	778	gettable      r7    r0   k80 ; k80 = "showDataList"
.line	778	gettable      r7    r7   k85 ; k85 = 1
.line	778	loadk         r8   k85 ; k85 = 1
.line	778	call          r5     4     1
.line	778	self          r5    r0   k90 ; k90 = "ScrollToItem"
.line	778	loadk         r7   k85 ; k85 = 1
.line	778	call          r5     3     1
.line	778	self          r5    r0   k91 ; k91 = "SetBanAutoDownloadLi" (truncated)
.line	778	newtable      r7     1     0
.line	778	gettable      r8    r0   k80 ; k80 = "showDataList"
.line	778	gettable      r8    r8   k85 ; k85 = 1
.line	778	test          r8     0
.line	778	jmp            0  l224
.line	778	gettable      r8    r0   k80 ; k80 = "showDataList"
.line	778	gettable      r8    r8   k85 ; k85 = 1
.line	778	gettable      r8    r8   k88 ; k88 = "itemId"
.label	l224
.line	778	setlist       r7     1     1
.line	778	loadnil       r8     0
.line	778	gettabup      r9    u0   k92 ; k92 = "StoreConst"
.line	778	gettable      r9    r9   k93 ; k93 = "store_tab"
.line	778	call          r5     5     1
.line	778	jmp            0  l260
.label	l230
.line	778	self          r4    r0   k97 ; k97 = "IfNeedChooseTheFirst" (truncated)
.line	778	call          r4     2     2
.line	778	test          r4     0
.line	778	jmp            0  l260
.line	778	self          r4    r0   k89 ; k89 = "OnClickItemHandle"
.line	778	gettable      r6    r0   k80 ; k80 = "showDataList"
.line	778	gettable      r6    r6   k85 ; k85 = 1
.line	778	loadk         r7   k85 ; k85 = 1
.line	778	loadbool      r8     1     0
.line	778	call          r4     5     1
.line	778	self          r4    r0   k90 ; k90 = "ScrollToItem"
.line	778	loadk         r6   k85 ; k85 = 1
.line	778	call          r4     3     1
.line	778	self          r4    r0   k91 ; k91 = "SetBanAutoDownloadLi" (truncated)
.line	778	newtable      r6     1     0
.line	778	gettable      r7    r0   k80 ; k80 = "showDataList"
.line	778	gettable      r7    r7   k85 ; k85 = 1
.line	778	test          r7     0
.line	778	jmp            0  l252
.line	778	gettable      r7    r0   k80 ; k80 = "showDataList"
.line	778	gettable      r7    r7   k85 ; k85 = 1
.line	778	gettable      r7    r7   k88 ; k88 = "itemId"
.label	l252
.line	778	setlist       r6     1     1
.line	778	loadnil       r7     0
.line	778	gettabup      r8    u0   k92 ; k92 = "StoreConst"
.line	778	gettable      r8    r8   k93 ; k93 = "store_tab"
.line	778	call          r4     5     1
.line	778	jmp            0  l260
.label	l258
.line	778	self          r4    r0   k98 ; k98 = "ShowDefaultScene"
.line	778	call          r4     2     1
.label	l260
.line	778	self          r4    r0   k84 ; k84 = "_ClearJumpInfoDelay"
.line	778	loadk         r6   k85 ; k85 = 1
.line	778	call          r4     3     1
.label	l263
.line	778	return        r0     1
.line	778	move          r0    r0
.line	778	move          r0    r0
.line	778	move          r0    r0
.line	778	return        r0     1

.function	main/f34

.source	null
.linedefined	839
.lastlinedefined	846
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	142
.constant	k18	60
.constant	k19	94
.constant	k20	129
.constant	k21	76
.constant	k22	170
.constant	k23	171
.constant	k24	15
.constant	k25	54
.constant	k26	241
.constant	k27	138
.constant	k28	93
.constant	k29	168
.constant	k30	"GetFrame"
.constant	k31	"ClearItemPreview"
.constant	k32	"require"
.constant	k33	77
.constant	k34	100
.constant	k35	104
.constant	k36	145
.constant	k37	17
.constant	k38	92
.constant	k39	35
.constant	k40	246
.constant	k41	231
.constant	k42	183
.constant	k43	61
.constant	k44	188
.constant	k45	38
.constant	k46	31
.constant	k47	187
.constant	k48	103
.constant	k49	2
.constant	k50	111
.constant	k51	51
.constant	k52	169
.constant	k53	229
.constant	k54	89
.constant	k55	191
.constant	k56	"SwitchToAvatar"
.constant	k57	"ModuleManager"
.constant	k58	"GetModule"
.constant	k59	"LobbyModuleConfig"
.constant	k60	"StoreDetailManager"
.constant	k61	"SetDefaultSceneByType"
.constant	k62	"StoreConst"
.constant	k63	"store_tab"

.line	839	gettabup      r1    u0    k0 ; k0 = "log"
.line	839	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	839	test          r2     0
.line	839	jmp            0   l40
.line	839	getupval      r2    u1
.line	839	loadk         r3    k2 ; k2 = 234
.line	839	loadk         r4    k3 ; k3 = 153
.line	839	loadk         r5    k4 ; k4 = 75
.line	839	loadk         r6    k5 ; k5 = 115
.line	839	loadk         r7    k6 ; k6 = 99
.line	839	loadk         r8    k7 ; k7 = 127
.line	839	loadk         r9    k8 ; k8 = 218
.line	839	loadk        r10    k9 ; k9 = 147
.line	839	loadk        r11   k10 ; k10 = 27
.line	839	loadk        r12   k11 ; k11 = 73
.line	839	loadk        r13   k12 ; k12 = 43
.line	839	loadk        r14   k13 ; k13 = 249
.line	839	loadk        r15    k3 ; k3 = 153
.line	839	loadk        r16   k14 ; k14 = 248
.line	839	loadk        r17   k15 ; k15 = 79
.line	839	loadk        r18   k16 ; k16 = 179
.line	839	loadk        r19    k5 ; k5 = 115
.line	839	loadk        r20   k17 ; k17 = 142
.line	839	loadk        r21   k18 ; k18 = 60
.line	839	loadk        r22   k19 ; k19 = 94
.line	839	loadk        r23   k20 ; k20 = 129
.line	839	loadk        r24   k21 ; k21 = 76
.line	839	loadk        r25   k22 ; k22 = 170
.line	839	loadk        r26   k23 ; k23 = 171
.line	839	loadk        r27   k24 ; k24 = 15
.line	839	loadk        r28   k19 ; k19 = 94
.line	839	loadk        r29   k25 ; k25 = 54
.line	839	loadk        r30   k26 ; k26 = 241
.line	839	loadk        r31   k27 ; k27 = 138
.line	839	loadk        r32    k2 ; k2 = 234
.line	839	loadk        r33   k28 ; k28 = 93
.line	839	loadk        r34   k29 ; k29 = 168
.line	839	loadk        r35   k18 ; k18 = 60
.line	839	call          r2    34     2
.label	l40
.line	839	call          r1     2     1
.line	839	self          r1    r0   k30 ; k30 = "GetFrame"
.line	839	call          r1     2     2
.line	839	self          r1    r1   k31 ; k31 = "ClearItemPreview"
.line	839	call          r1     2     1
.line	839	gettabup      r1    u0   k32 ; k32 = "require"
.line	839	getupval      r2    u1
.line	839	loadk         r3    k8 ; k8 = 218
.line	839	loadk         r4   k20 ; k20 = 129
.line	839	loadk         r5   k33 ; k33 = 77
.line	839	loadk         r6   k34 ; k34 = 100
.line	839	loadk         r7   k35 ; k35 = 104
.line	839	loadk         r8   k21 ; k21 = 76
.line	839	loadk         r9   k36 ; k36 = 145
.line	839	loadk        r10   k36 ; k36 = 145
.line	839	loadk        r11   k37 ; k37 = 17
.line	839	loadk        r12   k38 ; k38 = 92
.line	839	loadk        r13   k39 ; k39 = 35
.line	839	loadk        r14   k40 ; k40 = 246
.line	839	loadk        r15   k41 ; k41 = 231
.line	839	loadk        r16   k14 ; k14 = 248
.line	839	loadk        r17   k19 ; k19 = 94
.line	839	loadk        r18   k42 ; k42 = 183
.line	839	loadk        r19   k43 ; k43 = 61
.line	839	loadk        r20   k44 ; k44 = 188
.line	839	loadk        r21   k45 ; k45 = 38
.line	839	loadk        r22   k46 ; k46 = 31
.line	839	loadk        r23   k47 ; k47 = 187
.line	839	loadk        r24   k48 ; k48 = 103
.line	839	loadk        r25   k23 ; k23 = 171
.line	839	loadk        r26   k29 ; k29 = 168
.line	839	loadk        r27   k49 ; k49 = 2
.line	839	loadk        r28   k50 ; k50 = 111
.line	839	loadk        r29   k51 ; k51 = 51
.line	839	loadk        r30   k40 ; k40 = 246
.line	839	loadk        r31   k52 ; k52 = 169
.line	839	loadk        r32   k53 ; k53 = 229
.line	839	loadk        r33   k54 ; k54 = 89
.line	839	loadk        r34   k55 ; k55 = 191
.line	839	loadk        r35   k18 ; k18 = 60
.line	839	loadk        r36   k55 ; k55 = 191
.line	839	call          r2    35     2
.line	839	call          r1     2     2
.line	839	gettable      r2    r1   k56 ; k56 = "SwitchToAvatar"
.line	839	call          r2     1     1
.line	839	gettabup      r2    u0   k57 ; k57 = "ModuleManager"
.line	839	gettable      r2    r2   k58 ; k58 = "GetModule"
.line	839	gettabup      r3    u0   k57 ; k57 = "ModuleManager"
.line	839	gettable      r3    r3   k59 ; k59 = "LobbyModuleConfig"
.line	839	gettable      r3    r3   k60 ; k60 = "StoreDetailManager"
.line	839	call          r2     2     2
.line	839	self          r3    r2   k61 ; k61 = "SetDefaultSceneByTyp" (truncated)
.line	839	gettabup      r5    u0   k62 ; k62 = "StoreConst"
.line	839	gettable      r5    r5   k63 ; k63 = "store_tab"
.line	839	call          r3     3     1
.line	839	return        r0     1
.line	839	move          r0    r0
.line	839	return        r0     1

.function	main/f35

.source	null
.linedefined	848
.lastlinedefined	869
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"showDataList"
.constant	k1	1
.constant	k2	"itemId"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	218
.constant	k7	129
.constant	k8	77
.constant	k9	100
.constant	k10	104
.constant	k11	76
.constant	k12	145
.constant	k13	142
.constant	k14	18
.constant	k15	78
.constant	k16	43
.constant	k17	187
.constant	k18	165
.constant	k19	246
.constant	k20	79
.constant	k21	191
.constant	k22	42
.constant	k23	243
.constant	k24	48
.constant	k25	94
.constant	k26	102
.constant	k27	163
.constant	k28	162
.constant	k29	15
.constant	k30	116
.constant	k31	245
.constant	k32	172
.constant	k33	239
.constant	k34	227
.constant	k35	52
.constant	k36	84
.constant	k37	128
.constant	k38	126
.constant	k39	186
.constant	k40	175
.constant	k41	230
.constant	k42	69
.constant	k43	111
.constant	k44	103
.constant	k45	95
.constant	k46	143
.constant	k47	146
.constant	k48	39
.constant	k49	136
.constant	k50	107
.constant	k51	171
.constant	k52	"tabId"
.constant	k53	"StoreConst"
.constant	k54	"Page_New_ID_Recommend"
.constant	k55	"subTabId"
.constant	k56	"subtype_new_recommend_ucb"
.constant	k57	"subtype_new_recommend_dol"
.constant	k58	"GetGiftResIdListForReadyCheck"
.constant	k59	0
.constant	k60	"RequestFirstGiftInfoForReadyCheck"
.constant	k61	"GetItemDownloadResIdList"
.constant	k62	"GetState"
.constant	k63	"ENUM_DownloadType"
.constant	k64	"ODPAK"
.constant	k65	"ENUM_DownloadState"
.constant	k66	"Done"

.line	848	gettable      r1    r0    k0 ; k0 = "showDataList"
.line	848	test          r1     0
.line	848	jmp            0    l6
.line	848	gettable      r1    r0    k0 ; k0 = "showDataList"
.line	848	gettable      r1    r1    k1 ; k1 = 1
.label	l6
.line	848	test          r1     0
.line	848	jmp            0   l11
.line	848	gettable      r2    r1    k2 ; k2 = "itemId"
.line	848	test          r2     1
.line	848	jmp            0   l13
.label	l11
.line	848	loadbool      r2     0     0
.line	848	return        r2     2
.label	l13
.line	848	gettabup      r2    u0    k3 ; k3 = "require"
.line	848	gettabup      r3    u0    k4 ; k4 = "table"
.line	848	gettable      r3    r3    k5 ; k5 = "concat"
.line	848	newtable      r4     1     0
.line	848	getupval      r5    u1
.line	848	loadk         r6    k6 ; k6 = 218
.line	848	loadk         r7    k7 ; k7 = 129
.line	848	loadk         r8    k8 ; k8 = 77
.line	848	loadk         r9    k9 ; k9 = 100
.line	848	loadk        r10   k10 ; k10 = 104
.line	848	loadk        r11   k11 ; k11 = 76
.line	848	loadk        r12   k12 ; k12 = 145
.line	848	loadk        r13   k13 ; k13 = 142
.line	848	loadk        r14   k14 ; k14 = 18
.line	848	loadk        r15   k15 ; k15 = 78
.line	848	loadk        r16   k16 ; k16 = 43
.line	848	loadk        r17   k17 ; k17 = 187
.line	848	loadk        r18   k18 ; k18 = 165
.line	848	loadk        r19   k19 ; k19 = 246
.line	848	loadk        r20   k20 ; k20 = 79
.line	848	loadk        r21   k21 ; k21 = 191
.line	848	loadk        r22   k22 ; k22 = 42
.line	848	loadk        r23   k23 ; k23 = 243
.line	848	loadk        r24   k24 ; k24 = 48
.line	848	loadk        r25   k25 ; k25 = 94
.line	848	loadk        r26    k7 ; k7 = 129
.line	848	loadk        r27   k26 ; k26 = 102
.line	848	loadk        r28   k27 ; k27 = 163
.line	848	loadk        r29   k28 ; k28 = 162
.line	848	loadk        r30   k29 ; k29 = 15
.line	848	loadk        r31   k20 ; k20 = 79
.line	848	loadk        r32   k30 ; k30 = 116
.line	848	loadk        r33   k31 ; k31 = 245
.line	848	loadk        r34   k32 ; k32 = 172
.line	848	loadk        r35   k33 ; k33 = 239
.line	848	loadk        r36   k25 ; k25 = 94
.line	848	loadk        r37   k27 ; k27 = 163
.line	848	loadk        r38   k16 ; k16 = 43
.line	848	loadk        r39   k34 ; k34 = 227
.line	848	loadk        r40   k35 ; k35 = 52
.line	848	loadk        r41   k36 ; k36 = 84
.line	848	loadk        r42   k37 ; k37 = 128
.line	848	loadk        r43   k38 ; k38 = 126
.line	848	loadk        r44   k39 ; k39 = 186
.line	848	loadk        r45   k40 ; k40 = 175
.line	848	call          r5    41     2
.line	848	getupval      r6    u1
.line	848	loadk         r7   k41 ; k41 = 230
.line	848	loadk         r8   k37 ; k37 = 128
.line	848	loadk         r9   k42 ; k42 = 69
.line	848	loadk        r10   k43 ; k43 = 111
.line	848	loadk        r11   k44 ; k44 = 103
.line	848	loadk        r12   k45 ; k45 = 95
.line	848	loadk        r13    k6 ; k6 = 218
.line	848	loadk        r14   k46 ; k46 = 143
.line	848	call          r6     9     0
.line	848	setlist       r4     0     1
.line	848	call          r3     2     2
.line	848	call          r2     2     2
.line	848	gettabup      r3    u0    k3 ; k3 = "require"
.line	848	getupval      r4    u1
.line	848	loadk         r5    k6 ; k6 = 218
.line	848	loadk         r6    k7 ; k7 = 129
.line	848	loadk         r7    k8 ; k8 = 77
.line	848	loadk         r8    k9 ; k9 = 100
.line	848	loadk         r9   k10 ; k10 = 104
.line	848	loadk        r10   k11 ; k11 = 76
.line	848	loadk        r11   k12 ; k12 = 145
.line	848	loadk        r12   k13 ; k13 = 142
.line	848	loadk        r13   k14 ; k14 = 18
.line	848	loadk        r14   k15 ; k15 = 78
.line	848	loadk        r15   k16 ; k16 = 43
.line	848	loadk        r16   k17 ; k17 = 187
.line	848	loadk        r17   k18 ; k18 = 165
.line	848	loadk        r18   k19 ; k19 = 246
.line	848	loadk        r19   k20 ; k20 = 79
.line	848	loadk        r20   k21 ; k21 = 191
.line	848	loadk        r21   k22 ; k22 = 42
.line	848	loadk        r22   k23 ; k23 = 243
.line	848	loadk        r23   k24 ; k24 = 48
.line	848	loadk        r24   k25 ; k25 = 94
.line	848	loadk        r25    k7 ; k7 = 129
.line	848	loadk        r26   k26 ; k26 = 102
.line	848	loadk        r27   k27 ; k27 = 163
.line	848	loadk        r28   k28 ; k28 = 162
.line	848	loadk        r29   k29 ; k29 = 15
.line	848	loadk        r30   k20 ; k20 = 79
.line	848	loadk        r31   k30 ; k30 = 116
.line	848	loadk        r32   k31 ; k31 = 245
.line	848	loadk        r33   k32 ; k32 = 172
.line	848	loadk        r34   k33 ; k33 = 239
.line	848	loadk        r35   k25 ; k25 = 94
.line	848	loadk        r36   k27 ; k27 = 163
.line	848	loadk        r37   k16 ; k16 = 43
.line	848	loadk        r38   k47 ; k47 = 146
.line	848	loadk        r39   k48 ; k48 = 39
.line	848	loadk        r40   k15 ; k15 = 78
.line	848	loadk        r41   k49 ; k49 = 136
.line	848	loadk        r42   k50 ; k50 = 107
.line	848	loadk        r43   k51 ; k51 = 171
.line	848	call          r4    40     2
.line	848	call          r3     2     2
.line	848	loadnil       r4     0
.line	848	gettable      r5    r0   k52 ; k52 = "tabId"
.line	848	gettabup      r6    u0   k53 ; k53 = "StoreConst"
.line	848	gettable      r6    r6   k54 ; k54 = "Page_New_ID_Recommen" (truncated)
.line	848	eq             0    r5    r6
.line	848	jmp            0  l146
.line	848	gettable      r5    r0   k55 ; k55 = "subTabId"
.line	848	gettabup      r6    u0   k53 ; k53 = "StoreConst"
.line	848	gettable      r6    r6   k56 ; k56 = "subtype_new_recommen" (truncated)
.line	848	eq             1    r5    r6
.line	848	jmp            0  l131
.line	848	gettable      r5    r0   k55 ; k55 = "subTabId"
.line	848	gettabup      r6    u0   k53 ; k53 = "StoreConst"
.line	848	gettable      r6    r6   k57 ; k57 = "subtype_new_recommen" (truncated)
.line	848	eq             0    r5    r6
.line	848	jmp            0  l146
.label	l131
.line	848	self          r5    r0   k58 ; k58 = "GetGiftResIdListForR" (truncated)
.line	848	move          r7    r1
.line	848	call          r5     3     2
.line	848	move          r4    r5
.line	848	test          r4     0
.line	848	jmp            0  l140
.line	848	len           r5    r4
.line	848	le             0    r5   k59 ; k59 = 0
.line	848	jmp            0  l151
.label	l140
.line	848	self          r5    r0   k60 ; k60 = "RequestFirstGiftInfo" (truncated)
.line	848	move          r7    r1
.line	848	call          r5     3     1
.line	848	loadbool      r5     0     0
.line	848	return        r5     2
.line	848	jmp            0  l151
.label	l146
.line	848	gettabup      r5    u2   k61 ; k61 = "GetItemDownloadResId" (truncated)
.line	848	gettable      r6    r1    k2 ; k2 = "itemId"
.line	848	gettable      r7    r0   k52 ; k52 = "tabId"
.line	848	call          r5     3     2
.line	848	move          r4    r5
.label	l151
.line	848	test          r4     0
.line	848	jmp            0  l156
.line	848	len           r5    r4
.line	848	le             0    r5   k59 ; k59 = 0
.line	848	jmp            0  l158
.label	l156
.line	848	loadbool      r5     1     0
.line	848	return        r5     2
.label	l158
.line	848	gettable      r5    r2   k62 ; k62 = "GetState"
.line	848	gettable      r6    r3   k63 ; k63 = "ENUM_DownloadType"
.line	848	gettable      r6    r6   k64 ; k64 = "ODPAK"
.line	848	move          r7    r4
.line	848	call          r5     3     2
.line	848	gettable      r6    r3   k65 ; k65 = "ENUM_DownloadState"
.line	848	gettable      r6    r6   k66 ; k66 = "Done"
.line	848	eq             1    r5    r6
.line	848	jmp            0  l168
.line	848	loadbool      r5     0     1
.label	l168
.line	848	loadbool      r5     1     0
.line	848	return        r5     2
.line	848	return        r0     1
.line	848	move          r0    r0
.line	848	gettabup      r1    u1   k46 ; k46 = 143
.line	848	return        r0     1

.function	main/f36

.source	null
.linedefined	871
.lastlinedefined	920
.numparams	2
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"treasure_chest_manager"
.constant	k4	"subTabId"
.constant	k5	"StoreConst"
.constant	k6	"subtype_new_recommend_ucb"
.constant	k7	"shopId"
.constant	k8	"chest_info"
.constant	k9	"data"
.constant	k10	"GetChestAwards"
.constant	k11	"chestItemList"
.constant	k12	"GetChestItemsDownloadResIdList"
.constant	k13	"itemId"
.constant	k14	"ipairs"
.constant	k15	true
.constant	k16	"CDataTable"
.constant	k17	"GetTableData"
.constant	k18	240
.constant	k19	153
.constant	k20	65
.constant	k21	108
.constant	k22	"ItemSmallIcon"
.constant	k23	"ItemSmallIcon2"
.constant	k24	"ItemBigIcon"
.constant	k25	"ItemBigIcon2"
.constant	k26	"Preview"
.constant	k27	"GetItemBPResPathList"

.line	871	test          r1     1
.line	871	jmp            0    l5
.line	871	loadnil       r2     0
.line	871	return        r2     2
.label	l5
.line	871	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	871	gettable      r2    r2    k1 ; k1 = "GetModule"
.line	871	gettabup      r3    u0    k0 ; k0 = "ModuleManager"
.line	871	gettable      r3    r3    k2 ; k2 = "LobbyModuleConfig"
.line	871	gettable      r3    r3    k3 ; k3 = "treasure_chest_manag" (truncated)
.line	871	call          r2     2     2
.line	871	test          r2     1
.line	871	jmp            0   l15
.line	871	loadnil       r3     0
.line	871	return        r3     2
.label	l15
.line	871	loadnil       r3     0
.line	871	gettable      r4    r0    k4 ; k4 = "subTabId"
.line	871	gettabup      r5    u0    k5 ; k5 = "StoreConst"
.line	871	gettable      r5    r5    k6 ; k6 = "subtype_new_recommen" (truncated)
.line	871	eq             0    r4    r5
.line	871	jmp            0   l39
.line	871	gettable      r4    r1    k7 ; k7 = "shopId"
.line	871	gettable      r5    r2    k8 ; k8 = "chest_info"
.line	871	test          r5     0
.line	871	jmp            0   l27
.line	871	gettable      r5    r2    k8 ; k8 = "chest_info"
.line	871	gettable      r5    r5    r4
.label	l27
.line	871	test          r5     0
.line	871	jmp            0   l32
.line	871	gettable      r6    r5    k9 ; k9 = "data"
.line	871	test          r6     1
.line	871	jmp            0   l34
.label	l32
.line	871	loadnil       r6     0
.line	871	return        r6     2
.label	l34
.line	871	self          r6    r2   k10 ; k10 = "GetChestAwards"
.line	871	gettable      r8    r5    k9 ; k9 = "data"
.line	871	call          r6     3     2
.line	871	move          r3    r6
.line	871	jmp            0   l40
.label	l39
.line	871	gettable      r3    r1   k11 ; k11 = "chestItemList"
.label	l40
.line	871	self          r4    r2   k12 ; k12 = "GetChestItemsDownloa" (truncated)
.line	871	move          r6    r3
.line	871	call          r4     3     2
.line	871	test          r4     0
.line	871	jmp            0  l101
.line	871	gettable      r5    r1   k13 ; k13 = "itemId"
.line	871	test          r5     0
.line	871	jmp            0  l101
.line	871	newtable      r5     0     0
.line	871	gettabup      r6    u0   k14 ; k14 = "ipairs"
.line	871	move          r7    r4
.line	871	call          r6     2     4
.line	871	jmp            0   l54
.line	871	settable      r5   r10   k15 ; k15 = true
.label	l54
.line	871	move          r0    r0
.line	871	move          r0    r0
.line	871	closure       r6    f0
.line	871	move          r7    r6
.line	871	gettable      r8    r1   k13 ; k13 = "itemId"
.line	871	call          r7     2     1
.line	871	gettabup      r7    u0   k16 ; k16 = "CDataTable"
.line	871	gettable      r7    r7   k17 ; k17 = "GetTableData"
.line	871	getupval      r8    u1
.line	871	loadk         r9   k18 ; k18 = 240
.line	871	loadk        r10   k19 ; k19 = 153
.line	871	loadk        r11   k20 ; k20 = 65
.line	871	loadk        r12   k21 ; k21 = 108
.line	871	call          r8     5     2
.line	871	gettable      r9    r1   k13 ; k13 = "itemId"
.line	871	call          r7     3     2
.line	871	test          r7     0
.line	871	jmp            6  l101
.line	871	move          r8    r6
.line	871	gettable      r9    r7   k22 ; k22 = "ItemSmallIcon"
.line	871	call          r8     2     1
.line	871	move          r8    r6
.line	871	gettable      r9    r7   k23 ; k23 = "ItemSmallIcon2"
.line	871	call          r8     2     1
.line	871	move          r8    r6
.line	871	gettable      r9    r7   k24 ; k24 = "ItemBigIcon"
.line	871	call          r8     2     1
.line	871	move          r8    r6
.line	871	gettable      r9    r7   k25 ; k25 = "ItemBigIcon2"
.line	871	call          r8     2     1
.line	871	move          r8    r6
.line	871	gettable      r9    r7   k26 ; k26 = "Preview"
.line	871	call          r8     2     1
.line	871	self          r8    r2   k27 ; k27 = "GetItemBPResPathList"
.line	871	gettable     r10    r1   k13 ; k13 = "itemId"
.line	871	move         r11    r7
.line	871	call          r8     4     2
.line	871	gettabup      r9    u0   k14 ; k14 = "ipairs"
.line	871	move         r10    r8
.line	871	call          r9     2     4
.line	871	jmp            0   l98
.line	871	move         r14    r6
.line	871	move         r15   r13
.line	871	call         r14     2     1
.label	l98
.line	871	move          r0    r0
.line	871	move          r0    r0
.line	871	jmp            6  l101
.label	l101
.line	871	return        r4     2
.line	871	return        r0     1
.line	871	move          r0    r0
.line	871	move          r0    r0
.line	871	return        r0     1

.function	main/f36/f0

.source	null
.linedefined	896
.lastlinedefined	902
.numparams	1
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	1	false
.upvalue	"U1"	5	true
.upvalue	"U2"	4	true

.constant	k0	nil
.constant	k1	0
.constant	k2	true
.constant	k3	1

.line	896	eq             1    r0    k0 ; k0 = nil
.line	896	jmp            0   l12
.line	896	getupval      r1    u0
.line	896	call          r1     1     2
.line	896	eq             1    r0    r1
.line	896	jmp            0   l12
.line	896	eq             1    r0    k1 ; k1 = 0
.line	896	jmp            0   l12
.line	896	gettabup      r1    u1    r0
.line	896	test          r1     0
.line	896	jmp            0   l13
.label	l12
.line	896	return        r0     1
.label	l13
.line	896	settabup      u1    r0    k2 ; k2 = true
.line	896	move          r0    r0
.line	896	len           r1    r1
.line	896	add           r1    r1    k3 ; k3 = 1
.line	896	move          r0    r0
.line	896	return        r0     1
.line	896	move          r0    r0
.line	896	move          r0    r0
.line	896	move          r0    r0
.line	896	return        r0     1

.function	main/f37

.source	null
.linedefined	922
.lastlinedefined	927
.numparams	2
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false

.constant	k0	"subTabId"
.constant	k1	"StoreConst"
.constant	k2	"subtype_new_recommend_ucb"
.constant	k3	"bPendingGiftFirstSelect"
.constant	k4	true

.line	922	gettable      r2    r0    k0 ; k0 = "subTabId"
.line	922	gettabup      r3    u0    k1 ; k1 = "StoreConst"
.line	922	gettable      r3    r3    k2 ; k2 = "subtype_new_recommen" (truncated)
.line	922	eq             1    r2    r3
.line	922	jmp            0    l7
.line	922	return        r0     1
.label	l7
.line	922	settable      r0    k3    k4 ; k4 = true
.line	922	return        r0     1
.line	922	move          r0    r0
.line	922	move          r0    r0
.line	922	return        r0     1

.function	main/f38

.source	null
.linedefined	929
.lastlinedefined	944
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"tabId"
.constant	k1	"StoreConst"
.constant	k2	"Page_New_ID_Cloth"
.constant	k3	"Page_New_ID_Exchange"
.constant	k4	"Page_New_ID_Other"
.constant	k5	"subTabId"
.constant	k6	"subtype_new_other_theme"
.constant	k7	"Page_ID_Season"
.constant	k8	"subtype_new_exchange_fra"
.constant	k9	"label_subtype_new_season_mall"
.constant	k10	"require"
.constant	k11	"table"
.constant	k12	"concat"
.constant	k13	218
.constant	k14	129
.constant	k15	77
.constant	k16	100
.constant	k17	104
.constant	k18	76
.constant	k19	145
.constant	k20	142
.constant	k21	18
.constant	k22	78
.constant	k23	43
.constant	k24	187
.constant	k25	170
.constant	k26	246
.constant	k27	70
.constant	k28	176
.constant	k29	32
.constant	k30	186
.constant	k31	122
.constant	k32	114
.constant	k33	154
.constant	k34	97
.constant	k35	163
.constant	k36	26
.constant	k37	102
.constant	k38	59
.constant	k39	230
.constant	k40	171
.constant	k41	75
.constant	k42	232
.constant	k43	9
.constant	k44	184
.constant	k45	38
.constant	k46	143
.constant	k47	107
.constant	k48	183
.constant	k49	220
.constant	k50	138
.constant	k51	110
.constant	k52	117
.constant	k53	222
.constant	k54	158
.constant	k55	12
.constant	k56	84
.constant	k57	57
.constant	k58	"IsFITVersion"
.constant	k59	"showDataList"
.constant	k60	0
.constant	k61	"IsFirstItemResReady"
.constant	k62	"log"
.constant	k63	"bWriteLog"
.constant	k64	234
.constant	k65	153
.constant	k66	115
.constant	k67	99
.constant	k68	127
.constant	k69	147
.constant	k70	27
.constant	k71	73
.constant	k72	249
.constant	k73	248
.constant	k74	79
.constant	k75	179
.constant	k76	148
.constant	k77	50
.constant	k78	109
.constant	k79	6
.constant	k80	68
.constant	k81	53
.constant	k82	188
.constant	k83	221
.constant	k84	80
.constant	k85	31
.constant	k86	164
.constant	k87	54
.constant	k88	82
.constant	k89	146
.constant	k90	87
.constant	k91	177
.constant	k92	139
.constant	k93	159
.constant	k94	10
.constant	k95	94
.constant	k96	39
.constant	k97	181
.constant	k98	252
.constant	k99	91
.constant	k100	178
.constant	k101	17
.constant	k102	132
.constant	k103	174
.constant	k104	169
.constant	k105	23
.constant	k106	"ShowDefaultScene"
.constant	k107	"EventSystem"
.constant	k108	"postEvent"
.constant	k109	"EVENTTYPE_DETAIL_COMPONENT"
.constant	k110	"EVENTID_DETAIL_HIDE_ALL_COMPONENT"

.line	929	gettable      r1    r0    k0 ; k0 = "tabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k2 ; k2 = "Page_New_ID_Cloth"
.line	929	eq             1    r1    r2
.line	929	jmp            0   l41
.line	929	gettable      r1    r0    k0 ; k0 = "tabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k3 ; k3 = "Page_New_ID_Exchange"
.line	929	eq             1    r1    r2
.line	929	jmp            0   l41
.line	929	gettable      r1    r0    k0 ; k0 = "tabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k4 ; k4 = "Page_New_ID_Other"
.line	929	eq             0    r1    r2
.line	929	jmp            0   l21
.line	929	gettable      r1    r0    k5 ; k5 = "subTabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k6 ; k6 = "subtype_new_other_th" (truncated)
.line	929	eq             1    r1    r2
.line	929	jmp            0   l41
.label	l21
.line	929	gettable      r1    r0    k0 ; k0 = "tabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k7 ; k7 = "Page_ID_Season"
.line	929	eq             1    r1    r2
.line	929	jmp            0   l41
.line	929	gettable      r1    r0    k0 ; k0 = "tabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k3 ; k3 = "Page_New_ID_Exchange"
.line	929	eq             0    r1    r2
.line	929	jmp            0   l42
.line	929	gettable      r1    r0    k5 ; k5 = "subTabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k8 ; k8 = "subtype_new_exchange" (truncated)
.line	929	eq             1    r1    r2
.line	929	jmp            0   l41
.line	929	gettable      r1    r0    k5 ; k5 = "subTabId"
.line	929	gettabup      r2    u0    k1 ; k1 = "StoreConst"
.line	929	gettable      r2    r2    k9 ; k9 = "label_subtype_new_se" (truncated)
.line	929	eq             0    r1    r2
.line	929	jmp            0   l42
.label	l41
.line	929	loadbool      r1     0     1
.label	l42
.line	929	loadbool      r1     1     0
.line	929	gettabup      r2    u0   k10 ; k10 = "require"
.line	929	gettabup      r3    u0   k11 ; k11 = "table"
.line	929	gettable      r3    r3   k12 ; k12 = "concat"
.line	929	newtable      r4     1     0
.line	929	getupval      r5    u1
.line	929	loadk         r6   k13 ; k13 = 218
.line	929	loadk         r7   k14 ; k14 = 129
.line	929	loadk         r8   k15 ; k15 = 77
.line	929	loadk         r9   k16 ; k16 = 100
.line	929	loadk        r10   k17 ; k17 = 104
.line	929	loadk        r11   k18 ; k18 = 76
.line	929	loadk        r12   k19 ; k19 = 145
.line	929	loadk        r13   k20 ; k20 = 142
.line	929	loadk        r14   k21 ; k21 = 18
.line	929	loadk        r15   k22 ; k22 = 78
.line	929	loadk        r16   k23 ; k23 = 43
.line	929	loadk        r17   k24 ; k24 = 187
.line	929	loadk        r18   k25 ; k25 = 170
.line	929	loadk        r19   k26 ; k26 = 246
.line	929	loadk        r20   k27 ; k27 = 70
.line	929	loadk        r21   k28 ; k28 = 176
.line	929	loadk        r22   k29 ; k29 = 32
.line	929	loadk        r23   k30 ; k30 = 186
.line	929	loadk        r24   k31 ; k31 = 122
.line	929	loadk        r25   k32 ; k32 = 114
.line	929	loadk        r26   k33 ; k33 = 154
.line	929	loadk        r27   k34 ; k34 = 97
.line	929	loadk        r28   k25 ; k25 = 170
.line	929	loadk        r29   k35 ; k35 = 163
.line	929	loadk        r30   k36 ; k36 = 26
.line	929	loadk        r31   k37 ; k37 = 102
.line	929	loadk        r32   k38 ; k38 = 59
.line	929	loadk        r33   k39 ; k39 = 230
.line	929	loadk        r34   k40 ; k40 = 171
.line	929	loadk        r35   k39 ; k39 = 230
.line	929	loadk        r36   k41 ; k41 = 75
.line	929	loadk        r37   k42 ; k42 = 232
.line	929	loadk        r38   k43 ; k43 = 9
.line	929	loadk        r39   k44 ; k44 = 184
.line	929	loadk        r40   k45 ; k45 = 38
.line	929	loadk        r41   k15 ; k15 = 77
.line	929	loadk        r42   k46 ; k46 = 143
.line	929	loadk        r43   k47 ; k47 = 107
.line	929	loadk        r44   k48 ; k48 = 183
.line	929	loadk        r45   k46 ; k46 = 143
.line	929	call          r5    41     2
.line	929	getupval      r6    u1
.line	929	loadk         r7   k49 ; k49 = 220
.line	929	loadk         r8   k50 ; k50 = 138
.line	929	loadk         r9   k15 ; k15 = 77
.line	929	loadk        r10   k51 ; k51 = 110
.line	929	loadk        r11   k17 ; k17 = 104
.line	929	loadk        r12   k52 ; k52 = 117
.line	929	loadk        r13   k53 ; k53 = 222
.line	929	loadk        r14   k54 ; k54 = 158
.line	929	loadk        r15   k55 ; k55 = 12
.line	929	loadk        r16   k56 ; k56 = 84
.line	929	loadk        r17   k57 ; k57 = 57
.line	929	call          r6    12     0
.line	929	setlist       r4     0     1
.line	929	call          r3     2     2
.line	929	call          r2     2     2
.line	929	test          r1     0
.line	929	jmp            0  l210
.line	929	gettable      r3    r2   k58 ; k58 = "IsFITVersion"
.line	929	call          r3     1     2
.line	929	test          r3     0
.line	929	jmp            0  l210
.line	929	gettable      r3    r0   k59 ; k59 = "showDataList"
.line	929	test          r3     0
.line	929	jmp            0  l210
.line	929	gettable      r3    r0   k59 ; k59 = "showDataList"
.line	929	len           r3    r3
.line	929	lt             0   k60    r3 ; k60 = 0
.line	929	jmp            0  l210
.line	929	self          r3    r0   k61 ; k61 = "IsFirstItemResReady"
.line	929	call          r3     2     2
.line	929	test          r3     1
.line	929	jmp            0  l210
.line	929	gettabup      r3    u0   k62 ; k62 = "log"
.line	929	gettabup      r4    u0   k63 ; k63 = "bWriteLog"
.line	929	test          r4     0
.line	929	jmp            0  l200
.line	929	gettabup      r4    u0   k11 ; k11 = "table"
.line	929	gettable      r4    r4   k12 ; k12 = "concat"
.line	929	newtable      r5     1     0
.line	929	getupval      r6    u1
.line	929	loadk         r7   k64 ; k64 = 234
.line	929	loadk         r8   k65 ; k65 = 153
.line	929	loadk         r9   k41 ; k41 = 75
.line	929	loadk        r10   k66 ; k66 = 115
.line	929	loadk        r11   k67 ; k67 = 99
.line	929	loadk        r12   k68 ; k68 = 127
.line	929	loadk        r13   k13 ; k13 = 218
.line	929	loadk        r14   k69 ; k69 = 147
.line	929	loadk        r15   k70 ; k70 = 27
.line	929	loadk        r16   k71 ; k71 = 73
.line	929	loadk        r17   k23 ; k23 = 43
.line	929	loadk        r18   k72 ; k72 = 249
.line	929	loadk        r19   k65 ; k65 = 153
.line	929	loadk        r20   k73 ; k73 = 248
.line	929	loadk        r21   k74 ; k74 = 79
.line	929	loadk        r22   k75 ; k75 = 179
.line	929	loadk        r23   k66 ; k66 = 115
.line	929	loadk        r24   k76 ; k76 = 148
.line	929	loadk        r25   k77 ; k77 = 50
.line	929	loadk        r26   k68 ; k68 = 127
.line	929	loadk        r27   k69 ; k69 = 147
.line	929	loadk        r28   k78 ; k78 = 109
.line	929	loadk        r29   k40 ; k40 = 171
.line	929	loadk        r30   k20 ; k20 = 142
.line	929	loadk        r31   k79 ; k79 = 6
.line	929	loadk        r32   k80 ; k80 = 68
.line	929	loadk        r33   k81 ; k81 = 53
.line	929	loadk        r34   k26 ; k26 = 246
.line	929	loadk        r35   k82 ; k82 = 188
.line	929	loadk        r36   k83 ; k83 = 221
.line	929	loadk        r37   k84 ; k84 = 80
.line	929	loadk        r38   k35 ; k35 = 163
.line	929	loadk        r39   k85 ; k85 = 31
.line	929	loadk        r40   k86 ; k86 = 164
.line	929	loadk        r41   k87 ; k87 = 54
.line	929	loadk        r42   k88 ; k88 = 82
.line	929	loadk        r43   k89 ; k89 = 146
.line	929	loadk        r44   k90 ; k90 = 87
.line	929	loadk        r45   k91 ; k91 = 177
.line	929	loadk        r46   k44 ; k44 = 184
.line	929	call          r6    41     2
.line	929	getupval      r7    u1
.line	929	loadk         r8   k65 ; k65 = 153
.line	929	loadk         r9   k92 ; k92 = 139
.line	929	loadk        r10   k15 ; k15 = 77
.line	929	loadk        r11   k66 ; k66 = 115
.line	929	loadk        r12   k52 ; k52 = 117
.line	929	loadk        r13   k18 ; k18 = 76
.line	929	loadk        r14   k93 ; k93 = 159
.line	929	loadk        r15   k76 ; k76 = 148
.line	929	loadk        r16   k94 ; k94 = 10
.line	929	loadk        r17   k95 ; k95 = 94
.line	929	loadk        r18   k96 ; k96 = 39
.line	929	loadk        r19   k97 ; k97 = 181
.line	929	loadk        r20   k24 ; k24 = 187
.line	929	loadk        r21   k98 ; k98 = 252
.line	929	loadk        r22   k99 ; k99 = 91
.line	929	loadk        r23   k26 ; k26 = 246
.line	929	loadk        r24   k96 ; k96 = 39
.line	929	loadk        r25  k100 ; k100 = 178
.line	929	loadk        r26   k29 ; k29 = 32
.line	929	loadk        r27  k101 ; k101 = 17
.line	929	loadk        r28  k102 ; k102 = 132
.line	929	loadk        r29   k78 ; k78 = 109
.line	929	loadk        r30  k103 ; k103 = 174
.line	929	loadk        r31  k104 ; k104 = 169
.line	929	loadk        r32  k105 ; k105 = 23
.line	929	call          r7    26     0
.line	929	setlist       r5     0     1
.line	929	call          r4     2     2
.label	l200
.line	929	call          r3     2     1
.line	929	self          r3    r0  k106 ; k106 = "ShowDefaultScene"
.line	929	call          r3     2     1
.line	929	gettabup      r3    u0  k107 ; k107 = "EventSystem"
.line	929	self          r3    r3  k108 ; k108 = "postEvent"
.line	929	gettabup      r5    u0  k109 ; k109 = "EVENTTYPE_DETAIL_COM" (truncated)
.line	929	gettabup      r6    u0  k110 ; k110 = "EVENTID_DETAIL_HIDE_" (truncated)
.line	929	call          r3     4     1
.line	929	loadbool      r3     0     0
.line	929	return        r3     2
.label	l210
.line	929	test          r1     1
.line	929	jmp            0  l221
.line	929	self          r3    r0  k106 ; k106 = "ShowDefaultScene"
.line	929	call          r3     2     1
.line	929	gettabup      r3    u0  k107 ; k107 = "EventSystem"
.line	929	self          r3    r3  k108 ; k108 = "postEvent"
.line	929	gettabup      r5    u0  k109 ; k109 = "EVENTTYPE_DETAIL_COM" (truncated)
.line	929	gettabup      r6    u0  k110 ; k110 = "EVENTID_DETAIL_HIDE_" (truncated)
.line	929	call          r3     4     1
.line	929	loadbool      r3     0     0
.line	929	return        r3     2
.label	l221
.line	929	loadbool      r3     1     0
.line	929	return        r3     2
.line	929	return        r0     1
.line	929	move          r0    r0
.line	929	move          r0    r0
.line	929	move          r0    r0
.line	929	return        r0     1

.function	main/f39

.source	null
.linedefined	946
.lastlinedefined	953
.numparams	1
.is_vararg	0
.maxstacksize	5

.constant	k0	"parentFrame"
.constant	k1	"GetTabType"

.line	946	gettable      r1    r0    k0 ; k0 = "parentFrame"
.line	946	loadnil       r2     0
.line	946	test          r1     0
.line	946	jmp            0    l8
.line	946	self          r3    r1    k1 ; k1 = "GetTabType"
.line	946	call          r3     2     2
.line	946	move          r2    r3
.label	l8
.line	946	move          r3    r1
.line	946	move          r4    r2
.line	946	return        r3     3
.line	946	return        r0     1
.line	946	move          r0    r0
.line	946	move          r0    r0
.line	946	move          r0    r0
.line	946	move          r0    r0
.line	946	return        r0     1

.function	main/f40

.source	null
.linedefined	955
.lastlinedefined	975
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true
.upvalue	"U3"	10	true
.upvalue	"U4"	11	true

.constant	k0	"parentFrame"
.constant	k1	nil
.constant	k2	"PreviewTimeTLog"
.constant	k3	0
.constant	k4	"currentItem"
.constant	k5	"EventSystem"
.constant	k6	"postEvent"
.constant	k7	"EVENTTYPE_DETAIL_COMPONENT"
.constant	k8	"EVENTID_DETAIL_HIDE_ALL_COMPONENT"
.constant	k9	"animTimer"
.constant	k10	"RemoveTimer"
.constant	k11	"ClearStorePageData"
.constant	k12	"pageConfig"
.constant	k13	"curTitleTextList"
.constant	k14	"require"
.constant	k15	218
.constant	k16	129
.constant	k17	77
.constant	k18	100
.constant	k19	104
.constant	k20	76
.constant	k21	145
.constant	k22	17
.constant	k23	92
.constant	k24	35
.constant	k25	246
.constant	k26	231
.constant	k27	248
.constant	k28	94
.constant	k29	183
.constant	k30	61
.constant	k31	188
.constant	k32	38
.constant	k33	31
.constant	k34	187
.constant	k35	103
.constant	k36	171
.constant	k37	168
.constant	k38	2
.constant	k39	111
.constant	k40	51
.constant	k41	169
.constant	k42	229
.constant	k43	89
.constant	k44	191
.constant	k45	60
.constant	k46	"SetDisableSwitchChar"
.constant	k47	"__super"
.constant	k48	"OnClose"
.constant	k49	"currIndex"
.constant	k50	1
.constant	k51	"ModuleManager"
.constant	k52	"GetModule"
.constant	k53	"LobbyModuleConfig"
.constant	k54	"StoreDetailManager"
.constant	k55	"ClearMultiShapeClothCache"

.line	955	settable      r0    k0    k1 ; k1 = nil
.line	955	self          r1    r0    k2 ; k2 = "PreviewTimeTLog"
.line	955	loadk         r3    k3 ; k3 = 0
.line	955	call          r1     3     1
.line	955	settable      r0    k4    k1 ; k1 = nil
.line	955	gettabup      r1    u0    k5 ; k5 = "EventSystem"
.line	955	self          r1    r1    k6 ; k6 = "postEvent"
.line	955	gettabup      r3    u0    k7 ; k7 = "EVENTTYPE_DETAIL_COM" (truncated)
.line	955	gettabup      r4    u0    k8 ; k8 = "EVENTID_DETAIL_HIDE_" (truncated)
.line	955	call          r1     4     1
.line	955	gettable      r1    r0    k9 ; k9 = "animTimer"
.line	955	eq             1    r1    k1 ; k1 = nil
.line	955	jmp            0   l18
.line	955	self          r1    r0   k10 ; k10 = "RemoveTimer"
.line	955	gettable      r3    r0    k9 ; k9 = "animTimer"
.line	955	call          r1     3     1
.line	955	settable      r0    k9    k1 ; k1 = nil
.label	l18
.line	955	self          r1    r0   k11 ; k11 = "ClearStorePageData"
.line	955	call          r1     2     1
.line	955	settable      r0   k12    k1 ; k1 = nil
.line	955	settable      r0   k13    k1 ; k1 = nil
.line	955	gettabup      r1    u0   k14 ; k14 = "require"
.line	955	getupval      r2    u1
.line	955	loadk         r3   k15 ; k15 = 218
.line	955	loadk         r4   k16 ; k16 = 129
.line	955	loadk         r5   k17 ; k17 = 77
.line	955	loadk         r6   k18 ; k18 = 100
.line	955	loadk         r7   k19 ; k19 = 104
.line	955	loadk         r8   k20 ; k20 = 76
.line	955	loadk         r9   k21 ; k21 = 145
.line	955	loadk        r10   k21 ; k21 = 145
.line	955	loadk        r11   k22 ; k22 = 17
.line	955	loadk        r12   k23 ; k23 = 92
.line	955	loadk        r13   k24 ; k24 = 35
.line	955	loadk        r14   k25 ; k25 = 246
.line	955	loadk        r15   k26 ; k26 = 231
.line	955	loadk        r16   k27 ; k27 = 248
.line	955	loadk        r17   k28 ; k28 = 94
.line	955	loadk        r18   k29 ; k29 = 183
.line	955	loadk        r19   k30 ; k30 = 61
.line	955	loadk        r20   k31 ; k31 = 188
.line	955	loadk        r21   k32 ; k32 = 38
.line	955	loadk        r22   k33 ; k33 = 31
.line	955	loadk        r23   k34 ; k34 = 187
.line	955	loadk        r24   k35 ; k35 = 103
.line	955	loadk        r25   k36 ; k36 = 171
.line	955	loadk        r26   k37 ; k37 = 168
.line	955	loadk        r27   k38 ; k38 = 2
.line	955	loadk        r28   k39 ; k39 = 111
.line	955	loadk        r29   k40 ; k40 = 51
.line	955	loadk        r30   k25 ; k25 = 246
.line	955	loadk        r31   k41 ; k41 = 169
.line	955	loadk        r32   k42 ; k42 = 229
.line	955	loadk        r33   k43 ; k43 = 89
.line	955	loadk        r34   k44 ; k44 = 191
.line	955	loadk        r35   k45 ; k45 = 60
.line	955	loadk        r36   k44 ; k44 = 191
.line	955	call          r2    35     2
.line	955	call          r1     2     2
.line	955	gettable      r2    r1   k46 ; k46 = "SetDisableSwitchChar"
.line	955	loadbool      r3     0     0
.line	955	call          r2     2     1
.line	955	gettabup      r2    u2   k47 ; k47 = "__super"
.line	955	gettable      r2    r2   k48 ; k48 = "OnClose"
.line	955	move          r3    r0
.line	955	call          r2     2     1
.line	955	settable      r0   k49   k50 ; k50 = 1
.line	955	gettabup      r2    u0   k51 ; k51 = "ModuleManager"
.line	955	gettable      r2    r2   k52 ; k52 = "GetModule"
.line	955	gettabup      r3    u0   k51 ; k51 = "ModuleManager"
.line	955	gettable      r3    r3   k53 ; k53 = "LobbyModuleConfig"
.line	955	gettable      r3    r3   k54 ; k54 = "StoreDetailManager"
.line	955	call          r2     2     2
.line	955	self          r3    r2   k55 ; k55 = "ClearMultiShapeCloth" (truncated)
.line	955	call          r3     2     1
.line	955	loadk         r3    k3 ; k3 = 0
.line	955	setupval      r3    u3
.line	955	loadk         r3    k3 ; k3 = 0
.line	955	setupval      r3    u4
.line	955	return        r0     1
.line	955	gettabup      r3    u0   k49 ; k49 = "currIndex"
.line	955	return        r0     1

.function	main/f41

.source	null
.linedefined	977
.lastlinedefined	986
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	2	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	127
.constant	k8	218
.constant	k9	147
.constant	k10	27
.constant	k11	73
.constant	k12	43
.constant	k13	249
.constant	k14	248
.constant	k15	79
.constant	k16	179
.constant	k17	146
.constant	k18	58
.constant	k19	121
.constant	k20	159
.constant	k21	108
.constant	k22	170
.constant	k23	"SetPageShowing"
.constant	k24	"require"
.constant	k25	129
.constant	k26	77
.constant	k27	100
.constant	k28	104
.constant	k29	76
.constant	k30	145
.constant	k31	17
.constant	k32	92
.constant	k33	35
.constant	k34	246
.constant	k35	231
.constant	k36	94
.constant	k37	183
.constant	k38	61
.constant	k39	188
.constant	k40	38
.constant	k41	31
.constant	k42	187
.constant	k43	103
.constant	k44	171
.constant	k45	168
.constant	k46	2
.constant	k47	111
.constant	k48	51
.constant	k49	169
.constant	k50	229
.constant	k51	89
.constant	k52	191
.constant	k53	60
.constant	k54	"GetShowingAvatar"
.constant	k55	"StopAction"
.constant	k56	"EventSystem"
.constant	k57	"postEvent"
.constant	k58	"EVENTTYPE_STORE_DATA"
.constant	k59	"EVENTID_STORE_HIDE_JUMP_TP_CHEST"
.constant	k60	"__super"
.constant	k61	"OnHide"

.line	977	gettabup      r1    u0    k0 ; k0 = "log"
.line	977	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	977	test          r2     0
.line	977	jmp            0   l30
.line	977	getupval      r2    u1
.line	977	loadk         r3    k2 ; k2 = 234
.line	977	loadk         r4    k3 ; k3 = 153
.line	977	loadk         r5    k4 ; k4 = 75
.line	977	loadk         r6    k5 ; k5 = 115
.line	977	loadk         r7    k6 ; k6 = 99
.line	977	loadk         r8    k7 ; k7 = 127
.line	977	loadk         r9    k8 ; k8 = 218
.line	977	loadk        r10    k9 ; k9 = 147
.line	977	loadk        r11   k10 ; k10 = 27
.line	977	loadk        r12   k11 ; k11 = 73
.line	977	loadk        r13   k12 ; k12 = 43
.line	977	loadk        r14   k13 ; k13 = 249
.line	977	loadk        r15    k3 ; k3 = 153
.line	977	loadk        r16   k14 ; k14 = 248
.line	977	loadk        r17   k15 ; k15 = 79
.line	977	loadk        r18   k16 ; k16 = 179
.line	977	loadk        r19    k5 ; k5 = 115
.line	977	loadk        r20   k17 ; k17 = 146
.line	977	loadk        r21   k18 ; k18 = 58
.line	977	loadk        r22   k19 ; k19 = 121
.line	977	loadk        r23   k20 ; k20 = 159
.line	977	loadk        r24   k21 ; k21 = 108
.line	977	loadk        r25   k22 ; k22 = 170
.line	977	call          r2    24     2
.label	l30
.line	977	call          r1     2     1
.line	977	self          r1    r0   k23 ; k23 = "SetPageShowing"
.line	977	loadbool      r3     0     0
.line	977	call          r1     3     1
.line	977	gettabup      r1    u0   k24 ; k24 = "require"
.line	977	getupval      r2    u1
.line	977	loadk         r3    k8 ; k8 = 218
.line	977	loadk         r4   k25 ; k25 = 129
.line	977	loadk         r5   k26 ; k26 = 77
.line	977	loadk         r6   k27 ; k27 = 100
.line	977	loadk         r7   k28 ; k28 = 104
.line	977	loadk         r8   k29 ; k29 = 76
.line	977	loadk         r9   k30 ; k30 = 145
.line	977	loadk        r10   k30 ; k30 = 145
.line	977	loadk        r11   k31 ; k31 = 17
.line	977	loadk        r12   k32 ; k32 = 92
.line	977	loadk        r13   k33 ; k33 = 35
.line	977	loadk        r14   k34 ; k34 = 246
.line	977	loadk        r15   k35 ; k35 = 231
.line	977	loadk        r16   k14 ; k14 = 248
.line	977	loadk        r17   k36 ; k36 = 94
.line	977	loadk        r18   k37 ; k37 = 183
.line	977	loadk        r19   k38 ; k38 = 61
.line	977	loadk        r20   k39 ; k39 = 188
.line	977	loadk        r21   k40 ; k40 = 38
.line	977	loadk        r22   k41 ; k41 = 31
.line	977	loadk        r23   k42 ; k42 = 187
.line	977	loadk        r24   k43 ; k43 = 103
.line	977	loadk        r25   k44 ; k44 = 171
.line	977	loadk        r26   k45 ; k45 = 168
.line	977	loadk        r27   k46 ; k46 = 2
.line	977	loadk        r28   k47 ; k47 = 111
.line	977	loadk        r29   k48 ; k48 = 51
.line	977	loadk        r30   k34 ; k34 = 246
.line	977	loadk        r31   k49 ; k49 = 169
.line	977	loadk        r32   k50 ; k50 = 229
.line	977	loadk        r33   k51 ; k51 = 89
.line	977	loadk        r34   k52 ; k52 = 191
.line	977	loadk        r35   k53 ; k53 = 60
.line	977	loadk        r36   k52 ; k52 = 191
.line	977	call          r2    35     2
.line	977	call          r1     2     2
.line	977	gettable      r2    r1   k54 ; k54 = "GetShowingAvatar"
.line	977	call          r2     1     2
.line	977	test          r2     0
.line	977	jmp            0   l80
.line	977	gettable      r2    r1   k54 ; k54 = "GetShowingAvatar"
.line	977	call          r2     1     2
.line	977	self          r2    r2   k55 ; k55 = "StopAction"
.line	977	call          r2     2     1
.label	l80
.line	977	gettabup      r2    u0   k56 ; k56 = "EventSystem"
.line	977	self          r2    r2   k57 ; k57 = "postEvent"
.line	977	gettabup      r4    u0   k58 ; k58 = "EVENTTYPE_STORE_DATA"
.line	977	gettabup      r5    u0   k59 ; k59 = "EVENTID_STORE_HIDE_J" (truncated)
.line	977	call          r2     4     1
.line	977	gettabup      r2    u2   k60 ; k60 = "__super"
.line	977	gettable      r2    r2   k61 ; k61 = "OnHide"
.line	977	move          r3    r0
.line	977	call          r2     2     1
.line	977	return        r0     1
.line	977	move          r0    r0
.line	977	return        r0     1

.function	main/f42

.source	null
.linedefined	988
.lastlinedefined	1071
.numparams	1
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"logic_coupon_shop"
.constant	k4	"require"
.constant	k5	218
.constant	k6	129
.constant	k7	77
.constant	k8	100
.constant	k9	104
.constant	k10	76
.constant	k11	145
.constant	k12	142
.constant	k13	18
.constant	k14	78
.constant	k15	43
.constant	k16	187
.constant	k17	165
.constant	k18	246
.constant	k19	79
.constant	k20	191
.constant	k21	42
.constant	k22	243
.constant	k23	55
.constant	k24	94
.constant	k25	131
.constant	k26	120
.constant	k27	160
.constant	k28	163
.constant	k29	64
.constant	k30	71
.constant	k31	53
.constant	k32	226
.constant	k33	176
.constant	k34	234
.constant	k35	103
.constant	k36	54
.constant	k37	184
.constant	k38	52
.constant	k39	136
.constant	k40	"currentItem"
.constant	k41	"CurShopTab"
.constant	k42	"StoreConst"
.constant	k43	"Page_New_ID_Cloth"
.constant	k44	"finalPrice"
.constant	k45	0
.constant	k46	"lowestPriceList"
.constant	k47	"next"
.constant	k48	"pairs"
.constant	k49	"currency"
.constant	k50	1
.constant	k51	"originalPrice"
.constant	k52	2
.constant	k53	"ConvertToShopInfo"
.constant	k54	"rawItemInfo"
.constant	k55	"tabId"
.constant	k56	"subTabId"
.constant	k57	"money2_price3"
.constant	k58	"IsHaveCouldUseCoupon"
.constant	k59	"id"
.constant	k60	"_Enum_Scene"
.constant	k61	"_ClothesBuy"
.constant	k62	"money2_price2"
.constant	k63	"money2_price"
.constant	k64	"money1_price3"
.constant	k65	"money1_price2"
.constant	k66	"money1_price"
.constant	k67	"IsDirectBuyTab"
.constant	k68	"IsUCSpecialPackageTab"
.constant	k69	"CurShopSubTab"
.constant	k70	"IsSubscribeLimitTab"
.constant	k71	"_TresureBuy"

.line	988	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	988	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	988	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	988	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	988	gettable      r2    r2    k3 ; k3 = "logic_coupon_shop"
.line	988	call          r1     2     2
.line	988	gettabup      r2    u0    k4 ; k4 = "require"
.line	988	getupval      r3    u1
.line	988	loadk         r4    k5 ; k5 = 218
.line	988	loadk         r5    k6 ; k6 = 129
.line	988	loadk         r6    k7 ; k7 = 77
.line	988	loadk         r7    k8 ; k8 = 100
.line	988	loadk         r8    k9 ; k9 = 104
.line	988	loadk         r9   k10 ; k10 = 76
.line	988	loadk        r10   k11 ; k11 = 145
.line	988	loadk        r11   k12 ; k12 = 142
.line	988	loadk        r12   k13 ; k13 = 18
.line	988	loadk        r13   k14 ; k14 = 78
.line	988	loadk        r14   k15 ; k15 = 43
.line	988	loadk        r15   k16 ; k16 = 187
.line	988	loadk        r16   k17 ; k17 = 165
.line	988	loadk        r17   k18 ; k18 = 246
.line	988	loadk        r18   k19 ; k19 = 79
.line	988	loadk        r19   k20 ; k20 = 191
.line	988	loadk        r20   k21 ; k21 = 42
.line	988	loadk        r21   k22 ; k22 = 243
.line	988	loadk        r22   k23 ; k23 = 55
.line	988	loadk        r23   k24 ; k24 = 94
.line	988	loadk        r24   k25 ; k25 = 131
.line	988	loadk        r25   k26 ; k26 = 120
.line	988	loadk        r26   k27 ; k27 = 160
.line	988	loadk        r27   k28 ; k28 = 163
.line	988	loadk        r28   k29 ; k29 = 64
.line	988	loadk        r29   k30 ; k30 = 71
.line	988	loadk        r30   k31 ; k31 = 53
.line	988	loadk        r31   k32 ; k32 = 226
.line	988	loadk        r32   k33 ; k33 = 176
.line	988	loadk        r33   k34 ; k34 = 234
.line	988	loadk        r34   k35 ; k35 = 103
.line	988	loadk        r35   k17 ; k17 = 165
.line	988	loadk        r36   k36 ; k36 = 54
.line	988	loadk        r37   k37 ; k37 = 184
.line	988	loadk        r38   k38 ; k38 = 52
.line	988	loadk        r39   k14 ; k14 = 78
.line	988	loadk        r40   k39 ; k39 = 136
.line	988	call          r3    38     2
.line	988	call          r2     2     2
.line	988	loadbool      r3     0     0
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	test          r4     1
.line	988	jmp            0   l53
.line	988	return        r3     2
.label	l53
.line	988	gettable      r4    r1   k41 ; k41 = "CurShopTab"
.line	988	gettabup      r5    u0   k42 ; k42 = "StoreConst"
.line	988	gettable      r5    r5   k43 ; k43 = "Page_New_ID_Cloth"
.line	988	eq             0    r4    r5
.line	988	jmp            0  l194
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r4    r4   k44 ; k44 = "finalPrice"
.line	988	test          r4     0
.line	988	jmp            0  l194
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r4    r4   k44 ; k44 = "finalPrice"
.line	988	lt             0   k45    r4 ; k45 = 0
.line	988	jmp            0  l194
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r4    r4   k46 ; k46 = "lowestPriceList"
.line	988	test          r4     0
.line	988	jmp            0  l194
.line	988	gettabup      r4    u0   k47 ; k47 = "next"
.line	988	gettable      r5    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r5    r5   k46 ; k46 = "lowestPriceList"
.line	988	call          r4     2     2
.line	988	test          r4     0
.line	988	jmp            0  l194
.line	988	gettabup      r4    u0   k48 ; k48 = "pairs"
.line	988	gettable      r5    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r5    r5   k46 ; k46 = "lowestPriceList"
.line	988	call          r4     2     4
.line	988	jmp            0   l88
.line	988	gettable      r9    r8   k49 ; k49 = "currency"
.line	988	eq             0    r9   k50 ; k50 = 1
.line	988	jmp            0   l88
.line	988	gettable      r9    r8   k51 ; k51 = "originalPrice"
.line	988	lt             0   k45    r9 ; k45 = 0
.line	988	jmp            0   l88
.line	988	return        r3     2
.label	l88
.line	988	move          r0    r0
.line	988	move          r0    r0
.line	988	gettabup      r4    u0   k48 ; k48 = "pairs"
.line	988	gettable      r5    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r5    r5   k46 ; k46 = "lowestPriceList"
.line	988	call          r4     2     4
.line	988	jmp            0  l192
.line	988	gettable      r9    r8   k49 ; k49 = "currency"
.line	988	eq             0    r9   k52 ; k52 = 2
.line	988	jmp            0  l192
.line	988	gettable      r9    r8   k51 ; k51 = "originalPrice"
.line	988	lt             0   k45    r9 ; k45 = 0
.line	988	jmp            0  l192
.line	988	gettabup      r9    u2   k53 ; k53 = "ConvertToShopInfo"
.line	988	gettable     r10    r0   k54 ; k54 = "rawItemInfo"
.line	988	gettable     r11    r0   k55 ; k55 = "tabId"
.line	988	gettable     r12    r0   k56 ; k56 = "subTabId"
.line	988	call          r9     4     2
.line	988	test          r9     0
.line	988	jmp            0  l192
.line	988	gettable     r10    r9   k57 ; k57 = "money2_price3"
.line	988	test         r10     0
.line	988	jmp            0  l122
.line	988	gettable     r10    r9   k57 ; k57 = "money2_price3"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l122
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k61 ; k61 = "_ClothesBuy"
.line	988	gettable     r14    r9   k57 ; k57 = "money2_price3"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l122
.line	988	gettable     r10    r9   k62 ; k62 = "money2_price2"
.line	988	test         r10     0
.line	988	jmp            0  l136
.line	988	gettable     r10    r9   k62 ; k62 = "money2_price2"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l136
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k61 ; k61 = "_ClothesBuy"
.line	988	gettable     r14    r9   k62 ; k62 = "money2_price2"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l136
.line	988	gettable     r10    r9   k63 ; k63 = "money2_price"
.line	988	test         r10     0
.line	988	jmp            0  l150
.line	988	gettable     r10    r9   k63 ; k63 = "money2_price"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l150
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k61 ; k61 = "_ClothesBuy"
.line	988	gettable     r14    r9   k63 ; k63 = "money2_price"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l150
.line	988	gettable     r10    r9   k64 ; k64 = "money1_price3"
.line	988	test         r10     0
.line	988	jmp            0  l164
.line	988	gettable     r10    r9   k64 ; k64 = "money1_price3"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l164
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k61 ; k61 = "_ClothesBuy"
.line	988	gettable     r14    r9   k64 ; k64 = "money1_price3"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l164
.line	988	gettable     r10    r9   k65 ; k65 = "money1_price2"
.line	988	test         r10     0
.line	988	jmp            0  l178
.line	988	gettable     r10    r9   k65 ; k65 = "money1_price2"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l178
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k61 ; k61 = "_ClothesBuy"
.line	988	gettable     r14    r9   k65 ; k65 = "money1_price2"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l178
.line	988	gettable     r10    r9   k66 ; k66 = "money1_price"
.line	988	test         r10     0
.line	988	jmp            0  l192
.line	988	gettable     r10    r9   k66 ; k66 = "money1_price"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l192
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k61 ; k61 = "_ClothesBuy"
.line	988	gettable     r14    r9   k66 ; k66 = "money1_price"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l192
.line	988	move          r0    r0
.line	988	move          r0    r0
.label	l194
.line	988	gettabup      r4    u2   k67 ; k67 = "IsDirectBuyTab"
.line	988	gettable      r5    r1   k41 ; k41 = "CurShopTab"
.line	988	call          r4     2     2
.line	988	test          r4     1
.line	988	jmp            0  l211
.line	988	gettabup      r4    u2   k68 ; k68 = "IsUCSpecialPackageTa" (truncated)
.line	988	gettable      r5    r1   k41 ; k41 = "CurShopTab"
.line	988	gettable      r6    r1   k69 ; k69 = "CurShopSubTab"
.line	988	call          r4     3     2
.line	988	test          r4     1
.line	988	jmp            0  l211
.line	988	gettabup      r4    u2   k70 ; k70 = "IsSubscribeLimitTab"
.line	988	gettable      r5    r1   k41 ; k41 = "CurShopTab"
.line	988	gettable      r6    r1   k69 ; k69 = "CurShopSubTab"
.line	988	call          r4     3     2
.line	988	test          r4     0
.line	988	jmp            0  l347
.label	l211
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r4    r4   k44 ; k44 = "finalPrice"
.line	988	test          r4     0
.line	988	jmp            0  l347
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r4    r4   k44 ; k44 = "finalPrice"
.line	988	lt             0   k45    r4 ; k45 = 0
.line	988	jmp            0  l347
.line	988	gettable      r4    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r4    r4   k46 ; k46 = "lowestPriceList"
.line	988	test          r4     0
.line	988	jmp            0  l347
.line	988	gettabup      r4    u0   k47 ; k47 = "next"
.line	988	gettable      r5    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r5    r5   k46 ; k46 = "lowestPriceList"
.line	988	call          r4     2     2
.line	988	test          r4     0
.line	988	jmp            0  l347
.line	988	gettabup      r4    u0   k48 ; k48 = "pairs"
.line	988	gettable      r5    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r5    r5   k46 ; k46 = "lowestPriceList"
.line	988	call          r4     2     4
.line	988	jmp            0  l241
.line	988	gettable      r9    r8   k49 ; k49 = "currency"
.line	988	eq             0    r9   k50 ; k50 = 1
.line	988	jmp            0  l241
.line	988	gettable      r9    r8   k51 ; k51 = "originalPrice"
.line	988	lt             0   k45    r9 ; k45 = 0
.line	988	jmp            0  l241
.line	988	return        r3     2
.label	l241
.line	988	move          r0    r0
.line	988	move          r0    r0
.line	988	gettabup      r4    u0   k48 ; k48 = "pairs"
.line	988	gettable      r5    r0   k40 ; k40 = "currentItem"
.line	988	gettable      r5    r5   k46 ; k46 = "lowestPriceList"
.line	988	call          r4     2     4
.line	988	jmp            0  l345
.line	988	gettable      r9    r8   k49 ; k49 = "currency"
.line	988	eq             0    r9   k52 ; k52 = 2
.line	988	jmp            0  l345
.line	988	gettable      r9    r8   k51 ; k51 = "originalPrice"
.line	988	lt             0   k45    r9 ; k45 = 0
.line	988	jmp            0  l345
.line	988	gettabup      r9    u2   k53 ; k53 = "ConvertToShopInfo"
.line	988	gettable     r10    r0   k54 ; k54 = "rawItemInfo"
.line	988	gettable     r11    r0   k55 ; k55 = "tabId"
.line	988	gettable     r12    r0   k56 ; k56 = "subTabId"
.line	988	call          r9     4     2
.line	988	test          r9     0
.line	988	jmp            0  l345
.line	988	gettable     r10    r9   k57 ; k57 = "money2_price3"
.line	988	test         r10     0
.line	988	jmp            0  l275
.line	988	gettable     r10    r9   k57 ; k57 = "money2_price3"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l275
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k71 ; k71 = "_TresureBuy"
.line	988	gettable     r14    r9   k57 ; k57 = "money2_price3"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l275
.line	988	gettable     r10    r9   k62 ; k62 = "money2_price2"
.line	988	test         r10     0
.line	988	jmp            0  l289
.line	988	gettable     r10    r9   k62 ; k62 = "money2_price2"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l289
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k71 ; k71 = "_TresureBuy"
.line	988	gettable     r14    r9   k62 ; k62 = "money2_price2"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l289
.line	988	gettable     r10    r9   k63 ; k63 = "money2_price"
.line	988	test         r10     0
.line	988	jmp            0  l303
.line	988	gettable     r10    r9   k63 ; k63 = "money2_price"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l303
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k71 ; k71 = "_TresureBuy"
.line	988	gettable     r14    r9   k63 ; k63 = "money2_price"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l303
.line	988	gettable     r10    r9   k64 ; k64 = "money1_price3"
.line	988	test         r10     0
.line	988	jmp            0  l317
.line	988	gettable     r10    r9   k64 ; k64 = "money1_price3"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l317
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k71 ; k71 = "_TresureBuy"
.line	988	gettable     r14    r9   k64 ; k64 = "money1_price3"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l317
.line	988	gettable     r10    r9   k65 ; k65 = "money1_price2"
.line	988	test         r10     0
.line	988	jmp            0  l331
.line	988	gettable     r10    r9   k65 ; k65 = "money1_price2"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l331
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k71 ; k71 = "_TresureBuy"
.line	988	gettable     r14    r9   k65 ; k65 = "money1_price2"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l331
.line	988	gettable     r10    r9   k66 ; k66 = "money1_price"
.line	988	test         r10     0
.line	988	jmp            0  l345
.line	988	gettable     r10    r9   k66 ; k66 = "money1_price"
.line	988	lt             0   k45   r10 ; k45 = 0
.line	988	jmp            0  l345
.line	988	self         r10    r1   k58 ; k58 = "IsHaveCouldUseCoupon"
.line	988	gettable     r12    r9   k59 ; k59 = "id"
.line	988	gettable     r13    r2   k60 ; k60 = "_Enum_Scene"
.line	988	gettable     r13   r13   k71 ; k71 = "_TresureBuy"
.line	988	gettable     r14    r9   k66 ; k66 = "money1_price"
.line	988	call         r10     5     2
.line	988	move          r3   r10
.line	988	return        r3     2
.label	l345
.line	988	move          r0    r0
.line	988	move          r0    r0
.label	l347
.line	988	return        r0     1
.line	988	move          r0    r0
.line	988	move          r0    r0
.line	988	return        r0     1

.function	main/f43

.source	null
.linedefined	1073
.lastlinedefined	1078
.numparams	1
.is_vararg	0
.maxstacksize	37

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"showDataList"
.constant	k1	0
.constant	k2	"IfNeedChooseTheFirstOne"
.constant	k3	"require"
.constant	k4	218
.constant	k5	129
.constant	k6	77
.constant	k7	100
.constant	k8	104
.constant	k9	76
.constant	k10	145
.constant	k11	17
.constant	k12	92
.constant	k13	35
.constant	k14	246
.constant	k15	231
.constant	k16	248
.constant	k17	94
.constant	k18	183
.constant	k19	61
.constant	k20	188
.constant	k21	38
.constant	k22	31
.constant	k23	187
.constant	k24	103
.constant	k25	171
.constant	k26	168
.constant	k27	2
.constant	k28	111
.constant	k29	51
.constant	k30	169
.constant	k31	229
.constant	k32	89
.constant	k33	191
.constant	k34	60
.constant	k35	"RestoreCharacter"

.line	1073	gettable      r1    r0    k0 ; k0 = "showDataList"
.line	1073	test          r1     0
.line	1073	jmp            0   l52
.line	1073	gettable      r1    r0    k0 ; k0 = "showDataList"
.line	1073	len           r1    r1
.line	1073	lt             0    k1    r1 ; k1 = 0
.line	1073	jmp            0   l52
.line	1073	self          r1    r0    k2 ; k2 = "IfNeedChooseTheFirst" (truncated)
.line	1073	call          r1     2     2
.line	1073	test          r1     1
.line	1073	jmp            0   l52
.line	1073	gettabup      r1    u0    k3 ; k3 = "require"
.line	1073	getupval      r2    u1
.line	1073	loadk         r3    k4 ; k4 = 218
.line	1073	loadk         r4    k5 ; k5 = 129
.line	1073	loadk         r5    k6 ; k6 = 77
.line	1073	loadk         r6    k7 ; k7 = 100
.line	1073	loadk         r7    k8 ; k8 = 104
.line	1073	loadk         r8    k9 ; k9 = 76
.line	1073	loadk         r9   k10 ; k10 = 145
.line	1073	loadk        r10   k10 ; k10 = 145
.line	1073	loadk        r11   k11 ; k11 = 17
.line	1073	loadk        r12   k12 ; k12 = 92
.line	1073	loadk        r13   k13 ; k13 = 35
.line	1073	loadk        r14   k14 ; k14 = 246
.line	1073	loadk        r15   k15 ; k15 = 231
.line	1073	loadk        r16   k16 ; k16 = 248
.line	1073	loadk        r17   k17 ; k17 = 94
.line	1073	loadk        r18   k18 ; k18 = 183
.line	1073	loadk        r19   k19 ; k19 = 61
.line	1073	loadk        r20   k20 ; k20 = 188
.line	1073	loadk        r21   k21 ; k21 = 38
.line	1073	loadk        r22   k22 ; k22 = 31
.line	1073	loadk        r23   k23 ; k23 = 187
.line	1073	loadk        r24   k24 ; k24 = 103
.line	1073	loadk        r25   k25 ; k25 = 171
.line	1073	loadk        r26   k26 ; k26 = 168
.line	1073	loadk        r27   k27 ; k27 = 2
.line	1073	loadk        r28   k28 ; k28 = 111
.line	1073	loadk        r29   k29 ; k29 = 51
.line	1073	loadk        r30   k14 ; k14 = 246
.line	1073	loadk        r31   k30 ; k30 = 169
.line	1073	loadk        r32   k31 ; k31 = 229
.line	1073	loadk        r33   k32 ; k32 = 89
.line	1073	loadk        r34   k33 ; k33 = 191
.line	1073	loadk        r35   k34 ; k34 = 60
.line	1073	loadk        r36   k33 ; k33 = 191
.line	1073	call          r2    35     2
.line	1073	call          r1     2     2
.line	1073	gettable      r2    r1   k35 ; k35 = "RestoreCharacter"
.line	1073	call          r2     1     1
.label	l52
.line	1073	return        r0     1
.line	1073	move          r0    r0
.line	1073	move          r0    r0
.line	1073	move          r0    r0
.line	1073	return        r0     1

.function	main/f44

.source	null
.linedefined	1080
.lastlinedefined	1085
.numparams	3
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"GetFrame"
.constant	k1	"SetWidgetVisibility"
.constant	k2	"UEnums"
.constant	k3	"ESlateVisibility"
.constant	k4	"Collapsed"

.line	1080	self          r3    r0    k0 ; k0 = "GetFrame"
.line	1080	call          r3     2     3
.line	1080	test          r3     0
.line	1080	jmp            0   l10
.line	1080	self          r5    r3    k1 ; k1 = "SetWidgetVisibility"
.line	1080	gettabup      r7    u0    k2 ; k2 = "UEnums"
.line	1080	gettable      r7    r7    k3 ; k3 = "ESlateVisibility"
.line	1080	gettable      r7    r7    k4 ; k4 = "Collapsed"
.line	1080	call          r5     3     1
.label	l10
.line	1080	return        r0     1
.line	1080	move          r0    r0
.line	1080	move          r0    r0
.line	1080	move          r0    r0
.line	1080	return        r0     1

.function	main/f45

.source	null
.linedefined	1087
.lastlinedefined	1092
.numparams	3
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"GetFrame"
.constant	k1	"SetWidgetVisibility"
.constant	k2	"UEnums"
.constant	k3	"ESlateVisibility"
.constant	k4	"SelfHitTestInvisible"

.line	1087	self          r3    r0    k0 ; k0 = "GetFrame"
.line	1087	call          r3     2     3
.line	1087	test          r3     0
.line	1087	jmp            0   l10
.line	1087	self          r5    r3    k1 ; k1 = "SetWidgetVisibility"
.line	1087	gettabup      r7    u0    k2 ; k2 = "UEnums"
.line	1087	gettable      r7    r7    k3 ; k3 = "ESlateVisibility"
.line	1087	gettable      r7    r7    k4 ; k4 = "SelfHitTestInvisible"
.line	1087	call          r5     3     1
.label	l10
.line	1087	return        r0     1
.line	1087	move          r0    r0
.line	1087	move          r0    r0
.line	1087	move          r0    r0
.line	1087	return        r0     1

.function	main/f46

.source	null
.linedefined	1094
.lastlinedefined	1107
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	8	true
.upvalue	"U1"	0	false

.constant	k0	"UIRoot"
.constant	k1	"CanvasPanel_Filter"
.constant	k2	"GetNeedShowTitleConfig"
.constant	k3	"subTabId"
.constant	k4	nil
.constant	k5	"next"
.constant	k6	"SetWidgetVisibility"
.constant	k7	"UEnums"
.constant	k8	"ESlateVisibility"
.constant	k9	"Collapsed"
.constant	k10	"SelfHitTestInvisible"
.constant	k11	"titleType"
.constant	k12	"TitleType"
.constant	k13	"DropDown"
.constant	k14	"InitDropDownData"
.constant	k15	"textList"

.line	1094	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1094	gettable      r1    r1    k1 ; k1 = "CanvasPanel_Filter"
.line	1094	test          r1     1
.line	1094	jmp            0    l6
.line	1094	return        r0     1
.label	l6
.line	1094	gettabup      r1    u0    k2 ; k2 = "GetNeedShowTitleConf" (truncated)
.line	1094	gettable      r2    r0    k3 ; k3 = "subTabId"
.line	1094	call          r1     2     2
.line	1094	eq             1    r1    k4 ; k4 = nil
.line	1094	jmp            0   l16
.line	1094	gettabup      r2    u1    k5 ; k5 = "next"
.line	1094	move          r3    r1
.line	1094	call          r2     2     2
.line	1094	eq             0    r2    k4 ; k4 = nil
.line	1094	jmp            0   l24
.label	l16
.line	1094	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1094	gettable      r2    r2    k1 ; k1 = "CanvasPanel_Filter"
.line	1094	self          r2    r2    k6 ; k6 = "SetWidgetVisibility"
.line	1094	gettabup      r4    u1    k7 ; k7 = "UEnums"
.line	1094	gettable      r4    r4    k8 ; k8 = "ESlateVisibility"
.line	1094	gettable      r4    r4    k9 ; k9 = "Collapsed"
.line	1094	call          r2     3     1
.line	1094	return        r0     1
.label	l24
.line	1094	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1094	gettable      r2    r2    k1 ; k1 = "CanvasPanel_Filter"
.line	1094	self          r2    r2    k6 ; k6 = "SetWidgetVisibility"
.line	1094	gettabup      r4    u1    k7 ; k7 = "UEnums"
.line	1094	gettable      r4    r4    k8 ; k8 = "ESlateVisibility"
.line	1094	gettable      r4    r4   k10 ; k10 = "SelfHitTestInvisible"
.line	1094	call          r2     3     1
.line	1094	gettable      r2    r1   k11 ; k11 = "titleType"
.line	1094	gettabup      r3    u0   k12 ; k12 = "TitleType"
.line	1094	gettable      r3    r3   k13 ; k13 = "DropDown"
.line	1094	eq             0    r2    r3
.line	1094	jmp            0   l39
.line	1094	self          r2    r0   k14 ; k14 = "InitDropDownData"
.line	1094	gettable      r4    r1   k15 ; k15 = "textList"
.line	1094	call          r2     3     1
.label	l39
.line	1094	return        r0     1
.line	1094	move          r0    r0
.line	1094	return        r0     1

.function	main/f47

.source	null
.linedefined	1109
.lastlinedefined	1114
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false

.constant	k0	"GetFrame"
.constant	k1	"StoreConst"
.constant	k2	"give_tab"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"StoreDetailManager"
.constant	k7	"UpdateCollectBtn"

.line	1109	self          r2    r0    k0 ; k0 = "GetFrame"
.line	1109	call          r2     2     3
.line	1109	gettabup      r4    u0    k1 ; k1 = "StoreConst"
.line	1109	gettable      r4    r4    k2 ; k2 = "give_tab"
.line	1109	eq             1    r3    r4
.line	1109	jmp            0    l8
.line	1109	loadbool      r4     0     1
.label	l8
.line	1109	loadbool      r4     1     0
.line	1109	gettabup      r5    u0    k3 ; k3 = "ModuleManager"
.line	1109	gettable      r5    r5    k4 ; k4 = "GetModule"
.line	1109	gettabup      r6    u0    k3 ; k3 = "ModuleManager"
.line	1109	gettable      r6    r6    k5 ; k5 = "LobbyModuleConfig"
.line	1109	gettable      r6    r6    k6 ; k6 = "StoreDetailManager"
.line	1109	call          r5     2     2
.line	1109	self          r6    r5    k7 ; k7 = "UpdateCollectBtn"
.line	1109	move          r8    r1
.line	1109	move          r9    r4
.line	1109	call          r6     4     1
.line	1109	return        r0     1
.line	1109	move          r0    r0
.line	1109	move          r0    r0
.line	1109	move          r0    r0
.line	1109	move          r0    r0
.line	1109	return        r0     1

.function	main/f48

.source	null
.linedefined	1116
.lastlinedefined	1121
.numparams	2
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	false

.constant	k0	"GetFrame"
.constant	k1	"StoreConst"
.constant	k2	"give_tab"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"StoreDetailManager"
.constant	k7	"UpdateLimitedSubscribeBtn"

.line	1116	self          r2    r0    k0 ; k0 = "GetFrame"
.line	1116	call          r2     2     3
.line	1116	gettabup      r4    u0    k1 ; k1 = "StoreConst"
.line	1116	gettable      r4    r4    k2 ; k2 = "give_tab"
.line	1116	eq             1    r3    r4
.line	1116	jmp            0    l8
.line	1116	loadbool      r4     0     1
.label	l8
.line	1116	loadbool      r4     1     0
.line	1116	gettabup      r5    u0    k3 ; k3 = "ModuleManager"
.line	1116	gettable      r5    r5    k4 ; k4 = "GetModule"
.line	1116	gettabup      r6    u0    k3 ; k3 = "ModuleManager"
.line	1116	gettable      r6    r6    k5 ; k5 = "LobbyModuleConfig"
.line	1116	gettable      r6    r6    k6 ; k6 = "StoreDetailManager"
.line	1116	call          r5     2     2
.line	1116	self          r6    r5    k7 ; k7 = "UpdateLimitedSubscri" (truncated)
.line	1116	move          r8    r1
.line	1116	move          r9    r4
.line	1116	call          r6     4     1
.line	1116	return        r0     1
.line	1116	move          r0    r0
.line	1116	move          r0    r0
.line	1116	return        r0     1

.function	main/f49

.source	null
.linedefined	1123
.lastlinedefined	1128
.numparams	2
.is_vararg	0
.maxstacksize	11

.upvalue	"_ENV"	0	false

.constant	k0	"GetFrame"
.constant	k1	"StoreConst"
.constant	k2	"give_tab"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"StoreDetailManager"
.constant	k7	"UpdateGiftBtn"
.constant	k8	"OnClickSendGift"

.line	1123	self          r2    r0    k0 ; k0 = "GetFrame"
.line	1123	call          r2     2     3
.line	1123	gettabup      r4    u0    k1 ; k1 = "StoreConst"
.line	1123	gettable      r4    r4    k2 ; k2 = "give_tab"
.line	1123	eq             1    r3    r4
.line	1123	jmp            0    l8
.line	1123	loadbool      r4     0     1
.label	l8
.line	1123	loadbool      r4     1     0
.line	1123	gettabup      r5    u0    k3 ; k3 = "ModuleManager"
.line	1123	gettable      r5    r5    k4 ; k4 = "GetModule"
.line	1123	gettabup      r6    u0    k3 ; k3 = "ModuleManager"
.line	1123	gettable      r6    r6    k5 ; k5 = "LobbyModuleConfig"
.line	1123	gettable      r6    r6    k6 ; k6 = "StoreDetailManager"
.line	1123	call          r5     2     2
.line	1123	self          r6    r5    k7 ; k7 = "UpdateGiftBtn"
.line	1123	move          r8    r1
.line	1123	gettable      r9    r0    k8 ; k8 = "OnClickSendGift"
.line	1123	move         r10    r4
.line	1123	call          r6     5     1
.line	1123	return        r0     1
.line	1123	move          r0    r0
.line	1123	move          r0    r0
.line	1123	move          r0    r0
.line	1123	return        r0     1

.function	main/f50

.source	null
.linedefined	1130
.lastlinedefined	1149
.numparams	2
.is_vararg	0
.maxstacksize	16

.upvalue	"_ENV"	0	false

.constant	k0	"GetFrame"
.constant	k1	"StoreConst"
.constant	k2	"give_tab"
.constant	k3	"GetIsShowCoupon"
.constant	k4	"isSubDailyGift"
.constant	k5	"buyEvent"
.constant	k6	"OnClickSubscribeBuy"
.constant	k7	"jumpEvent"
.constant	k8	nil
.constant	k9	"showDiscountEvent"
.constant	k10	"OnClickBuy"
.constant	k11	"OnClickJump"
.constant	k12	"OnClickDisBtn"
.constant	k13	"ModuleManager"
.constant	k14	"GetModule"
.constant	k15	"LobbyModuleConfig"
.constant	k16	"StoreDetailManager"
.constant	k17	"UpdateBuyBtn"
.constant	k18	"directPurchaseList"

.line	1130	self          r2    r0    k0 ; k0 = "GetFrame"
.line	1130	call          r2     2     3
.line	1130	gettabup      r4    u0    k1 ; k1 = "StoreConst"
.line	1130	gettable      r4    r4    k2 ; k2 = "give_tab"
.line	1130	eq             1    r3    r4
.line	1130	jmp            0    l8
.line	1130	loadbool      r4     0     1
.label	l8
.line	1130	loadbool      r4     1     0
.line	1130	self          r5    r0    k3 ; k3 = "GetIsShowCoupon"
.line	1130	call          r5     2     2
.line	1130	test          r1     1
.line	1130	jmp            0   l14
.line	1130	return        r0     1
.label	l14
.line	1130	newtable      r6     0     0
.line	1130	gettable      r7    r1    k4 ; k4 = "isSubDailyGift"
.line	1130	test          r7     0
.line	1130	jmp            0   l23
.line	1130	gettable      r7    r0    k6 ; k6 = "OnClickSubscribeBuy"
.line	1130	settable      r6    k5    r7 ; k5 = "buyEvent"
.line	1130	settable      r6    k7    k8 ; k8 = nil
.line	1130	settable      r6    k9    k8 ; k8 = nil
.line	1130	jmp            0   l29
.label	l23
.line	1130	gettable      r7    r0   k10 ; k10 = "OnClickBuy"
.line	1130	settable      r6    k5    r7 ; k5 = "buyEvent"
.line	1130	gettable      r7    r0   k11 ; k11 = "OnClickJump"
.line	1130	settable      r6    k7    r7 ; k7 = "jumpEvent"
.line	1130	gettable      r7    r0   k12 ; k12 = "OnClickDisBtn"
.line	1130	settable      r6    k9    r7 ; k9 = "showDiscountEvent"
.label	l29
.line	1130	gettabup      r7    u0   k13 ; k13 = "ModuleManager"
.line	1130	gettable      r7    r7   k14 ; k14 = "GetModule"
.line	1130	gettabup      r8    u0   k13 ; k13 = "ModuleManager"
.line	1130	gettable      r8    r8   k15 ; k15 = "LobbyModuleConfig"
.line	1130	gettable      r8    r8   k16 ; k16 = "StoreDetailManager"
.line	1130	call          r7     2     2
.line	1130	self          r8    r7   k17 ; k17 = "UpdateBuyBtn"
.line	1130	move         r10    r1
.line	1130	gettable     r11    r0   k18 ; k18 = "directPurchaseList"
.line	1130	move         r12    r4
.line	1130	move         r13    r5
.line	1130	move         r14    r6
.line	1130	move         r15    r0
.line	1130	call          r8     8     1
.line	1130	return        r0     1
.line	1130	move          r0    r0
.line	1130	return        r0     1

.function	main/f51

.source	null
.linedefined	1151
.lastlinedefined	1221
.numparams	4
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	218
.constant	k4	129
.constant	k5	77
.constant	k6	100
.constant	k7	104
.constant	k8	76
.constant	k9	145
.constant	k10	142
.constant	k11	18
.constant	k12	78
.constant	k13	43
.constant	k14	187
.constant	k15	170
.constant	k16	246
.constant	k17	70
.constant	k18	176
.constant	k19	32
.constant	k20	186
.constant	k21	122
.constant	k22	114
.constant	k23	154
.constant	k24	97
.constant	k25	163
.constant	k26	26
.constant	k27	102
.constant	k28	59
.constant	k29	230
.constant	k30	171
.constant	k31	75
.constant	k32	232
.constant	k33	9
.constant	k34	184
.constant	k35	38
.constant	k36	143
.constant	k37	107
.constant	k38	183
.constant	k39	220
.constant	k40	138
.constant	k41	110
.constant	k42	117
.constant	k43	222
.constant	k44	158
.constant	k45	12
.constant	k46	84
.constant	k47	57
.constant	k48	"IsFITVersion"
.constant	k49	"tabId"
.constant	k50	"StoreConst"
.constant	k51	"Page_New_ID_Recommend"
.constant	k52	"subTabId"
.constant	k53	"subtype_new_recommend_ucb"
.constant	k54	"currentItem"
.constant	k55	"shopId"
.constant	k56	"marketId"
.constant	k57	"LoopScrollGrid_0"
.constant	k58	"showDataList"
.constant	k59	"ipairs"
.constant	k60	"RefreshItem"
.constant	k61	"bPendingGiftFirstSelect"
.constant	k62	0
.constant	k63	1
.constant	k64	false
.constant	k65	"IfNeedChooseTheFirstOne"
.constant	k66	"OnClickItemHandle"
.constant	k67	"ScrollToItem"
.constant	k68	"SetBanAutoDownloadList"
.constant	k69	"itemId"
.constant	k70	"store_tab"
.constant	k71	"ModuleManager"
.constant	k72	"GetModule"
.constant	k73	"LobbyModuleConfig"
.constant	k74	"store_default_wear_manager"
.constant	k75	"CheckRecoverLobbyWear"
.constant	k76	"defaultPreviewItems"
.constant	k77	"treasure_chest_manager"
.constant	k78	"GetChestAwards"
.constant	k79	"info"
.constant	k80	17
.constant	k81	92
.constant	k82	35
.constant	k83	231
.constant	k84	248
.constant	k85	94
.constant	k86	61
.constant	k87	188
.constant	k88	31
.constant	k89	103
.constant	k90	168
.constant	k91	2
.constant	k92	111
.constant	k93	51
.constant	k94	169
.constant	k95	229
.constant	k96	89
.constant	k97	191
.constant	k98	60
.constant	k99	"BanDefaultWearForDailyPack"
.constant	k100	"next"
.constant	k101	"HasGoldSuitInDataList"
.constant	k102	165
.constant	k103	79
.constant	k104	42
.constant	k105	243
.constant	k106	39
.constant	k107	69
.constant	k108	153
.constant	k109	227
.constant	k110	29
.constant	k111	95
.constant	k112	53
.constant	k113	247
.constant	k114	214
.constant	k115	91
.constant	k116	54
.constant	k117	185
.constant	k118	44
.constant	k119	126
.constant	k120	125
.constant	k121	190
.constant	k122	175
.constant	k123	137
.constant	k124	"HasCloseInWearList"
.constant	k125	"SetDisableSwitchToModel"
.constant	k126	"GetFrame"
.constant	k127	"pairs"
.constant	k128	"PutOnClothes"
.constant	k129	"bUseGoldSuitLevel"
.constant	k130	"SetChestAwardsEquips"
.constant	k131	68
.constant	k132	148
.constant	k133	123
.constant	k134	172
.constant	k135	7
.constant	k136	73
.constant	k137	63
.constant	k138	181
.constant	k139	58
.constant	k140	146
.constant	k141	55
.constant	k142	132
.constant	k143	208
.constant	k144	65
.constant	k145	209
.constant	k146	56
.constant	k147	"GetSubscribeModuleObj"
.constant	k148	"isSubDailyGift"
.constant	k149	"IsBuyPrime"
.constant	k150	"RefreshSubDailyGiftItem"
.constant	k151	"ModuleManager"
.constant	k152	"GetModule"
.constant	k153	"LobbyModuleConfig"
.constant	k154	"StoreDetailManager"
.constant	k155	"SetProductListData"
.constant	k156	"rateType"
.constant	k157	"rateList"
.constant	k158	"currIndex"

.line	1151	test          r3     1
.line	1151	jmp            0    l4
.line	1151	return        r0     1
.label	l4
.line	1151	gettabup      r4    u0    k0 ; k0 = "require"
.line	1151	gettabup      r5    u0    k1 ; k1 = "table"
.line	1151	gettable      r5    r5    k2 ; k2 = "concat"
.line	1151	newtable      r6     1     0
.line	1151	getupval      r7    u1
.line	1151	loadk         r8    k3 ; k3 = 218
.line	1151	loadk         r9    k4 ; k4 = 129
.line	1151	loadk        r10    k5 ; k5 = 77
.line	1151	loadk        r11    k6 ; k6 = 100
.line	1151	loadk        r12    k7 ; k7 = 104
.line	1151	loadk        r13    k8 ; k8 = 76
.line	1151	loadk        r14    k9 ; k9 = 145
.line	1151	loadk        r15   k10 ; k10 = 142
.line	1151	loadk        r16   k11 ; k11 = 18
.line	1151	loadk        r17   k12 ; k12 = 78
.line	1151	loadk        r18   k13 ; k13 = 43
.line	1151	loadk        r19   k14 ; k14 = 187
.line	1151	loadk        r20   k15 ; k15 = 170
.line	1151	loadk        r21   k16 ; k16 = 246
.line	1151	loadk        r22   k17 ; k17 = 70
.line	1151	loadk        r23   k18 ; k18 = 176
.line	1151	loadk        r24   k19 ; k19 = 32
.line	1151	loadk        r25   k20 ; k20 = 186
.line	1151	loadk        r26   k21 ; k21 = 122
.line	1151	loadk        r27   k22 ; k22 = 114
.line	1151	loadk        r28   k23 ; k23 = 154
.line	1151	loadk        r29   k24 ; k24 = 97
.line	1151	loadk        r30   k15 ; k15 = 170
.line	1151	loadk        r31   k25 ; k25 = 163
.line	1151	loadk        r32   k26 ; k26 = 26
.line	1151	loadk        r33   k27 ; k27 = 102
.line	1151	loadk        r34   k28 ; k28 = 59
.line	1151	loadk        r35   k29 ; k29 = 230
.line	1151	loadk        r36   k30 ; k30 = 171
.line	1151	loadk        r37   k29 ; k29 = 230
.line	1151	loadk        r38   k31 ; k31 = 75
.line	1151	loadk        r39   k32 ; k32 = 232
.line	1151	loadk        r40   k33 ; k33 = 9
.line	1151	loadk        r41   k34 ; k34 = 184
.line	1151	loadk        r42   k35 ; k35 = 38
.line	1151	loadk        r43    k5 ; k5 = 77
.line	1151	loadk        r44   k36 ; k36 = 143
.line	1151	loadk        r45   k37 ; k37 = 107
.line	1151	loadk        r46   k38 ; k38 = 183
.line	1151	loadk        r47   k36 ; k36 = 143
.line	1151	call          r7    41     2
.line	1151	getupval      r8    u1
.line	1151	loadk         r9   k39 ; k39 = 220
.line	1151	loadk        r10   k40 ; k40 = 138
.line	1151	loadk        r11    k5 ; k5 = 77
.line	1151	loadk        r12   k41 ; k41 = 110
.line	1151	loadk        r13    k7 ; k7 = 104
.line	1151	loadk        r14   k42 ; k42 = 117
.line	1151	loadk        r15   k43 ; k43 = 222
.line	1151	loadk        r16   k44 ; k44 = 158
.line	1151	loadk        r17   k45 ; k45 = 12
.line	1151	loadk        r18   k46 ; k46 = 84
.line	1151	loadk        r19   k47 ; k47 = 57
.line	1151	call          r8    12     0
.line	1151	setlist       r6     0     1
.line	1151	call          r5     2     2
.line	1151	call          r4     2     2
.line	1151	gettable      r5    r4   k48 ; k48 = "IsFITVersion"
.line	1151	call          r5     1     2
.line	1151	test          r5     0
.line	1151	jmp            0  l150
.line	1151	gettable      r5    r0   k49 ; k49 = "tabId"
.line	1151	gettabup      r6    u0   k50 ; k50 = "StoreConst"
.line	1151	gettable      r6    r6   k51 ; k51 = "Page_New_ID_Recommen" (truncated)
.line	1151	eq             0    r5    r6
.line	1151	jmp            0  l150
.line	1151	gettable      r5    r0   k52 ; k52 = "subTabId"
.line	1151	gettabup      r6    u0   k50 ; k50 = "StoreConst"
.line	1151	gettable      r6    r6   k53 ; k53 = "subtype_new_recommen" (truncated)
.line	1151	eq             0    r5    r6
.line	1151	jmp            0  l150
.line	1151	gettable      r5    r0   k54 ; k54 = "currentItem"
.line	1151	test          r5     0
.line	1151	jmp            0   l88
.line	1151	gettable      r5    r0   k54 ; k54 = "currentItem"
.line	1151	gettable      r5    r5   k55 ; k55 = "shopId"
.line	1151	gettable      r6    r3   k56 ; k56 = "marketId"
.line	1151	eq             1    r5    r6
.line	1151	jmp            0  l150
.label	l88
.line	1151	gettable      r5    r0   k57 ; k57 = "LoopScrollGrid_0"
.line	1151	test          r5     0
.line	1151	jmp            0  l109
.line	1151	gettable      r5    r0   k58 ; k58 = "showDataList"
.line	1151	test          r5     0
.line	1151	jmp            0  l109
.line	1151	gettabup      r5    u0   k59 ; k59 = "ipairs"
.line	1151	gettable      r6    r0   k58 ; k58 = "showDataList"
.line	1151	call          r5     2     4
.line	1151	jmp            0  l107
.line	1151	gettable     r10    r9   k55 ; k55 = "shopId"
.line	1151	gettable     r11    r3   k56 ; k56 = "marketId"
.line	1151	eq             0   r10   r11
.line	1151	jmp            0  l107
.line	1151	gettable     r10    r0   k57 ; k57 = "LoopScrollGrid_0"
.line	1151	self         r10   r10   k60 ; k60 = "RefreshItem"
.line	1151	move         r12    r8
.line	1151	call         r10     3     1
.line	1151	jmp            0  l109
.label	l107
.line	1151	move          r0    r0
.line	1151	move          r0    r0
.label	l109
.line	1151	gettable      r5    r0   k61 ; k61 = "bPendingGiftFirstSel" (truncated)
.line	1151	test          r5     0
.line	1151	jmp            0  l149
.line	1151	gettable      r5    r0   k58 ; k58 = "showDataList"
.line	1151	test          r5     0
.line	1151	jmp            0  l149
.line	1151	gettable      r5    r0   k58 ; k58 = "showDataList"
.line	1151	len           r5    r5
.line	1151	lt             0   k62    r5 ; k62 = 0
.line	1151	jmp            0  l149
.line	1151	gettable      r5    r3   k56 ; k56 = "marketId"
.line	1151	gettable      r6    r0   k58 ; k58 = "showDataList"
.line	1151	gettable      r6    r6   k63 ; k63 = 1
.line	1151	gettable      r6    r6   k55 ; k55 = "shopId"
.line	1151	eq             0    r5    r6
.line	1151	jmp            0  l149
.line	1151	settable      r0   k61   k64 ; k64 = false
.line	1151	self          r5    r0   k65 ; k65 = "IfNeedChooseTheFirst" (truncated)
.line	1151	call          r5     2     2
.line	1151	test          r5     0
.line	1151	jmp            0  l149
.line	1151	self          r5    r0   k66 ; k66 = "OnClickItemHandle"
.line	1151	gettable      r7    r0   k58 ; k58 = "showDataList"
.line	1151	gettable      r7    r7   k63 ; k63 = 1
.line	1151	loadk         r8   k63 ; k63 = 1
.line	1151	loadbool      r9     1     0
.line	1151	call          r5     5     1
.line	1151	self          r5    r0   k67 ; k67 = "ScrollToItem"
.line	1151	loadk         r7   k63 ; k63 = 1
.line	1151	call          r5     3     1
.line	1151	self          r5    r0   k68 ; k68 = "SetBanAutoDownloadLi" (truncated)
.line	1151	newtable      r7     1     0
.line	1151	gettable      r8    r0   k58 ; k58 = "showDataList"
.line	1151	gettable      r8    r8   k63 ; k63 = 1
.line	1151	gettable      r8    r8   k69 ; k69 = "itemId"
.line	1151	setlist       r7     1     1
.line	1151	loadnil       r8     0
.line	1151	gettabup      r9    u0   k50 ; k50 = "StoreConst"
.line	1151	gettable      r9    r9   k70 ; k70 = "store_tab"
.line	1151	call          r5     5     1
.label	l149
.line	1151	return        r0     1
.label	l150
.line	1151	gettabup      r5    u0   k71 ; k71 = "ModuleManager"
.line	1151	gettable      r5    r5   k72 ; k72 = "GetModule"
.line	1151	gettabup      r6    u0   k71 ; k71 = "ModuleManager"
.line	1151	gettable      r6    r6   k73 ; k73 = "LobbyModuleConfig"
.line	1151	gettable      r6    r6   k74 ; k74 = "store_default_wear_m" (truncated)
.line	1151	call          r5     2     2
.line	1151	self          r6    r5   k75 ; k75 = "CheckRecoverLobbyWea" (truncated)
.line	1151	gettable      r8    r3   k76 ; k76 = "defaultPreviewItems"
.line	1151	call          r6     3     1
.line	1151	gettabup      r6    u0   k71 ; k71 = "ModuleManager"
.line	1151	gettable      r6    r6   k72 ; k72 = "GetModule"
.line	1151	gettabup      r7    u0   k71 ; k71 = "ModuleManager"
.line	1151	gettable      r7    r7   k73 ; k73 = "LobbyModuleConfig"
.line	1151	gettable      r7    r7   k77 ; k77 = "treasure_chest_manag" (truncated)
.line	1151	call          r6     2     2
.line	1151	self          r7    r6   k78 ; k78 = "GetChestAwards"
.line	1151	gettable      r9    r3   k79 ; k79 = "info"
.line	1151	call          r7     3     2
.line	1151	gettabup      r8    u0    k0 ; k0 = "require"
.line	1151	getupval      r9    u1
.line	1151	loadk        r10    k3 ; k3 = 218
.line	1151	loadk        r11    k4 ; k4 = 129
.line	1151	loadk        r12    k5 ; k5 = 77
.line	1151	loadk        r13    k6 ; k6 = 100
.line	1151	loadk        r14    k7 ; k7 = 104
.line	1151	loadk        r15    k8 ; k8 = 76
.line	1151	loadk        r16    k9 ; k9 = 145
.line	1151	loadk        r17    k9 ; k9 = 145
.line	1151	loadk        r18   k80 ; k80 = 17
.line	1151	loadk        r19   k81 ; k81 = 92
.line	1151	loadk        r20   k82 ; k82 = 35
.line	1151	loadk        r21   k16 ; k16 = 246
.line	1151	loadk        r22   k83 ; k83 = 231
.line	1151	loadk        r23   k84 ; k84 = 248
.line	1151	loadk        r24   k85 ; k85 = 94
.line	1151	loadk        r25   k38 ; k38 = 183
.line	1151	loadk        r26   k86 ; k86 = 61
.line	1151	loadk        r27   k87 ; k87 = 188
.line	1151	loadk        r28   k35 ; k35 = 38
.line	1151	loadk        r29   k88 ; k88 = 31
.line	1151	loadk        r30   k14 ; k14 = 187
.line	1151	loadk        r31   k89 ; k89 = 103
.line	1151	loadk        r32   k30 ; k30 = 171
.line	1151	loadk        r33   k90 ; k90 = 168
.line	1151	loadk        r34   k91 ; k91 = 2
.line	1151	loadk        r35   k92 ; k92 = 111
.line	1151	loadk        r36   k93 ; k93 = 51
.line	1151	loadk        r37   k16 ; k16 = 246
.line	1151	loadk        r38   k94 ; k94 = 169
.line	1151	loadk        r39   k95 ; k95 = 229
.line	1151	loadk        r40   k96 ; k96 = 89
.line	1151	loadk        r41   k97 ; k97 = 191
.line	1151	loadk        r42   k98 ; k98 = 60
.line	1151	loadk        r43   k97 ; k97 = 191
.line	1151	call          r9    35     2
.line	1151	call          r8     2     2
.line	1151	self          r9    r0   k99 ; k99 = "BanDefaultWearForDai" (truncated)
.line	1151	gettable     r11    r3   k56 ; k56 = "marketId"
.line	1151	call          r9     3     2
.line	1151	test          r9     1
.line	1151	jmp            0  l305
.line	1151	gettable      r9    r3   k76 ; k76 = "defaultPreviewItems"
.line	1151	test          r9     0
.line	1151	jmp            0  l305
.line	1151	gettabup      r9    u0  k100 ; k100 = "next"
.line	1151	gettable     r10    r3   k76 ; k76 = "defaultPreviewItems"
.line	1151	call          r9     2     2
.line	1151	test          r9     0
.line	1151	jmp            0  l305
.line	1151	gettabup      r9    u2  k101 ; k101 = "HasGoldSuitInDataLis" (truncated)
.line	1151	gettable     r10    r3   k76 ; k76 = "defaultPreviewItems"
.line	1151	call          r9     2     2
.line	1151	gettabup     r10    u0    k0 ; k0 = "require"
.line	1151	gettabup     r11    u0    k1 ; k1 = "table"
.line	1151	gettable     r11   r11    k2 ; k2 = "concat"
.line	1151	newtable     r12     1     0
.line	1151	getupval     r13    u1
.line	1151	loadk        r14    k3 ; k3 = 218
.line	1151	loadk        r15    k4 ; k4 = 129
.line	1151	loadk        r16    k5 ; k5 = 77
.line	1151	loadk        r17    k6 ; k6 = 100
.line	1151	loadk        r18    k7 ; k7 = 104
.line	1151	loadk        r19    k8 ; k8 = 76
.line	1151	loadk        r20    k9 ; k9 = 145
.line	1151	loadk        r21   k10 ; k10 = 142
.line	1151	loadk        r22   k11 ; k11 = 18
.line	1151	loadk        r23   k12 ; k12 = 78
.line	1151	loadk        r24   k13 ; k13 = 43
.line	1151	loadk        r25   k14 ; k14 = 187
.line	1151	loadk        r26  k102 ; k102 = 165
.line	1151	loadk        r27   k16 ; k16 = 246
.line	1151	loadk        r28  k103 ; k103 = 79
.line	1151	loadk        r29   k97 ; k97 = 191
.line	1151	loadk        r30  k104 ; k104 = 42
.line	1151	loadk        r31  k105 ; k105 = 243
.line	1151	loadk        r32  k106 ; k106 = 39
.line	1151	loadk        r33  k107 ; k107 = 69
.line	1151	loadk        r34  k108 ; k108 = 153
.line	1151	loadk        r35   k21 ; k21 = 122
.line	1151	loadk        r36   k15 ; k15 = 170
.line	1151	loadk        r37  k109 ; k109 = 227
.line	1151	loadk        r38  k110 ; k110 = 29
.line	1151	loadk        r39  k111 ; k111 = 95
.line	1151	loadk        r40  k112 ; k112 = 53
.line	1151	loadk        r41  k113 ; k113 = 247
.line	1151	loadk        r42   k87 ; k87 = 188
.line	1151	loadk        r43  k114 ; k114 = 214
.line	1151	loadk        r44  k115 ; k115 = 91
.line	1151	loadk        r45   k15 ; k15 = 170
.line	1151	loadk        r46  k116 ; k116 = 54
.line	1151	loadk        r47  k117 ; k117 = 185
.line	1151	loadk        r48  k118 ; k118 = 44
.line	1151	loadk        r49  k119 ; k119 = 126
.line	1151	loadk        r50    k9 ; k9 = 145
.line	1151	loadk        r51  k120 ; k120 = 125
.line	1151	loadk        r52  k121 ; k121 = 190
.line	1151	loadk        r53  k122 ; k122 = 175
.line	1151	call         r13    41     2
.line	1151	getupval     r14    u1
.line	1151	loadk        r15   k29 ; k29 = 230
.line	1151	loadk        r16  k123 ; k123 = 137
.line	1151	loadk        r17  k107 ; k107 = 69
.line	1151	loadk        r18   k42 ; k42 = 117
.line	1151	loadk        r19   k89 ; k89 = 103
.line	1151	call         r14     6     0
.line	1151	setlist      r12     0     1
.line	1151	call         r11     2     2
.line	1151	call         r10     2     2
.line	1151	gettable     r11   r10  k124 ; k124 = "HasCloseInWearList"
.line	1151	gettable     r12    r3   k76 ; k76 = "defaultPreviewItems"
.line	1151	call         r11     2     2
.line	1151	test         r11     0
.line	1151	jmp            0  l286
.line	1151	gettable     r11    r8  k125 ; k125 = "SetDisableSwitchToMo" (truncated)
.line	1151	loadbool     r12     1     0
.line	1151	call         r11     2     1
.label	l286
.line	1151	self         r11    r0  k126 ; k126 = "GetFrame"
.line	1151	call         r11     2     2
.line	1151	test         r11     1
.line	1151	jmp            0  l291
.line	1151	return        r0     1
.label	l291
.line	1151	gettabup     r12    u0  k127 ; k127 = "pairs"
.line	1151	gettable     r13    r3   k76 ; k76 = "defaultPreviewItems"
.line	1151	call         r12     2     4
.line	1151	jmp            0  l300
.line	1151	self         r17   r11  k128 ; k128 = "PutOnClothes"
.line	1151	move         r19   r16
.line	1151	newtable     r20     0     1
.line	1151	settable     r20  k129    r9 ; k129 = "bUseGoldSuitLevel"
.line	1151	call         r17     4     1
.label	l300
.line	1151	move          r0    r0
.line	1151	move          r0    r0
.line	1151	self         r12    r6  k130 ; k130 = "SetChestAwardsEquips"
.line	1151	move         r14    r7
.line	1151	call         r12     3     1
.label	l305
.line	1151	gettabup      r9    u0    k0 ; k0 = "require"
.line	1151	gettabup     r10    u0    k1 ; k1 = "table"
.line	1151	gettable     r10   r10    k2 ; k2 = "concat"
.line	1151	newtable     r11     1     0
.line	1151	getupval     r12    u1
.line	1151	loadk        r13    k3 ; k3 = 218
.line	1151	loadk        r14    k4 ; k4 = 129
.line	1151	loadk        r15    k5 ; k5 = 77
.line	1151	loadk        r16    k6 ; k6 = 100
.line	1151	loadk        r17    k7 ; k7 = 104
.line	1151	loadk        r18    k8 ; k8 = 76
.line	1151	loadk        r19    k9 ; k9 = 145
.line	1151	loadk        r20   k10 ; k10 = 142
.line	1151	loadk        r21   k11 ; k11 = 18
.line	1151	loadk        r22   k12 ; k12 = 78
.line	1151	loadk        r23   k13 ; k13 = 43
.line	1151	loadk        r24   k14 ; k14 = 187
.line	1151	loadk        r25  k102 ; k102 = 165
.line	1151	loadk        r26   k16 ; k16 = 246
.line	1151	loadk        r27  k103 ; k103 = 79
.line	1151	loadk        r28   k97 ; k97 = 191
.line	1151	loadk        r29  k104 ; k104 = 42
.line	1151	loadk        r30  k105 ; k105 = 243
.line	1151	loadk        r31  k106 ; k106 = 39
.line	1151	loadk        r32  k131 ; k131 = 68
.line	1151	loadk        r33  k132 ; k132 = 148
.line	1151	loadk        r34  k133 ; k133 = 123
.line	1151	loadk        r35  k134 ; k134 = 172
.line	1151	loadk        r36   k97 ; k97 = 191
.line	1151	loadk        r37  k135 ; k135 = 7
.line	1151	loadk        r38  k136 ; k136 = 73
.line	1151	loadk        r39  k137 ; k137 = 63
.line	1151	loadk        r40   k30 ; k30 = 171
.line	1151	loadk        r41  k138 ; k138 = 181
.line	1151	loadk        r42   k29 ; k29 = 230
.line	1151	loadk        r43  k111 ; k111 = 95
.line	1151	loadk        r44  k122 ; k122 = 175
.line	1151	loadk        r45  k139 ; k139 = 58
.line	1151	loadk        r46  k140 ; k140 = 146
.line	1151	loadk        r47  k141 ; k141 = 55
.line	1151	loadk        r48   k46 ; k46 = 84
.line	1151	loadk        r49  k142 ; k142 = 132
.line	1151	loadk        r50   k37 ; k37 = 107
.line	1151	loadk        r51   k87 ; k87 = 188
.line	1151	loadk        r52  k122 ; k122 = 175
.line	1151	call         r12    41     2
.line	1151	getupval     r13    u1
.line	1151	loadk        r14  k143 ; k143 = 208
.line	1151	loadk        r15   k36 ; k36 = 143
.line	1151	loadk        r16  k144 ; k144 = 65
.line	1151	loadk        r17   k85 ; k85 = 94
.line	1151	loadk        r18   k41 ; k41 = 110
.line	1151	loadk        r19   k96 ; k96 = 89
.line	1151	loadk        r20  k145 ; k145 = 209
.line	1151	loadk        r21  k108 ; k108 = 153
.line	1151	loadk        r22   k11 ; k11 = 18
.line	1151	loadk        r23   k85 ; k85 = 94
.line	1151	loadk        r24  k146 ; k146 = 56
.line	1151	call         r13    12     0
.line	1151	setlist      r11     0     1
.line	1151	call         r10     2     2
.line	1151	call          r9     2     2
.line	1151	gettable     r10    r9  k147 ; k147 = "GetSubscribeModuleOb" (truncated)
.line	1151	call         r10     1     2
.line	1151	gettable     r11    r0   k54 ; k54 = "currentItem"
.line	1151	test         r11     1
.line	1151	jmp            0  l373
.line	1151	newtable     r11     0     0
.label	l373
.line	1151	gettable     r12   r11  k148 ; k148 = "isSubDailyGift"
.line	1151	test         r12     0
.line	1151	jmp            0  l383
.line	1151	self         r12   r10  k149 ; k149 = "IsBuyPrime"
.line	1151	call         r12     2     2
.line	1151	test         r12     0
.line	1151	jmp            0  l383
.line	1151	self         r12    r0  k150 ; k150 = "RefreshSubDailyGiftI" (truncated)
.line	1151	call         r12     2     1
.line	1151	return        r0     1
.label	l383
.line	1151	closure      r12    f0
.line	1151	gettabup     r13    u0  k151 ; k151 = "ModuleManager"
.line	1151	gettable     r13   r13  k152 ; k152 = "GetModule"
.line	1151	gettabup     r14    u0  k151 ; k151 = "ModuleManager"
.line	1151	gettable     r14   r14  k153 ; k153 = "LobbyModuleConfig"
.line	1151	gettable     r14   r14  k154 ; k154 = "StoreDetailManager"
.line	1151	call         r13     2     2
.line	1151	self         r14   r13  k155 ; k155 = "SetProductListData"
.line	1151	move         r16    r7
.line	1151	move         r17   r12
.line	1151	gettable     r18   r11  k156 ; k156 = "rateType"
.line	1151	gettable     r19   r11  k157 ; k157 = "rateList"
.line	1151	loadk        r20   k63 ; k63 = 1
.line	1151	call         r14     7     1
.line	1151	gettable     r14    r8  k125 ; k125 = "SetDisableSwitchToMo" (truncated)
.line	1151	loadbool     r15     0     0
.line	1151	call         r14     2     1
.line	1151	gettable     r14    r0   k49 ; k49 = "tabId"
.line	1151	gettabup     r15    u0   k50 ; k50 = "StoreConst"
.line	1151	gettable     r15   r15   k51 ; k51 = "Page_New_ID_Recommen" (truncated)
.line	1151	eq             0   r14   r15
.line	1151	jmp            0  l420
.line	1151	gettable     r14    r0   k52 ; k52 = "subTabId"
.line	1151	gettabup     r15    u0   k50 ; k50 = "StoreConst"
.line	1151	gettable     r15   r15   k53 ; k53 = "subtype_new_recommen" (truncated)
.line	1151	eq             0   r14   r15
.line	1151	jmp            0  l420
.line	1151	gettable     r14    r0   k57 ; k57 = "LoopScrollGrid_0"
.line	1151	test         r14     0
.line	1151	jmp            0  l420
.line	1151	gettable     r14    r0  k158 ; k158 = "currIndex"
.line	1151	test         r14     0
.line	1151	jmp            0  l420
.line	1151	gettable     r14    r0   k57 ; k57 = "LoopScrollGrid_0"
.line	1151	self         r14   r14   k60 ; k60 = "RefreshItem"
.line	1151	gettable     r16    r0  k158 ; k158 = "currIndex"
.line	1151	call         r14     3     1
.label	l420
.line	1151	return        r0     1
.line	1151	move          r0    r0
.line	1151	move          r0    r0
.line	1151	move          r0    r0
.line	1151	move          r0    r0
.line	1151	return        r0     1

.function	main/f51/f0

.source	null
.linedefined	1204
.lastlinedefined	1214
.numparams	4
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	0	true
.upvalue	"U1"	3	true
.upvalue	"U2"	0	false
.upvalue	"U3"	8	true

.constant	k0	"BanDefaultWearForDailyPack"
.constant	k1	"marketId"
.constant	k2	"ModuleManager"
.constant	k3	"GetModule"
.constant	k4	"LobbyModuleConfig"
.constant	k5	"StoreDetailManager"
.constant	k6	"ClearAvatarDisplay"
.constant	k7	"SwitchToAvatar"
.constant	k8	"GetFrame"
.constant	k9	"PutOffClothes"
.constant	k10	"DropItemID"
.constant	k11	"OnClickProductItem"

.line	1204	test          r2     1
.line	1204	jmp            0   l26
.line	1204	getupval      r4    u0
.line	1204	self          r4    r4    k0 ; k0 = "BanDefaultWearForDai" (truncated)
.line	1204	gettabup      r6    u1    k1 ; k1 = "marketId"
.line	1204	call          r4     3     2
.line	1204	test          r4     0
.line	1204	jmp            0   l26
.line	1204	gettabup      r4    u2    k2 ; k2 = "ModuleManager"
.line	1204	gettable      r4    r4    k3 ; k3 = "GetModule"
.line	1204	gettabup      r5    u2    k2 ; k2 = "ModuleManager"
.line	1204	gettable      r5    r5    k4 ; k4 = "LobbyModuleConfig"
.line	1204	gettable      r5    r5    k5 ; k5 = "StoreDetailManager"
.line	1204	call          r4     2     2
.line	1204	self          r5    r4    k6 ; k6 = "ClearAvatarDisplay"
.line	1204	call          r5     2     1
.line	1204	gettabup      r5    u3    k7 ; k7 = "SwitchToAvatar"
.line	1204	call          r5     1     1
.line	1204	getupval      r5    u0
.line	1204	self          r5    r5    k8 ; k8 = "GetFrame"
.line	1204	call          r5     2     2
.line	1204	self          r6    r5    k9 ; k9 = "PutOffClothes"
.line	1204	gettable      r8    r0   k10 ; k10 = "DropItemID"
.line	1204	call          r6     3     1
.line	1204	return        r0     1
.label	l26
.line	1204	getupval      r4    u0
.line	1204	self          r4    r4   k11 ; k11 = "OnClickProductItem"
.line	1204	move          r6    r0
.line	1204	move          r7    r1
.line	1204	move          r8    r2
.line	1204	move          r9    r3
.line	1204	call          r4     6     1
.line	1204	return        r0     1
.line	1204	move          r0    r0
.line	1204	move          r0    r0
.line	1204	move          r0    r0
.line	1204	move          r0    r0
.line	1204	return        r0     1

.function	main/f52

.source	null
.linedefined	1223
.lastlinedefined	1235
.numparams	1
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"StoreDetailManager"
.constant	k4	"require"
.constant	k5	218
.constant	k6	129
.constant	k7	77
.constant	k8	100
.constant	k9	104
.constant	k10	76
.constant	k11	145
.constant	k12	17
.constant	k13	92
.constant	k14	35
.constant	k15	246
.constant	k16	231
.constant	k17	248
.constant	k18	94
.constant	k19	183
.constant	k20	61
.constant	k21	188
.constant	k22	38
.constant	k23	31
.constant	k24	187
.constant	k25	103
.constant	k26	171
.constant	k27	168
.constant	k28	2
.constant	k29	111
.constant	k30	51
.constant	k31	169
.constant	k32	229
.constant	k33	89
.constant	k34	191
.constant	k35	60
.constant	k36	"table"
.constant	k37	"concat"
.constant	k38	142
.constant	k39	18
.constant	k40	78
.constant	k41	43
.constant	k42	165
.constant	k43	79
.constant	k44	42
.constant	k45	243
.constant	k46	39
.constant	k47	68
.constant	k48	148
.constant	k49	123
.constant	k50	172
.constant	k51	7
.constant	k52	73
.constant	k53	63
.constant	k54	181
.constant	k55	230
.constant	k56	95
.constant	k57	175
.constant	k58	58
.constant	k59	146
.constant	k60	55
.constant	k61	84
.constant	k62	132
.constant	k63	107
.constant	k64	208
.constant	k65	143
.constant	k66	65
.constant	k67	110
.constant	k68	209
.constant	k69	153
.constant	k70	56
.constant	k71	"GetSubscribeModuleObj"
.constant	k72	"currentItem"
.constant	k73	"isSubDailyGift"
.constant	k74	"IsBuyPrime"
.constant	k75	"GetSubscribeDailyPackCfg"
.constant	k76	"SetProductListData"
.constant	k77	"rateType"
.constant	k78	"rateList"
.constant	k79	"SetDisableSwitchToModel"

.line	1223	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1223	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1223	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1223	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1223	gettable      r2    r2    k3 ; k3 = "StoreDetailManager"
.line	1223	call          r1     2     2
.line	1223	gettabup      r2    u0    k4 ; k4 = "require"
.line	1223	getupval      r3    u1
.line	1223	loadk         r4    k5 ; k5 = 218
.line	1223	loadk         r5    k6 ; k6 = 129
.line	1223	loadk         r6    k7 ; k7 = 77
.line	1223	loadk         r7    k8 ; k8 = 100
.line	1223	loadk         r8    k9 ; k9 = 104
.line	1223	loadk         r9   k10 ; k10 = 76
.line	1223	loadk        r10   k11 ; k11 = 145
.line	1223	loadk        r11   k11 ; k11 = 145
.line	1223	loadk        r12   k12 ; k12 = 17
.line	1223	loadk        r13   k13 ; k13 = 92
.line	1223	loadk        r14   k14 ; k14 = 35
.line	1223	loadk        r15   k15 ; k15 = 246
.line	1223	loadk        r16   k16 ; k16 = 231
.line	1223	loadk        r17   k17 ; k17 = 248
.line	1223	loadk        r18   k18 ; k18 = 94
.line	1223	loadk        r19   k19 ; k19 = 183
.line	1223	loadk        r20   k20 ; k20 = 61
.line	1223	loadk        r21   k21 ; k21 = 188
.line	1223	loadk        r22   k22 ; k22 = 38
.line	1223	loadk        r23   k23 ; k23 = 31
.line	1223	loadk        r24   k24 ; k24 = 187
.line	1223	loadk        r25   k25 ; k25 = 103
.line	1223	loadk        r26   k26 ; k26 = 171
.line	1223	loadk        r27   k27 ; k27 = 168
.line	1223	loadk        r28   k28 ; k28 = 2
.line	1223	loadk        r29   k29 ; k29 = 111
.line	1223	loadk        r30   k30 ; k30 = 51
.line	1223	loadk        r31   k15 ; k15 = 246
.line	1223	loadk        r32   k31 ; k31 = 169
.line	1223	loadk        r33   k32 ; k32 = 229
.line	1223	loadk        r34   k33 ; k33 = 89
.line	1223	loadk        r35   k34 ; k34 = 191
.line	1223	loadk        r36   k35 ; k35 = 60
.line	1223	loadk        r37   k34 ; k34 = 191
.line	1223	call          r3    35     2
.line	1223	call          r2     2     2
.line	1223	gettabup      r3    u0    k4 ; k4 = "require"
.line	1223	gettabup      r4    u0   k36 ; k36 = "table"
.line	1223	gettable      r4    r4   k37 ; k37 = "concat"
.line	1223	newtable      r5     1     0
.line	1223	getupval      r6    u1
.line	1223	loadk         r7    k5 ; k5 = 218
.line	1223	loadk         r8    k6 ; k6 = 129
.line	1223	loadk         r9    k7 ; k7 = 77
.line	1223	loadk        r10    k8 ; k8 = 100
.line	1223	loadk        r11    k9 ; k9 = 104
.line	1223	loadk        r12   k10 ; k10 = 76
.line	1223	loadk        r13   k11 ; k11 = 145
.line	1223	loadk        r14   k38 ; k38 = 142
.line	1223	loadk        r15   k39 ; k39 = 18
.line	1223	loadk        r16   k40 ; k40 = 78
.line	1223	loadk        r17   k41 ; k41 = 43
.line	1223	loadk        r18   k24 ; k24 = 187
.line	1223	loadk        r19   k42 ; k42 = 165
.line	1223	loadk        r20   k15 ; k15 = 246
.line	1223	loadk        r21   k43 ; k43 = 79
.line	1223	loadk        r22   k34 ; k34 = 191
.line	1223	loadk        r23   k44 ; k44 = 42
.line	1223	loadk        r24   k45 ; k45 = 243
.line	1223	loadk        r25   k46 ; k46 = 39
.line	1223	loadk        r26   k47 ; k47 = 68
.line	1223	loadk        r27   k48 ; k48 = 148
.line	1223	loadk        r28   k49 ; k49 = 123
.line	1223	loadk        r29   k50 ; k50 = 172
.line	1223	loadk        r30   k34 ; k34 = 191
.line	1223	loadk        r31   k51 ; k51 = 7
.line	1223	loadk        r32   k52 ; k52 = 73
.line	1223	loadk        r33   k53 ; k53 = 63
.line	1223	loadk        r34   k26 ; k26 = 171
.line	1223	loadk        r35   k54 ; k54 = 181
.line	1223	loadk        r36   k55 ; k55 = 230
.line	1223	loadk        r37   k56 ; k56 = 95
.line	1223	loadk        r38   k57 ; k57 = 175
.line	1223	loadk        r39   k58 ; k58 = 58
.line	1223	loadk        r40   k59 ; k59 = 146
.line	1223	loadk        r41   k60 ; k60 = 55
.line	1223	loadk        r42   k61 ; k61 = 84
.line	1223	loadk        r43   k62 ; k62 = 132
.line	1223	loadk        r44   k63 ; k63 = 107
.line	1223	loadk        r45   k21 ; k21 = 188
.line	1223	loadk        r46   k57 ; k57 = 175
.line	1223	call          r6    41     2
.line	1223	getupval      r7    u1
.line	1223	loadk         r8   k64 ; k64 = 208
.line	1223	loadk         r9   k65 ; k65 = 143
.line	1223	loadk        r10   k66 ; k66 = 65
.line	1223	loadk        r11   k18 ; k18 = 94
.line	1223	loadk        r12   k67 ; k67 = 110
.line	1223	loadk        r13   k33 ; k33 = 89
.line	1223	loadk        r14   k68 ; k68 = 209
.line	1223	loadk        r15   k69 ; k69 = 153
.line	1223	loadk        r16   k39 ; k39 = 18
.line	1223	loadk        r17   k18 ; k18 = 94
.line	1223	loadk        r18   k70 ; k70 = 56
.line	1223	call          r7    12     0
.line	1223	setlist       r5     0     1
.line	1223	call          r4     2     2
.line	1223	call          r3     2     2
.line	1223	gettable      r4    r3   k71 ; k71 = "GetSubscribeModuleOb" (truncated)
.line	1223	call          r4     1     2
.line	1223	gettable      r5    r0   k72 ; k72 = "currentItem"
.line	1223	test          r5     0
.line	1223	jmp            0  l133
.line	1223	gettable      r5    r0   k72 ; k72 = "currentItem"
.line	1223	gettable      r5    r5   k73 ; k73 = "isSubDailyGift"
.line	1223	test          r5     0
.line	1223	jmp            0  l133
.line	1223	self          r5    r4   k74 ; k74 = "IsBuyPrime"
.line	1223	call          r5     2     2
.line	1223	test          r5     0
.line	1223	jmp            0  l133
.line	1223	self          r5    r0   k75 ; k75 = "GetSubscribeDailyPac" (truncated)
.line	1223	call          r5     2     2
.line	1223	self          r6    r1   k76 ; k76 = "SetProductListData"
.line	1223	move          r8    r5
.line	1223	closure       r9    f0
.line	1223	gettable     r10    r0   k72 ; k72 = "currentItem"
.line	1223	gettable     r10   r10   k77 ; k77 = "rateType"
.line	1223	gettable     r11    r0   k72 ; k72 = "currentItem"
.line	1223	gettable     r11   r11   k78 ; k78 = "rateList"
.line	1223	call          r6     6     1
.line	1223	gettable      r6    r2   k79 ; k79 = "SetDisableSwitchToMo" (truncated)
.line	1223	loadbool      r7     0     0
.line	1223	call          r6     2     1
.label	l133
.line	1223	return        r0     1
.line	1223	move          r0    r0
.line	1223	move          r0    r0
.line	1223	move          r0    r0
.line	1223	move          r0    r0
.line	1223	return        r0     1

.function	main/f52/f0

.source	null
.linedefined	1230
.lastlinedefined	1232
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	true

.constant	k0	"OnClickProductItem"

.line	1230	getupval      r2    u0
.line	1230	self          r2    r2    k0 ; k0 = "OnClickProductItem"
.line	1230	move          r4    r0
.line	1230	move          r5    r1
.line	1230	call          r2     4     1
.line	1230	return        r0     1
.line	1230	move          r0    r0
.line	1230	move          r0    r0
.line	1230	move          r0    r0
.line	1230	move          r0    r0
.line	1230	return        r0     1

.function	main/f53

.source	null
.linedefined	1237
.lastlinedefined	1267
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	218
.constant	k4	129
.constant	k5	77
.constant	k6	100
.constant	k7	104
.constant	k8	76
.constant	k9	145
.constant	k10	142
.constant	k11	18
.constant	k12	78
.constant	k13	43
.constant	k14	187
.constant	k15	165
.constant	k16	246
.constant	k17	79
.constant	k18	191
.constant	k19	42
.constant	k20	243
.constant	k21	39
.constant	k22	68
.constant	k23	148
.constant	k24	123
.constant	k25	172
.constant	k26	7
.constant	k27	73
.constant	k28	63
.constant	k29	171
.constant	k30	181
.constant	k31	230
.constant	k32	95
.constant	k33	175
.constant	k34	58
.constant	k35	146
.constant	k36	55
.constant	k37	84
.constant	k38	132
.constant	k39	107
.constant	k40	188
.constant	k41	208
.constant	k42	143
.constant	k43	65
.constant	k44	94
.constant	k45	110
.constant	k46	89
.constant	k47	209
.constant	k48	153
.constant	k49	56
.constant	k50	"GetSubscribeModuleObj"
.constant	k51	"Get_Discount_Item_Info"
.constant	k52	1
.constant	k53	"equiped"
.constant	k54	false
.constant	k55	"type"
.constant	k56	15
.constant	k57	"subType"
.constant	k58	1503
.constant	k59	"bigIcon"
.constant	k60	"privilege_icon"
.constant	k61	"reducedPrice"
.constant	k62	0
.constant	k63	"DropType"
.constant	k64	"is_must_drop"
.constant	k65	true
.constant	k66	"showSpecialIcon"
.constant	k67	"selected"
.constant	k68	"is_hot"
.constant	k69	"DropItemSort"
.constant	k70	"item_time_limit"
.constant	k71	"DropItemID"
.constant	k72	"item_id"
.constant	k73	"DropWeight"
.constant	k74	"is_new"
.constant	k75	"DropRate"
.constant	k76	"preview"
.constant	k77	"is_limit_time"
.constant	k78	"specialIconPath"
.constant	k79	"DropItemNum"
.constant	k80	"item_num"
.constant	k81	"is_owned"

.line	1237	gettabup      r1    u0    k0 ; k0 = "require"
.line	1237	gettabup      r2    u0    k1 ; k1 = "table"
.line	1237	gettable      r2    r2    k2 ; k2 = "concat"
.line	1237	newtable      r3     1     0
.line	1237	getupval      r4    u1
.line	1237	loadk         r5    k3 ; k3 = 218
.line	1237	loadk         r6    k4 ; k4 = 129
.line	1237	loadk         r7    k5 ; k5 = 77
.line	1237	loadk         r8    k6 ; k6 = 100
.line	1237	loadk         r9    k7 ; k7 = 104
.line	1237	loadk        r10    k8 ; k8 = 76
.line	1237	loadk        r11    k9 ; k9 = 145
.line	1237	loadk        r12   k10 ; k10 = 142
.line	1237	loadk        r13   k11 ; k11 = 18
.line	1237	loadk        r14   k12 ; k12 = 78
.line	1237	loadk        r15   k13 ; k13 = 43
.line	1237	loadk        r16   k14 ; k14 = 187
.line	1237	loadk        r17   k15 ; k15 = 165
.line	1237	loadk        r18   k16 ; k16 = 246
.line	1237	loadk        r19   k17 ; k17 = 79
.line	1237	loadk        r20   k18 ; k18 = 191
.line	1237	loadk        r21   k19 ; k19 = 42
.line	1237	loadk        r22   k20 ; k20 = 243
.line	1237	loadk        r23   k21 ; k21 = 39
.line	1237	loadk        r24   k22 ; k22 = 68
.line	1237	loadk        r25   k23 ; k23 = 148
.line	1237	loadk        r26   k24 ; k24 = 123
.line	1237	loadk        r27   k25 ; k25 = 172
.line	1237	loadk        r28   k18 ; k18 = 191
.line	1237	loadk        r29   k26 ; k26 = 7
.line	1237	loadk        r30   k27 ; k27 = 73
.line	1237	loadk        r31   k28 ; k28 = 63
.line	1237	loadk        r32   k29 ; k29 = 171
.line	1237	loadk        r33   k30 ; k30 = 181
.line	1237	loadk        r34   k31 ; k31 = 230
.line	1237	loadk        r35   k32 ; k32 = 95
.line	1237	loadk        r36   k33 ; k33 = 175
.line	1237	loadk        r37   k34 ; k34 = 58
.line	1237	loadk        r38   k35 ; k35 = 146
.line	1237	loadk        r39   k36 ; k36 = 55
.line	1237	loadk        r40   k37 ; k37 = 84
.line	1237	loadk        r41   k38 ; k38 = 132
.line	1237	loadk        r42   k39 ; k39 = 107
.line	1237	loadk        r43   k40 ; k40 = 188
.line	1237	loadk        r44   k33 ; k33 = 175
.line	1237	call          r4    41     2
.line	1237	getupval      r5    u1
.line	1237	loadk         r6   k41 ; k41 = 208
.line	1237	loadk         r7   k42 ; k42 = 143
.line	1237	loadk         r8   k43 ; k43 = 65
.line	1237	loadk         r9   k44 ; k44 = 94
.line	1237	loadk        r10   k45 ; k45 = 110
.line	1237	loadk        r11   k46 ; k46 = 89
.line	1237	loadk        r12   k47 ; k47 = 209
.line	1237	loadk        r13   k48 ; k48 = 153
.line	1237	loadk        r14   k11 ; k11 = 18
.line	1237	loadk        r15   k44 ; k44 = 94
.line	1237	loadk        r16   k49 ; k49 = 56
.line	1237	call          r5    12     0
.line	1237	setlist       r3     0     1
.line	1237	call          r2     2     2
.line	1237	call          r1     2     2
.line	1237	gettable      r2    r1   k50 ; k50 = "GetSubscribeModuleOb" (truncated)
.line	1237	call          r2     1     2
.line	1237	self          r3    r2   k51 ; k51 = "Get_Discount_Item_In" (truncated)
.line	1237	call          r3     2     2
.line	1237	test          r3     1
.line	1237	jmp            0   l70
.line	1237	newtable      r3     0     0
.label	l70
.line	1237	newtable      r4     0     1
.line	1237	newtable      r5     0    19
.line	1237	settable      r5   k53   k54 ; k54 = false
.line	1237	settable      r5   k55   k56 ; k56 = 15
.line	1237	settable      r5   k57   k58 ; k58 = 1503
.line	1237	gettable      r6    r3   k60 ; k60 = "privilege_icon"
.line	1237	test          r6     1
.line	1237	jmp            0   l80
.line	1237	getupval      r6    u1
.line	1237	call          r6     1     2
.label	l80
.line	1237	settable      r5   k59    r6 ; k59 = "bigIcon"
.line	1237	settable      r5   k61   k62 ; k62 = 0
.line	1237	settable      r5   k63   k52 ; k52 = 1
.line	1237	settable      r5   k64   k65 ; k65 = true
.line	1237	settable      r5   k66   k54 ; k54 = false
.line	1237	settable      r5   k67   k65 ; k65 = true
.line	1237	settable      r5   k68   k54 ; k54 = false
.line	1237	settable      r5   k69   k52 ; k52 = 1
.line	1237	settable      r5   k70   k62 ; k62 = 0
.line	1237	gettable      r6    r3   k72 ; k72 = "item_id"
.line	1237	settable      r5   k71    r6 ; k71 = "DropItemID"
.line	1237	settable      r5   k73   k52 ; k52 = 1
.line	1237	settable      r5   k74   k54 ; k54 = false
.line	1237	settable      r5   k75   k52 ; k52 = 1
.line	1237	getupval      r6    u1
.line	1237	call          r6     1     2
.line	1237	settable      r5   k76    r6 ; k76 = "preview"
.line	1237	settable      r5   k77   k54 ; k54 = false
.line	1237	getupval      r6    u1
.line	1237	call          r6     1     2
.line	1237	settable      r5   k78    r6 ; k78 = "specialIconPath"
.line	1237	gettable      r6    r3   k80 ; k80 = "item_num"
.line	1237	settable      r5   k79    r6 ; k79 = "DropItemNum"
.line	1237	settable      r5   k81   k54 ; k54 = false
.line	1237	settable      r4   k52    r5 ; k52 = 1
.line	1237	return        r4     2
.line	1237	return        r0     1
.line	1237	move          r0    r0
.line	1237	return        r0     1

.function	main/f54

.source	null
.linedefined	1269
.lastlinedefined	1283
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"GlobalData"
.constant	k1	"IsJapanOrKorea"
.constant	k2	"UIRoot"
.constant	k3	"Border_0"
.constant	k4	"Slot"
.constant	k5	"GetPosition"
.constant	k6	"ModuleManager"
.constant	k7	"GetModule"
.constant	k8	"CommonModuleConfig"
.constant	k9	"store_supply_manager"
.constant	k10	"GetSupplyHasSubMark"
.constant	k11	"SetPosition"
.constant	k12	"FVector2D"
.constant	k13	-273.0
.constant	k14	"Y"
.constant	k15	-248.0

.line	1269	gettabup      r1    u0    k0 ; k0 = "GlobalData"
.line	1269	gettable      r1    r1    k1 ; k1 = "IsJapanOrKorea"
.line	1269	call          r1     1     2
.line	1269	test          r1     1
.line	1269	jmp            0    l7
.line	1269	return        r0     1
.label	l7
.line	1269	gettable      r1    r0    k2 ; k2 = "UIRoot"
.line	1269	gettable      r1    r1    k3 ; k3 = "Border_0"
.line	1269	test          r1     1
.line	1269	jmp            0   l12
.line	1269	return        r0     1
.label	l12
.line	1269	gettable      r1    r0    k2 ; k2 = "UIRoot"
.line	1269	gettable      r1    r1    k3 ; k3 = "Border_0"
.line	1269	gettable      r1    r1    k4 ; k4 = "Slot"
.line	1269	self          r1    r1    k5 ; k5 = "GetPosition"
.line	1269	call          r1     2     2
.line	1269	gettabup      r2    u0    k6 ; k6 = "ModuleManager"
.line	1269	gettable      r2    r2    k7 ; k7 = "GetModule"
.line	1269	gettabup      r3    u0    k6 ; k6 = "ModuleManager"
.line	1269	gettable      r3    r3    k8 ; k8 = "CommonModuleConfig"
.line	1269	gettable      r3    r3    k9 ; k9 = "store_supply_manager"
.line	1269	call          r2     2     2
.line	1269	self          r3    r2   k10 ; k10 = "GetSupplyHasSubMark"
.line	1269	call          r3     2     2
.line	1269	test          r3     0
.line	1269	jmp            0   l37
.line	1269	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1269	gettable      r3    r3    k3 ; k3 = "Border_0"
.line	1269	gettable      r3    r3    k4 ; k4 = "Slot"
.line	1269	self          r3    r3   k11 ; k11 = "SetPosition"
.line	1269	gettabup      r5    u0   k12 ; k12 = "FVector2D"
.line	1269	loadk         r6   k13 ; k13 = -273.0
.line	1269	gettable      r7    r1   k14 ; k14 = "Y"
.line	1269	call          r5     3     0
.line	1269	call          r3     0     1
.line	1269	jmp            0   l46
.label	l37
.line	1269	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	1269	gettable      r3    r3    k3 ; k3 = "Border_0"
.line	1269	gettable      r3    r3    k4 ; k4 = "Slot"
.line	1269	self          r3    r3   k11 ; k11 = "SetPosition"
.line	1269	gettabup      r5    u0   k12 ; k12 = "FVector2D"
.line	1269	loadk         r6   k15 ; k15 = -248.0
.line	1269	gettable      r7    r1   k14 ; k14 = "Y"
.line	1269	call          r5     3     0
.line	1269	call          r3     0     1
.label	l46
.line	1269	return        r0     1
.line	1269	move          r0    r0
.line	1269	move          r0    r0
.line	1269	move          r0    r0
.line	1269	move          r0    r0
.line	1269	return        r0     1

.function	main/f55

.source	null
.linedefined	1285
.lastlinedefined	1287
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"UpdateUI"

.line	1285	self          r1    r0    k0 ; k0 = "UpdateUI"
.line	1285	call          r1     2     1
.line	1285	return        r0     1
.line	1285	move          r0    r0
.line	1285	return        r0     1

.function	main/f56

.source	null
.linedefined	1289
.lastlinedefined	1304
.numparams	2
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"slua"
.constant	k1	"getMiliseconds"
.constant	k2	"import"
.constant	k3	254
.constant	k4	140
.constant	k5	73
.constant	k6	100
.constant	k7	118
.constant	k8	84
.constant	k9	222
.constant	k10	132
.constant	k11	45
.constant	k12	79
.constant	k13	43
.constant	k14	225
.constant	k15	160
.constant	k16	250
.constant	k17	91
.constant	k18	"slua_GameFrontendHUD"
.constant	k19	"GetWorld"
.constant	k20	150
.constant	k21	190
.constant	k22	71
.constant	k23	115
.constant	k24	111
.constant	k25	72
.constant	k26	203
.constant	k27	210
.constant	k28	59
.constant	k29	85
.constant	k30	252
.constant	k31	167
.constant	k32	6
.constant	k33	151
.constant	k34	42
.constant	k35	169
.constant	k36	67
.constant	k37	"Array"
.constant	k38	"UEnums"
.constant	k39	"EPropertyClass"
.constant	k40	"Object"
.constant	k41	"GetAllActorsWithTag"
.constant	k42	241
.constant	k43	64
.constant	k44	101
.constant	k45	99
.constant	k46	86
.constant	k47	246
.constant	k48	147
.constant	k49	37
.constant	k50	231
.constant	k51	172
.constant	k52	201
.constant	k53	77
.constant	k54	162
.constant	k55	25
.constant	k56	188
.constant	k57	51
.constant	k58	"Num"
.constant	k59	0
.constant	k60	"pairs"
.constant	k61	"isValid"
.constant	k62	"SetActorHiddenInGame"
.constant	k63	"log"
.constant	k64	"bWriteLog"
.constant	k65	"table"
.constant	k66	"concat"
.constant	k67	234
.constant	k68	153
.constant	k69	75
.constant	k70	127
.constant	k71	218
.constant	k72	27
.constant	k73	249
.constant	k74	248
.constant	k75	179
.constant	k76	142
.constant	k77	49
.constant	k78	69
.constant	k79	105
.constant	k80	168
.constant	k81	170
.constant	k82	11
.constant	k83	10
.constant	k84	176
.constant	k85	76
.constant	k86	138
.constant	k87	48
.constant	k88	44
.constant	k89	174
.constant	k90	113
.constant	k91	187
.constant	k92	185
.constant	k93	220
.constant	k94	131
.constant	k95	4
.constant	k96	98
.constant	k97	199
.constant	k98	94
.constant	k99	212
.constant	k100	158

.line	1289	gettabup      r2    u0    k0 ; k0 = "slua"
.line	1289	gettable      r2    r2    k1 ; k1 = "getMiliseconds"
.line	1289	call          r2     1     2
.line	1289	gettabup      r3    u0    k2 ; k2 = "import"
.line	1289	getupval      r4    u1
.line	1289	loadk         r5    k3 ; k3 = 254
.line	1289	loadk         r6    k4 ; k4 = 140
.line	1289	loadk         r7    k5 ; k5 = 73
.line	1289	loadk         r8    k6 ; k6 = 100
.line	1289	loadk         r9    k7 ; k7 = 118
.line	1289	loadk        r10    k8 ; k8 = 84
.line	1289	loadk        r11    k9 ; k9 = 222
.line	1289	loadk        r12   k10 ; k10 = 132
.line	1289	loadk        r13   k11 ; k11 = 45
.line	1289	loadk        r14   k12 ; k12 = 79
.line	1289	loadk        r15   k13 ; k13 = 43
.line	1289	loadk        r16   k14 ; k14 = 225
.line	1289	loadk        r17   k15 ; k15 = 160
.line	1289	loadk        r18   k16 ; k16 = 250
.line	1289	loadk        r19   k17 ; k17 = 91
.line	1289	call          r4    16     2
.line	1289	call          r3     2     2
.line	1289	gettabup      r4    u0   k18 ; k18 = "slua_GameFrontendHUD"
.line	1289	self          r4    r4   k19 ; k19 = "GetWorld"
.line	1289	call          r4     2     2
.line	1289	gettabup      r5    u0    k2 ; k2 = "import"
.line	1289	getupval      r6    u1
.line	1289	loadk         r7   k20 ; k20 = 150
.line	1289	loadk         r8   k21 ; k21 = 190
.line	1289	loadk         r9   k22 ; k22 = 71
.line	1289	loadk        r10   k23 ; k23 = 115
.line	1289	loadk        r11   k24 ; k24 = 111
.line	1289	loadk        r12   k25 ; k25 = 72
.line	1289	loadk        r13   k26 ; k26 = 203
.line	1289	loadk        r14   k27 ; k27 = 210
.line	1289	loadk        r15   k28 ; k28 = 59
.line	1289	loadk        r16   k29 ; k29 = 85
.line	1289	loadk        r17   k11 ; k11 = 45
.line	1289	loadk        r18   k30 ; k30 = 252
.line	1289	loadk        r19   k31 ; k31 = 167
.line	1289	loadk        r20   k30 ; k30 = 252
.line	1289	loadk        r21   k32 ; k32 = 6
.line	1289	loadk        r22   k33 ; k33 = 151
.line	1289	loadk        r23   k34 ; k34 = 42
.line	1289	loadk        r24   k35 ; k35 = 169
.line	1289	loadk        r25   k28 ; k28 = 59
.line	1289	loadk        r26   k36 ; k36 = 67
.line	1289	call          r6    21     2
.line	1289	call          r5     2     2
.line	1289	gettabup      r6    u0    k0 ; k0 = "slua"
.line	1289	gettable      r6    r6   k37 ; k37 = "Array"
.line	1289	gettabup      r7    u0   k38 ; k38 = "UEnums"
.line	1289	gettable      r7    r7   k39 ; k39 = "EPropertyClass"
.line	1289	gettable      r7    r7   k40 ; k40 = "Object"
.line	1289	move          r8    r5
.line	1289	call          r6     3     2
.line	1289	gettable      r7    r3   k41 ; k41 = "GetAllActorsWithTag"
.line	1289	move          r8    r4
.line	1289	getupval      r9    u1
.line	1289	loadk        r10   k42 ; k42 = 241
.line	1289	loadk        r11   k10 ; k10 = 132
.line	1289	loadk        r12   k43 ; k43 = 64
.line	1289	loadk        r13   k44 ; k44 = 101
.line	1289	loadk        r14   k45 ; k45 = 99
.line	1289	loadk        r15   k46 ; k46 = 86
.line	1289	loadk        r16   k47 ; k47 = 246
.line	1289	loadk        r17   k48 ; k48 = 147
.line	1289	loadk        r18   k11 ; k11 = 45
.line	1289	loadk        r19   k12 ; k12 = 79
.line	1289	loadk        r20   k49 ; k49 = 37
.line	1289	loadk        r21   k50 ; k50 = 231
.line	1289	loadk        r22   k51 ; k51 = 172
.line	1289	loadk        r23   k52 ; k52 = 201
.line	1289	loadk        r24   k53 ; k53 = 77
.line	1289	loadk        r25   k54 ; k54 = 162
.line	1289	loadk        r26   k55 ; k55 = 25
.line	1289	loadk        r27   k56 ; k56 = 188
.line	1289	loadk        r28   k57 ; k57 = 51
.line	1289	loadk        r29    k8 ; k8 = 84
.line	1289	call          r9    21     2
.line	1289	move         r10    r6
.line	1289	call          r7     4     2
.line	1289	test          r7     0
.line	1289	jmp            0  l104
.line	1289	self          r8    r7   k58 ; k58 = "Num"
.line	1289	call          r8     2     2
.line	1289	lt             0   k59    r8 ; k59 = 0
.line	1289	jmp            0  l104
.line	1289	gettabup      r8    u0   k60 ; k60 = "pairs"
.line	1289	move          r9    r7
.line	1289	call          r8     2     4
.line	1289	jmp            0  l102
.line	1289	gettabup     r13    u0    k0 ; k0 = "slua"
.line	1289	gettable     r13   r13   k61 ; k61 = "isValid"
.line	1289	move         r14   r12
.line	1289	call         r13     2     2
.line	1289	test         r13     0
.line	1289	jmp            0  l102
.line	1289	self         r13   r12   k62 ; k62 = "SetActorHiddenInGame"
.line	1289	move         r15    r1
.line	1289	call         r13     3     1
.label	l102
.line	1289	move          r0    r0
.line	1289	move          r0    r0
.label	l104
.line	1289	gettabup      r8    u0   k63 ; k63 = "log"
.line	1289	gettabup      r9    u0   k64 ; k64 = "bWriteLog"
.line	1289	test          r9     0
.line	1289	jmp            0  l176
.line	1289	gettabup      r9    u0   k65 ; k65 = "table"
.line	1289	gettable      r9    r9   k66 ; k66 = "concat"
.line	1289	newtable     r10     1     0
.line	1289	getupval     r11    u1
.line	1289	loadk        r12   k67 ; k67 = 234
.line	1289	loadk        r13   k68 ; k68 = 153
.line	1289	loadk        r14   k69 ; k69 = 75
.line	1289	loadk        r15   k23 ; k23 = 115
.line	1289	loadk        r16   k45 ; k45 = 99
.line	1289	loadk        r17   k70 ; k70 = 127
.line	1289	loadk        r18   k71 ; k71 = 218
.line	1289	loadk        r19   k48 ; k48 = 147
.line	1289	loadk        r20   k72 ; k72 = 27
.line	1289	loadk        r21    k5 ; k5 = 73
.line	1289	loadk        r22   k13 ; k13 = 43
.line	1289	loadk        r23   k73 ; k73 = 249
.line	1289	loadk        r24   k68 ; k68 = 153
.line	1289	loadk        r25   k74 ; k74 = 248
.line	1289	loadk        r26   k12 ; k12 = 79
.line	1289	loadk        r27   k75 ; k75 = 179
.line	1289	loadk        r28   k23 ; k23 = 115
.line	1289	loadk        r29   k76 ; k76 = 142
.line	1289	loadk        r30   k77 ; k77 = 49
.line	1289	loadk        r31   k78 ; k78 = 69
.line	1289	loadk        r32   k54 ; k54 = 162
.line	1289	loadk        r33   k79 ; k79 = 105
.line	1289	loadk        r34   k80 ; k80 = 168
.line	1289	loadk        r35   k81 ; k81 = 170
.line	1289	loadk        r36   k82 ; k82 = 11
.line	1289	loadk        r37   k12 ; k12 = 79
.line	1289	loadk        r38   k83 ; k83 = 10
.line	1289	loadk        r39   k67 ; k67 = 234
.line	1289	loadk        r40   k84 ; k84 = 176
.line	1289	loadk        r41   k50 ; k50 = 231
.line	1289	loadk        r42   k85 ; k85 = 76
.line	1289	loadk        r43   k86 ; k86 = 138
.line	1289	loadk        r44   k87 ; k87 = 48
.line	1289	loadk        r45   k81 ; k81 = 170
.line	1289	loadk        r46   k88 ; k88 = 44
.line	1289	loadk        r47   k29 ; k29 = 85
.line	1289	loadk        r48   k89 ; k89 = 174
.line	1289	loadk        r49   k90 ; k90 = 113
.line	1289	loadk        r50   k91 ; k91 = 187
.line	1289	loadk        r51   k92 ; k92 = 185
.line	1289	call         r11    41     2
.line	1289	getupval     r12    u1
.line	1289	loadk        r13   k93 ; k93 = 220
.line	1289	loadk        r14   k94 ; k94 = 131
.line	1289	loadk        r15   k95 ; k95 = 4
.line	1289	loadk        r16   k96 ; k96 = 98
.line	1289	loadk        r17   k79 ; k79 = 105
.line	1289	loadk        r18   k69 ; k69 = 75
.line	1289	loadk        r19   k26 ; k26 = 203
.line	1289	loadk        r20   k97 ; k97 = 199
.line	1289	loadk        r21   k98 ; k98 = 94
.line	1289	call         r12    10     0
.line	1289	setlist      r10     0     1
.line	1289	call          r9     2     2
.line	1289	gettabup     r10    u0    k0 ; k0 = "slua"
.line	1289	gettable     r10   r10    k1 ; k1 = "getMiliseconds"
.line	1289	call         r10     1     2
.line	1289	sub          r10   r10    r2
.line	1289	getupval     r11    u1
.line	1289	loadk        r12   k99 ; k99 = 212
.line	1289	loadk        r13  k100 ; k100 = 158
.line	1289	loadk        r14   k83 ; k83 = 10
.line	1289	call         r11     4     2
.line	1289	concat        r9    r9   r11
.label	l176
.line	1289	call          r8     2     1
.line	1289	return        r0     1
.line	1289	move          r0    r0
.line	1289	return        r0     1

.function	main/f57

.source	null
.linedefined	1306
.lastlinedefined	1336
.numparams	3
.is_vararg	0
.maxstacksize	41

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"GetFrame"
.constant	k1	"itemId"
.constant	k2	"DropItemID"
.constant	k3	"selected"
.constant	k4	false
.constant	k5	"equiped"
.constant	k6	"PutOnClothes"
.constant	k7	"bIsWear"
.constant	k8	true
.constant	k9	"require"
.constant	k10	218
.constant	k11	129
.constant	k12	77
.constant	k13	100
.constant	k14	104
.constant	k15	76
.constant	k16	145
.constant	k17	17
.constant	k18	92
.constant	k19	35
.constant	k20	246
.constant	k21	231
.constant	k22	248
.constant	k23	94
.constant	k24	183
.constant	k25	61
.constant	k26	188
.constant	k27	38
.constant	k28	31
.constant	k29	187
.constant	k30	103
.constant	k31	171
.constant	k32	168
.constant	k33	2
.constant	k34	111
.constant	k35	51
.constant	k36	169
.constant	k37	229
.constant	k38	89
.constant	k39	191
.constant	k40	60
.constant	k41	"ModuleManager"
.constant	k42	"GetModule"
.constant	k43	"CommonModuleConfig"
.constant	k44	"multi_state_manager"
.constant	k45	"GetOtherStateClothID"
.constant	k46	"HasEquiped"
.constant	k47	"LobbyModuleConfig"
.constant	k48	"LogicFusionModule"
.constant	k49	"IsFusionItem"
.constant	k50	"GetFusionConfig"
.constant	k51	"targetItem"
.constant	k52	"ipairs"
.constant	k53	"originItems"
.constant	k54	"PutOffClothes"

.line	1306	self          r3    r0    k0 ; k0 = "GetFrame"
.line	1306	call          r3     2     2
.line	1306	testset       r4    r1     0
.line	1306	jmp            0    l9
.line	1306	gettable      r4    r1    k1 ; k1 = "itemId"
.line	1306	test          r4     1
.line	1306	jmp            0    l9
.line	1306	gettable      r4    r1    k2 ; k2 = "DropItemID"
.label	l9
.line	1306	gettable      r5    r1    k3 ; k3 = "selected"
.line	1306	eq             1    r5    k4 ; k4 = false
.line	1306	jmp            0   l17
.line	1306	gettable      r5    r1    k5 ; k5 = "equiped"
.line	1306	eq             1    r5    k4 ; k4 = false
.line	1306	jmp            0   l17
.line	1306	test          r2     0
.line	1306	jmp            0   l22
.label	l17
.line	1306	self          r5    r3    k6 ; k6 = "PutOnClothes"
.line	1306	move          r7    r4
.line	1306	call          r5     3     1
.line	1306	settable      r0    k7    k8 ; k8 = true
.line	1306	jmp            0  l115
.label	l22
.line	1306	gettabup      r5    u0    k9 ; k9 = "require"
.line	1306	getupval      r6    u1
.line	1306	loadk         r7   k10 ; k10 = 218
.line	1306	loadk         r8   k11 ; k11 = 129
.line	1306	loadk         r9   k12 ; k12 = 77
.line	1306	loadk        r10   k13 ; k13 = 100
.line	1306	loadk        r11   k14 ; k14 = 104
.line	1306	loadk        r12   k15 ; k15 = 76
.line	1306	loadk        r13   k16 ; k16 = 145
.line	1306	loadk        r14   k16 ; k16 = 145
.line	1306	loadk        r15   k17 ; k17 = 17
.line	1306	loadk        r16   k18 ; k18 = 92
.line	1306	loadk        r17   k19 ; k19 = 35
.line	1306	loadk        r18   k20 ; k20 = 246
.line	1306	loadk        r19   k21 ; k21 = 231
.line	1306	loadk        r20   k22 ; k22 = 248
.line	1306	loadk        r21   k23 ; k23 = 94
.line	1306	loadk        r22   k24 ; k24 = 183
.line	1306	loadk        r23   k25 ; k25 = 61
.line	1306	loadk        r24   k26 ; k26 = 188
.line	1306	loadk        r25   k27 ; k27 = 38
.line	1306	loadk        r26   k28 ; k28 = 31
.line	1306	loadk        r27   k29 ; k29 = 187
.line	1306	loadk        r28   k30 ; k30 = 103
.line	1306	loadk        r29   k31 ; k31 = 171
.line	1306	loadk        r30   k32 ; k32 = 168
.line	1306	loadk        r31   k33 ; k33 = 2
.line	1306	loadk        r32   k34 ; k34 = 111
.line	1306	loadk        r33   k35 ; k35 = 51
.line	1306	loadk        r34   k20 ; k20 = 246
.line	1306	loadk        r35   k36 ; k36 = 169
.line	1306	loadk        r36   k37 ; k37 = 229
.line	1306	loadk        r37   k38 ; k38 = 89
.line	1306	loadk        r38   k39 ; k39 = 191
.line	1306	loadk        r39   k40 ; k40 = 60
.line	1306	loadk        r40   k39 ; k39 = 191
.line	1306	call          r6    35     2
.line	1306	call          r5     2     2
.line	1306	gettabup      r6    u0   k41 ; k41 = "ModuleManager"
.line	1306	gettable      r6    r6   k42 ; k42 = "GetModule"
.line	1306	gettabup      r7    u0   k41 ; k41 = "ModuleManager"
.line	1306	gettable      r7    r7   k43 ; k43 = "CommonModuleConfig"
.line	1306	gettable      r7    r7   k44 ; k44 = "multi_state_manager"
.line	1306	call          r6     2     2
.line	1306	self          r7    r6   k45 ; k45 = "GetOtherStateClothID"
.line	1306	move          r9    r4
.line	1306	call          r7     3     2
.line	1306	test          r7     0
.line	1306	jmp            0   l77
.line	1306	gettable      r8    r5   k46 ; k46 = "HasEquiped"
.line	1306	move          r9    r4
.line	1306	call          r8     2     2
.line	1306	test          r8     1
.line	1306	jmp            0   l77
.line	1306	move          r4    r7
.label	l77
.line	1306	gettabup      r8    u0   k41 ; k41 = "ModuleManager"
.line	1306	gettable      r8    r8   k42 ; k42 = "GetModule"
.line	1306	gettabup      r9    u0   k41 ; k41 = "ModuleManager"
.line	1306	gettable      r9    r9   k47 ; k47 = "LobbyModuleConfig"
.line	1306	gettable      r9    r9   k48 ; k48 = "LogicFusionModule"
.line	1306	call          r8     2     2
.line	1306	self          r9    r8   k49 ; k49 = "IsFusionItem"
.line	1306	move         r11    r4
.line	1306	call          r9     3     2
.line	1306	test          r9     0
.line	1306	jmp            0  l111
.line	1306	self          r9    r8   k50 ; k50 = "GetFusionConfig"
.line	1306	move         r11    r4
.line	1306	call          r9     3     2
.line	1306	gettable     r10    r5   k46 ; k46 = "HasEquiped"
.line	1306	gettable     r11    r9   k51 ; k51 = "targetItem"
.line	1306	call         r10     2     2
.line	1306	test         r10     0
.line	1306	jmp            0   l98
.line	1306	gettable      r4    r9   k51 ; k51 = "targetItem"
.line	1306	jmp            0  l111
.label	l98
.line	1306	gettabup     r10    u0   k52 ; k52 = "ipairs"
.line	1306	gettable     r11    r9   k53 ; k53 = "originItems"
.line	1306	call         r10     2     4
.line	1306	jmp            0  l109
.line	1306	gettable     r15    r5   k46 ; k46 = "HasEquiped"
.line	1306	move         r16   r14
.line	1306	call         r15     2     2
.line	1306	test         r15     0
.line	1306	jmp            0  l109
.line	1306	move          r4   r14
.line	1306	jmp            0  l111
.label	l109
.line	1306	move          r0    r0
.line	1306	move          r0    r0
.label	l111
.line	1306	self          r9    r3   k54 ; k54 = "PutOffClothes"
.line	1306	move         r11    r4
.line	1306	call          r9     3     1
.line	1306	settable      r0    k7    k4 ; k4 = false
.label	l115
.line	1306	return        r0     1
.line	1306	move          r0    r0
.line	1306	return        r0     1

.function	main/f58

.source	null
.linedefined	1338
.lastlinedefined	1354
.numparams	4
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	8	true

.constant	k0	"StoreConst"
.constant	k1	"label_market_index_market_list"
.constant	k2	"rawData"
.constant	k3	nil
.constant	k4	"rawItemInfo"
.constant	k5	"showDataList"
.constant	k6	"next"
.constant	k7	"pairs"
.constant	k8	"selected"
.constant	k9	true
.constant	k10	false
.constant	k11	"equiped"
.constant	k12	"IsEquippedByItemId"
.constant	k13	"itemId"

.line	1338	gettabup      r4    u0    k0 ; k0 = "StoreConst"
.line	1338	gettable      r4    r4    k1 ; k1 = "label_market_index_m" (truncated)
.line	1338	gettable      r5    r0    k2 ; k2 = "rawData"
.line	1338	test          r5     0
.line	1338	jmp            0   l14
.line	1338	gettable      r5    r0    k2 ; k2 = "rawData"
.line	1338	gettable      r5    r5    r4
.line	1338	eq             1    r5    k3 ; k3 = nil
.line	1338	jmp            0   l14
.line	1338	gettable      r5    r0    k2 ; k2 = "rawData"
.line	1338	gettable      r5    r5    r4
.line	1338	gettable      r5    r5    r3
.line	1338	settable      r0    k4    r5 ; k4 = "rawItemInfo"
.label	l14
.line	1338	gettable      r5    r0    k5 ; k5 = "showDataList"
.line	1338	test          r5     0
.line	1338	jmp            0   l22
.line	1338	gettabup      r5    u0    k6 ; k6 = "next"
.line	1338	gettable      r6    r0    k5 ; k5 = "showDataList"
.line	1338	call          r5     2     2
.line	1338	test          r5     1
.line	1338	jmp            0   l23
.label	l22
.line	1338	return        r0     1
.label	l23
.line	1338	gettabup      r5    u0    k7 ; k7 = "pairs"
.line	1338	gettable      r6    r0    k5 ; k5 = "showDataList"
.line	1338	call          r5     2     4
.line	1338	jmp            0   l36
.line	1338	eq             0    r8    r1
.line	1338	jmp            0   l31
.line	1338	settable      r9    k8    k9 ; k9 = true
.line	1338	jmp            0   l32
.label	l31
.line	1338	settable      r9    k8   k10 ; k10 = false
.label	l32
.line	1338	gettabup     r10    u1   k12 ; k12 = "IsEquippedByItemId"
.line	1338	gettable     r11    r9   k13 ; k13 = "itemId"
.line	1338	call         r10     2     2
.line	1338	settable      r9   k11   r10 ; k11 = "equiped"
.label	l36
.line	1338	move          r0    r0
.line	1338	move          r0    r0
.line	1338	return        r0     1
.line	1338	move          r0    r0
.line	1338	move          r0    r0
.line	1338	move          r0    r0
.line	1338	return        r0     1

.function	main/f59

.source	null
.linedefined	1356
.lastlinedefined	1393
.numparams	5
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	8	true

.constant	k0	"showDataList"
.constant	k1	"next"
.constant	k2	"require"
.constant	k3	"table"
.constant	k4	"concat"
.constant	k5	218
.constant	k6	129
.constant	k7	77
.constant	k8	100
.constant	k9	104
.constant	k10	76
.constant	k11	145
.constant	k12	17
.constant	k13	92
.constant	k14	35
.constant	k15	246
.constant	k16	231
.constant	k17	248
.constant	k18	94
.constant	k19	183
.constant	k20	61
.constant	k21	188
.constant	k22	38
.constant	k23	31
.constant	k24	187
.constant	k25	103
.constant	k26	171
.constant	k27	168
.constant	k28	2
.constant	k29	111
.constant	k30	51
.constant	k31	169
.constant	k32	229
.constant	k33	89
.constant	k34	191
.constant	k35	13
.constant	k36	180
.constant	k37	52
.constant	k38	68
.constant	k39	174
.constant	k40	125
.constant	k41	179
.constant	k42	173
.constant	k43	220
.constant	k44	159
.constant	k45	"IsWeapon"
.constant	k46	"CDataTable"
.constant	k47	"GetTableData"
.constant	k48	240
.constant	k49	153
.constant	k50	65
.constant	k51	108
.constant	k52	"IsGrenade"
.constant	k53	"ItemType"
.constant	k54	"ItemSubType"
.constant	k55	"bDownloadAutoPutOn"
.constant	k56	"pairs"
.constant	k57	"equiped"
.constant	k58	"IsEquippedByItemId"
.constant	k59	"itemId"
.constant	k60	0
.constant	k61	"selected"
.constant	k62	true
.constant	k63	"OnClickItemHandle"
.constant	k64	"GetFrame"
.constant	k65	"PutOnClothes"
.constant	k66	"downloadFinish"
.constant	k67	"vehicleExtraData"
.constant	k68	"forceDisplay"
.constant	k69	"SetModelRotation"
.constant	k70	false
.constant	k71	"LoopScrollGrid_0"
.constant	k72	"RefreshAllItems"

.line	1356	gettable      r5    r0    k0 ; k0 = "showDataList"
.line	1356	test          r5     0
.line	1356	jmp            0    l9
.line	1356	gettabup      r5    u0    k1 ; k1 = "next"
.line	1356	gettable      r6    r0    k0 ; k0 = "showDataList"
.line	1356	call          r5     2     2
.line	1356	test          r5     1
.line	1356	jmp            0   l10
.label	l9
.line	1356	return        r0     1
.label	l10
.line	1356	gettabup      r5    u0    k2 ; k2 = "require"
.line	1356	gettabup      r6    u0    k3 ; k3 = "table"
.line	1356	gettable      r6    r6    k4 ; k4 = "concat"
.line	1356	newtable      r7     1     0
.line	1356	getupval      r8    u1
.line	1356	loadk         r9    k5 ; k5 = 218
.line	1356	loadk        r10    k6 ; k6 = 129
.line	1356	loadk        r11    k7 ; k7 = 77
.line	1356	loadk        r12    k8 ; k8 = 100
.line	1356	loadk        r13    k9 ; k9 = 104
.line	1356	loadk        r14   k10 ; k10 = 76
.line	1356	loadk        r15   k11 ; k11 = 145
.line	1356	loadk        r16   k11 ; k11 = 145
.line	1356	loadk        r17   k12 ; k12 = 17
.line	1356	loadk        r18   k13 ; k13 = 92
.line	1356	loadk        r19   k14 ; k14 = 35
.line	1356	loadk        r20   k15 ; k15 = 246
.line	1356	loadk        r21   k16 ; k16 = 231
.line	1356	loadk        r22   k17 ; k17 = 248
.line	1356	loadk        r23   k18 ; k18 = 94
.line	1356	loadk        r24   k19 ; k19 = 183
.line	1356	loadk        r25   k20 ; k20 = 61
.line	1356	loadk        r26   k21 ; k21 = 188
.line	1356	loadk        r27   k22 ; k22 = 38
.line	1356	loadk        r28   k23 ; k23 = 31
.line	1356	loadk        r29   k24 ; k24 = 187
.line	1356	loadk        r30   k25 ; k25 = 103
.line	1356	loadk        r31   k26 ; k26 = 171
.line	1356	loadk        r32   k27 ; k27 = 168
.line	1356	loadk        r33   k28 ; k28 = 2
.line	1356	loadk        r34   k29 ; k29 = 111
.line	1356	loadk        r35   k30 ; k30 = 51
.line	1356	loadk        r36   k15 ; k15 = 246
.line	1356	loadk        r37   k31 ; k31 = 169
.line	1356	loadk        r38   k32 ; k32 = 229
.line	1356	loadk        r39   k33 ; k33 = 89
.line	1356	loadk        r40   k34 ; k34 = 191
.line	1356	loadk        r41   k35 ; k35 = 13
.line	1356	loadk        r42   k36 ; k36 = 180
.line	1356	loadk        r43   k37 ; k37 = 52
.line	1356	loadk        r44   k38 ; k38 = 68
.line	1356	loadk        r45   k39 ; k39 = 174
.line	1356	loadk        r46   k40 ; k40 = 125
.line	1356	loadk        r47   k41 ; k41 = 179
.line	1356	loadk        r48   k42 ; k42 = 173
.line	1356	call          r8    41     2
.line	1356	getupval      r9    u1
.line	1356	loadk        r10   k43 ; k43 = 220
.line	1356	loadk        r11   k44 ; k44 = 159
.line	1356	call          r9     3     0
.line	1356	setlist       r7     0     1
.line	1356	call          r6     2     2
.line	1356	call          r5     2     2
.line	1356	gettabup      r6    u2   k45 ; k45 = "IsWeapon"
.line	1356	move          r7    r3
.line	1356	call          r6     2     2
.line	1356	gettabup      r7    u0   k46 ; k46 = "CDataTable"
.line	1356	gettable      r7    r7   k47 ; k47 = "GetTableData"
.line	1356	getupval      r8    u1
.line	1356	loadk         r9   k48 ; k48 = 240
.line	1356	loadk        r10   k49 ; k49 = 153
.line	1356	loadk        r11   k50 ; k50 = 65
.line	1356	loadk        r12   k51 ; k51 = 108
.line	1356	call          r8     5     2
.line	1356	move          r9    r3
.line	1356	call          r7     3     2
.line	1356	loadbool      r8     0     0
.line	1356	test          r7     0
.line	1356	jmp            0   l84
.line	1356	gettable      r9    r5   k52 ; k52 = "IsGrenade"
.line	1356	gettable     r10    r7   k53 ; k53 = "ItemType"
.line	1356	gettable     r11    r7   k54 ; k54 = "ItemSubType"
.line	1356	call          r9     3     2
.line	1356	move          r8    r9
.label	l84
.line	1356	testset       r9    r4     0
.line	1356	jmp            0   l87
.line	1356	gettable      r9    r4   k55 ; k55 = "bDownloadAutoPutOn"
.label	l87
.line	1356	gettabup     r10    u0   k56 ; k56 = "pairs"
.line	1356	gettable     r11    r0    k0 ; k0 = "showDataList"
.line	1356	call         r10     2     4
.line	1356	jmp            0  l129
.line	1356	gettabup     r15    u2   k58 ; k58 = "IsEquippedByItemId"
.line	1356	gettable     r16   r14   k59 ; k59 = "itemId"
.line	1356	call         r15     2     2
.line	1356	settable     r14   k57   r15 ; k57 = "equiped"
.line	1356	test          r3     0
.line	1356	jmp            0  l129
.line	1356	lt             0   k60    r3 ; k60 = 0
.line	1356	jmp            0  l129
.line	1356	gettable     r15   r14   k59 ; k59 = "itemId"
.line	1356	eq             0   r15    r3
.line	1356	jmp            0  l128
.line	1356	settable     r14   k61   k62 ; k62 = true
.line	1356	test          r9     0
.line	1356	jmp            0  l129
.line	1356	self         r15    r0   k63 ; k63 = "OnClickItemHandle"
.line	1356	move         r17   r14
.line	1356	move         r18   r13
.line	1356	loadbool     r19     1     0
.line	1356	call         r15     5     1
.line	1356	self         r15    r0   k64 ; k64 = "GetFrame"
.line	1356	call         r15     2     2
.line	1356	self         r16   r15   k65 ; k65 = "PutOnClothes"
.line	1356	move         r18    r3
.line	1356	newtable     r19     0     2
.line	1356	settable     r19   k66   k62 ; k62 = true
.line	1356	newtable     r20     0     1
.line	1356	settable     r20   k68   k62 ; k62 = true
.line	1356	settable     r19   k67   r20 ; k67 = "vehicleExtraData"
.line	1356	call         r16     4     1
.line	1356	test          r6     1
.line	1356	jmp            0  l124
.line	1356	test          r8     0
.line	1356	jmp            0  l126
.label	l124
.line	1356	self         r16    r0   k69 ; k69 = "SetModelRotation"
.line	1356	call         r16     2     1
.label	l126
.line	1356	return        r0     1
.line	1356	jmp            0  l129
.label	l128
.line	1356	settable     r14   k61   k70 ; k70 = false
.label	l129
.line	1356	move          r0    r0
.line	1356	move          r0    r0
.line	1356	test          r9     1
.line	1356	jmp            0  l139
.line	1356	gettable     r10    r0   k71 ; k71 = "LoopScrollGrid_0"
.line	1356	test         r10     0
.line	1356	jmp            0  l139
.line	1356	gettable     r10    r0   k71 ; k71 = "LoopScrollGrid_0"
.line	1356	self         r10   r10   k72 ; k72 = "RefreshAllItems"
.line	1356	call         r10     2     1
.label	l139
.line	1356	return        r0     1
.line	1356	move          r0    r0
.line	1356	move          r0    r0
.line	1356	move          r0    r0
.line	1356	return        r0     1

.function	main/f60

.source	null
.linedefined	1395
.lastlinedefined	1417
.numparams	5
.is_vararg	0
.maxstacksize	52

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	193
.constant	k5	142
.constant	k6	71
.constant	k7	33
.constant	k8	85
.constant	k9	76
.constant	k10	208
.constant	k11	143
.constant	k12	27
.constant	k13	124
.constant	k14	47
.constant	k15	251
.constant	k16	172
.constant	k17	235
.constant	k18	73
.constant	k19	186
.constant	k20	25
.constant	k21	188
.constant	k22	51
.constant	k23	84
.constant	k24	204
.constant	k25	93
.constant	k26	191
.constant	k27	169
.constant	k28	15
.constant	k29	95
.constant	k30	63
.constant	k31	210
.constant	k32	232
.constant	k33	74
.constant	k34	145
.constant	k35	48
.constant	k36	185
.constant	k37	44
.constant	k38	96
.constant	k39	147
.constant	k40	108
.constant	k41	176
.constant	k42	153
.constant	k43	214
.constant	k44	154
.constant	k45	109
.constant	k46	105
.constant	k47	89
.constant	k48	219
.constant	k49	221
.constant	k50	23
.constant	k51	79
.constant	k52	248
.constant	k53	128
.constant	k54	8
.constant	k55	"tostring"
.constant	k56	"log_tree"
.constant	k57	67
.constant	k58	62
.constant	k59	231
.constant	k60	168
.constant	k61	162
.constant	k62	40
.constant	k63	253
.constant	k64	17
.constant	k65	"showDataList"
.constant	k66	"next"
.constant	k67	13
.constant	k68	83
.constant	k69	37
.constant	k70	226
.constant	k71	141
.constant	k72	92
.constant	k73	183
.constant	k74	5
.constant	k75	180
.constant	k76	39
.constant	k77	69
.constant	k78	97
.constant	k79	237
.constant	k80	11
.constant	k81	234
.constant	k82	171
.constant	k83	"GetCurItemAndIndex"
.constant	k84	94
.constant	k85	38
.constant	k86	240
.constant	k87	170
.constant	k88	184
.constant	k89	45
.constant	k90	159
.constant	k91	123
.constant	k92	239
.constant	k93	28
.constant	k94	53
.constant	k95	247
.constant	k96	"bDownloadAutoPutOn"
.constant	k97	"itemId"
.constant	k98	58
.constant	k99	82
.constant	k100	57
.constant	k101	229
.constant	k102	165
.constant	k103	81
.constant	k104	246
.constant	k105	32
.constant	k106	49
.constant	k107	78
.constant	k108	115
.constant	k109	86
.constant	k110	152
.constant	k111	6
.constant	k112	119
.constant	k113	181
.constant	k114	"GetFrame"
.constant	k115	"PutOnClothes"
.constant	k116	"downloadFinish"
.constant	k117	true
.constant	k118	"vehicleExtraData"
.constant	k119	"forceDisplay"
.constant	k120	"SetModelRotation"

.line	1395	gettabup      r5    u0    k0 ; k0 = "log"
.line	1395	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1395	test          r6     0
.line	1395	jmp            0   l77
.line	1395	gettabup      r6    u0    k2 ; k2 = "table"
.line	1395	gettable      r6    r6    k3 ; k3 = "concat"
.line	1395	newtable      r7     1     0
.line	1395	getupval      r8    u1
.line	1395	loadk         r9    k4 ; k4 = 193
.line	1395	loadk        r10    k5 ; k5 = 142
.line	1395	loadk        r11    k6 ; k6 = 71
.line	1395	loadk        r12    k7 ; k7 = 33
.line	1395	loadk        r13    k8 ; k8 = 85
.line	1395	loadk        r14    k9 ; k9 = 76
.line	1395	loadk        r15   k10 ; k10 = 208
.line	1395	loadk        r16   k11 ; k11 = 143
.line	1395	loadk        r17   k12 ; k12 = 27
.line	1395	loadk        r18   k13 ; k13 = 124
.line	1395	loadk        r19   k14 ; k14 = 47
.line	1395	loadk        r20   k15 ; k15 = 251
.line	1395	loadk        r21   k16 ; k16 = 172
.line	1395	loadk        r22   k17 ; k17 = 235
.line	1395	loadk        r23   k18 ; k18 = 73
.line	1395	loadk        r24   k19 ; k19 = 186
.line	1395	loadk        r25   k20 ; k20 = 25
.line	1395	loadk        r26   k21 ; k21 = 188
.line	1395	loadk        r27   k22 ; k22 = 51
.line	1395	loadk        r28   k23 ; k23 = 84
.line	1395	loadk        r29   k24 ; k24 = 204
.line	1395	loadk        r30   k25 ; k25 = 93
.line	1395	loadk        r31   k26 ; k26 = 191
.line	1395	loadk        r32   k27 ; k27 = 169
.line	1395	loadk        r33   k28 ; k28 = 15
.line	1395	loadk        r34   k29 ; k29 = 95
.line	1395	loadk        r35   k30 ; k30 = 63
.line	1395	loadk        r36   k31 ; k31 = 210
.line	1395	loadk        r37   k21 ; k21 = 188
.line	1395	loadk        r38   k32 ; k32 = 232
.line	1395	loadk        r39   k33 ; k33 = 74
.line	1395	loadk        r40   k34 ; k34 = 145
.line	1395	loadk        r41   k35 ; k35 = 48
.line	1395	loadk        r42   k36 ; k36 = 185
.line	1395	loadk        r43   k37 ; k37 = 44
.line	1395	loadk        r44   k38 ; k38 = 96
.line	1395	loadk        r45   k39 ; k39 = 147
.line	1395	loadk        r46   k40 ; k40 = 108
.line	1395	loadk        r47   k41 ; k41 = 176
.line	1395	loadk        r48   k42 ; k42 = 153
.line	1395	call          r8    41     2
.line	1395	getupval      r9    u1
.line	1395	loadk        r10   k43 ; k43 = 214
.line	1395	loadk        r11   k44 ; k44 = 154
.line	1395	loadk        r12   k33 ; k33 = 74
.line	1395	loadk        r13   k45 ; k45 = 109
.line	1395	loadk        r14   k46 ; k46 = 105
.line	1395	loadk        r15   k47 ; k47 = 89
.line	1395	loadk        r16   k48 ; k48 = 219
.line	1395	loadk        r17   k49 ; k49 = 221
.line	1395	loadk        r18   k50 ; k50 = 23
.line	1395	loadk        r19   k51 ; k51 = 79
.line	1395	loadk        r20   k14 ; k14 = 47
.line	1395	loadk        r21   k52 ; k52 = 248
.line	1395	loadk        r22   k53 ; k53 = 128
.line	1395	loadk        r23   k49 ; k49 = 221
.line	1395	loadk        r24   k54 ; k54 = 8
.line	1395	loadk        r25   k17 ; k17 = 235
.line	1395	loadk        r26   k46 ; k46 = 105
.line	1395	call          r9    18     0
.line	1395	setlist       r7     0     1
.line	1395	call          r6     2     2
.line	1395	gettabup      r7    u0   k55 ; k55 = "tostring"
.line	1395	move          r8    r3
.line	1395	call          r7     2     2
.line	1395	getupval      r8    u1
.line	1395	call          r8     1     2
.line	1395	concat        r6    r6    r8
.label	l77
.line	1395	call          r5     2     1
.line	1395	gettabup      r5    u0   k56 ; k56 = "log_tree"
.line	1395	gettabup      r6    u0    k2 ; k2 = "table"
.line	1395	gettable      r6    r6    k3 ; k3 = "concat"
.line	1395	newtable      r7     1     0
.line	1395	getupval      r8    u1
.line	1395	loadk         r9    k4 ; k4 = 193
.line	1395	loadk        r10    k5 ; k5 = 142
.line	1395	loadk        r11    k6 ; k6 = 71
.line	1395	loadk        r12    k7 ; k7 = 33
.line	1395	loadk        r13    k8 ; k8 = 85
.line	1395	loadk        r14    k9 ; k9 = 76
.line	1395	loadk        r15   k10 ; k10 = 208
.line	1395	loadk        r16   k11 ; k11 = 143
.line	1395	loadk        r17   k12 ; k12 = 27
.line	1395	loadk        r18   k13 ; k13 = 124
.line	1395	loadk        r19   k14 ; k14 = 47
.line	1395	loadk        r20   k15 ; k15 = 251
.line	1395	loadk        r21   k16 ; k16 = 172
.line	1395	loadk        r22   k17 ; k17 = 235
.line	1395	loadk        r23   k18 ; k18 = 73
.line	1395	loadk        r24   k19 ; k19 = 186
.line	1395	loadk        r25   k20 ; k20 = 25
.line	1395	loadk        r26   k21 ; k21 = 188
.line	1395	loadk        r27   k22 ; k22 = 51
.line	1395	loadk        r28   k23 ; k23 = 84
.line	1395	loadk        r29   k24 ; k24 = 204
.line	1395	loadk        r30   k25 ; k25 = 93
.line	1395	loadk        r31   k26 ; k26 = 191
.line	1395	loadk        r32   k27 ; k27 = 169
.line	1395	loadk        r33   k28 ; k28 = 15
.line	1395	loadk        r34   k29 ; k29 = 95
.line	1395	loadk        r35   k30 ; k30 = 63
.line	1395	loadk        r36   k31 ; k31 = 210
.line	1395	loadk        r37   k21 ; k21 = 188
.line	1395	loadk        r38   k32 ; k32 = 232
.line	1395	loadk        r39   k33 ; k33 = 74
.line	1395	loadk        r40   k34 ; k34 = 145
.line	1395	loadk        r41   k35 ; k35 = 48
.line	1395	loadk        r42   k36 ; k36 = 185
.line	1395	loadk        r43   k37 ; k37 = 44
.line	1395	loadk        r44   k38 ; k38 = 96
.line	1395	loadk        r45   k39 ; k39 = 147
.line	1395	loadk        r46   k40 ; k40 = 108
.line	1395	loadk        r47   k41 ; k41 = 176
.line	1395	loadk        r48   k42 ; k42 = 153
.line	1395	call          r8    41     2
.line	1395	getupval      r9    u1
.line	1395	loadk        r10   k43 ; k43 = 214
.line	1395	loadk        r11   k44 ; k44 = 154
.line	1395	loadk        r12   k33 ; k33 = 74
.line	1395	loadk        r13   k45 ; k45 = 109
.line	1395	loadk        r14   k46 ; k46 = 105
.line	1395	loadk        r15   k47 ; k47 = 89
.line	1395	loadk        r16   k48 ; k48 = 219
.line	1395	loadk        r17   k49 ; k49 = 221
.line	1395	loadk        r18   k12 ; k12 = 27
.line	1395	loadk        r19   k57 ; k57 = 67
.line	1395	loadk        r20   k58 ; k58 = 62
.line	1395	loadk        r21   k59 ; k59 = 231
.line	1395	loadk        r22   k60 ; k60 = 168
.line	1395	loadk        r23   k49 ; k49 = 221
.line	1395	loadk        r24   k18 ; k18 = 73
.line	1395	loadk        r25   k61 ; k61 = 162
.line	1395	loadk        r26   k62 ; k62 = 40
.line	1395	loadk        r27   k63 ; k63 = 253
.line	1395	loadk        r28   k46 ; k46 = 105
.line	1395	loadk        r29   k64 ; k64 = 17
.line	1395	call          r9    21     0
.line	1395	setlist       r7     0     1
.line	1395	call          r6     2     2
.line	1395	move          r7    r4
.line	1395	call          r5     3     1
.line	1395	gettable      r5    r0   k65 ; k65 = "showDataList"
.line	1395	test          r5     0
.line	1395	jmp            0  l158
.line	1395	gettabup      r5    u0   k66 ; k66 = "next"
.line	1395	gettable      r6    r0   k65 ; k65 = "showDataList"
.line	1395	call          r5     2     2
.line	1395	test          r5     1
.line	1395	jmp            0  l242
.label	l158
.line	1395	gettabup      r5    u0    k0 ; k0 = "log"
.line	1395	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1395	test          r6     0
.line	1395	jmp            0  l240
.line	1395	gettabup      r6    u0    k2 ; k2 = "table"
.line	1395	gettable      r6    r6    k3 ; k3 = "concat"
.line	1395	newtable      r7     1     0
.line	1395	getupval      r8    u1
.line	1395	loadk         r9    k4 ; k4 = 193
.line	1395	loadk        r10    k5 ; k5 = 142
.line	1395	loadk        r11    k6 ; k6 = 71
.line	1395	loadk        r12    k7 ; k7 = 33
.line	1395	loadk        r13    k8 ; k8 = 85
.line	1395	loadk        r14    k9 ; k9 = 76
.line	1395	loadk        r15   k10 ; k10 = 208
.line	1395	loadk        r16   k11 ; k11 = 143
.line	1395	loadk        r17   k12 ; k12 = 27
.line	1395	loadk        r18   k13 ; k13 = 124
.line	1395	loadk        r19   k14 ; k14 = 47
.line	1395	loadk        r20   k15 ; k15 = 251
.line	1395	loadk        r21   k16 ; k16 = 172
.line	1395	loadk        r22   k17 ; k17 = 235
.line	1395	loadk        r23   k18 ; k18 = 73
.line	1395	loadk        r24   k19 ; k19 = 186
.line	1395	loadk        r25   k20 ; k20 = 25
.line	1395	loadk        r26   k21 ; k21 = 188
.line	1395	loadk        r27   k22 ; k22 = 51
.line	1395	loadk        r28   k23 ; k23 = 84
.line	1395	loadk        r29   k24 ; k24 = 204
.line	1395	loadk        r30   k25 ; k25 = 93
.line	1395	loadk        r31   k26 ; k26 = 191
.line	1395	loadk        r32   k27 ; k27 = 169
.line	1395	loadk        r33   k28 ; k28 = 15
.line	1395	loadk        r34   k29 ; k29 = 95
.line	1395	loadk        r35   k30 ; k30 = 63
.line	1395	loadk        r36   k31 ; k31 = 210
.line	1395	loadk        r37   k21 ; k21 = 188
.line	1395	loadk        r38   k32 ; k32 = 232
.line	1395	loadk        r39   k33 ; k33 = 74
.line	1395	loadk        r40   k34 ; k34 = 145
.line	1395	loadk        r41   k35 ; k35 = 48
.line	1395	loadk        r42   k36 ; k36 = 185
.line	1395	loadk        r43   k37 ; k37 = 44
.line	1395	loadk        r44   k38 ; k38 = 96
.line	1395	loadk        r45   k39 ; k39 = 147
.line	1395	loadk        r46   k40 ; k40 = 108
.line	1395	loadk        r47   k41 ; k41 = 176
.line	1395	loadk        r48   k42 ; k42 = 153
.line	1395	call          r8    41     2
.line	1395	getupval      r9    u1
.line	1395	loadk        r10   k43 ; k43 = 214
.line	1395	loadk        r11   k44 ; k44 = 154
.line	1395	loadk        r12   k33 ; k33 = 74
.line	1395	loadk        r13   k45 ; k45 = 109
.line	1395	loadk        r14   k46 ; k46 = 105
.line	1395	loadk        r15   k47 ; k47 = 89
.line	1395	loadk        r16   k48 ; k48 = 219
.line	1395	loadk        r17   k49 ; k49 = 221
.line	1395	loadk        r18   k67 ; k67 = 13
.line	1395	loadk        r19   k68 ; k68 = 83
.line	1395	loadk        r20   k69 ; k69 = 37
.line	1395	loadk        r21   k70 ; k70 = 226
.line	1395	loadk        r22   k71 ; k71 = 141
.line	1395	loadk        r23   k52 ; k52 = 248
.line	1395	loadk        r24   k72 ; k72 = 92
.line	1395	loadk        r25   k73 ; k73 = 183
.line	1395	loadk        r26   k74 ; k74 = 5
.line	1395	loadk        r27   k75 ; k75 = 180
.line	1395	loadk        r28   k76 ; k76 = 39
.line	1395	loadk        r29   k77 ; k77 = 69
.line	1395	loadk        r30   k43 ; k43 = 214
.line	1395	loadk        r31   k78 ; k78 = 97
.line	1395	loadk        r32   k21 ; k21 = 188
.line	1395	loadk        r33   k79 ; k79 = 237
.line	1395	loadk        r34   k80 ; k80 = 11
.line	1395	loadk        r35   k47 ; k47 = 89
.line	1395	loadk        r36   k62 ; k62 = 40
.line	1395	loadk        r37   k81 ; k81 = 234
.line	1395	loadk        r38   k82 ; k82 = 171
.line	1395	call          r9    30     0
.line	1395	setlist       r7     0     1
.line	1395	call          r6     2     2
.label	l240
.line	1395	call          r5     2     1
.line	1395	return        r0     1
.label	l242
.line	1395	self          r5    r0   k83 ; k83 = "GetCurItemAndIndex"
.line	1395	call          r5     2     3
.line	1395	test          r6     0
.line	1395	jmp            0  l248
.line	1395	test          r5     1
.line	1395	jmp            0  l331
.label	l248
.line	1395	gettabup      r7    u0    k0 ; k0 = "log"
.line	1395	gettabup      r8    u0    k1 ; k1 = "bWriteLog"
.line	1395	test          r8     0
.line	1395	jmp            0  l329
.line	1395	gettabup      r8    u0    k2 ; k2 = "table"
.line	1395	gettable      r8    r8    k3 ; k3 = "concat"
.line	1395	newtable      r9     1     0
.line	1395	getupval     r10    u1
.line	1395	loadk        r11    k4 ; k4 = 193
.line	1395	loadk        r12    k5 ; k5 = 142
.line	1395	loadk        r13    k6 ; k6 = 71
.line	1395	loadk        r14    k7 ; k7 = 33
.line	1395	loadk        r15    k8 ; k8 = 85
.line	1395	loadk        r16    k9 ; k9 = 76
.line	1395	loadk        r17   k10 ; k10 = 208
.line	1395	loadk        r18   k11 ; k11 = 143
.line	1395	loadk        r19   k12 ; k12 = 27
.line	1395	loadk        r20   k13 ; k13 = 124
.line	1395	loadk        r21   k14 ; k14 = 47
.line	1395	loadk        r22   k15 ; k15 = 251
.line	1395	loadk        r23   k16 ; k16 = 172
.line	1395	loadk        r24   k17 ; k17 = 235
.line	1395	loadk        r25   k18 ; k18 = 73
.line	1395	loadk        r26   k19 ; k19 = 186
.line	1395	loadk        r27   k20 ; k20 = 25
.line	1395	loadk        r28   k21 ; k21 = 188
.line	1395	loadk        r29   k22 ; k22 = 51
.line	1395	loadk        r30   k23 ; k23 = 84
.line	1395	loadk        r31   k24 ; k24 = 204
.line	1395	loadk        r32   k25 ; k25 = 93
.line	1395	loadk        r33   k26 ; k26 = 191
.line	1395	loadk        r34   k27 ; k27 = 169
.line	1395	loadk        r35   k28 ; k28 = 15
.line	1395	loadk        r36   k29 ; k29 = 95
.line	1395	loadk        r37   k30 ; k30 = 63
.line	1395	loadk        r38   k31 ; k31 = 210
.line	1395	loadk        r39   k21 ; k21 = 188
.line	1395	loadk        r40   k32 ; k32 = 232
.line	1395	loadk        r41   k33 ; k33 = 74
.line	1395	loadk        r42   k34 ; k34 = 145
.line	1395	loadk        r43   k35 ; k35 = 48
.line	1395	loadk        r44   k36 ; k36 = 185
.line	1395	loadk        r45   k37 ; k37 = 44
.line	1395	loadk        r46   k38 ; k38 = 96
.line	1395	loadk        r47   k39 ; k39 = 147
.line	1395	loadk        r48   k40 ; k40 = 108
.line	1395	loadk        r49   k41 ; k41 = 176
.line	1395	loadk        r50   k42 ; k42 = 153
.line	1395	call         r10    41     2
.line	1395	getupval     r11    u1
.line	1395	loadk        r12   k43 ; k43 = 214
.line	1395	loadk        r13   k44 ; k44 = 154
.line	1395	loadk        r14   k33 ; k33 = 74
.line	1395	loadk        r15   k45 ; k45 = 109
.line	1395	loadk        r16   k46 ; k46 = 105
.line	1395	loadk        r17   k47 ; k47 = 89
.line	1395	loadk        r18   k48 ; k48 = 219
.line	1395	loadk        r19   k49 ; k49 = 221
.line	1395	loadk        r20   k67 ; k67 = 13
.line	1395	loadk        r21   k84 ; k84 = 94
.line	1395	loadk        r22   k85 ; k85 = 38
.line	1395	loadk        r23   k86 ; k86 = 240
.line	1395	loadk        r24   k87 ; k87 = 170
.line	1395	loadk        r25   k79 ; k79 = 237
.line	1395	loadk        r26   k78 ; k78 = 97
.line	1395	loadk        r27   k88 ; k88 = 184
.line	1395	loadk        r28   k89 ; k89 = 45
.line	1395	loadk        r29   k88 ; k88 = 184
.line	1395	loadk        r30   k37 ; k37 = 44
.line	1395	loadk        r31   k64 ; k64 = 17
.line	1395	loadk        r32   k90 ; k90 = 159
.line	1395	loadk        r33   k91 ; k91 = 123
.line	1395	loadk        r34   k92 ; k92 = 239
.line	1395	loadk        r35   k60 ; k60 = 168
.line	1395	loadk        r36   k93 ; k93 = 28
.line	1395	loadk        r37   k47 ; k47 = 89
.line	1395	loadk        r38   k94 ; k94 = 53
.line	1395	loadk        r39   k95 ; k95 = 247
.line	1395	call         r11    29     0
.line	1395	setlist       r9     0     1
.line	1395	call          r8     2     2
.label	l329
.line	1395	call          r7     2     1
.line	1395	return        r0     1
.label	l331
.line	1395	testset       r7    r4     0
.line	1395	jmp            0  l334
.line	1395	gettable      r7    r4   k96 ; k96 = "bDownloadAutoPutOn"
.label	l334
.line	1395	test          r7     0
.line	1395	jmp            0  l453
.line	1395	gettable      r8    r5   k97 ; k97 = "itemId"
.line	1395	eq             0    r8    r3
.line	1395	jmp            0  l453
.line	1395	gettabup      r8    u0    k0 ; k0 = "log"
.line	1395	gettabup      r9    u0    k1 ; k1 = "bWriteLog"
.line	1395	test          r9     0
.line	1395	jmp            0  l440
.line	1395	gettabup      r9    u0    k2 ; k2 = "table"
.line	1395	gettable      r9    r9    k3 ; k3 = "concat"
.line	1395	newtable     r10     1     0
.line	1395	getupval     r11    u1
.line	1395	loadk        r12    k4 ; k4 = 193
.line	1395	loadk        r13    k5 ; k5 = 142
.line	1395	loadk        r14    k6 ; k6 = 71
.line	1395	loadk        r15    k7 ; k7 = 33
.line	1395	loadk        r16    k8 ; k8 = 85
.line	1395	loadk        r17    k9 ; k9 = 76
.line	1395	loadk        r18   k10 ; k10 = 208
.line	1395	loadk        r19   k11 ; k11 = 143
.line	1395	loadk        r20   k12 ; k12 = 27
.line	1395	loadk        r21   k13 ; k13 = 124
.line	1395	loadk        r22   k14 ; k14 = 47
.line	1395	loadk        r23   k15 ; k15 = 251
.line	1395	loadk        r24   k16 ; k16 = 172
.line	1395	loadk        r25   k17 ; k17 = 235
.line	1395	loadk        r26   k18 ; k18 = 73
.line	1395	loadk        r27   k19 ; k19 = 186
.line	1395	loadk        r28   k20 ; k20 = 25
.line	1395	loadk        r29   k21 ; k21 = 188
.line	1395	loadk        r30   k22 ; k22 = 51
.line	1395	loadk        r31   k23 ; k23 = 84
.line	1395	loadk        r32   k24 ; k24 = 204
.line	1395	loadk        r33   k25 ; k25 = 93
.line	1395	loadk        r34   k26 ; k26 = 191
.line	1395	loadk        r35   k27 ; k27 = 169
.line	1395	loadk        r36   k28 ; k28 = 15
.line	1395	loadk        r37   k29 ; k29 = 95
.line	1395	loadk        r38   k30 ; k30 = 63
.line	1395	loadk        r39   k31 ; k31 = 210
.line	1395	loadk        r40   k21 ; k21 = 188
.line	1395	loadk        r41   k32 ; k32 = 232
.line	1395	loadk        r42   k33 ; k33 = 74
.line	1395	loadk        r43   k34 ; k34 = 145
.line	1395	loadk        r44   k35 ; k35 = 48
.line	1395	loadk        r45   k36 ; k36 = 185
.line	1395	loadk        r46   k37 ; k37 = 44
.line	1395	loadk        r47   k38 ; k38 = 96
.line	1395	loadk        r48   k39 ; k39 = 147
.line	1395	loadk        r49   k40 ; k40 = 108
.line	1395	loadk        r50   k41 ; k41 = 176
.line	1395	loadk        r51   k42 ; k42 = 153
.line	1395	call         r11    41     2
.line	1395	getupval     r12    u1
.line	1395	loadk        r13   k43 ; k43 = 214
.line	1395	loadk        r14   k44 ; k44 = 154
.line	1395	loadk        r15   k33 ; k33 = 74
.line	1395	loadk        r16   k45 ; k45 = 109
.line	1395	loadk        r17   k46 ; k46 = 105
.line	1395	loadk        r18   k47 ; k47 = 89
.line	1395	loadk        r19   k48 ; k48 = 219
.line	1395	loadk        r20   k49 ; k49 = 221
.line	1395	loadk        r21   k98 ; k98 = 58
.line	1395	loadk        r22   k99 ; k99 = 82
.line	1395	loadk        r23  k100 ; k100 = 57
.line	1395	loadk        r24  k101 ; k101 = 229
.line	1395	loadk        r25  k102 ; k102 = 165
.line	1395	loadk        r26   k52 ; k52 = 248
.line	1395	loadk        r27  k103 ; k103 = 81
.line	1395	loadk        r28  k104 ; k104 = 246
.line	1395	loadk        r29  k105 ; k105 = 32
.line	1395	loadk        r30   k27 ; k27 = 169
.line	1395	loadk        r31  k106 ; k106 = 49
.line	1395	loadk        r32   k72 ; k72 = 92
.line	1395	loadk        r33   k26 ; k26 = 191
.line	1395	loadk        r34    k9 ; k9 = 76
.line	1395	loadk        r35   k92 ; k92 = 239
.line	1395	loadk        r36   k86 ; k86 = 240
.line	1395	loadk        r37  k107 ; k107 = 78
.line	1395	call         r12    26     0
.line	1395	setlist      r10     0     1
.line	1395	call          r9     2     2
.line	1395	gettabup     r10    u0   k55 ; k55 = "tostring"
.line	1395	move         r11    r3
.line	1395	call         r10     2     2
.line	1395	getupval     r11    u1
.line	1395	loadk        r12   k42 ; k42 = 153
.line	1395	loadk        r13    k5 ; k5 = 142
.line	1395	loadk        r14  k103 ; k103 = 81
.line	1395	loadk        r15  k108 ; k108 = 115
.line	1395	loadk        r16   k51 ; k51 = 79
.line	1395	loadk        r17  k109 ; k109 = 86
.line	1395	loadk        r18   k48 ; k48 = 219
.line	1395	loadk        r19  k110 ; k110 = 152
.line	1395	loadk        r20  k111 ; k111 = 6
.line	1395	loadk        r21   k12 ; k12 = 27
.line	1395	loadk        r22  k112 ; k112 = 119
.line	1395	loadk        r23  k113 ; k113 = 181
.line	1395	call         r11    13     2
.line	1395	gettabup     r12    u0   k55 ; k55 = "tostring"
.line	1395	move         r13    r6
.line	1395	call         r12     2     2
.line	1395	getupval     r13    u1
.line	1395	call         r13     1     2
.line	1395	concat        r9    r9   r13
.label	l440
.line	1395	call          r8     2     1
.line	1395	self          r8    r0  k114 ; k114 = "GetFrame"
.line	1395	call          r8     2     2
.line	1395	self          r9    r8  k115 ; k115 = "PutOnClothes"
.line	1395	move         r11    r3
.line	1395	newtable     r12     0     2
.line	1395	settable     r12  k116  k117 ; k117 = true
.line	1395	newtable     r13     0     1
.line	1395	settable     r13  k119  k117 ; k117 = true
.line	1395	settable     r12  k118   r13 ; k118 = "vehicleExtraData"
.line	1395	call          r9     4     1
.line	1395	self          r9    r0  k120 ; k120 = "SetModelRotation"
.line	1395	call          r9     2     1
.label	l453
.line	1395	return        r0     1
.line	1395	move          r0    r0
.line	1395	return        r0     1

.function	main/f61

.source	null
.linedefined	1419
.lastlinedefined	1430
.numparams	1
.is_vararg	0
.maxstacksize	48

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	218
.constant	k2	129
.constant	k3	77
.constant	k4	100
.constant	k5	104
.constant	k6	76
.constant	k7	145
.constant	k8	17
.constant	k9	92
.constant	k10	35
.constant	k11	246
.constant	k12	231
.constant	k13	248
.constant	k14	94
.constant	k15	183
.constant	k16	61
.constant	k17	188
.constant	k18	38
.constant	k19	31
.constant	k20	187
.constant	k21	103
.constant	k22	171
.constant	k23	168
.constant	k24	2
.constant	k25	111
.constant	k26	51
.constant	k27	169
.constant	k28	229
.constant	k29	89
.constant	k30	191
.constant	k31	60
.constant	k32	"GetShowingStatus"
.constant	k33	"Enum_Status"
.constant	k34	"Model"
.constant	k35	"table"
.constant	k36	"concat"
.constant	k37	142
.constant	k38	18
.constant	k39	78
.constant	k40	43
.constant	k41	165
.constant	k42	79
.constant	k43	42
.constant	k44	243
.constant	k45	57
.constant	k46	80
.constant	k47	152
.constant	k48	105
.constant	k49	28
.constant	k50	5
.constant	k51	13
.constant	k52	224
.constant	k53	184
.constant	k54	249
.constant	k55	87
.constant	k56	20
.constant	k57	162
.constant	k58	32
.constant	k59	68
.constant	k60	138
.constant	k61	84
.constant	k62	176
.constant	k63	186
.constant	k64	208
.constant	k65	"GetProperWeaponShowActor"
.constant	k66	"slua"
.constant	k67	"isValid"
.constant	k68	189
.constant	k69	235
.constant	k70	73
.constant	k71	174
.constant	k72	122
.constant	k73	117
.constant	k74	147
.constant	k75	124
.constant	k76	164
.constant	k77	53
.constant	k78	232
.constant	k79	230
.constant	k80	86
.constant	k81	163
.constant	k82	55
.constant	k83	185
.constant	k84	106
.constant	k85	119
.constant	k86	143
.constant	k87	125
.constant	k88	158
.constant	k89	214
.constant	k90	128
.constant	k91	110
.constant	k92	93
.constant	k93	209
.constant	k94	137
.constant	k95	120
.constant	k96	37
.constant	k97	251
.constant	k98	237
.constant	k99	126
.constant	k100	44
.constant	k101	170
.constant	k102	"SetAutoRotate"
.constant	k103	"SetAutoRotateSpeed"
.constant	k104	"C_WEAPON_AUTO_ROTATE_SPEED"

.line	1419	gettabup      r1    u0    k0 ; k0 = "require"
.line	1419	getupval      r2    u1
.line	1419	loadk         r3    k1 ; k1 = 218
.line	1419	loadk         r4    k2 ; k2 = 129
.line	1419	loadk         r5    k3 ; k3 = 77
.line	1419	loadk         r6    k4 ; k4 = 100
.line	1419	loadk         r7    k5 ; k5 = 104
.line	1419	loadk         r8    k6 ; k6 = 76
.line	1419	loadk         r9    k7 ; k7 = 145
.line	1419	loadk        r10    k7 ; k7 = 145
.line	1419	loadk        r11    k8 ; k8 = 17
.line	1419	loadk        r12    k9 ; k9 = 92
.line	1419	loadk        r13   k10 ; k10 = 35
.line	1419	loadk        r14   k11 ; k11 = 246
.line	1419	loadk        r15   k12 ; k12 = 231
.line	1419	loadk        r16   k13 ; k13 = 248
.line	1419	loadk        r17   k14 ; k14 = 94
.line	1419	loadk        r18   k15 ; k15 = 183
.line	1419	loadk        r19   k16 ; k16 = 61
.line	1419	loadk        r20   k17 ; k17 = 188
.line	1419	loadk        r21   k18 ; k18 = 38
.line	1419	loadk        r22   k19 ; k19 = 31
.line	1419	loadk        r23   k20 ; k20 = 187
.line	1419	loadk        r24   k21 ; k21 = 103
.line	1419	loadk        r25   k22 ; k22 = 171
.line	1419	loadk        r26   k23 ; k23 = 168
.line	1419	loadk        r27   k24 ; k24 = 2
.line	1419	loadk        r28   k25 ; k25 = 111
.line	1419	loadk        r29   k26 ; k26 = 51
.line	1419	loadk        r30   k11 ; k11 = 246
.line	1419	loadk        r31   k27 ; k27 = 169
.line	1419	loadk        r32   k28 ; k28 = 229
.line	1419	loadk        r33   k29 ; k29 = 89
.line	1419	loadk        r34   k30 ; k30 = 191
.line	1419	loadk        r35   k31 ; k31 = 60
.line	1419	loadk        r36   k30 ; k30 = 191
.line	1419	call          r2    35     2
.line	1419	call          r1     2     2
.line	1419	gettable      r2    r1   k32 ; k32 = "GetShowingStatus"
.line	1419	call          r2     1     2
.line	1419	gettable      r3    r1   k33 ; k33 = "Enum_Status"
.line	1419	gettable      r3    r3   k34 ; k34 = "Model"
.line	1419	eq             0    r2    r3
.line	1419	jmp            0  l181
.line	1419	gettabup      r2    u0    k0 ; k0 = "require"
.line	1419	gettabup      r3    u0   k35 ; k35 = "table"
.line	1419	gettable      r3    r3   k36 ; k36 = "concat"
.line	1419	newtable      r4     1     0
.line	1419	getupval      r5    u1
.line	1419	loadk         r6    k1 ; k1 = 218
.line	1419	loadk         r7    k2 ; k2 = 129
.line	1419	loadk         r8    k3 ; k3 = 77
.line	1419	loadk         r9    k4 ; k4 = 100
.line	1419	loadk        r10    k5 ; k5 = 104
.line	1419	loadk        r11    k6 ; k6 = 76
.line	1419	loadk        r12    k7 ; k7 = 145
.line	1419	loadk        r13   k37 ; k37 = 142
.line	1419	loadk        r14   k38 ; k38 = 18
.line	1419	loadk        r15   k39 ; k39 = 78
.line	1419	loadk        r16   k40 ; k40 = 43
.line	1419	loadk        r17   k20 ; k20 = 187
.line	1419	loadk        r18   k41 ; k41 = 165
.line	1419	loadk        r19   k11 ; k11 = 246
.line	1419	loadk        r20   k42 ; k42 = 79
.line	1419	loadk        r21   k30 ; k30 = 191
.line	1419	loadk        r22   k43 ; k43 = 42
.line	1419	loadk        r23   k44 ; k44 = 243
.line	1419	loadk        r24   k45 ; k45 = 57
.line	1419	loadk        r25   k46 ; k46 = 80
.line	1419	loadk        r26   k47 ; k47 = 152
.line	1419	loadk        r27   k48 ; k48 = 105
.line	1419	loadk        r28   k23 ; k23 = 168
.line	1419	loadk        r29   k23 ; k23 = 168
.line	1419	loadk        r30   k49 ; k49 = 28
.line	1419	loadk        r31   k50 ; k50 = 5
.line	1419	loadk        r32   k51 ; k51 = 13
.line	1419	loadk        r33   k52 ; k52 = 224
.line	1419	loadk        r34   k53 ; k53 = 184
.line	1419	loadk        r35   k54 ; k54 = 249
.line	1419	loadk        r36   k55 ; k55 = 87
.line	1419	loadk        r37   k23 ; k23 = 168
.line	1419	loadk        r38   k56 ; k56 = 20
.line	1419	loadk        r39   k57 ; k57 = 162
.line	1419	loadk        r40   k58 ; k58 = 32
.line	1419	loadk        r41   k59 ; k59 = 68
.line	1419	loadk        r42   k60 ; k60 = 138
.line	1419	loadk        r43   k61 ; k61 = 84
.line	1419	loadk        r44   k62 ; k62 = 176
.line	1419	loadk        r45   k63 ; k63 = 186
.line	1419	call          r5    41     2
.line	1419	getupval      r6    u1
.line	1419	loadk         r7   k64 ; k64 = 208
.line	1419	loadk         r8   k37 ; k37 = 142
.line	1419	call          r6     3     0
.line	1419	setlist       r4     0     1
.line	1419	call          r3     2     2
.line	1419	call          r2     2     2
.line	1419	gettable      r3    r2   k65 ; k65 = "GetProperWeaponShowA" (truncated)
.line	1419	call          r3     1     2
.line	1419	gettabup      r4    u0   k66 ; k66 = "slua"
.line	1419	gettable      r4    r4   k67 ; k67 = "isValid"
.line	1419	move          r5    r3
.line	1419	call          r4     2     2
.line	1419	test          r4     0
.line	1419	jmp            0  l181
.line	1419	gettabup      r4    u0    k0 ; k0 = "require"
.line	1419	gettabup      r5    u0   k35 ; k35 = "table"
.line	1419	gettable      r5    r5   k36 ; k36 = "concat"
.line	1419	newtable      r6     1     0
.line	1419	getupval      r7    u1
.line	1419	loadk         r8    k1 ; k1 = 218
.line	1419	loadk         r9    k2 ; k2 = 129
.line	1419	loadk        r10    k3 ; k3 = 77
.line	1419	loadk        r11    k4 ; k4 = 100
.line	1419	loadk        r12    k5 ; k5 = 104
.line	1419	loadk        r13    k6 ; k6 = 76
.line	1419	loadk        r14    k7 ; k7 = 145
.line	1419	loadk        r15   k37 ; k37 = 142
.line	1419	loadk        r16   k38 ; k38 = 18
.line	1419	loadk        r17   k39 ; k39 = 78
.line	1419	loadk        r18   k40 ; k40 = 43
.line	1419	loadk        r19   k20 ; k20 = 187
.line	1419	loadk        r20   k68 ; k68 = 189
.line	1419	loadk        r21   k69 ; k69 = 235
.line	1419	loadk        r22   k70 ; k70 = 73
.line	1419	loadk        r23   k30 ; k30 = 191
.line	1419	loadk        r24   k16 ; k16 = 61
.line	1419	loadk        r25   k71 ; k71 = 174
.line	1419	loadk        r26   k72 ; k72 = 122
.line	1419	loadk        r27   k73 ; k73 = 117
.line	1419	loadk        r28   k74 ; k74 = 147
.line	1419	loadk        r29   k75 ; k75 = 124
.line	1419	loadk        r30   k71 ; k71 = 174
.line	1419	loadk        r31   k76 ; k76 = 164
.line	1419	loadk        r32   k24 ; k24 = 2
.line	1419	loadk        r33    k5 ; k5 = 104
.line	1419	loadk        r34   k77 ; k77 = 53
.line	1419	loadk        r35   k78 ; k78 = 232
.line	1419	loadk        r36   k27 ; k27 = 169
.line	1419	loadk        r37   k79 ; k79 = 230
.line	1419	loadk        r38   k80 ; k80 = 86
.line	1419	loadk        r39   k81 ; k81 = 163
.line	1419	loadk        r40   k82 ; k82 = 55
.line	1419	loadk        r41   k83 ; k83 = 185
.line	1419	loadk        r42   k84 ; k84 = 106
.line	1419	loadk        r43   k85 ; k85 = 119
.line	1419	loadk        r44   k86 ; k86 = 143
.line	1419	loadk        r45   k87 ; k87 = 125
.line	1419	loadk        r46   k23 ; k23 = 168
.line	1419	loadk        r47   k88 ; k88 = 158
.line	1419	call          r7    41     2
.line	1419	getupval      r8    u1
.line	1419	loadk         r9   k89 ; k89 = 214
.line	1419	loadk        r10   k90 ; k90 = 128
.line	1419	loadk        r11   k61 ; k61 = 84
.line	1419	loadk        r12   k91 ; k91 = 110
.line	1419	loadk        r13    k5 ; k5 = 104
.line	1419	loadk        r14   k92 ; k92 = 93
.line	1419	loadk        r15   k93 ; k93 = 209
.line	1419	loadk        r16   k94 ; k94 = 137
.line	1419	loadk        r17   k46 ; k46 = 80
.line	1419	loadk        r18   k95 ; k95 = 120
.line	1419	loadk        r19   k96 ; k96 = 37
.line	1419	loadk        r20   k97 ; k97 = 251
.line	1419	loadk        r21   k63 ; k63 = 186
.line	1419	loadk        r22   k98 ; k98 = 237
.line	1419	loadk        r23   k99 ; k99 = 126
.line	1419	loadk        r24   k30 ; k30 = 191
.line	1419	loadk        r25  k100 ; k100 = 44
.line	1419	loadk        r26  k101 ; k101 = 170
.line	1419	call          r8    19     0
.line	1419	setlist       r6     0     1
.line	1419	call          r5     2     2
.line	1419	call          r4     2     2
.line	1419	self          r5    r3  k102 ; k102 = "SetAutoRotate"
.line	1419	loadbool      r7     1     0
.line	1419	call          r5     3     1
.line	1419	self          r5    r3  k103 ; k103 = "SetAutoRotateSpeed"
.line	1419	gettable      r7    r4  k104 ; k104 = "C_WEAPON_AUTO_ROTATE" (truncated)
.line	1419	call          r5     3     1
.label	l181
.line	1419	return        r0     1
.line	1419	move          r0    r0
.line	1419	gettabup      r3    u1   k89 ; k89 = 214
.line	1419	move          r0    r0
.line	1419	return        r0     1

.function	main/f62

.source	null
.linedefined	1432
.lastlinedefined	1451
.numparams	3
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	8	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"StoreDetailManager"
.constant	k4	"GetProductListData"
.constant	k5	"next"
.constant	k6	"pairs"
.constant	k7	"selected"
.constant	k8	true
.constant	k9	"equiped"
.constant	k10	"IsEquippedByItemId"
.constant	k11	"DropItemID"
.constant	k12	false

.line	1432	gettabup      r3    u0    k0 ; k0 = "ModuleManager"
.line	1432	gettable      r3    r3    k1 ; k1 = "GetModule"
.line	1432	gettabup      r4    u0    k0 ; k0 = "ModuleManager"
.line	1432	gettable      r4    r4    k2 ; k2 = "LobbyModuleConfig"
.line	1432	gettable      r4    r4    k3 ; k3 = "StoreDetailManager"
.line	1432	call          r3     2     2
.line	1432	self          r4    r3    k4 ; k4 = "GetProductListData"
.line	1432	call          r4     2     2
.line	1432	test          r4     0
.line	1432	jmp            0   l16
.line	1432	gettabup      r5    u0    k5 ; k5 = "next"
.line	1432	move          r6    r4
.line	1432	call          r5     2     2
.line	1432	test          r5     1
.line	1432	jmp            0   l17
.label	l16
.line	1432	return        r0     1
.label	l17
.line	1432	gettabup      r5    u0    k6 ; k6 = "pairs"
.line	1432	move          r6    r4
.line	1432	call          r5     2     4
.line	1432	jmp            0   l42
.line	1432	eq             0    r8    r1
.line	1432	jmp            0   l29
.line	1432	settable      r9    k7    k8 ; k8 = true
.line	1432	gettabup     r10    u1   k10 ; k10 = "IsEquippedByItemId"
.line	1432	gettable     r11    r9   k11 ; k11 = "DropItemID"
.line	1432	call         r10     2     2
.line	1432	settable      r9    k9   r10 ; k9 = "equiped"
.line	1432	jmp            0   l42
.label	l29
.line	1432	settable      r9    k7   k12 ; k12 = false
.line	1432	gettable     r10    r9   k11 ; k11 = "DropItemID"
.line	1432	eq             0   r10    r2
.line	1432	jmp            0   l35
.line	1432	settable      r9    k9   k12 ; k12 = false
.line	1432	jmp            0   l42
.label	l35
.line	1432	gettabup     r10    u1   k10 ; k10 = "IsEquippedByItemId"
.line	1432	gettable     r11    r9   k11 ; k11 = "DropItemID"
.line	1432	call         r10     2     2
.line	1432	test         r10     0
.line	1432	jmp            0   l41
.line	1432	gettable     r10    r9    k9 ; k9 = "equiped"
.label	l41
.line	1432	settable      r9    k9   r10 ; k9 = "equiped"
.label	l42
.line	1432	move          r0    r0
.line	1432	move          r0    r0
.line	1432	return        r0     1
.line	1432	move          r0    r0
.line	1432	move          r0    r0
.line	1432	return        r0     1

.function	main/f63

.source	null
.linedefined	1453
.lastlinedefined	1460
.numparams	5
.is_vararg	0
.maxstacksize	43

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	234
.constant	k3	153
.constant	k4	75
.constant	k5	115
.constant	k6	99
.constant	k7	125
.constant	k8	206
.constant	k9	136
.constant	k10	23
.constant	k11	39
.constant	k12	240
.constant	k13	167
.constant	k14	237
.constant	k15	120
.constant	k16	183
.constant	k17	46
.constant	k18	184
.constant	k19	110
.constant	k20	126
.constant	k21	152
.constant	k22	163
.constant	k23	164
.constant	k24	13
.constant	k25	64
.constant	k26	28
.constant	k27	181
.constant	k28	229
.constant	k29	107
.constant	k30	165
.constant	k31	43
.constant	k32	168
.constant	k33	33
.constant	k34	79
.constant	k35	"GetFrame"
.constant	k36	"currentItem"
.constant	k37	"itemId"
.constant	k38	0
.constant	k39	"EnterFullScreen"

.line	1453	gettabup      r5    u0    k0 ; k0 = "log"
.line	1453	gettabup      r6    u0    k1 ; k1 = "bWriteLog"
.line	1453	test          r6     0
.line	1453	jmp            0   l43
.line	1453	getupval      r6    u1
.line	1453	loadk         r7    k2 ; k2 = 234
.line	1453	loadk         r8    k3 ; k3 = 153
.line	1453	loadk         r9    k4 ; k4 = 75
.line	1453	loadk        r10    k5 ; k5 = 115
.line	1453	loadk        r11    k6 ; k6 = 99
.line	1453	loadk        r12    k7 ; k7 = 125
.line	1453	loadk        r13    k8 ; k8 = 206
.line	1453	loadk        r14    k9 ; k9 = 136
.line	1453	loadk        r15   k10 ; k10 = 23
.line	1453	loadk        r16    k4 ; k4 = 75
.line	1453	loadk        r17   k11 ; k11 = 39
.line	1453	loadk        r18   k12 ; k12 = 240
.line	1453	loadk        r19   k13 ; k13 = 167
.line	1453	loadk        r20   k14 ; k14 = 237
.line	1453	loadk        r21   k15 ; k15 = 120
.line	1453	loadk        r22   k16 ; k16 = 183
.line	1453	loadk        r23   k17 ; k17 = 46
.line	1453	loadk        r24   k18 ; k18 = 184
.line	1453	loadk        r25   k19 ; k19 = 110
.line	1453	loadk        r26   k20 ; k20 = 126
.line	1453	loadk        r27   k21 ; k21 = 152
.line	1453	loadk        r28    k4 ; k4 = 75
.line	1453	loadk        r29   k22 ; k22 = 163
.line	1453	loadk        r30   k23 ; k23 = 164
.line	1453	loadk        r31   k24 ; k24 = 13
.line	1453	loadk        r32   k25 ; k25 = 64
.line	1453	loadk        r33   k26 ; k26 = 28
.line	1453	loadk        r34   k12 ; k12 = 240
.line	1453	loadk        r35   k27 ; k27 = 181
.line	1453	loadk        r36   k28 ; k28 = 229
.line	1453	loadk        r37   k29 ; k29 = 107
.line	1453	loadk        r38   k30 ; k30 = 165
.line	1453	loadk        r39   k31 ; k31 = 43
.line	1453	loadk        r40   k32 ; k32 = 168
.line	1453	loadk        r41   k33 ; k33 = 33
.line	1453	loadk        r42   k34 ; k34 = 79
.line	1453	call          r6    37     2
.label	l43
.line	1453	call          r5     2     1
.line	1453	self          r5    r0   k35 ; k35 = "GetFrame"
.line	1453	call          r5     2     2
.line	1453	gettable      r6    r0   k36 ; k36 = "currentItem"
.line	1453	test          r6     0
.line	1453	jmp            0   l53
.line	1453	gettable      r6    r0   k36 ; k36 = "currentItem"
.line	1453	gettable      r6    r6   k37 ; k37 = "itemId"
.line	1453	test          r6     1
.line	1453	jmp            0   l54
.label	l53
.line	1453	loadk         r6   k38 ; k38 = 0
.label	l54
.line	1453	test          r5     0
.line	1453	jmp            0   l61
.line	1453	self          r7    r5   k39 ; k39 = "EnterFullScreen"
.line	1453	move          r9    r3
.line	1453	move         r10    r6
.line	1453	move         r11    r4
.line	1453	call          r7     5     1
.label	l61
.line	1453	return        r0     1
.line	1453	move          r0    r0
.line	1453	return        r0     1

.function	main/f64

.source	null
.linedefined	1462
.lastlinedefined	1467
.numparams	2
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	9	true

.constant	k0	true

.line	1462	newtable      r2     0     1
.line	1462	getupval      r3    u0
.line	1462	settable      r2    r3    k0 ; k0 = true
.line	1462	gettable      r3    r2    r1
.line	1462	return        r3     2
.line	1462	return        r0     1
.line	1462	move          r0    r0
.line	1462	move          r0    r0
.line	1462	move          r0    r0
.line	1462	move          r0    r0
.line	1462	return        r0     1

.function	main/f65

.source	"=[V12L:9a536956443dae65:d765157d9c8a29da]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f66

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f67

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f68

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f69

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

