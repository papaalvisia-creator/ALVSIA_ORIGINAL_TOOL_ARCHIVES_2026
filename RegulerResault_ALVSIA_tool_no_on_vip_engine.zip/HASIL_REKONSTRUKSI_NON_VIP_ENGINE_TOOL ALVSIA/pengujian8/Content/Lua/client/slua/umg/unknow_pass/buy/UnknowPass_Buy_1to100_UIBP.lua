do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(163, 98, 140, 254, 37)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 92, 107, 196, 46, 162, 66, 95, 240, 216, 209, 245, 120, 221, 125, 168, 203, 96, 107))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      _ARG_0_.openType = _ARG_2_
      _ARG_0_.callBack = _ARG_4_
      if _ARG_2_ then
        if _ARG_2_ == 1 then
          _ARG_0_.isGift = true
        elseif _ARG_2_ == 2 then
          _ARG_0_.isFromIntroduce = true
        end
      end
      _ARG_0_.voucherValue = 0
      _ARG_0_.fromForTlog = _ARG_3_
      UnknowPassSystem.RpBuyCallBack = _ARG_4_
      U1.bRpJump = _ARG_5_
      _ARG_0_.bIsShowCommonPopupSmall = _ARG_6_
      _ARG_0_.uRemainTimer = nil
      _ARG_0_.bUseFirstBuyPrivilege = false
      if require((table.concat({
        U2(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U2(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).IsShowFirstBuyPrivilege() then
        _ARG_0_.bUseFirstBuyPrivilege = not _ARG_0_.isGift
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[12]
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CloseUI, _ARG_0_.OnClickClose, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Normal, _ARG_0_.OnClickNormalBuy, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Plus, _ARG_0_.OnClickSuperBuy, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Plus_Supper, _ARG_0_.OnClickSuperBuy, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Normal_Card, _ARG_0_.OnClickBuyWithCard, _ARG_0_, 1)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Plus_SuperCard, _ARG_0_.OnClickBuyWithCard, _ARG_0_, 2)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Plus_Card, _ARG_0_.OnClickBuyWithCard, _ARG_0_, 3)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Buy_Normal_UCCard, _ARG_0_.OnClickBuyWithCard, _ARG_0_, 1, true)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_AskForNormal, _ARG_0_.OnClickAskFor, _ARG_0_, false)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_AskForPlus, _ARG_0_.OnClickAskFor, _ARG_0_, true)
      if _ARG_0_.UIRoot.Button_Cirt then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Cirt, _ARG_0_.OnClickAnnual, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_Unlcok then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Unlcok, _ARG_0_.OnClickUnlockPrivilege, _ARG_0_)
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_UnlockPlus, _ARG_0_.OnClickUnlockPrivilegePlus, _ARG_0_)
      end
      _ARG_0_:AddOnCheckStateChangedEventByControl(_ARG_0_.UIRoot[_ENV(131, 102, 136, 238, 61, 232, 21, 254, 28, 150, 204, 50, 51, 152, 65)], _ARG_0_.OnCheckBox50Changed, _ARG_0_)
      if _ARG_0_.UIRoot.Button_PlusTicket and _ARG_0_.UIRoot.Button_PassTicket then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PlusTicket, _ARG_0_.OnClickSuperBuy, _ARG_0_)
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_PassTicket, _ARG_0_.OnClickNormalBuy, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_Normal and _ARG_0_.UIRoot.Button_First_Buy_Good then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Normal, _ARG_0_.OnClickNotFirstBuy, _ARG_0_)
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_First_Buy_Good, _ARG_0_.OnClickFirstBuy, _ARG_0_)
      end
      if _ARG_0_.UIRoot.UnknowPass_Buy_Repurchase_UIBP then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.UnknowPass_Buy_Repurchase_UIBP.Button_Repurchase, _ARG_0_.OnClickRepurchase, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_Return_Explain_Tips then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Return_Explain_Tips, _ARG_0_.OnButtonReturnExplain, _ARG_0_)
      end
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GiftNormal, _ARG_0_.OnClickGiftNormal, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GiftElite, _ARG_0_.OnClickGiftElite, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_ITEM_PREVIEW_RESET_OPEN, _ARG_0_.ResetHide, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_ITEM_PREVIEW_RESET_CLOSE, _ARG_0_.ResetShow, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UNKNOW_PASS, U1.EVENTID_UNKNOW_PASS_NORMAL_IAP_PRICE, _ARG_0_.UpdateNormalIAPPrice, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UNKNOW_PASS, U1.EVENTID_UNKNOW_PASS_ELITE_IAP_PRICE, _ARG_0_.UpdateEliteIAPPrice, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CENTAURI_NOTIFY, U1.EVENTID_CENTAURI_GET_GOODS_PRODUCT_INFO_NOTIFY, _ARG_0_.OnLoadPriceDataCallback, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_STORE_DATA, U1.EVENTID_STORE_DATA, U2.OnGetStoreData)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_MALL, U1.EVENTID_MALL_REWARD_PKG_INFO, U2.OnGetDirectPurchaseInfo)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UNKNOW_PASS, U1.EVENTID_UNKNOW_UPDATE_NORMALPASS_INFO, _ARG_0_.OnUpdateNormalPassInfo, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UNKNOW_PASS, U1.EVENTID_UNKNOW_PASS_RECORD_INFO_UPDATE, _ARG_0_.OnGetPassRecord, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 157, 78, 71, 249, 196, 215, 230, 115, 220),
        U2(165)
      }))
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.NewAnimation_In, 0, 1, 0, 1)
      _ARG_0_:PlayAudio((U1.table.concat({
        U2(239, 73, 140, 224, 51, 133, 45, 241, 42, 169, 223, 70, 104, 200, 31, 176, 31, 107, 212, 226, 206, 251, 102, 218, 124, 154, 198, 114, 119, 226, 52, 157, 127, 106, 228, 204, 218, 213, 73, 206),
        U2(175, 121, 195, 221, 58, 203, 3, 217, 22, 147, 229, 71, 119, 204, 29, 155, 99, 86, 242, 202)
      })))
      if U1.UIManager.IsUIShow(U1.UIManager.UI_Config.PlanPH_Store_Main_UIBP) then
        U1.printf((U1.table.concat({
          U2(149, 96, 134, 227, 57, 221, 42, 231, 48, 169, 229, 65, 107, 212, 46, 245, 68, 81, 172, 141, 150, 197, 95, 255, 17, 154, 144, 92, 96, 244, 15, 189, 84, 71, 236, 193, 223, 240, 127, 134),
          U2(163, 98, 130, 254, 51, 138, 42, 234, 34, 180, 234, 75, 65, 254, 5, 171, 66, 91, 194, 240, 199, 243, 100, 233, 6, 131, 232, 67)
        })))
        U1.UIManager.CloseUI(U1.UIManager.UI_Config.PlanPH_Store_Main_UIBP)
      end
      if _ARG_0_.UIRoot.Border_Mask then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Border_Mask, false)
      end
      do return end
      _ARG_0_ = U1.ReportTLogEvent
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 132, 79, 93, 249, 228, 216, 227, 110, 207),
        U2(161, 98, 132, 247, 51)
      }))
      if not _ARG_0_.isGift and U1.UnknowPassSystem.nPreBuyType ~= U3.Enum_PreBuyType.None then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetPassRecord"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 147, 69, 90, 221, 204, 197, 249, 72, 195),
        U1(163, 97, 159, 233)
      }))
      if require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).IsShowSimpleRp() then
        return
      end
      if UnknowPassSystem.Season < 59 then
        return
      end
      if _ARG_0_.isGift then
        return
      end
      if require((U1(163, 98, 132, 232, 56, 222, 84, 232, 38, 174, 205, 108, 108, 198, 95, 148, 66, 81, 233, 210, 197, 245, 102, 152, 6, 186, 203, 96, 125, 245, 0, 186, 68, 66, 232))).serverRecord == nil then
        return
      end
      if DataMgr.HaveNewbieGuide(DataMgr.NEWBIE_GUIDE_MODULE_ID_PASS, 1000000) and _ARG_0_.bUseFirstBuyPrivilege and require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).CheckCurSeasonIsOpenBuyPrivilege() then
        return
      end
      if (require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 234, 44, 189, 211, 96, 48, 225, 30, 163, 89, 93, 205, 209, 199, 227, 111, 196, 3, 184, 207, 117, 125, 147, 17, 184, 65, 87, 232, 223, 198, 248, 127, 192),
        U1(179)
      }))).LoadFileToTable_N(require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 234, 44, 189, 211, 96, 48, 225, 30, 163, 89, 93, 205, 209, 199, 227, 111, 196, 3, 184, 207, 117, 125, 147, 17, 184, 65, 87, 232, 223, 198, 248, 127, 192),
        U1(179)
      }))).ePlayerPrefsType.eUnknowPassBuyGuide) or {}) and (require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 234, 44, 189, 211, 96, 48, 225, 30, 163, 89, 93, 205, 209, 199, 227, 111, 196, 3, 184, 207, 117, 125, 147, 17, 184, 65, 87, 232, 223, 198, 248, 127, 192),
        U1(179)
      }))).LoadFileToTable_N(require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 234, 44, 189, 211, 96, 48, 225, 30, 163, 89, 93, 205, 209, 199, 227, 111, 196, 3, 184, 207, 117, 125, 147, 17, 184, 65, 87, 232, 223, 198, 248, 127, 192),
        U1(179)
      }))).ePlayerPrefsType.eUnknowPassBuyGuide) or {})[tonumber(DataMgr.roleData.uid)] then
        return
      end
      goto lbl_618
      if 0 < U1(161, 125, 205, 239, 51, 207, 20, 166, 48, 178, 213, 116, 112, 129, 81, 182, 85, 74, 232, 207, 200).pass_type then
      else
        ::lbl_618::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if false then
        ;(require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 234, 44, 189, 211, 96, 48, 225, 30, 163, 89, 93, 205, 209, 199, 227, 111, 196, 3, 184, 207, 117, 125, 147, 17, 184, 65, 87, 232, 223, 198, 248, 127, 192),
          U1(179)
        }))).LoadFileToTable_N(require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 234, 44, 189, 211, 96, 48, 225, 30, 163, 89, 93, 205, 209, 199, 227, 111, 196, 3, 184, 207, 117, 125, 147, 17, 184, 65, 87, 232, 223, 198, 248, 127, 192),
          U1(179)
        }))).ePlayerPrefsType.eUnknowPassBuyGuide) or {})[tonumber(DataMgr.roleData.uid)] = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBuyGuide"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 238, 9, 187, 87, 108, 248, 212, 241, 255, 115, 194),
        U1(165)
      }))
      if not _ARG_0_.UIRoot.GuideMask then
        log(bWriteLog and table.concat({
          U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 211, 8, 184, 0, 73, 248, 196, 210, 239, 58, 203),
          U1(161, 125, 134)
        }))
        return
      end
      UIManager.ShowUI(UIManager.UI_Config.UnknowPass_Purchase_Guidance_UIBP, _ARG_0_.UIRoot.GuideMask)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 151, 76, 65, 254, 200))
      if _ARG_0_.uRemainTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.uRemainTimer)
        _ARG_0_.uRemainTimer = nil
      end
      U2.bIsShowRPBuyUI = false
      UIManager.CloseUI(UIManager.UI_Config.UnknowPass_Purchase_Guidance_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitCoupon"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 244, 15, 189, 84, 120, 226, 216, 213, 226, 127, 212))
      UnknowPassSystem.hasVoucher = require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).CheckVoucher()
      UnknowPassSystem.hasCoupon = require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).CheckCouponBoxType()
      UnknowPassSystem.CouponType = require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).CheckCouponType()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 244, 15, 189, 84, 123, 196))
      U2.ReportTLogEvent(TLogEventDefine.PassBuy)
      _ARG_0_.hasCardType = 0
      if U3.HasUpCard(false) then
        _ARG_0_.hasCardType = 2
      elseif U3.HasUpCard(true) then
        _ARG_0_.hasCardType = 3
      end
      _ARG_0_:RefreshLocText()
      _ARG_0_:RefreshAskAndGiftBtn()
      _ARG_0_:RefreshNormalBuyBtn()
      _ARG_0_:RefreshEliteBuyBtn()
      _ARG_0_:RefreshCouponIcon()
      _ARG_0_:AddTimerOnce(0.1, function()
        _ENV:RefreshNormalReward()
        return
      end)
      _ARG_0_:AddTimerOnce(0.2, function()
        _ENV:RefreshEliteReward()
        return
      end)
      _ARG_0_:RefreshCommonReward()
      _ARG_0_:RefreshExchangeBtn()
      _ARG_0_:UpdateNewCouponInfo()
      _ARG_0_:UpdateReturnInfo()
      _ARG_0_:UpdateFirstBuyPrivilege()
      _ARG_0_:ShowCommonPopupSmall()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLocText"] = function(_ARG_0_)
    do
      if UnknowPassSystem.IsBuyElite then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshAskAndGiftBtn"] = function(_ARG_0_)
    do
      if _ARG_0_.isGift then
        _ARG_0_.UIRoot.WidgetSwitcher_Normal:SetActiveWidgetIndex(1)
        _ARG_0_.UIRoot.WidgetSwitcher_Elite:SetActiveWidgetIndex(1)
      else
        _ARG_0_.UIRoot.WidgetSwitcher_Normal:SetActiveWidgetIndex(0)
        _ARG_0_.UIRoot.WidgetSwitcher_Elite:SetActiveWidgetIndex(0)
      end
      if Client.GetDevicePlatformName() == require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 125, 194, 31, 162, 89, 89, 179, 254, 202, 243, 111, 216, 39, 135, 203, 112, 124, 210, 18, 250, 100, 75, 251, 196, 213, 239, 74, 202),
        U1(161, 122, 139, 226, 36, 199, 52, 231, 46, 191, 247, 98, 125, 223, 30, 183)
      }))).Android and Client.GetAOSSHOP() ~= require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 125, 194, 31, 162, 89, 89, 179, 254, 202, 243, 111, 216, 39, 135, 203, 112, 124, 210, 18, 250, 97, 97, 222, 254, 254, 197, 74, 235),
        U1(161, 109, 159, 226, 37)
      }))).Google and Client.GetAOSSHOP() ~= require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 125, 194, 31, 162, 89, 89, 179, 254, 202, 243, 111, 216, 39, 135, 203, 112, 124, 210, 18, 250, 97, 97, 222, 254, 254, 197, 74, 235),
        U1(161, 109, 159, 226, 37)
      }))).HMS then
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_multiple_area):IsPaymentSupport() then
      end
      if not _ARG_0_.isGift and UnknowPassSystem.IsBuyElite and (UnknowPassSystem.Season <= 54 or UnknowPassSystem.PassType == 2) then
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_cloud_game):IsCloudGameWeb() then
      end
      if false and not true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNormalPriceViaBuyType"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetBuyConfigViaBuyType(_ARG_1_) then
        return
      end
      if 7 <= _ARG_1_ and _ARG_1_ <= 17 then
      end
      if true then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetNormalBuyState"] = function(_ARG_0_)
    do
      do return {
        bIsBuyElite = UnknowPassSystem.IsBuyElite,
        bIsBuyEliteSeg2 = UnknowPassSystem.IsBuyEliteSeg2,
        bHasNormalCard = U1.HasUpCard(true),
        bHasExperienceCard = U1.HasExperienceCard(),
        bHasNewUserPrivlegesCard = U1.HasNewUserPrivlegesCard(),
        bUseFirstBuyPrivilege = _ARG_0_.bUseFirstBuyPrivilege
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetermineNormalBuyType"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_.bIsBuyElite then
        if _ARG_1_.bIsBuyEliteSeg2 then
          return nil, 0, nil
        end
        if _ARG_1_.bHasNormalCard then
          return BuyType23, 0, nil
        end
        return BuyType18, 0, nil
      end
      if _ARG_1_.bUseFirstBuyPrivilege then
        if _ARG_1_.bHasNewUserPrivlegesCard then
          return BuyType45, 3, U1
        end
        return BuyType44, 0, nil
      end
      if _ARG_1_.bHasNormalCard then
        return BuyType4, 3, nil
      end
      if _ARG_1_.bHasNewUserPrivlegesCard then
        return BuyType47, 0, U1
      end
      if _ARG_1_.bHasExperienceCard then
        return BuyType41, 0, nil
      end
      do return BuyType2, 0, nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_UpdateNormalBuyDisplay"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
      end
      if _ARG_2_.bIsBuyElite then
        if _ARG_2_.bIsBuyEliteSeg2 then
          return
        end
        if _ARG_1_ == U1.BuyType23 then
        else
        end
        return
      end
      if _ARG_1_ == U1.BuyType4 or _ARG_1_ == U1.BuyType45 then
        return
      end
      if _ARG_1_ == U1.BuyType47 or _ARG_1_ == U1.BuyType41 then
        if U2.GetBuyConfigViaBuyType(_ARG_1_) then
        end
        return
      end
      if _ARG_1_ == U1.BuyType44 then
        if U2.GetBuyConfigViaBuyType(_ARG_1_) then
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshNormalBuyBtn"] = function(_ARG_0_)
    do
      _ARG_0_.NormalBuyType = 0
      _ARG_0_.UIRoot.TextBlock_Normal_Level:SetText(LocUtil.LocalizeResFormat(49165))
      _ARG_0_.UIRoot.TextBlock_L1:SetText(LocUtil.LocalizeResFormat(49167))
      if _ARG_0_.isGift then
        return
      end
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_Buy_NormalCard, U1)
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_Normal_UCCard, U1)
      _ARG_0_.hasCardType, _ARG_0_.NormalBuyType = _ARG_0_:_DetermineNormalBuyType((_ARG_0_:_GetNormalBuyState()))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetElitePriceViaBuyType"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetBuyConfigViaBuyType(_ARG_1_) then
        return
      end
      if 7 <= _ARG_1_ and _ARG_1_ <= 17 then
      end
      if true then
        if not U1.FuncUtil.IsPlayerJPKR() and GetBuyConfigViaBuyType(_ARG_1_).Price2 > GetBuyConfigViaBuyType(_ARG_1_).PriceDiscount2 then
        else
        end
      elseif not U1.FuncUtil.IsPlayerJPKR() and GetBuyConfigViaBuyType(_ARG_1_).Price1 > GetBuyConfigViaBuyType(_ARG_1_).PriceDiscount1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_GetEliteBuyState"] = function(_ARG_0_)
    do
      do return {
        bIsBuyElite = UnknowPassSystem.IsBuyElite,
        bIsBuyEliteSeg2 = UnknowPassSystem.IsBuyEliteSeg2,
        nPassType = UnknowPassSystem.PassType or 1,
        bHasEliteCard = U1.HasUpCard(false),
        bHasNormalCard = U1.HasUpCard(true),
        bHasExperienceCard = U1.HasExperienceCard(),
        bHasNewUserPrivlegesCard = U1.HasNewUserPrivlegesCard()
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DetermineEliteBuyType"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_.bIsBuyElite then
        if _ARG_1_.bIsBuyEliteSeg2 then
          if _ARG_1_.nPassType >= 2 then
            return nil, nil
          end
          if _ARG_1_.bHasEliteCard then
            return BuyType22, nil
          end
          return BuyType20, nil
        end
        if _ARG_1_.bHasEliteCard then
          return BuyType21, nil
        end
        if _ARG_1_.bHasNormalCard then
          return BuyType43, nil
        end
        return BuyType19, nil
      end
      if _ARG_1_.bHasEliteCard then
        return BuyType5, nil
      end
      if _ARG_1_.bHasNormalCard then
        return BuyType6, nil
      end
      if _ARG_1_.bHasNewUserPrivlegesCard then
        return BuyType48, U1
      end
      if _ARG_1_.bHasExperienceCard then
        return BuyType42, nil
      end
      do return U2.GetBuyTypeWithCoupon(BuyType3), nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_UpdateEliteBuyDisplay"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
      end
      if _ARG_2_.bIsBuyElite and _ARG_2_.bIsBuyEliteSeg2 and _ARG_2_.nPassType >= 2 then
        return
      end
      if not _ARG_1_ then
        return
      end
      if _ARG_1_ == BuyType5 or _ARG_1_ == BuyType21 or _ARG_1_ == BuyType22 then
        return
      end
      if _ARG_1_ == BuyType6 or _ARG_1_ == BuyType43 or _ARG_1_ == BuyType48 or _ARG_1_ == BuyType42 then
        if U1.GetBuyConfigViaBuyType(_ARG_1_) then
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEliteBuyBtn"] = function(_ARG_0_)
    do
      _ARG_0_.EliteBuyType = 0
      _ARG_0_:SetTexture(_ARG_0_.UIRoot.Image_Buy_Plus_Card, _ENV)
      _ARG_0_.EliteBuyType = _ARG_0_:_DetermineEliteBuyType((_ARG_0_:_GetEliteBuyState())) or 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCouponIcon"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).IsShowOldCouponIcon() then
        if not (not require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).CheckCouponBoxType(require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).GetBuyExceptCouponMap()) or UnknowPassSystem.CouponType ~= 1 or UnknowPassSystem.CanExtraUpgrade) or UnknowPassSystem.hasVoucher then
        elseif require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).CheckCouponBoxType(require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).GetBuyExceptCouponMap()) and UnknowPassSystem.CouponType == 2 and not UnknowPassSystem.CanExtraUpgrade then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshNormalReward"] = function(_ARG_0_)
    do
      if not _ARG_0_.LoopScrollGrid_Immediately then
        _ARG_0_.LoopScrollGrid_Immediately = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Immediately)
        _ARG_0_.LoopScrollGrid_Immediately:SetRefreshItemCallback(_ARG_0_.OnRefreshNormalItem, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshNormalItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.LoopScrollGrid_Immediately:GetItemData(_ARG_2_) then
        return
      end
      if not U4.CanAutoDownload() and GetSize(U1.ENUM_DownloadType.ODPAK, {
        _ARG_0_.LoopScrollGrid_Immediately:GetItemData(_ARG_2_).item_id
      }) / U1.MB >= 10 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickNormalItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.LoopScrollGrid_Immediately:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEliteReward"] = function(_ARG_0_)
    do
      if not _ARG_0_.LoopScrollGrid_0 then
        _ARG_0_.LoopScrollGrid_0 = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_0)
        _ARG_0_.LoopScrollGrid_0:SetRefreshItemCallback(_ARG_0_.OnRefreshEliteItem, _ARG_0_)
        _ARG_0_.LoopScrollGrid_0:SetData(GetAllSuperAwards(_ARG_0_.isGift, false))
      end
      if _ARG_0_.UIRoot.LoopScrollGrid_2 then
        if _ARG_0_.EliteBuyType == 0 then
        end
        if not GetBuyConfigViaBuyType(3) then
          return
        end
        goto lbl_193
        if GetBuyConfigViaBuyType(3)[U2(129, 121, 140, 255, 50, 227, 14, 227, 46, 147, 254) .. U2(250, 46)] ~= 0 then
        end
        ::lbl_193::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if true then
          if not _ARG_0_.LoopScrollGrid_2 then
            _ARG_0_.LoopScrollGrid_2 = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_2)
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowElitePlusReward"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.UIRoot.LoopScrollGrid_TrailerReward then
        log(bWriteLog and string.format((table.concat({
          U1(149, 96, 134, 227, 57, 221, 42, 231, 48, 169, 229, 65, 107, 212, 46, 245, 68, 81, 172, 141, 150, 197, 95, 255, 17, 154, 144, 64, 102, 210, 22, 145, 76, 71, 249, 200, 230, 230, 111, 213),
          U1(146, 107, 154, 236, 36, 206, 90, 202, 44, 181, 202, 80, 125, 223, 30, 168, 92, 121, 239, 212, 194, 197, 94, 196, 50, 163, 198, 118, 124, 239, 4, 163, 65, 92, 233, 141, 223, 249, 58, 200),
          U1(169, 98)
        }))))
        return
      end
      if not _ARG_1_ then
        log(bWriteLog and string.format((table.concat({
          U1(149, 96, 134, 227, 57, 221, 42, 231, 48, 169, 229, 65, 107, 212, 46, 245, 68, 81, 172, 141, 150, 197, 95, 255, 17, 154, 144, 64, 102, 210, 22, 145, 76, 71, 249, 200, 230, 230, 111, 213),
          U1(146, 107, 154, 236, 36, 206, 90, 229, 44, 180, 220, 106, 121, 233, 16, 176, 81, 30, 244, 206, 134, 244, 99, 218)
        }))))
        return
      end
      goto lbl_335
      if U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103).item_id_1 and U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103).item_id_1 ~= 0 and require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 13, 187, 71, 71, 238, 242, 195, 228, 113, 200),
        U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103)
      }))).GetLevelAwardGroupCfg(U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103).item_id_1) then
        _ARG_0_ = _ARG_0_
        if 0 < require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 13, 187, 71, 71, 238, 242, 195, 228, 113, 200),
          U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103)
        }))).GetLevelAwardGroupCfg(U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103).item_id_1)[U1(169, 122, 136, 224, 9, 195, 30, 217) .. U1(175, 121, 157, 236, 37, 217, 37, 231, 52, 187, 200, 103)] then
        end
        _ARG_0_ = _ARG_0_
      end
      ::lbl_335::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not _ARG_0_.LoopScrollGrid_TrailerReward then
        _ARG_0_.LoopScrollGrid_TrailerReward = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_TrailerReward)
      end
      do return end
      _ARG_1_ = _ENV[230]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCommonReward"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Welfare, not UnknowPassSystem.IsBuyEliteSeg2)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_2, not UnknowPassSystem.IsBuyElite)
      if UnknowPassSystem.IsBuyElite then
        _ARG_0_.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(1)
      else
        _ARG_0_.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(0)
      end
      _ARG_0_.UIRoot.TextBlock_Return:SetText(720)
      if UnknowPassSystem.IsBuyElite and not UnknowPassSystem.IsBuyEliteSeg2 then
        _ARG_0_.UIRoot.TextBlock_Return:SetText(360)
      end
      if U1.GetBuyConfigViaBuyType(_ARG_0_.EliteBuyType) and U1.GetBuyConfigViaBuyType(_ARG_0_.EliteBuyType).AwardItemCount3 ~= 0 and U1.GetBuyConfigViaBuyType(_ARG_0_.EliteBuyType).AwardItemID3 ~= 0 then
        if CDataTable.GetTableData(U2(137, 122, 136, 224), U1.GetBuyConfigViaBuyType(_ARG_0_.EliteBuyType).AwardItemCount3) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshEliteItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.LoopScrollGrid_0:GetItemData(_ARG_2_) then
        return
      end
      if not U4.CanAutoDownload() and GetSize(U1.ENUM_DownloadType.ODPAK, {
        _ARG_0_.LoopScrollGrid_0:GetItemData(_ARG_2_).item_id
      }) / U1.MB >= 10 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEliteItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.LoopScrollGrid_0:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshCustomItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.LoopScrollGrid_2:GetItemData(_ARG_2_) then
        return
      end
      if not U4.CanAutoDownload() and U2.GetSize(U3.ENUM_DownloadType.ODPAK, {
        _ARG_0_.LoopScrollGrid_2:GetItemData(_ARG_2_).item_id
      }) / U3.MB >= 10 then
      end
      if _ARG_0_.LoopScrollGrid_2:GetItemData(_ARG_2_).item_sign == 1 then
      end
      do return end
      _ARG_0_ = tostring
      _ARG_0_ = U1.CanAutoDownload
    end
  end,
  ["OnRefreshTrailerRewardItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.LoopScrollGrid_TrailerReward:GetItemData(_ARG_2_) then
        return
      end
      if not U4.CanAutoDownload() and U2.GetSize(U3.ENUM_DownloadType.ODPAK, {
        _ARG_0_.LoopScrollGrid_TrailerReward:GetItemData(_ARG_2_).item_id
      }) / U3.MB >= 10 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCustomItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.LoopScrollGrid_2:GetItemData(_ARG_2_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshExchangeBtn"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot[_ENV(131, 102, 136, 238, 61, 232, 21, 254, 28, 150, 204, 50, 51, 152, 65)]:SetIsChecked(false)
      _ARG_0_.UIRoot[_ENV(131, 102, 136, 238, 61, 232, 21, 254, 28, 150, 204, 50, 51, 156, 65, 244)]:SetIsChecked(true)
      if _ARG_0_.isGift or U1.UnknowPassSystem.IsBuyElite then
        _ARG_0_.UIRoot.CanvasPanel_FirstBuy:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
      else
        _ARG_0_.UIRoot.CanvasPanel_FirstBuy:SetWidgetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCheckBox50Changed"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 151, 72, 75, 238, 198, 244, 229, 98, 147),
        U1(240, 77, 133, 236, 56, 205, 31, 226, 121, 250)
      }) .. tostring(_ARG_1_))
      U2.ReportTLogEvent(TLogEventDefine.RP_Click_Toggle_LevelRange)
      _ARG_0_:PlayAudio(sound_config.toggle_v1)
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNewCouponInfo"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.CanvasPanel_NewDisNor and _ARG_0_.UIRoot.CanvasPanel_NewDisPlus then
        if not require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).IsUseNewCouponUIShow() then
          return
        end
        goto lbl_157
        if require((U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 234, 220, 212, 254, 120, 217, 49, 175, 132, 100, 111, 207, 5, 166, 79, 76, 232, 242, 210, 235, 110, 199))):GetHallDepotItemDataByResID(require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).GetAllCouponByThrow()) then
        end
        ::lbl_157::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if 0 < require((table.concat({
          U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
          U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
        }))).GetAllCouponByThrow() then
          goto lbl_231
          if require((table.concat({
            U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
            U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
          }))).GetAllCouponByThrow() == 232 then
          else
            ::lbl_231::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateReturnInfo"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.UTRichTextBlock_Return_Tips_01, not _ARG_0_.isGift)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.UTRichTextBlock_Return_Tips_02, not _ARG_0_.isGift)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Return_Explain_Tips, false, true)
      _ARG_0_.UIRoot.UTRichTextBlock_Return_Tips_01:SetText(LocUtil.GetLocalizeResStr(87315))
      _ARG_0_.UIRoot.UTRichTextBlock_Return_Tips_02:SetText(LocUtil.GetLocalizeResStr(87315))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFirstBuyPrivilege"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).CheckCurSeasonIsOpenBuyPrivilege() then
        return
      end
      if U2.GetSeasonEndTime() - require((U1(163, 98, 132, 232, 56, 222, 84, 229, 44, 183, 215, 108, 112, 131, 5, 173, 93, 91, 194, 200, 210, 243, 102))).GetServerTimeInSec() > 86400 then
      else
      end
      if (_ARG_0_.bUseFirstBuyPrivilege or UnknowPassSystem.GetCurRPIsNewUserUnlock()) and not _ARG_0_.isGift then
      else
      end
      if not CDataTable.GetTableData(U1(146, 94, 162, 225, 50, 255, 9, 227, 49, 155, 205, 98, 108, 201, 50, 171, 94, 88, 244, 218), UnknowPassSystem.Season) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCountDown"] = function(_ARG_0_, _ARG_1_)
    do
      if UnknowPassSystem.IsBuyElite and UnknowPassSystem.PassType == 2 then
        return
      end
      if _ARG_0_.uRemainTimer then
        _ARG_0_.uRemainTimer = nil
      end
      _ARG_0_.uRemainTimer = _ARG_0_:AddTimerLoop(1, function()
        _ENV = U1.tonumber(U2.expireTS) - U3:GetServerTimeInSec()
        if 0 < _ENV then
          U4 = U3.FormatCountDownTime_D_or_HMS(_ENV, 7)
          U3.FormatCountDownTime_D_or_HMS(_ENV, 7):SetText(7)
          U3.FormatCountDownTime_D_or_HMS(_ENV, 7).SetText:SetText(7)
        else
          U3.FormatCountDownTime_D_or_HMS(_ENV, 7).SetText.SetText:SetWidgetVisible(7, false)
          U3.FormatCountDownTime_D_or_HMS(_ENV, 7).SetText.SetText.SetWidgetVisible:SetWidgetVisible(7, false)
          U3.FormatCountDownTime_D_or_HMS(_ENV, 7).SetText.SetText.SetWidgetVisible.SetWidgetVisible:RemoveTimer(7)
        end
        return
      end, TIMER_INFINITE, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickNormalBuy"] = function(_ARG_0_)
    do
      if IsRPCardAlreadyReceivedByGift() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DoNormalBuy"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 226, 37, 187, 110, 65, 255, 192, 215, 230, 88, 211),
        U1(185)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U2.ReportBtnClickEvent(U2.SubEventName_PassBuyNormal)
      U3.ReportTLogEvent(TLogEventDefine.PassBuyNormal)
      if require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).CheckCurSeasonIsOpenBuyPrivilege() and require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).GetIsFirstBuyPrivilegeUser() and not _ARG_0_.bUseFirstBuyPrivilege then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSuperBuy"] = function(_ARG_0_)
    do
      ReportTLogEvent(U1.TLogEventDefine.RP_Click_BuyButton)
      ReportTLogEvent(U1.TLogEventDefine.RP_Click_Select_ElitePlus)
      if U2.IsRPCardAlreadyReceivedByGift() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_DoSuperBuy"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 226, 37, 187, 115, 91, 253, 200, 196, 200, 111, 223))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 170, 64, 95, 238, 206, 249, 254, 107, 194, 50)
      }))).IsShowFirstBuyPrivilege() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ShowGiftReceivedConfirm"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == ENUM_RP_UPGRADE_CARD_TYPE.Elite then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowCommonPopupSmall"] = function(_ARG_0_)
    do
      if _ARG_0_.bIsShowCommonPopupSmall then
        _ARG_0_:OnClickNormalBuy()
        _ARG_0_.bIsShowCommonPopupSmall = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickNotFirstBuy"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.LoopScrollGrid_Immediately then
        return
      end
      _ARG_0_.UIRoot.WidgetSwitcher_Tab_FirstBuy_Good:SetActiveWidgetIndex(1)
      _ARG_0_.bUseFirstBuyPrivilege = false
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Return_Explain_Tips, false, true)
      _ARG_0_:RefreshNormalBuyBtn()
      _ARG_0_:RefreshAskAndGiftBtn()
      _ARG_0_:RefreshCouponIcon()
      _ARG_0_:UpdateNewCouponInfo()
      _ARG_0_.LoopScrollGrid_Immediately:SetData(U1.GetAllSuperAwards(_ARG_0_.isGift, true, nil, nil, false))
      _ARG_0_.UIRoot.UTRichTextBlock_Return_Tips_01:SetText(LocUtil.GetLocalizeResStr(87315))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickFirstBuy"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.LoopScrollGrid_Immediately then
        return
      end
      _ARG_0_.UIRoot.WidgetSwitcher_Tab_FirstBuy_Good:SetActiveWidgetIndex(0)
      _ARG_0_.bUseFirstBuyPrivilege = true
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Return_Explain_Tips, true, true)
      _ARG_0_:RefreshNormalBuyBtn()
      _ARG_0_:RefreshAskAndGiftBtn()
      _ARG_0_:RefreshCouponIcon()
      _ARG_0_:UpdateNewCouponInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRepurchase"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if CDataTable.GetTableData(U1(146, 94, 162, 225, 50, 255, 9, 227, 49, 155, 205, 98, 108, 201, 50, 171, 94, 88, 244, 218), UnknowPassSystem.Season) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButtonReturnExplain"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.UnknowPass_Award_UC_Retuen_Popup_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBuyWithCard"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(149, 96, 134, 227, 57, 221, 42, 231, 48, 169, 229, 65, 107, 212, 46, 245, 68, 81, 172, 141, 150, 197, 95, 255, 17, 154, 144, 92, 96, 254, 13, 189, 67, 69, 207, 216, 207, 221, 115, 210),
        U1(168, 77, 140, 255, 50)
      }) .. _ARG_1_)
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_1_ == 1 then
        U2.HandleBuyPopup({
          nHasCardType = _ARG_1_,
          nFromType = _ARG_0_.fromForTlog,
          nRawBuyType = _ARG_0_.NormalBuyType,
          bIsSuper = true,
          bIsExperienceCardBuyNormal = _ARG_2_
        })
      else
        U2.HandleBuyPopup({
          nHasCardType = _ARG_1_,
          nFromType = _ARG_0_.fromForTlog,
          nRawBuyType = _ARG_0_.EliteBuyType,
          bIsSuper = true
        })
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickAskFor"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 151, 76, 71, 238, 198, 247, 249, 113, 224),
        U1(175, 124, 215, 173)
      }) .. tostring(_ARG_1_))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_1_ then
        if not U2.elitePassDirectPurchaseInfo then
          log(bWriteLog and table.concat({
            U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 211, 8, 184, 0, 75, 225, 196, 194, 239, 74, 199),
            U1(179, 125, 169, 228, 36, 207, 25, 242, 19, 175, 200, 96, 118, 204, 2, 161, 121, 80, 251, 210)
          }))
        end
        U3.ReportBtnClickEvent(U3.SubEventName_PassAskForElite)
        U4.ReportTLogEvent(TLogEventDefine.PassAskForElite)
        _ARG_0_:AskForSuper()
      else
        if not U2.normalPassDirectPurchaseInfo then
          log(bWriteLog and table.concat({
            U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 211, 8, 184, 0, 64, 226, 223, 219, 235, 118, 246),
            U1(161, 125, 158, 201, 63, 216, 31, 229, 55, 138, 207, 113, 125, 197, 16, 183, 85, 119, 243, 219, 201)
          }))
        end
        U2.OpenBuySuperUI(false, true, _ARG_0_.fromForTlog)
        U3.ReportBtnClickEvent(U3.SubEventName_PassAskForNormal)
        U4.ReportTLogEvent(TLogEventDefine.PassAskForNormal)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AskForSuper"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 252, 18, 191, 102, 65, 255, 254, 195, 250, 127, 212))
      if U2.FindBuyId(false, false) and CDataTable.GetTableData(U1(137, 122, 136, 224), U2.FindBuyId(false, false)) then
      end
      return
    end
  end,
  ["ShowCouponTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGiftNormal"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.normalPassShopInfo then
        log_warning((table.concat({
          U2(155, 67, 165, 217, 11, 255, 20, 237, 45, 181, 205, 83, 127, 222, 2, 155, 114, 75, 228, 226, 151, 238, 101, 135, 99, 250, 245, 70, 71, 255, 49, 238, 111, 64, 206, 193, 223, 233, 113, 225),
          U2(169, 104, 153, 195, 57, 216, 23, 231, 47, 242, 147, 35, 112, 194, 3, 169, 81, 82, 205, 220, 213, 233, 89, 222, 60, 186, 227, 125, 104, 210, 65, 189, 83, 14, 227, 196, 218, 171)
        })))
        return
      end
      if not U1.normalPassDirectPurchaseInfo then
        log_warning((table.concat({
          U2(155, 67, 165, 217, 11, 255, 20, 237, 45, 181, 205, 83, 127, 222, 2, 155, 114, 75, 228, 226, 151, 238, 101, 135, 99, 250, 245, 70, 71, 255, 49, 238, 111, 64, 206, 193, 223, 233, 113, 225),
          U2(169, 104, 153, 195, 57, 216, 23, 231, 47, 242, 147, 35, 112, 194, 3, 169, 81, 82, 205, 220, 213, 233, 78, 223, 33, 175, 201, 103, 94, 200, 19, 183, 72, 79, 254, 200, 255, 228, 124, 201),
          U2(224, 103, 158, 173, 56, 195, 22, 167)
        })))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGiftElite"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not U1.elitePassShopInfo then
        log_warning((table.concat({
          U2(155, 67, 165, 217, 11, 255, 20, 237, 45, 181, 205, 83, 127, 222, 2, 155, 114, 75, 228, 226, 151, 238, 101, 135, 99, 250, 245, 70, 71, 255, 49, 238, 111, 64, 206, 193, 223, 233, 113, 225),
          U2(169, 104, 153, 195, 57, 216, 23, 231, 47, 242, 147, 35, 123, 193, 24, 176, 85, 110, 252, 206, 213, 201, 98, 217, 35, 131, 196, 117, 97, 157, 8, 167, 0, 64, 228, 193, 151)
        })))
        return
      end
      if not U1.elitePassDirectPurchaseInfo then
        log_warning((table.concat({
          U2(155, 67, 165, 217, 11, 255, 20, 237, 45, 181, 205, 83, 127, 222, 2, 155, 114, 75, 228, 226, 151, 238, 101, 135, 99, 250, 245, 70, 71, 255, 49, 238, 111, 64, 206, 193, 223, 233, 113, 225),
          U2(169, 104, 153, 195, 57, 216, 23, 231, 47, 242, 147, 35, 123, 193, 24, 176, 85, 110, 252, 206, 213, 222, 99, 196, 54, 169, 222, 67, 123, 207, 2, 188, 65, 93, 232, 228, 216, 236, 117, 134),
          U2(169, 125, 205, 227, 63, 198, 91)
        })))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickClose"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 242, 15, 151, 76, 71, 238, 198, 245, 230, 117, 213),
        U1(165)
      }))
      _ARG_0_:PlayAudio(sound_config.close_v1)
      if _ARG_0_.isFromIntroduce == true and not require((table.concat({
        U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 232, 211, 205, 244, 101, 193, 12, 186, 203, 96, 125, 147, 47, 177, 87, 124, 221, 253, 196, 239, 108, 207),
        U1(165, 121, 195, 225, 57, 205, 19, 229, 28, 175, 212, 104, 112, 194, 6, 180, 81, 77, 238, 226, 210, 239, 100, 216, 54, 166)
      }))).isShowRP then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Close"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(155, 91, 131, 230, 56, 197, 13, 214, 34, 169, 201, 92, 92, 216, 8, 155, 1, 74, 242, 140, 150, 170, 85, 227, 26, 136, 250, 78, 46, 254, 13, 187, 83, 75))
      _ARG_0_:StopCountDown()
      _ARG_0_.isFromIntroduce = false
      UnknowPassSystem.RpBuyCallBack = nil
      UnknowPassSystem.bSendBuyReq = false
      U2.__super.Close(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopCountDown"] = function(_ARG_0_)
    do
      if _ARG_0_.AskTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.AskTimer)
        _ARG_0_.AskTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickAnnual"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.Annual_Crit_Popup_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUnlockPrivilege"] = function(_ARG_0_)
    do
      ReportTLogEvent(U1.TLogEventDefine.RP_Click_View_PrivilegeDetail)
      _ARG_0_:PlayAudio(U1.sound_config.click_v1)
      U1.UIManager.ShowUI(U1.UIManager.UI_Config.UnknowPass_Privilege_New_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUnlockPrivilegePlus"] = function(_ARG_0_)
    do
      ReportTLogEvent(U1.TLogEventDefine.RP_Click_View_PlusPrivilegeDetail)
      _ARG_0_:PlayAudio(U1.sound_config.click_v1)
      U1.UIManager.ShowUI(U1.UIManager.UI_Config.UnknowPass_Privilege_New_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemDesc"] = function(_ARG_0_, _ARG_1_)
    do
      if CDataTable.GetTableData(U1(137, 122, 136, 224), _ARG_1_) then
        return CDataTable.GetTableData(U1(137, 122, 136, 224), _ARG_1_).ItemName
      end
      do return (U1()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAndroidBack"] = function(_ARG_0_)
    do
      HideBuyUI(true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAnnualSaleBtn"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateAskForCountDown"] = function(_ARG_0_)
    do
      if not require((U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 252, 206, 205, 197, 108, 217, 33, 228, 198, 124, 105, 212, 2, 139, 65, 93, 230, 242, 208, 229, 104))).GetCurrentAskForInfo(U2.GetAskForItemID().NormalItemId) then
        return
      end
      if not require((U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 252, 206, 205, 197, 108, 217, 33, 228, 198, 124, 105, 212, 2, 139, 65, 93, 230, 242, 208, 229, 104))).GetCurrentAskForInfo(U2.GetAskForItemID().EliteItemId) then
        return
      end
      _ARG_0_.AskTimer = _ARG_0_:AddTimerLoop(U3.ENUM_Timer.Buy.AskForCountDownTimer, function()
        _ENV()
        return
      end, TIMER_INFINITE, require((U1(163, 97, 128, 224, 57, 196, 84, 242, 42, 183, 223, 92, 106, 196, 18, 175, 85, 76))).MINIMUM_STEP_TIME)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetShow"] = function(_ARG_0_)
    do
      _ARG_0_:SelfHitTestInvisible()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetHide"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLoadPriceDataCallback"] = function(_ARG_0_)
    do
      if _ARG_0_._bPriceRefreshed then
        log(bWriteLog and table.concat({
          U1(149, 96, 134, 227, 57, 221, 42, 231, 48, 169, 229, 65, 107, 212, 46, 245, 68, 81, 172, 141, 150, 197, 95, 255, 17, 154, 144, 92, 96, 241, 14, 181, 68, 126, 255, 196, 213, 239, 94, 199),
          U1(180, 111, 174, 236, 58, 198, 24, 231, 32, 177, 154, 112, 117, 196, 1, 232, 16, 95, 241, 207, 195, 251, 110, 207, 115, 184, 207, 117, 124, 216, 18, 188, 69, 74)
        }))
        return
      end
      _ARG_0_._bPriceRefreshed = true
      if U2.normalPassDirectPurchaseInfo then
        _ARG_0_:UpdateNormalIAPPrice()
      end
      if U2.elitePassDirectPurchaseInfo then
        _ARG_0_:UpdateEliteIAPPrice()
      end
      U2.OnGetCentauriGoodsInfo()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNormalIAPPrice"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateEliteIAPPrice"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateNormalPassInfo"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshNormalBuyBtn()
      _ARG_0_:RefreshEliteBuyBtn()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasSpecialItem"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.isGift then
        return false
      end
      if CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicPHomeStore):GetDepotItemCountMap()[_ARG_1_] and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.LogicPHomeStore):GetDepotItemCountMap()[_ARG_1_] > 0 then
        if UnknowPassSystem.privilege_exchange_list and UnknowPassSystem.privilege_exchange_list[_ARG_1_] then
          return true, math.floor(CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_).RefundedCount / 2)
        end
        return true, CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_).RefundedCount
      end
      if CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_) and CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_).RefundedItemId == 1006 and require((U1(163, 98, 132, 232, 56, 222, 84, 245, 47, 175, 219, 45, 114, 194, 22, 173, 83, 16, 234, 220, 212, 254, 120, 217, 49, 175, 132, 100, 111, 207, 5, 166, 79, 76, 232, 242, 210, 235, 110, 199))):CheckHasPermanentItem(_ARG_1_) then
        if UnknowPassSystem.privilege_exchange_list and UnknowPassSystem.privilege_exchange_list[_ARG_1_] then
          return true, math.floor(CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_).RefundedCount / 2)
        end
        return true, CDataTable.GetTableDataByFilter(U1(147, 107, 140, 254, 57, 196, 42, 231, 48, 169, 243, 119, 123, 192, 35, 161, 86, 75, 243, 217, 213), U1(147, 107, 140, 254, 57, 196, 51, 226), UnknowPassSystem.Season, U1(137, 122, 136, 224, 31, 206), _ARG_1_).RefundedCount
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckRefundsInfoShow"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_12
      if _ARG_0_:HasSpecialItem((nil).item_id) then
      end
      ::lbl_12::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < 0 + _ARG_0_:HasSpecialItem((nil).item_id) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
