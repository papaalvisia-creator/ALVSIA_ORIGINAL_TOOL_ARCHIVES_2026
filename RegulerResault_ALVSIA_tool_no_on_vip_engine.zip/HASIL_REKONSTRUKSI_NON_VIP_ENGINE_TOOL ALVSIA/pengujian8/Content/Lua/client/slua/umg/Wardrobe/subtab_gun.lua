do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(85, 87, 192, 199, 194)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 154, 255, 196, 55, 186, 133, 35, 191, 111, 164, 249, 14, 80, 158, 240),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(66, 100, 195, 213, 194, 121)
}))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.CurrentGunType = 1
      _ARG_0_.CurrentGunID = 0
      _ARG_0_.args = _ARG_3_
      _ARG_0_._tWaitingIconGunIDs = {}
      _ENV:SetShareBagConfigGunID(0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_.Common_Tab_BagMode = _ARG_0_:InitHorizontalLevelTwoTextTab(_ARG_0_.UIRoot.Common_Tab_BagMode, nil, {bWarehouse = true})
      _ARG_0_.LoopScrollGrid_GunList = _ARG_0_:InitChildClassScrollBox(_ARG_0_.UIRoot.LoopScrollBox_GunList, (U2.table.concat({
        U3(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 160, 254, 195, 46, 245, 176, 29, 164, 127, 179, 251, 51, 89, 168, 196),
        U3(67, 85, 245, 205, 193, 121, 222, 215, 27, 148, 197, 244, 3)
      })))
      _ARG_0_.LoopScrollGrid_Pendant = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGrid_Pendant)
      _ARG_0_.LoopScrollGridShareSlot = _ARG_0_:InitScrollBox(_ARG_0_.UIRoot.LoopScrollGridShareSlot)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_UPDATE_GUN_LIST, _ARG_0_.OnUpdateGunList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_UPDATE_GUN_TAB_UI, _ARG_0_.UpdateTabUI, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ARMORY, U1.EVENTID_ARMORY_EQUIP_STAT_CHANGE, _ARG_0_.OnUpdateSkinEquipState, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_UPDATE_CURRENT_PUT_ON_GUN, _ARG_0_.OnUpdateCurrentPutOnGun, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_SWITCH_USE_ROLEWEAR, _ARG_0_.OnFashionBagChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WEAPON_DIY, U1.EVENTID_WEAPON_DIY_SUMMARY_DATA, _ARG_0_.OnGetDiyData, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_REFRESH_CURRENT_TAB, _ARG_0_.OnRefreshGunList, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ITEM_UPGRADE, U1.EVENTID_ITEM_UPGRADE_REFIT_SUCCESS, _ARG_0_.OnRefitRspCallBack, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WEAPON_PENDANT, U1.EVENTID_WEAPON_PENDANT_WEAR_UPDATE, _ARG_0_.UpDateWeaponPendantWear, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_SHARE_SKIN_MODE_REFRESH, _ARG_0_.OnShareSkinModRefresh, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_WARDROBE, U1.EVENTID_WARDROBE_SELF_USING_SHARE_WEAPON_CHANGE, _ARG_0_.OnSelfUsingWeaponChange, _ARG_0_)
      _ARG_0_.Common_ComboBox_GunType = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_GunType, nil, false, {bWarehouse = true})
      _ARG_0_.Common_ComboBox_GunType:SetSelectOptionCallback(_ARG_0_.OnSelectGunTypeItem, _ARG_0_)
      _ARG_0_.Common_ComboBox_GunType:SetRefreshOptionCallback(_ARG_0_.OnRefreshGunTypeItem, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Wardrobe_Details_item.Button_ChangeState, _ARG_0_.OnClickChangeState, _ARG_0_)
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetWeaponPage() then
        _ARG_0_.redHandle = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetWeaponPage():BindEvent(function(_ARG_0_)
          do
            if not slua.isValid(U1.UIRoot) then
              return
            end
            U2:UpdateSubTabItemCount(U1:GetDataSource())
            U1.Common_ComboBox_GunType:RefreshOptions()
            U1.LoopScrollGrid_GunList:RefreshAllItems()
            U1:SetWidgetVisible(U1.UIRoot.Reddot_Anchor, _ARG_0_ ~= 0)
            do return end
            _ARG_0_ = _ARG_0_
          end
        end)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_OnLgdWpnUpdate"] = function(_ARG_0_)
    do
      if not _ARG_0_:IsShow() then
        return
      end
      if _ARG_0_:_IsGunListStructChanged((_ARG_0_:BuildGunResInfoList())) then
        _ARG_0_.gunResInfoList = _ARG_0_:BuildGunResInfoList()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_IsGunListStructChanged"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.gunResInfoList or #_ARG_0_.gunResInfoList ~= #_ARG_1_ then
        return true
      end
      goto lbl_21
      if _ARG_0_.gunResInfoList[nil].resID ~= (nil).resID then
        return true
      end
      ::lbl_21::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      _ARG_0_:InitGunID()
      _ARG_0_:RefreshGunTypeComboBox()
      _ARG_0_:RefreshProficiencyDisplay()
      if _ARG_0_.LoopScrollGrid_GunList:GetItemData(1) then
      end
      if not U1.require((U1.table.concat({
        U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 127, 168, 231, 33, 80, 150, 250),
        U2(105, 72, 196, 192, 197, 117, 249, 196)
      }))).ShowGun() and U1.DataMgr.Weapon_ID == 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshAllItems"] = function(_ARG_0_)
    do
      _ARG_0_.LoopScrollGrid_GunList:RefreshAllItems()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideCarSkinList"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.CanvasPanel_CarSkinDrag:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpToSpecialGunItemID"] = function(_ARG_0_)
    do
      if not _ARG_0_.args or not _ARG_0_.gunResInfoList then
        return
      end
      goto lbl_19
      if (nil).resID == _ARG_0_.args then
      else
        ::lbl_19::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(109, 92, 212, 218, 236, 60, 192, 194, 12, 157, 232, 217, 49, 174, 176, 25, 168, 49, 158, 234, 2, 64, 136, 224, 11))
      if _ARG_0_.redHandle then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetWeaponPage() then
        end
        _ARG_0_.redHandle = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateGunList"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:UpdateGunList(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateSkinEquipState"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:RefreshPutOnGunSkinListItem()
      _ARG_0_:UpdatePendantTab()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateCurrentPutOnGun"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:UpdateCurrentPutOnGun(_ARG_3_, _ARG_4_, _ARG_5_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFashionBagChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.OnFashionBagChange(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      _ARG_0_:UpdateGunList(_ARG_0_.CurrentGunType)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnWardrobeDataChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Common_Tab_BagMode:GetSelectedIndex() == ENUM_Tab_Gun then
      elseif _ARG_0_.Common_Tab_BagMode:GetSelectedIndex() == ENUM_Tab_Pendants then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitGunID"] = function(_ARG_0_)
    do
      _ENV:SetGunID(0)
      _ENV:SetPreviewGunResID(0)
      if not (U1.require((U1.table.concat({
        U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U2(83, 100, 207, 209, 198)
      }))):GetWardrobeEditMode() == U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag) then
        if 0 < U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(U1.DataMgr.roleData and U1.DataMgr.roleData.uid or 0) and (U1.DataMgr.Weapon_ID == 0 or _ENV:IsMeleeWeapon(U1.DataMgr.Weapon_ID)) then
          _ARG_0_.CurrentGunType = U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(U1.DataMgr.roleData and U1.DataMgr.roleData.uid or 0))) and U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(U1.DataMgr.roleData and U1.DataMgr.roleData.uid or 0))).WeaponType or 8
        elseif U1.DataMgr.Weapon_ID ~= 0 and not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_legend_weapon):IsLegendWeaponItem(U1.DataMgr.Weapon_ID) then
          if U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), U1.DataMgr.Weapon_ID) ~= nil then
            _ARG_0_.CurrentGunType = U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), U1.DataMgr.Weapon_ID).WeaponType
            if U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(U1.DataMgr.Weapon_Skin_InsID) or U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByResID(U1.DataMgr.Weapon_Skin_ResID) then
            end
          end
        else
          _ARG_0_.CurrentGunType = 1
        end
      elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.FashionBagEditUtils):GetMainWeaponID() ~= 0 and U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.FashionBagEditUtils):GetMainWeaponID())) ~= nil then
        _ARG_0_.CurrentGunType = U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.FashionBagEditUtils):GetMainWeaponID())).WeaponType
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BuildGunResInfoList"] = function(_ARG_0_)
    do
      if U2:GetGunArrayByGunType(_ARG_0_.CurrentGunType) ~= nil then
        goto lbl_327
        ::lbl_327::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateGunList"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 6, 187, 147, 13, 178, 110, 150, 241, 47, 96, 142, 224, 26, 201, 249, 206, 44, 172, 179, 5, 166, 126, 225) .. tostring(_ARG_1_))
      if not _ARG_0_:IsShow() then
        return
      end
      _ARG_0_._tWaitingIconGunIDs = {}
      _ARG_0_.gunResInfoList = _ARG_0_:BuildGunResInfoList(), _ARG_0_.LoopScrollGrid_GunList:SetData((_ARG_0_:BuildGunResInfoList()))
      if _ARG_0_:GetCurrentShowGunID() > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReqLegendWeaponCardStatus"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshGunList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ENV:UpdateSubTabItemCount(_ARG_0_:GetDataSource())
      _ARG_0_.LoopScrollGrid_GunList:RefreshAllItems()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MarkGunIconWaitingDownload"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ENV then
        return
      end
      if not _ARG_1_ or not _ARG_2_ then
        return
      end
      if not _ARG_0_._tWaitingIconGunIDs then
        _ARG_0_._tWaitingIconGunIDs = {}
      end
      if _ARG_3_ then
        _ARG_0_._tWaitingIconGunIDs[_ARG_2_] = _ARG_1_
      else
        _ARG_0_._tWaitingIconGunIDs[_ARG_2_] = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDownloadFinish"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      __super.OnDownloadFinish(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
      _ARG_0_:RefreshWaitingGunIcons()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshWaitingGunIcons"] = function(_ARG_0_)
    do
      if not _ARG_0_._tWaitingIconGunIDs or not next(_ARG_0_._tWaitingIconGunIDs) then
        return
      end
      goto lbl_16
      ::lbl_16::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_156
      if not (CDataTable.GetTableData(U1(127, 79, 196, 217), 200) and CDataTable.GetTableData(U1(127, 79, 196, 217), 200).ItemSmallIcon) or CDataTable.GetTableData(U1(127, 79, 196, 217), 200).ItemSmallIcon == U1() then
        _ARG_0_._tWaitingIconGunIDs[200] = nil
      elseif require((U1(85, 87, 200, 209, 223, 104, 185, 192, 17, 148, 247, 217, 61, 229, 135, 13, 173, 84, 164, 240, 40, 64))).IsTextureDownloadedByPath(CDataTable.GetTableData(U1(127, 79, 196, 217), 200).ItemSmallIcon) then
        _ARG_0_._tWaitingIconGunIDs[200] = nil
        if _ARG_0_:FindIndexByWeaponID(209) then
        end
      end
      ::lbl_156::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshGunListItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_) then
        if _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).skinResID and _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).skinResID > 0 then
        end
        if CDataTable.GetTableData(U1(119, 73, 204, 219, 195, 101, 211, 198, 13, 154, 217, 217, 61, 173, 158, 11), _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
        end
        if U2:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag then
          if U3:GetShareBagConfigGunID() == 0 then
          end
        elseif U2:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag then
        else
        end
        if _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID == _ARG_0_.CurrentGunID then
        else
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetTabByResId(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
        end
        if 0 < U3:GetSubTabItemCount(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
        else
        end
        if require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 225, 32, 92, 136, 253, 49, 141, 227, 223, 109, 183, 136, 27, 191, 120, 158, 227, 52, 93, 135, 236),
          U1(88, 100, 197, 221, 200)
        }))):GetCurUsePlanIdByWeaponId(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).skinResID) ~= nil and require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 225, 32, 92, 136, 253, 49, 141, 227, 223, 109, 183, 136, 27, 191, 120, 158, 227, 52, 93, 135, 236),
          U1(88, 100, 197, 221, 200)
        }))):GetCurUsePlanIdByWeaponId(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).skinResID) ~= 0 then
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):IsLegendWeaponItem(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) and 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetTrialRemainTime(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGunListItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 180, 0, 175, 104, 186, 195, 52, 66, 171, 250, 29, 157, 195, 210, 38, 182, 199) .. tostring(_ARG_2_))
      if _ARG_4_ then
      else
        _ARG_0_:PlayAudio(sound_config.subTab_v1)
      end
      if not require((U1(85, 87, 200, 209, 223, 104, 185, 192, 17, 148, 247, 217, 61, 229, 130, 5, 153, 126, 165, 237, 45))).CanClickNow(require((U1(85, 87, 200, 209, 223, 104, 185, 192, 17, 148, 247, 217, 61, 229, 130, 5, 153, 126, 165, 237, 45))).ClickFrequencyLimit.WardrobeGunSubTab) then
        return
      end
      if _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_) then
        if not (U3:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag) and not (U3:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag) then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):IsLegendWeaponItem(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
            if 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(DataMgr.roleData and DataMgr.roleData.uid or 0) and not U2:IsMeleeWeapon(DataMgr.Weapon_ID) then
            elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):IsPermanent(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
            else
            end
          elseif DataMgr.Weapon_ID ~= 0 then
            if _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID ~= DataMgr.Weapon_ID or 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(DataMgr.roleData and DataMgr.roleData.uid or 0) and U2:IsMeleeWeapon(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
              if 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(DataMgr.roleData and DataMgr.roleData.uid or 0) and U2:IsMeleeWeapon(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):IsLegendWeaponItem(U2:GetGunID()) then
              end
            else
            end
          elseif U2:GetGunID() ~= _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID then
          elseif _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID ~= 0 then
          end
        elseif U3:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag then
        elseif U3:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag then
        end
        if not true then
          if U2:HasGunSkinList() then
          else
          end
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetTabIdByRes(_ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_2_).resID) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCurrentPutOnGun"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:IsShow() then
        return
      end
      _ENV:SetIsPutOnGun(U1.DataMgr.Weapon_ID ~= 0)
      if _ARG_1_ then
        _ARG_0_:UpdatePutOnGunListItem()
      end
      if U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), (_ENV:GetGunID())) ~= nil and U1.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), (_ENV:GetGunID())).WeaponType == _ARG_0_.CurrentGunType and _ARG_0_.Common_Tab_BagMode:GetSelectedIndex() == U3.ENUM_Tab_Gun then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePutOnGunListItem"] = function(_ARG_0_)
    do
      if _ENV:GetGunID() ~= 0 then
        _ARG_0_.CurrentGunID = _ENV:GetGunID()
      else
        _ARG_0_.CurrentGunID = 0
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_0_.CurrentGunID).resID == _ARG_0_.CurrentGunID or _ARG_0_.LoopScrollGrid_GunList:GetItemData(_ARG_0_.CurrentGunID).resID == _ARG_0_.CurrentGunID then
      end
      _ARG_0_ = _ARG_0_
      if 0 < U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(U1.DataMgr.roleData and U1.DataMgr.roleData.uid or 0) then
      end
      if U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 181, 235, 54, 66, 139, 252, 15, 141, 164, 214, 54, 189, 129, 25, 164, 68, 178, 227, 56, 72, 148, 235))).CanAutoDownload() then
        return
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.puffer_odpak_manager):GetStateByItemID((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_legend_weapon):GetActiveLegendWeaponIdForUid(U1.DataMgr.roleData and U1.DataMgr.roleData.uid or 0))) == U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 181, 235, 54, 66, 139, 252, 15, 141, 164, 214, 54, 189, 129, 25, 164, 68, 162, 251, 63, 79, 131))).ENUM_DownloadState.Done then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGunSkinList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 1, 174, 145, 30, 163, 120, 185, 195, 52, 66, 180, 248, 7, 135, 198, 207, 48, 175, 199) .. tostring(_ARG_1_))
      if 0 < _ARG_1_ and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_legend_weapon):IsLegendWeaponItem(_ARG_1_) then
        return
      end
      if 0 < _ARG_1_ then
        if CDataTable.GetTableData(U1(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), _ARG_1_) ~= nil and CDataTable.GetTableData(U1(119, 73, 204, 219, 195, 101, 212, 204, 16, 159, 243, 209), _ARG_1_).WeaponType == _ARG_0_.CurrentGunType then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowEmptyGunSkinList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 0, 163, 152, 27, 131, 102, 161, 240, 56, 107, 146, 253, 61, 130, 227, 200, 15, 178, 148, 8, 246) .. tostring(_ARG_1_))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Wardrobe_Empty, _ARG_1_)
      if _ARG_1_ then
        _ARG_0_.UIRoot.WidgetSwitcher_Wardrobe_Empty:SetActiveWidgetIndex(1)
        U2.__super.UpdateItemList(_ARG_0_, {})
        if not _ARG_2_ then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateGunSkinList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 6, 187, 147, 13, 178, 110, 150, 241, 47, 127, 140, 250, 0, 165, 227, 213, 55, 251, 176, 29, 164, 127, 179, 251, 51, 89, 168, 196),
        U1(67, 85, 232, 240, 145)
      }) .. tostring(_ARG_1_))
      if not _ARG_0_:IsShow() then
        return
      end
      if U2.GetSkinListByWeaponID(_ARG_1_) ~= nil then
        if _ARG_2_ then
        end
        if #_ARG_0_:DoFilterTags((_ARG_0_:DoSearch(U3:GetSkinList(U2.GetSkinListByWeaponID(_ARG_1_), require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U1(83, 100, 207, 209, 198)
        }))):GetSortPreference((require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U1(83, 100, 198, 193, 223)
        }))))), _ARG_1_, _ARG_0_:GetDataSource()), U4:GetSearchString()))) == 0 then
        elseif (_ARG_0_:GetCurrentSelectItemInsID() or U3:GetSkinIdByWeaponID(_ARG_1_)) and (_ARG_0_:GetCurrentSelectItemInsID() or U3:GetSkinIdByWeaponID(_ARG_1_)) ~= 0 and 0 < _ARG_0_:GetItemIndexByInsId(_ARG_0_:GetCurrentSelectItemInsID() or U3:GetSkinIdByWeaponID(_ARG_1_)) then
        end
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_share_bag_team_util):GetUsingShareWeaponIDByUID(DataMgr.roleData.uid) == 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsShowBigIcon"] = function(_ARG_0_)
    do
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshListItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.OnRefreshListItem(_ARG_0_, _ARG_1_, _ARG_2_)
      if not _ARG_0_:GetItemData(_ARG_2_) then
        return
      end
      if U1.require((U1.table.concat({
        U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U2(83, 100, 207, 209, 198)
      }))):GetWardrobeEditMode() == U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.Common_Tab_BagMode:GetSelectedIndex() == ENUM_Tab_Pendants then
        return
      end
      if _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_) and _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).lock_cnt and _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).lock_cnt > 0 then
        return
      end
      if _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_) then
        if not U1.DataMgr.IsValidTime(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).expireTS) then
          return
        end
        if U1.require((U1.table.concat({
          U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U2(83, 100, 207, 209, 198)
        }))):IsItemIsolated(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id) then
          return
        end
        if not U1.require((U1.table.concat({
          U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U2(83, 100, 207, 209, 198)
        }))):IsCharacterUse(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id) then
          return
        end
        if _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).planID and _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).planID ~= U1.require((U1.table.concat({
          U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 225, 32, 92, 136, 253, 49, 141, 227, 223, 109, 183, 136, 27, 191, 120, 158, 227, 52, 93, 135, 236),
          U2(88, 100, 197, 221, 200)
        }))):GetCurUsePlanIdByWeaponId(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id) then
        end
        if U1.CDataTable.GetTableData(U2(97, 94, 192, 196, 222, 114, 196, 200, 23, 151, 215, 215, 35, 187, 158, 2, 161), _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id) then
          if U4:GetWardrobeEditMode() == U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag then
            if U1.require((U1.table.concat({
              U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 170, 129, 13, 178, 106, 163, 170, 45, 67, 128, 250, 13, 182, 254, 195, 34, 182, 184, 29, 160, 122, 181, 245, 35, 99, 154, 226),
              U2(88, 90, 198, 209, 195)
            }))).GetAvatarByUid(U1.tonumber(U1.DataMgr.roleData.uid)) and U1.require((U1.table.concat({
              U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 170, 129, 13, 178, 106, 163, 170, 45, 67, 128, 250, 13, 182, 254, 195, 34, 182, 184, 29, 160, 122, 181, 245, 35, 99, 154, 226),
              U2(88, 90, 198, 209, 195)
            }))).GetAvatarByUid(U1.tonumber(U1.DataMgr.roleData.uid)):GetCurHoldingWeaponSkinID() == _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id then
            end
          elseif not (U4:GetWardrobeEditMode() == U1.require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag) then
            if U1.require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).IsWeaponWear(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).ins_id) == false or _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).planID ~= U1.require((U1.table.concat({
              U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 225, 32, 92, 136, 253, 49, 141, 227, 223, 109, 183, 136, 27, 191, 120, 158, 227, 52, 93, 135, 236),
              U2(88, 100, 197, 221, 200)
            }))):GetCurUsePlanIdByWeaponId(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id) then
            else
            end
          elseif not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.FashionBagEditUtils):IsItemInTryMap(_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_).res_id, false, (_ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_2_))) then
          else
          end
        end
      end
      do return end
      _ARG_1_ = U1[66]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPutOnGunSkinListItem"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).planID ~= nil then
        _ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).isUsing = U1.tonumber(_ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).ins_id) == _ENV:GetSkinIdByWeaponID((_ARG_0_:GetCurrentShowGunID())) and _ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).planID == U1.require((U1.table.concat({
          U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 225, 32, 92, 136, 253, 49, 141, 227, 223, 109, 183, 136, 27, 191, 120, 158, 227, 52, 93, 135, 236),
          U2(88, 100, 197, 221, 200)
        }))):GetCurUsePlanIdByWeaponId(_ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).res_id)
      else
        _ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).isUsing = U1.tonumber(_ARG_0_.LoopScrollGrid_Normal:GetItemData(nil).ins_id) == _ENV:GetSkinIdByWeaponID((_ARG_0_:GetCurrentShowGunID()))
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSwitchPanel"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_1_ = _ARG_1_ or _ARG_0_:GetCurrentSelectItemInsID()
      log(bWriteLog and table.concat({
        U1(109, 108, 192, 198, 213, 110, 248, 193, 27, 180, 239, 218, 39, 162, 190, 24, 163, 102, 140, 164, 22, 77, 149, 247, 28, 134, 232, 195, 4, 174, 137, 92, 132, 126, 167, 230, 52, 79, 159, 208),
        U1(65, 82, 213, 215, 217, 76, 246, 205, 27, 149)
      }) .. tostring(_ARG_1_))
      if not _ARG_1_ or tonumber(_ARG_1_) == 0 then
        _ARG_0_.UIRoot.Wardrobe_Details_item:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        return
      end
      if not require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_) then
        return
      end
      if not CDataTable.GetTableData(U1(97, 94, 192, 196, 222, 114, 196, 212, 23, 141, 249, 222, 16, 164, 153, 10, 175, 108), (U2():GetLevel1ItemID(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_).resID))) then
        return
      end
      if U2():IsRefitUnlockComplete2(U2():GetBaseItemID(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_).resID), _ARG_0_:GetDataSource()) and not (U2():GetFullUnlockLevel((U2():GetGroupID(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_).resID))) > U2():GetLevel(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_).resID)) then
      else
      end
      return
    end
  end,
  ["RefreshGunTypeComboBox"] = function(_ARG_0_)
    do
      goto lbl_16
      ::lbl_16::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshGunTypeItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 165, 9, 160, 121, 180, 247, 41, 107, 146, 253, 58, 144, 250, 195, 10, 175, 130, 17))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.wardrobe_red_point):GetWeaponType(CDataTable.GetTableData(U1(119, 73, 204, 219, 195, 101, 195, 218, 14, 156, 217, 217, 61, 173, 158, 11), _ARG_2_).TypeID) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectGunTypeItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 164, 9, 170, 110, 178, 240, 6, 89, 137, 199, 23, 153, 239, 239, 55, 190, 138))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if CDataTable.GetTableData(U1(119, 73, 204, 219, 195, 101, 195, 218, 14, 156, 217, 217, 61, 173, 158, 11), _ARG_2_) ~= nil then
        _ARG_0_.CurrentGunType = CDataTable.GetTableData(U1(119, 73, 204, 219, 195, 101, 195, 218, 14, 156, 217, 217, 61, 173, 158, 11), _ARG_2_).TypeID
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGunTypeChanged"] = function(_ARG_0_)
    do
      if _ENV:HasGunSkinList() then
        _ARG_0_:UpdateGunList(_ARG_0_.CurrentGunType)
      else
        _ENV:GetGunSkinListReq()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetDiyData"] = function(_ARG_0_)
    do
      if _ENV:HasGunSkinList() then
        _ARG_0_:UpdateGunList(_ARG_0_.CurrentGunType)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ListenGunIconChange"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 36, 72, 158, 239),
        U1(69)
      }))).GetSubTabConfigByPageID(U2) or not next((require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 36, 72, 158, 239),
        U1(69)
      }))).GetSubTabConfigByPageID(U2))) then
        return
      end
      goto lbl_144
      if require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 210, 34, 185, 184, 15, 163, 105, 183, 241, 56, 80, 155, 226),
        U1(88, 88, 196)
      }))).GetTabEquip(U1(88, 88, 196).subTabID) then
      end
      ::lbl_144::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGunListIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:FindIndexByWeaponID(_ARG_1_) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FindIndexByWeaponID"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.LoopScrollGrid_GunList:GetItemData(nil).resID == _ARG_1_ then
        return nil
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TriggerSelectedGunIconDownload"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:FindIndexByWeaponID(_ARG_1_) then
        return
      end
      if not _ARG_0_.LoopScrollGrid_GunList:GetIndexOfWidget((_ARG_0_:FindIndexByWeaponID(_ARG_1_))) or not slua.isValid((_ARG_0_.LoopScrollGrid_GunList:GetIndexOfWidget((_ARG_0_:FindIndexByWeaponID(_ARG_1_))))) then
        return
      end
      if not (_ARG_0_.LoopScrollGrid_GunList:GetIndexOfWidget((_ARG_0_:FindIndexByWeaponID(_ARG_1_))).Wardrobe_GunTypeItem_UIBP and _ARG_0_.LoopScrollGrid_GunList:GetIndexOfWidget((_ARG_0_:FindIndexByWeaponID(_ARG_1_))).Wardrobe_GunTypeItem_UIBP.Image_Wardrobe_GunLogo) or not slua.isValid(_ARG_0_.LoopScrollGrid_GunList:GetIndexOfWidget((_ARG_0_:FindIndexByWeaponID(_ARG_1_))).Wardrobe_GunTypeItem_UIBP and _ARG_0_.LoopScrollGrid_GunList:GetIndexOfWidget((_ARG_0_:FindIndexByWeaponID(_ARG_1_))).Wardrobe_GunTypeItem_UIBP.Image_Wardrobe_GunLogo) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetItemName"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.TypeName ~= nil then
        if _ENV:GetTabItemCount(_ARG_2_.TypeID) > 0 then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshProficiencyDisplay"] = function(_ARG_0_)
    do
      if IsOpen() then
        if U3.CDataTable.GetTableData(U2(119, 73, 204, 219, 195, 101, 211, 198, 13, 154, 217, 217, 61, 173, 158, 11), (U1:GetGunID())) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCheckBox"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.toggle_v1)
      if _ARG_0_.UIRoot.CheckBox_Sort:IsChecked() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectSortItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_1_ and _ARG_1_.TextBlock_ItemName then
        _ARG_1_.TextBlock_ItemName:SetText(_ARG_2_.text)
      end
      if _ARG_2_.type == _ARG_0_.ENUM_SORT_TYPE.LATEST then
        U1:SetSortPreference(U2, true)
      else
        U1:SetSortPreference(U2, false)
      end
      _ARG_0_:OnWardrobeDataChange()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCheckBoxState"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.TextBlock_SortViaTime:SetText(LocUtil.LocalizeResFormat(34618))
      if U1:GetSortPreference(U2) then
      elseif U1:GetSortPreference(U2) == nil then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHorizontalTabButton"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_2_ == U1.ENUM_Tab_Gun then
        _ARG_0_:OnClickButtonGun()
      elseif _ARG_2_ == U1.ENUM_Tab_Pendants then
        _ARG_0_:OnClickButtonPendants()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonGun"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.HorizontalBox_Pendant:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      _ARG_0_.UIRoot.LoopScrollGrid_Avatar:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonPendants"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_share_bag_team_util):GetUsingShareWeaponIDByUID(DataMgr.roleData.uid) ~= 0 then
        return
      end
      if not require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() or require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() == 0 then
        return
      end
      if not (require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())) and require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).resID) or not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant):CanSkinWithPendant(require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).resID) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module):GetZoomInLobbyCameraCfg(require((U2(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U2(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).itemSubType, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module).currentCameraID) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBagPendantsList"] = function(_ARG_0_)
    do
      _ARG_0_.pendantList = _ARG_0_:GetBagPendantsList()
      _ARG_0_:SetInitItemList(_ARG_0_.pendantList)
      if _ARG_0_.UIRoot.WidgetSwitcher_Search then
        _ARG_0_.pendantList = _ARG_0_:DoSearch(_ARG_0_.pendantList, _ENV:GetSearchString())
      end
      if _ARG_0_.bShowTagFilter then
        _ARG_0_.pendantList = _ARG_0_:DoFilterTags(_ARG_0_.pendantList)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBagPendantsList"] = function(_ARG_0_)
    do
      if not require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() or require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() == 0 then
        return {}
      end
      if not require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())) or not require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).resID then
        return {}
      end
      goto lbl_421
      if CDataTable.GetTableData(U1(127, 79, 196, 217), (223).resID) and require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U1(83, 100, 207, 209, 198)
      }))):IsValidCurrentPageItem(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).ENUM_WardrobePageTypeId.ENUM_WardrobePageType_Parachute, require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).ENUM_WardrobeSubTabString.ENUM_WardrobeSubTabString_bag_pendant, 223, (require((U1(85, 87, 200, 209, 223, 104, 185, 192, 17, 148, 247, 217, 61, 229, 131, 5, 171, 110, 142, 241, 53, 69, 139))).GetServerTimeInSec())) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant):IsWeaponPendant((223).resID) then
        require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U1(83, 100, 207, 209, 198)
        }))):ArrayHallDepotToCommonItem(223, nil, tonumber((223).insID) == ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant):GetPendantInsBySkinID(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).resID), true, false, false).isRolewear = false
      end
      ::lbl_421::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshPendantList"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPendantItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.LoopScrollGrid_Pendant:GetItemData(_ARG_2_) then
        _ARG_0_.LoopScrollGrid_Pendant:GetItemData(_ARG_2_).isNew = false
        if not DataMgr.IsValidTime(_ARG_0_.LoopScrollGrid_Pendant:GetItemData(_ARG_2_).expireTS) then
          return
        end
        if require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U1(83, 100, 207, 209, 198)
        }))):IsItemIsolated(_ARG_0_.LoopScrollGrid_Pendant:GetItemData(_ARG_2_).res_id) then
          return
        end
        if not require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U1(83, 100, 207, 209, 198)
        }))):IsCharacterUse(_ARG_0_.LoopScrollGrid_Pendant:GetItemData(_ARG_2_).res_id) then
          return
        end
        if not require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() or require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() == 0 then
          return
        end
        if _ARG_0_.LoopScrollGrid_Pendant:GetItemData(_ARG_2_).isUsing then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpDateWeaponPendantWear"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 6, 187, 179, 13, 178, 110, 134, 225, 32, 92, 136, 253, 62, 140, 228, 194, 34, 181, 147, 43, 179, 122, 179, 180) .. tostring(_ARG_3_) .. tostring(_ARG_4_))
      if _ARG_0_.Common_Tab_BagMode:GetSelectedIndex() == U2.ENUM_Tab_Gun then
        return
      end
      if not _ARG_3_ and not _ARG_4_ then
        return
      end
      _ARG_0_ = _ARG_0_
      if tonumber(_ARG_0_.LoopScrollGrid_Pendant:GetItemData(208).ins_id) == _ARG_3_ then
        _ARG_0_.LoopScrollGrid_Pendant:GetItemData(208).isUsing = true
      end
      if tonumber(_ARG_0_.LoopScrollGrid_Pendant:GetItemData(208).ins_id) == _ARG_4_ then
        _ARG_0_.LoopScrollGrid_Pendant:GetItemData(208).isUsing = false
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdatePendantTab"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_share_bag_team_util):GetUsingShareWeaponIDByUID(DataMgr.roleData.uid) ~= 0 then
        return
      end
      if not require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() or require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId() == 0 then
        return
      end
      if not (require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())) and require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).resID) or not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_weapon_pendant):CanSkinWithPendant(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID((require((U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 167, 152, 14, 164, 114, 255, 236, 32, 64, 139, 204, 26, 129, 239, 203, 38, 132, 146, 8, 191, 119, 178))).GetCurWeaponInstId())).resID) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickChangeState"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.LoopScrollGrid_Normal:GetSelectIndex() <= 0 then
        return
      end
      if U2():IsRefitUnlockComplete2(U2():GetBaseItemID(_ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id), _ARG_0_:GetDataSource()) and not (U2():GetFullUnlockLevel((U2():GetGroupID(_ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id))) > U2():GetLevel(_ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id)) then
      elseif U2():GetFullUnlockLevel((U2():GetGroupID(_ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id))) > U2():GetLevel(_ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicMultiItemModule):GetUnlockTips((U2():GetLevel1ItemID((U2():GetRefitItemID(_ARG_0_.LoopScrollGrid_Normal:GetItemData((_ARG_0_.LoopScrollGrid_Normal:GetSelectIndex())).res_id))))) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefitRspCallBack"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_3_ ~= 0 then
        log_error(table.concat({
          U1(109, 108, 192, 198, 213, 110, 248, 193, 27, 180, 239, 218, 39, 162, 190, 24, 163, 102, 140, 164, 22, 77, 149, 247, 28, 134, 232, 195, 4, 174, 137, 92, 153, 117, 147, 241, 55, 85, 131, 209),
          U1(69, 75, 226, 213, 221, 112, 213, 194, 29, 146, 186, 211, 33, 185, 152, 30, 153, 104, 190, 224, 36, 12, 153, 174, 78, 217)
        }) .. tostring(_ARG_3_))
        return
      end
      log(bWriteLog and table.concat({
        U1(109, 108, 192, 198, 213, 110, 248, 193, 27, 180, 239, 218, 39, 162, 190, 24, 163, 102, 140, 164, 22, 77, 149, 247, 28, 134, 232, 195, 4, 174, 137, 92, 153, 117, 147, 241, 55, 85, 131, 209),
        U1(69, 75, 226, 213, 221, 112, 213, 194, 29, 146)
      }) .. tostring(_ARG_0_.CurrentGunID))
      _ARG_0_:UpdateGunSkinList(_ARG_0_.CurrentGunID)
      _ARG_0_ = _ARG_0_
      if tonumber(_ARG_0_.LoopScrollGrid_Normal:GetItemData(U1(69, 75, 226, 213, 221, 112, 213, 194, 29, 146)).ins_id) == tonumber(_ARG_4_) then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFashionBagEditWeaponUpdate"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_.LoopScrollGrid_GunList:RefreshAllItems()
      _ARG_0_:RefreshGunListIcon(_ARG_3_, _ARG_4_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurrentShowGunID"] = function(_ARG_0_)
    do
      if U2:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag then
        if U3:GetShareBagConfigGunID() == 0 then
        end
      elseif U2:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag then
      else
        if U3:GetGunID() == 0 then
        end
        if U3:GetKeepGunID() == 0 then
        end
      end
      do return 101001 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = GetGunID
    end
  end,
  ["GetShowSkinIDByWeaponID"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return 0
      end
      if not (U2:GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag) then
        return U3:GetSkinIdByWeaponID(_ARG_1_)
      else
        return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.FashionBagEditUtils):GetSkinIDByWeaponID(_ARG_1_)
      end
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFashionBagEditExit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      __super.OnFashionBagEditExit(_ARG_0_, _ARG_1_, _ARG_2_)
      _ARG_0_:UpdateTabUI()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTabUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:InitGunID()
      _ARG_0_:RefreshGunTypeComboBox()
      _ARG_0_:UpdateGunList(_ARG_0_.CurrentGunType)
      _ARG_0_:RefreshCommonTab()
      _ARG_0_:RefreshShareBagTips()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCommonTab"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateShareSlotList"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 6, 187, 147, 13, 178, 110, 130, 236, 32, 94, 130, 192, 2, 134, 254, 234, 42, 168, 147))
      _ARG_0_:RefreshCommonTab()
      if not (require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U1(83, 100, 207, 209, 198)
      }))):GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag) then
        return
      end
      _ARG_0_.shareItemList = {}
      if require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U1(83, 100, 207, 209, 198)
      }))):GetShareBagItemList() then
        goto lbl_224
        if U1(85, 73, 206, 199) then
        end
        ::lbl_224::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        _ARG_0_.sharedItemCount = #_ARG_0_.shareItemList
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
        _ARG_0_.sharedItemCount = 0
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshShareSlot"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareSlotDrop"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 164, 4, 167, 121, 180, 215, 45, 67, 147, 215, 28, 134, 250))
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 182, 26, 167, 127, 176, 246, 18, 64, 136, 231, 42, 155, 229, 214))
      if require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByInsID((tonumber(_ARG_3_.dragExtendData))) and _ARG_0_:GetItemIndexByInsIdAndResId(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByInsID((tonumber(_ARG_3_.dragExtendData))).insID, require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByInsID((tonumber(_ARG_3_.dragExtendData))).resID) ~= -1 then
      end
      do return end
      _ARG_0_ = _ENV[252]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShareSlotData"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.LoopScrollGridShareSlot:GetItemData(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareSlotDrag"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 182, 26, 167, 127, 176, 246, 18, 64, 136, 231, 42, 155, 235, 193))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareSlotRemove"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 182, 26, 167, 127, 176, 246, 18, 64, 136, 231, 60, 140, 231, 201, 53, 190))
      if require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByResID((tonumber(_ARG_3_.dragExtendData))) and _ARG_0_:GetItemIndexByInsIdAndResId(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByResID((tonumber(_ARG_3_.dragExtendData))).insID, require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetHallDepotItemDataByResID((tonumber(_ARG_3_.dragExtendData))).resID) ~= -1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGunItemDragReadyToShape"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 176, 25, 168, 66, 165, 225, 44, 104, 149, 242, 9, 187, 239, 199, 39, 162, 179, 19, 133, 115, 160, 228, 52))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGunItemDragCanceled"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 182, 26, 167, 127, 176, 246, 5, 94, 134, 244, 45, 136, 228, 197, 38, 183, 130, 24))
      _ARG_0_:EndAvatarDragHint()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BeginAvatarDragHint"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EndAvatarDragHint"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemData"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_.LoopScrollGrid_Normal:GetItemData(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitDragWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      if CDataTable.GetTableData(U1(127, 79, 196, 217), _ARG_2_) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PutWeaponDataToSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (_ARG_1_ and _ARG_2_) or not _ARG_3_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveWeaponDataFromSlot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshShareSlotItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ <= _ARG_0_.sharedItemCount and _ARG_0_.LoopScrollGridShareSlot:GetItemData(_ARG_2_) ~= 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitSlotItemView"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_1_.TextBlock_Index, true, false)
      _ARG_1_.TextBlock_Index:SetText(tostring(_ARG_2_))
      if _ARG_4_ then
        if CDataTable.GetTableData(U1(127, 79, 196, 217), _ARG_3_) then
        end
      else
        _ARG_0_:SetWidgetVisible(_ARG_1_.Icon, false, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.IsEmpty, true, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareSkinModRefresh"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(97, 90, 211, 208, 195, 115, 245, 198, 57, 140, 244, 140, 28, 165, 164, 4, 167, 121, 180, 215, 42, 69, 137, 222, 1, 141, 216, 195, 37, 169, 130, 15, 190, 53, 225, 241, 6, 93, 133, 231),
        U1(68, 84, 195, 209, 244, 120, 254, 215, 51, 150, 254, 211, 110, 238, 132)
      }), _ARG_3_))
      _ARG_0_:RefreshShareSlot()
      if _ARG_3_ == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.ShareBag then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitView"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_2_.expireTS and 0 < _ARG_2_.expireTS and 0 >= (_ARG_2_.expireTS - require((U1(85, 87, 200, 209, 223, 104, 185, 192, 17, 148, 247, 217, 61, 229, 131, 5, 171, 110, 142, 241, 53, 69, 139))).GetServerTimeInSec()) / 3600 then
      end
      ;(_ARG_2_.extra or {}).bIsShowTip = false
      ;(_ARG_2_.extra or {}).bIsShowBigIcon = _ARG_0_:IsShowBigIcon()
      ;(_ARG_2_.extra or {}).fCheckIconScaleCallback = function(_ARG_0_, _ARG_1_, _ARG_2_)
        do
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if not _ARG_4_ then
      end
      if require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U1(83, 100, 207, 209, 198)
      }))):GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag then
      else
      end
      if _ARG_2_.lock_cnt and 0 < _ARG_2_.lock_cnt then
      end
      if _ARG_2_.planID ~= nil and _ARG_2_.planID ~= 0 then
      end
      do return end
      _ARG_0_ = U1.ins_id
    end
  end,
  ["OnPostInitView"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U1(83, 100, 207, 209, 198)
      }))).isInShareSubscribeSetup then
        if require((table.concat({
          U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
          U1(83, 100, 207, 209, 198)
        }))):FindItemInShareList(_ARG_2_.res_id) then
        else
        end
      elseif require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 202, 44, 188, 142, 31, 137, 108, 160, 230, 53, 78, 152, 225),
        U1(83, 100, 207, 209, 198)
      }))):GetWardrobeEditMode() == require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.FashionBag then
        if _ARG_2_.lock_cnt and _ARG_2_.lock_cnt > 0 then
        end
      elseif _ARG_2_.lock_cnt and _ARG_2_.lock_cnt > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShareBagListUpdate"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateShareSlotList()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshShareBagTips"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_1_ = _ARG_1_ or U2:GetWardrobeEditMode() or require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 38, 166, 144, 66, 145, 106, 163, 224, 51, 67, 133, 246, 64, 158, 235, 212, 39, 169, 136, 30, 179, 68, 172, 245, 50, 78, 152))).EWardrobeEditMode.None
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LocalUpdateWeaponOnShareBag"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_4_ then
      end
      if require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 225, 32, 92, 136, 253, 49, 141, 227, 223, 109, 183, 136, 27, 191, 120, 158, 227, 52, 93, 135, 236),
        U1(88, 100, 197, 221, 200)
      }))):IsDIYWeapon(require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_) and require((U1(85, 87, 200, 209, 223, 104, 185, 208, 18, 140, 251, 152, 63, 164, 144, 5, 165, 37, 166, 229, 51, 72, 149, 252, 12, 140, 164, 209, 34, 169, 131, 14, 185, 121, 164, 203, 53, 93, 131, 226))):GetValidHallDepotItemDataByInsID(_ARG_1_).resID) and _ARG_3_ and require((table.concat({
        U1(85, 87, 200, 209, 223, 104, 185, 207, 17, 158, 243, 213, 125, 170, 129, 13, 178, 106, 163, 170, 45, 67, 128, 250, 13, 182, 254, 195, 34, 182, 184, 29, 160, 122, 181, 245, 35, 99, 154, 226),
        U1(88, 90, 198, 209, 195)
      }))).GetAvatarByUid(DataMgr.roleData.uid) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelfUsingWeaponChange"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:UpdatePendantTab()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
