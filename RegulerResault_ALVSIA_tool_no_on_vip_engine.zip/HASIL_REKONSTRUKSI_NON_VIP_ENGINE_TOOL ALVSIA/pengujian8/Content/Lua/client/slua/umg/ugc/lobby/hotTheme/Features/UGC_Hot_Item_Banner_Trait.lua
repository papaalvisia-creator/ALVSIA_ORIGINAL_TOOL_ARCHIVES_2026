local UGC_Hot_Item_Banner_Trait = {}
local Trait = require("common.trait")
local CUGC_Hot_Item_Banner_Trait = Trait(Trait.TraitPrototype, nil, UGC_Hot_Item_Banner_Trait)
local Config_UGC = require("client.slua.logic.ugc.config_ugc")
local StringUtil = require("common.string_util")
local TableUtil = require("common.table_util")
local C_MaxShowThemeNum = 2

function UGC_Hot_Item_Banner_Trait:InitBannerData()
  log(bWriteLog and "UGC_Hot_Item_Banner_Trait:InitBannerData")
  local logic_ugc_mode = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode)
  self.enterPageIndex = logic_ugc_mode:GetBannerEnterPagerIndex()
  for i, value in pairs(self.data.dataList) do
    if value.set_type == "banner" then
      self.bannerLeftData = value
    elseif value.set_type == "theme" then
      self.bannerRightData = value
    end
  end
  self:InitRightData()
  local NewUGCMainPanel = UIManager.GetUI(UIManager.UI_Config.NewUGCMainPanel)
  if NewUGCMainPanel and NewUGCMainPanel:GetUgcModThemeID() then
    log(bWriteLog and "UGC_HotBanner_TopRec_Theme_Item:OnRefresh NewUGCMainPanel")
    self:OpenTheme(NewUGCMainPanel:GetUgcModThemeID())
    NewUGCMainPanel:ClearUgcModThemeID()
  end
  self:ReqModInfoBatch()
  self:UpdateUI()
end

function UGC_Hot_Item_Banner_Trait:OnRefreshNewPageIterator(widget, index)
  local iterator = self.LoopScrollBox_TabPoint:GetItemData(index)
  local selectPage = self.LoopScrollBox_TabPoint:GetSelectIndex()
  if iterator == selectPage then
    widget.Image_Point:SetActiveColorIndex(1)
  else
    widget.Image_Point:SetActiveColorIndex(0)
  end
end

function UGC_Hot_Item_Banner_Trait:InitRightData()
  if not self.bannerRightData or not self.bannerRightData.showList then
    return
  end
  self.RightShowList = {}
  local num = 0
  for index, value in ipairs(self.bannerRightData.showList) do
    if value.mod_list ~= "" then
      table.insert(self.RightShowList, value)
      num = num + 1
      if num >= C_MaxShowThemeNum then
        break
      end
    end
  end
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  local logic_ugc_hot_page = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_hot_page)
  for i, value in ipairs(self.RightShowList) do
    local tempModIdList = {}
    local str_list = StringUtil.Split(value.mod_list, "|")
    local logic_ugc_new_process = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_new_process)
    local NewProcessList = logic_ugc_new_process:GetModIdList()
    for key, id in pairs(str_list) do
      if not logic_ugc_new_process:CheckIsAbtest() and logic_ugc_new_process:CheckNewProcessThemeId(value) and NewProcessList and next(NewProcessList) then
        local isFind = false
        for _, mod_id in ipairs(NewProcessList) do
          if tonumber(id) == mod_id then
            isFind = true
            break
          end
        end
        if not isFind then
          table.insert(tempModIdList, tonumber(id))
        end
      else
        table.insert(tempModIdList, tonumber(id))
      end
    end
    if logic_ugc_new_process:CheckIsAbtest() and logic_ugc_new_process:CheckNewProcessThemeId(value) then
      tempModIdList = logic_ugc_hot_page:SortModIdList(tempModIdList, NewProcessList)
    end
    local _modList = {}
    local ModInfoList = LogicUGC:BatchGetModInfo(tempModIdList, LogicUGC.C_ModListTypes.MixedBanner, nil, {bExportArray = true})
    if not ModInfoList or not next(ModInfoList) then
      log(bWriteLog and "UGC_Hot_Item_Banner_Trait:ReqModInfoBatch not ModInfoList")
      return
    end
    for _, mod in pairs(ModInfoList) do
      if mod.pub_mod_meta and not mod.pub_mod_meta.perf_off_banner then
        table.insert(_modList, mod.pub_mod_meta)
      end
    end
    value.modInfo_list = _modList
    value.index = i
  end
  if #self.RightShowList < 2 then
    if self.RightShowList[1] and self.RightShowList[1].mod_list then
      local str_list = StringUtil.Split(self.RightShowList[1].mod_list, "|")
      local num = TableUtil.CountTable(str_list)
      if num < 2 then
        log(bWriteLog and "UGC_Hot_Item_Banner_Trait:InitRightData num < 2")
        return
      end
    end
    local temp = TableUtil.CopyTable(self.RightShowList[1])
    table.insert(self.RightShowList, temp)
    for i, data in ipairs(self.RightShowList) do
      data.index = i + 2
    end
  end
  log(bWriteLog and "UGC_Hot_Item_Banner_Trait:InitRightData")
end

function UGC_Hot_Item_Banner_Trait:ReqModInfoBatch()
  if self.displayList then
    self:RspModInfoBatch()
    return
  end
  self.displayList = {}
  if not (self.bannerLeftData and self.bannerLeftData.showList) or not next(self.bannerLeftData.showList) then
    log(bWriteLog and "UGC_Hot_Item_Banner_Trait:ReqModInfoBatch not self.bannerLeftData.showList")
    self.UIRoot.WidgetSwitcher_Content01:SetActiveWidgetIndex(1)
    return
  end
  local StringUtil = require("common.string_util")
  table.sort(self.bannerLeftData.showList, function(a, b)
    return (a.rank_value or 1) < (b.rank_value or 1)
  end)
  for key, value in pairs(self.bannerLeftData.showList) do
    if value.mod_list then
      local str_list = StringUtil.Split(value.mod_list, "|")
      for _k, v in pairs(str_list) do
        local modID = tonumber(v)
        if modID ~= nil then
          table.insert(self.displayList, {
            Id = tonumber(v)
          })
        end
      end
    end
  end
  self:RspModInfoBatch()
end

function UGC_Hot_Item_Banner_Trait:RspModInfoBatch()
  self.loopData = {}
  local modID_list = {}
  local LogicUGC = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC)
  for _, display in pairs(self.displayList) do
    local mod_id = display.Id
    local modInfo = LogicUGC:GetModByWithoutPubCache(mod_id)
    if modInfo and modInfo.pub_mod_meta and not modInfo.pub_mod_meta.perf_off_banner then
      local state = modInfo.pub_mod_meta.base.state_release
      log(bWriteLog and "UGC_Hot_Item_Banner_Trait:RspModInfoBatch state = " .. tostring(state) .. " mod_id = " .. tostring(modInfo.pub_mod_meta.mod_id))
      if state == Config_UGC.E_PublishState.Published then
        local actId = self:InitActivity(modInfo.pub_mod_meta.mod_id)
        table.insert(self.loopData, {
          Mod = modInfo.pub_mod_meta,
          ActivityId = actId
        })
        table.insert(modID_list, mod_id)
      end
    end
  end
  self:UpdateBannerData()
  local logic_ugc_mode = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode)
  if self.playerNumTimer then
    self:RemoveTimer(self.playerNumTimer)
    self.playerNumTimer = nil
  end
  self.playerNumTimer = self:AddTimerLoop(logic_ugc_mode.CONST_REQ_GET_PLAYERNUM_INTERVAL, function()
    logic_ugc_mode:BatchModPlayerReq(modID_list)
  end, TIMER_INFINITE, logic_ugc_mode.CONST_REQ_GET_PLAYERNUM_INTERVAL)
end

function UGC_Hot_Item_Banner_Trait:UpdateUI()
  self:UpdateRightData()
end

function UGC_Hot_Item_Banner_Trait:_GetBannerSignature()
  local signList = {}
  for _, display in ipairs(self.loopData or {}) do
    local modId = display.Mod and display.Mod.mod_id or 0
    signList[#signList + 1] = string.format("%s_%s", tostring(modId), tostring(display.ActivityId or 0))
  end
  return table.concat(signList, "|")
end

function UGC_Hot_Item_Banner_Trait:UpdateBannerData()
  if not self.loopData then
    return
  end
  self.pageCount = #self.loopData
  local signature = self:_GetBannerSignature()
  if self.bannerSignature == signature and self.pageCount > 0 then
    return
  end
  self.bannerSignature = signature
  if self.pageCount > 0 and self.enterPageIndex > self.pageCount then
    self.enterPageIndex = 1
    local logic_ugc_mode = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mode)
    logic_ugc_mode:SetBannerEnterPagerIndex(self.enterPageIndex)
  end
  print(bWriteLog and "UGC_Hot_Item_Banner_Trait:UpdateBannerData pageCount = " .. tostring(self.pageCount) .. ", enterPageeIndex = " .. tostring(self.enterPageIndex))
  self.LoopScrollBox_Mod:InitPageParams(true, 0.8, true, nil, function()
    self:OnScrollHotModPage()
  end)
  self.LoopScrollBox_Mod:SetDataNew(self.loopData, self.enterPageIndex)
  if self.pageCount <= 0 then
    self.UIRoot.WidgetSwitcher_Content01:SetActiveWidgetIndex(1)
    self:SetWidgetVisible(self.UIRoot.LoopScrollBox_TabPoint, false)
    return
  end
  self.UIRoot.WidgetSwitcher_Content01:SetActiveWidgetIndex(0)
  if self.pageCount > 1 then
    self:SetWidgetVisible(self.UIRoot.LoopScrollBox_TabPoint, true)
    local iteratorList = {}
    for i = 1, self.pageCount do
      table.insert(iteratorList, i)
    end
    print(bWriteLog and "UGC_Hot_Item_Banner_Trait:UpdateBannerData #iteratorList = " .. tostring(#iteratorList))
    self.LoopScrollBox_TabPoint:SetData(iteratorList)
    self.LoopScrollBox_TabPoint:Select(self.enterPageIndex)
  else
    self:SetWidgetVisible(self.UIRoot.LoopScrollBox_TabPoint, false)
  end
  self:_ReportTlog(self.loopData[self.enterPageIndex])
end

function UGC_Hot_Item_Banner_Trait:UpdateRightData()
  if not self.bannerRightData then
    return
  end
  log(bWriteLog and "UGC_Hot_Item_Banner_Trait:UpdateRightData")
  log_tree("UGC_Hot_Item_Banner_Trait:UpdateRightData self.RightShowList = ", self.RightShowList)
  self.LoopScrollBox_Collect:SetData(self.RightShowList)
end

function UGC_Hot_Item_Banner_Trait:_ReportTlog(Display)
  if not Display then
    return
  end
  if not self.bFullVisible then
    print(bWriteLog and "UGC_Hot_Item_Banner_Trait:_ReportTlog bFullVisible = false")
    return
  end
  local Logic_UGC_TLog = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_UGC_TLog)
  if Display.Mod then
    Logic_UGC_TLog:ReportModExposure(Display.Mod.mod_id, self.enterPageIndex, {
      scene = TLogEventDefine.UGC_Mod_Exposure_Banner,
      extraParams = {
        bannerActId = Display.ActivityId
      }
    })
  end
end

function UGC_Hot_Item_Banner_Trait:IsTodayUpdate(time)
  time = time or 0
  local TimeUtil = require("client.common.time_util")
  local nowTime = TimeUtil.GetServerTimeInSec()
  local durTime = nowTime - time
  local showNewIconHours = 24
  local cfg = CDataTable.GetTableData("UGCParamConfig", "New_Show_Time")
  if cfg then
    showNewIconHours = cfg.Value
  end
  return 0 < durTime and durTime <= showNewIconHours * 3600
end

function UGC_Hot_Item_Banner_Trait:OnScrollHotModPage()
  local index = self.LoopScrollBox_Mod:GetSelectIndex()
  if not index then
    log(bWriteLog and "UGC_Hot_Item_Banner_Trait:OnScrollHotModPage index = nil")
    return
  end
  log(bWriteLog and "[wzp] UGC_Hot_Item_Banner_Trait:OnScrollHotModPage index = " .. index)
  self.LoopScrollBox_TabPoint:Select(index)
  self:_ReportTlog(self.loopData[index])
end

function UGC_Hot_Item_Banner_Trait:GetPageCount()
  return self.pageCount
end

function UGC_Hot_Item_Banner_Trait:InitActivity(ModId)
  log(bWriteLog and "UGC_Hot_Item_Banner_Trait:InitActivity")
  local logic_ugc_banner_activity = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_banner_activity)
  local ActId = logic_ugc_banner_activity:SearchModIDGetActivityID(ModId)
  if not ActId then
    return
  end
  local ActTaskList = logic_ugc_banner_activity:GetRealDataByFatherActID(ActId)
  if not ActTaskList or not next(ActTaskList) then
    return
  end
  return ActId
end

return CUGC_Hot_Item_Banner_Trait
