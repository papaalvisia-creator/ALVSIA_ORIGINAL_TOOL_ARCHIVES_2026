local XSuit_Custom_UIBP = {}
local ConstAvatarDislay = require("client.slua.traits.DetailComponent.AvatarDisplay.ConstAvatarDislay")
local StoreUtils = require("client.slua.logic.store.utils.store_utils")
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local StringUtil = require("common.string_util")
local TableUtil = require("common.table_util")
local XSuitMoney = require("client.slua.logic.XSuit.Traits.xsuit_money")
local XSuitSchemeFeatureType = require("GameLua.Activity.Commercialize.GamePlay.XSuit.XSuitSchemeFeatureType")
local fashionbag_data = require("client.slua.logic.wardrobe.fashionbag.fashionbag_data")
local enum_JumpType = {
  None = 0,
  Get = 1,
  Equip = 2,
  UnEquip = 3
}
local SUB_ITEM_COLUMN_COUNT = 3
local BOTTOM_COUNT_ITEM_NAME = "XSuit_Count_Item_UIBP_%s"
local TOP_COUNT_ITEM_NAME = "XSuit_Branch_Count_Item_UIBP_%s"
local CUSTOM_TAB_TYPE = {Custom = 1, Collect = 2}
local ENTRY_SOURCE = {Workshop = 1, Spin = 2}

function XSuit_Custom_UIBP:ctor(_, Period, BranchId, level, tabIndex, itemId, entrySource)
  self.Period = Period
  self.BranchId = BranchId
  self.entrySource = entrySource or ENTRY_SOURCE.Workshop
  self.pageIndex = 1
  self.selectIndex = 1
  self.CustomPageList = {}
  self.detailBtnType = 0
  self.level = level and level or 1
  self.lastLevel = 1
  self.initLevel = false
  self.itemList = {}
  self._bCustomListDirty = false
  self.selectTabIndex = tabIndex and tabIndex or 1
  self.branchIndex = 1
  self.MaxPeriod = LogicXSuit.GetMaxPeriod()
  self.itemId = itemId
  self._customPageListCache = {}
  self._itemListCache = {}
end

function XSuit_Custom_UIBP:OnConstruct(Period, BranchId, level, tabIndex, itemId, entrySource)
  XSuit_Custom_UIBP.__super.OnConstruct(self, Period, BranchId, level, tabIndex, itemId, entrySource)
  if not self._bInited then
    self._pendingConstructArgs = {
      Period = Period,
      BranchId = BranchId,
      level = level,
      tabIndex = tabIndex,
      itemId = itemId,
      entrySource = entrySource
    }
    return
  end
  self:ApplyConstructArgs(tabIndex, itemId, entrySource)
end

function XSuit_Custom_UIBP:ApplyConstructArgs(tabIndex, itemId, entrySource)
  self.entrySource = entrySource or ENTRY_SOURCE.Workshop
  if tabIndex and tabIndex ~= self.selectTabIndex then
    self:OnTabSelectChange(tabIndex)
  end
  if not itemId or not (0 < itemId) then
    return
  end
  self.itemId = itemId
  self._bCollectJumpDone = nil
  if self.selectTabIndex == CUSTOM_TAB_TYPE.Collect and self.CollectUI then
    self.CollectUI:ScrollToJumpItem(itemId)
  end
end

function XSuit_Custom_UIBP:_ApplyPendingConstructArgs()
  local args = self._pendingConstructArgs
  if not args then
    return
  end
  self._pendingConstructArgs = nil
  self:ApplyConstructArgs(args.tabIndex, args.itemId, args.entrySource)
end

function XSuit_Custom_UIBP:OnInitialize()
  XSuit_Custom_UIBP.__super.OnInitialize(self)
  self:TryUpdateScene(self.Period or 1, UIManager.UI_Config.XSuit_Custom_UIBP, ConstAvatarDislay.ESceneType.XSuitPreview)
  self:RefreshBranch()
end

function XSuit_Custom_UIBP:RefreshBranch()
  local cacheKey = self.Period .. "_" .. self.BranchId
  if self._customPageListCache[cacheKey] then
    self.CustomPageList = self._customPageListCache[cacheKey]
    self.itemList = self._itemListCache[cacheKey]
    return
  end
  self:CalculateCustomPageList()
  self._customPageListCache[cacheKey] = self.CustomPageList
  self._itemListCache[cacheKey] = self.itemList
end

function XSuit_Custom_UIBP:ClearCache()
  self._customPageListCache = {}
  self._itemListCache = {}
end

function XSuit_Custom_UIBP:CalculateCustomPageList()
  self.CustomPageList = {}
  self.itemList = {}
  local branchLevelList = {}
  local configs = CDataTable.GetTableByFilter("XSuitCommonBranch", "Period", self.Period, "IsBranch", 1)
  for _, config in pairs(configs) do
    local level = LogicXSuit.GetLevelByPeriodSelf(self.Period, config.BranchId)
    branchLevelList[config.BranchId] = level
  end
  local customCfg = CDataTable.GetTableByFilter("XSuitCustomScheme", "Period", self.Period, "Branch", self.BranchId)
  for _, v in pairs(customCfg) do
    local FeaturePageIndex
    for index, pageData in pairs(self.CustomPageList) do
      if pageData.FeatureID == v.FeatureID then
        FeaturePageIndex = index
        break
      end
    end
    if not FeaturePageIndex then
      local FeatureMap = CDataTable.GetTableData("XSuitCustomFeatureMap", v.FeatureID)
      local data = {
        Period = self.Period,
        BranchId = self.BranchId,
        FeatureID = FeatureMap.FeatureID,
        FeatureDesc = LocUtil.GetLocalizeResStr(tonumber(FeatureMap.FeatureDesc)),
        activePath = FeatureMap.SelectIcon,
        inactivePath = FeatureMap.UnselectIcon,
        ItemList = {}
      }
      table.insert(self.CustomPageList, data)
      FeaturePageIndex = #self.CustomPageList
    end
    local data = {
      ItemID = v.ItemID,
      Period = self.Period,
      BranchId = self.BranchId,
      FeatureID = v.FeatureID,
      SchemeID = v.SchemeID,
      IsDefaultColor = v.IsDefaultColor,
      RelateItem = v.RelateItem
    }
    if v.IsDefaultColor == 1 then
      data.bHave = LogicXSuit.IsBranchUnlocked(self.Period, self.BranchId)
      if data.FeatureID == XSuitSchemeFeatureType.Parachute then
        data.bHave = data.bHave and StoreUtils.HasItem(data.RelateItem)
      end
    else
      local missionConfig = CDataTable.GetTableData("XSuitCollect", v.ItemID)
      if not missionConfig then
        log_error(string.format("XSuit_Custom_UIBP:CalculateCustomPageList no XSuitCollect cfg period=%s branch=%s itemID=%s", tostring(self.Period), tostring(self.BranchId), tostring(v.ItemID)))
      end
      local conditions = {}
      local level_list = missionConfig and StringUtil.Split(missionConfig.BranchLevel, ";") or {}
      for _, levelInfo in pairs(level_list) do
        local info = StringUtil.Split(levelInfo, "=")
        conditions[tonumber(info[1])] = tonumber(info[2])
      end
      local bCanGet = true
      for branchId, needLevel in pairs(conditions) do
        if not branchLevelList[branchId] then
          bCanGet = false
          break
        end
        if needLevel > branchLevelList[branchId] then
          bCanGet = false
          break
        end
      end
      data.bHave = bCanGet and StoreUtils.HasItem(data.ItemID)
    end
    table.insert(self.CustomPageList[FeaturePageIndex].ItemList, data)
  end
  for i, v in ipairs(self.CustomPageList) do
    table.sort(v.ItemList, function(a, b)
      if a.bHave == b.bHave then
        return false
      else
        return a.IsDefaultColor == 1
      end
    end)
  end
  local upgradeInfo = LogicXSuit.GetUpgradeInfo(self.Period, true, self.BranchId) or {}
  for i, v in pairs(upgradeInfo) do
    table.insert(self.itemList, v.item_id)
  end
  local commonCfg = CDataTable.GetTableDataByFilter("XSuitCommonBranch", "Period", self.Period, "IsBranch", 0)
  local imagePathList = {}
  if commonCfg and commonCfg.CustomTabImage and commonCfg.CustomTabImage ~= "" then
    imagePathList = StringUtil.Split(commonCfg.CustomTabImage, "|")
  end
  self.loopScrollBoxTabData = {
    {
      TabType = 1,
      TabName = LocUtil.GetLocalizeResStr(200000716),
      bHasSub = true,
      branchList = LogicXSuit.GetWorkshopTabData(),
      ImagePath = 0 < #imagePathList and imagePathList[1] or "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Explain/Frames/XSuit_Ascend_Button_02.XSuit_Ascend_Button_02"
    },
    {
      TabType = 2,
      TabName = LocUtil.GetLocalizeResStr(200000777),
      bHasSub = false,
      ImagePath = 0 < #imagePathList and imagePathList[2] or "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/Explain/Frames/XSuit_Ascend_Button_01.XSuit_Ascend_Button_01"
    }
  }
  self:UpdateCountItemList(TOP_COUNT_ITEM_NAME)
end

function XSuit_Custom_UIBP:RegistEvents()
  XSuit_Custom_UIBP.__super.RegistEvents(self)
  self.LoopScrollBox_SubTabList = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_SubTabList, "client.slua.umg.XSuit_Workshop.Item.XSuit_Tab_Tow_Item")
  self.ExtendedLoopScrollGrid_Item_List = self:InitExtendedScrollGrid(self.UIRoot.ExtendedLoopScrollGrid_Item_List, {
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Custom_Title_Item",
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Custom_Item"
  })
  self.ExtendedLoopScrollBox_Tab = self:InitExtendedScrollBox(self.UIRoot.ExtendedLoopScrollBox_Tab, {
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Tab_Vertical_LevelOne_Text_Item",
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Tab_Vertical_LevelOne_Text_Item_Expand"
  })
  local bpPath = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/XSuit_LevelUp_UIBP.XSuit_LevelUp_UIBP"
  local cfg = LogicXSuit.GetCollectUIInfo(self.Period)
  if cfg and cfg.CollectUIBP and cfg.CollectUIBP ~= "" then
    bpPath = cfg.CollectUIBP
  end
  self.CollectUI = self:CreateChildWindowWithLuaAndBpPath(self.UIRoot.Border_Collect, nil, "client.slua.umg.XSuit_Workshop.Page.XSuit_Collect_UIBP", bpPath, self.Period, self.itemId, true)
  self:SetWidgetVisible(self.UIRoot.Border_Collect, false)
  self:AddOnClickedEventByControl(self.UIRoot.Common_System_Close_UIBP.Button_Close, self.OnButtonClick_Close, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Help_02, self.OnButtonClick_Help, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Detail, self.OnButtonClick_Detail, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Level1, self.OnButtonClick_Level1, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Level3, self.OnButtonClick_Level3, self)
  self:AddOnClickedEventByControl(self.UIRoot.Button_Level7, self.OnButtonClick_Level7, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_CUSTOM_SET, self.OnCustomSet, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_FEATURE_GET, self.OnFeatureGet, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_COLLECT_INFO_UPDATE, self.OnFeatureGet, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_ACTIVE_BRANCH_UPDATE, self.OnActiveBranchUpdate, self)
  self:AddControlEventByControl(self.UIRoot.ExtendedLoopScrollGrid_Item_List, "OnUserScrolled", self.OnScrollIndexChanged, self)
  self:InitParachuteComponent()
end

function XSuit_Custom_UIBP:OnPostInitialize()
  XSuit_Custom_UIBP.__super.OnPostInitialize(self)
  local titleStr = self.selectTabIndex == 1 and LocUtil.GetLocalizeResStr(200000717) or LocUtil.GetLocalizeResStr(200000815)
  self.UIRoot.TextBlock_Title:SetText(titleStr)
  self:UpdateUI()
  self:ChangePanelShow(self.selectTabIndex)
  local targetPageIndex, targetSubIndex = self:GetIndexByItemId(self.itemId)
  local bJumpByItemId = targetPageIndex ~= nil
  if bJumpByItemId then
    self.pageIndex = targetPageIndex
    self.selectIndex = targetSubIndex
  end
  self:OnSelectItem(self.pageIndex, self.selectIndex, bJumpByItemId)
  self:UpdateLevelLockState()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:PlaySpinAudio_BG(1, self.Period)
  self._bInited = true
  self:_ApplyPendingConstructArgs()
end

function XSuit_Custom_UIBP:OnClose()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:PlaySpinAudio_BG(-1, self.Period)
  self:OnCloseScene(ConstAvatarDislay.ESceneType.XSuitPreview)
end

function XSuit_Custom_UIBP:UpdateLevelLockState()
  local current = LogicXSuit.GetLevelByPeriodSelf(self.Period, self.BranchId)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Lock1, current < 1)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Lock3, current < 3)
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Lock7, current < 7)
  printf("XSuit_Custom_UIBP:UpdateLevelLockState refresh star lock, Period:%s, BranchId:%s, currentLevel:%s", tostring(self.Period), tostring(self.BranchId), tostring(current))
end

function XSuit_Custom_UIBP:UpdateUI()
  local baseInfo = LogicXSuit.GetBaseInfo(self.Period, true, self.BranchId)
  self.initData = {
    initEquipList = {}
  }
  table.insert(self.initData.initEquipList, {
    baseInfo.item_id
  })
  self.curScene = ConstAvatarDislay.ESceneType.XSuitPreview
  self:InitComponent_Avatar()
  self:SelectEquippedScheme()
  self:UpdatePageList()
  self:UpdateLevel()
end

function XSuit_Custom_UIBP:SelectEquippedScheme()
  local pageData = self.CustomPageList and self.CustomPageList[self.pageIndex]
  local itemList = pageData and pageData.ItemList
  if not itemList or #itemList <= 0 then
    return
  end
  local equippedSchemeId = LogicXSuit.GetSchemeIdByFeature(self.Period, self.BranchId, pageData.FeatureID)
  local targetIndex
  if equippedSchemeId and 0 < equippedSchemeId then
    for index, itemData in ipairs(itemList) do
      if itemData.SchemeID == equippedSchemeId then
        targetIndex = index
        break
      end
    end
  end
  if not targetIndex then
    for index, itemData in ipairs(itemList) do
      if itemData.IsDefaultColor == 1 then
        targetIndex = index
        break
      end
    end
  end
  if targetIndex and self.selectIndex ~= targetIndex then
    log(bWriteLog and string.format("XSuit_Custom_UIBP:SelectEquippedScheme period=%s branch=%s feature=%s scheme=%s selectIndex=%s", tostring(self.Period), tostring(self.BranchId), tostring(pageData.FeatureID), tostring(equippedSchemeId), tostring(targetIndex)))
    self.selectIndex = targetIndex
  end
end

function XSuit_Custom_UIBP:UpdateTitle()
  local PageData = self.CustomPageList[self.pageIndex]
  if PageData.FeatureID == 1 then
    self.UIRoot.TextBlock_TitleType:SetText(LocUtil.GetLocalizeResStr(200000718))
  else
    self.UIRoot.TextBlock_TitleType:SetText(LocUtil.GetLocalizeResStr(200000719))
  end
  self.UIRoot.TextBlock_TitleLevel:SetText(self.level)
  self.UIRoot.TextBlock_FeatureDesc:SetText(PageData.FeatureDesc)
end

function XSuit_Custom_UIBP:UpdateLevel(level)
  self.level = level or self.level or 1
  local FeatureID = self.SelectedCustomData and self.SelectedCustomData.FeatureID
  if FeatureID == XSuitSchemeFeatureType.Parachute then
    local GlideSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GlideSystem)
    GlideSystem:ExitGlideScene()
  end
  local itemId = self.itemList[self.level]
  self:ShowAvatarDisplay(itemId, {
    bWear = true,
    bDownloadIconInCenter = true,
    bOffsetCenterDownloadRoot = true
  })
  self:SetWidgetVisible(self.UIRoot.Select_Level1, self.level == 1)
  self:SetWidgetVisible(self.UIRoot.Select_Level3, self.level == 3)
  self:SetWidgetVisible(self.UIRoot.Select_Level7, self.level == 7)
  self:UpdateLevelIconColor(self.level)
  self:UpdateItemList()
end

function XSuit_Custom_UIBP:UpdateLevelIconColor(level)
  local uiRoot = self.UIRoot
  local iconList = {
    uiRoot.Image_Icon1,
    uiRoot.Image_Icon2,
    uiRoot.Image_Icon3
  }
  local levelList = {
    1,
    3,
    7
  }
  for index, icon in ipairs(iconList) do
    if icon and icon.SetActiveColorIndex then
      icon:SetActiveColorIndex(level == levelList[index] and 1 or 0)
    end
  end
end

function XSuit_Custom_UIBP:RefreshUnlockDescText(data)
  local desc = self.UIRoot and self.UIRoot.UTRichTextBlock_Desc
  if not desc then
    return
  end
  local bShow = data ~= nil and data.IsDefaultColor == 1 and data.bHave ~= true
  self:SetWidgetVisible(desc, bShow)
  desc:SetText(bShow and LocUtil.GetLocalizeResStr(90089) or "")
end

function XSuit_Custom_UIBP:UpdateDetail()
  local pageData = self.CustomPageList and self.CustomPageList[self.pageIndex]
  local data = pageData and pageData.ItemList and pageData.ItemList[self.selectIndex]
  self.SelectedCustomData = data
  self:RefreshParachuteComponent()
  self:RefreshUnlockDescText(data)
  if not data then
    log_error(string.format("XSuit_Custom_UIBP:UpdateDetail invalid data pageIndex=%s selectIndex=%s", tostring(self.pageIndex), tostring(self.selectIndex)))
    return
  end
  local ItemId = data.ItemID
  local ItemCfg = CDataTable.GetTableData("Item", ItemId)
  self.UIRoot.TextBlock_Name:SetText(ItemCfg.ItemName)
  self.UIRoot.TextBlock_Desc:SetText(ItemCfg.ItemDesc)
  local qualityPath = self:GetQualityPath(ItemCfg.ItemQuality)
  self:SetTexture(self.UIRoot.Image_Quality, qualityPath, {sync = false})
  self:ChangeColorScheme(true, data.SchemeID)
  if self.RelateItem then
    self:StopEmotion()
    if data.FeatureID ~= 5 then
      local GlideSystem = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.GlideSystem)
      GlideSystem:ExitGlideScene()
    end
    self:ShowAvatarDisplay(self.itemList[self.level], {
      bWear = true,
      bDownloadIconInCenter = true,
      bOffsetCenterDownloadRoot = true
    })
    self.RelateItem = nil
  end
  if data.RelateItem > 0 then
    self.RelateItem = data.RelateItem
    local ExtraData = {
      bWear = true,
      enableCameraAnim = true,
      bIsForceScene = data.FeatureID ~= XSuitSchemeFeatureType.Parachute,
      bDownloadIconInCenter = true,
      bOffsetCenterDownloadRoot = true
    }
    self:ShowAvatarDisplay(data.RelateItem, ExtraData)
  end
  if data.bHave then
    local schemeIdCache = LogicXSuit.GetSchemeIdByFeature(self.Period, self.BranchId, data.FeatureID)
    if schemeIdCache and schemeIdCache == data.SchemeID then
      self.detailBtnType = enum_JumpType.UnEquip
      self.UIRoot.TextBlock_Jump:SetText(LocUtil.GetLocalizeResStr(200000723))
    elseif data.IsDefaultColor == 1 and schemeIdCache == 0 then
      self.detailBtnType = enum_JumpType.None
      self.UIRoot.TextBlock_Jump:SetText(LocUtil.GetLocalizeResStr(200000804))
    else
      self.detailBtnType = enum_JumpType.Equip
      self.UIRoot.TextBlock_Jump:SetText(LocUtil.GetLocalizeResStr(200000722))
    end
  else
    self.detailBtnType = enum_JumpType.Get
    self.UIRoot.TextBlock_Jump:SetText(LocUtil.GetLocalizeResStr(200000724))
  end
  local needShowMission = (self.pageIndex ~= 1 or self.selectIndex ~= 1) and not data.bHave
  self:UpdateCountItemList(BOTTOM_COUNT_ITEM_NAME, needShowMission and ItemId or 0)
  local bShowLock = self.detailBtnType == enum_JumpType.Get
  self:SetWidgetVisible(self.UIRoot.Image_7, bShowLock and self.isShow)
  self:SetTexture(self.UIRoot.Image_Jump, "/Game/UMG/Texture_200/Atlas/Common_New_Atlas/Frames/Common_Btn_Huangse_png.Common_Btn_Huangse_png", {sync = false})
end

function XSuit_Custom_UIBP:GetCurPeriodTabData()
  local periodList = LogicXSuit.GetWorkshopTabData() or {}
  for _, info in ipairs(periodList) do
    if info.period == self.Period then
      return info
    end
  end
  log_error(string.format("XSuit_Custom_UIBP:GetCurPeriodTabData period not found, period:%s, maxPeriod:%s, listCount:%s", tostring(self.Period), tostring(self.MaxPeriod), tostring(#periodList)))
  return nil
end

function XSuit_Custom_UIBP:UpdateCountItemList(name, itemId)
  local curProgress, maxProgress = 0, 0
  local periodData = self:GetCurPeriodTabData()
  local branchList = periodData and periodData.branchList or {}
  local itemMissionData
  if itemId and 0 < itemId then
    itemMissionData = LogicXSuit.GetBranchMissionItemData(self.Period, itemId)
  end
  for branchIndex, branchData in ipairs(branchList) do
    local itemCtr = self:GetCountItemCtr(name, branchIndex)
    local branchId = branchIndex - 1
    curProgress = LogicXSuit.GetLevelByPeriodSelf(self.Period, branchId)
    maxProgress = itemMissionData and itemMissionData.conditions[branchId] or 0
    if maxProgress and maxProgress ~= 0 then
      if curProgress >= maxProgress then
        curProgress = maxProgress or curProgress
      end
    else
      maxProgress = not itemId and LogicXSuit.GetActSuitMaxLevelByPeriod(self.Period, branchId) or 0
    end
    if itemCtr then
      self:SetWidgetVisible(itemCtr, 0 < maxProgress)
      self:SetTexture(itemCtr.Image_Icon_01, branchData.branchCountIcon)
      self:SetWidgetVisible(itemCtr.TextBlock_Text, false)
      itemCtr.UTRichTextBlock_Number:SetText(LocUtil.LocalizeResFormat(18141397, curProgress, maxProgress))
    end
  end
end

function XSuit_Custom_UIBP:GetCountItemCtr(name, value)
  return self.UIRoot[string.format(name, value)]
end

function XSuit_Custom_UIBP:GetIndexByItemId(itemId)
  if not itemId or itemId <= 0 then
    return nil
  end
  if not self.itemPageIndexMap then
    log_error("XSuit_Custom_UIBP:GetIndexByItemId itemPageIndexMap is nil, call after UpdateItemList")
    return nil
  end
  return self.itemPageIndexMap[itemId], self.itemSubIndexMap[itemId]
end

function XSuit_Custom_UIBP:JumpToCustomItem(itemId)
  if not itemId or itemId <= 0 then
    log_error(string.format("XSuit_Custom_UIBP:JumpToCustomItem invalid itemId=%s", tostring(itemId)))
    return false
  end
  self:OnTabSelectChange(CUSTOM_TAB_TYPE.Custom, nil, true)
  local targetPageIndex, targetSubIndex = self:GetIndexByItemId(itemId)
  if not targetPageIndex then
    log_error(string.format("XSuit_Custom_UIBP:JumpToCustomItem item not found, itemId=%s period=%s branchId=%s", tostring(itemId), tostring(self.Period), tostring(self.BranchId)))
    return false
  end
  self:OnSelectItem(targetPageIndex, targetSubIndex, true)
  return true
end

function XSuit_Custom_UIBP:UpdateItemList()
  self.mainItemList = {}
  self.subDataMap = {}
  self.itemPageIndexMap = self.itemPageIndexMap or {}
  self.itemSubIndexMap = self.itemSubIndexMap or {}
  TableUtil.Clear(self.itemPageIndexMap)
  TableUtil.Clear(self.itemSubIndexMap)
  for pageIndex, pageData in ipairs(self.CustomPageList) do
    table.insert(self.mainItemList, {
      PageIndex = pageIndex,
      FeatureDesc = pageData.FeatureDesc,
      FeatureID = pageData.FeatureID,
      Level = self.level
    })
    self.subDataMap[pageIndex] = pageData.ItemList
    for subIndex, itemData in ipairs(pageData.ItemList or {}) do
      if self.itemPageIndexMap[itemData.ItemID] == nil then
        self.itemPageIndexMap[itemData.ItemID] = pageIndex
        self.itemSubIndexMap[itemData.ItemID] = subIndex
      end
    end
  end
  self.ExtendedLoopScrollGrid_Item_List:SetData(self.mainItemList)
  for pageIndex, subList in pairs(self.subDataMap) do
    self.ExtendedLoopScrollGrid_Item_List:SetSubData(pageIndex, subList)
  end
  self.ExtendedLoopScrollGrid_Item_List:ScrollToItem(self.pageIndex)
end

function XSuit_Custom_UIBP:UpdatePageList()
  local tabDataList = {}
  for i, pageData in ipairs(self.CustomPageList) do
    table.insert(tabDataList, {
      Index = i,
      FeatureID = pageData.FeatureID,
      FeatureDesc = pageData.FeatureDesc,
      activePath = pageData.activePath,
      inactivePath = pageData.inactivePath
    })
  end
  self.LoopScrollBox_SubTabList:SetData(tabDataList)
  self.LoopScrollBox_SubTabList:Select(self.pageIndex)
  self.branchIndex = self.BranchId + 1
  local periodData = self:GetCurPeriodTabData()
  local branchList = periodData and periodData.branchList
  self.extendedSubItemShowType = self.selectTabIndex == 1
  local data = self.loopScrollBoxTabData[self.selectTabIndex]
  data.bHasSub = (branchList and 0 < #branchList or false) and self.extendedSubItemShowType
  self.ExtendedLoopScrollBox_Tab:SetData(self.loopScrollBoxTabData)
  self.ExtendedLoopScrollBox_Tab:Select(self.selectTabIndex)
  if self.extendedSubItemShowType then
    self.ExtendedLoopScrollBox_Tab:SetSubData(1, self.extendedSubItemShowType and branchList or {})
    self.ExtendedLoopScrollBox_Tab:SelectSub(self.branchIndex)
  end
  self:UpdateDetail()
end

function XSuit_Custom_UIBP:OnScrollIndexChanged(scrollOffset)
  if not self.ExtendedLoopScrollGrid_Item_List then
    return
  end
  local uiRoot = self.ExtendedLoopScrollGrid_Item_List.UIRoot
  if not uiRoot then
    return
  end
  local offset = scrollOffset or 0
  local itemSize = uiRoot.ItemSize or 0
  local padding = uiRoot.Padding or 0
  local subItemSize = uiRoot.SubItemSize and uiRoot.SubItemSize.Y or 0
  local subPadding = uiRoot.SubPadding and uiRoot.SubPadding.Y or 0
  local itemCount = #(self.mainItemList or {})
  if itemCount <= 0 or itemSize + subItemSize + padding + subPadding <= 0 then
    return
  end
  local visibleIndex = itemCount
  local accHeight = 0
  for i = 1, itemCount do
    local subItemCount = #(self.subDataMap and self.subDataMap[i] or {})
    local subItemRowCount = math.ceil(subItemCount / SUB_ITEM_COLUMN_COUNT)
    local itemHeight = itemSize + subItemSize * subItemRowCount + subPadding * (subItemRowCount - 1) + padding
    if offset < accHeight + itemHeight then
      visibleIndex = i
      break
    end
    accHeight = accHeight + itemHeight
  end
  if visibleIndex ~= self.pageIndex then
    self.pageIndex = visibleIndex
    self.LoopScrollBox_SubTabList:Select(self.pageIndex)
    self.LoopScrollBox_SubTabList:RefreshAllItems()
    self:RefreshParachuteComponent()
  end
end

function XSuit_Custom_UIBP:OnButtonClick_Select(widget, index)
  self:PlayAudio(sound_config.close_v1)
  self:OnSelectPage(index)
end

function XSuit_Custom_UIBP:OnButtonClick_Close()
  self:PlayAudio(sound_config.close_v1)
  LogicXSuit.InitLastSelectedBranch()
  if self.entrySource == ENTRY_SOURCE.Spin then
    log_error("XSuit_Custom_UIBP:OnButtonClick_Close from spin, close and back to spin directly")
    self:CloseSelf()
    local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
    if Lobby_camera_manager_module and Lobby_camera_manager_module.SwitchCamera then
      Lobby_camera_manager_module:SwitchCamera(Lobby_camera_manager_module.Enum_CameraID.item_preview)
    end
    local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
    if logic_xsuit_activity then
      logic_xsuit_activity.playingAudio = nil
      logic_xsuit_activity:PlaySpinAudio_BG(1, self.Period)
    end
    return
  end
  local jumpParams = self:GetWorkshopJumpParamsByEquippedColor()
  self:CloseSelf()
  self:JumpBackToWorkshop(jumpParams)
end

function XSuit_Custom_UIBP:IsSelectedItemEquipped(selected)
  if not selected then
    return false
  end
  local period, branchId = self.Period, self.BranchId
  local featureId = tonumber(selected.FeatureID)
  if not period or branchId == nil or not featureId then
    return false
  end
  local equippedSchemeId = LogicXSuit.GetSchemeIdByFeature(period, branchId, featureId)
  if equippedSchemeId == nil then
    return false
  end
  return tonumber(selected.SchemeID) == tonumber(equippedSchemeId)
end

function XSuit_Custom_UIBP:GetEquippedItemInfo(period, branchId, featureId)
  local schemeMap = LogicXSuit.GetSchemeIdByBranch(period, branchId) or {}
  local equippedSchemeId = featureId and 0 < featureId and tonumber(schemeMap[featureId]) or nil
  if equippedSchemeId and 0 < equippedSchemeId then
    local schemeCfg = CDataTable.GetTableData("XSuitCustomScheme", equippedSchemeId)
    if schemeCfg and schemeCfg.ItemID and 0 < schemeCfg.ItemID then
      return schemeCfg.ItemID, tonumber(schemeCfg.FeatureID)
    end
  end
  if featureId and 0 < featureId then
    local defaultCfg = CDataTable.GetTableDataByFilter("XSuitCustomScheme", "Period", period, "Branch", branchId, "FeatureID", featureId, "IsDefaultColor", 1)
    if defaultCfg and defaultCfg.ItemID and 0 < defaultCfg.ItemID then
      return defaultCfg.ItemID, tonumber(defaultCfg.FeatureID)
    end
  end
  return nil, nil
end

function XSuit_Custom_UIBP:GetWorkshopJumpParamsByEquippedColor()
  local period, branchId = self.Period, self.BranchId
  if not period or branchId == nil then
    return nil
  end
  local selected = self.SelectedCustomData
  local colorItemId = selected and tonumber(selected.ItemID) or 0
  local featureId = selected and tonumber(selected.FeatureID) or 0
  if selected and not self:IsSelectedItemEquipped(selected) then
    local equippedItemId, equippedFeatureId = self:GetEquippedItemInfo(period, branchId, featureId)
    if equippedItemId and 0 < equippedItemId then
      log(bWriteLog and string.format("XSuit_Custom_UIBP:GetWorkshopJumpParamsByEquippedColor selected not equipped, use equipped. period:%s, branch:%s, selectedItem:%s, equippedItem:%s", tostring(period), tostring(branchId), tostring(colorItemId), tostring(equippedItemId)))
      colorItemId = equippedItemId
      featureId = equippedFeatureId or featureId
    end
  end
  if not colorItemId or not (0 < colorItemId) then
    local schemeMap = LogicXSuit.GetSchemeIdByBranch(period, branchId) or {}
    local schemeId = featureId and 0 < featureId and schemeMap[featureId] or 0
    if not schemeId or schemeId <= 0 then
      for _, sid in pairs(schemeMap) do
        if sid and 0 < sid then
          schemeId = sid
          break
        end
      end
    end
    local schemeCfg = schemeId and 0 < schemeId and CDataTable.GetTableData("XSuitCustomScheme", schemeId)
    if schemeCfg then
      colorItemId = tonumber(schemeCfg.ItemID) or 0
      if not featureId or not (0 < featureId) then
        featureId = tonumber(schemeCfg.FeatureID) or 0
      end
    end
  end
  local targetLevel = self.level
  local collectCfg, schemeIndex
  if colorItemId and 0 < colorItemId then
    collectCfg, schemeIndex = LogicXSuit.GetWorkshopCollectCfgByItemId(colorItemId, period, branchId, targetLevel)
  end
  if not collectCfg and featureId and 0 < featureId then
    collectCfg, schemeIndex = LogicXSuit.GetWorkshopCollectCfgByFeatureId(featureId, period, branchId, targetLevel, colorItemId)
  end
  if not collectCfg and selected and selected.IsDefaultColor == 1 then
    collectCfg, schemeIndex = LogicXSuit.GetWorkshopBaseAppearanceCfg(period, branchId, targetLevel)
  end
  if not collectCfg then
    log_error(string.format("XSuit_Custom_UIBP:GetWorkshopJumpParamsByEquippedColor collect cfg not found, period:%s, branch:%s, item:%s, feature:%s, level:%s", tostring(period), tostring(branchId), tostring(colorItemId), tostring(featureId), tostring(targetLevel)))
    return nil
  end
  return {
    period = period,
    branchId = branchId,
    level = collectCfg.BranchLevel,
    featureIndex = collectCfg.WFeatureID,
    schemeIndex = schemeIndex
  }
end

function XSuit_Custom_UIBP:JumpBackToWorkshop(params)
  if not params then
    return
  end
  local UI_Config = UIManager.UI_Config
  local mainUI = UIManager.GetUI(UI_Config.XSuit_Workshop_Main_UIBP)
  if not mainUI then
    UIManager.ShowUI(UI_Config.XSuit_Workshop_Main_UIBP, params.period, params.branchId, nil, nil, params.featureIndex, params.schemeIndex)
    return
  end
  mainUI.jumpInfo = mainUI.jumpInfo or {}
  local targetLevel = params.level
  local upgradeInfo = mainUI.CurUpgradeInfo
  if upgradeInfo and targetLevel and not upgradeInfo[targetLevel] then
    local fallbackLevel
    for lv in pairs(upgradeInfo) do
      if type(lv) == "number" and lv <= targetLevel and (not fallbackLevel or lv > fallbackLevel) then
        fallbackLevel = lv
      end
    end
    if fallbackLevel then
      log_error(string.format("XSuit_Custom_UIBP:JumpBackToWorkshop level %s has no data, fallback to %s (period:%s branch:%s)", tostring(targetLevel), tostring(fallbackLevel), tostring(params.period), tostring(params.branchId)))
      targetLevel = fallbackLevel
    end
  end
  if mainUI.selectPeriod ~= params.period and mainUI.SelectOnePeriodTab then
    mainUI.jumpInfo.selectBranchId = params.branchId
    mainUI.jumpInfo.selectLevel = targetLevel
    mainUI.jumpInfo.selectFeatureIndex = params.featureIndex
    mainUI.jumpInfo.selectSchemeIndex = params.schemeIndex
    mainUI:SelectOnePeriodTab(params.period)
  else
    if mainUI.selectBranchId ~= params.branchId and mainUI.SelectOneBranchTab then
      mainUI:SelectOneBranchTab(params.branchId)
    end
    mainUI.selectFeatureIndex = params.featureIndex or mainUI.selectFeatureIndex
    mainUI.jumpInfo.selectSchemeIndex = params.schemeIndex
    if mainUI.SelectOneLevelTab then
      mainUI:SelectOneLevelTab(targetLevel)
    end
  end
  if mainUI.ApplyJumpSchemeIndex then
    mainUI:ApplyJumpSchemeIndex(params.schemeIndex)
  end
  log(bWriteLog and string.format("XSuit_Custom_UIBP:JumpBackToWorkshop period:%s branch:%s level:%s feature:%s schemeIndex:%s", tostring(params.period), tostring(params.branchId), tostring(params.level), tostring(params.featureIndex), tostring(params.schemeIndex)))
end

function XSuit_Custom_UIBP:OnButtonClick_Detail()
  self:PlayAudio(sound_config.close_v1)
  local pageData = self.CustomPageList and self.CustomPageList[self.pageIndex]
  local data = pageData and pageData.ItemList and pageData.ItemList[self.selectIndex]
  if not data then
    log_error(string.format("XSuit_Custom_UIBP:OnButtonClick_Detail invalid data pageIndex=%s selectIndex=%s", tostring(self.pageIndex), tostring(self.selectIndex)))
    return
  end
  local period, branchId, featureId, schemeId = data.Period, data.BranchId, data.FeatureID, data.SchemeID
  local XSuitHandler = require("client.network.Protocol.XSuitHandler")
  if self.detailBtnType == enum_JumpType.None then
    return
  elseif self.detailBtnType == enum_JumpType.Get then
    if data.IsDefaultColor == 1 then
      if LobbySystem.CheckUrlCanJump("game://?module=1009500") then
        GlobalData.JumpUrl("game://?module=1009500")
      elseif featureId == XSuitSchemeFeatureType.Parachute then
        self:OnClickUnlockParachute()
      else
        ShowNotice(7809)
      end
    else
      self:SwitchToCollectTab(data.ItemID)
    end
  elseif self.detailBtnType == enum_JumpType.Equip then
    if data.IsDefaultColor == 1 then
      schemeId = 0
    end
    if data.FeatureID == XSuitSchemeFeatureType.Parachute and data.RelateItem ~= 0 and not self:TryPutonParachute(LogicXSuit.GetNormalParachuteID(data.RelateItem), true) then
      return
    end
    XSuitHandler.send_gold_dress_set_branch_personal_req(period, branchId, featureId, schemeId)
  elseif self.detailBtnType == enum_JumpType.UnEquip then
    XSuitHandler.send_gold_dress_set_branch_personal_req(period, branchId, featureId, 0)
    if data.FeatureID == XSuitSchemeFeatureType.Parachute then
      self:TryPutonParachute(DataMgr.defaultParachuteResID)
    end
  end
end

function XSuit_Custom_UIBP:SwitchToCollectTab(itemId)
  if itemId and 0 < itemId then
    self.itemId = itemId
    self._bCollectJumpDone = nil
  end
  if self.selectTabIndex == CUSTOM_TAB_TYPE.Collect then
    if self.CollectUI then
      self.CollectUI:ScrollToJumpItem(self.itemId)
    end
    return
  end
  self:OnTabSelectChange(CUSTOM_TAB_TYPE.Collect)
  self.ExtendedLoopScrollBox_Tab:Select(CUSTOM_TAB_TYPE.Collect)
end

function XSuit_Custom_UIBP:OnButtonClick_Help()
  self:PlayAudio(sound_config.close_v1)
  local title = self.selectTabIndex == 1 and LocUtil.GetLocalizeResStr(200000717) or LocUtil.GetLocalizeResStr(200000815)
  local content = self.selectTabIndex == 1 and LocUtil.GetLocalizeResStr(200000721) or LocUtil.GetLocalizeResStr(200000816)
  UIManager.ShowUI(UIManager.UI_Config.HelpTip, 0, title, content)
end

function XSuit_Custom_UIBP:OnButtonClick_Level1()
  self:PlayAudio(sound_config.close_v1)
  self:UpdateLevel(1)
end

function XSuit_Custom_UIBP:OnButtonClick_Level3()
  self:PlayAudio(sound_config.close_v1)
  self:UpdateLevel(3)
end

function XSuit_Custom_UIBP:OnButtonClick_Level7()
  self:PlayAudio(sound_config.close_v1)
  self:UpdateLevel(7)
end

function XSuit_Custom_UIBP:OnSelectItem(mainIndex, subIndex, needMust)
  if not mainIndex or not subIndex then
    return
  end
  if mainIndex ~= self.pageIndex or needMust then
    self.pageIndex = mainIndex
    self.selectIndex = 1
    self.LoopScrollBox_SubTabList:Select(self.pageIndex)
    if self.CustomPageList[self.pageIndex].FeatureDesc == LocUtil.GetLocalizeResStr(49516) then
      self.lastLevel = self.initLevel and self.lastLevel or self.level
      self.initLevel = true
      self:UpdateLevel(7)
    elseif self.CustomPageList[self.pageIndex].FeatureID == XSuitSchemeFeatureType.Parachute then
      self.lastLevel = self.initLevel and self.lastLevel or self.level
      self.initLevel = true
      self:UpdateLevel(self.level < 3 and 3 or self.level)
    else
      self:UpdateLevel(self.initLevel and self.lastLevel or self.level)
      self.initLevel = false
    end
  end
  self.selectIndex = subIndex
  self.detailBtnType = 0
  self.ExtendedLoopScrollGrid_Item_List:DeselectSub()
  self.ExtendedLoopScrollGrid_Item_List:SelectSub(mainIndex, subIndex)
  self.ExtendedLoopScrollGrid_Item_List:ScrollToSubItem(mainIndex, subIndex)
  self:UpdateDetail()
end

function XSuit_Custom_UIBP:OnSelectPage(index, must)
  if self.pageIndex == index and not must then
    return
  end
  self.pageIndex = index
  self.selectIndex = 1
  self:UpdateDetail()
  local PageData = self.CustomPageList and self.CustomPageList[index]
  if PageData and PageData.FeatureDesc == LocUtil.GetLocalizeResStr(49516) then
    self.lastLevel = self.initLevel and self.lastLevel or self.level
    self.initLevel = true
    self:UpdateLevel(7)
  elseif PageData and PageData.FeatureID == XSuitSchemeFeatureType.Parachute then
    self.lastLevel = self.initLevel and self.lastLevel or self.level
    self.initLevel = true
    self:UpdateLevel(self.level < 3 and 3 or self.level)
  else
    self:UpdateLevel(self.initLevel and self.lastLevel or self.level)
    self.initLevel = false
  end
  self.LoopScrollBox_SubTabList:Select(self.pageIndex)
  self:OnSelectItem(self.pageIndex, self.selectIndex)
end

function XSuit_Custom_UIBP:OnCustomSet(_, _)
  self:ClearCache()
  self.ExtendedLoopScrollGrid_Item_List:RefreshAllSubItems(self.pageIndex)
  self:UpdateDetail()
end

function XSuit_Custom_UIBP:OnFeatureGet(_, _, featureResId)
  printf("XSuit_Custom_UIBP:OnFeatureGet collect reward got, resid:%s, selectTabIndex:%s, pageIndex:%s", tostring(featureResId), tostring(self.selectTabIndex), tostring(self.pageIndex))
  self:ClearCache()
  self:RefreshBranch()
  self:UpdateItemList()
  self:UpdateDetail()
  self._bCustomListDirty = true
end

function XSuit_Custom_UIBP:OnActiveBranchUpdate(_, _)
  if self._IsClosed or not self.UIRoot then
    return
  end
  log(bWriteLog and string.format("XSuit_Custom_UIBP:OnActiveBranchUpdate refresh custom, selectTabIndex:%s", tostring(self.selectTabIndex)))
  self:ClearCache()
  self:RefreshBranch()
  self:UpdateItemList()
  self:UpdateDetail()
  self:UpdateCountItemList(TOP_COUNT_ITEM_NAME)
  self._bCustomListDirty = true
end

function XSuit_Custom_UIBP:OnTabSelectChange(index, data, isInit)
  if self.selectTabIndex ~= index or isInit then
    self:ChangePanelShow(index)
  end
  local titleStr = index == 1 and LocUtil.GetLocalizeResStr(200000717) or LocUtil.GetLocalizeResStr(200000815)
  self.UIRoot.TextBlock_Title:SetText(titleStr)
  self.selectTabIndex = index
  self.extendedSubItemShowType = index == 1 and not self.extendedSubItemShowType or false
  self.ExtendedLoopScrollBox_Tab:RefreshAllItems()
  local periodData = self:GetCurPeriodTabData()
  local branchList = periodData and periodData.branchList
  self.ExtendedLoopScrollBox_Tab:SetSubData(1, self.extendedSubItemShowType and branchList or {})
  self.ExtendedLoopScrollBox_Tab:SelectSub(self.branchIndex)
end

function XSuit_Custom_UIBP:ChangePanelShow(index)
  self:SetCustomObjectShow(index == CUSTOM_TAB_TYPE.Custom)
  if self.widgetAvatarDisplay and self.widgetAvatarDisplay.SetDownloadPanelVisible then
    local bCustomTab = index == CUSTOM_TAB_TYPE.Custom
    self.widgetAvatarDisplay:SetDownloadPanelVisible(bCustomTab, bCustomTab and self.itemList and self.itemList[self.level] or nil, bCustomTab and {bDownloadIconInCenter = true, bOffsetCenterDownloadRoot = true} or nil)
  end
  if index == CUSTOM_TAB_TYPE.Custom and self._bCustomListDirty then
    self._bCustomListDirty = false
    printf("XSuit_Custom_UIBP:ChangePanelShow dirty list refresh on switch back, pageIndex:%s, selectIndex:%s", tostring(self.pageIndex), tostring(self.selectIndex))
    self:ClearCache()
    self:RefreshBranch()
    self:UpdateItemList()
    self:UpdateDetail()
  end
  if self.CollectUI and index == CUSTOM_TAB_TYPE.Collect then
    self.CollectUI:RefreshData(self.Period)
  end
  self:SetWidgetVisible(self.UIRoot.Border_Collect, index == CUSTOM_TAB_TYPE.Collect)
  if index ~= CUSTOM_TAB_TYPE.Collect and self.CollectUI then
    self.CollectUI:HideBranchTips()
  end
  if index == CUSTOM_TAB_TYPE.Collect and self.CollectUI and not self._bCollectJumpDone then
    self._bCollectJumpDone = true
    self.CollectUI:ScrollToJumpItem(self.itemId)
  end
end

function XSuit_Custom_UIBP:SetCustomObjectShow(isShow)
  self.isShow = isShow
  self:SetWidgetVisible(self.UIRoot.VerticalBox_0, isShow)
  self:SetWidgetVisible(self.UIRoot.Border_4, isShow)
  self:SetWidgetVisible(self.UIRoot.Image_9, isShow)
  self:SetWidgetVisible(self.UIRoot.LoopScrollBox_SubTabList, isShow)
  self:SetWidgetVisible(self.UIRoot.Image_8, isShow)
  self:SetWidgetVisible(self.UIRoot.VerticalBox_4, isShow)
  self:SetWidgetVisible(self.UIRoot.Button_Detail, isShow, true)
  self:SetWidgetVisible(self.UIRoot.HorizontalBox_Star, isShow)
end

function XSuit_Custom_UIBP:OnPeriodSelectChange(branchIndex, data)
  if self.branchIndex == branchIndex then
    return
  end
  self.branchIndex = branchIndex
  self.BranchId = branchIndex - 1
  self.pageIndex, self.selectIndex = 1, 1
  self.ExtendedLoopScrollBox_Tab:SelectSub(self.branchIndex)
  self:RefreshBranch()
  self:UpdateUI()
  self:UpdateLevelLockState()
  self:OnSelectItem(self.pageIndex, self.selectIndex, true)
end

function XSuit_Custom_UIBP:ChangeColorScheme(bPutOn, SchemeID)
  if self.schemeId then
    self:RemoveClothSchemeID(self.schemeId)
    self.schemeId = nil
  end
  if bPutOn then
    self.schemeId = SchemeID
    self:AddClothSchemeID(SchemeID)
  else
    self:RemoveClothSchemeID(SchemeID)
  end
end

function XSuit_Custom_UIBP:GetQualityPath(quality)
  local path = ""
  if quality == 1 then
    path = "/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_04_1_png.T_icon_Airquality_04_1_png"
  else
    path = string.format("/Game/UMG/Texture/Atlas/Quality/Frames/T_icon_Airquality_0%s_1_png.T_icon_Airquality_0%s_1_png", quality, quality)
  end
  return path
end

function XSuit_Custom_UIBP:GetDefaultSchemeData(Period, Branch, FeatureID)
  local Cfg = CDataTable.GetTableDataByFilter("XSuitCustomScheme", "Period", Period, "Branch", Branch, "FeatureID", FeatureID, "IsDefaultColor", 1)
  if not Cfg then
    return nil
  end
  local data = {
    SchemeID = Cfg.SchemeID,
    ItemID = Cfg.ItemID,
    Period = Cfg.Period,
    BranchId = Cfg.Branch,
    FeatureID = Cfg.FeatureID,
    IsDefaultColor = Cfg.IsDefaultColor,
    RelateItem = Cfg.RelateItem
  }
  return data
end

function XSuit_Custom_UIBP:TryPutonDepotItem(ResID)
  local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
  local ItemData = WardrobeData:GetHallDepotItemDataByResIDAndValidExpireTime(ResID)
  if not ItemData then
    return
  end
  local WardrobeLogic = require("client.slua.logic.wardrobe.logic_wardrobe_new")
  WardrobeLogic:wardrobe_puton_req(tonumber(ItemData.insID))
end

function XSuit_Custom_UIBP:TryPutonParachute(ResID, bNoticeWhenMissing)
  local WardrobeData = require("client.slua.logic.wardrobe.wardrobe_data")
  local ItemData = WardrobeData:GetHallDepotItemDataByResIDAndValidExpireTime(ResID)
  if not ItemData then
    if bNoticeWhenMissing then
      ShowNotice(18141492)
    end
    return false
  end
  if fashionbag_data:GetParachute() ~= ItemData.insID then
    self:TryPutonDepotItem(ResID)
  end
  ShowNotice(200000804)
  return true
end

local ui_base = require("client.slua_ui_framework.base")
local Trait = require("common.trait")
local Traits = {
  require("client.slua.logic.XSuit.Traits.xsuit_scene"),
  require("client.slua.umg.XSuit_Workshop.Traits.Xsuit_Avatar_Component"),
  require("client.slua.umg.XSuit_Workshop.Traits.XSuit_Custom_Parachute_Component")
}
local TXSuit_Custom_UIBP = Trait.TraitClass(ui_base, nil, XSuit_Custom_UIBP, Traits)
return TXSuit_Custom_UIBP
