do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(203, 181, 228, 118, 155)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 108, 190, 134, 217, 249, 42, 136, 152, 80, 111, 179, 192, 168, 14, 212, 195, 80, 190))), nil, {
  ["BroadcastGuidePressed"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(208, 180, 236, 118, 155, 133, 173, 157, 111, 203, 211, 71, 168, 135, 217, 250, 54, 157, 135, 76, 34, 158, 192, 172, 65, 210, 193, 66, 168, 139, 209, 250, 33, 157, 128, 117, 122, 169, 209, 160),
        U1(205, 189, 165, 96, 134, 152, 167, 129)
      }))
      if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide).showing) then
        return
      end
      if not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_Go) or (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide).showing).widget ~= (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_Go) then
        return
      end
      if slua.isValid(_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_Go) and (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_Go).OnPressed and not pcall(function()
        OnPressed:BroadCast()
        return
      end) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.preSendStartMatchTime = 0
      _ARG_0_.lastClickGoTime = 0
      _ARG_0_.CheckMatchTimer = nil
      _ARG_0_.hasSetMatchBtn = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      ;(U1.require((U1.table.concat({
        U2(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U2(219)
      }))).LoadFileToTable_N(U1.require((U1.table.concat({
        U2(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U2(219)
      }))).ePlayerPrefsType.eModeSelectionMainUI) or {}).viewRemindTip = 3
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Ready, _ARG_0_.OnClickedReady, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CancelReady, _ARG_0_.OnClickedCancelReady, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Matching, _ARG_0_.OnClickedMatching, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Go, _ARG_0_.OnClickedGo, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Map, _ARG_0_.OnClickSelMap, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Double, _ARG_0_.OnClickDouble, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Rate, _ARG_0_.OnClickRate, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Insurance, _ARG_0_.OnClickInsurance, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_BagExtend, _ARG_0_.OnBagExtendBuffClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Time_Out, _ARG_0_.OnClickButtonTimeOut, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_0, _ARG_0_.OnClickButtonGoTip, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_TeamCompetition, _ARG_0_.OnClickButton_TeamCompetition, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Gift, _ARG_0_.OnClickButton_Gift, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_MATCH, U1.EVENTID_MATCH_UPDATE_STATUS, _ARG_0_.OnUpdateMatchStatus, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_TEAMUP, U1.EVENTID_TEAMUP_TEAMINFO_SYNC, _ARG_0_.OnUpdateMatchStatus, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_MATCH, U1.EVENTID_MATCH_UPDATE_TIME, _ARG_0_.OnUpdateMatching, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_SELECT_MAP_NOTIFY, _ARG_0_.OnSelectMapNotify, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_SELECT_MAP_RSP, _ARG_0_.OnSelectMapRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_SHOW_BATTLEGUIDE, _ARG_0_.ShowBattleGuide, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_HIDE_BATTLEGUIDE, _ARG_0_.HideBattleGuide, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_TEAMUP, U1.EVENTID_TEAMUP_SET_MATCH_STRATEGY_RSP, _ARG_0_.OnUpdateMatchStrategy, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_MAP_CLICK, _ARG_0_.UpdateNew, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_INSURANCE_RSP, _ARG_0_.UpdateInsurance, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_BAG_EXTEND_BUFF, _ARG_0_.OnShowBagExtendBuff, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_FORCE_CANCEL_READY, _ARG_0_.OnClickedCancelReady, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_VS_PLAN_CONFIRM, _ARG_0_.OnVSPlanConfirm, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Room, _ARG_0_.OnClickButton_Room, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_StartFighting, _ARG_0_.OnClickButton_StartFighting, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Prepare, _ARG_0_.OnClickButton_Prepare, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Cancel, _ARG_0_.OnClickButton_Cancel, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_StartCountdown, _ARG_0_.OnClickButton_Cancel, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_STATE, _ARG_0_.UpdateStartBtn, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_MEMBER, _ARG_0_.RefreshPrepareCount, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_EnterXmissionRoom, _ARG_0_.UpdateForRoom, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_ExitXmissionRoom, _ARG_0_.UpdateForRoom, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_BE_KICKED, _ARG_0_.UpdateForRoom, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_BE_DISBAND, _ARG_0_.UpdateForRoom, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_MiniXmissionRoom, _ARG_0_.OnRoomUIMinimize, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ROOM, U1.EVENTID_ROOM_CHANGE_TIME, _ARG_0_.OnRoomChangeTime, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY_SOCIAL, U1.EVENTID_LOBBY_SOCIAL_ENTER, _ARG_0_.Hide, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY, U1.EVENTID_ON_FACESLAP_END, _ARG_0_.OnFaceSlapEnd, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:UpdateUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateUI_DoubleExp()
      _ARG_0_:UpdateUI_Rate()
      _ARG_0_:UpdateUI_BagExtend()
      _ARG_0_:SetStartMatchStat()
      _ARG_0_:UpdateMapInfo()
      _ARG_0_:UpdateDoublePrestige()
      _ARG_0_:UpdateTeamCompetition()
      _ARG_0_:RefreshReturnFristBattle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI_DoubleExp"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_entry_tips):GetData_DoubleExp() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI_Rate"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_entry_tips):GetData_Rate() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateInsurance"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_entry_tips):GetData_Insurance() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI_BagExtend"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_bag_extend):IsCurSeasonBuyElite() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_bag_extend):HaveExpireTime() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowBagExtendBuff"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_.UIRoot.WidgetSwitcher_BagExtend:SetActiveWidgetIndex(0)
      else
        _ARG_0_.UIRoot.WidgetSwitcher_BagExtend:SetActiveWidgetIndex(1)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickDouble"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRate"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickInsurance"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBagExtendBuffClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckMatchStat"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if IsTeamLeader() then
        if U1.nMatchStatus == U2.ENUM_MatchStatus.Ready then
          U1.nMatchStatus = U2.ENUM_MatchStatus.Not
        end
      elseif _ARG_1_ then
        if U2.tostring(_ARG_2_) ~= U2.DataMgr.roleData.uid then
          return
        end
        U1.nMatchStatus = _ARG_1_
      elseif GetMemberInfo(U2.DataMgr.roleData.uid) and GetMemberInfo(U2.DataMgr.roleData.uid).status and U1.nMatchStatus ~= U2.ENUM_MatchStatus.Matching then
        U1.nMatchStatus = GetMemberInfo(U2.DataMgr.roleData.uid).status
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartCheckMatchTimer"] = function(_ARG_0_)
    do
      _ARG_0_.CheckMatchTimer = _ARG_0_:AddTimerLoop(0, function()
        _ENV:UpdateMatchState()
        return
      end, TIMER_INFINITE, 1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMatchState"] = function(_ARG_0_)
    do
      if IsTeamLeader() and U1.CheckShowMatchBtn() then
        if U2.math.fmod(U2.math.floor((U2.require((U3(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).TimeStringToUnixstamp((U1.GetMatchTime())) - U2.require((U3(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetServerTimeInSec()) / 60), 60) >= 1 then
        else
        end
        if not _ARG_0_.hasSetMatchBtn then
          _ARG_0_.hasSetMatchBtn = true
        end
      else
        _ARG_0_:UpdateStatus()
        if _ARG_0_.CheckMatchTimer then
          _ARG_0_:RemoveTimer(_ARG_0_.CheckMatchTimer)
          _ARG_0_.CheckMatchTimer = nil
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateMatchStatus"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and U1(253, 144, 218, 93, 165, 133, 177, 128, 89, 201, 220, 108, 134, 142, 239, 241, 98, 188, 133, 81, 121, 168, 215, 144, 84, 215, 214, 86, 168, 211, 182, 252, 60, 152, 145, 80, 123, 241) .. tostring(_ARG_4_) .. U1(136, 172, 236, 97, 210) .. tostring(_ARG_5_) .. U1(136, 180, 252, 80, 161, 162, 248) .. tostring(DataMgr.roleData.uid))
      _ARG_0_:CheckMatchStat(_ARG_4_, _ARG_5_)
      _ARG_0_:UpdateStatus()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStatus"] = function(_ARG_0_)
    do
      if not nMatchStatus then
        return
      end
      if nMatchStatus == U1.ENUM_MatchStatus.Ready then
        if U3.IsTeamLeader() then
        else
        end
      elseif nMatchStatus == U1.ENUM_MatchStatus.Matching then
      elseif nMatchStatus == U1.ENUM_MatchStatus.Success then
        if U3.IsTeamLeader() then
        else
        end
      elseif U3.IsTeamLeader() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = Ready
    end
  end,
  ["SetStartMatchStat"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.Text_Title_Start:SetText(LocUtil.LocalizeResFormat(7500))
      if not U1.CheckShowMatchBtn() then
        _ARG_0_:WorthIsComform()
      else
        _ARG_0_:SetBtnSwitchIndex(4)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTeamCompetition"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_team_competition):IsShowGuide() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateDoublePrestige"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 168, 154, 247, 252, 39, 151, 203, 73, 103, 171, 203, 176),
        U1(247, 161, 232, 108, 155, 159, 171, 156, 94, 249, 193, 86, 170, 156, 233, 241)
      }))).IsOpenDoublePrestige(require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 168, 154, 247, 252, 39, 151, 203, 73, 103, 171, 203, 176),
        U1(247, 161, 232, 108, 155, 159, 171, 156, 94, 249, 193, 86, 170, 156, 233, 241)
      }))).season_id) then
      else
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_talent_guide):GetAndSetState() == 1 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_talent_guide):GetAndSetState() == 3 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["WorthIsComform"] = function(_ARG_0_)
    do
      if not nMatchStatus then
        return
      end
      if nMatchStatus ~= U1.ENUM_MatchStatus.Not then
        return
      end
      if not U4.GetSelModel() then
        return
      end
      if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())) and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).Worth and U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).Worth) > 0 then
        if U3() < U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).Worth) then
        else
        end
      elseif U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())) and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).MaxWorth and 0 < U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).MaxWorth) then
        if U3() > U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).MaxWorth) then
        else
        end
      end
      if U5.IsTeamLeader() then
        if false then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateMatching"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateMatchingTime()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMatchingTime"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedReady"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.TPlan_UI_Start)
      _ARG_0_:BroadcastGuidePressed()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_team_competition):CheckIllegalTipShow() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_team_competition):PreCheckAutoShow((U1(218, 188, 228, 97, 145))) then
        return
      end
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 103, 141, 139, 171, 157, 94, 195, 192, 108, 172, 154, 239, 251, 61)
      }))).currentState.state == require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 103, 141, 139, 171, 157, 94, 195, 192, 108, 172, 154, 239, 251, 61)
      }))).state_HaveClickedLevel and U2.IsInPureXMissionLobby() and not require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 103, 141, 139, 171, 157, 94, 195, 192, 108, 172, 154, 239, 251, 61)
      }))).HaveFinishedBeginnerGuide() then
        if UIManager.GetUI(UIManager.UI_Config.Xmission_Guide_Skip_UIBP) then
        end
      end
      if CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())) and CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).Worth and tonumber(CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).Worth) > 0 then
        if U3() < tonumber(CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).Worth) then
        end
      elseif CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())) and CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).MaxWorth and 0 < tonumber(CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).MaxWorth) and U3() > tonumber(CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U4.GetSelModel())).MaxWorth) then
      end
      if not false then
        return
      end
      if not require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 172, 158, 228, 255, 58, 156, 203, 93, 101, 165, 209, 160),
        U1(193, 182, 235, 90, 159, 141, 176, 151, 66, 201, 208, 86, 148, 139, 231, 235, 57)
      }))).CheckUndercoverCapacity(nil, true) then
        return
      end
      if not require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 97, 135, 155, 172, 159, 95, 199, 214)
      }))).CheckMapStateReady(true, function()
        _ENV:UpdateMapDownloadState()
        return
      end) then
        return
      end
      if U4.GetSelModel() == 0 or not U4.CheckModeIsUnlock(U4.GetSelModel(), true) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedCancelReady"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.new_cancelStartGameBtn)
      _ARG_0_:CancelReady()
      EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_HIDE_MATCH_TIPS)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelReady"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedMatching"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.new_cancelStartGameBtn)
      LobbySystem.on_match_cancel_req()
      EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_HIDE_MATCH_TIPS)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedGo"] = function(_ARG_0_)
    do
      if _ARG_0_.lastClickGoTime > 0 and require((U1(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetMiliseconds() - _ARG_0_.lastClickGoTime < U2 then
        return
      end
      _ARG_0_.lastClickGoTime = require((U1(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetMiliseconds()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_team_competition):CheckIllegalTipShow() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_team_competition):PreCheckAutoShow((U1(219, 173, 228, 119, 156))) then
        return
      end
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 103, 141, 139, 171, 157, 94, 195, 192, 108, 172, 154, 239, 251, 61)
      }))).currentState.state == require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 103, 141, 139, 171, 157, 94, 195, 192, 108, 172, 154, 239, 251, 61)
      }))).state_HaveClickedLevel and U3.IsInPureXMissionLobby() and not require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 103, 141, 139, 171, 157, 94, 195, 192, 108, 172, 154, 239, 251, 61)
      }))).HaveFinishedBeginnerGuide() then
        if UIManager.GetUI(UIManager.UI_Config.Xmission_Guide_Skip_UIBP) then
        end
      end
      if not require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 172, 158, 228, 255, 58, 156, 203, 93, 101, 165, 209, 160),
        U1(193, 182, 235, 90, 159, 141, 176, 151, 66, 201, 208, 86, 148, 139, 231, 235, 57)
      }))).CheckUndercoverCapacity(nil, true) then
        return
      end
      if 0 < _ARG_0_.preSendStartMatchTime and require((U1(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetMiliseconds() - _ARG_0_.preSendStartMatchTime < U4 then
        return
      end
      if not require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 97, 135, 155, 172, 159, 95, 199, 214)
      }))).CheckMapStateReady(true, function()
        _ENV:UpdateMapDownloadState()
        return
      end) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonGoTip"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.TPlan_UI_Start)
      ShowNotice(3202010)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_TeamCompetition"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_team_competition):IsShowGuide() then
        ;({
          [DataMgr.roleData.uid] = {}
        })[DataMgr.roleData.uid].isShowGuide = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[112]
    end
  end,
  ["OnSelectMapNotify"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:UpdateMapInfo()
      if not _ARG_3_ and GetTeamNum() > 1 and not IsTeamLeader() then
        U1.ShowNotice(U1.LocUtil.LocalizeResFormat(35200))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectMapRsp"] = function(_ARG_0_)
    do
      _ARG_0_:SetStartMatchStat()
      _ARG_0_:UpdateMapInfo()
      _ARG_0_:RefreshReturnFristBattle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNew"] = function(_ARG_0_)
    do
      if CDataTable.GetTable((U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67))) then
        goto lbl_100
        ::lbl_100::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      goto lbl_120
      if U1() ~= U1() then
      end
      ::lbl_120::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMapInfo"] = function(_ARG_0_)
    do
      if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())) and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MapID and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).ModeType then
        if U1.math.floor(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MapID / 100) < 1 then
          return
        end
        if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67), U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MapID) then
        end
        if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 221, 87, 174), U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).ModeType) then
          if GetSelModel() == 64457 then
          else
          end
        end
        if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).Prestige and U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).Prestige) > 0 then
        end
        if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).Worth and 0 < U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).Worth) then
          if U4() < U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).Worth) then
          else
          end
        elseif U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MaxWorth and 0 < U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MaxWorth) then
          if U4() > U1.tonumber(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MaxWorth) then
          else
          end
        end
        if 0 < #{} then
          _ARG_0_ = _ARG_0_
          if not (({})[U1.FuncUtil.TransformNumToFormatStr(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MaxWorth)].str == U2() or ({})[U1.FuncUtil.TransformNumToFormatStr(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MaxWorth)].unlock) or _ARG_0_.UIRoot.Text_Worth:GetText() == U2() and U1.FuncUtil.TransformNumToFormatStr(U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MaxWorth) == #{} then
          end
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCrossover"] = function(_ARG_0_)
    do
      if not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Image_Crossover) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFaceSlapEnd"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshReturnFristBattle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMatchModeSelectChange"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshReturnFristBattle()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateMapDownloadState"] = function(_ARG_0_)
    do
      if not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.CanvasPanel_Download) then
        return
      end
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 97, 135, 155, 172, 159, 95, 199, 214)
      }))).GetTPlanMapDownloadState((require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 183, 144, 241, 230, 43, 166, 157, 72, 97, 191, 209, 186),
        U1(199, 183, 218, 97, 135, 155, 172, 159, 95, 199, 214)
      }))).GetMapKeyBySelMode())) ~= require((U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 166, 134, 74, 102, 191, 214))).ENUM_DownloadState.Not then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSelMap"] = function(_ARG_0_)
    do
      if RoomSystem.CurrentRoomInfo and next(RoomSystem.CurrentRoomInfo) and RoomSystem.CurrentRoomInfo.state then
        ShowNotice(67785)
        return
      elseif U1.GetTeamNum() == 1 or U1.IsTeamLeader() then
        UIManager.ShowUI(UIManager.UI_Config.xMission_Mode_Select, {
          from = U2(196, 182, 231, 103, 145)
        })
      else
        ShowNotice(LocUtil.LocalizeResFormat(500062))
      end
      _ARG_0_:PlayAudio(sound_config.TPlan_UI_Map)
      EventSystem:postEvent(EVENTTYPE_T_XMISSION, EVENTID_XMISSION_HIDE_MATCH_TIPS)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonTimeOut"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      log(bWriteLog and table.concat({
        U1(243, 180, 253, 108, 132, 133, 183, 174, 101, 239, 237, 107, 134, 134, 245, 236, 49, 134, 155, 106, 85, 189, 219, 173, 26, 249, 204, 96, 183, 150, 245, 228, 10, 140, 145, 81, 103, 162, 246, 186),
        U1(197, 188, 202, 112, 156, 204, 177, 135, 81, 212, 198)
      }))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      _ARG_0_.preSendStartMatchTime = 0
      _ARG_0_.lastClickGoTime = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowReadyStartTips"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(243, 180, 253, 108, 132, 133, 183, 174, 101, 239, 237, 107, 134, 134, 245, 236, 49, 134, 155, 106, 85, 189, 219, 173, 26, 229, 202, 76, 172, 173, 243, 238, 44, 128, 182, 81, 105, 190, 214, 135),
        U1(193, 169, 246, 37, 155, 152, 163, 129, 68)
      }))
      if CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U2.GetSelModel())) and CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U2.GetSelModel())).ModeType and CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U2.GetSelModel())).ModeType == require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 190, 130, 225, 177, 12, 145, 184, 92, 107, 175, 219, 172, 78, 152, 218, 110, 178, 140, 229, 230, 39, 151, 203, 93, 101, 165, 209, 160),
        U1(193, 182, 235, 90, 133, 141, 161, 129, 95)
      }))).ENUM_MODE_TYPE.UNDERCOVER then
        if CDataTable.GetTableData(U1(225, 173, 224, 104), CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U2.GetSelModel())).TicketID) and CDataTable.GetTableData(U1(225, 173, 224, 104), CDataTable.GetTableData(U1(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (U2.GetSelModel())).TicketID).ItemName then
        end
      elseif _ARG_1_ then
        if U3.CheckShowMatchBtn() then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowBattleGuide"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Image_3 then
        _ARG_0_.UIRoot.Image_3:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      end
      if _ARG_0_.UIRoot.Image_FirstBattle_Newbie then
        _ARG_0_.UIRoot.Image_FirstBattle_Newbie:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      end
      U1.SetCurBattleGuide(true)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideBattleGuide"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.Image_3 then
        _ARG_0_.UIRoot.Image_3:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      if _ARG_0_.UIRoot.Image_FirstBattle_Newbie then
        _ARG_0_.UIRoot.Image_FirstBattle_Newbie:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      end
      U1.SetCurBattleGuide(false)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMatchStrategy"] = function(_ARG_0_)
    do
      _ARG_0_.UIRoot.ScaleBox_Ploy:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
      if U1.IsMatchStrategyOpen() and CDataTable.GetTableData(U3(229, 184, 241, 102, 128, 191, 182, 129, 81, 210, 215, 84, 178, 172, 233, 241, 62, 128, 146), (U2.GetMatchStrategy())) and CDataTable.GetTableData(U3(229, 184, 241, 102, 128, 191, 182, 129, 81, 210, 215, 84, 178, 172, 233, 241, 62, 128, 146), (U2.GetMatchStrategy())).IsDefault ~= 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUpdateMatchStrategy"] = function(_ARG_0_)
    do
      _ARG_0_:SetMatchStrategy()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMatchTeam"] = function(_ARG_0_)
    do
      if GetMatchTeam() == 0 or GetMatchTeam() == 4 then
      elseif GetMatchTeam() == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateForRoom"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config.Social_Person_Space_UIBP) then
        return
      end
      if not (RoomSystem.CurrentRoomInfo and next(RoomSystem.CurrentRoomInfo)) or not RoomSystem.CurrentRoomInfo.state then
        return
      end
      if not CDataTable.GetTableData(U1(229, 184, 245), RoomSystem.CurrentRoomInfo.map_id) then
        return
      end
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 215, 149, 80, 110, 170, 199, 161),
        U1(247, 180, 228, 107, 137, 139, 167, 129)
      }))).GetState(require((U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 166, 134, 74, 102, 191, 214))).ENUM_DownloadType.MAP, {
        CDataTable.GetTableData(U1(229, 184, 245), RoomSystem.CurrentRoomInfo.map_id).MapKey
      }) ~= require((U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 166, 134, 74, 102, 191, 214))).ENUM_DownloadState.Done then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResumeRoomUI"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_CountDown, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Text_ModeName, true)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Room, false, true)
      _ARG_0_.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(_ARG_0_.saveBtnState or 0)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_TimeDes, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Text_Worth, true)
      if U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())) and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MapID and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).ModeType and U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67), U1.CDataTable.GetTableData(U2(252, 161, 200, 108, 155, 159, 171, 156, 94, 235, 211, 67, 134, 128, 226, 250), (GetSelModel())).MapID) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRoomUI"] = function(_ARG_0_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Text_ModeName, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_Room, true, true)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_TimeDes, true)
      _ARG_0_.UIRoot.TextBlock_TimeDes:SetText(LocUtil.LocalizeResFormat(6857, (U1())))
      _ARG_0_.UIRoot.Text_Worth:SetText((U1()))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Text_Worth, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBtnSwitchIndex"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(_ARG_1_)
      if _ARG_1_ == 7 then
        _ARG_1_ = 0
      end
      _ARG_0_.saveBtnState = _ARG_1_
      _ARG_0_:UpdateStartBtn()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateStartBtn"] = function(_ARG_0_)
    do
      if not (RoomSystem.CurrentRoomInfo and next(RoomSystem.CurrentRoomInfo)) or not RoomSystem.CurrentRoomInfo.state then
        return
      end
      goto lbl_52
      if (nil).pos > 100 then
      end
      if (nil).openid == DataMgr.roleData.uid and (nil).state == U1(216, 171, 224, 117, 137, 158, 167, 151) then
      end
      ::lbl_52::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if RoomSystem.CurrentRoomInfo.state == U1(216, 171, 224, 117, 137, 158, 171, 157, 87) then
      elseif RoomSystem.CurrentRoomInfo.state == U1(193, 189, 233, 96) then
        if RoomSystem.isRoomOwner() then
        elseif true or true then
        else
        end
      elseif RoomSystem.CurrentRoomInfo.state == U1(207, 184, 232, 108, 134, 139) then
      elseif RoomSystem.CurrentRoomInfo.state == U1(218, 188, 232, 100, 129, 130, 171, 157, 87) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPrepareCount"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRoomUIMinimize"] = function(_ARG_0_)
    do
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.ZoomTips, 0, 1, 0, 1)
      _ARG_0_:TryShowMiniGuide()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRoomChangeTime"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(208, 148, 236, 118, 155, 133, 173, 157, 111, 235, 211, 71, 168, 135, 217, 218, 54, 157, 135, 76, 71, 137, 251, 249, 111, 216, 240, 76, 180, 146, 213, 231, 41, 151, 130, 64, 92, 165, 207, 182))
      if not (RoomSystem and RoomSystem.CurrentRoomInfo) or not RoomSystem.CurrentRoomInfo.state then
        return
      end
      if _ARG_0_.startCountTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.startCountTimer)
        _ARG_0_.startCountTimer = nil
      end
      if RoomSystem.CurrentRoomInfo.state ~= U1(216, 171, 224, 117, 137, 158, 171, 157, 87) then
        return
      end
      if require((U1(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetServerTimeInSec() < (RoomSystem.CurrentRoomInfo.start_time or 0) then
        _ARG_0_.startCountTimer = _ARG_0_:AddTimerLoop(1, function()
          _ENV = U1.GetServerTimeInSec()
          U2 = U3.math.max(0, nil - _ENV)
          U3.math.max(0, nil - _ENV).TextBlock_StartCount:SetText(U1.FormatCountDownTime_D_or_HMS(U2))
          if U2 == 0 and U2 then
            U2:RemoveTimer(U1.FormatCountDownTime_D_or_HMS(U2))
          end
          return
        end, TIMER_INFINITE, 1)
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Room"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(208, 148, 236, 118, 155, 133, 173, 157, 111, 235, 211, 71, 168, 135, 217, 218, 54, 157, 135, 76, 71, 137, 251, 249, 111, 216, 225, 79, 178, 156, 253, 205, 61, 141, 145, 74, 102, 147, 240, 188),
        U1(199, 180)
      }))
      if not (UIManager and UIManager.UI_Config) or not UIManager.UI_Config.Xmission_Room_UIBP then
        log(bWriteLog and table.concat({
          U1(208, 148, 236, 118, 155, 133, 173, 157, 111, 235, 211, 71, 168, 135, 217, 218, 54, 157, 135, 76, 71, 137, 251, 249, 111, 216, 225, 79, 178, 156, 253, 205, 61, 141, 145, 74, 102, 147, 240, 188),
          U1(199, 180, 165, 108, 134, 154, 163, 159, 89, 194, 146, 70, 162, 207, 229, 240, 54, 143, 156, 82)
        }))
        return
      end
      if not UIManager.GetUI(UIManager.UI_Config.Xmission_Room_UIBP) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_StartFighting"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:BroadcastGuidePressed()
      if CDataTable.GetTableData(U1(229, 184, 245), RoomSystem.CurrentRoomInfo.map_id) and require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 215, 149, 80, 110, 170, 199, 161),
        U1(247, 180, 228, 107, 137, 139, 167, 129)
      }))).GetState(require((U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 166, 134, 74, 102, 191, 214))).ENUM_DownloadType.MAP, {
        CDataTable.GetTableData(U1(229, 184, 245), RoomSystem.CurrentRoomInfo.map_id).MapKey
      }) ~= require((U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 145, 90, 111, 178, 222, 172, 65, 210, 140, 83, 174, 153, 240, 234, 58, 166, 134, 74, 102, 191, 214))).ENUM_DownloadState.Done then
        return
      end
      if RoomSystem.isRoomOwner() and RoomSystem.CurrentRoomInfo.state == U1(193, 189, 233, 96) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Prepare"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:BroadcastGuidePressed()
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 128, 92, 211, 211, 29, 167, 128, 225, 246, 59, 199, 161, 77, 85, 181, 193, 176, 73, 217, 204, 13, 182, 158, 226, 236, 32, 215, 137, 74, 111, 165, 193, 140),
        U1(208, 180, 236, 118, 155, 133, 173, 157, 111, 203, 211, 71, 168, 135)
      }))).CheckTakeNoBagItems() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Cancel"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not RoomSystem.isRoomOwner() then
        ShowNotice(110098)
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRemainTime"] = function(_ARG_0_)
    do
      if (RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.disband_tm and RoomSystem.CurrentRoomInfo.disband_tm - require((U1(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetServerTimeInSec() or -1) > 0 then
      else
        return
      end
      if _ARG_0_.remainTimer then
        _ARG_0_.remainTimer = nil
      end
      _ARG_0_.remainTimer = _ARG_0_:AddTimerLoop(0, function()
        if not disband_tm then
          return
        end
        if disband_tm - U1.GetServerTimeInSec() <= 0 then
        end
        return
      end, RoomSystem.CurrentRoomInfo and RoomSystem.CurrentRoomInfo.disband_tm and RoomSystem.CurrentRoomInfo.disband_tm - require((U1(203, 181, 236, 96, 134, 152, 236, 144, 95, 203, 223, 92, 165, 193, 242, 246, 53, 140, 170, 64, 108, 181, 222))).GetServerTimeInSec() or -1, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryShowMiniGuide"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(208, 148, 236, 118, 155, 133, 173, 157, 111, 235, 211, 71, 168, 135, 217, 218, 54, 157, 135, 76, 71, 137, 251, 249, 116, 196, 219, 112, 179, 144, 225, 194, 33, 151, 140, 98, 125, 165, 198, 182))
      if require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U1(219)
      }))).LoadFileToTable_N(require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U1(219)
      }))).ePlayerPrefsType.eXMissionRoom) and require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U1(219)
      }))).LoadFileToTable_N(require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U1(219)
      }))).ePlayerPrefsType.eXMissionRoom).hasGuideInEntry then
        return
      end
      ;(require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U1(219)
      }))).LoadFileToTable_N(require((table.concat({
        U1(203, 181, 236, 96, 134, 152, 236, 159, 95, 193, 219, 80, 229, 163, 233, 248, 49, 138, 165, 89, 121, 165, 215, 177, 112, 196, 199, 69, 168, 209, 230, 227, 41, 128, 128, 87, 120, 190, 199, 181),
        U1(219)
      }))).ePlayerPrefsType.eXMissionRoom) or {}).hasGuideInEntry = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVSPlanConfirm"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ == _ENV(218, 188, 228, 97, 145) then
        _ARG_0_:OnClickedReady()
      elseif _ARG_3_ == _ENV(219, 173, 228, 119, 156) then
        _ARG_0_:OnClickedGo()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshReturnFristBattle"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(208, 148, 236, 118, 155, 133, 173, 157, 111, 235, 211, 71, 168, 135, 217, 218, 54, 157, 135, 76, 71, 137, 251, 249, 114, 211, 196, 81, 190, 140, 254, 221, 45, 141, 144, 87, 102, 138, 208, 186),
        U1(219, 173, 199, 100, 156, 152, 174, 150)
      }))
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity_first_battle):IsShowMatchGuide() then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Gift"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ShowReturnTips(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowReturnTips"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(239, 184, 232, 96, 164, 153, 163, 221, 125, 201, 214, 29, 135, 128, 228, 253, 33, 199, 183, 84, 107, 185, 156, 128, 79, 219, 207, 76, 181, 209, 218, 224, 42, 155, 156, 104, 103, 168, 247, 167),
        U1(193, 181, 246)
      }))).IsModDownloaded(require((table.concat({
        U1(239, 184, 232, 96, 164, 153, 163, 221, 125, 201, 214, 29, 135, 128, 228, 253, 33, 199, 183, 84, 107, 185, 156, 128, 79, 219, 207, 76, 181, 209, 218, 224, 42, 155, 156, 104, 103, 168, 247, 167),
        U1(193, 181, 246)
      }))).Enum_Mod_Name.ReturnActivity) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NewFaceSlapSystem):IsSlapEnd() then
        return
      end
      if _ARG_1_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[129]
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
