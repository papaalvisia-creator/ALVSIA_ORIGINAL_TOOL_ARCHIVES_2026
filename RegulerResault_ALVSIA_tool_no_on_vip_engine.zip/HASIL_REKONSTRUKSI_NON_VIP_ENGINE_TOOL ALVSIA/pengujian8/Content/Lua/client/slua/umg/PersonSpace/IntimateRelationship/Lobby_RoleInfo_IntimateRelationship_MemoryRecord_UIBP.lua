local Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP = {}

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:ctor(_, uid, isNewStyle)
  self.uid = uid and tonumber(uid) or 0
  self.isNewStyle = isNewStyle
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnInitialize()
  self.LoopScrollBox_0 = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_0, "client.slua.umg.PersonSpace.IntimateRelationship.Item.Lobby_IntimateRelationship_MemoryRecord_Item_UIBP")
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:RegistEvents()
  if slua.isValid(self.UIRoot.Button_More) then
    self:AddOnClickedEventByControl(self.UIRoot.Button_More, self.OnClickButton_More, self)
  else
    log_error("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:RegistEvents Button_More is nil, skip OnClickButton_More bind")
  end
  self:AddCommonEvent(EVENTTYPE_PERSON_SPACE, EVENTID_PERSONSPACE_INTIMACY_DATA_UPDATE, self.UpdateIntimacyUI, self)
  self:AddCommonEvent(EVENTTYPE_ROLEINFO, EVENTID_CUMULATIVE_ROLEINFO_INTERACT_RECORD, self.UpdateOtherFriendDataUI, self)
  self:AddControlEventByControl(self.UIRoot.Common_Avatar_BP, "OnClickItemCallback", self.OnClickAvatarCallback, self, true)
  self:AddControlEventByControl(self.UIRoot.Common_Avatar_BP_1, "OnClickItemCallback", self.OnClickAvatarCallback, self, false)
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnPostInitialize()
  self:ReqData()
  self:UpdateUI()
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:RefreshData(uid)
  printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:RefreshData uid:%s", uid)
  if not uid then
    return
  end
  self.uid = uid and tonumber(uid) or 0
  self:ReqData()
  self:UpdateUI()
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnClose()
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnClickButton_More()
  log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnClickButton_More")
  self:PlayAudio(sound_config.click_v1)
  UIManager.ShowUI(UIManager.UI_Config.Lobby_RoleInfo_InteractRecord_UIBP, self.uid)
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnClickAvatarCallback(bSelf)
  self:PlayAudio(sound_config.click_v1)
  local uid = bSelf and DataMgr.roleData.uid or self.uid
  local LogicFitVersionDownload = require("client.slua.logic.download.fit.logic_fitVersion_download")
  if not LogicFitVersionDownload.IsFitLobbyResDownloaded() then
    LogicFitVersionDownload.ShowFullLobbyResDownloadPopup()
    return
  end
  local RoleInfoMainSystem = require("client.logic.roleinfo.logic_new_roleinfo")
  local SocialPersonSpaceSystem = require("client.slua.logic.lobby.Left.logic_social_person_space")
  SocialPersonSpaceSystem.EnterPersonSpace(uid, false, RoleInfoMainSystem.RoleInfoOpenFromType.MemoryRecord)
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateUI()
  log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateUI")
  self:UpdateBaseInfoUI()
  self:UpdateIntimacyUI()
  self:UpdateOtherFriendDataUI()
  self:UpdateMemoryRecordUI()
  self:UpdateWaitUI()
  self.UIRoot.Text_More:SetText(LocUtil.GetLocalizeResStr(77949))
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateWaitUI()
  self:SetWidgetVisible(self.UIRoot.Text_Wait, false)
  if not self.isNewStyle then
    log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateWaitUI is not NewStyle")
    return
  end
  local LOC_WAIT_TEXT = 78801307
  local TableUtil = require("common.table_util")
  local rejoinTime = TableUtil.GetTableValue(DataMgr.roleData, "back_user_data", "rejoin_start_time") or 0
  if rejoinTime == 0 then
    log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateWaitUI rejoinTime is invalid")
    return
  end
  local logic_friend_interact_record = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record)
  local data = logic_friend_interact_record:GetCumulativeInteractRecordData(self.uid)
  if data then
    local add_friend_date = data.add_friend_date or 0
    if rejoinTime < add_friend_date then
      self:SetWidgetVisible(self.UIRoot.Text_Wait, false)
      return
    end
    log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateWaitUI")
    local noLoginDays = TableUtil.GetTableValue(DataMgr.roleData, "back_user_data", "no_login_days") or 0
    local TimeUtil = require("client.common.time_util")
    local dateStr = TimeUtil.FormatTime_YMD(rejoinTime)
    self.UIRoot.Text_Wait:SetText(LocUtil.LocalizeResFormat(LOC_WAIT_TEXT, dateStr, noLoginDays))
    self:SetWidgetVisible(self.UIRoot.Text_Wait, true)
  end
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateBaseInfoUI()
  if self.uid == nil or self.uid == 0 then
    printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateIntimacyUI uid is invalid %s", self.uid)
    return
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local LobbySocialSystem = require("client.slua.logic.lobby.Left.logic_lobby_social")
  local myProfile = LobbySocialSystem.GetSelfProfile()
  self.UIRoot.Common_Avatar_BP:InitView(1, myProfile.uid, myProfile.picUrl, tonumber(myProfile.sex) + 1, myProfile.cur_avatar_box_id, myProfile.level, false, "")
  self.UIRoot.Text_Name:SetText(myProfile.nickName)
  self.UIRoot.Common_Gender_UIBP:LoadIcon(myProfile.uid)
  local profile2 = logic_profile:GetLocalProfile(self.uid)
  if profile2 then
    self.UIRoot.Common_Avatar_BP_1:InitView(1, self.uid, profile2.picUrl, tonumber(profile2.sex) + 1, profile2.cur_avatar_box_id, profile2.level, false, "")
    self.UIRoot.Text_Name_1:SetText(profile2.nickName)
    self.UIRoot.Common_Gender_UIBP_1:LoadIcon(self.uid)
  end
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateIntimacyUI()
  if self.uid == nil or self.uid == 0 then
    printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateIntimacyUI uid is invalid %s", self.uid)
    return
  end
  local LogicFriend = require("client.slua.logic.friend.logic_new_friend")
  local relation = LogicFriend.GetRelation(self.uid)
  local iconPath = "/Game/UMG/Texture_200/Atlas/Common_New_Atlas/Frames/Common_Icon_Relationship_png.Common_Icon_Relationship_png"
  local relationText = LocUtil.GetLocalizeResStr(12663)
  if relation and 0 < relation then
    local IntimacyUtils = require("client.slua.logic.friend.Intimacy.IntimacyUtils")
    iconPath = IntimacyUtils.GetRelationTypeIcon(relation)
    local UIUtil = require("client.common.ui_util")
    relationText = UIUtil.GetIntimacyRelationName(relation)
  else
    log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateIntimacyUI relation is nil")
  end
  printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateIntimacyUI uid:%s, relation:%s, relationText:%s, iconPath:%s", self.uid, relation, relationText, iconPath)
  self:SetTexture(self.UIRoot.Image_Relation, iconPath)
  self.UIRoot.Text_Relation:SetText(relationText)
  local intimacy = LogicFriend.GetInnerFriendIntimacy(self.uid) or 0
  self.UIRoot.Text_Intimacy:SetText(tostring(intimacy))
  local logic_friend_intimacy = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_intimacy)
  local info = logic_friend_intimacy:GetIntimacyInfo(tonumber(DataMgr.roleData.uid), self.uid)
  local from = info and info.create_time or nil
  if from == 0 then
    from = nil
  end
  local TimeUtil = require("client.common.time_util")
  local to = TimeUtil.GetServerTimeInSec()
  local days = from and math.ceil((tonumber(to) - tonumber(from)) / 86400) or nil
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Relation, days)
  self.UIRoot.Text_RelationDays:SetText(tostring(days or "--"))
  self.UIRoot.Text_LabelUR:SetText(LocUtil.GetLocalizeResStr(77946))
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateOtherFriendDataUI()
  if self.uid == nil or self.uid == 0 then
    printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateOtherFriendDataUI uid is invalid %s", self.uid)
    return
  end
  local logic_friend_interact_record = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record)
  local data = logic_friend_interact_record:GetCumulativeInteractRecordData(self.uid)
  local TimeUtil = require("client.common.time_util")
  if data then
    self.UIRoot.Text_LabelUL:SetText(LocUtil.GetLocalizeResStr(77945))
    local add_friend_date = data.add_friend_date
    if add_friend_date == 0 or add_friend_date == nil then
      printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateOtherFriendDataUI invalid add_friend_date %s", add_friend_date)
      self.UIRoot.Text_Date:SetText("")
      self.UIRoot.Text_FriendDays:SetText("--")
    else
      local dateStr = TimeUtil.FormatTime_YMD(add_friend_date) or ""
      self.UIRoot.Text_Date:SetText(LocUtil.LocalizeResFormat(77960, dateStr))
      local add_friend_days = tostring(data.add_friend_days or "--")
      self.UIRoot.Text_FriendDays:SetText(add_friend_days)
    end
    if self.UIRoot.Image_Date then
      self:SetWidgetVisible(self.UIRoot.Image_Date, add_friend_date ~= 0)
    end
    local teamup_num = tostring(data.teamup_num or "--")
    self.UIRoot.Text_TeamupNum:SetText(teamup_num)
    self.UIRoot.Text_LabelLR:SetText(LocUtil.GetLocalizeResStr(77948))
    local teamup_scores = tostring(data.teamup_scores or "--")
    self.UIRoot.Text_TeamupScores:SetText(teamup_scores)
    self.UIRoot.Text_LabelLL:SetText(LocUtil.GetLocalizeResStr(77947))
  else
    log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateOtherFriendDataUI data is nil")
    self.UIRoot.Text_FriendDays:SetText("--")
    self.UIRoot.Text_TeamupNum:SetText("--")
    self.UIRoot.Text_TeamupScores:SetText("--")
  end
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:UpdateMemoryRecordUI()
  if not self.UIRoot then
    return
  end
  local logic_friend_memory_record = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_memory_record)
  local data = logic_friend_memory_record:GetData(self.uid)
  local item_data = data
  local combinedItemData = {}
  for i = 1, #item_data, 2 do
    local pair = {}
    pair[1] = item_data[i]
    if item_data[i + 1] then
      pair[2] = item_data[i + 1]
    end
    pair.uid = self.uid
    table.insert(combinedItemData, pair)
  end
  item_data = combinedItemData
  self.LoopScrollBox_0:SetData(item_data)
  self:SetWidgetVisible(self.UIRoot.Common_Empty_UIBP, #item_data == 0)
  self.UIRoot.Common_Empty_UIBP.TextBlock_Emtpy:SetText(LocUtil.GetLocalizeResStr(77985))
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnLikeUpdateUI()
  log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:OnLikeUpdateUI")
  self.LoopScrollBox_0:RefreshAllItems()
end

function Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:ReqData()
  log(bWriteLog and "Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:ReqData")
  if self.uid == nil or self.uid == 0 then
    printf("Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP:ReqData uid is invalid %s", self.uid)
    return
  end
  local logic_interaction = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction)
  logic_interaction:send_get_interact_info_req(self.uid)
  local logic_friend_memory_record = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_memory_record)
  logic_friend_memory_record:send_get_friend_interact_milestone_req(self.uid)
  local logic_friend_interact_record = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record)
  logic_friend_interact_record:RequestCumulativeInteractDataForPlayer(self.uid)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, Lobby_RoleInfo_IntimateRelationship_MemoryRecord_UIBP)
