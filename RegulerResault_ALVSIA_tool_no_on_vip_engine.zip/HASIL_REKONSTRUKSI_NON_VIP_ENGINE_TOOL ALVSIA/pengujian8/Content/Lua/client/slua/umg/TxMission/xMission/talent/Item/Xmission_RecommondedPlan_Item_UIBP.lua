local Xmission_RecommondedPlan_Item_UIBP = {}
local pairs = _ENV.pairs
local ipairs = _ENV.ipairs
ipairs = ipairs or function(a)
  local n = a and #a or 0
  local i = 0
  return function()
    i = i + 1
    if i <= n then
      return i, a[i]
    end
  end
end
local TalentDataMgr = require("client.slua.logic.TxMission.talent.logic_xmission_talent_data")
local TalentText = require("client.slua.umg.TxMission.xMission.talent.xmission_talent_text")
local TALENT_ITEM_LUA = "client.slua.umg.TxMission.xMission.talent.talent_item"
local ROW_PLATE_TINT = {
  0.16,
  0.18,
  0.19,
  1
}
local CARD_FILL_TINT = {
  0.07,
  0.08,
  0.09,
  0.92
}
local CARD_BORDER_TINT = {
  0.32,
  0.32,
  0.32,
  1
}

local function SetBrushTint(widget, r, g, b, a)
  if not widget then
    return
  end
  local ok, brush = pcall(function()
    return slua.IndexReference(widget, "Brush"):clone()
  end)
  if ok and brush then
    brush.TintColor = FSlateColor(FLinearColor(r, g, b, a))
    widget:SetBrush(brush)
  else
    widget:SetColorAndOpacity(FLinearColor(r, g, b, a))
  end
end

local function SetUMGVisible(self, widget, visible, hitTest)
  if not widget then
    return
  end
  local vis
  if visible then
    vis = hitTest and UEnums.ESlateVisibility.Visible or UEnums.ESlateVisibility.SelfHitTestInvisible
  else
    vis = UEnums.ESlateVisibility.Collapsed
  end
  if widget.SetVisibility_V2 then
    widget:SetVisibility_V2(vis)
  elseif widget.SetWidgetVisibility then
    widget:SetWidgetVisibility(vis)
  else
    self:SetWidgetVisible(widget, visible, hitTest)
  end
end

local LARGE_LOCAL_INDEX = {
  [1] = true,
  [6] = true,
  [11] = true
}

local function GetTalentDisplayName(talent)
  if not talent then
    return ""
  end
  local name = talent.name
  if type(name) == "number" and 0 < name then
    return LocUtil.GetLocalizeResStr(name) or tostring(name)
  end
  return name or ""
end

local function IsLargeTalentNode(localIndex)
  return LARGE_LOCAL_INDEX[tonumber(localIndex) or 0] == true
end

local TALENT_ROW_ELEMENT_NUM = 13

local function ResolveRecommendTalent(id, branchId)
  local idNum = tonumber(id) or id
  local talent = TalentDataMgr:GetTalentById(idNum)
  if not talent and type(idNum) == "number" and 1 <= idNum and idNum <= TALENT_ROW_ELEMENT_NUM then
    talent = TalentDataMgr:GetTalentById(idNum + (branchId - 1) * TALENT_ROW_ELEMENT_NUM)
  end
  local detailId = talent and talent.id or idNum
  local detail = CDataTable.GetTableData("TXTalentDetail", detailId)
  if not detail and idNum then
    detail = CDataTable.GetTableData("TXTalentDetail", idNum)
  end
  if not talent and not detail then
    return nil
  end
  local localIndex = talent and (talent.localIndex or talent.line) or nil
  if not localIndex and type(idNum) == "number" then
    if 1 <= idNum and idNum <= TALENT_ROW_ELEMENT_NUM then
      localIndex = idNum
    else
      localIndex = (idNum - 1) % TALENT_ROW_ELEMENT_NUM + 1
    end
  end
  local name = GetTalentDisplayName(talent)
  if (not name or name == "") and detail and detail.Name then
    local n = detail.Name
    if type(n) == "number" and 0 < n then
      name = LocUtil.GetLocalizeResStr(n) or tostring(n)
    else
      name = tostring(n)
    end
  end
  return {
    talent = talent,
    detail = detail,
    id = talent and talent.id or idNum,
    branch = talent and talent.branch or branchId,
    localIndex = localIndex or 0,
    name = name or "",
    icon = talent and talent.icon and talent.icon ~= "" and talent.icon or detail and detail.Icon or "",
    maxPoint = talent and talent.maxPointNum or detail and detail.MaxPoint or 0,
    subDesc = detail and detail.SubDesc or talent and talent.subDesc or ""
  }
end

local function BuildBranchShowList(pointMap, branchId)
  local list = {}
  for id, pt in pairs(pointMap or {}) do
    pt = tonumber(pt) or 0
    if 0 < pt then
      local resolved = ResolveRecommendTalent(id, branchId)
      if resolved then
        local detail = resolved.detail
        local rawLvDesc = detail and detail["Lv" .. tostring(pt) .. "Desc"]
        table.insert(list, {
          id = resolved.id,
          branch = resolved.branch,
          localIndex = resolved.localIndex,
          addPoint = pt,
          maxPoint = resolved.maxPoint,
          isUnlock = true,
          name = resolved.name,
          icon = resolved.icon,
          effect = resolved.subDesc,
          para = tonumber(rawLvDesc),
          showType = detail and tonumber(detail.showType)
        })
      else
        local idNum = tonumber(id) or 0
        local localIndex = idNum
        if idNum > TALENT_ROW_ELEMENT_NUM then
          localIndex = (idNum - 1) % TALENT_ROW_ELEMENT_NUM + 1
        end
        table.insert(list, {
          id = idNum,
          branch = branchId,
          localIndex = localIndex,
          addPoint = pt,
          maxPoint = 0,
          isUnlock = true,
          name = "",
          icon = "",
          effect = ""
        })
      end
    end
  end
  table.sort(list, function(a, b)
    return (a.localIndex or 0) < (b.localIndex or 0)
  end)
  return list
end

local function GroupRecommendTalents(list)
  local parents = {}
  local leadingSmalls = {}
  local current
  list = list or {}
  for i = 1, #list do
    local item = list[i]
    if IsLargeTalentNode(item.localIndex) then
      current = {
        item = item,
        subs = {}
      }
      table.insert(parents, current)
    elseif current then
      table.insert(current.subs, item)
    else
      table.insert(leadingSmalls, item)
    end
  end
  if 0 < #parents and 0 < #leadingSmalls then
    for i = #leadingSmalls, 1, -1 do
      table.insert(parents[1].subs, 1, leadingSmalls[i])
    end
    leadingSmalls = {}
  end
  return parents, leadingSmalls
end

local function PatchExtSubDataLookup(scroll)
  if not scroll or scroll._subDataMap then
    return
  end
  scroll._subDataMap = {}
  local rawSet = scroll.SetSubData
  local rawGet = scroll.GetSubItemData
  local rawRefresh = scroll._OnRefreshSubItem
  
  function scroll:SetSubData(index, arrayData)
    self._subDataMap[index] = arrayData or {}
    return rawSet(self, index, arrayData)
  end
  
  function scroll:GetSubItemData(index)
    local list = self._subDataMap[self._curUnfoldParentIndex]
    if list and list[index] then
      return list[index]
    end
    for _, subList in pairs(self._subDataMap) do
      if subList[index] then
        return subList[index]
      end
    end
    return rawGet(self, index)
  end
  
  function scroll:_OnRefreshSubItem(widget, index)
    if widget and widget.GetParent and self.UIRoot and self.UIRoot.GetWidgetIndex then
      local parentWidget = widget:GetParent()
      local ok, widx = pcall(function()
        return self.UIRoot:GetWidgetIndex(parentWidget)
      end)
      if ok and widx and 0 <= widx then
        do
          local parentIdx = widx + 1
          self._curUnfoldParentIndex = parentIdx
          if self._subDataMap[parentIdx] then
            self._subData = self._subDataMap[parentIdx]
          end
        end
      end
    end
    return rawRefresh(self, widget, index)
  end
end

function Xmission_RecommondedPlan_Item_UIBP:ctor()
  self.branchScroll = {}
  self.branchExtScroll = {}
  self.branchList = {}
end

function Xmission_RecommondedPlan_Item_UIBP:ApplyRecommendTextures()
  if self._recTexApplied then
    return
  end
  self._recTexApplied = true
  SetBrushTint(self.UIRoot.Image_0, CARD_FILL_TINT[1], CARD_FILL_TINT[2], CARD_FILL_TINT[3], CARD_FILL_TINT[4])
  SetBrushTint(self.UIRoot.Image_2, CARD_BORDER_TINT[1], CARD_BORDER_TINT[2], CARD_BORDER_TINT[3], CARD_BORDER_TINT[4])
  local rowIds = {
    15,
    19,
    22
  }
  for i = 1, 3 do
    SetBrushTint(self.UIRoot["Image_" .. rowIds[i]], ROW_PLATE_TINT[1], ROW_PLATE_TINT[2], ROW_PLATE_TINT[3], ROW_PLATE_TINT[4])
  end
end

function Xmission_RecommondedPlan_Item_UIBP:RegistEvents()
  for i = 1, 3 do
    local ext = self.UIRoot["ExtendedLoopScrollBox_Content" .. i]
    if ext then
      ext.bDisableScroll = false
      self.branchExtScroll[i] = self:InitExtendedScrollBox(ext, {TALENT_ITEM_LUA, TALENT_ITEM_LUA})
      PatchExtSubDataLookup(self.branchExtScroll[i])
      if self.branchExtScroll[i] and self.branchExtScroll[i].UIRoot then
        self.branchExtScroll[i].UIRoot.bDisableScroll = false
      end
    end
    local loop = self.UIRoot["LoopScrollBox_Content" .. i]
    if loop then
      SetUMGVisible(self, loop, false)
      self.branchScroll[i] = self:InitChildClassScrollBox(loop, TALENT_ITEM_LUA)
      SetUMGVisible(self, loop, false)
    end
    local previewBtn = self.UIRoot["Button_Preview" .. i]
    if previewBtn then
      self:AddOnClickedEventByControl(previewBtn, self.OnClickPreview, self, i)
    end
  end
  if self.UIRoot.Button_Apply then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Apply, self.OnClickButton_Apply, self)
  end
end

function Xmission_RecommondedPlan_Item_UIBP:ApplyDominantGradient(branchPoints)
  local bestBranch, bestPt = 1, -1
  for i = 1, 3 do
    local pt = tonumber(branchPoints and branchPoints[i]) or 0
    if bestPt < pt then
      bestPt = pt
      bestBranch = i
    end
  end
  local gradient = self.UIRoot.Image_Gradient
  if gradient and gradient.SetActiveColorIndex then
    gradient:SetActiveColorIndex(bestBranch - 1)
  end
end

function Xmission_RecommondedPlan_Item_UIBP:RefreshBranchTalents(branchId, showList)
  local parents, onlySmalls = GroupRecommendTalents(showList)
  local ext = self.branchExtScroll[branchId]
  local loop = self.branchScroll[branchId]
  local extRoot = self.UIRoot["ExtendedLoopScrollBox_Content" .. branchId]
  local loopRoot = self.UIRoot["LoopScrollBox_Content" .. branchId]
  local useExt = ext ~= nil and 0 < #parents
  SetUMGVisible(self, extRoot, useExt, true)
  SetUMGVisible(self, loopRoot, not useExt and loop ~= nil, true)
  if useExt then
    local parentItem = parents[1].item
    local allSubs = {}
    for i = 1, #parents do
      if 1 < i then
        table.insert(allSubs, parents[i].item)
      end
      local subs = parents[i].subs or {}
      for j = 1, #subs do
        table.insert(allSubs, subs[j])
      end
    end
    ext._subDataMap = {
      [1] = allSubs
    }
    ext:SetData({parentItem})
    ext:SetSubData(1, allSubs)
    SetUMGVisible(self, loopRoot, false)
    return
  end
  if loop then
    loop:SetData(showList or onlySmalls)
    SetUMGVisible(self, loopRoot, true, true)
  end
  if ext then
    ext:SetData({})
    SetUMGVisible(self, extRoot, false)
  end
end

function Xmission_RecommondedPlan_Item_UIBP:OnRefresh(data, selectIndex)
  self.data = data
  if not self.UIRoot or not data then
    return
  end
  TalentDataMgr:InitTalentMap()
  self:ApplyRecommendTextures()
  if self.UIRoot.TextBlock_Name then
    self.UIRoot.TextBlock_Name:SetText(data.name or data.tag or "")
  end
  if self.UIRoot.TextBlock_Desc then
    self.UIRoot.TextBlock_Desc:SetText(data.desc or "")
  end
  if self.UIRoot.TextBlock_TalentNum then
    self.UIRoot.TextBlock_TalentNum:SetText(tostring(data.totalPoint or 0))
  end
  local hasLabel = data.label and data.label ~= ""
  if self.UIRoot.TextBlock_Label then
    self.UIRoot.TextBlock_Label:SetText(hasLabel and data.label or "")
  end
  if self.UIRoot.SizeBox_2 then
    self:SetWidgetVisible(self.UIRoot.SizeBox_2, hasLabel)
  end
  if self.UIRoot.TextBlock_use then
    self.UIRoot.TextBlock_use:SetText(TalentText.Get("rec_btn_apply") or "")
  end
  if self.UIRoot.TextBlock_using then
    self.UIRoot.TextBlock_using:SetText(TalentText.Get("rec_btn_using") or "")
  end
  self.branchList = {}
  local branchPoints = {}
  for i = 1, 3 do
    local pointMap = data.branchData and data.branchData[i] or {}
    local showList = BuildBranchShowList(pointMap, i)
    self.branchList[i] = showList
    local branchPt = 0
    for _, pt in pairs(pointMap) do
      branchPt = branchPt + (pt or 0)
    end
    branchPoints[i] = branchPt
    local panel = self.UIRoot["CanvasPanel_type" .. i]
    if panel then
      self:SetWidgetVisible(panel, 0 < #showList or 0 < branchPt)
    end
    local nameWidget = self.UIRoot["TextBlock_TreeName" .. i]
    if nameWidget then
      nameWidget:SetText(TalentText.GetBranchName(i))
    end
    local numWidget = self.UIRoot["TextBlock_Num" .. i]
    if numWidget then
      numWidget:SetText(tostring(branchPt))
    end
    self:RefreshBranchTalents(i, showList)
  end
  self:ApplyDominantGradient(branchPoints)
  local using = TalentDataMgr:IsCurrentPageUsingConfig(data.id)
  if self.UIRoot.WidgetSwitcher_0 then
    self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(using and 1 or 0)
  end
end

function Xmission_RecommondedPlan_Item_UIBP:OnClickPreview(branchId)
  self:PlayAudio(sound_config.click_v1)
  local list = self.branchList and self.branchList[branchId]
  if not list or #list == 0 then
    return
  end
  local btn = self.UIRoot["Button_Preview" .. branchId]
  local num = 0
  for i = 1, #list do
    num = num + (list[i].addPoint or 0)
  end
  UIManager.ShowUI(UIManager.UI_Config.Xmission_Pop_UIBP, btn, {talentNum = num, data = list})
end

function Xmission_RecommondedPlan_Item_UIBP:OnClickButton_Apply()
  self:PlayAudio(sound_config.click_v1)
  log(bWriteLog and "Xmission_RecommondedPlan_Item_UIBP:OnClickButton_Apply")
  local mgr = require("client.slua.logic.TxMission.talent.logic_xmission_talent_data")
  mgr:ConfirmApplyRecommend(self.data)
end

local class = require("class")
local scroll_box_child_base = require("client.slua_ui_framework.component.scroll_box_child_base")
return class(scroll_box_child_base, nil, Xmission_RecommondedPlan_Item_UIBP)
