local AsyncXSuitSpinBase = {}
local Trait = require("common.trait")
local UIBase = require("client.slua_ui_framework.base")
local Traits = {
  require("client.slua.traits.Background.BackgroundSelector"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_Time"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_Rule"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_Video"),
  require("client.slua.traits.CommonTraits.TCommonUC"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_Close"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_JumpToPreview"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_JumpToExchange"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_JumpToUpgrade"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_JumpToWeapon"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_JumpToTrialRoad"),
  require("client.slua.umg.lobby_activity.xsuit_spin.Traits.XSuitSpin_Skip"),
  require("client.slua.umg.XSuit_Workshop.Traits.Xsuit_Avatar_Component")
}
local CAsyncSpinBase = Trait.TraitClass(UIBase, nil, AsyncXSuitSpinBase, Traits)
local xsuit_config_and_cache = require("client.slua.logic.XSuit.xsuit_config_and_cache")
local VideoLibrary = require("client.slua.logic.video.lobby_video_function_library")
local enum_draw_show_type = {
  video = 1,
  rareItem = 2,
  chest = 3,
  itemGet = 4
}

function AsyncXSuitSpinBase:ctor(_, jumpBack)
  self.Components = {}
  self.ComponentCounter = 0
  self.jumpBack = jumpBack
  self.openTime = 0
end

function AsyncXSuitSpinBase:OnInitialize()
  AsyncXSuitSpinBase.__super.OnInitialize(self)
  self:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self:InitializeConfigs()
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  logic_xsuit_activity:SetExchangeData(nil)
  self.Image_BG = {
    DrawNormal = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/XSuit_Get_BG05.XSuit_Get_BG05",
    DrawRare = "/Game/Arts_UI/FromUMG/XSuit/XsuitWorkShop/Texture/XSuit_Get_BG04.XSuit_Get_BG04",
    DrawBgUp = "/Game/Arts_UI/FromUMG/XSuit/XSuitSpin/Atlas/Frames/PharaohRises_BG_Plan_01_png.PharaohRises_BG_Plan_01_png",
    DrawBgDown = "/Game/Arts_UI/FromUMG/XSuit/XSuitSpin/Atlas/Frames/PharaohRises_BG_Plan_01_png.PharaohRises_BG_Plan_01_png"
  }
end

function AsyncXSuitSpinBase:RegistEvents()
  AsyncXSuitSpinBase.__super.RegistEvents(self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY, EVENTID_LUCKYBACK_EXCHANGE_REFRESH, self.OnExchangeDataRsp, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_SPIN_DRAW_RSP, self.OnSpinDrawRsp, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_SPIN_SHOWORHIDE_MASK, self.ShowOrHideMaskEvent, self)
  self:AddCommonEvent(EVENTTYPE_NEXTDAY, EVENTID_NEXTDAY_ZERO, self.UpdateDrawButton, self)
  self:AddCommonEvent(EVENTTYPE_DATA_MGR, EVENTID_DATAMGR_TICKET_CHANGE, self.UpdateDrawButton, self)
  self:AddCommonEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_DRAW_ACTIVITY_UPDATE, self.UpdateDrawButton, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_LUCKY_CARD_ENTRY_UPDATE, self.UpdateDrawButton, self)
  self:AddCommonEvent(EVENTTYPE_ACTIVITY_BLACK_FRIDAY, EVENTID_ACTIVITY_BLACK_FRIDAY_LUCKY_CARD_DATA_UPDATE, self.UpdateDrawButton, self)
end

function AsyncXSuitSpinBase:OnPostInitialize()
  AsyncXSuitSpinBase.__super.OnPostInitialize(self)
  self:InitScene()
  self:InitializeSpin()
  local tlog_commercial_player_behavior = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.tlog_commercial_player_behavior)
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  tlog_commercial_player_behavior:ReportOpen(TLogEventDefine.XSuitOpen, "XSuitOpen", logic_xsuit_activity:GetDrawActivityID())
  local TimeUtil = require("client.common.time_util")
  self.openTime = TimeUtil.GetServerTimeInSec()
  local CommerceInterfaceReport = require("client.slua.logic.lobby_activity.logic_commerce_interface_report")
  CommerceInterfaceReport.Start(CommerceInterfaceReport.InterfaceName.GoldDress, self)
  EventSystem:postEvent(EVENTTYPE_ACTIVITY, EVENTID_LUCKYSPINE_BG_FINISH)
  self:SetTexture(self.UIRoot.Image_BgUp, self.Image_BG.DrawBgUp, {sync = false})
  self:SetTexture(self.UIRoot.Image_BgDown, self.Image_BG.DrawBgDown, {sync = false})
end

function AsyncXSuitSpinBase:Close()
  local CommerceInterfaceReport = require("client.slua.logic.lobby_activity.logic_commerce_interface_report")
  CommerceInterfaceReport.Finish(self)
  self:ClearBackgroundWidget()
  AsyncXSuitSpinBase.__super.Close(self)
  self._BGTransWidget = nil
  local tlog_commercial_player_behavior = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.tlog_commercial_player_behavior)
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  tlog_commercial_player_behavior:ReportStay(TLogEventDefine.XSuitStay, "XSuitStay", logic_xsuit_activity:GetDrawActivityID(), self.openTime)
end

function AsyncXSuitSpinBase:ShowOrHideMask(show)
  log(bWriteLog and "  :AsyncXSuitSpinBase ShowOrHideMask: " .. tostring(show))
  if self.ShowOrHideMaskTimer then
    self:RemoveTimer(self.ShowOrHideMaskTimer)
    self.ShowOrHideMaskTimer = nil
  end
  local root = self.UIRoot
  if root and root.ScaleBox_Mask then
    self:SetWidgetVisible(root.ScaleBox_Mask, show)
  end
  if show then
    self.ShowOrHideMaskTimer = self:AddTimerOnce(1, function()
      self:ShowOrHideMask(false)
    end)
  end
end

function AsyncXSuitSpinBase:ShowOrHideMaskEvent(_, _, show)
  self:ShowOrHideMask(show)
end

function AsyncXSuitSpinBase:InitScene()
  local Lobby_camera_manager_module = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Lobby_camera_manager_module)
  Lobby_camera_manager_module:SwitchCamera(10127)
end

function AsyncXSuitSpinBase:InitDrawData(award_list, decompose_list)
  self.drawVideoPathList = {}
  self.drawVideoPathIndex = nil
  self.award_list = award_list
  self.decompose_list = decompose_list
  self.drawHeightQuality = false
  self.drawShowList = {}
end

function AsyncXSuitSpinBase:UpdateDrawButton()
  self:UpdateButton_DrawOne()
  self:UpdateButton_DrawTen()
end

function AsyncXSuitSpinBase:OnExchangeDataRsp()
  log(bWriteLog and "AsyncXSuitSpinBase:OnExchangeDataRsp")
  local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
  local luckybackactivity_mgr = require("client.slua.logic.lobby_activity.logic_luckyback_activity")
  logic_xsuit_activity:SetExchangeData(luckybackactivity_mgr.exchangeItemList)
  EventSystem:postEvent(EVENTTYPE_XSUIT, EVENTID_XSUIT_EXCHANGEDATA_UPDATE)
  self:UpdateExchangeRedTip()
end

function AsyncXSuitSpinBase:OnSpinDrawRsp(_, _, item_list, decompose_list)
  self:UpdateExchangeRedTip()
  self:UpdateUI()
  self:SetDrawShowList(item_list, decompose_list)
end

function AsyncXSuitSpinBase:IsLowEndDevice()
  if self._bLowEndDevice == nil then
    local UIUtil = require("client.common.ui_util")
    local gameInstance = UIUtil.GetGameInstance()
    local deviceLevel = gameInstance and gameInstance:GetDeviceLevel() or 0
    self._bLowEndDevice = deviceLevel <= 1
    log(bWriteLog and string.format("AsyncXSuitSpinBase:IsLowEndDevice deviceLevel:%s low:%s", tostring(deviceLevel), tostring(self._bLowEndDevice)))
  end
  return self._bLowEndDevice
end

function AsyncXSuitSpinBase:SetDrawShowList(award_list, decompose_list)
  self:InitDrawData(award_list, decompose_list)
  local bLowEndDevice = self:IsLowEndDevice()
  local PlayerPrefsSystem = require("client.logic.LogicPlayerPrefs.playerprefs")
  local data = PlayerPrefsSystem.LoadFileToTable_N(PlayerPrefsSystem.ePlayerPrefsType.eGoldenSuitLotterySkip)
  local bSkipVideo = data and data.skip == true or bLowEndDevice
  local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
  local bForceDrawVideo = false
  local bForceByGunSkin = false
  for i, v in ipairs(award_list) do
    if not bForceDrawVideo and v.itemid and v.itemid > 0 then
      if v.itemid == self.XSuitBranchBoxId then
        local boxPeriod = self:GetXSuitPeriodByItemId(self.XSuitBranchBoxId)
        local boxPeriodInfo = boxPeriod and LogicXSuit.shareTimeList and LogicXSuit.shareTimeList[boxPeriod]
        if boxPeriodInfo and next(boxPeriodInfo) then
          local _, bGetAll = LogicXSuit.IsGetAllXSuitByPeriod(boxPeriod)
          bForceDrawVideo = not bGetAll
        end
      elseif v.is_rare and v.is_rare == 1 then
        local decomposeData = decompose_list and decompose_list[i]
        local bDuplicate = decomposeData and decomposeData.itemid and decomposeData.itemid ~= 0 and true or false
        local gunVideoCfg = xsuit_config_and_cache.GetSpinVideoPathByVideoName(string.format("XSuit_Rate_Item_%d", v.itemid))
        if not bDuplicate and gunVideoCfg and gunVideoCfg.grating_card and gunVideoCfg.grating_card ~= "" then
          bForceDrawVideo = not LogicXSuit.IsGunGratingCardShown(self.curPeriod)
          bForceByGunSkin = bForceDrawVideo
        end
        if bDuplicate then
          log(bWriteLog and string.format("AsyncXSuitSpinBase:SetDrawShowList duplicate gun skin, do not force video. itemId:%s period:%s", tostring(v.itemid), tostring(self.curPeriod)))
        end
      end
    end
  end
  if bForceDrawVideo and not bLowEndDevice then
    bSkipVideo = false
    log(bWriteLog and string.format("AsyncXSuitSpinBase:SetDrawShowList force draw video. period:%s byGunSkin:%s", tostring(self.curPeriod), tostring(bForceByGunSkin)))
  end
  local rareList = {}
  local videoLevel
  for i, v in ipairs(award_list) do
    if not self.drawHeightQuality then
      local itemCfg = CDataTable.GetTableData("Item", v.itemid)
      if itemCfg and itemCfg.ItemQuality >= 7 then
        self.drawHeightQuality = true
      end
    end
    if v.itemid and v.itemid > 0 and v.count == 1 then
      if not bSkipVideo and v.animation_priority and 0 < v.animation_priority and (not videoLevel or videoLevel > v.animation_priority) then
        videoLevel = v.animation_priority
      end
      if v.is_rare and v.is_rare == 1 then
        local bExist = false
        for _, itemId in ipairs(rareList) do
          if itemId == v.itemid then
            bExist = true
            break
          end
        end
        if not bExist then
          table.insert(rareList, v.itemid)
        end
      end
      if v.itemid == self.XSuitBranchBoxId then
        self.drawShowList[enum_draw_show_type.chest] = self.drawShowList[enum_draw_show_type.chest] or {}
        table.insert(self.drawShowList[enum_draw_show_type.chest], i)
      end
    end
  end
  local videoName = string.format("XSuit_Normal_Draw_%d", videoLevel or 0)
  local drawVideoCfg = not bSkipVideo and xsuit_config_and_cache.GetSpinVideoPathByVideoName(videoName)
  if drawVideoCfg and drawVideoCfg.video_path ~= "" and VideoLibrary.IsCanVideoFileAndReady(drawVideoCfg.video_path) then
    self.drawShowList[enum_draw_show_type.video] = self.drawShowList[enum_draw_show_type.video] or {}
    table.insert(self.drawShowList[enum_draw_show_type.video], {
      videoPath = drawVideoCfg.video_path,
      audioId = drawVideoCfg.video_audio,
      bDisableSkip = bForceDrawVideo
    })
  end
  for _, itemId in ipairs(rareList) do
    videoName = string.format("XSuit_Rate_Item_%d", itemId)
    drawVideoCfg = xsuit_config_and_cache.GetSpinVideoPathByVideoName(videoName)
    if not bSkipVideo and drawVideoCfg and drawVideoCfg.video_path ~= "" and VideoLibrary.IsCanVideoFileAndReady(drawVideoCfg.video_path) then
      self.drawShowList[enum_draw_show_type.video] = self.drawShowList[enum_draw_show_type.video] or {}
      table.insert(self.drawShowList[enum_draw_show_type.video], {
        videoPath = drawVideoCfg.video_path,
        audioId = drawVideoCfg.video_audio,
        bDisableSkip = bForceDrawVideo
      })
    end
    if drawVideoCfg and 0 < drawVideoCfg.special_action then
      self.drawShowList[enum_draw_show_type.rareItem] = self.drawShowList[enum_draw_show_type.rareItem] or {}
      table.insert(self.drawShowList[enum_draw_show_type.rareItem], drawVideoCfg.special_action)
    end
    if not bLowEndDevice and drawVideoCfg and drawVideoCfg.grating_card and drawVideoCfg.grating_card ~= "" then
      self.drawShowList[enum_draw_show_type.rareItem] = self.drawShowList[enum_draw_show_type.rareItem] or {}
      table.insert(self.drawShowList[enum_draw_show_type.rareItem], {
        uiName = drawVideoCfg.grating_card,
        itemid = itemId
      })
    end
  end
  self.drawShowList[enum_draw_show_type.itemGet] = self.drawShowList[enum_draw_show_type.itemGet] or {}
  self:PlayDrawShowList()
end

function AsyncXSuitSpinBase:PlayDrawShowList()
  if self.showListTimer then
    self:RemoveTimer(self.showListTimer)
    self.showListTimer = nil
  end
  self.showListTimer = self:AddTimer(0, function()
    local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
    logic_xsuit_activity:PlaySpinAudio_BG(-1)
    self:SetWidgetVisible(self.UIRoot.Border_Root, false)
    self:SetWidgetVisible(self.UIRoot.Common_UIPopupBG, false)
    self:SetTexture(self.UIRoot.Image_Draw, self.drawHeightQuality and self.Image_BG.DrawRare or self.Image_BG.DrawNormal, {sync = false})
    for index = 1, enum_draw_show_type.itemGet do
      local list = self.drawShowList[index]
      if list then
        if index == enum_draw_show_type.video then
          for _, videoData in ipairs(list) do
            local EStretch = import("EStretch")
            local VideoLibrary = require("client.slua.logic.video.lobby_video_function_library")
            local videoPath = VideoLibrary.GetLowQualityVideoPath(videoData.videoPath)
            videoPath = videoPath or videoData.videoPath
            UIManager.ShowUI(UIManager.UI_Config.xsuit_spin_video_player_system, videoPath, {
              bRestoreLobbyMusic = false,
              ScaleToFit = EStretch.ScaleToFill,
              bKeepLobbyBgm = true,
              bDoNotChangeCameraSetting = true,
              bDisableSkip = videoData.bDisableSkip
            })
            self:SetWidgetVisible(self.UIRoot.ScaleBox_Draw, true)
            local ui = UIManager.GetUI(UIManager.UI_Config.xsuit_spin_video_player_system)
            while ui and (ui:IsShow() or ui:IsAsyncLoading()) do
              coroutine.yield(0.1)
            end
          end
        elseif index == enum_draw_show_type.rareItem then
          local ModelDisplayer = require("client.logic.avatar.ModelDisplayer")
          local showingAvatar = ModelDisplayer.GetShowingAvatar()
          local showingAvatarModel = showingAvatar and showingAvatar:GetModel()
          
          local function callback()
            local MultipleAvatarEnum = require("client.logic.avatar.MultipleAvatarEnum")
            log(bWriteLog and "AsyncXSuitSpinBase:PlayDrawShowList, emotionEndCallback")
            ModelDisplayer.HideAvatar(MultipleAvatarEnum.Enum_VisibilitySource.XSuitSpin)
          end
          
          if showingAvatarModel then
            local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
            for _, rareData in ipairs(list) do
              if type(rareData) == "number" then
                local actionId = rareData
                self:ShowAvatarDisplay(actionId, {
                  bWear = true,
                  enableCameraAnim = true,
                  bIsForceScene = false,
                  bForceHideBeforeEmote = true,
                  emotionEndCallback = callback
                })
                self:SetWidgetVisible(self.UIRoot.ScaleBox_Draw, false)
                while showingAvatarModel:GetCurrentActionID() == actionId do
                  coroutine.yield(0.1)
                end
                if self.curPeriod then
                  LogicXSuit.MarkGunGratingCardShown(self.curPeriod)
                end
              end
            end
          else
            do
              local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
              for _, rareData in ipairs(list) do
                if type(rareData) == "table" and rareData.uiName then
                  local uiConfig = UIManager.GetConfigByKey(rareData.uiName)
                  local gratingPeriod = self.curPeriod or LogicXSuit.GetPeriodByItemId(rareData.itemid)
                  if uiConfig and gratingPeriod and LogicXSuit.IsGunGratingCardShown(gratingPeriod) then
                    log(bWriteLog and string.format("AsyncXSuitSpinBase:PlayDrawShowList gun grating card already shown, period:%s, itemId:%s", tostring(gratingPeriod), tostring(rareData.itemid)))
                  elseif uiConfig then
                    UIManager.ShowUI(uiConfig, rareData.itemid)
                    if gratingPeriod then
                      LogicXSuit.MarkGunGratingCardShown(gratingPeriod)
                    end
                    self:SetWidgetVisible(self.UIRoot.ScaleBox_Draw, true)
                    local ui = UIManager.GetUI(uiConfig)
                    while ui and (ui:IsShow() or ui:IsAsyncLoading()) do
                      coroutine.yield(0.1)
                    end
                  else
                    log_error(bWriteLog and "AsyncXSuitSpinBase:PlayDrawShowList UI config not found: " .. tostring(rareData.uiName))
                  end
                end
              end
            end
          end
        elseif index == enum_draw_show_type.chest then
          local bShowXSuitBox = false
          local wardrobe_data = require("client.slua.logic.wardrobe.wardrobe_data")
          local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
          local boxPeriod = self:GetXSuitPeriodByItemId(self.XSuitBranchBoxId)
          local boxPeriodInfo = boxPeriod and LogicXSuit.shareTimeList and LogicXSuit.shareTimeList[boxPeriod]
          local bAllBranchGet = false
          if boxPeriodInfo and next(boxPeriodInfo) then
            local _, bGetAll = LogicXSuit.IsGetAllXSuitByPeriod(boxPeriod)
            bAllBranchGet = bGetAll or false
          end
          if bAllBranchGet then
            log(bWriteLog and string.format("AsyncXSuitSpinBase:PlayDrawShowList chest skip(all branch got). period:%s, boxId:%s", tostring(boxPeriod), tostring(self.XSuitBranchBoxId)))
          end
          for _, itemIndex in ipairs(list) do
            local awardInfo = self.award_list[itemIndex]
            local boxItemId = awardInfo and awardInfo.itemid or self.XSuitBranchBoxId
            local data
            if not bAllBranchGet then
              data = self.XSuitBranchBoxId and self.XSuitBranchBoxId > 0 and wardrobe_data:GetHallDepotItemDataByResID(self.XSuitBranchBoxId)
              if not data and boxItemId == self.XSuitBranchBoxId then
                local waitTime = 0
                while not data and waitTime < 0.3 do
                  coroutine.yield(0.05)
                  waitTime = waitTime + 0.05
                  data = wardrobe_data:GetHallDepotItemDataByResID(self.XSuitBranchBoxId)
                end
                if not data then
                  log(bWriteLog and string.format("AsyncXSuitSpinBase:PlayDrawShowList chest depot wait timeout(%.2fs), open box ui anyway. boxId:%s", waitTime, tostring(self.XSuitBranchBoxId)))
                end
              end
            end
            if (data or boxItemId == self.XSuitBranchBoxId) and not bAllBranchGet then
              bShowXSuitBox = true
              self:ShowBranchBoxSelect(boxItemId, function(itemData, decomposeData)
                self.award_list[itemIndex] = itemData or self.award_list[itemIndex]
                self.decompose_list[itemIndex] = decomposeData or self.decompose_list[itemIndex]
                bShowXSuitBox = false
              end)
              local boxUIConfig = LogicXSuit.GetBranchBoxSelectUIConfig(boxItemId)
              local boxUI
              local waitShowTime = 0
              while waitShowTime < 2 do
                boxUI = boxUIConfig and UIManager.GetUI(boxUIConfig)
                if boxUI and boxUI:IsShow() then
                  break
                end
                coroutine.yield(0.05)
                waitShowTime = waitShowTime + 0.05
              end
              self:SetWidgetVisible(self.UIRoot.ScaleBox_Draw, false)
              if not boxUI or not boxUI:IsShow() then
                log_error(string.format("AsyncXSuitSpinBase:PlayDrawShowList branch box UI not show. period:%s, boxId:%s, wait:%.2fs", tostring(boxPeriod), tostring(boxItemId), waitShowTime))
                bShowXSuitBox = false
              end
              while bShowXSuitBox do
                coroutine.yield(0.1)
              end
            end
          end
        elseif index == enum_draw_show_type.itemGet then
          self:ShowItemGet(self.award_list, self.decompose_list)
          self:RefreshBranchBox()
          self:SetWidgetVisible(self.UIRoot.Border_Root, true)
          self:SetWidgetVisible(self.UIRoot.Common_UIPopupBG, true)
        end
      end
    end
  end)
end

function AsyncXSuitSpinBase:GetXSuitPeriodByItemId(itemId)
  local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
  return LogicXSuit.GetBranchBoxPeriod(itemId)
end

function AsyncXSuitSpinBase:ShowBranchBoxSelect(boxItemId, callback)
  local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
  LogicXSuit.ShowBranchBoxSelect(boxItemId, callback, 1)
end

function AsyncXSuitSpinBase:CloseBranchBoxSelect()
  local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
  LogicXSuit.CloseBranchBoxSelect()
end

function AsyncXSuitSpinBase:PlayEntryAndLoopAnim()
  if self.Configs.AudioConfig.SpinEnter then
    self:PlayAudio(self.Configs.AudioConfig.SpinEnter)
  end
  self:PlayAnimation(self.Configs.AnimationConfig.EntryAnimation, 0, 1, 0, 1)
  if self.Configs.AudioConfig.SpinLoop then
    self:PlayAudio(self.Configs.AudioConfig.SpinLoop)
  end
  if self.Configs.AudioConfig.BGM then
    self:PlayMusic(self.Configs.AudioConfig.BGM)
  end
  self:PlayAnimation(self.Configs.AnimationConfig.LoopAnimation, 0, 0, 0, 1)
end

function AsyncXSuitSpinBase:PlayOutAnimation()
  self:PlayAnimation(self.Configs.AnimationConfig.OutAnimation, 0, 1, 0, 1)
  if self.BackgroundWidget then
    local BG_Out = self.Configs.Misc.BackgroundConfig.Animation.OutAnimation
    if BG_Out then
      local UIUtil = require("client.common.ui_util")
      UIUtil.PlayWidgetAnimation(self.BackgroundWidget, BG_Out, 0, 1, 0, 1)
    end
    for k, v in pairs(self.Configs.Misc.BackgroundConfig.SpineList) do
      if self.BackgroundWidget[k] then
        self.BackgroundWidget[k]:SetAnimation(0, v, false)
      end
    end
  end
end

function AsyncXSuitSpinBase:PlayBackAnimation()
  if self.Configs.AnimationConfig.BackAnimation then
    self:PlayAnimation(self.Configs.AnimationConfig.BackAnimation, 0, 1, 0, 1)
  else
    self:PlayAnimation(self.Configs.AnimationConfig.OutAnimation, 0, 1, 1, 1)
  end
  if self.BackgroundWidget then
    local BG_Out = self.Configs.Misc.BackgroundConfig.Animation.OutAnimation
    if BG_Out then
      local UIUtil = require("client.common.ui_util")
      UIUtil.PlayWidgetAnimation(self.BackgroundWidget, BG_Out, 0, 1, 1, 1)
    end
    for k, v in pairs(self.Configs.Misc.BackgroundConfig.SpineList) do
      if self.BackgroundWidget[k] then
        self.BackgroundWidget[k]:SetAnimation(0, v, true)
      end
    end
  end
end

function AsyncXSuitSpinBase:PlayAnimation(inAnimationName, startAtTime, numLoopsToPlay, playMode, playbackSpeed)
  local UIUtil = require("client.common.ui_util")
  local LOD = UIUtil.PlayWidgetAnimation(self.UIRoot, inAnimationName, startAtTime, numLoopsToPlay, playMode, playbackSpeed)
  return LOD
end

return CAsyncSpinBase
