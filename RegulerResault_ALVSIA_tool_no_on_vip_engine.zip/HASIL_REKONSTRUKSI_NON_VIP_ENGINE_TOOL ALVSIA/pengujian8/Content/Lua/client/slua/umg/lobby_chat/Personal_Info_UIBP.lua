do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(171, 124, 100, 58, 1)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 2, 187, 89, 144, 249, 74, 65, 24, 28, 245, 196, 186, 114, 193, 62, 148, 62, 187))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not _ARG_2_ or type(_ARG_2_) == U1(188, 113, 103, 37, 23) then
        return
      end
      _ARG_0_.uid = tonumber(_ARG_2_)
      _ARG_0_.params = _ARG_3_
      _ARG_0_.isSelf = tonumber(_ARG_0_.uid) == tonumber(DataMgr.roleData.uid)
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 26, 246, 196, 186, 57, 154, 53, 145, 109, 227, 0) .. tostring(_ARG_2_) .. U1(232, 99, 96, 37, 20, 181, 209, 90, 172, 41, 137, 59, 238, 13, 239) .. tostring(_ARG_0_.isSelf))
      _ARG_0_.bNeedRefreshNormalInfoNum = 0
      _ARG_0_.openSubWidget = nil
      _ARG_0_.isShowMood = false
      _ARG_0_.isShowSkin = false
      _ARG_0_.isDefultNameColor = true
      _ARG_0_.eShowLocationType = _ARG_4_
      _ARG_0_.needDownloadPakNames = {}
      _ARG_0_.bShowPinbi = _ARG_6_
      _ARG_0_.bShowGift = _ARG_5_
      _ARG_0_:PreloadPersonalInfo()
      _ARG_0_.IsPlanBTParam = _ARG_3_.IsPlanBTParam or false
      _ARG_0_.FrameAnimPlayed = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      _ARG_0_.LobbyChat_InformationCustomDetail_UIBP = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.LobbyChat_InformationCustomDetail_UIBP, _ARG_0_.UIRoot.LobbyChat_InformationCustomDetail_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyNicknameOutline"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_1_.Font then
        return
      end
      if _ARG_2_ then
        _ARG_1_.Font.OutlineSettings.OutlineSize = 1
        _ARG_1_.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
      else
        _ARG_1_.Font.OutlineSettings.OutlineSize = 0
        _ARG_1_.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Close, _ARG_0_.OnClickButton_Close, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_More, _ARG_0_.OnClickButton_More, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Report, _ARG_0_.OnClickButton_Report, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Poke, _ARG_0_.OnClickButton_Poke, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_SendGift, _ARG_0_.OnClickButton_SendGift, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Invite, _ARG_0_.OnClickButton_Invite, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Apply, _ARG_0_.OnClickButton_Apply, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_AddFriened, _ARG_0_.OnClickButton_AddFriened, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Chat, _ARG_0_.OnClickButton_Chat, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Play1, _ARG_0_.OnClickButton_Play1, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Play2, _ARG_0_.OnClickButton_Play2, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_mood, _ARG_0_.OnClickButton_mood, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_good, _ARG_0_.OnClickButton_good, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_SocialHall, _ARG_0_.OnClickButton_SocialHall, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Home, _ARG_0_.OnClickButton_Home, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CardCollect, _ARG_0_.OnClickButton_CardCollect, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_BP, _ARG_0_.OnClickButton_GiveBP, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Club, _ARG_0_.on_hover_club_profile_click, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Moment, _ARG_0_.on_hover_moment_click, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Remark, _ARG_0_.OnClickRemark, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_InteractRecord, _ARG_0_.OnButton_InteractRecordClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Souvenirs, _ARG_0_.OnButton_SouvenirsClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Pinbi, _ARG_0_.OnClickedPinbi, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Fire, _ARG_0_.OnClickButtonFire, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_FriendsGoTo, _ARG_0_.OnClickButton_FriendsGoTo, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Home22, _ARG_0_.OnClickGoHome, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Home_Download, _ARG_0_.OnClickHome_Download, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Lock01, _ARG_0_.OnClickHomeLock, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_CollectHall_Go, _ARG_0_.OnClickButton_CollectHall_Go, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Collect_DownLoad, _ARG_0_.OnClickButton_Collect_DownLoad, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Common_Avatar_BP, _ENV(135, 126, 70, 37, 27, 248, 211, 96, 139, 41, 136, 30, 175, 92, 163, 253, 89, 67, 30), _ARG_0_.OnClickHeadCallback, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CORPS, U1.EVENTID_CORPS_GET_SUMMARY, _ARG_0_.GetCorpsSummaryRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CHAT, U1.EVENTID_CHAT_INTERACT_RSP, _ARG_0_.OnInteract, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_BATCH_GET_PLAYERSTATUS, _ARG_0_.OnFriendStatusChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_UPDATE_REMARK, _ARG_0_.OnFriendStatusChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_GROUP_ONLINE_CHANGE, _ARG_0_.OnFriendStatusChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_INTIMACY_UPDATE, _ARG_0_.OnFriendStatusChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_STATUS_CHANGE, _ARG_0_.OnFriendStatusChange, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_FRIEND, U1.EVENTID_FRIEND_TOP_STATUS_CHANGE, _ARG_0_.OnFriendStatusChange, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      _ARG_0_.isShowGood = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if _ARG_0_.profile_frame_bp then
        _ARG_0_.profile_frame_bp = nil
        _ARG_0_.FrameAnimPlayed = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PreloadPersonalInfo"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) and 0 < (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).corps_id or 0) then
      end
      _ARG_0_._cpData = require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 28, 240, 216, 167, 119, 176, 47, 133, 44, 189, 69, 241, 236, 93, 67, 17, 6, 255, 228, 168, 123),
        U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 40, 186, 89, 163)
      }))).GetDataByUID(_ARG_0_.uid)
      goto lbl_389
      if U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95) and 0 < U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95).mId then
        if U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95).mId == require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 28, 240, 216, 167, 119, 176, 47, 133, 44, 189, 69, 241, 236, 93, 67, 17, 6, 255, 228, 168, 123),
          U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95)
        }))).NewModuleID.Common_RankIntegralLevelMax then
        elseif U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95).mId == require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 28, 240, 216, 167, 119, 176, 47, 133, 44, 189, 69, 241, 236, 93, 67, 17, 6, 255, 228, 168, 123),
          U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95)
        }))).NewModuleID.SeasonYear then
          if tonumber(_ARG_0_.uid) ~= tonumber(DataMgr.roleData.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_year_badge):CheckOtherSeasonYearBadge(_ARG_0_.uid) == nil then
          end
        elseif U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95).mId == require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 28, 240, 216, 167, 119, 176, 47, 133, 44, 189, 69, 241, 236, 93, 67, 17, 6, 255, 228, 168, 123),
          U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95)
        }))).NewModuleID.Relation and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95).relation_uid or U1(173, 99, 96, 39, 6, 250, 204, 64, 144, 34, 186, 62, 161, 94, 169, 246, 95).mData.uid) then
        end
      end
      ::lbl_389::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Close"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.openSubWidget then
        _ARG_0_:SetWidgetVisible(_ARG_0_.openSubWidget, false, false)
        _ARG_0_.openSubWidget = nil
        return
      end
      _ARG_0_:CloseSelf()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_More"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 125, 10, 27, 247))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_.isShowExtend = not _ARG_0_.isShowExtend
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_More, _ARG_0_.isShowExtend, false)
      _ARG_0_.openSubWidget = _ARG_0_.UIRoot.CanvasPanel_More
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Report"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 98, 0, 25, 253, 201, 172))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_More, false, false)
      _ARG_0_.openSubWidget = nil
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_BlackList"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 114, 9, 8, 241, 208, 148, 96),
        U1(187, 100)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_More, false, false)
      _ARG_0_.openSubWidget = nil
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_.uid) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Poke"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 96, 10, 2, 247))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_SendGift"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 99, 0, 7, 246, 252, 177, 111),
        U1(188)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Invite"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 121, 11, 31, 251, 207, 189))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:ShowWaitingUI()
      _ARG_0_:InviteRequest()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Apply"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 113, 21, 25, 254, 194))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) or type((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) ~= U1(188, 113, 103, 37, 23) or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid) then
        return
      end
      if U2.InHall((ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid))) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).mod_id then
      elseif U2.IsRoom((ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid))) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).mod_id then
      elseif require((U1(171, 124, 108, 44, 28, 239, 150, 69, 144, 43, 140, 62, 224, 92, 160, 248, 81, 78, 91, 21, 237, 204, 161, 122, 176, 48, 154, 47, 188, 89))).isInMatch then
        return
      elseif require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 1, 28, 227, 198, 189, 105, 193, 48, 154, 42, 183, 67, 128, 251, 77, 81, 8, 54, 231, 203))).CanInviteFriend() then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).tplan_type and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).tplan_type ~= 0 and not require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 33, 1, 207, 194, 187, 106, 134, 51, 155, 99, 178, 79, 184, 230, 75, 111, 29, 4, 251, 200, 171, 96),
          U1(167, 126, 90, 45, 29, 236, 214, 69, 144, 45, 129)
        }))).CheckResHasDownloaded() then
          return
        end
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetFrom() == U3.ENUM_OPEN_FROM.TPLAN then
          if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).tplan_type or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).tplan_type == 0 then
            return
          end
        elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetFrom() == U3.ENUM_OPEN_FROM.ISLAND then
          if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).tplan_type and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).uid).tplan_type == 1 then
            return
          else
          end
        elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetFrom() == U3.ENUM_OPEN_FROM.CREATIVEWOW then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowWaitingUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 42, 234, 196, 191, 78, 142, 53, 129, 36, 176, 71, 138, 198))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Team, true, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_10, true, false)
      _ARG_0_.UIRoot.WidgetSwitcher_Team:SetActiveWidgetIndex(2)
      _ARG_0_:AddTimerOnce(5.5, function()
        _ENV:RefreshInteractButton()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InviteRequest"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 48, 236, 221, 161, 109, 138, 14, 144, 60, 171, 69, 172, 251))
      if RoomSystem.IsShowWaiting() then
      elseif LobbySystem.isInMatch then
      else
      end
      if true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyRequest"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 56, 242, 219, 164, 96, 189, 57, 132, 56, 187, 83, 171))
      if LobbySystem.isInMatch then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_AddFriened"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 113, 1, 13, 212, 201, 177, 108),
        U1(166, 117, 97)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_teamquick_join):GetAvatarTeamID() then
        return
      end
      if UIManager.GetUI(UIManager.UI_Config.Lobby_InviteFriend_BP) then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetTabID() == 6 then
        end
      elseif UIManager.GetUI(UIManager.UI_Config.ui_chat_main) and UIManager.GetUI(UIManager.UI_Config.ui_chat_main) and UIManager.GetUI(UIManager.UI_Config.ui_chat_main).LoopScrollBox_ChannelTabs and UIManager.GetUI(UIManager.UI_Config.ui_chat_main).LoopScrollBox_ChannelTabs.GetSelectIndex and UIManager.GetUI(UIManager.UI_Config.ui_chat_main).LoopScrollBox_ChannelTabs:GetSelectIndex() == 4 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Chat"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 115, 13, 8, 230))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Play1"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 96, 9, 8, 235, 138))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Play2"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 183, 56, 170, 84, 176, 225, 119, 96, 9, 8, 235, 137))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHeadCallback"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 164, 112, 140, 55, 189, 40, 191, 68, 156, 238, 68, 92, 7, 8, 241, 208))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCharmLevelChanged"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      printf(table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 54, 236, 232, 160, 120, 157, 49, 185, 40, 168, 69, 179, 204, 64, 81, 11, 14, 247, 223, 248, 103),
        U1(152, 124, 100, 48, 23, 233, 237, 96, 187, 108, 216, 125, 235, 67, 227, 191, 86, 99, 29, 24, 240, 198, 132, 124, 153, 57, 153, 109, 227, 0, 250, 252, 4, 16, 7, 58, 250, 212, 175, 74),
        U1(160, 113, 119, 36, 82, 166, 152, 12, 140)
      }), _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_3_ == tonumber(_ARG_0_.uid) then
        _ARG_0_:RefreshCharmLevel(_ARG_4_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateUI"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 44, 242, 207, 169, 109, 138, 9, 188))
      _ARG_0_:SetContent()
      _ARG_0_:RefreshInfo()
      _ARG_0_:RefreshCharmLevel()
      _ARG_0_:UpdateCustomPresentation()
      _ARG_0_:ShowReturnFlag()
      _ARG_0_:ShowRPFlag()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshExtendButton"] = function(_ARG_0_)
    do
      if _ARG_0_.eShowLocationType ~= U2.EShowLocationType.PlanZMember and require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 22, 22, 239, 198, 189, 119, 134, 40, 140, 99, 178, 79, 184, 230, 75, 111, 6, 6, 255, 214, 173, 103),
        U1(161, 100, 124)
      }))).GetShowEntry() and UIManager.IsUIShow(UIManager.UI_Config.ui_room_waiting) == false and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_entry):IsPlanPHMode() then
      end
      if not LobbySystem.CheckOpen(BP_ENUM_MOMENT_SWITCH) or require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 24, 24, 246, 200, 160, 55, 131, 51, 146, 36, 189, 127, 178, 224, 76, 85, 58, 4, 245, 201))).IsSocialIslandMode() or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_entry):IsPlanPHMode() or _ARG_0_.eShowLocationType == U2.EShowLocationType.TPlanTeamPlatform or _ARG_0_.eShowLocationType == U2.EShowLocationType.PlanZMember or _ARG_0_.eShowLocationType == U2.EShowLocationType.PlanPHPlayerList or require((table.concat({
        U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 89, 161, 248, 84, 69, 33, 11, 227, 194, 166, 112, 129, 59, 219, 10, 191, 77, 186, 223, 68, 81, 28, 71, 214, 218, 172, 104),
        U1(230, 67, 108, 39, 21, 247, 221, 125, 141, 45, 140, 51, 154, 95, 160, 243)
      }))).IsSelfInTraining() then
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) then
      else
      end
      if not (_ARG_0_.eShowLocationType ~= U2.EShowLocationType.Chat and _ARG_0_.eShowLocationType ~= U2.EShowLocationType.PlanZMember and (_ARG_0_.eShowLocationType ~= U2.EShowLocationType.Teammate or require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid))) or _ARG_0_.eShowLocationType == U2.EShowLocationType.Assembly or _ARG_0_.eShowLocationType == U2.EShowLocationType.MainCity then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetContent"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 42, 231, 223, 139, 118, 129, 40, 144, 35, 170))
      _ARG_0_.UIRoot.TextBlock_Report:SetText(LocUtil.GetLocalizeResStr(638))
      _ARG_0_.UIRoot.TextBlock_Collect:SetText(LocUtil.GetLocalizeResStr(73314))
      _ARG_0_.UIRoot.TextBlock_Prosperity:SetText(LocUtil.GetLocalizeResStr(64754))
      _ARG_0_.UIRoot.TextBlock_Popularity:SetText(LocUtil.GetLocalizeResStr(64756))
      _ARG_0_.UIRoot.TextBlock_Interact:SetText(LocUtil.GetLocalizeResStr(73315))
      _ARG_0_.UIRoot.TextBlock_Play:SetText(LocUtil.GetLocalizeResStr(73316))
      _ARG_0_.UIRoot.TextBlock_Play1:SetText(LocUtil.GetLocalizeResStr(73317))
      _ARG_0_.UIRoot.TextBlock_Play2:SetText(LocUtil.GetLocalizeResStr(73318))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 43, 231, 205, 186, 124, 156, 52, 188, 35, 184, 79))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).rankdata then
        return
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBasicInfo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 43, 231, 205, 186, 124, 156, 52, 183, 44, 173, 73, 188, 198, 70, 86, 10))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_More, false, false)
      _ARG_0_:_RefreshAlisaInfo(_ARG_1_)
      _ARG_0_.UIRoot.Common_Avatar_BP:InitView(1, _ARG_0_.uid, _ARG_1_.picUrl, _ARG_1_.sex, _ARG_1_.cur_avatar_box_id, _ARG_1_.level, false, (U1()))
      _ARG_0_.UIRoot.Common_Gender_UIBP:LoadIcon(_ARG_0_.uid)
      _ARG_0_.UIRoot.TextBlock_Name:SetText(_ARG_1_.nickName or U1())
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).GetRemark(_ARG_0_.uid) then
      end
      if require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 186, 246, 103, 85, 1, 16, 238))).GetPlatformlIcon(_ARG_0_.uid) then
        if U2.IsBlueholeOperationRegion() and (BP_Platform == BP_ENUM_PLAYFORM_WX or BP_Platform == BP_ENUM_PLAYFORM_BGBGByiTOP) then
        end
      else
      end
      _ARG_0_.corp_alias_id = _ARG_1_.corp_alias_id or 0
      if 0 < (_ARG_1_.corps_id or 0) then
      else
      end
      if 0 < (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list):GetIntimacy(_ARG_0_.uid) or 0) then
      else
      end
      if not (_ARG_0_.eShowLocationType and _ARG_0_.eShowLocationType == U3.EShowLocationType.MainCity or false) then
        if require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
          U1(172)
        }))).IsMyFriend(_ARG_0_.uid) then
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordDataHighFrequency(_ARG_0_.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordDataHighFrequency(_ARG_0_.uid).add_friend_days then
          end
          if 0 < (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list):GetIntimacy(_ARG_0_.uid) or 0) or 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordDataHighFrequency(_ARG_0_.uid).add_friend_days then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1.SetText
    end
  end,
  ["_RefreshAlisaInfo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 12, 178, 73, 172, 238, 97, 94, 3, 6))
      if _ARG_1_.alias and _ARG_1_.alias.id and _ARG_1_.alias.id > 0 then
        _ARG_0_.UIRoot.Title_UIBP:SetAliasInfo(_ARG_1_.alias.id or 0, _ARG_1_.alias.title or U1(), _ARG_1_.alias.nation or U1(), 0, _ARG_1_.alias.rank_id or 0)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Title_UIBP, true, false)
      else
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Title_UIBP, false, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshTeamState"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 25, 187, 65, 178, 220, 92, 81, 17, 12))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_State, false, false)
      goto lbl_137
      if tonumber(_ARG_0_.uid) == tonumber(108) and tonumber(108) ~= DataMgr.roleData.uid then
      else
        ::lbl_137::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not true and require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) then
      end
      if _ARG_0_.eShowLocationType ~= U2.EShowLocationType.MainCity then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshBirthdayInfo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 15, 183, 82, 171, 231, 76, 81, 28, 32, 252, 221, 183))
      if _ARG_0_.isSelf then
        if require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))) and require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).MySocialCard then
        end
      else
      end
      if LobbySystem.CheckOpen(BP_ENUM_ONLY_FRIENFRIEND_PRIVACY) then
        if require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 6, 28, 246, 223, 161, 119, 136, 114, 134, 40, 170, 84, 182, 225, 79, 111, 16, 29, 251, 215))).OnlyFriend(_ARG_0_.uid, _ARG_1_.birthday_privacy_value, 1) or _ARG_1_.birthday_privacy_value == 1 then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSocialCardLabelInfo"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.isSelf then
        if require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))) and require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).MySocialCard then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshSocialCardLabelInfo"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 30, 177, 67, 182, 238, 68, 115, 4, 27, 246, 247, 185, 107),
        U1(173, 124, 76, 39, 20, 244)
      }))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.HorizontalBox_Label, false, false)
      if _ARG_1_ == nil or not next(_ARG_1_) then
        return
      end
      if _ARG_1_.tendency and type(_ARG_1_.tendency) == U1(166, 101, 104, 43, 23, 233) and require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetTendencyList()[_ARG_1_.tendency] then
      end
      if _ARG_1_.play_date and type(_ARG_1_.play_date) == U1(166, 101, 104, 43, 23, 233) then
      end
      if _ARG_1_.play_time and type(_ARG_1_.play_time) == U1(166, 101, 104, 43, 23, 233) then
      end
      if (require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetDataList()[_ARG_1_.play_date] or U1()) ~= U1() and (require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetTimeList()[_ARG_1_.play_time] or U1()) ~= U1() then
      elseif (require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetDataList()[_ARG_1_.play_date] or U1()) == U1() and (require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetTimeList()[_ARG_1_.play_time] or U1()) == U1() then
      else
      end
      if tostring(require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetDataList()[_ARG_1_.play_date] or U1()) .. tostring(require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetTimeList()[_ARG_1_.play_time] or U1()) and tostring(require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetDataList()[_ARG_1_.play_date] or U1()) .. tostring(require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetTimeList()[_ARG_1_.play_time] or U1()) ~= U1() then
      end
      goto lbl_280
      ::lbl_280::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if ({})[true] then
      else
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshFriendState"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 15, 183, 82, 171, 231, 76, 81, 28, 32, 252, 221, 183))
      if _ARG_1_.frd_status_end_time and require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 187, 246, 85, 69, 42, 12, 246, 194, 164))).GetServerTimeInSec() > _ARG_1_.frd_status_end_time then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid) ~= 0 then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid) and 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid) ~= 13 then
        if CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid))) and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid))).type ~= require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 21, 227, 210, 173, 107, 176, 47, 129, 44, 170, 85, 172, 161, 120, 92, 4, 16, 247, 201, 139, 125),
          U1(169, 100, 112, 58, 55, 245, 205, 68)
        }))).Enum_TeamState.Stealth then
        end
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_main_city_status):GetMCPlayerStatus(_ARG_0_.uid) == 13 and _ARG_1_.frd_custom_txt and _ARG_1_.frd_custom_txt ~= U1() and _ARG_1_.frd_icon_idx and _ARG_1_.frd_icon_idx ~= 0 then
      end
      goto lbl_486
      if table.concat({
        U1(231, 87, 100, 36, 23, 180, 237, 100, 184, 99, 177, 56, 182, 68, 186, 237, 93, 15, 52, 13, 238, 202, 187, 54, 172, 52, 148, 57, 155, 77, 176, 229, 65, 101, 44, 70, 212, 201, 185, 100),
        U1(173, 99, 42, 44, 31, 244, 210, 64, 160, 125, 186, 104, 254, 111)
      }) .. tostring(_ARG_1_.frd_icon_idx) .. U1(151, 96, 107, 46, 92, 254, 213, 70, 149, 37, 186, 108, 145, 5, 255, 192) .. tostring(_ARG_1_.frd_icon_idx) .. U1(151, 96, 107, 46) then
      end
      ::lbl_486::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshInteractButton"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 43, 231, 205, 186, 124, 156, 52, 188, 35, 170, 69, 173, 238, 75, 68, 39, 28, 230, 207, 183, 103))
      if not _ARG_0_.UIRoot then
        return
      end
      if _ARG_0_.isSelf then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.VerticalBox_Interact, false, false)
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.VerticalBox_Play, false, false)
        return
      end
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.VerticalBox_Interact, true, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.VerticalBox_Play, false, false)
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) then
      else
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) and not GameStatus.IsCollectionHallMode() then
      else
      end
      if _ARG_0_:GetPlayerCustomSwitches((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) and _ARG_0_:GetPlayerCustomSwitches((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))).collectLevel then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TryRefreshButtonState"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 45, 240, 210, 154, 124, 137, 46, 144, 62, 182, 98, 170, 251, 92, 95, 11, 58, 230, 218, 172, 108))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldShowTeamButton"] = function(_ARG_0_, _ARG_1_)
    do
      if GameStatus.IsInFightingPHomeMode() then
        log(bWriteLog and table.concat({
          U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 42, 234, 196, 189, 117, 139, 15, 157, 34, 169, 116, 186, 238, 69, 114, 16, 29, 230, 212, 182, 41),
          U1(165, 117, 37, 32, 28, 187, 208, 70, 146, 41)
        }))
        return false
      end
      if _ARG_1_ and _ARG_1_.game_sub_mode and _ARG_1_.game_sub_mode == require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 29, 22, 239, 206, 230, 113, 128, 49, 144, 18, 179, 65, 188, 253, 71, 67))).Home_SubMode.Visit then
        return false
      end
      if GameStatus.IsCollectionHallMode() then
        return false
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 21, 227, 210, 173, 107, 176, 47, 129, 44, 170, 85, 172, 161, 120, 92, 4, 16, 247, 201, 139, 125),
        U1(169, 100, 112, 58, 39, 239, 209, 69)
      }))).IsInCollectionHall(_ARG_1_) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshTeamButtonState"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 25, 187, 65, 178, 205, 93, 68, 17, 6, 252, 232, 172, 104),
        U1(188, 117, 37, 58, 6, 250, 204, 92, 140, 108, 216, 125)
      }), _ARG_1_)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.WidgetSwitcher_Team, false, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.SizeBox_10, false, false)
      if not _ARG_0_:ShouldShowTeamButton(_ARG_1_) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id > 0 and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id) and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id).type == require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 21, 227, 210, 173, 107, 176, 47, 129, 44, 170, 85, 172, 161, 120, 92, 4, 16, 247, 201, 139, 125),
        U1(169, 100, 112, 58, 55, 245, 205, 68)
      }))).Enum_TeamState.Busy then
      end
      if _ARG_1_.online == 0 then
        return
      end
      if (U2.IsIdleOrFree(_ARG_1_) or U2.ISLANDIdle(_ARG_1_) or U2.IsInHomeIdle(_ARG_1_) or U2.WoWIdle(_ARG_1_) or U2.IsMainCityIdle(_ARG_1_)) and require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 1, 28, 227, 198, 189, 105, 193, 48, 154, 42, 183, 67, 128, 251, 77, 81, 8, 54, 231, 203))).CanInvite() and not true then
        if _ARG_1_ and _ARG_1_.is_video_inspect or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetIsVideoInspect(_ARG_0_.uid) then
        else
        end
      elseif (U2.IsTeam(_ARG_1_) or U2.ISLANDInTeam(_ARG_1_) or U2.IsInHomeTeam(_ARG_1_) or U2.WoWInTeam(_ARG_1_) or U2.IsMainCityTeam(_ARG_1_)) and not require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 1, 28, 227, 198, 189, 105, 193, 48, 154, 42, 183, 67, 128, 251, 77, 81, 8, 54, 231, 203))).IsInTeam() and _ARG_1_.currentTeamAmount < _ARG_1_.maxTeamAmount and not true then
      elseif require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) and U2.IsDoNotBother(_ARG_1_) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshGameplayButtonState"] = function(_ARG_0_, _ARG_1_)
    do
      log_tree(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 10, 191, 77, 186, 255, 68, 81, 28, 43, 231, 207, 172, 102),
        U1(166, 67, 113, 40, 6, 254, 152, 90, 139, 45, 145, 40, 189, 16, 242, 191)
      }), _ARG_1_)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.VerticalBox_Play, false, false)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id > 0 and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id) and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id).type == require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 21, 227, 210, 173, 107, 176, 47, 129, 44, 170, 85, 172, 161, 120, 92, 4, 16, 247, 201, 139, 125),
        U1(169, 100, 112, 58, 55, 245, 205, 68)
      }))).Enum_TeamState.Busy then
      end
      if true then
        return
      end
      if U2.IsDoNotBother(_ARG_1_) then
        if require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
          U1(172)
        }))).IsMyFriend(_ARG_0_.uid) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshPlayerData"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 43, 231, 205, 186, 124, 156, 52, 165, 33, 191, 89, 186, 253, 108, 81, 17, 8))
      _ARG_0_:_RefreshRankData(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshRankData"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 31, 191, 78, 180, 203, 73, 68, 4))
      if not _ARG_1_.rankdata then
      elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetProfileRankdataMaxRating(_ARG_1_.rankdata) and 0 < ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_segment_title):GetProfileRankdataMaxRating(_ARG_1_.rankdata) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshHomeData"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 5, 177, 77, 186, 203, 73, 68, 4))
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile):GetHomeProfileByUid(_ARG_0_.uid, false) and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile):GetHomeProfileByUid(_ARG_0_.uid, false).grow_info and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_profile):GetHomeProfileByUid(_ARG_0_.uid, false).grow_info.level then
      else
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).IsMyFriend(_ARG_0_.uid) or _ARG_0_.isSelf then
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 29, 22, 239, 206, 230, 85, 128, 62, 151, 52, 240, 76, 176, 232, 65, 83, 58, 5, 253, 217, 186, 112),
        U1(151, 120, 106, 36, 23, 196, 221, 71, 139, 62, 156, 2, 167, 68, 170, 242, 103, 84, 7, 28, 231, 244, 161, 109, 138, 49)
      }))).GetShowInfo(_ARG_0_.uid).bShow then
      else
        _ARG_0_.bNeedRefreshNormalInfoNum = _ARG_0_.bNeedRefreshNormalInfoNum + 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshHomeGameplayData"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 5, 177, 77, 186, 200, 73, 93, 0, 25, 254, 218, 161, 77),
        U1(169, 100, 100)
      }))
      log_tree(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 5, 177, 77, 186, 200, 73, 93, 0, 25, 254, 218, 161, 77),
        U1(169, 100, 100, 105, 22, 254, 204, 72, 150, 32, 197, 96, 238)
      }), _ARG_1_)
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 29, 22, 239, 206, 184, 120, 157, 40, 140, 99, 150, 79, 178, 234, 120, 81, 23, 29, 235, 238, 172, 96),
        U1(164)
      }))).IsShowParty(_ARG_0_.uid, _ARG_1_.party_show_info) then
        if not _ARG_0_.Common_Home_Party_Item_UIBP then
          _ARG_0_.Common_Home_Party_Item_UIBP = require(UIManager.UI_Config.Common_Home_Party_Item_UIBP.moduleName)({
            uid = _ARG_0_.uid,
            partyInfo = _ARG_1_.party_show_info
          })
        else
        end
      else
        _ARG_0_.bNeedRefreshNormalInfoNum = _ARG_0_.bNeedRefreshNormalInfoNum + 1
      end
      if 0 < _ARG_0_.bNeedRefreshNormalInfoNum then
        _ARG_0_.bNeedRefreshNormalInfoNum = _ARG_0_.bNeedRefreshNormalInfoNum - 1
      end
      if 0 < _ARG_0_.bNeedRefreshNormalInfoNum then
        _ARG_0_.bNeedRefreshNormalInfoNum = _ARG_0_.bNeedRefreshNormalInfoNum - 1
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshDefaultHomeInfo"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 38, 208, 206, 174, 107, 138, 47, 157, 9, 187, 70, 190, 250, 68, 68, 45, 6, 255, 222, 145, 103),
        U1(174, 127)
      }))
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Info1, false, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Info2, true, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Info3, true, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Info4, false, false)
      _ARG_0_.bNeedRefreshNormalInfoNum = 0
      _ARG_0_.UIRoot.TextBlock_ProsperityValue:SetText((U1(248)))
      _ARG_0_.UIRoot.TextBlock_PopularityValue:SetText((U1(248)))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshCharmLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      printf(table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 43, 231, 205, 186, 124, 156, 52, 182, 37, 191, 82, 178, 195, 77, 70, 0, 5, 178, 213, 155, 97),
        U1(169, 98, 104, 5, 23, 237, 221, 69, 223, 113, 197, 120, 189, 28, 239, 253, 107, 72, 26, 14, 193, 195, 169, 107, 130, 124, 200, 109, 251, 83)
      }), _ARG_1_, _ARG_2_)
      if false == _ARG_2_ then
        printf(bWriteLog and table.concat({
          U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 43, 231, 205, 186, 124, 156, 52, 182, 37, 191, 82, 178, 195, 77, 70, 0, 5, 178, 217, 139, 97),
          U1(167, 103, 70, 33, 19, 233, 213, 9, 194, 108, 131, 60, 162, 67, 170)
        }))
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_137, false)
        return
      end
      if nil == _ARG_2_ then
        _ARG_2_ = require((table.concat({
          U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 131, 81, 166, 241, 123, 73, 1, 0, 172, 232, 164, 112, 138, 50, 129, 99, 178, 79, 184, 230, 75, 30, 38, 1, 243, 201, 181, 39),
          U1(139, 120, 100, 59, 31, 206, 204, 64, 147, 63)
        }))).IsPlayerShownCharmDisplay(tonumber(_ARG_0_.uid))
        if false == _ARG_2_ then
          return
        end
      end
      if _ARG_1_ == nil then
        _ARG_1_ = require((table.concat({
          U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 131, 81, 166, 241, 123, 73, 1, 0, 172, 232, 164, 112, 138, 50, 129, 99, 178, 79, 184, 230, 75, 30, 38, 1, 243, 201, 181, 39),
          U1(139, 120, 100, 59, 31, 206, 204, 64, 147, 63)
        }))).CalculateCharmLevel((require((table.concat({
          U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 131, 81, 166, 241, 123, 73, 1, 0, 172, 232, 164, 112, 138, 50, 129, 99, 178, 79, 184, 230, 75, 30, 38, 1, 243, 201, 181, 39),
          U1(139, 120, 100, 59, 31, 206, 204, 64, 147, 63)
        }))).GetCharmValueByUid(tonumber(_ARG_0_.uid))))
      end
      if CDataTable.GetTableData(U1(133, 113, 108, 39, 49, 242, 204, 80, 188, 36, 132, 47, 163, 124, 170, 233, 93, 76, 54, 31, 229), _ARG_1_) and CDataTable.GetTableData(U1(133, 113, 108, 39, 49, 242, 204, 80, 188, 36, 132, 47, 163, 124, 170, 233, 93, 76, 54, 31, 229), _ARG_1_).NameCardParam and CDataTable.GetTableData(U1(133, 113, 108, 39, 49, 242, 204, 80, 188, 36, 132, 47, 163, 124, 170, 233, 93, 76, 54, 31, 229), _ARG_1_).NameCardParam ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCustomPresentation"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 44, 242, 207, 169, 109, 138, 31, 128, 62, 170, 79, 178, 223, 90, 85, 22, 12, 252, 207, 185, 125),
        U1(161, 127, 107)
      }))
      if _ARG_0_.LobbyChat_InformationCustomDetail_UIBP then
        _ARG_0_.LobbyChat_InformationCustomDetail_UIBP:SetDataByUid(_ARG_0_.uid)
        _ARG_0_.LobbyChat_InformationCustomDetail_UIBP:HideBg()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowReturnFlag"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 26, 21, 230, 205, 186, 112, 138, 50, 145, 99, 178, 79, 184, 230, 75, 111, 10, 5, 246, 221, 170, 96),
        U1(173, 126, 97, 22, 17, 250, 202, 76)
      }))).IsRejoinPlayerForTag((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowRPFlag"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPeakGameRank"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(139, 120, 100, 61, 63, 254, 214, 92, 160, 14, 181, 103, 157, 85, 187, 220, 84, 65, 6, 10, 235, 200, 154, 120, 129, 55))
      if tonumber(_ARG_1_.uid) == tonumber(DataMgr.roleData.uid) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReportTLog"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_ = tonumber(_ARG_1_)
      if _ARG_1_ and 0 < _ARG_1_ then
        if require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 1, 28, 227, 198, 189, 105, 193, 48, 154, 42, 183, 67, 128, 251, 77, 81, 8, 54, 231, 203))).GetMemberInfo(_ARG_1_) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCorpsSummaryRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if GetCorpsSummaryIcon(_ARG_3_) ~= U1() then
      end
      if (_ARG_3_.position or 0) == 0 then
      elseif (_ARG_3_.position or 0) == 1 then
      elseif (_ARG_3_.position or 0) == 2 then
      elseif (_ARG_3_.position or 0) == 3 then
      else
      end
      if U2.CDataTable.GetTableData(U1(171, 127, 119, 57, 1, 196, 217, 69, 150, 45, 150, 2, 186, 81, 173, 243, 93), _ARG_0_.corp_alias_id or 0) and U2.CDataTable.GetTableData(U1(171, 127, 119, 57, 1, 196, 217, 69, 150, 45, 150, 2, 186, 81, 173, 243, 93), _ARG_0_.corp_alias_id or 0).Default == 1 then
      elseif U2.CDataTable.GetTableData(U1(171, 127, 119, 57, 1, 196, 217, 69, 150, 45, 150, 2, 186, 81, 173, 243, 93), _ARG_0_.corp_alias_id or 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInteract"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(139, 120, 100, 61, 63, 254, 214, 92, 160, 14, 181, 103, 129, 94, 134, 241, 76, 69, 7, 24, 225, 223))
      if not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction):GetInteractInfo(_ARG_3_))) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction):GetInteractInfo(_ARG_3_).status and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction):GetInteractInfo(_ARG_3_).status ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction).FireType.initial and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction):GetIconInfoByID(_ARG_3_) ~= nil and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction):GetInteractInfo(_ARG_3_).score and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_interaction):GetInteractInfo(_ARG_3_).score > 0 then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordDataHighFrequency(_ARG_0_.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordDataHighFrequency(_ARG_0_.uid).add_friend_days then
      end
      if true or 0 < (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list):GetIntimacy(_ARG_0_.uid) or 0) or 0 < ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_friend_interact_record):GetCumulativeInteractRecordDataHighFrequency(_ARG_0_.uid).add_friend_days then
        if not true and not (0 < (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list):GetIntimacy(_ARG_0_.uid) or 0)) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFriendState"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_BG1, false, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_LeftBG, false, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Image_LeftBG, false, false)
      if _ARG_1_.frd_status_end_time and require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 187, 246, 85, 69, 42, 12, 246, 194, 164))).GetServerTimeInSec() > _ARG_1_.frd_status_end_time then
      end
      _ARG_0_.isCanShowMood = false
      if 0 and 0 < 0 and 0 ~= 13 then
        if CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), 0) and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), 0).type ~= require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 5, 21, 227, 210, 173, 107, 176, 47, 129, 44, 170, 85, 172, 161, 120, 92, 4, 16, 247, 201, 139, 125),
          U1(169, 100, 112, 58, 55, 245, 205, 68)
        }))).Enum_TeamState.Stealth then
          _ARG_0_.isCanShowMood = true
        end
      elseif 0 and 0 == 13 and _ARG_1_.frd_custom_txt and _ARG_1_.frd_custom_txt ~= U1() and _ARG_1_.frd_icon_idx and _ARG_1_.frd_icon_idx ~= 0 then
        _ARG_0_.isCanShowMood = true
      end
      if _ARG_0_.isCanShowMood then
      else
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 26, 21, 230, 205, 186, 112, 138, 50, 145, 99, 178, 79, 184, 230, 75, 111, 10, 5, 246, 221, 170, 96),
        U1(173, 126, 97, 22, 17, 250, 202, 76)
      }))).IsRejoinPlayerForTag(_ARG_1_) then
        if _ARG_0_.uid == tonumber(DataMgr.roleData.uid) then
        end
        if not _ARG_0_.returnTagItem then
          _ARG_0_.returnTagItem = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.SizeBox_Return, UIManager.UI_Config.ReturnActivity_Player_Tag_Item, {
            uid = _ARG_0_.uid,
            type = require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 7, 28, 246, 222, 186, 119, 176, 61, 150, 57, 183, 86, 182, 251, 81, 30, 23, 12, 230, 206, 170, 103),
              U1(151, 113, 102, 61, 27, 237, 209, 93, 134, 19, 136, 60, 173, 66, 160)
            }))).Enum_Tag_ShowType.Me,
            dir = 1,
            bOnDarkBg = true
          })
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_mood"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.isCanShowMood then
        return
      end
      _ARG_0_.isShowMood = not _ARG_0_.isShowMood
      if _ARG_0_.isShowMood then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_mood, true, false)
      else
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_mood, false, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_good"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_SocialHall"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterHome"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Home"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 43, 183, 84, 241, 227, 71, 87, 12, 10, 205, 221, 177, 125),
        U1(158, 117, 119, 58, 27, 244, 214, 118, 155, 35, 146, 51, 162, 95, 174, 251)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch):CheckHomeLimit(true) then
        return
      end
      if require((table.concat({
        U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 89, 161, 248, 84, 69, 33, 11, 227, 194, 166, 112, 129, 59, 219, 10, 191, 77, 186, 223, 68, 81, 28, 71, 214, 218, 172, 104),
        U1(230, 67, 108, 39, 21, 247, 221, 125, 141, 45, 140, 51, 154, 95, 160, 243)
      }))).IsSelfInTraining() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_CardCollect"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicCollectionHallEntry):EntryVisitCollectionHall(_ARG_0_.uid, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicCollectionHallEntry).Enum_EnterPlanCHSource.Lobby_FriendDetail, true) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButtonFire"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if slua.isValid((require((U1(143, 113, 104, 44, 62, 238, 217, 7, 184, 45, 136, 56, 141, 95, 189, 250, 22, 100, 20, 13, 227, 133, 143, 120, 130, 57, 133, 33, 191, 89, 155, 238, 92, 81))).GetPlayerController())) and require((U1(143, 113, 104, 44, 62, 238, 217, 7, 184, 45, 136, 56, 141, 95, 189, 250, 22, 100, 20, 13, 227, 133, 143, 120, 130, 57, 133, 33, 191, 89, 155, 238, 92, 81))).GetPlayerController().bPlanBT then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_FriendsGoTo"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if slua.isValid((require((U1(143, 113, 104, 44, 62, 238, 217, 7, 184, 45, 136, 56, 141, 95, 189, 250, 22, 100, 20, 13, 227, 133, 143, 120, 130, 57, 133, 33, 191, 89, 155, 238, 92, 81))).GetPlayerController())) and require((U1(143, 113, 104, 44, 62, 238, 217, 7, 184, 45, 136, 56, 141, 95, 189, 250, 22, 100, 20, 13, 227, 133, 143, 120, 130, 57, 133, 33, 191, 89, 155, 238, 92, 81))).GetPlayerController().bPlanBT then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoHome"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:OnClickButton_Home()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomeLock"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      ShowNotice(19810167)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHome_Download"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 43, 183, 84, 241, 227, 71, 87, 12, 10, 205, 221, 177, 125),
        U1(158, 117, 119, 58, 27, 244, 214, 118, 155, 35, 146, 51, 162, 95, 174, 251)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_CollectHall_Go"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:OnClickButton_CardCollect()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Collect_DownLoad"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 43, 183, 84, 241, 227, 71, 87, 12, 10, 205, 221, 177, 125),
        U1(158, 117, 119, 58, 27, 244, 214, 118, 155, 35, 146, 51, 162, 95, 174, 251)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 24, 24, 246, 200, 160, 55, 131, 51, 146, 36, 189, 127, 178, 224, 76, 85, 58, 4, 245, 201))).IsSocialIslandMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_GiveBP"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_hover_club_profile_click"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(232, 83, 109, 40, 6, 214, 221, 71, 138, 19, 167, 13, 244, 95, 161, 192, 80, 79, 3, 28, 240, 244, 171, 117, 154, 62, 170, 61, 172, 79, 185, 230, 68, 85, 58, 10, 254, 210, 187, 98),
        U1(232)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_.uid) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsByBlacklist(_ARG_0_.uid) then
        return
      end
      if require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 24, 24, 246, 200, 160, 55, 131, 51, 146, 36, 189, 127, 178, 224, 76, 85, 58, 4, 245, 201))).IsSocialIslandMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPlayerInvisible"] = function(_ARG_0_)
    do
      if not (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id) or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id <= 0 then
      elseif CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id) and CDataTable.GetTableData(U1(142, 98, 108, 44, 28, 255, 235, 93, 158, 56, 144, 46, 141, 86, 168), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_id).type == 7 then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_hover_moment_click"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 43, 183, 84, 241, 227, 71, 87, 12, 10, 205, 221, 177, 125),
        U1(158, 117, 119, 58, 27, 244, 214, 118, 155, 35, 146, 51, 162, 95, 174, 251)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if require((U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 24, 24, 246, 200, 160, 55, 131, 51, 146, 36, 189, 127, 178, 224, 76, 85, 58, 4, 245, 201))).IsSocialIslandMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRemark"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.friend_remark, _ARG_0_.uid)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_SouvenirsClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedPinbi"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.uid then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_entry):IsPlanPHMode() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowHomeBlackListPop"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_.uid) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowCommonBlackListPop"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_blacklist):IsBlacklist(_ARG_0_.uid) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_InteractRecordClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.Lobby_RoleInfo_IntimateRelationship_RecordMain_UIBP, tonumber(_ARG_0_.uid), 1)
      _ARG_0_:CloseSelf()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomeEntry"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U2(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 43, 183, 84, 241, 227, 71, 87, 12, 10, 205, 221, 177, 125),
        U2(158, 117, 119, 58, 27, 244, 214, 118, 155, 35, 146, 51, 162, 95, 174, 251)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_home_switch):CheckHomeSwitchOpen(false) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCollectHallEntry"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).collect_data then
        if not require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 115, 176, 236, 65, 81, 9, 37, 253, 217, 186, 112),
          U1(230, 92, 106, 46, 27, 248, 231, 122, 188, 19, 161, 50, 185, 94, 163, 240, 89, 68, 33, 22, 237, 199, 187)
        }))).CheckPlanCHIsDownloaded(tonumber(DataMgr.roleData.uid)) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyPlanBTHideWidgets"] = function(_ARG_0_)
    do
      if not _ARG_0_.IsPlanBTParam then
        return
      end
      if not _ARG_0_.UIRoot or not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      goto lbl_139
      if _ARG_0_.UIRoot[U1(138, 101, 113, 61, 29, 245, 231, 106, 147, 57, 135)] then
      end
      ::lbl_139::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_262
      if _ARG_0_.UIRoot[159] then
      end
      ::lbl_262::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_TV"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateCardSkin"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.CanvasPanel_Download then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Download, false)
      end
      _ARG_0_.UIRoot.WidgetSwitcher_Effect:SetActiveWidgetIndex(0)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
        U1(164, 79, 102, 40, 0, 255)
      }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).BPType == 1 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP ~= U1() and require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 191, 254, 83, 127, 0, 13, 235, 199))).IsPufferDownloaded(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP) then
          return
        else
        end
        _ARG_0_.needDownloadPakNames = {}
        if U2.IsFITVersion() then
        else
          if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.item_display_fallback_logic):IsSmallPackageResourceMissing((require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))))) then
            goto lbl_358
            if require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) and require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) ~= U1() and not _ARG_0_.needDownloadPakNames[require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid)))] then
              _ARG_0_.needDownloadPakNames[require((table.concat({
                U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
                U1(164, 79, 102, 40, 0, 255)
              }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid)))] = true
            end
            ::lbl_358::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP ~= U1() and require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 191, 254, 83, 127, 0, 13, 235, 199))).IsPufferDownloaded(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP) then
            _ARG_0_.isShowSkin = true
            if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetCrateFrameBGCfg((require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))))) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetCrateFrameBGCfg((require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))))).Level == 3 then
            end
            _ARG_0_.card_skin_bp = _ARG_0_:CreateChildWindowWithBpPath(U1(139, 113, 107, 63, 19, 232, 232, 72, 145, 41, 137, 2, 139, 86, 169, 250, 91, 84, 42, 73, 178, 153), UIManager.UI_Config.Lobby_RoleInfo_EffectSkin_Item_UIBP, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP, U1(137, 101, 113, 38, 45, 215, 215, 70, 143), {["bEnableGyroscope"] = true})
          else
            _ARG_0_.isShowSkin = false
            if require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
              U1(151, 125, 100, 39, 19, 252, 221, 91)
            }))).GetPakName(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP) ~= U1() then
              _ARG_0_.needDownloadPakNames[require((table.concat({
                U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
                U1(151, 125, 100, 39, 19, 252, 221, 91)
              }))).GetPakName(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
                U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
                U1(164, 79, 102, 40, 0, 255)
              }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).EffectBP)] = true
            end
          end
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).SkinPath and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
          U1(164, 79, 102, 40, 0, 255)
        }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).SkinPath ~= U1() then
          if require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 191, 254, 83, 127, 0, 13, 235, 199))).IsTextureDownloadedByPath(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).SkinPath, true) then
          elseif require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
            U1(151, 125, 100, 39, 19, 252, 221, 91)
          }))).GetPakName(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).SkinPath) and require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
            U1(151, 125, 100, 39, 19, 252, 221, 91)
          }))).GetPakName(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
            U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
            U1(164, 79, 102, 40, 0, 255)
          }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).SkinPath) ~= U1() then
            _ARG_0_.needDownloadPakNames[require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
              U1(151, 125, 100, 39, 19, 252, 221, 91)
            }))).GetPakName(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetSkinPath(require((table.concat({
              U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 55, 163, 57, 147, 57, 240, 76, 176, 232, 65, 83, 58, 26, 253, 216, 177, 104),
              U1(164, 79, 102, 40, 0, 255)
            }))).GetCarteFrameEquipIdByProfile((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))), true).SkinPath)] = true
          end
        else
        end
      end
      return
    end
  end,
  ["UpdateProfileFrame"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_profileframe):IsFeatureOpen() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).profile_frame or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).profile_frame == 62310001 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_profileframe):GetSkinPath(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).profile_frame) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_profileframe):GetSkinPath(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).profile_frame) ~= U1() then
        if require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 191, 254, 83, 127, 0, 13, 235, 199))).IsPufferDownloaded(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_profileframe):GetSkinPath(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).profile_frame)) then
          _ARG_0_.profile_frame_bp = _ARG_0_:CreateChildWindowWithBpPath(U1(142, 98, 100, 36, 23, 201, 215, 70, 139), UIManager.UI_Config.Lobby_RoleInfo_EffectSkin_Item_UIBP, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_profileframe):GetSkinPath(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).profile_frame))
        else
        end
      else
      end
      if _ARG_0_.profile_frame_bp and _ARG_0_.profile_frame_bp.UIRoot.Anim_In then
        if _ARG_0_.FrameAnimPlayed then
          return
        end
        _ARG_0_.FrameAnimPlayed = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdataRelationship"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).GetRelation(_ARG_0_.uid) ~= 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCarteSkin"] = function(_ARG_0_)
    do
      if _ARG_0_.card_skin_bp then
        _ARG_0_.card_skin_bp:Close()
        _ARG_0_.card_skin_bp = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCarteFullSkin"] = function(_ARG_0_)
    do
      if _ARG_0_.card_full_skin_bp then
        _ARG_0_.card_full_skin_bp:Close()
        _ARG_0_.card_full_skin_bp = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateFullFrameEffectSkin"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 44, 242, 207, 169, 109, 138, 26, 128, 33, 178, 102, 173, 238, 69, 85, 32, 15, 244, 222, 187, 125),
        U1(155, 123, 108, 39)
      }))
      log_tree(bWriteLog and table.concat({
        U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 44, 242, 207, 169, 109, 138, 26, 128, 33, 178, 102, 173, 238, 69, 85, 32, 15, 244, 222, 187, 125),
        U1(155, 123, 108, 39, 82, 232, 211, 64, 145, 19, 140, 51, 168, 95, 245)
      }), _ARG_1_)
      _ARG_0_:ClearCarteFullSkin()
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetCrateFrameBGCfg(_ARG_2_) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetCrateFrameBGCfg(_ARG_2_).Level == 3 then
      end
      _ARG_0_.card_full_skin_bp = _ARG_0_:CreateChildWindowWithBpPath(U1(143, 98, 108, 45, 34, 250, 214, 76, 147, 19, 160, 59, 168, 85, 172, 235, 8, 17), UIManager.UI_Config.Lobby_RoleInfo_EffectSkin_Item_UIBP, _ARG_1_.EffectBP, U1(137, 101, 113, 38, 45, 215, 215, 70, 143), {["bEnableGyroscope"] = true})
      if _ARG_0_.card_full_skin_bp then
        _ARG_0_.isShowSkin = true
      else
        _ARG_0_.isShowSkin = false
      end
      _ARG_0_.needDownloadPakNames = {}
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateSkinDownloadPollTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.needDownloadPakNames and next(_ARG_0_.needDownloadPakNames) then
        if not _ARG_0_._skinDownloadPollTimer then
          log(bWriteLog and table.concat({
            U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 44, 242, 207, 169, 109, 138, 15, 158, 36, 176, 100, 176, 248, 70, 92, 10, 8, 246, 235, 183, 101),
            U1(164, 68, 108, 36, 23, 233, 152, 90, 139, 45, 151, 41)
          }))
          _ARG_0_._skinDownloadPollTimer = _ARG_0_:AddTimerLoop(1.0, function()
            if not slua.isValid(U1.UIRoot) then
              U1:StopSkinDownloadPollTimer()
              return
            end
            U1:UpdateCardSkin()
            return
          end, TIMER_INFINITE, 1.0)
        end
      else
        _ARG_0_:StopSkinDownloadPollTimer()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopSkinDownloadPollTimer"] = function(_ARG_0_)
    do
      if _ARG_0_._skinDownloadPollTimer then
        log(bWriteLog and table.concat({
          U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 42, 246, 196, 184, 74, 132, 53, 155, 9, 177, 87, 177, 227, 71, 81, 1, 57, 253, 215, 180, 93),
          U1(161, 125, 96, 59, 82, 232, 204, 70, 143)
        }))
        _ARG_0_:RemoveTimer(_ARG_0_._skinDownloadPollTimer)
        _ARG_0_._skinDownloadPollTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadCarteBGEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and U1(152, 117, 119, 58, 29, 245, 217, 69, 160, 5, 139, 59, 161, 111, 154, 214, 122, 112, 79, 53, 237, 202, 172, 90, 142, 46, 129, 40, 156, 103, 154, 233, 78, 85, 6, 29))
      if not _ARG_1_ or _ARG_1_ == U1() then
        _ARG_0_.isShowSkin = false
        return
      end
      if require((U1(171, 124, 108, 44, 28, 239, 150, 74, 144, 33, 136, 50, 160, 30, 191, 254, 83, 127, 0, 13, 235, 199))).IsPufferDownloaded(_ARG_1_) then
        _ARG_0_.isShowSkin = true
        if _ARG_2_ then
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetCrateFrameBGCfg(_ARG_3_) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleinfo_carte_frame):GetCrateFrameBGCfg(_ARG_3_).Level == 3 then
        end
        _ARG_0_.card_skin_bp = _ARG_0_:CreateChildWindowWithBpPath(U1(139, 113, 107, 63, 19, 232, 232, 72, 145, 41, 137, 2, 139, 86, 169, 250, 91, 84, 42, 73, 178, 153), UIManager.UI_Config.Lobby_RoleInfo_EffectSkin_Item_UIBP, _ARG_1_, U1(137, 101, 113, 38, 45, 215, 215, 70, 143), {["bEnableGyroscope"] = true})
        return
      end
      _ARG_0_.isShowSkin = false
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
        U1(151, 125, 100, 39, 19, 252, 221, 91)
      }))).GetPakName(_ARG_1_) and require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
        U1(151, 125, 100, 39, 19, 252, 221, 91)
      }))).GetPakName(_ARG_1_) ~= U1() then
        _ARG_0_.needDownloadPakNames = _ARG_0_.needDownloadPakNames or {}
        _ARG_0_.needDownloadPakNames[require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 17, 22, 245, 197, 164, 118, 142, 56, 219, 61, 171, 70, 185, 234, 90, 30, 21, 28, 244, 221, 189, 123),
          U1(151, 125, 100, 39, 19, 252, 221, 91)
        }))).GetPakName(_ARG_1_)] = true
      end
      if _ARG_4_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = UIManager
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HaveNameColor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.isDefultNameColor = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager):GetUserData(_ARG_1_.uid) == ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager).DEFAULT_PLAN_ID
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyTextSkinStyle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_1_.SetColorAndOpacity then
        _ARG_1_:SetColorAndOpacity(_ARG_2_)
      end
      if _ARG_1_.Font then
        if _ARG_0_.isShowSkin then
          _ARG_1_.Font.OutlineSettings.OutlineSize = 1
          _ARG_1_.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
        else
          _ARG_1_.Font.OutlineSettings.OutlineSize = 0
          _ARG_1_.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeTextColorBySkin"] = function(_ARG_0_)
    do
      do return end
      if _ARG_0_.isShowSkin then
      else
      end
      goto lbl_116
      ::lbl_116::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_.isShowSkin then
      else
      end
      goto lbl_259
      ::lbl_259::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).GetRemarkNamePure(_ARG_0_.uid) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClipString"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return (_ENV())
      end
      if 14 < U1.require((_ENV(171, 127, 104, 36, 29, 245, 150, 90, 139, 62, 140, 51, 169, 111, 186, 235, 81, 76))).GetCharactersLength(_ARG_0_, 2) then
        return U1.LocUtil.LocalizeResFormat(8600314, U1.require((_ENV(171, 127, 104, 36, 29, 245, 150, 90, 139, 62, 140, 51, 169, 111, 186, 235, 81, 76))).ClipString(_ARG_0_, 14, 2))
      else
        return _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseChatMain"] = function(_ARG_0_)
    do
      if UIManager.IsUIShow(UIManager.UI_Config.ui_chat_main) then
        UIManager.CloseUI(UIManager.UI_Config.ui_chat_main)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPlayerCustomSwitches"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return {
          collectLevel = true,
          alias = true,
          pass = true,
          wowPass = true,
          gender = true,
          nationFlag = true,
          certification = true
        }
      end
      if _ARG_1_.friend_list_bits_switch == nil then
      end
      do return {
        collectLevel = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.CollectLevel),
        alias = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.Alias),
        pass = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.Pass),
        wowPass = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.WowPass),
        gender = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.Gender),
        nationFlag = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.NationFlag),
        certification = require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).GetSwitch(require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).CalculateDefaultSwitch(_ARG_1_), require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 233, 90, 89, 0, 7, 246, 215, 177, 122),
          U1(188, 79, 102, 60, 1, 239, 215, 68, 160, 57, 145, 52, 162, 67)
        }))).SWITCH_MASK.Certification)
      } end
      do return end
      _ARG_1_ = U1.gender
    end
  end,
  ["OnClickButton_Island"] = function(_ARG_0_)
    do
      if not _ARG_0_._isLandState then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.QRcodeRestrictManager):IsRestrictBatlleAll() then
        return
      end
      if _ARG_0_._isLandState == 1 then
        if #require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 25, 22, 224, 201, 177, 70, 140, 52, 148, 57, 240, 76, 176, 232, 65, 83, 58, 10, 250, 218, 172, 86),
          U1(171, 120, 100, 39, 28, 254, 212, 118, 140, 35, 134, 52, 175, 92, 144, 246, 75, 76, 20, 23, 230, 244, 171, 113, 142, 40)
        }))).islandMember >= require((table.concat({
          U1(171, 124, 108, 44, 28, 239, 150, 71, 154, 56, 146, 50, 188, 91, 225, 207, 74, 79, 1, 22, 225, 196, 164, 55, 188, 51, 150, 36, 191, 76, 150, 252, 68, 81, 11, 13, 218, 218, 182, 109),
          U1(164, 117, 119)
        }))).GetMaxPlayer() then
        else
        end
      elseif _ARG_0_._isLandState == 2 then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCMatch):HasUGCMatchInfo() then
          return
        end
      elseif _ARG_0_._isLandState == 3 then
        if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_.uid) then
          return
        end
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.PlayerStatusMgr):GetStatusData(_ARG_0_.uid).socialland_type == 2 then
        end
      elseif _ARG_0_._isLandState == 4 then
        if not require((table.concat({
          U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 27, 148, 32, 187, 112, 179, 238, 81, 30, 54, 6, 241, 210, 185, 101),
          U1(129, 99, 105, 40, 28, 255, 236, 70, 144, 32, 150)
        }))).IsPlayerIdleClient() then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIslandActionData"] = function(_ARG_0_, _ARG_1_)
    do
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetFrom() == U1.ENUM_OPEN_FROM.TPLAN or _ARG_1_.tplan_type == 1 then
        return {
          bIsShow = false,
          ["bIsShow"] = false,
          ["bIsShow"] = true,
          ["bIsShow"] = true,
          ["bIsShow"] = true,
          ["bIsShow"] = true,
          ["bIsShow"] = false
        }
      end
      if require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 89, 161, 248, 84, 69, 33, 11, 227, 194, 166, 112, 129, 59, 219, 10, 191, 77, 186, 223, 68, 81, 28, 71, 214, 218, 172, 104),
        U2(230, 67, 108, 39, 21, 247, 221, 125, 141, 45, 140, 51, 154, 95, 160, 243)
      }))).IsSelfInTraining() or require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 89, 161, 248, 84, 69, 33, 11, 227, 194, 166, 112, 129, 59, 219, 10, 191, 77, 186, 223, 68, 81, 28, 71, 214, 218, 172, 104),
        U2(230, 67, 108, 39, 21, 247, 221, 125, 141, 45, 140, 51, 154, 95, 160, 243)
      }))).IsOtherInTraining(_ARG_1_) then
        return {
          bIsShow = false,
          ["bIsShow"] = false,
          ["bIsShow"] = true,
          ["bIsShow"] = true,
          ["bIsShow"] = true,
          ["bIsShow"] = true,
          ["bIsShow"] = false
        }
      end
      _ARG_0_._isLandState = 1
      if not (not U3.IsBattle(_ARG_1_) or _ARG_1_.socialland_type ~= 0 or _ARG_1_.game_sub_mode == require((U2(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 29, 22, 239, 206, 230, 113, 128, 49, 144, 18, 179, 65, 188, 253, 71, 67))).Home_SubMode.Visit or U3.IsMainCity(_ARG_1_)) or (_ARG_1_.teamState or 0) > 2 then
      elseif require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))):CheckIslandStatus(_ARG_1_.socialland_type, _ARG_1_.game_id, _ARG_1_.land_id) == require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))).ENUM_ISLAND_STATUS.ME_ON_ISLAND then
        _ARG_0_._isLandState = 1
      elseif require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))):CheckIslandStatus(_ARG_1_.socialland_type, _ARG_1_.game_id, _ARG_1_.land_id) == require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))).ENUM_ISLAND_STATUS.TARGET_ON_ISLAND then
        _ARG_0_._isLandState = 2
      elseif require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))):CheckIslandStatus(_ARG_1_.socialland_type, _ARG_1_.game_id, _ARG_1_.land_id) == require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))).ENUM_ISLAND_STATUS.ON_DIFFERENT_ISLAND then
        _ARG_0_._isLandState = 3
      elseif require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))):CheckIslandStatus(_ARG_1_.socialland_type, _ARG_1_.game_id, _ARG_1_.land_id) == require((table.concat({
        U2(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 95, 172, 246, 89, 76, 60, 10, 238, 202, 166, 125, 193, 31, 153, 36, 187, 78, 171, 161, 97, 67, 9, 8, 252, 223, 139, 125),
        U2(169, 100, 112, 58, 62, 244, 223, 64, 156)
      }))).ENUM_ISLAND_STATUS.ON_SAME_ISLAND then
        _ARG_0_._isLandState = 4
      else
      end
      do return {
        bIsShow = false,
        ["bIsShow"] = false,
        ["bIsShow"] = true,
        ["bIsShow"] = true,
        ["bIsShow"] = true,
        ["bIsShow"] = true,
        ["bIsShow"] = false
      } end
      do return end
      _ARG_0_ = U1[60]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTipsBySetAnchors"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckCanCare"] = function(_ARG_0_)
    do
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) then
        return false
      end
      if require((U1(171, 124, 108, 44, 28, 239, 150, 71, 154, 56, 146, 50, 188, 91, 225, 207, 74, 79, 1, 22, 225, 196, 164, 55, 169, 46, 156, 40, 176, 68, 151, 238, 70, 84, 9, 12, 224))).friend_status_data and require((U1(171, 124, 108, 44, 28, 239, 150, 71, 154, 56, 146, 50, 188, 91, 225, 207, 74, 79, 1, 22, 225, 196, 164, 55, 169, 46, 156, 40, 176, 68, 151, 238, 70, 84, 9, 12, 224))).friend_status_data.self_like_list then
        goto lbl_75
        if 44 == (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).frd_status_end_time or 0) then
          return false
        end
        ::lbl_75::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickButton_Reservation"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid) or type((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) ~= U1(188, 113, 103, 37, 23) or not next((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid))) then
        return
      end
      if require((table.concat({
        U1(171, 124, 108, 44, 28, 239, 150, 90, 147, 57, 132, 115, 162, 95, 168, 246, 91, 14, 19, 11, 235, 206, 166, 125, 193, 48, 154, 42, 183, 67, 128, 225, 77, 71, 58, 15, 224, 210, 189, 103),
        U1(172)
      }))).GetReserveState(_ARG_0_.uid) ~= 1 then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.uid).game_sub_mode == 26001 then
        return
      end
      if require((table.concat({
        U1(143, 113, 104, 44, 62, 238, 217, 7, 178, 35, 129, 115, 157, 89, 161, 248, 84, 69, 33, 11, 227, 194, 166, 112, 129, 59, 219, 10, 191, 77, 186, 223, 68, 81, 28, 71, 214, 218, 172, 104),
        U1(230, 67, 108, 39, 21, 247, 221, 125, 141, 45, 140, 51, 154, 95, 160, 243)
      }))).IsSelfInTraining() then
        return
      else
      end
      if not _ARG_0_.UIRoot then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_friend_list_ui):GetFrom() == U2.ENUM_OPEN_FROM.ISMOREPLAYERNUM then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFriendStatusChange"] = function(_ARG_0_)
    do
      _ARG_0_:UpdateUI()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTipsPosition"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.UIRoot then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
