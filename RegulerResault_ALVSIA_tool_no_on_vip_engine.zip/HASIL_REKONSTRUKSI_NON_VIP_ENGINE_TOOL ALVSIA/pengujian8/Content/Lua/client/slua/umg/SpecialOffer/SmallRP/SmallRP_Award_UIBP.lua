do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(176, 227, 99, 129, 252, 216, 228, 197, 126, 102, 227, 138))).TraitClass(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 161, 133, 28, 148, 164, 81, 221, 19, 185, 20, 233, 200, 234, 50, 117, 251, 157, 133))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_._cObj_avatarDetails = nil
      _ARG_0_._cObj_smallRPModule, _ARG_0_._nActivityId, _ARG_0_._tSmallRPContext = Create(_ARG_2_)
      _ARG_0_._nLastAvatarShowLevel = nil
      _ARG_0_._nLastItemId = nil
      _ARG_0_._nLastSelectLevel = nil
      _ARG_0_._nCurBannerShowLevel = nil
      _ARG_0_._nCurBannerShowRoundId = nil
      _ARG_0_._nCurBannerShowItemId = nil
      _ARG_0_._sTitleImagePath = nil
      _ARG_0_._bIsShowAvatar = false
      _ARG_0_._bIsCardUnlock = false
      _ARG_0_._tAllRewardNode = {}
      _ARG_0_._tLevelRewardPos = {}
      _ARG_0_._nScrollWidth = 0
      _ARG_0_._bIsInit = false
      _ARG_0_._bIsDragShow = false
      _ARG_0_._nDragCheckTime = 0
      _ARG_0_._guidePromise = nil
      _ARG_0_._fnPreviewSceneNameGetter = nil
      _ARG_0_._cObj_goodLuckEntry = nil
      _ARG_0_._uGoodLuckEntryCanvas = nil
      _ARG_0_._bHasLuckyCard = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Help, _ARG_0_.OnHelpBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Video, _ARG_0_.OnVideoBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_BuyScore, _ARG_0_.OnBuyScoreBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Task, _ARG_0_.OnTaskBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_UnLock, _ARG_0_.OnUnlockBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_GetAll, _ARG_0_.OnGetAllBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Preview, _ARG_0_.OnPreviewButtonClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Gift, _ARG_0_.OnGiftBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_LuckTip, _ARG_0_.OnLuckTipBtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Go1Button, _ARG_0_.OnGo1BtnClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Go2Button, _ARG_0_.OnGo2BtnClick, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.ScrollBox_LevelReward, U1(156, 226, 76, 137, 244, 223, 164, 226, 111, 117, 229, 146, 156), _ARG_0_.OnBeginScroll, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.ScrollBox_LevelReward, U1(156, 226, 91, 159, 246, 196, 153, 210, 126, 104, 230, 146, 149, 17), _ARG_0_.OnScrollingEvent, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.ScrollBox_LevelReward, U1(156, 226, 75, 130, 247, 229, 169, 195, 99, 107, 230), _ARG_0_.OnDragLoopEnd, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Fadein, U1(156, 226, 79, 130, 250, 219, 171, 197, 101, 104, 228, 184, 153, 27, 162, 177, 75, 217, 26), _ARG_0_.OnFadeInAnimFinished, _ARG_0_)
      _ARG_0_:AddControlEventByControl(_ARG_0_.UIRoot.Tips_Fadein, U1(156, 226, 79, 130, 250, 219, 171, 197, 101, 104, 228, 184, 153, 27, 162, 177, 75, 217, 26), _ARG_0_.OnTipsFadeInAnimFinished, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_INIT_REWARD_LIST, _ARG_0_.OnGotLevelRewardCfgRefresh, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_REFRESH_REWARD_LIST, _ARG_0_.OnRefreshRewardListEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_UNLOCK, _ARG_0_.OnUnlockEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_LEVEL_CHANGE, _ARG_0_.OnLevelChangeEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_RED_DOT_REFRESH, _ARG_0_.OnRedDotRefreshEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_LOBBY_SCENE, U2.EVENTID_SCENE_LOADED, _ARG_0_.OnSceneLoaded, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_GOT_ACT_DATA, _ARG_0_.OnGotActDataEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_REWARD_UPDATE, _ARG_0_.OnActivityRewardUpdateEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_GOT_ACT_DATA, _ARG_0_.OnActivityGotActDataEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_INIT_REWARD_LIST, _ARG_0_.OnActivityInitRewardListEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_UNLOCK, _ARG_0_.OnActivityUnlockEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_SCORE_CHANGE, _ARG_0_.OnActivityScoreChangeEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_LEVEL_CHANGE, _ARG_0_.OnActivityLevelChangeEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_SMALL_RP, U2.EVENTID_SMALL_RP_ACTIVITY_RED_DOT_REFRESH, _ARG_0_.OnActivityRedDotRefreshEvent, _ARG_0_)
      _ARG_0_:AddCommonEvent(U2.EVENTTYPE_ACTIVITY_BLACK_FRIDAY, U2.EVENTID_ACTIVITY_BLACK_FRIDAY_LUCKY_CARD_DATA_UPDATE, _ARG_0_.OnLuckyCardDataUpdate, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      _ARG_0_:ApplyPreviewSceneNameGetter()
      _ARG_0_._cObj_smallRPModule:RequestTaskData()
      _ARG_0_:InitShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      _ARG_0_:ShowKoreaRevealItemTips()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      if _ENV == _ARG_0_ then
        U1(U2)
        U2 = nil
        _ENV = nil
      end
      _ARG_0_:RestorePreviewSceneNameGetter()
      if _ARG_0_._guidePromise then
        _ARG_0_._guidePromise:Reject()
        _ARG_0_._guidePromise = nil
      end
      U3.EventSystem:postEvent(U3.EVENTTYPE_SPECIAL_OFFER, U3.EVENTID_SPECIAL_OFFER_SET_MASK, true)
      if U3.UIManager.IsUIShow(U3.UIManager.UI_Config.NewbieGuide_UIBP) then
        U3.UIManager.CloseUI(U3.UIManager.UI_Config.NewbieGuide_UIBP)
      end
      U4.__super.OnClose(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHelpBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).RuleTextKey and (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).RuleTextKey ~= 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVideoBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      _ARG_0_:CheckIsPlayVideo(true)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBuyScoreBtnClick"] = function(_ARG_0_)
    do
      if not _ARG_0_._cObj_smallRPModule:GetIsUnlock() then
        return
      end
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTaskBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLuckTipBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEntranceConnectedRPScore"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_._cObj_smallRPModule:IsEntranceConnectedRPScore(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGo1BtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGo2BtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGiftBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not _ARG_0_._cObj_smallRPModule:GetIsUnlock() then
      else
      end
      if not _ARG_0_._cObj_smallRPModule:GetSmallRPCardId() or _ARG_0_._cObj_smallRPModule:GetSmallRPCardId() == 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUnlockBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGetAllBtnClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not _ARG_0_._nActivityId then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreviewButtonClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click)
      if not _ARG_0_._bIsInit or not _ARG_0_._nCurBannerShowLevel then
        return
      end
      _ARG_0_._bIsDragShow = false
      if _ARG_0_._nCurBannerShowLevel == _ARG_0_._nLastSelectLevel then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBeginScroll"] = function(_ARG_0_)
    do
      _ARG_0_._bIsDragShow = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnScrollingEvent"] = function(_ARG_0_)
    do
      if require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 191, 171, 78, 217, 33, 169, 23, 239, 214))).GetMiliseconds() - _ARG_0_._nDragCheckTime > 0.5 then
        goto lbl_47
        if 210 > _ARG_0_.UIRoot.ScrollBox_LevelReward:GetScrollOffset() then
        else
          ::lbl_47::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if 228 then
        end
      end
      _ARG_0_._nDragCheckTime = require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 191, 171, 78, 217, 33, 169, 23, 239, 214))).GetMiliseconds(), _ARG_0_.UIRoot, _ARG_0_.UIRoot.ScrollBox_LevelReward:GetScrollOffset(), 228, _ARG_0_:AddLevelRewardNodeByShowLevel(false, 228 + U2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDragLoopEnd"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshBannerShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTipsFadeInAnimFinished"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnFadeInAnimFinished"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_smallRPModule:IsEntranceConnectedRPScore(1) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TriggerGuide"] = function(_ARG_0_, _ARG_1_)
    do
      if #_ARG_1_ <= 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshRewardListEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        goto lbl_16
        if _ARG_0_._tAllRewardNode[nil] then
        end
        ::lbl_16::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
        goto lbl_28
        ::lbl_28::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityRewardUpdateEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) or _ARG_4_ ~= U1(191, 233, 120, 137, 255) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGotLevelRewardCfgRefresh"] = function(_ARG_0_)
    do
      _ARG_0_:InitLevelRewardLoop()
      _ARG_0_:RefreshGetAllBtnShow()
      _ARG_0_:RefreshBannerShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUnlockEvent"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshActUnlock()
      _ARG_0_:RefreshUnlockLevelRewardTip()
      if not _ARG_0_._bIsShowAvatar then
        _ARG_0_:InitAvatarDisplay()
        _ARG_0_:OnScrollingEvent()
      end
      _ARG_0_:RefreshLevelChange()
      _ARG_0_:RefreshGiftBtnShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLevelChangeEvent"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshLevelChange()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRedDotRefreshEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_3_ = tonumber(_ARG_3_)
      if _ARG_0_._nActivityId then
        if _ARG_3_ and _ARG_0_._nActivityId ~= _ARG_3_ then
          return
        end
      elseif _ARG_3_ then
        return
      end
      _ARG_0_:RefreshRedDot()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityGotActDataEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) then
        return
      end
      _ARG_0_:RefreshUnlockCostShow()
      _ARG_0_:RefreshActUnlock()
      _ARG_0_:RefreshLevelChange()
      _ARG_0_:RefreshGiftBtnShow()
      _ARG_0_:RefreshGoodLuckEntry()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityInitRewardListEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) then
        return
      end
      _ARG_0_:OnGotLevelRewardCfgRefresh()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityUnlockEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) then
        return
      end
      _ARG_0_:OnUnlockEvent()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnLuckyCardDataUpdate"] = function(_ARG_0_)
    do
      if not _ARG_0_._cObj_goodLuckEntry then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):IsReady() then
        return
      end
      _ARG_0_._bHasLuckyCard = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):HasLuckyCard(), _ARG_0_._bHasLuckyCard
      if _ARG_0_._bHasLuckyCard == nil or _ARG_0_._bHasLuckyCard == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):HasLuckyCard() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityScoreChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) then
        return
      end
      _ARG_0_:RefreshLevelChange()
      _ARG_0_:RefreshGiftBtnShow()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityLevelChangeEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) then
        return
      end
      _ARG_0_:RefreshLevelChange()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnActivityRedDotRefreshEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._nActivityId ~= tonumber(_ARG_3_) then
        return
      end
      _ARG_0_:RefreshRedDot()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPreviewSceneName"] = function(_ARG_0_)
    do
      if _ARG_0_._nActivityId then
        return (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).SceneName
      end
      do return (require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
        U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 165, 1, 162, 174, 80)
      }))).GetSceneName()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyPreviewSceneNameGetter"] = function(_ARG_0_)
    do
      if not _ARG_0_._nActivityId or _ARG_0_._fnPreviewSceneNameGetter then
        return
      end
      
      function _ARG_0_._fnPreviewSceneNameGetter()
        do return _ENV:GetPreviewSceneName() end
        return
      end
      
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RestorePreviewSceneNameGetter"] = function(_ARG_0_)
    do
      if not _ARG_0_._fnPreviewSceneNameGetter then
        return
      end
      _ARG_0_._fnPreviewSceneNameGetter = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSceneLoaded"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ == _ARG_0_:GetPreviewSceneName() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnGotActDataEvent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:RefreshUnlockCostShow()
      _ARG_0_:RefreshActUnlock()
      _ARG_0_:RefreshLevelChange()
      _ARG_0_:RefreshGiftBtnShow()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTitleTextureByReward"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_._cObj_smallRPModule:GetActShowCfg() then
        return
      end
      if _ARG_1_ == 14 and _ARG_2_ == 1967005 then
      end
      if _ARG_0_._sTitleImagePath == U1.string.format(_ENV(246, 255, 64, 131, 210, 194, 166, 208, 127, 40, 175, 141, 222, 80, 184), _ARG_0_._cObj_smallRPModule:GetActShowCfg().TemplateBasePath, _ENV(154, 225, 111, 139, 246, 233, 158, 216, 120, 107, 239, 161, 167, 29, 162, 182, 70), (_ENV(154, 225, 111, 139, 246, 233, 158, 216, 120, 107, 239, 161, 167, 29, 162, 182, 70))) then
        return
      end
      _ARG_0_._sTitleImagePath = U1.string.format(_ENV(246, 255, 64, 131, 210, 194, 166, 208, 127, 40, 175, 141, 222, 80, 184), _ARG_0_._cObj_smallRPModule:GetActShowCfg().TemplateBasePath, _ENV(154, 225, 111, 139, 246, 233, 158, 216, 120, 107, 239, 161, 167, 29, 162, 182, 70), (_ENV(154, 225, 111, 139, 246, 233, 158, 216, 120, 107, 239, 161, 167, 29, 162, 182, 70)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitShow"] = function(_ARG_0_)
    do
      if _ARG_0_._nActivityId then
      else
      end
      if _ARG_0_._cObj_smallRPModule:GetActTime() and _ARG_0_._cObj_smallRPModule:GetActTime() then
      else
      end
      if _ARG_0_._cObj_smallRPModule:GetActTime() and require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 190, 171, 124, 201, 10, 181, 15))).IsCountDown(_ARG_0_._cObj_smallRPModule:GetActTime()) then
      else
      end
      if _ARG_0_._cObj_smallRPModule:GetActRoundId() then
      else
      end
      _ARG_0_._bIsInit = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitGoodLuckEntry"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard then
        return
      end
      if not _ARG_0_._nActivityId then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):IsShowCommonEntry(_ARG_0_._nActivityId) then
        return
      end
      _ARG_0_._uGoodLuckEntryCanvas, _ARG_0_._cObj_goodLuckEntry = _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard, _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_GoodLuckCard, UIManager.UI_Config.Common_GoodLuck_Enter_UIBP, _ARG_0_._nActivityId, nil, function(_ARG_0_)
        do
          do return _ENV:GetLuckyCardRelationContext(_ARG_0_) end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):IsReady() then
        _ARG_0_._bHasLuckyCard = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):HasLuckyCard()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGoodLuckEntryAnchor"] = function(_ARG_0_)
    do
      if not _ARG_0_._cObj_goodLuckEntry then
        return
      end
      if _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard02 and _ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp and CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID) and _ARG_0_._cObj_avatarDetails:CheckViewComponentShow(_ARG_0_._cObj_avatarDetails.curItemID) and (not (CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemType == ENUM_ITEM_TYPE.Weapon) and (_ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp):GetWidgetSwitcherTypeStyle(CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemType, CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemSubType) == require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 154, 26, 243, 221, 210),
        U1(188, 225, 126, 131, 253, 211, 164, 197, 34, 68, 229, 144, 131, 1, 157, 171, 70, 203)
      }))).E_TypeBtnStyle.sex or (_ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp).switchConfig.enlarge and (CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemType == ENUM_ITEM_TYPE.Extra or CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemType == ENUM_ITEM_TYPE.Backpack) and require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 154, 26, 243, 221, 210),
        U1(188, 225, 126, 131, 253, 211, 164, 197, 34, 68, 229, 144, 131, 1, 157, 171, 70, 203)
      })))._NeedEnlargeTypeTable[CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemSubType] or CDataTable.GetTableData(U1(154, 248, 107, 129), _ARG_0_._cObj_avatarDetails.curItemID).ItemType == ENUM_ITEM_TYPE.Weapon and ((_ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp).switchConfig.weapon or (_ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp).switchConfig.preview and not (_ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp).switchConfig.fullScreen or (_ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp).switchConfig.kdpPreview)) then
      end
      if not _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard02 then
        return
      end
      if _ARG_0_._uGoodLuckEntryCanvas ~= _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard02 then
        _ARG_0_._uGoodLuckEntryCanvas = _ARG_0_.UIRoot.CanvasPanel_GoodLuckCard02, _ARG_0_._cObj_avatarDetails, _ARG_0_._cObj_avatarDetails and _ARG_0_._cObj_avatarDetails.ViewComp, _ARG_0_._cObj_goodLuckEntry:SetAutoSize(true)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGoodLuckEntry"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLuckyCardRelationContext"] = function(_ARG_0_, _ARG_1_)
    do
      if tonumber(_ARG_1_.SourceType) == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule).BenefitSourceType.DailyReward then
        return nil, nil, {bFallback = true}
      end
      if tonumber(_ARG_1_.SourceType) ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule).BenefitSourceType.Benefit then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):GetBenefit(_ARG_1_.SourceID) or tonumber(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):GetBenefit(_ARG_1_.SourceID).privilege_benefit_type) ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule).BenefitKind.SmallRpDiscount then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule):HasLuckyCard() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId) == require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
        U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
      }))).Enum_LuckyDiscountRefundStatus.CanClaim or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId) == require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
        U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
      }))).Enum_LuckyDiscountRefundStatus.Claimed then
        return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule).BenefitUsageKey.SmallRpRefund, {
          canUse = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId) == require((table.concat({
            U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
            U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
          }))).Enum_LuckyDiscountRefundStatus.CanClaim,
          quotaAvailable = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId) == require((table.concat({
            U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
            U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
          }))).Enum_LuckyDiscountRefundStatus.CanClaim,
          value = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId)
        }, {
          specialText = LocUtil.LocalizeResFormat(U2, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId)),
          bClaimable = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetLuckyDiscountRefundInfo(_ARG_0_._nActivityId) == require((table.concat({
            U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
            U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
          }))).Enum_LuckyDiscountRefundStatus.CanClaim,
          fnClaim = function()
            _ENV:ClaimLuckyDiscountRefund(U1, U2)
            return
          end
        }
      end
      do return ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayLuckyCardModule).BenefitUsageKey.SmallRpDiscount, {
        canUse = not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_SmallRPActivity):GetIsUnlock(_ARG_0_._nActivityId)
      } end
      do return end
      _ARG_0_ = U1[129]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUnlockCostShow"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_smallRPModule:GetSmallRPCardId() and require((U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 9, 189, 17, 226, 200, 238, 126, 114, 180, 153, 129, 23, 191, 160, 92, 206, 11, 147, 23, 247, 222, 240))):GetHallDepotItemDataByResID((_ARG_0_._cObj_smallRPModule:GetSmallRPCardId())) then
        _ARG_0_._bIsCardUnlock = true
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTextureShow"] = function(_ARG_0_)
    do
      if not _ARG_0_._cObj_smallRPModule:GetActShowCfg() then
        return
      end
      if require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 190, 171, 124, 201, 10, 181, 15))).IsExistBlueprintPath(_ARG_0_._cObj_smallRPModule:GetActShowCfg().TemplateBasePath .. U1(157, 227, 79, 152, 255, 215, 185, 158, 69, 106, 235, 153, 149, 42, 155, 176, 76, 209, 17, 242, 42, 235, 219, 230, 121, 72, 202, 156, 143, 8, 180)) then
      elseif require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 190, 171, 124, 201, 10, 181, 15))).IsExistBlueprintPath(_ARG_0_._cObj_smallRPModule:GetActShowCfg().TemplateBasePath .. U1(157, 227, 79, 152, 255, 215, 185, 158, 69, 106, 235, 153, 149, 42, 137, 165, 111, 146, 55, 177, 2, 225, 223, 222, 94, 112, 214)) and require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 190, 171, 124, 201, 10, 181, 15))).IsExistBlueprintPath(_ARG_0_._cObj_smallRPModule:GetActShowCfg().TemplateBasePath .. U1(157, 227, 79, 152, 255, 215, 185, 158, 69, 106, 235, 153, 149, 42, 137, 165, 113, 146, 55, 177, 2, 225, 223, 222, 94, 112, 200)) then
      else
      end
      if _ARG_0_._cObj_smallRPModule:GetActShowCfg().ActTimeTextColor == U1() then
      end
      if _ARG_0_._cObj_smallRPModule:GetActShowCfg().ActIconColor == U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitRelatedModuleShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_._cObj_smallRPModule:GetActShowCfg() then
        return
      end
      if _ARG_0_._cObj_smallRPModule:GetConcernEntranceType(1) == require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
        U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
      }))).Enum_EntranceType.Invalid then
      else
      end
      if _ARG_0_._cObj_smallRPModule:GetConcernEntranceType(2) == require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 13, 172, 6, 229, 211, 224, 112, 120, 252, 136, 133, 23, 245, 129, 94, 205, 2, 160, 33, 198, 132, 221),
        U1(188, 235, 103, 143, 204, 229, 167, 208, 96, 107, 216, 174, 179, 26, 165, 177, 87)
      }))).Enum_EntranceType.Invalid then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitMaskImageShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ and _ARG_2_ ~= _ENV() then
        return
      end
      _ARG_0_:SetWidgetVisible(_ARG_1_, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitAvatarDetails"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_avatarDetails then
        return
      end
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().videoBtn = false
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().enlarge = true
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().boxDropList = true
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().car = true
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().goResearch = true
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().inventory = true
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().characterTrans = false
      require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
        U1(151, 233, 122, 141, 250, 218)
      }))).GetDefaultConfig().fTransPreview = function(_ARG_0_)
        do
          if not _cObj_smallRPModule:GetActRoundId() then
            return
          end
          if not U2.CDataTable.GetTableDataByFilter(_nActivityId and U1(128, 225, 111, 128, 255, 228, 154, 240, 111, 115, 227, 136, 153, 1, 178, 145, 83, 217, 29, 181, 2, 234, 243, 245, 121, 122, 208, 155, 141, 21, 152, 180, 84) or U1(128, 252, 107, 143, 250, 215, 166, 248, 120, 98, 231, 180, 133, 24, 187, 129, 69, 219), U1(154, 248, 107, 129, 218, 210), _ARG_0_, U1(146, 239, 122, 190, 252, 195, 164, 213), (_cObj_smallRPModule:GetActRoundId())) then
            return
          end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      _ARG_0_._cObj_avatarDetails = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_Details, UIManager.UI_Config.DetailComponentMain, {
        switches = require((table.concat({
          U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
          U1(151, 233, 122, 141, 250, 218)
        }))).GetDefaultConfig(),
        curScene = require((table.concat({
          U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 141, 5, 247, 222, 240),
          U1(161, 200, 103, 159, 227, 218, 171, 200, 34, 68, 229, 144, 131, 1, 138, 180, 66, 200, 31, 174, 39, 239, 201, 237, 125, 110)
        }))).ESceneType.SmallRP300,
        namePadding = FMargin(0, 0, 0, 195),
        topPadding = FMargin(0, 110, 0, 0),
        offsetInfo = {
          kill = FVector2D(350, 0)
        }
      }), _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.CanvasPanel_Details, UIManager.UI_Config.DetailComponentMain, {
        switches = require((table.concat({
          U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 143, 28, 248, 217, 229),
          U1(151, 233, 122, 141, 250, 218)
        }))).GetDefaultConfig(),
        curScene = require((table.concat({
          U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 152, 6, 242, 219, 232, 112, 84, 245, 131, 144, 10, 181, 183, 93, 216, 64, 141, 5, 247, 222, 240),
          U1(161, 200, 103, 159, 227, 218, 171, 200, 34, 68, 229, 144, 131, 1, 138, 180, 66, 200, 31, 174, 39, 239, 201, 237, 125, 110)
        }))).ESceneType.SmallRP300,
        namePadding = FMargin(0, 0, 0, 195),
        topPadding = FMargin(0, 110, 0, 0),
        offsetInfo = {
          kill = FVector2D(350, 0)
        }
      }):SetPadding(-10, 0, 0, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshRedDot"] = function(_ARG_0_)
    do
      if _ARG_0_._nActivityId then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGiftBtnShow"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddLevelRewardNodeByShowLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_ and not _ARG_0_._bIsInit then
        return
      end
      _ARG_3_ = _ARG_3_ or _ARG_0_._cObj_smallRPModule:GetCurRoundLevelRewardCfg()
      if not _ARG_3_ then
        return
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return math.max(1, _ARG_2_ - U1), (math.min(#_ARG_3_, _ARG_2_ + U1)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitLevelRewardLoop"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_smallRPModule:GetCurRoundLevelRewardCfg() then
        if next(_ARG_0_._tAllRewardNode) then
          return
        end
        _ARG_0_._tLevelRewardPos[1] = 0
        goto lbl_32
        _ARG_0_._tLevelRewardPos[nil + 1] = (_ARG_0_._tLevelRewardPos[nil] or 0) + _ARG_0_:GetCurSizeX(nil) + U1
        ::lbl_32::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if not _ARG_0_:AddLevelRewardNodeByShowLevel(true, _ARG_0_:GetCurScrollToLevel(), (_ARG_0_._cObj_smallRPModule:GetCurRoundLevelRewardCfg())) or not _ARG_0_:AddLevelRewardNodeByShowLevel(true, _ARG_0_:GetCurScrollToLevel(), (_ARG_0_._cObj_smallRPModule:GetCurRoundLevelRewardCfg())) then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DelayAddRewardLevelNode"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurScrollToLevel"] = function(_ARG_0_)
    do
      if not _ARG_0_._cObj_smallRPModule:GetIsUnlock() then
        return 1
      end
      do return (math.max(1, _ARG_0_._cObj_smallRPModule:GetCurLevel() - 2)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitAvatarDisplay"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_smallRPModule:GetIsUnlock() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshVideoBtnShow"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 8, 181, 7, 227, 213, 175, 112, 120, 248, 140, 153, 58, 173, 187, 87, 201, 1, 147, 21, 227, 196, 242),
        U1(167, 229, 97, 130, 204, 218, 163, 211, 126, 102, 248, 135)
      }))).IsCanPlayVideo() then
        return
      end
      if not (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).VideoPath or (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).VideoPath == U1() then
        return
      end
      if DataMgr.GetVideoDownloadPath((_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).VideoPath) ~= U1() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshActUnlock"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLevelChange"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshLevelShow()
      _ARG_0_:RefreshGetAllBtnShow()
      goto lbl_14
      ::lbl_14::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_:RefreshBannerShow()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLevelShow"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_smallRPModule:GetCurLevel() == _ARG_0_._cObj_smallRPModule:GetMaxLevel() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshGetAllBtnShow"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_smallRPModule:GetIsUnlock() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshUnlockLevelRewardTip"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBannerShow"] = function(_ARG_0_)
    do
      if not next(_ARG_0_._tLevelRewardPos) then
        return
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot.ScrollBox_LevelReward:GetScrollOffset() + _ARG_0_._nScrollWidth >= _ARG_0_._tLevelRewardPos[nil] then
        goto lbl_26
        goto lbl_27
        ::lbl_26::
        _ARG_0_ = _ARG_0_
      end
      ::lbl_27::
      if not _ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit) then
        _ARG_0_._nCurBannerShowLevel = nil
        _ARG_0_._nCurBannerShowRoundId = nil
        _ARG_0_._nCurBannerShowItemId = nil
        return
      end
      if not _ARG_0_._cObj_smallRPModule:GetActRoundId() or not _ARG_0_._cObj_smallRPModule:GetShowItemIdByLevel((_ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit))) then
        _ARG_0_._nCurBannerShowLevel = nil
        _ARG_0_._nCurBannerShowRoundId = nil
        _ARG_0_._nCurBannerShowItemId = nil
        return
      end
      if _ARG_0_._nCurBannerShowLevel == _ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit) and _ARG_0_._nCurBannerShowRoundId == _ARG_0_._cObj_smallRPModule:GetActRoundId() and _ARG_0_._nCurBannerShowItemId == _ARG_0_._cObj_smallRPModule:GetShowItemIdByLevel((_ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit))) then
        return
      end
      if not CDataTable.GetTableDataByFilter(_ARG_0_._nActivityId and U1(128, 225, 111, 128, 255, 228, 154, 240, 111, 115, 227, 136, 153, 1, 178, 128, 66, 210, 16, 185, 17) or U1(146, 255, 125, 137, 254, 212, 166, 212, 77, 100, 254, 188, 145, 27, 165, 167, 81), U1(154, 248, 107, 129, 218, 210), _ARG_0_._cObj_smallRPModule:GetShowItemIdByLevel((_ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit))), U1(146, 239, 122, 190, 252, 195, 164, 213), (_ARG_0_._cObj_smallRPModule:GetActRoundId())) then
        _ARG_0_._nCurBannerShowLevel = nil
        _ARG_0_._nCurBannerShowRoundId = nil
        _ARG_0_._nCurBannerShowItemId = nil
        return
      end
      _ARG_0_._nCurBannerShowItemId, _ARG_0_._nCurBannerShowRoundId, _ARG_0_._nCurBannerShowLevel = _ARG_0_._cObj_smallRPModule:GetShowItemIdByLevel((_ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit))), _ARG_0_._cObj_smallRPModule:GetActRoundId(), _ARG_0_._cObj_smallRPModule:GetCurShowBannerLevel(nil, _ARG_0_._bIsInit)
      if _ARG_0_._bIsInit and _ARG_0_._bIsDragShow then
        _ARG_0_._bIsDragShow = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSelectLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_._nLastSelectLevel and _ARG_0_._nLastSelectLevel ~= _ARG_2_ and _ARG_0_:GetRewardLevelNode(_ARG_0_._nLastSelectLevel) then
      end
      if _ARG_0_:GetRewardLevelNode(_ARG_2_) then
      end
      _ARG_0_._nLastSelectLevel = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ScrollToIndex"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRewardDisplay"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      if _ARG_0_._nLastAvatarShowLevel == _ARG_2_ and _ARG_0_._nLastItemId == _ARG_1_.resid then
        return
      end
      _ARG_0_._nLastItemId = _ARG_1_.resid
      _ARG_0_._nLastAvatarShowLevel = _ARG_2_
      _ARG_0_._bIsShowAvatar = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAvatarShow"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_._cObj_avatarDetails then
        _ARG_0_:InitAvatarDetails()
      end
      itemValidTime = _ARG_2_
      _ARG_0_._cObj_avatarDetails:SetData(_ARG_1_, _ENV)
      _ARG_0_._cObj_avatarDetails:CallAfterSetData(function()
        _ENV:RefreshGoodLuckEntryAnchor()
        return
      end)
      _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_BG, false)
      U1.EventSystem:postEvent(U1.EVENTTYPE_SPECIAL_OFFER, U1.EVENTID_SPECIAL_OFFER_SET_MASK, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRewardLevelNode"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_._tAllRewardNode[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddLevelRewardNode"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ or _ARG_0_._tAllRewardNode[_ARG_1_] then
        return
      end
      _ARG_0_._tAllRewardNode[_ARG_1_] = _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.Canvas_LevelReward, UIManager.UI_Config.SmallRP_Award_Item_UIBP, _ARG_1_, _ARG_2_[_ARG_1_], _ARG_0_:GetCurSizeX(_ARG_2_[_ARG_1_]), _ARG_0_._tSmallRPContext), _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.Canvas_LevelReward, UIManager.UI_Config.SmallRP_Award_Item_UIBP, _ARG_1_, _ARG_2_[_ARG_1_], _ARG_0_:GetCurSizeX(_ARG_2_[_ARG_1_]), _ARG_0_._tSmallRPContext):SetPosition(_ARG_3_ or 0, 0)
      do return (_ARG_0_:CreateChildWindow(_ARG_0_.UIRoot.Canvas_LevelReward, UIManager.UI_Config.SmallRP_Award_Item_UIBP, _ARG_1_, _ARG_2_[_ARG_1_], _ARG_0_:GetCurSizeX(_ARG_2_[_ARG_1_]), _ARG_0_._tSmallRPContext)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowActivityMultiChooseOne"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if type(_ARG_1_) ~= U1(167, 237, 108, 128, 246) or _ARG_1_.activity_id ~= _ARG_0_._nActivityId then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckIsPlayVideo"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 156, 26, 172, 171, 64, 146, 8, 181, 7, 227, 213, 175, 112, 120, 248, 140, 153, 58, 173, 187, 87, 201, 1, 147, 21, 227, 196, 242),
        U1(167, 229, 97, 130, 204, 218, 163, 211, 126, 102, 248, 135)
      }))).IsCanPlayVideo() then
        return
      end
      if (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).VideoPath and (_ARG_0_._cObj_smallRPModule:GetActShowCfg() or {}).VideoPath ~= U1() and (_ARG_1_ or not require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 191, 171, 78, 217, 33, 169, 23, 239, 214))).IsSameDay(require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 191, 171, 78, 217, 33, 169, 23, 239, 214))).GetServerTimeInSec(), (require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 221, 99, 96, 227, 157, 222, 57, 164, 165, 74, 223, 46, 176, 2, 255, 223, 243, 76, 101, 255, 136, 147, 75, 171, 190, 82, 213, 11, 190, 3, 228, 207, 247),
        U1(160)
      }))).LoadFileToTable_N(require((table.concat({
        U1(176, 224, 103, 137, 253, 194, 228, 221, 99, 96, 227, 157, 222, 57, 164, 165, 74, 223, 46, 176, 2, 255, 223, 243, 76, 101, 255, 136, 147, 75, 171, 190, 82, 213, 11, 190, 3, 228, 207, 247),
        U1(160)
      }))).ePlayerPrefsType.eSmallRP) or {}).nVideoTime)) then
        ;(require((table.concat({
          U1(176, 224, 103, 137, 253, 194, 228, 221, 99, 96, 227, 157, 222, 57, 164, 165, 74, 223, 46, 176, 2, 255, 223, 243, 76, 101, 255, 136, 147, 75, 171, 190, 82, 213, 11, 190, 3, 228, 207, 247),
          U1(160)
        }))).LoadFileToTable_N(require((table.concat({
          U1(176, 224, 103, 137, 253, 194, 228, 221, 99, 96, 227, 157, 222, 57, 164, 165, 74, 223, 46, 176, 2, 255, 223, 243, 76, 101, 255, 136, 147, 75, 171, 190, 82, 213, 11, 190, 3, 228, 207, 247),
          U1(160)
        }))).ePlayerPrefsType.eSmallRP) or {}).nVideoTime = require((U1(176, 224, 103, 137, 253, 194, 228, 210, 99, 106, 231, 145, 158, 91, 191, 171, 78, 217, 33, 169, 23, 239, 214))).GetServerTimeInSec()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurSizeX"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return 0
      end
      if _ARG_1_[1] and _ARG_1_[1].select_one then
        return _ENV[#_ARG_1_] or U1
      end
      do return U2[#_ARG_1_] or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end
}, {
  require((table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(176, 224, 103, 137, 253, 194, 228, 194, 96, 114, 235, 208, 132, 7, 170, 171, 87, 207, 80, 144, 12, 229, 219, 237, 117, 109, 251, 154, 137, 10, 181, 252, 103, 231, 1, 190, 22, 247, 248, 244),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(165, 233, 111, 128, 218, 194, 175, 220, 88, 110, 250, 141)
  })))
})) end
return
