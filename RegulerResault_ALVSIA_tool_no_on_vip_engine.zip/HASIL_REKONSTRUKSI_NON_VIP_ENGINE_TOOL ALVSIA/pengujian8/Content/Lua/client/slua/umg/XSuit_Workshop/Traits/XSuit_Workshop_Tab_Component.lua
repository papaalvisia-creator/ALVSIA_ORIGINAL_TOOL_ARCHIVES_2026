local XSuit_Workshop_Tab_Component = {}
local LogicXSuit = require("client.slua.logic.XSuit.logic_xsuit")
local defaultState = 2

function XSuit_Workshop_Tab_Component:InitLevelTabComponent()
  self.ExtendedLoopScrollBox_Period = self:InitExtendedScrollBox(self.UIRoot.ExtendedLoopScrollBox_Period, {
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Workshop_Period_Tab",
    "client.slua.umg.XSuit_Workshop.Item.XSuit_WorkShop_Branch_Sub_Tab"
  })
  self.ExtendedLoopScrollBox_Level = self:InitExtendedScrollBox(self.UIRoot.ExtendedLoopScrollBox_Level, {
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Workshop_Level_Tab",
    "client.slua.umg.XSuit_Workshop.Item.XSuit_Workshop_Feature_Sub_Tab"
  })
  self.periodList = LogicXSuit.GetWorkshopTabData()
  self.selectPeriod = 0
  self.selectLevel = 0
  self.selectFeatureIndex = 0
  self.bBranch = false
  self.selectBranchId = 0
  self.lastSelectBranchId = {}
end

function XSuit_Workshop_Tab_Component:SetPeriodTabData()
  if self.ExtendedLoopScrollBox_Period then
    self.periodList = LogicXSuit.GetWorkshopTabData() or {}
    self.selectPeriod = self.jumpInfo.selectPeriod or self.selectPeriod
    local maxPeriod = self.MaxPeriod or 0
    if not self.selectPeriod or self.selectPeriod <= 0 or maxPeriod < self.selectPeriod then
      log_error(string.format("XSuit_Workshop_Tab_Component:SetPeriodTabData invalid selectPeriod:%s, maxPeriod:%s, jumpPeriod:%s", tostring(self.selectPeriod), tostring(maxPeriod), tostring(self.jumpInfo.selectPeriod)))
      self.selectPeriod = maxPeriod
    end
    self.ExtendedLoopScrollBox_Period:SetData(self.periodList)
    self.ExtendedLoopScrollBox_Period:ScrollToItem(self.MaxPeriod - self.selectPeriod + 1)
    self.jumpInfo.selectPeriod = nil
    self:SelectOnePeriodTab(self.selectPeriod)
  end
end

function XSuit_Workshop_Tab_Component:RefreshOnePeriodTab(period)
  if self.ExtendedLoopScrollBox_Period and period and 0 < period then
    local index = self.MaxPeriod - period + 1
    local data = self.periodList and self.periodList[index]
    if data then
      self.ExtendedLoopScrollBox_Period:RefreshItem(index, data)
    end
  end
end

function XSuit_Workshop_Tab_Component:SelectOnePeriodTab(period)
  if self.ExtendedLoopScrollBox_Period then
    local maxPeriod = self.MaxPeriod or 0
    local listIndex = maxPeriod - (period or 0) + 1
    if not (period and not (period <= 0) and not (period > maxPeriod) and self.periodList) or not self.periodList[listIndex] then
      log_error(string.format("XSuit_Workshop_Tab_Component:SelectOnePeriodTab invalid period:%s, maxPeriod:%s, listSize:%s", tostring(period), tostring(maxPeriod), tostring(self.periodList and #self.periodList)))
      return
    end
    local oldPeriod = self.selectPeriod
    self.selectPeriod = period
    self.selectBranchId = self.jumpInfo.selectBranchId or 0
    self.lastSelectBranchId[self.selectPeriod] = self.jumpInfo.selectBranchId or self.selectBranchId or 0
    self.jumpInfo.selectBranchId = nil
    self:RefreshOnePeriodTab(oldPeriod)
    self:RefreshOnePeriodTab(self.selectPeriod)
    local ui_item_upgrade_effect = UIManager.GetUI(UIManager.UI_Config.item_upgrade_effect)
    if ui_item_upgrade_effect then
      ui_item_upgrade_effect:ClearAll()
    end
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Select, 0, 1, 0, 1)
    local serState = LogicXSuit.GetCurStateByPeriod(self.selectPeriod)
    if serState then
      self.CurState = serState
    elseif LogicXSuit.CheckUnlockState(self.selectPeriod, 1) then
      self.CurState = 1
    elseif LogicXSuit.CheckUnlockState(self.selectPeriod, 2) then
      self.CurState = 2
    else
      self.CurState = defaultState
    end
    self.selectLevel = self.jumpInfo.selectLevel or 0
    self.jumpInfo.selectLevel = nil
    self.selectFeatureIndex = self.jumpInfo.selectFeatureIndex or 1
    self.jumpInfo.selectFeatureIndex = nil
    self.schemeIndex = self:ResolveSchemeIndex(self.jumpInfo.selectSchemeIndex)
    self._bReplayEnterAction = nil
    self:UpdateUI(true)
    if not self.CurUpgradeInfo or not self.CurUpgradeInfo[self.selectLevel] then
      log_error(string.format("XSuit_Workshop_Tab_Component:SelectOnePeriodTab no level data, period:%s, branch:%s, level:%s", tostring(self.selectPeriod), tostring(self.selectBranchId), tostring(self.selectLevel)))
      return
    end
    self:UpdateScene()
    self:UpdateBranchComponent()
    self:InitMoneyComponent()
    self:InitDownloadBtn()
    self.bBranch = LogicXSuit.IsBranch(self.selectPeriod)
    local periodIndex = self.MaxPeriod - self.selectPeriod + 1
    local periodSubData = self.periodList[periodIndex].branchList
    self.ExtendedLoopScrollBox_Period:SetSubData(periodIndex, periodSubData)
    self.ExtendedLoopScrollBox_Period:RefreshAllSubItems()
    self.ExtendedLoopScrollBox_Period:SelectSub(self.selectBranchId + 1)
    self.ExtendedLoopScrollBox_Level:SetData(self.CurUpgradeInfo)
    self:SelectOneLevelTab(self.selectLevel)
    local logic_xsuit_activity = ModuleManager.GetModule(ModuleManager.JumpModuleConfig.logic_xsuit_activity)
    logic_xsuit_activity:PlaySpinAudio_BG(1, self.selectPeriod)
    local schemeList = LogicXSuit.GetSchemeIdByBranch(self.selectPeriod, self.selectBranchId)
    self:SetClothSchemeIDList(schemeList)
    self:RefreshBranchCollectRewardReddot()
    self:RefreshUpgradeReddots()
  end
end

function XSuit_Workshop_Tab_Component:SelectOneBranchTab(branchId)
  if self.ExtendedLoopScrollBox_Period then
    self.selectBranchId = branchId
    self.ExtendedLoopScrollBox_Period:RefreshAllSubItems()
    self.lastSelectBranchId[self.selectPeriod] = branchId
    self:RefreshOnePeriodTab(self.selectPeriod)
    self.selectLevel = 0
    self.jumpInfo.selectSchemeIndex = nil
    self.selectFeatureIndex = self.jumpInfo.selectFeatureIndex or 1
    self.jumpInfo.selectFeatureIndex = nil
    local bUIOK = self:UpdateUI(true)
    self:InitDownloadBtn()
    if not bUIOK then
      log_error(string.format("XSuit_Workshop_Tab_Component:SelectOneBranchTab data not ready, period:%s, branch:%s", tostring(self.selectPeriod), tostring(branchId)))
      return
    end
    self.ExtendedLoopScrollBox_Level:SetData(self.CurUpgradeInfo)
    self._bReplayEnterAction = true
    self:SelectOneLevelTab(self.selectLevel)
    local schemeList = LogicXSuit.GetSchemeIdByBranch(self.selectPeriod, self.selectBranchId)
    self:SetClothSchemeIDList(schemeList)
    self:RefreshUpgradeReddots()
  end
end

function XSuit_Workshop_Tab_Component:RefreshOneBranchTab(branchId)
  if self.ExtendedLoopScrollBox_Period then
  end
end

function XSuit_Workshop_Tab_Component:RefreshOneLevelTab(index, data)
  if self.ExtendedLoopScrollBox_Level then
    self.ExtendedLoopScrollBox_Level:RefreshItem(index, data)
    self.ExtendedLoopScrollBox_Level:RefreshAllSubItems()
  end
end

function XSuit_Workshop_Tab_Component:SelectOneLevelTab(index)
  if self.ExtendedLoopScrollBox_Level then
    local levelInfo = self.CurUpgradeInfo and self.CurUpgradeInfo[index]
    if not levelInfo then
      log_error(string.format("XSuit_Workshop_Tab_Component:SelectOneLevelTab no level data, period:%s, branch:%s, level:%s", tostring(self.selectPeriod), tostring(self.selectBranchId), tostring(index)))
      return
    end
    local oldLevel = self.selectLevel
    self.ExtendedLoopScrollBox_Level:Select(index)
    self.ExtendedLoopScrollBox_Level:ScrollToItem(index)
    self.selectLevel = index
    self.schemeIndex = self:ResolveSchemeIndex(self.jumpInfo.selectSchemeIndex)
    self.ItemResID = levelInfo.item_id
    if self.initData then
      self.initData.initEquipList = {
        {
          self.ItemResID
        }
      }
    end
    self:RefreshOneFeatureTab(oldLevel)
    self.selectFeatureIndex = self.selectFeatureIndex or 1
    self.ExtendedLoopScrollBox_Level:SetSubData(index, levelInfo.featureList)
    self.ExtendedLoopScrollBox_Level:SelectSub(self.selectFeatureIndex)
    self.ExtendedLoopScrollBox_Level:ScrollToSubItem(self.selectFeatureIndex)
    self:UpdateShareButton()
    self:UpdateChangeStateButton()
    self:UpdatePoseButton()
    self:UpdateSlideButton()
    self:_UpdateSchemeId()
    self:TryShowEffect()
    self:UpdateUnlockFeatureButton(false)
    self:UpdateButtonGroup()
    self:UpdateMaterial()
    self:RefreshFeatureComponent()
    self:RefreshGlideComponent()
    self:UpdateCurXSuitInfo()
    self:_UpdateSchemeId()
    self:_ApplySchemeId()
  end
end

function XSuit_Workshop_Tab_Component:RefreshOneFeatureTab(sub_index)
  if self.ExtendedLoopScrollBox_Level then
    self.ExtendedLoopScrollBox_Level:RefreshSubItem(sub_index)
  end
end

function XSuit_Workshop_Tab_Component:SelectOneFeatureTab(sub_index)
  if self.ExtendedLoopScrollBox_Level then
    local oldFeatureIndex = self.selectFeatureIndex
    self.ExtendedLoopScrollBox_Level:SelectSub(sub_index)
    self.ExtendedLoopScrollBox_Level:ScrollToSubItem(sub_index)
    self.selectFeatureIndex = sub_index
    self.schemeIndex = self:ResolveSchemeIndex()
    self.ExtendedLoopScrollBox_Level:RefreshSubItem(oldFeatureIndex)
    self:UpdateSlideButton()
    self:_UpdateSchemeId()
    self:TryShowEffect()
    self:RefreshFeatureComponent()
    self:RefreshGlideComponent()
    self:UpdateCurXSuitInfo()
    self:_UpdateSchemeId()
    self:_ApplySchemeId()
  end
end

function XSuit_Workshop_Tab_Component:CacheCurXSuitInfo()
  self.jumpInfo = {
    selectPeriod = self.selectPeriod,
    selectBranchId = self.selectBranchId,
    selectLevel = self.selectLevel,
    selectFeatureIndex = self.selectFeatureIndex,
    selectSchemeIndex = self.schemeIndex
  }
end

function XSuit_Workshop_Tab_Component:GetLastSelectBranchId(period)
  return self.lastSelectBranchId[period] or 0
end

local Trait = require("common.trait")
local Cxsuit_level_tab_component = Trait(Trait.TraitPrototype, nil, XSuit_Workshop_Tab_Component)
return Cxsuit_level_tab_component
