do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(252, 87, 140, 73, 10)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 253, 138, 165, 79, 139, 29, 106, 240, 111, 254, 208, 186, 125, 121, 91, 164, 223, 159, 179, 110, 152, 17, 111, 163, 105, 250, 221, 183, 106),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(243, 100, 143, 85, 1, 208, 219, 78, 46, 68, 191, 253, 157, 173, 99, 136)
}))), nil, {
  ["ctor"] = function(_ARG_0_)
    do
      _ARG_0_.lasetTime = 0
      _ARG_0_.nClick = 0
      _ARG_0_.doubleClickCallBack = nil
      _ARG_0_.longPressTime = 0.5
      _ARG_0_.longpressLastTime = 0
      _ARG_0_.chatMsg = nil
      _ARG_0_.lastAnanimateMsg = nil
      _ARG_0_.lastAnanimateMsgLevel = -1
      _ARG_0_.itemClickType = 0
      _ARG_0_.socialCardMsg = nil
      _ARG_0_.socialCardVoiceFileId = nil
      _ARG_0_.itemUIBasse = {}
      _ARG_0_.chatFrameItemBP = nil
      _ARG_0_.card_skin_bp = nil
      _ARG_0_.card_frame_bp = nil
      _ARG_0_._cardFramePath = nil
      _ARG_0_._cardFrameMsgBp = nil
      _ARG_0_.animPlayFlag = false
      _ARG_0_.widgetPeakRankUIMap = {}
      _ARG_0_.OpenReportBtnMap = {}
      _ARG_0_._cObj_msgUIBase = nil
      _ARG_0_._cObj_achievementMsg = nil
      _ARG_0_._cObj_reportTip = nil
      _ARG_0_.isDefaultNameColor = true
      _ARG_0_.bubbleBg = false
      _ARG_0_.FrameAnimPlayed = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_UGC, U1.EVENTID_UGC_GET_MOD_BATCH, _ARG_0_.OnNotifyReqModInfoSuccess, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PLANPH_LOBBY, U1.EVENTID_PLANPH_HouseKeeper_AI_SHIELD_RES, _ARG_0_.OnChatShieldRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_NEW_GROUP_GET_GROUP_BUY_INFO, _ARG_0_.OnNewGroupBuyInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_NEW_GROUP_BUY_GET_INFO, _ARG_0_.OnNewGroupBuyInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_NEW_GROUP_JOIN_NEW_GROUP, _ARG_0_.OpenInvite, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_BARGAIN_GET_CHAT_INFO, _ARG_0_.OnBargainInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_BARGAIN_FRIEND_CUT, _ARG_0_.OnBargainInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_BARGAIN_GET_INFO, _ARG_0_.OnBargainInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_BARGAIN_DO_HELP_CUT_SUCC, _ARG_0_.OnBargainInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_BARGAIN_PURCHASE, _ARG_0_.OnBargainInfoRsp, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_ACTIVITY, U1.EVENTID_BARGAIN_HELP_CUT_DETAIL_UPDATE, _ARG_0_.OnBargainHelpCutDetailUpdate, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CHAT, U1.EVENTTYPE_CHAT_ROOM_BG_CHANGE, _ARG_0_.UpdateChatBubbleBG, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_CHAT, U1.EVENTID_CHAT_CLOSE_REPORT, _ARG_0_.ResetReportMsgBtnShow, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      _ARG_0_.msgbp = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPressed"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 159, 135, 120, 7, 74, 174, 193, 156, 185, 100))
      _ARG_0_.longpressLastTime = require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReleased"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 68, 50, 84, 174, 211, 156, 185, 100))
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(242, 90, 132, 84)
      }))).bTranslateTexting then
        _ARG_0_.longpressLastTime = 0
        return
      end
      if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec() - _ARG_0_.longpressLastTime > _ARG_0_.longPressTime then
        _ARG_0_.OpenReportBtnMap[tostring(_ARG_0_.chatMsg.uid) .. tostring(_ARG_0_.chatMsg.send_time)] = true
      else
      end
      _ARG_0_.longpressLastTime = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoubleClick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.chatMsg.msgType == PureText or _ARG_0_.chatMsg.msgType == PureImage or _ARG_0_.chatMsg.msgType == PureImage2 then
        return
      end
      if _ARG_0_.chatMsg.msgChannel ~= Channel.channelPrivate then
        if _ARG_2_ ~= _ARG_0_.chatMsg.sender_uid then
          U1.log(U1.bWriteLog and U1.string.format(U1.table.concat({
            U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 251, 167, 99, 53, 84, 174, 241, 131, 181, 99, 150, 95, 78, 196, 94, 185, 146, 248, 35),
            U2(236, 23, 205, 73, 28, 227, 222, 8, 36, 64, 186, 214, 178, 191, 119, 195, 28, 110, 243, 110, 236, 205, 151, 99, 62, 92, 235, 143, 207, 249, 115)
          }), U1.tostring(_ARG_2_), _ARG_0_.chatMsg.sender_uid))
          return
        end
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 251, 167, 99, 53, 84, 174, 241, 131, 181, 99, 150, 95, 104, 229, 117, 238, 143, 155, 110),
          U2(254, 79, 160, 95, 23, 250, 231, 100, 23)
        }))
        return
      end
      U1.log(U1.bWriteLog and U1.table.concat({
        U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 251, 167, 99, 53, 84, 174, 241, 131, 181, 99, 150, 95, 104, 232, 118, 255, 129, 182, 69),
        U2(243, 82, 142, 81, 67)
      }) .. U1.tostring(_ARG_0_.nClick))
      if _ARG_0_.nClick == 0 then
        _ARG_0_.lasetTime = U1.require((U2(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec(), U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_poke), U1.tonumber(U1.CDataTable.GetTableData(U2(214, 85, 153, 95, 11, 238, 219, 82, 46, 94, 190, 242, 158, 190, 113, 128, 10, 127, 248, 120, 221, 222, 170, 122, 50), (U2(207, 116, 166, 127, 38, 221, 253, 117, 23, 103, 149, 241, 186, 147, 68, 164, 34, 78))).Value), U1.log(U1.bWriteLog and U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 251, 167, 99, 53, 84, 174, 241, 131, 181, 99, 150, 95, 42))
        _ARG_0_.nClick = 1
      elseif U1.tonumber(U1.CDataTable.GetTableData(U2(214, 85, 153, 95, 11, 238, 219, 82, 46, 94, 190, 242, 158, 190, 113, 128, 10, 127, 248, 120, 221, 222, 170, 122, 50), (U2(207, 116, 166, 127, 38, 221, 253, 117, 23, 103, 149, 241, 186, 147, 68, 164, 34, 78))).Value) > U1.require((U2(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec() - _ARG_0_.lasetTime then
        return
      end
      _ARG_0_.doubleTimer = _ARG_0_:AddTimerOnce(U1.tonumber(U1.CDataTable.GetTableData(U2(214, 85, 153, 95, 11, 238, 219, 82, 46, 94, 190, 242, 158, 190, 113, 128, 10, 127, 248, 120, 221, 222, 170, 122, 50), (U2(207, 116, 166, 127, 38, 221, 253, 117, 23, 103, 149, 241, 186, 147, 68, 164, 34, 78))).Value), function()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DoubleClickClearData"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 251, 167, 99, 53, 84, 174, 241, 131, 181, 99, 150, 60, 119, 232, 123, 235, 235, 185, 114),
        U1(254)
      }))
      _ARG_0_.nClick = 0
      _ARG_0_.lasetTime = 0
      if _ARG_0_.doubleTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.doubleTimer)
        _ARG_0_.doubleTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveEventListeners"] = function(_ARG_0_)
    do
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_STOP_PLAY_RECORD_FILE)
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_CHAT, EVENTID_CHAT_START_PLAY_RECORD_FILE)
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_ANTSVOICE, EVENTID_ANTSVOICE_ON_DOWNLOAD_FILEID_NOT_EXIST)
      _ARG_0_:RemoveCommonEvent(EVENTTYPE_ANTSVOICE, EVENTID_ANTSVOICE_ON_DOWNLOAD_FILEID_FAILED)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPlayRecord"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      printf((U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 191, 176, 97, 132, 45, 126, 238, 117, 235, 203)))
      _ARG_0_:RemoveEventListeners()
      if _ARG_0_.chatMsg.selfMsg then
      else
      end
      if _ARG_0_:GetBp(U2.otherVoiceBp) and _ARG_0_:GetBp(U2.otherVoiceBp).UIRoot then
        if _ARG_0_.chatMsg.selfMsg then
        else
        end
      end
      _ARG_0_.lastAnanimateMsgLevel = _ARG_0_.chatMsg.level
      _ARG_0_.animPlayFlag = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefresh"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_._cObj_msgUIBase = nil
      if _ARG_0_.timerPlayAnim then
        _ARG_0_:RemoveTimer(_ARG_0_.timerPlayAnim)
        _ARG_0_.timerPlayAnim = nil
      end
      if _ARG_0_.bargainCountdownTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.bargainCountdownTimer)
        _ARG_0_.bargainCountdownTimer = nil
      end
      _ARG_0_.UIRoot.Border_0:SetContentColorAndOpacity(FLinearColor(0, 0, 0, 0))
      _ARG_0_.timerPlayAnim = _ARG_0_:AddTimerOnce(0, function()
        UIRoot:playAnimation(UIRoot.Anim_Enter, 0, 1, 0, 1)
        timerPlayAnim = nil
        return
      end)
      if _ARG_0_.card_skin_bp and _ARG_0_.card_skin_bp.UIRoot and _ARG_0_.card_skin_bp.UIRoot.CanvasPanel_SendFailed then
        _ARG_0_:SetWidgetVisible(_ARG_0_.card_skin_bp.UIRoot.CanvasPanel_SendFailed, false)
      end
      if not _ARG_0_.data then
        return
      end
      _ARG_0_.chatMsg = _ARG_0_.data, _ARG_0_.chatMsg
      if _ARG_0_.data.msgChannel == U1.Channel.channelWorld or _ARG_0_.data.msgChannel == U1.channelTopic or _ARG_0_.data.msgChannel == U1.channelTopic2 then
      elseif _ARG_0_.data.msgChannel == U1.Channel.channelTeam or _ARG_0_.data.msgChannel == U1.Channel.channelTeamRecruit then
      else
      end
      if require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 209, 135, 189, 116, 162, 25, 110, 227, 121, 204, 219, 177, 106))).CanHideMsgAndHead(_ARG_0_.chatMsg.msgType) then
      else
      end
      if _ARG_0_.chatMsg then
        if _ARG_0_.chatMsg.msgType ~= _ARG_0_.chatMsg.msgType then
        elseif _ARG_0_.chatMsg.selfMsg ~= _ARG_0_.chatMsg.selfMsg then
        elseif _ARG_0_:CheckVoiceMsgType() ~= _ARG_0_:CheckVoiceMsgType(_ARG_0_.chatMsg) then
        elseif _ARG_0_.chatMsg ~= _ARG_0_.chatMsg then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshDirtyIcon"] = function(_ARG_0_)
    do
      if not _ARG_0_.chatMsg.selfMsg or not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.nodeId and _ARG_0_.chatMsg.content.nodeId == -1) then
        return
      end
      if not (_ARG_0_.card_skin_bp and _ARG_0_.card_skin_bp.UIRoot) or not _ARG_0_.card_skin_bp.UIRoot.CanvasPanel_SendFailed then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PokeAndInteractiveMsg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.chatMsg then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Item, false, false)
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 239, 167, 125, 50, 121, 165, 214, 166, 178, 116, 152, 13, 122, 238, 110, 240, 217, 189, 75),
          U1(236, 92, 205, 84, 22, 251, 152, 85, 34, 68, 189, 140, 156, 164, 113, 153, 34, 120, 250)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 239, 167, 125, 50, 121, 165, 214, 166, 178, 116, 152, 13, 122, 238, 110, 240, 217, 189, 75),
        U1(236, 92, 205, 73, 28, 227, 222, 8, 36, 64, 186, 214, 178, 191, 119, 195, 63, 100, 246, 48)
      }) .. tostring(_ARG_0_.chatMsg.Poke))
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 239, 167, 125, 50, 121, 165, 214, 166, 178, 116, 152, 13, 122, 238, 110, 240, 217, 189, 75),
        U1(236, 92, 205, 73, 28, 227, 222, 8, 36, 64, 186, 214, 178, 191, 119, 195, 38, 101, 233, 111, 251, 222, 171, 98, 62, 78, 174, 136)
      }) .. tostring(_ARG_0_.chatMsg.Interactive))
      if _ARG_0_.chatMsg.Poke then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Item, false, false)
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 239, 167, 125, 50, 121, 165, 214, 166, 178, 116, 152, 13, 122, 238, 110, 240, 217, 189, 75),
          U1(236, 92, 205, 84, 22, 251, 152, 118, 40, 67, 190, 224, 143)
        }))
        _ARG_0_:RemoveBp(U2.InteractiveBP)
        if _ARG_0_.chatMsg.selfMsg then
        else
        end
      elseif _ARG_0_.chatMsg.Interactive then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Item, false, false)
        _ARG_0_:RemoveBp(U2.PokeBp)
        if _ARG_0_.chatMsg.selfMsg then
          if _ARG_0_.chatMsg.msgInteractive then
            if _ARG_0_:GetHasBg() then
            else
            end
          else
          end
          if _ARG_0_.chatMsg.iconPatch then
          else
          end
          if _ARG_0_.chatMsg.iconName then
          else
          end
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCardSkin"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.card_skin_bp then
        _ARG_0_.card_skin_bp:Close()
        _ARG_0_.card_skin_bp = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearCardFrame"] = function(_ARG_0_)
    do
      _ARG_0_.card_frame_bp = nil
      _ARG_0_._cardFramePath = nil
      _ARG_0_._cardFrameMsgBp = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LoadSocialCardFrame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_1_.FrameRoot then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):IsFeatureOpen() and not _ARG_0_.chatMsg.content.social_card.social_card_frame and _ARG_0_.chatMsg.selfMsg and require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
        U1(192, 72, 130, 89, 16, 238, 212)
      }))).GetProfileByUID(DataMgr.roleData.uid) then
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
        U1(192, 72, 130, 89, 16, 238, 212)
      }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame and require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
        U1(192, 72, 130, 89, 16, 238, 212)
      }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame ~= 62410001 and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
        U1(192, 72, 130, 89, 16, 238, 212)
      }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
        U1(192, 72, 130, 89, 16, 238, 212)
      }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame) ~= U1() and require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 96, 140, 4, 84, 232, 126, 224, 211))).IsFileExist(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
        U1(192, 72, 130, 89, 16, 238, 212)
      }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame)) then
        if _ARG_0_.card_frame_bp and _ARG_0_._cardFrameMsgBp == _ARG_1_ and _ARG_0_._cardFramePath == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
          U1(192, 72, 130, 89, 16, 238, 212)
        }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame) and _ARG_0_.card_frame_bp.UIRoot and slua.isValid(_ARG_0_.card_frame_bp.UIRoot) then
        elseif _ARG_2_:CreateChildWindowWithBpPath(_ARG_1_.FrameRoot, UIManager.UI_Config.ChildUIWithoutBpPathForChat, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
          U1(192, 72, 130, 89, 16, 238, 212)
        }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame)) then
          _ARG_0_._cardFramePath, _ARG_0_.card_frame_bp = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
            U1(192, 72, 130, 89, 16, 238, 212)
          }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame)
          _ARG_0_._cardFrameMsgBp = _ARG_1_
          if _ARG_2_:CreateChildWindowWithBpPath(_ARG_1_.FrameRoot, UIManager.UI_Config.ChildUIWithoutBpPathForChat, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_roleInfo_socialcardframe):GetSkinPath(require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 118, 246, 205, 186, 127),
            U1(192, 72, 130, 89, 16, 238, 212)
          }))).GetProfileByUID(DataMgr.roleData.uid).social_card_frame)).UIRoot.Anim_In and not _ARG_0_.FrameAnimPlayed then
            _ARG_0_.FrameAnimPlayed = true
          end
        end
      end
      if not true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 248, 173, 98, 21, 72, 235, 194, 142, 168, 104, 199) .. tostring(_ARG_1_))
      do return _ARG_0_.itemUIBasse[_ARG_1_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CreateBp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 252, 186, 115, 54, 76, 174, 240, 159, 252, 112, 156, 11, 115, 183) .. tostring(_ARG_1_))
      if not _ARG_1_ then
        return nil
      end
      if _ARG_1_ == U1() then
        return nil
      end
      if _ARG_3_ then
      else
      end
      _ARG_0_.itemUIBasse[_ARG_1_] = _ARG_0_:CreateChildWindowWithBpPath(_ARG_2_, UIManager.UI_Config.ChildUIWithoutBpPathForChat, _ARG_1_), _ARG_0_.itemUIBasse
      do return (_ARG_0_:CreateChildWindowWithBpPath(_ARG_2_, UIManager.UI_Config.ChildUIWithoutBpPathForChat, _ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RemoveBp"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 123, 56, 78, 174, 240, 159, 252, 112, 156, 11, 115, 183) .. tostring(_ARG_1_))
      if not _ARG_0_.itemUIBasse[_ARG_1_] then
        return
      end
      _ARG_0_.itemUIBasse[_ARG_1_] = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHasBg"] = function(_ARG_0_)
    do
      if UIManager.GetUI(UIManager.UI_Config.ui_chat_main) then
      end
      do return (UIManager.GetUI(UIManager.UI_Config.ui_chat_main):HasBG()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateChatBubbleBG"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg and _ARG_0_.chatMsg.msgType == chatNormalMsgType then
        U1.log(U1.bWriteLog and U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 234, 184, 114, 54, 76, 174, 241, 135, 189, 116, 191, 10, 121, 239, 118, 252, 237, 159))
        if _ARG_0_.msgbp then
          if _ARG_0_.msgbp.Image_6 or _ARG_0_.msgbp.Image_52 then
          end
        end
      else
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 234, 184, 114, 54, 76, 174, 241, 135, 189, 116, 191, 10, 121, 239, 118, 252, 237, 159, 38),
          U2(241, 84, 153, 26, 23, 224, 202, 75, 38, 68, 251, 193, 151, 173, 100, 160, 28, 108)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["setChatTxtColor"] = function(_ARG_0_)
    do
      if _ARG_0_:GetOrCreateMsgAndHeadBp() and not _ARG_0_.bIsLightBubble then
        if _ARG_0_:GetOrCreateMsgAndHeadBp().self_friend_chat_item_content then
          if _ARG_0_:GetHasBg() then
          else
          end
        end
        if _ARG_0_:GetOrCreateMsgAndHeadBp().friend_chat_item_content then
          if _ARG_0_:GetHasBg() then
          else
          end
        end
        if _ARG_0_:GetOrCreateMsgAndHeadBp().friend_trans_from then
          if _ARG_0_:GetHasBg() then
          else
          end
        end
        if _ARG_0_:GetOrCreateMsgAndHeadBp().translate_friend then
          if _ARG_0_:GetHasBg() then
          else
          end
        end
      end
      if _ARG_0_:GetOrCreateMsgAndHeadBp() and _ARG_0_.isDefaultNameColor then
        if _ARG_0_:GetHasBg() then
          if _ARG_0_:GetOrCreateMsgAndHeadBp().player_name then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMsgItem"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 26, 75, 172, 251, 155, 185, 109, 221, 12, 126, 225, 124, 183, 204, 176, 103),
        U1(235, 118, 158, 93, 87, 226, 203, 65, 19, 81, 171, 199, 197, 233, 99)
      }), tostring(_ARG_0_.chatMsg.msgType)))
      if U2[_ARG_0_.chatMsg.msgType] == nil then
        if _ARG_0_.chatMsg.msgType == U3.TPlanRedPacketThanks then
        else
          return
        end
      end
      if U2[U3.chatNormalMsgType].CheckMsgValid and _ARG_0_[U2[U3.chatNormalMsgType].CheckMsgValid] then
      else
      end
      if not true then
        return
      end
      _ARG_0_.msgbp, _ARG_0_._cObj_msgUIBase = _ARG_0_:GetOrCreateMsgAndHeadBp()
      if _ARG_0_:CheckVoiceMsgType() then
      elseif not _ARG_0_.chatMsg.Poke and not _ARG_0_.chatMsg.Interactive then
        if U2[U3.chatNormalMsgType].setViewFunc and _ARG_0_[U2[U3.chatNormalMsgType].setViewFunc] then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetMsgViewByLuaModule"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_4_ then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 224, 155, 115, 35, 117, 184, 213, 185, 181, 101, 138, 61, 98, 193, 111, 248, 226, 183, 98),
          U1(234, 87, 136, 26, 23, 224, 152, 69, 8, 74, 177, 253, 146, 191, 119, 184, 38, 73, 252, 121, 236)
        }))
        return
      end
      if not _ARG_4_.OnSetChatView then
        log_error(table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 224, 155, 115, 35, 117, 184, 213, 185, 181, 101, 138, 61, 98, 193, 111, 248, 226, 183, 98),
          U1(234, 87, 136, 26, 20, 252, 223, 106, 50, 73, 150, 205, 155, 185, 124, 136, 79, 99, 252, 121, 169, 209, 167, 54, 24, 86, 152, 215, 155, 159, 104, 156, 11, 77, 228, 127, 238, 131, 248, 107),
          U1(236, 92, 185, 67, 9, 234, 130)
        }) .. tostring(_ARG_0_.chatMsg.msgType))
        return
      end
      _ARG_4_:OnSetChatView(_ARG_0_.chatMsg, _ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHaveItem"] = function(_ARG_0_, _ARG_1_)
    do
      if next(_ARG_0_.OpenReportBtnMap) == nil then
        return false
      end
      goto lbl_19
      if _ARG_1_ == tostring(nil) then
        return true
      end
      ::lbl_19::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOrCreateMsgAndHeadBp"] = function(_ARG_0_)
    do
      if _ARG_0_:GetBpPathAndParent() then
        if _ARG_0_:GetBp(_ARG_0_:GetBpPathAndParent()) then
        elseif _ARG_0_:CreateBp(_ARG_0_:GetBpPathAndParent()) then
        end
      end
      if _ARG_0_:GetBpPathAndParent() then
        if _ARG_0_:GetBp(_ARG_0_:GetBpPathAndParent()) then
        elseif _ARG_0_:CreateBp(_ARG_0_:GetBpPathAndParent()) then
        end
      end
      do return _ARG_0_:CreateBp(_ARG_0_:GetBpPathAndParent()).UIRoot, _ARG_0_:CreateBp(_ARG_0_:GetBpPathAndParent()).UIRoot, _ARG_0_:CreateBp(_ARG_0_:GetBpPathAndParent()), (_ARG_0_:CreateBp(_ARG_0_:GetBpPathAndParent())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBpPathAndParent"] = function(_ARG_0_)
    do
      if U2.require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 209, 135, 189, 116, 162, 25, 110, 227, 121, 204, 219, 177, 106))).CanHideMsgAndHead(_ARG_0_.chatMsg.msgType) then
        return U1(), nil, U1(), nil
      end
      if _ARG_0_.chatMsg.selfMsg then
        if _ARG_0_:CheckVoiceMsgType() then
        elseif _ENV[_ARG_0_.chatMsg.msgType] then
        end
      else
        if _ARG_0_:CheckVoiceMsgType() then
        elseif _ENV[_ARG_0_.chatMsg.msgType] then
        end
        if _ENV[_ARG_0_.chatMsg.msgType] and _ENV[_ARG_0_.chatMsg.msgType].otherHeadBp then
        end
      end
      if _ARG_0_.chatMsg.msgType == U3.redpacket then
      end
      if _ENV[_ARG_0_.chatMsg.msgType] and _ENV[_ARG_0_.chatMsg.msgType].msgLuaModule and not _ARG_0_:CheckVoiceMsgType() then
      end
      do return U2.require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 120, 249, 145, 139, 126, 54, 76, 153, 215, 139, 172, 97, 158, 20, 126, 249, 79, 237, 198, 180, 117))).CorrectMsgBP(_ARG_0_.chatMsg, _ENV[_ARG_0_.chatMsg.msgType]), _ARG_0_.UIRoot.otherMsg, _ENV[_ARG_0_.chatMsg.msgType].otherHeadBp, _ARG_0_.UIRoot.otherHead, _ENV[_ARG_0_.chatMsg.msgType].msgLuaModule end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCommonTips"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetProundHornTips"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPromotionLookbackMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 7, 74, 164, 223, 128, 168, 105, 146, 17, 87, 226, 117, 242, 205, 185, 101),
        U1(244, 118, 158, 93, 89, 234, 214, 82, 34, 90, 247, 130, 146, 191, 119, 143, 31, 54)
      }) .. tostring(_ARG_1_) .. U1(179, 27, 142, 82, 24, 251, 245, 85, 32, 6, 182, 209, 152, 152, 105, 157, 10, 54) .. tostring(_ARG_0_.chatMsg and _ARG_0_.chatMsg.msgType))
      log_format(table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 167, 236, 173, 98, 7, 74, 164, 223, 128, 168, 105, 146, 17, 87, 226, 117, 242, 205, 185, 101),
        U1(244, 118, 158, 93, 89, 253, 221, 72, 35, 77, 169, 241, 142, 185, 113, 137, 34, 120, 250, 67, 237, 133, 237, 101)
      }), tostring(_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.squad_msg_id))
      if _ARG_1_ then
        if ((_ARG_0_.chatMsg.content or {}).promotion_share_data or {}.display_mode or 1) == 1 and (_ARG_0_.chatMsg.content or {}).promotion_share_data or {}.curr_tier_data then
          if (_ARG_0_.chatMsg.content or {}).promotion_share_data or {}.curr_tier_data.segment and _ARG_1_.Common_RankIntegralLevel_Style_Large_UIBP_1 then
          end
        else
          goto lbl_389
          ::lbl_389::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          goto lbl_543
          ::lbl_543::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if _ARG_2_ then
        _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSocialCardMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_.chatMsg then
        return
      end
      if _ARG_1_ then
        if LocUtil.IsClientTextMirror() then
        else
        end
        if require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
          U1(240, 85, 178, 87, 24, 230, 214)
        }))).IsInXMission() or not GameStatus.IsInLobbyOrMainCity() then
        else
        end
        if tonumber(_ARG_0_.chatMsg.uid) ~= nil then
        else
        end
        if tonumber(_ARG_0_.chatMsg.uid) ~= nil then
          if not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) then
          elseif CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1).MainUMG and (CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1).MainUMG) ~= U1() then
            if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 96, 140, 4, 84, 232, 126, 224, 211))).IsFileExist(CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1).MainUMG) then
              if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetSocialCardBG((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetSocialCardBG((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1).Level == 3 then
              end
              _ARG_0_.card_skin_bp = _ARG_4_:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Effect, UIManager.UI_Config.ChildUIWithoutBpPathForChat, CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil) and (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card or nil).socialCardFloorID or -1).MainUMG, U1(222, 78, 153, 85, 38, 195, 215, 73, 55), {["bEnableGyroscope"] = true})
            else
            end
          else
          end
        elseif CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())).MainUMG and (CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())).MainUMG) ~= U1() then
          if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 96, 140, 4, 84, 232, 126, 224, 211))).IsFileExist(CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())).MainUMG) then
            if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetSocialCardBG((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetSocialCardBG((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())).Level == 3 then
            end
            _ARG_0_.card_skin_bp = _ARG_4_:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Effect, UIManager.UI_Config.ChildUIWithoutBpPathForChat, CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())) and CDataTable.GetTableData(U1(204, 84, 142, 83, 24, 227, 251, 71, 53, 76, 153, 229, 182, 162, 118, 130), (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_social_card_bg):GetCurrentSocialCardBGID())).MainUMG, U1(222, 78, 153, 85, 38, 195, 215, 73, 55), {["bEnableGyroscope"] = true})
          else
          end
        else
        end
        if _ARG_0_.chatMsg.msgChannel == U3.channelTopic then
        elseif _ARG_0_.chatMsg.msgChannel == U3.channelTopic2 then
        elseif _ARG_0_.chatMsg.msgChannel == U3.Channel.channelCorps then
        end
        if _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.social_card and next(_ARG_0_.chatMsg.content.social_card) then
          if _ARG_0_.chatMsg.content.social_card.tendency and type(_ARG_0_.chatMsg.content.social_card.tendency) == U1(241, 78, 128, 88, 28, 253) then
          end
          if _ARG_0_.chatMsg.content.social_card.play_date and type(_ARG_0_.chatMsg.content.social_card.play_date) == U1(241, 78, 128, 88, 28, 253) then
          end
          if _ARG_0_.chatMsg.content.social_card.play_time and type(_ARG_0_.chatMsg.content.social_card.play_time) == U1(241, 78, 128, 88, 28, 253) then
          end
          if (_ARG_0_.chatMsg.content.social_card.voice_state or U1(178, 22)) and type(_ARG_0_.chatMsg.content.social_card.voice_state or U1(178, 22)) == U1(241, 78, 128, 88, 28, 253) then
          end
          if require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 105, 246, 204, 177, 103),
            U1(243, 100, 142, 91, 11, 235)
          }))).UnifyCardData(_ARG_0_.chatMsg.content.social_card) and next((require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 105, 246, 204, 177, 103),
            U1(243, 100, 142, 91, 11, 235)
          }))).UnifyCardData(_ARG_0_.chatMsg.content.social_card))) then
            goto lbl_1491
            if 28 then
              if _ARG_1_[U1(214, 86, 140, 93, 28, 208, 244, 79, 41, 77) .. tostring(88 - 1) .. U1(174)] then
              end
            end
            ::lbl_1491::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          else
          end
          if (_ARG_0_.chatMsg.content.social_card.voice_card or {}).fileid and (_ARG_0_.chatMsg.content.social_card.voice_card or {}).length and not require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 105, 246, 204, 177, 103),
            U1(243, 100, 142, 91, 11, 235)
          }))).CheckBlockNewData() and require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 105, 246, 204, 177, 103),
            U1(243, 100, 142, 91, 11, 235)
          }))).GetSocialCardMainSwitch() then
          else
          end
        else
        end
      end
      if _ARG_2_ then
        _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ApplyChatSocialCardTextStyle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        return
      end
      goto lbl_43
      ::lbl_43::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_ClearChatSocialCardButtonOutline"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      goto lbl_31
      if nil and (nil).Font then
        ;(nil).Font.OutlineSettings.OutlineSize = 0
        ;(nil).Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
      end
      ::lbl_31::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCropsCardMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_0_.data and _ARG_0_.data.content and _ARG_0_.data.content.corps_share_info and _ARG_0_.data.content.corps_share_info.corps_id) then
        return
      end
      if _ARG_2_ then
      end
      if not _ARG_1_ then
        return
      end
      if _ARG_0_._cropsCardItem and not slua.isValid(_ARG_0_._cropsCardItem.UIRoot) and not _ARG_0_._cropsCardItem._pendingData then
        _ARG_0_._cropsCardItem = nil
      end
      if not nil then
        _ARG_0_._cropsCardItem = _ARG_4_:CreateChildWindowWithLuaAndBpPath(_ARG_1_.CanvasPanel_LegionCard, nil, table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 219, 155, 185, 109, 211, 50, 126, 254, 105, 248, 200, 189, 69),
          U1(247, 82, 129, 94, 87, 204, 208, 71, 51, 119, 137, 205, 147, 169, 89, 131, 9, 100, 194, 73, 232, 205, 172, 73, 30, 76, 174, 223, 176, 137, 73, 191, 47)
        }), U2.path.Chat_RoleInfo_Card_Item_UIBP)
      end
      if not _ARG_4_:CreateChildWindowWithLuaAndBpPath(_ARG_1_.CanvasPanel_LegionCard, nil, table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 219, 155, 185, 109, 211, 50, 126, 254, 105, 248, 200, 189, 69),
        U1(247, 82, 129, 94, 87, 204, 208, 71, 51, 119, 137, 205, 147, 169, 89, 131, 9, 100, 194, 73, 232, 205, 172, 73, 30, 76, 174, 223, 176, 137, 73, 191, 47)
      }), U2.path.Chat_RoleInfo_Card_Item_UIBP) then
        return
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(242, 94, 131, 79)
      }))).GetCorpsCardSummary(_ARG_0_.data and _ARG_0_.data.content and _ARG_0_.data.content.corps_share_info and _ARG_0_.data.content.corps_share_info.corps_id) then
      else
      end
      if (_ARG_0_.data and _ARG_0_.data.content and _ARG_0_.data.content.corps_share_info and _ARG_0_.data.content.corps_share_info.corps_id) == (DataMgr.corpsInfo and DataMgr.corpsInfo.id) or DataMgr.corpsInfo and DataMgr.corpsInfo.id and (DataMgr.corpsInfo and DataMgr.corpsInfo.id) ~= 0 then
      else
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
        U1(240, 85, 178, 87, 24, 230, 214)
      }))).IsInXMission() or not GameStatus.IsInLobbyOrMainCity() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRoomChangeTips"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SeClubChatTips"] = function(_ARG_0_)
    do
      _ARG_0_:SetCommonTips(LocUtil.GetLocalizeResStr((U1(173, 12, 219, 10, 79))))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetClubRecentMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      if not U1[_ARG_0_.chatMsg.msgType] or not U1[_ARG_0_.chatMsg.msgType].ClubRecentMessageBP then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickClubRecentMessage"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetClubOwnerMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        _ARG_1_.TextBlock_OwnerText:SetText(_ARG_0_.chatMsg.content.ownerText)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickClubOwnerMessage, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickClubOwnerMessage"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetModifyRecruitFilterTips"] = function(_ARG_0_)
    do
      _ARG_0_:SetCommonTips(LocUtil.GetLocalizeResStr(29679))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCorpsNews"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ENV[_ARG_0_.chatMsg.msgType] and _ENV[_ARG_0_.chatMsg.msgType].CorpsNewsBP then
        if _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.extra and _ARG_0_.chatMsg.content.extra.source == U1(237, 94, 153, 79, 11, 225, 209, 72, 32, 119, 186, 215, 139, 163, 79, 158, 31, 110, 252, 97) then
          if U2.LocUtil.LocalizeResFormat(_ARG_0_.chatMsg.content.extra.loc_id, _ARG_0_.chatMsg.content.extra.nick_name) and U2.LocUtil.LocalizeResFormat(_ARG_0_.chatMsg.content.extra.loc_id, _ARG_0_.chatMsg.content.extra.nick_name) ~= U1() then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetOpenBlack"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content) or not _ARG_0_.chatMsg.content.chatMsg then
        return
      end
      if _ARG_0_.chatMsg.content.chatMsg < 47630 or _ARG_0_.chatMsg.content.chatMsg > 47635 then
        return
      end
      if _ENV[_ARG_0_.chatMsg.msgType] and _ENV[_ARG_0_.chatMsg.msgType].OpenBlackNewsBP then
        if U1.tonumber(_ARG_0_.chatMsg.uid) == U1.tonumber(U1.DataMgr.roleData.uid) then
        else
        end
        if _ARG_0_.chatMsg.content.chatMsg >= U2.OpenBlackChatConfig.OpenBlackChatFirstIDList and _ARG_0_.chatMsg.content.chatMsg <= U2.OpenBlackChatConfig.OpenBlackChatLastIDList then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoRelationship"] = function(_ARG_0_)
    do
      if not (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content) or not _ARG_0_.chatMsg.content.chatMsg then
        return
      end
      if _ARG_0_.chatMsg.content.chatMsg < OpenBlackChatConfig.OpenBlackChatFirstIDList or _ARG_0_.chatMsg.content.chatMsg > OpenBlackChatConfig.OpenBlackChatLastIDList then
        return
      end
      _ARG_0_:PlayAudio(U1.sound_config.click_v1)
      if U1.require((U1.table.concat({
        U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
        U2(240, 85, 178, 87, 24, 230, 214)
      }))).IsInXMission() then
        return
      end
      if U1.require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 109, 146, 27, 126, 210, 119, 254, 221))).IsSocialIslandMode() then
        return
      end
      if U1.RoomSystem.IsShowWaiting() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFriendRecruit"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHyperLinkClicked"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReleaseItem"] = function(_ARG_0_)
    do
      _ARG_0_:ClearCardFrame()
      _ARG_0_:ReleaseVoiceItemAnim()
      _ARG_0_:ResetReportMsgBtnShow()
      _ARG_0_:ReleaseAchievementMsg()
      _ARG_0_.lastAnanimateMsgLevel = -1
      _ARG_0_.animPlayFlag = false
      if _ARG_0_.Chat_HouseKeeper_Item_UIBP then
        _ARG_0_.Chat_HouseKeeper_Item_UIBP:RemoveOnAnimationFinishedEvent((_ENV(222, 85, 132, 87, 38, 221, 221, 86, 43, 81, 178, 204, 152)))
        _ARG_0_.Chat_HouseKeeper_Item_UIBP.UIRoot:StopAnimation(_ARG_0_.Chat_HouseKeeper_Item_UIBP.UIRoot.Anim_Replying)
        _ARG_0_.Chat_HouseKeeper_Item_UIBP:Close()
        _ARG_0_.Chat_HouseKeeper_Item_UIBP = nil
      end
      goto lbl_53
      if 85 then
        _ARG_0_.itemUIBasse[222] = nil
      end
      ::lbl_53::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetReportMsgBtnShow"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_reportTip then
        _ARG_0_._cObj_reportTip:Close()
        _ARG_0_._cObj_reportTip = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReleaseVoiceItemAnim"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 122, 50, 89, 184, 215, 185, 179, 105, 158, 26, 82, 249, 127, 244, 238, 182, 111),
        U1(242)
      }))
      if _ARG_0_.lastAnanimateMsg then
        if _ARG_0_.lastAnanimateMsg.self_voice_anim then
          _ARG_0_.lastAnanimateMsg.self_voice_anim:StopAnimation(_ARG_0_.lastAnanimateMsg.self_voice_anim.Bugle)
        end
        if _ARG_0_.lastAnanimateMsg.other_voice_anim then
          _ARG_0_.lastAnanimateMsg.other_voice_anim:StopAnimation(_ARG_0_.lastAnanimateMsg.other_voice_anim.Bugle)
        end
      end
      _ARG_0_.lastAnanimateMsg = nil
      if _ARG_0_.socialCardMsg and _ARG_0_.socialCardMsg.loop then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 122, 50, 89, 184, 215, 185, 179, 105, 158, 26, 82, 249, 127, 244, 238, 182, 111),
          U1(242, 27, 158, 78, 22, 255, 152, 85, 40, 75, 178, 195, 147, 175, 113, 159, 11, 43, 252, 100, 224, 210)
        }))
        _ARG_0_.socialCardMsg:StopAnimation(_ARG_0_.socialCardMsg.loop)
      end
      _ARG_0_.socialCardMsg = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTimeMsg"] = function(_ARG_0_)
    do
      printf(table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 3, 81, 166, 215, 162, 175, 103, 221, 12, 126, 225, 124, 183, 204, 176, 103),
        U1(235, 118, 158, 93, 87, 226, 203, 65, 20, 77, 181, 198, 171, 165, 125, 136, 79, 54, 189, 47, 250)
      }), _ARG_0_.chatMsg.msgSendTime)
      if _ARG_0_.chatMsg.msgSendTime and _ARG_0_.chatMsg.msgSendTime ~= U1() then
        if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).FormatTime_YMD(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec(), true) == _ARG_0_.chatMsg.msgSendDate then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[182]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetVoiceMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_1_ then
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_1_.self_chat_voice_time:SetText(_ARG_0_.chatMsg.voiceMsgTime .. _ENV(189))
          _ARG_1_.self_voice_anim:StopAnimation(_ARG_1_.self_voice_anim.Bugle)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_1, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickPlayRecord, _ARG_0_)
        else
          _ARG_1_.other_voice_anim:StopAnimation(_ARG_1_.other_voice_anim.Bugle)
          _ARG_1_.chat_voice_time:SetText(_ARG_0_.chatMsg.voiceMsgTime .. _ENV(189))
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_2, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickPlayRecord, _ARG_0_)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_2, _ENV(208, 85, 189, 72, 28, 252, 203, 67, 35), _ARG_0_.OnPressed, _ARG_0_)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_2, _ENV(208, 85, 191, 95, 21, 234, 217, 85, 34, 76), _ARG_0_.OnReleased, _ARG_0_)
        end
      end
      if _ARG_2_ then
        _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNomalMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_1_ then
        _ARG_0_:_SetCommonMsg(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
        _ARG_0_:_SetCommonMsgFrame(_ARG_1_)
        if _ARG_1_.Button_translate_friend then
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_translate_friend, _ENV(208, 85, 189, 72, 28, 252, 203, 67, 35), _ARG_0_.OnPressed, _ARG_0_)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_translate_friend, _ENV(208, 85, 191, 95, 21, 234, 217, 85, 34, 76), _ARG_0_.OnReleased, _ARG_0_)
        end
        if _ARG_1_.Button_ClickLink and U1.UIManager.IsUIShow(U1.UIManager.UI_Config.CorpsHomepageNewUI2) then
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_ClickLink, _ENV(208, 85, 189, 72, 28, 252, 203, 67, 35), _ARG_0_.OnPressed, _ARG_0_)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_ClickLink, _ENV(208, 85, 191, 95, 21, 234, 217, 85, 34, 76), _ARG_0_.OnReleased, _ARG_0_)
        end
      end
      if _ARG_2_ then
        _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPandoraInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedPandoraInviteMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.pandora_common_protocol):ParseJumpUrl(_ARG_0_.chatMsg.msg, _ARG_0_.chatMsg.content.other) or ModuleManager.GetModule(ModuleManager.CommonModuleConfig.pandora_common_protocol):ParseJumpUrl(_ARG_0_.chatMsg.msg, _ARG_0_.chatMsg.content.other) == U1() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetTextBlockDefaultColor"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetTextBlockColor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_2_ then
        return
      end
      if _ARG_2_.SetColorAndOpacity and _ARG_1_ then
        _ARG_2_:SetColorAndOpacity(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChannelColorTypeForNickname"] = function(_ARG_0_, _ARG_1_)
    do
      log_format(table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 248, 173, 98, 20, 80, 170, 220, 129, 185, 108, 190, 16, 119, 226, 104, 205, 214, 168, 99),
        U1(217, 84, 159, 116, 16, 236, 211, 104, 38, 69, 190, 130, 218, 191)
      }), _ARG_1_)
      if _ARG_1_ == U2.Channel.channelChatRoom then
      end
      do return ENUM_NAME_COLOR_UI_TYPE.ChatRoom end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetCommonMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if _ARG_1_ then
        if _ARG_0_.chatMsg.selfMsg and _ARG_0_.chatMsg.msg then
          if _ARG_1_.self_friend_chat_item_content then
            _ARG_1_.self_friend_chat_item_content:SetText(_ARG_0_.chatMsg.msg)
            _ARG_0_:_SetTextBlockDefaultColor(_ARG_1_.self_friend_chat_item_content)
            if _ARG_6_ then
              _ARG_1_.self_friend_chat_item_content:SetText((_ENV(181, 17, 199, 16)))
            end
          end
        else
          if _ARG_1_.friend_chat_item_content then
            _ARG_1_.friend_chat_item_content:SetText(_ARG_0_.chatMsg.msg)
            _ARG_0_:_SetTextBlockDefaultColor(_ARG_1_.friend_chat_item_content)
          end
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_translate_friend, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickTranslateCallback, _ARG_0_)
          if _ARG_1_.friend_trans_from then
            if _ARG_0_.chatMsg.isTranslate then
              _ARG_1_.friend_trans_from:SetText(_ARG_0_.chatMsg.languageFrom)
            else
              _ARG_1_.friend_trans_from:SetText(U1.LocUtil.LocalizeResFormat((_ENV(174, 9, 223, 11))))
            end
            _ARG_0_:_SetTextBlockDefaultColor(_ARG_1_.friend_trans_from)
          end
          if not _ARG_0_.chatMsg.translatting then
            _ARG_1_:StopAnimation(_ARG_1_.translate_friend_animation)
          else
            _ARG_1_:PlayUserWidgetAnimation(_ARG_1_.translate_friend_animation, 0, 10, 0, 1)
          end
        end
        _ARG_0_:setChatTxtColor()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetCommonMsgFrame"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 224, 155, 115, 35, 123, 164, 223, 130, 179, 110, 176, 12, 124, 203, 104, 248, 194, 189, 38),
        U1(252, 83, 140, 78, 38, 237, 205, 68, 37, 68, 190, 130, 194, 236)
      }) .. tostring(_ARG_2_))
      if _ARG_1_ then
        _ARG_0_.bubbleBg = false
        if _ARG_1_.translate_friend then
          _ARG_1_.translate_friend:SetColorAndOpacity(FLinearColor(0, 0, 0, 0.7))
        end
        if _ARG_0_.chatFrameItemBP then
          _ARG_0_.chatFrameItemBP:Close()
          _ARG_0_.chatFrameItemBP = nil
        end
        _ARG_1_.WidgetSwitcher_Effect:SetActiveWidgetIndex(0)
        if _ARG_0_.chatMsg.selfMsg then
        elseif _ARG_2_ and (_ARG_0_.chatMsg.msgChannel == U2.Channel.channelSocialIslandChat or _ARG_0_.chatMsg.msgChannel == U2.Channel.channelCurrentMainCity) then
        else
        end
        if not _ARG_0_.chatMsg.content.chat_bubble or _ARG_0_.chatMsg.content.chat_bubble == 61400001 then
          if _ARG_0_:checkShouldUseThanksBubble() then
          else
            return
          end
        end
        if not CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()) then
          return
        end
        if CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).BPPath == U1() then
          return
        end
        if U3.IsFITVersion() then
          if require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
            U1(192, 86, 140, 84, 24, 232, 221, 84)
          }))).GetState(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPAK, {
            CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).BPPath
          }) ~= require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadState.Done then
            if _ARG_0_._cObj_msgUIBase then
              _ARG_0_.chatFrameItemBP = _ARG_0_._cObj_msgUIBase:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Effect, UIManager.UI_Config.Lobby_RoleInfo_Chat_Message_Effect_Item_UIBP, (table.concat({
                U1(176, 124, 140, 87, 28, 160, 245, 73, 35, 7, 151, 205, 157, 174, 105, 194, 45, 106, 238, 111, 166, 237, 167, 122, 50, 113, 165, 212, 128, 243, 73, 137, 26, 118, 162, 86, 246, 205, 186, 127),
                U1(192, 105, 130, 86, 28, 198, 214, 64, 40, 119, 152, 202, 158, 184, 79, 160, 10, 120, 238, 107, 238, 218, 151, 83, 49, 94, 174, 209, 155, 131, 77, 148, 17, 114, 224, 123, 245, 198, 171, 114),
                U1(192, 110, 164, 120, 41, 161, 244, 73, 37, 74, 162, 253, 173, 163, 124, 136, 38, 101, 251, 101, 214, 252, 160, 119, 35, 103, 134, 215, 156, 175, 97, 154, 26, 68, 200, 124, 255, 202, 187, 114),
                U1(192, 118, 132, 84, 16, 226, 217, 74, 46, 91, 175, 253, 170, 133, 82, 189)
              })))
            end
            return
          end
        elseif require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
          U1(192, 86, 140, 84, 24, 232, 221, 84)
        }))).GetState(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPAK, {
          CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).BPPath
        }) ~= require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadState.Done then
          if _ARG_0_._cObj_msgUIBase then
            _ARG_0_.chatFrameItemBP = _ARG_0_._cObj_msgUIBase:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Effect, UIManager.UI_Config.Lobby_RoleInfo_Chat_Message_Effect_Item_UIBP, (table.concat({
              U1(176, 124, 140, 87, 28, 160, 245, 73, 35, 7, 151, 205, 157, 174, 105, 194, 45, 106, 238, 111, 166, 237, 167, 122, 50, 113, 165, 212, 128, 243, 73, 137, 26, 118, 162, 86, 246, 205, 186, 127),
              U1(192, 105, 130, 86, 28, 198, 214, 64, 40, 119, 152, 202, 158, 184, 79, 160, 10, 120, 238, 107, 238, 218, 151, 83, 49, 94, 174, 209, 155, 131, 77, 148, 17, 114, 224, 123, 245, 198, 171, 114),
              U1(192, 110, 164, 120, 41, 161, 244, 73, 37, 74, 162, 253, 173, 163, 124, 136, 38, 101, 251, 101, 214, 252, 160, 119, 35, 103, 134, 215, 156, 175, 97, 154, 26, 68, 200, 124, 255, 202, 187, 114),
              U1(192, 118, 132, 84, 16, 226, 217, 74, 46, 91, 175, 253, 170, 133, 82, 189)
            })))
          end
          return
        end
        if _ARG_0_._cObj_msgUIBase then
          _ARG_0_.chatFrameItemBP = _ARG_0_._cObj_msgUIBase:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Effect, UIManager.UI_Config.Lobby_RoleInfo_Chat_Message_Effect_Item_UIBP, CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).BPPath)
        end
        if not _ARG_0_.chatFrameItemBP then
          _ARG_0_.bubbleBg = false
          return
        end
        if _ARG_0_.chatFrameItemBP and _ARG_0_.chatFrameItemBP.UIRoot and _ARG_0_.chatFrameItemBP.UIRoot.Fadein and _ARG_0_.chatMsg.new then
          _ARG_0_.chatMsg.new = false
        else
        end
        if CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).MirrorText then
          if _ARG_0_.chatMsg.selfMsg then
          else
          end
          if _ARG_0_.chatFrameItemBP and _ARG_0_.chatFrameItemBP.UIRoot and _ARG_0_.chatFrameItemBP.UIRoot.Vx_Image_Wz_1 then
            _ARG_0_.chatFrameItemBP.UIRoot.Vx_Image_Wz_1.RenderTransform.Scale = FVector2D(1, 1)
          end
          if _ARG_0_.chatFrameItemBP and _ARG_0_.chatFrameItemBP.UIRoot and _ARG_0_.chatFrameItemBP.UIRoot.Vx_Image_Wz_Light then
            _ARG_0_.chatFrameItemBP.UIRoot.Vx_Image_Wz_Light.RenderTransform.Scale = FVector2D(1, 1)
          end
        end
        _ARG_0_.bIsLightBubble = CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).IsLightBubble and CDataTable.GetTableData(U1(220, 83, 140, 78, 60, 233, 222, 67, 36, 92, 152, 196, 152), _ARG_0_:checkShouldUseThanksBubble()).IsLightBubble == 1 or false
        _ARG_0_.bubbleBg = true
      else
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 224, 155, 115, 35, 123, 164, 223, 130, 179, 110, 176, 12, 124, 203, 104, 248, 194, 189, 38),
          U1(241, 84, 153, 26, 20, 252, 223, 68, 55)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = U1[234]
    end
  end,
  ["SetHornMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_1_ then
        if _ARG_0_.chatMsg.selfMsg then
          if _ARG_1_.self_friend_chat_item_content then
          end
        else
          if _ARG_0_.chatMsg.isTranslate then
          else
          end
          if not _ARG_0_.chatMsg.translatting then
          else
          end
        end
      end
      if _ARG_2_ then
        _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["filterMsg"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.msgType == hornMsgType or _ARG_0_.chatMsg.msgType == giftFreeHornMsgType then
        return U1.string.format(U2(186, 72, 200, 73), U3.hornMsgPrefix, _ARG_0_.chatMsg.msg)
      end
      do return _ARG_0_.chatMsg.msg end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetHeadBpBase"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.chatMsg.selfMsg and (_ARG_0_.chatMsg.msgChannel == U1.Channel.channelSocialIslandChat or _ARG_0_.chatMsg.msgChannel == U1.Channel.channelPrivate or _ARG_0_.chatMsg.msgType == U1.ClubOwnerMsgType or _ARG_0_.chatMsg.msgType == U1.ManorGiftMsgType or _ARG_0_.chatMsg.msgChannel == U1.Channel.channelCurrentManor or _ARG_0_.chatMsg.msgChannel == U1.Channel.channelCurPlanCH or _ARG_0_.chatMsg.msgChannel == U1.Channel.channelCurrentMainCity) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.chatMsg.sender_uid) then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAchivementMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_1_ then
        return
      end
      _ARG_0_:SetNomalMsg(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
      if _ARG_1_.self_friend_chat_item_content then
        _ARG_1_.self_friend_chat_item_content:SetText(_ARG_0_.chatMsg.msg)
      end
      if not _ARG_0_._cObj_achievementMsg then
        _ARG_0_._cObj_achievementMsg = _ARG_4_:CreateChildWindow(_ARG_1_.CanvasPanel_Achievement, UIManager.UI_Config.ChatMessage_Achievement_UIBP, _ARG_0_.chatMsg), _ARG_4_:CreateChildWindow(_ARG_1_.CanvasPanel_Achievement, UIManager.UI_Config.ChatMessage_Achievement_UIBP, _ARG_0_.chatMsg):SetAutoSize(true)
      end
      if not _ARG_4_:CreateChildWindow(_ARG_1_.CanvasPanel_Achievement, UIManager.UI_Config.ChatMessage_Achievement_UIBP, _ARG_0_.chatMsg) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReleaseAchievementMsg"] = function(_ARG_0_)
    do
      if _ARG_0_._cObj_achievementMsg then
        _ARG_0_._cObj_achievementMsg:Close()
        _ARG_0_._cObj_achievementMsg = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideAchievementCanvasPanel"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_1_.CanvasPanel_Achievement then
        _ARG_0_:SetWidgetVisible(_ARG_1_.CanvasPanel_Achievement, false)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTeamRecruitMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
          U1(240, 85, 178, 87, 24, 230, 214)
        }))).IsInXMission(false) then
        else
        end
        if _ARG_0_.chatMsg.msgType == U2.roomRecruitMsgType then
        end
        if #require((U1(252, 84, 128, 87, 22, 225, 150, 85, 51, 90, 178, 204, 152, 147, 101, 153, 6, 103))).Split(_ARG_0_.chatMsg.msg, (U1(227))) > 4 then
        end
        if 6 < #require((U1(252, 84, 128, 87, 22, 225, 150, 85, 51, 90, 178, 204, 152, 147, 101, 153, 6, 103))).Split(_ARG_0_.chatMsg.msg, (U1(227))) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRoomTeamRecruitMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      if #require((U1(252, 84, 128, 87, 22, 225, 150, 85, 51, 90, 178, 204, 152, 147, 101, 153, 6, 103))).Split(_ARG_0_.chatMsg.msg, (U1(227))) > 4 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRecruitModelStyle"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_) then
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_).team_recruit_arrow or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_).team_recruit_arrow == _ENV() then
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_).team_recruit_bg or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_).team_recruit_bg == _ENV() then
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_).team_recruit_icon or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_).team_recruit_icon == _ENV() then
      end
      if _ARG_0_.chatMsg.selfMsg then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRecruitTask"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.chatMsg.taskId then
        _ARG_1_.WidgetSwitcher_1:SetActiveWidgetIndex(1)
      else
        _ARG_1_.WidgetSwitcher_1:SetActiveWidgetIndex(0)
        if require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 140, 10, 114, 238, 113, 198, 219, 189, 103),
          U1(242, 100, 152, 74)
        }))).GetMissionInfo(_ARG_0_.chatMsg.isRp, _ARG_0_.chatMsg.taskId).isToyShare then
        elseif require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 140, 10, 114, 238, 113, 198, 219, 189, 103),
          U1(242, 100, 152, 74)
        }))).GetMissionInfo(_ARG_0_.chatMsg.isRp, _ARG_0_.chatMsg.taskId).isRPAdd then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRecruitPingText"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.chatMsg.zoneText then
        _ARG_1_.self_zone_textNew:SetText(_ARG_0_.chatMsg.zoneText)
      end
      if _ARG_0_.chatMsg.zoneIp then
        if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 122, 146, 17, 126, 210, 126, 252, 195, 185, 127))).GetZoneDelay(_ARG_0_.chatMsg.zoneId, 10000, 10000) > 3000 or require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 122, 146, 17, 126, 210, 126, 252, 195, 185, 127))).GetZoneDelay(_ARG_0_.chatMsg.zoneId, 10000, 10000) < 0 then
        else
        end
        if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 122, 146, 17, 126, 210, 126, 252, 195, 185, 127))).GetZoneDelay(_ARG_0_.chatMsg.zoneId, 10000, 10000) >= 0 and require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 122, 146, 17, 126, 210, 126, 252, 195, 185, 127))).GetZoneDelay(_ARG_0_.chatMsg.zoneId, 10000, 10000) < 200 then
        elseif require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 122, 146, 17, 126, 210, 126, 252, 195, 185, 127))).GetZoneDelay(_ARG_0_.chatMsg.zoneId, 10000, 10000) >= 200 and require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 122, 146, 17, 126, 210, 126, 252, 195, 185, 127))).GetZoneDelay(_ARG_0_.chatMsg.zoneId, 10000, 10000) < 500 then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCShareRoomMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.content.other.url then
            if _ARG_0_.chatMsg.content.other.url == U2() then
              if require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).GetTemplateConfigByID(_ARG_0_.chatMsg.content.other.templateId) then
              end
            else
            end
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCPlayHallRoomMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if _ARG_0_.chatMsg.content.mod_info then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPlayHallRoom"] = function(_ARG_0_)
    do
      print(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 191, 176, 97, 132, 55, 122, 225, 118, 203, 192, 183, 107))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
        U1(240, 85, 178, 87, 24, 230, 214)
      }))).IsInXMission() then
        return
      end
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.mod_info.mod_id)) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.mod_info.mod_id)).pub_mod_meta then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):IsCompleteRes(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloaderType.ModCopy, {
        setting = _ARG_0_.chatMsg.content.mod_info.setting,
        base = {
          template_id = _ARG_0_.chatMsg.content.mod_info.template_id
        },
        mod_id = _ARG_0_.chatMsg.content.mod_info.mod_id
      }) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide({
        setting = _ARG_0_.chatMsg.content.mod_info.setting,
        base = {
          template_id = _ARG_0_.chatMsg.content.mod_info.template_id
        },
        mod_id = _ARG_0_.chatMsg.content.mod_info.mod_id
      }) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[162]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPlayHallModInfo"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
        U1(240, 85, 178, 87, 24, 230, 214)
      }))).IsInXMission() then
        return
      end
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.mod_info.mod_id)) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.mod_info.mod_id)).pub_mod_meta then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide({
        setting = _ARG_0_.chatMsg.content.mod_info.setting,
        base = {
          template_id = _ARG_0_.chatMsg.content.mod_info.template_id
        },
        mod_id = _ARG_0_.chatMsg.content.mod_info.mod_id
      }) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTeamPlatFormRecruitMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if U1.require((U1.table.concat({
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 104, 252, 204, 170, 115),
        _ENV(246, 79)
      }))).IsTPlanRecruitMsg(_ARG_0_.chatMsg.content) then
      elseif (_ARG_0_.chatMsg.content.perspective or 0) ~= U1.ENUM_PerspectiveType.FPP and (_ARG_0_.chatMsg.content.perspective or 0) ~= U1.ENUM_PerspectiveType.TPP then
      else
      end
      if _ARG_0_.chatMsg.content.taskId and _ARG_0_.chatMsg.content.taskId ~= 0 then
      else
      end
      if (_ARG_0_.chatMsg.content.team_size or 0) < (_ARG_0_.chatMsg.content.player_count or 0) and (_ARG_0_.chatMsg.content.player_count or 0) <= 4 then
      end
      if (_ARG_0_.chatMsg.content.from == U1.require((U1.table.concat({
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 76, 174, 211, 130, 172, 108, 156, 11, 125, 226, 104, 244, 240, 181, 103),
        _ENV(252, 73, 130)
      }))).Enum_PublishRecruitMsgFromType.WoWTeamPlatForm or _ARG_0_.chatMsg.content.from == U1.require((U1.table.concat({
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 76, 174, 211, 130, 172, 108, 156, 11, 125, 226, 104, 244, 240, 181, 103),
        _ENV(252, 73, 130)
      }))).Enum_PublishRecruitMsgFromType.WoWChat or _ARG_0_.chatMsg.content.from == U1.require((U1.table.concat({
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 76, 174, 211, 130, 172, 108, 156, 11, 125, 226, 104, 244, 240, 181, 103),
        _ENV(252, 73, 130)
      }))).Enum_PublishRecruitMsgFromType.LobbyEntrance) and _ARG_0_.chatMsg.content.view == 20002 then
        _ARG_0_.TeamPlatform_MapItem_UIBP = _ARG_1_.TeamPlatform_MapItem_UIBP
        if not _ARG_0_.chatMsg.content.wow_cli_trans then
          return
        end
        if _ARG_0_.chatMsg.content.wow_cli_trans.mod_id and 0 < _ARG_0_.chatMsg.content.wow_cli_trans.mod_id then
        elseif _ARG_0_.chatMsg.content.wow_cli_trans.mod_collection_id then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitName"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_.TextBlock_SelfMap:SetText(_ARG_2_ or _ENV())
      _ARG_0_.TeamPlatform_MapItem_UIBP.TextBlock_0:SetText(_ARG_2_)
      U1.log(U1.bWriteLog and _ENV(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 246, 166, 127, 35, 118, 170, 223, 138, 252, 110, 156, 18, 126, 173) .. _ARG_2_)
      _ARG_0_.TeamPlatform_MapItem_UIBP.TextBlock_Tag:SetText((_ENV()))
      _ARG_0_.TeamPlatform_MapItem_UIBP.UTRichTextBlock_AuthorName:SetText((_ENV()))
      _ARG_0_:SetWidgetVisible(_ARG_0_.TeamPlatform_MapItem_UIBP.CanvasPanel_Quantity, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.TeamPlatform_MapItem_UIBP.Image_6, false)
      _ARG_0_:SetWidgetVisible(_ARG_0_.TeamPlatform_MapItem_UIBP.UTRichTextBlock_AuthorName, false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRecruitTeamMod"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 189, 185, 99, 143, 10, 114, 249, 78, 252, 206, 181, 75),
        U1(240, 95)
      }))
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
        U1(240, 85, 178, 87, 24, 230, 214)
      }))).IsInXMission() then
        return
      end
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.wow_cli_trans.mod_id)) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.wow_cli_trans.mod_id)).pub_mod_meta then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(tonumber(_ARG_0_.chatMsg.content.wow_cli_trans.mod_id)).pub_mod_meta) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickRecruitTeamCollection"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 189, 185, 99, 143, 10, 114, 249, 78, 252, 206, 181, 69),
        U1(240, 87, 129, 95, 26, 251, 209, 73, 41)
      }))
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
        U1(240, 85, 178, 87, 24, 230, 214)
      }))).IsInXMission() then
        return
      end
      if not GameStatus.IsInLobbyOrMainCity() then
        return
      end
      if UIManager and UIManager.UI_Config.UGCCollectionListDetailsPanelUI then
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCollectionList):GetCollectionInfo(_ARG_0_.chatMsg.content.wow_cli_trans.mod_collection_id) then
          if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCollectionList):IsInvalidCollection(_ARG_0_.chatMsg.content.wow_cli_trans.mod_collection_id) then
          else
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshCollection"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 224, 154, 115, 49, 74, 174, 193, 135, 159, 111, 145, 19, 126, 238, 110, 240, 192, 182))
      if _ARG_0_.chatMsg.content.wow_cli_trans.mod_collection_id ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCollectionList):GetCurSelectCollectionID() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCollectionList):GetCollectionInfo(_ARG_0_.chatMsg.content.wow_cli_trans.mod_collection_id) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRecruitImageIconPath"] = function(_ARG_0_, _ARG_1_)
    do
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 104, 252, 204, 170, 115),
        U1(246, 79)
      }))).IsTPlanRecruitMsg(_ARG_1_) then
        return U2.tPlan
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_.view) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_.view).is_ranked then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_.view).is_ranked == 1 then
          return U2.rank
        end
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_.view).id == 20002 then
          return U2.wow
        elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_.view).id == 90112 then
          return U2.asymmertric
        elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):IsPeakGameViewID(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetSubviewInfoBySubviewID(_ARG_1_.view).id) then
          return U2.peak
        end
        return U2.other
      end
      do return U2.default end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickJoinRecruitTeam"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).GetPlayerType() == require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).EPlayerType.Low_Priority_Player and not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).CheckLowPriorityPlayer(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).EAccessType.TeamRecruit) then
        return
      end
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).CheckAccessAndPopTips(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).EAccessType.TeamRecruit) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEnterTeam"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).GetPlayerType() == require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).EPlayerType.Low_Priority_Player and not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).CheckLowPriorityPlayer(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).EAccessType.TeamRecruit) then
        return
      end
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).CheckAccessAndPopTips(require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 175, 127, 128, 2, 100, 243, 36, 229, 208, 175, 127, 52, 103, 170, 209, 140, 185, 115, 142, 32, 105, 232, 105, 237, 221, 177, 101),
        U1(235, 82, 130, 84)
      }))).EAccessType.TeamRecruit) then
        return
      end
      if U2.currentChannel == U3.Channel.channelChatRoom then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnNotifyReqModInfoSuccess"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_)
    do
      if not require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 189, 113, 52, 103, 166, 211, 140, 174, 111, 142))).CheckMetaType(_ARG_3_, require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 189, 113, 52, 103, 166, 211, 140, 174, 111, 142))).ENUM_MODE_TYPE.UgcChatRoom) then
        return
      end
      if U2.roomRecruitMsgType == _ARG_0_.chatMsg.msgType and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.ugc_room_param and _ARG_0_.chatMsg.content.ugc_room_param.mod_id and _ARG_0_.chatMsg.content.ugc_room_param.mod_id > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckVoiceMsgType"] = function(_ARG_0_, _ARG_1_)
    do
      if (_ARG_1_ or _ARG_0_.chatMsg).voiceMsgId and (_ARG_1_ or _ARG_0_.chatMsg).voiceMsgId ~= _ENV() then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckReportVoiceMsgType"] = function(_ARG_0_, _ARG_1_)
    do
      if (_ARG_1_ or _ARG_0_.chatMsg).voiceMsgId and (_ARG_1_ or _ARG_0_.chatMsg).voiceMsgId ~= _ENV() then
        return true
      end
      if (_ARG_1_ or _ARG_0_.chatMsg).content and (_ARG_1_ or _ARG_0_.chatMsg).content.social_card and U1.next((_ARG_1_ or _ARG_0_.chatMsg).content.social_card) and (_ARG_1_ or _ARG_0_.chatMsg).content.social_card.voice_card and U1.next((_ARG_1_ or _ARG_0_.chatMsg).content.social_card.voice_card) and (_ARG_1_ or _ARG_0_.chatMsg).content.social_card.voice_card.fileid and (_ARG_1_ or _ARG_0_.chatMsg).content.social_card.voice_card.length and not U1.require((U1.table.concat({
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 105, 246, 204, 177, 103),
        _ENV(243, 100, 142, 91, 11, 235)
      }))).CheckBlockNewData() and U1.require((U1.table.concat({
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 56, 27, 93, 173, 198, 193, 176, 111, 154, 22, 120, 210, 105, 246, 204, 177, 103),
        _ENV(243, 100, 142, 91, 11, 235)
      }))).GetSocialCardMainSwitch() then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClose"] = function(_ARG_0_)
    do
      _ARG_0_:ResetReportMsgBtnShow()
      _ARG_0_:ClearCardFrame()
      _ARG_0_.FrameAnimPlayed = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFlashSquadHighlightMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_1_ then
        return
      end
      if not _ARG_0_.chatMsg.content then
        return
      end
      if _ARG_0_.chatMsg.content.highlight_type == 1 then
        if _ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_data.segment_id then
          goto lbl_144
          if tostring(_ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_data.segment_id).IntegralTypeNew == _ARG_0_.chatMsg.content.highlight_data.segment_id then
          else
            ::lbl_144::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end
        if tostring(_ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_data.segment_id) then
          if 10 <= tostring(_ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_data.segment_id).IntegralTypeNew then
          elseif tostring(_ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_data.segment_id).IntegralTypeNew >= 7 then
          else
          end
        end
        if _ARG_0_.chatMsg.content.highlight_like_enable and _ARG_0_.chatMsg.content.highlight_like_pending then
        else
        end
      elseif _ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_type == 2 then
        if CDataTable.GetTableData(U1(222, 87, 132, 91, 10, 204, 222, 65), _ARG_0_.chatMsg.content.highlight_data.alias_id) then
          if CDataTable.GetTableData(U1(222, 87, 132, 91, 10, 204, 222, 65), _ARG_0_.chatMsg.content.highlight_data.alias_id).AliasQuality == 4 then
          elseif CDataTable.GetTableData(U1(222, 87, 132, 91, 10, 204, 222, 65), _ARG_0_.chatMsg.content.highlight_data.alias_id).AliasQuality == 5 or CDataTable.GetTableData(U1(222, 87, 132, 91, 10, 204, 222, 65), _ARG_0_.chatMsg.content.highlight_data.alias_id).AliasQuality == 6 then
          end
        end
      elseif _ARG_0_.chatMsg.content.highlight_data and _ARG_0_.chatMsg.content.highlight_type == 3 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetFlashSquadHighlightEmojiSelect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_.LoopScrollBox_1 then
      else
        _ARG_2_.LoopScrollBox_1 = _ARG_2_:InitChildClassScrollBox(_ARG_1_.LoopScrollBox_1, (table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 219, 155, 185, 109, 211, 60, 115, 236, 110, 220, 194, 183, 108),
          U1(246, 104, 128, 91, 21, 227, 231, 100, 23)
        })))
      end
      goto lbl_119
      ::lbl_119::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetFlashSquadHighlightEmojiLiked"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if (_ARG_0_.chatMsg.content.highlight_like_count or 0) == 0 then
      else
      end
      if _ARG_0_.chatMsg.content.lastLikeUid then
      else
      end
      if _ARG_2_.LoopScrollBox_0 then
      else
        _ARG_2_.LoopScrollBox_0 = _ARG_2_:InitChildClassScrollBox(_ARG_1_.LoopScrollBox_0, (U1.table.concat({
          _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 219, 155, 185, 109, 211, 60, 115, 236, 110, 220, 194, 183, 108),
          _ENV(246, 121, 132, 93, 38, 205, 232)
        })))
      end
      goto lbl_277
      if U1.CDataTable.GetTableData(_ENV(217, 87, 140, 73, 17, 220, 201, 83, 38, 76, 152, 202, 158, 184, 85, 128, 0, 97, 244, 71, 232, 207), {
        _ENV(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 138, 161, 119, 195, 3, 100, 255, 104, 240, 224, 171, 126, 54, 76, 229, 219, 155, 185, 109, 211, 60, 115, 236, 110, 220, 194, 183, 108),
        _ENV(246, 121, 132, 93, 38, 205, 232)
      }) then
      end
      ::lbl_277::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshFlashSquadHighlightLikePanel"] = function(_ARG_0_)
    do
      if not (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content).highlight_type == 1 and _ARG_0_.msgbp) or not _ARG_0_._cObj_msgUIBase then
        return false
      end
      if (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content).highlight_like_enable and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content).highlight_like_pending then
      else
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTargetShareMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_1_.VerticalBox_8:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
        _ARG_1_.CanvasPanel_3:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        if _ARG_0_.chatMsg.selfMsg then
        else
        end
        if _ARG_0_.chatMsg.content.other.score >= U2.Target_Shooting_Calculate_Star_Score then
        end
        if require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 201, 114, 196, 214, 187, 101, 62, 87, 165, 156, 131, 179, 103, 148, 28, 68, 245, 119, 240, 220, 171, 111),
          U1(240, 85, 178, 87, 24, 230, 214)
        }))).IsInXMission(false) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickShareMsg"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if not U2.IsValid() then
        return
      end
      if not U2.IsSubsideValid() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBattleShareMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBattleShareMsg, _ARG_0_)
        _ARG_1_.VerticalBox_8:SetWidgetVisibility(U1.UEnums.ESlateVisibility.Collapsed)
        _ARG_1_.CanvasPanel_3:SetWidgetVisibility(U1.UEnums.ESlateVisibility.SelfHitTestInvisible)
        if _ARG_0_.chatMsg.content.other.isWin then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBattleShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        return
      end
      if not U1.IsSubsideValid() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSeasonLookbackMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 4, 93, 170, 193, 128, 178, 76, 146, 16, 112, 239, 123, 250, 196, 149, 117),
        U1(248)
      }))
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 4, 93, 170, 193, 128, 178, 76, 146, 16, 112, 239, 123, 250, 196, 149, 117),
          U1(248, 27, 220)
        }))
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        end
        _ARG_1_.TextBlock_Desc:SetText(LocUtil.GetLocalizeResStr(512139))
        _ARG_1_.TextBlock_Go:SetText(LocUtil.GetLocalizeResStr(512156))
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickSeasonLookback, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckPassBuyAct"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPassBuyActMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        _ARG_0_:SetWidgetVisible(_ARG_1_.SizeBox_Group, true)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBuyActShareMsg, _ARG_0_)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_Group, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBuyActShareMsg, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBuyActShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        return
      end
      if require((table.concat({
        U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 100, 226, 209, 167, 97, 8, 72, 170, 193, 156, 242, 108, 146, 24, 114, 238, 69, 236, 193, 179, 104),
        U2(240, 76, 157, 91, 10, 252, 231, 68, 50, 81, 132, 195, 156, 184)
      }))).GetPlayerGroupID(DataMgr.roleData.uid) == nil or require((table.concat({
        U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 100, 226, 209, 167, 97, 8, 72, 170, 193, 156, 242, 108, 146, 24, 114, 238, 69, 236, 193, 179, 104),
        U2(240, 76, 157, 91, 10, 252, 231, 68, 50, 81, 132, 195, 156, 184)
      }))).GetPlayerGroupID(DataMgr.roleData.uid) == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBlackFridayGroupActMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBlackFridayGroupActMsg, _ARG_0_)
        if _ARG_0_.chatMsg.content.other.actType == U1.require((U1.table.concat({
          _ENV(216, 90, 128, 95, 53, 250, 217, 8, 10, 71, 191, 140, 179, 163, 114, 143, 22, 37, 223, 107, 250, 218, 230, 84, 59, 89, 168, 217, 169, 174, 105, 153, 30, 98, 163, 86, 246, 200, 177, 101),
          _ENV(177, 121, 129, 91, 26, 228, 254, 84, 46, 76, 186, 219, 178, 173, 115, 159, 0, 120)
        }))).ActivityType.RPGroup then
        elseif _ARG_0_.chatMsg.content.other.actType == U1.require((U1.table.concat({
          _ENV(216, 90, 128, 95, 53, 250, 217, 8, 10, 71, 191, 140, 179, 163, 114, 143, 22, 37, 223, 107, 250, 218, 230, 84, 59, 89, 168, 217, 169, 174, 105, 153, 30, 98, 163, 86, 246, 200, 177, 101),
          _ENV(177, 121, 129, 91, 26, 228, 254, 84, 46, 76, 186, 219, 178, 173, 115, 159, 0, 120)
        }))).ActivityType.Subscribe then
        end
      end
      do return end
      _ARG_2_ = _ENV[114]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBlackFridayGroupActMsg"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.selfMsg then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 173, 176, 97, 158, 20, 93, 255, 115, 253, 206, 161, 65),
          U1(237, 84, 152, 74, 56, 236, 204, 107, 52, 79, 251, 156, 193, 242, 48, 164, 28, 43, 206, 111, 229, 217, 232, 69, 50, 86, 175)
        }))
        return
      end
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U2.IsValid() then
        return
      end
      if _ARG_0_.chatMsg.content.other.actType == require((table.concat({
        U1(216, 90, 128, 95, 53, 250, 217, 8, 10, 71, 191, 140, 179, 163, 114, 143, 22, 37, 223, 107, 250, 218, 230, 84, 59, 89, 168, 217, 169, 174, 105, 153, 30, 98, 163, 86, 246, 200, 177, 101),
        U1(177, 121, 129, 91, 26, 228, 254, 84, 46, 76, 186, 219, 178, 173, 115, 159, 0, 120)
      }))).ActivityType.RPGroup then
        if not require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).CanClickNow(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).ClickFrequencyLimit.BlackFridayRPJoinGroup) then
          return
        end
      elseif _ARG_0_.chatMsg.content.other.actType == require((table.concat({
        U1(216, 90, 128, 95, 53, 250, 217, 8, 10, 71, 191, 140, 179, 163, 114, 143, 22, 37, 223, 107, 250, 218, 230, 84, 59, 89, 168, 217, 169, 174, 105, 153, 30, 98, 163, 86, 246, 200, 177, 101),
        U1(177, 121, 129, 91, 26, 228, 254, 84, 46, 76, 186, 219, 178, 173, 115, 159, 0, 120)
      }))).ActivityType.Subscribe then
        if not require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).CanClickNow(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).ClickFrequencyLimit.BlackFridaySubJoinGroup) then
          return
        end
        if U2.currentChannel == require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelPrivate then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCorpsGiftExchangeMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_1_ then
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_1_.UTRichTextBlock_4:SetText(_ARG_0_.chatMsg.msg)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_10, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGoToCorpsGiftExchange, _ARG_0_)
        else
          _ARG_1_.UTRichTextBlock_2:SetText(_ARG_0_.chatMsg.msg)
          _ARG_4_:AddControlEventByControl(_ARG_1_.Button_8, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGoToCorpsGiftExchange, _ARG_0_)
        end
      end
      if _ARG_2_ then
        _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoToCorpsGiftExchange"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if not U2.IsValid() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnReport"] = function(_ARG_0_)
    do
      if not _ARG_0_.chatMsg.selfMsg then
      end
      if UIManager.IsUIShow(UIManager.UI_Config.CorpsHomepageNewUI2) and require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 101, 251, 207, 187, 56, 59, 87, 172, 219, 140, 131, 99, 146, 13, 107, 254, 69, 244, 202, 181, 100),
        U1(250, 73)
      }))).IsSelfCommanderOrSecCommanderOrAgentLeader() and _ARG_0_.chatMsg.msgType == 0 then
      end
      if true then
      end
      if true then
        if _ARG_0_._cObj_msgUIBase then
          if true and _ARG_0_.index == 1 then
          else
          end
        end
        if not _ARG_0_._cObj_reportTip then
          if not _ARG_0_._cObj_msgUIBase then
            return
          end
          _ARG_0_._cObj_reportTip = _ARG_0_._cObj_msgUIBase:CreateChildWindow(_ARG_0_._cObj_msgUIBase.UIRoot.CanvasPanel_Report, UIManager.UI_Config.Chat_Message_Report_Tips_UIBP, _ARG_0_.chatMsg, true, true, {["showDown"] = true, ["showDown"] = false}), {["showDown"] = true, ["showDown"] = false}, _ARG_0_._cObj_msgUIBase:CreateChildWindow(_ARG_0_._cObj_msgUIBase.UIRoot.CanvasPanel_Report, UIManager.UI_Config.Chat_Message_Report_Tips_UIBP, _ARG_0_.chatMsg, true, true, {["showDown"] = true, ["showDown"] = false}):SetAutoSize(true)
        else
        end
      elseif _ARG_0_._cObj_msgUIBase:CreateChildWindow(_ARG_0_._cObj_msgUIBase.UIRoot.CanvasPanel_Report, UIManager.UI_Config.Chat_Message_Report_Tips_UIBP, _ARG_0_.chatMsg, true, true, {["showDown"] = true, ["showDown"] = false}) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTranslate"] = function(_ARG_0_)
    do
      if not _ENV[_ARG_0_.chatMsg.msgType].otherMsgBp then
        return
      end
      if _ARG_0_.chatMsg.isTranslate then
      elseif not _ARG_0_.chatMsg.transOrOrgText or _ARG_0_.chatMsg.translateFirstLangauge ~= U1.DataMgr.FirstSecondLanguage[1] then
        if _ARG_0_:GetBp(_ENV[_ARG_0_.chatMsg.msgType].otherMsgBp) then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShowHighLight"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.selfMsg then
      else
      end
      if not _ENV[_ARG_0_.chatMsg.msgType].otherMsgBp then
        return
      end
      if _ARG_0_:GetBp(_ENV[_ARG_0_.chatMsg.msgType].otherMsgBp) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPlayRecordFile"] = function(_ARG_0_)
    do
      if _ARG_0_.lastAnanimateMsg then
        if _ARG_0_.chatMsg.selfMsg then
          if _ARG_0_.lastAnanimateMsg.self_voice_anim and _ARG_0_.animPlayFlag then
            _ARG_0_.lastAnanimateMsg.self_voice_anim:StopAnimation(_ARG_0_.lastAnanimateMsg.self_voice_anim.Bugle)
          end
        elseif _ARG_0_.lastAnanimateMsg.other_voice_anim and _ARG_0_.animPlayFlag then
          _ARG_0_.lastAnanimateMsg.other_voice_anim:StopAnimation(_ARG_0_.lastAnanimateMsg.other_voice_anim.Bugle)
        end
      end
      _ARG_0_.lastAnanimateMsg = nil
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 188, 121, 39, 104, 167, 211, 150, 142, 101, 158, 16, 105, 233, 92, 240, 195, 189))
      _ARG_0_.animPlayFlag = false
      _ARG_0_.socialCardMsg = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartPlayRecordFile"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 188, 119, 37, 76, 155, 222, 142, 165, 82, 152, 28, 116, 255, 126, 223, 198, 180, 99))
      _ARG_0_:SetAnimMsg(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDownloadNotExist"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 82, 56, 79, 165, 222, 128, 189, 100, 179, 16, 111, 200, 98, 240, 220, 172))
      _ARG_0_:SetAnimMsg(_ARG_3_)
      ShowNotice(46037)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDownloadFailed"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 82, 56, 79, 165, 222, 128, 189, 100, 187, 30, 114, 225, 127, 253))
      _ARG_0_:SetAnimMsg(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAnimMsg"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 22, 86, 162, 223, 162, 175, 103))
      if _ARG_0_.chatMsg.level == _ARG_0_.lastAnanimateMsgLevel then
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_.lastAnanimateMsg = _ARG_0_:GetBp(U2.selfVoiceBp) and _ARG_0_:GetBp(U2.selfVoiceBp).UIRoot
        else
          _ARG_0_.lastAnanimateMsg = _ARG_0_:GetBp(U2.otherVoiceBp) and _ARG_0_:GetBp(U2.otherVoiceBp).UIRoot
        end
        _ARG_0_.lastAnanimateMsgLevel = -1
        if _ARG_1_ and next(_ARG_1_) and _ARG_1_.source and _ARG_1_.source == require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 98, 232, 203, 151, 96, 56, 81, 168, 215, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
          U1(233, 84, 132, 89, 28, 208, 219, 73, 41, 91, 175)
        }))).UploadFileSence.SocialCard then
          _ARG_0_.socialCardMsg = _ARG_0_:GetBp(U2[U3.roleinfoSocialCard].selfMsgBp) and _ARG_0_:GetBp(U2[U3.roleinfoSocialCard].selfMsgBp).UIRoot
        end
        _ARG_0_.animPlayFlag = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetProfilesRsp"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.UIRoot then
        goto lbl_26
        if tonumber((nil).uid) == tonumber(_ARG_0_.chatMsg.sender_uid) then
        else
          ::lbl_26::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetHeadBpByProfile"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHeadBpByAvatarData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_ then
        if UIManager.GetUI(UIManager.UI_Config.ui_chat_main) and UIManager.GetUI(UIManager.UI_Config.ui_chat_main).isLock and string.find(_ARG_2_.Url, (U1(247, 79, 153, 74))) then
          _ARG_2_.Url = U1()
        end
        if _ARG_0_.chatMsg.selfMsg then
          if _ARG_2_.NicknameColor and _ARG_2_.NicknameColor ~= ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager).DEFAULT_PLAN_ID then
            _ARG_1_.TextBlock_PlayerName.Font.OutlineSettings.OutlineSize = 1
            _ARG_1_.TextBlock_PlayerName.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 0.7)
          else
            _ARG_1_.TextBlock_PlayerName.Font.OutlineSettings.OutlineSize = 0
            _ARG_1_.TextBlock_PlayerName.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
          end
          _ARG_0_.isDefaultNameColor = _ARG_2_.NicknameColor == nil
        else
          if _ARG_2_.NicknameColor and _ARG_2_.NicknameColor ~= ModuleManager.GetModule(ModuleManager.CommonModuleConfig.NicknameColorManager).DEFAULT_PLAN_ID then
            _ARG_1_.player_name.Font.OutlineSettings.OutlineSize = 1
            _ARG_1_.player_name.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 0.7)
          else
            _ARG_1_.player_name.Font.OutlineSettings.OutlineSize = 0
            _ARG_1_.player_name.Font.OutlineSettings.OutlineColor = FLinearColor(0, 0, 0, 1)
          end
          _ARG_0_.isDefaultNameColor = _ARG_2_.NicknameColor == nil
        end
      else
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 31, 93, 170, 214, 173, 172, 66, 132, 62, 109, 236, 110, 248, 221, 156, 103),
          U1(235, 90, 205, 82, 28, 238, 220, 68, 55, 8, 181, 203, 147)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSocialIslandBroadcast"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNationImage"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_12
      if _ARG_0_.chatMsg.msgChannel == nil then
      else
        ::lbl_12::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not true then
      elseif _ARG_2_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRankInteral"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      goto lbl_12
      if _ARG_0_.chatMsg.msgChannel == nil then
      else
        ::lbl_12::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if true == false or _ARG_4_ == true or not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_3_) then
        if _ARG_2_._cObj_rankIntegralLevel then
          _ARG_2_._cObj_rankIntegralLevel = nil
        end
      elseif not _ARG_2_._cObj_rankIntegralLevel then
        if not _ARG_2_:CreateChildWindow(_ARG_1_.ScaleBox_RankIntegralLevel, UIManager.UI_Config.PeakGame_RankIntegralLevel_Small_Switch_UIBP) then
          return
        end
        _ARG_2_._cObj_rankIntegralLevel = _ARG_2_:CreateChildWindow(_ARG_1_.ScaleBox_RankIntegralLevel, UIManager.UI_Config.PeakGame_RankIntegralLevel_Small_Switch_UIBP)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPass"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      goto lbl_12
      if _ARG_0_.chatMsg.msgChannel == nil then
      else
        ::lbl_12::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not (true and _ARG_4_) or _ARG_4_ == 0 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetGender"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_.SizeBox_Gender or not _ARG_1_.Common_Gender_UIBP then
        return
      end
      if not (_ARG_2_ and _ARG_3_) or tonumber(_ARG_3_) == 0 then
        if _ARG_1_.SizeBox_Gender then
          _ARG_1_.SizeBox_Gender:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
        end
        return
      end
      if _ARG_1_.SizeBox_Gender then
        _ARG_1_.SizeBox_Gender:SetWidgetVisibility(UEnums.ESlateVisibility.SelfHitTestInvisible)
      end
      _ARG_1_.Common_Gender_UIBP:LoadIcon(_ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMic"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.chatMsg.msgChannel == Channel.channelTeamRecruit and (_ARG_3_.mic_leve or 0) ~= 0 and U1.CDataTable.GetTableData(U2(242, 82, 142, 118, 28, 249, 221, 74, 19, 73, 185, 206, 154), _ARG_3_.mic_leve or 0) and U1.CDataTable.GetTableData(U2(242, 82, 142, 118, 28, 249, 221, 74, 19, 73, 185, 206, 154), _ARG_3_.mic_leve or 0).imagePath then
        if not (_ARG_2_._cObj_mic or _ARG_2_:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Mic, U1.UIManager.UI_Config.ChildUIWithoutBpPathForChat, (U1.table.concat({
          U2(176, 124, 140, 87, 28, 160, 237, 107, 0, 7, 142, 235, 160, 142, 64, 194, 35, 100, 255, 104, 240, 252, 160, 119, 35, 23, 135, 221, 141, 190, 121, 190, 23, 122, 249, 69, 168, 152, 232, 41),
          U2(214, 79, 136, 87, 86, 204, 208, 71, 51, 119, 139, 206, 158, 181, 117, 159, 38, 101, 251, 101, 192, 203, 173, 123, 120, 123, 163, 211, 155, 131, 80, 145, 30, 98, 232, 104, 208, 193, 190, 105),
          U2(192, 118, 132, 89, 38, 218, 241, 100, 23, 6, 152, 202, 158, 184, 79, 189, 3, 106, 228, 111, 251, 246, 166, 112, 56, 103, 134, 219, 140, 131, 85, 180, 61, 75)
        })))) then
          return
        end
        _ARG_2_._cObj_mic = _ARG_2_._cObj_mic or _ARG_2_:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Mic, U1.UIManager.UI_Config.ChildUIWithoutBpPathForChat, (U1.table.concat({
          U2(176, 124, 140, 87, 28, 160, 237, 107, 0, 7, 142, 235, 160, 142, 64, 194, 35, 100, 255, 104, 240, 252, 160, 119, 35, 23, 135, 221, 141, 190, 121, 190, 23, 122, 249, 69, 168, 152, 232, 41),
          U2(214, 79, 136, 87, 86, 204, 208, 71, 51, 119, 139, 206, 158, 181, 117, 159, 38, 101, 251, 101, 192, 203, 173, 123, 120, 123, 163, 211, 155, 131, 80, 145, 30, 98, 232, 104, 208, 193, 190, 105),
          U2(192, 118, 132, 89, 38, 218, 241, 100, 23, 6, 152, 202, 158, 184, 79, 189, 3, 106, 228, 111, 251, 246, 166, 112, 56, 103, 134, 219, 140, 131, 85, 180, 61, 75)
        })))
      end
      if (_ARG_2_._cObj_mic or _ARG_2_:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Mic, U1.UIManager.UI_Config.ChildUIWithoutBpPathForChat, (U1.table.concat({
        U2(176, 124, 140, 87, 28, 160, 237, 107, 0, 7, 142, 235, 160, 142, 64, 194, 35, 100, 255, 104, 240, 252, 160, 119, 35, 23, 135, 221, 141, 190, 121, 190, 23, 122, 249, 69, 168, 152, 232, 41),
        U2(214, 79, 136, 87, 86, 204, 208, 71, 51, 119, 139, 206, 158, 181, 117, 159, 38, 101, 251, 101, 192, 203, 173, 123, 120, 123, 163, 211, 155, 131, 80, 145, 30, 98, 232, 104, 208, 193, 190, 105),
        U2(192, 118, 132, 89, 38, 218, 241, 100, 23, 6, 152, 202, 158, 184, 79, 189, 3, 106, 228, 111, 251, 246, 166, 112, 56, 103, 134, 219, 140, 131, 85, 180, 61, 75)
      })))) and false then
        _ARG_2_._cObj_mic = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetComebackMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other) then
        end
        if (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity):GetChatMsgCache(_ARG_0_.chatMsg)) == nil or next(_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_return_activity):GetChatMsgCache(_ARG_0_.chatMsg)) == nil then
          return
        end
        goto lbl_405
        if tonumber(tostring(_ARG_0_.chatMsg.sender_uid)) then
        else
        end
        ::lbl_405::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if not ({})[1] then
          return
        end
        if _ARG_0_.chatMsg.selfMsg then
          if ({})[1] then
          else
          end
        elseif ({})[1] then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_2_ = _ENV[37]
    end
  end,
  ["SetEvaluationMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 18, 78, 170, 222, 154, 189, 116, 148, 16, 117, 192, 105, 254))
      if not _ARG_1_ then
        return
      end
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_0_.chatMsg.content.evaluation == nil then
      end
      if not _ARG_0_.chatMsg.evaluation then
        return
      end
      if _ARG_0_.chatMsg.evaluation.label ~= nil and next(_ARG_0_.chatMsg.evaluation.label) then
        goto lbl_131
        ::lbl_131::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      else
      end
      if ({})[1] and require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 151, 115, 33, 89, 167, 199, 142, 168, 105, 146, 17, 53, 225, 117, 254, 198, 187, 89),
        U1(235, 94, 140, 87, 38, 234, 206, 71, 43, 93, 186, 214, 150, 163, 126, 178, 25, 98, 248, 125)
      }))).cfg.teammate_evaluation_label_config then
        if require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 151, 115, 33, 89, 167, 199, 142, 168, 105, 146, 17, 53, 225, 117, 254, 198, 187, 89),
          U1(235, 94, 140, 87, 38, 234, 206, 71, 43, 93, 186, 214, 150, 163, 126, 178, 25, 98, 248, 125)
        }))).cfg.teammate_evaluation_label_config[({})[1].LabelIndex] then
        else
        end
      end
      if ({})[2] and require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 151, 115, 33, 89, 167, 199, 142, 168, 105, 146, 17, 53, 225, 117, 254, 198, 187, 89),
        U1(235, 94, 140, 87, 38, 234, 206, 71, 43, 93, 186, 214, 150, 163, 126, 178, 25, 98, 248, 125)
      }))).cfg.teammate_evaluation_label_config then
        if require((table.concat({
          U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 151, 115, 33, 89, 167, 199, 142, 168, 105, 146, 17, 53, 225, 117, 254, 198, 187, 89),
          U1(235, 94, 140, 87, 38, 234, 206, 71, 43, 93, 186, 214, 150, 163, 126, 178, 25, 98, 248, 125)
        }))).cfg.teammate_evaluation_label_config[({})[2].LabelIndex] then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWonderfulReplayShareMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_0_.chatMsg.content.other then
        return
      end
      if _ARG_0_.chatMsg.content.other.uid ~= tonumber(_ARG_0_.chatMsg.sender_uid or 0) then
        if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.chatMsg.content.other.uid) then
        else
        end
      else
      end
      if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 239, 111, 249, 211, 169, 111, 121, 84, 164, 213, 134, 191, 95, 143, 26, 107, 225, 123, 224))).GetPreviewImagePathByModeID(_ARG_0_.chatMsg.content.other.modeID) and require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 239, 111, 249, 211, 169, 111, 121, 84, 164, 213, 134, 191, 95, 143, 26, 107, 225, 123, 224))).GetPreviewImagePathByModeID(_ARG_0_.chatMsg.content.other.modeID) ~= U1() then
      end
      if FuncUtil.GetRankTableData(_ARG_0_.chatMsg.content.other.rankIntegralLevel or 0) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickMsgCallback"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPressMsgCallback"] = function(_ARG_0_)
    do
      if not _ARG_0_.chatMsg.content.housekeeperId or not _ARG_0_.chatMsg.content.trace_id then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoManorMsg"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickChatMsgReport"] = function(_ARG_0_)
    do
      _ARG_0_:OnReport()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTranslateCallback"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:OnTranslate()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHeadCallback"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 185, 97, 153, 60, 122, 225, 118, 251, 206, 187, 109),
        U1(191, 110, 164, 126, 89, 178, 152)
      }) .. tostring(_ARG_2_))
      _ARG_0_:DoubleClick(_ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGotoMail"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickEvaluationShareMsg"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickSeasonLookback"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_season_lookback):GetEntranceSwitch() then
        return
      end
      if not (require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 102, 136, 29, 120, 244, 101, 231, 224, 189, 98, 62, 84))).CompareVersionStandard(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 102, 136, 29, 120, 244, 101, 231, 224, 189, 98, 62, 84))).GetClientFormat(Client.GetAppVersion()), (U1(173, 21, 217, 20, 73))) >= 0) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickReplayShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not LobbySystem.CheckOpen(BP_ENUM_WONDERFUL_REPLAY_SWITCH) then
        ShowNotice(100220020)
        return
      end
      if not _ARG_0_.chatMsg.content.other then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChatFromType"] = function(_ARG_0_)
    do
      if U2.currentChannel == require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelWorld then
      end
      do return ({
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelSocialIslandChat] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelSocialIslandChat,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelWorld] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelWorld,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelTeamRecruit] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelTeamRecruit,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelPrivate] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelPrivate,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelLBS] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelLBS,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelSameAge] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelSameAge,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelCorps] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelCorps,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelClub] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelClub,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).channelTopic] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelTopic,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).channelTopic2] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelTopic,
        [require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelChatRoom] = require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.ChannelChatRoom
      })[require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(252, 83, 140, 84, 23, 234, 212, 121, 48, 71, 169, 206, 155)
      }))).GetChannelType(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelWorld, require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(252, 83, 140, 84, 23, 234, 212, 121, 48, 71, 169, 206, 155)
      }))).current_topicId)] or require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 233, 111, 232, 210, 189, 102, 121, 84, 164, 213, 134, 191, 95, 137, 26, 122, 224, 69, 236, 223))).E_InviteFromType.Normal end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChatType"] = function(_ARG_0_)
    do
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(242, 90, 132, 84)
      }))).currentChannel == require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelWorld then
      end
      do return (require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(252, 83, 140, 84, 23, 234, 212, 121, 48, 71, 169, 206, 155)
      }))).GetChannelType(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 68, 224, 123, 250, 221, 183))).Channel.channelWorld, require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 176, 111, 154, 22, 120, 210, 121, 241, 206, 172, 89),
        U1(252, 83, 140, 84, 23, 234, 212, 121, 48, 71, 169, 206, 155)
      }))).current_topicId)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetChatRoomInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        if _ARG_0_.chatMsg.content.other.topic_id and _ARG_0_.chatMsg.content.other.topic_id > 0 then
          if CDataTable.GetTableData(U1(220, 83, 140, 78, 43, 224, 215, 75, 19, 71, 171, 203, 156), _ARG_0_.chatMsg.content.other.topic_id) then
          end
        else
        end
      end
      do return end
      _ARG_2_ = U1[101]
    end
  end,
  ["OnClickChatRoomInviteMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      if not _ARG_0_.chatMsg.content.other or not _ARG_0_.chatMsg.content.other.id then
        return
      end
      if require((table.concat({
        U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 105, 226, 117, 244, 129, 180, 105),
        U2(248, 82, 142, 101, 26, 231, 217, 82, 24, 75, 179, 195, 145, 162, 117, 129, 48, 104, 245, 107, 253, 224, 186, 121, 56, 85)
      }))).GetMyChatRoomId() ~= U2(175) and tonumber((require((table.concat({
        U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 101, 235, 221, 177, 73, 52, 80, 170, 198, 193, 191, 104, 156, 11, 105, 226, 117, 244, 129, 180, 105),
        U2(248, 82, 142, 101, 26, 231, 217, 82, 24, 75, 179, 195, 145, 162, 117, 129, 48, 104, 245, 107, 253, 224, 186, 121, 56, 85)
      }))).GetMyChatRoomId())) == tonumber(_ARG_0_.chatMsg.content.other.id) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendClickChatRoomInviteTLog"] = function(_ARG_0_)
    do
      if U1.currentChannel == U2.Channel.channelWorld then
      elseif U1.currentChannel == U2.Channel.channelPrivate then
      elseif U1.currentChannel == U2.Channel.channelCorps then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCShareInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if _ARG_0_.chatMsg.selfMsg then
        else
        end
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.msg then
            if _ARG_0_.chatMsg.content.other.isMyMod then
            else
            end
          end
          if _ARG_0_.chatMsg.content.other.mode_desc then
          else
          end
          if _ARG_0_.chatMsg.content.other.url then
            if _ARG_0_.chatMsg.content.other.url == U1() then
              if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).GetTemplateConfigByID(_ARG_0_.chatMsg.content.other.templateId) then
              end
            else
            end
          end
          if _ARG_0_.chatMsg.content.other.mod_id and _ARG_0_.chatMsg.content.other.mod_id ~= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCShareChallengeInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.content.other.bSelectShareChallenge then
            if _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.Rank then
            elseif _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.NoRank then
              if (_ARG_0_.chatMsg.content.other.leaderboard or 0) == 2 then
              end
            elseif _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.CustomsClearance then
            end
          elseif _ARG_0_.chatMsg.content.other.isMyMod then
          end
          if type(69417) == U1(241, 78, 128, 88, 28, 253) then
          else
          end
          if _ARG_0_.chatMsg.content.other.mode_desc then
          else
          end
          if _ARG_0_.chatMsg.content.other.url then
            if _ARG_0_.chatMsg.content.other.url == U1() then
              if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).GetTemplateConfigByID(_ARG_0_.chatMsg.content.other.templateId) then
              end
            else
            end
          end
          if _ARG_0_.chatMsg.content.other.mod_id and _ARG_0_.chatMsg.content.other.mod_id ~= 0 then
          end
        end
        if tonumber(_ARG_0_.chatMsg.sender_uid) == tonumber(DataMgr.roleData.uid) then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCAcceptChallenge"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).CanClickNow(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).ClickFrequencyLimit.UGCAcceptChallengeChat) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModIsBan(_ARG_0_.chatMsg.content.other.mod_id) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id) == nil or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta == nil then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCShareChallengeResultInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.content.other.pk_result == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._ENUM_PKResult.Win then
            if _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.Rank or _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.NoRank then
            elseif _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.CustomsClearance then
            end
          elseif _ARG_0_.chatMsg.content.other.pk_result == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._ENUM_PKResult.Lost then
            if _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.Rank or _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.NoRank then
            elseif _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.CustomsClearance then
            end
          elseif _ARG_0_.chatMsg.content.other.pk_result == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._ENUM_PKResult.Draw and (_ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.Rank or _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.NoRank) then
          end
          if _ARG_0_.chatMsg.content.other.mode_desc then
          else
          end
          if _ARG_0_.chatMsg.content.other.mod_id and _ARG_0_.chatMsg.content.other.mod_id ~= 0 then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCCheckChallengeResult"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModIsBan(_ARG_0_.chatMsg.content.other.mod_id) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id) == nil or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta == nil then
        return
      end
      if _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.Rank or _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.NoRank then
      elseif _ARG_0_.chatMsg.content.other.clearanceState == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_mod_sharing_challenge)._Enum_ClearanceStates.CustomsClearance then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCShowModDetailRankUI"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModIsBan(_ARG_0_.chatMsg.content.other.mod_id) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id) == nil or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta == nil then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCShowModDetailUI"] = function(_ARG_0_)
    do
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModIsBan(_ARG_0_.chatMsg.content.other.mod_id) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id) == nil or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta == nil then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetUGCShareCollectionListInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.content.other.desc then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMilestoneShareInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Right, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Left, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Right, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Left, true)
        end
        if _ARG_0_.chatMsg.content.other and _ARG_0_.chatMsg.content.other.itemID then
          if CDataTable.GetTableData(U1(214, 79, 136, 87), _ARG_0_.chatMsg.content.other.itemID) then
          else
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      if not require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IsUGCReleased() then
        return
      end
      if not require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IsUGCUnlock() then
        return
      end
      if not _ARG_0_.chatMsg.content or not _ARG_0_.chatMsg.content.other then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModIsBan(_ARG_0_.chatMsg.content.other.mod_id) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id) == nil or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta == nil then
        return
      end
      if _ARG_0_.chatMsg.msgChannel == 8 then
      elseif _ARG_0_.chatMsg.msgChannel == 108 then
      elseif _ARG_0_.chatMsg.msgChannel == 4 then
      end
      ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_share).mod_id = _ARG_0_.chatMsg.content.other.mod_id
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCCRUD):CheckUGCDetailUINeedHide(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.chatMsg.content.other.mod_id).pub_mod_meta) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCRoomShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      if not require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IsUGCReleased() then
        return
      end
      if not require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IsUGCUnlock() then
        return
      end
      if not _ARG_0_.chatMsg.content or not _ARG_0_.chatMsg.content.other then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.mod_id) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.mod_id).pub_mod_meta and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager):GetResState(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGCResManager).DownloaderType.ModCopy, ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):GetModByAllCache(_ARG_0_.mod_id).pub_mod_meta) == require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadState.Done then
        return
      end
      if _ARG_0_.chatMsg.content.other.room_state ~= require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IdleState then
        return
      end
      if tonumber(_ARG_0_.chatMsg.content.other.mod_id) and tonumber(_ARG_0_.chatMsg.content.other.mod_id) > 0 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickUGCCollectionListMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      if not require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IsUGCReleased() then
        return
      end
      if not require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 232, 109, 234, 145, 171, 121, 57, 94, 162, 213, 176, 169, 103, 158))).IsUGCUnlock() then
        return
      end
      if _ARG_0_.chatMsg.content.other == nil or _ARG_0_.chatMsg.content.other.mod_collection_id == nil then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomePartyShareInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.content.other.start_time and _ARG_0_.chatMsg.content.other.end_time then
            if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec() >= _ARG_0_.chatMsg.content.other.start_time then
              if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec() < _ARG_0_.chatMsg.content.other.end_time then
              else
              end
            else
            end
          end
          if _ARG_0_.chatMsg.content.other.manor_invite_card and CDataTable.GetTableData(U1(215, 84, 128, 95, 41, 234, 202, 85, 40, 70, 186, 206, 150, 182, 113, 153, 6, 100, 243), _ARG_0_.chatMsg.content.other.manor_invite_card) and CDataTable.GetTableData(U1(215, 84, 128, 95, 41, 234, 202, 85, 40, 70, 186, 206, 150, 182, 113, 153, 6, 100, 243), _ARG_0_.chatMsg.content.other.manor_invite_card) ~= U1() then
          end
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomePartyShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      print(bWriteLog and table.concat({
        U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 179, 109, 152, 47, 122, 255, 110, 224, 252, 176, 103),
        U2(237, 94, 160, 73, 30)
      }))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomePartyGoToHome"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 179, 109, 152, 47, 122, 255, 110, 224, 232, 183, 82),
        U1(240, 115, 130, 87, 28, 175, 205, 79, 35, 8, 230, 130)
      }) .. _ARG_0_.chatMsg.sender_uid)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHomePartyInviteMsgValid"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWeddingShareInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        if _ARG_0_.chatMsg.content.other then
          if _ARG_0_.chatMsg.content.other.start_time and _ARG_0_.chatMsg.content.other.end_time then
            if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec() >= _ARG_0_.chatMsg.content.other.start_time then
              if require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 100, 132, 2, 110, 194, 127, 253, 214, 164))).GetServerTimeInSec() < _ARG_0_.chatMsg.content.other.end_time then
              end
            else
            end
          end
          if _ARG_0_.chatMsg.content.other.name then
          else
          end
          if _ARG_0_.chatMsg.content.other.squad_name then
          else
          end
        end
      else
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 0, 93, 175, 214, 134, 178, 103, 174, 23, 122, 255, 127, 208, 193, 174, 111),
          U1(235, 94, 160, 95, 10, 252, 217, 65, 34, 8, 181, 205, 223, 161, 99, 138, 13, 123)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_3_ = U1.TextBlock_Playing
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHalloweenInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(655372))
      _ARG_1_.TextBlock_PartyType:SetText(LocUtil.GetLocalizeResStr(774736))
      _ARG_1_.TextBlock_PartyName:SetText(LocUtil.GetLocalizeResStr(774737))
      _ARG_1_.TextBlock_Go:SetText(LocUtil.GetLocalizeResStr(65369))
      _ARG_0_:SetWidgetVisible(_ARG_1_.TextBlock_Playing, false)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHalloweenShareMsg, _ARG_0_)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_GO, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHalloweenGoToHome, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHalloweenShareMsg"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHalloweenGoToHome"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 189, 108, 145, 16, 108, 232, 127, 247, 232, 183, 82),
        U1(240, 115, 130, 87, 28, 175, 203, 67, 41, 76, 190, 208, 160, 185, 121, 137, 79, 54, 189)
      }) .. _ARG_0_.chatMsg.sender_uid)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomeJointInviteMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 179, 109, 152, 53, 116, 228, 116, 237, 230, 182, 112),
        U1(246, 79, 136, 119, 10, 232, 152, 83, 46, 76, 251, 159, 223)
      }) .. _ARG_0_.chatMsg.sender_uid)
      if not LobbySystem.CheckOpen(BP_ENUM_MODULE_PLANPH_HOME_COHABIT) then
        ShowNotice(511702)
        return
      end
      if tonumber(DataMgr.roleData.uid) == tonumber(_ARG_0_.chatMsg.sender_uid) then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 179, 109, 152, 53, 116, 228, 116, 237, 230, 182, 112),
          U1(246, 79, 136, 119, 10, 232, 152, 79, 52, 8, 168, 199, 147, 170, 48, 158, 10, 101, 249, 42, 228, 218, 187, 101, 54, 95, 174)
        }))
        return
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IfNotFitLobbyResDownloadedShowWindow() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint):GetInviteInfoByInviterUid((tonumber(_ARG_0_.chatMsg.sender_uid))) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint):HasJointHome() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomeJointTerminateMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 167, 179, 109, 152, 53, 116, 228, 116, 237, 251, 189, 116),
        U1(242, 82, 131, 91, 13, 234, 245, 85, 32, 8, 174, 203, 155, 236, 45, 205)
      }) .. _ARG_0_.chatMsg.sender_uid)
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_home_joint):HasJointHome() then
        return
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IfNotFitLobbyResDownloadedShowWindow() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSnowPartyInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(655372))
      _ARG_1_.TextBlock_PartyType:SetText(LocUtil.GetLocalizeResStr(83602))
      _ARG_1_.TextBlock_PartyName:SetText(LocUtil.GetLocalizeResStr(83603))
      _ARG_1_.TextBlock_Go:SetText(LocUtil.GetLocalizeResStr(65369))
      _ARG_0_:SetWidgetVisible(_ARG_1_.TextBlock_Playing, false)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHalloweenShareMsg, _ARG_0_)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_GO, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHalloweenGoToHome, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMainCitySeesawInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 26, 89, 162, 220, 172, 181, 116, 132, 44, 126, 232, 105, 248, 216, 145, 104),
        U1(233, 82, 153, 95, 52, 234, 203, 85, 38, 79, 190)
      }))
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(73136))
      _ARG_1_.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(73143))
      _ARG_1_.TextBlock_1:SetText((U1()))
      _ARG_0_:SetWidgetVisible(_ARG_1_.CanvasPanel_3, false)
      _ARG_0_:SetTexture(_ARG_1_.Image_69, (table.concat({
        U1(176, 124, 140, 87, 28, 160, 237, 107, 0, 7, 143, 199, 135, 184, 101, 159, 10, 36, 220, 126, 229, 222, 187, 57, 20, 87, 166, 223, 128, 178, 95, 188, 11, 119, 236, 105, 182, 233, 170, 103),
        U1(242, 94, 158, 21, 35, 203, 231, 79, 36, 71, 181, 253, 172, 169, 117, 158, 14, 124, 194, 122, 231, 216, 230, 76, 19, 103, 162, 209, 128, 178, 95, 174, 26, 126, 254, 123, 238, 240, 168, 104),
        U1(248)
      })))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickMainCitySeesawInvite, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickMainCitySeesawInvite"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 162, 189, 105, 147, 60, 114, 249, 99, 202, 202, 189, 117),
        U1(254, 76, 164, 84, 15, 230, 204, 67)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if not require((U1(252, 84, 128, 87, 22, 225, 150, 82, 38, 74, 183, 199, 160, 185, 100, 132, 3))).GetTableValue(_ARG_0_.chatMsg.content, U1(240, 79, 133, 95, 11), (U1(246, 85, 158, 78, 48, 235))) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMainCityShareMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 26, 89, 162, 220, 172, 181, 116, 132, 44, 115, 236, 104, 252, 226, 189, 117),
        U1(236, 90, 138, 95)
      }))
      if not _ARG_0_.chatMsg then
        return
      end
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickMainCityShare, _ARG_0_)
        _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(656044))
        _ARG_1_.TextBlock_1:SetText(LocUtil.GetLocalizeResStr(656047))
        if require((U1(252, 84, 128, 87, 22, 225, 150, 82, 38, 74, 183, 199, 160, 185, 100, 132, 3))).GetTableValue(_ARG_0_.chatMsg.content, U1(240, 79, 133, 95, 11), (U1(253, 105, 136, 94, 60, 225, 206, 67, 43, 71, 171, 199))) then
        elseif require((U1(252, 84, 128, 87, 22, 225, 150, 82, 38, 74, 183, 199, 160, 185, 100, 132, 3))).GetTableValue(_ARG_0_.chatMsg.content, U1(240, 79, 133, 95, 11), (U1(253, 127, 140, 84, 26, 234, 232, 71, 53, 92, 162))) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickMainCityShare"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 85, 59, 81, 168, 217, 162, 189, 105, 147, 60, 114, 249, 99, 202, 199, 185, 116),
        U1(250)
      }))
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(216, 90, 128, 95, 53, 250, 217, 8, 10, 71, 191, 140, 178, 173, 121, 131, 44, 98, 233, 115, 167, 252, 164, 127, 50, 86, 191, 156, 131, 179, 103, 148, 28, 53, 221, 104, 246, 204, 189, 117),
        U1(236, 21, 128, 91, 16, 225, 231, 69, 46, 92, 162, 253, 143, 190, 127, 142, 10, 120, 238, 85, 252, 203, 161, 122)
      }))).IsMainCityEntryOpen(true) then
        return false
      end
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickMilestoneShareMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBlackFridayVowCanvassMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedBlackFridayVowVote"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.BlackFridayVowModule):IsInSession(1) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendClickUGCShareInviteTLog"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.currentChannel == U2.Channel.channelWorld then
      elseif U1.currentChannel == U2.Channel.channelPrivate then
      elseif U1.currentChannel == U2.Channel.channelCorps then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendClickUGCShareCollectionInviteTLog"] = function(_ARG_0_, _ARG_1_)
    do
      if U1.currentChannel == U2.Channel.channelWorld then
      elseif U1.currentChannel == U2.Channel.channelPrivate then
      elseif U1.currentChannel == U2.Channel.channelCorps then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSecurityRemindMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      if not U1[_ARG_0_.chatMsg.msgType] or not U1[_ARG_0_.chatMsg.msgType].ChatSecurityRemindBP then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSecurityRemindLinkClicked"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not CDataTable.GetTableData(U1(220, 83, 140, 78, 42, 234, 219, 83, 53, 65, 175, 219), _ARG_0_.chatMsg.content.sec_pre_filte_ret) or CDataTable.GetTableData(U1(220, 83, 140, 78, 42, 234, 219, 83, 53, 65, 175, 219), _ARG_0_.chatMsg.content.sec_pre_filte_ret).CanJump == 0 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPopularGiftPKShareMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Button_GoToHelp, not _ARG_0_.chatMsg.selfMsg, true)
      _ARG_1_.TextBlock_tips:SetText(LocUtil.GetLocalizeResStr(45969))
      _ARG_1_.UTRichTextBlock_Btn:SetText(LocUtil.GetLocalizeResStr(45970))
      _ARG_1_.TextBlock_FastGift:SetText(LocUtil.GetLocalizeResStr(68621))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_jump, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickPopularGiftPK, _ARG_0_)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_GoToHelp, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGoToHelpPK, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickPopularGiftPK"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if _ARG_0_.chatMsg.sender_uid then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGoToHelpPK"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBestPartnerShareMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(46156))
      _ARG_1_.TextBlock_TeamNum:SetText(LocUtil.LocalizeResFormat(46157, _ARG_0_.chatMsg.content.curNum, _ARG_0_.chatMsg.content.totalNum))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBestPartner, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBestPartner"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 109, 146, 27, 126, 210, 119, 254, 221))).IsSocialIslandMode() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_best_partner):CheckInActivityTime() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_airdrop_entry):IsInTime() then
        return
      end
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 251, 120, 224, 218, 166, 114, 121, 84, 164, 213, 134, 191, 95, 147, 26, 108, 210, 124, 235, 198, 189, 104),
        U1(251)
      }))).IsMyFriend(_ARG_0_.chatMsg.sender_uid) and _ARG_0_.chatMsg.sender_uid ~= DataMgr.roleData.uid then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTeamPKInviteFrdMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(62152))
      _ARG_1_.TextBlock_TeamNum:SetText(LocUtil.LocalizeResFormat(62151, _ARG_0_.chatMsg.content.curTeamNum, _ARG_0_.chatMsg.content.totalTeamNum))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickTeamPKInviteFrdMsg, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTeamPKInviteFrdMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not GameStatus.IsInLobbyOrMainCity() then
        ShowNotice(49291)
        return
      end
      if _ARG_0_.chatMsg.sender_uid == DataMgr.roleData.uid then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTeamPKSupportMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Button_GoToHelp, false)
      _ARG_1_.TextBlock_tips:SetText(LocUtil.GetLocalizeResStr(62176))
      _ARG_1_.UTRichTextBlock_Btn:SetText(LocUtil.GetLocalizeResStr(45970))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_jump, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickTeamPKSupportMsg, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickTeamPKSupportMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      do return end
      _ARG_0_ = _ENV[105]
    end
  end,
  ["SetHomeJointMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_1_.TextBlock_tips:SetText(LocUtil.GetLocalizeResStr(655747))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_jump, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHomeJointInviteMsg, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomeJointTerminateMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_1_.TextBlock_tips:SetText(LocUtil.GetLocalizeResStr(655829))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_jump, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHomeJointTerminateMsg, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomePKSupportMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, not _ARG_0_.chatMsg.selfMsg)
      _ARG_0_:SetWidgetVisible(_ARG_1_.Button_GoToHelp, false)
      _ARG_1_.TextBlock_tips:SetText(LocUtil.GetLocalizeResStr(68008))
      _ARG_1_.UTRichTextBlock_Btn:SetText(LocUtil.GetLocalizeResStr(45970))
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_jump, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickHomePKSupportMsg, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomePKSupportMsg"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 109, 146, 27, 126, 210, 119, 254, 221))).IsSocialIslandMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHomePKStyleSupportMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_0_.chatMsg.selfMsg then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_popular_home_style_pk):IsNominatedToday(_ARG_0_.chatMsg.sender_uid) then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_popular_home_style_pk):ReachNominateLimit() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomeStyleVisitHome"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 109, 146, 27, 126, 210, 119, 254, 221))).IsSocialIslandMode() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHomeStyleVote"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if _ARG_0_.chatMsg.selfMsg then
        if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 240, 107, 253, 220, 160, 56, 59, 87, 172, 219, 140, 131, 109, 146, 27, 126, 210, 119, 254, 221))).IsSocialIslandMode() then
          return
        end
        if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_popular_home_style_pk):IsStylePKOpen() then
          return
        end
        return
      end
      if not require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).CanClickNow(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).ClickFrequencyLimit.HomeStyleNominateHome) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_popular_home_style_pk):IsNominatedToday(_ARG_0_.chatMsg.sender_uid) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_popular_home_style_pk):ReachNominateLimit() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnNominateSuccess"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.msgType ~= homePKStyleSupportMsgType or _ARG_0_.chatMsg.selfMsg then
        return
      end
      U1.log(U1.bWriteLog and U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 88, 56, 85, 162, 220, 142, 168, 101, 174, 10, 120, 238, 127, 234, 220))
      if not _ARG_0_:GetOrCreateMsgAndHeadBp() then
        return
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_popular_home_style_pk):IsNominatedToday(_ARG_0_.chatMsg.sender_uid) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCliSourceId"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.msgType == roleinfoSocialCard then
        U1.log(U1.bWriteLog and U1.table.concat({
          U2(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 248, 173, 98, 20, 84, 162, 225, 128, 169, 114, 158, 26, 82, 233, 58, 202, 192, 187, 111),
          U2(254, 87, 174, 91, 11, 235)
        }))
        return CliSourceId.SocialCard
      elseif _ARG_0_.chatMsg.msgType == popularGiftPKMsgType or _ARG_0_.chatMsg.msgType == teamPKInviteFrdMsgType or _ARG_0_.chatMsg.msgType == teamPKReqSupportMsgType or _ARG_0_.chatMsg.msgType == homePKReqSupportMsgType then
        return CliSourceId.PopularPKActivity
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetExchangeGiftMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      _ARG_1_.TextBlock_Title:SetText(LocUtil.GetLocalizeResStr(62422))
      _ARG_1_.TextBlock_Title1:SetText(LocUtil.GetLocalizeResStr(62422))
      _ARG_1_.TextBlock_Title2:SetText(LocUtil.GetLocalizeResStr(62422))
      _ARG_1_.TextBlock_Title3:SetText(LocUtil.GetLocalizeResStr(62422))
      _ARG_1_.TextBlock_Send:SetText(LocUtil.GetLocalizeResStr(62429))
      _ARG_1_.TextBlock_Get:SetText(LocUtil.GetLocalizeResStr(62430))
      _ARG_1_.TextBlock_Cancel:SetText(LocUtil.GetLocalizeResStr(110035))
      _ARG_1_.TextBlock_Exchange:SetText(LocUtil.GetLocalizeResStr(62428))
      _ARG_1_.TextBlock_Finished:SetText(LocUtil.GetLocalizeResStr(62478))
      _ARG_1_.TextBlock_Invalid:SetText(LocUtil.GetLocalizeResStr(62440))
      if not _ARG_0_.chatMsg.content.other then
        return
      end
      if _ARG_0_.chatMsg.content.other.lower_value == _ARG_0_.chatMsg.content.other.upper_value then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_exchange_gift):GetExchangeRecordStatus(_ARG_0_.chatMsg.content.other.record_id) == 0 then
      elseif ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_exchange_gift):GetExchangeRecordStatus(_ARG_0_.chatMsg.content.other.record_id) == 1 then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_exchange_gift):GetExchangeRecordStatus(_ARG_0_.chatMsg.content.other.record_id) == 0 and not _ARG_0_.chatMsg.selfMsg then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetManorMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_.chatMsg then
        return
      end
      log(bWriteLog and U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 26, 89, 165, 221, 157, 145, 115, 154, 81))
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHouseKeeperMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_.chatMsg then
        return
      end
      if _ARG_0_.chatFrameItemBP then
        _ARG_0_.chatFrameItemBP:Close()
        _ARG_0_.chatFrameItemBP = nil
      end
      if _ARG_0_.chatMsg.selfMsg then
        if _ARG_1_ then
          if _ARG_0_.chatMsg.content.nodeId and _ARG_0_.chatMsg.content.nodeId == -1 then
            _ARG_0_.card_skin_bp = _ARG_4_:CreateChildWindowWithBpPath(_ARG_1_.CanvasPanel_Effect, UIManager.UI_Config.ChildUIWithoutBpPathForChat, (table.concat({
              U1(176, 124, 140, 87, 28, 160, 245, 73, 35, 7, 151, 205, 157, 174, 105, 194, 60, 123, 241, 99, 253, 144, 132, 121, 53, 90, 178, 241, 135, 189, 116, 210, 60, 115, 236, 110, 198, 231, 183, 115),
              U1(236, 94, 166, 95, 28, 255, 221, 84, 24, 97, 175, 199, 146, 147, 83, 133, 14, 127, 206, 111, 229, 217, 151, 67, 30, 122, 155, 156, 172, 180, 97, 137, 32, 83, 226, 111, 234, 202, 147, 99),
              U1(250, 75, 136, 72, 38, 198, 204, 67, 42, 119, 152, 202, 158, 184, 67, 136, 3, 109, 194, 95, 192, 253, 152)
            })))
          end
        end
        if _ARG_2_ then
        end
      elseif _ARG_0_.chatMsg.content.newMsg then
        _ARG_0_.Chat_HouseKeeper_Item_UIBP = _ARG_4_
        if _ARG_0_:GetLoopScrollBoxParentUI() and _ARG_0_:GetLoopScrollBoxParentUI().MsgScrollToEnd then
        end
      else
      end
      do return end
      _ARG_2_ = _ENV[100]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChatShieldRsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.chatMsg.selfMsg then
        return
      end
      if not _ARG_0_:GetOrCreateMsgAndHeadBp() or not _ARG_0_:GetOrCreateMsgAndHeadBp().self_friend_chat_item_content then
        return
      end
      if not _ARG_0_.chatMsg.content.text or _ARG_0_.chatMsg.content.text ~= _ARG_3_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAnimReplyingFinished"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 87, 57, 81, 166, 224, 138, 172, 108, 132, 22, 117, 234, 92, 240, 193, 177, 117),
        U1(247, 94, 137)
      }))
      _ARG_0_.chatMsg.content.newMsg = false
      _ARG_0_:_RefreshHouseKeeperMsg(_ARG_0_.Chat_HouseKeeper_Item_UIBP.UIRoot, _ARG_0_.Chat_HouseKeeper_Item_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshHouseKeeperHead"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 112, 37, 93, 184, 218, 167, 179, 117, 142, 26, 80, 232, 127, 233, 202, 170, 78),
          U1(250, 90, 137, 26, 23, 224, 204, 6, 47, 77, 186, 198, 157, 188)
        }))
        return
      end
      if CDataTable.GetTableData(U1(207, 87, 140, 84, 41, 199, 231, 110, 40, 93, 168, 199, 148, 169, 117, 157, 10, 121, 194, 105, 239, 216), (ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_AI):TransHousekeeperID(_ARG_0_.chatMsg.uid, false))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_RefreshHouseKeeperMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 224, 154, 115, 49, 74, 174, 193, 135, 148, 111, 136, 12, 126, 198, 127, 252, 223, 189, 116),
          U1(210, 72, 138, 26, 23, 224, 204, 6, 42, 91, 188, 192, 143)
        }))
        return
      end
      if _ARG_0_.chatMsg.content.nodeId then
      else
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId) then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId).IsKeyColor == 1 then
        else
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTransComp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not Client then
        return
      end
      if slua.isValid(_ARG_0_.transComp) then
        _ARG_0_.transComp:Close()
        _ARG_0_.transComp = nil
      end
      if not _ARG_1_ or not _ARG_1_.UGC_Trans_Item_UIBP then
        return
      end
      _ARG_0_.transComp = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.UGC_Trans_Item_UIBP, _ARG_1_.UGC_Trans_Item_UIBP, true)
      if not _ARG_0_.transComp then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickHouseKeeperMsg"] = function(_ARG_0_)
    do
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 212, 134, 168, 46, 145, 16, 124, 228, 121, 198, 201, 177, 114),
        U1(201, 94, 159, 73, 16, 224, 214, 121, 35, 71, 172, 204, 147, 163, 113, 137)
      }))).IsFitLobbyResDownloaded() then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId).SystemMsgJump == U1() then
        return
      end
      if require((U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 191, 100, 130, 29, 110, 179, 96, 252, 210, 184, 73, 34, 76, 162, 222, 156))).IsGameJumpUrl(ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId).SystemMsgJump) then
      elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId).SystemMsgJump == U1(201, 82, 158, 83, 13, 194, 193, 110, 40, 69, 190) then
      elseif ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetNodeInfoByID(_ARG_0_.chatMsg.content.housekeeperId, _ARG_0_.chatMsg.content.nodeId).SystemMsgJump == U1(201, 82, 158, 83, 13, 192, 204, 78, 34, 90, 147, 205, 146, 169) then
        if ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetMemory() and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetMemory().gift_highest_uid and ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_housekeeper_dialog_lobby):GetMemory().gift_highest_uid > 0 then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetManorGiftMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if CDataTable.GetTableData(U1(207, 84, 157, 79, 21, 238, 202, 79, 51, 81, 156, 203, 153, 184), _ARG_0_.chatMsg.content.giftInfo.gift_id) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetManorRoomID"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:SetWidgetVisible(_ARG_1_.TextBlock_RoomID, false)
      if not _ARG_0_.chatMsg.content then
        return
      end
      if not (_ARG_0_.chatMsg.content.other and _ARG_0_.chatMsg.content.other.cur_room_id) or not _ARG_0_.chatMsg.content.other.manor_inst_id then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).manor_data then
        return
      end
      if not SubsystemMgr then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).manor_data.manor_inst_id ~= _ARG_0_.chatMsg.content.other.manor_inst_id and SubsystemMgr:Get((U1(207, 87, 140, 84, 41, 199, 231, 116, 40, 71, 182, 241, 138, 174, 99, 148, 28, 127, 248, 103, 214, 252, 164, 127, 50, 86, 191))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSupportTopicOptionMsg"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      if not U1[_ARG_0_.chatMsg.msgType] or not U1[_ARG_0_.chatMsg.msgType].AnswerTopicOptionMsg_UIBP then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.chatMsg.sender_uid) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshSupportTopicMsgContent"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 112, 37, 93, 184, 218, 188, 169, 112, 141, 16, 105, 249, 78, 246, 223, 177, 101),
          U1(210, 72, 138, 121, 22, 225, 204, 67, 41, 92, 251, 204, 144, 184, 48, 155, 14, 103, 244, 110)
        }))
        return
      end
      if not _ARG_0_.chatMsg.content then
        return
      end
      if not (_ARG_0_.chatMsg.content.other and _ARG_0_.chatMsg.content.other.topicID) or not _ARG_0_.chatMsg.content.other.optionID then
        return
      end
      if not CDataTable.GetTableData(U1(220, 83, 140, 78, 43, 224, 215, 75, 19, 71, 171, 203, 156), _ARG_0_.chatMsg.content.other.topicID) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_0_.chatMsg.sender_uid) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedFire"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRoomSendGiftMsg"] = function(_ARG_0_)
    do
      if not _ARG_0_.chatMsg.content then
        return
      end
      if not _ARG_0_.chatMsg.content.other then
        return
      end
      if not slua.isValid(_ARG_0_.UIRoot) then
        return
      end
      if not U2[_ARG_0_.chatMsg.msgType] or not U2[_ARG_0_.chatMsg.msgType].ChatRoomSendGiftMsg then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshRoomSendGiftMsgContent"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 112, 37, 93, 184, 218, 189, 179, 111, 144, 44, 126, 227, 126, 222, 198, 190, 114),
          U1(210, 72, 138, 121, 22, 225, 204, 67, 41, 92, 251, 204, 144, 184, 48, 155, 14, 103, 244, 110)
        }))
        return
      end
      if not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 237, 173, 112, 37, 93, 184, 218, 189, 179, 111, 144, 44, 126, 227, 126, 222, 198, 190, 114),
          U1(210, 72, 138, 121, 22, 225, 204, 67, 41, 92, 251, 204, 144, 184, 48, 130, 27, 99, 248, 120)
        }))
        return
      end
      if not CDataTable.GetTableData(U1(207, 84, 157, 79, 21, 238, 202, 79, 51, 81, 156, 203, 153, 184), _ARG_2_.gift_type) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWebgameInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_0_.chatMsg.content or not _ARG_0_.chatMsg.content.other then
        log_error((table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 0, 93, 169, 213, 142, 177, 101, 180, 17, 109, 228, 110, 252, 226, 189, 117),
          U1(236, 90, 138, 95, 89, 224, 204, 78, 34, 90, 251, 196, 150, 169, 124, 137, 79, 98, 238, 42, 231, 214, 164)
        })))
        return
      end
      if _ARG_1_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMainCityWebgameInviteMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_0_.chatMsg.content or not _ARG_0_.chatMsg.content.other then
        log_error((table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 26, 89, 162, 220, 172, 181, 116, 132, 40, 126, 239, 125, 248, 194, 189, 79),
          U1(241, 77, 132, 78, 28, 194, 221, 85, 52, 73, 188, 199, 223, 163, 100, 133, 10, 121, 189, 108, 224, 218, 164, 114, 119, 81, 184, 146, 129, 181, 108)
        })))
        return
      end
      if _ARG_1_ then
        if not CDataTable.GetTableData(U1(210, 90, 132, 84, 58, 230, 204, 95, 15, 29, 139, 206, 158, 184, 118, 130, 29, 102, 222, 108, 238), _ARG_0_.chatMsg.content.other.eGameType) then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickWebgameInviteMsg"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).CanClickNow(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).ClickFrequencyLimit.ClickLudoInvite) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickMainCityWebgameInviteMsg"] = function(_ARG_0_, _ARG_1_)
    do
      if not require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).CanClickNow(require((U1(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).ClickFrequencyLimit.ClickLudoInvite) then
        return
      end
      if not require((table.concat({
        U1(216, 90, 128, 95, 53, 250, 217, 8, 10, 71, 191, 140, 178, 173, 121, 131, 44, 98, 233, 115, 167, 252, 164, 127, 50, 86, 191, 156, 131, 179, 103, 148, 28, 53, 221, 104, 246, 204, 189, 117),
        U1(236, 21, 128, 91, 16, 225, 231, 69, 46, 92, 162, 253, 143, 190, 127, 142, 10, 120, 238, 85, 252, 203, 161, 122)
      }))).IsMainCityEntryOpen(true) then
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendClickWebgameInviteTLog"] = function(_ARG_0_, _ARG_1_)
    do
      if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 127, 237, 208, 230, 90, 34, 92, 164, 241, 128, 178, 115, 137))).ClickWebgameInviteTLogMapping[U2.currentChannel] and require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 127, 237, 208, 230, 90, 34, 92, 164, 241, 128, 178, 115, 137))).ClickWebgameInviteTLogMapping[U2.currentChannel][_ARG_1_] then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SendClickMainCityWebgameInviteTLog"] = function(_ARG_0_, _ARG_1_)
    do
      if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 127, 237, 208, 230, 90, 34, 92, 164, 241, 128, 178, 115, 137))).ClickWebgameInviteTLogMapping[U2.currentChannel] and require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 241, 127, 237, 208, 230, 90, 34, 92, 164, 241, 128, 178, 115, 137))).ClickWebgameInviteTLogMapping[U2.currentChannel].MainCity then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAIHouseKeeperMsg"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_.chatMsg then
        return
      end
      if _ARG_0_.chatFrameItemBP then
        _ARG_0_.chatFrameItemBP:Close()
        _ARG_0_.chatFrameItemBP = nil
      end
      if _ARG_0_.chatMsg.selfMsg then
        if _ARG_1_ then
          _ARG_0_:_SetCommonMsg(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
          _ARG_1_.WidgetSwitcher_Effect:SetActiveWidgetIndex(0)
        end
        if _ARG_2_ then
          _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
        end
      else
        _ARG_0_:RefreshHouseKeeperHead(_ARG_2_)
        if _ARG_0_.chatMsg.content.newMsg then
          _ARG_4_:AddOnAnimationFinishedEvent(_ENV(222, 85, 132, 87, 38, 221, 221, 86, 43, 81, 178, 204, 152), _ARG_0_.OnAnimReplyingFinished, _ARG_0_)
          _ARG_1_.WidgetSwitcher_Effect:SetActiveWidgetIndex(1)
          _ARG_1_:PlayUserWidgetAnimation(_ARG_1_.Anim_Replying, 0, 1, 0, 1)
          _ARG_1_.Message_Normal:SetText((_ENV()))
          _ARG_1_.Message_Special:SetText((_ENV()))
          _ARG_0_.Chat_HouseKeeper_Item_UIBP = _ARG_4_
        else
          _ARG_0_:_RefreshHouseKeeperMsg(_ARG_1_, _ARG_4_)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPicShareMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if (_ARG_0_.chatMsg.content or {}).shareContentType == require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 74, 40, 79, 178, 193, 209, 191, 120, 140, 29, 110, 179, 70, 230, 216, 161, 117, 8, 107, 163, 211, 157, 185, 84, 146, 57, 105, 228, 127, 247, 203, 155, 105),
        U1(241, 72, 153)
      }))).Enum_ShareContentType.CS_ExhibitionHall and (_ARG_0_.chatMsg.content or {}).curUId ~= DataMgr.roleData.uid then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPureTextMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPureImageMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickedPureImage"] = function(_ARG_0_)
    do
      if (_ARG_0_.chatMsg.content.detail or _ENV()) == _ENV() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPureImage2Message"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNotifyMessage"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTemuInviteTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        _ARG_0_:SetWidgetVisible(_ARG_1_.Button_0, not _ARG_0_.chatMsg.selfMsg, true)
        _ARG_0_:SetWidgetVisible(_ARG_1_.SizeBox_Group, not _ARG_0_.chatMsg.selfMsg)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnclickJoinTemuTeam, _ARG_0_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTemuTaskRemindTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        _ARG_0_:SetWidgetVisible(_ARG_1_.Button_GoTry, true, true)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_GoTry, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnclickJumpTemu, _ARG_0_)
        _ARG_1_.TextBlock_OwnerText:SetText(U1.LocUtil.GetLocalizeResStr(527128))
        _ARG_1_.TextBlock_0:SetText(U1.LocUtil.GetLocalizeResStr(76859))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnclickJumpTemu"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        return
      end
      GlobalData.JumpUrl((U2(248, 90, 128, 95, 67, 160, 151, 25, 42, 71, 191, 215, 147, 169, 45, 212, 95, 59, 173, 56, 186, 143, 238, 127, 51, 5, 250, 139)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnclickJoinTemuTeam"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_temu):GetSelfTeamID() == nil and require((U2(252, 84, 128, 87, 22, 225, 150, 82, 38, 74, 183, 199, 160, 185, 100, 132, 3))).GetTableValue(_ARG_0_.chatMsg, U2(252, 84, 131, 78, 28, 225, 204), U2(240, 79, 133, 95, 11), (U2(248, 73, 130, 79, 9, 208, 209, 66))) ~= nil then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckTemuIsOpen"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(196, 104, 180, 103, 11, 234, 205, 85, 34, 119, 183, 203, 140, 184, 79, 142, 7, 106, 233, 85, 224, 203, 173, 123, 109, 123, 163, 215, 140, 183, 84, 152, 18, 110, 196, 105, 214, 223, 189, 104),
        U1(177)
      }))
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_temu):GetCurSeasonID() or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_temu):GetCurSeasonID() == 0 or require((U1(252, 84, 128, 87, 22, 225, 150, 82, 38, 74, 183, 199, 160, 185, 100, 132, 3))).GetTableValue(_ARG_1_, U1(252, 84, 131, 78, 28, 225, 204), U1(240, 79, 133, 95, 11), (U1(254, 88, 153, 83, 15, 230, 204, 95, 24, 65, 191))) ~= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_temu):GetCurSeasonID() then
        return false
      end
      if not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.Logic_temu):IsCurSeasonInTime() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWarmUpGroupInviteTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Self, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Other, true)
        end
        if _ARG_0_.chatMsg.content.other then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnclickJoinWarmUpGroupTeam"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        return
      end
      if not tonumber((require((U2(252, 84, 128, 87, 22, 225, 150, 82, 38, 74, 183, 199, 160, 185, 100, 132, 3))).GetTableValue(_ARG_0_.chatMsg, U2(252, 84, 131, 78, 28, 225, 204), U2(240, 79, 133, 95, 11), (U2(236, 92, 159, 85, 12, 255, 231, 79, 35))))) then
        return
      end
      if not ModuleManager.GetModule(ModuleManager.JumpModuleConfig.Logic_Warm_Up_Group):IsHaveTeam() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckWarmUpGroupIsOpen"] = function(_ARG_0_, _ARG_1_)
    do
      if not ModuleManager.GetModule(ModuleManager.JumpModuleConfig.Logic_Warm_Up_Group):CheckDataValid() then
        return true
      end
      do return ModuleManager.GetModule(ModuleManager.JumpModuleConfig.Logic_Warm_Up_Group):IsActivityOpen() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowReturnFlag"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_.SizeBox_Return then
        return
      end
      if not require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 242, 102, 237, 217, 186, 127, 50, 86, 175, 156, 131, 179, 103, 148, 28, 68, 226, 118, 253, 201, 170, 111),
        U1(250, 85, 137, 101, 26, 238, 202, 67)
      }))).IsRejoinPlayerForTag((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile):GetLocalProfile(_ARG_2_))) then
        return
      end
      if _ARG_2_ == tonumber(DataMgr.roleData.uid) then
      end
      if not _ARG_0_.returnTagItem then
        _ARG_0_.returnTagItem = _ARG_0_:CreateChildWindow(_ARG_1_.SizeBox_Return, UIManager.UI_Config.ReturnActivity_Player_Tag_Item, {
          uid = _ARG_2_,
          type = require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 239, 111, 253, 202, 186, 120, 8, 89, 168, 198, 134, 170, 105, 137, 6, 53, 255, 127, 237, 218, 170, 104),
            U1(192, 90, 142, 78, 16, 249, 209, 82, 62, 119, 182, 195, 156, 190, 127)
          }))).Enum_Tag_ShowType.Me,
          dir = 3,
          bOnDarkBg = true
        })
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowNewbieFlag"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_.SizeBox_NewTips then
        return
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 250, 120, 230, 200, 188, 126, 8, 72, 185, 221, 133, 185, 99, 137, 81, 117, 232, 109, 251, 198, 189, 89),
        U1(248, 78, 132, 94, 28, 208, 205, 82, 46, 68)
      }))).IsNewbie(_ARG_2_) then
        if not _ARG_0_.returnTagItem then
          _ARG_0_.newbieTag = _ARG_0_:CreateChildWindow(_ARG_1_.SizeBox_NewTips, UIManager.UI_Config.PartnerReadiness_NewTips_UIBP)
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNationalEsportsInviteTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(209, 90, 153, 83, 22, 225, 217, 74, 2, 91, 171, 205, 141, 184, 99, 164, 1, 125, 244, 126, 236, 235, 161, 102, 119, 74, 174, 199, 156, 185, 95, 145, 22, 104, 249, 69, 250, 199, 185, 114),
          U1(192, 82, 153, 95, 20, 161, 235, 67, 51, 102, 186, 214, 150, 163, 126, 140, 3, 78, 238, 122, 230, 205, 188, 101, 30, 86, 189, 219, 155, 185, 84, 148, 15)
        }))
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Left, false)
        _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Right, false)
        if _ARG_0_.chatMsg.selfMsg then
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Right, true)
        else
          _ARG_0_:SetWidgetVisible(_ARG_1_.Image_Left, true)
        end
        if _ARG_0_.chatMsg then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnclickJoinNationalEsports"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckNationalEsportsIsOpen"] = function(_ARG_0_, _ARG_1_)
    do
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCardCollectionSwapMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        return
      end
      if not {
        data = _ARG_0_.chatMsg.content.other
      } then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetGroupBuyMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if _ARG_1_ then
        _ARG_0_:SetWidgetVisible(_ARG_1_.CanvasPanel_All, false)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_GroupBuy, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGroupBuyGroup, _ARG_0_)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_Buy1, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGroupBuy1, _ARG_0_)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_Buy2, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGroupBuy2, _ARG_0_)
        _ARG_4_:AddControlEventByControl(_ARG_1_.Button_Pay, _ENV(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickGroupBuyPay, _ARG_0_)
        _ARG_0_:OnNewGroupBuyInfoRsp()
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBargainMessage"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_0_:_SetHeadBpBase(_ARG_2_, _ARG_5_)
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 236, 173, 98, 21, 89, 185, 213, 142, 181, 110, 176, 26, 104, 254, 123, 254, 202, 248, 104),
          U1(240, 27, 128, 73, 30, 237, 200)
        }))
        return
      end
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_Buy1, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBargainHelperList, _ARG_0_)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_Buy2, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBargainCutOrGo, _ARG_0_)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_0, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickBargainBuy, _ARG_0_)
      _ARG_4_:AddControlEventByControl(_ARG_1_.Button_2, U1(208, 85, 174, 86, 16, 236, 211, 67, 35), _ARG_0_.OnClickLimit, _ARG_0_)
      if _ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain_invite) then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnBargainInfoRsp"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.msgType ~= BargainFriendsMsgType and _ARG_0_.chatMsg.msgType ~= BargainCorpsMsgType and _ARG_0_.chatMsg.msgType ~= BargainChannelsMsgType then
        return
      end
      if not _ARG_0_:GetOrCreateMsgAndHeadBp() then
        return
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain) then
        return
      end
      if not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other) or not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id then
        return
      end
      _ARG_0_.bargain_info = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id)
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id) then
        return
      end
      if (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id).items and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id).items[1] and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id).items[1].item_id or 0) ~= 0 then
      end
      if _ARG_0_:GetOrCreateMsgAndHeadBp().TextBlock_6 then
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).friend_cuts then
          goto lbl_290
          ::lbl_290::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id).cost_id and U1.require((U2(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).GetItemSmallIcon2(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetGiftConfigById(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).package_id or U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).cfg_id or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id).cost_id) then
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):IsShow() then
      elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain).SERVER_STATUS.BOUGHT and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price <= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price then
      elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain).SERVER_STATUS.BOUGHT and not (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price <= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price) then
      elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price <= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price then
      else
      end
      if not true then
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain).SERVER_STATUS.BOUGHT and not (U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price <= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price) then
      elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain).SERVER_STATUS.BOUGHT and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price <= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price then
      elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).current_price <= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).floor_price then
      else
      end
      if _ARG_0_:GetOrCreateMsgAndHeadBp().TextBlock_Name then
        if U1.tonumber(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).owner_uid or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or 0) ~= 0 and U1.tonumber(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).owner_uid or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or 0) == U1.tonumber(U1.DataMgr.roleData.uid) then
          if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):GetChatInfoByBargainId((_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id).friend_cuts then
            goto lbl_625
            ::lbl_625::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = U1[188]
    end
  end,
  ["OnBargainHelpCutDetailUpdate"] = function(_ARG_0_)
    do
      if not _ARG_0_.bargain_info then
        return
      end
      if _ARG_0_.chatMsg.msgType ~= BargainFriendsMsgType and _ARG_0_.chatMsg.msgType ~= BargainCorpsMsgType and _ARG_0_.chatMsg.msgType ~= BargainChannelsMsgType then
        return
      end
      if not _ARG_0_:GetOrCreateMsgAndHeadBp() or not _ARG_0_:GetOrCreateMsgAndHeadBp().TextBlock_Name then
        return
      end
      if not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other) or not (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id then
        return
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain) then
        return
      end
      if not (U1.tonumber(_ARG_0_.bargain_info.owner_uid or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or 0) ~= 0 and U1.tonumber(_ARG_0_.bargain_info.owner_uid or (_ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or 0) == U1.tonumber(U1.DataMgr.roleData.uid)) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetBargainCountdown"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.bargainCountdownTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.bargainCountdownTimer)
        _ARG_0_.bargainCountdownTimer = nil
      end
      if not _ARG_2_ or not _ARG_2_.end_time then
        return
      end
      if not _ARG_2_.end_time then
        return
      end
      _ARG_0_.bargainCountdownTimer = _ARG_0_:AddTimerLoop(1, function()
        if not _ENV or not UTRichTextBlock_Status then
          if U1.bargainCountdownTimer then
            U1:RemoveTimer(U1.bargainCountdownTimer)
            U1.bargainCountdownTimer = nil
          end
          return
        end
        if U2 - U3.GetServerTimeInSec() <= 0 then
          if U1.bargainCountdownTimer then
            U1.bargainCountdownTimer = nil
          end
          return
        end
        return
      end, TIMER_INFINITE, 1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_SetBargainButtonSwitcher"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_, _ARG_7_, _ARG_8_)
    do
      if not _ARG_5_ then
        if _ARG_8_ or _ARG_2_ and _ARG_4_ then
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(BOUGHT)
        else
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(HELPER_LIST)
        end
        return
      end
      if not _ARG_6_ then
        if _ARG_8_ then
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(BOUGHT)
        else
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(HELPER_LIST)
        end
        return
      end
      if not _ARG_2_ and not _ARG_3_ and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain) and U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_bargain):IsHelpCutDailyLimitReached() then
        return
      end
      if _ARG_2_ then
        if _ARG_8_ then
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(BOUGHT)
        elseif _ARG_4_ then
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(BUY)
          _ARG_1_.TextBlock_0:SetText(U1.LocUtil.GetLocalizeResStr(166066))
        elseif _ARG_3_ then
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(HELPER_LIST)
          _ARG_1_.TextBlock_Buy1:SetText(U1.LocUtil.GetLocalizeResStr(167041))
        else
          _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(CUT_OR_GO)
          _ARG_1_.TextBlock_Buy2:SetText(U1.LocUtil.GetLocalizeResStr(167010))
        end
      elseif _ARG_8_ then
        _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(BOUGHT)
        _ARG_1_.TextBlock_Buy1:SetText(U1.LocUtil.GetLocalizeResStr(167041))
      elseif _ARG_4_ or _ARG_3_ then
        _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(HELPER_LIST)
        _ARG_1_.TextBlock_Buy1:SetText(U1.LocUtil.GetLocalizeResStr(167041))
      else
        _ARG_1_.WidgetSwitcher_2:SetActiveWidgetIndex(CUT_OR_GO)
        _ARG_1_.TextBlock_Buy2:SetText(U1.LocUtil.GetLocalizeResStr(167038) or U2(220, 78, 153))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBargainCutOrGo"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not GameStatus.IsInLobbyOrMainCity() then
        ShowNotice(157160)
        return
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).ShowDownloadTips(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPAK, U2(), nil, nil, nil, {bForceAsk = true}) then
        return
      end
      if not (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other) then
        return
      end
      if not (tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or _ARG_0_.bargain_info and _ARG_0_.bargain_info.owner_uid or 0) ~= 0 and tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or _ARG_0_.bargain_info and _ARG_0_.bargain_info.owner_uid or 0) == tonumber(DataMgr.roleData.uid)) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain):IsHelpCutDailyLimitReached() then
        return
      end
      if tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or _ARG_0_.bargain_info and _ARG_0_.bargain_info.owner_uid or 0) ~= 0 and tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or _ARG_0_.bargain_info and _ARG_0_.bargain_info.owner_uid or 0) == tonumber(DataMgr.roleData.uid) then
        if tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id or 0) == 0 then
          return
        end
      elseif not (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBargainBuy"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not GameStatus.IsInLobbyOrMainCity() then
        ShowNotice(157160)
        return
      end
      goto lbl_131
      if U1(192, 86, 140, 84, 24, 232, 221, 84) == UIManager.UI_Config.Discount_Bargain_UIBP.path then
      else
        ::lbl_131::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not true then
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).ShowDownloadTips(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPAK, U2(), nil, nil, nil, {bForceAsk = true}) then
        return
      end
      if tonumber(_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id or 0) == 0 then
        return
      end
      if _ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).bargain_id then
      else
      end
      if ((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain):GetActiveOrderByPackageId((tonumber(_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id or 0))) or nil) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain) and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain):GetActiveOrderByPackageId((tonumber(_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other and (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id or 0))) or nil).bargain_id or U1()) == U1() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickLimit"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      ShowNotice(9940224)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickBargainHelperList"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not GameStatus.IsInLobbyOrMainCity() then
        ShowNotice(157160)
        return
      end
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).ShowDownloadTips(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPACK, {
        UIManager.UI_Config.Discount_Member_Popup_UIBP.path
      }, nil, nil, nil, {bForceAsk = true}) then
        return
      end
      if not (_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other) then
        return
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain) and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_bargain):IsShow() then
        return
      end
      if tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or _ARG_0_.bargain_info and _ARG_0_.bargain_info.owner_uid or 0) ~= 0 and tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).owner_uid or _ARG_0_.bargain_info and _ARG_0_.bargain_info.owner_uid or 0) == tonumber(DataMgr.roleData.uid) then
        if tonumber((_ARG_0_.chatMsg and _ARG_0_.chatMsg.content and _ARG_0_.chatMsg.content.other).cfg_id or 0) == 0 then
          return
        end
      else
      end
      do return end
      _ARG_0_ = _ENV[220]
    end
  end,
  ["CheckTimer"] = function(_ARG_0_)
    do
      if _ARG_0_.GroupTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.GroupTimer)
        _ARG_0_.GroupTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnNewGroupBuyInfoRsp"] = function(_ARG_0_)
    do
      if _ARG_0_.chatMsg.msgType ~= GroupBuyFriendsMsgType and _ARG_0_.chatMsg.msgType ~= GroupBuyCorpsMsgType and _ARG_0_.chatMsg.msgType ~= GroupBuyChannelsMsgType then
        return
      end
      if not _ARG_0_:GetOrCreateMsgAndHeadBp() then
        return
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):IsShow() then
        return
      else
      end
      _ARG_0_.group_info = U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetChatInfoById(_ARG_0_.chatMsg.content.other.group_id)
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetChatInfoById(_ARG_0_.chatMsg.content.other.group_id) then
        return
      end
      if not U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id) then
        return
      end
      if U1.require((U2(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 234, 107, 251, 219, 186, 121, 53, 93, 229, 197, 142, 174, 100, 143, 16, 121, 232, 69, 253, 206, 172, 103))):HasItem(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).item_id) then
      else
      end
      if U1.CDataTable.GetTableData(U2(214, 79, 136, 87), U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).item_id) then
      end
      if U1.require((U2(252, 87, 132, 95, 23, 251, 150, 69, 40, 69, 182, 205, 145, 226, 101, 132, 48, 126, 233, 99, 229))).GetItemSmallIcon2(U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id) then
      end
      if _ARG_0_.group_info.merge_peer_creator_uid then
      elseif _ARG_0_.group_info.creator_uid == U1.tonumber(U1.DataMgr.roleData.uid) then
      else
      end
      goto lbl_672
      if U2(249, 82, 129, 95, 38, 232, 221, 82, 24, 95, 169, 195, 143).uid == U1.tonumber(U1.DataMgr.roleData.uid) then
      else
        ::lbl_672::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if _ARG_0_.group_info.status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying).GROUP_BUY_STATUS.FORMING then
        _ARG_0_.GroupTimer = _ARG_0_:AddTimerLoop(0, function()
          if group_info then
            if group_info.create_time and U1:GetItemLeftTime(group_info.create_time + U2.life_time, U3.end_time) - U4.GetServerTimeInSec() > 0 then
              if U1:GetItemLeftTime(group_info.create_time + U2.life_time, U3.end_time) - U4.GetServerTimeInSec() <= 86400 then
              else
              end
            else
            end
          end
          return
        end, 0, 1)
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftLimited((U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetPackageIDByID(_ARG_0_.group_info.group_cfg_id))) then
        elseif true then
        else
        end
        if 1 >= U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).group_member_count - #_ARG_0_.group_info.members then
        elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).group_member_count - #_ARG_0_.group_info.members <= 5 then
        elseif U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):ContainFriendInGroup(_ARG_0_.group_info.members) then
        else
        end
      elseif _ARG_0_.group_info.status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying).GROUP_BUY_STATUS.ACTIVE then
        goto lbl_978
        if U1.LocUtil.GetLocalizeResStr(166040).uid == U1.tonumber(U1.DataMgr.roleData.uid) and U1.LocUtil.GetLocalizeResStr(166040).merged_from then
        else
          ::lbl_978::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying):GetGroupInfoByGroupBuyID(U1.LocUtil.GetLocalizeResStr(166040).merged_from).buy_type == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying).CLIENT_BUY_TYPE.NOT_BUY then
          if true then
          else
          end
          if U1.tonumber(U1.DataMgr.roleData.uid) == _ARG_0_.group_info.creator_uid or U1.tonumber(U1.DataMgr.roleData.uid) == _ARG_0_.group_info.merge_peer_creator_uid then
          else
          end
        else
        end
      elseif _ARG_0_.group_info.status == U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_group_buying).GROUP_BUY_STATUS.FAILED then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGroupBuyGroup"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGroupBuy1"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).ShowDownloadTips(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPACK, {
        UIManager.UI_Config.GroupBuying_Invite_UIBP.path
      }, nil, nil, nil, {bForceAsk = true}) then
        return
      end
      if tonumber(DataMgr.roleData.uid) == _ARG_0_.group_info.creator_uid or tonumber(DataMgr.roleData.uid) == _ARG_0_.group_info.merge_peer_creator_uid then
      else
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).direct_buy_price > tonumber((require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 101, 228, 210, 167, 120, 121, 116, 164, 213, 134, 191, 95, 180, 11, 126, 224, 79, 237, 198, 180, 117))).GetItemCount(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id))) then
      else
      end
      if CDataTable.GetTableDataByFilter(U1(241, 94, 154, 101, 30, 253, 215, 83, 55, 119, 185, 215, 134, 147, 96, 140, 12, 96, 252, 109, 236, 224, 171, 121, 57, 94, 162, 213), U1(246, 95), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).id) and CDataTable.GetTableDataByFilter(U1(241, 94, 154, 101, 30, 253, 215, 83, 55, 119, 185, 215, 134, 147, 96, 140, 12, 96, 252, 109, 236, 224, 171, 121, 57, 94, 162, 213), U1(246, 95), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).id).cost_style_name then
      end
      if DataMgr.CheckIsNeedUSAPolicy() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id == require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 156, 163, 126, 139, 6, 108, 179, 73, 229, 214, 173, 120, 35, 117, 170, 209, 157, 179, 115, 211, 60, 116, 228, 116, 212, 206, 187, 116),
        U1(240)
      }))).Uc then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGroupBuy2"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).ShowDownloadTips(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPACK, {
        UIManager.UI_Config.GroupBuying_Invite_UIBP.path
      }, nil, nil, nil, {bForceAsk = true}) then
        return
      end
      if _ARG_0_.group_info.status == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying).GROUP_BUY_STATUS.FORMING and not ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftLimited((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetPackageIDByID(_ARG_0_.group_info.group_cfg_id))) then
        goto lbl_164
        if U1(192, 86, 140, 84, 24, 232, 221, 84).uid == tonumber(DataMgr.roleData.uid) then
        else
          ::lbl_164::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if true then
        else
          if require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 101, 228, 210, 167, 120, 121, 116, 164, 213, 134, 191, 95, 180, 11, 126, 224, 79, 237, 198, 180, 117))).GetItemCount(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying).DEPOSIT_DEDUCTION_VOUCHER_ID[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id]) >= ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying).gifts_config[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).package_id].member_uc then
          else
          end
          if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying).gifts_config[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).package_id].member_uc - require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 101, 228, 210, 167, 120, 121, 116, 164, 213, 134, 191, 95, 180, 11, 126, 224, 79, 237, 198, 180, 117))).GetItemCount(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying).DEPOSIT_DEDUCTION_VOUCHER_ID[ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id]) > tonumber((require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 101, 228, 210, 167, 120, 121, 116, 164, 213, 134, 191, 95, 180, 11, 126, 224, 79, 237, 198, 180, 117))).GetItemCount(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id))) then
          else
          end
          if DataMgr.CheckIsNeedUSAPolicy() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id == require((table.concat({
            U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 156, 163, 126, 139, 6, 108, 179, 73, 229, 214, 173, 120, 35, 117, 170, 209, 157, 179, 115, 211, 60, 116, 228, 116, 212, 206, 187, 116),
            U1(240)
          }))).Uc then
          end
        end
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickGroupBuyPay"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).ShowDownloadTips(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPACK, {
        UIManager.UI_Config.GroupBuying_Invite_UIBP.path
      }, nil, nil, nil, {bForceAsk = true}) then
        return
      end
      if tonumber(DataMgr.roleData.uid) == _ARG_0_.group_info.creator_uid or tonumber(DataMgr.roleData.uid) == _ARG_0_.group_info.merge_peer_creator_uid then
      else
      end
      if CDataTable.GetTableDataByFilter(U1(241, 94, 154, 101, 30, 253, 215, 83, 55, 119, 185, 215, 134, 147, 96, 140, 12, 96, 252, 109, 236, 224, 171, 121, 57, 94, 162, 213), U1(246, 95), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).id) and CDataTable.GetTableDataByFilter(U1(241, 94, 154, 101, 30, 253, 215, 83, 55, 119, 185, 215, 134, 147, 96, 140, 12, 96, 252, 109, 236, 224, 171, 121, 57, 94, 162, 213), U1(246, 95), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).id).cost_style_name then
      end
      if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).group_price - ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBaseConfigById((ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetPackageIDByID(_ARG_0_.group_info.group_cfg_id))).member_uc > tonumber((require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 254, 101, 228, 210, 167, 120, 121, 116, 164, 213, 134, 191, 95, 180, 11, 126, 224, 79, 237, 198, 180, 117))).GetItemCount(ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id))) then
      else
      end
      if DataMgr.CheckIsNeedUSAPolicy() and ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying):GetGiftBuyConfigById(_ARG_0_.group_info.group_cfg_id).cost_id == require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 156, 163, 126, 139, 6, 108, 179, 73, 229, 214, 173, 120, 35, 117, 170, 209, 157, 179, 115, 211, 60, 116, 228, 116, 212, 206, 187, 116),
        U1(240)
      }))).Uc then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenInvite"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:OnNewGroupBuyInfoRsp()
      if _ARG_3_.status == ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_group_buying).GROUP_BUY_STATUS.FORMING then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCardCollectionSwapRecord"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      if not _ARG_0_.chatMsg.content.other then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickCardCollectionSwapAccept"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not U1.IsValid() then
        ShowNotice(38768)
        return
      end
      if not _ARG_0_.chatMsg.content.other then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnJagerDownloadedUpdate"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(237, 94, 152, 73, 28, 208, 212, 79, 52, 92, 132, 193, 151, 173, 100, 178, 6, 127, 248, 103, 179, 240, 166, 92, 54, 95, 174, 192, 171, 179, 119, 147, 19, 116, 236, 126, 252, 203, 141, 118),
        U1(251, 90, 153, 95, 87)
      }))
      if U2.IsFITVersion() then
      elseif require((table.concat({
        U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 53, 253, 111, 255, 201, 189, 116),
        U1(192, 86, 140, 84, 24, 232, 221, 84)
      }))).GetState(require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadType.ODPAK, {_ARG_2_}) == require((U1(252, 87, 132, 95, 23, 251, 150, 85, 43, 93, 186, 140, 147, 163, 119, 132, 12, 37, 249, 101, 254, 209, 164, 121, 54, 92, 229, 194, 154, 186, 102, 152, 13, 68, 238, 117, 247, 220, 172))).ENUM_DownloadState.Done then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[90]
    end
  end
})) end
return
