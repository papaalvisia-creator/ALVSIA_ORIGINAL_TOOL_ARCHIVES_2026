local Featured_Comment_AuthorReply_Item_UIBP = {}
local REPLY_COMMENT_COLOR_WIDGETS = {
  "TextBlock_Author_Name",
  "TextBlock_Reply",
  "TextBlock_Reply_Arabic",
  "TextBlock_Reply_Time",
  "TextBlock_Support_Reply",
  "TextBlock_ExpandReply"
}
local comment_gradient_helper = require("client.slua.umg.ugc.comment.comment_gradient_helper")

function Featured_Comment_AuthorReply_Item_UIBP:ctor(_, transComp)
  self.transComp = transComp
  self.replyDetail = nil
  self.replyId = nil
  self.rootCommentID = nil
  self.replyIndex = 1
  self.replyIds = nil
  self.rootCommentInfo = nil
  self.bIsLastReply = false
  self.bIsSkinDark = true
  self.bIsSupported = false
end

function Featured_Comment_AuthorReply_Item_UIBP:RegistEvents()
  if self.UIRoot.Button_Support_2 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Support_2, self.OnClickSupport, self)
  end
  if self.UIRoot.Button_Reply then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Reply, self.OnClickReply, self)
  end
  if self.UIRoot.Button_Report_2 then
    self:AddOnClickedEventByControl(self.UIRoot.Button_Report_2, self.OnClickReport, self)
  end
  if self.UIRoot.Button_More_Reply then
    self:AddOnClickedEventByControl(self.UIRoot.Button_More_Reply, self.OnClickMore, self)
  end
  if self.UIRoot.Button_ExpandReply then
    self:AddOnClickedEventByControl(self.UIRoot.Button_ExpandReply, self.OnClickExpand, self)
  end
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SUPPORT_COMMENT_RES, self.OnSupportReplyRes, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_SUPPORT_REPLY_RES, self.OnSupportReplyRes, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_COMMENT_REPLY_LIST_RSP, self.OnReplyListRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_DELETE_COMMENT_REPLY_RSP, self.OnDeleteReplyRsp, self)
  self:AddCommonEvent(EVENTTYPE_UGC, EVENTID_UGC_BATCH_GET_COMMENT_DATA_RSP, self.OnReplyDetailRsp, self)
end

function Featured_Comment_AuthorReply_Item_UIBP:OnClickSupport()
  self:PlayAudio(sound_config.click_v1)
  local replyDetail = self.replyDetail
  if not replyDetail or not replyDetail.comment_id then
    return
  end
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local bMigration = replyDetail.migration_flag == true
  local targetCommentID = bMigration and replyDetail.root_comment_id or replyDetail.comment_id
  local optObj = bMigration and logic_ugc_comment_macro.SupportOptTarget.Reply or logic_ugc_comment_macro.SupportOptTarget.Comment
  local bSupported = bMigration and logic_ugc_comment:HaveSupportReply(replyDetail.comment_id) or logic_ugc_comment:HaveSupportComment(replyDetail.comment_id)
  local optType = bSupported and logic_ugc_comment_macro.SupportOptType.CancelSupport or logic_ugc_comment_macro.SupportOptType.Support
  local modInfo = logic_ugc_comment:GetModInfo(replyDetail.mod_id)
  local authorUid = modInfo and modInfo.base and modInfo.base.uid or nil
  logic_ugc_comment:send_ugc_support_comment_req(replyDetail.mod_id, targetCommentID, optType, optObj, nil, authorUid)
end

function Featured_Comment_AuthorReply_Item_UIBP:OnClickReply()
  self:PlayAudio(sound_config.click_v1)
  if not self.replyDetail then
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  logic_ugc_comment:TryShowReplyPopup(self.replyDetail.mod_id, self.rootCommentID, self.replyDetail.comment_id, self.replyDetail.uid)
end

function Featured_Comment_AuthorReply_Item_UIBP:OnClickReport()
  self:PlayAudio(sound_config.click_v1)
  if not self.replyDetail then
    return
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(self.replyDetail.uid)
  if not profile then
    return
  end
  local chatMacro = require("client.slua.logic.lobby_chat.chat_macro")
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  logic_ugc_comment:SetReportDataCache({
    comment_id = self.replyDetail.comment_id,
    mod_id = self.replyDetail.mod_id
  })
  local ChatMenuSystem = require("client.slua.logic.lobby_chat.logic_chat_menu")
  ChatMenuSystem.on_report_req(profile.uid, profile.nickName, self.replyDetail.comment_text or "", false, 0, chatMacro.CliSourceId.UGCCommentAuthorReply)
end

function Featured_Comment_AuthorReply_Item_UIBP:OnClickMore()
  self:PlayAudio(sound_config.click_v1)
  if not self.replyDetail then
    return
  end
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local bIsSelf = tonumber(self.replyDetail.uid) == tonumber(DataMgr.roleData.uid)
  local bIsAuthor = logic_ugc_comment:IsAuthor(self.replyDetail.mod_id)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local menuData = {
    comment_id = self.replyDetail.comment_id,
    root_comment_id = self.rootCommentID,
    commentDetail = self.replyDetail,
    is_reply_item = true,
    namedSlot = self.UIRoot.NamedSlot_MoreReply,
    visitorType = (bIsSelf or bIsAuthor) and logic_ugc_comment_macro.VisitorType.Author or logic_ugc_comment_macro.VisitorType.Passerby,
    MenuType = logic_ugc_comment_macro.MenuType.Reply
  }
  local parentUI = self:GetParentUI()
  while parentUI do
    if parentUI.ShowFeaturedCommentMenu then
      parentUI:ShowFeaturedCommentMenu(menuData)
      return
    end
    parentUI = parentUI.GetParentUI and parentUI:GetParentUI()
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:OnClickExpand()
  self:PlayAudio(sound_config.click_v1)
  self:PlayExpandUpdateAnim()
  if self.expandCallback then
    self.expandCallback()
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:PlayExpandUpdateAnim()
  if self.UIRoot.WidgetSwitcher_ExpandReply then
    self.UIRoot.WidgetSwitcher_ExpandReply:SetActiveWidgetIndex(1)
  end
  if self.UIRoot.TextBlock_Loading then
    self.UIRoot.TextBlock_Loading:SetText(LocUtil.GetLocalizeResStr(29677))
  end
  if self:IsAnimationPlaying("Anim_Update") then
    return
  end
  if self:PlayAnimation("Anim_Update", 0, 0, 0, 1) == -1 then
    log(bWriteLog and "Featured_Comment_AuthorReply_Item_UIBP:PlayExpandUpdateAnim Anim_Update missing")
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:OnSupportReplyRes(_, _, replyID)
  if tonumber(replyID) ~= tonumber(self.replyDetail and self.replyDetail.comment_id) then
    return
  end
  self:RefreshSupport()
end

function Featured_Comment_AuthorReply_Item_UIBP:OnReplyListRsp(_, _, commentID)
  if tonumber(commentID) ~= tonumber(self.rootCommentID) then
    return
  end
  self:RefreshExpand()
end

function Featured_Comment_AuthorReply_Item_UIBP:OnReplyDetailRsp()
  if self.replyDetail or not self.replyId then
    return
  end
  local logic_ugc_comment_reply = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_reply)
  self.replyDetail = logic_ugc_comment_reply:GetReplyDetail(self.replyId)
  if not self.replyDetail then
    return
  end
  self:UpdateUI()
  self:RefreshExpand()
  self:NotifyFallItemResize()
end

function Featured_Comment_AuthorReply_Item_UIBP:NotifyFallItemResize()
  local parentUI = self:GetParentUI()
  while parentUI do
    if parentUI.GetLoopScrollBox and parentUI.index then
      local loopScrollBox = parentUI:GetLoopScrollBox()
      if loopScrollBox and loopScrollBox.RefreshItem then
        loopScrollBox:RefreshItem(parentUI.index)
      end
      return
    end
    parentUI = parentUI.GetParentUI and parentUI:GetParentUI()
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:OnDeleteReplyRsp(_, _, commentID)
  if tonumber(commentID) ~= tonumber(self.rootCommentID) then
    return
  end
  local parentUI = self:GetParentUI()
  while parentUI do
    if parentUI.RefreshFeaturedCommentList then
      parentUI:RefreshFeaturedCommentList()
      return
    end
    parentUI = parentUI.GetParentUI and parentUI:GetParentUI()
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:SetData(replyId, rootCommentID, bIsLastReply, expandCallback, replyIndex, replyIds, rootCommentInfo)
  self.replyId = replyId
  self.rootCommentID = rootCommentID
  self.bIsLastReply = bIsLastReply == true
  self.expandCallback = expandCallback
  self.replyIndex = tonumber(replyIndex) or 1
  self.replyIds = replyIds
  self.rootCommentInfo = rootCommentInfo
  local logic_ugc_comment_reply = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_reply)
  self.replyDetail = logic_ugc_comment_reply:GetReplyDetail(replyId)
  if not self.replyDetail then
    self:ClearShow()
    local logic_ugc_comment_detail = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_detail)
    local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
    logic_ugc_comment_detail:send_batch_get_comment_data_req({replyId}, false, logic_ugc_comment_macro.ReqDetailSource.CommentReply)
    return
  end
  self:UpdateUI()
  self:RefreshExpand()
end

function Featured_Comment_AuthorReply_Item_UIBP:ClearShow()
  if self.UIRoot.TextBlock_Author_Name then
    self.UIRoot.TextBlock_Author_Name:SetText("")
  end
  if self.UIRoot.TextBlock_Reply then
    self.UIRoot.TextBlock_Reply:SetText("")
  end
  if self.UIRoot.TextBlock_Reply_Time then
    self.UIRoot.TextBlock_Reply_Time:SetText("")
  end
  if self.UIRoot.CanvasPanel_Author_2 then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_Author_2, false)
  end
  if self.UIRoot.CanvasPanel_ExpandReply then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_ExpandReply, false)
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:UpdateUI()
  if not self.replyDetail then
    return
  end
  self:RefreshVisitor()
  self:RefreshReplyContent()
  self:RefreshAuthorMark()
  self:RefreshReplyTime()
  self:RefreshSupport()
  local bIsSelfReply = tonumber(self.replyDetail.uid) == tonumber(DataMgr.roleData.uid)
  self:SetWidgetVisible(self.UIRoot.Button_Report_2, not bIsSelfReply, true)
  self:RefreshReplySkin()
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshVisitor()
  if not self.UIRoot.TextBlock_Author_Name then
    return
  end
  local replyUid = self.replyDetail.uid
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(replyUid)
  if profile then
    self.UIRoot.TextBlock_Author_Name:SetText(profile.nickName or "")
    return
  end
  local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
  logic_profile_get_wrap.GetNormalProfiles({replyUid}, function()
    if not (slua.isValid(self.UIRoot) and self.replyDetail) or self.replyDetail.uid ~= replyUid then
      return
    end
    local innerLogicProfile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local innerProfile = innerLogicProfile:GetLocalProfile(replyUid)
    if innerProfile and self.UIRoot.TextBlock_Author_Name then
      self.UIRoot.TextBlock_Author_Name:SetText(innerProfile.nickName or "")
    end
  end, Enum_PROFILE_REPORT_CFG.UGC_COMMENT, 0, true)
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshReplyContent()
  local replyDetail = self.replyDetail
  local replyText = replyDetail.comment_text or ""
  log(bWriteLog and string.format("Featured_Comment_AuthorReply_Item_UIBP:RefreshReplyContent replyID:%s refCommentID:%s refUid:%s rootCommentID:%s", tostring(replyDetail.comment_id), tostring(replyDetail.ref_comment_id), tostring(replyDetail.ref_uid), tostring(self.rootCommentID)))
  replyText = self.transComp and self.transComp:GetTextAndSetOneTranslateData(replyText, {
    index = self.index
  }) or replyText
  local refCommentID = tonumber(replyDetail.ref_comment_id)
  local bReplyRootComment = not refCommentID or refCommentID == tonumber(self.rootCommentID)
  local refUid = not bReplyRootComment and (replyDetail.ref_uid or replyDetail.ref_comment_id and self:GetRefUidByRefCommentID(replyDetail.ref_comment_id))
  if refUid then
    replyDetail.ref_uid = refUid
    local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
    local refProfile = logic_profile:GetLocalProfile(refUid)
    if refProfile then
      local refName = refProfile.nickName or ""
      replyText = LocUtil.LocalizeResFormat(818744, refName, replyText)
    else
      local replyId = replyDetail.comment_id
      local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
      logic_profile_get_wrap.GetNormalProfiles({refUid}, function()
        if not (slua.isValid(self.UIRoot) and self.replyDetail) or tonumber(self.replyDetail.comment_id) ~= tonumber(replyId) then
          return
        end
        self:RefreshReplyContent()
      end, Enum_PROFILE_REPORT_CFG.UGC_COMMENT, 0, true)
    end
  end
  self.UIRoot.TextBlock_Reply:SetText(replyText)
end

function Featured_Comment_AuthorReply_Item_UIBP:GetRefUidByRefCommentID(refCommentID)
  local logic_ugc_comment_detail = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_detail)
  local refCommentDetail = logic_ugc_comment_detail:GetCommentDetail(refCommentID)
  log(bWriteLog and string.format("Featured_Comment_AuthorReply_Item_UIBP:GetRefUidByRefCommentID refCommentID:%s hasDetail:%s", tostring(refCommentID), tostring(refCommentDetail ~= nil)))
  if refCommentDetail and refCommentDetail.uid then
    return refCommentDetail.uid
  end
  if tonumber(refCommentID) == tonumber(self.rootCommentID) then
    local rootCommentDetail = logic_ugc_comment_detail:GetCommentDetail(self.rootCommentID)
    return rootCommentDetail and rootCommentDetail.uid
  end
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  logic_ugc_comment_detail:send_batch_get_comment_data_req({refCommentID}, false, logic_ugc_comment_macro.ReqDetailSource.CommentReply)
  return nil
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshAuthorMark()
  local bIsAuthorReply = self.replyDetail.is_author_reply == true
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_Author_2, bIsAuthorReply)
  if bIsAuthorReply and self.UIRoot.TextBlock_4 then
    self.UIRoot.TextBlock_4:SetText(LocUtil.GetLocalizeResStr(65154))
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshReplyTime()
  local logic_ugc_comment_util = require("client.slua.logic.ugc.comment.logic_ugc_comment_util")
  local timeStr = logic_ugc_comment_util:GetCommentTime(self.replyDetail.comment_time)
  self.UIRoot.TextBlock_Reply_Time:SetText(timeStr)
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshSupport()
  local logic_ugc_comment = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment)
  local logic_ugc_comment_reply = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_reply)
  self.replyDetail = logic_ugc_comment_reply:GetReplyDetail(self.replyId) or self.replyDetail
  local supportCount = self.replyDetail.support_count or 0
  if supportCount == 0 then
    self:SetWidgetVisible(self.UIRoot.TextBlock_Support_Reply, false)
  else
    self:SetWidgetVisible(self.UIRoot.TextBlock_Support_Reply, true)
    local StringUtil = require("common.string_util")
    self.UIRoot.TextBlock_Support_Reply:SetText(StringUtil.FormatNum_KMB(supportCount))
  end
  local bMigration = self.replyDetail.migration_flag == true
  local bSupported = bMigration and logic_ugc_comment:HaveSupportReply(self.replyDetail.comment_id) or logic_ugc_comment:HaveSupportComment(self.replyDetail.comment_id)
  if self.UIRoot.WidgetSwitcher_Support_Reply then
    self.UIRoot.WidgetSwitcher_Support_Reply:SetActiveWidgetIndex(0)
  end
  self.bIsSupported = bSupported
  self:ApplyGoodColor()
end

function Featured_Comment_AuthorReply_Item_UIBP:ApplyGoodColor()
  local goodImage = self.UIRoot.Image_Good03
  if goodImage and slua.isValid(goodImage) and goodImage.SetActiveColorIndex then
    goodImage:SetActiveColorIndex((self.bIsSkinDark and 0 or 2) + (self.bIsSupported and 1 or 0))
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshExpand()
  if not self.UIRoot.CanvasPanel_ExpandReply then
    return
  end
  if not self.bIsLastReply or not self.rootCommentID then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_ExpandReply, false)
    return
  end
  local logic_ugc_comment_reply = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_reply)
  local replyCount = logic_ugc_comment_reply:GetReplyCount(self.rootCommentID)
  local loadedCount = logic_ugc_comment_reply:GetDisplayedReplyCount(self.rootCommentID)
  local remainCount = math.max(replyCount - loadedCount, 0)
  local bHasMore = 0 < remainCount or logic_ugc_comment_reply:HasMoreReply(self.rootCommentID)
  if not bHasMore then
    self:SetWidgetVisible(self.UIRoot.CanvasPanel_ExpandReply, false)
    return
  end
  self:SetWidgetVisible(self.UIRoot.CanvasPanel_ExpandReply, true)
  local bIsLoadingReply = logic_ugc_comment_reply:IsLoading(self.rootCommentID)
  if self.UIRoot.WidgetSwitcher_ExpandReply then
    self.UIRoot.WidgetSwitcher_ExpandReply:SetActiveWidgetIndex(bIsLoadingReply and 1 or 0)
  end
  if bIsLoadingReply then
    self:PlayExpandUpdateAnim()
  else
    self:StopAnimation("Anim_Update")
  end
  if self.UIRoot.TextBlock_ExpandReply then
    local showCount = math.min(remainCount, 999)
    if 0 < showCount then
      self.UIRoot.TextBlock_ExpandReply:SetText(LocUtil.LocalizeResFormat(818742, showCount))
    else
      self.UIRoot.TextBlock_ExpandReply:SetText(LocUtil.GetLocalizeResStr(818743))
    end
  end
end

function Featured_Comment_AuthorReply_Item_UIBP:ApplySkinColor(bIsSkinDark)
  self.bIsSkinDark = bIsSkinDark
  local colorIndex = bIsSkinDark and 0 or 1
  for _, widgetName in ipairs(REPLY_COMMENT_COLOR_WIDGETS) do
    local widget = self.UIRoot[widgetName]
    if widget and slua.isValid(widget) and widget.SetActiveColorIndex then
      widget:SetActiveColorIndex(colorIndex)
    end
  end
  self:ApplyGoodColor()
end

function Featured_Comment_AuthorReply_Item_UIBP:GetRootCommentUid()
  local logic_ugc_comment_detail = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_comment_detail)
  local rootDetail = logic_ugc_comment_detail:GetCommentDetail(self.rootCommentID) or self.rootCommentInfo
  return rootDetail and tonumber(rootDetail.uid)
end

function Featured_Comment_AuthorReply_Item_UIBP:RefreshReplySkin()
  self:ApplySkinColor(true)
  comment_gradient_helper.Hide(self, self.UIRoot.Image_Gradient)
  local skinImage = self.UIRoot.Image_SkinBg02
  if skinImage and slua.isValid(skinImage) then
    skinImage:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  end
  local rootUid = self:GetRootCommentUid()
  if not rootUid then
    return
  end
  local logic_profile = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_profile)
  local profile = logic_profile:GetLocalProfile(rootUid)
  if profile then
    self:ApplyRootSkin(profile)
    return
  end
  local replyId = self.replyId
  local logic_profile_get_wrap = require("client.slua.logic.user.profile.logic_profile_get_wrap")
  logic_profile_get_wrap.GetNormalProfiles({rootUid}, function()
    if not slua.isValid(self.UIRoot) or self.replyId ~= replyId then
      return
    end
    local innerProfile = logic_profile:GetLocalProfile(rootUid)
    if innerProfile then
      self:ApplyRootSkin(innerProfile)
    end
  end, Enum_PROFILE_REPORT_CFG.UGC_COMMENT, 0, true)
end

function Featured_Comment_AuthorReply_Item_UIBP:ApplyRootSkin(rootProfile)
  local logic_ugc_comment_macro = require("client.slua.logic.ugc.comment.logic_ugc_comment_macro")
  local commentSkinList = rootProfile.ugc_personal_dress and rootProfile.ugc_personal_dress[logic_ugc_comment_macro.CommentSkinSubTabID]
  local commentSkinID = tonumber(commentSkinList and commentSkinList[1])
  if not commentSkinID or commentSkinID <= 0 then
    return
  end
  local logic_ugc_inventory = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_ugc_inventory)
  local skinData = logic_ugc_inventory:GetPlayerCommentData(commentSkinID)
  if not skinData then
    return
  end
  if not logic_ugc_inventory:IsPlayerCommentSkinReady(skinData) then
    log(bWriteLog and string.format("Featured_Comment_AuthorReply_Item_UIBP:ApplyRootSkin root skin res not ready, skip gradient. id=%s", tostring(skinData.ID)))
    return
  end
  self:ApplySkinColor(tonumber(skinData.TxtColor) == 2)
  local chain = comment_gradient_helper.NewChain(self.rootCommentID, self.replyIds, self.replyIndex + 1)
  comment_gradient_helper.Apply(self, self.UIRoot.Image_Gradient, skinData, chain)
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
local CFeatured_Comment_AuthorReply_Item_UIBP = class(ui_base, nil, Featured_Comment_AuthorReply_Item_UIBP)
return CFeatured_Comment_AuthorReply_Item_UIBP
