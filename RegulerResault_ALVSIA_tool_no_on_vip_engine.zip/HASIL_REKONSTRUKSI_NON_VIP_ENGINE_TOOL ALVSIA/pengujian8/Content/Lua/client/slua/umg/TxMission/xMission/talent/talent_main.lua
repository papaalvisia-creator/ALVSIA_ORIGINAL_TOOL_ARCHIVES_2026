do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(196, 36, 122, 1, 231)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(196, 36, 114, 23, 250, 68, 38, 213, 197, 86, 148, 152, 65, 162, 99, 76, 37, 25, 6, 39, 19, 111, 10, 253, 151, 81, 132, 164, 65))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.TreeList = {}
      _ARG_0_.pageNum = _ENV:GePageNum()
      _ARG_0_.selectTalentNode = nil
      _ARG_0_.selectTalentId = nil
      _ARG_0_.jumpInfo = _ARG_2_
      _ARG_0_.Jumpout = false
      _ARG_0_.TalentList = {}
      _ARG_0_.detailVisible = false
      _ARG_0_.treePan = {
        x = 0,
        y = 0,
        dragging = false,
        moved = false,
        lastX = 0,
        lastY = 0
      }
      _ARG_0_.treeScale = 1
      _ARG_0_.appliedScale = 1
      _ARG_0_._appliedPanX = 0
      _ARG_0_._appliedPanY = 0
      _ARG_0_.pinchAccum = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnInitialize"] = function(_ARG_0_)
    do
      __super.OnInitialize(_ARG_0_)
      _ARG_0_:InitMain()
      _ARG_0_:InitTalentTrees()
      _ARG_0_:InitTabComboBox()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Reset, _ARG_0_.OnResetClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Use, _ARG_0_.OnUseClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Close, _ARG_0_.OnCloseClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_QA, _ARG_0_.OnQAClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Minus, _ARG_0_.OnMinusClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Add, _ARG_0_.OnAddClick, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_LeftPoint, _ARG_0_.OnButton_LeftPoint, _ARG_0_)
      _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_RS, _ARG_0_.OnButton_RS, _ARG_0_)
      if _ARG_0_.UIRoot.Button_WeekendHelp then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_WeekendHelp, _ARG_0_.OnButton_WeekendHelp, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_Tips1 then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Tips1, _ARG_0_.OnButton_Tips1Click, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_Tips2 then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_Tips2, _ARG_0_.OnButton_Tips2Click, _ARG_0_)
      end
      if _ARG_0_.UIRoot.Button_TipsClose then
        _ARG_0_:AddOnClickedEventByControl(_ARG_0_.UIRoot.Button_TipsClose, _ARG_0_.OnButton_TipsCloseClick, _ARG_0_)
      end
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_TALENT_DATA_READY, _ARG_0_.OnDataReady, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_TALENT_ITEM_CLICK, _ARG_0_.OnTalentSelect, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_T_XMISSION, U1.EVENTID_XMISSION_TALENT_APPLY_CONFIG, _ARG_0_.OnApplyConfig, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostInitialize"] = function(_ARG_0_)
    do
      __super.OnPostInitialize(_ARG_0_)
      U1:RequireTalentData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnShow"] = function(_ARG_0_)
    do
      __super.OnShow(_ARG_0_)
      _ARG_0_._scaleRemembered = false
      _ARG_0_._focusCentered = false
      _ARG_0_._focusFadePending = false
      _ARG_0_._userOpenedDetail = false
      if U1 and U1.talentId then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnHide"] = function(_ARG_0_)
    do
      _ARG_0_:RememberTreeScale()
      _ARG_0_._reopenTalentId = nil
      _ARG_0_._focusFadePending = false
      _ARG_0_:ResetTreeView()
      __super.OnHide(_ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopTreeGesture"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.treePan.dragging = false
      _ARG_0_.treePan.moved = false
      _ARG_0_.treePan.kind = nil
      _ARG_0_.treePan.touchIndex = nil
      _ARG_0_.treePan.fromPoll = false
      _ARG_0_.pinchAccum = 0
      if _ARG_0_.treePinch then
        _ARG_0_.treePinch.active = false
      end
      if _ARG_0_.panTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.panTimer)
        _ARG_0_.panTimer = nil
      end
      if _ARG_0_.pinchTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.pinchTimer)
        _ARG_0_.pinchTimer = nil
      end
      if not _ARG_1_ and _ARG_0_._initialViewTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._initialViewTimer)
        _ARG_0_._initialViewTimer = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RememberTalentFocus"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_1_ = tonumber(_ARG_1_)
      if not _ARG_1_ or _ARG_1_ <= 0 then
        return
      end
      if not U1 then
        U1 = {
          talentId = _ARG_1_,
          scale = _ARG_0_.treeScale
        }
      else
        U1.talentId = _ARG_1_
        if not U1.scale or 0 >= U1.scale then
          U1.scale = _ARG_0_.treeScale
        end
      end
      if _ARG_0_._reopenTalentId then
        _ARG_0_._reopenTalentId = _ARG_1_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RememberTreeScale"] = function(_ARG_0_)
    do
      if not (not _ARG_0_._scaleRemembered and _ENV) or not talentId then
        return
      end
      _ARG_0_._scaleRemembered = true
      if _ARG_0_.treeScale and _ARG_0_.treeScale > 0 then
        scale = _ARG_0_.treeScale
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayFadein"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot or not _ARG_0_.UIRoot.Fadein then
        return
      end
      _ARG_0_:PlayUserWidgetAnimation(_ARG_0_.UIRoot.Fadein, 0, 1, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ScheduleEntrance"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_._initialViewTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._initialViewTimer)
        _ARG_0_._initialViewTimer = nil
      end
      if _ARG_1_ then
        _ARG_0_:PlayFadein()
      end
      _ARG_0_._initialViewTimer = _ARG_0_:AddTimerOnce(0, function()
        _initialViewTimer = nil
        if U1 then
          U1()
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyInitialTreeView"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_:StopTreeGesture()
      _ARG_0_._reopenTalentId = nil
      _ARG_0_.treeScale = _ARG_0_:GetTreeScaleRange()
      _ARG_0_.treePan.x = 0
      _ARG_0_.treePan.y = 0
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaceMiddleTreeAboveButton"] = function(_ARG_0_)
    do
      if not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02 and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_RS) or not _ARG_0_:GetTreeViewportWidget() then
        return
      end
      if not ((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02).GetCachedGeometry and (_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_RS).GetCachedGeometry) or not _ARG_0_:GetTreeViewportWidget().GetCachedGeometry then
        return
      end
      if not (GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())) and GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry()))) or GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X < 1 or 1 > GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y or not GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_RS):GetCachedGeometry())) then
        return
      end
      if not AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X + GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X * 0.5, GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y + GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y)) or not AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), (GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_RS):GetCachedGeometry())))) then
        return
      end
      _ARG_0_.treePan.x = (_ARG_0_.treePan.x or 0) + (_ARG_0_:GetTreeViewportSize() * 0.5 - AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X + GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X * 0.5, GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y + GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y)).X)
      _ARG_0_.treePan.y = (_ARG_0_.treePan.y or 0) + (AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), (GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.Button_RS):GetCachedGeometry())))).Y - 50 - AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X + GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).X * 0.5, GetAbsolutePosition(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y + GetAbsoluteSize(((_ARG_0_.UIRoot and _ARG_0_.UIRoot.TalentTree02):GetCachedGeometry())).Y)).Y)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyFocusedTreeView"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_:StopTreeGesture()
      _ARG_2_ = tonumber(_ARG_2_) or _ARG_0_:GetTreeScaleRange()
      if _ARG_0_:GetTreeScaleRange() > _ARG_2_ then
        _ARG_2_ = _ARG_0_:GetTreeScaleRange()
      end
      if _ARG_0_:GetTreeScaleRange() < _ARG_2_ then
        _ARG_2_ = _ARG_0_:GetTreeScaleRange()
      end
      _ARG_0_.treeScale = _ARG_2_
      _ARG_0_.treePan.x = 0
      _ARG_0_.treePan.y = 0
      _ARG_0_._reopenTalentId = _ARG_1_
      _ARG_0_._focusCentered = false
      _ARG_0_._focusCenterPending = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CenterWidgetInTreeView"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_0_:GetTreeViewportWidget() and _ARG_1_.GetCachedGeometry) or not _ARG_0_:GetTreeViewportWidget().GetCachedGeometry then
        return false
      end
      if not (GetAbsolutePosition((_ARG_1_:GetCachedGeometry())) and GetAbsoluteSize((_ARG_1_:GetCachedGeometry()))) or GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X < 1 or 1 > GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y then
        return false
      end
      if not AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)) then
        return false
      end
      _ARG_0_.treePan.x = (_ARG_0_.treePan.x or 0) + (_ARG_0_:GetTreeViewportSize() * 0.5 - AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)).X)
      _ARG_0_.treePan.y = (_ARG_0_.treePan.y or 0) + (_ARG_0_:GetTreeViewportSize() * 0.5 - AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)).Y)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OpenFocusedTalentDetail"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not _ENV:GetNodeByTalentId(_ARG_1_) then
        return false
      end
      _ARG_0_.selectTalentItem = _ARG_0_:GetItemByTalentId(_ARG_1_)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetTreeView"] = function(_ARG_0_)
    do
      _ARG_0_.treePan.dragging = false
      _ARG_0_.treePan.moved = false
      _ARG_0_.treePan.kind = nil
      _ARG_0_.treePan.touchIndex = nil
      _ARG_0_.treePan.fromPoll = false
      _ARG_0_.treePan.x = 0
      _ARG_0_.treePan.y = 0
      _ARG_0_.treeScale = 1
      _ARG_0_.appliedScale = 1
      _ARG_0_._appliedPanX = 0
      _ARG_0_._appliedPanY = 0
      _ARG_0_.pinchAccum = 0
      if _ARG_0_.treePinch then
        _ARG_0_.treePinch.active = false
      end
      if _ARG_0_.panTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.panTimer)
        _ARG_0_.panTimer = nil
      end
      if _ARG_0_.pinchTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.pinchTimer)
        _ARG_0_.pinchTimer = nil
      end
      if not _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))) or not _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot then
        return
      end
      if not U1.pcall(function()
        _ENV:SetUserSpecifiedScale(1)
        return
      end) then
      end
      _ARG_0_._appliedPanX = 0
      _ARG_0_._appliedPanY = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FillRootScaleBox"] = function(_ARG_0_)
    do
      if not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.ScaleBox_0 and slua.isValid(_ARG_0_.UIRoot and _ARG_0_.UIRoot.ScaleBox_0)) or not (_ARG_0_.UIRoot and _ARG_0_.UIRoot.ScaleBox_0).Slot then
        return
      end
      if not pcall(function()
        if SetSupportNotch then
          _ENV:SetSupportNotch(false)
        end
        if SetAnchors then
          _ENV:SetAnchors(U1.FAnchors(0, 0, 1, 1))
        end
        if SetOffsets then
          _ENV:SetOffsets(U1.FMargin(0, 0, 0, 0))
        end
        if SetAutoSize then
          _ENV:SetAutoSize(false)
        end
        return
      end) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTreeZoomLayout"] = function(_ARG_0_)
    do
      _ARG_0_:FillRootScaleBox()
      _ARG_0_:PinTreeEdgeMasks()
      _ARG_0_:EnableEditorEmptyDrag()
      _ARG_0_:InflateTreeCullBounds()
      _ARG_0_:AddTimerOnce(0, function()
        _ENV:FillRootScaleBox()
        if not treeRest then
          _ENV:CacheTreeRestPose()
        end
        _ENV:LogTreeCullInfo()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InflateTreeCullBounds"] = function(_ARG_0_)
    do
      if not (_ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))) and _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot) or not _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot.SetSize then
        return
      end
      if not U1.pcall(function()
        if (Slot.GetSize and Slot:GetSize() and (Slot.GetSize and Slot:GetSize()).X or 0) >= U1 and (Slot.GetSize and Slot:GetSize() and (Slot.GetSize and Slot:GetSize()).Y or 0) >= U2 then
          return
        end
        U3._treeSlotOrigW = U3._treeSlotOrigW or Slot.GetSize and Slot:GetSize() and (Slot.GetSize and Slot:GetSize()).X or 0
        U3._treeSlotOrigH = U3._treeSlotOrigH or Slot.GetSize and Slot:GetSize() and (Slot.GetSize and Slot:GetSize()).Y or 0
        return
      end) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LogTreeCullInfo"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ENV[255]
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PinTreeEdgeMasks"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartWheelPoll"] = function(_ARG_0_)
    do
      if not IsEditor then
        return
      end
      if _ARG_0_.wheelPollTimer then
        return
      end
      _ARG_0_.wheelPollTimer = _ARG_0_:AddTimerLoop(0, function()
        if not U2.slua.isValid((GetPlayerController(U1.GetGameInstance(), 0))) then
          return
        end
        if U3:GetActiveTalentGuideStep() then
          U3._lastWheelAxis = U3:GetMouseWheelAxis((GetPlayerController(U1.GetGameInstance(), 0)))
          return
        end
        if U3:GetMouseWheelAxis((GetPlayerController(U1.GetGameInstance(), 0))) ~= 0 and (U3._lastWheelAxis or 0) == 0 then
        end
        U3._lastWheelAxis = U3:GetMouseWheelAxis((GetPlayerController(U1.GetGameInstance(), 0))), 0 < U3:GetMouseWheelAxis((GetPlayerController(U1.GetGameInstance(), 0))) and U4 or 1 / U4, U3:GetPointerViewportPos()
        return
      end, TIMER_INFINITE, 0.05)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMouseWheelAxis"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_._wheelAxisMode == _ENV(197, 58, 116, 25, 241, 94) then
        return 0
      end
      if _ARG_0_._wheelAxisMode == _ENV(198, 38, 122, 30, 251, 87) then
        return _ARG_1_:GetInputAnalogKeyState(U1) or 0
      end
      if _ARG_0_._wheelAxisMode == _ENV(209, 45, 120, 6, 251, 66) then
        return _ARG_1_:GetInputVectorKeyState(U1) and _ARG_1_:GetInputVectorKeyState(U1).X or 0
      end
      if _ARG_1_.GetInputAnalogKeyState and U2.pcall(_ARG_1_.GetInputAnalogKeyState, _ARG_1_, U1) then
        _ARG_0_._wheelAxisMode = _ENV(198, 38, 122, 30, 251, 87)
        return U2.pcall(_ARG_1_.GetInputAnalogKeyState, _ARG_1_, U1) or 0
      end
      if _ARG_1_.GetInputVectorKeyState and U2.pcall(_ARG_1_.GetInputVectorKeyState, _ARG_1_, U1) then
        _ARG_0_._wheelAxisMode = _ENV(209, 45, 120, 6, 251, 66)
        return U2.pcall(_ARG_1_.GetInputVectorKeyState, _ARG_1_, U1) and U2.pcall(_ARG_1_.GetInputVectorKeyState, _ARG_1_, U1).X or 0
      end
      _ARG_0_._wheelAxisMode = _ENV(197, 58, 116, 25, 241, 94)
      do return 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartPanInputPoll"] = function(_ARG_0_)
    do
      if _ARG_0_.panPollTimer then
        return
      end
      if not U2.slua.isValid((GetPlayerController(U1.GetGameInstance(), 0))) then
        return
      end
      _ARG_0_._mouseWasDown = _ARG_0_:IsMouseLeftDown((GetPlayerController(U1.GetGameInstance(), 0)))
      _ARG_0_._touchWasDown = {}
      _ARG_0_._touchSuppress = {}
      if not U2.IsEditor then
        _ARG_0_ = _ARG_0_
        _ARG_0_._touchWasDown[nil] = _ARG_0_:ReadTouch(GetPlayerController(U1.GetGameInstance(), 0), nil)
        _ARG_0_._touchSuppress[nil] = _ARG_0_:ReadTouch(GetPlayerController(U1.GetGameInstance(), 0), nil)
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.panPollTimer = _ARG_0_:AddTimerLoop(0, function()
        _ENV:PollPanInput()
        return
      end, U2.TIMER_INFINITE, 0)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnableEditorEmptyDrag"] = function(_ARG_0_)
    do
      if not IsEditor then
        return
      end
      if _ARG_0_:GetTreeControl((U1(238, 37, 122, 21, 241, 111, 49))) then
        if _ARG_0_:GetTreeControl((U1(238, 37, 122, 21, 241, 111, 49))).SetVisibility_V2 then
        else
        end
      end
      if not (not _ARG_0_:GetTreeControl((U1(229, 39, 105, 22, 241, 66, 87, 226, 219, 66, 146))) and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Border_Drag and slua.isValid(not _ARG_0_:GetTreeControl((U1(229, 39, 105, 22, 241, 66, 87, 226, 219, 66, 146))) and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Border_Drag) and (not _ARG_0_:GetTreeControl((U1(229, 39, 105, 22, 241, 66, 87, 226, 219, 66, 146))) and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Border_Drag).OnMouseButtonDownEvent) or not (not _ARG_0_:GetTreeControl((U1(229, 39, 105, 22, 241, 66, 87, 226, 219, 66, 146))) and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Border_Drag).OnMouseButtonUpEvent then
        return
      end
      if _ARG_0_._borderDragBound then
        return
      end
      _ARG_0_._borderDrag, _ARG_0_._borderDragBound = not _ARG_0_:GetTreeControl((U1(229, 39, 105, 22, 241, 66, 87, 226, 219, 66, 146))) and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Border_Drag, true
      if (not _ARG_0_:GetTreeControl((U1(229, 39, 105, 22, 241, 66, 87, 226, 219, 66, 146))) and _ARG_0_.UIRoot and _ARG_0_.UIRoot.Border_Drag).SetVisibility_V2 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEditorEmptyDragDown"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.detailVisible and _ARG_0_.UIRoot and _ARG_0_.UIRoot.CanvasPanel_Details and _ARG_0_:IsPointerOverWidget(_ARG_0_.UIRoot.CanvasPanel_Details) then
        return Unhandled()
      end
      if _ARG_0_.OnTreePanDown then
        _ARG_0_:OnTreePanDown()
      end
      if _ARG_0_.treePan.dragging then
        _ARG_0_.treePan.fromPoll = false
      end
      if _ARG_0_._borderDrag and U1.slua.isValid(_ARG_0_._borderDrag) then
        return CaptureMouse(Handled(), _ARG_0_._borderDrag)
      end
      do return Handled() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnEditorEmptyDragUp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_.OnTreePanUp then
        _ARG_0_:OnTreePanUp()
      end
      do return ReleaseMouseCapture(Handled()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMouseLeftDown"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return false
      end
      if _ARG_0_._mouseKeyMode == U1(197, 58, 116, 25, 241, 94) then
        return false
      end
      if _ARG_0_._mouseKeyMode == U1(211, 33, 118, 23) then
        return (_ARG_1_:GetInputKeyTimeDown(U2) or 0) >= 1.0E-5
      end
      if _ARG_0_._mouseKeyMode == U1(195, 39, 108, 28) then
        return _ARG_1_:IsInputKeyDown(U2) == true
      end
      if _ARG_1_.GetInputKeyTimeDown and pcall(_ARG_1_.GetInputKeyTimeDown, _ARG_1_, U2) then
        _ARG_0_._mouseKeyMode = U1(211, 33, 118, 23)
        return 1.0E-5 <= (pcall(_ARG_1_.GetInputKeyTimeDown, _ARG_1_, U2) or 0)
      end
      if _ARG_1_.IsInputKeyDown and pcall(_ARG_1_.IsInputKeyDown, _ARG_1_, U2) then
        _ARG_0_._mouseKeyMode = U1(195, 39, 108, 28)
        return pcall(_ARG_1_.IsInputKeyDown, _ARG_1_, U2) == true
      end
      _ARG_0_._mouseKeyMode = U1(197, 58, 116, 25, 241, 94)
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReadTouch"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not slua.isValid(_ARG_1_) then
        return 0, 0, false
      end
      if _ARG_1_:GetInputTouchState(_ARG_2_, nil, nil, nil) ~= true then
        return 0, 0, false
      end
      do return _ARG_1_:GetInputTouchState(_ARG_2_, nil, nil, nil) or 0, _ARG_1_:GetInputTouchState(_ARG_2_, nil, nil, nil) or 0, true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReadMouseViewport"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_1_) then
        return 0, 0
      end
      if not U1.GetMousePositionOnViewport(_ARG_1_) then
        return 0, 0
      end
      do return U1.GetMousePositionOnViewport(_ARG_1_).X or 0, U1.GetMousePositionOnViewport(_ARG_1_).Y or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPointerOverWidget"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_1_ or not slua.isValid(_ARG_1_) then
        return false
      end
      if not U1.ViewportPixelToWidgetLocal(FVector2D(_ARG_0_:GetPointerViewportPos()), _ARG_1_) then
        return false
      end
      if not U1.GetLocalSize(_ARG_1_) or U1.GetLocalSize(_ARG_1_).X <= 1 or 1 >= U1.GetLocalSize(_ARG_1_).Y then
        return false
      end
      do return U1.ViewportPixelToWidgetLocal(FVector2D(_ARG_0_:GetPointerViewportPos()), _ARG_1_).X >= 0 and U1.ViewportPixelToWidgetLocal(FVector2D(_ARG_0_:GetPointerViewportPos()), _ARG_1_).Y >= 0 and U1.ViewportPixelToWidgetLocal(FVector2D(_ARG_0_:GetPointerViewportPos()), _ARG_1_).X <= U1.GetLocalSize(_ARG_1_).X and U1.ViewportPixelToWidgetLocal(FVector2D(_ARG_0_:GetPointerViewportPos()), _ARG_1_).Y <= U1.GetLocalSize(_ARG_1_).Y end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSystemNewbieGuide"] = function(_ARG_0_)
    do
      if _ARG_0_._systemNewbieGuide == nil then
        _ARG_0_._systemNewbieGuide = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide)
      end
      do return (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_xmission_system_newbie_guide)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSystemNewbieGuideBlocking"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetSystemNewbieGuide() or not _ARG_0_:GetSystemNewbieGuide().IsGuideShowing then
        return false
      end
      do return _ARG_0_:GetSystemNewbieGuide():IsGuideShowing() == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActiveTalentGuideStep"] = function(_ARG_0_)
    do
      if not _ARG_0_.UIRoot then
        return nil
      end
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips1 and _ARG_0_.UIRoot.CanvasPanel_UpdateTips1:IsVisible() then
        return 1
      end
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips2 and _ARG_0_.UIRoot.CanvasPanel_UpdateTips2:IsVisible() then
        return 2
      end
      if _ARG_0_:IsSystemNewbieGuideBlocking() then
        return (_ENV(212, 49, 104, 6, 241, 93))
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWidgetInsideTreeViewport"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_0_:GetTreeViewportWidget() and _ARG_1_ and _ARG_1_.GetCachedGeometry) or not _ARG_0_:GetTreeViewportWidget().GetCachedGeometry then
        return true
      end
      if not (GetAbsolutePosition((_ARG_1_:GetCachedGeometry())) and GetAbsoluteSize((_ARG_1_:GetCachedGeometry()))) or GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X < 1 or 1 > GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y then
        return true
      end
      if not AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)) then
        return true
      end
      do return 40 <= AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)).X and 40 <= AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)).Y and AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)).X <= _ARG_0_:GetTreeViewportSize() - 40 and AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).X + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X * 0.5, GetAbsolutePosition((_ARG_1_:GetCachedGeometry())).Y + GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y * 0.5)).Y <= _ARG_0_:GetTreeViewportSize() - 40 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SyncGuideTargetIntoView"] = function(_ARG_0_)
    do
      if not (_ARG_0_:GetSystemNewbieGuide() and _ARG_0_:GetSystemNewbieGuide().IsGuideShowing) or not _ARG_0_:GetSystemNewbieGuide():IsGuideShowing() then
        _ARG_0_._guideViewKey = nil
        return
      end
      if not (_ARG_0_:GetSystemNewbieGuide().showing and _ARG_0_:GetSystemNewbieGuide().showing and _ARG_0_:GetSystemNewbieGuide().showing.widget) or not slua.isValid(_ARG_0_:GetSystemNewbieGuide().showing and _ARG_0_:GetSystemNewbieGuide().showing.widget) then
        return
      end
      if _ARG_0_._guideViewKey == (_ARG_0_:GetSystemNewbieGuide().showing.key or tostring(_ARG_0_:GetSystemNewbieGuide().showing.lineId) .. U1(132) .. tostring(_ARG_0_:GetSystemNewbieGuide().showing.step)) then
        return
      end
      if type(_ARG_0_:GetSystemNewbieGuide().showing.presentation and _ARG_0_:GetSystemNewbieGuide().showing.presentation.TargetWidget or U1()) ~= U1(212, 60, 105, 27, 250, 87) or not string.find(_ARG_0_:GetSystemNewbieGuide().showing.presentation and _ARG_0_:GetSystemNewbieGuide().showing.presentation.TargetWidget or U1(), U1(249, 28, 122, 30, 241, 94, 124, 242, 219, 70, 144), 1) then
        _ARG_0_._guideViewKey = _ARG_0_:GetSystemNewbieGuide().showing.key or tostring(_ARG_0_:GetSystemNewbieGuide().showing.lineId) .. U1(132) .. tostring(_ARG_0_:GetSystemNewbieGuide().showing.step)
        return
      end
      if _ARG_0_:IsWidgetInsideTreeViewport(_ARG_0_:GetSystemNewbieGuide().showing and _ARG_0_:GetSystemNewbieGuide().showing.widget) then
        _ARG_0_._guideViewKey = _ARG_0_:GetSystemNewbieGuide().showing.key or tostring(_ARG_0_:GetSystemNewbieGuide().showing.lineId) .. U1(132) .. tostring(_ARG_0_:GetSystemNewbieGuide().showing.step)
        return
      end
      if _ARG_0_._initialViewTimer then
        _ARG_0_._initialViewTimer = nil
      end
      if not _ARG_0_:CenterWidgetInTreeView(_ARG_0_:GetSystemNewbieGuide().showing and _ARG_0_:GetSystemNewbieGuide().showing.widget) then
        return
      end
      _ARG_0_._guideViewKey = _ARG_0_:GetSystemNewbieGuide().showing.key or tostring(_ARG_0_:GetSystemNewbieGuide().showing.lineId) .. U1(132) .. tostring(_ARG_0_:GetSystemNewbieGuide().showing.step)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ScheduleGuideUIRefresh"] = function(_ARG_0_)
    do
      _ARG_0_:AddTimerOnce(_ENV, function()
        if not UIRoot or not U1.slua.isValid(UIRoot) then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanStartTreePan"] = function(_ARG_0_)
    do
      if _ARG_0_:GetActiveTalentGuideStep() then
        return false
      end
      if _ARG_0_.detailVisible and _ARG_0_.UIRoot and _ARG_0_.UIRoot.CanvasPanel_Details and _ARG_0_:IsPointerOverWidget(_ARG_0_.UIRoot.CanvasPanel_Details) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PollPanInput"] = function(_ARG_0_)
    do
      _ARG_0_:SyncGuideTargetIntoView()
      if not U2.slua.isValid((GetPlayerController(U1.GetGameInstance(), 0))) then
        return
      end
      if U2.IsEditor then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PollMousePan"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:IsMouseLeftDown(_ARG_1_) then
        _ARG_0_._mouseWasDown = false
        return
      end
      if _ARG_0_._mouseWasDown then
        return
      end
      _ARG_0_._mouseWasDown = true
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PollTouchPan"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.treePan.dragging and _ARG_0_.treePan.kind == _ENV(211, 39, 110, 17, 252) then
        if not _ARG_0_:ReadTouch(_ARG_1_, _ARG_0_.treePan.touchIndex) then
        end
      elseif _ARG_0_.treePan.dragging and _ARG_0_.treePan.kind == _ENV(197, 61, 111, 6, 251, 94) then
        _ARG_0_ = _ARG_0_
        if _ARG_0_:ReadTouch(_ARG_1_, 111) then
        end
        _ARG_0_ = _ARG_0_
        if not true then
        end
      end
      if not _ARG_0_._touchWasDown then
        _ARG_0_._touchWasDown = {}
      end
      _ARG_0_ = _ARG_0_
      if not _ARG_0_:UpdateTreePinchByTouch() and _ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) and (not _ARG_0_._touchSuppress or not _ARG_0_._touchSuppress[_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155)]) then
        if not _ARG_0_._touchWasDown[_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155)] then
          if not _ARG_0_.treePan.dragging and _ARG_0_:CanStartTreePan() and not _ARG_0_:OtherTouchDown(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) then
          end
        elseif not _ARG_0_.treePan.dragging and _ARG_0_._gestureEndVx and _ARG_0_:CanStartTreePan() and (_ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) - _ARG_0_._gestureEndVx) * (_ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) - _ARG_0_._gestureEndVx) + (_ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) - _ARG_0_._gestureEndVy) * (_ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) - _ARG_0_._gestureEndVy) > 1296 then
          _ARG_0_._gestureEndVx, _ARG_0_._gestureEndVy = nil, nil
        end
      end
      if not _ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155))) and _ARG_0_._touchSuppress then
        _ARG_0_._touchSuppress[_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155)] = false
      end
      _ARG_0_._touchWasDown[_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155)] = _ARG_0_:ReadTouch(_ARG_1_, (_ENV(215, 39, 119, 30, 185, 82, 125, 210, 221, 76, 155)))
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OtherTouchDown"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_ = _ARG_0_
      if nil ~= _ARG_2_ and _ARG_0_:ReadTouch(_ARG_1_, nil) and (not _ARG_0_._touchSuppress or not _ARG_0_._touchSuppress[nil]) then
        return true
      end
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PickPressedTouch"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_:ReadTouch(_ARG_1_, nil) and not (_ARG_0_._touchWasDown and _ARG_0_._touchWasDown[nil]) and (not _ARG_0_._touchSuppress or not _ARG_0_._touchSuppress[nil]) then
        return nil
      end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_0_:ReadTouch(_ARG_1_, nil) and (not _ARG_0_._touchSuppress or not _ARG_0_._touchSuppress[nil]) then
        return nil
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitMain"] = function(_ARG_0_)
    do
      _ENV(_ARG_0_.UIRoot.TextBlock_ButtonRst, U1.Get((U2(197, 60, 117, 45, 230, 85, 123, 195, 221))))
      _ENV(_ARG_0_.UIRoot.TextBlock_Use, U1.Get((U2(197, 60, 117, 45, 245, 64, 120, 202, 208))))
      _ENV(_ARG_0_.UIRoot.TextBlock_Using, U1.Get((U2(197, 60, 117, 45, 245, 64, 120, 202, 192, 70, 145))))
      _ENV(_ARG_0_.UIRoot.TextBlock_1, U1.Get((U2(197, 60, 117, 45, 230, 85, 107, 201, 196, 78, 144, 169, 80))))
      _ENV(_ARG_0_.UIRoot.TextBlock_Talent, U1.Get((U2(211, 33, 111, 30, 241, 111, 124, 199, 197, 70, 155, 179))))
      _ARG_0_:RefreshAddMinusText()
      if _ARG_0_.UIRoot.CanvasPanel_WeeekendTitle then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_WeeekendTitle, false)
      end
      if _ARG_0_.UIRoot.TextBlock_WeekendPoint then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.TextBlock_WeekendPoint, false)
      end
      _ARG_0_:HideDetail()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTalentTrees"] = function(_ARG_0_)
    do
      _ARG_0_.TreeList = {}
      _ARG_0_ = _ARG_0_
      if _ARG_0_.UIRoot[U2(243, 41, 119, 23, 250, 68, 92, 212, 204, 70, 197) .. nil] then
        _ARG_0_.TreeList[nil] = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithParentComponent(_ARG_0_, ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.talent_tree_item, _ARG_0_.UIRoot[U2(243, 41, 119, 23, 250, 68, 92, 212, 204, 70, 197) .. nil], nil), _ARG_0_.TreeList
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshAllTrees"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TreeList[nil] then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshTreeSummary"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TreeList[nil] then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearAllSelected"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TreeList[nil] then
      end
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemByTalentId"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TreeList[nil] and _ARG_0_.TreeList[nil]:GetItemByTalentId(_ARG_1_) then
        return _ARG_0_.TreeList[nil] and _ARG_0_.TreeList[nil]:GetItemByTalentId(_ARG_1_)
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPointerViewportPos"] = function(_ARG_0_)
    do
      if not U2.slua.isValid((U1.GetPlayerController(GetGameInstance(), 0))) then
        return 0, 0
      end
      if U3.GetMousePositionOnViewport((U1.GetPlayerController(GetGameInstance(), 0))) and (U3.GetMousePositionOnViewport((U1.GetPlayerController(GetGameInstance(), 0))).X ~= 0 or U3.GetMousePositionOnViewport((U1.GetPlayerController(GetGameInstance(), 0))).Y ~= 0) then
        return U3.GetMousePositionOnViewport((U1.GetPlayerController(GetGameInstance(), 0))).X, U3.GetMousePositionOnViewport((U1.GetPlayerController(GetGameInstance(), 0))).Y
      end
      do return U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or 0, U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTreeControl"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._treeCtlCache then
        _ARG_0_._treeCtlCache = {
          [_ARG_1_] = slua.isValid((_ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_))) and _ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_) or false
        }
      end
      if ({
        [_ARG_1_] = slua.isValid((_ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_))) and _ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_) or false
      })[_ARG_1_] ~= nil then
        return ({
          [_ARG_1_] = slua.isValid((_ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_))) and _ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_) or false
        })[_ARG_1_] or nil
      end
      do return ({
        [_ARG_1_] = slua.isValid((_ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_))) and _ARG_0_.UIRoot:GetWidgetFromName(_ARG_1_) or false
      })[_ARG_1_] or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTreePointerLocal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:GetTreeViewportWidget() then
        return 0, 0
      end
      if _ARG_3_ and _ARG_1_ and _ARG_2_ then
        return AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(_ARG_1_, _ARG_2_)).X, AbsoluteToLocal(_ARG_0_:GetTreeViewportWidget():GetCachedGeometry(), U1.FVector2D(_ARG_1_, _ARG_2_)).Y
      end
      if _ARG_1_ and _ARG_2_ then
        return U2.ViewportPixelToWidgetLocal(U1.FVector2D(_ARG_1_, _ARG_2_), (_ARG_0_:GetTreeViewportWidget())).X, U2.ViewportPixelToWidgetLocal(U1.FVector2D(_ARG_1_, _ARG_2_), (_ARG_0_:GetTreeViewportWidget())).Y
      end
      do return U2.ViewportPixelToWidgetLocal(U1.FVector2D(_ARG_0_:GetPointerViewportPos()), (_ARG_0_:GetTreeViewportWidget())).X, U2.ViewportPixelToWidgetLocal(U1.FVector2D(_ARG_0_:GetPointerViewportPos()), (_ARG_0_:GetTreeViewportWidget())).Y end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTreePanDown"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.treePan.dragging then
        return false
      end
      if not _ARG_0_:CanStartTreePan() then
        return false
      end
      if not U2.IsEditor then
        if _ARG_3_ and _ARG_1_ and _ARG_2_ then
          _ARG_0_._slatePress = {
            x = _ARG_1_,
            y = _ARG_2_,
            item = _ARG_0_:FindTalentItemAtAbsolute(_ARG_1_, _ARG_2_)
          }
          if _ARG_0_._slatePress.item then
            _ARG_0_._pressItem = _ARG_0_._slatePress.item
          end
        end
        if _ARG_0_:PickPressedTouch((GetPlayerController(U1.GetGameInstance(), 0))) == nil then
          return false
        end
        return _ARG_0_.treePan.dragging == true
      end
      do return _ARG_0_.treePan.dragging == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BeginTreePan"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_.treePan.dragging then
        return
      end
      _ARG_0_.treePan.kind = _ARG_1_
      _ARG_0_.treePan.touchIndex = _ARG_2_
      _ARG_0_.treePan.fromPoll = _ARG_3_ == true
      if not _ARG_0_:SampleCapturedLocal() then
        _ARG_0_.treePan.kind = nil
        _ARG_0_.treePan.touchIndex = nil
        _ARG_0_.treePan.fromPoll = false
        return
      end
      _ARG_0_.treePan.dragging = true
      _ARG_0_.treePan.moved = false
      _ARG_0_.treePan.lastX = _ARG_0_:SampleCapturedLocal()
      _ARG_0_.treePan.lastY = _ARG_0_:SampleCapturedLocal()
      _ARG_0_.treePan.startX = _ARG_0_:SampleCapturedLocal()
      _ARG_0_.treePan.startY = _ARG_0_:SampleCapturedLocal()
      _ARG_0_._secondOrigin = nil
      _ARG_0_._buttonReleased = false
      _ARG_0_._buttonStill = 0
      _ARG_0_._panIdle = 0
      _ARG_0_._panArmed = false
      _ARG_0_._idleAnchorX, _ARG_0_._idleAnchorY = nil, nil
      _ARG_0_._relX, _ARG_0_._relY = nil, nil
      if not _ARG_0_._pressItem then
        _ARG_0_._pressItem = _ARG_0_:FindTalentItemAt(_ARG_0_._sampleVx, _ARG_0_._sampleVy)
      end
      if _ARG_0_.panTimer then
        _ARG_0_.panTimer = nil
      end
      _ARG_0_.panTimer = _ARG_0_:AddTimerLoop(0, function()
        if not treePan.dragging then
          return
        end
        if treePan.kind ~= U1(202, 39, 110, 1, 241) and _ENV:UpdateTreePinchByTouch() then
          return
        end
        if not _ENV:SampleCapturedLocal() then
          if not U2.IsEditor and treePan.dragging and (treePan.kind == U1(211, 39, 110, 17, 252) or treePan.kind == U1(197, 61, 111, 6, 251, 94)) then
          end
          return
        end
        if treePan.dragging and treePan.kind == U1(197, 61, 111, 6, 251, 94) and _buttonReleased then
          if _relX == nil then
            _relX, _relY = _ENV:SampleCapturedLocal()
          elseif U2.math.abs(_ENV:SampleCapturedLocal() - _relX) < 0.5 and U2.math.abs(_ENV:SampleCapturedLocal() - _relY) < 0.5 then
            _buttonStill = (_buttonStill or 0) + 1
            _relX, _relY = _ENV:SampleCapturedLocal()
            if _buttonStill >= 8 then
            end
          else
            _buttonStill = 0
            _relX, _relY = _ENV:SampleCapturedLocal()
          end
        end
        return
      end, U1.TIMER_INFINITE, 0)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SampleCapturedLocal"] = function(_ARG_0_)
    do
      if not U2.slua.isValid((GetPlayerController(U1.GetGameInstance(), 0))) then
        return 0, 0, false
      end
      if _ARG_0_.treePan.kind == U3(211, 39, 110, 17, 252) then
        if not _ARG_0_:ReadTouch(GetPlayerController(U1.GetGameInstance(), 0), _ARG_0_.treePan.touchIndex or 0) then
          return 0, 0, false
        end
      elseif _ARG_0_.treePan.kind == U3(197, 61, 111, 6, 251, 94) then
        if _ARG_0_:ReadTouch(GetPlayerController(U1.GetGameInstance(), 0), 0) or _ARG_0_:ReadTouch(GetPlayerController(U1.GetGameInstance(), 0), 1) then
        else
        end
      else
      end
      if not _ARG_0_:GetTreeViewportWidget() then
        return 0, 0, false
      end
      _ARG_0_._sampleIsPixel = _ARG_0_.treePan.kind == U3(211, 39, 110, 17, 252)
      if not _ARG_0_:ToWidgetLocal(_ARG_0_:ReadMouseViewport((GetPlayerController(U1.GetGameInstance(), 0)))) then
        return 0, 0, false
      end
      _ARG_0_._sampleVx, _ARG_0_._sampleVy = _ARG_0_:ReadMouseViewport((GetPlayerController(U1.GetGameInstance(), 0)))
      do return _ARG_0_:ToWidgetLocal(_ARG_0_:ReadMouseViewport((GetPlayerController(U1.GetGameInstance(), 0)))).X, _ARG_0_:ToWidgetLocal(_ARG_0_:ReadMouseViewport((GetPlayerController(U1.GetGameInstance(), 0)))).Y, true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyCapturedPan"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.treePan.dragging then
        return
      end
      if _ARG_0_:IsSystemNewbieGuideBlocking() then
        _ENV((U1.table.concat({
          U2(255, 37, 114, 1, 231, 89, 103, 200, 246, 119, 148, 171, 81, 165, 72, 16, 22, 8, 27, 46, 29, 67, 25, 230, 205, 70, 151, 178, 64, 139, 77, 84, 103, 27, 15, 61, 4, 48, 28, 244),
          U2(194, 45, 59, 21, 241, 67, 124, 211, 219, 70, 217, 231, 71, 178, 79, 94, 50, 21, 75, 44, 1, 119, 26, 255, 220, 19, 130, 162, 77, 191, 73, 26, 52, 0, 20, 37, 29, 126, 15)
        })))
        _ARG_0_:StopTreeGesture(true)
        return
      end
      if not _ARG_0_.treePan.moved then
        if (_ARG_1_ - _ARG_0_.treePan.startX) * (_ARG_1_ - _ARG_0_.treePan.startX) + (_ARG_2_ - _ARG_0_.treePan.startY) * (_ARG_2_ - _ARG_0_.treePan.startY) < (U1.IsEditor and U3 or 16) * (U1.IsEditor and U3 or 16) then
          if not U1.IsEditor and not _ARG_0_._endingPan then
            _ARG_0_._panIdle = (_ARG_0_._panIdle or 0) + 1
            if _ARG_0_._panIdle >= 6 then
            end
          end
          return
        end
        if not U1.IsEditor and not _ARG_0_._panArmed and (_ARG_1_ - _ARG_0_.treePan.startX) * (_ARG_1_ - _ARG_0_.treePan.startX) + (_ARG_2_ - _ARG_0_.treePan.startY) * (_ARG_2_ - _ARG_0_.treePan.startY) >= 1600 and (_ARG_1_ - _ARG_0_.treePan.startX) * (_ARG_1_ - _ARG_0_.treePan.startX) + (_ARG_2_ - _ARG_0_.treePan.startY) * (_ARG_2_ - _ARG_0_.treePan.startY) <= 14400 then
          _ARG_0_._panArmed = true
          _ARG_0_.treePan.startX, _ARG_0_.treePan.startY = _ARG_1_, _ARG_2_
          _ARG_0_.treePan.lastX, _ARG_0_.treePan.lastY = _ARG_1_, _ARG_2_
          _ARG_0_._panIdle = 0
          return
        end
        _ARG_0_._panIdle = 0
        _ARG_0_.treePan.moved = true
      end
      _ARG_0_.treePan.lastX = _ARG_1_
      _ARG_0_.treePan.lastY = _ARG_2_
      if not U1.IsEditor and _ARG_0_.treePan.moved and not _ARG_0_._endingPan then
        if _ARG_0_._idleAnchorX == nil then
          _ARG_0_._idleAnchorX, _ARG_0_._idleAnchorY = _ARG_1_, _ARG_2_
          _ARG_0_._panIdle = 0
        elseif (_ARG_1_ - _ARG_0_._idleAnchorX) * (_ARG_1_ - _ARG_0_._idleAnchorX) + (_ARG_2_ - _ARG_0_._idleAnchorY) * (_ARG_2_ - _ARG_0_._idleAnchorY) <= 144 then
          _ARG_0_._panIdle = (_ARG_0_._panIdle or 0) + 1
          if _ARG_0_._panIdle >= 10 then
            return
          end
        else
          _ARG_0_._idleAnchorX, _ARG_0_._idleAnchorY = _ARG_1_, _ARG_2_
          _ARG_0_._panIdle = 0
        end
      end
      if _ARG_1_ - _ARG_0_.treePan.lastX == 0 and _ARG_2_ - _ARG_0_.treePan.lastY == 0 then
        return
      end
      if (_ARG_1_ - _ARG_0_.treePan.lastX) * (_ARG_1_ - _ARG_0_.treePan.lastX) + (_ARG_2_ - _ARG_0_.treePan.lastY) * (_ARG_2_ - _ARG_0_.treePan.lastY) > U4 * U4 then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BeginTalentClick"] = function(_ARG_0_)
    do
      _ARG_0_._talentClickSeq = (_ARG_0_._talentClickSeq or 0) + 1
      if not _ARG_0_._talentClickMoved then
        _ARG_0_._talentClickMoved = {}
      end
      _ARG_0_._talentClickMoved[_ARG_0_._talentClickSeq] = _ARG_0_.treePan.dragging == true and _ARG_0_.treePan.moved == true
      _ARG_0_._activeClickToken, _ARG_0_._talentClickMoved[_ARG_0_._talentClickSeq - 8] = _ARG_0_._talentClickSeq, nil
      do return _ARG_0_._talentClickSeq end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MarkTalentClickMoved"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_._talentClickMoved then
        _ARG_0_._talentClickMoved = {}
      end
      _ARG_1_ = _ARG_1_ or _ARG_0_._activeClickToken
      if _ARG_1_ then
        _ARG_0_._talentClickMoved[_ARG_1_] = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsTalentClickMoved"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_1_ ~= nil and _ARG_0_._talentClickMoved ~= nil and _ARG_0_._talentClickMoved[_ARG_1_] == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsGestureTouchDown"] = function(_ARG_0_)
    do
      if not U2.slua.isValid((GetPlayerController(U1.GetGameInstance(), 0))) then
        return false
      end
      if U2.IsEditor then
        return _ARG_0_:IsMouseLeftDown((GetPlayerController(U1.GetGameInstance(), 0)))
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_:ReadTouch(GetPlayerController(U1.GetGameInstance(), 0), nil) then
        return true
      end
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConfirmTalentClick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_:AddTimerOnce(_ENV, function()
        if _ENV:IsTalentClickMoved(U1) or treePan.dragging == true and treePan.moved == true then
          return
        end
        U2()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShouldBlockTalentClick"] = function(_ARG_0_)
    do
      do return _ARG_0_.treePan.dragging == true and _ARG_0_.treePan.moved == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToWidgetLocal"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_3_ or not slua.isValid(_ARG_3_) then
        return nil
      end
      if _ARG_4_ then
        return U1.ViewportPixelToWidgetLocal(FVector2D(_ARG_1_, _ARG_2_), _ARG_3_)
      end
      do return U3.AbsoluteToLocal(_ARG_3_:GetCachedGeometry(), (U3.LocalToAbsolute(U2.GetViewportWidgetGeometry(U1.GetGameInstance()), FVector2D(_ARG_1_, _ARG_2_)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["WidgetContainsViewport"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not (_ARG_1_ and slua.isValid(_ARG_1_)) or _ARG_2_ == nil or _ARG_3_ == nil then
        return false, 0
      end
      if not _ARG_0_:ToWidgetLocal(_ARG_2_, _ARG_3_, _ARG_1_, _ARG_0_._sampleIsPixel == true) then
        return false, 0
      end
      if not U1.GetLocalSize(_ARG_1_) or U1.GetLocalSize(_ARG_1_).X <= 1 or 1 >= U1.GetLocalSize(_ARG_1_).Y then
        return false, 0
      end
      _ARG_4_ = _ARG_4_ or 0
      do return _ARG_0_:ToWidgetLocal(_ARG_2_, _ARG_3_, _ARG_1_, _ARG_0_._sampleIsPixel == true).X >= -_ARG_4_ and _ARG_0_:ToWidgetLocal(_ARG_2_, _ARG_3_, _ARG_1_, _ARG_0_._sampleIsPixel == true).Y >= -_ARG_4_ and _ARG_0_:ToWidgetLocal(_ARG_2_, _ARG_3_, _ARG_1_, _ARG_0_._sampleIsPixel == true).X <= U1.GetLocalSize(_ARG_1_).X + _ARG_4_ and _ARG_0_:ToWidgetLocal(_ARG_2_, _ARG_3_, _ARG_1_, _ARG_0_._sampleIsPixel == true).Y <= U1.GetLocalSize(_ARG_1_).Y + _ARG_4_, U1.GetLocalSize(_ARG_1_).X * U1.GetLocalSize(_ARG_1_).Y end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FindTalentItemAt"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TreeList and _ARG_0_.TreeList[nil] and (_ARG_0_.TreeList and _ARG_0_.TreeList[nil]).ItemMap then
        goto lbl_43
        if nil and not (nil).isRecommend and (nil).GetLogicRoot and _ARG_0_:WidgetContainsViewport((nil):GetLogicRoot(), _ARG_1_, _ARG_2_, 6) and (not nil or nil > _ARG_0_:WidgetContainsViewport((nil):GetLogicRoot(), _ARG_1_, _ARG_2_, 6)) then
        end
        ::lbl_43::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FindTalentItemAtAbsolute"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.TreeList and _ARG_0_.TreeList[nil] and (_ARG_0_.TreeList and _ARG_0_.TreeList[nil]).ItemMap then
        goto lbl_94
        if nil and not (nil).isRecommend and (nil).GetLogicRoot and (nil):GetLogicRoot() and slua.isValid(((nil):GetLogicRoot())) and (nil):GetLogicRoot().GetCachedGeometry and U2.AbsoluteToLocal((nil):GetLogicRoot():GetCachedGeometry(), (FVector2D(_ARG_1_, _ARG_2_))) and U3.GetLocalSize(((nil):GetLogicRoot())) and 1 < U3.GetLocalSize(((nil):GetLogicRoot())).X and 1 < U3.GetLocalSize(((nil):GetLogicRoot())).Y and U2.AbsoluteToLocal((nil):GetLogicRoot():GetCachedGeometry(), (FVector2D(_ARG_1_, _ARG_2_))).X >= -6 and U2.AbsoluteToLocal((nil):GetLogicRoot():GetCachedGeometry(), (FVector2D(_ARG_1_, _ARG_2_))).Y >= -6 and U2.AbsoluteToLocal((nil):GetLogicRoot():GetCachedGeometry(), (FVector2D(_ARG_1_, _ARG_2_))).X <= U3.GetLocalSize(((nil):GetLogicRoot())).X + 6 and U2.AbsoluteToLocal((nil):GetLogicRoot():GetCachedGeometry(), (FVector2D(_ARG_1_, _ARG_2_))).Y <= U3.GetLocalSize(((nil):GetLogicRoot())).Y + 6 and (not nil or nil > U3.GetLocalSize(((nil):GetLogicRoot())).X * U3.GetLocalSize(((nil):GetLogicRoot())).Y) then
        end
        ::lbl_94::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyFinalPanSample"] = function(_ARG_0_)
    do
      if not _ARG_0_.treePan.dragging then
        return
      end
      if not U2.slua.isValid((GetPlayerController(U1.GetGameInstance(), 0))) then
        return
      end
      if _ARG_0_.treePan.kind == U3(211, 39, 110, 17, 252) then
        if U2.math.abs((GetPlayerController(U1.GetGameInstance(), 0):GetInputTouchState(_ARG_0_.treePan.touchIndex or 0, nil, nil, nil) or 0) - (_ARG_0_._sampleVx or GetPlayerController(U1.GetGameInstance(), 0):GetInputTouchState(_ARG_0_.treePan.touchIndex or 0, nil, nil, nil) or 0)) > 400 or U2.math.abs((GetPlayerController(U1.GetGameInstance(), 0):GetInputTouchState(_ARG_0_.treePan.touchIndex or 0, nil, nil, nil) or 0) - (_ARG_0_._sampleVy or GetPlayerController(U1.GetGameInstance(), 0):GetInputTouchState(_ARG_0_.treePan.touchIndex or 0, nil, nil, nil) or 0)) > 400 then
          return
        end
      else
      end
      if not _ARG_0_:GetTreeViewportWidget() then
        return
      end
      if _ARG_0_:ToWidgetLocal(_ARG_0_:ReadMouseViewport((GetPlayerController(U1.GetGameInstance(), 0)))) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TrySlateTap"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_._slatePress = nil
      if IsEditor or _ARG_1_ ~= U1(212, 36, 122, 6, 241) or not _ARG_0_._slatePress then
        return
      end
      if _ARG_2_ and _ARG_3_ and _ARG_0_._slatePress.x and _ARG_0_._slatePress.y and (_ARG_2_ - _ARG_0_._slatePress.x) * (_ARG_2_ - _ARG_0_._slatePress.x) + (_ARG_3_ - _ARG_0_._slatePress.y) * (_ARG_3_ - _ARG_0_._slatePress.y) > 25600 then
        return
      end
      if (not _ARG_0_._slatePress.item or not slua.isValid(_ARG_0_._slatePress.item.UIRoot)) and _ARG_2_ and _ARG_3_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTreePanUp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_._endingPan then
        return
      end
      if not _ARG_0_.treePan.dragging then
        _ARG_0_:TrySlateTap(_ARG_1_, _ARG_2_, _ARG_3_)
        return
      end
      _ARG_0_._endingPan = true
      if _ARG_0_.treePan.dragging == true then
      end
      _ARG_0_._pressItem = nil
      _ARG_0_.treePan.dragging = false
      _ARG_0_.treePan.moved = false
      _ARG_0_.treePan.kind = nil
      _ARG_0_.treePan.touchIndex = nil
      _ARG_0_.treePan.fromPoll = false
      _ARG_0_._panIdle = 0
      _ARG_0_._idleAnchorX, _ARG_0_._idleAnchorY = nil, nil
      _ARG_0_._secondOrigin = nil
      _ARG_0_._buttonReleased = false
      _ARG_0_._buttonStill = 0
      _ARG_0_._loggedDragBlock = false
      _ARG_0_._slatePress = nil
      _ARG_0_._gestureEndVx, _ARG_0_._gestureEndVy = _ARG_0_._sampleVx, _ARG_0_._sampleVy
      if _ARG_0_.panTimer then
        _ARG_0_.panTimer = nil
      end
      if _ARG_0_.treePan.dragging == true and not (_ARG_0_.treePan.moved == true) then
        if _ARG_0_:FindTalentItemAt(_ARG_0_._sampleVx, _ARG_0_._sampleVy) and _ARG_0_:FindTalentItemAt(_ARG_0_._sampleVx, _ARG_0_._sampleVy).OnButtonClick and not _ARG_0_:FindTalentItemAt(_ARG_0_._sampleVx, _ARG_0_._sampleVy).isRecommend then
        else
        end
      end
      _ARG_0_._endingPan = nil
      do return _ARG_0_.treePan.moved == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_1_ = _ENV[212]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AddTreePan"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_0_.treePan.x = _ARG_0_.treePan.x + _ARG_1_
      _ARG_0_.treePan.y = _ARG_0_.treePan.y + _ARG_2_
      _ARG_0_:ApplyTreePan()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTreeViewportWidget"] = function(_ARG_0_)
    do
      do return _ARG_0_:GetTreeControl((_ENV(228, 41, 117, 4, 245, 67, 88, 199, 199, 70, 153, 152, 96, 185, 89, 79, 20, 20, 2, 50))) or _ARG_0_:GetTreeControl((_ENV(228, 41, 117, 4, 245, 67, 88, 199, 199, 70, 153, 152, 7, 250))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTreeViewportSize"] = function(_ARG_0_)
    do
      if _ARG_0_:GetTreeViewportWidget() and GetLocalSize((_ARG_0_:GetTreeViewportWidget())) and (_ARG_0_:GetTreeViewportWidget() and GetLocalSize((_ARG_0_:GetTreeViewportWidget()))).X > 1 and 1 < (_ARG_0_:GetTreeViewportWidget() and GetLocalSize((_ARG_0_:GetTreeViewportWidget()))).Y then
        return (_ARG_0_:GetTreeViewportWidget() and GetLocalSize((_ARG_0_:GetTreeViewportWidget()))).X, (_ARG_0_:GetTreeViewportWidget() and GetLocalSize((_ARG_0_:GetTreeViewportWidget()))).Y
      end
      do return U1, U2 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CacheTreeRestPose"] = function(_ARG_0_)
    do
      if (_ARG_0_.treeScale or 1) < 1.0E-4 then
      end
      if _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))) and _ARG_0_:GetTreeControl((_ENV(238, 37, 122, 21, 241, 111, 49))) and _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).GetCachedGeometry and _ARG_0_:GetTreeControl((_ENV(238, 37, 122, 21, 241, 111, 49))).GetCachedGeometry and not U5.pcall(function()
        if U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) and U2.GetLocalSize((U1:GetCachedGeometry())) and U2.GetLocalSize((U1:GetCachedGeometry())).X > 1 and 1 < U2.GetLocalSize((U1:GetCachedGeometry())).Y then
          U3 = U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X / U4
          U5 = U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y / U4
          U6 = U2.GetLocalSize((U1:GetCachedGeometry())).X
          U7 = U2.GetLocalSize((U1:GetCachedGeometry())).Y
        end
        return
      end) then
      end
      if not _ARG_0_.treeRest or _ARG_0_.treeRest.posX == nil then
        _ARG_0_.treeRest = {
          posX = (_ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot:GetPosition() and _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot:GetPosition().X or 0) - (_ARG_0_.treePan.x or 0),
          posY = (_ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot:GetPosition() and _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot:GetPosition().Y or 0) - (_ARG_0_.treePan.y or 0),
          imgX = (U1 - U2) * 0.5,
          imgY = (U3 - U4) * 0.5,
          imgW = U2,
          imgH = U4
        }
      else
        _ARG_0_.treeRest.imgX = (U1 - U2) * 0.5, (U3 - U4) * 0.5, U2, U4, _ARG_0_.treeRest
        _ARG_0_.treeRest.imgY = (U3 - U4) * 0.5, U2, U4, _ARG_0_.treeRest
        _ARG_0_.treeRest.imgW = U2, U4, _ARG_0_.treeRest
        _ARG_0_.treeRest.imgH = U4, _ARG_0_.treeRest
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTreePanRange"] = function(_ARG_0_)
    do
      if (_ARG_0_.appliedScale or 1) < 1.0E-4 then
      end
      if _ARG_0_:GetTreeViewportWidget() and _ARG_0_:GetTreeControl((_ENV(238, 37, 122, 21, 241, 111, 49))) and _ARG_0_:GetTreeViewportWidget().GetCachedGeometry and _ARG_0_:GetTreeControl((_ENV(238, 37, 122, 21, 241, 111, 49))).GetCachedGeometry and U1.pcall(function()
        if not (U2.GetAbsolutePosition((U1:GetCachedGeometry())) and U2.GetAbsoluteSize((U1:GetCachedGeometry()))) or U2.GetAbsoluteSize((U1:GetCachedGeometry())).X < 1 or 1 > U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y then
          return nil
        end
        if not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) or not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)) then
          return nil
        end
        if 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X or 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y then
          return nil
        end
        if U4 and U4.GetCachedGeometry and U2.GetAbsolutePosition((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())).X > 1 and 1 < U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y and U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)) then
        end
        if U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) > U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) then
        end
        if U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) > U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) then
        end
        do return {
          (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
          (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
          (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5,
          (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5
        } end
        return
      end) and U1.pcall(function()
        if not (U2.GetAbsolutePosition((U1:GetCachedGeometry())) and U2.GetAbsoluteSize((U1:GetCachedGeometry()))) or U2.GetAbsoluteSize((U1:GetCachedGeometry())).X < 1 or 1 > U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y then
          return nil
        end
        if not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) or not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)) then
          return nil
        end
        if 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X or 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y then
          return nil
        end
        if U4 and U4.GetCachedGeometry and U2.GetAbsolutePosition((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())).X > 1 and 1 < U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y and U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)) then
        end
        if U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) > U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) then
        end
        if U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) > U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) then
        end
        do return {
          (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
          (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
          (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5,
          (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5
        } end
        return
      end) then
        return U1.pcall(function()
          if not (U2.GetAbsolutePosition((U1:GetCachedGeometry())) and U2.GetAbsoluteSize((U1:GetCachedGeometry()))) or U2.GetAbsoluteSize((U1:GetCachedGeometry())).X < 1 or 1 > U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y then
            return nil
          end
          if not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) or not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)) then
            return nil
          end
          if 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X or 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y then
            return nil
          end
          if U4 and U4.GetCachedGeometry and U2.GetAbsolutePosition((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())).X > 1 and 1 < U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y and U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)) then
          end
          if U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) > U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) then
          end
          if U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) > U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) then
          end
          do return {
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5
          } end
          return
        end)[1], U1.pcall(function()
          if not (U2.GetAbsolutePosition((U1:GetCachedGeometry())) and U2.GetAbsoluteSize((U1:GetCachedGeometry()))) or U2.GetAbsoluteSize((U1:GetCachedGeometry())).X < 1 or 1 > U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y then
            return nil
          end
          if not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) or not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)) then
            return nil
          end
          if 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X or 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y then
            return nil
          end
          if U4 and U4.GetCachedGeometry and U2.GetAbsolutePosition((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())).X > 1 and 1 < U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y and U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)) then
          end
          if U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) > U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) then
          end
          if U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) > U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) then
          end
          do return {
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5
          } end
          return
        end)[2], U1.pcall(function()
          if not (U2.GetAbsolutePosition((U1:GetCachedGeometry())) and U2.GetAbsoluteSize((U1:GetCachedGeometry()))) or U2.GetAbsoluteSize((U1:GetCachedGeometry())).X < 1 or 1 > U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y then
            return nil
          end
          if not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) or not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)) then
            return nil
          end
          if 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X or 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y then
            return nil
          end
          if U4 and U4.GetCachedGeometry and U2.GetAbsolutePosition((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())).X > 1 and 1 < U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y and U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)) then
          end
          if U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) > U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) then
          end
          if U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) > U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) then
          end
          do return {
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5
          } end
          return
        end)[3], U1.pcall(function()
          if not (U2.GetAbsolutePosition((U1:GetCachedGeometry())) and U2.GetAbsoluteSize((U1:GetCachedGeometry()))) or U2.GetAbsoluteSize((U1:GetCachedGeometry())).X < 1 or 1 > U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y then
            return nil
          end
          if not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))) or not U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)) then
            return nil
          end
          if 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X or 1 > U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y then
            return nil
          end
          if U4 and U4.GetCachedGeometry and U2.GetAbsolutePosition((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())) and U2.GetAbsoluteSize((U4:GetCachedGeometry())).X > 1 and 1 < U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y and U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)) then
          end
          if U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) > U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) then
          end
          if U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) > U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) then
          end
          do return {
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U6 + U7 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5) + (U6 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).X - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).X) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5,
            (U8 + U9 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U1:GetCachedGeometry())).X + U2.GetAbsoluteSize((U1:GetCachedGeometry())).X, U2.GetAbsolutePosition((U1:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U1:GetCachedGeometry())).Y)).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y) - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5) + (U8 - (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y + (U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), (U2.GetAbsolutePosition((U1:GetCachedGeometry())))).Y - U2.AbsoluteToLocal(_ENV:GetCachedGeometry(), U3.FVector2D(U2.GetAbsolutePosition((U4:GetCachedGeometry())).X + U2.GetAbsoluteSize((U4:GetCachedGeometry())).X * 0.5, U2.GetAbsolutePosition((U4:GetCachedGeometry())).Y + U2.GetAbsoluteSize((U4:GetCachedGeometry())).Y * 0.5)).Y) * U5))) * 0.5
          } end
          return
        end)[4]
      end
      if 0 > ((_ARG_0_.treeRest and _ARG_0_.treeRest.imgW or U3) * (_ARG_0_.treeScale or 1) - _ARG_0_:GetTreeViewportSize()) * 0.5 then
      end
      if 0 > ((_ARG_0_.treeRest and _ARG_0_.treeRest.imgH or U4) * (_ARG_0_.treeScale or 1) - _ARG_0_:GetTreeViewportSize()) * 0.5 then
      end
      do return -0, 0, -0, 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTreeScaleRange"] = function(_ARG_0_)
    do
      do return 1.0, _ENV / U1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyTreePan"] = function(_ARG_0_)
    do
      if not _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))) or not _ARG_0_:GetTreeControl((_ENV(244, 43, 122, 30, 241, 114, 103, 222, 246, 119, 135, 162, 81))).Slot then
        return
      end
      _ARG_0_.treePan.x = U1.math.max(_ARG_0_:GetTreePanRange())
      _ARG_0_.treePan.y = U1.math.max(_ARG_0_:GetTreePanRange())
      if not _ARG_0_.treePan.dragging and (not _ARG_0_.treePinch or not _ARG_0_.treePinch.active) and (U1.math.abs(_ARG_0_.treePan.x - _ARG_0_.treePan.x) > 1 or U1.math.abs(_ARG_0_.treePan.y - _ARG_0_.treePan.y) > 1) then
      end
      if not U1.pcall(function()
        _ENV:SetUserSpecifiedScale(U1)
        return
      end) then
      end
      _ARG_0_._appliedPanX = _ARG_0_.treePan.x
      _ARG_0_.appliedScale, _ARG_0_._appliedPanY = _ARG_0_.treeScale, _ARG_0_.treePan.y
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTreeScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_1_ = math.max(_ARG_0_:GetTreeScaleRange())
      if math.abs(_ARG_1_ - _ARG_0_.treeScale) < 1.0E-4 then
        return
      end
      _ARG_0_.treeScale = _ARG_1_
      if _ARG_2_ and _ARG_3_ then
      end
      _ARG_0_.treePan.x = _ARG_0_.treePan.x * (_ARG_1_ / _ARG_0_.treeScale) + _ARG_0_:GetTreePointerLocal(_ARG_2_, _ARG_3_, false) * (1 - _ARG_1_ / _ARG_0_.treeScale)
      _ARG_0_.treePan.y = _ARG_0_.treePan.y * (_ARG_1_ / _ARG_0_.treeScale) + _ARG_0_:GetTreePointerLocal(_ARG_2_, _ARG_3_, false) * (1 - _ARG_1_ / _ARG_0_.treeScale)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPinchCenterScreen"] = function(_ARG_0_)
    do
      if not U2.slua.isValid((U1.GetPlayerController(GetGameInstance(), 0))) then
        return nil, nil
      end
      if U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) then
        return (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) + U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) * 0.5, (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) + U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) * 0.5
      end
      do return nil, nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateTreePinchByTouch"] = function(_ARG_0_)
    do
      if not U2.slua.isValid((U1.GetPlayerController(GetGameInstance(), 0))) then
        return false
      end
      if not U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or not U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) then
        _ARG_0_._secondOrigin = nil
        if _ARG_0_.treePinch and _ARG_0_.treePinch.active then
          _ARG_0_.treePinch.active = false
        end
        return false
      end
      if _ARG_0_:GetActiveTalentGuideStep() then
        return false
      end
      if _ARG_0_.treePan.dragging and _ARG_0_.treePan.kind == U3(211, 39, 110, 17, 252) and (not _ARG_0_.treePinch or not _ARG_0_.treePinch.active) then
        if not _ARG_0_._secondOrigin then
          _ARG_0_._secondOrigin = {
            x = (_ARG_0_.treePan.touchIndex == 0 and 1 or 0) == 0 and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil),
            y = (_ARG_0_.treePan.touchIndex == 0 and 1 or 0) == 0 and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)
          }
          return false
        end
        if (((_ARG_0_.treePan.touchIndex == 0 and 1 or 0) == 0 and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) - _ARG_0_._secondOrigin.x) * (((_ARG_0_.treePan.touchIndex == 0 and 1 or 0) == 0 and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) - _ARG_0_._secondOrigin.x) + (((_ARG_0_.treePan.touchIndex == 0 and 1 or 0) == 0 and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) - _ARG_0_._secondOrigin.y) * (((_ARG_0_.treePan.touchIndex == 0 and 1 or 0) == 0 and U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) or U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) - _ARG_0_._secondOrigin.y) < U4 * U4 then
          return false
        end
        _ARG_0_._secondOrigin = nil
      end
      if not _ARG_0_.treePinch or not _ARG_0_.treePinch.active then
        _ARG_0_.treePinch = {
          active = true,
          lastDist = U2.math.sqrt((U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) + (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)))
        }
        _ARG_0_.treePan.dragging = false
        _ARG_0_.treePan.moved = true
        _ARG_0_._pressItem = nil
        if _ARG_0_.panTimer then
          _ARG_0_.panTimer = nil
        end
        _ARG_0_.pinchTimer = _ARG_0_:AddTimerLoop(0, function()
          if not _ENV:UpdateTreePinchByTouch() then
            if pinchTimer then
              _ENV:RemoveTimer(pinchTimer)
              pinchTimer = nil
            end
            pinchAccum = 0
          end
          return
        end, U2.TIMER_INFINITE, 0.03)
        return true
      end
      if _ARG_0_.treePinch.lastDist and 1 < _ARG_0_.treePinch.lastDist and 1 < U2.math.sqrt((U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) + (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil))) and U2.math.abs(U2.math.sqrt((U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) + (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil))) / _ARG_0_.treePinch.lastDist - 1) > 0.001 then
      end
      _ARG_0_.treePinch.lastDist = U2.math.sqrt((U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) + (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil))), (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) + U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) * 0.5, (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) + U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) * 0.5, _ARG_0_.treePinch, U2.math.sqrt((U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) + (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil))) / _ARG_0_.treePinch.lastDist, _ARG_0_:SetTreeScale(_ARG_0_.treeScale * (U2.math.sqrt((U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) + (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil)) * (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil) - U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil))) / _ARG_0_.treePinch.lastDist), (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) + U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) * 0.5, (U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(0, nil, nil, nil) + U1.GetPlayerController(GetGameInstance(), 0):GetInputTouchState(1, nil, nil, nil)) * 0.5)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshEdgeHint"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetEdgeAlpha"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_ then
        return
      end
      if 1 < _ARG_3_ and 0 < _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMouseWheel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not IsEditor then
        return U1.Unhandled()
      end
      if _ARG_0_:GetActiveTalentGuideStep() then
        return U1.Handled()
      end
      if _ARG_2_ then
      end
      if (U2.PointerEvent_GetWheelDelta(_ARG_2_) or 0) ~= 0 then
      end
      do return U1.Handled() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnChangeSelectScheme"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshAllTrees()
      _ARG_0_:HideDetail()
      if _ENV:GetCurSCheme() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnDataReady"] = function(_ARG_0_)
    do
      _ARG_0_.SimulateClick = true
      _ARG_0_._schemeRefreshedByCombo = false
      if _ARG_0_.jumpInfo and _ARG_0_.jumpInfo.form == U1(204, 39, 119) and _ARG_0_.jumpInfo.id then
        if _ENV:GetOneRecItem(_ARG_0_.jumpInfo.id) ~= nil then
        else
        end
        _ARG_0_.jumpInfo.id = nil
      end
      _ARG_0_._schemeRefreshedByCombo = nil
      if _ARG_0_._reopenTalentId then
        _ARG_0_._reopenTalentId = nil
        if not _ARG_0_._focusCentered and not _ARG_0_._focusCenterPending and _ARG_0_:CenterWidgetInTreeView(_ARG_0_:GetItemByTalentId(_ARG_0_._reopenTalentId) and _ARG_0_:GetItemByTalentId(_ARG_0_._reopenTalentId).UIRoot) then
          _ARG_0_._focusCentered = true
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Close"] = function(_ARG_0_)
    do
      _ARG_0_:RememberTreeScale()
      _ARG_0_:ResetTreeView()
      _ARG_0_ = _ARG_0_
      _ARG_0_.TreeList[nil] = nil
      _ARG_0_ = _ARG_0_
      if _ARG_0_.panTimer then
        _ARG_0_.panTimer = nil
      end
      if _ARG_0_.pinchTimer then
        _ARG_0_.pinchTimer = nil
      end
      if _ARG_0_.panPollTimer then
        _ARG_0_.panPollTimer = nil
      end
      if _ARG_0_.wheelPollTimer then
        _ARG_0_.wheelPollTimer = nil
      end
      if _ARG_0_.treePinch then
        _ARG_0_.treePinch.active = false
      end
      _ARG_0_.selectTalentNode = nil
      if _ENV:GetCurSCheme() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnResetClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnUseClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      U1:UseCurScheme()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnCloseClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.close_v1)
      U1:CloseSystem()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnQAClick"] = function(_ARG_0_)
    do
      _ARG_0_:OnButton_QA()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnTalentSelect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_0_:RememberTalentFocus(_ARG_3_)
      _ARG_0_.selectTalentItem = _ARG_4_
      if _ARG_0_.detailVisible and _ARG_0_.selectTalentId == _ARG_3_ then
        _ARG_0_._userOpenedDetail = false
        _ARG_0_:HideDetail()
        return
      end
      _ARG_0_._userOpenedDetail = true
      _ARG_0_:ShowDetail(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetDetailVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.UIRoot.CanvasPanel_Details then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_Details, _ARG_1_)
      end
      if _ARG_0_.UIRoot.Border_1 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Border_1, _ARG_1_)
      end
      if _ARG_0_.UIRoot.Button_TipsClose then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.Button_TipsClose, _ARG_1_, true)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideDetail"] = function(_ARG_0_)
    do
      _ARG_0_.detailVisible = false
      if _ARG_0_.selectTalentNode then
        _ARG_0_.selectTalentNode:UnBindDelegate(_ARG_0_)
        _ARG_0_.selectTalentNode = nil
      end
      _ARG_0_:ClearAllSelected()
      _ARG_0_.selectTalentId = nil
      _ARG_0_.selectTalentItem = nil
      _ARG_0_:SetDetailVisible(false)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowDetail"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.detailVisible = true
      _ARG_0_:SetDetailVisible(true)
      _ARG_0_:SelectTalentNode(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMinusClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.selectTalentNode or (_ARG_0_.selectTalentNode.addPoint or 0) <= 0 and not U1:IsIgnoreCheck() then
        return
      end
      if _ARG_0_.selectTalentId and 0 < _ARG_0_.selectTalentId and U1:DeletePoint(_ARG_0_.selectTalentId) and not U1:DeletePoint(_ARG_0_.selectTalentId).success and U1:DeletePoint(_ARG_0_.selectTalentId).failTip and U1:DeletePoint(_ARG_0_.selectTalentId).failTip ~= U2() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnAddClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if not _ARG_0_.selectTalentNode then
        return
      end
      if not U1:IsIgnoreCheck() then
        if not (not _ARG_0_.selectTalentNode.isUnlock and _ARG_0_.selectTalentNode.ComputeUnlock and _ARG_0_.selectTalentNode:ComputeUnlock()) then
          return
        end
        if _ARG_0_.selectTalentNode.talent and (_ARG_0_.selectTalentNode.addPoint or 0) >= (_ARG_0_.selectTalentNode.talent.maxPointNum or 0) then
          return
        end
      end
      if _ARG_0_.selectTalentId and 0 < _ARG_0_.selectTalentId then
        if U1:AddPoint(_ARG_0_.selectTalentId) and U1:AddPoint(_ARG_0_.selectTalentId).success then
        elseif U1:AddPoint(_ARG_0_.selectTalentId) and U1:AddPoint(_ARG_0_.selectTalentId).failTip and U1:AddPoint(_ARG_0_.selectTalentId).failTip ~= U3() then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSchemeAtrribChange"] = function(_ARG_0_)
    do
      if not _ENV:GetCurSCheme() then
        return
      end
      if _ENV:GetCurTemporaryData().temporary_point ~= nil and not _ENV:IsMaxTalentPlayer() then
        if 0 > _ENV:GetCurTemporaryData().temporary_point - _ENV:GetCurSCheme().addPointNum - _ENV:GetCurSCheme().havePointNum then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnApplyConfig"] = function(_ARG_0_)
    do
      _ARG_0_:RefreshTreeSummary()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateWeenked"] = function(_ARG_0_)
    do
      if _ARG_0_.weekTimer then
        _ARG_0_.weekTimer = nil
      end
      if _ENV:IsMaxTalentPlayer() or not _ARG_0_.UIRoot.TextBlock_InEffect then
        return
      end
      if _ENV:GetCurTemporaryData().temporary_point ~= nil and not _ENV:IsMaxTalentPlayer() then
        _ARG_0_.weekTimer = _ARG_0_:AddTimerLoop(0, function()
          if end_time - U1.GetServerTimeInSec() > 0 then
          elseif not U3.checkWeekendOver or U3.checkWeekendOver < 10 then
            U3.checkWeekendOver = U3.checkWeekendOver and U3.checkWeekendOver + 1 or 1
          end
          return
        end, U1.TIMER_INFINITE, 1)
      elseif _ENV:GetCurTemporaryData().start_time ~= -1 then
        _ARG_0_.weekTimer = _ARG_0_:AddTimerLoop(0, function()
          if start_time - U1.GetServerTimeInSec() > -3 then
          elseif not U4.checkWeekend then
            U4.checkWeekend = true
          end
          return
        end, U1.TIMER_INFINITE, 1)
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SelectTalentNode"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.selectTalentNode then
        _ARG_0_.selectTalentNode:UnBindDelegate(_ARG_0_)
      end
      if _ARG_0_.selectTalentId and _ARG_0_:GetItemByTalentId(_ARG_0_.selectTalentId) then
      end
      _ARG_0_.selectTalentId = _ARG_1_
      if _ENV:GetNodeByTalentId(_ARG_1_) then
        _ARG_0_.selectTalentNode = _ENV:GetNodeByTalentId(_ARG_1_)
        if _ARG_0_:GetItemByTalentId(_ARG_1_) then
        end
      else
        _ARG_0_.selectTalentNode = nil
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSlectNodeChange"] = function(_ARG_0_)
    do
      if not _ARG_0_.selectTalentNode or not _ARG_0_.selectTalentNode.talent then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBranchTypeColor"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.UIRoot.TextBlock_TalentType or not _ARG_0_.UIRoot.TextBlock_TalentType.SetActiveColorIndex then
        return
      end
      if (tonumber(_ARG_1_) or 1) - 1 < 0 then
      end
      if pcall(import, (U1(228, 58, 126, 19, 224, 89, 126, 195, 228, 76, 145, 162, 118, 167, 73, 79, 39, 10, 2, 44, 16, 76, 17, 244, 203, 82, 151, 174))) and pcall(import, (U1(228, 58, 126, 19, 224, 89, 126, 195, 228, 76, 145, 162, 118, 167, 73, 79, 39, 10, 2, 44, 16, 76, 17, 244, 203, 82, 151, 174))) and pcall(import, (U1(228, 58, 126, 19, 224, 89, 126, 195, 228, 76, 145, 162, 118, 167, 73, 79, 39, 10, 2, 44, 16, 76, 17, 244, 203, 82, 151, 174))).SynchronizePropertiesWidget and not pcall(function()
        SynchronizePropertiesWidget(U1)
        return
      end) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUnlockWarning"] = function(_ARG_0_, _ARG_1_)
    do
      if not (_ARG_1_ and _ARG_1_.talent) then
        return _ENV(), (_ENV())
      end
      if 0 < ((_ARG_1_ and _ARG_1_.talent).unlockBranchNeed or 0) then
        return U2.Format(_ENV(210, 38, 119, 29, 247, 91, 87, 200, 204, 70, 145, 152, 86, 185, 93, 68, 52, 16, 52, 38, 1, 116, 25, 255, 213), (_ARG_1_ and _ARG_1_.talent).unlockBranchNeed or 0), U2.Format(_ENV(210, 38, 119, 29, 247, 91, 87, 200, 204, 70, 145, 152, 86, 185, 93, 68, 52, 16, 52, 50, 22, 111, 31, 228, 220, 64, 150), U1:GetBranchAddPoint((_ARG_1_ and _ARG_1_.talent).branch), (_ARG_1_ and _ARG_1_.talent).unlockBranchNeed or 0)
      end
      goto lbl_122
      if ((_ARG_1_ and _ARG_1_.talent).preTalentNum or 1) <= (U1:GetNodeByTalentId(U2.Format(_ENV(210, 38, 119, 29, 247, 91, 87, 200, 204, 70, 145, 152, 86, 185, 93, 68, 52, 16, 52, 50, 22, 111, 31, 228, 220, 64, 150), U1:GetBranchAddPoint((_ARG_1_ and _ARG_1_.talent).branch), (_ARG_1_ and _ARG_1_.talent).unlockBranchNeed or 0)) and U1:GetNodeByTalentId(U2.Format(_ENV(210, 38, 119, 29, 247, 91, 87, 200, 204, 70, 145, 152, 86, 185, 93, 68, 52, 16, 52, 50, 22, 111, 31, 228, 220, 64, 150), U1:GetBranchAddPoint((_ARG_1_ and _ARG_1_.talent).branch), (_ARG_1_ and _ARG_1_.talent).unlockBranchNeed or 0)).addPoint or 0) then
      else
        ::lbl_122::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not true and 0 < #{} then
        return U2.Format(_ENV(210, 38, 119, 29, 247, 91, 87, 200, 204, 70, 145, 152, 68, 185, 89, 117, 57, 25, 6, 39, 23), U3.table.concat({}, (_ENV(139)))), (_ENV())
      end
      do return _ENV(), (_ENV()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshDetailWarning"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.selectTalentItem and _ARG_0_.selectTalentItem.IsLargeTalent and not _ARG_0_.selectTalentItem:IsLargeTalent() then
      end
      if false and _ARG_0_:GetUnlockWarning(_ARG_1_) == _ENV() then
      end
      if _ARG_0_.UIRoot.CanvasPanel_32 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshAddMinusText"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSlectNodeAtrribChange"] = function(_ARG_0_)
    do
      if not _ARG_0_.selectTalentNode or not _ARG_0_.selectTalentNode.talent then
        return
      end
      if (not _ARG_0_.selectTalentNode.talent[_ENV(203, 62) .. U1.tostring(_ARG_0_.selectTalentNode.addPoint) .. _ENV(227, 45, 104, 17)] or _ARG_0_.selectTalentNode.talent[_ENV(203, 62) .. U1.tostring(_ARG_0_.selectTalentNode.addPoint) .. _ENV(227, 45, 104, 17)] == _ENV()) and _ARG_0_.selectTalentNode.addPoint == 0 then
      end
      if (not _ARG_0_.selectTalentNode.talent.lv1Desc or _ARG_0_.selectTalentNode.talent.lv1Desc == _ENV()) and _ARG_0_.selectTalentNode.talent.subDesc and _ARG_0_.selectTalentNode.talent.subDesc ~= _ENV() then
      end
      if _ARG_0_.selectTalentNode.addPoint < (_ARG_0_.selectTalentNode.talent.maxPointNum or 0) then
      end
      if (_ARG_0_.selectTalentNode.ComputeUnlock and _ARG_0_.selectTalentNode:ComputeUnlock() or _ARG_0_.selectTalentNode.isUnlock) and not _ARG_0_.selectTalentNode.isUnlock then
        _ARG_0_.selectTalentNode.isUnlock = true
      end
      if U5:IsIgnoreCheck() then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpToWardrobeBag"] = function(_ARG_0_)
    do
      _ARG_0_.Jumpout = true
      _ENV:CloseSystem()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitTabComboBox"] = function(_ARG_0_)
    do
      _ARG_0_.TalentList = {}
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.ComboBox_Talent = _ARG_0_:InitCommonComboBoxNew(_ARG_0_.UIRoot.Common_ComboBox_UIBP)
      _ARG_0_.ComboBox_Talent:SetRefreshOptionCallback(_ARG_0_.OnRefreshComboBoxItem, _ARG_0_)
      _ARG_0_.ComboBox_Talent:SetSelectOptionCallback(_ARG_0_.OnSelectComboBoxItem, _ARG_0_)
      _ARG_0_.ComboBox_Talent:SetData(_ARG_0_.TalentList)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSelectComboBoxItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_.SimulateClick then
        _ARG_0_.SimulateClick = false
      else
        _ARG_0_:PlayAudio(sound_config.tab_v1)
      end
      if U1:GetCurSCheme() then
      end
      if _ARG_0_._schemeRefreshedByCombo ~= nil then
        _ARG_0_._schemeRefreshedByCombo = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnRefreshComboBoxItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_1_ and _ARG_1_.TextBlock_ItemName then
        _ARG_1_.TextBlock_ItemName:SetText(GetPageName(_ARG_2_.id))
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowTalentUpdateTips"] = function(_ARG_0_)
    do
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips1 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_UpdateTips1, false)
      end
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips2 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_UpdateTips2, false)
      end
      if not _ARG_0_.UIRoot.CanvasPanel_UpdateTips1 then
        return
      end
      if not _ENV:CheckUpdateTipsShow() then
        return
      end
      if (U1.DataMgr.GetNewbieGuideValue(U1.DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10) or 0) == 0 then
        return
      end
      if (U1.DataMgr.GetNewbieGuideValue(U1.DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10) or 0) == 1 or (U1.DataMgr.GetNewbieGuideValue(U1.DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10) or 0) == 2 then
      end
      if (U1.DataMgr.GetNewbieGuideValue(U1.DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10) or 0) == 1 then
        if _ARG_0_.UIRoot.CanvasPanel_UpdateTips2 then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_Tips1Click"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips1 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_UpdateTips1, false)
      end
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips2 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_UpdateTips2, true)
      end
      DataMgr.SetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10, 2)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_Tips2Click"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      if _ARG_0_.UIRoot.CanvasPanel_UpdateTips2 then
        _ARG_0_:SetWidgetVisible(_ARG_0_.UIRoot.CanvasPanel_UpdateTips2, false)
      end
      DataMgr.SetNewbieGuideValue(DataMgr.NEWBIE_GUIDE_MODULE_ID_XMISSION_TALENT, 10, 3)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_TipsCloseClick"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:HideDetail()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_LeftPoint"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_QA"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      UIManager.ShowUI(UIManager.UI_Config.xmission_talent_jump)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_RS"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      _ARG_0_:HideDetail()
      _ARG_0_:AddTimerOnce(0.1, function()
        if slua.isValid(U1.UIRoot) and U1.ComboBox_Talent then
          U1.ComboBox_Talent:CloseComboBox()
        end
        return
      end)
      UIManager.ShowUI(UIManager.UI_Config.Xmission_RecommondedPlan_UIBP)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnButton_WeekendHelp"] = function(_ARG_0_)
    do
      _ARG_0_:PlayAudio(sound_config.click_v1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
