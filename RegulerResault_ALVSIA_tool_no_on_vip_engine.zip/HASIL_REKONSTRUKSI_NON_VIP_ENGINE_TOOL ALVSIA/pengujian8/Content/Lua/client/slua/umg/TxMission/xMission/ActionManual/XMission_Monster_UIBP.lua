local TPlanPVEManualBestiaryData = require("GameLua.Mod.Lobby.Split.TPlanPVE.logic.ActionManual.TPlanPVEManualBestiaryData")
local XMission_Monster_UIBP = {}

function XMission_Monster_UIBP:ctor()
  self.curClueItemList = {}
end

function XMission_Monster_UIBP:OnInitialize()
  self.LoopScrollBox_List = self:InitChildClassScrollBox(self.UIRoot.LoopScrollBox_List, "client.slua.umg.TxMission.xMission.ActionManual.Item.XMission_Monster_Item02_UIBP")
end

function XMission_Monster_UIBP:RegistEvents()
  self:AddCommonEvent(EVENTTYPE_TPLANPVE_NORMAL, EVENTID_TPLANPVE_BESTIRAY_INFO_UPDATE, self.UpdateInfo, self)
end

function XMission_Monster_UIBP:OnPostInitialize()
  self:PlayUserWidgetAnimation(self.UIRoot.Fadein, 0, 1, 0, 1)
  self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(260866014))
  self:UpdateMonsterList(TPlanPVEManualBestiaryData.ENUM_MONSTER_TYPE.ALL)
end

function XMission_Monster_UIBP:OnClose()
  for index, value in pairs(self.curClueItemList) do
    for index2, value2 in ipairs(value) do
      value2:CloseSelf()
    end
  end
end

function XMission_Monster_UIBP:UpdateInfo(_, __, book_id)
  if self.monsterInfo and book_id == self.monsterInfo.BestiaryID then
    self:UpdateUI()
  end
end

function XMission_Monster_UIBP:UpdateMonsterList(monsterType)
  log(bWriteLog and "XMission_Monster_UIBP:UpdateUI")
  local item_data = TPlanPVEManualBestiaryData.GetMonsterList(monsterType)
  self.LoopScrollBox_List:SetData(item_data)
  self:SetSelectItem(1)
end

function XMission_Monster_UIBP:SetSelectItem(index)
  self.LoopScrollBox_List:Select(index)
  self.monsterInfo = self.LoopScrollBox_List:GetItemData(index)
  self.selectIndex = index
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  if logic_pve_action_manual:TryReqBestiaryInfo(self.monsterInfo.BestiaryID, true) then
    self:UpdateUI()
  end
end

function XMission_Monster_UIBP:UpdateUI()
  if not self.monsterInfo then
    return
  end
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  local info = logic_pve_action_manual:GetBestiaryInfo(self.monsterInfo.BestiaryID)
  if not info then
    logic_pve_action_manual:TryReqBestiaryInfo(self.monsterInfo.BestiaryID, true)
    return
  end
  self.UIRoot.Text_Content:SetText(self.monsterInfo.MonsterDesc)
  local isUnlock = logic_pve_action_manual:GetIsLockByBestiary(self.monsterInfo.BestiaryID)
  self.UIRoot.Text_Name:SetText(isUnlock and self.monsterInfo.MonsterName or LocUtil.GetLocalizeResStr(260866064))
  self:SetTexture(self.UIRoot.Image_Monster, isUnlock and self.monsterInfo.MonsterIcon or "/Game/Mod/TPlanLobby2D/XMission/NoAtlas/MonsterBestiary/illustration/MonsterBestiary_Monster_illustration01.MonsterBestiary_Monster_illustration01")
  self.lock_state = true
  local cur_clue = info.cur_clue
  local clue_list = TPlanPVEManualBestiaryData.GetClueListInfo(self.monsterInfo.MonsterClue)
  local clue_cout = #clue_list
  local UIUtil = require("client.common.ui_util")
  local r = UIUtil.IsRTL()
  self.UIRoot.WidgetSwitcher_0:SetActiveWidgetIndex(r and 1 or 0)
  self.UIRoot.TextBlock_0:SetText(LocUtil.GetLocalizeResStr(260866014))
  self.UIRoot.TextBlock_2:SetText(LocUtil.GetLocalizeResStr(260866014))
  self.UIRoot.TextBlock_1:SetText(LocUtil.LocalizeResFormat(7255, cur_clue, clue_cout))
  self.UIRoot.TextBlock_Num:SetText(LocUtil.LocalizeResFormat(7255, cur_clue, clue_cout))
  local cur_clue_data
  local unlock_clue_list = {}
  local lock_clue_list = {}
  for index, value in ipairs(clue_list) do
    if index == cur_clue + 1 then
      cur_clue_data = value
    elseif index > cur_clue + 1 then
      table.insert(lock_clue_list, {
        index = index,
        AttributeBonus = value.AttributeBonus,
        Exp = value.Exp,
        BeforeTextID = value.BeforeTextID
      })
    elseif cur_clue >= index then
      table.insert(unlock_clue_list, value)
    end
  end
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_Reveal, 0, 1, 0, 0)
  if logic_pve_action_manual:IsShowMonsterUnlockReddot(self.monsterInfo.BestiaryID) then
    self:PlayUserWidgetAnimation(self.UIRoot.Anim_Reveal, 0, 1, 0, 1)
  else
  end
  self:AddTimerOnce(0.01, function()
    if not self.UIRoot or not slua.isValid(self.UIRoot) then
      return
    end
    self:SetClueItems(1, self.UIRoot.WrapBox_Clues, UIManager.UI_Config.XMission_Monster_Item05_UIBP, unlock_clue_list, 1)
    self:SetClueItems(2, self.UIRoot.WrapBox_Clues01, UIManager.UI_Config.XMission_Monster_Item_UIBP, {cur_clue_data}, cur_clue)
    self:SetClueItems(3, self.UIRoot.WrapBox_Clues02, UIManager.UI_Config.XMission_Monster_Item04_UIBP, lock_clue_list)
    logic_pve_action_manual:SetMonsterUnlockReddot(self.monsterInfo.BestiaryID)
    logic_pve_action_manual:UpdateMonsterReddotData(1, self.monsterInfo.BestiaryID, cur_clue_data and self.lock_state)
  end)
end

function XMission_Monster_UIBP:SetClueItems(type, parent, UI_Config, data_list, i)
  i = i or 0
  self.curClueItemList[type] = self.curClueItemList[type] or {}
  local itemList = self.curClueItemList[type]
  for index, value in ipairs(itemList) do
    value:Collapsed()
  end
  if not data_list or not next(data_list) then
    return
  end
  for index, value in ipairs(data_list) do
    if not value or not next(value) then
      return
    end
    local widget = itemList[index]
    if not widget then
      widget = self:CreateChildWindow(parent, UI_Config)
      itemList[index] = widget
    end
    widget:Show()
    widget:UpdateData(value, i + index - 1)
  end
end

function XMission_Monster_UIBP:UnlockMonster()
  if not self.lock_state then
    ShowNotice(260866069)
    return false
  end
  self:PlayUserWidgetAnimation(self.UIRoot.Anim_Reveal, 0, 1, 0, 1)
  local logic_pve_action_manual = ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_pve_action_manual)
  local id = self.monsterInfo.BestiaryID
  local mosnterInfo = logic_pve_action_manual:GetBestiaryInfo(id)
  local cur_clue = mosnterInfo.cur_clue
  logic_pve_action_manual:DelayExecute(id, 1.2, function()
    TPlanPVEManualBestiaryData.RevealingClues(id, cur_clue)
  end)
  return true
end

local class = require("class")
local ui_base = require("client.slua_ui_framework.base")
return class(ui_base, nil, XMission_Monster_UIBP)
