do return {
  globalUIFunctionLibrary = nil,
  globalLuaUaeWidgetTable = {},
  ClickFrequencyLimit = {
    setting_bindchoice_panel = {5, 0},
    guest_bind_main = {5, 0},
    BindPhoneMail = {5, 0},
    MailInviteWait = {5, 0},
    EditorStartGame = {5, 0},
    TeamPlatform_UIBP_Base = {0.5, 0},
    GoToIsland = {0.5, 0},
    HallThemeSwitch = {0.5, 0},
    InGameWebview = {0.5, 0},
    SettingShare = {0.5, 0},
    SidebarBanner = {0.5, 0},
    TPlan_TeamPlatform_MyTeam_UIBP = {0.5, 0},
    ui_recharge_gas_station = {0.5, 0},
    TeamPlatform_MyTeam_UIBP = {0.5, 0},
    subtab_suit = {0.5, 0},
    EntryVisitHome = {0.5, 0},
    EntryVisitCollectionHall = {1.1, 0},
    OpenCollectionHallDetail = {0.4, 0},
    WardrobeUndo = {0.5, 0},
    WardrobeGunSubTab = {0.5, 0},
    MentorPageSwitch = {0.5, 0},
    CorpsEnergyMission = {0.5, 0},
    SecretStoreRefresh = {0.5, 0},
    MomentClick = {0.5, 0},
    JoinTeam = {0.5, 0},
    SeasonCycleAwardItem = {0.5, 0},
    ChatVoice = {0.5, 0},
    LobbyModel = {0.5, 0},
    LimitedTimeGift = {0.5, 0},
    ReturnActivity_Suit_UIBP = {0.5, 0},
    ExpressionPopUIBP = {0.5, 0},
    ReturnActivity_Newest_UIBP = {0.5, 0},
    ReturnActivity_TreasureChest_UIBP = {0.5, 0},
    ui_moment_add_photo = {0.5, 0},
    ui_moment_tab_photo_detail = {0.5, 0},
    NewCameraPhotoSwitch = {1, 0},
    UpgradePendant = {0.5, 0},
    Exchange = {0.8, 0},
    logic_display_setting = {0.5, 0},
    WardrobeAvatarItemClick = {1, 0},
    setting_account_protect = {0.5, 0},
    Sociallsland_SelectMap_UIBP = {0.5, 0},
    StoreTab = {0.5, 0},
    StoreItem = {0.5, 0},
    StoreCollectionBtn = {0.5, 0},
    CrateCollectionBtn = {0.5, 0},
    XSuit_Workshop_Main_UIBP = {0.5, 0},
    XSuitPreview_Tab = {0.5, 0},
    XSuitSpin_QuickUpgrade = {0.5, 0},
    UnknowPassTab = {0.5, 0},
    suit_dye_main = {0.5, 0},
    ActivitySwitch = {0.5, 0},
    LegendWeaponSwitch = {0.5, 0},
    ActivityTab = {0.5, 0},
    ActivityGetBtn = {0.5, 0},
    WardrobeChangeRolewear = {0.5, 0},
    WardrobeVehicleTab = {0.5, 0},
    WardrobeVehicleItem = {0.5, 0},
    WardrobeFeatureTrigger = {1, 0},
    RankTab = {0.5, 0},
    SpaceSecrecySetting = {0.5, 0},
    SubwayHistory = {0.5, 0},
    InviteJoinCarTeam = {0.5, 0},
    APlanAwardUpgrade = {0.5, 0},
    DrawJumpExchange = {0.5, 0},
    TarotCardDraw = {0.5, 0},
    UGCAuthorFollow = {1, 0},
    UGCAppreciationGetAward = {1, 0},
    UGCCommentReplyTab = {1, 0},
    CarIllustratedBook = {0.5, 0},
    RoleInfoPopularityUI = {0.5, 0},
    roleinfo_main = {0.5, 0},
    corps_suggestion = {0.5, 0},
    PlayGame_Award_Sub_UIBP = {0.5, 0},
    Rank_Award_Sub_UIBP = {0.5, 0},
    PlanPH_Template_Select = {0.5, 0},
    PlanPH_Rec_Home_Req = {0.5, 0},
    Theme_System_Tab = {0.5, 0},
    Theme_System_Task_Button = {1, 0},
    PopularHomePKTab = {0.5, 0},
    PHomeTreeTab = {0.5, 0},
    PopularBoxTab = {0.5, 0},
    PopularBoxAward = {0.5, 0},
    PopularGiftPlayerClick = {0.5, 0},
    PKSocialTaskGetReward = {1, 0},
    HomeTaskAwardClick = {0.5, 0},
    SportsCarDrawClick = {0.5, 0},
    PlanPH_Crystal_Tab = {0.5, 0},
    PlanPH_CrystalGetReward = {0.5, 0},
    PlanPH_ParkingLot_Tab = {0.5, 0},
    Kol_Tab = {0.5, 0},
    Kol_SubTab = {0.5, 0},
    Kol_Card = {0.5, 0},
    Collect_Inherit = {0.5, 0},
    PetCarry = {0.5, 0},
    CreateAICover = {0.5, 0},
    DelAICover = {0.5, 0},
    WeddingActivityTab = {0.5, 0},
    Fission_Tab = {0.5, 0},
    Fission_Award = {0.5, 0},
    Fission_Inviter_Tab = {0.5, 0},
    MineSubTab = {1, 0},
    AssemblyTab = {1, 0},
    Character_Exchange_Tab = {0.5, 0},
    RPXYearBox = {0.5, 0},
    MusicItem = {0.5, 0},
    FriendApplyTranslate = {0.5, 0},
    LobbyBtn = {0.5, 0},
    Wardrobe = {0.5, 0},
    TaskPageSwitch = {0.5, 0},
    SubscribeStoreTab = {0.5, 0},
    MailTab = {0.5, 0},
    PictorialTab = {0.5, 0},
    PictorialItem = {0.5, 0},
    LobbyPaint = {7, 0},
    WeaponDiffColor = {1, 0},
    ReplaceEmoticonBubbles = {1, 0},
    ReplaceCharacterAction = {1, 0},
    SyncLobbyEmotion = {1, 0},
    UpgradeWeapon = {2, 0},
    UpgradeGunAttach = {0.5, 0},
    PutOnWeapon = {1, 0},
    PutOnWeaponPendant = {0.5, 0},
    PutOffWeaponPendant = {0.5, 0},
    PetChangeSize = {1, 0},
    PetShareConfig = {1, 0},
    HomeShare = {1, 0},
    WeddingActivityPublish = {1, 0},
    WeddingActivityRefreshList = {1, 0},
    SportCarPopClick = {0.5, 0},
    PlanPHTeleportToPlayerStart = {3, 0},
    PlanPHMsgBoard = {0.5, 0},
    PlanPHDrawing = {0.5, 0},
    PlanPHThemeSetChange = {2, 0},
    PlanPHThemeSetBuy = {2, 0},
    PlanPHGiftBoxPut = {2, 0},
    UGCRecommendVideo = {2, 0},
    PlanPHGoldenTreeCollect = {0.5, 0},
    PlanPHGoldenTreePlant = {0.5, 0},
    PlanPHGoldenTreeBuyClick = {0.5, 0},
    PlanPHGoldenTreeWater = {0.5, 0},
    PlanPHGoldenTreeFeed = {0.5, 0},
    PlanPHLevelUpClick = {0.5, 0},
    PlanPHEditHomeSave = {5.5, 0},
    ChatRoomShareToWorld = {0.5, 0},
    ChatRoomShareToTopic = {0.5, 0},
    ChatRoomShareToCorps = {0.5, 0},
    ChatRoomShareToFriend = {0.5, 0},
    PhoneMailVerify = {1, 0},
    ChatRoomChannelTab_1 = {0.5, 0},
    ChatRoomChannelTab_2 = {0.5, 0},
    ChatRoomChannelTab_3 = {0.5, 0},
    ChatRoomChannelTab_4 = {0.5, 0},
    ChatRoomChannelTab_5 = {0.5, 0},
    ChatRoomSetTopic = {3.5, 0},
    ChatRoomAnswerTopic = {30, 0},
    GoldenSuitChangeHeadUnlock = {0.5, 0},
    ClickLudoInvite = {10, 0},
    PlanPHReEnterRoom = {5, 0},
    LudoInviteToWorld = {0.5, 0},
    LudoInviteToTopic = {0.5, 0},
    LudoInviteToCorps = {0.5, 0},
    LudoInviteToFriend = {0.5, 0},
    LudoInviteToManor = {0.5, 0},
    HalloweenHowl = {2, 0},
    HalloweenCatch = {0.5, 0},
    HalloweenInvite = {30, 0},
    HalloweenPlaceGift = {3, 0},
    HalloweenPaintDecal = {1, 0},
    HomeStyleGetNominateAward = {1, 0},
    HomeStyleRefreshRecommendList = {3, 0},
    HomeStyleNominateHome = {1, 0},
    SnowPartyEnterGame = {0.5, 0},
    SnowPartyInvite = {30, 0},
    SnowPartyBuyShop = {0.5, 0},
    SnowPartyGetReward = {1, 0},
    PlanPHCarParkingUpgrade = {0.5, 0},
    PlanPHCarParkingGetCarGift = {0.5, 0},
    PlanPHCarParkingInviteParking = {0.2, 0},
    PlanPHCarParkingParkCar = {5, 0},
    PlanPHCarParkingAutoPark = {0.5, 0},
    PlanPHCarParkingRankTab = {0.5, 0},
    GCByObjectOrMemory = {10, 0},
    LowGCByObjectOrMemory = {5, 0},
    DropAvatarFeatureNotice = {60, 0},
    CollectLibraryThemeBatch = {1, 0},
    SeasonSwitchButton = {1, 0},
    SettingPrivacySwitchButton = {1, 0},
    WoWTabSwitchButton = {1, 0},
    NewWoWTabSwitchButton = {0.8, 0},
    UGCInventorySwitchButton = {0.5, 0},
    FilterTagRefresh = {1, 0},
    PlanPHSearchPlan = {3, 0},
    PlanPHLobbyClickStore = {2, 0},
    HomeScanQRClick = {2, 0},
    BlackFridayVote = {0.5, 0},
    BlackFridayGroupBuyShare = {2, 0},
    BlackFridayUpgradePreview = {2, 0},
    BlackFridaySubJoinGroup = {2, 0},
    BlackFridayRPJoinGroup = {2, 0},
    BlackFridayRPInviteAllFriend = {5, 0},
    BlackFridaySubInviteAllFriend = {1, 0},
    NewbieModeSelectionAward = {1, 0},
    ModeSelectionSideberCollect = {1, 0},
    SearchGuessRefreshClick = {1, 0},
    PlanPH_PartyMain_UIBP_TabClick = {1, 0},
    ThemeRefreshBtnClick = {0.5, 0},
    PlanPHNewbieGuideHandle = {0.2, 0},
    SeasonShopBtnClick = {0.5, 0},
    ScrapGoldDiscount = {0.5, 0},
    MainCityPrivacySetting = {1, 0},
    MainCityInviteToWorld = {60, 0},
    MainCityInviteToTopic = {60, 0},
    MainCityInviteToMainCity = {60, 0},
    MainCityInviteToCorps = {60, 0},
    MainCityInviteToFriend = {60, 0},
    MainCityInviteToManor = {60, 0},
    MainCityEnterSeesawBattle = {1, 0},
    MainCityMatch = {10, 0},
    MainCityTryReEnter = {5, 0},
    MainCityMainRingBtnClickSimple = {3, 0},
    MainCityMainRingBtnClick = {8, 0},
    MainCityContinusSkillBtnClick = {3, 0},
    MainCityMultiposeBtnClick = {3, 0},
    MainCityH5PlatformRouteClickItem = {3, 0},
    InteractiveCommon = {0.5, 0},
    ExploreAwardBtnClick = {1, 0},
    SpecialOfferTemu = {0.5, 0},
    PopularPKShareToFriend = {3, 0},
    CreateWalletWithdrawalClick = {1, 0},
    CreateWalletIncomeAndWithdrawalClick = {1, 0},
    CreateWalletOneTabClick = {1, 0},
    ActiveMotivationApplyForClick = {0.5, 0},
    ActiveMotivationClaimRewardsClick = {0.5, 0},
    NewMapDailyRefreshBtnClick = {0.7, 0},
    WeaponStrengthPopSecondTabClick = {1.5, 0},
    MainCityQueryPlayerState = {0.5, 0},
    ConquerorVideoPlayLimit = {1, 0},
    ChangeUGCAuthorSkin = {1.2, 0},
    CreativeGameParamUI = {2, 0},
    CreativeGameParamSubTabUI = {0.5, 0},
    CreativeAIGCAssetBtnClick = {0.5, 0},
    BlockyluaCustomInput = {2, 0},
    CreativeCreativityRankSwitch = {3, 0},
    UsePromotionCard = {4, 0},
    WowPassTask = {0.5, 0},
    StopAction = {0.1, 0},
    PrefabSearchBtn = {1, 0},
    AiCopilotChatStopBtnClick = {3, 0},
    CommonOneSeconds = {1, 0},
    PrefabMallTab = {1.5, 0},
    PrefabMallAddFavorite = {1, 0},
    PrefabMallAddLike = {1, 0},
    PrefabOfficialSend = {3, 0},
    PrefabOfficialCollectionSend = {3, 0},
    PrefabMallMyShare = {10, 0},
    PrefabMallMyFavorite = {10, 0},
    PrefabMallMyShareAndFavorte = {10, 0},
    BackPackCustomPrefab = {10, 0},
    PrefabMallReqBin = {1, 0},
    PrefabMallPrefabAllowSecondEditFilterButton = {1.1, 0},
    PrefabMallUpload = {3, 0},
    PrefabMallUploadConfirm = {1, 0},
    PrefabMallCollectionSave = {3, 0},
    PrefabMallCollectionRelease = {3, 0},
    PrefabMallCollectionDelete = {3, 0},
    UGCAcceptChallengeChat = {1, 0},
    UGCTemplateTab = {1, 0},
    UGCRankTab = {0.5, 0},
    PromotionStatusPrivacySetting = {1, 0},
    ChatPlaerRecommandSideBarRefresh = {3, 0},
    PlanCHDisplayEditClearData = {1, 0},
    PlanCHDisplayEditSaveBackgroundData = {1, 0},
    PlanCHDisplayEditSaveData = {1.5, 0},
    PlanCHDisplayAutoEditData = {3, 0},
    PlanCHDisplayEditSwitchHallPart = {0.1, 0},
    PlanCHTeleport = {2, 0},
    PlanCHClickCommon = {1, 0},
    UGC_WOW_COIN = {1, 0},
    UGC_APPRECIATION_BUTTON = {1, 0},
    UGC_PREFAB_MALL_CLICK = {1.5, 0},
    SubtabCabinShowPageClick = {1.5, 0},
    CardCollectionGetAward = {1.5, 0},
    CardCollectionOpenLuckyBag = {1.5, 0},
    UGCPublishStateChange1 = {0.5, 0},
    UGCPublishStateChange2 = {0.5, 0},
    UGCPublishStateChange3 = {1, 0},
    UGCSetSharePermit1 = {1, 0},
    UGC_HALL_MOD_CLICK = {0.5, 0},
    UGC_MOD_CLICK = {1, 0},
    UGC_Friend_Create_Req = {2, 0},
    UGCLLMDiag = {3, 0},
    UGCPromotionNoticeListItem = {1, 0},
    FinancialTaskRewardReceive = {1.1, 0},
    UGCAppreciationGroupJoin = {0.5, 0},
    TeamQuickSkinUseAndRemove = {2, 0},
    TeamQuickInviteTeamUp = {5, 0},
    TeamQuickInviteToWorld = {60, 0},
    TeamQuickInviteToCorps = {60, 0},
    TeamQuickSwitchTeam = {1, 0},
    PlanCHArenaMatch = {2, 0},
    PlanCHArenaContinue = {2, 0},
    PlanCHArenaPetUpgrade = {0.5, 0},
    PlanCHArenaPetUse = {1, 0},
    PlanCHArenaSkillChange = {1, 0},
    PlanCHArenaSkillUpgrade = {0.5, 0},
    PlanCHArenaAutoLineup = {2, 0},
    PlanCHArenaSkillLearn = {0.5, 0},
    PlanCHArenaSkillReplaceOK = {1, 0},
    PlanCHArenaBattleConfirm = {1, 0},
    PlanCHArenaBuffConfirm = {1, 0},
    PlanCHArenaAddBattle = {1, 0},
    PlanCHArenaExchange = {1, 0},
    PlanCHArenaChallenge = {2, 0},
    PlanCHArenaPlayback = {2, 0},
    SeasonActiveExchangeOpenEgg = {1, 0},
    SeasonActiveExchangeMatchGameDropEgg = {0.5, 0}
  },
  ModuleFrequencyLimit = {
    LobbyVehicle = {3, 0},
    LobbyVehicleAccessory = {3, 0}
  },
  DefaultCommonIcon = (function(_ARG_0_, _ARG_1_)
    do
      if IsFITVersion() then
        return _ARG_0_
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end)(table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 189, 39, 133, 56, 227, 73, 145, 172, 212, 117, 4, 144, 107, 8, 153, 118, 226, 22, 206, 31, 185, 106, 169, 230, 252, 112, 89, 170, 114, 48, 153, 97, 179, 54),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(249, 161, 19, 30, 100, 118, 181, 33, 148, 38, 147, 70, 176, 226, 238, 118, 3, 149, 81, 113, 203, 55, 207, 10, 140, 54, 179, 98, 151, 218, 228, 97, 27, 179, 68, 57, 139, 103, 254, 16),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(255, 147, 78, 64)
  }), (table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 66, 46, 152, 123, 245, 58, 175, 52, 157, 120, 164, 242, 227, 43, 53, 131, 115, 60, 133, 103, 179, 38),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(254, 163, 14, 94, 73, 70, 145, 56, 158, 37, 147, 85, 172, 230, 237, 75, 60, 148, 111, 47, 152, 124, 229, 75, 162, 52, 177, 97, 167, 253, 207, 77, 2, 137, 115, 14, 176, 97, 253, 27),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(244, 169, 23)
  }))),
  DefaultSingleSniperIcon = (function(_ARG_0_, _ARG_1_)
    do
      if IsFITVersion() then
        return _ARG_0_
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end)(table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 189, 39, 133, 56, 227, 73, 145, 172, 212, 117, 4, 144, 107, 8, 153, 118, 226, 22, 206, 31, 185, 106, 169, 230, 252, 112, 89, 170, 114, 48, 153, 97, 179, 54),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(249, 161, 19, 30, 100, 118, 181, 33, 148, 38, 147, 77, 177, 226, 238, 115, 30, 149, 107, 30, 202, 41, 188, 81, 190, 25, 176, 109, 171, 248, 190, 71, 25, 129, 115, 62, 132, 86, 213, 1),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(243, 161, 33, 32, 99, 72, 146, 50, 137, 34, 169, 67, 232, 179, 176, 32, 57, 190, 98, 32, 153, 114)
  }), (table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 66, 46, 152, 123, 245, 58, 175, 52, 157, 120, 164, 242, 227, 43, 53, 131, 115, 60, 133, 103, 179, 38),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(254, 163, 14, 94, 73, 70, 145, 56, 158, 37, 147, 85, 172, 230, 237, 75, 55, 149, 111, 47, 157, 97, 229, 0, 190, 107, 236, 60, 252, 189, 211, 107, 27, 129, 113, 63, 181, 64, 232, 16),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(251, 147, 47, 24, 107, 71, 155, 45, 152, 46, 147, 44, 232, 179, 180)
  }))),
  DefaultBurstSniperIcon = (function(_ARG_0_, _ARG_1_)
    do
      if IsFITVersion() then
        return _ARG_0_
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end)(table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 189, 39, 133, 56, 227, 73, 145, 172, 212, 117, 4, 144, 107, 8, 153, 118, 226, 22, 206, 31, 185, 106, 169, 230, 252, 112, 89, 170, 114, 48, 153, 97, 179, 54),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(249, 161, 19, 30, 100, 118, 181, 33, 148, 38, 147, 77, 177, 226, 238, 115, 30, 149, 107, 30, 202, 41, 188, 83, 190, 25, 176, 109, 171, 248, 190, 71, 25, 129, 115, 62, 132, 86, 213, 1),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(243, 161, 33, 32, 99, 72, 146, 50, 137, 34, 169, 67, 232, 179, 176, 34, 57, 190, 98, 32, 153, 114)
  }), (table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 66, 46, 152, 123, 245, 58, 175, 52, 157, 120, 164, 242, 227, 43, 53, 131, 115, 60, 133, 103, 179, 38),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(254, 163, 14, 94, 73, 70, 145, 56, 158, 37, 147, 85, 172, 230, 237, 75, 55, 149, 111, 47, 157, 97, 229, 0, 190, 107, 236, 60, 254, 189, 211, 107, 27, 129, 113, 63, 181, 64, 232, 16),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(251, 147, 47, 24, 107, 71, 155, 45, 152, 46, 147, 44, 232, 179, 182)
  }))),
  DefaultWardrobeSuitIcon = (function(_ARG_0_, _ARG_1_)
    do
      if IsFITVersion() then
        return _ARG_0_
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end)(table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 189, 39, 133, 56, 227, 73, 145, 172, 212, 117, 4, 144, 107, 8, 153, 118, 226, 22, 206, 31, 185, 106, 169, 230, 252, 112, 89, 170, 114, 48, 153, 97, 179, 54),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(249, 161, 19, 30, 100, 118, 181, 54, 158, 37, 147, 95, 180, 236, 244, 124, 3, 143, 81, 113, 203, 55, 207, 10, 140, 54, 179, 98, 151, 218, 243, 107, 24, 179, 93, 61, 133, 125, 244, 16),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(229, 147, 78, 64)
  }), (table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 66, 46, 152, 123, 245, 58, 175, 52, 157, 120, 164, 242, 227, 43, 53, 131, 115, 60, 133, 103, 179, 38),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(254, 163, 14, 94, 73, 70, 145, 56, 158, 37, 147, 85, 172, 230, 237, 75, 32, 137, 125, 41, 147, 70, 187, 75, 162, 52, 177, 97, 167, 253, 207, 77, 2, 137, 115, 14, 172, 124, 239, 29),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(255, 147, 73)
  }))),
  DefaultChangeIcon = (function(_ARG_0_, _ARG_1_)
    do
      if IsFITVersion() then
        return _ARG_0_
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end)(table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 189, 39, 133, 56, 227, 73, 145, 172, 212, 117, 4, 144, 107, 8, 153, 118, 226, 22, 206, 31, 185, 106, 169, 230, 252, 112, 89, 170, 114, 48, 153, 97, 179, 54),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(249, 161, 19, 30, 100, 118, 181, 54, 158, 37, 147, 95, 176, 226, 238, 115, 3, 163, 62, 112, 212, 90, 227, 8, 140, 52, 178, 83, 129, 240, 255, 106, 41, 175, 118, 48, 132, 110, 249, 42),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(166, 253)
  }), (table.concat({
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 66, 46, 152, 123, 245, 58, 175, 52, 157, 120, 164, 242, 227, 43, 53, 131, 115, 60, 133, 103, 179, 38),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(254, 163, 14, 94, 73, 70, 145, 56, 158, 37, 147, 85, 187, 236, 238, 75, 37, 148, 111, 47, 157, 124, 162, 38, 142, 54, 177, 99, 166, 204, 217, 103, 25, 130, 65, 18, 130, 104, 242, 18),
    (function(...)
      do return table.concat({
        [...] = string.char((({
          ...
        })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
      }) end
      return
    end)(243)
  }))),
  ["PickPackageIcon"] = function(_ARG_0_, _ARG_1_)
    do
      if IsFITVersion() then
        return _ARG_0_
      end
      do return _ARG_1_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CanClickNow"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ == nil then
        _ENV(U1.bWriteLog and U1.table.concat({
          U2(195, 133, 43, 5, 99, 69, 210, 22, 144, 37, 143, 112, 177, 224, 235, 90, 9, 139, 34, 97, 148, 118, 172, 12, 143, 61, 179, 44, 169, 253, 244, 36, 26, 137, 106, 113, 131, 125, 188, 18),
          U2(249, 226)
        }))
        return true
      end
      if _ARG_1_ == nil then
        _ARG_1_ = true
      end
      if U4(U3((U2(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).GetServerTimeInSecWithFraction() - _ARG_0_[2]) < _ARG_0_[1] then
        if _ARG_1_ then
        end
        return false
      else
        _ARG_0_[2] = U3((U2(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).GetServerTimeInSecWithFraction()
        return true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckClickCooldownSilently"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil then
        _ENV(U1.bWriteLog and U1.table.concat({
          U2(195, 133, 43, 5, 99, 69, 210, 22, 153, 46, 175, 119, 155, 239, 233, 119, 13, 191, 97, 46, 150, 125, 227, 18, 143, 8, 181, 96, 173, 253, 228, 104, 15, 192, 62, 63, 133, 41, 245, 27),
          U2(240, 163, 94, 16, 100, 77, 220, 57, 148, 63, 236, 117, 172, 163, 231, 123, 72)
        }))
        return true
      end
      if U4(U3((U2(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).GetServerTimeInSecWithFraction() - _ARG_0_[2]) < _ARG_0_[1] then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BoolToVisible"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == nil then
        _ARG_1_ = true
      end
      if _ARG_0_ then
        if _ARG_2_ then
          return ESlateVisibility.Visible
        else
          return ESlateVisibility.SelfHitTestInvisible
        end
      elseif _ARG_1_ then
        return ESlateVisibility.Collapsed
      else
        return ESlateVisibility.Hidden
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWidgetVisible"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_ then
        return
      end
      if _ARG_1_ then
        if _ARG_2_ then
          _ARG_0_:SetWidgetVisibility(ESlateVisibility.Visible)
        else
          _ARG_0_:SetWidgetVisibility(ESlateVisibility.SelfHitTestInvisible)
        end
      else
        _ARG_0_:SetWidgetVisibility(ESlateVisibility.Collapsed)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWidgetVisible"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return false
      end
      do return _ARG_0_:GetVisibility() == ESlateVisibility.Visible or _ARG_0_:GetVisibility() == ESlateVisibility.SelfHitTestInvisible or _ARG_0_:GetVisibility() == ESlateVisibility.HitTestInvisible end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGameInstance"] = function()
    if _ENV(U1.slua_GameFrontendHUD) then
      return U1.slua_GameFrontendHUD:GetGameInstance()
    end
    do return U2((U3(197, 152, 59, 9, 126, 91, 157, 18, 144, 38, 169, 85, 182, 240, 244, 117, 8, 159, 107))).GetInstance() end
    return
  end,
  ["GetGameFrontendHUD"] = function()
    do return GetGameInstance():GetAssociatedFrontendHUD() end
    return
  end,
  ["GetFirstGameFrontendHUD"] = function()
    if U2((_ENV((U1(209, 173, 19, 20, 72, 72, 159, 62, 148, 37, 168, 84, 141, 199))).GetInstance())) then
      return _ENV((U1(209, 173, 19, 20, 72, 72, 159, 62, 148, 37, 168, 84, 141, 199))).GetInstance():GetFirstGameFrontendHUD()
    end
    do return nil end
    return
  end,
  ["GetGlobalUIFunctionLibrary"] = function()
    if globalUIFunctionLibrary == nil then
      globalUIFunctionLibrary = U1((U2.table.concat({
        U3(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 153, 85, 135, 214, 244, 125, 10, 149, 122, 56, 213, 94, 224, 10, 131, 58, 176, 89, 129, 213, 229, 106, 21, 152, 119, 62, 132, 69, 245, 23),
        U3(228, 173, 12, 8, 36, 110, 144, 58, 147, 42, 160, 73, 145, 197, 245, 122, 5, 136, 103, 46, 148, 85, 229, 7, 147, 58, 174, 117, 151, 208)
      })))
    end
    do return globalUIFunctionLibrary end
    return
  end,
  ["SetCornerQuality"] = function(_ARG_0_, _ARG_1_)
    do
      GetGlobalUIFunctionLibrary().SetCornerQuality(_ARG_0_, _ARG_1_, GetGameInstance())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCommonItemFunctionLibrary"] = function()
    if commonItemFunctionLibrary == nil then
      commonItemFunctionLibrary = U1((U2.table.concat({
        U3(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 153, 85, 135, 207, 239, 115, 15, 159, 33, 2, 149, 116, 225, 10, 143, 116, 159, 99, 165, 254, 255, 106, 63, 152, 123, 60, 172, 124, 242, 22),
        U3(226, 165, 17, 31, 70, 64, 158, 39, 144, 57, 181, 50, 155, 236, 237, 121, 9, 146, 71, 53, 159, 116, 202, 16, 143, 56, 168, 101, 167, 253, 220, 109, 20, 158, 127, 35, 147, 86, 223)
      })))
    end
    do return commonItemFunctionLibrary end
    return
  end,
  ["SetItemIconAndQuality"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      _ARG_5_ = _ARG_5_ or 0
      GetCommonItemFunctionLibrary().SetItemIconAndQuality(_ARG_0_, _ARG_5_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, GetGameInstance())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBigItemIconAndQuality"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      GetCommonItemFunctionLibrary().SetBigItemIconAndQuality(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, GetGameInstance())
      if not U1.GetTableData(U2(223, 184, 27, 28), _ARG_0_) then
        return
      end
      if _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowItemTips"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CloseItemTips"] = function()
    GetGlobalUIFunctionLibrary().CloseItemTips(GetGameInstance())
    return
  end,
  ["OpenUseItemUI"] = function(_ARG_0_)
    do
      GLOBAL_USE_ITEM = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNationImage"] = function(_ARG_0_, _ARG_1_)
    do
      UpdateNationImageByLua(_ARG_0_, _ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNationImageByLua"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if GlobalData.GetNationSwitch((U1(215, 160, 18))) and _ARG_1_ ~= U1() then
        if GlobalData.GetNationInfo(_ARG_1_) and GlobalData.GetNationInfo(_ARG_1_).res_path then
        end
      elseif GlobalData.GetNationSwitch((U1(215, 160, 18))) and _ARG_2_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAdaptation"] = function(_ARG_0_)
    do
      if not isValid(_ARG_0_) then
        return
      end
      if not U1.Game:IsValid(U2) then
        return
      end
      if U3((U4(185, 159, 29, 3, 99, 89, 136, 122, 164, 6, 139, 50, 141, 240, 229, 102, 49, 149, 106, 38, 159, 109))) and U1.Game:IsClassOf(_ARG_0_, (U3((U4(185, 159, 29, 3, 99, 89, 136, 122, 164, 6, 139, 50, 141, 240, 229, 102, 49, 149, 106, 38, 159, 109))))) then
        return
      end
      if not _ARG_0_.Slot then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetScreenPadding"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScreenPadding"] = function()
    do return _ENV((U1(197, 175, 12, 24, 122, 93, 180, 48, 157, 59, 169, 110, 155, 239, 233, 113, 8, 136))).GetScreenPadding() end
    return
  end,
  ["GetWidgetByPath"] = function(_ARG_0_)
    do
      if _ENV((U1(193, 165, 26, 22, 111, 93, 190, 57, 132, 46, 188, 110, 177, 237, 244, 88, 15, 158, 124, 32, 136, 96))).GetAllWidgetsOfClass(U5.GetGameInstance(), U3.Array(U4.EPropertyClass.Object, (U2(_ARG_0_))), U2(_ARG_0_), false):Num() >= 1 then
        return _ENV((U1(193, 165, 26, 22, 111, 93, 190, 57, 132, 46, 188, 110, 177, 237, 244, 88, 15, 158, 124, 32, 136, 96))).GetAllWidgetsOfClass(U5.GetGameInstance(), U3.Array(U4.EPropertyClass.Object, (U2(_ARG_0_))), U2(_ARG_0_), false):Get(0)
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLogicManagerByName"] = function(_ARG_0_)
    do
      do return slua_GameFrontendHUD:GetLogicManagerByName(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLuaObjectByLogicName"] = function(_ARG_0_)
    do
      do return slua_GameFrontendHUD:GetLogicManagerByName(_ARG_0_).LuaObject end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWidgetByLogicName"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetLogicManagerByName(_ARG_0_) then
        return nil
      end
      _ARG_1_ = _ARG_1_ or 0
      if GetLogicManagerByName(_ARG_0_).WidgetList:Num() >= _ARG_1_ + 1 then
        return GetLogicManagerByName(_ARG_0_).WidgetList:Get(_ARG_1_)
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWidgetByName"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetLogicManagerByName(_ARG_0_) then
        return nil
      end
      do return GetLogicManagerByName(_ARG_0_):GetWidgetByName(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLuaTableByName"] = function(_ARG_0_)
    do
      if globalLuaUaeWidgetTable[_ARG_0_] then
        return globalLuaUaeWidgetTable[_ARG_0_]
      else
        return nil
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitScrollBox"] = function(_ARG_0_)
    do
      do return ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule):InitWithoutParentComponent(ModuleManager.GetModule(ModuleManager.CommonModuleConfig.UIComponentModule).Config.loop_scroll_box, _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemTimeS"] = function(_ARG_0_, _ARG_1_)
    do
      do return GetGlobalUIFunctionLibrary().GetItemTimeS(_ARG_0_, _ARG_1_, GetGameInstance()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemTimeLimitText"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ENV(U1.bWriteLog and U2(U1.table.concat({
        U3(195, 133, 43, 5, 99, 69, 210, 18, 148, 63, 133, 104, 189, 238, 212, 125, 11, 153, 66, 40, 151, 112, 248, 49, 132, 35, 168, 44, 170, 192, 248, 107, 1, 185, 109, 52, 190, 96, 241, 16),
        U3(182, 246, 94, 84, 121, 5, 220, 39, 148, 56, 133, 120, 248, 185, 160, 49, 21, 208, 46, 53, 147, 116, 233, 54, 149, 41, 252, 54, 232, 182, 227)
      }), _ARG_0_, _ARG_1_, _ARG_2_))
      if _ARG_0_ then
        _ENV(U1.bWriteLog and U3(195, 133, 43, 5, 99, 69, 210, 18, 148, 63, 133, 104, 189, 238, 212, 125, 11, 153, 66, 40, 151, 112, 248, 49, 132, 35, 168, 44, 44, 46, 47, 227, 226, 68, 248, 205, 117, 224, 5, 229))
        return U4:GetDifferentCountryTimeFormatContent(_ARG_2_) or U3(), true
      elseif U6(_ARG_2_) == U3(248, 185, 19, 19, 111, 91) then
        return U5((U1.table.concat({
          U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 173, 238, 231, 58, 49, 157, 124, 37, 136, 118, 238, 0, 207, 47, 181, 124, 187, 189, 249, 112, 19, 129, 65, 37, 131, 121, 239, 42),
          U3(227, 184, 23, 29)
        }))):GetRemainTimeString(_ARG_2_), true
      elseif U5((U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 121, 32, 136, 125, 254, 10, 131, 62, 242, 123, 169, 225, 244, 118, 25, 142, 123, 14, 142, 104, 232, 20))):GetHallDepotItemDataByResIDAndTimeliness(_ARG_1_, true) and U4.GetIsShowOwnTextOrTimeRemaining(U5((U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 121, 32, 136, 125, 254, 10, 131, 62, 242, 123, 169, 225, 244, 118, 25, 142, 123, 14, 142, 104, 232, 20))):GetHallDepotItemDataByResIDAndTimeliness(_ARG_1_, true).itemType, U5((U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 121, 32, 136, 125, 254, 10, 131, 62, 242, 123, 169, 225, 244, 118, 25, 142, 123, 14, 142, 104, 232, 20))):GetHallDepotItemDataByResIDAndTimeliness(_ARG_1_, true).itemSubType) then
        return U5((U1.table.concat({
          U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 173, 238, 231, 58, 49, 157, 124, 37, 136, 118, 238, 0, 207, 47, 181, 124, 187, 189, 249, 112, 19, 129, 65, 37, 131, 121, 239, 42),
          U3(227, 184, 23, 29)
        }))):GetRemainTimeString(U5((U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 121, 32, 136, 125, 254, 10, 131, 62, 242, 123, 169, 225, 244, 118, 25, 142, 123, 14, 142, 104, 232, 20))):GetHallDepotItemDataByResIDAndTimeliness(_ARG_1_, true).expireTS)
      else
        return U4:GetDifferentCountryTimeFormatContent(_ARG_2_) or U3(), true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[129]
    end
  end,
  ["GetIsShowOwnTextOrTimeRemaining"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ and _ENV(_ARG_1_) and _ARG_2_ ~= 1 then
        return true
      end
      if _ARG_0_ and U1(_ARG_0_) and _ARG_2_ ~= 2 then
        return true
      end
      if _ARG_0_ and _ARG_1_ and U2(_ARG_0_, _ARG_1_) and _ARG_2_ ~= 3 then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDifferentCountryTimeFormatContent"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ ~= nil and _ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).FormatTime_YMDHM((_ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).TimeStringToUnixstamp(_ARG_1_))) ~= nil then
        if (U2.IsBlueholeOperationRegion() or U2.IsJapanOrKorea()) and _ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).TimeStringToUnixstamp(_ARG_1_) ~= 0 then
        else
        end
      end
      do return (U4(U3.LocalizeResFormat(4425, (_ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).FormatTime_YMDHM(_ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).TimeStringToUnixstamp(_ARG_1_), true))), U1(190, 233, 26, 90, 35, 4, 212, 112, 149, 96, 229, 49, 240, 166, 228, 63, 79, 220, 38, 100, 158, 50, 165, 95, 201, 126, 184, 39, 225, 169, 184, 33, 18, 199, 55), U5((_ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).FormatTime_YMDHM(_ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).TimeStringToUnixstamp(_ARG_1_), true))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLocalizationString"] = function(_ARG_0_)
    do
      do return _ENV((U1(223, 162, 10, 29, 66, 76, 144, 37, 148, 57))).GetLocalizationString(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLobbyCamera"] = function(_ARG_0_)
    do
      _ENV(U1.bWriteLog and U2(195, 133, 43, 5, 99, 69, 210, 6, 153, 36, 187, 80, 183, 225, 226, 109, 37, 157, 99, 36, 136, 120, 182) .. U3(_ARG_0_))
      if not U4.IsIn2DLobby() then
        _ENV(U1.bWriteLog and U2(195, 133, 43, 5, 99, 69, 210, 6, 153, 36, 187, 80, 183, 225, 226, 109, 37, 157, 99, 36, 136, 120, 172, 11, 142, 47, 252, 101, 166, 179, 252, 107, 20, 142, 103))
        return
      end
      if U1.UIManager.IsUIShow(U1.UIManager.UI_Config.level_sequence_player_system) then
        return
      end
      if U5((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 90, 57, 183, 112, 255, 22, 136, 52, 178, 34, 164, 252, 247, 109, 21, 179, 102, 60, 131, 122, 239, 28),
        U2(249, 162, 33, 28, 107, 64, 146)
      }))).IsInXMission() and U5((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 90, 57, 183, 112, 255, 22, 136, 52, 178, 34, 164, 252, 247, 109, 21, 179, 102, 60, 131, 122, 239, 28),
        U2(249, 162, 33, 28, 107, 64, 146)
      }))).IsLobby2D() then
        return
      end
      if _ARG_0_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetSize"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_.Slot then
        return
      end
      if _ARG_0_.Slot.SetSize then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLeftBarQualityPath"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ARG_0_ < 3 or 8 < _ARG_0_ then
        _ARG_0_ = 3
      end
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetQualityPath"] = function(_ARG_0_)
    do
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTQualityPath"] = function(_ARG_0_)
    do
      if _ARG_0_ == 10 then
        _ARG_0_ = 8
      end
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPHomeBgQualityPath"] = function(_ARG_0_)
    do
      if not tonumber(_ARG_0_) or tonumber(_ARG_0_) < 3 then
      elseif 3 > 8 then
      end
      do return U1[8] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBgQualityPath"] = function(_ARG_0_)
    do
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTBgQualityPath"] = function(_ARG_0_)
    do
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetXieQualityPath"] = function(_ARG_0_)
    do
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBottomQualityPath"] = function(_ARG_0_)
    do
      do return _ENV[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCombatReadinessQualityPath"] = function(_ARG_0_)
    do
      if _ARG_0_ < 4 or 8 < _ARG_0_ then
        return (_ENV())
      end
      do return U1[_ARG_0_ - 4] end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetQualityDropDesc"] = function(_ARG_0_)
    do
      if U1[_ARG_0_] then
      end
      do return (U2.GetLocalizeResStr(U1[_ARG_0_])) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIntimacyRelationName"] = function(_ARG_0_)
    do
      do return _ENV((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 104, 51, 147, 124, 226, 1, 207, 18, 178, 120, 161, 254, 241, 103, 15, 194, 87, 63, 158, 96, 241, 20),
        U2(245, 181, 43, 5, 99, 69, 143)
      }))).GetRelationText(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWidgetViewportPos"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not U2.isValid(_ARG_0_) then
        return U3(0, 0)
      end
      do return _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).LocalToViewport(_ARG_0_, _ARG_0_:GetCachedGeometry(), U3(_ARG_1_ or 0, _ARG_2_ or 0), U3(0, 0), U3(0, 0), U4.GetGameInstance()) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["LocalToContainerBoundingBox"] = function(_ARG_0_)
    do
      do return _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).LocalToViewport(_ARG_0_, _ARG_0_:GetCachedGeometry(), _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetLocalSize((_ARG_0_:GetCachedGeometry())) * U2(0, 0), U2(0, 0), U2(0, 0)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetWidgetViewportPosInNormalized"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).LocalToViewport(_ARG_0_, _ARG_0_:GetCachedGeometry(), _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetLocalSize((_ARG_0_:GetCachedGeometry())) * U2(_ARG_1_ or 0, _ARG_2_ or 0), U2(0, 0), U2(0, 0)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RayIntersectPlane"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if (DotProduct(_ARG_3_, _ARG_2_) - DotProduct(_ARG_3_, _ARG_0_)) / DotProduct(_ARG_3_, _ARG_1_) >= 0 then
        return true, _ARG_0_ + _ARG_1_ * ((DotProduct(_ARG_3_, _ARG_2_) - DotProduct(_ARG_3_, _ARG_0_)) / DotProduct(_ARG_3_, _ARG_1_))
      end
      do return false, nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetAdaptiveLayout"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if (_ARG_1_ or _ARG_2_) and _ARG_0_.Slot and _ARG_0_.Slot.SetAnchors then
        if not isValid((_ARG_0_:GetParent())) then
          return
        end
        if _ARG_1_ then
        end
        if _ARG_2_ then
        end
        return U1.GetWidgetViewportPosInNormalized(_ARG_0_:GetParent(), 0.5, 0.5).X < U1.GetViewportSize().X * 0.5, U1.GetWidgetViewportPosInNormalized(_ARG_0_:GetParent(), 0.5, 0.5).Y < U1.GetViewportSize().Y * 0.5
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetViewportScale"] = function()
    do return _ENV((U1(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).GetViewportScale(U2.GetGameInstance()) end
    return
  end,
  ["GetViewportSize"] = function()
    do return _ENV((U1(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).GetViewportSize(U2.GetGameInstance()) end
    return
  end,
  ["GetViewportSizebyScale"] = function()
    do return _ENV((U1(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).GetViewportSize(U2.GetGameInstance()) / _ENV((U1(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).GetViewportScale(U2.GetGameInstance()) end
    return
  end,
  ["GetLocalSize"] = function(_ARG_0_)
    do
      do return _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetLocalSize((_ARG_0_:GetCachedGeometry())) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ViewportPixelToWidgetLocal"] = function(_ARG_0_, _ARG_1_)
    do
      if not isValid(_ARG_1_) then
        return U1(0, 0)
      end
      if not U4.GetViewportScale() or U4.GetViewportScale() == 0 then
      end
      do return U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).AbsoluteToLocal(_ARG_1_:GetCachedGeometry(), (U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).LocalToAbsolute(U2((U3(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).GetViewportWidgetGeometry(U4.GetGameInstance()), (U1(_ARG_0_.X / 1, _ARG_0_.Y / 1))))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["AbsoluteToViewportPixel"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return _ENV(0, 0)
      end
      do return _ENV(_ARG_0_.X or 0, _ARG_0_.Y or 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAbsoluteSize"] = function(_ARG_0_)
    do
      do return _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_0_:GetCachedGeometry())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScreenPositionBy3DActor"] = function(_ARG_0_)
    do
      if _ARG_0_ ~= nil then
      else
      end
      do return (U5((U3(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).ProjectWorldLocationToWidgetPositionReturnValue(U2.slua_GameFrontendHUD:GetPlayerController(), (_ARG_0_:K2_GetActorLocation()))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScreenPositionBy3DActor2"] = function(_ARG_0_)
    do
      if _ARG_0_ ~= nil then
        U2._ = U2.slua_GameFrontendHUD:GetPlayerController():ProjectWorldLocationToScreen(_ARG_0_:K2_GetActorLocation(), _ENV(0, 0), false)
      else
      end
      do return U2.slua_GameFrontendHUD:GetPlayerController():ProjectWorldLocationToScreen(_ARG_0_:K2_GetActorLocation(), _ENV(0, 0), false) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScreenPositionBy3DLoc"] = function(_ARG_0_)
    do
      do return (U5((U3(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).ProjectWorldLocationToWidgetPositionReturnValue(U2.slua_GameFrontendHUD:GetPlayerController(), _ARG_0_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScreenPositionBy3DLoc2"] = function(_ARG_0_)
    do
      if _ARG_0_ ~= nil then
        U2._ = U2.slua_GameFrontendHUD:GetPlayerController():ProjectWorldLocationToScreen(_ARG_0_, _ENV(0, 0), false)
      else
      end
      do return U2.slua_GameFrontendHUD:GetPlayerController():ProjectWorldLocationToScreen(_ARG_0_, _ENV(0, 0), false) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMaskBoxItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_ == nil or _ARG_0_.MaskBox == nil then
        return
      end
      do return SetMaskBox(_ARG_0_.MaskBox, _ARG_1_, _ARG_2_, _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMaskBoxItemAlpha"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.Image_0:SetColorAndOpacity(FLinearColor(0, 0, 0, _ARG_1_))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMaskBoxTouchSpace"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_ == nil or _ARG_1_ == nil then
        return
      end
      _ARG_2_ = _ARG_2_ or 0
      _ARG_3_ = _ARG_3_ or 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetMaskBox"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_1_ or not isValid(_ARG_1_) then
        _ARG_0_:SetMaskTransformPivot(U1(-10000, -10000))
        _ARG_0_:SetMaskTransformScale(U1(0, 0))
        return U1(-10000, -10000), U1(0, 0)
      end
      if not U4.GetWidgetViewportPos(_ARG_1_, _ARG_2_ or 0, _ARG_3_ or 0) then
        return U1(-10000, -10000), U1(0, 0)
      end
      do return (U4.GetWidgetViewportPos(_ARG_1_, _ARG_2_ or 0, _ARG_3_ or 0) * U4.GetViewportScale() - U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())) * 0.5) / U4.GetViewportSize() / (U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())) / (U4.GetViewportSize() * 0.5)), U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())) / (U4.GetViewportSize() * 0.5) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLobbyUI"] = function(_ARG_0_)
    do
      if _ARG_0_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HideLobbyAndPersonSpaceUI"] = function()
    _ENV(U1.bWriteLog and U2(195, 133, 43, 5, 99, 69, 210, 29, 152, 47, 169, 80, 183, 225, 226, 109, 41, 142, 94, 36, 136, 106, 227, 11, 178, 43, 189, 111, 173, 198, 217))
    return
  end,
  ["GetProgress"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      goto lbl_8
      ::lbl_8::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_2_ <= _ARG_1_ then
      else
        _ARG_0_ = _ARG_0_
        if _ARG_1_ >= _ARG_0_[(nil).len].count then
        else
          goto lbl_42
        end
        _ARG_0_ = _ARG_0_
        ::lbl_42::
      end
      do return (0 + _ARG_0_[(nil).len].len + (_ARG_1_ - _ARG_0_[(nil).len - 1].count) / (_ARG_0_[(nil).len].count - _ARG_0_[(nil).len - 1].count) * _ARG_0_[(nil).len].len) / (0 + (nil).len) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPlatformlIcon"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return
      end
      if _ENV((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 104, 51, 147, 124, 226, 1, 207, 55, 179, 107, 161, 240, 207, 106, 19, 155, 65, 55, 152, 96, 249, 27),
        U2(242)
      }))).IsPlatFriend(_ARG_0_) then
        if U1.BP_Platform == U1.BP_ENUM_PLAYFORM_BGBG then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 186, 23, 174, 59, 162, 123, 246, 215, 223, 125, 5, 147, 96, 30, 188, 91, 211, 21, 143, 60)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_WX then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 178, 58, 130, 40, 164, 125, 172, 220, 240, 122, 1, 210, 90, 30, 147, 122, 227, 11, 190, 21, 179, 127, 171, 251, 241, 112, 41, 156, 112, 54)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_GAMECENTER then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 187, 52, 156, 46, 143, 121, 182, 247, 229, 102, 57, 140, 96, 38, 212, 77, 211, 12, 130, 52, 178, 83, 143, 242, 253, 97, 53, 137, 112, 37, 143, 123, 195, 5),
            U2(248, 171)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_TWITTER then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 168, 34, 152, 63, 184, 121, 170, 220, 240, 122, 1, 210, 90, 30, 147, 122, 227, 11, 190, 15, 171, 101, 188, 231, 245, 118, 41, 156, 112, 54)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_VK then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 170, 30, 174, 59, 162, 123, 246, 215, 223, 125, 5, 147, 96, 30, 172, 82, 211, 21, 143, 60)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_LINE then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 144, 60, 159, 46, 147, 108, 182, 228, 174, 64, 57, 149, 109, 46, 148, 70, 224, 12, 143, 62, 131, 124, 166, 244)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_GOOGLEPLAY then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 133, 29, 30, 100, 118, 187, 58, 158, 44, 160, 121, 136, 239, 225, 109, 57, 140, 96, 38, 212, 77, 211, 44, 130, 52, 178, 83, 143, 252, 255, 99, 26, 137, 78, 61, 139, 112, 195, 5),
            U2(248, 171)
          }))
        elseif U1.BP_Platform == U1.BP_ENUM_PLAYFORM_BGBGByiTOP then
          return (U1.table.concat({
            U2(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 198, 217, 43, 48, 158, 127, 60, 143, 122, 179, 33),
            U2(201, 165, 29, 30, 100, 118, 190, 18, 179, 12, 189, 117, 188, 236, 238, 115, 57, 140, 96, 38, 212, 77, 211, 12, 130, 52, 178, 83, 138, 212, 210, 67, 7, 133, 122, 62, 132, 110, 195, 5),
            U2(248, 171)
          }))
        end
      end
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProjectWorldLocationToWidgetPosition"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return (U1((U2(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).ProjectWorldLocationToWidgetPositionReturnValue(U3.slua_GameFrontendHUD:GetPlayerController(), (_ENV(_ARG_0_, _ARG_1_, _ARG_2_)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProjectWorldPosToScreenPos"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not U1.isValid(slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()) then
        return
      end
      if not (slua_GameFrontendHUD and slua_GameFrontendHUD:GetPlayerController()):ProjectWorldLocationToScreen(U4(_ARG_0_, _ARG_1_, _ARG_2_), U5(0, 0), true) then
        return U6.ProjectWorldLocationToWidgetPosition(_ARG_0_, _ARG_1_, _ARG_2_)
      end
      if U6.GetViewportScale() and 0 < U6.GetViewportScale() and U6.GetViewportScale() ~= 1 then
        return U5(U5(0, 0).X / U6.GetViewportScale(), U5(0, 0).Y / U6.GetViewportScale())
      end
      do return (U5(0, 0)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["WorldToUILocalPosition"] = function(_ARG_0_, _ARG_1_)
    do
      if not isValid(_ARG_1_) then
        return U1(0, 0)
      end
      if not U3((U4(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(U2.GetGameInstance(), 0) then
        return U1(0, 0)
      end
      U1(0, 0).X = U1(0, 0).X / U2.GetViewportSize().X * U3((U4(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetLocalSize((_ARG_1_:GetCachedGeometry())).X
      U1(0, 0).Y = U1(0, 0).Y / U2.GetViewportSize().Y * U3((U4(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetLocalSize((_ARG_1_:GetCachedGeometry())).Y
      do return (U1(0, 0)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConvertLocalPositionBetweenWidgets"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not isValid(_ARG_0_) or not isValid(_ARG_2_) then
        return U1(0, 0)
      end
      do return (U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).AbsoluteToLocal(_ARG_2_:GetCachedGeometry(), (U2((U3(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).LocalToAbsolute(_ARG_0_:GetCachedGeometry(), _ARG_1_)))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpToByPattern"] = function(_ARG_0_)
    do
      if (function(_ARG_0_)
        do
          goto lbl_45
          if 48 == 1 then
            if U3._G[6] then
            end
          else
          end
          ::lbl_45::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          do return U3._G[6], (U1(241, 173, 19, 20, 48, 6, 211, 106, 156, 36, 168, 105, 180, 230, 189) .. U3._G[6]) .. U1(176) .. 6 end
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)(_ARG_0_) ~= nil then
        if (function(_ARG_0_)
          do
            goto lbl_45
            if 48 == 1 then
              if U3._G[6] then
              end
            else
            end
            ::lbl_45::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            do return U3._G[6], (U1(241, 173, 19, 20, 48, 6, 211, 106, 156, 36, 168, 105, 180, 230, 189) .. U3._G[6]) .. U1(176) .. 6 end
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)(_ARG_0_) ~= U3.BP_ENUM_MODULE_SHARE then
        end
        if (function(_ARG_0_)
          do
            goto lbl_45
            if 48 == 1 then
              if U3._G[6] then
              end
            else
            end
            ::lbl_45::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            do return U3._G[6], (U1(241, 173, 19, 20, 48, 6, 211, 106, 156, 36, 168, 105, 180, 230, 189) .. U3._G[6]) .. U1(176) .. 6 end
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)(_ARG_0_) == U3.BP_ENUM_MODULE_FRIEND or (function(_ARG_0_)
          do
            goto lbl_45
            if 48 == 1 then
              if U3._G[6] then
              end
            else
            end
            ::lbl_45::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            do return U3._G[6], (U1(241, 173, 19, 20, 48, 6, 211, 106, 156, 36, 168, 105, 180, 230, 189) .. U3._G[6]) .. U1(176) .. 6 end
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)(_ARG_0_) == U3.BP_ENUM_MODULE_INVITE_FRIEND then
        end
        if (function(_ARG_0_)
          do
            goto lbl_45
            if 48 == 1 then
              if U3._G[6] then
              end
            else
            end
            ::lbl_45::
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
            do return U3._G[6], (U1(241, 173, 19, 20, 48, 6, 211, 106, 156, 36, 168, 105, 180, 230, 189) .. U3._G[6]) .. U1(176) .. 6 end
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end)(_ARG_0_) == U3.BP_ENUM_MODULE_SHOP then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetGradeImage"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ == _ENV() and _ENV(212) or _ARG_0_
      do return U1[_ARG_0_] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemCfg"] = function(_ARG_0_)
    do
      do return GetTableData(U1(223, 184, 27, 28), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ItemTypeCheck"] = function(_ARG_0_, _ARG_1_)
    do
      if GetTableData(U1(223, 184, 27, 28), _ARG_0_) and GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemType and GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemType == _ARG_1_ then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPreview"] = function(_ARG_0_, _ARG_1_)
    do
      if nil == GetItemCfg(_ARG_0_) then
        return GetDefaultIcon(_ARG_0_), false, true
      end
      if GetItemCfg(_ARG_0_).Preview and GetItemCfg(_ARG_0_).Preview ~= U3() then
        if U5((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).Preview) then
          return GetItemCfg(_ARG_0_).Preview, false, false
        elseif U6.IsFITVersion() and not IsIconNeedAutoDownload() then
          return GetItemCfg(_ARG_0_).Preview, false, false
        end
      end
      do return GetItemBigIcon(_ARG_0_, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemBigIconNotPakCheck"] = function(_ARG_0_)
    do
      _ENV(U1.bWriteLog and U1.table.concat({
        U2(195, 133, 43, 5, 99, 69, 210, 18, 148, 63, 133, 104, 189, 238, 194, 125, 1, 181, 109, 46, 148, 87, 227, 17, 177, 58, 183, 79, 160, 246, 243, 111, 86, 133, 106, 52, 135, 64, 248, 79),
        U2(182)
      }) .. _ARG_0_)
      if nil == U3.GetItemCfg(_ARG_0_) then
        return U3.GetDefaultIcon(_ARG_0_)
      end
      if U1._G.IsEditor then
        return U3.GetItemCfg(_ARG_0_).ItemBigIcon
      end
      if U6.Split(U3.GetItemCfg(_ARG_0_).ItemBigIcon, (U2(184)))[1] and U6.Split(U3.GetItemCfg(_ARG_0_).ItemBigIcon, (U2(184)))[1] ~= U2() then
        if U3.IsFileExistsWithOutPakCheck(U6.Split(U3.GetItemCfg(_ARG_0_).ItemBigIcon, (U2(184)))[1]) then
          return U3.GetItemCfg(_ARG_0_).ItemBigIcon
        end
      end
      if U6.Split(U3.GetItemCfg(_ARG_0_).ItemSmallIcon, (U2(184)))[1] and U6.Split(U3.GetItemCfg(_ARG_0_).ItemSmallIcon, (U2(184)))[1] ~= U2() then
        if U3.IsFileExistsWithOutPakCheck(U6.Split(U3.GetItemCfg(_ARG_0_).ItemSmallIcon, (U2(184)))[1]) then
          return U3.GetItemCfg(_ARG_0_).ItemSmallIcon
        end
      end
      do return U3.GetDefaultIcon(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsIconNeedAutoDownload"] = function()
    if U2.IsFITVersion() then
      if _ENV((U1(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 109, 38, 131, 125, 255, 29))).GetIsDisableFitIconAutoDownload() then
        return false
      end
      if _ENV((U1(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 109, 38, 131, 125, 255, 29))).GetFitAutoDownloadIconIsMax() then
        return false
      end
      return _ENV((U1(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 109, 38, 131, 125, 255, 29))).AutoDownloadCfg.AutoDownloadIconSwitch == true
    end
    if _ENV((U1(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 109, 38, 131, 125, 255, 29))).GetDownloadShowIconCheckBox() then
      return _ENV((U1(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 109, 38, 131, 125, 255, 29))).AutoDownloadCfg.AutoDownloadIconSwitch == true
    end
    do return true end
    return
  end,
  ["AddKnownMissingPackageByIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if U3.isValid(_ARG_1_) then
        if U2.IsIconNeedAutoDownload() or _ARG_2_ then
        end
      elseif U2.IsIconNeedAutoDownload() then
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsFileExistsWithOutPakCheck"] = function(_ARG_0_)
    do
      if _ENV((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
        U2(201, 161, 31, 31, 107, 78, 153, 39)
      }))).GetPakName(_ARG_0_) == U2() or U5.IsFileExistsWithOutPakCheck(U5.ProjectSavedDir() .. U1.PufferDownloader.DOWNLOAD_DIR_RELATIVE .. _ENV((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
        U2(201, 161, 31, 31, 107, 78, 153, 39)
      }))).GetPakName(_ARG_0_)) then
        return true
      end
      if U6.IsBlueholeOperationRegion() then
        if _ENV((U1.table.concat({
          U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
          U2(201, 161, 31, 31, 107, 78, 153, 39)
        }))).GetPakName((U7(_ARG_0_, U2(185, 139, 31, 28, 111, 6), (U2(185, 139, 31, 28, 111, 6, 177, 32, 157, 63, 165, 78, 189, 228, 233, 123, 8, 211, 77, 46, 148, 109, 233, 11, 149, 116, 149, 66, 231))))) == U2() or U5.IsFileExistsWithOutPakCheck(U5.ProjectSavedDir() .. U1.PufferDownloader.DOWNLOAD_DIR_RELATIVE .. _ENV((U1.table.concat({
          U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
          U2(201, 161, 31, 31, 107, 78, 153, 39)
        }))).GetPakName((U7(_ARG_0_, U2(185, 139, 31, 28, 111, 6), (U2(185, 139, 31, 28, 111, 6, 177, 32, 157, 63, 165, 78, 189, 228, 233, 123, 8, 211, 77, 46, 148, 109, 233, 11, 149, 116, 149, 66, 231)))))) then
          return true
        end
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemBigIconPakName"] = function(_ARG_0_)
    do
      if nil == U1.GetItemCfg(_ARG_0_) then
        return (_ENV())
      end
      if U1.GetItemCfg(_ARG_0_).ItemBigIcon ~= _ENV() then
      end
      do return (U2((U3.table.concat({
        _ENV(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
        _ENV(201, 161, 31, 31, 107, 78, 153, 39)
      }))).GetPakName(U1.GetItemCfg(_ARG_0_).ItemBigIcon)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasIconDownloaded"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        return false
      end
      if U1((_ENV(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(_ARG_0_) then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetItemIconQuality"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not GetItemCfg(_ARG_0_) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetQuality"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBgQuality"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemBigIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if nil == GetItemCfg(_ARG_0_) then
        return GetDefaultIcon(_ARG_0_), false, true
      end
      if GetItemCfg(_ARG_0_).ItemBigIcon and GetItemCfg(_ARG_0_).ItemBigIcon ~= U3() then
        if U5((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).ItemBigIcon) then
          return GetItemCfg(_ARG_0_).ItemBigIcon, false, false
        elseif U6.IsFITVersion() and not IsIconNeedAutoDownload() and not _ARG_3_ then
          return GetItemCfg(_ARG_0_).ItemBigIcon, false, false
        end
        if not _ARG_3_ then
        end
        if _ARG_2_ then
          return GetItemCfg(_ARG_0_).ItemBigIcon, AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).ItemBigIcon, _ARG_1_), false
        end
      end
      if _ARG_2_ then
        return GetItemSmallIcon2(_ARG_0_, _ARG_1_)
      end
      do return GetItemSmallIcon(_ARG_0_, _ARG_1_, AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).ItemBigIcon, _ARG_1_), _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemIconForSmallPackage"] = function(_ARG_0_, _ARG_1_)
    do
      if GetItemCfg(_ARG_0_) and U1.IsFITVersion() and GetItemCfg(_ARG_0_).ItemBigIcon and GetItemCfg(_ARG_0_).ItemBigIcon ~= U3() and not U2((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).ItemBigIcon) then
        return GetItemSmallIcon(_ARG_0_, _ARG_1_)
      end
      do return GetItemBigIcon(_ARG_0_, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemBigIcon2"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if nil == GetItemCfg(_ARG_0_) then
        return GetDefaultIcon(_ARG_0_), false, true
      end
      if GetItemCfg(_ARG_0_).ItemBigIcon2 and GetItemCfg(_ARG_0_).ItemBigIcon2 ~= U3() then
        if U5((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).ItemBigIcon2) then
          return GetItemCfg(_ARG_0_).ItemBigIcon2, false, false
        elseif U6.IsFITVersion() and not IsIconNeedAutoDownload() and not _ARG_3_ then
          return GetItemCfg(_ARG_0_).ItemBigIcon2, false, false
        end
        if not _ARG_3_ then
        end
        if _ARG_2_ then
          return GetItemCfg(_ARG_0_).ItemBigIcon2, AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).ItemBigIcon2, _ARG_1_), false
        end
      end
      do return GetItemBigIcon(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemBigIconWithCallBack"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if nil == GetTableData(U1(223, 184, 27, 28), _ARG_0_) then
        return U5.GetDefaultIcon(_ARG_0_)
      end
      if GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemBigIcon and GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemBigIcon ~= U1() then
        if U6((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemBigIcon) then
          return GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemBigIcon, false
        end
      end
      do return U5.GetItemSmallIcon(_ARG_0_, _ARG_1_, (U5.AddKnownMissingPackageByIcon(GetTableData(U1(223, 184, 27, 28), _ARG_0_).ItemBigIcon, _ARG_1_))) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemBigIcon2WithCallBack"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if nil == GetItemCfg(_ARG_0_) then
        return GetDefaultIcon(_ARG_0_)
      end
      if GetItemCfg(_ARG_0_).ItemBigIcon2 and GetItemCfg(_ARG_0_).ItemBigIcon2 ~= U3() then
        if U5((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).ItemBigIcon2) then
          return GetItemCfg(_ARG_0_).ItemBigIcon2, false
        end
        if _ARG_2_ then
          return GetItemCfg(_ARG_0_).ItemBigIcon2, (AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).ItemBigIcon2, _ARG_1_))
        end
      end
      do return GetItemBigIcon(_ARG_0_, _ARG_1_, _ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckSmallIconMissing"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ and _ARG_0_ ~= _ENV() then
        if U1((_ENV(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(_ARG_0_) then
          return false
        end
      end
      do return (U2.AddKnownMissingPackageByIcon(_ARG_0_, _ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetFPSMax"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsSmallIconStreamingDownloadDisabled"] = function(_ARG_0_)
    do
      if _ENV(_ARG_0_) == U1(226, 173, 28, 29, 111) and _ARG_0_.bDisableStreamingDownload ~= nil then
        return _ARG_0_.bDisableStreamingDownload == true
      end
      do return U2.IsFITVersion() == true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemSmallIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not GetItemCfg(_ARG_0_) then
        return GetDefaultIcon(_ARG_0_), false, true, false
      end
      if U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.music_manager):GetIsBlackRegion() and U5.GetTableData(U3(220, 188, 54, 24, 110, 76, 175, 58, 132, 37, 168, 85, 187, 236, 238, 87, 0, 155), _ARG_0_) then
        return U5.GetTableData(U3(220, 188, 54, 24, 110, 76, 175, 58, 132, 37, 168, 85, 187, 236, 238, 87, 0, 155), _ARG_0_).Path128, _ARG_2_ or false, false, false
      end
      if GetItemCfg(_ARG_0_).ItemSmallIcon and GetItemCfg(_ARG_0_).ItemSmallIcon ~= U3() then
        if U6((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).ItemSmallIcon) then
          return GetItemCfg(_ARG_0_).ItemSmallIcon, _ARG_2_ or false, false, false
        elseif U7.IsFITVersion() and not IsIconNeedAutoDownload() and not _ARG_4_ then
          return GetItemCfg(_ARG_0_).ItemSmallIcon, _ARG_2_ or false, false, true
        end
        if not _ARG_4_ then
        end
      end
      do return GetDefaultIcon(_ARG_0_), AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).ItemSmallIcon, _ARG_1_, not IsSmallIconStreamingDownloadDisabled(_ARG_3_)), true, false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemSmallIcon2"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if nil == GetItemCfg(_ARG_0_) then
        return GetDefaultIcon(_ARG_0_), false, true
      end
      if U2.ModuleManager.GetModule(U2.ModuleManager.LobbyModuleConfig.music_manager):GetIsBlackRegion() and U5.GetTableData(U3(220, 188, 54, 24, 110, 76, 175, 58, 132, 37, 168, 85, 187, 236, 238, 87, 0, 155), _ARG_0_) then
        return U5.GetTableData(U3(220, 188, 54, 24, 110, 76, 175, 58, 132, 37, 168, 85, 187, 236, 238, 87, 0, 155), _ARG_0_).Path256, false, false
      end
      if GetItemCfg(_ARG_0_).ItemSmallIcon2 and GetItemCfg(_ARG_0_).ItemSmallIcon2 ~= U3() then
        if U6((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).ItemSmallIcon2) then
          return GetItemCfg(_ARG_0_).ItemSmallIcon2, false, false
        elseif U7.IsFITVersion() and not IsIconNeedAutoDownload() and not _ARG_3_ then
          return GetItemCfg(_ARG_0_).ItemSmallIcon2, false, false
        end
        if not _ARG_3_ then
        end
      end
      do return GetItemSmallIcon(_ARG_0_, _ARG_1_, AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).ItemSmallIcon2, _ARG_1_, not IsSmallIconStreamingDownloadDisabled(_ARG_2_)), _ARG_2_, _ARG_3_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemSpecialIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not GetItemCfg(_ARG_0_) then
        return (U3())
      end
      if GetItemCfg(_ARG_0_).SpecialIcon and GetItemCfg(_ARG_0_).SpecialIcon ~= U3() then
        if U5((U3(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(GetItemCfg(_ARG_0_).SpecialIcon) then
          return GetItemCfg(_ARG_0_).SpecialIcon, false
        end
        if not _ARG_2_ then
        end
      end
      do return U3(), (AddKnownMissingPackageByIcon(GetItemCfg(_ARG_0_).SpecialIcon, _ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSignatureIcon"] = function(_ARG_0_, _ARG_1_)
    do
      if not GetTableData(U1(197, 165, 25, 31, 79, 79, 154, 48, 146, 63, 143, 122, 191), _ARG_0_) then
        return
      end
      do return U2._CheckCommonIcon(GetTableData(U1(197, 165, 25, 31, 79, 79, 154, 48, 146, 63, 143, 122, 191), _ARG_0_).Icon, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialQualityBottomBg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        return
      end
      if not GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_) then
        return
      end
      do return U2._CheckCommonIcon(GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_).StoreButtomBg, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialQualityTurnTableBg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        return
      end
      if not GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_) then
        return
      end
      do return U2._CheckCommonIcon(GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_).TurntableBg, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialQualityBg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        return
      end
      if not GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_) then
        return
      end
      do return U2._CheckCommonIcon(GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_).BG, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialQuality"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return 0
      end
      if not GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_) then
        return 0
      end
      do return GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_).SpecialQuality_f end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSpecialQualityShareNameBg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ then
        return
      end
      if not GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_) then
        return
      end
      do return U2._CheckCommonIcon(GetTableData(U1(223, 184, 27, 28, 89, 89, 153, 54, 152, 42, 160, 77, 173, 226, 236, 125, 18, 133, 77, 39, 157), _ARG_0_).ShareNameBg, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["_CheckCommonIcon"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ and _ARG_0_ ~= _ENV() then
        if U1((_ENV(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(_ARG_0_) then
          return _ARG_0_, false
        end
      end
      do return _ENV(), (U2.AddKnownMissingPackageByIcon(_ARG_0_, _ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDefaultIcon"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return DefaultCommonIcon
      end
      _ARG_0_ = U1.tonumber(_ARG_0_)
      if not GetItemCfg(_ARG_0_) then
        return DefaultCommonIcon
      end
      if U2.IsFITVersion() and U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.item_display_fallback_logic):GetSmallPackageIcon(_ARG_0_, GetItemCfg(_ARG_0_).ItemSubType, GetItemCfg(_ARG_0_).ItemType) then
        return (U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.item_display_fallback_logic):GetSmallPackageIcon(_ARG_0_, GetItemCfg(_ARG_0_).ItemSubType, GetItemCfg(_ARG_0_).ItemType))
      end
      if U3((U1.table.concat({
        U4(245, 160, 23, 20, 100, 93, 210, 57, 158, 44, 165, 127, 246, 226, 246, 117, 18, 157, 124, 111, 183, 118, 232, 0, 141, 31, 181, 127, 184, 255, 241, 125, 34, 149, 110, 52, 162, 108, 240, 5),
        U4(243, 190)
      }))).IsWeapon(GetItemCfg(_ARG_0_).ItemType) and U5.GetTableData(U4(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_) and GetItemCfg(_ARG_0_).ItemSubType == 103 and U5.GetTableData(U4(215, 190, 19, 30, 120, 80, 191, 58, 159, 45, 165, 123), U5.GetTableData(U4(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_).WeaponID) then
        if U5.GetTableData(U4(215, 190, 19, 30, 120, 80, 191, 58, 159, 45, 165, 123), U5.GetTableData(U4(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_).WeaponID).WeaponType == 2 then
          return DefaultSingleSniperIcon
        end
        if U5.GetTableData(U4(215, 190, 19, 30, 120, 80, 191, 58, 159, 45, 165, 123), U5.GetTableData(U4(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_).WeaponID).WeaponType == 3 then
          return DefaultBurstSniperIcon
        end
      end
      if GetItemCfg(_ARG_0_).ItemType == U1.ENUM_ITEM_TYPE.Extra and GetItemCfg(_ARG_0_).ItemSubType == 403 and GetItemCfg(_ARG_0_).WardrobeTab == U3((U4(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 173, 238, 231, 58, 49, 157, 124, 37, 136, 118, 238, 0, 207, 44, 189, 126, 172, 225, 255, 102, 19, 179, 115, 48, 137, 123, 243))).ENUM_WardrobeSubTabString.ENUM_WardrobeSubTabString_suit then
        return DefaultWardrobeSuitIcon
      end
      if U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_xmission_souvenirs):IsSouvenirsItem(_ARG_0_) then
        return U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.logic_xmission_souvenirs):GetSouvenirsDefaultIcon(_ARG_0_)
      end
      if GetItemCfg(_ARG_0_).ItemSubType > 10000 then
      else
      end
      if U5.GetTableData(U4(210, 169, 24, 16, 127, 69, 136, 28, 146, 36, 162, 95, 190, 228), GetItemCfg(_ARG_0_).ItemType * 10000 + GetItemCfg(_ARG_0_).ItemSubType) then
        return U5.GetTableData(U4(210, 169, 24, 16, 127, 69, 136, 28, 146, 36, 162, 95, 190, 228), GetItemCfg(_ARG_0_).ItemType * 10000 + GetItemCfg(_ARG_0_).ItemSubType).IconPath
      end
      do return DefaultCommonIcon end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIconCheckDownloaded"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_ or _ENV()
      if not U1.HasIconDownloaded(_ARG_0_) then
        _ARG_0_ = U1.GetDefaultIcon()
      end
      do return _ARG_0_ end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckAndUpdateIconScale"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_ or not _ARG_2_ then
        return false
      end
      _ENV(U1.bWriteLog and U2(195, 133, 43, 5, 99, 69, 210, 22, 153, 46, 175, 119, 153, 237, 228, 65, 22, 152, 111, 53, 159, 80, 239, 10, 143, 8, 191, 109, 164, 246, 176, 109, 2, 137, 115, 24, 174, 51, 188) .. _ARG_0_)
      if not U3.GetTableData(U2(223, 184, 27, 28), _ARG_0_) then
        return false
      end
      if _ARG_3_ == 1 then
      end
      if _ARG_1_ ~= U3.GetTableData(U2(223, 184, 27, 28), _ARG_0_).ItemSmallIcon and _ARG_1_ ~= U3.GetTableData(U2(223, 184, 27, 28), _ARG_0_).ItemSmallIcon2 or _ARG_1_ == U3.GetTableData(U2(223, 184, 27, 28), _ARG_0_).ItemBigIcon then
        return false
      end
      if U3.GetTableData(U2(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_) and U3.GetTableData(U2(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_).WeaponID and U3.GetTableData(U2(193, 169, 31, 1, 101, 71, 175, 62, 152, 37, 129, 125, 168, 243, 233, 122, 1), _ARG_0_).WeaponID ~= 0 then
      elseif U3.GetTableData(U2(215, 190, 19, 30, 120, 80, 191, 58, 159, 45, 165, 123), _ARG_0_) then
      end
      if _ARG_0_ then
        if U3.GetTableData(U2(193, 169, 31, 1, 101, 71, 175, 54, 144, 39, 169, 72, 185, 225, 236, 113), _ARG_0_) and _ARG_3_ == 1 then
        end
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEmptyDefaultAssociationTexture"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_ == nil then
        return (_ENV())
      end
      if _ARG_0_ <= #U1 then
        return U1[_ARG_0_]
      elseif _ARG_1_ and U2.GetTableData(_ENV(194, 180, 51, 24, 121, 90, 149, 58, 159, 2, 184, 121, 181), _ARG_1_) and U2.GetTableData(_ENV(194, 180, 51, 24, 121, 90, 149, 58, 159, 2, 184, 121, 181), _ARG_1_).TacticalAccessoryIcon then
        return U2.GetTableData(_ENV(194, 180, 51, 24, 121, 90, 149, 58, 159, 2, 184, 121, 181), _ARG_1_).TacticalAccessoryIcon
      end
      do return (_ENV()) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPartSlotName"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil then
        return (_ENV())
      end
      if _ARG_0_ <= #U1 then
        return U1[_ARG_0_]
      else
        return (_ENV())
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItemShowDetail"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if GM_ShowDetailItem then
        _ARG_1_ = GM_ShowDetailItem
      end
      if U1((U2.table.concat({
        U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 103, 53, 159, 116, 211, 21, 147, 62, 170, 101, 173, 228, 190, 104, 25, 139, 119, 50, 181, 96, 232, 16),
        U3(251, 156, 12, 20, 124, 64, 153, 34)
      }))).IsNeedShow(_ARG_1_) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnClickItemShowDetailActivity"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if GM_ShowDetailItem then
        _ARG_1_ = GM_ShowDetailItem
      end
      if U1((U2.table.concat({
        U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 103, 53, 159, 116, 211, 21, 147, 62, 170, 101, 173, 228, 190, 104, 25, 139, 119, 50, 181, 96, 232, 16),
        U3(251, 156, 12, 20, 124, 64, 153, 34)
      }))).IsNeedShow(_ARG_1_, _ARG_5_) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckHasIsLand"] = function()
    do return _ENV((U1(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 99, 32, 142, 122, 228, 75, 141, 52, 187, 101, 171, 204, 253, 107, 18, 137, 65, 60, 141, 123))).IsSocialIslandMode(true) end
    return
  end,
  ["CheckShow18Logo"] = function()
    if not GlobalData.IsIOSCheck() and U1.GetOperationRegion() == U1.OperationRegion.VNG then
    end
    do return (LobbySystem.CheckOpen(BP_ENUM_VNG_OPENMARK_Lobby)) end
    return
  end,
  ["InitChildWindow18Logo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not (_ARG_0_ and _ARG_0_.UIRoot) or not _ARG_0_.UIRoot[_ARG_1_] then
        return
      end
      if not CheckShow18Logo() then
        return
      end
      if not _ARG_0_:CreateChildWindow(_ARG_0_.UIRoot[_ARG_1_], U1.UIManager.UI_Config.VNG_18Add_Item, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_) then
        return
      end
      if _ARG_6_ ~= nil then
      end
      do return (_ARG_0_:CreateChildWindow(_ARG_0_.UIRoot[_ARG_1_], U1.UIManager.UI_Config.VNG_18Add_Item, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShow18LogoBattle"] = function()
    if not GlobalData.IsIOSCheck() and U1.GetOperationRegion() == U1.OperationRegion.VNG then
    end
    do return (LobbySystem.CheckOpen(BP_ENUM_VNG_OPENMARK)) end
    return
  end,
  ["ltrim"] = function(_ARG_0_)
    do
      do return _ENV(_ARG_0_, U1(200, 151, 94, 120, 0, 36, 161, 126), (U1())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["rtrim"] = function(_ARG_0_)
    do
      do return _ENV(_ARG_0_, U1(205, 236, 119, 123, 7, 116, 215, 113), (U1())) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsValid"] = function(_ARG_0_)
    do
      do return _ENV(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ProjectWorldToScreen"] = function(_ARG_0_)
    do
      if not U3.isValid((U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0))) then
        return U5(0, 0)
      end
      if U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).ProjectWorldToScreen(U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0), _ARG_0_, U5(0, 0), false) then
        return U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).ProjectWorldToScreen(U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0), _ARG_0_, U5(0, 0), false)
      end
      do return U5(0, 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeprojectScreenToWorld"] = function(_ARG_0_)
    do
      if not U3.isValid((U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0))) then
        return false
      end
      if U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).DeprojectScreenToWorld(U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0), _ARG_0_, U5(0, 0, 0), (U5(0, 0, 0))) then
        return U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).DeprojectScreenToWorld(U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0), _ARG_0_, U5(0, 0, 0), (U5(0, 0, 0)))
      end
      do return U5(0, 0, 0), (U5(0, 0, 0)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["DeprojectScreenToWorldFast"] = function(_ARG_0_)
    do
      if not U3.isValid((U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0))) then
        return false
      end
      if U1((U2(218, 163, 28, 19, 115, 100, 147, 49, 148, 39, 153, 104, 177, 239, 243))).DeprojectScreenToWorldFast(U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0), _ARG_0_, U5(0, 0, 0), (U5(0, 0, 0))) then
        return U1((U2(218, 163, 28, 19, 115, 100, 147, 49, 148, 39, 153, 104, 177, 239, 243))).DeprojectScreenToWorldFast(U1((U2(209, 173, 19, 20, 122, 69, 157, 44, 162, 63, 173, 104, 177, 224, 243))).GetPlayerController(GetGameInstance(), 0), _ARG_0_, U5(0, 0, 0), (U5(0, 0, 0)))
      end
      do return U5(0, 0, 0), (U5(0, 0, 0)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMousePositionOnViewport"] = function()
    do return slua_GameFrontendHUD:GetPlayerController():GetInputTouchState(0, nil, nil, nil) end
    return
  end,
  ["IsTargetValid"] = function(_ARG_0_)
    do
      if _ARG_0_ == nil or not isValid(_ARG_0_) then
        return
      end
      do return not (U3.GetWidgetViewportPos(_ARG_0_, 0, 0).X < 1.0E-5 and U3.GetWidgetViewportPos(_ARG_0_, 0, 0).Y < 1.0E-5 and U1((U2(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_0_:GetCachedGeometry())).X < 1.0E-5 and U1((U2(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_0_:GetCachedGeometry())).Y < 1.0E-5) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetGuideByWidget"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_2_ = _ARG_2_ or U5(0, 0)
      if _ARG_3_ then
        U2.GetWidgetViewportPos(_ARG_1_, 0, 0).X = U2.GetWidgetViewportPos(_ARG_1_, 0, 0).X + _ARG_3_.X
        U2.GetWidgetViewportPos(_ARG_1_, 0, 0).Y = U2.GetWidgetViewportPos(_ARG_1_, 0, 0).Y + _ARG_3_.Y
      end
      if _ENV((U1(193, 165, 26, 22, 111, 93, 176, 52, 136, 36, 185, 104, 148, 234, 226, 102, 7, 142, 119))).SlotAsCanvasSlot(_ARG_0_) then
      end
      do return not (U2.GetWidgetViewportPos(_ARG_1_, 0, 0).X < 1.0E-5 and U2.GetWidgetViewportPos(_ARG_1_, 0, 0).Y < 1.0E-5 and _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X < 1.0E-5 and _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y < 1.0E-5), U2.GetWidgetViewportPos(_ARG_1_, 0, 0).X + 0, U2.GetWidgetViewportPos(_ARG_1_, 0, 0).Y + 0, (U2.GetViewportSize().X - U2.GetWidgetViewportPos(_ARG_1_, 0, 0).X * U2.GetViewportScale() - _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X) / U2.GetViewportScale() + 0 - _ARG_2_.X, (U2.GetViewportSize().Y - U2.GetWidgetViewportPos(_ARG_1_, 0, 0).Y * U2.GetViewportScale() - _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y) / U2.GetViewportScale() + 0 - _ARG_2_.Y, _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).X / U2.GetViewportScale(), _ENV((U1(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).GetAbsoluteSize((_ARG_1_:GetCachedGeometry())).Y / U2.GetViewportScale() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetNationFlag"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
      elseif _ARG_1_ then
        if U3.IsBlueholeOperationRegion() and _ARG_1_ == U1(223, 130) then
        else
          U4.UpdateNationImage(_ARG_0_, _ARG_1_)
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTitleItem"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_ or not _ARG_1_ then
        return
      end
      if _ARG_1_.rank_id and _ARG_1_.rank_id > 0 then
        if _ARG_1_.rank_id and _ARG_1_.rank_id == 100001 then
        else
        end
      elseif _ARG_1_.aliasNation and _ARG_1_.aliasNation ~= U1() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetItemCoBrandedVisibility"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_1_ and _ARG_1_.Switcher_Joint and _ARG_1_.Switcher_Joint.SetWidgetVisibility then
        _ARG_1_.Switcher_Joint:SetWidgetVisibility(ESlateVisibility.Collapsed)
      end
      if _ARG_0_ == nil then
        return
      end
      if U1.GetTableData(U2(223, 184, 27, 28, 73, 70, 190, 39, 144, 37, 168, 121, 188, 192, 239, 122, 0, 149, 105), _ARG_0_) == nil then
        return
      end
      if _ARG_1_ and _ARG_1_.Switcher_Joint then
      end
      if _ARG_1_.Switcher_Joint then
        if _ARG_1_.Switcher_Joint.SetActiveWidgetIndex and U1.GetTableData(U2(223, 184, 27, 28, 73, 70, 190, 39, 144, 37, 168, 121, 188, 192, 239, 122, 0, 149, 105), _ARG_0_).coType then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocalpositionInBorder"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV(_ARG_1_) then
        return false
      end
      do return U1((U2(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).IsUnderLocation(_ARG_1_:GetCachedGeometry(), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConvertToAnimationNameWithLOD"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV(_ARG_1_ ~= nil and _ARG_1_ ~= U1(), (U2.table.concat({
        U1(213, 163, 16, 7, 111, 91, 136, 1, 158, 10, 162, 117, 181, 226, 244, 125, 9, 146, 64, 32, 151, 124, 219, 12, 149, 51, 144, 67, 140, 179, 249, 106, 55, 130, 119, 60, 139, 125, 245, 26),
        U1(248, 130, 31, 28, 111, 9, 130, 104, 209, 37, 165, 112, 248, 226, 238, 112, 70, 149, 96, 0, 148, 112, 225, 4, 149, 50, 179, 98, 134, 242, 253, 97, 86, 146, 35, 113)
      })))
      if not U3(_ARG_0_) or not _ARG_1_ then
        U4(U2.bWriteLog and U2.table.concat({
          U1(195, 133, 43, 5, 99, 69, 210, 22, 158, 37, 186, 121, 170, 247, 212, 123, 39, 146, 103, 44, 155, 109, 229, 10, 143, 21, 189, 97, 173, 196, 249, 112, 30, 160, 81, 21, 202, 41, 245, 6),
          U1(182, 162, 17, 5, 42, 95, 157, 57, 152, 47)
        }))
        return (U1())
      end
      if U2.FuncUtil.Clamp(U5.GetGameInstance():GetDeviceLevel(), 0, 2) == 1 then
        if _ARG_0_[_ARG_1_ .. U1(201, 128, 49, 53, 59)] then
          return _ARG_1_ .. U1(201, 128, 49, 53, 59), 1
        end
      elseif U2.FuncUtil.Clamp(U5.GetGameInstance():GetDeviceLevel(), 0, 2) == 0 then
        if _ARG_0_[_ARG_1_ .. U1(201, 128, 49, 53, 56)] then
          return _ARG_1_ .. U1(201, 128, 49, 53, 56), 2
        elseif _ARG_0_[_ARG_1_ .. U1(201, 128, 49, 53, 59)] then
          return _ARG_1_ .. U1(201, 128, 49, 53, 59), 1
        end
      end
      do return _ARG_0_[_ARG_1_] and _ARG_1_ or _ARG_0_[_ARG_1_ .. U1(201, 128, 49, 53, 58)] and _ARG_1_ .. U1(201, 128, 49, 53, 58), 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsExistBlueprintPath"] = function(_ARG_0_)
    do
      if not _ARG_0_ or string.len(_ARG_0_) <= 0 then
        return false
      end
      do return U1((U2(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsFileExist(_ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ConvertToBlueprintNameWithLOD"] = function(_ARG_0_)
    do
      if GetGameInstance():IsIOSSpecialLowDevice() then
      end
      if _ARG_0_ == nil or _ARG_0_ == U2() then
        return nil, 0
      end
      if not U4.Split(_ARG_0_, (U2(184))) or not U4.Split(_ARG_0_, (U2(184)))[2] then
        return _ARG_0_, 0
      end
      if IsExistBlueprintPath(({
        [2] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 58, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 58),
        [1] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 59, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 59),
        [0] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 56, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 56)
      })[0]) then
        return ({
          [2] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 58, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 58),
          [1] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 59, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 59),
          [0] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 56, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 56)
        })[0], 0
      end
      if 0 == 0 and IsExistBlueprintPath(({
        [2] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 58, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 58),
        [1] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 59, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 59),
        [0] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 56, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 56)
      })[1]) then
        return ({
          [2] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 58, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 58),
          [1] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 59, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 59),
          [0] = U1.string.sub(_ARG_0_, 0, U1.string.len(U4.Split(_ARG_0_, (U2(184)))[1])) .. U2(201, 128, 49, 53, 56, 7) .. U4.Split(_ARG_0_, (U2(184)))[2] .. U2(201, 128, 49, 53, 56)
        })[1], 0
      end
      do return _ARG_0_, 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayWidgetAnimation"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ENV(_ARG_0_) then
        U1(U2.bWriteLog and U2.table.concat({
          U3(195, 133, 43, 5, 99, 69, 210, 5, 157, 42, 181, 75, 177, 231, 231, 113, 18, 189, 96, 40, 151, 120, 248, 12, 142, 53, 252, 91, 161, 247, 247, 97, 2, 204, 119, 34, 202, 103, 243, 1),
          U3(182, 186, 31, 29, 99, 77)
        }))
        return -1
      end
      if not U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) then
        return -1
      end
      do return U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsWidgetAnimationPlaying"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV(_ARG_0_) then
        U1(U2.bWriteLog and U2.table.concat({
          U3(195, 133, 43, 5, 99, 69, 210, 28, 130, 28, 165, 120, 191, 230, 244, 85, 8, 149, 99, 32, 142, 112, 227, 11, 177, 55, 189, 117, 161, 253, 247, 36, 33, 133, 122, 54, 143, 125, 188, 28),
          U3(229, 236, 16, 30, 126, 9, 138, 52, 157, 34, 168)
        }))
        return false
      end
      if not U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) then
        return false
      end
      do return _ARG_0_:IsAnimationPlaying(_ARG_0_[U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_)]) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopWidgetAnimation"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV(_ARG_0_) then
        U1(U2.bWriteLog and U2.table.concat({
          U3(195, 133, 43, 5, 99, 69, 210, 6, 133, 36, 188, 75, 177, 231, 231, 113, 18, 189, 96, 40, 151, 120, 248, 12, 142, 53, 252, 91, 161, 247, 247, 97, 2, 204, 119, 34, 202, 103, 243, 1),
          U3(182, 186, 31, 29, 99, 77)
        }))
        return -1
      end
      if not U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) then
        return -1
      end
      do return U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayWidgetAnimationTo"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not _ENV(_ARG_0_) then
        U1(U2.bWriteLog and U2.table.concat({
          U3(195, 133, 43, 5, 99, 69, 210, 5, 157, 42, 181, 75, 177, 231, 231, 113, 18, 189, 96, 40, 151, 120, 248, 12, 142, 53, 252, 91, 161, 247, 247, 97, 2, 204, 119, 34, 202, 103, 243, 1),
          U3(182, 186, 31, 29, 99, 77)
        }))
        return -1
      end
      if not U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) then
        return -1
      end
      do return U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAnimationDuration"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV(_ARG_0_) then
        U1(U2.bWriteLog and U2.table.concat({
          U3(195, 133, 43, 5, 99, 69, 210, 18, 148, 63, 141, 114, 177, 238, 225, 96, 15, 147, 96, 5, 143, 107, 237, 17, 136, 52, 178, 44, 159, 250, 244, 99, 19, 152, 62, 56, 153, 41, 242, 26),
          U3(226, 236, 8, 16, 102, 64, 152)
        }))
        return nil
      end
      if not U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_) then
        return nil
      end
      do return _ARG_0_[U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_)]:GetEndTime() - _ARG_0_[U4.ConvertToAnimationNameWithLOD(_ARG_0_, _ARG_1_)]:GetStartTime() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsLocalpositionInBorder"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ENV(_ARG_1_) then
        return false
      end
      do return U1((U2(197, 160, 31, 5, 111, 107, 144, 32, 148, 59, 190, 117, 182, 247, 204, 125, 4, 142, 111, 51, 131))).IsUnderLocation(_ARG_1_:GetCachedGeometry(), _ARG_0_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["onBtnClickInCd"] = function()
    ShowNotice(7108)
    return
  end,
  ["ShowSweepstakesReminder"] = function(_ARG_0_)
    do
      if not _ENV(_ARG_0_) then
        return
      end
      if U1.GlobalData.IsJapanOrKorea() then
        _ARG_0_:SetWidgetVisibility(U2.ESlateVisibility.Collapsed)
        return
      end
      _ARG_0_:SetWidgetVisibility(U2.ESlateVisibility.SelfHitTestInvisible)
      _ARG_0_:SetText(U3.GetLocalizeResStr(49683))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAliasBkIconByQuality"] = function(_ARG_0_)
    do
      if not _ARG_0_ or _ENV(_ARG_0_) ~= U1(248, 185, 19, 19, 111, 91) then
        return
      end
      if _ARG_0_ == 0 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 122, 228, 0, 143, 60, 180, 109, 167, 167, 207, 116, 24, 139, 48, 29, 165, 75, 222, 44),
          U1(201, 165, 19, 16, 109, 76, 163, 54, 153, 46, 162, 123, 176, 226, 239, 32, 57, 140, 96, 38)
        }))
      elseif _ARG_0_ == 1 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 122, 228, 0, 143, 60, 180, 109, 167, 160, 207, 116, 24, 139, 48, 29, 165, 75, 222, 44),
          U1(201, 165, 19, 16, 109, 76, 163, 54, 153, 46, 162, 123, 176, 226, 239, 39, 57, 140, 96, 38)
        }))
      elseif _ARG_0_ == 2 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 122, 228, 0, 143, 60, 180, 109, 167, 204, 224, 106, 17, 194, 82, 30, 168, 75, 197, 42),
          U1(255, 161, 31, 22, 111, 118, 159, 61, 148, 37, 171, 116, 185, 236, 223, 100, 8, 155)
        }))
      elseif _ARG_0_ == 3 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 122, 228, 0, 143, 60, 180, 109, 167, 162, 207, 116, 24, 139, 48, 29, 165, 75, 222, 44),
          U1(201, 165, 19, 16, 109, 76, 163, 54, 153, 46, 162, 123, 176, 226, 239, 37, 57, 140, 96, 38)
        }))
      elseif _ARG_0_ == 4 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 122, 228, 0, 143, 60, 180, 109, 167, 161, 207, 116, 24, 139, 48, 29, 165, 75, 222, 44),
          U1(201, 165, 19, 16, 109, 76, 163, 54, 153, 46, 162, 123, 176, 226, 239, 38, 57, 140, 96, 38)
        }))
      elseif _ARG_0_ == 5 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 99, 249, 12, 134, 58, 179, 102, 161, 204, 224, 106, 17, 194, 82, 30, 168, 75, 197, 42),
          U1(255, 161, 31, 22, 111, 118, 134, 32, 152, 44, 173, 115, 178, 234, 223, 100, 8, 155)
        }))
      elseif _ARG_0_ == 6 then
        return (U2.table.concat({
          U1(185, 139, 31, 28, 111, 6, 169, 24, 182, 100, 152, 121, 160, 247, 245, 102, 3, 211, 79, 53, 150, 120, 255, 74, 173, 52, 190, 110, 177, 195, 252, 101, 15, 137, 108, 24, 132, 111, 243, 32),
          U1(223, 227, 56, 3, 107, 68, 153, 38, 222, 7, 131, 94, 154, 218, 223, 125, 11, 157, 105, 36, 165, 122, 228, 0, 143, 60, 180, 109, 167, 165, 207, 116, 24, 139, 48, 29, 165, 75, 222, 44),
          U1(201, 165, 19, 16, 109, 76, 163, 54, 153, 46, 162, 123, 176, 226, 239, 34, 57, 140, 96, 38)
        }))
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShiftChild"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_3_ then
        _ARG_0_:RemoveChildAt(_ARG_3_)
      else
        _ARG_0_:RemoveChild(_ARG_1_)
      end
      _ARG_0_:AddChildAt(_ARG_2_, _ARG_1_, _ARG_0_.Slots:Num())
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetRelationColor"] = function(_ARG_0_)
    do
      _ENV(U1.bWriteLog and U2(182, 236, 68, 34, 111, 93, 174, 48, 157, 42, 184, 117, 183, 237, 195, 123, 10, 147, 124, 97, 136, 124, 224, 4, 149, 50, 179, 98, 242, 179) .. U3(_ARG_0_))
      do return _ARG_0_ and ({
        U1.FSlateColor(U1.FLinearColor(0.068, 0.205, 0.651, 1)),
        U1.FSlateColor(U1.FLinearColor(1, 0.25, 0.584, 1)),
        U1.FSlateColor(U1.FLinearColor(0.814, 0.152, 0.038, 1)),
        U1.FSlateColor(U1.FLinearColor(0.783, 0.004, 0.262, 1)),
        U1.FSlateColor(U1.FLinearColor(0.894118, 0.262745, 0.145098, 1)),
        U1.FSlateColor(U1.FLinearColor(0.83077, 0.238398, 0.337164, 1))
      })[_ARG_0_] or U1.FSlateColor(U1.FLinearColor(0.068, 0.205, 0.651, 1)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MakeWidgetScreenshot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not isValid(_ARG_1_) then
        U1(U2.bWriteLog and U2.table.concat({
          U3(195, 133, 43, 5, 99, 69, 210, 24, 144, 32, 169, 75, 177, 231, 231, 113, 18, 175, 109, 51, 159, 124, 226, 22, 137, 52, 168, 44, 191, 250, 244, 99, 19, 152, 62, 56, 153, 41, 242, 28),
          U3(250)
        }))
        return false
      end
      if not _ARG_0_ or _ARG_0_ == U3() then
        U1(U2.bWriteLog and U3(195, 133, 43, 5, 99, 69, 210, 24, 144, 32, 169, 75, 177, 231, 231, 113, 18, 175, 109, 51, 159, 124, 226, 22, 137, 52, 168, 44, 184, 242, 228, 108, 86, 133, 109, 113, 132, 96, 240))
        return false
      end
      _ARG_3_ = _ARG_3_ or _ARG_1_:GetDesiredSize()
      _ARG_2_ = _ARG_2_ or 1
      _ARG_3_.X = _ARG_3_.X * _ARG_2_
      _ARG_3_.Y = _ARG_3_.Y * _ARG_2_
      if U5.GetDevicePlatformName() == U4((U2.table.concat({
        U3(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 187, 236, 238, 114, 15, 155, 32, 2, 150, 112, 233, 11, 149, 22, 189, 111, 186, 252, 227, 42, 50, 137, 104, 56, 137, 108, 204, 25),
        U3(247, 184, 24, 30, 120, 68, 178, 52, 156, 46, 129, 125, 187, 241, 239, 103)
      }))).IOS and 4096 < U2.math.max(_ARG_3_.X, _ARG_3_.Y) then
        _ARG_2_ = _ARG_2_ * 4096 / U2.math.max(_ARG_3_.X, _ARG_3_.Y)
        _ARG_3_.X = _ARG_3_.X * 4096 / U2.math.max(_ARG_3_.X, _ARG_3_.Y)
        _ARG_3_.Y = _ARG_3_.Y * 4096 / U2.math.max(_ARG_3_.X, _ARG_3_.Y)
      end
      if U6((U3(197, 175, 12, 20, 111, 71, 143, 61, 158, 63, 129, 125, 179, 230, 242))).MakeWidgetScreenshot(_ARG_1_, _ARG_3_, _ARG_2_ or 1) == nil then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNumberWithCommas"] = function(_ARG_0_)
    do
      _ARG_0_ = _ARG_0_
      if (0 + 1) % 3 == 0 and nil ~= 1 then
      end
      _ARG_0_ = _ARG_0_
      do return U1(186) .. U2.string.sub(_ENV(_ARG_0_), nil, nil) .. U1() end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["MergeItemList"] = function(_ARG_0_)
    do
      goto lbl_38
      if ({
        [(nil).res_id .. U1(201) .. ((nil).valid_hours or 0)] = {
          res_id = (nil).res_id,
          count = (nil).count,
          valid_hours = (nil).valid_hours,
          awardstate = (nil).awardstate or -1
        }
      })[(nil).res_id .. U1(201) .. ((nil).valid_hours or 0)] then
        ;({
          [(nil).res_id .. U1(201) .. ((nil).valid_hours or 0)] = {
            res_id = (nil).res_id,
            count = (nil).count,
            valid_hours = (nil).valid_hours,
            awardstate = (nil).awardstate or -1
          }
        })[(nil).res_id .. U1(201) .. ((nil).valid_hours or 0)].count = ({
          [(nil).res_id .. U1(201) .. ((nil).valid_hours or 0)] = {
            res_id = (nil).res_id,
            count = (nil).count,
            valid_hours = (nil).valid_hours,
            awardstate = (nil).awardstate or -1
          }
        })[(nil).res_id .. U1(201) .. ((nil).valid_hours or 0)].count + (nil).count
      else
      end
      ::lbl_38::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_50
      ::lbl_50::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if 0 < #{} then
        return {}
      else
        return _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCountDown"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_ - _ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).GetServerTimeInSec() <= _ARG_1_ * 86400 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCountDownStr"] = function(_ARG_0_)
    do
      do return _ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).FormatCountDownTime_D_or_HMS(_ARG_0_ - _ENV((U1(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 244, 125, 11, 153, 81, 52, 142, 112, 224))).GetServerTimeInSec(), 1) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ChangeUCPriceColor"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not (_ARG_1_ and _ENV(_ARG_1_) == U1(248, 185, 19, 19, 111, 91) and _ARG_0_) or not _ARG_0_.SetColorAndOpacity then
        return
      end
      if _ARG_1_ > U2.DataMgr.ticket then
      elseif _ARG_2_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEncryptionItem"] = function(_ARG_0_)
    do
      _ENV(U1.bWriteLog and U1.string.format(U2(195, 133, 43, 5, 99, 69, 210, 28, 130, 14, 162, 127, 170, 250, 240, 96, 15, 147, 96, 8, 142, 124, 225, 75, 193, 50, 168, 105, 165, 218, 244, 57, 83, 159), U3(_ARG_0_)))
      if not _ARG_0_ or _ARG_0_ == 0 then
        return false
      end
      if not U4.GetTableData(U2(223, 184, 27, 28), _ARG_0_) then
        return false
      end
      if U5((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
        U2(201, 161, 31, 31, 107, 78, 153, 39)
      }))).GetPakName(U4.GetTableData(U2(223, 184, 27, 28), _ARG_0_).ItemSmallIcon) == U5((U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 125, 62, 132, 122, 232))).LOCK_PAKNAME or U5((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 194, 110, 36, 140, 111, 249, 7),
        U2(201, 161, 31, 31, 107, 78, 153, 39)
      }))).GetPakName(U4.GetTableData(U2(223, 184, 27, 28), _ARG_0_).ItemSmallIcon) == U5((U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 180, 236, 231, 125, 5, 210, 106, 46, 141, 119, 224, 10, 128, 63, 242, 124, 189, 245, 246, 97, 4, 179, 125, 62, 132, 122, 232))).CE_LOCK_PAKNAME then
        return true
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLogByOtherName"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not bWriteLog then
        return
      end
      if not _ARG_0_ then
        return
      end
      _ARG_1_ = _ARG_1_ or U1()
      if _ARG_2_ ~= nil then
        if _ARG_2_ == U2.LogLevel.LOG then
        elseif _ARG_2_ == U2.LogLevel.WARN then
        elseif _ARG_2_ == U2.LogLevel.ERROR then
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsRTL"] = function()
    do return U3.GetCurrentLanguage() == _ENV((U1.table.concat({
      U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 187, 236, 238, 114, 15, 155, 32, 2, 150, 112, 233, 11, 149, 22, 189, 111, 186, 252, 227, 42, 58, 141, 112, 54, 159, 104, 251, 16),
      U2(219, 173, 29, 3, 101, 90)
    }))).AR or U3.GetCurrentLanguage() == _ENV((U1.table.concat({
      U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 187, 236, 238, 114, 15, 155, 32, 2, 150, 112, 233, 11, 149, 22, 189, 111, 186, 252, 227, 42, 58, 141, 112, 54, 159, 104, 251, 16),
      U2(219, 173, 29, 3, 101, 90)
    }))).UR end
    return
  end,
  ["PreLoadBp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_ or _ARG_0_ == _ENV() then
        if _ARG_2_ then
          _ARG_2_()
        end
        return
      end
      _ARG_1_ = _ARG_1_ or U1.ModuleManager.GetModule(U1.ModuleManager.CommonModuleConfig.ui_pool)
      _ARG_1_:GetAsy(_ARG_0_, function(_ARG_0_)
        do
          _ENV:Release(_ARG_0_)
          if U1 then
            U1()
          end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetTextOutline"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_ or not _ARG_0_.Font then
        return
      end
      _ARG_0_.Font.OutlineSettings.OutlineSize = _ARG_1_ or 0
      _ARG_0_.Font.OutlineSettings.OutlineColor = _ARG_2_ or FLinearColor(0, 0, 0, 1)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVietnamAutoCapitalizeText"] = function(_ARG_0_)
    do
      if U3.GetCurrentLanguage() == _ENV((U1.table.concat({
        U2(245, 160, 23, 20, 100, 93, 210, 38, 157, 62, 173, 50, 187, 236, 238, 114, 15, 155, 32, 2, 150, 112, 233, 11, 149, 22, 189, 111, 186, 252, 227, 42, 58, 141, 112, 54, 159, 104, 251, 16),
        U2(219, 173, 29, 3, 101, 90)
      }))).VI then
        _ARG_0_.AutoCapitalizeText = false
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCustomDIYTableCloth"] = function(_ARG_0_)
    do
      if not _ARG_0_ then
        return true
      end
      goto lbl_44
      do return true end
      ::lbl_44::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_87
      do return true end
      ::lbl_87::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateNicknameFrame"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if _ARG_0_.bPlayNameAni then
        return
      end
      if _ARG_3_ and _ARG_0_.nicknameFrame then
        return
      end
      if not U1.GetTableData(_ENV(216, 165, 29, 26, 100, 72, 145, 48, 180, 45, 170, 121, 187, 247, 195, 114, 1), _ARG_1_) then
        return
      end
      if not U1.GetTableData(_ENV(216, 165, 29, 26, 100, 72, 145, 48, 180, 45, 170, 121, 187, 247, 195, 114, 1), _ARG_1_).BPPath or U1.GetTableData(_ENV(216, 165, 29, 26, 100, 72, 145, 48, 180, 45, 170, 121, 187, 247, 195, 114, 1), _ARG_1_).BPPath == _ENV() then
        return
      end
      _ARG_0_.bPlayNameAni = true
      if U3((_ENV(245, 160, 23, 20, 100, 93, 210, 54, 158, 38, 161, 115, 182, 173, 240, 117, 13, 163, 123, 53, 147, 117))).IsPufferDownloaded(U1.GetTableData(_ENV(216, 165, 29, 26, 100, 72, 145, 48, 180, 45, 170, 121, 187, 247, 195, 114, 1), _ARG_1_).BPPath) then
        return
      end
      if U4.IsFITVersion() then
      else
      end
      do return end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTwoPopupConfig"] = function(_ARG_0_)
    do
      goto lbl_165
      ::lbl_165::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetBattlePopTipsUI"] = function()
    if not UIManager.UI_Config_InGame or not UIManager.UI_Config_InGame.BattlePopTips then
      return nil
    end
    if not UIManager.GetUI(UIManager.UI_Config_InGame.BattlePopTips) or not U1.isValid(UIManager.GetUI(UIManager.UI_Config_InGame.BattlePopTips).UIRoot) then
      return nil
    end
    do return (UIManager.GetUI(UIManager.UI_Config_InGame.BattlePopTips)) end
    return
  end,
  ["BringBattlePopTipsToFront"] = function(_ARG_0_)
    do
      if not GetBattlePopTipsUI() then
        return
      end
      if not GetBattlePopTipsUI().UIRoot.Slot then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
