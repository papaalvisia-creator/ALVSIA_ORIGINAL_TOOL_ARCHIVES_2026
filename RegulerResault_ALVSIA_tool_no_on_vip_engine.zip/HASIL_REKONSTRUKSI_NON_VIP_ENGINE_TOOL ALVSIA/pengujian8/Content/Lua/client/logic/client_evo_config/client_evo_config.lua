do return {
  bInit = false,
  bLevelStreamingBackEndEnable = false,
  SavedLevelStreamingRemoveLevelTimeLimit = 5,
  SavedLevelStreamingOptSpecialApplyWorldOffsetActorNum = 1,
  SavedLevelStreamingOptSpecialHeavyRegComponentNum = 1,
  SavedLevelStreamingOptSpecialRegComponentTimeLimit = 3,
  SavedLevelStreamingOptSpecialUnRegComponentTimeLimit = 3,
  SavedLevelStreamingOptSpecialHeavyUnRegComponentNum = 1,
  SavedLevelStreamingOptSpecialRouteActorEndPlayGranularity = 10,
  SavedLevelStreamingOptSpecialComponentsRegistrationGranularity = 10,
  SavedLevelStreamingOptSpecialHISMPhysicBodyIncrementClearNum = 150,
  SavedLevelStreamingOptSpecialHeavyActorBeginPlayNum = 0,
  SavedLevelStreamingOptSpecialRouteActorInitializeGranularity = 3,
  SavedLevelStreamingOptSpecialLimitPreformStep = 1,
  SavedLevelStreamingOptSpecialSortLevlFromPriority = 1,
  SavedLevelStreamingOptSpecialIncrementalUnregisterComponents = 1,
  SavedLevelStreamingOptSpecialMaxUnLoadLevelGCMemoryThresholds = 50000,
  SavedLevelStreamingOptSpecialBodyStreamingCountPerTimeLimit = 20,
  SavedLevelStreamingOptSpecialBodyStreamingTimeLimit = 5,
  SavedSuperFrameEnableUpdateLevelStreamingInUpdateCamera = 0,
  bTickAsyncLoadingSetInFighting = false,
  bTickAsyncLoadingBackEndEnable = false,
  SavedTickAsyncLoadingOptSpecialMaxHeavyObjectPostLoadCost = 32768,
  SavedTickAsyncLoadingOptSpecialIncrementalUpdateDistanceVolumeGranularity = 100,
  SavedTickAsyncLoadingOptSpecialPostLoadThreadEnabled = 1,
  SavedTickAsyncLoadingOptSpecialTexCubeMaxSizeLimit = 32,
  SavedLightOptSwitcher = 0,
  CloudLightLossyOptEnable = nil,
  CloudLightCommonOptEnable = nil,
  bLightOptAppliedInFighting = false,
  bLightLossyOptCurrentEnabled = false,
  bLightOptForceEnableByGM = false,
  SavedLightOptCmdValues = {},
  ManagedTickNonTypicalModList = {
    21001,
    21002,
    21003,
    21004,
    880047,
    40001,
    40002,
    40003,
    40004,
    40005,
    40006,
    26000,
    12050,
    12051,
    12054,
    12055,
    999008,
    999009,
    12021,
    12022,
    12023,
    12024,
    12025,
    12026,
    12027,
    12028,
    12029,
    12030,
    12031,
    12032,
    12033,
    12034,
    12035,
    12036,
    12037,
    12038,
    12039,
    12040,
    12041,
    12042,
    12043,
    12044,
    12045,
    12101,
    12102,
    12103,
    12104,
    12105,
    12106,
    12107,
    12108,
    12109,
    12201,
    12202,
    12203,
    12204,
    12205,
    12206,
    12207,
    12208,
    12209
  },
  bEnterBorderland = false,
  BorderlandModList = {
    2301,
    2302,
    2303,
    2304,
    2305,
    2306,
    2311,
    2312,
    2313,
    2314,
    2315,
    2316,
    90016,
    90017,
    90018,
    90019,
    90020,
    90021
  },
  bEnterTMod = false,
  TModList = {
    23001,
    23004,
    23005,
    23006,
    23007,
    23008,
    23009,
    23010,
    23012,
    23013,
    23104,
    23015,
    23016,
    23017,
    23018,
    23019,
    23020,
    91067,
    91068,
    91069,
    91070,
    91071,
    91072,
    91073,
    91074
  },
  bEnterSingleMode = false,
  SingModlList = {
    24005,
    24006,
    24007,
    24008,
    24009,
    24010
  },
  SavedUseLowFakeLandScape = 0,
  bUseLowFakeLandScapeBackEndEnable = false,
  bEnableSlateGICloud = false,
  bEnableInvalidationPanelsCloud = false,
  bEnableSlateVerifyHitTestVisibilityCloud = false,
  bEnableRemoveVolatilePrepassFlagCloud = false,
  bEnableFixSlateFastPathHitTestCloud = false,
  MaxFontAtlasPagesBeforeFlushRequest = 1,
  bForceOneFontAtlasPage = false,
  bEnableUIDynamicBatch = false,
  bSlateThrottleSwitchEnabled = false,
  bEnableSlateThrottle = false,
  bSlateGIThrottleSwitchEnabled = false,
  bEnableSlateGIThrottle = false,
  bLightSlateGIThrottleSwitchEnabled = false,
  bEnableLightSlateGIThrottle = false,
  bUseLightSlateGIThrottleWhiteList = true,
  bLightWidgetTickFrequencySwitchEnabled = false,
  bEnableLightWidgetTickFrequency = false,
  bUseLightWidgetTickFrequencyWhiteList = true,
  bWidgetTickFrequencySwitchEnabled = false,
  bEnableWidgetTickFrequency = false,
  bUseWidgetTickFrequencyWhiteList = true,
  bSlateGIThrottleSetByGM = false,
  bSlateFrequencySetByGM = false,
  bEnableSlateLayoutCache = false,
  bEnableSlateLayoutCacheBackendValue = false,
  NewObjectPoolGCConfigValue = nil,
  TextureMipOffsetbackUp = -1,
  bEnableIOSPSOCache = false,
  NewObjectPoolAvailableMod = {
    BaseMod = true,
    Mecha = true,
    Atlantis = true,
    NewbieGame = true,
    TPlanPVE = true,
    CreativeBase = true,
    HeavyWeapon = true,
    Halloween4 = true,
    IceWorld3 = true,
    EasternRealm = true,
    Neon = true,
    ZNQ7th = true,
    SteamTrain = true,
    Egypt2 = true,
    TDM = false
  },
  LayoutCacheAvailableMod = {
    BaseMod = true,
    SteamTrain = true,
    TPlanPVE = true,
    PlanTF = true,
    Halloween5 = true,
    Escape = true,
    IceWorld4 = true,
    ZNQ8th = true
  },
  InvalidationPanelsAvailableMod = {
    TDM = false,
    PlanPH = false,
    SocialIsland = false
  },
  ActorSpawnQueueAvailableMod = {BaseMod = true, TPlanX = false},
  SlateGIAvailableMod = {
    CreativeBase = false,
    MainCity = false,
    SocialIsland = false,
    PlanPH = false,
    PlanCH = false,
    SingleTraining = false
  },
  bNeedDelayEnableSlateGI = false,
  bNewObjectPoolGCOptimizationEnable = false,
  bNewObjectPoolDefferedPhysicsState = false,
  bEnable400AnimationOptimization = false,
  bEnableNotRenderedParallelUpdateBackEnd = false,
  bEnableNotRenderedParallelUpdateApplied = false,
  bEnableRefreshBonesTickAnimationOptBackEnd = false,
  bEnableRefreshBonesTickAnimationOptApplied = false,
  DefaultJankCollectionTimeThresholdOnIni = 0,
  DefaultSleepTimeThodOnIni = 5.0E-4,
  DefaultSleepSlackTimeOnIni = 5.0E-4,
  CurrentWorldName = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(),
  LastWorldName = (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(),
  CurrentModID = 0,
  SlateTickDownWhitList = {
    Baltic_Main = 1,
    FourMaps_Main = 1,
    PUBG_Desert = 1,
    DihorOtok_Main = 1,
    PUBG_Savage_Main = 1
  },
  SlateThrottleWhiteList = {Baltic_Main = 1, UEDPIE_1_Baltic_Main = 1},
  bUseSlateThrottleWhiteList = true,
  SlateGIThrottleWhiteList = {Baltic_Main = 1, UEDPIE_1_Baltic_Main = 1},
  bUseSlateGIThrottleWhiteList = true,
  bLevelEnd = false,
  bCallLoadingUIOpend = false,
  backupHLODScale = 1.0,
  CurrentBattleFPSLevel = 1,
  CollectorTimerID = 0,
  DefaultGCSweepTimeOnIni = 0,
  EnableGCSweepTimeModifiy_GCloud = 0,
  CloseGCWhitList = {
    AR_Library = 1,
    TD_FoolsDayBigHead_Factory = 1,
    TD_Factory_Depot_Main = 1,
    HP_City_Main = 1,
    TD_Ruins_Half = 1,
    TD_RushHour = 1,
    TD_Santorini = 1
  },
  BackUpbUseNewHole = -1,
  BakcUpNumVisibleComponents = 0,
  BackGrassUpdateIntervel = 5,
  bFirstEnterLobby = true,
  bOpenDevLog = false,
  ManagedTickSysFlagBackEnd = 0,
  bEnableActorSpawnQueueCloud = false,
  bEnableActorSpawnQueueLightOpt = false,
  bTextureGroupBiasApplied = false,
  CachedFlashFavorVerySmooth50Device = nil,
  ["IsFlashFavorVerySmooth50Device"] = function()
    if CachedFlashFavorVerySmooth50Device ~= nil then
      return CachedFlashFavorVerySmooth50Device
    end
    CachedFlashFavorVerySmooth50Device = U1.require((U1.table.concat({
      U2(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 152, 109, 28, 226, 57, 55, 26, 128, 93, 91, 11, 86, 2, 252, 65, 85, 143, 113, 27, 180, 14, 33, 14, 141, 77, 72, 65, 104),
      U2(245, 3, 109, 139, 161, 124, 71, 106, 16, 251, 26, 112, 184, 116, 18, 160)
    }))).IsFlashFavorEnabled() and U1.Client.GetDevicePlatformName() == U1.require((U1.table.concat({
      U2(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
      U2(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
    }))).Android and (U1.Client.GetTCDeviceLevel() == 5 or U1.Client.GetTCDeviceLevel() == 6) and not (U1.math.max(U1.Client.GetPhysicalScreenWidth(), U1.Client.GetPhysicalScreenHeight()) > 1900) and (U1.require((U2(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U1.require((U1.table.concat({
      U2(228, 14, 116, 134, 166, 107, 33, 99, 19, 236, 22, 97, 195, 99, 23, 165, 18, 60, 25, 140, 93, 89, 16, 96, 15, 244, 1, 116, 148, 119, 69, 143, 18, 50, 24, 177, 110, 77, 14, 66),
      U2(226, 49, 126, 130, 164, 122, 73, 110, 31, 255, 16, 112, 169, 111, 12, 162, 52, 61, 3, 181, 81, 72)
    }))).WhiteListDeviceModel, (U1.Client.GetDeviceModel())) or U1.require((U2(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U1.require((U1.table.concat({
      U2(228, 14, 116, 134, 166, 107, 33, 99, 19, 236, 22, 97, 195, 99, 23, 165, 18, 60, 25, 140, 93, 89, 16, 96, 15, 244, 1, 116, 148, 119, 69, 143, 18, 50, 24, 177, 110, 77, 14, 66),
      U2(226, 49, 126, 130, 164, 122, 73, 110, 31, 255, 16, 112, 169, 111, 12, 162, 52, 61, 3, 181, 81, 72)
    }))).WhiteListSOC, (U1.Client.GetLowerSOCModelAboveAndroid12()))) and 12 < U1.ModuleManager.GetModule(U1.ModuleManager.LobbyModuleConfig.device_module):GetOSMajorVersion()
    do return CachedFlashFavorVerySmooth50Device end
    return
  end,
  ["IsSuperFrameScaleFactorDownEnable"] = function()
    do return 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 92, 122, 12, 238, 13, 68, 159, 97, 22, 169, 36, 49, 12, 191, 93, 105, 30, 92, 24, 244, 29, 86, 146, 103, 5), 0) and require((table.concat({
      U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 152, 109, 28, 226, 57, 55, 26, 128, 93, 91, 11, 86, 2, 252, 65, 85, 143, 113, 27, 180, 14, 33, 14, 141, 77, 72, 65, 104),
      U1(245, 3, 109, 139, 161, 124, 71, 106, 16, 251, 26, 112, 184, 116, 18, 160)
    }))).IsFlashFavorEnabled() and Client.GetDevicePlatformName() == require((table.concat({
      U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
      U1(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
    }))).Android and (Client.GetTCDeviceLevel() == 5 or Client.GetTCDeviceLevel() == 6) end
    return
  end,
  ["Init"] = function()
    if bInit == true then
      return
    end
    bInit = true
    CollectorTimerID = 0
    U1.EventSystem:registEvent(U1.EVENTTYPE_STATE, U1.EVENTID_GAMESTATE_ON_PRE_BATTLE_RESULT, HandleOnPreBattleResult)
    U1.EventSystem:registEvent(U1.EVENTTYPE_ACCOUNT, U1.EVENTID_BATTLE_RESULT_ON_START_PHASE, HandleOnBattleResultStartPase)
    U1.EventSystem:registEvent(U1.EVENTTYPE_ACCOUNT, U1.EVENTID_BATTLE_RESULT_ON_END_PHASE, HandleOnBattleResultEndPase)
    U1.EventSystem:registEvent(U1.EVENTTYPE_LOBBY, U1.EVENTID_LOADING_PRE_BEGIN, HandleOnLoadingPreBegin)
    U1.EventSystem:registEvent(U1.EVENTTYPE_LOBBY, U1.EVENTID_LOADING_FINISH, HandleOnLoadingEnd)
    DefaultJankCollectionTimeThresholdOnIni = U1.import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableFloatValue((U2(205, 3, 115, 136, 230, 92, 96, 99, 16, 238, 28, 118, 132, 111, 21, 152, 30, 63, 8, 135, 80, 93, 26, 76, 4, 244, 3, 118)))
    DefaultSleepTimeThodOnIni = U1.import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableFloatValue((U2(194, 12, 122, 138, 166, 122, 33, 72, 47, 231, 26, 103, 157, 84, 18, 161, 18, 6, 5, 188, 92)))
    DefaultSleepSlackTimeOnIni = U1.import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableFloatValue((U2(194, 12, 122, 138, 166, 122, 33, 72, 47, 231, 26, 103, 157, 83, 23, 173, 20, 57, 57, 186, 85, 74, 43, 87, 3, 255)))
    backupHLODScale = U1.import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableFloatValue((U2(245, 76, 85, 175, 135, 91, 33, 75, 21, 248, 11, 99, 131, 99, 30, 159, 20, 51, 1, 182)))
    BackGrassUpdateIntervel = U1.import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1.table.concat({
      U2(244, 76, 77, 140, 191, 122, 125, 64, 12, 255, 44, 103, 157, 99, 18, 173, 27, 124, 33, 178, 86, 75, 44, 92, 13, 235, 10, 65, 152, 98, 2, 185, 20, 108, 58, 177, 73, 76, 28, 122),
      U2(247, 6, 124, 151, 173, 86, 97, 123, 25, 249, 9, 99, 129)
    })))
    CurrentBattleFPSLevel = U1.require((U1.table.concat({
      U2(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 129, 111, 28, 165, 20, 124, 30, 182, 76, 91, 22, 81, 11, 181, 3, 125, 154, 121, 8, 131, 20, 39, 9, 183, 65, 81, 8, 112),
      U2(224, 16, 124, 147, 160, 118, 108, 124)
    }))).GetSettingConfig().BattleFPS
    if U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(195, 11, 110, 130, 170, 115, 106, 95, 14, 238, 19, 109, 140, 100, 50, 162, 59, 61, 15, 177, 65), 0) == 1 then
      NewObjectPoolAvailableMod.NoviceGuidance = false
      NewObjectPoolAvailableMod.MainCity = false
      NewObjectPoolAvailableMod.PlanPH = false
    end
    MaxFontAtlasPagesBeforeFlushRequest = U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(202, 3, 101, 165, 167, 113, 123, 78, 8, 231, 30, 113, 189, 97, 28, 169, 4, 16, 8, 181, 87, 93, 26, 121, 0, 238, 28, 122, 175, 117, 26, 169, 2, 49, 9), 1)
    if U1.import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1.table.concat({
      U2(212, 14, 124, 151, 173, 49, 66, 110, 4, 205, 16, 108, 153, 65, 15, 160, 22, 33, 61, 178, 95, 74, 12, 125, 9, 253, 0, 96, 152, 86, 7, 169, 20, 42, 47, 166, 89, 74, 10, 92),
      U2(243)
    }))) < MaxFontAtlasPagesBeforeFlushRequest then
    end
    bForceOneFontAtlasPage = U1.HDmpveRemote.HDmpveRemoteConfigGetBool(U2(193, 13, 111, 128, 173, 80, 97, 106, 58, 228, 17, 118, 172, 116, 23, 173, 4, 2, 12, 180, 93), false)
    if bForceOneFontAtlasPage then
      MaxFontAtlasPagesBeforeFlushRequest = 1
    end
    return
  end,
  ["ShouldEnableNotRenderedParallelUpdate"] = function()
    do return bEnableNotRenderedParallelUpdateBackEnd and U1.GameStatus.IsInFightingNotSocialNotMainCityNotHome() end
    return
  end,
  ["ToggleNotRenderedParallelUpdate"] = function(_ARG_0_)
    do
      U2.bEnableNotRenderedParallelUpdateApplied = (import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(230, 76, 88, 141, 169, 125, 99, 106, 50, 228, 11, 80, 136, 110, 31, 169, 5, 55, 9, 131, 89, 93, 30, 83, 0, 254, 3, 71, 141, 116, 10, 168, 2))) or 0) == 1
      if _ARG_0_ == ((import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(230, 76, 88, 141, 169, 125, 99, 106, 50, 228, 11, 80, 136, 110, 31, 169, 5, 55, 9, 131, 89, 93, 30, 83, 0, 254, 3, 71, 141, 116, 10, 168, 2))) or 0) == 1) then
        return
      end
      U2.bEnableNotRenderedParallelUpdateApplied = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshNotRenderedParallelUpdate"] = function()
    ToggleNotRenderedParallelUpdate(ShouldEnableNotRenderedParallelUpdate())
    return
  end,
  ["ShouldEnableRefreshBonesTickAnimationOpt"] = function()
    do return bEnableRefreshBonesTickAnimationOptBackEnd and U1.GameStatus.IsInFightingNotSocialNotMainCityNotHome() end
    return
  end,
  ["ToggleRefreshBonesTickAnimationOpt"] = function(_ARG_0_)
    do
      U2.bEnableRefreshBonesTickAnimationOptApplied = (import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(230, 76, 77, 145, 161, 114, 106, 75, 19, 249, 18, 99, 131, 116, 40, 185, 21, 27, 3, 160, 76, 78, 17, 92, 9, 206, 31, 118, 156, 100, 14, 159, 8, 55, 19, 183, 77, 77))) or 0) ~= 0
      if _ARG_0_ == ((import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(230, 76, 77, 145, 161, 114, 106, 75, 19, 249, 18, 99, 131, 116, 40, 185, 21, 27, 3, 160, 76, 78, 17, 92, 9, 206, 31, 118, 156, 100, 14, 159, 8, 55, 19, 183, 77, 77))) or 0) ~= 0) then
        return
      end
      U2.bEnableRefreshBonesTickAnimationOptApplied = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshBonesTickAnimationOpt"] = function()
    ToggleRefreshBonesTickAnimationOpt(ShouldEnableRefreshBonesTickAnimationOpt())
    return
  end,
  ["Optimize_Android_32_OOM"] = function()
    if Client.GetAndroidSOVersion() ~= 32 or Client.GetMemorySize() >= 4 then
      return
    end
    if HDmpveRemote.HDmpveRemoteConfigGetIntSeprate32Bit(U1(198, 12, 121, 145, 167, 118, 107, 80, 44, 238, 13, 100, 130, 114, 22, 173, 25, 49, 8, 140, 11, 29, 32, 112, 35, 214), 0) == 1 then
    end
    return
  end,
  ["Optimize_Android_Performance_Swap_2G"] = function()
    if Client.GetMemorySize() ~= 2 then
      return
    end
    if HDmpveRemote.HDmpveRemoteConfigGetInt(U1(198, 12, 121, 145, 167, 118, 107, 80, 44, 238, 13, 100, 130, 114, 22, 173, 25, 49, 8, 140, 107, 88, 30, 79), 0) == 0 then
      return
    end
    return
  end,
  ["Optimize_Android_Performance_Swap_3G"] = function()
    if Client.GetMemorySize() ~= 3 then
      return
    end
    if HDmpveRemote.HDmpveRemoteConfigGetInt(U1(198, 12, 121, 145, 167, 118, 107, 80, 44, 238, 13, 100, 130, 114, 22, 173, 25, 49, 8, 140, 107, 88, 30, 79), 0) == 0 then
      return
    end
    return
  end,
  ["Optimize_Android_Performance_Swap_4G"] = function()
    if Client.GetMemorySize() ~= 4 then
      return
    end
    if HDmpveRemote.HDmpveRemoteConfigGetInt(U1(198, 12, 121, 145, 167, 118, 107, 80, 44, 238, 13, 100, 130, 114, 22, 173, 25, 49, 8, 140, 107, 88, 30, 79, 88), 0) == 0 then
      return
    end
    return
  end,
  ["DisableLevelStreamingOpt"] = function()
    U2.SavedLevelStreamingRemoveLevelTimeLimit = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 37, 55, 0, 188, 78, 74, 51, 90, 26, 254, 3, 70, 148, 125, 14, 144, 14, 47, 20, 183)))
    U2.SavedLevelStreamingOptSpecialApplyWorldOffsetActorNum = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableFloatValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 83, 141, 96, 7, 165, 48, 45, 15, 175, 76, 112, 9, 73),
      U1(244, 7, 105, 162, 171, 107, 96, 125, 50, 254, 18)
    })))
    U2.SavedLevelStreamingOptSpecialHeavyRegComponentNum = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 90, 152, 113, 29, 165, 53, 39, 26, 128, 71, 82, 31, 64),
      U1(233, 7, 115, 151, 134, 106, 98)
    })))
    U2.SavedLevelStreamingOptSpecialRegComponentTimeLimit = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 64, 152, 119, 40, 179, 10, 50, 18, 173, 77, 81, 27, 123),
      U1(238, 15, 120, 175, 161, 114, 102, 123)
    })))
    U2.SavedLevelStreamingOptSpecialUnRegComponentTimeLimit = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 71, 147, 66, 14, 187, 36, 45, 16, 179, 71, 81, 10, 65),
      U1(243, 54, 116, 142, 173, 83, 102, 98, 21, 255)
    })))
    U2.SavedLevelStreamingOptSpecialHeavyUnRegComponentNum = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 90, 152, 113, 29, 165, 50, 44, 47, 166, 79, 124, 0, 66),
      U1(247, 13, 115, 134, 166, 107, 65, 122, 17)
    })))
    U2.SavedLevelStreamingOptSpecialRouteActorEndPlayGranularity = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 64, 146, 101, 31, 185, 38, 33, 9, 172, 90, 122, 1, 75),
      U1(215, 14, 124, 154, 143, 109, 110, 97, 9, 231, 30, 112, 132, 116, 2)
    })))
    U2.SavedLevelStreamingOptSpecialComponentsRegistrationGranularity = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 81, 146, 125, 27, 179, 9, 39, 19, 183, 91, 109, 10, 72),
      U1(238, 17, 105, 145, 169, 107, 102, 96, 18, 204, 13, 99, 131, 117, 23, 173, 5, 59, 25, 170)
    })))
    U2.SavedLevelStreamingOptSpecialHISMPhysicBodyIncrementClearNum = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 90, 180, 67, 38, 140, 15, 59, 14, 170, 75, 125, 0, 75),
      U1(254, 43, 115, 128, 186, 122, 98, 106, 18, 255, 60, 110, 136, 97, 9, 130, 2, 63)
    })))
    U2.SavedLevelStreamingOptSpecialHeavyActorBeginPlayNum = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 90, 152, 113, 29, 165, 38, 33, 9, 172, 90, 125, 10, 72),
      U1(238, 12, 77, 143, 169, 102, 65, 122, 17)
    })))
    U2.SavedLevelStreamingOptSpecialRouteActorInitializeGranularity = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 64, 146, 101, 31, 185, 38, 33, 9, 172, 90, 118, 1, 70),
      U1(243, 11, 124, 143, 161, 101, 106, 72, 14, 234, 17, 119, 129, 97, 9, 165, 3, 43)
    })))
    U2.SavedLevelStreamingOptSpecialLimitPreformStep = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 94, 148, 125, 2, 168, 55, 48, 24, 165, 71, 77, 2, 124),
      U1(243, 7, 109)
    })))
    U2.SavedLevelStreamingOptSpecialSortLevlFromPriority = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 65, 146, 98, 31, 144, 2, 52, 17, 133, 90, 80, 2, 127),
      U1(245, 11, 114, 145, 161, 107, 118)
    })))
    U2.SavedLevelStreamingOptSpecialIncrementalUnregisterComponents = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 91, 147, 115, 25, 185, 10, 39, 19, 183, 73, 83, 58, 65),
      U1(245, 7, 122, 138, 187, 107, 106, 125, 63, 228, 18, 114, 130, 110, 30, 162, 3, 33)
    })))
    U2.SavedLevelStreamingOptSpecialMaxUnLoadLevelGCMemoryThresholds = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 95, 156, 104, 62, 178, 43, 45, 28, 167, 100, 90, 25, 74),
      U1(235, 37, 94, 174, 173, 114, 96, 125, 5, 223, 23, 112, 136, 115, 19, 163, 27, 54, 30)
    })))
    U2.SavedLevelStreamingOptSpecialBodyStreamingCountPerTimeLimit = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 80, 146, 116, 18, 143, 19, 48, 24, 162, 69, 86, 1, 72),
      U1(196, 13, 104, 141, 188, 79, 106, 125, 40, 226, 18, 103, 161, 105, 22, 165, 3)
    })))
    U2.SavedLevelStreamingOptSpecialBodyStreamingTimeLimit = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 81, 134, 190, 122, 99, 92, 8, 249, 26, 99, 128, 105, 21, 171, 56, 34, 25, 128, 72, 74, 28, 86, 13, 247, 65, 80, 146, 116, 18, 143, 19, 48, 24, 162, 69, 86, 1, 72),
      U1(211, 11, 112, 134, 132, 118, 98, 102, 8)
    })))
    U2.SavedSuperFrameEnableUpdateLevelStreamingInUpdateCamera = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(245, 76, 78, 150, 184, 122, 125, 73, 14, 234, 18, 103, 195, 69, 21, 173, 21, 62, 8, 134, 72, 75, 30, 75, 9, 215, 10, 100, 152, 124, 56, 168, 21, 39, 28, 174, 65, 81, 8, 102),
      U1(233, 55, 109, 135, 169, 107, 106, 76, 29, 230, 26, 112, 140)
    })))
    return
  end,
  ["EnableLevelStreamingOpt"] = function()
    return
  end,
  ["DisableTickAsyncLoadingOpt"] = function()
    U2.SavedTickAsyncLoadingOptSpecialMaxHeavyObjectPostLoadCost = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 73, 138, 171, 116, 78, 124, 5, 229, 28, 78, 130, 97, 31, 165, 25, 53, 34, 163, 76, 124, 15, 90, 15, 242, 14, 126, 211, 93, 10, 164, 47, 39, 28, 181, 81, 112, 13, 69),
      U1(226, 1, 105, 179, 167, 108, 123, 67, 19, 234, 27, 65, 130, 115, 15)
    })))
    U2.SavedTickAsyncLoadingOptSpecialIncrementalUpdateDistanceVolumeGranularity = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 73, 138, 171, 116, 78, 124, 5, 229, 28, 78, 130, 97, 31, 165, 25, 53, 34, 163, 76, 124, 15, 90, 15, 242, 14, 126, 211, 89, 5, 191, 21, 39, 16, 166, 70, 75, 14, 67),
      U1(210, 18, 121, 130, 188, 122, 75, 102, 15, 255, 30, 108, 142, 101, 45, 163, 27, 39, 0, 182, 127, 93, 30, 81, 25, 247, 14, 96, 148, 100, 18)
    })))
    U2.SavedTickAsyncLoadingOptSpecialPostLoadThreadEnabled = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 73, 138, 171, 116, 78, 124, 5, 229, 28, 78, 130, 97, 31, 165, 25, 53, 34, 163, 76, 124, 15, 90, 15, 242, 14, 126, 211, 64, 4, 175, 19, 14, 18, 162, 76, 107, 7, 93),
      U1(226, 3, 121, 166, 166, 126, 109, 99, 25, 239)
    })))
    U2.SavedTickAsyncLoadingOptSpecialTexCubeMaxSizeLimit = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((table.concat({
      U1(244, 76, 73, 138, 171, 116, 78, 124, 5, 229, 28, 78, 130, 97, 31, 165, 25, 53, 34, 163, 76, 124, 15, 90, 15, 242, 14, 126, 211, 68, 14, 164, 36, 55, 31, 166, 101, 94, 23, 124),
      U1(238, 24, 120, 175, 161, 114, 102, 123)
    })))
    return
  end,
  ["EnableTickAsyncLoadingOpt"] = function()
    return
  end,
  ["LightCommonOptCmdList"] = {
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 20, 51, 182, 187, 122, 67, 96, 11, 216, 22, 111, 152, 108, 26, 184, 18, 30, 34, 151, 104, 93, 16, 89, 5, 247, 10),
      1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(240, 7, 124, 147, 167, 113, 98, 104, 14, 165, 43, 107, 142, 107, 51, 165, 19, 55, 58, 182, 89, 64, 17, 118, 2, 239, 10, 96, 139, 117, 7),
      5
    }
  },
  ["LightLossyOptCmdList"] = {
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(230, 76, 72, 177, 135, 49, 72, 99, 19, 233, 30, 110, 172, 110, 18, 161, 34, 0, 34, 145, 81, 78, 12),
      1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(245, 76, 80, 138, 184, 83, 64, 75, 62, 226, 30, 113, 171, 114, 20, 161, 38, 39, 12, 191, 81, 91, 6),
      1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(245, 76, 80, 140, 170, 118, 99, 106, 82, 199, 16, 117, 169, 101, 13, 165, 20, 55, 33, 156, 124, 109, 22, 94, 31),
      1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(224, 16, 124, 144, 187, 49, 107, 106, 18, 248, 22, 118, 148, 83, 24, 173, 27, 55),
      0.4
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(245, 76, 78, 150, 184, 122, 125, 73, 14, 234, 18, 103, 195, 83, 24, 190, 18, 55, 3, 128, 81, 85, 26, 124, 25, 247, 3, 84, 156, 115, 31, 179, 21),
      1.2
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(245, 76, 78, 136, 173, 115, 106, 123, 29, 231, 50, 103, 158, 104, 55, 131, 51, 0, 12, 183, 81, 90, 12, 108, 15, 250, 3, 119),
      0.7
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(240, 7, 124, 147, 167, 113, 33, 72, 57, 229, 30, 96, 129, 101, 44, 169, 22, 34, 2, 189, 123, 90, 19, 86, 2, 252, 60, 113, 143, 117, 14, 178, 20, 43, 7, 166),
      0.1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(234, 20, 51, 176, 161, 114, 122, 99, 29, 255, 26, 78, 162, 68, 43, 190, 24, 52, 4, 191, 93),
      1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(240, 7, 124, 147, 167, 113, 33, 88, 25, 234, 15, 109, 131, 67, 9, 169, 22, 38, 8, 155, 81, 91, 54, 81, 10, 244, 44, 86),
      0.2
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(240, 7, 124, 147, 167, 113, 33, 88, 25, 234, 15, 109, 131, 67, 9, 169, 22, 38, 8, 149, 81, 93, 26, 126, 15, 239, 6, 125, 147, 83, 47),
      0.2
    },
    {
      table.concat({
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(240, 7, 124, 147, 167, 113, 33, 92, 21, 230, 10, 110, 140, 116, 30, 133, 25, 51, 14, 167, 81, 89, 26, 104, 9, 250, 31, 125, 147, 68, 2, 191, 12, 11, 19, 183, 77, 77, 25, 74),
        (function(...)
          do return table.concat({
            [...] = string.char((({
              ...
            })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
          }) end
          return
        end)(235)
      }),
      5
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(240, 7, 124, 147, 167, 113, 33, 92, 21, 230, 10, 110, 140, 116, 30, 136, 18, 52, 12, 166, 84, 91, 40, 90, 13, 235, 0, 124, 169, 121, 8, 183, 46, 44, 9, 166, 90, 73, 10, 67),
      2
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(230, 76, 81, 140, 191, 91, 106, 121, 21, 232, 26, 70, 132, 115, 26, 174, 27, 55, 62, 167, 89, 65, 27, 125, 21),
      1
    },
    {
      (function(...)
        do return table.concat({
          [...] = string.char((({
            ...
          })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
        }) end
        return
      end)(212, 14, 124, 151, 173, 49, 91, 106, 4, 255, 48, 119, 153, 108, 18, 162, 18, 31, 2, 183, 93),
      2
    }
  },
  ["SnapshotLightOptCmdValues"] = function()
    goto lbl_62
    goto lbl_60
    if U2.SavedLightOptCmdValues[(26)[1]] == nil then
      U2.SavedLightOptCmdValues[(26)[1]] = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableFloatValue((26)[1])
    end
    ::lbl_60::
    ::lbl_62::
    return
  end,
  ["ApplyLightOptCmdList"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_118
      if _ARG_1_ and _ARG_1_[(188)[1]] ~= nil then
      end
      ::lbl_118::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetLightOptCmdList"] = function(_ARG_0_)
    do
      goto lbl_94
      if U2.SavedLightOptCmdValues[(109)[1]] ~= nil then
        U2.SavedLightOptCmdValues[(109)[1]] = nil
      end
      ::lbl_94::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 + 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyLightManagedTickOpt"] = function(_ARG_0_)
    do
      if not _ARG_0_ and require((U1(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U2.ManagedTickNonTypicalModList, U2.CurrentModID) then
        return
      end
      Client.SwitchMapMangedTickProfile(999007)
      Client.RefershAllManagedTickConfigWhenFPSChanged()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyLightCommonOptCmds"] = function(_ARG_0_)
    do
      ApplyLightOptCmdList(LightCommonOptCmdList, _ARG_0_)
      ApplyLightOptCmdList(LightLossyOptCmdList, _ARG_0_)
      ApplyLightManagedTickOpt(true)
      U1.log_shipping_client((U1.table.concat({
        U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 44, 163, 72, 67, 6, 115, 5, 252, 7, 102, 190, 127, 6, 177, 8, 44, 50, 179, 92, 124, 2, 75),
        U2(244, 66, 53, 164, 133, 54)
      })))
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetLightCommonOptCmds"] = function()
    ResetLightOptCmdList(LightCommonOptCmdList)
    ResetLightOptCmdList(LightLossyOptCmdList)
    return
  end,
  ["IsLightPackage"] = function()
    do return require((table.concat({
      U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 152, 109, 28, 226, 57, 55, 26, 128, 93, 91, 11, 86, 2, 252, 65, 85, 143, 113, 27, 180, 14, 33, 14, 141, 77, 72, 65, 104),
      U1(245, 3, 109, 139, 161, 124, 71, 106, 16, 251, 26, 112, 184, 116, 18, 160)
    }))).IsFlashFavorEnabled() end
    return
  end,
  ["IsFlashOnlyQualityEnabled"] = function()
    do return require((table.concat({
      U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 129, 111, 28, 165, 20, 124, 30, 182, 76, 91, 22, 81, 11, 181, 3, 125, 154, 121, 8, 131, 20, 39, 9, 183, 65, 81, 8, 112),
      U1(224, 16, 124, 147, 160, 118, 108, 124)
    }))).IsFlashOnlyQuality(nil) end
    return
  end,
  ["ApplyLightLossyOpt"] = function(_ARG_0_)
    do
      if _ARG_0_ and _ARG_0_ == U2.bLightLossyOptCurrentEnabled then
        return
      end
      U2.bEnableActorSpawnQueueLightOpt = import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))).IsLightOptSwitcherEnable(6)
      if _ARG_0_ then
      end
      if _ARG_0_ and 7 > Client.GetTCDeviceLevel() and U2.CloudLightLossyOptEnable == 1 then
      else
      end
      U2.bLightLossyOptCurrentEnabled = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyLightCommonOpt"] = function(_ARG_0_)
    do
      if _ARG_0_ and U2.CloudLightCommonOptEnable == 1 then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyFlashOnlyQualityOptDynamic"] = function(_ARG_0_)
    do
      if not import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))) or not import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))).SetLightOptSwitcher then
        return
      end
      if not U2.IsLightPackage() then
        return
      end
      if U2.bLightOptForceEnableByGM then
        return
      end
      if GameStatus.IsInFightingNotSocialNotMainCityNotHome() then
        if not U2.bLightOptAppliedInFighting then
          return
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EnterFightingLightOpt"] = function()
    if not import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))) or not import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))).SetLightOptSwitcher then
      return
    end
    if U2.bLightOptForceEnableByGM then
      U2.bLightOptAppliedInFighting = true
      U2.bLightLossyOptCurrentEnabled = true
      return
    end
    if not U2.IsLightPackage() then
      return
    end
    if U2.CloudLightCommonOptEnable == nil then
      U2.CloudLightLossyOptEnable = HDmpveRemote.HDmpveRemoteConfigGetInt(U1(203, 11, 122, 139, 188, 83, 96, 124, 15, 242, 48, 114, 153, 69, 21, 173, 21, 62, 8), 1)
      U2.CloudLightCommonOptEnable = HDmpveRemote.HDmpveRemoteConfigGetInt(U1(203, 11, 122, 139, 188, 92, 96, 98, 17, 228, 17, 77, 157, 116, 62, 162, 22, 48, 1, 182), 1)
    end
    U2.bLightOptAppliedInFighting = true
    return
  end,
  ["LeaveFightingLightOpt"] = function()
    if not import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))) or not import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))).SetLightOptSwitcher then
      return
    end
    U2.bLightOptAppliedInFighting = false
    return
  end,
  ["GMForceEnableLightOptSwitcher"] = function()
    bLightOptForceEnableByGM = true
    U1.log_shipping_client((U1.table.concat({
      U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 42, 158, 126, 64, 13, 92, 9, 222, 1, 115, 159, 124, 14, 144, 14, 37, 21, 183, 103, 79, 27, 124),
      U2(240, 11, 105, 128, 160, 122, 125)
    })))
    return
  end,
  ["BuildLightOptStatusReport"] = function()
    if Client and Client.GetTCDeviceLevel and (function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return Client.GetTCDeviceLevel() end
      return
    end) ~= nil then
    end
    if not ((function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return GameStatus.IsInFightingNotSocialNotMainCityNotHome() end
      return
    end) == true) then
    elseif not ((function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return IsLightPackage() end
      return
    end) == true) then
    elseif not ((function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return IsFlashOnlyQualityEnabled() end
      return
    end) == true) then
    end
    if false and U2.CloudLightLossyOptEnable ~= 1 then
    end
    if false and not (0 <= (function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return Client.GetTCDeviceLevel() end
      return
    end) and (function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return Client.GetTCDeviceLevel() end
      return
    end) < 7) then
    end
    if false and U2.CloudLightCommonOptEnable ~= 1 then
    end
    if U2.bLightOptForceEnableByGM then
    else
    end
    if (function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return IsLightOptSwitcherEnable(U1) end
      return
    end) == nil then
    elseif (function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return IsLightOptSwitcherEnable(U1) end
      return
    end) == true or (function(_ARG_0_)
      do
        if _ARG_0_ == nil then
          return nil
        end
        if pcall(_ARG_0_) then
          return pcall(_ARG_0_)
        end
        do return nil end
        do return end
        _ARG_0_ = _ARG_0_
      end
    end)(function()
      do return IsLightOptSwitcherEnable(U1) end
      return
    end) == 1 then
    end
    if true then
    else
    end
    do return table.concat({}, (U1(141))) end
    return
  end,
  ["OpenDevLog"] = function()
    bOpenDevLog = true
    return
  end,
  ["ReadSlateThrottleRemoteSwitch"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_.bNeedLightPackage and not IsLightPackage() then
        _ENV[_ARG_0_.switchField] = false
        _ENV[_ARG_0_.enableField] = false
        return false
      end
      if _ARG_0_.bExcludeLightPackage and IsLightPackage() then
        _ENV[_ARG_0_.switchField] = false
        _ENV[_ARG_0_.enableField] = false
        return false
      end
      if _ARG_0_.bExcludeIpad and U1.HDmpveRemote.HDmpveRemoteConfigGetInt(_ARG_0_.remoteKey, _ARG_0_.defaultValue) > 0 and not _ARG_1_ then
        _ENV[_ARG_0_.switchField] = true
        _ENV[_ARG_0_.useWhiteListField] = U1.HDmpveRemote.HDmpveRemoteConfigGetInt(_ARG_0_.remoteKey, _ARG_0_.defaultValue) == 1
        return true
      end
      _ENV[_ARG_0_.switchField] = false
      _ENV[_ARG_0_.enableField] = false
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["EvalSlateThrottleEnabled"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_ then
        return false
      end
      if _ARG_3_ and _ARG_4_ < _ARG_3_ then
        return false
      end
      if _ARG_1_ then
        if not _ARG_2_ or not _ARG_2_[U2.CurrentWorldName] then
          return false
        end
        if require((U1(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U2.TModList, U2.CurrentModID) then
          return false
        end
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLightThrottleFrequency"] = function()
    do return 30 end
    return
  end,
  ["OnPreBackEndSwitcherSet"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_1_ and _ARG_1_ & 16777216 ~= 0 then
        U2.bTickAsyncLoadingBackEndEnable = true
      end
      if _ARG_1_ and _ARG_1_ & 8388608 ~= 0 then
        U2.bLevelStreamingBackEndEnable = true
      end
      if _ARG_4_ and _ARG_4_ & 2 ~= 0 then
        U2.bUseLowFakeLandScapeBackEndEnable = true
      end
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(194, 12, 124, 129, 164, 122, 92, 99, 29, 255, 26, 69, 129, 111, 25, 173, 27, 27, 3, 165, 89, 67, 22, 91, 13, 239, 6, 125, 147), false) == true then
        U2.bEnableSlateGICloud = true
      else
        U2.bEnableSlateGICloud = false
      end
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(194, 12, 124, 129, 164, 122, 70, 97, 10, 234, 19, 107, 137, 97, 15, 165, 24, 60, 61, 178, 86, 74, 19, 76), false) == true or IsEditor then
        U2.bEnableInvalidationPanelsCloud = true
      else
        U2.bEnableInvalidationPanelsCloud = false
      end
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(194, 12, 124, 129, 164, 122, 92, 99, 29, 255, 26, 84, 136, 114, 18, 170, 14, 26, 4, 167, 108, 74, 12, 75, 58, 242, 28, 123, 159, 121, 7, 181, 19, 59), false) == true or IsEditor then
        U2.bEnableSlateVerifyHitTestVisibilityCloud = true
      else
        U2.bEnableSlateVerifyHitTestVisibilityCloud = false
      end
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(194, 12, 124, 129, 164, 122, 93, 106, 17, 228, 9, 103, 187, 111, 23, 173, 3, 59, 1, 182, 104, 93, 26, 79, 13, 232, 28, 84, 145, 113, 12), false) == true or IsEditor then
        U2.bEnableRemoveVolatilePrepassFlagCloud = true
      else
        U2.bEnableRemoveVolatilePrepassFlagCloud = false
      end
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(194, 12, 124, 129, 164, 122, 73, 102, 4, 216, 19, 99, 153, 101, 61, 173, 4, 38, 61, 178, 76, 71, 55, 86, 24, 207, 10, 97, 137), false) == true or IsEditor then
        U2.bEnableFixSlateFastPathHitTestCloud = true
      else
        U2.bEnableFixSlateFastPathHitTestCloud = false
      end
      if HDmpveRemote.HDmpveRemoteConfigGetBool(U1(194, 12, 124, 129, 164, 122, 78, 108, 8, 228, 13, 81, 157, 97, 12, 162, 38, 39, 8, 166, 93, 27, 72, 15), false) == true then
        U2.bEnableActorSpawnQueueCloud = true
      else
        U2.bEnableActorSpawnQueueCloud = false
      end
      if _ARG_2_ and _ARG_2_ & 32 ~= 0 then
        U2.bEnableUIDynamicBatch = true
      end
      if _ARG_2_ and _ARG_2_ & 32768 ~= 0 then
        U2.bEnableSlateLayoutCacheBackendValue = true
        U2.bEnableSlateLayoutCache = true
      end
      if _ARG_3_ and _ARG_3_ & 2048 ~= 0 and import((U1(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance():IsIOSVersionAbove14() then
        U2.bEnableIOSPSOCache = true
      end
      if not U2.bSlateGIThrottleSetByGM then
        if U2.bSlateGIThrottleSwitchEnabled or U2.bLightSlateGIThrottleSwitchEnabled then
        else
        end
      else
      end
      U2.bEnableNotRenderedParallelUpdateBackEnd = 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 65, 96, 8, 217, 26, 108, 137, 101, 9, 169, 19, 2, 12, 161, 89, 67, 19, 90, 0, 206, 31, 118, 156, 100, 14), 0)
      U2.bEnableRefreshBonesTickAnimationOptBackEnd = 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 93, 106, 26, 249, 26, 113, 133, 66, 20, 162, 18, 33, 57, 186, 91, 68, 62, 81, 5, 246, 14, 102, 148, 127, 5, 147, 23, 54), 0)
      if _ARG_4_ and _ARG_4_ & 16 ~= 0 then
        U2.bNewObjectPoolGCOptimizationEnable = true
      end
      if _ARG_4_ and _ARG_4_ & 64 ~= 0 then
        U2.bNewObjectPoolDefferedPhysicsState = true
      end
      if _ARG_4_ and _ARG_4_ & 512 ~= 0 then
        U2.bEnable400AnimationOptimization = true
      end
      if U2.DefaultSleepTimeThodOnIni > 1.0E-6 and 1.0E-6 < U2.DefaultSleepSlackTimeOnIni then
        if Client.GetDevicePlatformName() == require((table.concat({
          U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
          U1(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
        }))).IOS then
          if 0 > Client.HDmpveRemoteConfigGetInt(U1(192, 49, 113, 134, 173, 111, 91, 102, 17, 238, 43, 106, 130, 100, 36, 133, 56, 1), -1) then
          else
          end
          if 0 > Client.HDmpveRemoteConfigGetInt(U1(192, 49, 113, 134, 173, 111, 92, 99, 29, 232, 20, 86, 132, 109, 30, 152, 31, 61, 9, 140, 113, 96, 44), -1) then
          else
          end
        elseif Client.GetDevicePlatformName() == require((table.concat({
          U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
          U1(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
        }))).Android then
          if 0 > Client.HDmpveRemoteConfigGetInt(U1(192, 49, 113, 134, 173, 111, 91, 102, 17, 238, 43, 106, 130, 100, 36, 141, 56, 1), -1) then
          else
          end
          if 0 > Client.HDmpveRemoteConfigGetInt(U1(192, 49, 113, 134, 173, 111, 92, 99, 29, 232, 20, 86, 132, 109, 30, 152, 31, 61, 9, 140, 121, 96, 44), -1) then
          else
          end
        end
      end
      U2.EnableGCSweepTimeModifiy_GCloud = Client.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 72, 76, 47, 252, 26, 103, 157, 84, 18, 161, 18, 31, 2, 183, 81, 73, 22, 70), 0)
      if not Client.IsEditor() then
        if 3 <= Client.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 92, 102, 17, 254, 19, 99, 153, 101, 54, 163, 1, 55, 34, 163, 76), 0) then
        else
        end
      else
      end
      if _ARG_3_ and _ARG_3_ & 1048576 ~= 0 then
      end
      if _ARG_3_ and _ARG_3_ & 32768 ~= 0 then
      end
      if _ARG_3_ and _ARG_3_ & 65536 ~= 0 then
      end
      if _ARG_3_ and _ARG_3_ & 33554432 ~= 0 then
      end
      U2.ManagedTickSysFlagBackEnd = 2
      if not Client.IsEditor() then
        U2.ManagedTickSysFlagBackEnd = HDmpveRemote.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 66, 110, 18, 234, 24, 103, 137, 84, 18, 175, 28, 1, 20, 160), 0)
      end
      if 2 <= U2.ManagedTickSysFlagBackEnd then
      end
      if 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(194, 12, 124, 129, 164, 122, 67, 96, 29, 239, 48, 96, 135, 101, 24, 184, 56, 34, 25), 0) then
      else
      end
      if U2.IsFlashFavorVerySmooth50Device() then
        import((U1(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance().Userdetailsetting.PUBGDeviceFPSVerySmooth = 60
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_3_ = _ENV[142]
    end
  end,
  ["HandleOnLoadingPreBegin"] = function()
    if not Client then
      return
    end
    if U2.CollectorTimerID and U2.CollectorTimerID > 0 then
      U2.CollectorTimerID = 0
    end
    U2.bCallLoadingUIOpend = true
    return
  end,
  ["HandleOnLoadingEnd"] = function()
    if not Client or not U1.bCallLoadingUIOpend then
      return
    end
    U1.bCallLoadingUIOpend = false
    U1.CollectorTimerID = require((U2(228, 13, 112, 142, 167, 113, 33, 123, 21, 230, 26, 93, 153, 105, 24, 167, 18, 32))).AddTimerOnce(10, function()
      CollectorTimerID = 0
      if U1.GameStatus.IsInFightingStatus() and not U1.GameStatus.IsIn2DLobby() then
        U2:ExecuteCMD(U3(205, 3, 115, 136, 230, 90, 97, 110, 30, 231, 26, 65, 130, 108, 23, 169, 20, 38, 4, 188, 86, 105, 13, 80, 1, 220, 14, 127, 152, 64, 7, 189, 30), 1)
        U2:ExecuteCMD(U3(244, 76, 88, 141, 169, 125, 99, 106, 48, 228, 30, 102, 162, 98, 17, 169, 20, 38, 34, 163, 76, 105, 13, 80, 1, 220, 14, 127, 152, 64, 7, 189, 30), 1)
        U1.Client.ClearJankStats()
        U1.Client.SyncLoadInfoCollector_OnLevelStart()
      end
      return
    end)
    return
  end,
  ["HandleOnPreBattleResult"] = function()
    if not Client then
      return
    end
    if U1.CollectorTimerID and U1.CollectorTimerID > 0 then
      U1.CollectorTimerID = 0
    end
    if U1.bLevelEnd then
      return
    end
    U1.bLevelEnd = true
    if not GameStatus.IsInFightingStatus() or GameStatus.IsIn2DLobby() then
      return
    end
    return
  end,
  ["OnBeforeConfirmBackToLobby"] = function()
    if not Client then
      return
    end
    if U2.CollectorTimerID and U2.CollectorTimerID > 0 then
      U2.CollectorTimerID = 0
    end
    U2.bLevelEnd = true
    return
  end,
  ["HandleOnBattleResultStartPase"] = function()
    if not Client then
      return
    end
    return
  end,
  ["HandleOnBattleResultEndPase"] = function()
    if not Client then
      return
    end
    return
  end,
  ["PostBackEndSwitcherSet"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      U2.SavedUseLowFakeLandScape = U1.import((_ENV(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((_ENV(245, 76, 91, 130, 163, 122, 67, 110, 18, 239, 12, 97, 140, 112, 30, 226, 50, 60, 12, 177, 84, 74, 51, 80, 27)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyTextureGroupBiasFallback"] = function()
    if (import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(245, 76, 73, 134, 176, 107, 122, 125, 25, 216, 11, 112, 136, 97, 22, 165, 25, 53))) or 0) == 0 and (import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(245, 76, 88, 141, 169, 125, 99, 106, 62, 226, 30, 113, 186, 104, 30, 162, 35, 55, 21, 128, 76, 93, 26, 94, 1, 242, 1, 117, 178, 118, 13))) or 0) == 1 then
      if U2.bTextureGroupBiasApplied then
        return
      end
      U2.bTextureGroupBiasApplied = true
    end
    return
  end,
  ["ResetTextureGroupBiasFallback"] = function()
    if not bTextureGroupBiasApplied then
      return
    end
    U1.Client.ResetAllTextureGroupBiasFromQuality()
    bTextureGroupBiasApplied = false
    U1.log_shipping_client((U1.table.concat({
      U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 63, 182, 75, 74, 11, 107, 9, 227, 27, 103, 143, 117, 44, 174, 8, 55, 13, 129, 65, 94, 28, 105),
      U2(230, 14, 113, 129, 169, 124, 100, 53, 92, 233, 22, 99, 158, 32, 9, 169, 4, 55, 25)
    })))
    return
  end,
  ["OnModePreSwitch"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      if GameStatus.IsPreSwitchEnterFightingFromLobbyOrMainCity(_ARG_0_, _ARG_1_) then
        U1.ToggleNotRenderedParallelUpdate(U1.bEnableNotRenderedParallelUpdateBackEnd)
        U1.ToggleRefreshBonesTickAnimationOpt(U1.bEnableRefreshBonesTickAnimationOptBackEnd)
      end
      if _ARG_0_ == _ARG_1_ then
        log(bWriteLog and table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 34, 189, 117, 64, 27, 90, 60, 233, 10, 65, 138, 121, 31, 191, 15, 98, 15, 166, 92, 74, 29, 65),
          U2(167, 18, 111, 134, 155, 107, 110, 123, 25, 171, 66, 63, 205, 110, 30, 180, 3, 1, 25, 178, 76, 74, 94, 30)
        }))
        return
      end
      log(bWriteLog and table.concat({
        U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 34, 189, 117, 64, 27, 90, 60, 233, 10, 65, 138, 121, 31, 191, 15, 98, 19, 166, 80, 75, 60, 91),
        U2(230, 22, 120, 222)
      }) .. tostring(_ARG_1_))
      if U1.bLevelStreamingBackEndEnable then
        if _ARG_1_ == GameStatus.Lobby and U1.bEnterBorderland then
          U1.bEnterBorderland = false
          U1.EnableLevelStreamingOpt()
        elseif _ARG_1_ == GameStatus.Lobby and U1.bEnterTMod then
          U1.bEnterTMod = false
          U1.EnableLevelStreamingOpt()
        elseif _ARG_1_ == GameStatus.Lobby and U1.bEnterSingleMode then
          U1.bEnterSingleMode = false
          U1.EnableLevelStreamingOpt()
        end
      end
      if U1.bTickAsyncLoadingBackEndEnable then
        if _ARG_1_ == GameStatus.Lobby and U1.bTickAsyncLoadingSetInFighting then
          U1.DisableTickAsyncLoadingOpt()
          U1.bTickAsyncLoadingSetInFighting = false
        end
        if _ARG_1_ == GameStatus.Fighting and not U1.bTickAsyncLoadingSetInFighting then
          U1.EnableTickAsyncLoadingOpt()
          U1.bTickAsyncLoadingSetInFighting = true
        end
      end
      if _ARG_1_ ~= GameStatus.Fighting then
        U1.ToggleProfileInNeon(false, (U2(235, 13, 127, 129, 177)))
      end
      if U1.bEnableUIDynamicBatch then
        if _ARG_1_ == GameStatus.Lobby then
        end
        if _ARG_1_ == GameStatus.Fighting then
          if 1 >= import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance():GetExactDeviceLevel() then
          end
        end
      end
      if not U1.DefaultHitTestOptimization then
        U1.DefaultHitTestOptimization = import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U2(244, 76, 90, 166, 166, 126, 109, 99, 25, 195, 22, 118, 185, 101, 8, 184, 56, 34, 25, 186, 85, 70, 5, 94, 24, 242, 0, 124))) or 0
      end
      if _ARG_1_ == GameStatus.Fighting then
      else
      end
      if U1.bEnableIOSPSOCache and import((U2(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U2(245, 76, 84, 172, 155, 79, 92, 64, 46, 254, 17, 118, 132, 109, 30, 143, 22, 49, 5, 182))) ~= 0 then
        if _ARG_1_ == GameStatus.Lobby then
        end
        if _ARG_1_ == GameStatus.Fighting then
        end
      end
      if _ARG_1_ == GameStatus.Lobby then
        if import((U2(194, 12, 120, 145, 175, 102, 92, 110, 10, 226, 17, 101, 160, 97, 21, 173, 16, 55, 31, 159, 77, 78, 61, 77, 5, 255, 8, 119))) then
        end
        if Client.HDmpveRemoteConfigGetInt(U2(212, 9, 116, 147, 159, 126, 102, 123, 46, 195, 54, 86, 133, 114, 30, 173, 19, 20, 2, 161, 126, 67, 10, 76, 4, 201, 10, 97, 180, 126, 44, 189, 10, 39), 0) == 1 then
        end
        if 0 <= Client.HDmpveRemoteConfigGetInt(U2(198, 17, 100, 141, 171, 92, 96, 98, 12, 226, 19, 103, 190, 107, 18, 162, 58, 61, 9, 182, 113, 65, 56, 94, 1, 254), -1) then
        end
      else
        if require((table.concat({
          U2(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 55, 55, 31, 175, 65, 76, 7, 125),
          U2(226, 5, 116, 140, 166, 82, 110, 108, 14, 228, 12)
        }))).IsFITVersion() and 1 >= import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance():GetExactDeviceLevel() then
        else
        end
        if Client.HDmpveRemoteConfigGetInt(U2(212, 9, 116, 147, 159, 126, 102, 123, 46, 195, 54, 86, 133, 114, 30, 173, 19, 20, 2, 161, 126, 67, 10, 76, 4, 201, 10, 97, 180, 126, 44, 189, 10, 39), 0) == 1 then
        end
        if 0 <= Client.HDmpveRemoteConfigGetInt(U2(198, 17, 100, 141, 171, 92, 96, 98, 12, 226, 19, 103, 190, 107, 18, 162, 58, 61, 9, 182, 113, 65, 56, 94, 1, 254), -1) then
        end
      end
      if _ARG_1_ == GameStatus.Fighting and not (Client.GetAndroidSOVersion() == 32 and 3 > Client.GetMemorySize()) then
        if 0 >= import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance():GetExactDeviceLevel() then
        end
      end
      if 0 < U1.ManagedTickSysFlagBackEnd and _ARG_1_ == GameStatus.Fighting then
      else
      end
      if _ARG_1_ == GameStatus.Fighting and not U1.bLightOptAppliedInFighting then
      else
      end
      if Client.HDmpveRemoteConfigGetBool(U2(194, 12, 124, 129, 164, 122, 60, 75, 47, 227, 30, 112, 136, 85, 50), false) then
        if _ARG_1_ == GameStatus.Fighting then
        else
        end
      end
      if _ARG_1_ == GameStatus.Lobby then
      end
      if _ARG_1_ == GameStatus.Fighting then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[7]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSetInGameModeID"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      log(bWriteLog and table.concat({
        U1(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 34, 189, 107, 74, 11, 118, 2, 220, 14, 127, 152, 93, 4, 184, 2, 11, 57, 227, 101, 80, 11, 102),
        U1(195, 95)
      }) .. tostring(_ARG_0_))
      U2.CurrentModID = _ARG_0_
      if U2.bLevelStreamingBackEndEnable then
        if not U2.bEnterBorderland and require((U1(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U2.BorderlandModList, _ARG_0_) then
          U2.bEnterBorderland = true
        elseif not U2.bEnterTMod and require((U1(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U2.TModList, _ARG_0_) then
          U2.bEnterTMod = true
        elseif not U2.bEnterSingleMode and require((U1(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U2.SingModlList, _ARG_0_) then
          U2.bEnterSingleMode = true
        end
      end
      if _ARG_0_ and tonumber(_ARG_0_) and CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)) and CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType then
        if require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1] and (U2.SlateGIAvailableMod[require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1]] == true or U2.SlateGIAvailableMod[require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1]] == nil) and not U2.IsCreativeMode() then
        else
        end
        if require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1] and (U2.NewObjectPoolAvailableMod[require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1]] == true or U2.NewObjectPoolAvailableMod[require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1]] == nil) and HDmpveRemote.HDmpveRemoteConfigGetInt(U1(193, 13, 111, 128, 173, 91, 102, 124, 29, 233, 19, 103, 162, 98, 17, 169, 20, 38, 61, 188, 87, 67), 0) == 1 then
        end
        if false then
        else
        end
        if require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1] and U2.InvalidationPanelsAvailableMod[require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1]] == false then
        else
        end
        if require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1] and U2.ActorSpawnQueueAvailableMod[require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188))) and require((U1(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(CDataTable.GetTableData(U1(197, 54, 80, 140, 172, 122), tonumber(_ARG_0_)).ModType, (U1(188)))[1]] == true then
        else
        end
      end
      if not U2.NewObjectPoolGCConfigValue then
        U2.NewObjectPoolGCConfigValue = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(224, 76, 88, 141, 169, 125, 99, 106, 40, 238, 18, 114, 130, 114, 26, 160, 51, 59, 30, 161, 93, 72, 30, 77, 8, 221, 0, 96, 186, 83))) == 1 and import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(224, 76, 83, 134, 191, 80, 109, 101, 25, 232, 11, 82, 130, 111, 23, 226, 51, 59, 30, 161, 93, 72, 30, 77, 8, 221, 0, 96, 186, 83))) == 1
      end
      if U2.bNewObjectPoolGCOptimizationEnable and U2.NewObjectPoolGCConfigValue then
      else
      end
      if U2.bNewObjectPoolDefferedPhysicsState or Client.IsEditor() then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPreLoadMap"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      U2.LastWorldName = U2.CurrentWorldName
      U2.CurrentWorldName = Client.GetCleanFileName(_ARG_0_)
      if U2.bUseLowFakeLandScapeBackEndEnable then
        if string.find(_ARG_0_, U1(197, 3, 113, 151, 161, 124, 80, 66, 29, 226, 17), 1) then
        else
        end
      end
      if U2.BackUpbUseNewHole == -1 then
        U2.BackUpbUseNewHole = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(245, 76, 72, 144, 173, 81, 106, 120, 48, 234, 17, 102, 158, 99, 26, 188, 18, 26, 2, 191, 93)))
        U2.BakcUpNumVisibleComponents = import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(245, 76, 75, 138, 187, 118, 110, 109, 16, 238, 60, 109, 128, 112, 20, 162, 18, 60, 25, 157, 77, 66, 48, 81, 32, 250, 1, 118, 152, 116)))
      end
      if import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))) ~= nil then
        if (string.find(_ARG_0_, U1(197, 3, 113, 151, 161, 124, 80, 66, 29, 226, 17), 1) or string.find(_ARG_0_, U1(193, 13, 104, 145, 133, 126, 127, 124, 35, 198, 30, 107, 131), 1)) and import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))).IsClientBackEndSwitcherBEnable(23) and Client.EnableSubMountPoint() then
        else
        end
        if (string.find(_ARG_0_, U1(197, 3, 113, 151, 161, 124, 80, 66, 29, 226, 17), 1) or string.find(_ARG_0_, U1(193, 13, 104, 145, 133, 126, 127, 124, 35, 198, 30, 107, 131), 1)) and import((U1(212, 15, 124, 145, 188, 93, 106, 110, 14, 238, 13, 79, 140, 110, 26, 171, 18, 32, 33, 166, 89, 109, 13, 86, 8, 252, 10))).IsClientBackEndSwitcherBEnable(24) then
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnModePostSwitch"] = function(_ARG_0_, _ARG_1_)
    do
      if not Client then
        return
      end
      U1.RefreshNotRenderedParallelUpdate()
      U1.RefreshBonesTickAnimationOpt()
      if _ARG_0_ == _ARG_1_ then
        log(bWriteLog and table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 34, 189, 117, 64, 27, 90, 60, 244, 28, 102, 174, 103, 2, 168, 4, 42, 93, 177, 77, 75, 26, 93),
          U2(233, 66, 109, 145, 173, 76, 123, 110, 8, 238, 95, 63, 208, 32, 21, 169, 15, 38, 62, 167, 89, 91, 26, 30, 77)
        }))
        return
      end
      U1.bLevelEnd = false
      if not GameStatus.InSupportDownloadState() then
      else
      end
      if not U3.IsBlueholeOperationRegion() then
        if _ARG_1_ == GameStatus.Fighting then
          if CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).sub_mode) and CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_enter_game).sub_mode).ModeFightType then
          end
          if CDataTable.GetSplitTableData(U2(203, 13, 127, 129, 177), U2(202, 13, 121, 134, 155, 122, 99, 106, 31, 255, 22, 109, 131), U2(241, 11, 120, 148, 151, 124, 96, 97, 8, 234, 22, 108, 178, 116, 26, 174, 27, 55), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()) and CDataTable.GetSplitTableData(U2(203, 13, 127, 129, 177), U2(202, 13, 121, 134, 155, 122, 99, 106, 31, 255, 22, 109, 131), U2(241, 11, 120, 148, 151, 124, 96, 97, 8, 234, 22, 108, 178, 116, 26, 174, 27, 55), ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.logic_mode_selection):GetCurSelectInfo()).is_rank then
          end
        else
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleProfileInNeon"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 60, 233, 0, 116, 148, 124, 14, 149, 9, 12, 24, 172, 70, 31, 12, 90),
        U1(245, 16, 112, 130, 184)
      }) .. _ARG_1_ .. U1(194, 12, 124, 129, 164, 122, 48, 53) .. tostring(_ARG_0_))
      if _ARG_0_ then
        if string.find(_ARG_1_, (U1(215, 55, 95, 164, 151, 81, 106, 96, 18, 212, 50, 99, 132, 110))) then
          if Client.GetTCDeviceLevel() < 7 and U2.TextureMipOffsetbackUp == -1 then
            if import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(245, 76, 80, 138, 184, 83, 64, 75, 62, 226, 30, 113, 171, 114, 20, 161, 38, 39, 12, 191, 81, 91, 6))) < 1 then
              U2.TextureMipOffsetbackUp = 0
            end
          end
        end
      elseif Client.GetTCDeviceLevel() < 7 and U2.TextureMipOffsetbackUp == 0 then
        U2.TextureMipOffsetbackUp = -1
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSlateGIState"] = function()
    if import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(244, 14, 124, 151, 173, 49, 74, 97, 29, 233, 19, 103, 170, 73))) == 1 then
      return true
    else
      return false
    end
    return
  end,
  ["GetIBState"] = function()
    if import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(212, 14, 124, 151, 173, 49, 74, 97, 29, 233, 19, 103, 164, 110, 13, 173, 27, 59, 9, 178, 76, 70, 16, 81, 60, 250, 1, 119, 145, 99))) == 1 then
      return true
    else
      return false
    end
    return
  end,
  ["ToggleInvalidationPanels"] = function(_ARG_0_)
    do
      if not bEnableInvalidationPanelsCloud and not U1.IsEditor then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 37, 245, 25, 115, 145, 121, 15, 189, 19, 43, 18, 173, 120, 94, 1, 74),
          U2(235, 17, 61, 160, 164, 112, 122, 107, 92, 216, 8, 107, 153, 99, 19, 236, 56, 52, 11)
        })))
        _ARG_0_ = false
      end
      if U1.Client.IsWindowOB() then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 37, 245, 25, 115, 145, 121, 15, 189, 19, 43, 18, 173, 120, 94, 1, 74),
          U2(235, 17, 61, 180, 161, 113, 107, 96, 11, 171, 22, 113, 205, 79, 57, 224, 87, 54, 4, 160, 89, 77, 19, 90, 76, 210, 1, 100, 156, 124, 2, 184, 6, 54, 20, 172, 70, 111, 14, 65),
          U2(226, 14, 110)
        })))
        _ARG_0_ = false
      end
      if _ARG_0_ then
      else
      end
      return
    end
  end,
  ["ToggleSlateVerifyHitTestVisibility"] = function(_ARG_0_)
    do
      if not bEnableSlateVerifyHitTestVisibilityCloud and not U1.IsEditor then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 63, 247, 14, 102, 152, 70, 14, 174, 14, 36, 4, 139, 65, 75, 59, 74),
          U2(244, 22, 75, 138, 187, 118, 109, 102, 16, 226, 11, 123, 205, 67, 23, 163, 2, 54, 77, 128, 79, 70, 11, 92, 4, 187, 32, 116, 155)
        })))
        _ARG_0_ = false
      else
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 63, 247, 14, 102, 152, 70, 14, 174, 14, 36, 4, 139, 65, 75, 59, 74),
          U2(244, 22, 75, 138, 187, 118, 109, 102, 16, 226, 11, 123, 205, 67, 23, 163, 2, 54, 77, 128, 79, 70, 11, 92, 4, 187, 32, 124)
        })))
      end
      if not U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance() or not U1.slua.isValid((U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance())) then
        return
      end
      if _ARG_0_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleFixSlateFastPathHitTest"] = function(_ARG_0_)
    do
      if not bEnableFixSlateFastPathHitTestCloud and not U1.IsEditor then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 42, 242, 23, 65, 145, 113, 31, 185, 33, 35, 14, 183, 120, 94, 27, 71),
          U2(207, 11, 105, 183, 173, 108, 123, 47, 63, 231, 16, 119, 137, 32, 40, 187, 30, 38, 14, 187, 24, 96, 25, 89)
        })))
        _ARG_0_ = false
      else
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 42, 242, 23, 65, 145, 113, 31, 185, 33, 35, 14, 183, 120, 94, 27, 71),
          U2(207, 11, 105, 183, 173, 108, 123, 47, 63, 231, 16, 119, 137, 32, 40, 187, 30, 38, 14, 187, 24, 96, 17)
        })))
      end
      if not U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance() or not U1.slua.isValid((U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance())) then
        return
      end
      if _ARG_0_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleRemoveVolatilePrepassFlag"] = function(_ARG_0_)
    do
      if not bEnableRemoveVolatilePrepassFlagCloud and not U1.IsEditor then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 62, 254, 2, 125, 139, 117, 61, 179, 11, 35, 9, 170, 68, 90, 63, 93),
          U2(226, 18, 124, 144, 187, 89, 99, 110, 27, 171, 60, 110, 130, 117, 31, 236, 36, 37, 4, 167, 91, 71, 95, 112, 10, 253)
        })))
        _ARG_0_ = false
      else
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 62, 254, 2, 125, 139, 117, 61, 179, 11, 35, 9, 170, 68, 90, 63, 93),
          U2(226, 18, 124, 144, 187, 89, 99, 110, 27, 171, 60, 110, 130, 117, 31, 236, 36, 37, 4, 167, 91, 71, 95, 112, 2)
        })))
      end
      if not U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance() or not U1.slua.isValid((U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance())) then
        return
      end
      if _ARG_0_ then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleSlateGI"] = function(_ARG_0_, _ARG_1_)
    do
      bNeedDelayEnableSlateGI = false
      _ARG_1_ = _ARG_1_ or false
      if not bEnableSlateGICloud and not U1.IsEditor then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 63, 247, 14, 102, 152, 87, 34, 252, 36, 46, 18, 182, 76, 31, 60, 88),
          U2(238, 22, 126, 139, 232, 80, 105, 105)
        })))
        _ARG_0_ = false
      else
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 63, 247, 14, 102, 152, 87, 34, 252, 36, 46, 18, 182, 76, 31, 60, 88),
          U2(238, 22, 126, 139, 232, 80, 97)
        })))
      end
      if CurrentModID == 0 then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 63, 247, 14, 102, 152, 87, 34, 252, 36, 55, 15, 177, 77, 81, 27, 98),
          U2(232, 6, 84, 167, 232, 118, 124, 47, 76, 167, 95, 102, 132, 115, 26, 174, 27, 55, 77, 128, 84, 78, 11, 90, 43, 210)
        })))
        _ARG_0_ = false
      end
      if U1.Client.IsWindowOB() then
        U1.log_shipping_client((U1.table.concat({
          U2(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 57, 188, 95, 72, 19, 90, 63, 247, 14, 102, 152, 87, 34, 252, 48, 43, 19, 167, 71, 72, 79, 70),
          U2(244, 66, 82, 161, 228, 63, 107, 102, 15, 234, 29, 110, 136, 32, 40, 160, 22, 38, 8, 148, 113)
        })))
        _ARG_0_ = false
      end
      if not U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance() or not U1.slua.isValid((U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance())) then
        return
      end
      if U1.HDmpveRemote.HDmpveRemoteConfigGetInt(U2(212, 14, 124, 151, 173, 88, 70, 66, 29, 243, 62, 110, 129, 111, 12, 136, 18, 36, 4, 176, 93, 99, 26, 73, 9, 247), 99) < U1.import((U2(212, 54, 88, 155, 188, 109, 110, 72, 29, 230, 26, 75, 131, 115, 15, 173, 25, 49, 8))).GetInstance():GetDeviceLevel() then
        _ARG_0_ = false
      end
      if _ARG_0_ then
        if GetSlateGIState() == true then
          return
        end
        if _ARG_1_ then
          bNeedDelayEnableSlateGI = true
          return
        end
      elseif GetSlateGIState() == false then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActorSpawnQueueState"] = function()
    do return import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(233, 7, 105, 205, 137, 124, 123, 96, 14, 216, 15, 99, 154, 110, 42, 185, 18, 39, 8, 253, 125, 65, 30, 93, 0, 254))) == 1 end
    return
  end,
  ["ToggleActorSpawnQueue"] = function(_ARG_0_)
    do
      if not bEnableActorSpawnQueueCloud and not bEnableActorSpawnQueueLightOpt then
        _ARG_0_ = false
      end
      if _ARG_0_ then
        if U1.CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), U1.tonumber(CurrentModID)) and U1.CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), U1.tonumber(CurrentModID)).ModType and U1.require((U2(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(U1.CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), U1.tonumber(CurrentModID)).ModType, (U2(188))) and U1.require((U2(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(U1.CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), U1.tonumber(CurrentModID)).ModType, (U2(188)))[1] and ActorSpawnQueueAvailableMod[U1.require((U2(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(U1.CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), U1.tonumber(CurrentModID)).ModType, (U2(188))) and U1.require((U2(228, 13, 112, 142, 167, 113, 33, 124, 8, 249, 22, 108, 138, 95, 14, 184, 30, 62))).Split(U1.CDataTable.GetTableData(U2(197, 54, 80, 140, 172, 122), U1.tonumber(CurrentModID)).ModType, (U2(188)))[1]] == false then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleSlateLayoutCache"] = function(_ARG_0_)
    do
      U2.bEnableSlateLayoutCache = U2.bEnableSlateLayoutCacheBackendValue
      SwitcherModifiedCount = 0
      if not U2.bEnableSlateLayoutCache then
        return
      end
      if _ARG_0_ then
        if import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(244, 14, 124, 151, 173, 49, 74, 97, 29, 233, 19, 103, 161, 97, 2, 163, 2, 38, 46, 178, 91, 71, 22, 81, 11))) ~= 1 then
        end
      elseif import((U1(212, 54, 88, 155, 188, 109, 110, 77, 16, 254, 26, 114, 159, 105, 21, 184, 49, 39, 3, 176, 76, 70, 16, 81, 32, 242, 13, 96, 156, 98, 18))).GetConsoleVariableIntValue((U1(244, 14, 124, 151, 173, 49, 74, 97, 29, 233, 19, 103, 161, 97, 2, 163, 2, 38, 46, 178, 91, 71, 22, 81, 11))) == 1 then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDesiredSlateLayoutCacheState"] = function()
    if GameStatus.GetGameStatus() ~= GameStatus.Fighting then
      return 0
    end
    do return U1.bEnableSlateLayoutCache and 1 or 0 end
    return
  end,
  ["ReportDeviceOverHeatInfo"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnPostSetFPS"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      log(bWriteLog and U1(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 34, 189, 104, 64, 12, 75, 63, 254, 27, 84, 173, 67))
      if 7 <= _ARG_0_ and U2.SlateTickDownWhitList[U2.CurrentWorldName] and not require((U1(228, 13, 112, 142, 167, 113, 33, 123, 29, 233, 19, 103, 178, 117, 15, 165, 27))).IsInTable(U2.TModList, U2.CurrentModID) then
        if _ARG_0_ == 7 then
        elseif _ARG_0_ == 8 then
        end
      else
      end
      U2.bEnableSlateThrottle = U2.EvalSlateThrottleEnabled(U2.bSlateThrottleSwitchEnabled, U2.bUseSlateThrottleWhiteList, U2.SlateThrottleWhiteList, 8, _ARG_0_)
      if not U2.bSlateGIThrottleSetByGM then
        U2.bEnableSlateGIThrottle = U2.EvalSlateThrottleEnabled(U2.bSlateGIThrottleSwitchEnabled, U2.bUseSlateGIThrottleWhiteList, U2.SlateGIThrottleWhiteList, 5, _ARG_0_)
      end
      U2.bEnableLightSlateGIThrottle = U2.EvalSlateThrottleEnabled(U2.bLightSlateGIThrottleSwitchEnabled, U2.bUseLightSlateGIThrottleWhiteList, U2.SlateGIThrottleWhiteList, nil, _ARG_0_)
      U2.bEnableLightWidgetTickFrequency = U2.EvalSlateThrottleEnabled(U2.bLightWidgetTickFrequencySwitchEnabled, U2.bUseLightWidgetTickFrequencyWhiteList, U2.SlateGIThrottleWhiteList, nil, _ARG_0_)
      U2.bEnableWidgetTickFrequency = U2.EvalSlateThrottleEnabled(U2.bWidgetTickFrequencySwitchEnabled, U2.bUseWidgetTickFrequencyWhiteList, U2.SlateGIThrottleWhiteList, 5, _ARG_0_)
      if not U2.bSlateGIThrottleSetByGM then
        if U2.bEnableLightSlateGIThrottle then
        else
        end
      end
      if not U2.bSlateFrequencySetByGM then
        if U2.bEnableLightSlateGIThrottle then
        elseif U2.bEnableSlateThrottle or U2.bEnableSlateGIThrottle then
        else
        end
      end
      if U2.bEnableLightWidgetTickFrequency then
      elseif U2.bEnableWidgetTickFrequency then
      else
      end
      if 8 <= _ARG_0_ then
      else
      end
      if 7 <= _ARG_0_ then
        if _ARG_0_ == 7 then
        elseif _ARG_0_ == 8 then
        end
      end
      if 0 < HDmpveRemote.HDmpveRemoteConfigGetInt(U1(212, 7, 105, 176, 188, 109, 106, 110, 17, 226, 17, 101, 189, 111, 20, 160, 36, 59, 23, 182, 119, 65, 44, 90, 24, 239, 6, 124, 154), 0) then
      end
      if _ARG_0_ == 6 and Client.GetDevicePlatformName() == require((table.concat({
        U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
        U1(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
      }))).IOS then
      end
      if 8 <= _ARG_0_ then
      elseif 7 <= _ARG_0_ then
      else
      end
      if 1 <= HDmpveRemote.HDmpveRemoteConfigGetInt(U1(205, 3, 115, 136, 139, 112, 99, 99, 25, 232, 11, 107, 130, 110, 47, 165, 26, 55, 57, 187, 74, 74, 12, 87, 3, 247, 11), 0) then
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyGCIntervelFromMap"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      if Client.GetDevicePlatformName() ~= require((table.concat({
        U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
        U1(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
      }))).Android or U2.EnableGCSweepTimeModifiy_GCloud <= 0 or Client.GetAndroidSOVersion() == 32 then
        return
      end
      if _ARG_0_ == 0 then
        if Client.GetMemorySize() >= 5 and Client.GetTCDeviceLevel() >= 6 and U2.CloseGCWhitList[U2.CurrentWorldName] then
        end
      elseif _ARG_0_ == 1 and Client.GetMemorySize() >= 5 and Client.GetTCDeviceLevel() >= 7 then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsCreativeMode"] = function()
    if ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC) and (ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCGameMod() or ModuleManager.GetModule(ModuleManager.LobbyModuleConfig.LogicUGC):IsUGCEditMod()) then
      return true
    end
    do return false end
    return
  end,
  ["RevertGCIntervelFromMap"] = function(_ARG_0_)
    do
      if not Client then
        return
      end
      log(bWriteLog and table.concat({
        U1(220, 33, 113, 138, 173, 113, 123, 74, 42, 196, 60, 109, 131, 102, 18, 171, 42, 114, 63, 182, 78, 74, 13, 75, 43, 216, 38, 124, 137, 117, 25, 170, 2, 46, 59, 177, 71, 82, 34, 78),
        U1(247, 66, 112, 130, 184, 118, 107, 53)
      }) .. tostring(_ARG_0_))
      if Client.GetDevicePlatformName() ~= require((table.concat({
        U1(228, 14, 116, 134, 166, 107, 33, 124, 16, 254, 30, 44, 142, 111, 21, 170, 30, 53, 67, 144, 84, 70, 26, 81, 24, 214, 14, 113, 143, 127, 24, 242, 35, 39, 11, 170, 75, 90, 63, 67),
        U1(230, 22, 123, 140, 186, 114, 65, 110, 17, 238, 50, 99, 142, 114, 20, 191)
      }))).Android or U2.EnableGCSweepTimeModifiy_GCloud <= 0 or Client.GetAndroidSOVersion() == 32 then
        return
      end
      if _ARG_0_ == 0 then
        if Client.GetMemorySize() >= 5 and Client.GetTCDeviceLevel() >= 6 then
        end
      elseif _ARG_0_ == 1 and Client.GetMemorySize() >= 5 and Client.GetTCDeviceLevel() >= 7 then
      end
      do return end
      _ARG_0_ = U1[25]
      _ARG_0_ = _ENV[77]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
} end
return
