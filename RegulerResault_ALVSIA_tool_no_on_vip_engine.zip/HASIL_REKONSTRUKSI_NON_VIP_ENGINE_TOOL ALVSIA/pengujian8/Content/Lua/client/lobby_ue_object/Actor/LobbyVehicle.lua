do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(35, 77, 36, 118, 178)))(require((table.concat({
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(7, 64, 40, 96, 141, 62, 140, 120, 179, 70, 191, 199, 187, 95, 199, 238, 253, 126, 81, 27, 114, 20, 240, 11, 129, 87, 229, 186, 134, 92, 193, 181, 225, 98, 81, 74, 83, 41, 236, 5),
  (function(...)
    do return table.concat({
      [...] = string.char((({
        ...
      })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
    }) end
    return
  end)(37)
}))), nil, {
  ["ctor"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_0_.IsHallVehicle = false
      _ARG_0_.ChangeLightTimer = nil
      _ARG_0_.bIsProhibitOpenDoorAnim = false
      _ARG_0_.InitAnimTimer = nil
      _ARG_0_.CabrioletAnimTimer = nil
      _ARG_0_.VehicleFXMap = {}
      _ARG_0_.VehicleFXTimers = {}
      _ARG_0_.PreviewSwitchEffectData = nil
      _ARG_0_.ClientUsedAvatarID = nil
      _ARG_0_.curPlayingAccSoundId = nil
      _ARG_0_.PreviewSwitchAssetHandleId = nil
      _ARG_0_.VehicleMatData = {}
      _ARG_0_.VehicleMatTickTimer = nil
      _ARG_0_.MatTickTime = 0
      _ARG_0_.MatTickEndTime = 5
      _ARG_0_.bSetOnlyTickPoseWhenRendered = false
      _ARG_0_.EquipedMultiSlotParts = {}
      _ARG_0_.bPermanentParticleHidden = false
      _ARG_0_.bPermanentParticleDissolving = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveBeginPlay"] = function(_ARG_0_)
    do
      __super.ReceiveBeginPlay(_ARG_0_)
      U1.print(U1.bWriteLog and U2(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 108, 209, 232, 213, 120, 67, 80, 115, 30, 250, 15, 128, 105, 167, 152, 144))
      if U1.slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        _ARG_0_:AddControlEvent(_ARG_0_.VehicleAvatarComponent_BP, U2(22, 68, 45, 108, 162, 39, 136, 23, 136, 72, 175, 136, 139, 123, 197, 226, 197, 97, 80, 81), _ARG_0_.OnVehicleAvatarEquiped, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_.VehicleAvatarComponent_BP, U2(22, 68, 45, 108, 162, 39, 136, 5, 146, 70, 175, 172, 136, 75, 221, 251, 213, 117), _ARG_0_.OnVehicleSlotEquiped, _ARG_0_)
        _ARG_0_:AddControlEvent(_ARG_0_.VehicleAvatarComponent_BP, U2(15, 79, 19, 96, 169, 34, 142, 58, 155, 122, 172, 128, 141, 93, 220, 206, 214, 119, 80, 86, 69, 62, 243, 2), _ARG_0_.OnVehicleSwitchEffectEnd, _ARG_0_)
      end
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_LOBBY_SCENE, U1.EVENTID_SCENE_LOADED, _ARG_0_.OnSceneLoaded, _ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_PUFFER, U1.EVENTID_PUFFER_DOWNLOADFINISH, _ARG_0_.OnMultiSlotPartDownloadFinish, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReceiveEndPlay"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 108, 209, 232, 213, 120, 67, 80, 116, 21, 249, 54, 130, 88, 178))
      goto lbl_42
      ::lbl_42::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFXTimers = nil
      if _ARG_0_.PermanentParticleShowTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.PermanentParticleShowTimer)
        _ARG_0_.PermanentParticleShowTimer = nil
      end
      if _ARG_0_.PermanentParticleHideRetryTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.PermanentParticleHideRetryTimer)
        _ARG_0_.PermanentParticleHideRetryTimer = nil
      end
      _ARG_0_:CancelSwitchAssetLoadHandle()
      U2.__super.ReceiveEndPlay(_ARG_0_, _ARG_1_, _ARG_2_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleAvatarEquiped"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 113, 218, 221, 213, 121, 92, 86, 93, 30, 220, 16, 143, 77, 170, 139, 172, 95, 209, 242, 208, 100, 65))
      _ARG_0_:CleanAavatarShowEffects()
      EventSystem:postEvent(EVENTTYPE_STORE_BTNEVENT, EVENTID_STORE_CAR_MODEL_LOADED)
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        return
      end
      if _ARG_0_.bPermanentParticleDissolving then
        printf(table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 113, 218, 221, 213, 121, 92, 86, 93, 30, 220, 16, 143, 77, 170, 139, 172, 95, 209, 242, 208, 100, 65, 5, 83, 14, 236, 6),
          U1(48, 77, 60, 37, 165, 34, 158, 37, 145, 69, 173, 140, 217, 86, 221, 239, 213, 61, 21, 70, 90, 18, 243, 47, 138, 3, 238, 138)
        }), tostring(_ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID()))
        _ARG_0_:ApplyPermanentParticleHide()
      end
      if _ARG_0_.ChangeLightTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.ChangeLightTimer)
        _ARG_0_.ChangeLightTimer = nil
      end
      if require((table.concat({
        U1(35, 77, 44, 96, 175, 63, 195, 37, 146, 92, 186, 199, 149, 81, 211, 226, 211, 63, 81, 90, 70, 21, 241, 9, 143, 93, 229, 137, 156, 72, 194, 254, 210, 47, 85, 80, 71, 13, 232, 4),
        U1(31, 76, 36, 107, 160, 44, 136, 36)
      }))).GetState(require((U1(35, 77, 44, 96, 175, 63, 195, 37, 146, 92, 186, 199, 149, 81, 211, 226, 211, 63, 81, 90, 70, 21, 241, 9, 143, 93, 229, 137, 156, 72, 194, 254, 210, 94, 70, 74, 79, 24, 249))).ENUM_DownloadType.ODPAK, {
        (_ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID())
      }) ~= require((U1(35, 77, 44, 96, 175, 63, 195, 37, 146, 92, 186, 199, 149, 81, 211, 226, 211, 63, 81, 90, 70, 21, 241, 9, 143, 93, 229, 137, 156, 72, 194, 254, 210, 94, 70, 74, 79, 24, 249))).ENUM_DownloadState.Done then
        return
      end
      _ARG_0_.ClientUsedAvatarID = _ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID()
      if _ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID() == 1908077 and slua.isValid(_ARG_0_.Mesh) and not _ARG_0_.VehicleAvatarComponent_BP.bIsLobbyAvatar then
        goto lbl_553
        ::lbl_553::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if CDataTable.GetTableData(U1(2, 68, 49, 113, 164, 57, 187, 51, 150, 64, 184, 133, 156, 123, 210, 237, 213, 114, 65), (_ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID())) and CDataTable.GetTableData(U1(2, 68, 49, 113, 164, 57, 187, 51, 150, 64, 184, 133, 156, 123, 210, 237, 213, 114, 65), (_ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID())).MiniTVVehiclePhoto == 1 then
        _ARG_0_.ChangeLightTimer = _ARG_0_:AddTimer(0.1, function()
          _ENV:TurnOnLights()
          U1.coroutine.yield(2)
          _ENV:TurnOnLights()
          return
        end)
      end
      if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[195]
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleSlotEquiped"] = function(_ARG_0_)
    do
      log(bWriteLog and string.format(table.concat({
        U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 113, 218, 221, 213, 121, 92, 86, 93, 30, 206, 10, 129, 77, 142, 136, 156, 71, 212, 254, 196, 33, 87, 64, 64, 27, 253, 26),
        U1(57, 1, 0, 107, 160, 41, 129, 51, 182, 64, 188, 129, 173, 87, 198, 238, 252, 120, 82, 93, 69, 87, 189, 5, 143, 90, 163, 156, 211, 11, 215)
      }), tostring(_ARG_0_.VehicleAvatarComponent_BP and _ARG_0_.VehicleAvatarComponent_BP._enableHighTireCache)))
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        return
      end
      if _ARG_0_.VehicleAvatarComponent_BP._enableHighTireCache ~= nil then
        _ARG_0_.VehicleAvatarComponent_BP:EnableHighTireLight(_ARG_0_.VehicleAvatarComponent_BP._enableHighTireCache)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleSwitchEffectEnd"] = function(_ARG_0_)
    do
      if slua.isValid(_ARG_0_.BP_VehicleDIYComp) then
        _ARG_0_.BP_VehicleDIYComp:OnVehicleSwitchEffectEnd()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TurnOnLights"] = function(_ARG_0_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnSceneLoaded"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        return
      end
      if _ARG_3_ == nil or _ARG_3_ == U1() then
        return
      end
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 113, 218, 216, 211, 116, 91, 80, 125, 20, 252, 2, 139, 93) .. _ARG_3_)
      if string.find(_ARG_3_, (U1(44, 72, 34, 109, 181))) or string.find(_ARG_3_, (U1(12, 72, 34, 109, 181))) then
        return
      end
      _ARG_0_:AddTimer(0.3, function()
        if not IsHallVehicle then
          return
        end
        VehicleAvatarComponent_BP:DestroyWelcomeLight()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["Sleep"] = function(_ARG_0_)
    do
      _ARG_0_:StopMontage()
      _ARG_0_:ClearLightEffect()
      _ARG_0_:CleanAavatarShowEffects()
      if slua.isValid(_ARG_0_.Mesh) then
        _ARG_0_.Mesh:SetCastPhotonShadow(false)
        _ARG_0_.Mesh:SetAnimInstanceClass(nil)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopMontage"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Mesh) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 216, 238, 213, 97, 21, 70, 84, 23, 251, 72, 163, 92, 184, 145, 201, 71, 215, 187, 206, 110, 81, 5, 119, 10, 225, 31),
          U1(36)
        }))
        return
      end
      if not slua.isValid((_ARG_0_.Mesh:GetAnimInstance())) then
        return
      end
      if not slua.isValid((_ARG_0_.Mesh:GetAnimInstance():GetCurrentActiveMontage())) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearLightEffect"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 125, 216, 238, 209, 99, 121, 92, 86, 19, 233, 35, 136, 95, 174, 154, 157, 14, 242, 254, 200, 104, 70, 73, 68, 42, 251, 23),
          U1(52, 64, 55, 70, 174, 38, 157, 57, 144, 76, 181, 157, 166, 124, 228, 171, 217, 98, 21, 91, 94, 15, 189, 48, 143, 85, 162, 157)
        }))
        return
      end
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP.LightEffect) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 125, 216, 238, 209, 99, 121, 92, 86, 19, 233, 35, 136, 95, 174, 154, 157, 14, 242, 254, 200, 104, 70, 73, 68, 42, 251, 23),
          U1(52, 64, 55, 70, 174, 38, 157, 57, 144, 76, 181, 157, 166, 124, 228, 165, 252, 120, 82, 93, 69, 62, 251, 0, 139, 90, 191, 217, 128, 93, 132, 245, 207, 117, 5, 115, 64, 7, 228, 18)
        }))
        return
      end
      _ARG_0_.VehicleAvatarComponent_BP.LightEffect:K2_DestroyComponent(_ARG_0_.VehicleAvatarComponent_BP.LightEffect)
      _ARG_0_.VehicleAvatarComponent_BP.LightEffect = nil
      _ARG_0_.VehicleAvatarComponent_BP.CurLightEffect = nil
      _ARG_0_.VehicleAvatarComponent_BP.HasLightEffect = false
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CleanAavatarShowEffects"] = function(_ARG_0_)
    do
      if _ARG_0_.GetComponentsByTag then
        goto lbl_74
        ::lbl_74::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayAccelerateEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 80, 86, 86, 84, 23, 248, 20, 143, 77, 174, 188, 143, 72, 193, 248, 212, 33))
      if not _ARG_0_:CheckCanAccelerate() then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 20, 187, 51, 150, 64, 184, 133, 156, 4, 228, 231, 209, 104, 116, 86, 82, 30, 241, 3, 156, 88, 191, 156, 172, 72, 194, 254, 195, 117, 5, 108, 82, 75, 196, 24),
          U1(96, 98, 1)
        }))
        return
      end
      if _ARG_0_.ClientUsedAvatarID and require((table.concat({
        U1(35, 77, 44, 96, 175, 63, 195, 58, 145, 78, 178, 138, 215, 72, 209, 227, 217, 114, 89, 80, 31, 45, 248, 14, 135, 90, 167, 156, 168, 77, 199, 254, 204, 100, 87, 68, 85, 14, 206, 25),
        U1(46, 71, 44, 98)
      })))[_ARG_0_.ClientUsedAvatarID] then
        if require((table.concat({
          U1(35, 77, 44, 96, 175, 63, 195, 58, 145, 78, 178, 138, 215, 72, 209, 227, 217, 114, 89, 80, 31, 45, 248, 14, 135, 90, 167, 156, 168, 77, 199, 254, 204, 100, 87, 68, 85, 14, 206, 25),
          U1(46, 71, 44, 98)
        })))[_ARG_0_.ClientUsedAvatarID].Effect then
          goto lbl_231
          if not U1(46, 71, 44, 98).beginTime or U1(46, 71, 44, 98).beginTime == 0 then
          else
            _ARG_0_.VehicleFXTimers[U1(46, 71, 44, 98).Name] = _ARG_0_:AddTimer(U1(46, 71, 44, 98).beginTime, function()
              _ENV:PlayVehicleEffect(U1.Name, U1.endTime - U1.beginTime)
              return
            end)
          end
          ::lbl_231::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if require((table.concat({
          U1(35, 77, 44, 96, 175, 63, 195, 58, 145, 78, 178, 138, 215, 72, 209, 227, 217, 114, 89, 80, 31, 45, 248, 14, 135, 90, 167, 156, 168, 77, 199, 254, 204, 100, 87, 68, 85, 14, 206, 25),
          U1(46, 71, 44, 98)
        })))[_ARG_0_.ClientUsedAvatarID].MatConfig then
          _ARG_0_.MatTickEndTime = require((table.concat({
            U1(35, 77, 44, 96, 175, 63, 195, 58, 145, 78, 178, 138, 215, 72, 209, 227, 217, 114, 89, 80, 31, 45, 248, 14, 135, 90, 167, 156, 168, 77, 199, 254, 204, 100, 87, 68, 85, 14, 206, 25),
            U1(46, 71, 44, 98)
          })))[_ARG_0_.ClientUsedAvatarID].EndTime or 5
          goto lbl_250
          ::lbl_250::
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
        if slua.isValid((_ARG_0_.Mesh:GetAnimInstance())) and _ARG_0_.Mesh:GetAnimInstance().LobbyPlayAccelerateAnim then
        end
      else
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopAccelerateEffect"] = function(_ARG_0_)
    do
      _ARG_0_:StopVehicleEffect((_ENV(5, 89, 45, 100, 180, 56, 153)))
      _ARG_0_:StopVehicleEffect((_ENV(19, 81, 42, 108, 173, 46, 159, 37, 170, 72, 178, 133, 176, 80, 248, 226, 214, 101)))
      _ARG_0_:StopTickVehicleMat()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayAccelerateSound"] = function(_ARG_0_)
    do
      if slua.isValid((_ARG_0_.Mesh:GetAnimInstance())) then
        if _ARG_0_.curPlayingAccSoundId then
          _ARG_0_.curPlayingAccSoundId = nil
        end
        if _ARG_0_.Mesh:GetAnimInstance().AccelerateSound then
          _ARG_0_.curPlayingAccSoundId = import((U1(1, 74, 2, 100, 172, 46, 157, 58, 159, 80, 136, 157, 152, 74, 221, 232, 195))).PostEvent(_ARG_0_.Mesh:GetAnimInstance().AccelerateSound, _ARG_0_.Object, true, (U1()))
        end
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckCanAccelerate"] = function(_ARG_0_)
    do
      if not require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 193, 226, 239, 100, 65, 92, 93))).CanClickNow(require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 193, 226, 239, 100, 65, 92, 93))).ModuleFrequencyLimit.LobbyVehicle) then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLicensePlate"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_.BP_Lobby_VehicleLicenseComponent then
        log(bWriteLog and table.concat({
          U1(27, 109, 44, 102, 164, 37, 158, 51, 174, 69, 186, 157, 156, 99, 148, 199, 223, 115, 87, 76, 103, 30, 245, 15, 141, 85, 174, 217, 170, 70, 197, 245, 199, 100, 117, 73, 64, 31, 232, 86),
          U1(19, 68, 49, 73, 168, 40, 136, 56, 141, 76, 139, 133, 152, 74, 209, 171, 243, 112, 91, 85, 69, 91, 251, 15, 128, 93, 235, 187, 185, 113, 232, 244, 194, 99, 92, 122, 119, 14, 229, 31),
          U1(35, 77, 32, 73, 168, 40, 136, 56, 141, 76, 152, 134, 148, 78, 219, 229, 213, 127, 65)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayDoorAnim"] = function(_ARG_0_)
    do
      _ARG_0_:PlayOpenDoorAnim()
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNewVehilceMasterPath"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 4, 155, 79, 178, 157, 176, 80, 210, 228), _ARG_1_) then
        return (U1())
      end
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 5, 150, 72, 171, 140, 173, 95, 214, 231, 213), CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 4, 155, 79, 178, 157, 176, 80, 210, 228), _ARG_1_).VehicleShapeID) then
        return (U1())
      end
      do return CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 5, 150, 72, 171, 140, 173, 95, 214, 231, 213), CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 4, 155, 79, 178, 157, 176, 80, 210, 228), _ARG_1_).VehicleShapeID).MeshBasePath end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetNewVehicleMasterAnimBPPath"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 4, 155, 79, 178, 157, 176, 80, 210, 228), _ARG_1_) then
        return (U1())
      end
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 5, 150, 72, 171, 140, 173, 95, 214, 231, 213), CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 4, 155, 79, 178, 157, 176, 80, 210, 228), _ARG_1_).VehicleShapeID) then
        return (U1())
      end
      do return CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 5, 150, 72, 171, 140, 173, 95, 214, 231, 213), CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 4, 155, 79, 178, 157, 176, 80, 210, 228), _ARG_1_).VehicleShapeID).AnimBPPath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleMasterPath"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 20, 174, 125, 186, 139, 149, 91), _ARG_1_) then
        return (U1())
      end
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 5, 150, 72, 171, 140, 173, 95, 214, 231, 213), CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 20, 174, 125, 186, 139, 149, 91), _ARG_1_).VehicleShapeID) then
        return (U1())
      end
      do return CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 5, 150, 72, 171, 140, 173, 95, 214, 231, 213), CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 20, 174, 125, 186, 139, 149, 91), _ARG_1_).VehicleShapeID).MeshBasePath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PreChangeVehicleAvatar"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 198, 238, 243, 121, 84, 91, 86, 30, 203, 3, 134, 80, 168, 149, 140, 111, 210, 250, 212, 96, 87, 5, 96, 29, 236, 2),
          U1(33, 83, 12, 65, 225, 34, 158, 118, 144, 64, 183)
        }))
        return
      end
      if 0 < _ARG_2_ and _ARG_0_.VehicleAdvanceAvatarComp_BP then
        return _ARG_0_.Super:PreChangeVehicleAvatar(0, _ARG_2_)
      else
        return _ARG_0_.Super:PreChangeVehicleAvatar(_ARG_1_, _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PutOnVehicleItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_.VehicleAdvanceAvatarComp_BP then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 110, 193, 255, 255, 127, 99, 80, 89, 18, 254, 10, 139, 112, 191, 156, 132, 14, 202, 244, 128, 87, 64, 77, 72, 8, 225, 19),
          U1(1, 69, 51, 100, 175, 40, 136, 23, 136, 72, 175, 136, 139, 125, 219, 230, 192, 78, 119, 101)
        }))
        return false
      end
      do return _ARG_0_.VehicleAdvanceAvatarComp_BP:PutOnItemIDInLobby(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PutOffVehicleItem"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.VehicleAdvanceAvatarComp_BP then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 110, 193, 255, 255, 119, 83, 99, 84, 19, 244, 5, 130, 92, 130, 141, 140, 67, 132, 245, 207, 33, 115, 64, 73, 2, 238, 26),
          U1(37, 96, 33, 115, 160, 37, 142, 51, 191, 95, 186, 157, 152, 76, 247, 228, 221, 97, 106, 119, 97)
        }))
        return false
      end
      do return _ARG_0_.VehicleAdvanceAvatarComp_BP:PutOffItemIDInLobby(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDefaultAvatarID"] = function(_ARG_0_, _ARG_1_)
    do
      if not CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 6, 146, 72, 181, 140, 170, 85, 221, 229, 253, 112, 69, 69, 88, 21, 250), _ARG_1_) then
        return _ARG_1_
      end
      do return CDataTable.GetTableData(U1(22, 68, 45, 108, 162, 39, 136, 6, 146, 72, 181, 140, 170, 85, 221, 229, 253, 112, 69, 69, 88, 21, 250), _ARG_1_).OrginalID end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PreChangeVehicleAvatar_Old"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if 0 < _ARG_2_ and _ARG_0_.VehicleAdvanceAvatarComp_BP then
        return _ARG_0_.Super:PreChangeVehicleAvatar(0, _ARG_2_)
      else
        return _ARG_0_.Super:PreChangeVehicleAvatar(_ARG_1_, _ARG_2_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TrySetHighLight"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_0_.Mesh) then
        return
      end
      if _ARG_0_.Mesh:GetMaterials():Num() <= 0 then
        return
      end
      if not CDataTable.GetTableData(U1(9, 85, 32, 104), _ARG_0_.vehicleResId) then
        return
      end
      goto lbl_357
      if not slua.isValid((_ARG_0_.Mesh:CreateDynamicMaterialInstance(_ARG_0_.vehicleResId, U1(96)))) then
        return
      end
      ::lbl_357::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PutOffVehicleSlot"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.VehicleAdvanceAvatarComp_BP then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 110, 193, 255, 255, 119, 83, 99, 84, 19, 244, 5, 130, 92, 152, 149, 134, 90, 132, 245, 207, 117, 5, 115, 68, 3, 228, 21),
          U1(44, 68, 4, 97, 183, 42, 131, 53, 155, 104, 173, 136, 141, 95, 198, 200, 223, 124, 69, 106, 115, 43)
        }))
        return false
      end
      do return (_ARG_0_.VehicleAdvanceAvatarComp_BP:PutOffSlotinLobby(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClearAllVehicleItems"] = function(_ARG_0_)
    do
      if not _ARG_0_.VehicleAdvanceAvatarComp_BP then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 125, 216, 238, 209, 99, 116, 89, 93, 45, 248, 14, 135, 90, 167, 156, 160, 90, 193, 246, 211, 33, 75, 74, 85, 75, 219, 19),
          U1(40, 72, 38, 105, 164, 10, 137, 32, 159, 71, 184, 140, 184, 72, 213, 255, 209, 99, 118, 90, 92, 11, 194, 36, 190)
        }))
        return false
      end
      _ARG_0_.VehicleAdvanceAvatarComp_BP:RemoveAllEquippedItem()
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetDMIParam"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_2_ or not _ARG_3_ then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 109, 209, 255, 244, 92, 124, 101, 80, 9, 252, 11, 206, 80, 165, 143, 136, 66, 205, 255, 128, 81, 68, 87, 64, 6, 219, 23),
          U1(44, 84, 32, 37, 174, 57, 205, 6, 159, 91, 186, 132, 183, 95, 217, 238)
        }))
        return
      end
      if not slua.isValid(_ARG_1_) or not _ARG_1_.SetScalarParameterValue then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 217, 109, 209, 255, 244, 92, 124, 101, 80, 9, 252, 11, 206, 80, 165, 143, 136, 66, 205, 255, 128, 76, 68, 81, 68, 25, 228, 23),
          U1(44, 104, 43, 118, 181, 42, 131, 53, 155)
        }))
        return
      end
      _ARG_1_:SetScalarParameterValue(_ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetHighLight"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_0_.HighlightTryTime = 0
      _ARG_0_:TrySetHighLight(_ARG_1_, _ARG_2_, _ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShowModelOutline"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not slua.isValid(_ARG_0_.Mesh) then
        return
      end
      goto lbl_71
      if 168 and slua.isValid(168) then
        if _ARG_1_ then
        end
      end
      ::lbl_71::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetVehicleAccessorySlotConfig"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_1_ or not _ARG_2_ then
        log(bWriteLog and table.concat({
          U1(27, 119, 32, 109, 168, 40, 129, 51, 191, 74, 184, 140, 138, 77, 219, 249, 201, 76, 21, 121, 94, 25, 255, 31, 184, 92, 163, 144, 138, 66, 193, 161, 231, 100, 81, 115, 68, 3, 228, 21),
          U1(44, 68, 4, 102, 162, 46, 158, 37, 145, 91, 162, 186, 149, 81, 192, 200, 223, 127, 83, 92, 86, 87, 189, 22, 143, 75, 170, 148, 201, 71, 215, 187, 206, 104, 73)
        }))
        return nil
      end
      log(bWriteLog and table.concat({
        U1(27, 119, 32, 109, 168, 40, 129, 51, 191, 74, 184, 140, 138, 77, 219, 249, 201, 76, 21, 121, 94, 25, 255, 31, 184, 92, 163, 144, 138, 66, 193, 161, 231, 100, 81, 115, 68, 3, 228, 21),
        U1(44, 68, 4, 102, 162, 46, 158, 37, 145, 91, 162, 186, 149, 81, 192, 200, 223, 127, 83, 92, 86, 87, 189, 8, 175, 79, 170, 141, 136, 92, 237, 223, 128, 60, 5)
      }) .. tostring(_ARG_1_) .. U1(96, 82, 41, 106, 181, 5, 140, 59, 155, 9, 230, 201) .. tostring(_ARG_2_))
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        return nil
      end
      if not slua.isValid((_ARG_0_.VehicleAvatarComponent_BP:GetItemAvatarHandle(_ARG_1_))) then
        return nil
      end
      if not _ARG_0_.VehicleAvatarComponent_BP:GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs or _ARG_0_.VehicleAvatarComponent_BP:GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Num() == 0 then
        return nil
      end
      _ARG_0_ = _ARG_0_
      if _ARG_0_.VehicleAvatarComponent_BP:GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(27, 119, 32, 109, 168, 40, 129, 51, 191, 74, 184, 140, 138, 77, 219, 249, 201, 76, 21, 121, 94, 25, 255, 31, 184, 92, 163, 144, 138, 66, 193, 161, 231, 100, 81, 115, 68, 3, 228, 21))) and _ARG_0_.VehicleAvatarComponent_BP:GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(27, 119, 32, 109, 168, 40, 129, 51, 191, 74, 184, 140, 138, 77, 219, 249, 201, 76, 21, 121, 94, 25, 255, 31, 184, 92, 163, 144, 138, 66, 193, 161, 231, 100, 81, 115, 68, 3, 228, 21))).AccessorySlotName == _ARG_2_ then
        return (_ARG_0_.VehicleAvatarComponent_BP:GetItemAvatarHandle(_ARG_1_).VehicleAccessorySlotCfgs:Get((U1(27, 119, 32, 109, 168, 40, 129, 51, 191, 74, 184, 140, 138, 77, 219, 249, 201, 76, 21, 121, 94, 25, 255, 31, 184, 92, 163, 144, 138, 66, 193, 161, 231, 100, 81, 115, 68, 3, 228, 21))))
      end
      _ARG_0_ = _ARG_0_
      do return nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_1_ = U1[114]
    end
  end,
  ["SetVehicleAccessoryWithPreview"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.BP_Lobby_VehicleLicenseComponent then
        log(bWriteLog and table.concat({
          U1(27, 109, 44, 102, 164, 37, 158, 51, 174, 69, 186, 157, 156, 99, 148, 199, 223, 115, 87, 76, 103, 30, 245, 15, 141, 85, 174, 217, 186, 75, 208, 205, 197, 105, 76, 70, 77, 14, 204, 21),
          U1(35, 68, 54, 118, 174, 57, 148, 1, 151, 93, 179, 185, 139, 91, 194, 226, 213, 102, 21, 118, 80, 21, 253, 18, 206, 95, 162, 151, 141, 14, 230, 203, 255, 77, 74, 71, 67, 18, 210, 32),
          U1(37, 73, 44, 102, 173, 46, 161, 63, 157, 76, 181, 154, 156, 125, 219, 230, 192, 126, 91, 80, 95, 15)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleAccessoryList"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.BP_Lobby_VehicleLicenseComponent then
        log(bWriteLog and table.concat({
          U1(27, 109, 44, 102, 164, 37, 158, 51, 174, 69, 186, 157, 156, 99, 148, 199, 223, 115, 87, 76, 103, 30, 245, 15, 141, 85, 174, 217, 186, 75, 208, 205, 197, 105, 76, 70, 77, 14, 204, 21),
          U1(35, 68, 54, 118, 174, 57, 148, 26, 151, 90, 175, 201, 186, 95, 218, 235, 196, 49, 83, 92, 95, 31, 189, 36, 190, 102, 135, 150, 139, 76, 221, 196, 246, 100, 77, 76, 66, 7, 232, 58),
          U1(41, 66, 32, 107, 178, 46, 174, 57, 147, 89, 180, 135, 156, 80, 192)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetChassisLightShowData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_.BP_Lobby_VehicleLicenseComponent then
        log(bWriteLog and table.concat({
          U1(27, 109, 44, 102, 164, 37, 158, 51, 174, 69, 186, 157, 156, 99, 148, 199, 223, 115, 87, 76, 103, 30, 245, 15, 141, 85, 174, 217, 186, 75, 208, 216, 200, 96, 86, 86, 72, 24, 193, 31),
          U1(39, 73, 49, 86, 169, 36, 154, 18, 159, 93, 186, 201, 186, 95, 218, 235, 196, 49, 83, 92, 95, 31, 189, 36, 190, 102, 135, 150, 139, 76, 221, 196, 246, 100, 77, 76, 66, 7, 232, 58),
          U1(41, 66, 32, 107, 178, 46, 174, 57, 147, 89, 180, 135, 156, 80, 192)
        }))
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetWheelHubShowData"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        log(bWriteLog and table.concat({
          U1(27, 109, 42, 103, 163, 50, 187, 51, 150, 64, 184, 133, 156, 99, 239, 198, 197, 125, 65, 92, 98, 23, 242, 18, 179, 25, 135, 150, 139, 76, 221, 205, 197, 105, 76, 70, 77, 14, 173, 37),
          U1(37, 85, 18, 109, 164, 46, 129, 30, 139, 75, 136, 129, 150, 73, 240, 234, 196, 112, 21, 118, 80, 21, 253, 18, 206, 95, 162, 151, 141, 14, 242, 254, 200, 104, 70, 73, 68, 42, 251, 23),
          U1(52, 64, 55, 70, 174, 38, 157, 57, 144, 76, 181, 157, 166, 124, 228)
        }))
        return
      end
      if _ARG_1_ and 0 < _ARG_1_ then
        _ARG_0_.VehicleAvatarComponent_BP:EquipSlots({
          [U2.WheelHub] = _ARG_1_
        }, false)
        _ARG_0_:RecordEquipedMultiSlotPart(U2.WheelHub, _ARG_1_)
      else
        _ARG_0_.VehicleAvatarComponent_BP:UnequipSlots({
          tonumber(U2.WheelHub)
        })
        _ARG_0_:RecordEquipedMultiSlotPart(U2.WheelHub, nil)
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBrakeCaliperShowData"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        log(bWriteLog and table.concat({
          U1(27, 109, 42, 103, 163, 50, 187, 51, 150, 64, 184, 133, 156, 99, 239, 198, 197, 125, 65, 92, 98, 23, 242, 18, 179, 25, 135, 150, 139, 76, 221, 205, 197, 105, 76, 70, 77, 14, 173, 37),
          U1(37, 85, 7, 119, 160, 32, 136, 21, 159, 69, 178, 153, 156, 76, 231, 227, 223, 102, 113, 84, 69, 26, 189, 37, 143, 87, 171, 141, 201, 72, 205, 245, 196, 33, 115, 64, 73, 2, 238, 26),
          U1(37, 96, 51, 100, 181, 42, 159, 21, 145, 68, 171, 134, 151, 91, 218, 255, 239, 83, 101)
        }))
        return
      end
      if _ARG_1_ and 0 < _ARG_1_ then
        _ARG_0_.VehicleAvatarComponent_BP:EquipSlots({
          [U2.BrakeCaliper] = _ARG_1_
        }, false)
        _ARG_0_:RecordEquipedMultiSlotPart(U2.BrakeCaliper, _ARG_1_)
      else
        _ARG_0_.VehicleAvatarComponent_BP:UnequipSlots({
          tonumber(U2.BrakeCaliper)
        })
        _ARG_0_:RecordEquipedMultiSlotPart(U2.BrakeCaliper, nil)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetCanopyShowData"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        log(bWriteLog and table.concat({
          U1(27, 109, 42, 103, 163, 50, 187, 51, 150, 64, 184, 133, 156, 99, 239, 198, 197, 125, 65, 92, 98, 23, 242, 18, 179, 25, 135, 150, 139, 76, 221, 205, 197, 105, 76, 70, 77, 14, 173, 37),
          U1(37, 85, 6, 100, 175, 36, 157, 47, 173, 65, 180, 158, 189, 95, 192, 234, 144, 82, 84, 91, 81, 15, 189, 0, 135, 87, 175, 217, 191, 75, 204, 242, 195, 109, 64, 100, 87, 10, 249, 23),
          U1(50, 98, 42, 104, 177, 36, 131, 51, 144, 93, 132, 171, 169)
        }))
        return
      end
      if _ARG_1_ and 0 < _ARG_1_ then
        _ARG_0_.VehicleAvatarComponent_BP:EquipSlots({
          [U2.Canopy] = _ARG_1_
        }, false)
        _ARG_0_:RecordEquipedMultiSlotPart(U2.Canopy, _ARG_1_)
      else
        _ARG_0_.VehicleAvatarComponent_BP:UnequipSlots({
          tonumber(U2.Canopy)
        })
        _ARG_0_:RecordEquipedMultiSlotPart(U2.Canopy, nil)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RecordEquipedMultiSlotPart"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_1_ == nil then
        return
      end
      _ARG_0_.EquipedMultiSlotParts = _ARG_0_.EquipedMultiSlotParts or {}
      _ARG_0_.EquipedMultiSlotParts[_ARG_1_] = _ARG_2_
      if slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) and _ARG_0_.VehicleAvatarComponent_BP.SetLobbyMultiSlotEquipData then
        _ARG_0_.VehicleAvatarComponent_BP:SetLobbyMultiSlotEquipData(_ARG_0_.EquipedMultiSlotParts)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnMultiSlotPartDownloadFinish"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_3_ then
        return
      end
      if _ARG_3_.errorCode and _ARG_3_.errorCode ~= 0 then
        return
      end
      if _ARG_3_.downloadType ~= require((U1(35, 77, 44, 96, 175, 63, 195, 37, 146, 92, 186, 199, 149, 81, 211, 226, 211, 63, 81, 90, 70, 21, 241, 9, 143, 93, 229, 137, 156, 72, 194, 254, 210, 94, 70, 74, 79, 24, 249))).ENUM_DownloadType.ODPAK then
        return
      end
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) or not _ARG_0_.EquipedMultiSlotParts then
        return
      end
      if not (_ARG_3_.itemID and tonumber(_ARG_3_.itemID)) then
        return
      end
      goto lbl_207
      if 175 and tonumber(175) == (_ARG_3_.itemID and tonumber(_ARG_3_.itemID)) then
      end
      ::lbl_207::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayCabrioAnim"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.Mesh) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 82, 84, 87, 67, 18, 242, 39, 128, 80, 166, 217, 154, 75, 200, 253, 142, 76, 64, 86, 73, 75, 228, 5),
          U1(96, 79, 42, 113, 225, 29, 140, 58, 151, 77)
        }))
        return false
      end
      if not slua.isValid((_ARG_0_.Mesh:GetAnimInstance())) then
        return false
      end
      if _ARG_0_.Mesh:GetAnimInstance().CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).BeenOpen or _ARG_0_.Mesh:GetAnimInstance().CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).BeenClose then
        if _ARG_0_.VehicleAnimParams.CabrioletState ~= _ARG_0_.Mesh:GetAnimInstance().CabrioletState then
          _ARG_0_.VehicleAnimParams.CabrioletState = _ARG_0_.Mesh:GetAnimInstance().CabrioletState, _ARG_1_ and true or false, _ARG_0_.VehicleAnimParams
        end
        if _ARG_0_.Mesh:GetAnimInstance().CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).BeenOpen == (_ARG_1_ and true or false) then
          return true
        end
      end
      if not _ARG_0_.Mesh:GetAnimInstance().CabrioletState or _ARG_0_.Mesh:GetAnimInstance().CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).Close or _ARG_0_.Mesh:GetAnimInstance().CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).Open then
        return false
      end
      if _ARG_1_ then
      else
      end
      _ARG_0_.VehicleAnimParams.CabrioletState = import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).Close, _ARG_0_.VehicleAnimParams
      if _ARG_0_.CabrioletAnimTimer then
        _ARG_0_.CabrioletAnimTimer = nil
      end
      if _ARG_0_.VehicleAvatarComponent_BP and _ARG_0_.VehicleAvatarComponent_BP.lastEquipedAvatarId and CDataTable.GetTableData(U1(2, 68, 49, 113, 164, 57, 187, 51, 150, 64, 184, 133, 156, 123, 210, 237, 213, 114, 65), _ARG_0_.VehicleAvatarComponent_BP and _ARG_0_.VehicleAvatarComponent_BP.lastEquipedAvatarId) and CDataTable.GetTableData(U1(2, 68, 49, 113, 164, 57, 187, 51, 150, 64, 184, 133, 156, 123, 210, 237, 213, 114, 65), _ARG_0_.VehicleAvatarComponent_BP and _ARG_0_.VehicleAvatarComponent_BP.lastEquipedAvatarId).CabrioletDelayTime and CDataTable.GetTableData(U1(2, 68, 49, 113, 164, 57, 187, 51, 150, 64, 184, 133, 156, 123, 210, 237, 213, 114, 65), _ARG_0_.VehicleAvatarComponent_BP and _ARG_0_.VehicleAvatarComponent_BP.lastEquipedAvatarId).CabrioletDelayTime ~= 0 then
      end
      _ARG_0_.CabrioletAnimTimer = _ARG_0_:AddTimerOnce(CDataTable.GetTableData(U1(2, 68, 49, 113, 164, 57, 187, 51, 150, 64, 184, 133, 156, 123, 210, 237, 213, 114, 65), _ARG_0_.VehicleAvatarComponent_BP and _ARG_0_.VehicleAvatarComponent_BP.lastEquipedAvatarId).CabrioletDelayTime, function()
        CabrioletAnimTimer = nil
        if U1 then
          VehicleAnimParams.CabrioletState = U2.BeenOpen
        else
          VehicleAnimParams.CabrioletState = U2.BeenClose
        end
        U3.log(U3.bWriteLog and U3.table.concat({
          U4(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 82, 84, 87, 67, 18, 242, 39, 128, 80, 166, 217, 157, 71, 201, 254, 210, 33, 70, 80, 83, 40, 236, 20),
          U4(50, 72, 42, 105, 160, 63, 190, 34, 159, 93, 190, 211)
        }) .. U3.tostring(VehicleAnimParams.CabrioletState))
        return
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAvatarComponent"] = function(_ARG_0_)
    do
      do return _ARG_0_.VehicleAvatarComponent_BP end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ToggleSunroofEffect"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 106, 219, 236, 215, 125, 80, 102, 68, 21, 239, 9, 129, 95, 142, 159, 143, 75, 199, 239, 128, 87, 64, 77, 72, 8, 225, 19),
          U1(1, 87, 36, 113, 160, 57, 174, 57, 147, 89, 180, 135, 156, 80, 192, 212, 242, 65, 21, 92, 95, 13, 252, 10, 135, 93)
        }))
        return
      end
      _ARG_0_.VehicleAvatarComponent_BP:ApplySunroofState(_ARG_1_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayStartUpEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 66, 65, 84, 67, 15, 200, 22, 171, 95, 173, 156, 138, 90))
      if not require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 193, 226, 239, 100, 65, 92, 93))).CanClickNow(require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 193, 226, 239, 100, 65, 92, 93))).ModuleFrequencyLimit.LobbyVehicle) then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopStartUpEffect"] = function(_ARG_0_)
    do
      _ARG_0_:StopVehicleEffect((_ENV(19, 85, 36, 119, 181, 30, 157, 16, 166)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlaySwiftEffect"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 66, 66, 92, 87, 15, 216, 0, 136, 92, 168, 141))
      if not require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 193, 226, 239, 100, 65, 92, 93))).CanClickNow(require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 193, 226, 239, 100, 65, 92, 93))).ModuleFrequencyLimit.LobbyVehicle) then
        return
      end
      _ARG_1_ = _ARG_1_ or 5
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopSwiftEffect"] = function(_ARG_0_)
    do
      _ARG_0_:StopVehicleEffect((_ENV(19, 86, 44, 99, 181, 13, 181)))
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayVehicleEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 171, 95, 173, 156, 138, 90, 132, 222, 198, 103, 64, 70, 85, 37, 236, 27),
        U1(37, 27)
      }) .. tostring(_ARG_1_))
      if not _ARG_1_ or _ARG_1_ == U1() then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 171, 95, 173, 156, 138, 90, 132, 222, 198, 103, 64, 70, 85, 37, 236, 27),
          U1(37, 1, 11, 106, 181, 107, 187, 55, 146, 64, 191)
        }))
        return
      end
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 171, 95, 173, 156, 138, 90, 132, 218, 214, 96, 81, 68, 83, 75, 206, 25),
          U1(45, 81, 101, 75, 174, 63, 205, 0, 159, 69, 178, 141)
        }))
        return
      end
      if not slua.isValid((_ARG_0_.VehicleAvatarComponent_BP:GetVehicleAvatarHandle())) then
        return
      end
      if _ARG_0_.VehicleFXTimers and _ARG_0_.VehicleFXTimers[_ARG_1_] then
        _ARG_0_.VehicleFXTimers[_ARG_1_] = nil
      end
      if not _ARG_0_.VehicleAvatarComponent_BP:GetVehicleAvatarHandle().ParticleSfx:Get(_ARG_1_) then
        return
      end
      _ARG_0_.VehicleFXMap = _ARG_0_.VehicleFXMap or {}
      _ARG_0_.VehicleFXMap[_ARG_1_] = _ARG_0_.VehicleFXMap[_ARG_1_] or {}
      goto lbl_459
      ::lbl_459::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_.VehicleFXTimers[_ARG_1_] = _ARG_0_:AddTimer(_ARG_2_ or 0.3, function()
        VehicleFXTimers[U1] = nil
        _ENV:StopVehicleEffect(U1)
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ENV[218]
    end
  end,
  ["StopVehicleEffect"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and table.concat({
        U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 192, 228, 192, 71, 80, 93, 88, 24, 241, 3, 171, 95, 173, 156, 138, 90, 132, 222, 198, 103, 64, 70, 85, 37, 236, 27),
        U1(37, 27)
      }) .. tostring(_ARG_1_))
      if not _ARG_1_ or _ARG_1_ == U1() then
        return
      end
      if not _ARG_0_.VehicleFXMap or not _ARG_0_.VehicleFXMap[_ARG_1_] then
        return
      end
      if #_ARG_0_.VehicleFXMap[_ARG_1_] > 0 then
        goto lbl_94
        ::lbl_94::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.VehicleFXMap[_ARG_1_] = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["BeginTickVehicleMat"] = function(_ARG_0_, _ARG_1_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 124, 209, 236, 217, 127, 97, 92, 82, 16, 203, 3, 134, 80, 168, 149, 140, 99, 197, 239))
      if not _ARG_1_ then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 124, 209, 236, 217, 127, 97, 92, 82, 16, 203, 3, 134, 80, 168, 149, 140, 99, 197, 239, 128, 76, 68, 81, 98, 4, 227, 16),
          U1(41, 70, 101, 108, 178, 107, 131, 63, 146)
        }))
        return
      end
      if not slua.isValid(_ARG_0_.Mesh) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 124, 209, 236, 217, 127, 97, 92, 82, 16, 203, 3, 134, 80, 168, 149, 140, 99, 197, 239, 128, 76, 64, 86, 73, 75, 228, 5),
          U1(96, 79, 42, 113, 225, 29, 140, 58, 151, 77)
        }))
        return
      end
      if not _ARG_1_.Slot or not _ARG_1_.MatPath then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 124, 209, 236, 217, 127, 97, 92, 82, 16, 203, 3, 134, 80, 168, 149, 140, 99, 197, 239, 128, 104, 75, 83, 64, 7, 228, 18),
          U1(96, 108, 36, 113, 130, 36, 131, 48, 151, 78, 251, 186, 149, 81, 192, 171, 223, 99, 21, 120, 80, 15, 205, 7, 154, 81)
        }))
        return
      end
      if _ARG_0_.Mesh:GetMaterialIndex(_ARG_1_.Slot) < 0 then
        return
      end
      goto lbl_483
      if (103).SlotIndex == _ARG_0_.Mesh:GetMaterialIndex(_ARG_1_.Slot) then
      else
        ::lbl_483::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not slua.isValid((_ARG_0_.Mesh:GetMaterial((_ARG_0_.Mesh:GetMaterialIndex(_ARG_1_.Slot))))) then
        return
      end
      if not slua.isValid((require((U1(35, 78, 40, 104, 174, 37, 195, 55, 141, 90, 190, 157, 166, 75, 192, 226, 220))).GetAssetSync(_ARG_1_.MatPath))) then
        return
      end
      if not slua.isValid((_ARG_0_.Mesh:CreateDynamicMaterialInstance(_ARG_0_.Mesh:GetMaterialIndex(_ARG_1_.Slot), (require((U1(35, 78, 40, 104, 174, 37, 195, 55, 141, 90, 190, 157, 166, 75, 192, 226, 220))).GetAssetSync(_ARG_1_.MatPath))))) then
        return
      end
      if _ARG_1_.Param then
        goto lbl_922
        if U1(52, 78, 101, 102, 179, 46, 140, 34, 155, 9, 191, 144, 151, 95, 217, 226, 211, 49, 88, 84, 69, 30, 239, 15, 143, 85, 235, 144, 135, 93, 208, 250, 206, 98, 64).Curve then
          if slua.isValid((require((U1(35, 78, 40, 104, 174, 37, 195, 55, 141, 90, 190, 157, 166, 75, 192, 226, 220))).GetAssetSync(U1(52, 78, 101, 102, 179, 46, 140, 34, 155, 9, 191, 144, 151, 95, 217, 226, 211, 49, 88, 84, 69, 30, 239, 15, 143, 85, 235, 144, 135, 93, 208, 250, 206, 98, 64).Curve))) then
          else
          end
        end
        ::lbl_922::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      if not _ARG_0_.VehicleMatTickTimer then
        _ARG_0_.VehicleMatTickTimer = _ARG_0_:AddTimerLoop(0, function(_ARG_0_)
          do
            _ENV:UpdateVehicleMatTick(_ARG_0_)
            do return end
            _ARG_0_ = _ARG_0_
            _ARG_0_ = _ARG_0_
          end
        end, TIMER_INFINITE or 0, -2)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UpdateVehicleMatTick"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.Mesh) then
        return
      end
      _ARG_0_.MatTickTime = _ARG_0_.MatTickTime + (_ARG_1_ or 0)
      if _ARG_0_.MatTickTime > _ARG_0_.MatTickEndTime then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 107, 196, 239, 209, 101, 80, 99, 84, 19, 244, 5, 130, 92, 134, 152, 157, 122, 205, 248, 203, 33, 104, 68, 85, 63, 228, 21),
          U1(43, 100, 43, 97)
        }))
        _ARG_0_:StopTickVehicleMat()
        return
      end
      goto lbl_163
      if slua.isValid(U1(43, 100, 43, 97).DynamicMaterialInstance) then
        goto lbl_161
        if slua.isValid(U1(43, 100, 43, 97).Curve) and U1(43, 100, 43, 97).Curve.GetFloatValue and U1(43, 100, 43, 97).Curve:GetFloatValue(_ARG_0_.MatTickTime) then
          if U1(43, 100, 43, 97).UseAdditive then
            if not U1(43, 100, 43, 97).DynamicMaterialInstance:K2_GetScalarParameterValue(U1(43, 100, 43, 97).Name) then
              goto lbl_161
            end
          end
        end
        ::lbl_161::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      ::lbl_163::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopTickVehicleMat"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 192, 228, 192, 69, 92, 86, 90, 45, 248, 14, 135, 90, 167, 156, 164, 79, 208))
      if _ARG_0_.VehicleMatTickTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.VehicleMatTickTimer)
        _ARG_0_.VehicleMatTickTimer = nil
      end
      if slua.isValid(_ARG_0_.Mesh) then
        goto lbl_141
        if slua.isValid((39).OriginalMaterial) then
        else
        end
        ::lbl_141::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_.VehicleMatData = {}
      _ARG_0_.MatTickTime = 0
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["OnVehicleAnimInsInitialize"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 113, 218, 221, 213, 121, 92, 86, 93, 30, 220, 8, 135, 84, 130, 151, 154, 103, 202, 242, 212, 104, 68, 73, 72, 17, 232))
      if _ARG_0_.InitAnimTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.InitAnimTimer)
        _ARG_0_.InitAnimTimer = nil
      end
      if slua.isValid(_ARG_0_.Mesh and _ARG_0_.Mesh:GetAnimInstance()) then
        if _ARG_0_.VehicleAnimParams and (_ARG_0_.VehicleAnimParams.CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).Open or _ARG_0_.VehicleAnimParams.CabrioletState == import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).Close) then
          _ARG_0_.VehicleAnimParams.CabrioletState = (_ARG_0_.Mesh and _ARG_0_.Mesh:GetAnimInstance()).CabrioletState or import((U1(5, 98, 36, 103, 179, 34, 130, 58, 155, 93, 136, 157, 152, 74, 209))).BeenOpen
        end
        if _ARG_0_.CabrioletAnimTimer then
          _ARG_0_.CabrioletAnimTimer = nil
        end
        ;(_ARG_0_.Mesh and _ARG_0_.Mesh:GetAnimInstance()).isProhibitOpenDoorAnim = true
      end
      _ARG_0_.InitAnimTimer = _ARG_0_:AddTimerOnce(0.1, function()
        if not U1.slua.isValid(Mesh and Mesh:GetAnimInstance()) then
          return false
        end
        ;(Mesh and Mesh:GetAnimInstance()).isProhibitOpenDoorAnim = true
        if bIsProhibitOpenDoorAnim then
          return
        end
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HidePermanentParticleForOpenDoor"] = function(_ARG_0_)
    do
      _ARG_0_.bPermanentParticleHidden = true
      _ARG_0_:ApplyPermanentParticleHide()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsPermanentParticleNeedHide"] = function(_ARG_0_)
    do
      do return _ARG_0_.bPermanentParticleHidden or _ARG_0_.bPermanentParticleDissolving end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPermanentParticleDissolveHidden"] = function(_ARG_0_, _ARG_1_)
    do
      _ARG_1_ = _ARG_1_ and true or false
      if _ARG_0_.bPermanentParticleDissolving == _ARG_1_ then
        return
      end
      _ARG_0_.bPermanentParticleDissolving = _ARG_1_
      if _ARG_1_ then
        return
      end
      if _ARG_0_.bPermanentParticleHidden then
        return
      end
      if _ARG_0_.PermanentParticleShowTimer then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ApplyPermanentParticleHide"] = function(_ARG_0_)
    do
      if _ARG_0_.PermanentParticleShowTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.PermanentParticleShowTimer)
        _ARG_0_.PermanentParticleShowTimer = nil
      end
      _ARG_0_:SetPermanentParticleVisible(false)
      _ARG_0_:StartHidePermanentParticleRetry()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartHidePermanentParticleRetry"] = function(_ARG_0_)
    do
      if _ARG_0_.PermanentParticleHideRetryTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.PermanentParticleHideRetryTimer)
        _ARG_0_.PermanentParticleHideRetryTimer = nil
      end
      _ARG_0_.PermanentParticleHideRetryCount = 0
      _ARG_0_.PermanentParticleHideRetryTimer = _ARG_0_:AddTimerLoop(_ENV, function()
        if not slua.isValid(U1.VehicleAvatarComponent_BP) or U1.VehicleAvatarComponent_BP:GetCurItemAvatarID() ~= U2 or not U1:IsPermanentParticleNeedHide() then
          U1:StopHidePermanentParticleRetry()
          return
        end
        U1.PermanentParticleHideRetryCount = (U1.PermanentParticleHideRetryCount or 0) + 1
        U1:SetPermanentParticleVisible(false)
        if U1 <= U1.PermanentParticleHideRetryCount then
          U1:StopHidePermanentParticleRetry()
        end
        return
      end, U1.TIMER_INFINITE, U4)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopHidePermanentParticleRetry"] = function(_ARG_0_)
    do
      if _ARG_0_.PermanentParticleHideRetryTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.PermanentParticleHideRetryTimer)
        _ARG_0_.PermanentParticleHideRetryTimer = nil
      end
      _ARG_0_.PermanentParticleHideRetryCount = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowPermanentParticleForCloseDoor"] = function(_ARG_0_)
    do
      _ARG_0_.bPermanentParticleHidden = false
      if not _ARG_0_.bPermanentParticleDissolving then
        _ARG_0_:StopHidePermanentParticleRetry()
      end
      if _ARG_0_.PermanentParticleShowTimer then
        _ARG_0_:RemoveTimer(_ARG_0_.PermanentParticleShowTimer)
        _ARG_0_.PermanentParticleShowTimer = nil
      end
      _ARG_0_.PermanentParticleShowTimer = _ARG_0_:AddTimerOnce(_ENV, function()
        PermanentParticleShowTimer = nil
        _ENV:RestorePermanentParticleAfterCloseDoor()
        return
      end)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RestorePermanentParticleAfterCloseDoor"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        return
      end
      if _ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID() ~= U1 then
        return
      end
      if _ARG_0_:IsPermanentParticleNeedHide() then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPermanentParticleVisible"] = function(_ARG_0_, _ARG_1_)
    do
      if not slua.isValid(_ARG_0_.VehicleAvatarComponent_BP) then
        return 0
      end
      if _ARG_0_.VehicleAvatarComponent_BP:GetCurItemAvatarID() ~= U1 then
        return 0
      end
      if not _ARG_0_.VehicleAvatarComponent_BP.AppliedParticlesGroup or not _ARG_0_.VehicleAvatarComponent_BP.AppliedParticlesGroup.ParticleCompList then
        return 0
      end
      goto lbl_48
      ::lbl_48::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 + 1 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayOpenDoorAnim"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 94, 69, 80, 95, 63, 242, 9, 156, 120, 165, 144, 132))
      if not slua.isValid(_ARG_0_.Mesh) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 94, 69, 80, 95, 63, 242, 9, 156, 120, 165, 144, 132, 14, 242, 254, 200, 104, 70, 73, 68, 42, 238, 2),
          U1(47, 83, 107, 72, 164, 56, 133, 118, 151, 90, 251, 135, 150, 74, 148, 221, 209, 125, 92, 81)
        }))
        return false
      end
      if not slua.isValid((_ARG_0_.Mesh:GetAnimInstance())) then
        return false
      end
      if _ARG_0_.Mesh:GetAnimInstance().PlayDoorAnim then
        return true
      end
      do return _ARG_0_:PlayVehiclePreviewAnim(_ARG_0_.Mesh:GetAnimInstance(), (U1(15, 81, 32, 107, 133, 36, 130, 36))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayCloseDoorAnim"] = function(_ARG_0_)
    do
      if not slua.isValid(_ARG_0_.Mesh) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 82, 89, 90, 66, 30, 217, 9, 129, 75, 138, 151, 128, 67, 132, 205, 197, 105, 76, 70, 77, 14, 204, 21),
          U1(52, 78, 55, 43, 140, 46, 158, 62, 222, 64, 168, 201, 151, 81, 192, 171, 230, 112, 89, 92, 85)
        }))
        return false
      end
      if not slua.isValid((_ARG_0_.Mesh:GetAnimInstance())) then
        return false
      end
      if _ARG_0_.Mesh:GetAnimInstance().CloseDoorAnim then
        return true
      end
      do return _ARG_0_:PlayVehiclePreviewAnim(_ARG_0_.Mesh:GetAnimInstance(), (U1(3, 77, 42, 118, 164, 15, 130, 57, 140))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["PlayVehiclePreviewAnim"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and table.concat({
        U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 190, 75, 174, 143, 128, 75, 211, 218, 206, 104, 72, 5, 96, 5, 228, 27),
        U1(14, 64, 40, 96, 251)
      }) .. tostring(_ARG_2_))
      if not _ARG_2_ or _ARG_2_ == U1() or not slua.isValid(_ARG_1_) then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 190, 75, 174, 143, 128, 75, 211, 218, 206, 104, 72, 5, 81, 10, 255, 23),
          U1(45, 1, 44, 118, 225, 37, 130, 34, 222, 127, 186, 133, 144, 90)
        }))
        return false
      end
      if not _ARG_1_.LobbyPreviewAnims then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 190, 75, 174, 143, 128, 75, 211, 218, 206, 104, 72, 5, 96, 5, 228, 27),
          U1(9, 79, 54, 43, 141, 36, 143, 52, 135, 121, 169, 140, 143, 87, 209, 252, 241, 127, 92, 88, 66, 91, 244, 21, 206, 87, 164, 141, 201, 120, 197, 247, 201, 101)
        }))
        return false
      end
      if not (_ARG_1_.LobbyPreviewAnims:Get(_ARG_2_) and _ARG_1_.LobbyPreviewAnims:Get(_ARG_2_):ToString()) or (_ARG_1_.LobbyPreviewAnims:Get(_ARG_2_) and _ARG_1_.LobbyPreviewAnims:Get(_ARG_2_):ToString()) == U1() then
        return false
      end
      if _ARG_0_.DoorAminLoadingHandle then
        _ARG_0_.DoorAminLoadingHandle = nil
      end
      _ARG_0_.DoorAminLoadingHandle = require((U1(35, 77, 44, 96, 175, 63, 195, 37, 146, 92, 186, 182, 140, 87, 235, 237, 194, 112, 88, 80, 70, 20, 239, 13, 192, 76, 191, 144, 133))).GetAssetAsync(_ARG_1_.LobbyPreviewAnims:Get(_ARG_2_) and _ARG_1_.LobbyPreviewAnims:Get(_ARG_2_):ToString(), function(_ARG_0_)
        do
          DoorAminLoadingHandle = nil
          if not U1.slua.isValid(_ARG_0_) then
            U1.log(U1.bWriteLog and U1.table.concat({
              U2(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 190, 75, 174, 143, 128, 75, 211, 218, 206, 104, 72, 5, 108, 4, 227, 2),
              U2(33, 70, 32, 37, 168, 56, 205, 56, 145, 93, 251, 191, 152, 82, 221, 239)
            }))
            return
          end
          if not U1.slua.isValid(U3) then
            U1.log(U1.bWriteLog and U1.table.concat({
              U2(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 190, 75, 174, 143, 128, 75, 211, 218, 206, 104, 72, 5, 96, 5, 228, 27),
              U2(9, 79, 54, 37, 168, 56, 205, 56, 145, 93, 251, 191, 152, 82, 221, 239)
            }))
            return
          end
          if U3:Montage_IsPlaying(_ARG_0_) then
            U1.log(U1.bWriteLog and U1.table.concat({
              U2(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 110, 216, 234, 201, 71, 80, 93, 88, 24, 241, 3, 190, 75, 174, 143, 128, 75, 211, 218, 206, 104, 72, 5, 108, 4, 227, 2),
              U2(33, 70, 32, 90, 136, 56, 189, 58, 159, 80, 178, 135, 158)
            }))
            return
          end
          U3.ForceUpdateAnimation = true
          do return end
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
          _ARG_0_ = _ARG_0_
        end
      end)
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetPreviewSwitchEffectData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (_ARG_1_ and _ARG_2_) or not _ARG_3_ then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 209, 255, 224, 99, 80, 67, 88, 30, 234, 53, 153, 80, 191, 154, 129, 107, 194, 253, 197, 98, 81, 97, 64, 31, 236, 86),
          U1(48, 64, 55, 100, 172, 107, 132, 37, 222, 71, 180, 157, 217, 104, 213, 231, 217, 117)
        }))
        return false
      end
      log(bWriteLog and table.concat({
        U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 209, 255, 224, 99, 80, 67, 88, 30, 234, 53, 153, 80, 191, 154, 129, 107, 194, 253, 197, 98, 81, 97, 64, 31, 236, 86),
        U1(44, 64, 54, 113, 151, 46, 133, 63, 157, 69, 190, 160, 157, 4)
      }) .. tostring(_ARG_2_) .. U1(96, 79, 32, 114, 151, 46, 133, 63, 157, 69, 190, 160, 157, 4) .. tostring(_ARG_3_))
      _ARG_0_.PreviewSwitchEffectData = _ARG_0_.PreviewSwitchEffectData or {}
      _ARG_0_.PreviewSwitchEffectData.switchEffectId = _ARG_1_
      _ARG_0_.PreviewSwitchEffectData.lastVehicleId = _ARG_2_
      _ARG_0_.PreviewSwitchEffectData.newVehicleId = _ARG_3_
      _ARG_0_:CancelSwitchAssetLoadHandle()
      if _ARG_0_.ClientUsedAvatarID ~= _ARG_3_ then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 209, 255, 224, 99, 80, 67, 88, 30, 234, 53, 153, 80, 191, 154, 129, 107, 194, 253, 197, 98, 81, 97, 64, 31, 236, 86),
          U1(3, 77, 44, 96, 175, 63, 184, 37, 155, 77, 154, 159, 152, 74, 213, 249, 249, 85, 21, 75, 12, 91, 243, 3, 153, 111, 174, 145, 128, 77, 200, 254, 233, 101)
        }))
        return
      end
      if not require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 217, 228, 212, 116, 89, 106, 68, 15, 244, 10))).GetPath(U1(22, 68, 45, 108, 162, 39, 136), require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 217, 228, 212, 116, 89, 106, 68, 15, 244, 10))).GetBPID(_ARG_2_), true, false) or require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 217, 228, 212, 116, 89, 106, 68, 15, 244, 10))).GetPath(U1(22, 68, 45, 108, 162, 39, 136), require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 217, 228, 212, 116, 89, 106, 68, 15, 244, 10))).GetBPID(_ARG_2_), true, false) == U1() then
        return false
      end
      _ARG_0_.PreviewSwitchAssetHandleId = require((U1(35, 78, 40, 104, 174, 37, 195, 55, 141, 90, 190, 157, 166, 75, 192, 226, 220))).GetAssetAsync(require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 217, 228, 212, 116, 89, 106, 68, 15, 244, 10))).GetPath(U1(22, 68, 45, 108, 162, 39, 136), require((U1(35, 77, 44, 96, 175, 63, 195, 53, 145, 68, 182, 134, 151, 16, 217, 228, 212, 116, 89, 106, 68, 15, 244, 10))).GetBPID(_ARG_2_), true, false), function()
        PreviewSwitchAssetHandleId = nil
        if U1.require((U1.table.concat({
          U2(7, 64, 40, 96, 141, 62, 140, 120, 191, 74, 175, 128, 143, 87, 192, 242, 158, 82, 90, 88, 92, 30, 239, 5, 135, 88, 167, 144, 147, 75, 138, 220, 193, 108, 64, 117, 77, 10, 244, 88),
          U2(22, 68, 45, 108, 162, 39, 136, 120, 168, 76, 179, 128, 154, 82, 209, 219, 220, 112, 65, 80, 125, 18, 254, 3, 128, 74, 174, 172, 157, 71, 200)
        }))).GetOneVehicleResPaths(U1.require((U1.table.concat({
          U2(7, 64, 40, 96, 141, 62, 140, 120, 191, 74, 175, 128, 143, 87, 192, 242, 158, 82, 90, 88, 92, 30, 239, 5, 135, 88, 167, 144, 147, 75, 138, 220, 193, 108, 64, 117, 77, 10, 244, 88),
          U2(22, 68, 45, 108, 162, 39, 136, 120, 168, 76, 179, 128, 154, 82, 209, 219, 220, 112, 65, 80, 125, 18, 254, 3, 128, 74, 174, 172, 157, 71, 200)
        }))).GetSportsCarDissolveMatPathList(U3, U4), U4) and U1.next((U1.require((U1.table.concat({
          U2(7, 64, 40, 96, 141, 62, 140, 120, 191, 74, 175, 128, 143, 87, 192, 242, 158, 82, 90, 88, 92, 30, 239, 5, 135, 88, 167, 144, 147, 75, 138, 220, 193, 108, 64, 117, 77, 10, 244, 88),
          U2(22, 68, 45, 108, 162, 39, 136, 120, 168, 76, 179, 128, 154, 82, 209, 219, 220, 112, 65, 80, 125, 18, 254, 3, 128, 74, 174, 172, 157, 71, 200)
        }))).GetOneVehicleResPaths(U1.require((U1.table.concat({
          U2(7, 64, 40, 96, 141, 62, 140, 120, 191, 74, 175, 128, 143, 87, 192, 242, 158, 82, 90, 88, 92, 30, 239, 5, 135, 88, 167, 144, 147, 75, 138, 220, 193, 108, 64, 117, 77, 10, 244, 88),
          U2(22, 68, 45, 108, 162, 39, 136, 120, 168, 76, 179, 128, 154, 82, 209, 219, 220, 112, 65, 80, 125, 18, 254, 3, 128, 74, 174, 172, 157, 71, 200)
        }))).GetSportsCarDissolveMatPathList(U3, U4), U4))) then
          PreviewSwitchAssetHandleId = U5.GetAssetsArrayAsyncParallel(U1.require((U1.table.concat({
            U2(7, 64, 40, 96, 141, 62, 140, 120, 191, 74, 175, 128, 143, 87, 192, 242, 158, 82, 90, 88, 92, 30, 239, 5, 135, 88, 167, 144, 147, 75, 138, 220, 193, 108, 64, 117, 77, 10, 244, 88),
            U2(22, 68, 45, 108, 162, 39, 136, 120, 168, 76, 179, 128, 154, 82, 209, 219, 220, 112, 65, 80, 125, 18, 254, 3, 128, 74, 174, 172, 157, 71, 200)
          }))).GetOneVehicleResPaths(U1.require((U1.table.concat({
            U2(7, 64, 40, 96, 141, 62, 140, 120, 191, 74, 175, 128, 143, 87, 192, 242, 158, 82, 90, 88, 92, 30, 239, 5, 135, 88, 167, 144, 147, 75, 138, 220, 193, 108, 64, 117, 77, 10, 244, 88),
            U2(22, 68, 45, 108, 162, 39, 136, 120, 168, 76, 179, 128, 154, 82, 209, 219, 220, 112, 65, 80, 125, 18, 254, 3, 128, 74, 174, 172, 157, 71, 200)
          }))).GetSportsCarDissolveMatPathList(U3, U4), U4), U6)
        else
        end
        return
      end)
      do return end
      _ARG_2_ = ClientUsedAvatarID
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StartPreviewSwitchEffect"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (_ARG_1_ and _ARG_2_) or not _ARG_3_ then
        log(bWriteLog and table.concat({
          U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 192, 234, 194, 101, 101, 71, 84, 13, 244, 3, 153, 106, 188, 144, 157, 77, 204, 222, 198, 103, 64, 70, 85, 75, 253, 23),
          U1(50, 64, 40, 37, 168, 56, 205, 56, 145, 93, 251, 191, 152, 82, 221, 239)
        }))
        return false
      end
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) or not _ARG_0_:GetAvatarComponent().CheckAndShowVehicleSwitchEffect then
        return false
      end
      if _ARG_0_.ClientUsedAvatarID ~= _ARG_3_ then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["StopPreviewSwitchEffect"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 192, 228, 192, 65, 71, 80, 71, 18, 248, 17, 189, 78, 162, 141, 138, 70, 225, 253, 198, 100, 70, 81))
      _ARG_0_.PreviewSwitchEffectData = nil
      _ARG_0_:CancelSwitchAssetLoadHandle()
      if not slua.isValid((_ARG_0_:GetAvatarComponent())) then
        return false
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CancelSwitchAssetLoadHandle"] = function(_ARG_0_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 125, 213, 229, 211, 116, 89, 102, 70, 18, 233, 5, 134, 120, 184, 138, 140, 90, 232, 244, 193, 101, 109, 68, 79, 15, 225, 19))
      if not _ARG_0_.PreviewSwitchAssetHandleId then
        return
      end
      _ARG_0_.PreviewSwitchAssetHandleId = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetVehicleTick"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      log(bWriteLog and U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 209, 255, 230, 116, 93, 92, 82, 23, 248, 50, 135, 90, 160, 217, 139, 122, 205, 248, 203, 33, 24, 5) .. tostring(_ARG_1_) .. U1(96, 67, 22, 96, 181, 13, 130, 36, 157, 76, 191, 165, 182, 122, 148, 182, 144) .. tostring(_ARG_2_))
      if _ARG_2_ then
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetOnlyTickPoseWhenRendered"] = function(_ARG_0_)
    do
      log(bWriteLog and table.concat({
        U1(12, 78, 39, 103, 184, 29, 136, 62, 151, 74, 183, 140, 195, 109, 209, 255, 255, 127, 89, 76, 101, 18, 254, 13, 190, 86, 184, 156, 190, 70, 193, 245, 242, 100, 75, 65, 68, 25, 232, 18),
        U1(96)
      }))
      if slua.isValid(_ARG_0_.Mesh) and _ARG_0_.Mesh.MeshComponentUpdateFlag then
        _ARG_0_.Mesh.MeshComponentUpdateFlag = import((U1(5, 108, 32, 118, 169, 8, 130, 59, 142, 70, 181, 140, 151, 74, 225, 251, 212, 112, 65, 80, 119, 23, 252, 1))).OnlyTickPoseWhenRendered
        _ARG_0_.bSetOnlyTickPoseWhenRendered = true
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetForcedLOD"] = function(_ARG_0_, _ARG_1_)
    do
      if slua.isValid(_ARG_0_.Mesh) and _ARG_0_.Mesh.SetForcedLOD then
        _ARG_0_.Mesh:SetForcedLOD(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
