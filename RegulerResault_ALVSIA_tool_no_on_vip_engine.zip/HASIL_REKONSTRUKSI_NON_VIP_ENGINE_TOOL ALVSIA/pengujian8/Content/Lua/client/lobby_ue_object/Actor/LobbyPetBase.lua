local LobbyPetBase = {}
local EPetEventType = import("EPetEventType")
local EAttachmentRule = import("EAttachmentRule")
local UPetEmotionEventInfo = import("PetEmotionEventInfo")
local UPetWaitEventInfo = import("PetWaitEventInfo")
local STExtraBlueprintFunctionLibrary = import("STExtraBlueprintFunctionLibrary")
local KismetSystemLibrary = import("KismetSystemLibrary")
local ParticleSystemComponentClass = import("/Script/Engine.ParticleSystemComponent")
local EMontagePlayReturnType = import("EMontagePlayReturnType")
local AkGameplayStatics = import("AkGameplayStatics")
local GameplayStatics = import("GameplayStatics")
local WidgetLayoutLibrary = import("WidgetLayoutLibrary")
local EActionPattern = import("EPetActionPattern")
local EPetFeatureType = import("EPetFeatureType")
local EPetSlotType = import("EPetSlotType")
local PetUtil = require("GameLua.Mod.BRMod.Gameplay.Actor.Pet.PetUtil")
local MAX_FEATURE_COUNT = EPetFeatureType.MaxCount

local function IsValid(Object)
  return Object and slua.isValid(Object)
end

local function GetAssetByPath(PathString)
  local SoftObjectPath = KismetSystemLibrary.MakeSoftObjectPath(PathString)
  local Asset = STExtraBlueprintFunctionLibrary.GetAssetByAssetReference(SoftObjectPath)
  return Asset
end

local function Contains(Array, ItemToFind)
  for i = 0, Array:Num() - 1 do
    if Array:Get(i) == ItemToFind then
      return true
    end
  end
  return false
end

local function SplitStringToVector(Str, Separator, bToRotator)
  local StringUtil = require("common.string_util")
  local Vector = StringUtil.Split(Str, Separator)
  if bToRotator then
    return FRotator(tonumber(Vector[1]), tonumber(Vector[2]), tonumber(Vector[3]))
  else
    return FVector(tonumber(Vector[1]), tonumber(Vector[2]), tonumber(Vector[3]))
  end
end

function LobbyPetBase:ctor(ClassType)
  self.PlayingMontage = nil
  self.RandomActionHandle = nil
  self.SubAnimationMeshes = {}
  self.PlayingActionID = 0
  self.ActionEndHandle = nil
  self.EnableIdleRandomAction = true
  self.EnabledIdleRandomAction = true
  self.UnlockedActions = slua.Array(UEnums.EPropertyClass.Int)
  self.BlockSound = false
  self.MasterActionID = 0
  self.nUid = nil
  self.HasFixTransform = false
  self.NeedResetTransform = false
  self.InstanceID = 0
  self.Master = nil
  self.ConfigID = 0
  self.PlayingSoundID = 0
  self.bSimulate = false
  self.bEnlargeState = false
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  self.PetShowType = logic_pet.ENUM_PetShowType.Avatar
  self.LastFeatureValue = {}
  self.bReleased = false
  self.effectItemId = 0
  self.playBubbleTimer = nil
  self.playBubbleIndex = nil
  self.switchEffectTimer = nil
  self.switchEffectIndex = nil
  self.playingInEffect = nil
  self.playingOutEffect = nil
  self.extraScale = 1
  self.bAllMeshLoaded = false
end

function LobbyPetBase:ReceiveBeginPlay()
  if self.Super.ReceiveBeginPlay then
    self.Super:ReceiveBeginPlay()
  end
  self:_RegisterPetControlEvents()
  self:StartRandomAction()
  self:CheckToActivateMood()
  self:SetName("")
  if IsValid(self.Mesh) and IsValid(self.Mesh.SkeletalMesh) then
    self.WidgetName:K2_AttachToComponent(self.Mesh, "Bip001-PelvisSocket", EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, true)
    self.WidgetMood:K2_AttachToComponent(self.Mesh, "Bip001-MoodSocket", EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, true)
  end
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_EXHIBITION_START, self.OnExhibitionStart, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_EXHIBITION_END, self.OnExhibitionEnd, self)
  if self.LobbyRotateComponent then
    self.LobbyRotateComponent.CanRotate = true
    self.LobbyRotateComponent.TargetMesh = self.Mesh
  end
  self.CharacterMovement:Deactivate()
  self:SetPetAIEnabled(false)
end

function LobbyPetBase:InitializePet(PetLevelInfo, bSimulate)
  log(bWriteLog and "  LobbyPetBase:InitializePet.  ")
  self.PetLevelInfo = PetLevelInfo
  local PetLevelID = PetLevelInfo.PetID * 10000 + PetLevelInfo.PetLevel
  self:SetConfigID(PetLevelID)
  self.PetEventManager.EventConfigs:Clear()
  self.PetEventManager:InitEventConfigs(true)
  self:InitAvatar()
  self:InitBaseScale()
  self.bSimulate = bSimulate
  self:OnPostInitializePet()
end

function LobbyPetBase:SetUid(uid)
  log(bWriteLog and "LobbyPetBase:SetUid. uid: " .. tostring(uid))
  self.nUid = uid
end

function LobbyPetBase:OnPostInitializePet()
  self:SetupLobbyPetParams()
end

function LobbyPetBase:OnAvatarEquipFinish(InSlotID, NewItemID, OldItemID)
  log(bWriteLog and "LobbyPetBase:OnAvatarEquipFinish. InSlotID: " .. tostring(InSlotID))
  log(bWriteLog and "LobbyPetBase:OnAvatarEquipFinish. NewItemID.TypeSpecificID: " .. tostring(NewItemID.TypeSpecificID))
end

function LobbyPetBase:SetDress(PetAvatarIDs)
  self.PetAvatarIDs = PetAvatarIDs
  log_tree("LobbyPetBase:SetDress. PetAvatarIDs ", PetAvatarIDs)
end

function LobbyPetBase:SetupLobbyPetParams()
  log(bWriteLog and "LobbyPetBase:SetupLobbyPetParams.  ")
  local PetID = self.PetLevelInfo.PetId
  if not PetID or PetID == 0 then
    return
  end
  local LobbyPetParamsCfg, dress
  if PetUtil.IsBird(PetID) then
    if self.Parent then
      dress = self.Parent.DefaultDress
    else
      dress = self.PetAvatarIDs
    end
    if dress then
      for id, _ in pairs(dress) do
        LobbyPetParamsCfg = CDataTable.GetTableData("LobbyPetParams", id)
        if LobbyPetParamsCfg then
          log(bWriteLog and "LobbyPetBase:SetupLobbyPetParams.SetupLobbyPetParams   id: " .. tostring(id))
          break
        end
      end
    end
  end
  LobbyPetParamsCfg = LobbyPetParamsCfg or CDataTable.GetTableData("LobbyPetParams", PetID)
  if not LobbyPetParamsCfg then
    return
  end
  local MeshLocation = self:ParseStrToFVector(LobbyPetParamsCfg.MeshLocation, FVector.ZeroVector)
  local MeshRotation = self:ParseStrToFRotator(LobbyPetParamsCfg.MeshRotation, FRotator.ZeroRotator)
  local MeshScale = self:ParseStrToFVector(LobbyPetParamsCfg.MeshScale, FVector.OneVector)
  self.BaseMeshScale = MeshScale.X
  log(bWriteLog and "LobbyPetBase:SetupLobbyPetParams. LobbyPetParamsCfg.MeshLocation: " .. tostring(LobbyPetParamsCfg.MeshLocation))
  self.Mesh:K2_SetRelativeTransform(FTransform(MeshRotation, MeshLocation, MeshScale), false, nil, false)
  local ParachuteOffset = self:ParseStrToFVector(LobbyPetParamsCfg.ParachuteLocation, FVector.ZeroVector)
  local ParachuteRotation = self:ParseStrToFRotator(LobbyPetParamsCfg.ParachuteRotation, FRotator.ZeroRotator)
  local ParachuteScale = self:ParseStrToFVector(LobbyPetParamsCfg.ParachuteScale, FVector.OneVector)
  self.ParachuteOffset = FTransform(ParachuteRotation, ParachuteOffset, ParachuteScale)
end

function LobbyPetBase:ParseStrToFVector(VectorStr, DefaultVector)
  if not VectorStr or VectorStr == "" then
    return DefaultVector
  end
  local ParsedVector = LobbySceneManager.ParseVec3(VectorStr)
  return FVector(ParsedVector.x_f, ParsedVector.y_f, ParsedVector.z_f)
end

function LobbyPetBase:ParseStrToFRotator(RotatorStr, DefaultRotator)
  if not RotatorStr or RotatorStr == "" then
    return DefaultRotator
  end
  local ParsedRotator = LobbySceneManager.ParseVec3(RotatorStr)
  return FRotator(ParsedRotator.y_f, ParsedRotator.z_f, ParsedRotator.x_f)
end

function LobbyPetBase:InitBaseScale()
  self:ResetPetScale(self.bEnlargeState, true)
end

function LobbyPetBase:ResetPetScale(bEnlargeState, bForceUpdate)
  log(bWriteLog and string.format("LobbyPetBase:ResetPetScale. self=(%s) bEnlargeState=%s bForceUpdate=%s, bIgnoreScale=%s", tostring(self), tostring(bEnlargeState), tostring(bForceUpdate), tostring(self.bIgnoreScale)))
  if not bForceUpdate and self.bIgnoreScale then
    return
  end
  self.bEnlargeState = bEnlargeState
  self.LastFeatureValue[EPetFeatureType.Enlarge] = bEnlargeState and 1 or 0
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local Scale = logic_pet:GetPetBaseScale(self.PetLevelInfo.PetID, self.PetShowType)
  if not Scale then
    return
  end
  local extraScale = self.extraScale or 1
  Scale = Scale * extraScale
  local FinalMeshScale = self.BaseMeshScale or 1
  if self.PetShowType == logic_pet.ENUM_PetShowType.Avatar and bEnlargeState then
    local CurrentPetID = self.PetLevelInfo.PetID
    local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
    if logic_pet:IsPetEnlargeEnabled(CurrentPetID) then
      FinalMeshScale = FinalMeshScale * logic_pet:GetPetScaleOfEnlargeState(CurrentPetID)
    end
  end
  log(bWriteLog and string.format("LobbyPetBase:ResetPetScale. PetID=%s, bEnlargeState=%s Scale=%s, FinaleMeshScale=%s", tostring(self.PetLevelInfo.PetID), tostring(bEnlargeState), tostring(Scale), tostring(FinalMeshScale)))
  self:SetActorScale3D(FVector(Scale, Scale, Scale))
  self.Mesh:SetRelativeScale3D(FVector(FinalMeshScale, FinalMeshScale, FinalMeshScale))
end

function LobbyPetBase:ReceiveTick(DeltaSeconds)
  if not IsValid(self.WidgetMood) then
    return
  end
  local UserWidgetObject = self.WidgetMood:GetUserWidgetObject()
  if not IsValid(UserWidgetObject) then
    return
  end
  UserWidgetObject:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
  self:RefreshMoodTipsVisibility()
end

function LobbyPetBase:OnReceiveEndPlay()
  self:StopActionSound()
  self:Dispose()
end

function LobbyPetBase:InitAvatar()
  local DefaultAvatarConfig = CDataTable.GetTableData("PetDressBlueprintTable", self.PetLevelInfo.PetID)
  if not DefaultAvatarConfig then
    log(bWriteLog and "LobbyPetBase:InitAvatar() - DefaultAvatarConfig is nil")
    return
  end
  local ret = self.PetAvatarComponent_BP:PetEquipItemById(self.PetLevelInfo.PetID)
  self.Mesh:SetCastPhotonShadow(true)
  log(bWriteLog and "  LobbyPetBase:InitAvatar. ret: " .. tostring(ret))
  if not ret then
    self:OnAvatarAllMeshLoaded()
  end
end

function LobbyPetBase:OnAvatarAllMeshLoaded()
  self:ResetPetMaterialOnReuse()
  log(bWriteLog and "LobbyPetBase:OnAvatarAllMeshLoaded PetTypeID: " .. tostring(self.PetLevelInfo.PetID))
  self.Mesh:SetHiddenInGame(false, true)
  self:AddTimer(0.2, function()
    self.bAllMeshLoaded = true
    self:ResetPermanentParticle()
  end)
  self:UpdateMeshColorMaterials(self.PetColor)
  self.WidgetName:K2_AttachToComponent(self.Mesh, "Bip001-PelvisSocket", EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, true)
  self.WidgetMood:K2_AttachToComponent(self.Mesh, "Bip001-MoodSocket", EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, true)
  if self.Parent then
    self.Parent:AttachToMaster()
    if self.Parent.OnPetMeshLoaded then
      self.Parent:OnPetMeshLoaded()
    end
  end
  if not self.bReleased then
    EventSystem:postEvent(EVENTTYPE_PET, EVENTID_PET_AVATAR_REFRESHED, self.InstanceID, self.PetLevelInfo.PetID, self.Mesh)
  end
end

function LobbyPetBase:CheckToActivateMood()
  self:SetActorTickEnabled(self.EnableMood)
  if not IsValid(self.WidgetMood) then
    return
  end
  if not self.EnableMood then
    local Widget = self.WidgetMood:GetUserWidgetObject()
    if IsValid(Widget) then
      Widget:SetWidgetVisibility(UEnums.ESlateVisibility.Collapsed)
    end
    self.WidgetMood:Deactivate()
    self.BP_LobbyPetMoodComponent:Deactivate()
  end
end

function LobbyPetBase:OnPetClicked()
  if self.BP_LobbyPetMoodComponent.InMood then
    self:ResponseMoodAction()
    self.BP_LobbyPetMoodComponent:OnMoodRespone()
  else
    self:PlayClickRandomAction()
  end
end

function LobbyPetBase:OnPetInMood()
  if IsValid(self.PlayingMontage) then
    log(bWriteLog and "[HZA] LobbyPetBase: On Pet Mood: Is playing Montage")
  else
    self:ChangeMoodTip()
    self:OnMoodAction()
    log(bWriteLog and "[HZA] LobbyPetBase: On Pet Mood")
  end
end

function LobbyPetBase:OnPetExitMood()
  log(bWriteLog and "[HZA] LobbyPetBase: On Pet Mood Exit")
end

function LobbyPetBase:OnPetEventTiggered(EventInfo)
  if not IsValid(self.PetEventManager.CurExecuteEvent) then
    log(bWriteLog and "  LobbyPetBase:OnPetEventTiggered.  CurExecuteEvent is nil")
    return
  end
  log(bWriteLog and "  LobbyPetBase:OnPetEventTiggered. self.PetEventManager.CurExecuteEvent.EventType: " .. tostring(self.PetEventManager.CurExecuteEvent.EventType))
  if self.PetEventManager.CurExecuteEvent.EventType == EPetEventType.PlayEmotionEvent then
    self:DownloadMontageAndPlay(self.PetEventManager.CurExecuteEvent.EmotionId)
  elseif self.PetEventManager.CurExecuteEvent.EventType == EPetEventType.PetRandomMontageEvent then
    self.PlayingActionID = self.PetEventManager.CurExecuteEvent.AnimationAssetId
    self:DownloadMontageAndPlay(self.PlayingActionID)
  end
end

function LobbyPetBase:PlayAction(EmotionID)
  if not EmotionID then
    log_error("LobbyPetBase:PlayAction invalid EmotionID")
    return
  end
  local AnimInstance = self.Mesh:GetAnimInstance()
  if IsValid(AnimInstance) and AnimInstance.PlayAction then
    AnimInstance:PlayAction(EmotionID)
    if AnimInstance.DestroySubAnimations then
      AnimInstance:DestroySubAnimations()
    end
  end
  self.PlayingActionID = EmotionID
  local PetEmotionEventInfo = UPetEmotionEventInfo(self)
  PetEmotionEventInfo.EmotionId = EmotionID
  PetEmotionEventInfo.EventType = EPetEventType.PlayEmotionEvent
  local Controller = self:GetController()
  if not IsValid(Controller) then
  end
  self.PetEventManager:TriggerPetEvent(PetEmotionEventInfo)
  self.IsPlayingAction = true
  if self.Parent then
    self.Parent:OnActorPlayAction(EmotionID)
  end
end

function LobbyPetBase:SetParent(parent)
  log(bWriteLog and "LobbyPetBase:SetParent.  ")
  self.Parent = parent
end

function LobbyPetBase:StopAction()
  log(bWriteLog and "LobbyPetBase:StopAction")
  if self.PetLevelInfo and self.PetLevelInfo.PetID == 50038 then
    self:AddTimer(0.17, function()
      if slua.isValid(self.Mesh) then
        local DynamicMat = self.Mesh:GetMaterial(0)
        if slua.isValid(DynamicMat) and DynamicMat.SetScalarParameterValue then
          DynamicMat:SetScalarParameterValue("ElectricEmiss", 0)
        end
      end
    end)
  end
  local AnimInstance = self.Mesh:GetAnimInstance()
  if IsValid(AnimInstance) and IsValid(self.PlayingMontage) then
    if AnimInstance.DestroySubAnimations then
      AnimInstance:DestroySubAnimations()
    end
    AnimInstance:Montage_Stop(0, self.PlayingMontage)
  end
  self.PlayingMontage = nil
  if self.ActionEndHandle then
    self:RemoveTimer(self.ActionEndHandle)
    self.ActionEndHandle = nil
  end
  self.IsPlayingAction = false
  self:StopActionSound()
end

function LobbyPetBase:ResetPlayingAction()
  log(bWriteLog and "LobbyPetBase:ResetPlayingAction")
  local AnimInstance = self.Mesh:GetAnimInstance()
  if IsValid(AnimInstance) and AnimInstance.PlayAction then
    AnimInstance:PlayAction(0)
    if AnimInstance.DestroySubAnimations then
      AnimInstance:DestroySubAnimations()
    end
  end
  self.PlayingActionID = 0
  self.IsPlayingAction = false
end

function LobbyPetBase:RandomAction()
  if IsValid(self.PlayingMontage) then
    log(bWriteLog and "[HZA] LobbyPetBase: LobbyPetBase:RandomAction: Is playing montage")
    return
  end
  if self.BP_LobbyPetMoodComponent.InMood then
    log(bWriteLog and "[HZA] LobbyPetBase: Pet is in Mood")
    return
  end
  if not self:IsInViewport() then
    return
  end
  if self.PlayingActionID ~= 0 then
    local ActionConfig = CDataTable.GetTableData("PetActionTable", self.PlayingActionID)
    if not ActionConfig then
      return
    end
    if not ActionConfig.ActionPattern then
      return
    end
    if ActionConfig.ActionPattern == EActionPattern.Walk or ActionConfig.ActionPattern == EActionPattern.Run or ActionConfig.ActionPattern == EActionPattern.Parachute or ActionConfig.ActionPattern == EActionPattern.Swimming then
      return
    end
  end
  self:OnRandomAction()
end

function LobbyPetBase:OnRandomAction()
  if not self.EnableIdleRandomAction then
    return
  end
  local PetWaitEventInfo = UPetWaitEventInfo(self)
  PetWaitEventInfo.EventType = EPetEventType.PetRandomMontageEvent
  local Controller = self:GetController()
  if not IsValid(Controller) then
    self:SpawnDefaultController()
  end
  self.PetEventManager:TriggerPetEvent(PetWaitEventInfo)
end

function LobbyPetBase:DestroyParticles(Actor)
  if not IsValid(Actor) then
    Actor = self
  end
  local ParticleSystemComponent = Actor:GetComponentByClass(ParticleSystemComponentClass)
  while IsValid(ParticleSystemComponent) do
    ParticleSystemComponent:K2_DestroyComponent()
    ParticleSystemComponent = Actor:GetComponentByClass(ParticleSystemComponentClass)
  end
end

function LobbyPetBase:DownloadMontageAndPlay(ID)
  log(bWriteLog and "LobbyPetBase:DownloadMontageAndPlay :" .. tostring(ID))
  self:PlayActionSound(ID)
  self.PlayingActionID = ID
  local ActionConfig = CDataTable.GetTableData("PetActionTable", ID)
  if not ActionConfig then
    return
  end
  local RealPetAnimRes
  if self.PetAvatarComponent_BP then
    RealPetAnimRes = self.PetAvatarComponent_BP:GetMappedAssetPath(ActionConfig.LobbyPetAnimRes)
  else
    RealPetAnimRes = ActionConfig.LobbyPetAnimRes
  end
  self.NeedResetTransform = ActionConfig.NeedResetTransform ~= 0
  
  local function callback()
    if self.PlayingActionID ~= ID then
      return
    end
    local AnimMontage = GetAssetByPath(RealPetAnimRes)
    if IsValid(AnimMontage) then
      local Mesh = self.Mesh
      if IsValid(Mesh) then
        local AnimInstance = Mesh:GetAnimInstance()
        if IsValid(AnimInstance) and AnimInstance.SetPetMontageId then
          AnimInstance:RegisterOnPlay()
          AnimInstance:SetPetMontageId(ID)
        end
        self:PlayMontage(AnimMontage, ID)
      end
    end
  end
  
  local isLobby = GameStatus.IsInLobbyOrMainCity()
  local pak_util = require("client.common.pak_util")
  if not isLobby and pak_util.IsPufferDownloaded(RealPetAnimRes) then
    callback()
  else
    pak_util.CheckAndDownloadWithCallback(RealPetAnimRes, callback)
  end
end

local NoRotateActionTb = {
  [50001013] = 1,
  [50001015] = 1
}

function LobbyPetBase:EnableRotate(bEnable)
  if not self.Parent then
    return
  end
  local isSpecial
  local FlyBtIdTb = PetUtil.GetFlyBtIdTb()
  for id, _ in pairs(FlyBtIdTb) do
    if self.Parent:HasEquiped(id) then
      isSpecial = true
    end
  end
  log(bWriteLog and "LobbyPetBase:EnableRotate. bEnable: " .. tostring(bEnable))
  if isSpecial then
    log(bWriteLog and "LobbyPetBase:EnableRotate real. bEnable: " .. tostring(bEnable))
    self.LobbyRotateComponent:EnableRotation(bEnable)
    local Master = self.Parent and self.Parent.Master
    if Master then
      local model = Master:GetModel()
      if model then
        model:SetCanRotate(bEnable)
      end
    end
  end
end

function LobbyPetBase:ForceEnableRotate(bEnable)
  log(bWriteLog and "LobbyPetBase:ForceEnableRotate real. bEnable: " .. tostring(bEnable))
  if slua.isValid(self.LobbyRotateComponent) then
    self.LobbyRotateComponent:EnableRotation(bEnable)
  end
end

function LobbyPetBase:PlayMontage(AnimMontage, ID)
  if ID then
    if NoRotateActionTb[ID] then
      self:EnableRotate(false)
    else
      self:EnableRotate(true)
    end
  end
  if self.ActionEndHandle then
    self:RemoveTimer(self.ActionEndHandle)
    self.ActionEndHandle = nil
  end
  if not slua.isValid(self.Mesh) then
    return
  end
  self.PlayingMontage = AnimMontage
  local AnimInstance = self.Mesh:GetAnimInstance()
  if AnimInstance then
    local Duration = AnimInstance:Montage_Play(self.PlayingMontage, 1, EMontagePlayReturnType.Duration, 0) - 0.15
    if Duration < 0 then
      Duration = 0
    end
    self.ActionEndHandle = self:AddTimerOnce(Duration, function()
      self:OnActionEnd(ID)
    end)
  end
  if self.NeedResetTransform and self.HasFixTransform then
    self:UpdateDefaultTransform()
  end
end

function LobbyPetBase:OnActionEnd(ID)
  log(bWriteLog and "LobbyPetBase:OnActionEnd. ID: " .. tostring(ID))
  if ID and NoRotateActionTb[ID] then
    self:EnableRotate(true)
  end
  self:StopAction()
  self.PlayingMontage = nil
  if self.ActionEndHandle then
    self:RemoveTimer(self.ActionEndHandle)
    self.ActionEndHandle = nil
  end
  self.OnActionEndEvent:BroadCast()
  if IsValid(self.Master) then
    self:FixTransformByEquipments()
  end
  if self.BP_LobbyPetMoodComponent.InMood then
    self:ChangeMoodTip()
  end
end

function LobbyPetBase:PlayClickRandomAction()
  assert(self.PetLevelInfo.PetID ~= 0, "LobbyPetBase:PlayClickRandomAction PetLevelInfo must be setted")
  local PetConfigData = CDataTable.GetTableData("PetTable", self.PetLevelInfo.PetID)
  local ClickAction = PetConfigData.ClickAction
  local StringUtil = require("common.string_util")
  local ClickActionList = StringUtil.Split(tostring(ClickAction), "|")
  if 0 < #ClickActionList then
    local RandomSelected = math.random(#ClickActionList)
    self:PlayAction(tonumber(ClickActionList[RandomSelected]))
    log(bWriteLog and "[HZA] LobbyPetBase.PlayClickRandomAction: clicked to play action: " .. tostring(ClickActionList[RandomSelected]))
  end
end

function LobbyPetBase:EnableRandomAction(bEnable)
  log(bWriteLog and "  LobbyPetBase:EnableRandomAction. bEnable: " .. tostring(bEnable))
  self.EnableIdleRandomAction = bEnable
  if not bEnable then
    self:StopActionSound()
  end
end

local PetSoundMap = {
  [50003006] = "/Game/WwiseEvent/Activity/Activity_140/Pet_140/Play_Pet_Godzilla.Play_Pet_Godzilla",
  [50003007] = "/Game/WwiseEvent/Activity/Activity_140/Pet_140/Play_Pet_Godzilla.Play_Pet_Godzilla",
  [50004005] = "/Game/WwiseEvent/Activity/Activity_140/Pet_140/Play_Pet_Kong_Hit_Chest.Play_Pet_Kong_Hit_Chest",
  [50004006] = "/Game/WwiseEvent/Activity/Activity_140/Pet_140/Play_Pet_Kong.Play_Pet_Kong",
  [50004007] = "/Game/WwiseEvent/Activity/Activity_140/Pet_140/Play_Pet_Kong.Play_Pet_Kong",
  [50005008] = "/Game/WwiseEvent/Activity/Activity_170/Pet_Poro_170/Play_Pet_Poro_170.Play_Pet_Poro_170"
}

function LobbyPetBase:PlayActionSound(ActionID)
  if self.BlockSound then
    return
  end
  local settingConfig = slua_GameFrontendHUD:GetUserSettings()
  if settingConfig and not settingConfig.OpenPetSound then
    log(bWriteLog and "LobbyPetBase:PlayActionSound OpenPetSound = false")
    return
  end
  self:StopActionSound()
  local audio = PetSoundMap[ActionID]
  if self:IsInViewport() and audio then
    local audio_util = require("client.common.audio_util")
    self.PlayingSoundID = audio_util.PlayAudio(audio)
  end
end

function LobbyPetBase:StopActionSound()
  if self.PlayingSoundID and self.PlayingSoundID ~= 0 then
    AkGameplayStatics.StopPlayingID(self.PlayingSoundID)
  end
end

function LobbyPetBase:UpdateActorPos()
  local LobbyPetParamsCfg
  if self.Parent then
    LobbyPetParamsCfg = self.Parent:GetOneDressCfg()
  end
  if LobbyPetParamsCfg then
    local actorLoc = self:ParseStrToFVector(LobbyPetParamsCfg.ActorLocation, FVector.ZeroVector)
    self:K2_SetActorRelativeLocation(actorLoc, false, nil, true)
  else
    local NewRelativeLocation = self.PetEntity.AttachInfo.AttachOffset
    self:K2_SetActorRelativeLocation(NewRelativeLocation, false, nil, true)
  end
  local NewRelativeRotation = self.PetEntity.AttachInfo.AttachRotation
  self:K2_SetActorRelativeRotation(NewRelativeRotation, false, nil, true)
  if LobbyPetParamsCfg and LobbyPetParamsCfg.ActorRotation ~= "" then
    log(bWriteLog and "LobbyPetBase:UpdateActorPos. LobbyPetParamsCfg.ActorRotation: " .. tostring(LobbyPetParamsCfg.ActorRotation))
    local actorRotation = self:ParseStrToFRotator(LobbyPetParamsCfg.ActorRotation, FRotator.ZeroRotator)
    self:K2_SetActorRelativeRotation(actorRotation, false, nil, true)
  else
    self:K2_SetActorRelativeRotation(self.PetEntity.AttachInfo.AttachRotation, false, nil, true)
  end
end

function LobbyPetBase:AttachToCharacter(Player)
  local AttachSocketName = self.PetEntity.AttachInfo.AttachSocketName
  self:K2_AttachToComponent(Player.Mesh, AttachSocketName, EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, true)
  self:UpdateActorPos()
  self:FixTransformByEquipments()
end

function LobbyPetBase:OnExhibitionStart(_, __, UID, PlayerKey)
  if tonumber(UID) == tonumber(DataMgr.roleData.uid) then
    self.isShowExhibition = true
    self:CloseMoodUI()
  end
end

function LobbyPetBase:OnExhibitionEnd(_, __, UID, PlayerKey)
  if tonumber(UID) == tonumber(DataMgr.roleData.uid) then
    self.isShowExhibition = nil
    log(bWriteLog and "  LobbyPetBase:OnExhibitionEnd.  my exihbition end")
  end
end

function LobbyPetBase:OnMasterPlayAction(ActionID)
  if not self.PetLevelInfo or self.PetLevelInfo.PetID == 0 then
    log_warning("LobbyPetBase:OnMasterPlayAction PetLevelInfo must be setted")
    return
  end
  self.MasterActionID = ActionID
  log(bWriteLog and "[HZA] LobbyPetBase.OnMasterPlayAction: " .. tostring(ActionID))
  local PetExhibitConfig = require("client.lobby_ue_object.Actor.PetExhibit.PetExhibitConfig")
  if ActionID ~= PetExhibitConfig.PlayerActionID then
    self:SetVisible(true)
  end
  local PetPlayerEmoteConfig = CDataTable.GetTableData("PetPlayerEmoteTable", tostring(ActionID) .. "_" .. tostring(self.PetLevelInfo.PetID))
  if not PetPlayerEmoteConfig then
    return
  end
  local UnlocakAnimIds = self:GetPetUnlockAnimIds()
  self:SetVisible(PetPlayerEmoteConfig.PetResponse == 0)
  if Contains(UnlocakAnimIds, PetPlayerEmoteConfig.PetAnimID) then
    self:PlayAction(PetPlayerEmoteConfig.PetAnimID)
  end
end

function LobbyPetBase:OnMasterStopAction(ActionID)
  self.MasterActionID = 0
  log(bWriteLog and "[HZA] LobbyPetBase.OnMasterStopAction: " .. tostring(ActionID))
  local PetExhibitConfig = require("client.lobby_ue_object.Actor.PetExhibit.PetExhibitConfig")
  if ActionID ~= PetExhibitConfig.PlayerActionID then
    self:SetVisible(true)
  end
end

function LobbyPetBase:SetMaster(LobbyAvatar)
  if IsValid(self.Master) then
    self:RemoveControlEvent(self.Master, "OnPlayAction")
    self:RemoveControlEvent(self.Master, "OnStopAction")
    self:RemoveControlEvent(self.Master, "EmoteMontageFinishedEvent")
    self:RemoveControlEvent(self.Master, "OnChangeEquipment")
  end
  if IsValid(LobbyAvatar) then
    self.Master = LobbyAvatar
    self:AddControlEvent(self.Master, "OnPlayAction", self.OnMasterPlayAction, self)
    self:AddControlEvent(self.Master, "OnStopAction", self.OnMasterStopAction, self)
    self:AddControlEvent(self.Master, "EmoteMontageFinishedEvent", self.OnMasterStopAction, self)
    self:AddControlEvent(self.Master, "OnChangeEquipment", self.FixTransformByEquipments, self)
  end
end

function LobbyPetBase:UpdateVisibleByMasterAction()
  self:SetVisible(true)
  local PetPlayerEmoteConfig = CDataTable.GetTableData("PetPlayerEmoteTable", tostring(self.Master.CurrentActionID) .. "_" .. tostring(self.PetLevelInfo.PetID))
  if not PetPlayerEmoteConfig then
    return
  end
  self:SetVisible(PetPlayerEmoteConfig.PetResponse == 0)
end

function LobbyPetBase:FixTransformByEquipments()
  if not IsValid(self.Master) then
    return
  end
  if self.Parent then
    local LobbyPetParamsCfg = self.Parent:GetOneDressCfg()
    if LobbyPetParamsCfg then
      log(bWriteLog and "LobbyPetBase:FixTransformByEquipments.  ignore")
      return
    end
  end
  assert(self.PetLevelInfo.PetID ~= 0, "LobbyPetBase:FixTransformByEquipments PetLevelInfo must be setted")
  local MasterEeuipments = self.Master:GetAllEquipmentList()
  local Priority = -1
  local TempID
  for i, v in ipairs(MasterEeuipments) do
    local PetPlayerOffset = CDataTable.GetTableData("PetPlayerOffsetTable", tostring(v) .. "_" .. tostring(self.PetLevelInfo.PetID))
    if PetPlayerOffset and Priority < PetPlayerOffset.Priority then
      Priority = PetPlayerOffset.Priority
      TempID = PetPlayerOffset.ItemPetId
    end
  end
  if TempID then
    local PremierPetPlayerOffset = CDataTable.GetTableData("PetPlayerOffsetTable", TempID)
    if PremierPetPlayerOffset then
      log(bWriteLog and "[HZA]LobbyPetBase:FixTransformByEquipments TempID: " .. tostring(TempID))
      local RelativeLocation = SplitStringToVector(PremierPetPlayerOffset.RelativeLocation, ";", false)
      self:K2_SetActorRelativeLocation(RelativeLocation, false, nil, true)
      local RelativeRotation = SplitStringToVector(PremierPetPlayerOffset.RelativeRotation, ";", true)
      self:K2_SetActorRelativeRotation(RelativeRotation, false, nil, true)
      self.HasFixTransform = true
    elseif self.HasFixTransform then
      self:UpdateDefaultTransform()
    end
  end
end

function LobbyPetBase:UpdateDefaultTransform()
  if not IsValid(self.Master) then
    return
  end
  self:UpdateActorPos()
  self:K2_SetActorRelativeRotation(self.PetEntity.AttachInfo.AttachRotation, false, nil, true)
end

function LobbyPetBase:GetPetUnlockAnimIds()
  if self.UnlockedActions:Num() > 0 then
    return self.UnlockedActions
  end
  if self.PetLevelInfo.PetID == 0 then
    return
  end
  local PetLevelConfig = CDataTable.GetTableData("PetLevelTable", self.ConfigID)
  if not PetLevelConfig then
    return self.UnlockedActions
  end
  local StringUtil = require("common.string_util")
  if PetLevelConfig.AllAction ~= "" then
    local AllActions = StringUtil.Split(PetLevelConfig.AllAction, "|")
    for i, v in ipairs(AllActions) do
      local actionID = tonumber(v)
      if actionID then
        self.UnlockedActions:Add(actionID)
      end
    end
  end
  return self.UnlockedActions
end

function LobbyPetBase:GetPetAnimLimitePlayerState(AnimId)
  return ""
end

function LobbyPetBase:SetPetAIEnabled(bAIEnabled)
  self.IsEnableAI = bAIEnabled
end

function LobbyPetBase:ChangeMoodTip()
  if self.isShowExhibition then
    log(bWriteLog and "  LobbyPetBase:ChangeMoodTip.  isShowExhibition")
    return
  end
  if self.EnableMood then
    local ClassPath = self.BP_LobbyPetMoodComponent.CurrentMoodConfig.MoodWidgetClass
    if self.bHidden then
      log(bWriteLog and "  LobbyPetBase:ChangeMoodTip.  is hidden")
      return
    end
    log(bWriteLog and "  LobbyPetBase:ChangeMoodTip. ClassPath: " .. tostring(ClassPath))
    if ClassPath and ClassPath ~= "" then
      local MoodWidget = slua.loadUI(self.BP_LobbyPetMoodComponent.CurrentMoodConfig.MoodWidgetClass)
      if IsValid(MoodWidget) then
        self.WidgetMood:SetWidget(MoodWidget)
      end
    end
  end
end

function LobbyPetBase:OnMoodAction()
  local actionId = self.BP_LobbyPetMoodComponent.CurrentMoodConfig.OnMoodActionId
  log(bWriteLog and "[HZA] LobbyPetBase:OnMoodAction: " .. tostring(actionId))
  if actionId ~= 0 then
    self:PlayAction(actionId)
  end
end

function LobbyPetBase:ResponseMoodAction()
  local ActionConfig = CDataTable.GetTableData("PetActionTable", self.BP_LobbyPetMoodComponent.CurrentMoodConfig.ResponeMoodActionId)
  if not ActionConfig then
    return
  end
  log(bWriteLog and "[HZA] LobbyPetBase:OnMoodAction: " .. tostring(self.BP_LobbyPetMoodComponent.CurrentMoodConfig.OnMoodActionId))
  self:PlayAction(self.BP_LobbyPetMoodComponent.CurrentMoodConfig.ResponeMoodActionId)
  if not IsValid(self.Master) then
    return
  end
  if ActionConfig.MasterActionID and ActionConfig.MasterActionID ~= 0 then
    local PlayerUID = self.Master:GetPlayerUID()
    if PlayerUID then
      local TeamAvatarManager = require("client.logic.avatar.logic_team_avatar_manager")
      TeamAvatarManager.StopAction(PlayerUID)
    end
    self.Master:CharPlayEmoteByResId(ActionConfig.MasterActionID, "")
  end
end

function LobbyPetBase:RefreshMoodTipsVisibility()
  if not self.EnableMood then
    return
  end
  local MoodWidget = self.WidgetMood:GetUserWidgetObject()
  MoodWidget:SetWidgetVisibility(UEnums.ESlateVisibility.Hidden)
  if not IsValid(self.Master) then
    return
  end
  if IsValid(self.PlayingMontage) then
    return
  end
  if not self.BP_LobbyPetMoodComponent.InMood then
    return
  end
  local LogicLobby = require("client.slua.logic.lobby.logic_lobby_main")
  if not LogicLobby.isCurrentShow then
    return
  end
  local MasterRotation = self.Master.CapsuleComponent:K2_GetComponentRotation()
  if math.abs(MasterRotation.Yaw) <= 30 then
    MoodWidget:SetWidgetVisibility(UEnums.ESlateVisibility.Visible)
  end
end

function LobbyPetBase:SetVisible(bVisible)
  self:SetActorHiddenInGame(not bVisible)
end

function LobbyPetBase:SetName(InName)
  local NameWidget = self.WidgetName:GetUserWidgetObject()
  if not IsValid(NameWidget) then
    return
  end
  NameWidget.PetName:SetText(InName)
end

function LobbyPetBase:SetConfigID(ConfigID)
  self.ConfigID = ConfigID
  assert(self.ConfigID ~= 0, "LobbyPetBase:SetConfigID PetLevelInfo must be setted first")
  self.BP_LobbyPetMoodComponent:SetPetType(self.PetLevelInfo.PetID)
end

function LobbyPetBase:DisableSound(bDisable)
  self.BlockSound = bDisable
end

function LobbyPetBase:IsInViewport()
  local Controller = GameplayStatics.GetPlayerController(self, 0)
  local bResult, ScreenPosition = GameplayStatics.ProjectWorldToScreen(Controller, self:K2_GetActorLocation(), FVector2D(0, 0), false)
  if not bResult then
    return false
  end
  if not (0 < ScreenPosition.X) then
    return false
  end
  if not (0 < ScreenPosition.Y) then
    return false
  end
  local ViewportSize = WidgetLayoutLibrary.GetViewportSize(self) * 1.5
  if not (ScreenPosition.X < ViewportSize.X) then
    return false
  end
  if not (ScreenPosition.Y < ViewportSize.Y) then
    return false
  end
  return true
end

function LobbyPetBase:UpdateMeshColorMaterials(SpeciefiedColor)
  log(bWriteLog and string.format("LobbyPetBase:UpdateMeshColorMaterials. SpeciefiedColor=%s", tostring(SpeciefiedColor)))
  if not slua.isValid(self.Mesh) then
    return
  end
  if self.PetLevelInfo.PetID ~= ENUM_LOBBYPET_TYPE.TYPE_BLOCKBEARDROP then
    return
  end
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local PetData = logic_pet:GetPetDataByPetItemID(self.PetLevelInfo.PetID) or {}
  if not next(PetData) and not SpeciefiedColor then
    return
  end
  if not PetData.color and not SpeciefiedColor then
    return
  end
  if self.bSimulate then
    self.PetColor = SpeciefiedColor or self.PetColor
  else
    self.PetColor = SpeciefiedColor or PetData.color or self.PetColor
  end
  if not self.PetColor then
    return
  end
  log(bWriteLog and "LobbyPetBase:UpdateMeshColorMaterials PetColor:" .. tostring(self.PetColor) .. ", SpeciefiedColor:" .. tostring(SpeciefiedColor))
  local PetConfig = require("client.slua.logic.pet.pet_config")
  local ColorConfig = PetConfig.ColorConfig
  local ColorMaterials = ColorConfig[self.PetColor]
  if not ColorMaterials then
    return
  end
  local STExtraGameInstance = import("STExtraGameInstance")
  local GameInstance = STExtraGameInstance.GetInstance()
  local DeviceLevel = GameInstance:GetDeviceLevel()
  local Util = require("client.slua_ui_framework.util")
  if DeviceLevel <= 0 then
    Util.GetAssetAsync(ColorMaterials.LowDeviceMaterial, function(MaterialInstance)
      if self.Mesh and slua.isValid(self.Mesh) then
        self.Mesh:SetMaterial(0, MaterialInstance)
      end
    end)
  else
    for SlotID, MatPath in pairs(ColorMaterials.HighDeviceMaterials) do
      Util.GetAssetAsync(MatPath, function(MaterialInstance)
        if self.Mesh and slua.isValid(self.Mesh) then
          self.Mesh:SetMaterial(SlotID, MaterialInstance)
        end
      end)
    end
  end
end

function LobbyPetBase:SetPetShowType(ShowType, bIgnoreScale)
  print(bWriteLog and "LobbyPetBase:SetPetShowType. ", ShowType, bIgnoreScale)
  if not ShowType then
    local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
    ShowType = logic_pet.ENUM_PetShowType.Avatar
  end
  self.PetShowType = ShowType
  if not bIgnoreScale then
    self:ResetPetScale(self.bEnlargeState)
  end
end

function LobbyPetBase:StartRandomAction()
  self:StopRandomAction()
  log(bWriteLog and "LobbyPetBase:StartRandomAction. self.RandomInterval: " .. tostring(self.RandomInterval))
  self.RandomActionHandle = self:AddTimerLoop(self.RandomInterval, function(DeltaTime)
    self:RandomAction()
  end, TIMER_INFINITE, self.RandomInterval)
end

function LobbyPetBase:StopRandomAction()
  if self.RandomActionHandle then
    self:RemoveTimer(self.RandomActionHandle)
    self.RandomActionHandle = nil
  end
end

function LobbyPetBase:ResetPermanentParticle()
  log(bWriteLog and "LobbyPetBase:ResetPermanentParticle. ")
  if not IsValid(self.Object) then
    log(bWriteLog and "LobbyPetBase:ResetPermanentParticle. Object is not valid.")
    return
  end
  local ParticleComponentClass = import("/Script/Engine.ParticleSystemComponent")
  local ParticleArray = self.Object:GetComponentsByTag(ParticleComponentClass, "PetPermanent")
  if ParticleArray and ParticleArray:Num() > 0 then
    for i = 0, ParticleArray:Num() - 1 do
      local Particle = ParticleArray:Get(i)
      if IsValid(Particle) then
        Particle:Activate(true)
        Particle:SetVisibility(true, false)
      end
    end
  end
end

function LobbyPetBase:DestroyPetPermanentParticle()
  log(bWriteLog and "LobbyPetBase:DestroyPetPermanentParticle. ")
  if not IsValid(self.Object) then
    log(bWriteLog and "LobbyPetBase:DestroyPetPermanentParticle. Object is not valid")
    return
  end
  local ParticleComponentClass = import("/Script/Engine.ParticleSystemComponent")
  local ParticleArray = self.Object:GetComponentsByTag(ParticleComponentClass, "PetPermanent")
  if ParticleArray and ParticleArray:Num() > 0 then
    for i = 0, ParticleArray:Num() - 1 do
      local Particle = ParticleArray:Get(i)
      if IsValid(Particle) then
        Particle:K2_DestroyComponent(Particle)
      end
    end
  end
end

function LobbyPetBase:OnPetFeatureDataChanged()
  log(bWriteLog and "LobbyPetBase:OnPetFeatureDataChanged. ")
  for FeatureType = 0, MAX_FEATURE_COUNT - 1 do
    local OldValue = self.LastFeatureValue[FeatureType]
    local NewValue = self.PetFeatureData:Get(FeatureType) or 0
    if OldValue ~= NewValue then
      self:OnSingleFeatureDataChange(FeatureType, OldValue, NewValue)
    end
    self.LastFeatureValue[FeatureType] = NewValue
  end
end

function LobbyPetBase:OnSingleFeatureDataChange(FeatureType, OldValue, NewValue)
  log(bWriteLog and string.format("LobbyPetBase:OnSingleFeatureDataChange. FeatureType=%s, OldValue=%s, NewValue=%s", tostring(FeatureType), tostring(OldValue), tostring(NewValue)))
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  if FeatureType == EPetFeatureType.Enlarge then
    if self.PetShowType ~= logic_pet.ENUM_PetShowType.Avatar then
      return
    end
    self:ResetPetScale(NewValue == 1)
  end
end

function LobbyPetBase:OnEnlargeStateChanged(_, __, PetID, EnlargeValue)
  log(bWriteLog and string.format("LobbyPetBase:OnEnlargeStateChanged. PetID=%s, EnlargeValue=%s", tostring(PetID), tostring(EnlargeValue)))
  if self.PetLevelInfo.PetID ~= PetID then
    return
  end
  local uid = self.nUid
  log(bWriteLog and "LobbyPetBase:OnEnlargeStateChanged. uid: " .. tostring(uid))
  if uid and tostring(uid) ~= DataMgr.roleData.uid then
    log(bWriteLog and "LobbyPetBase:OnEnlargeStateChanged.  is not my pet")
    return
  end
  self:SetPetFeatureValue(EPetFeatureType.Enlarge, EnlargeValue or 0)
end

function LobbyPetBase:OnLobbyMusicOn()
  self:DisableSound(false)
end

function LobbyPetBase:OnLobbyMusicOff()
  self:DisableSound(true)
end

function LobbyPetBase:SetRandomEmotion(BPID, bRemove)
  local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
  local EquipEmotionID = logic_pet:GetEquipEmotionIDByBPID(BPID)
  if not EquipEmotionID then
    return
  end
  if 0 < EquipEmotionID and self.PetEventManager then
    local Weight = logic_pet:GetDressActionWeightID(BPID)
    local ActionConfig = CDataTable.GetTableData("PetActionTable", EquipEmotionID)
    if ActionConfig and ActionConfig.IsShowInWorkshop == 1 and ActionConfig.ShowInLobby == 1 then
      log(bWriteLog and "LobbyPetBase:SetRandomEmotion _equipEmotionID:" .. tostring(EquipEmotionID) .. " ,Weight:" .. tostring(Weight) .. " ,bRemove:" .. tostring(bRemove))
      local PetMontageConfig = import("PetMontageConfig")
      local MontageConfig = PetMontageConfig()
      MontageConfig.AnimationAssetId = EquipEmotionID
      MontageConfig.Weight = Weight
      local EPetEventType = import("EPetEventType")
      self.PetEventManager:AddPetMontageConfig(MontageConfig, EPetEventType.PetRandomMontageEvent, bRemove)
    end
    if bRemove then
      self:StopAction()
    end
  end
end

function LobbyPetBase:UpdateStreamingTextureMipOffset(bShowHigh)
  if not IsValid(self.Mesh) then
    log(bWriteLog and "LobbyPetBase:UpdateStreamingTextureMipOffset Mesh is not valid")
    return
  end
  local MeshMaterials = self.Mesh:GetMaterials()
  if MeshMaterials then
    for Index, MeshMaterial in pairs(MeshMaterials) do
      if MeshMaterial then
        if bShowHigh then
          MeshMaterial:SetStreamingTextureMipOffset(1, false)
        else
          MeshMaterial:SetStreamingTextureMipOffset(0, false)
        end
        log(bWriteLog and "LobbyPetBase:UpdateStreamingTextureMipOffset Index:" .. tostring(Index) .. ", bShowHigh: " .. tostring(bShowHigh))
      end
    end
  end
end

function LobbyPetBase:SetBPPath(BPPath)
  self._BPPath = BPPath
end

function LobbyPetBase:GetBPPath()
  return self._BPPath
end

function LobbyPetBase:OnPawnReleased()
  log(bWriteLog and "  LobbyPetBase:OnPawnReleased.  " .. tostring(self))
  self.bIgnoreScale = nil
  self.Parent = nil
  self.Master = nil
  self.bReleased = true
  self:_UnRegisterPetControlEvents()
  self:UnequipAllSlots()
  self:ResetPlayingAction()
  self:DestroyPetPermanentParticle()
  self:SetActorHiddenInGame(true)
  self:SetActorTickEnabled(false)
  self:StopSwitchEffect()
  self:StopBubble()
  self:CloseMoodUI()
  self:StopAction()
  self:K2_SetActorRelativeLocation(FVector(-99999, -99999, -99999), false, nil, false)
  if slua.isValid(self.Mesh) then
    self.Mesh:K2_AttachToComponent(self:K2_GetRootComponent(), "None", EAttachmentRule.KeepRelative, EAttachmentRule.KeepRelative, EAttachmentRule.KeepWorld, true)
    self.Mesh:K2_SetRelativeRotation(FRotator(0, -90, 0), false, nil, false)
    self.Mesh:SetHiddenInGame(true, true)
  end
  self:K2_DetachFromActor(1, 1, 1)
  EventSystem:postEvent(EVENTTYPE_PET, EVENTID_PET_AVATAR_REFRESHED)
  if self.PetLevelInfo.PetID == ENUM_LOBBYPET_TYPE.TYPE_BLOCKBEARDROP then
    local STExtraGameInstance = import("STExtraGameInstance")
    local GameInstance = STExtraGameInstance.GetInstance()
    local DeviceLevel = GameInstance:GetDeviceLevel()
    if slua.isValid(self.Mesh) then
      if DeviceLevel <= 0 then
        self.Mesh:SetMaterial(0, nil)
      else
        local PetConfig = require("client.slua.logic.pet.pet_config")
        local ColorConfig = PetConfig.ColorConfig
        local ColorMaterials = ColorConfig[self.PetColor]
        if ColorMaterials then
          for SlotID, _ in pairs(ColorMaterials.HighDeviceMaterials) do
            self.Mesh:SetMaterial(SlotID, nil)
          end
        end
      end
    end
  end
  self.extraScale = 1
end

function LobbyPetBase:OnPawnReused()
  self.bReleased = false
  self:_RegisterPetControlEvents()
  self:SetActorHiddenInGame(false)
  self:SetActorTickEnabled(true)
  self:ResetPetMaterialOnReuse()
  if slua.isValid(self.Mesh) then
    self.Mesh:K2_SetRelativeLocation(FVector.ZeroVector, false, nil, false)
  end
end

function LobbyPetBase:GetPetLevelInfo()
  return self.PetLevelInfo
end

function LobbyPetBase:CloseMoodUI()
  self.WidgetMood:SetWidget(nil)
end

function LobbyPetBase:UnequipAllSlots()
  log(bWriteLog and "LobbyPetBase:UnequipAllSlots")
  if slua.isValid(self.PetAvatarComponent_BP) then
    self.PetAvatarComponent_BP:HandleUnequipSlot(EPetSlotType.EPetSlotType_Body)
    self.PetAvatarComponent_BP:HandleUnequipSlot(EPetSlotType.EPetSlotType_Suit)
    self.PetAvatarComponent_BP:HandleUnequipSlot(EPetSlotType.EPetSlotType_Hat)
    self.PetAvatarComponent_BP:HandleUnequipSlot(EPetSlotType.EPetSlotType_Jacket)
  end
end

function LobbyPetBase:_RegisterPetControlEvents()
  log(bWriteLog and "LobbyPetBase:_RegisterPetControlEvents")
  if self.PetEventManager and self.PetEventManager.OnPetEventDelegate then
    self:AddControlEvent(self.PetEventManager, "OnPetEventDelegate", self.OnPetEventTiggered, self)
    log(bWriteLog and "LobbyPetBase:_RegisterPetControlEvents Register OnPetEventDelegate")
  end
  if slua.isValid(self.LobbyRotateComponent) and slua.isValid(self.RotateCapsule) and self.RotateCapsule.OnInputTouchBegin and self.RotateCapsule.OnInputTouchEnd then
    self:AddControlEvent(self.RotateCapsule, "OnInputTouchBegin", self.LobbyRotateComponent.OnTouchBegin, self.LobbyRotateComponent)
    self:AddControlEvent(self.RotateCapsule, "OnInputTouchEnd", self.LobbyRotateComponent.OnTouchEnd, self.LobbyRotateComponent)
  end
  if slua.isValid(self.LobbyRotateComponent) and self.LobbyRotateComponent.OnClicked then
    self:AddControlEvent(self.LobbyRotateComponent, "OnClicked", self.OnPetClicked, self)
  end
  if slua.isValid(self.BP_LobbyPetMoodComponent) and self.BP_LobbyPetMoodComponent.OnInMoodEvent and self.BP_LobbyPetMoodComponent.OnExitMoodEvent then
    self:AddControlEvent(self.BP_LobbyPetMoodComponent, "OnInMoodEvent", self.OnPetInMood, self)
    self:AddControlEvent(self.BP_LobbyPetMoodComponent, "OnExitMoodEvent", self.OnPetExitMood, self)
  end
  if slua.isValid(self.PetAvatarComponent_BP) and self.PetAvatarComponent_BP.OnAvatarAllMeshLoaded then
    self:AddControlEvent(self.PetAvatarComponent_BP, "OnAvatarAllMeshLoaded", self.OnAvatarAllMeshLoaded, self)
  end
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_GET_PET_DATA, self.UpdateMeshColorMaterials, self)
  self:AddCommonEvent(EVENTTYPE_PET, EVENTID_PET_MODEL_ENLARGE_STATE_CHANGE, self.OnEnlargeStateChanged, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVENTID_LOBBY_MUSIC_OFF, self.OnLobbyMusicOff, self)
  self:AddCommonEvent(EVENTTYPE_LOBBY, EVENTID_LOBBY_MUSIC_ON, self.OnLobbyMusicOn, self)
  self:AddCommonEvent(EVENTTYPE_CAMERA, EVENTID_CAMERA_SWITCHED, self.StopActionSound, self)
end

function LobbyPetBase:_UnRegisterPetControlEvents()
  log(bWriteLog and "LobbyPetBase:_UnRegisterPetControlEvents")
  if slua.isValid(self.PetEventManager) and self.PetEventManager.OnPetEventDelegate then
    self:RemoveControlEvent(self.PetEventManager, "OnPetEventDelegate")
    log(bWriteLog and "LobbyPetBase:_UnRegisterPetControlEvents Unregister OnPetEventDelegate")
  end
  if slua.isValid(self.LobbyRotateComponent) and slua.isValid(self.RotateCapsule) and self.RotateCapsule.OnInputTouchBegin and self.RotateCapsule.OnInputTouchEnd then
    self:RemoveControlEvent(self.RotateCapsule, "OnInputTouchBegin")
    self:RemoveControlEvent(self.RotateCapsule, "OnInputTouchEnd")
  end
  if slua.isValid(self.LobbyRotateComponent) and self.LobbyRotateComponent.OnClicked then
    self:RemoveControlEvent(self.LobbyRotateComponent, "OnClicked")
  end
  if slua.isValid(self.BP_LobbyPetMoodComponent) and self.BP_LobbyPetMoodComponent.OnInMoodEvent and self.BP_LobbyPetMoodComponent.OnExitMoodEvent then
    self:RemoveControlEvent(self.BP_LobbyPetMoodComponent, "OnInMoodEvent")
    self:RemoveControlEvent(self.BP_LobbyPetMoodComponent, "OnExitMoodEvent")
  end
  if slua.isValid(self.PetAvatarComponent_BP) and self.PetAvatarComponent_BP.OnAvatarAllMeshLoaded then
    self:RemoveControlEvent(self.PetAvatarComponent_BP, "OnAvatarAllMeshLoaded")
  end
  if self:IsCommonEventExists(EVENTTYPE_PET, EVENTID_PET_GET_PET_DATA) then
    self:RemoveCommonEvent(EVENTTYPE_PET, EVENTID_PET_GET_PET_DATA)
  end
  if self:IsCommonEventExists(EVENTTYPE_PET, EVENTID_PET_MODEL_ENLARGE_STATE_CHANGE) then
    self:RemoveCommonEvent(EVENTTYPE_PET, EVENTID_PET_MODEL_ENLARGE_STATE_CHANGE)
  end
  if self:IsCommonEventExists(EVENTTYPE_LOBBY, EVENTID_LOBBY_MUSIC_OFF) then
    self:RemoveCommonEvent(EVENTTYPE_LOBBY, EVENTID_LOBBY_MUSIC_OFF)
  end
  if self:IsCommonEventExists(EVENTTYPE_LOBBY, EVENTID_LOBBY_MUSIC_ON) then
    self:RemoveCommonEvent(EVENTTYPE_LOBBY, EVENTID_LOBBY_MUSIC_ON)
  end
  if self:IsCommonEventExists(EVENTTYPE_CAMERA, EVENTID_CAMERA_SWITCHED) then
    self:RemoveCommonEvent(EVENTTYPE_CAMERA, EVENTID_CAMERA_SWITCHED)
  end
end

function LobbyPetBase:SetEffectItemId(itemId)
  self.effectItemId = itemId
end

function LobbyPetBase:GetEffectItemId()
  return self.effectItemId
end

function LobbyPetBase:PlayRandomAction()
  log(bWriteLog and "  LobbyPetBase:PlayRandomAction.  ")
  local PetExhibitConfig = require("client.lobby_ue_object.Actor.PetExhibit.PetExhibitConfig")
  local PetId = self.PetLevelInfo.PetId
  local dress = self.PetAvatarIDs
  local actionPath
  
  local function GetMappedAssetPath()
    if dress then
      for _, id in pairs(dress) do
        local path = PetUtil.GetMappedAssetPath(actionPath, id)
        if path ~= actionPath then
          actionPath = path
          break
        end
      end
    end
  end
  
  if 50001 == PetId then
    local Util = require("client.slua_ui_framework.util")
    actionPath = PetExhibitConfig.GyrfalconActionAsset
    log(bWriteLog and "LobbyPetBase:PlayRandomAction. actionPath: " .. tostring(actionPath))
    GetMappedAssetPath()
    Util.GetAssetAsync(actionPath, function(uAnimAsset)
      if slua.isValid(uAnimAsset) then
        self.Mesh:PlayAnimation(uAnimAsset, true)
      end
    end)
  else
    local pet_show_module = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.pet_show_module)
    local ActionData = pet_show_module:GetOnePetActionData(PetId)
    local action_id = ActionData and ActionData.ActionID or 0
    local ActionConfig = CDataTable.GetTableData("PetActionTable", action_id)
    if not ActionConfig then
      log(bWriteLog and "LobbyPetBase:PlayRandomAction. no ActionConfig for " .. tostring(action_id) .. " return")
      return false
    end
    actionPath = ActionConfig.LobbyPetAnimRes
    GetMappedAssetPath()
    local SoftObjectPath = KismetSystemLibrary.MakeSoftObjectPath(actionPath)
    local MontageAsset = STExtraBlueprintFunctionLibrary.GetAssetByAssetReference(SoftObjectPath)
    if not MontageAsset then
      return false
    end
    self:StopAction()
    self:PlayMontage(MontageAsset)
  end
end

function LobbyPetBase:ResetPetMaterialOnReuse()
  if self.PetLevelInfo and self.PetLevelInfo.PetID and slua.isValid(self.Mesh) then
    for i = 0, 9 do
      log(bWriteLog and "[pet][material]LobbyPetBase:ResetPetMaterialOnReuse")
      self.Mesh:SetMaterial(i, nil)
    end
  end
end

function LobbyPetBase:PlayBubble(BubbleItemIDList, bLoop)
  log(bWriteLog and string.format("[pet][bubble] LobbyPetBase:PlayBubble. #BubbleItemIDList=%s, bLoop=%s", tostring(BubbleItemIDList and #BubbleItemIDList or 0), tostring(bLoop)))
  self:StopBubble()
  if not BubbleItemIDList or not next(BubbleItemIDList) then
    return
  end
  if bLoop then
    self.playBubbleTimer = self:AddTimerLoop(0, function()
      if not self.playBubbleIndex then
        self.playBubbleIndex = 1
      else
        self.playBubbleIndex = self.playBubbleIndex + 1
        if self.playBubbleIndex <= 0 or self.playBubbleIndex > #BubbleItemIDList then
          self.playBubbleIndex = 1
        end
      end
      self:PlayBubbleInternal(BubbleItemIDList[self.playBubbleIndex])
    end, TIMER_INFINITE, 4.5)
  else
    self:PlayBubbleInternal(BubbleItemIDList[1])
  end
end

function LobbyPetBase:PlayBubbleInternal(EffectItemID)
  if not EffectItemID then
    return
  end
  if slua.isValid(self.PetBubbleComponent_BP) then
    self.PetBubbleComponent_BP:SpawnEmoteBubble(EffectItemID)
  end
end

function LobbyPetBase:StopBubble()
  if self.playBubbleTimer then
    self:RemoveTimer(self.playBubbleTimer)
    self.playBubbleTimer = nil
  end
  self.playBubbleIndex = nil
  if slua.isValid(self.PetBubbleComponent_BP) and self.PetBubbleComponent_BP.DisposePetBubble then
    self.PetBubbleComponent_BP:DisposePetBubble()
  end
end

function LobbyPetBase:PlaySwitchEffect(EffectItemIDList, bLoop)
  log(bWriteLog and string.format("[pet][switch] LobbyPetBase:PlaySwitchEffect. #EffectItemIDList=%s, bLoop=%s", tostring(EffectItemIDList and #EffectItemIDList or 0), tostring(bLoop)))
  self:StopSwitchEffect()
  if not EffectItemIDList or not next(EffectItemIDList) then
    return
  end
  if bLoop then
    self.switchEffectTimer = self:AddTimerLoop(0, function()
      if not self.switchEffectIndex then
        self.switchEffectIndex = 1
      else
        self.switchEffectIndex = self.switchEffectIndex + 1
        if self.switchEffectIndex <= 0 or self.switchEffectIndex > #EffectItemIDList then
          self.switchEffectIndex = 1
        end
      end
      self:PlaySwitchEffectInternal(EffectItemIDList[self.switchEffectIndex])
    end, TIMER_INFINITE, 6)
  else
    self:PlaySwitchEffectInternal(EffectItemIDList[1])
  end
end

function LobbyPetBase:PlaySwitchEffectInternal(EffectItemID)
  if not EffectItemID then
    return
  end
  local switchEffectCfg = CDataTable.GetTableData("PetSwitchEffectBPTable", EffectItemID)
  if not switchEffectCfg or not switchEffectCfg.Path then
    return
  end
  local Util = require("client.slua_ui_framework.util")
  self:StopSwitchEffect()
  if self._loadInHandleID then
    Util.ClearAssetAsync(self._loadInHandleID)
    self._loadInHandleID = nil
  end
  if self._loadOutHandleID then
    Util.ClearAssetAsync(self._loadOutHandleID)
    self._loadOutHandleID = nil
  end
  self.playPortalEffectTimer = self:AddTimer(0.0, function()
    local UGameplayStatics = import("GameplayStatics")
    local position = self:K2_GetActorLocation()
    position.Y = position.Y + 50
    local logic_pet = ModuleManager.GetModule(ModuleManager.CommonModuleConfig.logic_pet)
    local effectCfg = logic_pet:GetPortalCfgByItemId(EffectItemID)
    if effectCfg then
      local inParticlePath = effectCfg.Appear
      local outParticlePath = effectCfg.DisAppear
      local scale = effectCfg.Scale or 1
      self._loadInHandleID = Util.GetAssetAsync(inParticlePath, function(uParticle)
        if slua.isValid(uParticle) and slua.isValid(self.Object) then
          self.playingInEffect = UGameplayStatics.SpawnEmitterAtLocation(self.Object, uParticle, position, FRotator(0, 0, 0), FVector(scale, scale, scale), true)
        end
      end)
      coroutine.yield(2)
      self._loadOutHandleID = Util.GetAssetAsync(outParticlePath, function(uParticle)
        if slua.isValid(uParticle) and slua.isValid(self.Object) then
          self.playingOutEffect = UGameplayStatics.SpawnEmitterAtLocation(self.Object, uParticle, position, FRotator(0, 0, 0), FVector(scale, scale, scale), true)
        end
      end)
    end
  end)
end

function LobbyPetBase:StopSwitchEffect()
  if self.switchEffectTimer then
    self:RemoveTimer(self.switchEffectTimer)
    self.switchEffectTimer = nil
  end
  if self.playPortalEffectTimer then
    self:RemoveTimer(self.playPortalEffectTimer)
    self.playPortalEffectTimer = nil
  end
  if slua.isValid(self.playingInEffect) then
    self.playingInEffect:K2_DestroyComponent(self.playingInEffect)
    self.playingInEffect = nil
  end
  if slua.isValid(self.playingOutEffect) then
    self.playingOutEffect:K2_DestroyComponent(self.playingOutEffect)
    self.playingOutEffect = nil
  end
end

function LobbyPetBase:SetExtraScale(extraScale)
  self.extraScale = extraScale or 1
  if self.PetLevelInfo and self.PetLevelInfo.PetID and self.PetLevelInfo.PetID > 0 then
    self:ResetPetScale(self.bEnlargeState, true)
  end
end

function LobbyPetBase:SetIgnoreScale(bIgnoreScale)
  log(bWriteLog and string.format("[scale] LobbyPetBase:SetIgnoreScale bIgnoreScale:%s", tostring(bIgnoreScale)))
  self.bIgnoreScale = bIgnoreScale
end

function LobbyPetBase:ReSetRotation()
  if self.mesh then
    self.mesh:K2_SetRelativeRotation(FRotator(0, -90, 0), false, nil, true)
  end
end

local class = require("class")
local CActorBase = require("GameLua.Mod.BaseMod.Common.Core.ActorBase")
local CBP_LobbyPetBase = class(CActorBase, nil, LobbyPetBase)
return CBP_LobbyPetBase
