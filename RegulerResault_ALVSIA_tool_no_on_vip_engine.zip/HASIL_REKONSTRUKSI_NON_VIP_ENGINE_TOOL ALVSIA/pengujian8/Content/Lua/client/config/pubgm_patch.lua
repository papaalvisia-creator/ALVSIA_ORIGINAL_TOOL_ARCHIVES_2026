-- !!! DO NOT MODIFY THIS FILE. !!!
-- AUTO GENERATE BY pubgm_patch.py 2026-11-03 22:30:50
global_patch_make_time = "" ..
"Patch Version : 4.7.0.21748\n" ..
"Mode : TAPD\n" ..
"Branch : Release4.7.0\n" ..
"Git Engine : 85c8c9418653e0138b69c48c4eef0611996a4f12\n" ..
"Git Survive : 761fb3a40d172ea0db727f46c8379fce60efc0dc\n" ..
"Git Lua : 223b002059a6bcadc39e9a9d41750160f073bb74\n" ..
"SVN Xls : 1695949\n" ..
"P4 Content : 991655\n" ..
"BuildNo : #1\n" ..
"HostName : VPC36\n" ..
"Mfg. Date : 2026-11-03 22:30:50\n" ..
"Pipeline : #p-449984fb7f47431997aaff667cbc648e\n"

global_patch_make_time_map = {
    ["Patch Version"] = "4.7.0.21748",
    ["Mode"] = "TAPD",
    ["Branch"] = "Release4.7.0",
    ["Git Engine"] = "85c8c9418653e0138b69c48c4eef0611996a4f12",
    ["Git Survive"] = "761fb3a40d172ea0db727f46c8379fce60efc0dc",
    ["Git Lua"] = "223b002059a6bcadc39e9a9d41750160f073bb74",
    ["SVN Xls"] = "1695949",
    ["P4 Content"] = "991655",
    ["Pipeline"] =  "p-449984fb7f47431997aaff667cbc648e",
    ["BuildNo"] =  "#1",
    ["HostName"] = "VPC36",
    ["Mfg. Date"] = "2026-11-03 22:30:50",
}

global_patch_tss = "2lUiadFDtuTIrGQmQvhMEA=="
