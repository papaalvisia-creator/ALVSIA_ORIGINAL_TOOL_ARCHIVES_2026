.version	5.3

.format	0
.int_size	4
.size_t_size	4
.instruction_size	4
.integer_format	8
.float_format	8
.endianness	LITTLE

.function	main

.source	null
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	1
.maxstacksize	63

.upvalue	"_ENV"	0	true

.constant	k0	13
.constant	k1	202
.constant	k2	218
.constant	k3	220
.constant	k4	73
.constant	k5	27
.constant	k6	228
.constant	k7	22
.constant	k8	181
.constant	k9	9
.constant	k10	200
.constant	k11	92
.constant	k12	129
.constant	k13	45
.constant	k14	135
.constant	k15	131
.constant	k16	"require"
.constant	k17	"table"
.constant	k18	"concat"
.constant	k19	105
.constant	k20	128
.constant	k21	246
.constant	k22	221
.constant	k23	164
.constant	k24	205
.constant	k25	11
.constant	k26	133
.constant	k27	38
.constant	k28	98
.constant	k29	148
.constant	k30	46
.constant	k31	153
.constant	k32	216
.constant	k33	80
.constant	k34	61
.constant	k35	147
.constant	k36	187
.constant	k37	193
.constant	k38	252
.constant	k39	86
.constant	k40	230
.constant	k41	50
.constant	k42	232
.constant	k43	107
.constant	k44	138
.constant	k45	119
.constant	k46	213
.constant	k47	75
.constant	k48	59
.constant	k49	190
.constant	k50	139
.constant	k51	199
.constant	k52	95
.constant	k53	237
.constant	k54	44
.constant	k55	186
.constant	k56	121
.constant	k57	77
.constant	k58	141
.constant	k59	242
.constant	k60	134
.constant	k61	204
.constant	k62	68
.constant	k63	7
.constant	k64	120
.constant	k65	145
.constant	k66	182
.constant	k67	57
.constant	k68	173
.constant	k69	233
.constant	k70	236
.constant	k71	123
.constant	k72	132
.constant	k73	54
.constant	k74	102
.constant	k75	172
.constant	k76	71
.constant	k77	47
.constant	k78	209
.constant	k79	212
.constant	k80	69
.constant	k81	254
.constant	k82	36
.constant	k83	174
.constant	k84	243
.constant	k85	217
.constant	k86	169
.constant	k87	210
.constant	k88	99
.constant	k89	35
.constant	k90	115
.constant	k91	183
.constant	k92	214
.constant	k93	93
.constant	k94	41
.constant	k95	149
.constant	k96	175
.constant	k97	"ActivityType"
.constant	k98	"Enum_ReceivePopupSourceType"
.constant	k99	1
.constant	k100	"LocUtil"
.constant	k101	"GetLocalizeResStr"
.constant	k102	18130163
.constant	k103	2
.constant	k104	18130162
.constant	k105	3
.constant	k106	18130161
.constant	k107	"FSlateColor"
.constant	k108	"FLinearColor"
.constant	k109	0.5
.constant	k110	0.82
.constant	k111	0.033
.constant	k112	150
.constant	k113	89
.constant	k114	154
.constant	k115	81
.constant	k116	231
.constant	k117	58
.constant	k118	177
.constant	k119	5
.constant	k120	137
.constant	k121	66
.constant	k122	165
.constant	k123	156
.constant	k124	247
.constant	k125	184
.constant	k126	101
.constant	k127	155
.constant	k128	239
.constant	k129	185
.constant	k130	122
.constant	k131	63
.constant	k132	110
.constant	k133	91
.constant	k134	37
.constant	k135	162
.constant	k136	144
.constant	k137	90
.constant	k138	248
.constant	k139	85
.constant	k140	219
.constant	k141	"ENUM_RP_BUY_TYPE"
.constant	k142	171
.constant	k143	100
.constant	k144	62
.constant	k145	179
.constant	k146	152
.constant	k147	106
.constant	k148	176
.constant	k149	117
.constant	k150	78
.constant	k151	238
.constant	k152	227
.constant	k153	188
.constant	k154	88
.constant	k155	235
.constant	k156	32
.constant	k157	241
.constant	k158	24
.constant	k159	180
.constant	k160	215
.constant	k161	109
.constant	k162	19
.constant	k163	126
.constant	k164	245
.constant	k165	10
.constant	k166	143
.constant	k167	255
.constant	k168	33
.constant	k169	116
.constant	k170	159
.constant	k171	249
.constant	k172	20
.constant	k173	224
.constant	k174	52
.constant	k175	124
.constant	k176	211
.constant	k177	160
.constant	k178	161
.constant	k179	225
.constant	k180	34
.constant	k181	142
.constant	k182	127
.constant	k183	94
.constant	k184	158
.constant	k185	151
.constant	k186	96
.constant	k187	82
.constant	k188	40
.constant	k189	206
.constant	k190	130
.constant	k191	56
.constant	k192	118
.constant	k193	222
.constant	k194	97
.constant	k195	136
.constant	k196	189
.constant	k197	39
.constant	k198	"TraitClass"
.constant	k199	"ctor"
.constant	k200	"OnInitialize"
.constant	k201	"RegistEvents"
.constant	k202	"OnPostInitialize"
.constant	k203	"OnClose"
.constant	k204	"OnClickedGroup"
.constant	k205	"OnClickedBuyRP"
.constant	k206	"OnClickedCreateGroup"
.constant	k207	"OnClickedGroupRewardHelp"
.constant	k208	"OnClickedMemberNumHelp"
.constant	k209	"OnClickedReceiveGroupReward"
.constant	k210	"OnClickedJKDetail"
.constant	k211	"OnClickedOpenLinkageRewardPopup"
.constant	k212	"OnClickedUpgradeRPPlus"
.constant	k213	"OnClickRepurchase"
.constant	k214	"OnClickedSwitchToBuyRP"
.constant	k215	"OnJumpLuckCardButtonClick"
.constant	k216	"OnClickedReceiveLuckCardReward"
.constant	k217	"OnLinkageRewardButtonClick"
.constant	k218	"OnClickedQuickGroup"
.constant	k219	"OnClickedInvitateRecord"
.constant	k220	"OnUpdateGroupUI"
.constant	k221	"OnUpdateGroupRewardState"
.constant	k222	"OnUpdateGroupMemberState"
.constant	k223	"OnRPInfoUpdate"
.constant	k224	"OnUpdateNormalPassInfo"
.constant	k225	"OnRPGroupInvitedRecordEvent"
.constant	k226	"OnUpdateInvitedRecordRedEvent"
.constant	k227	"OnUpdateInvitedRecordRed"
.constant	k228	"OnUpdateJKDetailButton"
.constant	k229	"OnUpdateGroupBuyText"
.constant	k230	"UpdateLuckyCardReward"
.constant	k231	"RefreshLinkageRewardBtnShow"
.constant	k232	"OnUpdateGroupBuyRPUI"
.constant	k233	"_GetBuyItemNodes"
.constant	k234	"_SetupBuyItemRewardList"
.constant	k235	"_RefreshBuyItemBtn"
.constant	k236	"_RefreshExtraLocalText"
.constant	k237	"_RegistBuyItemBtnEvents"
.constant	k238	"OnClickBuyItem"
.constant	k239	"OnClickNewUserPrivileges"
.constant	k240	"RefreshExperienceNormalBuyBtn"
.constant	k241	"_GetExperienceBuyState"
.constant	k242	"_DetermineExperienceBuyType"
.constant	k243	"_UpdateExperienceBuyDisplay"
.constant	k244	"_SetExperiencePriceViaBuyType"
.constant	k245	"RefreshNormalBuyBtn"
.constant	k246	"_GetNormalBuyState"
.constant	k247	"_DetermineNormalBuyType"
.constant	k248	"_UpdateNormalBuyDisplay"
.constant	k249	"SetNormalPriceViaBuyType"
.constant	k250	"RefreshEliteBuyBtn"
.constant	k251	"_GetEliteBuyState"
.constant	k252	"_DetermineEliteBuyType"
.constant	k253	"_UpdateEliteBuyDisplay"
.constant	k254	"SetElitePriceViaBuyType"
.constant	k255	"OnUpdateLinkageReward"
.constant	k256	"SwitchTab"
.constant	k257	"UpdateTabPage"
.constant	k258	"InitText"
.constant	k259	"UpdateLinkageRewardIcon"
.constant	k260	79
.constant	k261	148
.constant	k262	239
.constant	k263	221
.constant	k264	184
.constant	k265	208
.constant	k266	64
.constant	k267	152
.constant	k268	41
.constant	k269	114
.constant	k270	68
.constant	k271	131
.constant	k272	237
.constant	k273	213
.constant	k274	171
.constant	k275	90
.constant	k276	128
.constant	k277	234
.constant	k278	203
.constant	k279	77
.constant	k280	240
.constant	k281	207
.constant	k282	149
.constant	k283	248
.constant	k284	122
.constant	k285	198
.constant	k286	38
.constant	k287	37
.constant	k288	251
.constant	k289	250
.constant	k290	18130200
.constant	k291	18140081
.constant	k292	18141419
.constant	k293	6162
.constant	k294	101
.constant	k295	102
.constant	k296	103
.constant	k297	"_SetRPRewardTexts"
.constant	k298	"_SetRPJumpVisible"
.constant	k299	"_SetRPBuyBtnState"
.constant	k300	"_SetRPReceiveBtnEnabled"
.constant	k301	"_SetRPRewardGlowVisible"
.constant	k302	88
.constant	k303	137
.constant	k304	220
.constant	k305	165
.constant	k306	205
.constant	k307	122
.constant	k308	183
.constant	k309	36
.constant	k310	116
.constant	k311	157
.constant	k312	111
.constant	k313	136
.constant	k314	232
.constant	k315	123
.constant	k316	35
.constant	k317	138
.constant	k318	185
.constant	k319	225
.constant	k320	95
.constant	k321	231
.constant	k322	54
.constant	k323	163
.constant	k324	112
.constant	k325	52
.constant	k326	177
.constant	k327	142
.constant	k328	228
.constant	k329	110
.constant	k330	55
.constant	k331	143
.constant	k332	175
.constant	k333	"_SetRPRewardReddot"
.constant	k334	"UpdateGroupRewardStatus"
.constant	k335	"OnUpdateGroupRewardTips"
.constant	k336	"UpdateFirstBuyPrivilege"
.constant	k337	"UpdateGroupState"
.constant	k338	"InitLoopData"
.constant	k339	"InitTrait"
.constant	k340	"GetActTime"
.constant	k341	"ShowReward"

.line	0	newtable      r0    16     0
.line	0	loadk         r1    k0 ; k0 = 13
.line	0	loadk         r2    k1 ; k1 = 202
.line	0	loadk         r3    k2 ; k2 = 218
.line	0	loadk         r4    k3 ; k3 = 220
.line	0	loadk         r5    k4 ; k4 = 73
.line	0	loadk         r6    k5 ; k5 = 27
.line	0	loadk         r7    k6 ; k6 = 228
.line	0	loadk         r8    k7 ; k7 = 22
.line	0	loadk         r9    k8 ; k8 = 181
.line	0	loadk        r10    k9 ; k9 = 9
.line	0	loadk        r11   k10 ; k10 = 200
.line	0	loadk        r12   k11 ; k11 = 92
.line	0	loadk        r13   k12 ; k12 = 129
.line	0	loadk        r14   k13 ; k13 = 45
.line	0	loadk        r15   k14 ; k14 = 135
.line	0	loadk        r16   k15 ; k15 = 131
.line	0	setlist       r0    16     1
.line	0	closure       r1    f0
.line	0	newtable      r2     0     0
.line	0	gettabup      r3    u0   k16 ; k16 = "require"
.line	0	gettabup      r4    u0   k17 ; k17 = "table"
.line	0	gettable      r4    r4   k18 ; k18 = "concat"
.line	0	newtable      r5     1     0
.line	0	move          r6    r1
.line	0	loadk         r7   k19 ; k19 = 105
.line	0	loadk         r8   k20 ; k20 = 128
.line	0	loadk         r9   k21 ; k21 = 246
.line	0	loadk        r10   k22 ; k22 = 221
.line	0	loadk        r11   k23 ; k23 = 164
.line	0	loadk        r12   k24 ; k24 = 205
.line	0	loadk        r13   k25 ; k25 = 11
.line	0	loadk        r14   k26 ; k26 = 133
.line	0	loadk        r15   k27 ; k27 = 38
.line	0	loadk        r16   k28 ; k28 = 98
.line	0	loadk        r17   k29 ; k29 = 148
.line	0	loadk        r18   k30 ; k30 = 46
.line	0	loadk        r19   k31 ; k31 = 153
.line	0	loadk        r20   k32 ; k32 = 216
.line	0	loadk        r21   k33 ; k33 = 80
.line	0	loadk        r22   k34 ; k34 = 61
.line	0	loadk        r23   k35 ; k35 = 147
.line	0	loadk        r24   k36 ; k36 = 187
.line	0	loadk        r25   k37 ; k37 = 193
.line	0	loadk        r26   k38 ; k38 = 252
.line	0	loadk        r27   k39 ; k39 = 86
.line	0	loadk        r28   k40 ; k40 = 230
.line	0	loadk        r29   k41 ; k41 = 50
.line	0	loadk        r30   k42 ; k42 = 232
.line	0	loadk        r31   k30 ; k30 = 46
.line	0	loadk        r32   k43 ; k43 = 107
.line	0	loadk        r33   k44 ; k44 = 138
.line	0	loadk        r34   k45 ; k45 = 119
.line	0	loadk        r35    k8 ; k8 = 181
.line	0	loadk        r36   k46 ; k46 = 213
.line	0	loadk        r37   k47 ; k47 = 75
.line	0	loadk        r38   k48 ; k48 = 59
.line	0	loadk        r39   k26 ; k26 = 133
.line	0	loadk        r40   k49 ; k49 = 190
.line	0	loadk        r41   k50 ; k50 = 139
.line	0	loadk        r42   k51 ; k51 = 199
.line	0	loadk        r43   k52 ; k52 = 95
.line	0	loadk        r44   k53 ; k53 = 237
.line	0	loadk        r45   k54 ; k54 = 44
.line	0	loadk        r46   k55 ; k55 = 186
.line	0	call          r6    41     2
.line	0	move          r7    r1
.line	0	loadk         r8   k56 ; k56 = 121
.line	0	call          r7     2     0
.line	0	setlist       r5     0     1
.line	0	call          r4     2     2
.line	0	call          r3     2     2
.line	0	gettabup      r4    u0   k16 ; k16 = "require"
.line	0	gettabup      r5    u0   k17 ; k17 = "table"
.line	0	gettable      r5    r5   k18 ; k18 = "concat"
.line	0	newtable      r6     1     0
.line	0	move          r7    r1
.line	0	loadk         r8   k57 ; k57 = 77
.line	0	loadk         r9   k58 ; k58 = 141
.line	0	loadk        r10   k59 ; k59 = 242
.line	0	loadk        r11   k22 ; k22 = 221
.line	0	loadk        r12   k60 ; k60 = 134
.line	0	loadk        r13   k61 ; k61 = 204
.line	0	loadk        r14   k62 ; k62 = 68
.line	0	loadk        r15   k32 ; k32 = 216
.line	0	loadk        r16   k63 ; k63 = 7
.line	0	loadk        r17   k64 ; k64 = 120
.line	0	loadk        r18   k65 ; k65 = 145
.line	0	loadk        r19   k30 ; k30 = 46
.line	0	loadk        r20   k66 ; k66 = 182
.line	0	loadk        r21   k32 ; k32 = 216
.line	0	loadk        r22   k11 ; k11 = 92
.line	0	loadk        r23   k67 ; k67 = 57
.line	0	loadk        r24   k15 ; k15 = 131
.line	0	loadk        r25   k59 ; k59 = 242
.line	0	loadk        r26   k68 ; k68 = 173
.line	0	loadk        r27   k69 ; k69 = 233
.line	0	loadk        r28    k4 ; k4 = 73
.line	0	loadk        r29   k70 ; k70 = 236
.line	0	loadk        r30   k71 ; k71 = 123
.line	0	loadk        r31   k72 ; k72 = 132
.line	0	loadk        r32   k73 ; k73 = 54
.line	0	loadk        r33   k74 ; k74 = 102
.line	0	loadk        r34   k60 ; k60 = 134
.line	0	loadk        r35   k71 ; k71 = 123
.line	0	loadk        r36   k75 ; k75 = 172
.line	0	loadk        r37   k46 ; k46 = 213
.line	0	loadk        r38   k76 ; k76 = 71
.line	0	loadk        r39   k77 ; k77 = 47
.line	0	loadk        r40   k50 ; k50 = 139
.line	0	loadk        r41    k8 ; k8 = 181
.line	0	loadk        r42   k78 ; k78 = 209
.line	0	loadk        r43   k79 ; k79 = 212
.line	0	loadk        r44   k80 ; k80 = 69
.line	0	loadk        r45   k81 ; k81 = 254
.line	0	loadk        r46   k54 ; k54 = 44
.line	0	loadk        r47    k8 ; k8 = 181
.line	0	call          r7    41     2
.line	0	move          r8    r1
.line	0	loadk         r9   k82 ; k82 = 36
.line	0	loadk        r10   k83 ; k83 = 174
.line	0	loadk        r11   k84 ; k84 = 243
.line	0	loadk        r12   k85 ; k85 = 217
.line	0	loadk        r13   k86 ; k86 = 169
.line	0	loadk        r14   k87 ; k87 = 210
.line	0	loadk        r15   k88 ; k88 = 99
.line	0	loadk        r16   k72 ; k72 = 132
.line	0	loadk        r17   k89 ; k89 = 35
.line	0	loadk        r18   k90 ; k90 = 115
.line	0	loadk        r19   k29 ; k29 = 148
.line	0	loadk        r20   k56 ; k56 = 121
.line	0	loadk        r21   k91 ; k91 = 183
.line	0	loadk        r22   k92 ; k92 = 214
.line	0	loadk        r23   k93 ; k93 = 93
.line	0	loadk        r24   k94 ; k94 = 41
.line	0	loadk        r25   k95 ; k95 = 149
.line	0	loadk        r26   k96 ; k96 = 175
.line	0	call          r8    19     0
.line	0	setlist       r6     0     1
.line	0	call          r5     2     2
.line	0	call          r4     2     2
.line	0	gettable      r5    r4   k97 ; k97 = "ActivityType"
.line	0	gettable      r6    r4   k98 ; k98 = "Enum_ReceivePopupSou" (truncated)
.line	0	newtable      r7     0     3
.line	0	gettabup      r8    u0  k100 ; k100 = "LocUtil"
.line	0	gettable      r8    r8  k101 ; k101 = "GetLocalizeResStr"
.line	0	loadk         r9  k102 ; k102 = 18130163
.line	0	call          r8     2     2
.line	0	settable      r7   k99    r8 ; k99 = 1
.line	0	gettabup      r8    u0  k100 ; k100 = "LocUtil"
.line	0	gettable      r8    r8  k101 ; k101 = "GetLocalizeResStr"
.line	0	loadk         r9  k104 ; k104 = 18130162
.line	0	call          r8     2     2
.line	0	settable      r7  k103    r8 ; k103 = 2
.line	0	gettabup      r8    u0  k100 ; k100 = "LocUtil"
.line	0	gettable      r8    r8  k101 ; k101 = "GetLocalizeResStr"
.line	0	loadk         r9  k106 ; k106 = 18130161
.line	0	call          r8     2     2
.line	0	settable      r7  k105    r8 ; k105 = 3
.line	0	gettabup      r8    u0  k107 ; k107 = "FSlateColor"
.line	0	gettabup      r9    u0  k108 ; k108 = "FLinearColor"
.line	0	loadk        r10   k99 ; k99 = 1
.line	0	loadk        r11   k99 ; k99 = 1
.line	0	loadk        r12   k99 ; k99 = 1
.line	0	loadk        r13   k99 ; k99 = 1
.line	0	call          r9     5     0
.line	0	call          r8     0     2
.line	0	gettabup      r9    u0  k107 ; k107 = "FSlateColor"
.line	0	gettabup     r10    u0  k108 ; k108 = "FLinearColor"
.line	0	loadk        r11   k99 ; k99 = 1
.line	0	loadk        r12   k99 ; k99 = 1
.line	0	loadk        r13   k99 ; k99 = 1
.line	0	loadk        r14  k109 ; k109 = 0.5
.line	0	call         r10     5     0
.line	0	call          r9     0     2
.line	0	gettabup     r10    u0  k107 ; k107 = "FSlateColor"
.line	0	gettabup     r11    u0  k108 ; k108 = "FLinearColor"
.line	0	loadk        r12  k110 ; k110 = 0.82
.line	0	loadk        r13  k111 ; k111 = 0.033
.line	0	loadk        r14  k111 ; k111 = 0.033
.line	0	loadk        r15   k99 ; k99 = 1
.line	0	call         r11     5     0
.line	0	call         r10     0     2
.line	0	gettabup     r11    u0   k16 ; k16 = "require"
.line	0	gettabup     r12    u0   k17 ; k17 = "table"
.line	0	gettable     r12   r12   k18 ; k18 = "concat"
.line	0	newtable     r13     1     0
.line	0	move         r14    r1
.line	0	loadk        r15   k19 ; k19 = 105
.line	0	loadk        r16   k20 ; k20 = 128
.line	0	loadk        r17   k21 ; k21 = 246
.line	0	loadk        r18   k22 ; k22 = 221
.line	0	loadk        r19   k23 ; k23 = 164
.line	0	loadk        r20   k24 ; k24 = 205
.line	0	loadk        r21   k25 ; k25 = 11
.line	0	loadk        r22   k26 ; k26 = 133
.line	0	loadk        r23   k27 ; k27 = 38
.line	0	loadk        r24   k28 ; k28 = 98
.line	0	loadk        r25   k29 ; k29 = 148
.line	0	loadk        r26   k30 ; k30 = 46
.line	0	loadk        r27  k112 ; k112 = 150
.line	0	loadk        r28   k32 ; k32 = 216
.line	0	loadk        r29  k113 ; k113 = 89
.line	0	loadk        r30   k41 ; k41 = 50
.line	0	loadk        r31   k31 ; k31 = 153
.line	0	loadk        r32   k59 ; k59 = 242
.line	0	loadk        r33  k114 ; k114 = 154
.line	0	loadk        r34   k40 ; k40 = 230
.line	0	loadk        r35  k115 ; k115 = 81
.line	0	loadk        r36  k116 ; k116 = 231
.line	0	loadk        r37  k117 ; k117 = 58
.line	0	loadk        r38  k118 ; k118 = 177
.line	0	loadk        r39  k119 ; k119 = 5
.line	0	loadk        r40   k45 ; k45 = 119
.line	0	loadk        r41   k72 ; k72 = 132
.line	0	loadk        r42   k88 ; k88 = 99
.line	0	loadk        r43   k31 ; k31 = 153
.line	0	loadk        r44  k120 ; k120 = 137
.line	0	loadk        r45  k121 ; k121 = 66
.line	0	loadk        r46   k82 ; k82 = 36
.line	0	loadk        r47   k58 ; k58 = 141
.line	0	loadk        r48  k122 ; k122 = 165
.line	0	loadk        r49  k123 ; k123 = 156
.line	0	loadk        r50   k51 ; k51 = 199
.line	0	loadk        r51   k52 ; k52 = 95
.line	0	loadk        r52  k124 ; k124 = 247
.line	0	loadk        r53   k30 ; k30 = 46
.line	0	loadk        r54  k125 ; k125 = 184
.line	0	call         r14    41     2
.line	0	move         r15    r1
.line	0	loadk        r16  k126 ; k126 = 101
.line	0	loadk        r17  k127 ; k127 = 155
.line	0	loadk        r18  k128 ; k128 = 239
.line	0	loadk        r19   k85 ; k85 = 217
.line	0	loadk        r20  k129 ; k129 = 185
.line	0	loadk        r21    k1 ; k1 = 202
.line	0	loadk        r22  k130 ; k130 = 122
.line	0	loadk        r23   k29 ; k29 = 148
.line	0	loadk        r24  k131 ; k131 = 63
.line	0	loadk        r25  k132 ; k132 = 110
.line	0	call         r15    11     0
.line	0	setlist      r13     0     1
.line	0	call         r12     2     2
.line	0	call         r11     2     2
.line	0	gettabup     r12    u0   k16 ; k16 = "require"
.line	0	gettabup     r13    u0   k17 ; k17 = "table"
.line	0	gettable     r13   r13   k18 ; k18 = "concat"
.line	0	newtable     r14     1     0
.line	0	move         r15    r1
.line	0	loadk        r16   k19 ; k19 = 105
.line	0	loadk        r17   k20 ; k20 = 128
.line	0	loadk        r18   k21 ; k21 = 246
.line	0	loadk        r19   k22 ; k22 = 221
.line	0	loadk        r20   k23 ; k23 = 164
.line	0	loadk        r21   k24 ; k24 = 205
.line	0	loadk        r22   k25 ; k25 = 11
.line	0	loadk        r23   k26 ; k26 = 133
.line	0	loadk        r24   k27 ; k27 = 38
.line	0	loadk        r25   k28 ; k28 = 98
.line	0	loadk        r26   k29 ; k29 = 148
.line	0	loadk        r27   k30 ; k30 = 46
.line	0	loadk        r28  k112 ; k112 = 150
.line	0	loadk        r29   k32 ; k32 = 216
.line	0	loadk        r30  k113 ; k113 = 89
.line	0	loadk        r31   k41 ; k41 = 50
.line	0	loadk        r32   k31 ; k31 = 153
.line	0	loadk        r33   k59 ; k59 = 242
.line	0	loadk        r34  k114 ; k114 = 154
.line	0	loadk        r35   k40 ; k40 = 230
.line	0	loadk        r36  k115 ; k115 = 81
.line	0	loadk        r37  k116 ; k116 = 231
.line	0	loadk        r38  k117 ; k117 = 58
.line	0	loadk        r39  k118 ; k118 = 177
.line	0	loadk        r40  k119 ; k119 = 5
.line	0	loadk        r41   k45 ; k45 = 119
.line	0	loadk        r42   k72 ; k72 = 132
.line	0	loadk        r43   k88 ; k88 = 99
.line	0	loadk        r44   k31 ; k31 = 153
.line	0	loadk        r45  k120 ; k120 = 137
.line	0	loadk        r46  k133 ; k133 = 91
.line	0	loadk        r47  k134 ; k134 = 37
.line	0	loadk        r48   k12 ; k12 = 129
.line	0	loadk        r49  k135 ; k135 = 162
.line	0	loadk        r50  k136 ; k136 = 144
.line	0	loadk        r51  k128 ; k128 = 239
.line	0	loadk        r52  k137 ; k137 = 90
.line	0	loadk        r53  k138 ; k138 = 248
.line	0	loadk        r54   k73 ; k73 = 54
.line	0	loadk        r55  k122 ; k122 = 165
.line	0	call         r15    41     2
.line	0	move         r16    r1
.line	0	loadk        r17  k139 ; k139 = 85
.line	0	loadk        r18   k12 ; k12 = 129
.line	0	loadk        r19   k81 ; k81 = 254
.line	0	loadk        r20  k140 ; k140 = 219
.line	0	loadk        r21  k125 ; k125 = 184
.line	0	loadk        r22   k92 ; k92 = 214
.line	0	call         r16     7     0
.line	0	setlist      r14     0     1
.line	0	call         r13     2     2
.line	0	call         r12     2     2
.line	0	gettable     r13   r12  k141 ; k141 = "ENUM_RP_BUY_TYPE"
.line	0	gettabup     r14    u0   k17 ; k17 = "table"
.line	0	gettable     r14   r14   k18 ; k18 = "concat"
.line	0	newtable     r15     2     0
.line	0	move         r16    r1
.line	0	loadk        r17  k134 ; k134 = 37
.line	0	loadk        r18  k142 ; k142 = 171
.line	0	loadk        r19   k81 ; k81 = 254
.line	0	loadk        r20   k46 ; k46 = 213
.line	0	loadk        r21   k96 ; k96 = 175
.line	0	loadk        r22  k112 ; k112 = 150
.line	0	loadk        r23  k143 ; k143 = 100
.line	0	loadk        r24   k72 ; k72 = 132
.line	0	loadk        r25  k144 ; k144 = 62
.line	0	loadk        r26  k143 ; k143 = 100
.line	0	loadk        r27    k2 ; k2 = 218
.line	0	loadk        r28  k139 ; k139 = 85
.line	0	loadk        r29  k145 ; k145 = 179
.line	0	loadk        r30  k146 ; k146 = 152
.line	0	loadk        r31  k147 ; k147 = 106
.line	0	loadk        r32  k117 ; k117 = 58
.line	0	loadk        r33  k146 ; k146 = 152
.line	0	loadk        r34  k148 ; k148 = 176
.line	0	loadk        r35   k44 ; k44 = 138
.line	0	loadk        r36   k37 ; k37 = 193
.line	0	loadk        r37  k113 ; k113 = 89
.line	0	loadk        r38   k40 ; k40 = 230
.line	0	loadk        r39   k48 ; k48 = 59
.line	0	loadk        r40    k8 ; k8 = 181
.line	0	loadk        r41  k149 ; k149 = 117
.line	0	loadk        r42  k150 ; k150 = 78
.line	0	loadk        r43   k65 ; k65 = 145
.line	0	loadk        r44  k149 ; k149 = 117
.line	0	loadk        r45   k14 ; k14 = 135
.line	0	loadk        r46  k151 ; k151 = 238
.line	0	loadk        r47   k57 ; k57 = 77
.line	0	loadk        r48   k82 ; k82 = 36
.line	0	loadk        r49   k72 ; k72 = 132
.line	0	loadk        r50  k152 ; k152 = 227
.line	0	loadk        r51  k153 ; k153 = 188
.line	0	loadk        r52   k53 ; k53 = 237
.line	0	loadk        r53  k154 ; k154 = 88
.line	0	loadk        r54  k155 ; k155 = 235
.line	0	loadk        r55  k156 ; k156 = 32
.line	0	loadk        r56  k125 ; k125 = 184
.line	0	call         r16    41     2
.line	0	move         r17    r1
.line	0	loadk        r18   k19 ; k19 = 105
.line	0	loadk        r19   k95 ; k95 = 149
.line	0	loadk        r20  k148 ; k148 = 176
.line	0	loadk        r21  k157 ; k157 = 241
.line	0	loadk        r22   k86 ; k86 = 169
.line	0	loadk        r23   k92 ; k92 = 214
.line	0	loadk        r24   k47 ; k47 = 75
.line	0	loadk        r25   k86 ; k86 = 169
.line	0	loadk        r26  k158 ; k158 = 24
.line	0	loadk        r27   k76 ; k76 = 71
.line	0	loadk        r28  k159 ; k159 = 180
.line	0	loadk        r29   k52 ; k52 = 95
.line	0	loadk        r30   k96 ; k96 = 175
.line	0	loadk        r31   k51 ; k51 = 199
.line	0	loadk        r32  k113 ; k113 = 89
.line	0	loadk        r33   k94 ; k94 = 41
.line	0	loadk        r34  k127 ; k127 = 155
.line	0	loadk        r35  k125 ; k125 = 184
.line	0	loadk        r36   k44 ; k44 = 138
.line	0	loadk        r37  k160 ; k160 = 215
.line	0	loadk        r38   k25 ; k25 = 11
.line	0	loadk        r39   k36 ; k36 = 187
.line	0	loadk        r40  k161 ; k161 = 109
.line	0	loadk        r41   k42 ; k42 = 232
.line	0	loadk        r42  k162 ; k162 = 19
.line	0	loadk        r43  k143 ; k143 = 100
.line	0	loadk        r44   k44 ; k44 = 138
.line	0	loadk        r45  k163 ; k163 = 126
.line	0	loadk        r46    k8 ; k8 = 181
.line	0	loadk        r47  k164 ; k164 = 245
.line	0	loadk        r48  k163 ; k163 = 126
.line	0	loadk        r49  k165 ; k165 = 10
.line	0	loadk        r50    k8 ; k8 = 181
.line	0	loadk        r51   k31 ; k31 = 153
.line	0	loadk        r52  k166 ; k166 = 143
.line	0	loadk        r53  k167 ; k167 = 255
.line	0	loadk        r54  k154 ; k154 = 88
.line	0	loadk        r55  k138 ; k138 = 248
.line	0	loadk        r56  k168 ; k168 = 33
.line	0	loadk        r57  k145 ; k145 = 179
.line	0	call         r17    41     2
.line	0	move         r18    r1
.line	0	loadk        r19  k139 ; k139 = 85
.line	0	loadk        r20   k22 ; k22 = 221
.line	0	loadk        r21   k68 ; k68 = 173
.line	0	loadk        r22   k20 ; k20 = 128
.line	0	call         r18     5     0
.line	0	setlist      r15     0     1
.line	0	call         r14     2     2
.line	0	gettabup     r15    u0   k17 ; k17 = "table"
.line	0	gettable     r15   r15   k18 ; k18 = "concat"
.line	0	newtable     r16     1     0
.line	0	move         r17    r1
.line	0	loadk        r18  k134 ; k134 = 37
.line	0	loadk        r19  k142 ; k142 = 171
.line	0	loadk        r20   k81 ; k81 = 254
.line	0	loadk        r21   k46 ; k46 = 213
.line	0	loadk        r22   k96 ; k96 = 175
.line	0	loadk        r23  k112 ; k112 = 150
.line	0	loadk        r24  k143 ; k143 = 100
.line	0	loadk        r25   k72 ; k72 = 132
.line	0	loadk        r26  k144 ; k144 = 62
.line	0	loadk        r27  k143 ; k143 = 100
.line	0	loadk        r28    k2 ; k2 = 218
.line	0	loadk        r29  k139 ; k139 = 85
.line	0	loadk        r30  k145 ; k145 = 179
.line	0	loadk        r31  k146 ; k146 = 152
.line	0	loadk        r32  k147 ; k147 = 106
.line	0	loadk        r33  k117 ; k117 = 58
.line	0	loadk        r34  k146 ; k146 = 152
.line	0	loadk        r35  k148 ; k148 = 176
.line	0	loadk        r36   k44 ; k44 = 138
.line	0	loadk        r37   k37 ; k37 = 193
.line	0	loadk        r38  k113 ; k113 = 89
.line	0	loadk        r39   k40 ; k40 = 230
.line	0	loadk        r40   k48 ; k48 = 59
.line	0	loadk        r41    k8 ; k8 = 181
.line	0	loadk        r42  k149 ; k149 = 117
.line	0	loadk        r43  k150 ; k150 = 78
.line	0	loadk        r44   k65 ; k65 = 145
.line	0	loadk        r45  k149 ; k149 = 117
.line	0	loadk        r46   k14 ; k14 = 135
.line	0	loadk        r47  k151 ; k151 = 238
.line	0	loadk        r48   k57 ; k57 = 77
.line	0	loadk        r49   k82 ; k82 = 36
.line	0	loadk        r50   k72 ; k72 = 132
.line	0	loadk        r51  k152 ; k152 = 227
.line	0	loadk        r52  k153 ; k153 = 188
.line	0	loadk        r53   k53 ; k53 = 237
.line	0	loadk        r54  k154 ; k154 = 88
.line	0	loadk        r55  k155 ; k155 = 235
.line	0	loadk        r56  k156 ; k156 = 32
.line	0	loadk        r57  k125 ; k125 = 184
.line	0	call         r17    41     2
.line	0	move         r18    r1
.line	0	loadk        r19   k19 ; k19 = 105
.line	0	loadk        r20   k95 ; k95 = 149
.line	0	loadk        r21  k148 ; k148 = 176
.line	0	loadk        r22   k78 ; k78 = 209
.line	0	loadk        r23   k86 ; k86 = 169
.line	0	loadk        r24   k92 ; k92 = 214
.line	0	loadk        r25   k47 ; k47 = 75
.line	0	loadk        r26   k86 ; k86 = 169
.line	0	loadk        r27   k77 ; k77 = 47
.line	0	loadk        r28   k71 ; k71 = 123
.line	0	loadk        r29  k123 ; k123 = 156
.line	0	loadk        r30  k169 ; k169 = 116
.line	0	loadk        r31  k170 ; k170 = 159
.line	0	loadk        r32  k171 ; k171 = 249
.line	0	loadk        r33  k133 ; k133 = 91
.line	0	loadk        r34   k54 ; k54 = 44
.line	0	loadk        r35  k122 ; k122 = 165
.line	0	loadk        r36   k53 ; k53 = 237
.line	0	loadk        r37   k22 ; k22 = 221
.line	0	loadk        r38  k148 ; k148 = 176
.line	0	loadk        r39  k172 ; k172 = 20
.line	0	loadk        r40  k173 ; k173 = 224
.line	0	loadk        r41   k73 ; k73 = 54
.line	0	loadk        r42   k86 ; k86 = 169
.line	0	loadk        r43  k174 ; k174 = 52
.line	0	loadk        r44  k154 ; k154 = 88
.line	0	loadk        r45   k20 ; k20 = 128
.line	0	loadk        r46  k175 ; k175 = 124
.line	0	loadk        r47   k15 ; k15 = 131
.line	0	loadk        r48  k176 ; k176 = 211
.line	0	loadk        r49   k47 ; k47 = 75
.line	0	loadk        r50  k119 ; k119 = 5
.line	0	loadk        r51  k166 ; k166 = 143
.line	0	loadk        r52   k36 ; k36 = 187
.line	0	loadk        r53  k177 ; k177 = 160
.line	0	loadk        r54   k86 ; k86 = 169
.line	0	loadk        r55  k158 ; k158 = 24
.line	0	loadk        r56  k178 ; k178 = 161
.line	0	call         r18    39     0
.line	0	setlist      r16     0     1
.line	0	call         r15     2     2
.line	0	newtable     r16     2     0
.line	0	gettabup     r17    u0   k16 ; k16 = "require"
.line	0	gettabup     r18    u0   k17 ; k17 = "table"
.line	0	gettable     r18   r18   k18 ; k18 = "concat"
.line	0	newtable     r19     1     0
.line	0	move         r20    r1
.line	0	loadk        r21   k57 ; k57 = 77
.line	0	loadk        r22   k58 ; k58 = 141
.line	0	loadk        r23   k59 ; k59 = 242
.line	0	loadk        r24   k22 ; k22 = 221
.line	0	loadk        r25   k60 ; k60 = 134
.line	0	loadk        r26   k61 ; k61 = 204
.line	0	loadk        r27   k62 ; k62 = 68
.line	0	loadk        r28   k32 ; k32 = 216
.line	0	loadk        r29   k63 ; k63 = 7
.line	0	loadk        r30   k64 ; k64 = 120
.line	0	loadk        r31   k65 ; k65 = 145
.line	0	loadk        r32   k30 ; k30 = 46
.line	0	loadk        r33   k66 ; k66 = 182
.line	0	loadk        r34   k32 ; k32 = 216
.line	0	loadk        r35   k11 ; k11 = 92
.line	0	loadk        r36   k67 ; k67 = 57
.line	0	loadk        r37   k15 ; k15 = 131
.line	0	loadk        r38   k59 ; k59 = 242
.line	0	loadk        r39  k153 ; k153 = 188
.line	0	loadk        r40  k138 ; k138 = 248
.line	0	loadk        r41   k39 ; k39 = 86
.line	0	loadk        r42  k173 ; k173 = 224
.line	0	loadk        r43  k168 ; k168 = 33
.line	0	loadk        r44   k42 ; k42 = 232
.line	0	loadk        r45  k158 ; k158 = 24
.line	0	loadk        r46   k43 ; k43 = 107
.line	0	loadk        r47   k72 ; k72 = 132
.line	0	loadk        r48   k90 ; k90 = 115
.line	0	loadk        r49   k12 ; k12 = 129
.line	0	loadk        r50  k179 ; k179 = 225
.line	0	loadk        r51   k11 ; k11 = 92
.line	0	loadk        r52  k180 ; k180 = 34
.line	0	loadk        r53  k181 ; k181 = 142
.line	0	loadk        r54   k68 ; k68 = 173
.line	0	loadk        r55   k60 ; k60 = 134
.line	0	loadk        r56   k66 ; k66 = 182
.line	0	loadk        r57  k182 ; k182 = 127
.line	0	loadk        r58   k79 ; k79 = 212
.line	0	loadk        r59  k103 ; k103 = 2
.line	0	loadk        r60  k138 ; k138 = 248
.line	0	call         r20    41     2
.line	0	move         r21    r1
.line	0	loadk        r22  k183 ; k183 = 94
.line	0	loadk        r23  k184 ; k184 = 158
.line	0	loadk        r24   k81 ; k81 = 254
.line	0	loadk        r25   k78 ; k78 = 209
.line	0	loadk        r26   k49 ; k49 = 190
.line	0	loadk        r27  k185 ; k185 = 151
.line	0	loadk        r28  k186 ; k186 = 96
.line	0	loadk        r29   k20 ; k20 = 128
.line	0	loadk        r30   k77 ; k77 = 47
.line	0	loadk        r31   k56 ; k56 = 121
.line	0	loadk        r32   k12 ; k12 = 129
.line	0	loadk        r33  k187 ; k187 = 82
.line	0	loadk        r34  k166 ; k166 = 143
.line	0	loadk        r35  k140 ; k140 = 219
.line	0	loadk        r36  k133 ; k133 = 91
.line	0	loadk        r37  k188 ; k188 = 40
.line	0	call         r21    17     0
.line	0	setlist      r19     0     1
.line	0	call         r18     2     2
.line	0	call         r17     2     2
.line	0	gettabup     r18    u0   k16 ; k16 = "require"
.line	0	gettabup     r19    u0   k17 ; k17 = "table"
.line	0	gettable     r19   r19   k18 ; k18 = "concat"
.line	0	newtable     r20     1     0
.line	0	move         r21    r1
.line	0	loadk        r22   k57 ; k57 = 77
.line	0	loadk        r23   k58 ; k58 = 141
.line	0	loadk        r24   k59 ; k59 = 242
.line	0	loadk        r25   k22 ; k22 = 221
.line	0	loadk        r26   k60 ; k60 = 134
.line	0	loadk        r27   k61 ; k61 = 204
.line	0	loadk        r28   k62 ; k62 = 68
.line	0	loadk        r29   k32 ; k32 = 216
.line	0	loadk        r30   k63 ; k63 = 7
.line	0	loadk        r31   k64 ; k64 = 120
.line	0	loadk        r32   k65 ; k65 = 145
.line	0	loadk        r33   k30 ; k30 = 46
.line	0	loadk        r34   k66 ; k66 = 182
.line	0	loadk        r35   k32 ; k32 = 216
.line	0	loadk        r36   k11 ; k11 = 92
.line	0	loadk        r37   k67 ; k67 = 57
.line	0	loadk        r38   k15 ; k15 = 131
.line	0	loadk        r39   k59 ; k59 = 242
.line	0	loadk        r40  k153 ; k153 = 188
.line	0	loadk        r41  k138 ; k138 = 248
.line	0	loadk        r42   k39 ; k39 = 86
.line	0	loadk        r43  k173 ; k173 = 224
.line	0	loadk        r44  k168 ; k168 = 33
.line	0	loadk        r45   k42 ; k42 = 232
.line	0	loadk        r46  k158 ; k158 = 24
.line	0	loadk        r47   k43 ; k43 = 107
.line	0	loadk        r48   k72 ; k72 = 132
.line	0	loadk        r49   k90 ; k90 = 115
.line	0	loadk        r50   k12 ; k12 = 129
.line	0	loadk        r51  k179 ; k179 = 225
.line	0	loadk        r52   k11 ; k11 = 92
.line	0	loadk        r53  k180 ; k180 = 34
.line	0	loadk        r54  k181 ; k181 = 142
.line	0	loadk        r55   k68 ; k68 = 173
.line	0	loadk        r56   k60 ; k60 = 134
.line	0	loadk        r57   k66 ; k66 = 182
.line	0	loadk        r58  k182 ; k182 = 127
.line	0	loadk        r59   k79 ; k79 = 212
.line	0	loadk        r60  k103 ; k103 = 2
.line	0	loadk        r61  k138 ; k138 = 248
.line	0	call         r21    41     2
.line	0	move         r22    r1
.line	0	loadk        r23  k183 ; k183 = 94
.line	0	loadk        r24  k184 ; k184 = 158
.line	0	loadk        r25   k81 ; k81 = 254
.line	0	loadk        r26   k78 ; k78 = 209
.line	0	loadk        r27   k49 ; k49 = 190
.line	0	loadk        r28  k185 ; k185 = 151
.line	0	loadk        r29  k143 ; k143 = 100
.line	0	loadk        r30   k95 ; k95 = 149
.line	0	loadk        r31  k144 ; k144 = 62
.line	0	loadk        r32  k163 ; k163 = 126
.line	0	loadk        r33   k15 ; k15 = 131
.line	0	loadk        r34   k19 ; k19 = 105
.line	0	loadk        r35  k181 ; k181 = 142
.line	0	loadk        r36  k189 ; k189 = 206
.line	0	loadk        r37  k147 ; k147 = 106
.line	0	loadk        r38   k41 ; k41 = 50
.line	0	loadk        r39  k185 ; k185 = 151
.line	0	loadk        r40  k129 ; k129 = 185
.line	0	call         r22    19     0
.line	0	setlist      r20     0     1
.line	0	call         r19     2     2
.line	0	call         r18     2     2
.line	0	gettabup     r19    u0   k16 ; k16 = "require"
.line	0	gettabup     r20    u0   k17 ; k17 = "table"
.line	0	gettable     r20   r20   k18 ; k18 = "concat"
.line	0	newtable     r21     1     0
.line	0	move         r22    r1
.line	0	loadk        r23   k57 ; k57 = 77
.line	0	loadk        r24   k58 ; k58 = 141
.line	0	loadk        r25   k59 ; k59 = 242
.line	0	loadk        r26   k22 ; k22 = 221
.line	0	loadk        r27   k60 ; k60 = 134
.line	0	loadk        r28   k61 ; k61 = 204
.line	0	loadk        r29   k62 ; k62 = 68
.line	0	loadk        r30   k32 ; k32 = 216
.line	0	loadk        r31   k63 ; k63 = 7
.line	0	loadk        r32   k64 ; k64 = 120
.line	0	loadk        r33   k65 ; k65 = 145
.line	0	loadk        r34   k30 ; k30 = 46
.line	0	loadk        r35   k66 ; k66 = 182
.line	0	loadk        r36   k32 ; k32 = 216
.line	0	loadk        r37   k11 ; k11 = 92
.line	0	loadk        r38   k67 ; k67 = 57
.line	0	loadk        r39   k15 ; k15 = 131
.line	0	loadk        r40   k59 ; k59 = 242
.line	0	loadk        r41  k153 ; k153 = 188
.line	0	loadk        r42  k138 ; k138 = 248
.line	0	loadk        r43   k39 ; k39 = 86
.line	0	loadk        r44  k173 ; k173 = 224
.line	0	loadk        r45  k168 ; k168 = 33
.line	0	loadk        r46   k42 ; k42 = 232
.line	0	loadk        r47  k158 ; k158 = 24
.line	0	loadk        r48   k43 ; k43 = 107
.line	0	loadk        r49   k72 ; k72 = 132
.line	0	loadk        r50   k90 ; k90 = 115
.line	0	loadk        r51   k12 ; k12 = 129
.line	0	loadk        r52  k179 ; k179 = 225
.line	0	loadk        r53   k11 ; k11 = 92
.line	0	loadk        r54  k180 ; k180 = 34
.line	0	loadk        r55  k181 ; k181 = 142
.line	0	loadk        r56   k68 ; k68 = 173
.line	0	loadk        r57   k60 ; k60 = 134
.line	0	loadk        r58   k66 ; k66 = 182
.line	0	loadk        r59  k182 ; k182 = 127
.line	0	loadk        r60   k79 ; k79 = 212
.line	0	loadk        r61  k103 ; k103 = 2
.line	0	loadk        r62  k138 ; k138 = 248
.line	0	call         r22    41     2
.line	0	move         r23    r1
.line	0	loadk        r24  k183 ; k183 = 94
.line	0	loadk        r25  k184 ; k184 = 158
.line	0	loadk        r26   k81 ; k81 = 254
.line	0	loadk        r27   k78 ; k78 = 209
.line	0	loadk        r28   k49 ; k49 = 190
.line	0	loadk        r29  k185 ; k185 = 151
.line	0	loadk        r30  k143 ; k143 = 100
.line	0	loadk        r31   k95 ; k95 = 149
.line	0	loadk        r32  k144 ; k144 = 62
.line	0	loadk        r33  k163 ; k163 = 126
.line	0	loadk        r34   k15 ; k15 = 131
.line	0	loadk        r35   k19 ; k19 = 105
.line	0	loadk        r36  k181 ; k181 = 142
.line	0	loadk        r37  k189 ; k189 = 206
.line	0	loadk        r38  k147 ; k147 = 106
.line	0	loadk        r39   k41 ; k41 = 50
.line	0	loadk        r40  k181 ; k181 = 142
.line	0	loadk        r41  k148 ; k148 = 176
.line	0	loadk        r42   k44 ; k44 = 138
.line	0	call         r23    20     0
.line	0	setlist      r21     0     1
.line	0	call         r20     2     2
.line	0	call         r19     2     0
.line	0	setlist      r16     0     1
.line	0	gettabup     r17    u0   k16 ; k16 = "require"
.line	0	move         r18    r1
.line	0	loadk        r19   k19 ; k19 = 105
.line	0	loadk        r20   k15 ; k15 = 131
.line	0	loadk        r21   k59 ; k59 = 242
.line	0	loadk        r22   k46 ; k46 = 213
.line	0	loadk        r23  k122 ; k122 = 165
.line	0	loadk        r24  k160 ; k160 = 215
.line	0	loadk        r25   k25 ; k25 = 11
.line	0	loadk        r26  k190 ; k190 = 130
.line	0	loadk        r27  k191 ; k191 = 56
.line	0	loadk        r28  k192 ; k192 = 118
.line	0	loadk        r29  k123 ; k123 = 156
.line	0	loadk        r30  k169 ; k169 = 116
.line	0	call         r18    13     2
.line	0	call         r17     2     2
.line	0	gettabup     r18    u0   k16 ; k16 = "require"
.line	0	move         r19    r1
.line	0	loadk        r20   k19 ; k19 = 105
.line	0	loadk        r21   k20 ; k20 = 128
.line	0	loadk        r22   k21 ; k21 = 246
.line	0	loadk        r23   k22 ; k22 = 221
.line	0	loadk        r24   k23 ; k23 = 164
.line	0	loadk        r25   k24 ; k24 = 205
.line	0	loadk        r26   k25 ; k25 = 11
.line	0	loadk        r27   k26 ; k26 = 133
.line	0	loadk        r28   k27 ; k27 = 38
.line	0	loadk        r29   k28 ; k28 = 98
.line	0	loadk        r30   k29 ; k29 = 148
.line	0	loadk        r31   k52 ; k52 = 95
.line	0	loadk        r32  k166 ; k166 = 143
.line	0	loadk        r33  k193 ; k193 = 222
.line	0	loadk        r34  k194 ; k194 = 97
.line	0	loadk        r35   k34 ; k34 = 61
.line	0	loadk        r36  k195 ; k195 = 136
.line	0	loadk        r37  k196 ; k196 = 189
.line	0	loadk        r38  k190 ; k190 = 130
.line	0	loadk        r39   k53 ; k53 = 237
.line	0	loadk        r40   k57 ; k57 = 77
.line	0	loadk        r41   k40 ; k40 = 230
.line	0	loadk        r42  k197 ; k197 = 39
.line	0	loadk        r43   k68 ; k68 = 173
.line	0	loadk        r44  k169 ; k169 = 116
.line	0	loadk        r45  k126 ; k126 = 101
.line	0	loadk        r46   k72 ; k72 = 132
.line	0	loadk        r47   k88 ; k88 = 99
.line	0	loadk        r48  k166 ; k166 = 143
.line	0	call         r19    30     2
.line	0	call         r18     2     2
.line	0	gettable     r19   r17  k198 ; k198 = "TraitClass"
.line	0	move         r20   r18
.line	0	loadnil      r21     0
.line	0	move         r22    r2
.line	0	move         r23   r16
.line	0	call         r19     5     2
.line	0	closure      r20    f1
.line	0	settable      r2  k199   r20 ; k199 = "ctor"
.line	0	closure      r20    f2
.line	0	settable      r2  k200   r20 ; k200 = "OnInitialize"
.line	0	closure      r20    f3
.line	0	settable      r2  k201   r20 ; k201 = "RegistEvents"
.line	0	closure      r20    f4
.line	0	settable      r2  k202   r20 ; k202 = "OnPostInitialize"
.line	0	closure      r20    f5
.line	0	settable      r2  k203   r20 ; k203 = "OnClose"
.line	0	closure      r20    f6
.line	0	settable      r2  k204   r20 ; k204 = "OnClickedGroup"
.line	0	closure      r20    f7
.line	0	settable      r2  k205   r20 ; k205 = "OnClickedBuyRP"
.line	0	closure      r20    f8
.line	0	settable      r2  k206   r20 ; k206 = "OnClickedCreateGroup"
.line	0	closure      r20    f9
.line	0	settable      r2  k207   r20 ; k207 = "OnClickedGroupReward" (truncated)
.line	0	closure      r20   f10
.line	0	settable      r2  k208   r20 ; k208 = "OnClickedMemberNumHe" (truncated)
.line	0	closure      r20   f11
.line	0	settable      r2  k209   r20 ; k209 = "OnClickedReceiveGrou" (truncated)
.line	0	closure      r20   f12
.line	0	settable      r2  k210   r20 ; k210 = "OnClickedJKDetail"
.line	0	closure      r20   f13
.line	0	settable      r2  k211   r20 ; k211 = "OnClickedOpenLinkage" (truncated)
.line	0	closure      r20   f14
.line	0	settable      r2  k212   r20 ; k212 = "OnClickedUpgradeRPPl" (truncated)
.line	0	closure      r20   f15
.line	0	settable      r2  k213   r20 ; k213 = "OnClickRepurchase"
.line	0	closure      r20   f16
.line	0	settable      r2  k214   r20 ; k214 = "OnClickedSwitchToBuy" (truncated)
.line	0	closure      r20   f17
.line	0	settable      r2  k215   r20 ; k215 = "OnJumpLuckCardButton" (truncated)
.line	0	closure      r20   f18
.line	0	settable      r2  k216   r20 ; k216 = "OnClickedReceiveLuck" (truncated)
.line	0	closure      r20   f19
.line	0	settable      r2  k217   r20 ; k217 = "OnLinkageRewardButto" (truncated)
.line	0	closure      r20   f20
.line	0	settable      r2  k218   r20 ; k218 = "OnClickedQuickGroup"
.line	0	closure      r20   f21
.line	0	settable      r2  k219   r20 ; k219 = "OnClickedInvitateRec" (truncated)
.line	0	closure      r20   f22
.line	0	settable      r2  k220   r20 ; k220 = "OnUpdateGroupUI"
.line	0	closure      r20   f23
.line	0	settable      r2  k221   r20 ; k221 = "OnUpdateGroupRewardS" (truncated)
.line	0	closure      r20   f24
.line	0	settable      r2  k222   r20 ; k222 = "OnUpdateGroupMemberS" (truncated)
.line	0	closure      r20   f25
.line	0	settable      r2  k223   r20 ; k223 = "OnRPInfoUpdate"
.line	0	closure      r20   f26
.line	0	settable      r2  k224   r20 ; k224 = "OnUpdateNormalPassIn" (truncated)
.line	0	closure      r20   f27
.line	0	settable      r2  k225   r20 ; k225 = "OnRPGroupInvitedReco" (truncated)
.line	0	closure      r20   f28
.line	0	settable      r2  k226   r20 ; k226 = "OnUpdateInvitedRecor" (truncated)
.line	0	closure      r20   f29
.line	0	settable      r2  k227   r20 ; k227 = "OnUpdateInvitedRecor" (truncated)
.line	0	closure      r20   f30
.line	0	settable      r2  k228   r20 ; k228 = "OnUpdateJKDetailButt" (truncated)
.line	0	closure      r20   f31
.line	0	settable      r2  k229   r20 ; k229 = "OnUpdateGroupBuyText"
.line	0	closure      r20   f32
.line	0	settable      r2  k230   r20 ; k230 = "UpdateLuckyCardRewar" (truncated)
.line	0	closure      r20   f33
.line	0	settable      r2  k231   r20 ; k231 = "RefreshLinkageReward" (truncated)
.line	0	closure      r20   f34
.line	0	settable      r2  k232   r20 ; k232 = "OnUpdateGroupBuyRPUI"
.line	0	closure      r20   f35
.line	0	settable      r2  k233   r20 ; k233 = "_GetBuyItemNodes"
.line	0	closure      r20   f36
.line	0	settable      r2  k234   r20 ; k234 = "_SetupBuyItemRewardL" (truncated)
.line	0	closure      r20   f37
.line	0	settable      r2  k235   r20 ; k235 = "_RefreshBuyItemBtn"
.line	0	closure      r20   f38
.line	0	settable      r2  k236   r20 ; k236 = "_RefreshExtraLocalTe" (truncated)
.line	0	closure      r20   f39
.line	0	settable      r2  k237   r20 ; k237 = "_RegistBuyItemBtnEve" (truncated)
.line	0	closure      r20   f40
.line	0	settable      r2  k238   r20 ; k238 = "OnClickBuyItem"
.line	0	closure      r20   f41
.line	0	settable      r2  k239   r20 ; k239 = "OnClickNewUserPrivil" (truncated)
.line	0	closure      r20   f42
.line	0	settable      r2  k240   r20 ; k240 = "RefreshExperienceNor" (truncated)
.line	0	closure      r20   f43
.line	0	settable      r2  k241   r20 ; k241 = "_GetExperienceBuySta" (truncated)
.line	0	closure      r20   f44
.line	0	settable      r2  k242   r20 ; k242 = "_DetermineExperience" (truncated)
.line	0	closure      r20   f45
.line	0	settable      r2  k243   r20 ; k243 = "_UpdateExperienceBuy" (truncated)
.line	0	closure      r20   f46
.line	0	settable      r2  k244   r20 ; k244 = "_SetExperiencePriceV" (truncated)
.line	0	closure      r20   f47
.line	0	settable      r2  k245   r20 ; k245 = "RefreshNormalBuyBtn"
.line	0	closure      r20   f48
.line	0	settable      r2  k246   r20 ; k246 = "_GetNormalBuyState"
.line	0	closure      r20   f49
.line	0	settable      r2  k247   r20 ; k247 = "_DetermineNormalBuyT" (truncated)
.line	0	closure      r20   f50
.line	0	settable      r2  k248   r20 ; k248 = "_UpdateNormalBuyDisp" (truncated)
.line	0	closure      r20   f51
.line	0	settable      r2  k249   r20 ; k249 = "SetNormalPriceViaBuy" (truncated)
.line	0	closure      r20   f52
.line	0	settable      r2  k250   r20 ; k250 = "RefreshEliteBuyBtn"
.line	0	closure      r20   f53
.line	0	settable      r2  k251   r20 ; k251 = "_GetEliteBuyState"
.line	0	closure      r20   f54
.line	0	settable      r2  k252   r20 ; k252 = "_DetermineEliteBuyTy" (truncated)
.line	0	closure      r20   f55
.line	0	settable      r2  k253   r20 ; k253 = "_UpdateEliteBuyDispl" (truncated)
.line	0	closure      r20   f56
.line	0	settable      r2  k254   r20 ; k254 = "SetElitePriceViaBuyT" (truncated)
.line	0	closure      r20   f57
.line	0	settable      r2  k255   r20 ; k255 = "OnUpdateLinkageRewar" (truncated)
.line	0	loadk        r20  k256 ; k256 = "SwitchTab"
.line	0	closure      r21   f58
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k257 ; k257 = "UpdateTabPage"
.line	0	closure      r21   f59
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k258 ; k258 = "InitText"
.line	0	closure      r21   f60
.line	0	settable      r2   r20   r21
.line	0	loadk        r20  k259 ; k259 = "UpdateLinkageRewardI" (truncated)
.line	0	closure      r21   f61
.line	0	settable      r2   r20   r21
.line	0	newtable     r20     3     0
.line	0	move         r21    r1
.line	0	loadk        r22  k260 ; k260 = 79
.line	0	loadk        r23  k261 ; k261 = 148
.line	0	loadk        r24  k262 ; k262 = 239
.line	0	loadk        r25  k263 ; k263 = 221
.line	0	loadk        r26  k264 ; k264 = 184
.line	0	loadk        r27  k265 ; k265 = 208
.line	0	loadk        r28  k266 ; k266 = 64
.line	0	loadk        r29  k267 ; k267 = 152
.line	0	loadk        r30  k268 ; k268 = 41
.line	0	loadk        r31  k269 ; k269 = 114
.line	0	call         r21    11     2
.line	0	move         r22    r1
.line	0	loadk        r23  k270 ; k270 = 68
.line	0	loadk        r24  k271 ; k271 = 131
.line	0	loadk        r25  k272 ; k272 = 237
.line	0	loadk        r26  k273 ; k273 = 213
.line	0	loadk        r27  k274 ; k274 = 171
.line	0	loadk        r28  k273 ; k273 = 213
.line	0	call         r22     7     2
.line	0	move         r23    r1
.line	0	loadk        r24  k275 ; k275 = 90
.line	0	loadk        r25  k276 ; k276 = 128
.line	0	loadk        r26  k277 ; k277 = 234
.line	0	loadk        r27  k278 ; k278 = 203
.line	0	call         r23     5     2
.line	0	setlist      r20     3     1
.line	0	newtable     r21     6     0
.line	0	move         r22    r1
.line	0	loadk        r23  k279 ; k279 = 77
.line	0	loadk        r24  k276 ; k276 = 128
.line	0	loadk        r25  k280 ; k280 = 240
.line	0	loadk        r26  k281 ; k281 = 207
.line	0	loadk        r27  k282 ; k282 = 149
.line	0	loadk        r28  k283 ; k283 = 248
.line	0	loadk        r29  k284 ; k284 = 122
.line	0	loadk        r30  k285 ; k285 = 198
.line	0	loadk        r31  k284 ; k284 = 122
.line	0	loadk        r32  k286 ; k286 = 38
.line	0	call         r22    11     2
.line	0	move         r23    r1
.line	0	loadk        r24  k279 ; k279 = 77
.line	0	loadk        r25  k276 ; k276 = 128
.line	0	loadk        r26  k280 ; k280 = 240
.line	0	loadk        r27  k281 ; k281 = 207
.line	0	loadk        r28  k282 ; k282 = 149
.line	0	loadk        r29  k283 ; k283 = 248
.line	0	loadk        r30  k284 ; k284 = 122
.line	0	loadk        r31  k285 ; k285 = 198
.line	0	loadk        r32  k284 ; k284 = 122
.line	0	loadk        r33  k287 ; k287 = 37
.line	0	call         r23    11     2
.line	0	move         r24    r1
.line	0	loadk        r25  k279 ; k279 = 77
.line	0	loadk        r26  k276 ; k276 = 128
.line	0	loadk        r27  k280 ; k280 = 240
.line	0	loadk        r28  k281 ; k281 = 207
.line	0	loadk        r29  k282 ; k282 = 149
.line	0	loadk        r30  k288 ; k288 = 251
.line	0	loadk        r31  k284 ; k284 = 122
.line	0	loadk        r32  k285 ; k285 = 198
.line	0	loadk        r33  k284 ; k284 = 122
.line	0	loadk        r34  k286 ; k286 = 38
.line	0	call         r24    11     2
.line	0	move         r25    r1
.line	0	loadk        r26  k279 ; k279 = 77
.line	0	loadk        r27  k276 ; k276 = 128
.line	0	loadk        r28  k280 ; k280 = 240
.line	0	loadk        r29  k281 ; k281 = 207
.line	0	loadk        r30  k282 ; k282 = 149
.line	0	loadk        r31  k288 ; k288 = 251
.line	0	loadk        r32  k284 ; k284 = 122
.line	0	loadk        r33  k285 ; k285 = 198
.line	0	loadk        r34  k284 ; k284 = 122
.line	0	loadk        r35  k287 ; k287 = 37
.line	0	call         r25    11     2
.line	0	move         r26    r1
.line	0	loadk        r27  k279 ; k279 = 77
.line	0	loadk        r28  k276 ; k276 = 128
.line	0	loadk        r29  k280 ; k280 = 240
.line	0	loadk        r30  k281 ; k281 = 207
.line	0	loadk        r31  k282 ; k282 = 149
.line	0	loadk        r32  k289 ; k289 = 250
.line	0	loadk        r33  k284 ; k284 = 122
.line	0	loadk        r34  k285 ; k285 = 198
.line	0	loadk        r35  k284 ; k284 = 122
.line	0	loadk        r36  k286 ; k286 = 38
.line	0	call         r26    11     2
.line	0	move         r27    r1
.line	0	loadk        r28  k279 ; k279 = 77
.line	0	loadk        r29  k276 ; k276 = 128
.line	0	loadk        r30  k280 ; k280 = 240
.line	0	loadk        r31  k281 ; k281 = 207
.line	0	loadk        r32  k282 ; k282 = 149
.line	0	loadk        r33  k289 ; k289 = 250
.line	0	loadk        r34  k284 ; k284 = 122
.line	0	loadk        r35  k285 ; k285 = 198
.line	0	loadk        r36  k284 ; k284 = 122
.line	0	loadk        r37  k287 ; k287 = 37
.line	0	call         r27    11     2
.line	0	setlist      r21     6     1
.line	0	loadk        r22  k290 ; k290 = 18130200
.line	0	loadk        r23  k291 ; k291 = 18140081
.line	0	loadk        r24  k292 ; k292 = 18141419
.line	0	loadk        r25  k293 ; k293 = 6162
.line	0	loadk        r26  k294 ; k294 = 101
.line	0	loadk        r27  k295 ; k295 = 102
.line	0	loadk        r28  k296 ; k296 = 103
.line	0	loadk        r29  k297 ; k297 = "_SetRPRewardTexts"
.line	0	closure      r30   f62
.line	0	settable      r2   r29   r30
.line	0	loadk        r29  k298 ; k298 = "_SetRPJumpVisible"
.line	0	closure      r30   f63
.line	0	settable      r2   r29   r30
.line	0	loadk        r29  k299 ; k299 = "_SetRPBuyBtnState"
.line	0	closure      r30   f64
.line	0	settable      r2   r29   r30
.line	0	loadk        r29  k300 ; k300 = "_SetRPReceiveBtnEnab" (truncated)
.line	0	closure      r30   f65
.line	0	settable      r2   r29   r30
.line	0	loadk        r29  k301 ; k301 = "_SetRPRewardGlowVisi" (truncated)
.line	0	closure      r30   f66
.line	0	settable      r2   r29   r30
.line	0	newtable     r29     3     0
.line	0	move         r30    r1
.line	0	loadk        r31  k302 ; k302 = 88
.line	0	loadk        r32  k303 ; k303 = 137
.line	0	loadk        r33  k288 ; k288 = 251
.line	0	loadk        r34  k304 ; k304 = 220
.line	0	loadk        r35  k305 ; k305 = 165
.line	0	loadk        r36  k306 ; k306 = 205
.line	0	loadk        r37  k307 ; k307 = 122
.line	0	loadk        r38  k308 ; k308 = 183
.line	0	loadk        r39  k309 ; k309 = 36
.line	0	loadk        r40  k310 ; k310 = 116
.line	0	loadk        r41  k311 ; k311 = 157
.line	0	loadk        r42  k312 ; k312 = 111
.line	0	loadk        r43  k313 ; k313 = 136
.line	0	loadk        r44  k314 ; k314 = 232
.line	0	loadk        r45  k315 ; k315 = 123
.line	0	loadk        r46  k316 ; k316 = 35
.line	0	loadk        r47  k317 ; k317 = 138
.line	0	loadk        r48  k318 ; k318 = 185
.line	0	loadk        r49  k311 ; k311 = 157
.line	0	loadk        r50  k319 ; k319 = 225
.line	0	loadk        r51  k320 ; k320 = 95
.line	0	loadk        r52  k321 ; k321 = 231
.line	0	loadk        r53  k322 ; k322 = 54
.line	0	loadk        r54  k323 ; k323 = 163
.line	0	call         r30    25     2
.line	0	move         r31    r1
.line	0	loadk        r32  k302 ; k302 = 88
.line	0	loadk        r33  k303 ; k303 = 137
.line	0	loadk        r34  k288 ; k288 = 251
.line	0	loadk        r35  k304 ; k304 = 220
.line	0	loadk        r36  k305 ; k305 = 165
.line	0	loadk        r37  k306 ; k306 = 205
.line	0	loadk        r38  k307 ; k307 = 122
.line	0	loadk        r39  k308 ; k308 = 183
.line	0	loadk        r40  k309 ; k309 = 36
.line	0	loadk        r41  k310 ; k310 = 116
.line	0	loadk        r42  k311 ; k311 = 157
.line	0	loadk        r43  k312 ; k312 = 111
.line	0	loadk        r44  k313 ; k313 = 136
.line	0	loadk        r45  k314 ; k314 = 232
.line	0	loadk        r46  k324 ; k324 = 112
.line	0	loadk        r47  k325 ; k325 = 52
.line	0	loadk        r48  k313 ; k313 = 136
.line	0	loadk        r49  k326 ; k326 = 177
.line	0	loadk        r50  k327 ; k327 = 142
.line	0	loadk        r51  k328 ; k328 = 228
.line	0	call         r31    21     2
.line	0	move         r32    r1
.line	0	loadk        r33  k302 ; k302 = 88
.line	0	loadk        r34  k303 ; k303 = 137
.line	0	loadk        r35  k288 ; k288 = 251
.line	0	loadk        r36  k304 ; k304 = 220
.line	0	loadk        r37  k305 ; k305 = 165
.line	0	loadk        r38  k306 ; k306 = 205
.line	0	loadk        r39  k307 ; k307 = 122
.line	0	loadk        r40  k308 ; k308 = 183
.line	0	loadk        r41  k309 ; k309 = 36
.line	0	loadk        r42  k310 ; k310 = 116
.line	0	loadk        r43  k311 ; k311 = 157
.line	0	loadk        r44  k312 ; k312 = 111
.line	0	loadk        r45  k313 ; k313 = 136
.line	0	loadk        r46  k314 ; k314 = 232
.line	0	loadk        r47  k329 ; k329 = 110
.line	0	loadk        r48  k330 ; k330 = 55
.line	0	loadk        r49  k331 ; k331 = 143
.line	0	loadk        r50  k332 ; k332 = 175
.line	0	call         r32    19     2
.line	0	setlist      r29     3     1
.line	0	loadk        r30  k333 ; k333 = "_SetRPRewardReddot"
.line	0	closure      r31   f67
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k334 ; k334 = "UpdateGroupRewardSta" (truncated)
.line	0	closure      r31   f68
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k335 ; k335 = "OnUpdateGroupRewardT" (truncated)
.line	0	closure      r31   f69
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k336 ; k336 = "UpdateFirstBuyPrivil" (truncated)
.line	0	closure      r31   f70
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k337 ; k337 = "UpdateGroupState"
.line	0	closure      r31   f71
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k338 ; k338 = "InitLoopData"
.line	0	closure      r31   f72
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k339 ; k339 = "InitTrait"
.line	0	closure      r31   f73
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k340 ; k340 = "GetActTime"
.line	0	closure      r31   f74
.line	0	settable      r2   r30   r31
.line	0	loadk        r30  k341 ; k341 = "ShowReward"
.line	0	closure      r31   f75
.line	0	settable      r2   r30   r31
.line	0	return       r19     2
.line	0	return        r0     1
.line	0	move          r0    r0
.line	0	gettabup      r1    u1   k55 ; k55 = 186
.line	0	return        r0     1

.function	main/f0

.source	null
.linedefined	2
.lastlinedefined	9
.numparams	0
.is_vararg	1
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	0	true

.constant	k0	1
.constant	k1	"string"
.constant	k2	"char"
.constant	k3	16
.constant	k4	31
.constant	k5	7
.constant	k6	256
.constant	k7	"table"
.constant	k8	"concat"

.line	2	newtable      r0     0     0
.line	2	vararg        r1     0
.line	2	setlist       r0     0     1
.line	2	newtable      r1     0     0
.line	2	loadk         r2    k0 ; k0 = 1
.line	2	len           r3    r0
.line	2	loadk         r4    k0 ; k0 = 1
.line	2	move          r0    r0
.line	2	gettabup      r6    u0    k1 ; k1 = "string"
.line	2	gettable      r6    r6    k2 ; k2 = "char"
.line	2	gettable      r7    r0    r5
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mod           r8    r8    k3 ; k3 = 16
.line	2	add           r8    r8    k0 ; k0 = 1
.line	2	gettabup      r8    u1    r8
.line	2	bxor          r7    r7    r8
.line	2	sub           r8    r5    k0 ; k0 = 1
.line	2	mul           r8    r8    k4 ; k4 = 31
.line	2	add           r8    r8    k5 ; k5 = 7
.line	2	mod           r8    r8    k6 ; k6 = 256
.line	2	bxor          r7    r7    r8
.line	2	mod           r7    r7    k6 ; k6 = 256
.line	2	call          r6     2     2
.line	2	settable      r1    r5    r6
.line	2	move          r0    r0
.line	2	gettabup      r2    u0    k7 ; k7 = "table"
.line	2	gettable      r2    r2    k8 ; k8 = "concat"
.line	2	move          r3    r1
.line	2	tailcall      r2     2
.line	2	return        r2     0
.line	2	return        r0     1
.line	2	move          r0    r0
.line	2	return        r0     1

.function	main/f1

.source	null
.linedefined	51
.lastlinedefined	56
.numparams	3
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	5	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"ActType"
.constant	k1	"RPGroup"
.constant	k2	"tExtraData"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	105
.constant	k7	128
.constant	k8	246
.constant	k9	221
.constant	k10	164
.constant	k11	205
.constant	k12	11
.constant	k13	133
.constant	k14	38
.constant	k15	98
.constant	k16	148
.constant	k17	46
.constant	k18	150
.constant	k19	216
.constant	k20	89
.constant	k21	50
.constant	k22	153
.constant	k23	242
.constant	k24	154
.constant	k25	230
.constant	k26	81
.constant	k27	231
.constant	k28	58
.constant	k29	177
.constant	k30	5
.constant	k31	119
.constant	k32	132
.constant	k33	99
.constant	k34	137
.constant	k35	96
.constant	k36	157
.constant	k37	158
.constant	k38	175
.constant	k39	200
.constant	k40	88
.constant	k41	252
.constant	k42	51
.constant	k43	191
.constant	k44	111
.constant	k45	155
.constant	k46	212
.constant	k47	165
.constant	k48	222
.constant	k49	76
.constant	k50	149
.constant	k51	21
.constant	k52	107
.constant	k53	73
.constant	k54	53
.constant	k55	138
.constant	k56	189
.constant	k57	156
.constant	k58	251
.constant	k59	101
.constant	k60	237
.constant	k61	52
.constant	k62	178
.constant	k63	59
.constant	k64	"bUseFirstBuyPrivilege"
.constant	k65	"IsShowFirstBuyPrivilege"

.line	51	gettabup      r3    u0    k1 ; k1 = "RPGroup"
.line	51	settable      r0    k0    r3 ; k0 = "ActType"
.line	51	settable      r0    k2    r2 ; k2 = "tExtraData"
.line	51	gettabup      r3    u1    k3 ; k3 = "require"
.line	51	gettabup      r4    u1    k4 ; k4 = "table"
.line	51	gettable      r4    r4    k5 ; k5 = "concat"
.line	51	newtable      r5     1     0
.line	51	getupval      r6    u2
.line	51	loadk         r7    k6 ; k6 = 105
.line	51	loadk         r8    k7 ; k7 = 128
.line	51	loadk         r9    k8 ; k8 = 246
.line	51	loadk        r10    k9 ; k9 = 221
.line	51	loadk        r11   k10 ; k10 = 164
.line	51	loadk        r12   k11 ; k11 = 205
.line	51	loadk        r13   k12 ; k12 = 11
.line	51	loadk        r14   k13 ; k13 = 133
.line	51	loadk        r15   k14 ; k14 = 38
.line	51	loadk        r16   k15 ; k15 = 98
.line	51	loadk        r17   k16 ; k16 = 148
.line	51	loadk        r18   k17 ; k17 = 46
.line	51	loadk        r19   k18 ; k18 = 150
.line	51	loadk        r20   k19 ; k19 = 216
.line	51	loadk        r21   k20 ; k20 = 89
.line	51	loadk        r22   k21 ; k21 = 50
.line	51	loadk        r23   k22 ; k22 = 153
.line	51	loadk        r24   k23 ; k23 = 242
.line	51	loadk        r25   k24 ; k24 = 154
.line	51	loadk        r26   k25 ; k25 = 230
.line	51	loadk        r27   k26 ; k26 = 81
.line	51	loadk        r28   k27 ; k27 = 231
.line	51	loadk        r29   k28 ; k28 = 58
.line	51	loadk        r30   k29 ; k29 = 177
.line	51	loadk        r31   k30 ; k30 = 5
.line	51	loadk        r32   k31 ; k31 = 119
.line	51	loadk        r33   k32 ; k32 = 132
.line	51	loadk        r34   k33 ; k33 = 99
.line	51	loadk        r35   k22 ; k22 = 153
.line	51	loadk        r36   k34 ; k34 = 137
.line	51	loadk        r37   k35 ; k35 = 96
.line	51	loadk        r38   k17 ; k17 = 46
.line	51	loadk        r39   k36 ; k36 = 157
.line	51	loadk        r40   k37 ; k37 = 158
.line	51	loadk        r41   k38 ; k38 = 175
.line	51	loadk        r42   k39 ; k39 = 200
.line	51	loadk        r43   k40 ; k40 = 88
.line	51	loadk        r44   k41 ; k41 = 252
.line	51	loadk        r45   k42 ; k42 = 51
.line	51	loadk        r46   k43 ; k43 = 191
.line	51	call          r6    41     2
.line	51	getupval      r7    u2
.line	51	loadk         r8   k44 ; k44 = 111
.line	51	loadk         r9   k45 ; k45 = 155
.line	51	loadk        r10   k29 ; k29 = 177
.line	51	loadk        r11   k46 ; k46 = 212
.line	51	loadk        r12   k47 ; k47 = 165
.line	51	loadk        r13   k48 ; k48 = 222
.line	51	loadk        r14   k49 ; k49 = 76
.line	51	loadk        r15   k50 ; k50 = 149
.line	51	loadk        r16   k51 ; k51 = 21
.line	51	loadk        r17   k15 ; k15 = 98
.line	51	loadk        r18   k45 ; k45 = 155
.line	51	loadk        r19   k52 ; k52 = 107
.line	51	loadk        r20   k16 ; k16 = 148
.line	51	loadk        r21   k19 ; k19 = 216
.line	51	loadk        r22   k53 ; k53 = 73
.line	51	loadk        r23   k54 ; k54 = 53
.line	51	loadk        r24   k55 ; k55 = 138
.line	51	loadk        r25   k56 ; k56 = 189
.line	51	loadk        r26   k57 ; k57 = 156
.line	51	loadk        r27   k58 ; k58 = 251
.line	51	loadk        r28   k59 ; k59 = 101
.line	51	loadk        r29   k60 ; k60 = 237
.line	51	loadk        r30   k61 ; k61 = 52
.line	51	loadk        r31   k62 ; k62 = 178
.line	51	loadk        r32   k63 ; k63 = 59
.line	51	call          r7    26     0
.line	51	setlist       r5     0     1
.line	51	call          r4     2     2
.line	51	call          r3     2     2
.line	51	gettable      r4    r3   k65 ; k65 = "IsShowFirstBuyPrivil" (truncated)
.line	51	call          r4     1     2
.line	51	settable      r0   k64    r4 ; k64 = "bUseFirstBuyPrivileg" (truncated)
.line	51	return        r0     1
.line	51	move          r0    r0
.line	51	move          r0    r0
.line	51	return        r0     1

.function	main/f2

.source	null
.linedefined	58
.lastlinedefined	88
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"require"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	105
.constant	k8	128
.constant	k9	246
.constant	k10	221
.constant	k11	164
.constant	k12	205
.constant	k13	11
.constant	k14	152
.constant	k15	47
.constant	k16	99
.constant	k17	130
.constant	k18	111
.constant	k19	136
.constant	k20	220
.constant	k21	16
.constant	k22	179
.constant	k23	155
.constant	k24	231
.constant	k25	89
.constant	k26	230
.constant	k27	57
.constant	k28	232
.constant	k29	24
.constant	k30	107
.constant	k31	132
.constant	k32	115
.constant	k33	129
.constant	k34	225
.constant	k35	92
.constant	k36	34
.constant	k37	142
.constant	k38	173
.constant	k39	134
.constant	k40	208
.constant	k41	75
.constant	k42	247
.constant	k43	33
.constant	k44	186
.constant	k45	158
.constant	k46	L"send_black_friday_get_rp_promotion_info_req"
.constant	k47	L"send_black_friday_get_rp_group_received_invitation_req"
.constant	k48	L"send_black_friday_get_rp_group_send_invitation_req"
.constant	k49	"IsJapanOrKoreaThreeStarPackage"
.constant	k50	"IsSubscriptionBunishment"
.constant	k51	203
.constant	k52	95
.constant	k53	251
.constant	k54	13
.constant	k55	183
.constant	k56	100
.constant	k57	243
.constant	k58	184
.constant	k59	L"send_black_friday_prime_get_relate_reward_req"
.constant	k60	"SetIsNeedUpdateInvitationTimeRecord"
.constant	k61	"LoopScrollBox_GroupList"
.constant	k62	"InitChildClassScrollBox"
.constant	k63	"UIRoot"
.constant	k64	77
.constant	k65	141
.constant	k66	242
.constant	k67	204
.constant	k68	68
.constant	k69	216
.constant	k70	7
.constant	k71	120
.constant	k72	145
.constant	k73	46
.constant	k74	182
.constant	k75	131
.constant	k76	188
.constant	k77	248
.constant	k78	86
.constant	k79	224
.constant	k80	127
.constant	k81	212
.constant	k82	2
.constant	k83	88
.constant	k84	177
.constant	k85	250
.constant	k86	166
.constant	k87	70
.constant	k88	157
.constant	k89	12
.constant	k90	101
.constant	k91	156
.constant	k92	206
.constant	k93	97
.constant	k94	9
.constant	k95	170
.constant	k96	169
.constant	k97	83
.constant	k98	236
.constant	k99	59
.constant	k100	162
.constant	k101	5
.constant	k102	78
.constant	k103	117
.constant	k104	135
.constant	k105	123
.constant	k106	168
.constant	k107	"LoopScrollBox_TeamMember"
.constant	k108	187
.constant	k109	237
.constant	k110	91
.constant	k111	228
.constant	k112	10
.constant	k113	143
.constant	k114	98
.constant	k115	79
.constant	k116	191
.constant	k117	238
.constant	k118	108
.constant	k119	27
.constant	k120	"GetIsHadReceiveReward"
.constant	k121	"GetIsNeedPopUpRewardUpgradePopup"
.constant	k122	"UIManager"
.constant	k123	"ShowUI"
.constant	k124	"UI_Config"
.constant	k125	"BlackFriday_RP_RewardUpgrades_Popup_UIBP"
.constant	k126	"PlayUserWidgetAnimation"
.constant	k127	"Anim_Tips"
.constant	k128	0
.constant	k129	1
.constant	k130	"tExtraData"
.constant	k131	"bIsJumpRPGroup"
.constant	k132	"jumpFromRP"
.constant	k133	"ReportTLogEvent"
.constant	k134	"TLogEventDefine"
.constant	k135	L"BlackFridayRPGroup_ClickToRPGroupActivity"
.constant	k136	3
.constant	k137	"Logic_BFSubscribeModule"
.constant	k138	"GetIsSamsung"
.constant	k139	"SetWidgetVisible"
.constant	k140	"Border_LinkageReward"

.line	58	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	58	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	58	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	58	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	58	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	58	call          r1     2     2
.line	58	gettabup      r2    u0    k4 ; k4 = "require"
.line	58	gettabup      r3    u0    k5 ; k5 = "table"
.line	58	gettable      r3    r3    k6 ; k6 = "concat"
.line	58	newtable      r4     1     0
.line	58	getupval      r5    u1
.line	58	loadk         r6    k7 ; k7 = 105
.line	58	loadk         r7    k8 ; k8 = 128
.line	58	loadk         r8    k9 ; k9 = 246
.line	58	loadk         r9   k10 ; k10 = 221
.line	58	loadk        r10   k11 ; k11 = 164
.line	58	loadk        r11   k12 ; k12 = 205
.line	58	loadk        r12   k13 ; k13 = 11
.line	58	loadk        r13   k14 ; k14 = 152
.line	58	loadk        r14   k15 ; k15 = 47
.line	58	loadk        r15   k16 ; k16 = 99
.line	58	loadk        r16   k17 ; k17 = 130
.line	58	loadk        r17   k18 ; k18 = 111
.line	58	loadk        r18   k19 ; k19 = 136
.line	58	loadk        r19   k20 ; k20 = 220
.line	58	loadk        r20   k21 ; k21 = 16
.line	58	loadk        r21   k13 ; k13 = 11
.line	58	loadk        r22   k19 ; k19 = 136
.line	58	loadk        r23   k22 ; k22 = 179
.line	58	loadk        r24   k23 ; k23 = 155
.line	58	loadk        r25   k24 ; k24 = 231
.line	58	loadk        r26   k25 ; k25 = 89
.line	58	loadk        r27   k26 ; k26 = 230
.line	58	loadk        r28   k27 ; k27 = 57
.line	58	loadk        r29   k28 ; k28 = 232
.line	58	loadk        r30   k29 ; k29 = 24
.line	58	loadk        r31   k30 ; k30 = 107
.line	58	loadk        r32   k31 ; k31 = 132
.line	58	loadk        r33   k32 ; k32 = 115
.line	58	loadk        r34   k33 ; k33 = 129
.line	58	loadk        r35   k34 ; k34 = 225
.line	58	loadk        r36   k35 ; k35 = 92
.line	58	loadk        r37   k36 ; k36 = 34
.line	58	loadk        r38   k37 ; k37 = 142
.line	58	loadk        r39   k38 ; k38 = 173
.line	58	loadk        r40   k39 ; k39 = 134
.line	58	loadk        r41   k40 ; k40 = 208
.line	58	loadk        r42   k41 ; k41 = 75
.line	58	loadk        r43   k42 ; k42 = 247
.line	58	loadk        r44   k43 ; k43 = 33
.line	58	loadk        r45   k44 ; k44 = 186
.line	58	call          r5    41     2
.line	58	getupval      r6    u1
.line	58	loadk         r7   k18 ; k18 = 111
.line	58	loadk         r8   k45 ; k45 = 158
.line	58	call          r6     3     0
.line	58	setlist       r4     0     1
.line	58	call          r3     2     2
.line	58	call          r2     2     2
.line	58	gettable      r3    r2   k46 ; k46 = L"send_black_friday_ge" (truncated)
.line	58	call          r3     1     1
.line	58	gettable      r3    r2   k47 ; k47 = L"send_black_friday_ge" (truncated)
.line	58	call          r3     1     1
.line	58	gettable      r3    r2   k48 ; k48 = L"send_black_friday_ge" (truncated)
.line	58	call          r3     1     1
.line	58	self          r3    r1   k49 ; k49 = "IsJapanOrKoreaThreeS" (truncated)
.line	58	call          r3     2     2
.line	58	test          r3     1
.line	58	jmp            0  l132
.line	58	self          r3    r1   k50 ; k50 = "IsSubscriptionBunish" (truncated)
.line	58	call          r3     2     2
.line	58	test          r3     1
.line	58	jmp            0  l132
.line	58	gettabup      r3    u0    k4 ; k4 = "require"
.line	58	gettabup      r4    u0    k5 ; k5 = "table"
.line	58	gettable      r4    r4    k6 ; k6 = "concat"
.line	58	newtable      r5     1     0
.line	58	getupval      r6    u1
.line	58	loadk         r7    k7 ; k7 = 105
.line	58	loadk         r8    k8 ; k8 = 128
.line	58	loadk         r9    k9 ; k9 = 246
.line	58	loadk        r10   k10 ; k10 = 221
.line	58	loadk        r11   k11 ; k11 = 164
.line	58	loadk        r12   k12 ; k12 = 205
.line	58	loadk        r13   k13 ; k13 = 11
.line	58	loadk        r14   k14 ; k14 = 152
.line	58	loadk        r15   k15 ; k15 = 47
.line	58	loadk        r16   k16 ; k16 = 99
.line	58	loadk        r17   k17 ; k17 = 130
.line	58	loadk        r18   k18 ; k18 = 111
.line	58	loadk        r19   k19 ; k19 = 136
.line	58	loadk        r20   k20 ; k20 = 220
.line	58	loadk        r21   k21 ; k21 = 16
.line	58	loadk        r22   k13 ; k13 = 11
.line	58	loadk        r23   k19 ; k19 = 136
.line	58	loadk        r24   k22 ; k22 = 179
.line	58	loadk        r25   k23 ; k23 = 155
.line	58	loadk        r26   k24 ; k24 = 231
.line	58	loadk        r27   k25 ; k25 = 89
.line	58	loadk        r28   k26 ; k26 = 230
.line	58	loadk        r29   k27 ; k27 = 57
.line	58	loadk        r30   k28 ; k28 = 232
.line	58	loadk        r31   k29 ; k29 = 24
.line	58	loadk        r32   k30 ; k30 = 107
.line	58	loadk        r33   k31 ; k31 = 132
.line	58	loadk        r34   k32 ; k32 = 115
.line	58	loadk        r35   k33 ; k33 = 129
.line	58	loadk        r36   k34 ; k34 = 225
.line	58	loadk        r37   k35 ; k35 = 92
.line	58	loadk        r38   k36 ; k36 = 34
.line	58	loadk        r39   k37 ; k37 = 142
.line	58	loadk        r40   k38 ; k38 = 173
.line	58	loadk        r41   k39 ; k39 = 134
.line	58	loadk        r42   k51 ; k51 = 203
.line	58	loadk        r43   k52 ; k52 = 95
.line	58	loadk        r44   k53 ; k53 = 251
.line	58	loadk        r45   k54 ; k54 = 13
.line	58	loadk        r46   k55 ; k55 = 183
.line	58	call          r6    41     2
.line	58	getupval      r7    u1
.line	58	loadk         r8   k56 ; k56 = 100
.line	58	loadk         r9   k19 ; k19 = 136
.line	58	loadk        r10   k57 ; k57 = 243
.line	58	loadk        r11   k10 ; k10 = 221
.line	58	loadk        r12   k58 ; k58 = 184
.line	58	call          r7     6     0
.line	58	setlist       r5     0     1
.line	58	call          r4     2     2
.line	58	call          r3     2     2
.line	58	gettable      r4    r3   k59 ; k59 = L"send_black_friday_pr" (truncated)
.line	58	call          r4     1     1
.label	l132
.line	58	self          r3    r1   k60 ; k60 = "SetIsNeedUpdateInvit" (truncated)
.line	58	loadbool      r5     1     0
.line	58	call          r3     3     1
.line	58	self          r3    r0   k62 ; k62 = "InitChildClassScroll" (truncated)
.line	58	gettable      r5    r0   k63 ; k63 = "UIRoot"
.line	58	gettable      r5    r5   k61 ; k61 = "LoopScrollBox_GroupL" (truncated)
.line	58	gettabup      r6    u0    k5 ; k5 = "table"
.line	58	gettable      r6    r6    k6 ; k6 = "concat"
.line	58	newtable      r7     1     0
.line	58	getupval      r8    u1
.line	58	loadk         r9   k64 ; k64 = 77
.line	58	loadk        r10   k65 ; k65 = 141
.line	58	loadk        r11   k66 ; k66 = 242
.line	58	loadk        r12   k10 ; k10 = 221
.line	58	loadk        r13   k39 ; k39 = 134
.line	58	loadk        r14   k67 ; k67 = 204
.line	58	loadk        r15   k68 ; k68 = 68
.line	58	loadk        r16   k69 ; k69 = 216
.line	58	loadk        r17   k70 ; k70 = 7
.line	58	loadk        r18   k71 ; k71 = 120
.line	58	loadk        r19   k72 ; k72 = 145
.line	58	loadk        r20   k73 ; k73 = 46
.line	58	loadk        r21   k74 ; k74 = 182
.line	58	loadk        r22   k69 ; k69 = 216
.line	58	loadk        r23   k35 ; k35 = 92
.line	58	loadk        r24   k27 ; k27 = 57
.line	58	loadk        r25   k75 ; k75 = 131
.line	58	loadk        r26   k66 ; k66 = 242
.line	58	loadk        r27   k76 ; k76 = 188
.line	58	loadk        r28   k77 ; k77 = 248
.line	58	loadk        r29   k78 ; k78 = 86
.line	58	loadk        r30   k79 ; k79 = 224
.line	58	loadk        r31   k43 ; k43 = 33
.line	58	loadk        r32   k28 ; k28 = 232
.line	58	loadk        r33   k29 ; k29 = 24
.line	58	loadk        r34   k30 ; k30 = 107
.line	58	loadk        r35   k31 ; k31 = 132
.line	58	loadk        r36   k32 ; k32 = 115
.line	58	loadk        r37   k33 ; k33 = 129
.line	58	loadk        r38   k34 ; k34 = 225
.line	58	loadk        r39   k35 ; k35 = 92
.line	58	loadk        r40   k36 ; k36 = 34
.line	58	loadk        r41   k37 ; k37 = 142
.line	58	loadk        r42   k38 ; k38 = 173
.line	58	loadk        r43   k39 ; k39 = 134
.line	58	loadk        r44   k74 ; k74 = 182
.line	58	loadk        r45   k80 ; k80 = 127
.line	58	loadk        r46   k81 ; k81 = 212
.line	58	loadk        r47   k82 ; k82 = 2
.line	58	loadk        r48   k77 ; k77 = 248
.line	58	call          r8    41     2
.line	58	getupval      r9    u1
.line	58	loadk        r10   k83 ; k83 = 88
.line	58	loadk        r11   k76 ; k76 = 188
.line	58	loadk        r12   k84 ; k84 = 177
.line	58	loadk        r13   k85 ; k85 = 250
.line	58	loadk        r14   k86 ; k86 = 166
.line	58	loadk        r15   k69 ; k69 = 216
.line	58	loadk        r16   k87 ; k87 = 70
.line	58	loadk        r17   k88 ; k88 = 157
.line	58	loadk        r18   k89 ; k89 = 12
.line	58	loadk        r19   k90 ; k90 = 101
.line	58	loadk        r20   k91 ; k91 = 156
.line	58	loadk        r21   k56 ; k56 = 100
.line	58	loadk        r22   k23 ; k23 = 155
.line	58	loadk        r23   k92 ; k92 = 206
.line	58	loadk        r24   k93 ; k93 = 97
.line	58	loadk        r25   k94 ; k94 = 9
.line	58	loadk        r26   k95 ; k95 = 170
.line	58	loadk        r27   k75 ; k75 = 131
.line	58	loadk        r28   k96 ; k96 = 169
.line	58	loadk        r29   k85 ; k85 = 250
.line	58	loadk        r30   k97 ; k97 = 83
.line	58	loadk        r31   k98 ; k98 = 236
.line	58	loadk        r32   k99 ; k99 = 59
.line	58	loadk        r33  k100 ; k100 = 162
.line	58	loadk        r34  k101 ; k101 = 5
.line	58	loadk        r35  k102 ; k102 = 78
.line	58	loadk        r36   k72 ; k72 = 145
.line	58	loadk        r37  k103 ; k103 = 117
.line	58	loadk        r38  k104 ; k104 = 135
.line	58	loadk        r39   k77 ; k77 = 248
.line	58	loadk        r40  k105 ; k105 = 123
.line	58	loadk        r41   k82 ; k82 = 2
.line	58	loadk        r42  k106 ; k106 = 168
.line	58	loadk        r43   k91 ; k91 = 156
.line	58	call          r9    35     0
.line	58	setlist       r7     0     1
.line	58	call          r6     2     2
.line	58	call          r3     4     2
.line	58	settable      r0   k61    r3 ; k61 = "LoopScrollBox_GroupL" (truncated)
.line	58	self          r3    r0   k62 ; k62 = "InitChildClassScroll" (truncated)
.line	58	gettable      r5    r0   k63 ; k63 = "UIRoot"
.line	58	gettable      r5    r5  k107 ; k107 = "LoopScrollBox_TeamMe" (truncated)
.line	58	gettabup      r6    u0    k5 ; k5 = "table"
.line	58	gettable      r6    r6    k6 ; k6 = "concat"
.line	58	newtable      r7     1     0
.line	58	getupval      r8    u1
.line	58	loadk         r9   k64 ; k64 = 77
.line	58	loadk        r10   k65 ; k65 = 141
.line	58	loadk        r11   k66 ; k66 = 242
.line	58	loadk        r12   k10 ; k10 = 221
.line	58	loadk        r13   k39 ; k39 = 134
.line	58	loadk        r14   k67 ; k67 = 204
.line	58	loadk        r15   k68 ; k68 = 68
.line	58	loadk        r16   k69 ; k69 = 216
.line	58	loadk        r17   k70 ; k70 = 7
.line	58	loadk        r18   k71 ; k71 = 120
.line	58	loadk        r19   k72 ; k72 = 145
.line	58	loadk        r20   k73 ; k73 = 46
.line	58	loadk        r21   k74 ; k74 = 182
.line	58	loadk        r22   k69 ; k69 = 216
.line	58	loadk        r23   k35 ; k35 = 92
.line	58	loadk        r24   k27 ; k27 = 57
.line	58	loadk        r25   k75 ; k75 = 131
.line	58	loadk        r26   k66 ; k66 = 242
.line	58	loadk        r27   k76 ; k76 = 188
.line	58	loadk        r28   k77 ; k77 = 248
.line	58	loadk        r29   k78 ; k78 = 86
.line	58	loadk        r30   k79 ; k79 = 224
.line	58	loadk        r31   k43 ; k43 = 33
.line	58	loadk        r32   k28 ; k28 = 232
.line	58	loadk        r33   k29 ; k29 = 24
.line	58	loadk        r34   k30 ; k30 = 107
.line	58	loadk        r35   k31 ; k31 = 132
.line	58	loadk        r36   k32 ; k32 = 115
.line	58	loadk        r37   k33 ; k33 = 129
.line	58	loadk        r38   k34 ; k34 = 225
.line	58	loadk        r39   k35 ; k35 = 92
.line	58	loadk        r40   k36 ; k36 = 34
.line	58	loadk        r41   k37 ; k37 = 142
.line	58	loadk        r42   k38 ; k38 = 173
.line	58	loadk        r43   k39 ; k39 = 134
.line	58	loadk        r44   k74 ; k74 = 182
.line	58	loadk        r45   k80 ; k80 = 127
.line	58	loadk        r46   k81 ; k81 = 212
.line	58	loadk        r47   k82 ; k82 = 2
.line	58	loadk        r48   k77 ; k77 = 248
.line	58	call          r8    41     2
.line	58	getupval      r9    u1
.line	58	loadk        r10   k83 ; k83 = 88
.line	58	loadk        r11   k76 ; k76 = 188
.line	58	loadk        r12   k84 ; k84 = 177
.line	58	loadk        r13   k85 ; k85 = 250
.line	58	loadk        r14   k86 ; k86 = 166
.line	58	loadk        r15   k69 ; k69 = 216
.line	58	loadk        r16   k87 ; k87 = 70
.line	58	loadk        r17   k88 ; k88 = 157
.line	58	loadk        r18   k89 ; k89 = 12
.line	58	loadk        r19   k90 ; k90 = 101
.line	58	loadk        r20   k91 ; k91 = 156
.line	58	loadk        r21   k56 ; k56 = 100
.line	58	loadk        r22   k23 ; k23 = 155
.line	58	loadk        r23   k92 ; k92 = 206
.line	58	loadk        r24   k93 ; k93 = 97
.line	58	loadk        r25   k94 ; k94 = 9
.line	58	loadk        r26   k95 ; k95 = 170
.line	58	loadk        r27   k75 ; k75 = 131
.line	58	loadk        r28  k108 ; k108 = 187
.line	58	loadk        r29  k109 ; k109 = 237
.line	58	loadk        r30  k110 ; k110 = 91
.line	58	loadk        r31  k111 ; k111 = 228
.line	58	loadk        r32  k112 ; k112 = 10
.line	58	loadk        r33  k113 ; k113 = 143
.line	58	loadk        r34   k73 ; k73 = 46
.line	58	loadk        r35  k114 ; k114 = 98
.line	58	loadk        r36   k19 ; k19 = 136
.line	58	loadk        r37  k115 ; k115 = 79
.line	58	loadk        r38  k116 ; k116 = 191
.line	58	loadk        r39  k117 ; k117 = 238
.line	58	loadk        r40  k118 ; k118 = 108
.line	58	loadk        r41  k119 ; k119 = 27
.line	58	call          r9    33     0
.line	58	setlist       r7     0     1
.line	58	call          r6     2     2
.line	58	call          r3     4     2
.line	58	settable      r0  k107    r3 ; k107 = "LoopScrollBox_TeamMe" (truncated)
.line	58	self          r3    r1  k120 ; k120 = "GetIsHadReceiveRewar" (truncated)
.line	58	call          r3     2     2
.line	58	self          r4    r1  k121 ; k121 = "GetIsNeedPopUpReward" (truncated)
.line	58	call          r4     2     2
.line	58	test          r4     0
.line	58	jmp            0  l323
.line	58	test          r3     1
.line	58	jmp            0  l323
.line	58	gettabup      r4    u0  k122 ; k122 = "UIManager"
.line	58	gettable      r4    r4  k123 ; k123 = "ShowUI"
.line	58	gettabup      r5    u0  k122 ; k122 = "UIManager"
.line	58	gettable      r5    r5  k124 ; k124 = "UI_Config"
.line	58	gettable      r5    r5  k125 ; k125 = "BlackFriday_RP_Rewar" (truncated)
.line	58	call          r4     2     1
.label	l323
.line	58	self          r4    r0  k126 ; k126 = "PlayUserWidgetAnimat" (truncated)
.line	58	gettable      r6    r0   k63 ; k63 = "UIRoot"
.line	58	gettable      r6    r6  k127 ; k127 = "Anim_Tips"
.line	58	loadk         r7  k128 ; k128 = 0
.line	58	loadk         r8  k128 ; k128 = 0
.line	58	loadk         r9  k128 ; k128 = 0
.line	58	loadk        r10  k129 ; k129 = 1
.line	58	call          r4     7     1
.line	58	gettable      r4    r0  k130 ; k130 = "tExtraData"
.line	58	gettable      r4    r4  k131 ; k131 = "bIsJumpRPGroup"
.line	58	test          r4     0
.line	58	jmp            0  l351
.line	58	gettable      r4    r0  k130 ; k130 = "tExtraData"
.line	58	gettable      r4    r4  k132 ; k132 = "jumpFromRP"
.line	58	test          r4     0
.line	58	jmp            0  l345
.line	58	gettabup      r4    u2  k133 ; k133 = "ReportTLogEvent"
.line	58	gettabup      r5    u0  k134 ; k134 = "TLogEventDefine"
.line	58	gettable      r5    r5  k135 ; k135 = L"BlackFridayRPGroup_C" (truncated)
.line	58	loadk         r6  k129 ; k129 = 1
.line	58	call          r4     3     1
.line	58	jmp            0  l356
.label	l345
.line	58	gettabup      r4    u2  k133 ; k133 = "ReportTLogEvent"
.line	58	gettabup      r5    u0  k134 ; k134 = "TLogEventDefine"
.line	58	gettable      r5    r5  k135 ; k135 = L"BlackFridayRPGroup_C" (truncated)
.line	58	loadk         r6  k136 ; k136 = 3
.line	58	call          r4     3     1
.line	58	jmp            0  l356
.label	l351
.line	58	gettabup      r4    u2  k133 ; k133 = "ReportTLogEvent"
.line	58	gettabup      r5    u0  k134 ; k134 = "TLogEventDefine"
.line	58	gettable      r5    r5  k135 ; k135 = L"BlackFridayRPGroup_C" (truncated)
.line	58	loadk         r6   k82 ; k82 = 2
.line	58	call          r4     3     1
.label	l356
.line	58	gettabup      r4    u0    k0 ; k0 = "ModuleManager"
.line	58	gettable      r4    r4    k1 ; k1 = "GetModule"
.line	58	gettabup      r5    u0    k0 ; k0 = "ModuleManager"
.line	58	gettable      r5    r5    k2 ; k2 = "LobbyModuleConfig"
.line	58	gettable      r5    r5  k137 ; k137 = "Logic_BFSubscribeMod" (truncated)
.line	58	call          r4     2     2
.line	58	self          r5    r4  k138 ; k138 = "GetIsSamsung"
.line	58	call          r5     2     2
.line	58	self          r6    r0  k139 ; k139 = "SetWidgetVisible"
.line	58	gettable      r8    r0   k63 ; k63 = "UIRoot"
.line	58	gettable      r8    r8  k140 ; k140 = "Border_LinkageReward"
.line	58	not           r9    r5
.line	58	call          r6     4     1
.line	58	return        r0     1
.line	58	move          r0    r0
.line	58	return        r0     1

.function	main/f3

.source	null
.linedefined	90
.lastlinedefined	122
.numparams	1
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"AddOnClickedEventByControl"
.constant	k1	"UIRoot"
.constant	k2	"Button_Group"
.constant	k3	"OnClickedGroup"
.constant	k4	"Button_BuyRP"
.constant	k5	"OnClickedBuyRP"
.constant	k6	"Button_UpgradeRPPlus"
.constant	k7	"OnClickedUpgradeRPPlus"
.constant	k8	"Button_QuickGroup"
.constant	k9	"OnClickedQuickGroup"
.constant	k10	"Button_InvitateRecord"
.constant	k11	"OnClickedInvitateRecord"
.constant	k12	"Button_CreateGroup"
.constant	k13	"OnClickedCreateGroup"
.constant	k14	"Button_CreateGroup1"
.constant	k15	"Button_GoBuyRP"
.constant	k16	"Button_BuyNormal"
.constant	k17	"OnClickedSwitchToBuyRP"
.constant	k18	1
.constant	k19	"Button_BuyExperience"
.constant	k20	2
.constant	k21	"Button_BuyPlus"
.constant	k22	3
.constant	k23	"Button_BuyLuckCard"
.constant	k24	"OnJumpLuckCardButtonClick"
.constant	k25	"Button_ReceiveLuckCardReward"
.constant	k26	"OnClickedReceiveLuckCardReward"
.constant	k27	"Button_LinkageReward"
.constant	k28	"OnLinkageRewardButtonClick"
.constant	k29	"Button_RewardTips"
.constant	k30	"OnClickedGroupRewardHelp"
.constant	k31	"Button_MemberNum"
.constant	k32	"OnClickedMemberNumHelp"
.constant	k33	"Button_ReceiveExperience"
.constant	k34	"OnClickedReceiveGroupReward"
.constant	k35	"Button_ReceiveNormal"
.constant	k36	"Button_ReceivePlus"
.constant	k37	"Button_JK_Detail"
.constant	k38	"OnClickedJKDetail"
.constant	k39	"AddCommonEvent"
.constant	k40	"EVENTTYPE_ACTIVITY_BLACK_FRIDAY"
.constant	k41	L"EVENTID_ACTIVITY_BLACK_FRIDAY_RPGROUP_REWARD_STATE_UPDATE"
.constant	k42	"OnUpdateGroupRewardState"
.constant	k43	L"EVENTID_ACTIVITY_BLACK_FRIDAY_RPGROUP_INFO_UPDATE"
.constant	k44	"OnUpdateGroupUI"
.constant	k45	L"EVENTID_ACTIVITY_BLACK_FRIDAY_RPGROUP_MEMBER_INFO_UPDATE"
.constant	k46	"OnUpdateGroupMemberState"
.constant	k47	"EVENTTYPE_UNKNOW_PASS"
.constant	k48	"EVENTID_UNKNOW_PASS_INFO_UPDATE"
.constant	k49	"OnRPInfoUpdate"
.constant	k50	"EVENTID_UNKNOW_UPDATE_NORMALPASS_INFO"
.constant	k51	"OnUpdateNormalPassInfo"
.constant	k52	L"EVENTID_BLACK_FRIDAY_RPGROUP_INVITED_RECORD"
.constant	k53	"OnRPGroupInvitedRecordEvent"
.constant	k54	L"EVENTID_ACTIVITY_BLACK_FRIDAY_RPGROUP_UPDATE_INVITED_REDDOT"
.constant	k55	"OnUpdateInvitedRecordRedEvent"
.constant	k56	L"EVENTID_ACTIVITY_BLACK_FRIDAY_RPGROUP_UPDATE_LINKAGE_REWARD"
.constant	k57	"OnUpdateLinkageReward"
.constant	k58	"EVENTID_UNKNOW_PASS_BUY_PASS"

.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3    k2 ; k2 = "Button_Group"
.line	90	gettable      r4    r0    k3 ; k3 = "OnClickedGroup"
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3    k4 ; k4 = "Button_BuyRP"
.line	90	gettable      r4    r0    k5 ; k5 = "OnClickedBuyRP"
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3    k6 ; k6 = "Button_UpgradeRPPlus"
.line	90	gettable      r4    r0    k7 ; k7 = "OnClickedUpgradeRPPl" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3    k8 ; k8 = "Button_QuickGroup"
.line	90	gettable      r4    r0    k9 ; k9 = "OnClickedQuickGroup"
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k10 ; k10 = "Button_InvitateRecor" (truncated)
.line	90	gettable      r4    r0   k11 ; k11 = "OnClickedInvitateRec" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k12 ; k12 = "Button_CreateGroup"
.line	90	gettable      r4    r0   k13 ; k13 = "OnClickedCreateGroup"
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k14 ; k14 = "Button_CreateGroup1"
.line	90	gettable      r4    r0   k13 ; k13 = "OnClickedCreateGroup"
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k15 ; k15 = "Button_GoBuyRP"
.line	90	gettable      r4    r0    k7 ; k7 = "OnClickedUpgradeRPPl" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k16 ; k16 = "Button_BuyNormal"
.line	90	gettable      r4    r0   k17 ; k17 = "OnClickedSwitchToBuy" (truncated)
.line	90	move          r5    r0
.line	90	loadk         r6   k18 ; k18 = 1
.line	90	call          r1     6     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k19 ; k19 = "Button_BuyExperience"
.line	90	gettable      r4    r0   k17 ; k17 = "OnClickedSwitchToBuy" (truncated)
.line	90	move          r5    r0
.line	90	loadk         r6   k20 ; k20 = 2
.line	90	call          r1     6     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k21 ; k21 = "Button_BuyPlus"
.line	90	gettable      r4    r0   k17 ; k17 = "OnClickedSwitchToBuy" (truncated)
.line	90	move          r5    r0
.line	90	loadk         r6   k22 ; k22 = 3
.line	90	call          r1     6     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k23 ; k23 = "Button_BuyLuckCard"
.line	90	gettable      r4    r0   k24 ; k24 = "OnJumpLuckCardButton" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k25 ; k25 = "Button_ReceiveLuckCa" (truncated)
.line	90	gettable      r4    r0   k26 ; k26 = "OnClickedReceiveLuck" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k27 ; k27 = "Button_LinkageReward"
.line	90	gettable      r4    r0   k28 ; k28 = "OnLinkageRewardButto" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k29 ; k29 = "Button_RewardTips"
.line	90	gettable      r4    r0   k30 ; k30 = "OnClickedGroupReward" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k31 ; k31 = "Button_MemberNum"
.line	90	gettable      r4    r0   k32 ; k32 = "OnClickedMemberNumHe" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k33 ; k33 = "Button_ReceiveExperi" (truncated)
.line	90	gettable      r4    r0   k34 ; k34 = "OnClickedReceiveGrou" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k35 ; k35 = "Button_ReceiveNormal"
.line	90	gettable      r4    r0   k34 ; k34 = "OnClickedReceiveGrou" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k36 ; k36 = "Button_ReceivePlus"
.line	90	gettable      r4    r0   k34 ; k34 = "OnClickedReceiveGrou" (truncated)
.line	90	move          r5    r0
.line	90	call          r1     5     1
.line	90	gettable      r1    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r1    r1   k37 ; k37 = "Button_JK_Detail"
.line	90	test          r1     0
.line	90	jmp            0  l128
.line	90	self          r1    r0    k0 ; k0 = "AddOnClickedEventByC" (truncated)
.line	90	gettable      r3    r0    k1 ; k1 = "UIRoot"
.line	90	gettable      r3    r3   k37 ; k37 = "Button_JK_Detail"
.line	90	gettable      r4    r0   k38 ; k38 = "OnClickedJKDetail"
.line	90	move          r5    r0
.line	90	call          r1     5     1
.label	l128
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_ACTIVITY_B" (truncated)
.line	90	gettabup      r4    u0   k41 ; k41 = L"EVENTID_ACTIVITY_BLA" (truncated)
.line	90	gettable      r5    r0   k42 ; k42 = "OnUpdateGroupRewardS" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_ACTIVITY_B" (truncated)
.line	90	gettabup      r4    u0   k43 ; k43 = L"EVENTID_ACTIVITY_BLA" (truncated)
.line	90	gettable      r5    r0   k44 ; k44 = "OnUpdateGroupUI"
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_ACTIVITY_B" (truncated)
.line	90	gettabup      r4    u0   k45 ; k45 = L"EVENTID_ACTIVITY_BLA" (truncated)
.line	90	gettable      r5    r0   k46 ; k46 = "OnUpdateGroupMemberS" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k47 ; k47 = "EVENTTYPE_UNKNOW_PAS" (truncated)
.line	90	gettabup      r4    u0   k48 ; k48 = "EVENTID_UNKNOW_PASS_" (truncated)
.line	90	gettable      r5    r0   k49 ; k49 = "OnRPInfoUpdate"
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k47 ; k47 = "EVENTTYPE_UNKNOW_PAS" (truncated)
.line	90	gettabup      r4    u0   k50 ; k50 = "EVENTID_UNKNOW_UPDAT" (truncated)
.line	90	gettable      r5    r0   k51 ; k51 = "OnUpdateNormalPassIn" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_ACTIVITY_B" (truncated)
.line	90	gettabup      r4    u0   k52 ; k52 = L"EVENTID_BLACK_FRIDAY" (truncated)
.line	90	gettable      r5    r0   k53 ; k53 = "OnRPGroupInvitedReco" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_ACTIVITY_B" (truncated)
.line	90	gettabup      r4    u0   k54 ; k54 = L"EVENTID_ACTIVITY_BLA" (truncated)
.line	90	gettable      r5    r0   k55 ; k55 = "OnUpdateInvitedRecor" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k40 ; k40 = "EVENTTYPE_ACTIVITY_B" (truncated)
.line	90	gettabup      r4    u0   k56 ; k56 = L"EVENTID_ACTIVITY_BLA" (truncated)
.line	90	gettable      r5    r0   k57 ; k57 = "OnUpdateLinkageRewar" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	self          r1    r0   k39 ; k39 = "AddCommonEvent"
.line	90	gettabup      r3    u0   k47 ; k47 = "EVENTTYPE_UNKNOW_PAS" (truncated)
.line	90	gettabup      r4    u0   k58 ; k58 = "EVENTID_UNKNOW_PASS_" (truncated)
.line	90	gettable      r5    r0   k51 ; k51 = "OnUpdateNormalPassIn" (truncated)
.line	90	move          r6    r0
.line	90	call          r1     6     1
.line	90	return        r0     1
.line	90	move          r0    r0
.line	90	move          r0    r0
.line	90	move          r0    r0
.line	90	move          r0    r0
.line	90	return        r0     1

.function	main/f4

.source	null
.linedefined	124
.lastlinedefined	144
.numparams	1
.is_vararg	0
.maxstacksize	10

.constant	k0	"UpdateTabPage"
.constant	k1	"InitTrait"
.constant	k2	"InitText"
.constant	k3	"InitLoopData"
.constant	k4	"UpdateGroupState"
.constant	k5	"OnUpdateInvitedRecordRed"
.constant	k6	"OnUpdateJKDetailButton"
.constant	k7	"OnUpdateGroupBuyText"
.constant	k8	"UpdateLuckyCardReward"
.constant	k9	"RefreshLinkageRewardBtnShow"
.constant	k10	"UpdateLinkageRewardIcon"
.constant	k11	"UpdateGroupRewardStatus"
.constant	k12	"OnUpdateGroupRewardTips"
.constant	k13	"UpdateFirstBuyPrivilege"
.constant	k14	1
.constant	k15	3
.constant	k16	"_GetBuyItemNodes"
.constant	k17	"_RegistBuyItemBtnEvents"
.constant	k18	"OnUpdateGroupBuyRPUI"

.line	124	self          r1    r0    k0 ; k0 = "UpdateTabPage"
.line	124	call          r1     2     1
.line	124	self          r1    r0    k1 ; k1 = "InitTrait"
.line	124	call          r1     2     1
.line	124	self          r1    r0    k2 ; k2 = "InitText"
.line	124	call          r1     2     1
.line	124	self          r1    r0    k3 ; k3 = "InitLoopData"
.line	124	call          r1     2     1
.line	124	self          r1    r0    k4 ; k4 = "UpdateGroupState"
.line	124	call          r1     2     1
.line	124	self          r1    r0    k5 ; k5 = "OnUpdateInvitedRecor" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0    k6 ; k6 = "OnUpdateJKDetailButt" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0    k7 ; k7 = "OnUpdateGroupBuyText"
.line	124	call          r1     2     1
.line	124	self          r1    r0    k8 ; k8 = "UpdateLuckyCardRewar" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0    k9 ; k9 = "RefreshLinkageReward" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0   k10 ; k10 = "UpdateLinkageRewardI" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0   k11 ; k11 = "UpdateGroupRewardSta" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0   k12 ; k12 = "OnUpdateGroupRewardT" (truncated)
.line	124	call          r1     2     1
.line	124	self          r1    r0   k13 ; k13 = "UpdateFirstBuyPrivil" (truncated)
.line	124	call          r1     2     1
.line	124	loadk         r1   k14 ; k14 = 1
.line	124	loadk         r2   k15 ; k15 = 3
.line	124	loadk         r3   k14 ; k14 = 1
.line	124	move          r0    r0
.line	124	self          r5    r0   k16 ; k16 = "_GetBuyItemNodes"
.line	124	move          r7    r4
.line	124	call          r5     3     2
.line	124	self          r6    r0   k17 ; k17 = "_RegistBuyItemBtnEve" (truncated)
.line	124	move          r8    r4
.line	124	move          r9    r5
.line	124	call          r6     4     1
.line	124	move          r0    r0
.line	124	self          r1    r0   k18 ; k18 = "OnUpdateGroupBuyRPUI"
.line	124	call          r1     2     1
.line	124	return        r0     1
.line	124	move          r0    r0
.line	124	move          r0    r0
.line	124	return        r0     1

.function	main/f5

.source	null
.linedefined	146
.lastlinedefined	153
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false
.upvalue	"U1"	2	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"SetIsBlackFridayJumpToRPBuy"
.constant	k5	"SetIsNeedPopUpRewardUpgradePopup"
.constant	k6	"SetIsUpgradeRPPlus"
.constant	k7	"SetIsNeedCheckProductDataDuplicate"
.constant	k8	"__super"
.constant	k9	"OnClose"

.line	146	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	146	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	146	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	146	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	146	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	146	call          r1     2     2
.line	146	self          r2    r1    k4 ; k4 = "SetIsBlackFridayJump" (truncated)
.line	146	loadbool      r4     0     0
.line	146	call          r2     3     1
.line	146	self          r2    r1    k5 ; k5 = "SetIsNeedPopUpReward" (truncated)
.line	146	loadbool      r4     0     0
.line	146	call          r2     3     1
.line	146	self          r2    r1    k6 ; k6 = "SetIsUpgradeRPPlus"
.line	146	loadbool      r4     0     0
.line	146	call          r2     3     1
.line	146	self          r2    r1    k7 ; k7 = "SetIsNeedCheckProduc" (truncated)
.line	146	loadbool      r4     0     0
.line	146	call          r2     3     1
.line	146	gettabup      r2    u1    k8 ; k8 = "__super"
.line	146	gettable      r2    r2    k9 ; k9 = "OnClose"
.line	146	move          r3    r0
.line	146	call          r2     2     1
.line	146	return        r0     1
.line	146	move          r0    r0
.line	146	move          r0    r0
.line	146	move          r0    r0
.line	146	move          r0    r0
.line	146	return        r0     1

.function	main/f6

.source	null
.linedefined	155
.lastlinedefined	159
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"SwitchTab"
.constant	k4	"ReportTLogEvent"
.constant	k5	"TLogEventDefine"
.constant	k6	"BlackFridayRPGroup_ClickGroupTab"

.line	155	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	155	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	155	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	155	call          r1     3     1
.line	155	self          r1    r0    k3 ; k3 = "SwitchTab"
.line	155	loadbool      r3     0     0
.line	155	call          r1     3     1
.line	155	gettabup      r1    u1    k4 ; k4 = "ReportTLogEvent"
.line	155	gettabup      r2    u0    k5 ; k5 = "TLogEventDefine"
.line	155	gettable      r2    r2    k6 ; k6 = "BlackFridayRPGroup_C" (truncated)
.line	155	call          r1     2     1
.line	155	return        r0     1
.line	155	move          r0    r0
.line	155	move          r0    r0
.line	155	return        r0     1

.function	main/f7

.source	null
.linedefined	161
.lastlinedefined	165
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"SwitchTab"
.constant	k4	"ReportTLogEvent"
.constant	k5	"TLogEventDefine"
.constant	k6	"BlackFridayRPGroup_ClickBuyTab"

.line	161	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	161	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	161	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	161	call          r1     3     1
.line	161	self          r1    r0    k3 ; k3 = "SwitchTab"
.line	161	loadbool      r3     1     0
.line	161	call          r1     3     1
.line	161	gettabup      r1    u1    k4 ; k4 = "ReportTLogEvent"
.line	161	gettabup      r2    u0    k5 ; k5 = "TLogEventDefine"
.line	161	gettable      r2    r2    k6 ; k6 = "BlackFridayRPGroup_C" (truncated)
.line	161	call          r1     2     1
.line	161	return        r0     1
.line	161	move          r0    r0
.line	161	move          r0    r0
.line	161	move          r0    r0
.line	161	move          r0    r0
.line	161	return        r0     1

.function	main/f8

.source	null
.linedefined	167
.lastlinedefined	188
.numparams	1
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"BlackFridayRPGroupModule"
.constant	k7	"IsJoinedRPGroup"
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	105
.constant	k12	128
.constant	k13	246
.constant	k14	221
.constant	k15	164
.constant	k16	205
.constant	k17	11
.constant	k18	152
.constant	k19	47
.constant	k20	99
.constant	k21	130
.constant	k22	111
.constant	k23	136
.constant	k24	220
.constant	k25	16
.constant	k26	179
.constant	k27	155
.constant	k28	231
.constant	k29	89
.constant	k30	230
.constant	k31	57
.constant	k32	232
.constant	k33	24
.constant	k34	107
.constant	k35	132
.constant	k36	115
.constant	k37	129
.constant	k38	225
.constant	k39	92
.constant	k40	34
.constant	k41	142
.constant	k42	173
.constant	k43	134
.constant	k44	208
.constant	k45	75
.constant	k46	247
.constant	k47	33
.constant	k48	186
.constant	k49	158
.constant	k50	"send_black_friday_create_rp_group_req"
.constant	k51	"UnknowPassSystem"
.constant	k52	"IsBuyElite"
.constant	k53	"ReportTLogEvent"
.constant	k54	"TLogEventDefine"
.constant	k55	"BlackFridayRPGroup_ClickedCreateGroup"
.constant	k56	"LocUtil"
.constant	k57	"GetLocalizeResStr"
.constant	k58	101001
.constant	k59	18130173
.constant	k60	77
.constant	k61	141
.constant	k62	242
.constant	k63	204
.constant	k64	68
.constant	k65	216
.constant	k66	7
.constant	k67	120
.constant	k68	145
.constant	k69	46
.constant	k70	184
.constant	k71	214
.constant	k72	62
.constant	k73	183
.constant	k74	139
.constant	k75	166
.constant	k76	121
.constant	k77	56
.constant	k78	171
.constant	k79	53
.constant	k80	203
.constant	k81	69
.constant	k82	163
.constant	k83	137
.constant	k84	103
.constant	k85	37
.constant	k86	146
.constant	k87	253
.constant	k88	126
.constant	k89	240
.constant	k90	165
.constant	k91	94
.constant	k92	131
.constant	k93	212
.constant	k94	185
.constant	k95	"ShowMsgBox"
.constant	k96	2

.line	167	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	167	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	167	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	167	call          r1     3     1
.line	167	gettabup      r1    u0    k3 ; k3 = "ModuleManager"
.line	167	gettable      r1    r1    k4 ; k4 = "GetModule"
.line	167	gettabup      r2    u0    k3 ; k3 = "ModuleManager"
.line	167	gettable      r2    r2    k5 ; k5 = "LobbyModuleConfig"
.line	167	gettable      r2    r2    k6 ; k6 = "BlackFridayRPGroupMo" (truncated)
.line	167	call          r1     2     2
.line	167	self          r2    r1    k7 ; k7 = "IsJoinedRPGroup"
.line	167	call          r2     2     2
.line	167	test          r2     0
.line	167	jmp            0   l71
.line	167	gettabup      r2    u0    k8 ; k8 = "require"
.line	167	gettabup      r3    u0    k9 ; k9 = "table"
.line	167	gettable      r3    r3   k10 ; k10 = "concat"
.line	167	newtable      r4     1     0
.line	167	getupval      r5    u1
.line	167	loadk         r6   k11 ; k11 = 105
.line	167	loadk         r7   k12 ; k12 = 128
.line	167	loadk         r8   k13 ; k13 = 246
.line	167	loadk         r9   k14 ; k14 = 221
.line	167	loadk        r10   k15 ; k15 = 164
.line	167	loadk        r11   k16 ; k16 = 205
.line	167	loadk        r12   k17 ; k17 = 11
.line	167	loadk        r13   k18 ; k18 = 152
.line	167	loadk        r14   k19 ; k19 = 47
.line	167	loadk        r15   k20 ; k20 = 99
.line	167	loadk        r16   k21 ; k21 = 130
.line	167	loadk        r17   k22 ; k22 = 111
.line	167	loadk        r18   k23 ; k23 = 136
.line	167	loadk        r19   k24 ; k24 = 220
.line	167	loadk        r20   k25 ; k25 = 16
.line	167	loadk        r21   k17 ; k17 = 11
.line	167	loadk        r22   k23 ; k23 = 136
.line	167	loadk        r23   k26 ; k26 = 179
.line	167	loadk        r24   k27 ; k27 = 155
.line	167	loadk        r25   k28 ; k28 = 231
.line	167	loadk        r26   k29 ; k29 = 89
.line	167	loadk        r27   k30 ; k30 = 230
.line	167	loadk        r28   k31 ; k31 = 57
.line	167	loadk        r29   k32 ; k32 = 232
.line	167	loadk        r30   k33 ; k33 = 24
.line	167	loadk        r31   k34 ; k34 = 107
.line	167	loadk        r32   k35 ; k35 = 132
.line	167	loadk        r33   k36 ; k36 = 115
.line	167	loadk        r34   k37 ; k37 = 129
.line	167	loadk        r35   k38 ; k38 = 225
.line	167	loadk        r36   k39 ; k39 = 92
.line	167	loadk        r37   k40 ; k40 = 34
.line	167	loadk        r38   k41 ; k41 = 142
.line	167	loadk        r39   k42 ; k42 = 173
.line	167	loadk        r40   k43 ; k43 = 134
.line	167	loadk        r41   k44 ; k44 = 208
.line	167	loadk        r42   k45 ; k45 = 75
.line	167	loadk        r43   k46 ; k46 = 247
.line	167	loadk        r44   k47 ; k47 = 33
.line	167	loadk        r45   k48 ; k48 = 186
.line	167	call          r5    41     2
.line	167	getupval      r6    u1
.line	167	loadk         r7   k22 ; k22 = 111
.line	167	loadk         r8   k49 ; k49 = 158
.line	167	call          r6     3     0
.line	167	setlist       r4     0     1
.line	167	call          r3     2     2
.line	167	call          r2     2     2
.line	167	gettable      r3    r2   k50 ; k50 = "send_black_friday_cr" (truncated)
.line	167	call          r3     1     1
.line	167	return        r0     1
.label	l71
.line	167	gettabup      r2    u0   k51 ; k51 = "UnknowPassSystem"
.line	167	gettable      r2    r2   k52 ; k52 = "IsBuyElite"
.line	167	test          r2     0
.line	167	jmp            0  l135
.line	167	gettabup      r2    u0    k8 ; k8 = "require"
.line	167	gettabup      r3    u0    k9 ; k9 = "table"
.line	167	gettable      r3    r3   k10 ; k10 = "concat"
.line	167	newtable      r4     1     0
.line	167	getupval      r5    u1
.line	167	loadk         r6   k11 ; k11 = 105
.line	167	loadk         r7   k12 ; k12 = 128
.line	167	loadk         r8   k13 ; k13 = 246
.line	167	loadk         r9   k14 ; k14 = 221
.line	167	loadk        r10   k15 ; k15 = 164
.line	167	loadk        r11   k16 ; k16 = 205
.line	167	loadk        r12   k17 ; k17 = 11
.line	167	loadk        r13   k18 ; k18 = 152
.line	167	loadk        r14   k19 ; k19 = 47
.line	167	loadk        r15   k20 ; k20 = 99
.line	167	loadk        r16   k21 ; k21 = 130
.line	167	loadk        r17   k22 ; k22 = 111
.line	167	loadk        r18   k23 ; k23 = 136
.line	167	loadk        r19   k24 ; k24 = 220
.line	167	loadk        r20   k25 ; k25 = 16
.line	167	loadk        r21   k17 ; k17 = 11
.line	167	loadk        r22   k23 ; k23 = 136
.line	167	loadk        r23   k26 ; k26 = 179
.line	167	loadk        r24   k27 ; k27 = 155
.line	167	loadk        r25   k28 ; k28 = 231
.line	167	loadk        r26   k29 ; k29 = 89
.line	167	loadk        r27   k30 ; k30 = 230
.line	167	loadk        r28   k31 ; k31 = 57
.line	167	loadk        r29   k32 ; k32 = 232
.line	167	loadk        r30   k33 ; k33 = 24
.line	167	loadk        r31   k34 ; k34 = 107
.line	167	loadk        r32   k35 ; k35 = 132
.line	167	loadk        r33   k36 ; k36 = 115
.line	167	loadk        r34   k37 ; k37 = 129
.line	167	loadk        r35   k38 ; k38 = 225
.line	167	loadk        r36   k39 ; k39 = 92
.line	167	loadk        r37   k40 ; k40 = 34
.line	167	loadk        r38   k41 ; k41 = 142
.line	167	loadk        r39   k42 ; k42 = 173
.line	167	loadk        r40   k43 ; k43 = 134
.line	167	loadk        r41   k44 ; k44 = 208
.line	167	loadk        r42   k45 ; k45 = 75
.line	167	loadk        r43   k46 ; k46 = 247
.line	167	loadk        r44   k47 ; k47 = 33
.line	167	loadk        r45   k48 ; k48 = 186
.line	167	call          r5    41     2
.line	167	getupval      r6    u1
.line	167	loadk         r7   k22 ; k22 = 111
.line	167	loadk         r8   k49 ; k49 = 158
.line	167	call          r6     3     0
.line	167	setlist       r4     0     1
.line	167	call          r3     2     2
.line	167	call          r2     2     2
.line	167	gettable      r3    r2   k50 ; k50 = "send_black_friday_cr" (truncated)
.line	167	call          r3     1     1
.line	167	gettabup      r3    u2   k53 ; k53 = "ReportTLogEvent"
.line	167	gettabup      r4    u0   k54 ; k54 = "TLogEventDefine"
.line	167	gettable      r4    r4   k55 ; k55 = "BlackFridayRPGroup_C" (truncated)
.line	167	call          r3     2     1
.line	167	return        r0     1
.label	l135
.line	167	gettabup      r2    u0   k56 ; k56 = "LocUtil"
.line	167	gettable      r2    r2   k57 ; k57 = "GetLocalizeResStr"
.line	167	loadk         r3   k58 ; k58 = 101001
.line	167	call          r2     2     2
.line	167	gettabup      r3    u0   k56 ; k56 = "LocUtil"
.line	167	gettable      r3    r3   k57 ; k57 = "GetLocalizeResStr"
.line	167	loadk         r4   k59 ; k59 = 18130173
.line	167	call          r3     2     2
.line	167	closure       r4    f0
.line	167	gettabup      r5    u0    k8 ; k8 = "require"
.line	167	gettabup      r6    u0    k9 ; k9 = "table"
.line	167	gettable      r6    r6   k10 ; k10 = "concat"
.line	167	newtable      r7     1     0
.line	167	getupval      r8    u1
.line	167	loadk         r9   k60 ; k60 = 77
.line	167	loadk        r10   k61 ; k61 = 141
.line	167	loadk        r11   k62 ; k62 = 242
.line	167	loadk        r12   k14 ; k14 = 221
.line	167	loadk        r13   k43 ; k43 = 134
.line	167	loadk        r14   k63 ; k63 = 204
.line	167	loadk        r15   k64 ; k64 = 68
.line	167	loadk        r16   k65 ; k65 = 216
.line	167	loadk        r17   k66 ; k66 = 7
.line	167	loadk        r18   k67 ; k67 = 120
.line	167	loadk        r19   k68 ; k68 = 145
.line	167	loadk        r20   k69 ; k69 = 46
.line	167	loadk        r21   k70 ; k70 = 184
.line	167	loadk        r22   k71 ; k71 = 214
.line	167	loadk        r23   k60 ; k60 = 77
.line	167	loadk        r24   k72 ; k72 = 62
.line	167	loadk        r25   k73 ; k73 = 183
.line	167	loadk        r26   k26 ; k26 = 179
.line	167	loadk        r27   k74 ; k74 = 139
.line	167	loadk        r28   k75 ; k75 = 166
.line	167	loadk        r29   k76 ; k76 = 121
.line	167	loadk        r30   k30 ; k30 = 230
.line	167	loadk        r31   k77 ; k77 = 56
.line	167	loadk        r32   k78 ; k78 = 171
.line	167	loadk        r33   k79 ; k79 = 53
.line	167	loadk        r34   k11 ; k11 = 105
.line	167	loadk        r35   k80 ; k80 = 203
.line	167	loadk        r36   k81 ; k81 = 69
.line	167	loadk        r37   k82 ; k82 = 163
.line	167	loadk        r38   k83 ; k83 = 137
.line	167	loadk        r39   k84 ; k84 = 103
.line	167	loadk        r40   k85 ; k85 = 37
.line	167	loadk        r41   k42 ; k42 = 173
.line	167	loadk        r42   k42 ; k42 = 173
.line	167	loadk        r43   k86 ; k86 = 146
.line	167	loadk        r44   k87 ; k87 = 253
.line	167	loadk        r45   k88 ; k88 = 126
.line	167	loadk        r46   k89 ; k89 = 240
.line	167	loadk        r47   k79 ; k79 = 53
.line	167	loadk        r48   k90 ; k90 = 165
.line	167	call          r8    41     2
.line	167	getupval      r9    u1
.line	167	loadk        r10   k91 ; k91 = 94
.line	167	loadk        r11   k92 ; k92 = 131
.line	167	loadk        r12   k89 ; k89 = 240
.line	167	loadk        r13   k93 ; k93 = 212
.line	167	loadk        r14   k94 ; k94 = 185
.line	167	call          r9     6     0
.line	167	setlist       r7     0     1
.line	167	call          r6     2     2
.line	167	call          r5     2     2
.line	167	gettable      r6    r5   k95 ; k95 = "ShowMsgBox"
.line	167	loadk         r7   k96 ; k96 = 2
.line	167	move          r8    r2
.line	167	move          r9    r3
.line	167	move         r10    r4
.line	167	call          r6     5     1
.line	167	return        r0     1
.line	167	move          r0    r0
.line	167	move          r0    r0
.line	167	move          r0    r0
.line	167	return        r0     1

.function	main/f8/f0

.source	null
.linedefined	183
.lastlinedefined	185
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"OnClickedBuyRP"

.line	183	getupval      r0    u0
.line	183	self          r0    r0    k0 ; k0 = "OnClickedBuyRP"
.line	183	call          r0     2     1
.line	183	return        r0     1
.line	183	move          r0    r0
.line	183	return        r0     1

.function	main/f9

.source	null
.linedefined	190
.lastlinedefined	194
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	18130160
.constant	k6	"UIManager"
.constant	k7	"ShowUI"
.constant	k8	"UI_Config"
.constant	k9	"common_questionmark_style_three"
.constant	k10	"UIRoot"
.constant	k11	"Button_RewardTips"

.line	190	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	190	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	190	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	190	call          r1     3     1
.line	190	gettabup      r1    u0    k3 ; k3 = "LocUtil"
.line	190	gettable      r1    r1    k4 ; k4 = "GetLocalizeResStr"
.line	190	loadk         r2    k5 ; k5 = 18130160
.line	190	call          r1     2     2
.line	190	gettabup      r2    u0    k6 ; k6 = "UIManager"
.line	190	gettable      r2    r2    k7 ; k7 = "ShowUI"
.line	190	gettabup      r3    u0    k6 ; k6 = "UIManager"
.line	190	gettable      r3    r3    k8 ; k8 = "UI_Config"
.line	190	gettable      r3    r3    k9 ; k9 = "common_questionmark_" (truncated)
.line	190	move          r4    r1
.line	190	gettable      r5    r0   k10 ; k10 = "UIRoot"
.line	190	gettable      r5    r5   k11 ; k11 = "Button_RewardTips"
.line	190	call          r2     4     1
.line	190	return        r0     1
.line	190	move          r0    r0
.line	190	move          r0    r0
.line	190	return        r0     1

.function	main/f10

.source	null
.linedefined	196
.lastlinedefined	200
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	18141463
.constant	k6	"UIManager"
.constant	k7	"ShowUI"
.constant	k8	"UI_Config"
.constant	k9	"common_questionmark_style_three"
.constant	k10	"UIRoot"
.constant	k11	"Button_MemberNum"

.line	196	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	196	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	196	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	196	call          r1     3     1
.line	196	gettabup      r1    u0    k3 ; k3 = "LocUtil"
.line	196	gettable      r1    r1    k4 ; k4 = "GetLocalizeResStr"
.line	196	loadk         r2    k5 ; k5 = 18141463
.line	196	call          r1     2     2
.line	196	gettabup      r2    u0    k6 ; k6 = "UIManager"
.line	196	gettable      r2    r2    k7 ; k7 = "ShowUI"
.line	196	gettabup      r3    u0    k6 ; k6 = "UIManager"
.line	196	gettable      r3    r3    k8 ; k8 = "UI_Config"
.line	196	gettable      r3    r3    k9 ; k9 = "common_questionmark_" (truncated)
.line	196	move          r4    r1
.line	196	gettable      r5    r0   k10 ; k10 = "UIRoot"
.line	196	gettable      r5    r5   k11 ; k11 = "Button_MemberNum"
.line	196	call          r2     4     1
.line	196	return        r0     1
.line	196	move          r0    r0
.line	196	move          r0    r0
.line	196	move          r0    r0
.line	196	move          r0    r0
.line	196	return        r0     1

.function	main/f11

.source	null
.linedefined	202
.lastlinedefined	234
.numparams	1
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	6	true
.upvalue	"U2"	7	true
.upvalue	"U3"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"BlackFridayRPGroupModule"
.constant	k7	"IsGroupFullAndAllBuyedRP"
.constant	k8	"GetIsHadReceiveReward"
.constant	k9	"LocUtil"
.constant	k10	"GetLocalizeResStr"
.constant	k11	18130194
.constant	k12	"UnknowPassSystem"
.constant	k13	"IsBuyElite"
.constant	k14	"PassType"
.constant	k15	2
.constant	k16	"GetRPGroupRewardConfig"
.constant	k17	1
.constant	k18	3
.constant	k19	"IsBuyEliteSeg2"
.constant	k20	"nShowSourceType"
.constant	k21	"RPTeamReceive"
.constant	k22	"sReceiveTip"
.constant	k23	"nRewardTipKey"
.constant	k24	"bIsHighestReward"
.constant	k25	"tRPGroupReward"
.constant	k26	"fReceiveCallback"
.constant	k27	"UIManager"
.constant	k28	"ShowUI"
.constant	k29	"UI_Config"
.constant	k30	"BlackFriday_RewardReceiveTipPopup_UIBP"

.line	202	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	202	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	202	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	202	call          r1     3     1
.line	202	gettabup      r1    u0    k3 ; k3 = "ModuleManager"
.line	202	gettable      r1    r1    k4 ; k4 = "GetModule"
.line	202	gettabup      r2    u0    k3 ; k3 = "ModuleManager"
.line	202	gettable      r2    r2    k5 ; k5 = "LobbyModuleConfig"
.line	202	gettable      r2    r2    k6 ; k6 = "BlackFridayRPGroupMo" (truncated)
.line	202	call          r1     2     2
.line	202	self          r2    r1    k7 ; k7 = "IsGroupFullAndAllBuy" (truncated)
.line	202	call          r2     2     2
.line	202	test          r2     1
.line	202	jmp            0   l16
.line	202	return        r0     1
.label	l16
.line	202	self          r3    r1    k8 ; k8 = "GetIsHadReceiveRewar" (truncated)
.line	202	call          r3     2     2
.line	202	test          r3     0
.line	202	jmp            0   l21
.line	202	return        r0     1
.label	l21
.line	202	gettabup      r4    u0    k9 ; k9 = "LocUtil"
.line	202	gettable      r4    r4   k10 ; k10 = "GetLocalizeResStr"
.line	202	loadk         r5   k11 ; k11 = 18130194
.line	202	call          r4     2     2
.line	202	gettabup      r5    u0   k12 ; k12 = "UnknowPassSystem"
.line	202	gettable      r5    r5   k13 ; k13 = "IsBuyElite"
.line	202	test          r5     0
.line	202	jmp            0   l35
.line	202	gettabup      r5    u0   k12 ; k12 = "UnknowPassSystem"
.line	202	gettable      r5    r5   k14 ; k14 = "PassType"
.line	202	eq             1    r5   k15 ; k15 = 2
.line	202	jmp            0   l34
.line	202	loadbool      r5     0     1
.label	l34
.line	202	loadbool      r5     1     0
.label	l35
.line	202	self          r6    r1   k16 ; k16 = "GetRPGroupRewardConf" (truncated)
.line	202	call          r6     2     2
.line	202	loadk         r7   k17 ; k17 = 1
.line	202	test          r5     0
.line	202	jmp            0   l42
.line	202	loadk         r7   k18 ; k18 = 3
.line	202	jmp            0   l51
.label	l42
.line	202	gettabup      r8    u0   k12 ; k12 = "UnknowPassSystem"
.line	202	gettable      r8    r8   k13 ; k13 = "IsBuyElite"
.line	202	test          r8     0
.line	202	jmp            0   l51
.line	202	gettabup      r8    u0   k12 ; k12 = "UnknowPassSystem"
.line	202	gettable      r8    r8   k19 ; k19 = "IsBuyEliteSeg2"
.line	202	test          r8     0
.line	202	jmp            0   l51
.line	202	loadk         r7   k15 ; k15 = 2
.label	l51
.line	202	newtable      r8     0     6
.line	202	gettabup      r9    u1   k21 ; k21 = "RPTeamReceive"
.line	202	settable      r8   k20    r9 ; k20 = "nShowSourceType"
.line	202	settable      r8   k22    r4 ; k22 = "sReceiveTip"
.line	202	gettabup      r9    u2    r7
.line	202	settable      r8   k23    r9 ; k23 = "nRewardTipKey"
.line	202	settable      r8   k24    r5 ; k24 = "bIsHighestReward"
.line	202	gettable      r9    r6    r7
.line	202	settable      r8   k25    r9 ; k25 = "tRPGroupReward"
.line	202	closure       r9    f0
.line	202	settable      r8   k26    r9 ; k26 = "fReceiveCallback"
.line	202	gettabup      r9    u0   k27 ; k27 = "UIManager"
.line	202	gettable      r9    r9   k28 ; k28 = "ShowUI"
.line	202	gettabup     r10    u0   k27 ; k27 = "UIManager"
.line	202	gettable     r10   r10   k29 ; k29 = "UI_Config"
.line	202	gettable     r10   r10   k30 ; k30 = "BlackFriday_RewardRe" (truncated)
.line	202	move         r11    r8
.line	202	call          r9     3     1
.line	202	return        r0     1
.line	202	move          r0    r0
.line	202	move          r0    r0
.line	202	move          r0    r0
.line	202	return        r0     1

.function	main/f11/f0

.source	null
.linedefined	228
.lastlinedefined	231
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	false

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	105
.constant	k4	128
.constant	k5	246
.constant	k6	221
.constant	k7	164
.constant	k8	205
.constant	k9	11
.constant	k10	152
.constant	k11	47
.constant	k12	99
.constant	k13	130
.constant	k14	111
.constant	k15	136
.constant	k16	220
.constant	k17	16
.constant	k18	179
.constant	k19	155
.constant	k20	231
.constant	k21	89
.constant	k22	230
.constant	k23	57
.constant	k24	232
.constant	k25	24
.constant	k26	107
.constant	k27	132
.constant	k28	115
.constant	k29	129
.constant	k30	225
.constant	k31	92
.constant	k32	34
.constant	k33	142
.constant	k34	173
.constant	k35	134
.constant	k36	208
.constant	k37	75
.constant	k38	247
.constant	k39	33
.constant	k40	186
.constant	k41	158
.constant	k42	L"send_black_friday_get_rp_group_reward_req"

.line	228	gettabup      r0    u0    k0 ; k0 = "require"
.line	228	gettabup      r1    u0    k1 ; k1 = "table"
.line	228	gettable      r1    r1    k2 ; k2 = "concat"
.line	228	newtable      r2     1     0
.line	228	getupval      r3    u1
.line	228	loadk         r4    k3 ; k3 = 105
.line	228	loadk         r5    k4 ; k4 = 128
.line	228	loadk         r6    k5 ; k5 = 246
.line	228	loadk         r7    k6 ; k6 = 221
.line	228	loadk         r8    k7 ; k7 = 164
.line	228	loadk         r9    k8 ; k8 = 205
.line	228	loadk        r10    k9 ; k9 = 11
.line	228	loadk        r11   k10 ; k10 = 152
.line	228	loadk        r12   k11 ; k11 = 47
.line	228	loadk        r13   k12 ; k12 = 99
.line	228	loadk        r14   k13 ; k13 = 130
.line	228	loadk        r15   k14 ; k14 = 111
.line	228	loadk        r16   k15 ; k15 = 136
.line	228	loadk        r17   k16 ; k16 = 220
.line	228	loadk        r18   k17 ; k17 = 16
.line	228	loadk        r19    k9 ; k9 = 11
.line	228	loadk        r20   k15 ; k15 = 136
.line	228	loadk        r21   k18 ; k18 = 179
.line	228	loadk        r22   k19 ; k19 = 155
.line	228	loadk        r23   k20 ; k20 = 231
.line	228	loadk        r24   k21 ; k21 = 89
.line	228	loadk        r25   k22 ; k22 = 230
.line	228	loadk        r26   k23 ; k23 = 57
.line	228	loadk        r27   k24 ; k24 = 232
.line	228	loadk        r28   k25 ; k25 = 24
.line	228	loadk        r29   k26 ; k26 = 107
.line	228	loadk        r30   k27 ; k27 = 132
.line	228	loadk        r31   k28 ; k28 = 115
.line	228	loadk        r32   k29 ; k29 = 129
.line	228	loadk        r33   k30 ; k30 = 225
.line	228	loadk        r34   k31 ; k31 = 92
.line	228	loadk        r35   k32 ; k32 = 34
.line	228	loadk        r36   k33 ; k33 = 142
.line	228	loadk        r37   k34 ; k34 = 173
.line	228	loadk        r38   k35 ; k35 = 134
.line	228	loadk        r39   k36 ; k36 = 208
.line	228	loadk        r40   k37 ; k37 = 75
.line	228	loadk        r41   k38 ; k38 = 247
.line	228	loadk        r42   k39 ; k39 = 33
.line	228	loadk        r43   k40 ; k40 = 186
.line	228	call          r3    41     2
.line	228	getupval      r4    u1
.line	228	loadk         r5   k14 ; k14 = 111
.line	228	loadk         r6   k41 ; k41 = 158
.line	228	call          r4     3     0
.line	228	setlist       r2     0     1
.line	228	call          r1     2     2
.line	228	call          r0     2     2
.line	228	gettable      r1    r0   k42 ; k42 = L"send_black_friday_ge" (truncated)
.line	228	call          r1     1     1
.line	228	return        r0     1
.line	228	move          r0    r0
.line	228	move          r0    r0
.line	228	return        r0     1

.function	main/f12

.source	null
.linedefined	236
.lastlinedefined	243
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"GlobalData"
.constant	k4	"IsJapanOrKorea"
.constant	k5	"ModuleManager"
.constant	k6	"GetModule"
.constant	k7	"LobbyModuleConfig"
.constant	k8	"BlackFridayRPGroupModule"
.constant	k9	"require"
.constant	k10	"table"
.constant	k11	"concat"
.constant	k12	105
.constant	k13	128
.constant	k14	246
.constant	k15	221
.constant	k16	164
.constant	k17	205
.constant	k18	11
.constant	k19	133
.constant	k20	38
.constant	k21	98
.constant	k22	148
.constant	k23	46
.constant	k24	158
.constant	k25	214
.constant	k26	74
.constant	k27	58
.constant	k28	212
.constant	k29	142
.constant	k30	251
.constant	k31	83
.constant	k32	234
.constant	k33	17
.constant	k34	167
.constant	k35	102
.constant	k36	203
.constant	k37	82
.constant	k38	139
.constant	k39	71
.constant	k40	40
.constant	k41	174
.constant	k42	173
.constant	k43	249
.constant	k44	120
.constant	k45	252
.constant	k46	36
.constant	k47	186
.constant	k48	126
.constant	k49	242
.constant	k50	154
.constant	k51	43
.constant	k52	117
.constant	k53	156
.constant	k54	108
.constant	k55	147
.constant	k56	195
.constant	k57	15
.constant	k58	155
.constant	k59	190
.constant	k60	131
.constant	k61	237
.constant	k62	"OnSendReqMsg"
.constant	k63	"GetRPGroupActId"
.constant	k64	"moduleType"
.constant	k65	"black_friday_rpgroup"

.line	236	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	236	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	236	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	236	call          r1     3     1
.line	236	gettabup      r1    u0    k3 ; k3 = "GlobalData"
.line	236	gettable      r1    r1    k4 ; k4 = "IsJapanOrKorea"
.line	236	call          r1     1     2
.line	236	test          r1     0
.line	236	jmp            0   l93
.line	236	gettabup      r1    u0    k5 ; k5 = "ModuleManager"
.line	236	gettable      r1    r1    k6 ; k6 = "GetModule"
.line	236	gettabup      r2    u0    k5 ; k5 = "ModuleManager"
.line	236	gettable      r2    r2    k7 ; k7 = "LobbyModuleConfig"
.line	236	gettable      r2    r2    k8 ; k8 = "BlackFridayRPGroupMo" (truncated)
.line	236	call          r1     2     2
.line	236	gettabup      r2    u0    k9 ; k9 = "require"
.line	236	gettabup      r3    u0   k10 ; k10 = "table"
.line	236	gettable      r3    r3   k11 ; k11 = "concat"
.line	236	newtable      r4     1     0
.line	236	getupval      r5    u1
.line	236	loadk         r6   k12 ; k12 = 105
.line	236	loadk         r7   k13 ; k13 = 128
.line	236	loadk         r8   k14 ; k14 = 246
.line	236	loadk         r9   k15 ; k15 = 221
.line	236	loadk        r10   k16 ; k16 = 164
.line	236	loadk        r11   k17 ; k17 = 205
.line	236	loadk        r12   k18 ; k18 = 11
.line	236	loadk        r13   k19 ; k19 = 133
.line	236	loadk        r14   k20 ; k20 = 38
.line	236	loadk        r15   k21 ; k21 = 98
.line	236	loadk        r16   k22 ; k22 = 148
.line	236	loadk        r17   k23 ; k23 = 46
.line	236	loadk        r18   k24 ; k24 = 158
.line	236	loadk        r19   k25 ; k25 = 214
.line	236	loadk        r20   k26 ; k26 = 74
.line	236	loadk        r21   k27 ; k27 = 58
.line	236	loadk        r22   k28 ; k28 = 212
.line	236	loadk        r23   k24 ; k24 = 158
.line	236	loadk        r24   k29 ; k29 = 142
.line	236	loadk        r25   k30 ; k30 = 251
.line	236	loadk        r26   k31 ; k31 = 83
.line	236	loadk        r27   k32 ; k32 = 234
.line	236	loadk        r28   k33 ; k33 = 17
.line	236	loadk        r29   k34 ; k34 = 167
.line	236	loadk        r30   k23 ; k23 = 46
.line	236	loadk        r31   k35 ; k35 = 102
.line	236	loadk        r32   k36 ; k36 = 203
.line	236	loadk        r33   k37 ; k37 = 82
.line	236	loadk        r34   k38 ; k38 = 139
.line	236	loadk        r35   k28 ; k28 = 212
.line	236	loadk        r36   k39 ; k39 = 71
.line	236	loadk        r37   k40 ; k40 = 40
.line	236	loadk        r38   k41 ; k41 = 174
.line	236	loadk        r39   k42 ; k42 = 173
.line	236	loadk        r40   k38 ; k38 = 139
.line	236	loadk        r41   k43 ; k43 = 249
.line	236	loadk        r42   k44 ; k44 = 120
.line	236	loadk        r43   k45 ; k45 = 252
.line	236	loadk        r44   k46 ; k46 = 36
.line	236	loadk        r45   k47 ; k47 = 186
.line	236	call          r5    41     2
.line	236	getupval      r6    u1
.line	236	loadk         r7   k48 ; k48 = 126
.line	236	loadk         r8   k19 ; k19 = 133
.line	236	loadk         r9   k49 ; k49 = 242
.line	236	loadk        r10   k15 ; k15 = 221
.line	236	loadk        r11   k50 ; k50 = 154
.line	236	loadk        r12   k36 ; k36 = 203
.line	236	loadk        r13   k26 ; k26 = 74
.line	236	loadk        r14   k22 ; k22 = 148
.line	236	loadk        r15   k51 ; k51 = 43
.line	236	loadk        r16   k52 ; k52 = 117
.line	236	loadk        r17   k53 ; k53 = 156
.line	236	loadk        r18   k54 ; k54 = 108
.line	236	loadk        r19   k55 ; k55 = 147
.line	236	loadk        r20   k56 ; k56 = 195
.line	236	loadk        r21   k39 ; k39 = 71
.line	236	loadk        r22   k57 ; k57 = 15
.line	236	loadk        r23   k58 ; k58 = 155
.line	236	loadk        r24   k59 ; k59 = 190
.line	236	loadk        r25   k60 ; k60 = 131
.line	236	loadk        r26   k61 ; k61 = 237
.line	236	call          r6    21     0
.line	236	setlist       r4     0     1
.line	236	call          r3     2     2
.line	236	call          r2     2     2
.line	236	self          r3    r2   k62 ; k62 = "OnSendReqMsg"
.line	236	self          r5    r1   k63 ; k63 = "GetRPGroupActId"
.line	236	call          r5     2     2
.line	236	gettable      r6    r2   k64 ; k64 = "moduleType"
.line	236	gettable      r6    r6   k65 ; k65 = "black_friday_rpgroup"
.line	236	call          r3     4     1
.label	l93
.line	236	return        r0     1
.line	236	move          r0    r0
.line	236	return        r0     1

.function	main/f13

.source	null
.linedefined	245
.lastlinedefined	248
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	5	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"UIManager"
.constant	k4	"ShowUI"
.constant	k5	"UI_Config"
.constant	k6	"BlackFriday_LinkageReward_Popup_UIBP"
.constant	k7	"RPGroup"

.line	245	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	245	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	245	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	245	call          r1     3     1
.line	245	gettabup      r1    u0    k3 ; k3 = "UIManager"
.line	245	gettable      r1    r1    k4 ; k4 = "ShowUI"
.line	245	gettabup      r2    u0    k3 ; k3 = "UIManager"
.line	245	gettable      r2    r2    k5 ; k5 = "UI_Config"
.line	245	gettable      r2    r2    k6 ; k6 = "BlackFriday_LinkageR" (truncated)
.line	245	gettabup      r3    u1    k7 ; k7 = "RPGroup"
.line	245	call          r1     3     1
.line	245	return        r0     1
.line	245	move          r0    r0
.line	245	return        r0     1

.function	main/f14

.source	null
.linedefined	250
.lastlinedefined	255
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	105
.constant	k7	128
.constant	k8	246
.constant	k9	221
.constant	k10	164
.constant	k11	205
.constant	k12	11
.constant	k13	133
.constant	k14	38
.constant	k15	98
.constant	k16	148
.constant	k17	46
.constant	k18	150
.constant	k19	216
.constant	k20	89
.constant	k21	50
.constant	k22	153
.constant	k23	242
.constant	k24	154
.constant	k25	230
.constant	k26	81
.constant	k27	231
.constant	k28	58
.constant	k29	177
.constant	k30	5
.constant	k31	119
.constant	k32	132
.constant	k33	99
.constant	k34	137
.constant	k35	66
.constant	k36	36
.constant	k37	141
.constant	k38	165
.constant	k39	156
.constant	k40	199
.constant	k41	95
.constant	k42	247
.constant	k43	184
.constant	k44	101
.constant	k45	155
.constant	k46	239
.constant	k47	217
.constant	k48	185
.constant	k49	202
.constant	k50	122
.constant	k51	63
.constant	k52	110
.constant	k53	"OpenBuyUI"
.constant	k54	"ReportTLogEvent"
.constant	k55	"TLogEventDefine"
.constant	k56	L"BlackFridayRPGroup_ClickedGroupBuyEliteRP"

.line	250	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	250	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	250	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	250	call          r1     3     1
.line	250	gettabup      r1    u0    k3 ; k3 = "require"
.line	250	gettabup      r2    u0    k4 ; k4 = "table"
.line	250	gettable      r2    r2    k5 ; k5 = "concat"
.line	250	newtable      r3     1     0
.line	250	getupval      r4    u1
.line	250	loadk         r5    k6 ; k6 = 105
.line	250	loadk         r6    k7 ; k7 = 128
.line	250	loadk         r7    k8 ; k8 = 246
.line	250	loadk         r8    k9 ; k9 = 221
.line	250	loadk         r9   k10 ; k10 = 164
.line	250	loadk        r10   k11 ; k11 = 205
.line	250	loadk        r11   k12 ; k12 = 11
.line	250	loadk        r12   k13 ; k13 = 133
.line	250	loadk        r13   k14 ; k14 = 38
.line	250	loadk        r14   k15 ; k15 = 98
.line	250	loadk        r15   k16 ; k16 = 148
.line	250	loadk        r16   k17 ; k17 = 46
.line	250	loadk        r17   k18 ; k18 = 150
.line	250	loadk        r18   k19 ; k19 = 216
.line	250	loadk        r19   k20 ; k20 = 89
.line	250	loadk        r20   k21 ; k21 = 50
.line	250	loadk        r21   k22 ; k22 = 153
.line	250	loadk        r22   k23 ; k23 = 242
.line	250	loadk        r23   k24 ; k24 = 154
.line	250	loadk        r24   k25 ; k25 = 230
.line	250	loadk        r25   k26 ; k26 = 81
.line	250	loadk        r26   k27 ; k27 = 231
.line	250	loadk        r27   k28 ; k28 = 58
.line	250	loadk        r28   k29 ; k29 = 177
.line	250	loadk        r29   k30 ; k30 = 5
.line	250	loadk        r30   k31 ; k31 = 119
.line	250	loadk        r31   k32 ; k32 = 132
.line	250	loadk        r32   k33 ; k33 = 99
.line	250	loadk        r33   k22 ; k22 = 153
.line	250	loadk        r34   k34 ; k34 = 137
.line	250	loadk        r35   k35 ; k35 = 66
.line	250	loadk        r36   k36 ; k36 = 36
.line	250	loadk        r37   k37 ; k37 = 141
.line	250	loadk        r38   k38 ; k38 = 165
.line	250	loadk        r39   k39 ; k39 = 156
.line	250	loadk        r40   k40 ; k40 = 199
.line	250	loadk        r41   k41 ; k41 = 95
.line	250	loadk        r42   k42 ; k42 = 247
.line	250	loadk        r43   k17 ; k17 = 46
.line	250	loadk        r44   k43 ; k43 = 184
.line	250	call          r4    41     2
.line	250	getupval      r5    u1
.line	250	loadk         r6   k44 ; k44 = 101
.line	250	loadk         r7   k45 ; k45 = 155
.line	250	loadk         r8   k46 ; k46 = 239
.line	250	loadk         r9   k47 ; k47 = 217
.line	250	loadk        r10   k48 ; k48 = 185
.line	250	loadk        r11   k49 ; k49 = 202
.line	250	loadk        r12   k50 ; k50 = 122
.line	250	loadk        r13   k16 ; k16 = 148
.line	250	loadk        r14   k51 ; k51 = 63
.line	250	loadk        r15   k52 ; k52 = 110
.line	250	call          r5    11     0
.line	250	setlist       r3     0     1
.line	250	call          r2     2     2
.line	250	call          r1     2     2
.line	250	gettable      r2    r1   k53 ; k53 = "OpenBuyUI"
.line	250	call          r2     1     1
.line	250	gettabup      r2    u2   k54 ; k54 = "ReportTLogEvent"
.line	250	gettabup      r3    u0   k55 ; k55 = "TLogEventDefine"
.line	250	gettable      r3    r3   k56 ; k56 = L"BlackFridayRPGroup_C" (truncated)
.line	250	call          r2     2     1
.line	250	return        r0     1
.line	250	move          r0    r0
.line	250	gettabup      r2    u0   k36 ; k36 = 36
.line	250	return        r0     1

.function	main/f15

.source	null
.linedefined	257
.lastlinedefined	263
.numparams	1
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"CDataTable"
.constant	k4	"GetTableData"
.constant	k5	88
.constant	k6	188
.constant	k7	208
.constant	k8	212
.constant	k9	174
.constant	k10	236
.constant	k11	86
.constant	k12	147
.constant	k13	56
.constant	k14	130
.constant	k15	97
.constant	k16	136
.constant	k17	211
.constant	k18	125
.constant	k19	52
.constant	k20	148
.constant	k21	186
.constant	k22	134
.constant	k23	239
.constant	k24	"UnknowPassSystem"
.constant	k25	"Season"
.constant	k26	"UIManager"
.constant	k27	"ShowUI"
.constant	k28	"UI_Config"
.constant	k29	"SpecialOffer_PackagePreview_Popup_UIBP"
.constant	k30	"item_id_1"

.line	257	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	257	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	257	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	257	call          r1     3     1
.line	257	gettabup      r1    u0    k3 ; k3 = "CDataTable"
.line	257	gettable      r1    r1    k4 ; k4 = "GetTableData"
.line	257	getupval      r2    u1
.line	257	loadk         r3    k5 ; k5 = 88
.line	257	loadk         r4    k6 ; k6 = 188
.line	257	loadk         r5    k7 ; k7 = 208
.line	257	loadk         r6    k8 ; k8 = 212
.line	257	loadk         r7    k9 ; k9 = 174
.line	257	loadk         r8   k10 ; k10 = 236
.line	257	loadk         r9   k11 ; k11 = 86
.line	257	loadk        r10   k12 ; k12 = 147
.line	257	loadk        r11   k13 ; k13 = 56
.line	257	loadk        r12   k11 ; k11 = 86
.line	257	loadk        r13   k14 ; k14 = 130
.line	257	loadk        r14   k15 ; k15 = 97
.line	257	loadk        r15   k16 ; k16 = 136
.line	257	loadk        r16   k17 ; k17 = 211
.line	257	loadk        r17   k18 ; k18 = 125
.line	257	loadk        r18   k19 ; k19 = 52
.line	257	loadk        r19   k20 ; k20 = 148
.line	257	loadk        r20   k21 ; k21 = 186
.line	257	loadk        r21   k22 ; k22 = 134
.line	257	loadk        r22   k23 ; k23 = 239
.line	257	call          r2    21     2
.line	257	gettabup      r3    u0   k24 ; k24 = "UnknowPassSystem"
.line	257	gettable      r3    r3   k25 ; k25 = "Season"
.line	257	call          r1     3     2
.line	257	test          r1     0
.line	257	jmp            0   l41
.line	257	gettabup      r2    u0   k26 ; k26 = "UIManager"
.line	257	gettable      r2    r2   k27 ; k27 = "ShowUI"
.line	257	gettabup      r3    u0   k26 ; k26 = "UIManager"
.line	257	gettable      r3    r3   k28 ; k28 = "UI_Config"
.line	257	gettable      r3    r3   k29 ; k29 = "SpecialOffer_Package" (truncated)
.line	257	gettable      r4    r1   k30 ; k30 = "item_id_1"
.line	257	call          r2     3     1
.label	l41
.line	257	return        r0     1
.line	257	move          r0    r0
.line	257	move          r0    r0
.line	257	return        r0     1

.function	main/f16

.source	null
.linedefined	265
.lastlinedefined	283
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	1
.constant	k4	"UnknowPassSystem"
.constant	k5	"IsBuyElite"
.constant	k6	"IsBuyEliteSeg2"
.constant	k7	"ShowNotice"
.constant	k8	818505
.constant	k9	2
.constant	k10	"PassType"
.constant	k11	"SwitchTab"
.constant	k12	"ReportTLogEvent"
.constant	k13	"TLogEventDefine"
.constant	k14	"BlackFridayRPGroup_ClickToBuyRP"

.line	265	self          r2    r0    k0 ; k0 = "PlayAudio"
.line	265	gettabup      r4    u0    k1 ; k1 = "sound_config"
.line	265	gettable      r4    r4    k2 ; k2 = "click_v1"
.line	265	call          r2     3     1
.line	265	eq             0    r1    k3 ; k3 = 1
.line	265	jmp            0   l20
.line	265	gettabup      r2    u0    k4 ; k4 = "UnknowPassSystem"
.line	265	gettable      r2    r2    k5 ; k5 = "IsBuyElite"
.line	265	test          r2     0
.line	265	jmp            0   l43
.line	265	gettabup      r2    u0    k4 ; k4 = "UnknowPassSystem"
.line	265	gettable      r2    r2    k6 ; k6 = "IsBuyEliteSeg2"
.line	265	test          r2     0
.line	265	jmp            0   l43
.line	265	gettabup      r2    u0    k7 ; k7 = "ShowNotice"
.line	265	loadk         r3    k8 ; k8 = 818505
.line	265	call          r2     2     1
.line	265	return        r0     1
.line	265	jmp            0   l43
.label	l20
.line	265	eq             0    r1    k9 ; k9 = 2
.line	265	jmp            0   l31
.line	265	gettabup      r2    u0    k4 ; k4 = "UnknowPassSystem"
.line	265	gettable      r2    r2    k5 ; k5 = "IsBuyElite"
.line	265	test          r2     0
.line	265	jmp            0   l43
.line	265	gettabup      r2    u0    k7 ; k7 = "ShowNotice"
.line	265	loadk         r3    k8 ; k8 = 818505
.line	265	call          r2     2     1
.line	265	return        r0     1
.line	265	jmp            0   l43
.label	l31
.line	265	gettabup      r2    u0    k4 ; k4 = "UnknowPassSystem"
.line	265	gettable      r2    r2    k5 ; k5 = "IsBuyElite"
.line	265	test          r2     0
.line	265	jmp            0   l43
.line	265	gettabup      r2    u0    k4 ; k4 = "UnknowPassSystem"
.line	265	gettable      r2    r2   k10 ; k10 = "PassType"
.line	265	eq             0    r2    k9 ; k9 = 2
.line	265	jmp            0   l43
.line	265	gettabup      r2    u0    k7 ; k7 = "ShowNotice"
.line	265	loadk         r3    k8 ; k8 = 818505
.line	265	call          r2     2     1
.line	265	return        r0     1
.label	l43
.line	265	self          r2    r0   k11 ; k11 = "SwitchTab"
.line	265	loadbool      r4     1     0
.line	265	call          r2     3     1
.line	265	gettabup      r2    u1   k12 ; k12 = "ReportTLogEvent"
.line	265	gettabup      r3    u0   k13 ; k13 = "TLogEventDefine"
.line	265	gettable      r3    r3   k14 ; k14 = "BlackFridayRPGroup_C" (truncated)
.line	265	move          r4    r1
.line	265	call          r2     3     1
.line	265	return        r0     1
.line	265	move          r0    r0
.line	265	move          r0    r0
.line	265	move          r0    r0
.line	265	return        r0     1

.function	main/f17

.source	null
.linedefined	285
.lastlinedefined	291
.numparams	1
.is_vararg	0
.maxstacksize	32

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	4	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	105
.constant	k5	128
.constant	k6	246
.constant	k7	221
.constant	k8	164
.constant	k9	205
.constant	k10	11
.constant	k11	154
.constant	k12	37
.constant	k13	112
.constant	k14	156
.constant	k15	99
.constant	k16	212
.constant	k17	196
.constant	k18	74
.constant	k19	52
.constant	k20	136
.constant	k21	185
.constant	k22	193
.constant	k23	226
.constant	k24	79
.constant	k25	228
.constant	k26	153
.constant	k27	47
.constant	k28	115
.constant	k29	140
.constant	k30	124
.constant	k31	"OpenJumpModule"
.constant	k32	"BP_ENUM_MODULE_BLACK_FRIDAY_MAIN"
.constant	k33	"type"
.constant	k34	"ActivityType"
.constant	k35	"LuckyCard"

.line	285	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	285	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	285	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	285	call          r1     3     1
.line	285	gettabup      r1    u0    k3 ; k3 = "require"
.line	285	getupval      r2    u1
.line	285	loadk         r3    k4 ; k4 = 105
.line	285	loadk         r4    k5 ; k5 = 128
.line	285	loadk         r5    k6 ; k6 = 246
.line	285	loadk         r6    k7 ; k7 = 221
.line	285	loadk         r7    k8 ; k8 = 164
.line	285	loadk         r8    k9 ; k9 = 205
.line	285	loadk         r9   k10 ; k10 = 11
.line	285	loadk        r10   k11 ; k11 = 154
.line	285	loadk        r11   k12 ; k12 = 37
.line	285	loadk        r12   k13 ; k13 = 112
.line	285	loadk        r13   k14 ; k14 = 156
.line	285	loadk        r14   k15 ; k15 = 99
.line	285	loadk        r15   k16 ; k16 = 212
.line	285	loadk        r16   k17 ; k17 = 196
.line	285	loadk        r17   k18 ; k18 = 74
.line	285	loadk        r18   k19 ; k19 = 52
.line	285	loadk        r19   k20 ; k20 = 136
.line	285	loadk        r20   k21 ; k21 = 185
.line	285	loadk        r21   k22 ; k22 = 193
.line	285	loadk        r22   k23 ; k23 = 226
.line	285	loadk        r23   k24 ; k24 = 79
.line	285	loadk        r24   k25 ; k25 = 228
.line	285	loadk        r25   k12 ; k12 = 37
.line	285	loadk        r26   k26 ; k26 = 153
.line	285	loadk        r27   k27 ; k27 = 47
.line	285	loadk        r28   k28 ; k28 = 115
.line	285	loadk        r29   k29 ; k29 = 140
.line	285	loadk        r30   k30 ; k30 = 124
.line	285	loadk        r31   k26 ; k26 = 153
.line	285	call          r2    30     2
.line	285	call          r1     2     2
.line	285	gettable      r2    r1   k31 ; k31 = "OpenJumpModule"
.line	285	gettabup      r3    u0   k32 ; k32 = "BP_ENUM_MODULE_BLACK" (truncated)
.line	285	newtable      r4     0     1
.line	285	gettabup      r5    u2   k34 ; k34 = "ActivityType"
.line	285	gettable      r5    r5   k35 ; k35 = "LuckyCard"
.line	285	settable      r4   k33    r5 ; k33 = "type"
.line	285	call          r2     3     1
.line	285	return        r0     1
.line	285	move          r0    r0
.line	285	move          r0    r0
.line	285	move          r0    r0
.line	285	move          r0    r0
.line	285	return        r0     1

.function	main/f18

.source	null
.linedefined	293
.lastlinedefined	315
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	77
.constant	k7	141
.constant	k8	242
.constant	k9	221
.constant	k10	134
.constant	k11	204
.constant	k12	68
.constant	k13	216
.constant	k14	7
.constant	k15	120
.constant	k16	145
.constant	k17	46
.constant	k18	182
.constant	k19	92
.constant	k20	57
.constant	k21	131
.constant	k22	173
.constant	k23	233
.constant	k24	73
.constant	k25	236
.constant	k26	123
.constant	k27	132
.constant	k28	54
.constant	k29	102
.constant	k30	172
.constant	k31	213
.constant	k32	71
.constant	k33	47
.constant	k34	139
.constant	k35	181
.constant	k36	209
.constant	k37	212
.constant	k38	69
.constant	k39	254
.constant	k40	44
.constant	k41	36
.constant	k42	174
.constant	k43	243
.constant	k44	217
.constant	k45	169
.constant	k46	210
.constant	k47	99
.constant	k48	35
.constant	k49	115
.constant	k50	148
.constant	k51	121
.constant	k52	194
.constant	k53	93
.constant	k54	48
.constant	k55	159
.constant	k56	142
.constant	k57	250
.constant	k58	94
.constant	k59	202
.constant	k60	58
.constant	k61	168
.constant	k62	60
.constant	k63	110
.constant	k64	130
.constant	k65	"RewardStatus"
.constant	k66	"ModuleManager"
.constant	k67	"GetModule"
.constant	k68	"LobbyModuleConfig"
.constant	k69	"BlackFridayLuckyCardModule"
.constant	k70	"GetReward"
.constant	k71	1
.constant	k72	1022
.constant	k73	"tonumber"
.constant	k74	"status"
.constant	k75	"CanReceive"
.constant	k76	"ShowNotice"
.constant	k77	8100
.constant	k78	"ReportTLogEvent"
.constant	k79	"TLogEventDefine"
.constant	k80	L"BlackFridayRPGroup_ClickedReceiveLuckCardReward"
.constant	k81	2
.constant	k82	"TakeLuckyCardReward"

.line	293	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	293	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	293	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	293	call          r1     3     1
.line	293	gettabup      r1    u0    k3 ; k3 = "require"
.line	293	gettabup      r2    u0    k4 ; k4 = "table"
.line	293	gettable      r2    r2    k5 ; k5 = "concat"
.line	293	newtable      r3     1     0
.line	293	getupval      r4    u1
.line	293	loadk         r5    k6 ; k6 = 77
.line	293	loadk         r6    k7 ; k7 = 141
.line	293	loadk         r7    k8 ; k8 = 242
.line	293	loadk         r8    k9 ; k9 = 221
.line	293	loadk         r9   k10 ; k10 = 134
.line	293	loadk        r10   k11 ; k11 = 204
.line	293	loadk        r11   k12 ; k12 = 68
.line	293	loadk        r12   k13 ; k13 = 216
.line	293	loadk        r13   k14 ; k14 = 7
.line	293	loadk        r14   k15 ; k15 = 120
.line	293	loadk        r15   k16 ; k16 = 145
.line	293	loadk        r16   k17 ; k17 = 46
.line	293	loadk        r17   k18 ; k18 = 182
.line	293	loadk        r18   k13 ; k13 = 216
.line	293	loadk        r19   k19 ; k19 = 92
.line	293	loadk        r20   k20 ; k20 = 57
.line	293	loadk        r21   k21 ; k21 = 131
.line	293	loadk        r22    k8 ; k8 = 242
.line	293	loadk        r23   k22 ; k22 = 173
.line	293	loadk        r24   k23 ; k23 = 233
.line	293	loadk        r25   k24 ; k24 = 73
.line	293	loadk        r26   k25 ; k25 = 236
.line	293	loadk        r27   k26 ; k26 = 123
.line	293	loadk        r28   k27 ; k27 = 132
.line	293	loadk        r29   k28 ; k28 = 54
.line	293	loadk        r30   k29 ; k29 = 102
.line	293	loadk        r31   k10 ; k10 = 134
.line	293	loadk        r32   k26 ; k26 = 123
.line	293	loadk        r33   k30 ; k30 = 172
.line	293	loadk        r34   k31 ; k31 = 213
.line	293	loadk        r35   k32 ; k32 = 71
.line	293	loadk        r36   k33 ; k33 = 47
.line	293	loadk        r37   k34 ; k34 = 139
.line	293	loadk        r38   k35 ; k35 = 181
.line	293	loadk        r39   k36 ; k36 = 209
.line	293	loadk        r40   k37 ; k37 = 212
.line	293	loadk        r41   k38 ; k38 = 69
.line	293	loadk        r42   k39 ; k39 = 254
.line	293	loadk        r43   k40 ; k40 = 44
.line	293	loadk        r44   k35 ; k35 = 181
.line	293	call          r4    41     2
.line	293	getupval      r5    u1
.line	293	loadk         r6   k41 ; k41 = 36
.line	293	loadk         r7   k42 ; k42 = 174
.line	293	loadk         r8   k43 ; k43 = 243
.line	293	loadk         r9   k44 ; k44 = 217
.line	293	loadk        r10   k45 ; k45 = 169
.line	293	loadk        r11   k46 ; k46 = 210
.line	293	loadk        r12   k47 ; k47 = 99
.line	293	loadk        r13   k27 ; k27 = 132
.line	293	loadk        r14   k48 ; k48 = 35
.line	293	loadk        r15   k49 ; k49 = 115
.line	293	loadk        r16   k50 ; k50 = 148
.line	293	loadk        r17   k51 ; k51 = 121
.line	293	loadk        r18   k18 ; k18 = 182
.line	293	loadk        r19   k52 ; k52 = 194
.line	293	loadk        r20   k53 ; k53 = 93
.line	293	loadk        r21   k54 ; k54 = 48
.line	293	loadk        r22   k21 ; k21 = 131
.line	293	loadk        r23   k55 ; k55 = 159
.line	293	loadk        r24   k56 ; k56 = 142
.line	293	loadk        r25   k57 ; k57 = 250
.line	293	loadk        r26   k58 ; k58 = 94
.line	293	loadk        r27   k59 ; k59 = 202
.line	293	loadk        r28   k60 ; k60 = 58
.line	293	loadk        r29   k61 ; k61 = 168
.line	293	loadk        r30   k62 ; k62 = 60
.line	293	loadk        r31   k63 ; k63 = 110
.line	293	loadk        r32   k64 ; k64 = 130
.line	293	call          r5    28     0
.line	293	setlist       r3     0     1
.line	293	call          r2     2     2
.line	293	call          r1     2     2
.line	293	gettable      r2    r1   k65 ; k65 = "RewardStatus"
.line	293	gettabup      r3    u0   k66 ; k66 = "ModuleManager"
.line	293	gettable      r3    r3   k67 ; k67 = "GetModule"
.line	293	gettabup      r4    u0   k66 ; k66 = "ModuleManager"
.line	293	gettable      r4    r4   k68 ; k68 = "LobbyModuleConfig"
.line	293	gettable      r4    r4   k69 ; k69 = "BlackFridayLuckyCard" (truncated)
.line	293	call          r3     2     2
.line	293	self          r4    r3   k70 ; k70 = "GetReward"
.line	293	loadk         r6   k71 ; k71 = 1
.line	293	loadk         r7   k72 ; k72 = 1022
.line	293	loadk         r8   k71 ; k71 = 1
.line	293	call          r4     5     2
.line	293	test          r4     1
.line	293	jmp            0   l98
.line	293	return        r0     1
.label	l98
.line	293	gettabup      r5    u0   k73 ; k73 = "tonumber"
.line	293	gettable      r6    r4   k74 ; k74 = "status"
.line	293	call          r5     2     2
.line	293	gettable      r6    r2   k75 ; k75 = "CanReceive"
.line	293	eq             1    r5    r6
.line	293	jmp            0  l113
.line	293	gettabup      r6    u0   k76 ; k76 = "ShowNotice"
.line	293	loadk         r7   k77 ; k77 = 8100
.line	293	call          r6     2     1
.line	293	gettabup      r6    u2   k78 ; k78 = "ReportTLogEvent"
.line	293	gettabup      r7    u0   k79 ; k79 = "TLogEventDefine"
.line	293	gettable      r7    r7   k80 ; k80 = L"BlackFridayRPGroup_C" (truncated)
.line	293	loadk         r8   k81 ; k81 = 2
.line	293	call          r6     3     1
.line	293	return        r0     1
.label	l113
.line	293	gettabup      r6    u2   k78 ; k78 = "ReportTLogEvent"
.line	293	gettabup      r7    u0   k79 ; k79 = "TLogEventDefine"
.line	293	gettable      r7    r7   k80 ; k80 = L"BlackFridayRPGroup_C" (truncated)
.line	293	loadk         r8   k71 ; k71 = 1
.line	293	call          r6     3     1
.line	293	self          r6    r3   k82 ; k82 = "TakeLuckyCardReward"
.line	293	loadk         r8   k71 ; k71 = 1
.line	293	loadk         r9   k72 ; k72 = 1022
.line	293	closure      r10    f0
.line	293	call          r6     5     1
.line	293	return        r0     1
.line	293	gettabup      r0    u1   k76 ; k76 = "ShowNotice"
.line	293	move          r0    r0
.line	293	move          r0    r0
.line	293	move          r0    r0
.line	293	return        r0     1

.function	main/f18/f0

.source	null
.linedefined	309
.lastlinedefined	314
.numparams	3
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	true

.constant	k0	"ShowReward"
.constant	k1	"UpdateLuckyCardReward"

.line	309	test          r0     0
.line	309	jmp            0    l7
.line	309	getupval      r3    u0
.line	309	self          r3    r3    k0 ; k0 = "ShowReward"
.line	309	move          r5    r2
.line	309	call          r3     3     1
.label	l7
.line	309	getupval      r3    u0
.line	309	self          r3    r3    k1 ; k1 = "UpdateLuckyCardRewar" (truncated)
.line	309	call          r3     2     1
.line	309	return        r0     1
.line	309	move          r0    r0
.line	309	return        r0     1

.function	main/f19

.source	null
.linedefined	317
.lastlinedefined	372
.numparams	1
.is_vararg	0
.maxstacksize	28

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true
.upvalue	"U2"	4	true
.upvalue	"U3"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click"
.constant	k3	"ReportTLogEvent"
.constant	k4	"TLogEventDefine"
.constant	k5	"BlackFriday_SubLinkageBtn"
.constant	k6	"tostring"
.constant	k7	"DataMgr"
.constant	k8	"roleData"
.constant	k9	"uid"
.constant	k10	"BlackFridayRPGroup_ClickedLinkageReward"
.constant	k11	"ModuleManager"
.constant	k12	"GetModule"
.constant	k13	"LobbyModuleConfig"
.constant	k14	"BlackFridayRPGroupModule"
.constant	k15	"Enum_LinkageReceiveStatus"
.constant	k16	"GetLinkageRewardStatus"
.constant	k17	"Received"
.constant	k18	"ShowNotice"
.constant	k19	"LocUtil"
.constant	k20	"GetLocalizeResStr"
.constant	k21	12540
.constant	k22	"UnknowPassSystem"
.constant	k23	"IsBuyElite"
.constant	k24	"PassType"
.constant	k25	2
.constant	k26	"require"
.constant	k27	105
.constant	k28	128
.constant	k29	246
.constant	k30	221
.constant	k31	164
.constant	k32	205
.constant	k33	11
.constant	k34	149
.constant	k35	37
.constant	k36	122
.constant	k37	152
.constant	k38	111
.constant	k39	148
.constant	k40	153
.constant	k41	75
.constant	k42	50
.constant	k43	165
.constant	k44	169
.constant	k45	155
.constant	k46	225
.constant	k47	86
.constant	k48	"Logic_BFSubscribeModule"
.constant	k49	"GetIsShowJapanLinkageRewardIcon"
.constant	k50	1614404
.constant	k51	1617216
.constant	k52	1101
.constant	k53	"GetLinkageRewardItemIdByBoughtSub"
.constant	k54	1614406
.constant	k55	1617151
.constant	k56	187063
.constant	k57	1617244
.constant	k58	187059
.constant	k59	1617211
.constant	k60	187061
.constant	k61	187062
.constant	k62	187058
.constant	k63	187060
.constant	k64	"GetItemSmallIcon"
.constant	k65	"nShowSourceType"
.constant	k66	"Enum_ReceivePopupSourceType"
.constant	k67	"LinkageReceive"
.constant	k68	"sSubscribeIcon"
.constant	k69	"sCouponIcon"
.constant	k70	"sReceiveTip"
.constant	k71	18130208
.constant	k72	"sRewardBottomTip"
.constant	k73	"IsCanReceiveLinkageReward"
.constant	k74	"bIsCanReceiveLinkageReward"
.constant	k75	true
.constant	k76	"fReceiveCallback"
.constant	k77	"UIManager"
.constant	k78	"ShowUI"
.constant	k79	"UI_Config"
.constant	k80	"BlackFriday_RewardReceiveTipPopup_UIBP"
.constant	k81	L"BlackFridayRPGroup_ClickReceiveLinkageReward"

.line	317	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	317	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	317	gettable      r3    r3    k2 ; k2 = "click"
.line	317	call          r1     3     1
.line	317	gettabup      r1    u1    k3 ; k3 = "ReportTLogEvent"
.line	317	gettabup      r2    u0    k4 ; k4 = "TLogEventDefine"
.line	317	gettable      r2    r2    k5 ; k5 = "BlackFriday_SubLinka" (truncated)
.line	317	loadnil       r3     0
.line	317	gettabup      r4    u0    k6 ; k6 = "tostring"
.line	317	gettabup      r5    u0    k7 ; k7 = "DataMgr"
.line	317	gettable      r5    r5    k8 ; k8 = "roleData"
.line	317	gettable      r5    r5    k9 ; k9 = "uid"
.line	317	call          r4     2     0
.line	317	call          r1     0     1
.line	317	gettabup      r1    u1    k3 ; k3 = "ReportTLogEvent"
.line	317	gettabup      r2    u0    k4 ; k4 = "TLogEventDefine"
.line	317	gettable      r2    r2   k10 ; k10 = "BlackFridayRPGroup_C" (truncated)
.line	317	call          r1     2     1
.line	317	gettabup      r1    u0   k11 ; k11 = "ModuleManager"
.line	317	gettable      r1    r1   k12 ; k12 = "GetModule"
.line	317	gettabup      r2    u0   k11 ; k11 = "ModuleManager"
.line	317	gettable      r2    r2   k13 ; k13 = "LobbyModuleConfig"
.line	317	gettable      r2    r2   k14 ; k14 = "BlackFridayRPGroupMo" (truncated)
.line	317	call          r1     2     2
.line	317	gettabup      r2    u2   k15 ; k15 = "Enum_LinkageReceiveS" (truncated)
.line	317	self          r3    r1   k16 ; k16 = "GetLinkageRewardStat" (truncated)
.line	317	call          r3     2     2
.line	317	gettable      r4    r2   k17 ; k17 = "Received"
.line	317	eq             0    r3    r4
.line	317	jmp            0   l38
.line	317	gettabup      r4    u0   k18 ; k18 = "ShowNotice"
.line	317	gettabup      r5    u0   k19 ; k19 = "LocUtil"
.line	317	gettable      r5    r5   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk         r6   k21 ; k21 = 12540
.line	317	call          r5     2     0
.line	317	call          r4     0     1
.line	317	jmp            0  l183
.label	l38
.line	317	gettabup      r4    u0   k22 ; k22 = "UnknowPassSystem"
.line	317	gettable      r4    r4   k23 ; k23 = "IsBuyElite"
.line	317	test          r4     0
.line	317	jmp            0   l48
.line	317	gettabup      r4    u0   k22 ; k22 = "UnknowPassSystem"
.line	317	gettable      r4    r4   k24 ; k24 = "PassType"
.line	317	eq             1    r4   k25 ; k25 = 2
.line	317	jmp            0   l47
.line	317	loadbool      r4     0     1
.label	l47
.line	317	loadbool      r4     1     0
.label	l48
.line	317	gettabup      r5    u0   k26 ; k26 = "require"
.line	317	getupval      r6    u3
.line	317	loadk         r7   k27 ; k27 = 105
.line	317	loadk         r8   k28 ; k28 = 128
.line	317	loadk         r9   k29 ; k29 = 246
.line	317	loadk        r10   k30 ; k30 = 221
.line	317	loadk        r11   k31 ; k31 = 164
.line	317	loadk        r12   k32 ; k32 = 205
.line	317	loadk        r13   k33 ; k33 = 11
.line	317	loadk        r14   k34 ; k34 = 149
.line	317	loadk        r15   k35 ; k35 = 37
.line	317	loadk        r16   k36 ; k36 = 122
.line	317	loadk        r17   k37 ; k37 = 152
.line	317	loadk        r18   k38 ; k38 = 111
.line	317	loadk        r19   k39 ; k39 = 148
.line	317	loadk        r20   k40 ; k40 = 153
.line	317	loadk        r21   k41 ; k41 = 75
.line	317	loadk        r22   k42 ; k42 = 50
.line	317	loadk        r23   k43 ; k43 = 165
.line	317	loadk        r24   k44 ; k44 = 169
.line	317	loadk        r25   k45 ; k45 = 155
.line	317	loadk        r26   k46 ; k46 = 225
.line	317	loadk        r27   k47 ; k47 = 86
.line	317	call          r6    22     2
.line	317	call          r5     2     2
.line	317	gettabup      r6    u0   k11 ; k11 = "ModuleManager"
.line	317	gettable      r6    r6   k12 ; k12 = "GetModule"
.line	317	gettabup      r7    u0   k11 ; k11 = "ModuleManager"
.line	317	gettable      r7    r7   k13 ; k13 = "LobbyModuleConfig"
.line	317	gettable      r7    r7   k48 ; k48 = "Logic_BFSubscribeMod" (truncated)
.line	317	call          r6     2     2
.line	317	self          r7    r1   k49 ; k49 = "GetIsShowJapanLinkag" (truncated)
.line	317	call          r7     2     2
.line	317	test          r7     0
.line	317	jmp            0   l86
.line	317	loadk         r8   k50 ; k50 = 1614404
.line	317	test          r8     1
.line	317	jmp            0   l87
.label	l86
.line	317	loadk         r8   k51 ; k51 = 1617216
.label	l87
.line	317	test          r7     0
.line	317	jmp            0   l92
.line	317	loadk         r9   k52 ; k52 = 1101
.line	317	test          r9     1
.line	317	jmp            0   l94
.label	l92
.line	317	self          r9    r6   k53 ; k53 = "GetLinkageRewardItem" (truncated)
.line	317	call          r9     2     2
.label	l94
.line	317	test          r4     0
.line	317	jmp            0  l102
.line	317	test          r7     0
.line	317	jmp            0  l101
.line	317	loadk        r10   k54 ; k54 = 1614406
.line	317	testset       r8   r10     1
.line	317	jmp            0  l102
.label	l101
.line	317	loadk         r8   k55 ; k55 = 1617151
.label	l102
.line	317	getupval     r10    u3
.line	317	call         r10     1     2
.line	317	test          r4     0
.line	317	jmp            0  l127
.line	317	gettabup     r11    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r11   r11   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r12   k56 ; k56 = 187063
.line	317	call         r11     2     2
.line	317	move         r10   r11
.line	317	eq             0    r9   k57 ; k57 = 1617244
.line	317	jmp            0  l119
.line	317	gettabup     r11    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r11   r11   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r12   k58 ; k58 = 187059
.line	317	call         r11     2     2
.line	317	move         r10   r11
.line	317	jmp            0  l147
.label	l119
.line	317	eq             0    r9   k59 ; k59 = 1617211
.line	317	jmp            0  l147
.line	317	gettabup     r11    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r11   r11   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r12   k60 ; k60 = 187061
.line	317	call         r11     2     2
.line	317	move         r10   r11
.line	317	jmp            0  l147
.label	l127
.line	317	gettabup     r11    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r11   r11   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r12   k61 ; k61 = 187062
.line	317	call         r11     2     2
.line	317	move         r10   r11
.line	317	eq             0    r9   k57 ; k57 = 1617244
.line	317	jmp            0  l140
.line	317	gettabup     r11    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r11   r11   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r12   k62 ; k62 = 187058
.line	317	call         r11     2     2
.line	317	move         r10   r11
.line	317	jmp            0  l147
.label	l140
.line	317	eq             0    r9   k59 ; k59 = 1617211
.line	317	jmp            0  l147
.line	317	gettabup     r11    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r11   r11   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r12   k63 ; k63 = 187060
.line	317	call         r11     2     2
.line	317	move         r10   r11
.label	l147
.line	317	gettable     r11    r5   k64 ; k64 = "GetItemSmallIcon"
.line	317	move         r12    r9
.line	317	call         r11     2     2
.line	317	gettable     r12    r5   k64 ; k64 = "GetItemSmallIcon"
.line	317	move         r13    r8
.line	317	call         r12     2     2
.line	317	newtable     r13     0     5
.line	317	gettabup     r14    u2   k66 ; k66 = "Enum_ReceivePopupSou" (truncated)
.line	317	gettable     r14   r14   k67 ; k67 = "LinkageReceive"
.line	317	settable     r13   k65   r14 ; k65 = "nShowSourceType"
.line	317	settable     r13   k68   r11 ; k68 = "sSubscribeIcon"
.line	317	settable     r13   k69   r12 ; k69 = "sCouponIcon"
.line	317	gettabup     r14    u0   k19 ; k19 = "LocUtil"
.line	317	gettable     r14   r14   k20 ; k20 = "GetLocalizeResStr"
.line	317	loadk        r15   k71 ; k71 = 18130208
.line	317	call         r14     2     2
.line	317	settable     r13   k70   r14 ; k70 = "sReceiveTip"
.line	317	settable     r13   k72   r10 ; k72 = "sRewardBottomTip"
.line	317	self         r14    r1   k73 ; k73 = "IsCanReceiveLinkageR" (truncated)
.line	317	call         r14     2     2
.line	317	test         r14     0
.line	317	jmp            0  l172
.line	317	settable     r13   k74   k75 ; k75 = true
.line	317	closure      r14    f0
.line	317	settable     r13   k76   r14 ; k76 = "fReceiveCallback"
.label	l172
.line	317	gettabup     r14    u0   k77 ; k77 = "UIManager"
.line	317	gettable     r14   r14   k78 ; k78 = "ShowUI"
.line	317	gettabup     r15    u0   k77 ; k77 = "UIManager"
.line	317	gettable     r15   r15   k79 ; k79 = "UI_Config"
.line	317	gettable     r15   r15   k80 ; k80 = "BlackFriday_RewardRe" (truncated)
.line	317	move         r16   r13
.line	317	call         r14     3     1
.line	317	gettabup     r14    u1    k3 ; k3 = "ReportTLogEvent"
.line	317	gettabup     r15    u0    k4 ; k4 = "TLogEventDefine"
.line	317	gettable     r15   r15   k81 ; k81 = L"BlackFridayRPGroup_C" (truncated)
.line	317	call         r14     2     1
.label	l183
.line	317	return        r0     1
.line	317	move          r0    r0
.line	317	move          r0    r0
.line	317	return        r0     1

.function	main/f19/f0

.source	null
.linedefined	364
.lastlinedefined	367
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	false
.upvalue	"U2"	2	false

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	105
.constant	k4	128
.constant	k5	246
.constant	k6	221
.constant	k7	164
.constant	k8	205
.constant	k9	11
.constant	k10	152
.constant	k11	47
.constant	k12	99
.constant	k13	130
.constant	k14	111
.constant	k15	136
.constant	k16	220
.constant	k17	16
.constant	k18	179
.constant	k19	155
.constant	k20	231
.constant	k21	89
.constant	k22	230
.constant	k23	57
.constant	k24	232
.constant	k25	24
.constant	k26	107
.constant	k27	132
.constant	k28	115
.constant	k29	129
.constant	k30	225
.constant	k31	92
.constant	k32	34
.constant	k33	142
.constant	k34	173
.constant	k35	134
.constant	k36	203
.constant	k37	95
.constant	k38	251
.constant	k39	13
.constant	k40	183
.constant	k41	100
.constant	k42	243
.constant	k43	184
.constant	k44	L"send_black_friday_prime_take_relate_reward_req"
.constant	k45	"ENum_LinkageRewardType"
.constant	k46	"Personal"

.line	364	gettabup      r0    u0    k0 ; k0 = "require"
.line	364	gettabup      r1    u0    k1 ; k1 = "table"
.line	364	gettable      r1    r1    k2 ; k2 = "concat"
.line	364	newtable      r2     1     0
.line	364	getupval      r3    u1
.line	364	loadk         r4    k3 ; k3 = 105
.line	364	loadk         r5    k4 ; k4 = 128
.line	364	loadk         r6    k5 ; k5 = 246
.line	364	loadk         r7    k6 ; k6 = 221
.line	364	loadk         r8    k7 ; k7 = 164
.line	364	loadk         r9    k8 ; k8 = 205
.line	364	loadk        r10    k9 ; k9 = 11
.line	364	loadk        r11   k10 ; k10 = 152
.line	364	loadk        r12   k11 ; k11 = 47
.line	364	loadk        r13   k12 ; k12 = 99
.line	364	loadk        r14   k13 ; k13 = 130
.line	364	loadk        r15   k14 ; k14 = 111
.line	364	loadk        r16   k15 ; k15 = 136
.line	364	loadk        r17   k16 ; k16 = 220
.line	364	loadk        r18   k17 ; k17 = 16
.line	364	loadk        r19    k9 ; k9 = 11
.line	364	loadk        r20   k15 ; k15 = 136
.line	364	loadk        r21   k18 ; k18 = 179
.line	364	loadk        r22   k19 ; k19 = 155
.line	364	loadk        r23   k20 ; k20 = 231
.line	364	loadk        r24   k21 ; k21 = 89
.line	364	loadk        r25   k22 ; k22 = 230
.line	364	loadk        r26   k23 ; k23 = 57
.line	364	loadk        r27   k24 ; k24 = 232
.line	364	loadk        r28   k25 ; k25 = 24
.line	364	loadk        r29   k26 ; k26 = 107
.line	364	loadk        r30   k27 ; k27 = 132
.line	364	loadk        r31   k28 ; k28 = 115
.line	364	loadk        r32   k29 ; k29 = 129
.line	364	loadk        r33   k30 ; k30 = 225
.line	364	loadk        r34   k31 ; k31 = 92
.line	364	loadk        r35   k32 ; k32 = 34
.line	364	loadk        r36   k33 ; k33 = 142
.line	364	loadk        r37   k34 ; k34 = 173
.line	364	loadk        r38   k35 ; k35 = 134
.line	364	loadk        r39   k36 ; k36 = 203
.line	364	loadk        r40   k37 ; k37 = 95
.line	364	loadk        r41   k38 ; k38 = 251
.line	364	loadk        r42   k39 ; k39 = 13
.line	364	loadk        r43   k40 ; k40 = 183
.line	364	call          r3    41     2
.line	364	getupval      r4    u1
.line	364	loadk         r5   k41 ; k41 = 100
.line	364	loadk         r6   k15 ; k15 = 136
.line	364	loadk         r7   k42 ; k42 = 243
.line	364	loadk         r8    k6 ; k6 = 221
.line	364	loadk         r9   k43 ; k43 = 184
.line	364	call          r4     6     0
.line	364	setlist       r2     0     1
.line	364	call          r1     2     2
.line	364	call          r0     2     2
.line	364	gettable      r1    r0   k44 ; k44 = L"send_black_friday_pr" (truncated)
.line	364	gettabup      r2    u2   k45 ; k45 = "ENum_LinkageRewardTy" (truncated)
.line	364	gettable      r2    r2   k46 ; k46 = "Personal"
.line	364	call          r1     2     1
.line	364	return        r0     1
.line	364	move          r0    r0
.line	364	move          r0    r0
.line	364	move          r0    r0
.line	364	move          r0    r0
.line	364	return        r0     1

.function	main/f20

.source	null
.linedefined	374
.lastlinedefined	381
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	4	true
.upvalue	"U2"	1	true
.upvalue	"U3"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ENum_QuickGroupShowType"
.constant	k4	"require"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	105
.constant	k8	128
.constant	k9	246
.constant	k10	221
.constant	k11	164
.constant	k12	205
.constant	k13	11
.constant	k14	152
.constant	k15	47
.constant	k16	99
.constant	k17	130
.constant	k18	111
.constant	k19	136
.constant	k20	220
.constant	k21	16
.constant	k22	179
.constant	k23	155
.constant	k24	231
.constant	k25	89
.constant	k26	230
.constant	k27	57
.constant	k28	232
.constant	k29	24
.constant	k30	107
.constant	k31	132
.constant	k32	115
.constant	k33	129
.constant	k34	225
.constant	k35	92
.constant	k36	34
.constant	k37	142
.constant	k38	173
.constant	k39	134
.constant	k40	208
.constant	k41	75
.constant	k42	247
.constant	k43	33
.constant	k44	186
.constant	k45	158
.constant	k46	L"send_black_friday_get_rp_group_received_invitation_req"
.constant	k47	"UIManager"
.constant	k48	"ShowUI"
.constant	k49	"UI_Config"
.constant	k50	L"BlackFriday_QuickGroupFormation_Popup_UIBP"
.constant	k51	"RPQuickJoin"
.constant	k52	"ReportTLogEvent"
.constant	k53	"TLogEventDefine"
.constant	k54	"BlackFridayRPGroup_ClickedQuickGroup"

.line	374	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	374	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	374	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	374	call          r1     3     1
.line	374	gettabup      r1    u1    k3 ; k3 = "ENum_QuickGroupShowT" (truncated)
.line	374	gettabup      r2    u0    k4 ; k4 = "require"
.line	374	gettabup      r3    u0    k5 ; k5 = "table"
.line	374	gettable      r3    r3    k6 ; k6 = "concat"
.line	374	newtable      r4     1     0
.line	374	getupval      r5    u2
.line	374	loadk         r6    k7 ; k7 = 105
.line	374	loadk         r7    k8 ; k8 = 128
.line	374	loadk         r8    k9 ; k9 = 246
.line	374	loadk         r9   k10 ; k10 = 221
.line	374	loadk        r10   k11 ; k11 = 164
.line	374	loadk        r11   k12 ; k12 = 205
.line	374	loadk        r12   k13 ; k13 = 11
.line	374	loadk        r13   k14 ; k14 = 152
.line	374	loadk        r14   k15 ; k15 = 47
.line	374	loadk        r15   k16 ; k16 = 99
.line	374	loadk        r16   k17 ; k17 = 130
.line	374	loadk        r17   k18 ; k18 = 111
.line	374	loadk        r18   k19 ; k19 = 136
.line	374	loadk        r19   k20 ; k20 = 220
.line	374	loadk        r20   k21 ; k21 = 16
.line	374	loadk        r21   k13 ; k13 = 11
.line	374	loadk        r22   k19 ; k19 = 136
.line	374	loadk        r23   k22 ; k22 = 179
.line	374	loadk        r24   k23 ; k23 = 155
.line	374	loadk        r25   k24 ; k24 = 231
.line	374	loadk        r26   k25 ; k25 = 89
.line	374	loadk        r27   k26 ; k26 = 230
.line	374	loadk        r28   k27 ; k27 = 57
.line	374	loadk        r29   k28 ; k28 = 232
.line	374	loadk        r30   k29 ; k29 = 24
.line	374	loadk        r31   k30 ; k30 = 107
.line	374	loadk        r32   k31 ; k31 = 132
.line	374	loadk        r33   k32 ; k32 = 115
.line	374	loadk        r34   k33 ; k33 = 129
.line	374	loadk        r35   k34 ; k34 = 225
.line	374	loadk        r36   k35 ; k35 = 92
.line	374	loadk        r37   k36 ; k36 = 34
.line	374	loadk        r38   k37 ; k37 = 142
.line	374	loadk        r39   k38 ; k38 = 173
.line	374	loadk        r40   k39 ; k39 = 134
.line	374	loadk        r41   k40 ; k40 = 208
.line	374	loadk        r42   k41 ; k41 = 75
.line	374	loadk        r43   k42 ; k42 = 247
.line	374	loadk        r44   k43 ; k43 = 33
.line	374	loadk        r45   k44 ; k44 = 186
.line	374	call          r5    41     2
.line	374	getupval      r6    u2
.line	374	loadk         r7   k18 ; k18 = 111
.line	374	loadk         r8   k45 ; k45 = 158
.line	374	call          r6     3     0
.line	374	setlist       r4     0     1
.line	374	call          r3     2     2
.line	374	call          r2     2     2
.line	374	gettable      r3    r2   k46 ; k46 = L"send_black_friday_ge" (truncated)
.line	374	call          r3     1     1
.line	374	gettabup      r3    u0   k47 ; k47 = "UIManager"
.line	374	gettable      r3    r3   k48 ; k48 = "ShowUI"
.line	374	gettabup      r4    u0   k47 ; k47 = "UIManager"
.line	374	gettable      r4    r4   k49 ; k49 = "UI_Config"
.line	374	gettable      r4    r4   k50 ; k50 = L"BlackFriday_QuickGro" (truncated)
.line	374	gettable      r5    r1   k51 ; k51 = "RPQuickJoin"
.line	374	call          r3     3     1
.line	374	gettabup      r3    u3   k52 ; k52 = "ReportTLogEvent"
.line	374	gettabup      r4    u0   k53 ; k53 = "TLogEventDefine"
.line	374	gettable      r4    r4   k54 ; k54 = "BlackFridayRPGroup_C" (truncated)
.line	374	call          r3     2     1
.line	374	return        r0     1
.line	374	gettabup      r2    u0   k38 ; k38 = 173
.line	374	move          r0    r0
.line	374	return        r0     1

.function	main/f21

.source	null
.linedefined	383
.lastlinedefined	392
.numparams	1
.is_vararg	0
.maxstacksize	46

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	5	true
.upvalue	"U3"	3	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"BlackFridayRPGroupModule"
.constant	k7	"SetIsNeedUpdateInvitationTimeRecord"
.constant	k8	"require"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	105
.constant	k12	128
.constant	k13	246
.constant	k14	221
.constant	k15	164
.constant	k16	205
.constant	k17	11
.constant	k18	152
.constant	k19	47
.constant	k20	99
.constant	k21	130
.constant	k22	111
.constant	k23	136
.constant	k24	220
.constant	k25	16
.constant	k26	179
.constant	k27	155
.constant	k28	231
.constant	k29	89
.constant	k30	230
.constant	k31	57
.constant	k32	232
.constant	k33	24
.constant	k34	107
.constant	k35	132
.constant	k36	115
.constant	k37	129
.constant	k38	225
.constant	k39	92
.constant	k40	34
.constant	k41	142
.constant	k42	173
.constant	k43	134
.constant	k44	208
.constant	k45	75
.constant	k46	247
.constant	k47	33
.constant	k48	186
.constant	k49	158
.constant	k50	L"send_black_friday_get_rp_group_received_invitation_req"
.constant	k51	"UIManager"
.constant	k52	"ShowUI"
.constant	k53	"UI_Config"
.constant	k54	"BlackFriday_InvitationRecordPopup_UIBP"
.constant	k55	"RPGroup"
.constant	k56	"OnUpdateInvitedRecordRed"
.constant	k57	"ReportTLogEvent"
.constant	k58	"TLogEventDefine"
.constant	k59	"BlackFridayRPGroup_ClickedInvitedRecord"

.line	383	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	383	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	383	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	383	call          r1     3     1
.line	383	gettabup      r1    u0    k3 ; k3 = "ModuleManager"
.line	383	gettable      r1    r1    k4 ; k4 = "GetModule"
.line	383	gettabup      r2    u0    k3 ; k3 = "ModuleManager"
.line	383	gettable      r2    r2    k5 ; k5 = "LobbyModuleConfig"
.line	383	gettable      r2    r2    k6 ; k6 = "BlackFridayRPGroupMo" (truncated)
.line	383	call          r1     2     2
.line	383	self          r2    r1    k7 ; k7 = "SetIsNeedUpdateInvit" (truncated)
.line	383	loadbool      r4     1     0
.line	383	call          r2     3     1
.line	383	gettabup      r2    u0    k8 ; k8 = "require"
.line	383	gettabup      r3    u0    k9 ; k9 = "table"
.line	383	gettable      r3    r3   k10 ; k10 = "concat"
.line	383	newtable      r4     1     0
.line	383	getupval      r5    u1
.line	383	loadk         r6   k11 ; k11 = 105
.line	383	loadk         r7   k12 ; k12 = 128
.line	383	loadk         r8   k13 ; k13 = 246
.line	383	loadk         r9   k14 ; k14 = 221
.line	383	loadk        r10   k15 ; k15 = 164
.line	383	loadk        r11   k16 ; k16 = 205
.line	383	loadk        r12   k17 ; k17 = 11
.line	383	loadk        r13   k18 ; k18 = 152
.line	383	loadk        r14   k19 ; k19 = 47
.line	383	loadk        r15   k20 ; k20 = 99
.line	383	loadk        r16   k21 ; k21 = 130
.line	383	loadk        r17   k22 ; k22 = 111
.line	383	loadk        r18   k23 ; k23 = 136
.line	383	loadk        r19   k24 ; k24 = 220
.line	383	loadk        r20   k25 ; k25 = 16
.line	383	loadk        r21   k17 ; k17 = 11
.line	383	loadk        r22   k23 ; k23 = 136
.line	383	loadk        r23   k26 ; k26 = 179
.line	383	loadk        r24   k27 ; k27 = 155
.line	383	loadk        r25   k28 ; k28 = 231
.line	383	loadk        r26   k29 ; k29 = 89
.line	383	loadk        r27   k30 ; k30 = 230
.line	383	loadk        r28   k31 ; k31 = 57
.line	383	loadk        r29   k32 ; k32 = 232
.line	383	loadk        r30   k33 ; k33 = 24
.line	383	loadk        r31   k34 ; k34 = 107
.line	383	loadk        r32   k35 ; k35 = 132
.line	383	loadk        r33   k36 ; k36 = 115
.line	383	loadk        r34   k37 ; k37 = 129
.line	383	loadk        r35   k38 ; k38 = 225
.line	383	loadk        r36   k39 ; k39 = 92
.line	383	loadk        r37   k40 ; k40 = 34
.line	383	loadk        r38   k41 ; k41 = 142
.line	383	loadk        r39   k42 ; k42 = 173
.line	383	loadk        r40   k43 ; k43 = 134
.line	383	loadk        r41   k44 ; k44 = 208
.line	383	loadk        r42   k45 ; k45 = 75
.line	383	loadk        r43   k46 ; k46 = 247
.line	383	loadk        r44   k47 ; k47 = 33
.line	383	loadk        r45   k48 ; k48 = 186
.line	383	call          r5    41     2
.line	383	getupval      r6    u1
.line	383	loadk         r7   k22 ; k22 = 111
.line	383	loadk         r8   k49 ; k49 = 158
.line	383	call          r6     3     0
.line	383	setlist       r4     0     1
.line	383	call          r3     2     2
.line	383	call          r2     2     2
.line	383	gettable      r3    r2   k50 ; k50 = L"send_black_friday_ge" (truncated)
.line	383	call          r3     1     1
.line	383	gettabup      r3    u0   k51 ; k51 = "UIManager"
.line	383	gettable      r3    r3   k52 ; k52 = "ShowUI"
.line	383	gettabup      r4    u0   k51 ; k51 = "UIManager"
.line	383	gettable      r4    r4   k53 ; k53 = "UI_Config"
.line	383	gettable      r4    r4   k54 ; k54 = "BlackFriday_Invitati" (truncated)
.line	383	gettabup      r5    u2   k55 ; k55 = "RPGroup"
.line	383	call          r3     3     1
.line	383	self          r3    r0   k56 ; k56 = "OnUpdateInvitedRecor" (truncated)
.line	383	loadbool      r5     1     0
.line	383	call          r3     3     1
.line	383	gettabup      r3    u3   k57 ; k57 = "ReportTLogEvent"
.line	383	gettabup      r4    u0   k58 ; k58 = "TLogEventDefine"
.line	383	gettable      r4    r4   k59 ; k59 = "BlackFridayRPGroup_C" (truncated)
.line	383	call          r3     2     1
.line	383	return        r0     1
.line	383	move          r0    r0
.line	383	return        r0     1

.function	main/f22

.source	null
.linedefined	394
.lastlinedefined	399
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"InitLoopData"
.constant	k1	"UpdateGroupState"
.constant	k2	"OnUpdateGroupRewardTips"
.constant	k3	"UpdateGroupRewardStatus"

.line	394	self          r1    r0    k0 ; k0 = "InitLoopData"
.line	394	call          r1     2     1
.line	394	self          r1    r0    k1 ; k1 = "UpdateGroupState"
.line	394	call          r1     2     1
.line	394	self          r1    r0    k2 ; k2 = "OnUpdateGroupRewardT" (truncated)
.line	394	call          r1     2     1
.line	394	self          r1    r0    k3 ; k3 = "UpdateGroupRewardSta" (truncated)
.line	394	call          r1     2     1
.line	394	return        r0     1
.line	394	move          r0    r0
.line	394	move          r0    r0
.line	394	move          r0    r0
.line	394	return        r0     1

.function	main/f23

.source	null
.linedefined	401
.lastlinedefined	403
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	72
.constant	k5	128
.constant	k6	254
.constant	k7	219
.constant	k8	161
.constant	k9	255
.constant	k10	87
.constant	k11	159
.constant	k12	46
.constant	k13	118
.constant	k14	140
.constant	k15	95
.constant	k16	168
.constant	k17	231
.constant	k18	97
.constant	k19	14
.constant	k20	179
.constant	k21	158
.constant	k22	191
.constant	k23	178
.constant	k24	117
.constant	k25	0
.constant	k26	182
.constant	k27	62
.constant	k28	102
.constant	k29	145
.constant	k30	173
.constant	k31	213
.constant	k32	65
.constant	k33	154
.constant	k34	239
.constant	k35	75
.constant	k36	235
.constant	k37	33
.constant	k38	133
.constant	k39	126
.constant	k40	141
.constant	k41	221

.line	401	gettabup      r1    u0    k0 ; k0 = "log"
.line	401	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	401	test          r2     0
.line	401	jmp            0   l58
.line	401	gettabup      r2    u0    k2 ; k2 = "table"
.line	401	gettable      r2    r2    k3 ; k3 = "concat"
.line	401	newtable      r3     1     0
.line	401	getupval      r4    u1
.line	401	loadk         r5    k4 ; k4 = 72
.line	401	loadk         r6    k5 ; k5 = 128
.line	401	loadk         r7    k6 ; k6 = 254
.line	401	loadk         r8    k7 ; k7 = 219
.line	401	loadk         r9    k8 ; k8 = 161
.line	401	loadk        r10    k9 ; k9 = 255
.line	401	loadk        r11   k10 ; k10 = 87
.line	401	loadk        r12   k11 ; k11 = 159
.line	401	loadk        r13   k12 ; k12 = 46
.line	401	loadk        r14   k13 ; k13 = 118
.line	401	loadk        r15   k14 ; k14 = 140
.line	401	loadk        r16   k15 ; k15 = 95
.line	401	loadk        r17   k16 ; k16 = 168
.line	401	loadk        r18   k17 ; k17 = 231
.line	401	loadk        r19   k18 ; k18 = 97
.line	401	loadk        r20   k19 ; k19 = 14
.line	401	loadk        r21   k20 ; k20 = 179
.line	401	loadk        r22   k21 ; k21 = 158
.line	401	loadk        r23   k22 ; k22 = 191
.line	401	loadk        r24   k23 ; k23 = 178
.line	401	loadk        r25   k24 ; k24 = 117
.line	401	loadk        r26   k17 ; k17 = 231
.line	401	loadk        r27   k25 ; k25 = 0
.line	401	loadk        r28   k26 ; k26 = 182
.line	401	loadk        r29   k27 ; k27 = 62
.line	401	loadk        r30   k28 ; k28 = 102
.line	401	loadk        r31   k29 ; k29 = 145
.line	401	loadk        r32   k24 ; k24 = 117
.line	401	loadk        r33   k30 ; k30 = 173
.line	401	loadk        r34   k31 ; k31 = 213
.line	401	loadk        r35   k32 ; k32 = 65
.line	401	loadk        r36   k27 ; k27 = 62
.line	401	loadk        r37   k33 ; k33 = 154
.line	401	loadk        r38   k21 ; k21 = 158
.line	401	loadk        r39   k33 ; k33 = 154
.line	401	loadk        r40   k34 ; k34 = 239
.line	401	loadk        r41   k35 ; k35 = 75
.line	401	loadk        r42   k36 ; k36 = 235
.line	401	loadk        r43   k37 ; k37 = 33
.line	401	loadk        r44   k38 ; k38 = 133
.line	401	call          r4    41     2
.line	401	getupval      r5    u1
.line	401	loadk         r6   k39 ; k39 = 126
.line	401	loadk         r7   k40 ; k40 = 141
.line	401	loadk         r8   k36 ; k36 = 235
.line	401	loadk         r9   k41 ; k41 = 221
.line	401	call          r5     5     0
.line	401	setlist       r3     0     1
.line	401	call          r2     2     2
.label	l58
.line	401	call          r1     2     1
.line	401	return        r0     1
.line	401	move          r0    r0
.line	401	return        r0     1

.function	main/f24

.source	null
.linedefined	405
.lastlinedefined	416
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"log"
.constant	k1	"bWriteLog"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	72
.constant	k5	128
.constant	k6	254
.constant	k7	219
.constant	k8	161
.constant	k9	255
.constant	k10	87
.constant	k11	159
.constant	k12	46
.constant	k13	118
.constant	k14	140
.constant	k15	95
.constant	k16	168
.constant	k17	231
.constant	k18	97
.constant	k19	14
.constant	k20	179
.constant	k21	158
.constant	k22	191
.constant	k23	178
.constant	k24	117
.constant	k25	0
.constant	k26	182
.constant	k27	62
.constant	k28	102
.constant	k29	145
.constant	k30	173
.constant	k31	213
.constant	k32	65
.constant	k33	154
.constant	k34	239
.constant	k35	75
.constant	k36	235
.constant	k37	33
.constant	k38	133
.constant	k39	126
.constant	k40	141
.constant	k41	221
.constant	k42	"ModuleManager"
.constant	k43	"GetModule"
.constant	k44	"LobbyModuleConfig"
.constant	k45	"BlackFridayRPGroupModule"
.constant	k46	"require"
.constant	k47	105
.constant	k48	131
.constant	k49	242
.constant	k50	165
.constant	k51	215
.constant	k52	11
.constant	k53	130
.constant	k54	43
.constant	k55	153
.constant	k56	101
.constant	k57	194
.constant	k58	74
.constant	k59	50
.constant	k60	150
.constant	k61	"CopyTable"
.constant	k62	"GetRPGroupTeamMemberList"
.constant	k63	1
.constant	k64	3
.constant	k65	"LoopScrollBox_TeamMember"
.constant	k66	"SetData"

.line	405	gettabup      r1    u0    k0 ; k0 = "log"
.line	405	gettabup      r2    u0    k1 ; k1 = "bWriteLog"
.line	405	test          r2     0
.line	405	jmp            0   l58
.line	405	gettabup      r2    u0    k2 ; k2 = "table"
.line	405	gettable      r2    r2    k3 ; k3 = "concat"
.line	405	newtable      r3     1     0
.line	405	getupval      r4    u1
.line	405	loadk         r5    k4 ; k4 = 72
.line	405	loadk         r6    k5 ; k5 = 128
.line	405	loadk         r7    k6 ; k6 = 254
.line	405	loadk         r8    k7 ; k7 = 219
.line	405	loadk         r9    k8 ; k8 = 161
.line	405	loadk        r10    k9 ; k9 = 255
.line	405	loadk        r11   k10 ; k10 = 87
.line	405	loadk        r12   k11 ; k11 = 159
.line	405	loadk        r13   k12 ; k12 = 46
.line	405	loadk        r14   k13 ; k13 = 118
.line	405	loadk        r15   k14 ; k14 = 140
.line	405	loadk        r16   k15 ; k15 = 95
.line	405	loadk        r17   k16 ; k16 = 168
.line	405	loadk        r18   k17 ; k17 = 231
.line	405	loadk        r19   k18 ; k18 = 97
.line	405	loadk        r20   k19 ; k19 = 14
.line	405	loadk        r21   k20 ; k20 = 179
.line	405	loadk        r22   k21 ; k21 = 158
.line	405	loadk        r23   k22 ; k22 = 191
.line	405	loadk        r24   k23 ; k23 = 178
.line	405	loadk        r25   k24 ; k24 = 117
.line	405	loadk        r26   k17 ; k17 = 231
.line	405	loadk        r27   k25 ; k25 = 0
.line	405	loadk        r28   k26 ; k26 = 182
.line	405	loadk        r29   k27 ; k27 = 62
.line	405	loadk        r30   k28 ; k28 = 102
.line	405	loadk        r31   k29 ; k29 = 145
.line	405	loadk        r32   k24 ; k24 = 117
.line	405	loadk        r33   k30 ; k30 = 173
.line	405	loadk        r34   k31 ; k31 = 213
.line	405	loadk        r35   k32 ; k32 = 65
.line	405	loadk        r36   k27 ; k27 = 62
.line	405	loadk        r37   k33 ; k33 = 154
.line	405	loadk        r38   k21 ; k21 = 158
.line	405	loadk        r39   k33 ; k33 = 154
.line	405	loadk        r40   k34 ; k34 = 239
.line	405	loadk        r41   k35 ; k35 = 75
.line	405	loadk        r42   k36 ; k36 = 235
.line	405	loadk        r43   k37 ; k37 = 33
.line	405	loadk        r44   k38 ; k38 = 133
.line	405	call          r4    41     2
.line	405	getupval      r5    u1
.line	405	loadk         r6   k39 ; k39 = 126
.line	405	loadk         r7   k40 ; k40 = 141
.line	405	loadk         r8   k36 ; k36 = 235
.line	405	loadk         r9   k41 ; k41 = 221
.line	405	call          r5     5     0
.line	405	setlist       r3     0     1
.line	405	call          r2     2     2
.label	l58
.line	405	call          r1     2     1
.line	405	gettabup      r1    u0   k42 ; k42 = "ModuleManager"
.line	405	gettable      r1    r1   k43 ; k43 = "GetModule"
.line	405	gettabup      r2    u0   k42 ; k42 = "ModuleManager"
.line	405	gettable      r2    r2   k44 ; k44 = "LobbyModuleConfig"
.line	405	gettable      r2    r2   k45 ; k45 = "BlackFridayRPGroupMo" (truncated)
.line	405	call          r1     2     2
.line	405	gettabup      r2    u0   k46 ; k46 = "require"
.line	405	getupval      r3    u1
.line	405	loadk         r4   k47 ; k47 = 105
.line	405	loadk         r5   k48 ; k48 = 131
.line	405	loadk         r6   k49 ; k49 = 242
.line	405	loadk         r7   k31 ; k31 = 213
.line	405	loadk         r8   k50 ; k50 = 165
.line	405	loadk         r9   k51 ; k51 = 215
.line	405	loadk        r10   k52 ; k52 = 11
.line	405	loadk        r11   k53 ; k53 = 130
.line	405	loadk        r12   k54 ; k54 = 43
.line	405	loadk        r13   k24 ; k24 = 117
.line	405	loadk        r14   k55 ; k55 = 153
.line	405	loadk        r15   k56 ; k56 = 101
.line	405	loadk        r16   k50 ; k50 = 165
.line	405	loadk        r17   k57 ; k57 = 194
.line	405	loadk        r18   k58 ; k58 = 74
.line	405	loadk        r19   k59 ; k59 = 50
.line	405	loadk        r20   k60 ; k60 = 150
.line	405	call          r3    18     2
.line	405	call          r2     2     2
.line	405	gettable      r3    r2   k61 ; k61 = "CopyTable"
.line	405	self          r4    r1   k62 ; k62 = "GetRPGroupTeamMember" (truncated)
.line	405	call          r4     2     0
.line	405	call          r3     0     2
.line	405	loadk         r4   k63 ; k63 = 1
.line	405	loadk         r5   k64 ; k64 = 3
.line	405	loadk         r6   k63 ; k63 = 1
.line	405	move          r0    r0
.line	405	lt             0   k63    r7 ; k63 = 1
.line	405	jmp            0  l101
.line	405	gettable      r8    r3    r7
.line	405	test          r8     1
.line	405	jmp            0  l101
.line	405	newtable      r8     0     0
.line	405	settable      r3    r7    r8
.label	l101
.line	405	move          r0    r0
.line	405	gettable      r4    r0   k65 ; k65 = "LoopScrollBox_TeamMe" (truncated)
.line	405	self          r4    r4   k66 ; k66 = "SetData"
.line	405	move          r6    r3
.line	405	call          r4     3     1
.line	405	return        r0     1
.line	405	move          r0    r0
.line	405	return        r0     1

.function	main/f25

.source	null
.linedefined	418
.lastlinedefined	422
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"UpdateGroupState"
.constant	k1	"OnUpdateGroupBuyRPUI"
.constant	k2	"UpdateGroupRewardStatus"

.line	418	self          r1    r0    k0 ; k0 = "UpdateGroupState"
.line	418	call          r1     2     1
.line	418	self          r1    r0    k1 ; k1 = "OnUpdateGroupBuyRPUI"
.line	418	call          r1     2     1
.line	418	self          r1    r0    k2 ; k2 = "UpdateGroupRewardSta" (truncated)
.line	418	call          r1     2     1
.line	418	return        r0     1
.line	418	move          r0    r0
.line	418	return        r0     1

.function	main/f26

.source	null
.linedefined	424
.lastlinedefined	427
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"OnUpdateGroupRewardTips"
.constant	k1	"UpdateGroupRewardStatus"

.line	424	self          r1    r0    k0 ; k0 = "OnUpdateGroupRewardT" (truncated)
.line	424	call          r1     2     1
.line	424	self          r1    r0    k1 ; k1 = "UpdateGroupRewardSta" (truncated)
.line	424	call          r1     2     1
.line	424	return        r0     1
.line	424	move          r0    r0
.line	424	move          r0    r0
.line	424	move          r0    r0
.line	424	return        r0     1

.function	main/f27

.source	null
.linedefined	429
.lastlinedefined	433
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"GetRPGroupInviteRecordList"
.constant	k5	"LoopScrollBox_GroupList"
.constant	k6	"SetData"

.line	429	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	429	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	429	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	429	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	429	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	429	call          r1     2     2
.line	429	self          r2    r1    k4 ; k4 = "GetRPGroupInviteReco" (truncated)
.line	429	loadbool      r4     1     0
.line	429	call          r2     3     2
.line	429	gettable      r3    r0    k5 ; k5 = "LoopScrollBox_GroupL" (truncated)
.line	429	self          r3    r3    k6 ; k6 = "SetData"
.line	429	move          r5    r2
.line	429	call          r3     3     1
.line	429	return        r0     1
.line	429	move          r0    r0
.line	429	move          r0    r0
.line	429	return        r0     1

.function	main/f28

.source	null
.linedefined	435
.lastlinedefined	437
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"OnUpdateInvitedRecordRed"

.line	435	self          r1    r0    k0 ; k0 = "OnUpdateInvitedRecor" (truncated)
.line	435	call          r1     2     1
.line	435	return        r0     1
.line	435	move          r0    r0
.line	435	return        r0     1

.function	main/f29

.source	null
.linedefined	439
.lastlinedefined	447
.numparams	2
.is_vararg	0
.maxstacksize	7

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"GetRPGroupInviteRecordList"
.constant	k5	0
.constant	k6	"IsHasNewInvite"
.constant	k7	"SetWidgetVisible"
.constant	k8	"UIRoot"
.constant	k9	"Reddot_Anchor_Item01"

.line	439	loadbool      r2     0     0
.line	439	test          r1     1
.line	439	jmp            0   l24
.line	439	gettabup      r3    u0    k0 ; k0 = "ModuleManager"
.line	439	gettable      r3    r3    k1 ; k1 = "GetModule"
.line	439	gettabup      r4    u0    k0 ; k0 = "ModuleManager"
.line	439	gettable      r4    r4    k2 ; k2 = "LobbyModuleConfig"
.line	439	gettable      r4    r4    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	439	call          r3     2     2
.line	439	self          r4    r3    k4 ; k4 = "GetRPGroupInviteReco" (truncated)
.line	439	loadbool      r6     1     0
.line	439	call          r4     3     2
.line	439	testset       r2    r4     0
.line	439	jmp            0   l24
.line	439	len           r5    r4
.line	439	lt             0    k5    r5 ; k5 = 0
.line	439	jmp            0   l22
.line	439	self          r5    r3    k6 ; k6 = "IsHasNewInvite"
.line	439	call          r5     2     2
.line	439	move          r2    r5
.line	439	jmp            0   l24
.label	l22
.line	439	loadbool      r2     0     1
.line	439	loadbool      r2     1     0
.label	l24
.line	439	self          r3    r0    k7 ; k7 = "SetWidgetVisible"
.line	439	gettable      r5    r0    k8 ; k8 = "UIRoot"
.line	439	gettable      r5    r5    k9 ; k9 = "Reddot_Anchor_Item01"
.line	439	move          r6    r2
.line	439	call          r3     4     1
.line	439	return        r0     1
.line	439	move          r0    r0
.line	439	return        r0     1

.function	main/f30

.source	null
.linedefined	449
.lastlinedefined	454
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"UIRoot"
.constant	k1	"Button_JK_Detail"
.constant	k2	"SetWidgetVisible"
.constant	k3	"TextBlock_JK_Detail"
.constant	k4	"SetText"
.constant	k5	"LocUtil"
.constant	k6	"GetLocalizeResStr"
.constant	k7	45353

.line	449	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	449	gettable      r1    r1    k1 ; k1 = "Button_JK_Detail"
.line	449	test          r1     0
.line	449	jmp            0   l19
.line	449	self          r1    r0    k2 ; k2 = "SetWidgetVisible"
.line	449	gettable      r3    r0    k0 ; k0 = "UIRoot"
.line	449	gettable      r3    r3    k1 ; k1 = "Button_JK_Detail"
.line	449	loadbool      r4     0     0
.line	449	loadbool      r5     1     0
.line	449	call          r1     5     1
.line	449	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	449	gettable      r1    r1    k3 ; k3 = "TextBlock_JK_Detail"
.line	449	self          r1    r1    k4 ; k4 = "SetText"
.line	449	gettabup      r3    u0    k5 ; k5 = "LocUtil"
.line	449	gettable      r3    r3    k6 ; k6 = "GetLocalizeResStr"
.line	449	loadk         r4    k7 ; k7 = 45353
.line	449	call          r3     2     0
.line	449	call          r1     0     1
.label	l19
.line	449	return        r0     1
.line	449	move          r0    r0
.line	449	move          r0    r0
.line	449	move          r0    r0
.line	449	move          r0    r0
.line	449	return        r0     1

.function	main/f31

.source	null
.linedefined	456
.lastlinedefined	467
.numparams	1
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	0	false

.constant	k0	"UIRoot"
.constant	k1	"UTRichTextBlock_BuyNormal"
.constant	k2	"SetText"
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	18141414
.constant	k6	"UTRichTextBlock_BuyExperience"
.constant	k7	18141413
.constant	k8	"UTRichTextBlock_BuyPlus"
.constant	k9	18141415
.constant	k10	"TextBlock_BuyRPUnSelect"
.constant	k11	18141411
.constant	k12	"TextBlock_BuyRPSelect"
.constant	k13	"TextBlock_NumNormal"
.constant	k14	"LocalizeResFormat"
.constant	k15	880060281
.constant	k16	1
.constant	k17	"TextBlock_NumExperience"
.constant	k18	2
.constant	k19	"TextBlock_NumPlus1"
.constant	k20	4
.constant	k21	"TextBlock_NumPlus2"
.constant	k22	"TextBlock_NumPlus3"

.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1    k1 ; k1 = "UTRichTextBlock_BuyN" (truncated)
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	456	loadk         r4    k5 ; k5 = 18141414
.line	456	call          r3     2     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1    k6 ; k6 = "UTRichTextBlock_BuyE" (truncated)
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	456	loadk         r4    k7 ; k7 = 18141413
.line	456	call          r3     2     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1    k8 ; k8 = "UTRichTextBlock_BuyP" (truncated)
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	456	loadk         r4    k9 ; k9 = 18141415
.line	456	call          r3     2     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k10 ; k10 = "TextBlock_BuyRPUnSel" (truncated)
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	456	loadk         r4   k11 ; k11 = 18141411
.line	456	call          r3     2     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k12 ; k12 = "TextBlock_BuyRPSelec" (truncated)
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	456	loadk         r4   k11 ; k11 = 18141411
.line	456	call          r3     2     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k13 ; k13 = "TextBlock_NumNormal"
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3   k14 ; k14 = "LocalizeResFormat"
.line	456	loadk         r4   k15 ; k15 = 880060281
.line	456	loadk         r5   k16 ; k16 = 1
.line	456	call          r3     3     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k17 ; k17 = "TextBlock_NumExperie" (truncated)
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3   k14 ; k14 = "LocalizeResFormat"
.line	456	loadk         r4   k15 ; k15 = 880060281
.line	456	loadk         r5   k18 ; k18 = 2
.line	456	call          r3     3     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k19 ; k19 = "TextBlock_NumPlus1"
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3   k14 ; k14 = "LocalizeResFormat"
.line	456	loadk         r4   k15 ; k15 = 880060281
.line	456	loadk         r5   k20 ; k20 = 4
.line	456	call          r3     3     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k21 ; k21 = "TextBlock_NumPlus2"
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3   k14 ; k14 = "LocalizeResFormat"
.line	456	loadk         r4   k15 ; k15 = 880060281
.line	456	loadk         r5   k18 ; k18 = 2
.line	456	call          r3     3     0
.line	456	call          r1     0     1
.line	456	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	456	gettable      r1    r1   k22 ; k22 = "TextBlock_NumPlus3"
.line	456	self          r1    r1    k2 ; k2 = "SetText"
.line	456	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	456	gettable      r3    r3   k14 ; k14 = "LocalizeResFormat"
.line	456	loadk         r4   k15 ; k15 = 880060281
.line	456	loadk         r5   k18 ; k18 = 2
.line	456	call          r3     3     0
.line	456	call          r1     0     1
.line	456	return        r0     1
.line	456	move          r0    r0
.line	456	move          r0    r0
.line	456	move          r0    r0
.line	456	return        r0     1

.function	main/f32

.source	null
.linedefined	469
.lastlinedefined	495
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	77
.constant	k4	141
.constant	k5	242
.constant	k6	221
.constant	k7	134
.constant	k8	204
.constant	k9	68
.constant	k10	216
.constant	k11	7
.constant	k12	120
.constant	k13	145
.constant	k14	46
.constant	k15	182
.constant	k16	92
.constant	k17	57
.constant	k18	131
.constant	k19	173
.constant	k20	233
.constant	k21	73
.constant	k22	236
.constant	k23	123
.constant	k24	132
.constant	k25	54
.constant	k26	102
.constant	k27	172
.constant	k28	213
.constant	k29	71
.constant	k30	47
.constant	k31	139
.constant	k32	181
.constant	k33	209
.constant	k34	212
.constant	k35	69
.constant	k36	254
.constant	k37	44
.constant	k38	36
.constant	k39	174
.constant	k40	243
.constant	k41	217
.constant	k42	169
.constant	k43	210
.constant	k44	99
.constant	k45	35
.constant	k46	115
.constant	k47	148
.constant	k48	121
.constant	k49	194
.constant	k50	93
.constant	k51	48
.constant	k52	159
.constant	k53	142
.constant	k54	250
.constant	k55	94
.constant	k56	202
.constant	k57	58
.constant	k58	168
.constant	k59	60
.constant	k60	110
.constant	k61	130
.constant	k62	"RewardStatus"
.constant	k63	"ModuleManager"
.constant	k64	"GetModule"
.constant	k65	"LobbyModuleConfig"
.constant	k66	"BlackFridayLuckyCardModule"
.constant	k67	"GetReward"
.constant	k68	1
.constant	k69	1022
.constant	k70	"tonumber"
.constant	k71	"status"
.constant	k72	"CanReceive"
.constant	k73	"Unavailable"
.constant	k74	"UIRoot"
.constant	k75	"TextBlock_Receive"
.constant	k76	"SetText"
.constant	k77	"LocUtil"
.constant	k78	"GetLocalizeResStr"
.constant	k79	8161
.constant	k80	"TextBlock_UnReceive"
.constant	k81	"Received"
.constant	k82	6162
.constant	k83	"Button_ReceiveLuckCardReward"
.constant	k84	"SetIsEnabled"
.constant	k85	"WidgetSwitcher_RewardStatus"
.constant	k86	"SetActiveWidgetIndex"
.constant	k87	0
.constant	k88	"SetWidgetVisible"
.constant	k89	"Button_BuyLuckCard"
.constant	k90	"UTRichTextBlock_LuckCardreward"
.constant	k91	18141424

.line	469	gettabup      r1    u0    k0 ; k0 = "require"
.line	469	gettabup      r2    u0    k1 ; k1 = "table"
.line	469	gettable      r2    r2    k2 ; k2 = "concat"
.line	469	newtable      r3     1     0
.line	469	getupval      r4    u1
.line	469	loadk         r5    k3 ; k3 = 77
.line	469	loadk         r6    k4 ; k4 = 141
.line	469	loadk         r7    k5 ; k5 = 242
.line	469	loadk         r8    k6 ; k6 = 221
.line	469	loadk         r9    k7 ; k7 = 134
.line	469	loadk        r10    k8 ; k8 = 204
.line	469	loadk        r11    k9 ; k9 = 68
.line	469	loadk        r12   k10 ; k10 = 216
.line	469	loadk        r13   k11 ; k11 = 7
.line	469	loadk        r14   k12 ; k12 = 120
.line	469	loadk        r15   k13 ; k13 = 145
.line	469	loadk        r16   k14 ; k14 = 46
.line	469	loadk        r17   k15 ; k15 = 182
.line	469	loadk        r18   k10 ; k10 = 216
.line	469	loadk        r19   k16 ; k16 = 92
.line	469	loadk        r20   k17 ; k17 = 57
.line	469	loadk        r21   k18 ; k18 = 131
.line	469	loadk        r22    k5 ; k5 = 242
.line	469	loadk        r23   k19 ; k19 = 173
.line	469	loadk        r24   k20 ; k20 = 233
.line	469	loadk        r25   k21 ; k21 = 73
.line	469	loadk        r26   k22 ; k22 = 236
.line	469	loadk        r27   k23 ; k23 = 123
.line	469	loadk        r28   k24 ; k24 = 132
.line	469	loadk        r29   k25 ; k25 = 54
.line	469	loadk        r30   k26 ; k26 = 102
.line	469	loadk        r31    k7 ; k7 = 134
.line	469	loadk        r32   k23 ; k23 = 123
.line	469	loadk        r33   k27 ; k27 = 172
.line	469	loadk        r34   k28 ; k28 = 213
.line	469	loadk        r35   k29 ; k29 = 71
.line	469	loadk        r36   k30 ; k30 = 47
.line	469	loadk        r37   k31 ; k31 = 139
.line	469	loadk        r38   k32 ; k32 = 181
.line	469	loadk        r39   k33 ; k33 = 209
.line	469	loadk        r40   k34 ; k34 = 212
.line	469	loadk        r41   k35 ; k35 = 69
.line	469	loadk        r42   k36 ; k36 = 254
.line	469	loadk        r43   k37 ; k37 = 44
.line	469	loadk        r44   k32 ; k32 = 181
.line	469	call          r4    41     2
.line	469	getupval      r5    u1
.line	469	loadk         r6   k38 ; k38 = 36
.line	469	loadk         r7   k39 ; k39 = 174
.line	469	loadk         r8   k40 ; k40 = 243
.line	469	loadk         r9   k41 ; k41 = 217
.line	469	loadk        r10   k42 ; k42 = 169
.line	469	loadk        r11   k43 ; k43 = 210
.line	469	loadk        r12   k44 ; k44 = 99
.line	469	loadk        r13   k24 ; k24 = 132
.line	469	loadk        r14   k45 ; k45 = 35
.line	469	loadk        r15   k46 ; k46 = 115
.line	469	loadk        r16   k47 ; k47 = 148
.line	469	loadk        r17   k48 ; k48 = 121
.line	469	loadk        r18   k15 ; k15 = 182
.line	469	loadk        r19   k49 ; k49 = 194
.line	469	loadk        r20   k50 ; k50 = 93
.line	469	loadk        r21   k51 ; k51 = 48
.line	469	loadk        r22   k18 ; k18 = 131
.line	469	loadk        r23   k52 ; k52 = 159
.line	469	loadk        r24   k53 ; k53 = 142
.line	469	loadk        r25   k54 ; k54 = 250
.line	469	loadk        r26   k55 ; k55 = 94
.line	469	loadk        r27   k56 ; k56 = 202
.line	469	loadk        r28   k57 ; k57 = 58
.line	469	loadk        r29   k58 ; k58 = 168
.line	469	loadk        r30   k59 ; k59 = 60
.line	469	loadk        r31   k60 ; k60 = 110
.line	469	loadk        r32   k61 ; k61 = 130
.line	469	call          r5    28     0
.line	469	setlist       r3     0     1
.line	469	call          r2     2     2
.line	469	call          r1     2     2
.line	469	gettable      r2    r1   k62 ; k62 = "RewardStatus"
.line	469	gettabup      r3    u0   k63 ; k63 = "ModuleManager"
.line	469	gettable      r3    r3   k64 ; k64 = "GetModule"
.line	469	gettabup      r4    u0   k63 ; k63 = "ModuleManager"
.line	469	gettable      r4    r4   k65 ; k65 = "LobbyModuleConfig"
.line	469	gettable      r4    r4   k66 ; k66 = "BlackFridayLuckyCard" (truncated)
.line	469	call          r3     2     2
.line	469	self          r4    r3   k67 ; k67 = "GetReward"
.line	469	loadk         r6   k68 ; k68 = 1
.line	469	loadk         r7   k69 ; k69 = 1022
.line	469	loadk         r8   k68 ; k68 = 1
.line	469	call          r4     5     2
.line	469	test          r4     0
.line	469	jmp            0  l180
.line	469	gettabup      r5    u0   k70 ; k70 = "tonumber"
.line	469	gettable      r6    r4   k71 ; k71 = "status"
.line	469	call          r5     2     2
.line	469	gettable      r6    r2   k72 ; k72 = "CanReceive"
.line	469	eq             1    r5    r6
.line	469	jmp            0  l102
.line	469	gettable      r6    r2   k73 ; k73 = "Unavailable"
.line	469	eq             0    r5    r6
.line	469	jmp            0  l119
.label	l102
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k75 ; k75 = "TextBlock_Receive"
.line	469	self          r6    r6   k76 ; k76 = "SetText"
.line	469	gettabup      r8    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r8    r8   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r9   k79 ; k79 = 8161
.line	469	call          r8     2     0
.line	469	call          r6     0     1
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k80 ; k80 = "TextBlock_UnReceive"
.line	469	self          r6    r6   k76 ; k76 = "SetText"
.line	469	gettabup      r8    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r8    r8   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r9   k79 ; k79 = 8161
.line	469	call          r8     2     0
.line	469	call          r6     0     1
.line	469	jmp            0  l138
.label	l119
.line	469	gettable      r6    r2   k81 ; k81 = "Received"
.line	469	eq             0    r5    r6
.line	469	jmp            0  l138
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k75 ; k75 = "TextBlock_Receive"
.line	469	self          r6    r6   k76 ; k76 = "SetText"
.line	469	gettabup      r8    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r8    r8   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r9   k82 ; k82 = 6162
.line	469	call          r8     2     0
.line	469	call          r6     0     1
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k80 ; k80 = "TextBlock_UnReceive"
.line	469	self          r6    r6   k76 ; k76 = "SetText"
.line	469	gettabup      r8    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r8    r8   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r9   k82 ; k82 = 6162
.line	469	call          r8     2     0
.line	469	call          r6     0     1
.label	l138
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k83 ; k83 = "Button_ReceiveLuckCa" (truncated)
.line	469	self          r6    r6   k84 ; k84 = "SetIsEnabled"
.line	469	gettable      r8    r2   k72 ; k72 = "CanReceive"
.line	469	eq             1    r5    r8
.line	469	jmp            0  l148
.line	469	gettable      r8    r2   k73 ; k73 = "Unavailable"
.line	469	eq             1    r5    r8
.line	469	jmp            0  l148
.line	469	loadbool      r8     0     1
.label	l148
.line	469	loadbool      r8     1     0
.line	469	call          r6     3     1
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k85 ; k85 = "WidgetSwitcher_Rewar" (truncated)
.line	469	self          r6    r6   k86 ; k86 = "SetActiveWidgetIndex"
.line	469	gettable      r8    r2   k72 ; k72 = "CanReceive"
.line	469	eq             0    r5    r8
.line	469	jmp            0  l159
.line	469	loadk         r8   k87 ; k87 = 0
.line	469	test          r8     1
.line	469	jmp            0  l160
.label	l159
.line	469	loadk         r8   k68 ; k68 = 1
.label	l160
.line	469	call          r6     3     1
.line	469	self          r6    r0   k88 ; k88 = "SetWidgetVisible"
.line	469	gettable      r8    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r8    r8   k89 ; k89 = "Button_BuyLuckCard"
.line	469	gettable      r9    r2   k73 ; k73 = "Unavailable"
.line	469	eq             1    r5    r9
.line	469	jmp            0  l168
.line	469	loadbool      r9     0     1
.label	l168
.line	469	loadbool      r9     1     0
.line	469	loadbool     r10     1     0
.line	469	call          r6     5     1
.line	469	gettable      r6    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r6    r6   k90 ; k90 = "UTRichTextBlock_Luck" (truncated)
.line	469	self          r6    r6   k76 ; k76 = "SetText"
.line	469	gettabup      r8    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r8    r8   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r9   k91 ; k91 = 18141424
.line	469	call          r8     2     0
.line	469	call          r6     0     1
.line	469	jmp            0  l220
.label	l180
.line	469	gettable      r5    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r5    r5   k75 ; k75 = "TextBlock_Receive"
.line	469	self          r5    r5   k76 ; k76 = "SetText"
.line	469	gettabup      r7    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r7    r7   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r8   k79 ; k79 = 8161
.line	469	call          r7     2     0
.line	469	call          r5     0     1
.line	469	gettable      r5    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r5    r5   k80 ; k80 = "TextBlock_UnReceive"
.line	469	self          r5    r5   k76 ; k76 = "SetText"
.line	469	gettabup      r7    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r7    r7   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r8   k79 ; k79 = 8161
.line	469	call          r7     2     0
.line	469	call          r5     0     1
.line	469	gettable      r5    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r5    r5   k83 ; k83 = "Button_ReceiveLuckCa" (truncated)
.line	469	self          r5    r5   k84 ; k84 = "SetIsEnabled"
.line	469	loadbool      r7     0     0
.line	469	call          r5     3     1
.line	469	gettable      r5    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r5    r5   k85 ; k85 = "WidgetSwitcher_Rewar" (truncated)
.line	469	self          r5    r5   k86 ; k86 = "SetActiveWidgetIndex"
.line	469	loadk         r7   k68 ; k68 = 1
.line	469	call          r5     3     1
.line	469	self          r5    r0   k88 ; k88 = "SetWidgetVisible"
.line	469	gettable      r7    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r7    r7   k89 ; k89 = "Button_BuyLuckCard"
.line	469	loadbool      r8     1     0
.line	469	loadbool      r9     1     0
.line	469	call          r5     5     1
.line	469	gettable      r5    r0   k74 ; k74 = "UIRoot"
.line	469	gettable      r5    r5   k90 ; k90 = "UTRichTextBlock_Luck" (truncated)
.line	469	self          r5    r5   k76 ; k76 = "SetText"
.line	469	gettabup      r7    u0   k77 ; k77 = "LocUtil"
.line	469	gettable      r7    r7   k78 ; k78 = "GetLocalizeResStr"
.line	469	loadk         r8   k91 ; k91 = 18141424
.line	469	call          r7     2     0
.line	469	call          r5     0     1
.label	l220
.line	469	return        r0     1
.line	469	move          r0    r0
.line	469	move          r0    r0
.line	469	move          r0    r0
.line	469	move          r0    r0
.line	469	return        r0     1

.function	main/f33

.source	null
.linedefined	497
.lastlinedefined	510
.numparams	1
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	0	false
.upvalue	"U1"	4	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"IsCanReceiveLinkageReward"
.constant	k5	"GetLinkageRewardStatus"
.constant	k6	"Enum_LinkageReceiveStatus"
.constant	k7	"UIRoot"
.constant	k8	"WidgetSwitcher_LinkageRewardStatus"
.constant	k9	"SetActiveWidgetIndex"
.constant	k10	0
.constant	k11	1
.constant	k12	"Received"
.constant	k13	"TextBlock_ReceiveLinkageReward1"
.constant	k14	"SetText"
.constant	k15	"LocUtil"
.constant	k16	"GetLocalizeResStr"
.constant	k17	6162
.constant	k18	"TextBlock_ReceiveLinkageReward2"
.constant	k19	8161

.line	497	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	497	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	497	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	497	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	497	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	497	call          r1     2     2
.line	497	self          r2    r1    k4 ; k4 = "IsCanReceiveLinkageR" (truncated)
.line	497	call          r2     2     2
.line	497	self          r3    r1    k5 ; k5 = "GetLinkageRewardStat" (truncated)
.line	497	call          r3     2     2
.line	497	gettabup      r4    u1    k6 ; k6 = "Enum_LinkageReceiveS" (truncated)
.line	497	gettable      r5    r0    k7 ; k7 = "UIRoot"
.line	497	gettable      r5    r5    k8 ; k8 = "WidgetSwitcher_Linka" (truncated)
.line	497	self          r5    r5    k9 ; k9 = "SetActiveWidgetIndex"
.line	497	test          r2     0
.line	497	jmp            0   l20
.line	497	loadk         r7   k10 ; k10 = 0
.line	497	test          r7     1
.line	497	jmp            0   l21
.label	l20
.line	497	loadk         r7   k11 ; k11 = 1
.label	l21
.line	497	call          r5     3     1
.line	497	gettable      r5    r4   k12 ; k12 = "Received"
.line	497	eq             0    r3    r5
.line	497	jmp            0   l42
.line	497	gettable      r5    r0    k7 ; k7 = "UIRoot"
.line	497	gettable      r5    r5   k13 ; k13 = "TextBlock_ReceiveLin" (truncated)
.line	497	self          r5    r5   k14 ; k14 = "SetText"
.line	497	gettabup      r7    u0   k15 ; k15 = "LocUtil"
.line	497	gettable      r7    r7   k16 ; k16 = "GetLocalizeResStr"
.line	497	loadk         r8   k17 ; k17 = 6162
.line	497	call          r7     2     0
.line	497	call          r5     0     1
.line	497	gettable      r5    r0    k7 ; k7 = "UIRoot"
.line	497	gettable      r5    r5   k18 ; k18 = "TextBlock_ReceiveLin" (truncated)
.line	497	self          r5    r5   k14 ; k14 = "SetText"
.line	497	gettabup      r7    u0   k15 ; k15 = "LocUtil"
.line	497	gettable      r7    r7   k16 ; k16 = "GetLocalizeResStr"
.line	497	loadk         r8   k17 ; k17 = 6162
.line	497	call          r7     2     0
.line	497	call          r5     0     1
.line	497	jmp            0   l58
.label	l42
.line	497	gettable      r5    r0    k7 ; k7 = "UIRoot"
.line	497	gettable      r5    r5   k13 ; k13 = "TextBlock_ReceiveLin" (truncated)
.line	497	self          r5    r5   k14 ; k14 = "SetText"
.line	497	gettabup      r7    u0   k15 ; k15 = "LocUtil"
.line	497	gettable      r7    r7   k16 ; k16 = "GetLocalizeResStr"
.line	497	loadk         r8   k19 ; k19 = 8161
.line	497	call          r7     2     0
.line	497	call          r5     0     1
.line	497	gettable      r5    r0    k7 ; k7 = "UIRoot"
.line	497	gettable      r5    r5   k18 ; k18 = "TextBlock_ReceiveLin" (truncated)
.line	497	self          r5    r5   k14 ; k14 = "SetText"
.line	497	gettabup      r7    u0   k15 ; k15 = "LocUtil"
.line	497	gettable      r7    r7   k16 ; k16 = "GetLocalizeResStr"
.line	497	loadk         r8   k19 ; k19 = 8161
.line	497	call          r7     2     0
.line	497	call          r5     0     1
.label	l58
.line	497	return        r0     1
.line	497	move          r0    r0
.line	497	move          r0    r0
.line	497	move          r0    r0
.line	497	move          r0    r0
.line	497	return        r0     1

.function	main/f34

.source	null
.linedefined	512
.lastlinedefined	519
.numparams	1
.is_vararg	0
.maxstacksize	10

.constant	k0	1
.constant	k1	3
.constant	k2	"_GetBuyItemNodes"
.constant	k3	"_SetupBuyItemRewardList"
.constant	k4	"_RefreshBuyItemBtn"
.constant	k5	"_RefreshExtraLocalText"

.line	512	loadk         r1    k0 ; k0 = 1
.line	512	loadk         r2    k1 ; k1 = 3
.line	512	loadk         r3    k0 ; k0 = 1
.line	512	move          r0    r0
.line	512	self          r5    r0    k2 ; k2 = "_GetBuyItemNodes"
.line	512	move          r7    r4
.line	512	call          r5     3     2
.line	512	self          r6    r0    k3 ; k3 = "_SetupBuyItemRewardL" (truncated)
.line	512	move          r8    r4
.line	512	move          r9    r5
.line	512	call          r6     4     1
.line	512	self          r6    r0    k4 ; k4 = "_RefreshBuyItemBtn"
.line	512	move          r8    r4
.line	512	move          r9    r5
.line	512	call          r6     4     1
.line	512	self          r6    r0    k5 ; k5 = "_RefreshExtraLocalTe" (truncated)
.line	512	move          r8    r4
.line	512	move          r9    r5
.line	512	call          r6     4     1
.line	512	move          r0    r0
.line	512	return        r0     1
.line	512	move          r0    r0
.line	512	move          r0    r0
.line	512	move          r0    r0
.line	512	move          r0    r0
.line	512	return        r0     1

.function	main/f35

.source	null
.linedefined	521
.lastlinedefined	571
.numparams	2
.is_vararg	0
.maxstacksize	4

.constant	k0	1
.constant	k1	"root"
.constant	k2	"UIRoot"
.constant	k3	"BlackFriday_RP_Buy_Item_UIBP_1"
.constant	k4	"rewardRoot"
.constant	k5	"BlackFriday_RP_Buy02_Item_UIBP"
.constant	k6	"widgetSwitcherReward"
.constant	k7	"WidgetSwitcher_Reward"
.constant	k8	"widgetSwitcherBuy"
.constant	k9	"WidgetSwitcher_Buy_Plus"
.constant	k10	"imageCard"
.constant	k11	"Image_Buy_Plus_Card"
.constant	k12	"imageSuperCard"
.constant	k13	"Image_Buy_Plus_SuperCard"
.constant	k14	"textPrice"
.constant	k15	"TextBlock_Price"
.constant	k16	"textPriceUc"
.constant	k17	"TextBlock_Buy_Plus_Uc"
.constant	k18	"textOriginPrice"
.constant	k19	"Buy_Plus_Supper_Disount"
.constant	k20	"textDiscountPrice"
.constant	k21	"TextBlock_Buy_Plus_Supper"
.constant	k22	"btnBuy"
.constant	k23	"Button_Buy_Plus"
.constant	k24	"btnBuyDiscount"
.constant	k25	"Button_Buy_Plus_Supper"
.constant	k26	"btnBuyCard"
.constant	k27	"Button_Buy_Plus_SuperCard"
.constant	k28	"btnBuyNormalCard"
.constant	k29	"Button_Buy_Plus_Card"
.constant	k30	2
.constant	k31	"BlackFriday_RP_Buy_Item_UIBP_2"
.constant	k32	3
.constant	k33	"BlackFriday_RP_Buy_Item_UIBP_3"
.constant	k34	"rewardRoot1"
.constant	k35	"BlackFriday_RP_Buy02_Item_UIBP_1"
.constant	k36	"rewardRoot2"
.constant	k37	"BlackFriday_RP_Buy02_Item_UIBP_2"

.line	521	newtable      r2     0     0
.line	521	eq             0    r1    k0 ; k0 = 1
.line	521	jmp            0   l47
.line	521	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	521	gettable      r3    r3    k3 ; k3 = "BlackFriday_RP_Buy_I" (truncated)
.line	521	settable      r2    k1    r3 ; k1 = "root"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k5 ; k5 = "BlackFriday_RP_Buy02" (truncated)
.line	521	settable      r2    k4    r3 ; k4 = "rewardRoot"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k7 ; k7 = "WidgetSwitcher_Rewar" (truncated)
.line	521	settable      r2    k6    r3 ; k6 = "widgetSwitcherReward"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k9 ; k9 = "WidgetSwitcher_Buy_P" (truncated)
.line	521	settable      r2    k8    r3 ; k8 = "widgetSwitcherBuy"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k11 ; k11 = "Image_Buy_Plus_Card"
.line	521	settable      r2   k10    r3 ; k10 = "imageCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k13 ; k13 = "Image_Buy_Plus_Super" (truncated)
.line	521	settable      r2   k12    r3 ; k12 = "imageSuperCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k15 ; k15 = "TextBlock_Price"
.line	521	settable      r2   k14    r3 ; k14 = "textPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k17 ; k17 = "TextBlock_Buy_Plus_U" (truncated)
.line	521	settable      r2   k16    r3 ; k16 = "textPriceUc"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k19 ; k19 = "Buy_Plus_Supper_Diso" (truncated)
.line	521	settable      r2   k18    r3 ; k18 = "textOriginPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k21 ; k21 = "TextBlock_Buy_Plus_S" (truncated)
.line	521	settable      r2   k20    r3 ; k20 = "textDiscountPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k23 ; k23 = "Button_Buy_Plus"
.line	521	settable      r2   k22    r3 ; k22 = "btnBuy"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k25 ; k25 = "Button_Buy_Plus_Supp" (truncated)
.line	521	settable      r2   k24    r3 ; k24 = "btnBuyDiscount"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k27 ; k27 = "Button_Buy_Plus_Supe" (truncated)
.line	521	settable      r2   k26    r3 ; k26 = "btnBuyCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k29 ; k29 = "Button_Buy_Plus_Card"
.line	521	settable      r2   k28    r3 ; k28 = "btnBuyNormalCard"
.line	521	jmp            0  l139
.label	l47
.line	521	eq             0    r1   k30 ; k30 = 2
.line	521	jmp            0   l92
.line	521	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	521	gettable      r3    r3   k31 ; k31 = "BlackFriday_RP_Buy_I" (truncated)
.line	521	settable      r2    k1    r3 ; k1 = "root"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k5 ; k5 = "BlackFriday_RP_Buy02" (truncated)
.line	521	settable      r2    k4    r3 ; k4 = "rewardRoot"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k7 ; k7 = "WidgetSwitcher_Rewar" (truncated)
.line	521	settable      r2    k6    r3 ; k6 = "widgetSwitcherReward"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k9 ; k9 = "WidgetSwitcher_Buy_P" (truncated)
.line	521	settable      r2    k8    r3 ; k8 = "widgetSwitcherBuy"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k11 ; k11 = "Image_Buy_Plus_Card"
.line	521	settable      r2   k10    r3 ; k10 = "imageCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k13 ; k13 = "Image_Buy_Plus_Super" (truncated)
.line	521	settable      r2   k12    r3 ; k12 = "imageSuperCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k15 ; k15 = "TextBlock_Price"
.line	521	settable      r2   k14    r3 ; k14 = "textPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k17 ; k17 = "TextBlock_Buy_Plus_U" (truncated)
.line	521	settable      r2   k16    r3 ; k16 = "textPriceUc"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k19 ; k19 = "Buy_Plus_Supper_Diso" (truncated)
.line	521	settable      r2   k18    r3 ; k18 = "textOriginPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k21 ; k21 = "TextBlock_Buy_Plus_S" (truncated)
.line	521	settable      r2   k20    r3 ; k20 = "textDiscountPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k23 ; k23 = "Button_Buy_Plus"
.line	521	settable      r2   k22    r3 ; k22 = "btnBuy"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k25 ; k25 = "Button_Buy_Plus_Supp" (truncated)
.line	521	settable      r2   k24    r3 ; k24 = "btnBuyDiscount"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k27 ; k27 = "Button_Buy_Plus_Supe" (truncated)
.line	521	settable      r2   k26    r3 ; k26 = "btnBuyCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k29 ; k29 = "Button_Buy_Plus_Card"
.line	521	settable      r2   k28    r3 ; k28 = "btnBuyNormalCard"
.line	521	jmp            0  l139
.label	l92
.line	521	eq             0    r1   k32 ; k32 = 3
.line	521	jmp            0  l139
.line	521	gettable      r3    r0    k2 ; k2 = "UIRoot"
.line	521	gettable      r3    r3   k33 ; k33 = "BlackFriday_RP_Buy_I" (truncated)
.line	521	settable      r2    k1    r3 ; k1 = "root"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k35 ; k35 = "BlackFriday_RP_Buy02" (truncated)
.line	521	settable      r2   k34    r3 ; k34 = "rewardRoot1"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k37 ; k37 = "BlackFriday_RP_Buy02" (truncated)
.line	521	settable      r2   k36    r3 ; k36 = "rewardRoot2"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k7 ; k7 = "WidgetSwitcher_Rewar" (truncated)
.line	521	settable      r2    k6    r3 ; k6 = "widgetSwitcherReward"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3    k9 ; k9 = "WidgetSwitcher_Buy_P" (truncated)
.line	521	settable      r2    k8    r3 ; k8 = "widgetSwitcherBuy"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k11 ; k11 = "Image_Buy_Plus_Card"
.line	521	settable      r2   k10    r3 ; k10 = "imageCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k13 ; k13 = "Image_Buy_Plus_Super" (truncated)
.line	521	settable      r2   k12    r3 ; k12 = "imageSuperCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k15 ; k15 = "TextBlock_Price"
.line	521	settable      r2   k14    r3 ; k14 = "textPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k17 ; k17 = "TextBlock_Buy_Plus_U" (truncated)
.line	521	settable      r2   k16    r3 ; k16 = "textPriceUc"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k19 ; k19 = "Buy_Plus_Supper_Diso" (truncated)
.line	521	settable      r2   k18    r3 ; k18 = "textOriginPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k21 ; k21 = "TextBlock_Buy_Plus_S" (truncated)
.line	521	settable      r2   k20    r3 ; k20 = "textDiscountPrice"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k23 ; k23 = "Button_Buy_Plus"
.line	521	settable      r2   k22    r3 ; k22 = "btnBuy"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k25 ; k25 = "Button_Buy_Plus_Supp" (truncated)
.line	521	settable      r2   k24    r3 ; k24 = "btnBuyDiscount"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k27 ; k27 = "Button_Buy_Plus_Supe" (truncated)
.line	521	settable      r2   k26    r3 ; k26 = "btnBuyCard"
.line	521	gettable      r3    r2    k1 ; k1 = "root"
.line	521	gettable      r3    r3   k29 ; k29 = "Button_Buy_Plus_Card"
.line	521	settable      r2   k28    r3 ; k28 = "btnBuyNormalCard"
.label	l139
.line	521	return        r2     2
.line	521	return        r0     1
.line	521	move          r0    r0
.line	521	return        r0     1

.function	main/f36

.source	null
.linedefined	573
.lastlinedefined	617
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true
.upvalue	"U2"	11	true

.constant	k0	1
.constant	k1	"widgetSwitcherReward"
.constant	k2	"SetActiveWidgetIndex"
.constant	k3	0
.constant	k4	"SetWidgetVisible"
.constant	k5	"rewardRoot"
.constant	k6	"LoopScrollGrid_Reward"
.constant	k7	"rewardItemLoop1"
.constant	k8	"InitChildClassScrollBox"
.constant	k9	"table"
.constant	k10	"concat"
.constant	k11	77
.constant	k12	141
.constant	k13	242
.constant	k14	221
.constant	k15	134
.constant	k16	204
.constant	k17	68
.constant	k18	216
.constant	k19	7
.constant	k20	120
.constant	k21	145
.constant	k22	46
.constant	k23	182
.constant	k24	92
.constant	k25	57
.constant	k26	131
.constant	k27	188
.constant	k28	248
.constant	k29	86
.constant	k30	224
.constant	k31	33
.constant	k32	232
.constant	k33	24
.constant	k34	107
.constant	k35	132
.constant	k36	115
.constant	k37	129
.constant	k38	225
.constant	k39	34
.constant	k40	142
.constant	k41	173
.constant	k42	127
.constant	k43	212
.constant	k44	2
.constant	k45	88
.constant	k46	177
.constant	k47	250
.constant	k48	166
.constant	k49	70
.constant	k50	157
.constant	k51	12
.constant	k52	101
.constant	k53	156
.constant	k54	100
.constant	k55	155
.constant	k56	206
.constant	k57	97
.constant	k58	9
.constant	k59	170
.constant	k60	189
.constant	k61	237
.constant	k62	39
.constant	k63	162
.constant	k64	19
.constant	k65	128
.constant	k66	125
.constant	k67	181
.constant	k68	103
.constant	k69	186
.constant	k70	"SetData"
.constant	k71	"GetAllSuperAwards"
.constant	k72	50
.constant	k73	"rewardItemLoop2"
.constant	k74	"require"
.constant	k75	105
.constant	k76	246
.constant	k77	164
.constant	k78	205
.constant	k79	11
.constant	k80	133
.constant	k81	38
.constant	k82	98
.constant	k83	148
.constant	k84	150
.constant	k85	89
.constant	k86	153
.constant	k87	154
.constant	k88	230
.constant	k89	81
.constant	k90	231
.constant	k91	58
.constant	k92	5
.constant	k93	119
.constant	k94	99
.constant	k95	137
.constant	k96	96
.constant	k97	158
.constant	k98	175
.constant	k99	200
.constant	k100	252
.constant	k101	51
.constant	k102	191
.constant	k103	111
.constant	k104	165
.constant	k105	222
.constant	k106	76
.constant	k107	149
.constant	k108	21
.constant	k109	73
.constant	k110	53
.constant	k111	138
.constant	k112	251
.constant	k113	52
.constant	k114	178
.constant	k115	59
.constant	k116	"CheckCurSeasonIsOpenBuyPrivilege"
.constant	k117	"bUseFirstBuyPrivilege"
.constant	k118	"UnknowPassSystem"
.constant	k119	"GetCurRPIsNewUserUnlock"
.constant	k120	3
.constant	k121	"rewardRoot1"
.constant	k122	"rewardRoot2"
.constant	k123	"rewardItemLoop3"
.constant	k124	"rewardItemLoop4"
.constant	k125	"GetBuyConfigViaBuyType"
.constant	k126	4
.constant	k127	6
.constant	k128	"ipairs"
.constant	k129	75
.constant	k130	254
.constant	k131	202
.constant	k132	174
.constant	k133	240
.constant	k134	147
.constant	k135	94
.constant	k136	"insert"
.constant	k137	"item_id"
.constant	k138	"item_num"
.constant	k139	84
.constant	k140	117
.constant	k141	195
.constant	k142	"item_sign"

.line	573	eq             0    r1    k0 ; k0 = 1
.line	573	jmp            0  l109
.line	573	gettable      r3    r2    k1 ; k1 = "widgetSwitcherReward"
.line	573	self          r3    r3    k2 ; k2 = "SetActiveWidgetIndex"
.line	573	loadk         r5    k3 ; k3 = 0
.line	573	call          r3     3     1
.line	573	self          r3    r0    k4 ; k4 = "SetWidgetVisible"
.line	573	gettable      r5    r2    k5 ; k5 = "rewardRoot"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	loadbool      r6     1     0
.line	573	loadbool      r7     1     0
.line	573	call          r3     5     1
.line	573	self          r3    r0    k8 ; k8 = "InitChildClassScroll" (truncated)
.line	573	gettable      r5    r2    k5 ; k5 = "rewardRoot"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	gettabup      r6    u0    k9 ; k9 = "table"
.line	573	gettable      r6    r6   k10 ; k10 = "concat"
.line	573	newtable      r7     1     0
.line	573	getupval      r8    u1
.line	573	loadk         r9   k11 ; k11 = 77
.line	573	loadk        r10   k12 ; k12 = 141
.line	573	loadk        r11   k13 ; k13 = 242
.line	573	loadk        r12   k14 ; k14 = 221
.line	573	loadk        r13   k15 ; k15 = 134
.line	573	loadk        r14   k16 ; k16 = 204
.line	573	loadk        r15   k17 ; k17 = 68
.line	573	loadk        r16   k18 ; k18 = 216
.line	573	loadk        r17   k19 ; k19 = 7
.line	573	loadk        r18   k20 ; k20 = 120
.line	573	loadk        r19   k21 ; k21 = 145
.line	573	loadk        r20   k22 ; k22 = 46
.line	573	loadk        r21   k23 ; k23 = 182
.line	573	loadk        r22   k18 ; k18 = 216
.line	573	loadk        r23   k24 ; k24 = 92
.line	573	loadk        r24   k25 ; k25 = 57
.line	573	loadk        r25   k26 ; k26 = 131
.line	573	loadk        r26   k13 ; k13 = 242
.line	573	loadk        r27   k27 ; k27 = 188
.line	573	loadk        r28   k28 ; k28 = 248
.line	573	loadk        r29   k29 ; k29 = 86
.line	573	loadk        r30   k30 ; k30 = 224
.line	573	loadk        r31   k31 ; k31 = 33
.line	573	loadk        r32   k32 ; k32 = 232
.line	573	loadk        r33   k33 ; k33 = 24
.line	573	loadk        r34   k34 ; k34 = 107
.line	573	loadk        r35   k35 ; k35 = 132
.line	573	loadk        r36   k36 ; k36 = 115
.line	573	loadk        r37   k37 ; k37 = 129
.line	573	loadk        r38   k38 ; k38 = 225
.line	573	loadk        r39   k24 ; k24 = 92
.line	573	loadk        r40   k39 ; k39 = 34
.line	573	loadk        r41   k40 ; k40 = 142
.line	573	loadk        r42   k41 ; k41 = 173
.line	573	loadk        r43   k15 ; k15 = 134
.line	573	loadk        r44   k23 ; k23 = 182
.line	573	loadk        r45   k42 ; k42 = 127
.line	573	loadk        r46   k43 ; k43 = 212
.line	573	loadk        r47   k44 ; k44 = 2
.line	573	loadk        r48   k28 ; k28 = 248
.line	573	call          r8    41     2
.line	573	getupval      r9    u1
.line	573	loadk        r10   k45 ; k45 = 88
.line	573	loadk        r11   k27 ; k27 = 188
.line	573	loadk        r12   k46 ; k46 = 177
.line	573	loadk        r13   k47 ; k47 = 250
.line	573	loadk        r14   k48 ; k48 = 166
.line	573	loadk        r15   k18 ; k18 = 216
.line	573	loadk        r16   k49 ; k49 = 70
.line	573	loadk        r17   k50 ; k50 = 157
.line	573	loadk        r18   k51 ; k51 = 12
.line	573	loadk        r19   k52 ; k52 = 101
.line	573	loadk        r20   k53 ; k53 = 156
.line	573	loadk        r21   k54 ; k54 = 100
.line	573	loadk        r22   k55 ; k55 = 155
.line	573	loadk        r23   k56 ; k56 = 206
.line	573	loadk        r24   k57 ; k57 = 97
.line	573	loadk        r25   k58 ; k58 = 9
.line	573	loadk        r26   k59 ; k59 = 170
.line	573	loadk        r27   k26 ; k26 = 131
.line	573	loadk        r28   k60 ; k60 = 189
.line	573	loadk        r29   k61 ; k61 = 237
.line	573	loadk        r30   k11 ; k11 = 77
.line	573	loadk        r31   k32 ; k32 = 232
.line	573	loadk        r32   k62 ; k62 = 39
.line	573	loadk        r33   k63 ; k63 = 162
.line	573	loadk        r34   k64 ; k64 = 19
.line	573	loadk        r35   k36 ; k36 = 115
.line	573	loadk        r36   k65 ; k65 = 128
.line	573	loadk        r37   k66 ; k66 = 125
.line	573	loadk        r38   k67 ; k67 = 181
.line	573	loadk        r39   k13 ; k13 = 242
.line	573	loadk        r40   k68 ; k68 = 103
.line	573	loadk        r41   k58 ; k58 = 9
.line	573	loadk        r42   k69 ; k69 = 186
.line	573	call          r9    34     0
.line	573	setlist       r7     0     1
.line	573	call          r6     2     2
.line	573	call          r3     4     2
.line	573	settable      r0    k7    r3 ; k7 = "rewardItemLoop1"
.line	573	gettable      r3    r0    k7 ; k7 = "rewardItemLoop1"
.line	573	self          r3    r3   k70 ; k70 = "SetData"
.line	573	gettabup      r5    u2   k71 ; k71 = "GetAllSuperAwards"
.line	573	loadbool      r6     0     0
.line	573	loadbool      r7     1     0
.line	573	loadk         r8   k72 ; k72 = 50
.line	573	call          r5     4     0
.line	573	call          r3     0     1
.line	573	jmp            0  l604
.label	l109
.line	573	eq             0    r1   k44 ; k44 = 2
.line	573	jmp            0  l304
.line	573	gettable      r3    r2    k1 ; k1 = "widgetSwitcherReward"
.line	573	self          r3    r3    k2 ; k2 = "SetActiveWidgetIndex"
.line	573	loadk         r5    k3 ; k3 = 0
.line	573	call          r3     3     1
.line	573	self          r3    r0    k4 ; k4 = "SetWidgetVisible"
.line	573	gettable      r5    r2    k5 ; k5 = "rewardRoot"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	loadbool      r6     1     0
.line	573	loadbool      r7     1     0
.line	573	call          r3     5     1
.line	573	self          r3    r0    k8 ; k8 = "InitChildClassScroll" (truncated)
.line	573	gettable      r5    r2    k5 ; k5 = "rewardRoot"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	gettabup      r6    u0    k9 ; k9 = "table"
.line	573	gettable      r6    r6   k10 ; k10 = "concat"
.line	573	newtable      r7     1     0
.line	573	getupval      r8    u1
.line	573	loadk         r9   k11 ; k11 = 77
.line	573	loadk        r10   k12 ; k12 = 141
.line	573	loadk        r11   k13 ; k13 = 242
.line	573	loadk        r12   k14 ; k14 = 221
.line	573	loadk        r13   k15 ; k15 = 134
.line	573	loadk        r14   k16 ; k16 = 204
.line	573	loadk        r15   k17 ; k17 = 68
.line	573	loadk        r16   k18 ; k18 = 216
.line	573	loadk        r17   k19 ; k19 = 7
.line	573	loadk        r18   k20 ; k20 = 120
.line	573	loadk        r19   k21 ; k21 = 145
.line	573	loadk        r20   k22 ; k22 = 46
.line	573	loadk        r21   k23 ; k23 = 182
.line	573	loadk        r22   k18 ; k18 = 216
.line	573	loadk        r23   k24 ; k24 = 92
.line	573	loadk        r24   k25 ; k25 = 57
.line	573	loadk        r25   k26 ; k26 = 131
.line	573	loadk        r26   k13 ; k13 = 242
.line	573	loadk        r27   k27 ; k27 = 188
.line	573	loadk        r28   k28 ; k28 = 248
.line	573	loadk        r29   k29 ; k29 = 86
.line	573	loadk        r30   k30 ; k30 = 224
.line	573	loadk        r31   k31 ; k31 = 33
.line	573	loadk        r32   k32 ; k32 = 232
.line	573	loadk        r33   k33 ; k33 = 24
.line	573	loadk        r34   k34 ; k34 = 107
.line	573	loadk        r35   k35 ; k35 = 132
.line	573	loadk        r36   k36 ; k36 = 115
.line	573	loadk        r37   k37 ; k37 = 129
.line	573	loadk        r38   k38 ; k38 = 225
.line	573	loadk        r39   k24 ; k24 = 92
.line	573	loadk        r40   k39 ; k39 = 34
.line	573	loadk        r41   k40 ; k40 = 142
.line	573	loadk        r42   k41 ; k41 = 173
.line	573	loadk        r43   k15 ; k15 = 134
.line	573	loadk        r44   k23 ; k23 = 182
.line	573	loadk        r45   k42 ; k42 = 127
.line	573	loadk        r46   k43 ; k43 = 212
.line	573	loadk        r47   k44 ; k44 = 2
.line	573	loadk        r48   k28 ; k28 = 248
.line	573	call          r8    41     2
.line	573	getupval      r9    u1
.line	573	loadk        r10   k45 ; k45 = 88
.line	573	loadk        r11   k27 ; k27 = 188
.line	573	loadk        r12   k46 ; k46 = 177
.line	573	loadk        r13   k47 ; k47 = 250
.line	573	loadk        r14   k48 ; k48 = 166
.line	573	loadk        r15   k18 ; k18 = 216
.line	573	loadk        r16   k49 ; k49 = 70
.line	573	loadk        r17   k50 ; k50 = 157
.line	573	loadk        r18   k51 ; k51 = 12
.line	573	loadk        r19   k52 ; k52 = 101
.line	573	loadk        r20   k53 ; k53 = 156
.line	573	loadk        r21   k54 ; k54 = 100
.line	573	loadk        r22   k55 ; k55 = 155
.line	573	loadk        r23   k56 ; k56 = 206
.line	573	loadk        r24   k57 ; k57 = 97
.line	573	loadk        r25   k58 ; k58 = 9
.line	573	loadk        r26   k59 ; k59 = 170
.line	573	loadk        r27   k26 ; k26 = 131
.line	573	loadk        r28   k60 ; k60 = 189
.line	573	loadk        r29   k61 ; k61 = 237
.line	573	loadk        r30   k11 ; k11 = 77
.line	573	loadk        r31   k32 ; k32 = 232
.line	573	loadk        r32   k62 ; k62 = 39
.line	573	loadk        r33   k63 ; k63 = 162
.line	573	loadk        r34   k64 ; k64 = 19
.line	573	loadk        r35   k36 ; k36 = 115
.line	573	loadk        r36   k65 ; k65 = 128
.line	573	loadk        r37   k66 ; k66 = 125
.line	573	loadk        r38   k67 ; k67 = 181
.line	573	loadk        r39   k13 ; k13 = 242
.line	573	loadk        r40   k68 ; k68 = 103
.line	573	loadk        r41   k58 ; k58 = 9
.line	573	loadk        r42   k69 ; k69 = 186
.line	573	call          r9    34     0
.line	573	setlist       r7     0     1
.line	573	call          r6     2     2
.line	573	call          r3     4     2
.line	573	settable      r0   k73    r3 ; k73 = "rewardItemLoop2"
.line	573	gettabup      r3    u0   k74 ; k74 = "require"
.line	573	gettabup      r4    u0    k9 ; k9 = "table"
.line	573	gettable      r4    r4   k10 ; k10 = "concat"
.line	573	newtable      r5     1     0
.line	573	getupval      r6    u1
.line	573	loadk         r7   k75 ; k75 = 105
.line	573	loadk         r8   k65 ; k65 = 128
.line	573	loadk         r9   k76 ; k76 = 246
.line	573	loadk        r10   k14 ; k14 = 221
.line	573	loadk        r11   k77 ; k77 = 164
.line	573	loadk        r12   k78 ; k78 = 205
.line	573	loadk        r13   k79 ; k79 = 11
.line	573	loadk        r14   k80 ; k80 = 133
.line	573	loadk        r15   k81 ; k81 = 38
.line	573	loadk        r16   k82 ; k82 = 98
.line	573	loadk        r17   k83 ; k83 = 148
.line	573	loadk        r18   k22 ; k22 = 46
.line	573	loadk        r19   k84 ; k84 = 150
.line	573	loadk        r20   k18 ; k18 = 216
.line	573	loadk        r21   k85 ; k85 = 89
.line	573	loadk        r22   k72 ; k72 = 50
.line	573	loadk        r23   k86 ; k86 = 153
.line	573	loadk        r24   k13 ; k13 = 242
.line	573	loadk        r25   k87 ; k87 = 154
.line	573	loadk        r26   k88 ; k88 = 230
.line	573	loadk        r27   k89 ; k89 = 81
.line	573	loadk        r28   k90 ; k90 = 231
.line	573	loadk        r29   k91 ; k91 = 58
.line	573	loadk        r30   k46 ; k46 = 177
.line	573	loadk        r31   k92 ; k92 = 5
.line	573	loadk        r32   k93 ; k93 = 119
.line	573	loadk        r33   k35 ; k35 = 132
.line	573	loadk        r34   k94 ; k94 = 99
.line	573	loadk        r35   k86 ; k86 = 153
.line	573	loadk        r36   k95 ; k95 = 137
.line	573	loadk        r37   k96 ; k96 = 96
.line	573	loadk        r38   k22 ; k22 = 46
.line	573	loadk        r39   k50 ; k50 = 157
.line	573	loadk        r40   k97 ; k97 = 158
.line	573	loadk        r41   k98 ; k98 = 175
.line	573	loadk        r42   k99 ; k99 = 200
.line	573	loadk        r43   k45 ; k45 = 88
.line	573	loadk        r44  k100 ; k100 = 252
.line	573	loadk        r45  k101 ; k101 = 51
.line	573	loadk        r46  k102 ; k102 = 191
.line	573	call          r6    41     2
.line	573	getupval      r7    u1
.line	573	loadk         r8  k103 ; k103 = 111
.line	573	loadk         r9   k55 ; k55 = 155
.line	573	loadk        r10   k46 ; k46 = 177
.line	573	loadk        r11   k43 ; k43 = 212
.line	573	loadk        r12  k104 ; k104 = 165
.line	573	loadk        r13  k105 ; k105 = 222
.line	573	loadk        r14  k106 ; k106 = 76
.line	573	loadk        r15  k107 ; k107 = 149
.line	573	loadk        r16  k108 ; k108 = 21
.line	573	loadk        r17   k82 ; k82 = 98
.line	573	loadk        r18   k55 ; k55 = 155
.line	573	loadk        r19   k34 ; k34 = 107
.line	573	loadk        r20   k83 ; k83 = 148
.line	573	loadk        r21   k18 ; k18 = 216
.line	573	loadk        r22  k109 ; k109 = 73
.line	573	loadk        r23  k110 ; k110 = 53
.line	573	loadk        r24  k111 ; k111 = 138
.line	573	loadk        r25   k60 ; k60 = 189
.line	573	loadk        r26   k53 ; k53 = 156
.line	573	loadk        r27  k112 ; k112 = 251
.line	573	loadk        r28   k52 ; k52 = 101
.line	573	loadk        r29   k61 ; k61 = 237
.line	573	loadk        r30  k113 ; k113 = 52
.line	573	loadk        r31  k114 ; k114 = 178
.line	573	loadk        r32  k115 ; k115 = 59
.line	573	call          r7    26     0
.line	573	setlist       r5     0     1
.line	573	call          r4     2     2
.line	573	call          r3     2     2
.line	573	gettable      r4    r3  k116 ; k116 = "CheckCurSeasonIsOpen" (truncated)
.line	573	call          r4     1     2
.line	573	testset       r5    r4     0
.line	573	jmp            0  l294
.line	573	gettable      r5    r0  k117 ; k117 = "bUseFirstBuyPrivileg" (truncated)
.line	573	test          r5     1
.line	573	jmp            0  l294
.line	573	gettabup      r5    u0  k118 ; k118 = "UnknowPassSystem"
.line	573	gettable      r5    r5  k119 ; k119 = "GetCurRPIsNewUserUnl" (truncated)
.line	573	call          r5     1     2
.label	l294
.line	573	gettable      r6    r0   k73 ; k73 = "rewardItemLoop2"
.line	573	self          r6    r6   k70 ; k70 = "SetData"
.line	573	gettabup      r8    u2   k71 ; k71 = "GetAllSuperAwards"
.line	573	loadbool      r9     0     0
.line	573	loadbool     r10     1     0
.line	573	loadnil      r11     1
.line	573	move         r13    r5
.line	573	call          r8     6     0
.line	573	call          r6     0     1
.line	573	jmp            0  l604
.label	l304
.line	573	eq             0    r1  k120 ; k120 = 3
.line	573	jmp            0  l604
.line	573	gettable      r3    r2    k1 ; k1 = "widgetSwitcherReward"
.line	573	self          r3    r3    k2 ; k2 = "SetActiveWidgetIndex"
.line	573	loadk         r5    k0 ; k0 = 1
.line	573	call          r3     3     1
.line	573	self          r3    r0    k4 ; k4 = "SetWidgetVisible"
.line	573	gettable      r5    r2  k121 ; k121 = "rewardRoot1"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	loadbool      r6     1     0
.line	573	call          r3     4     1
.line	573	self          r3    r0    k4 ; k4 = "SetWidgetVisible"
.line	573	gettable      r5    r2  k122 ; k122 = "rewardRoot2"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	loadbool      r6     1     0
.line	573	call          r3     4     1
.line	573	self          r3    r0    k8 ; k8 = "InitChildClassScroll" (truncated)
.line	573	gettable      r5    r2  k121 ; k121 = "rewardRoot1"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	gettabup      r6    u0    k9 ; k9 = "table"
.line	573	gettable      r6    r6   k10 ; k10 = "concat"
.line	573	newtable      r7     1     0
.line	573	getupval      r8    u1
.line	573	loadk         r9   k11 ; k11 = 77
.line	573	loadk        r10   k12 ; k12 = 141
.line	573	loadk        r11   k13 ; k13 = 242
.line	573	loadk        r12   k14 ; k14 = 221
.line	573	loadk        r13   k15 ; k15 = 134
.line	573	loadk        r14   k16 ; k16 = 204
.line	573	loadk        r15   k17 ; k17 = 68
.line	573	loadk        r16   k18 ; k18 = 216
.line	573	loadk        r17   k19 ; k19 = 7
.line	573	loadk        r18   k20 ; k20 = 120
.line	573	loadk        r19   k21 ; k21 = 145
.line	573	loadk        r20   k22 ; k22 = 46
.line	573	loadk        r21   k23 ; k23 = 182
.line	573	loadk        r22   k18 ; k18 = 216
.line	573	loadk        r23   k24 ; k24 = 92
.line	573	loadk        r24   k25 ; k25 = 57
.line	573	loadk        r25   k26 ; k26 = 131
.line	573	loadk        r26   k13 ; k13 = 242
.line	573	loadk        r27   k27 ; k27 = 188
.line	573	loadk        r28   k28 ; k28 = 248
.line	573	loadk        r29   k29 ; k29 = 86
.line	573	loadk        r30   k30 ; k30 = 224
.line	573	loadk        r31   k31 ; k31 = 33
.line	573	loadk        r32   k32 ; k32 = 232
.line	573	loadk        r33   k33 ; k33 = 24
.line	573	loadk        r34   k34 ; k34 = 107
.line	573	loadk        r35   k35 ; k35 = 132
.line	573	loadk        r36   k36 ; k36 = 115
.line	573	loadk        r37   k37 ; k37 = 129
.line	573	loadk        r38   k38 ; k38 = 225
.line	573	loadk        r39   k24 ; k24 = 92
.line	573	loadk        r40   k39 ; k39 = 34
.line	573	loadk        r41   k40 ; k40 = 142
.line	573	loadk        r42   k41 ; k41 = 173
.line	573	loadk        r43   k15 ; k15 = 134
.line	573	loadk        r44   k23 ; k23 = 182
.line	573	loadk        r45   k42 ; k42 = 127
.line	573	loadk        r46   k43 ; k43 = 212
.line	573	loadk        r47   k44 ; k44 = 2
.line	573	loadk        r48   k28 ; k28 = 248
.line	573	call          r8    41     2
.line	573	getupval      r9    u1
.line	573	loadk        r10   k45 ; k45 = 88
.line	573	loadk        r11   k27 ; k27 = 188
.line	573	loadk        r12   k46 ; k46 = 177
.line	573	loadk        r13   k47 ; k47 = 250
.line	573	loadk        r14   k48 ; k48 = 166
.line	573	loadk        r15   k18 ; k18 = 216
.line	573	loadk        r16   k49 ; k49 = 70
.line	573	loadk        r17   k50 ; k50 = 157
.line	573	loadk        r18   k51 ; k51 = 12
.line	573	loadk        r19   k52 ; k52 = 101
.line	573	loadk        r20   k53 ; k53 = 156
.line	573	loadk        r21   k54 ; k54 = 100
.line	573	loadk        r22   k55 ; k55 = 155
.line	573	loadk        r23   k56 ; k56 = 206
.line	573	loadk        r24   k57 ; k57 = 97
.line	573	loadk        r25   k58 ; k58 = 9
.line	573	loadk        r26   k59 ; k59 = 170
.line	573	loadk        r27   k26 ; k26 = 131
.line	573	loadk        r28   k60 ; k60 = 189
.line	573	loadk        r29   k61 ; k61 = 237
.line	573	loadk        r30   k11 ; k11 = 77
.line	573	loadk        r31   k32 ; k32 = 232
.line	573	loadk        r32   k62 ; k62 = 39
.line	573	loadk        r33   k63 ; k63 = 162
.line	573	loadk        r34   k64 ; k64 = 19
.line	573	loadk        r35   k36 ; k36 = 115
.line	573	loadk        r36   k65 ; k65 = 128
.line	573	loadk        r37   k66 ; k66 = 125
.line	573	loadk        r38   k67 ; k67 = 181
.line	573	loadk        r39   k13 ; k13 = 242
.line	573	loadk        r40   k68 ; k68 = 103
.line	573	loadk        r41   k58 ; k58 = 9
.line	573	loadk        r42   k69 ; k69 = 186
.line	573	call          r9    34     0
.line	573	setlist       r7     0     1
.line	573	call          r6     2     2
.line	573	call          r3     4     2
.line	573	settable      r0  k123    r3 ; k123 = "rewardItemLoop3"
.line	573	self          r3    r0    k8 ; k8 = "InitChildClassScroll" (truncated)
.line	573	gettable      r5    r2  k122 ; k122 = "rewardRoot2"
.line	573	gettable      r5    r5    k6 ; k6 = "LoopScrollGrid_Rewar" (truncated)
.line	573	gettabup      r6    u0    k9 ; k9 = "table"
.line	573	gettable      r6    r6   k10 ; k10 = "concat"
.line	573	newtable      r7     1     0
.line	573	getupval      r8    u1
.line	573	loadk         r9   k11 ; k11 = 77
.line	573	loadk        r10   k12 ; k12 = 141
.line	573	loadk        r11   k13 ; k13 = 242
.line	573	loadk        r12   k14 ; k14 = 221
.line	573	loadk        r13   k15 ; k15 = 134
.line	573	loadk        r14   k16 ; k16 = 204
.line	573	loadk        r15   k17 ; k17 = 68
.line	573	loadk        r16   k18 ; k18 = 216
.line	573	loadk        r17   k19 ; k19 = 7
.line	573	loadk        r18   k20 ; k20 = 120
.line	573	loadk        r19   k21 ; k21 = 145
.line	573	loadk        r20   k22 ; k22 = 46
.line	573	loadk        r21   k23 ; k23 = 182
.line	573	loadk        r22   k18 ; k18 = 216
.line	573	loadk        r23   k24 ; k24 = 92
.line	573	loadk        r24   k25 ; k25 = 57
.line	573	loadk        r25   k26 ; k26 = 131
.line	573	loadk        r26   k13 ; k13 = 242
.line	573	loadk        r27   k27 ; k27 = 188
.line	573	loadk        r28   k28 ; k28 = 248
.line	573	loadk        r29   k29 ; k29 = 86
.line	573	loadk        r30   k30 ; k30 = 224
.line	573	loadk        r31   k31 ; k31 = 33
.line	573	loadk        r32   k32 ; k32 = 232
.line	573	loadk        r33   k33 ; k33 = 24
.line	573	loadk        r34   k34 ; k34 = 107
.line	573	loadk        r35   k35 ; k35 = 132
.line	573	loadk        r36   k36 ; k36 = 115
.line	573	loadk        r37   k37 ; k37 = 129
.line	573	loadk        r38   k38 ; k38 = 225
.line	573	loadk        r39   k24 ; k24 = 92
.line	573	loadk        r40   k39 ; k39 = 34
.line	573	loadk        r41   k40 ; k40 = 142
.line	573	loadk        r42   k41 ; k41 = 173
.line	573	loadk        r43   k15 ; k15 = 134
.line	573	loadk        r44   k23 ; k23 = 182
.line	573	loadk        r45   k42 ; k42 = 127
.line	573	loadk        r46   k43 ; k43 = 212
.line	573	loadk        r47   k44 ; k44 = 2
.line	573	loadk        r48   k28 ; k28 = 248
.line	573	call          r8    41     2
.line	573	getupval      r9    u1
.line	573	loadk        r10   k45 ; k45 = 88
.line	573	loadk        r11   k27 ; k27 = 188
.line	573	loadk        r12   k46 ; k46 = 177
.line	573	loadk        r13   k47 ; k47 = 250
.line	573	loadk        r14   k48 ; k48 = 166
.line	573	loadk        r15   k18 ; k18 = 216
.line	573	loadk        r16   k49 ; k49 = 70
.line	573	loadk        r17   k50 ; k50 = 157
.line	573	loadk        r18   k51 ; k51 = 12
.line	573	loadk        r19   k52 ; k52 = 101
.line	573	loadk        r20   k53 ; k53 = 156
.line	573	loadk        r21   k54 ; k54 = 100
.line	573	loadk        r22   k55 ; k55 = 155
.line	573	loadk        r23   k56 ; k56 = 206
.line	573	loadk        r24   k57 ; k57 = 97
.line	573	loadk        r25   k58 ; k58 = 9
.line	573	loadk        r26   k59 ; k59 = 170
.line	573	loadk        r27   k26 ; k26 = 131
.line	573	loadk        r28   k60 ; k60 = 189
.line	573	loadk        r29   k61 ; k61 = 237
.line	573	loadk        r30   k11 ; k11 = 77
.line	573	loadk        r31   k32 ; k32 = 232
.line	573	loadk        r32   k62 ; k62 = 39
.line	573	loadk        r33   k63 ; k63 = 162
.line	573	loadk        r34   k64 ; k64 = 19
.line	573	loadk        r35   k36 ; k36 = 115
.line	573	loadk        r36   k65 ; k65 = 128
.line	573	loadk        r37   k66 ; k66 = 125
.line	573	loadk        r38   k67 ; k67 = 181
.line	573	loadk        r39   k13 ; k13 = 242
.line	573	loadk        r40   k68 ; k68 = 103
.line	573	loadk        r41   k58 ; k58 = 9
.line	573	loadk        r42   k69 ; k69 = 186
.line	573	call          r9    34     0
.line	573	setlist       r7     0     1
.line	573	call          r6     2     2
.line	573	call          r3     4     2
.line	573	settable      r0  k124    r3 ; k124 = "rewardItemLoop4"
.line	573	gettable      r3    r0  k124 ; k124 = "rewardItemLoop4"
.line	573	self          r3    r3   k70 ; k70 = "SetData"
.line	573	gettabup      r5    u2   k71 ; k71 = "GetAllSuperAwards"
.line	573	loadbool      r6     0     0
.line	573	loadbool      r7     0     0
.line	573	call          r5     3     0
.line	573	call          r3     0     1
.line	573	gettabup      r3    u2  k125 ; k125 = "GetBuyConfigViaBuyTy" (truncated)
.line	573	loadk         r4  k120 ; k120 = 3
.line	573	call          r3     2     2
.line	573	test          r3     1
.line	573	jmp            0  l507
.line	573	return        r0     1
.label	l507
.line	573	newtable      r4     5     0
.line	573	loadk         r5    k0 ; k0 = 1
.line	573	loadk         r6  k126 ; k126 = 4
.line	573	loadk         r7   k92 ; k92 = 5
.line	573	loadk         r8  k127 ; k127 = 6
.line	573	loadk         r9   k19 ; k19 = 7
.line	573	setlist       r4     5     1
.line	573	newtable      r5     0     0
.line	573	gettabup      r6    u0  k128 ; k128 = "ipairs"
.line	573	move          r7    r4
.line	573	call          r6     2     4
.line	573	jmp            0  l598
.line	573	getupval     r11    u1
.line	573	loadk        r12  k129 ; k129 = 75
.line	573	loadk        r13   k55 ; k55 = 155
.line	573	loadk        r14  k130 ; k130 = 254
.line	573	loadk        r15  k131 ; k131 = 202
.line	573	loadk        r16  k132 ; k132 = 174
.line	573	loadk        r17  k133 ; k133 = 240
.line	573	loadk        r18   k89 ; k89 = 81
.line	573	loadk        r19  k134 ; k134 = 147
.line	573	loadk        r20   k62 ; k62 = 39
.line	573	loadk        r21  k135 ; k135 = 94
.line	573	loadk        r22   k46 ; k46 = 177
.line	573	call         r11    12     2
.line	573	move         r12   r10
.line	573	concat       r11   r11   r12
.line	573	gettable     r11    r3   r11
.line	573	eq             1   r11    k3 ; k3 = 0
.line	573	jmp            0  l598
.line	573	gettabup     r11    u0    k9 ; k9 = "table"
.line	573	gettable     r11   r11  k136 ; k136 = "insert"
.line	573	move         r12    r5
.line	573	newtable     r13     0     3
.line	573	getupval     r14    u1
.line	573	loadk        r15  k129 ; k129 = 75
.line	573	loadk        r16   k55 ; k55 = 155
.line	573	loadk        r17  k130 ; k130 = 254
.line	573	loadk        r18  k131 ; k131 = 202
.line	573	loadk        r19  k132 ; k132 = 174
.line	573	loadk        r20  k133 ; k133 = 240
.line	573	loadk        r21   k89 ; k89 = 81
.line	573	loadk        r22  k134 ; k134 = 147
.line	573	loadk        r23   k62 ; k62 = 39
.line	573	loadk        r24  k135 ; k135 = 94
.line	573	loadk        r25   k46 ; k46 = 177
.line	573	call         r14    12     2
.line	573	move         r15   r10
.line	573	concat       r14   r14   r15
.line	573	gettable     r14    r3   r14
.line	573	settable     r13  k137   r14 ; k137 = "item_id"
.line	573	getupval     r14    u1
.line	573	loadk        r15  k129 ; k129 = 75
.line	573	loadk        r16   k55 ; k55 = 155
.line	573	loadk        r17  k130 ; k130 = 254
.line	573	loadk        r18  k131 ; k131 = 202
.line	573	loadk        r19  k132 ; k132 = 174
.line	573	loadk        r20  k133 ; k133 = 240
.line	573	loadk        r21   k89 ; k89 = 81
.line	573	loadk        r22  k134 ; k134 = 147
.line	573	loadk        r23   k62 ; k62 = 39
.line	573	loadk        r24  k139 ; k139 = 84
.line	573	loadk        r25   k87 ; k87 = 154
.line	573	loadk        r26  k140 ; k140 = 117
.line	573	loadk        r27   k83 ; k83 = 148
.line	573	loadk        r28  k141 ; k141 = 195
.line	573	call         r14    15     2
.line	573	move         r15   r10
.line	573	concat       r14   r14   r15
.line	573	gettable     r14    r3   r14
.line	573	settable     r13  k138   r14 ; k138 = "item_num"
.line	573	getupval     r14    u1
.line	573	loadk        r15  k129 ; k129 = 75
.line	573	loadk        r16   k55 ; k55 = 155
.line	573	loadk        r17  k130 ; k130 = 254
.line	573	loadk        r18  k131 ; k131 = 202
.line	573	loadk        r19  k132 ; k132 = 174
.line	573	loadk        r20  k133 ; k133 = 240
.line	573	loadk        r21   k89 ; k89 = 81
.line	573	loadk        r22  k134 ; k134 = 147
.line	573	loadk        r23   k62 ; k62 = 39
.line	573	loadk        r24   k17 ; k17 = 68
.line	573	loadk        r25   k53 ; k53 = 156
.line	573	loadk        r26   k68 ; k68 = 103
.line	573	loadk        r27   k83 ; k83 = 148
.line	573	call         r14    14     2
.line	573	move         r15   r10
.line	573	concat       r14   r14   r15
.line	573	gettable     r14    r3   r14
.line	573	settable     r13  k142   r14 ; k142 = "item_sign"
.line	573	call         r11     3     1
.label	l598
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	gettable      r6    r0  k123 ; k123 = "rewardItemLoop3"
.line	573	self          r6    r6   k70 ; k70 = "SetData"
.line	573	move          r8    r5
.line	573	call          r6     3     1
.label	l604
.line	573	return        r0     1
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	move          r0    r0
.line	573	return        r0     1

.function	main/f37

.source	null
.linedefined	619
.lastlinedefined	627
.numparams	3
.is_vararg	0
.maxstacksize	6

.constant	k0	1
.constant	k1	"RefreshExperienceNormalBuyBtn"
.constant	k2	2
.constant	k3	"RefreshNormalBuyBtn"
.constant	k4	3
.constant	k5	"RefreshEliteBuyBtn"

.line	619	eq             0    r1    k0 ; k0 = 1
.line	619	jmp            0    l7
.line	619	self          r3    r0    k1 ; k1 = "RefreshExperienceNor" (truncated)
.line	619	move          r5    r2
.line	619	call          r3     3     1
.line	619	jmp            0   l18
.label	l7
.line	619	eq             0    r1    k2 ; k2 = 2
.line	619	jmp            0   l13
.line	619	self          r3    r0    k3 ; k3 = "RefreshNormalBuyBtn"
.line	619	move          r5    r2
.line	619	call          r3     3     1
.line	619	jmp            0   l18
.label	l13
.line	619	eq             0    r1    k4 ; k4 = 3
.line	619	jmp            0   l18
.line	619	self          r3    r0    k5 ; k5 = "RefreshEliteBuyBtn"
.line	619	move          r5    r2
.line	619	call          r3     3     1
.label	l18
.line	619	return        r0     1
.line	619	move          r0    r0
.line	619	move          r0    r0
.line	619	return        r0     1

.function	main/f38

.source	null
.linedefined	629
.lastlinedefined	671
.numparams	3
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"root"
.constant	k1	"UTRichTextBlock_Rebate1"
.constant	k2	"SetText"
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	49329
.constant	k6	"UTRichTextBlock_Rebate2"
.constant	k7	18141458
.constant	k8	"TextBlock_BuyTips"
.constant	k9	18141460
.constant	k10	1
.constant	k11	"TextBlock_Title"
.constant	k12	83009
.constant	k13	"TextBlock_Level"
.constant	k14	87323
.constant	k15	"TextBlock_RebateNum1"
.constant	k16	360
.constant	k17	"TextBlock_RebateNum2"
.constant	k18	"SetTexture"
.constant	k19	"Image_Bg"
.constant	k20	"table"
.constant	k21	"concat"
.constant	k22	37
.constant	k23	171
.constant	k24	254
.constant	k25	213
.constant	k26	175
.constant	k27	150
.constant	k28	104
.constant	k29	153
.constant	k30	46
.constant	k31	56
.constant	k32	185
.constant	k33	111
.constant	k34	152
.constant	k35	71
.constant	k36	116
.constant	k37	169
.constant	k38	172
.constant	k39	131
.constant	k40	225
.constant	k41	78
.constant	k42	166
.constant	k43	23
.constant	k44	170
.constant	k45	59
.constant	k46	100
.constant	k47	142
.constant	k48	86
.constant	k49	206
.constant	k50	74
.constant	k51	42
.constant	k52	147
.constant	k53	227
.constant	k54	173
.constant	k55	200
.constant	k56	5
.constant	k57	215
.constant	k58	151
.constant	k59	126
.constant	k60	128
.constant	k61	203
.constant	k62	229
.constant	k63	251
.constant	k64	73
.constant	k65	41
.constant	k66	124
.constant	k67	179
.constant	k68	114
.constant	k69	211
.constant	k70	95
.constant	k71	34
.constant	k72	165
.constant	k73	149
.constant	k74	130
.constant	k75	233
.constant	k76	93
.constant	k77	236
.constant	k78	10
.constant	k79	148
.constant	k80	69
.constant	k81	144
.constant	k82	119
.constant	k83	181
.constant	k84	123
.constant	k85	219
.constant	k86	226
.constant	k87	189
.constant	k88	244
.constant	k89	75
.constant	k90	250
.constant	k91	120
.constant	k92	133
.constant	k93	217
.constant	k94	230
.constant	k95	108
.constant	k96	155
.constant	k97	43
.constant	k98	112
.constant	k99	168
.constant	k100	231
.constant	k101	157
.constant	k102	239
.constant	k103	184
.constant	k104	"rewardRoot"
.constant	k105	"TextBlock_RPLevel"
.constant	k106	88433
.constant	k107	"SetWidgetVisible"
.constant	k108	"TextBlock_Tips"
.constant	k109	"Image_Tips"
.constant	k110	"CanvasPanel_BuyTips"
.constant	k111	2
.constant	k112	49165
.constant	k113	49167
.constant	k114	"UnknowPassSystem"
.constant	k115	"IsBuyElite"
.constant	k116	88429
.constant	k117	"require"
.constant	k118	105
.constant	k119	246
.constant	k120	221
.constant	k121	164
.constant	k122	205
.constant	k123	11
.constant	k124	38
.constant	k125	98
.constant	k126	216
.constant	k127	89
.constant	k128	50
.constant	k129	242
.constant	k130	154
.constant	k131	81
.constant	k132	58
.constant	k133	177
.constant	k134	132
.constant	k135	99
.constant	k136	137
.constant	k137	96
.constant	k138	158
.constant	k139	88
.constant	k140	252
.constant	k141	51
.constant	k142	191
.constant	k143	212
.constant	k144	222
.constant	k145	76
.constant	k146	21
.constant	k147	107
.constant	k148	53
.constant	k149	138
.constant	k150	156
.constant	k151	101
.constant	k152	237
.constant	k153	52
.constant	k154	178
.constant	k155	"CheckCurSeasonIsOpenBuyPrivilege"
.constant	k156	"bUseFirstBuyPrivilege"
.constant	k157	"GetCurRPIsNewUserUnlock"
.constant	k158	60
.constant	k159	720
.constant	k160	18141422
.constant	k161	187
.constant	k162	"IsBuyEliteSeg2"
.constant	k163	87316
.constant	k164	"rewardRoot1"
.constant	k165	6562
.constant	k166	"rewardRoot2"
.constant	k167	88133
.constant	k168	87322
.constant	k169	18141423
.constant	k170	186
.constant	k171	"PassType"

.line	629	gettable      r3    r2    k0 ; k0 = "root"
.line	629	gettable      r4    r3    k1 ; k1 = "UTRichTextBlock_Reba" (truncated)
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7    k5 ; k5 = 49329
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3    k6 ; k6 = "UTRichTextBlock_Reba" (truncated)
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7    k7 ; k7 = 18141458
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3    k8 ; k8 = "TextBlock_BuyTips"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7    k9 ; k9 = 18141460
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	eq             0    r1   k10 ; k10 = 1
.line	629	jmp            0  l184
.line	629	gettable      r4    r3   k11 ; k11 = "TextBlock_Title"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7   k12 ; k12 = 83009
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3   k13 ; k13 = "TextBlock_Level"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7   k14 ; k14 = 87323
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3   k15 ; k15 = "TextBlock_RebateNum1"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	loadk         r6   k16 ; k16 = 360
.line	629	call          r4     3     1
.line	629	gettable      r4    r3   k17 ; k17 = "TextBlock_RebateNum2"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	loadk         r6   k16 ; k16 = 360
.line	629	call          r4     3     1
.line	629	self          r4    r0   k18 ; k18 = "SetTexture"
.line	629	gettable      r6    r3   k19 ; k19 = "Image_Bg"
.line	629	gettabup      r7    u0   k20 ; k20 = "table"
.line	629	gettable      r7    r7   k21 ; k21 = "concat"
.line	629	newtable      r8     2     0
.line	629	getupval      r9    u1
.line	629	loadk        r10   k22 ; k22 = 37
.line	629	loadk        r11   k23 ; k23 = 171
.line	629	loadk        r12   k24 ; k24 = 254
.line	629	loadk        r13   k25 ; k25 = 213
.line	629	loadk        r14   k26 ; k26 = 175
.line	629	loadk        r15   k27 ; k27 = 150
.line	629	loadk        r16   k28 ; k28 = 104
.line	629	loadk        r17   k29 ; k29 = 153
.line	629	loadk        r18   k30 ; k30 = 46
.line	629	loadk        r19   k31 ; k31 = 56
.line	629	loadk        r20   k32 ; k32 = 185
.line	629	loadk        r21   k33 ; k33 = 111
.line	629	loadk        r22   k34 ; k34 = 152
.line	629	loadk        r23   k25 ; k25 = 213
.line	629	loadk        r24   k35 ; k35 = 71
.line	629	loadk        r25   k36 ; k36 = 116
.line	629	loadk        r26   k37 ; k37 = 169
.line	629	loadk        r27   k38 ; k38 = 172
.line	629	loadk        r28   k39 ; k39 = 131
.line	629	loadk        r29   k40 ; k40 = 225
.line	629	loadk        r30   k41 ; k41 = 78
.line	629	loadk        r31   k42 ; k42 = 166
.line	629	loadk        r32   k43 ; k43 = 23
.line	629	loadk        r33   k44 ; k44 = 170
.line	629	loadk        r34   k45 ; k45 = 59
.line	629	loadk        r35   k46 ; k46 = 100
.line	629	loadk        r36   k47 ; k47 = 142
.line	629	loadk        r37   k48 ; k48 = 86
.line	629	loadk        r38   k34 ; k34 = 152
.line	629	loadk        r39   k49 ; k49 = 206
.line	629	loadk        r40   k50 ; k50 = 74
.line	629	loadk        r41   k51 ; k51 = 42
.line	629	loadk        r42   k52 ; k52 = 147
.line	629	loadk        r43   k53 ; k53 = 227
.line	629	loadk        r44   k54 ; k54 = 173
.line	629	loadk        r45   k55 ; k55 = 200
.line	629	loadk        r46   k56 ; k56 = 5
.line	629	loadk        r47   k57 ; k57 = 215
.line	629	loadk        r48   k51 ; k51 = 42
.line	629	loadk        r49   k58 ; k58 = 151
.line	629	call          r9    41     2
.line	629	getupval     r10    u1
.line	629	loadk        r11   k59 ; k59 = 126
.line	629	loadk        r12   k60 ; k60 = 128
.line	629	loadk        r13   k24 ; k24 = 254
.line	629	loadk        r14   k61 ; k61 = 203
.line	629	loadk        r15   k62 ; k62 = 229
.line	629	loadk        r16   k63 ; k63 = 251
.line	629	loadk        r17   k64 ; k64 = 73
.line	629	loadk        r18   k58 ; k58 = 151
.line	629	loadk        r19   k65 ; k65 = 41
.line	629	loadk        r20   k66 ; k66 = 124
.line	629	loadk        r21   k67 ; k67 = 179
.line	629	loadk        r22   k68 ; k68 = 114
.line	629	loadk        r23   k52 ; k52 = 147
.line	629	loadk        r24   k69 ; k69 = 211
.line	629	loadk        r25   k70 ; k70 = 95
.line	629	loadk        r26   k71 ; k71 = 34
.line	629	loadk        r27   k72 ; k72 = 165
.line	629	loadk        r28   k73 ; k73 = 149
.line	629	loadk        r29   k74 ; k74 = 130
.line	629	loadk        r30   k75 ; k75 = 233
.line	629	loadk        r31   k76 ; k76 = 93
.line	629	loadk        r32   k77 ; k77 = 236
.line	629	loadk        r33   k78 ; k78 = 10
.line	629	loadk        r34   k79 ; k79 = 148
.line	629	loadk        r35   k78 ; k78 = 10
.line	629	loadk        r36   k80 ; k80 = 69
.line	629	loadk        r37   k81 ; k81 = 144
.line	629	loadk        r38   k82 ; k82 = 119
.line	629	loadk        r39   k83 ; k83 = 181
.line	629	loadk        r40   k62 ; k62 = 229
.line	629	loadk        r41   k64 ; k64 = 73
.line	629	loadk        r42   k84 ; k84 = 123
.line	629	loadk        r43   k85 ; k85 = 219
.line	629	loadk        r44   k86 ; k86 = 226
.line	629	loadk        r45   k87 ; k87 = 189
.line	629	loadk        r46   k88 ; k88 = 244
.line	629	loadk        r47   k89 ; k89 = 75
.line	629	loadk        r48   k90 ; k90 = 250
.line	629	loadk        r49   k30 ; k30 = 46
.line	629	loadk        r50   k81 ; k81 = 144
.line	629	call         r10    41     2
.line	629	getupval     r11    u1
.line	629	loadk        r12   k91 ; k91 = 120
.line	629	loadk        r13   k92 ; k92 = 133
.line	629	loadk        r14   k63 ; k63 = 251
.line	629	loadk        r15   k93 ; k93 = 217
.line	629	loadk        r16   k67 ; k67 = 179
.line	629	loadk        r17   k94 ; k94 = 230
.line	629	loadk        r18   k95 ; k95 = 108
.line	629	loadk        r19   k96 ; k96 = 155
.line	629	loadk        r20   k97 ; k97 = 43
.line	629	loadk        r21   k98 ; k98 = 112
.line	629	loadk        r22   k81 ; k81 = 144
.line	629	loadk        r23   k70 ; k70 = 95
.line	629	loadk        r24   k99 ; k99 = 168
.line	629	loadk        r25  k100 ; k100 = 231
.line	629	loadk        r26   k66 ; k66 = 124
.line	629	loadk        r27   k30 ; k30 = 46
.line	629	loadk        r28  k101 ; k101 = 157
.line	629	loadk        r29   k39 ; k39 = 131
.line	629	loadk        r30   k54 ; k54 = 173
.line	629	loadk        r31  k102 ; k102 = 239
.line	629	loadk        r32   k78 ; k78 = 10
.line	629	loadk        r33  k103 ; k103 = 184
.line	629	call         r11    23     0
.line	629	setlist       r8     0     1
.line	629	call          r7     2     2
.line	629	call          r4     4     1
.line	629	gettable      r4    r2  k104 ; k104 = "rewardRoot"
.line	629	gettable      r4    r4  k105 ; k105 = "TextBlock_RPLevel"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k106 ; k106 = 88433
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r6    r3  k108 ; k108 = "TextBlock_Tips"
.line	629	loadbool      r7     0     0
.line	629	call          r4     4     1
.line	629	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r6    r3  k109 ; k109 = "Image_Tips"
.line	629	loadbool      r7     0     0
.line	629	call          r4     4     1
.line	629	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r6    r3  k110 ; k110 = "CanvasPanel_BuyTips"
.line	629	loadbool      r7     0     0
.line	629	call          r4     4     1
.line	629	jmp            0  l645
.label	l184
.line	629	eq             0    r1  k111 ; k111 = 2
.line	629	jmp            0  l456
.line	629	gettable      r4    r3   k11 ; k11 = "TextBlock_Title"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k112 ; k112 = 49165
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3   k13 ; k13 = "TextBlock_Level"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k113 ; k113 = 49167
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r2  k104 ; k104 = "rewardRoot"
.line	629	gettable      r4    r4  k105 ; k105 = "TextBlock_RPLevel"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	gettabup      r7    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable      r7    r7  k115 ; k115 = "IsBuyElite"
.line	629	test          r7     0
.line	629	jmp            0  l212
.line	629	loadk         r7  k106 ; k106 = 88433
.line	629	test          r7     1
.line	629	jmp            0  l213
.label	l212
.line	629	loadk         r7  k116 ; k116 = 88429
.label	l213
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettabup      r4    u0  k117 ; k117 = "require"
.line	629	gettabup      r5    u0   k20 ; k20 = "table"
.line	629	gettable      r5    r5   k21 ; k21 = "concat"
.line	629	newtable      r6     1     0
.line	629	getupval      r7    u1
.line	629	loadk         r8  k118 ; k118 = 105
.line	629	loadk         r9   k60 ; k60 = 128
.line	629	loadk        r10  k119 ; k119 = 246
.line	629	loadk        r11  k120 ; k120 = 221
.line	629	loadk        r12  k121 ; k121 = 164
.line	629	loadk        r13  k122 ; k122 = 205
.line	629	loadk        r14  k123 ; k123 = 11
.line	629	loadk        r15   k92 ; k92 = 133
.line	629	loadk        r16  k124 ; k124 = 38
.line	629	loadk        r17  k125 ; k125 = 98
.line	629	loadk        r18   k79 ; k79 = 148
.line	629	loadk        r19   k30 ; k30 = 46
.line	629	loadk        r20   k27 ; k27 = 150
.line	629	loadk        r21  k126 ; k126 = 216
.line	629	loadk        r22  k127 ; k127 = 89
.line	629	loadk        r23  k128 ; k128 = 50
.line	629	loadk        r24   k29 ; k29 = 153
.line	629	loadk        r25  k129 ; k129 = 242
.line	629	loadk        r26  k130 ; k130 = 154
.line	629	loadk        r27   k94 ; k94 = 230
.line	629	loadk        r28  k131 ; k131 = 81
.line	629	loadk        r29  k100 ; k100 = 231
.line	629	loadk        r30  k132 ; k132 = 58
.line	629	loadk        r31  k133 ; k133 = 177
.line	629	loadk        r32   k56 ; k56 = 5
.line	629	loadk        r33   k82 ; k82 = 119
.line	629	loadk        r34  k134 ; k134 = 132
.line	629	loadk        r35  k135 ; k135 = 99
.line	629	loadk        r36   k29 ; k29 = 153
.line	629	loadk        r37  k136 ; k136 = 137
.line	629	loadk        r38  k137 ; k137 = 96
.line	629	loadk        r39   k30 ; k30 = 46
.line	629	loadk        r40  k101 ; k101 = 157
.line	629	loadk        r41  k138 ; k138 = 158
.line	629	loadk        r42   k26 ; k26 = 175
.line	629	loadk        r43   k55 ; k55 = 200
.line	629	loadk        r44  k139 ; k139 = 88
.line	629	loadk        r45  k140 ; k140 = 252
.line	629	loadk        r46  k141 ; k141 = 51
.line	629	loadk        r47  k142 ; k142 = 191
.line	629	call          r7    41     2
.line	629	getupval      r8    u1
.line	629	loadk         r9   k33 ; k33 = 111
.line	629	loadk        r10   k96 ; k96 = 155
.line	629	loadk        r11  k133 ; k133 = 177
.line	629	loadk        r12  k143 ; k143 = 212
.line	629	loadk        r13   k72 ; k72 = 165
.line	629	loadk        r14  k144 ; k144 = 222
.line	629	loadk        r15  k145 ; k145 = 76
.line	629	loadk        r16   k73 ; k73 = 149
.line	629	loadk        r17  k146 ; k146 = 21
.line	629	loadk        r18  k125 ; k125 = 98
.line	629	loadk        r19   k96 ; k96 = 155
.line	629	loadk        r20  k147 ; k147 = 107
.line	629	loadk        r21   k79 ; k79 = 148
.line	629	loadk        r22  k126 ; k126 = 216
.line	629	loadk        r23   k64 ; k64 = 73
.line	629	loadk        r24  k148 ; k148 = 53
.line	629	loadk        r25  k149 ; k149 = 138
.line	629	loadk        r26   k87 ; k87 = 189
.line	629	loadk        r27  k150 ; k150 = 156
.line	629	loadk        r28   k63 ; k63 = 251
.line	629	loadk        r29  k151 ; k151 = 101
.line	629	loadk        r30  k152 ; k152 = 237
.line	629	loadk        r31  k153 ; k153 = 52
.line	629	loadk        r32  k154 ; k154 = 178
.line	629	loadk        r33   k45 ; k45 = 59
.line	629	call          r8    26     0
.line	629	setlist       r6     0     1
.line	629	call          r5     2     2
.line	629	call          r4     2     2
.line	629	gettable      r5    r4  k155 ; k155 = "CheckCurSeasonIsOpen" (truncated)
.line	629	call          r5     1     2
.line	629	testset       r6    r5     0
.line	629	jmp            0  l301
.line	629	gettable      r6    r0  k156 ; k156 = "bUseFirstBuyPrivileg" (truncated)
.line	629	test          r6     1
.line	629	jmp            0  l301
.line	629	gettabup      r6    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable      r6    r6  k157 ; k157 = "GetCurRPIsNewUserUnl" (truncated)
.line	629	call          r6     1     2
.label	l301
.line	629	gettable      r7    r3   k15 ; k15 = "TextBlock_RebateNum1"
.line	629	self          r7    r7    k2 ; k2 = "SetText"
.line	629	test          r6     0
.line	629	jmp            0  l308
.line	629	loadk         r9  k158 ; k158 = 60
.line	629	test          r9     1
.line	629	jmp            0  l309
.label	l308
.line	629	loadk         r9  k159 ; k159 = 720
.label	l309
.line	629	call          r7     3     1
.line	629	gettable      r7    r3   k17 ; k17 = "TextBlock_RebateNum2"
.line	629	self          r7    r7    k2 ; k2 = "SetText"
.line	629	loadk         r9   k16 ; k16 = 360
.line	629	call          r7     3     1
.line	629	gettable      r7    r3  k108 ; k108 = "TextBlock_Tips"
.line	629	self          r7    r7    k2 ; k2 = "SetText"
.line	629	gettabup      r9    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r9    r9    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk        r10  k160 ; k160 = 18141422
.line	629	call          r9     2     0
.line	629	call          r7     0     1
.line	629	self          r7    r0   k18 ; k18 = "SetTexture"
.line	629	gettable      r9    r3   k19 ; k19 = "Image_Bg"
.line	629	gettabup     r10    u0   k20 ; k20 = "table"
.line	629	gettable     r10   r10   k21 ; k21 = "concat"
.line	629	newtable     r11     2     0
.line	629	getupval     r12    u1
.line	629	loadk        r13   k22 ; k22 = 37
.line	629	loadk        r14   k23 ; k23 = 171
.line	629	loadk        r15   k24 ; k24 = 254
.line	629	loadk        r16   k25 ; k25 = 213
.line	629	loadk        r17   k26 ; k26 = 175
.line	629	loadk        r18   k27 ; k27 = 150
.line	629	loadk        r19   k28 ; k28 = 104
.line	629	loadk        r20   k29 ; k29 = 153
.line	629	loadk        r21   k30 ; k30 = 46
.line	629	loadk        r22   k31 ; k31 = 56
.line	629	loadk        r23   k32 ; k32 = 185
.line	629	loadk        r24   k33 ; k33 = 111
.line	629	loadk        r25   k34 ; k34 = 152
.line	629	loadk        r26   k25 ; k25 = 213
.line	629	loadk        r27   k35 ; k35 = 71
.line	629	loadk        r28   k36 ; k36 = 116
.line	629	loadk        r29   k37 ; k37 = 169
.line	629	loadk        r30   k38 ; k38 = 172
.line	629	loadk        r31   k39 ; k39 = 131
.line	629	loadk        r32   k40 ; k40 = 225
.line	629	loadk        r33   k41 ; k41 = 78
.line	629	loadk        r34   k42 ; k42 = 166
.line	629	loadk        r35   k43 ; k43 = 23
.line	629	loadk        r36   k44 ; k44 = 170
.line	629	loadk        r37   k45 ; k45 = 59
.line	629	loadk        r38   k46 ; k46 = 100
.line	629	loadk        r39   k47 ; k47 = 142
.line	629	loadk        r40   k48 ; k48 = 86
.line	629	loadk        r41   k34 ; k34 = 152
.line	629	loadk        r42   k49 ; k49 = 206
.line	629	loadk        r43   k50 ; k50 = 74
.line	629	loadk        r44   k51 ; k51 = 42
.line	629	loadk        r45   k52 ; k52 = 147
.line	629	loadk        r46   k53 ; k53 = 227
.line	629	loadk        r47   k54 ; k54 = 173
.line	629	loadk        r48   k55 ; k55 = 200
.line	629	loadk        r49   k56 ; k56 = 5
.line	629	loadk        r50   k57 ; k57 = 215
.line	629	loadk        r51   k51 ; k51 = 42
.line	629	loadk        r52   k58 ; k58 = 151
.line	629	call         r12    41     2
.line	629	getupval     r13    u1
.line	629	loadk        r14   k59 ; k59 = 126
.line	629	loadk        r15   k60 ; k60 = 128
.line	629	loadk        r16   k24 ; k24 = 254
.line	629	loadk        r17   k61 ; k61 = 203
.line	629	loadk        r18   k62 ; k62 = 229
.line	629	loadk        r19   k63 ; k63 = 251
.line	629	loadk        r20   k64 ; k64 = 73
.line	629	loadk        r21   k58 ; k58 = 151
.line	629	loadk        r22   k65 ; k65 = 41
.line	629	loadk        r23   k66 ; k66 = 124
.line	629	loadk        r24   k67 ; k67 = 179
.line	629	loadk        r25   k68 ; k68 = 114
.line	629	loadk        r26   k52 ; k52 = 147
.line	629	loadk        r27   k69 ; k69 = 211
.line	629	loadk        r28   k70 ; k70 = 95
.line	629	loadk        r29   k71 ; k71 = 34
.line	629	loadk        r30   k72 ; k72 = 165
.line	629	loadk        r31   k73 ; k73 = 149
.line	629	loadk        r32   k74 ; k74 = 130
.line	629	loadk        r33   k75 ; k75 = 233
.line	629	loadk        r34   k76 ; k76 = 93
.line	629	loadk        r35   k77 ; k77 = 236
.line	629	loadk        r36   k78 ; k78 = 10
.line	629	loadk        r37   k79 ; k79 = 148
.line	629	loadk        r38   k78 ; k78 = 10
.line	629	loadk        r39   k80 ; k80 = 69
.line	629	loadk        r40   k81 ; k81 = 144
.line	629	loadk        r41   k82 ; k82 = 119
.line	629	loadk        r42   k83 ; k83 = 181
.line	629	loadk        r43   k62 ; k62 = 229
.line	629	loadk        r44   k64 ; k64 = 73
.line	629	loadk        r45   k84 ; k84 = 123
.line	629	loadk        r46  k126 ; k126 = 216
.line	629	loadk        r47   k86 ; k86 = 226
.line	629	loadk        r48   k87 ; k87 = 189
.line	629	loadk        r49   k88 ; k88 = 244
.line	629	loadk        r50   k89 ; k89 = 75
.line	629	loadk        r51   k90 ; k90 = 250
.line	629	loadk        r52   k30 ; k30 = 46
.line	629	loadk        r53   k81 ; k81 = 144
.line	629	call         r13    41     2
.line	629	getupval     r14    u1
.line	629	loadk        r15   k91 ; k91 = 120
.line	629	loadk        r16   k92 ; k92 = 133
.line	629	loadk        r17   k63 ; k63 = 251
.line	629	loadk        r18   k93 ; k93 = 217
.line	629	loadk        r19   k67 ; k67 = 179
.line	629	loadk        r20   k94 ; k94 = 230
.line	629	loadk        r21   k95 ; k95 = 108
.line	629	loadk        r22   k96 ; k96 = 155
.line	629	loadk        r23   k97 ; k97 = 43
.line	629	loadk        r24   k98 ; k98 = 112
.line	629	loadk        r25   k81 ; k81 = 144
.line	629	loadk        r26   k70 ; k70 = 95
.line	629	loadk        r27   k99 ; k99 = 168
.line	629	loadk        r28  k100 ; k100 = 231
.line	629	loadk        r29   k66 ; k66 = 124
.line	629	loadk        r30   k30 ; k30 = 46
.line	629	loadk        r31  k101 ; k101 = 157
.line	629	loadk        r32   k39 ; k39 = 131
.line	629	loadk        r33   k54 ; k54 = 173
.line	629	loadk        r34  k102 ; k102 = 239
.line	629	loadk        r35   k78 ; k78 = 10
.line	629	loadk        r36  k161 ; k161 = 187
.line	629	call         r14    23     0
.line	629	setlist      r11     0     1
.line	629	call         r10     2     2
.line	629	call          r7     4     1
.line	629	self          r7    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r9    r3  k108 ; k108 = "TextBlock_Tips"
.line	629	loadbool     r10     1     0
.line	629	call          r7     4     1
.line	629	self          r7    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r9    r3  k109 ; k109 = "Image_Tips"
.line	629	loadbool     r10     1     0
.line	629	call          r7     4     1
.line	629	self          r7    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r9    r3  k110 ; k110 = "CanvasPanel_BuyTips"
.line	629	gettabup     r10    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable     r10   r10  k115 ; k115 = "IsBuyElite"
.line	629	test         r10     0
.line	629	jmp            0  l454
.line	629	gettabup     r10    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable     r10   r10  k162 ; k162 = "IsBuyEliteSeg2"
.line	629	not          r10   r10
.label	l454
.line	629	call          r7     4     1
.line	629	jmp            0  l645
.label	l456
.line	629	gettable      r4    r3   k11 ; k11 = "TextBlock_Title"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k112 ; k112 = 49165
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3   k13 ; k13 = "TextBlock_Level"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k163 ; k163 = 87316
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r2  k164 ; k164 = "rewardRoot1"
.line	629	gettable      r4    r4  k105 ; k105 = "TextBlock_RPLevel"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k165 ; k165 = 6562
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r2  k166 ; k166 = "rewardRoot2"
.line	629	gettable      r4    r4  k105 ; k105 = "TextBlock_RPLevel"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	gettabup      r7    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable      r7    r7  k115 ; k115 = "IsBuyElite"
.line	629	test          r7     0
.line	629	jmp            0  l490
.line	629	loadk         r7  k167 ; k167 = 88133
.line	629	test          r7     1
.line	629	jmp            0  l491
.label	l490
.line	629	loadk         r7  k168 ; k168 = 87322
.label	l491
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	gettable      r4    r3   k15 ; k15 = "TextBlock_RebateNum1"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	loadk         r6  k159 ; k159 = 720
.line	629	call          r4     3     1
.line	629	gettable      r4    r3   k17 ; k17 = "TextBlock_RebateNum2"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	loadk         r6   k16 ; k16 = 360
.line	629	call          r4     3     1
.line	629	gettable      r4    r3  k108 ; k108 = "TextBlock_Tips"
.line	629	self          r4    r4    k2 ; k2 = "SetText"
.line	629	gettabup      r6    u0    k3 ; k3 = "LocUtil"
.line	629	gettable      r6    r6    k4 ; k4 = "GetLocalizeResStr"
.line	629	loadk         r7  k169 ; k169 = 18141423
.line	629	call          r6     2     0
.line	629	call          r4     0     1
.line	629	self          r4    r0   k18 ; k18 = "SetTexture"
.line	629	gettable      r6    r3   k19 ; k19 = "Image_Bg"
.line	629	gettabup      r7    u0   k20 ; k20 = "table"
.line	629	gettable      r7    r7   k21 ; k21 = "concat"
.line	629	newtable      r8     2     0
.line	629	getupval      r9    u1
.line	629	loadk        r10   k22 ; k22 = 37
.line	629	loadk        r11   k23 ; k23 = 171
.line	629	loadk        r12   k24 ; k24 = 254
.line	629	loadk        r13   k25 ; k25 = 213
.line	629	loadk        r14   k26 ; k26 = 175
.line	629	loadk        r15   k27 ; k27 = 150
.line	629	loadk        r16   k28 ; k28 = 104
.line	629	loadk        r17   k29 ; k29 = 153
.line	629	loadk        r18   k30 ; k30 = 46
.line	629	loadk        r19   k31 ; k31 = 56
.line	629	loadk        r20   k32 ; k32 = 185
.line	629	loadk        r21   k33 ; k33 = 111
.line	629	loadk        r22   k34 ; k34 = 152
.line	629	loadk        r23   k25 ; k25 = 213
.line	629	loadk        r24   k35 ; k35 = 71
.line	629	loadk        r25   k36 ; k36 = 116
.line	629	loadk        r26   k37 ; k37 = 169
.line	629	loadk        r27   k38 ; k38 = 172
.line	629	loadk        r28   k39 ; k39 = 131
.line	629	loadk        r29   k40 ; k40 = 225
.line	629	loadk        r30   k41 ; k41 = 78
.line	629	loadk        r31   k42 ; k42 = 166
.line	629	loadk        r32   k43 ; k43 = 23
.line	629	loadk        r33   k44 ; k44 = 170
.line	629	loadk        r34   k45 ; k45 = 59
.line	629	loadk        r35   k46 ; k46 = 100
.line	629	loadk        r36   k47 ; k47 = 142
.line	629	loadk        r37   k48 ; k48 = 86
.line	629	loadk        r38   k34 ; k34 = 152
.line	629	loadk        r39   k49 ; k49 = 206
.line	629	loadk        r40   k50 ; k50 = 74
.line	629	loadk        r41   k51 ; k51 = 42
.line	629	loadk        r42   k52 ; k52 = 147
.line	629	loadk        r43   k53 ; k53 = 227
.line	629	loadk        r44   k54 ; k54 = 173
.line	629	loadk        r45   k55 ; k55 = 200
.line	629	loadk        r46   k56 ; k56 = 5
.line	629	loadk        r47   k57 ; k57 = 215
.line	629	loadk        r48   k51 ; k51 = 42
.line	629	loadk        r49   k58 ; k58 = 151
.line	629	call          r9    41     2
.line	629	getupval     r10    u1
.line	629	loadk        r11   k59 ; k59 = 126
.line	629	loadk        r12   k60 ; k60 = 128
.line	629	loadk        r13   k24 ; k24 = 254
.line	629	loadk        r14   k61 ; k61 = 203
.line	629	loadk        r15   k62 ; k62 = 229
.line	629	loadk        r16   k63 ; k63 = 251
.line	629	loadk        r17   k64 ; k64 = 73
.line	629	loadk        r18   k58 ; k58 = 151
.line	629	loadk        r19   k65 ; k65 = 41
.line	629	loadk        r20   k66 ; k66 = 124
.line	629	loadk        r21   k67 ; k67 = 179
.line	629	loadk        r22   k68 ; k68 = 114
.line	629	loadk        r23   k52 ; k52 = 147
.line	629	loadk        r24   k69 ; k69 = 211
.line	629	loadk        r25   k70 ; k70 = 95
.line	629	loadk        r26   k71 ; k71 = 34
.line	629	loadk        r27   k72 ; k72 = 165
.line	629	loadk        r28   k73 ; k73 = 149
.line	629	loadk        r29   k74 ; k74 = 130
.line	629	loadk        r30   k75 ; k75 = 233
.line	629	loadk        r31   k76 ; k76 = 93
.line	629	loadk        r32   k77 ; k77 = 236
.line	629	loadk        r33   k78 ; k78 = 10
.line	629	loadk        r34   k79 ; k79 = 148
.line	629	loadk        r35   k78 ; k78 = 10
.line	629	loadk        r36   k80 ; k80 = 69
.line	629	loadk        r37   k81 ; k81 = 144
.line	629	loadk        r38   k82 ; k82 = 119
.line	629	loadk        r39   k83 ; k83 = 181
.line	629	loadk        r40   k62 ; k62 = 229
.line	629	loadk        r41   k64 ; k64 = 73
.line	629	loadk        r42   k84 ; k84 = 123
.line	629	loadk        r43   k93 ; k93 = 217
.line	629	loadk        r44   k86 ; k86 = 226
.line	629	loadk        r45   k87 ; k87 = 189
.line	629	loadk        r46   k88 ; k88 = 244
.line	629	loadk        r47   k89 ; k89 = 75
.line	629	loadk        r48   k90 ; k90 = 250
.line	629	loadk        r49   k30 ; k30 = 46
.line	629	loadk        r50   k81 ; k81 = 144
.line	629	call         r10    41     2
.line	629	getupval     r11    u1
.line	629	loadk        r12   k91 ; k91 = 120
.line	629	loadk        r13   k92 ; k92 = 133
.line	629	loadk        r14   k63 ; k63 = 251
.line	629	loadk        r15   k93 ; k93 = 217
.line	629	loadk        r16   k67 ; k67 = 179
.line	629	loadk        r17   k94 ; k94 = 230
.line	629	loadk        r18   k95 ; k95 = 108
.line	629	loadk        r19   k96 ; k96 = 155
.line	629	loadk        r20   k97 ; k97 = 43
.line	629	loadk        r21   k98 ; k98 = 112
.line	629	loadk        r22   k81 ; k81 = 144
.line	629	loadk        r23   k70 ; k70 = 95
.line	629	loadk        r24   k99 ; k99 = 168
.line	629	loadk        r25  k100 ; k100 = 231
.line	629	loadk        r26   k66 ; k66 = 124
.line	629	loadk        r27   k30 ; k30 = 46
.line	629	loadk        r28  k101 ; k101 = 157
.line	629	loadk        r29   k39 ; k39 = 131
.line	629	loadk        r30   k54 ; k54 = 173
.line	629	loadk        r31  k102 ; k102 = 239
.line	629	loadk        r32   k78 ; k78 = 10
.line	629	loadk        r33  k170 ; k170 = 186
.line	629	call         r11    23     0
.line	629	setlist       r8     0     1
.line	629	call          r7     2     2
.line	629	call          r4     4     1
.line	629	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r6    r3  k108 ; k108 = "TextBlock_Tips"
.line	629	loadbool      r7     1     0
.line	629	call          r4     4     1
.line	629	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r6    r3  k109 ; k109 = "Image_Tips"
.line	629	loadbool      r7     1     0
.line	629	call          r4     4     1
.line	629	self          r4    r0  k107 ; k107 = "SetWidgetVisible"
.line	629	gettable      r6    r3  k110 ; k110 = "CanvasPanel_BuyTips"
.line	629	gettabup      r7    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable      r7    r7  k115 ; k115 = "IsBuyElite"
.line	629	test          r7     0
.line	629	jmp            0  l644
.line	629	gettabup      r7    u0  k114 ; k114 = "UnknowPassSystem"
.line	629	gettable      r7    r7  k171 ; k171 = "PassType"
.line	629	lt             1    r7  k111 ; k111 = 2
.line	629	jmp            0  l643
.line	629	loadbool      r7     0     1
.label	l643
.line	629	loadbool      r7     1     0
.label	l644
.line	629	call          r4     4     1
.label	l645
.line	629	return        r0     1
.line	629	move          r0    r0
.line	629	move          r0    r0
.line	629	move          r0    r0
.line	629	return        r0     1

.function	main/f39

.source	null
.linedefined	673
.lastlinedefined	697
.numparams	3
.is_vararg	0
.maxstacksize	8

.constant	k0	"btnBuy"
.constant	k1	"AddOnClickedEventByControl"
.constant	k2	"btnBuyDiscount"
.constant	k3	"btnBuyCard"
.constant	k4	"btnBuyNormalCard"
.constant	k5	"root"
.constant	k6	"Button_NewUser"

.line	673	gettable      r3    r2    k0 ; k0 = "btnBuy"
.line	673	test          r3     0
.line	673	jmp            0    l9
.line	673	self          r3    r0    k1 ; k1 = "AddOnClickedEventByC" (truncated)
.line	673	gettable      r5    r2    k0 ; k0 = "btnBuy"
.line	673	closure       r6    f0
.line	673	move          r7    r0
.line	673	call          r3     5     1
.label	l9
.line	673	gettable      r3    r2    k2 ; k2 = "btnBuyDiscount"
.line	673	test          r3     0
.line	673	jmp            0   l17
.line	673	self          r3    r0    k1 ; k1 = "AddOnClickedEventByC" (truncated)
.line	673	gettable      r5    r2    k2 ; k2 = "btnBuyDiscount"
.line	673	closure       r6    f1
.line	673	move          r7    r0
.line	673	call          r3     5     1
.label	l17
.line	673	gettable      r3    r2    k3 ; k3 = "btnBuyCard"
.line	673	test          r3     0
.line	673	jmp            0   l25
.line	673	self          r3    r0    k1 ; k1 = "AddOnClickedEventByC" (truncated)
.line	673	gettable      r5    r2    k3 ; k3 = "btnBuyCard"
.line	673	closure       r6    f2
.line	673	move          r7    r0
.line	673	call          r3     5     1
.label	l25
.line	673	gettable      r3    r2    k4 ; k4 = "btnBuyNormalCard"
.line	673	test          r3     0
.line	673	jmp            0   l33
.line	673	self          r3    r0    k1 ; k1 = "AddOnClickedEventByC" (truncated)
.line	673	gettable      r5    r2    k4 ; k4 = "btnBuyNormalCard"
.line	673	closure       r6    f3
.line	673	move          r7    r0
.line	673	call          r3     5     1
.label	l33
.line	673	self          r3    r0    k1 ; k1 = "AddOnClickedEventByC" (truncated)
.line	673	gettable      r5    r2    k5 ; k5 = "root"
.line	673	gettable      r5    r5    k6 ; k6 = "Button_NewUser"
.line	673	closure       r6    f4
.line	673	move          r7    r0
.line	673	call          r3     5     1
.line	673	return        r0     1
.line	673	move          r0    r0
.line	673	move          r0    r0
.line	673	move          r0    r0
.line	673	move          r0    r0
.line	673	return        r0     1

.function	main/f39/f0

.source	null
.linedefined	675
.lastlinedefined	677
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true

.constant	k0	"OnClickBuyItem"

.line	675	getupval      r0    u0
.line	675	self          r0    r0    k0 ; k0 = "OnClickBuyItem"
.line	675	getupval      r2    u1
.line	675	loadbool      r3     0     0
.line	675	call          r0     4     1
.line	675	return        r0     1
.line	675	move          r0    r0
.line	675	return        r0     1

.function	main/f39/f1

.source	null
.linedefined	680
.lastlinedefined	682
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true

.constant	k0	"OnClickBuyItem"

.line	680	getupval      r0    u0
.line	680	self          r0    r0    k0 ; k0 = "OnClickBuyItem"
.line	680	getupval      r2    u1
.line	680	loadbool      r3     0     0
.line	680	call          r0     4     1
.line	680	return        r0     1
.line	680	move          r0    r0
.line	680	move          r0    r0
.line	680	move          r0    r0
.line	680	move          r0    r0
.line	680	return        r0     1

.function	main/f39/f2

.source	null
.linedefined	685
.lastlinedefined	687
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true

.constant	k0	"OnClickBuyItem"

.line	685	getupval      r0    u0
.line	685	self          r0    r0    k0 ; k0 = "OnClickBuyItem"
.line	685	getupval      r2    u1
.line	685	loadbool      r3     1     0
.line	685	call          r0     4     1
.line	685	return        r0     1
.line	685	move          r0    r0
.line	685	move          r0    r0
.line	685	move          r0    r0
.line	685	return        r0     1

.function	main/f39/f3

.source	null
.linedefined	690
.lastlinedefined	692
.numparams	0
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	true
.upvalue	"U1"	1	true

.constant	k0	"OnClickBuyItem"

.line	690	getupval      r0    u0
.line	690	self          r0    r0    k0 ; k0 = "OnClickBuyItem"
.line	690	getupval      r2    u1
.line	690	loadbool      r3     1     0
.line	690	call          r0     4     1
.line	690	return        r0     1
.line	690	move          r0    r0
.line	690	return        r0     1

.function	main/f39/f4

.source	null
.linedefined	694
.lastlinedefined	696
.numparams	0
.is_vararg	0
.maxstacksize	2

.upvalue	"_ENV"	0	true

.constant	k0	"OnClickNewUserPrivileges"

.line	694	getupval      r0    u0
.line	694	self          r0    r0    k0 ; k0 = "OnClickNewUserPrivil" (truncated)
.line	694	call          r0     2     1
.line	694	return        r0     1
.line	694	move          r0    r0
.line	694	move          r0    r0
.line	694	move          r0    r0
.line	694	move          r0    r0
.line	694	return        r0     1

.function	main/f40

.source	null
.linedefined	699
.lastlinedefined	733
.numparams	3
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	0	false
.upvalue	"U1"	11	true
.upvalue	"U2"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	0
.constant	k4	1
.constant	k5	"hasCardType"
.constant	k6	"nHasCardType"
.constant	k7	"nFromType"
.constant	k8	"nRawBuyType"
.constant	k9	"ExperienceBuyType"
.constant	k10	"nBuyType"
.constant	k11	3
.constant	k12	2
.constant	k13	"NormalBuyType"
.constant	k14	"HasNewUserPrivlegesCard"
.constant	k15	"require"
.constant	k16	"table"
.constant	k17	"concat"
.constant	k18	105
.constant	k19	128
.constant	k20	246
.constant	k21	221
.constant	k22	164
.constant	k23	205
.constant	k24	11
.constant	k25	133
.constant	k26	38
.constant	k27	98
.constant	k28	148
.constant	k29	46
.constant	k30	150
.constant	k31	216
.constant	k32	89
.constant	k33	50
.constant	k34	153
.constant	k35	242
.constant	k36	154
.constant	k37	230
.constant	k38	81
.constant	k39	231
.constant	k40	58
.constant	k41	177
.constant	k42	5
.constant	k43	119
.constant	k44	132
.constant	k45	99
.constant	k46	137
.constant	k47	66
.constant	k48	36
.constant	k49	141
.constant	k50	165
.constant	k51	156
.constant	k52	199
.constant	k53	95
.constant	k54	247
.constant	k55	184
.constant	k56	101
.constant	k57	155
.constant	k58	239
.constant	k59	217
.constant	k60	185
.constant	k61	202
.constant	k62	122
.constant	k63	63
.constant	k64	110
.constant	k65	"OpenBuyUI"
.constant	k66	"EliteBuyType"
.constant	k67	"bIsSuper"
.constant	k68	true
.constant	k69	"HandleBuyPopup"

.line	699	self          r3    r0    k0 ; k0 = "PlayAudio"
.line	699	gettabup      r5    u0    k1 ; k1 = "sound_config"
.line	699	gettable      r5    r5    k2 ; k2 = "click_v1"
.line	699	call          r3     3     1
.line	699	loadk         r3    k3 ; k3 = 0
.line	699	newtable      r4     0     0
.line	699	eq             0    r1    k4 ; k4 = 1
.line	699	jmp            0   l21
.line	699	gettable      r5    r0    k5 ; k5 = "hasCardType"
.line	699	testset       r3    r5     1
.line	699	jmp            0   l13
.line	699	loadk         r3    k4 ; k4 = 1
.label	l13
.line	699	newtable      r5     0     4
.line	699	settable      r5    k6    r3 ; k6 = "nHasCardType"
.line	699	settable      r5    k7    k3 ; k3 = 0
.line	699	gettable      r6    r0    k9 ; k9 = "ExperienceBuyType"
.line	699	settable      r5    k8    r6 ; k8 = "nRawBuyType"
.line	699	settable      r5   k10   k11 ; k11 = 3
.line	699	move          r4    r5
.line	699	jmp            0  l117
.label	l21
.line	699	eq             0    r1   k12 ; k12 = 2
.line	699	jmp            0  l102
.line	699	gettable      r5    r0    k5 ; k5 = "hasCardType"
.line	699	testset       r3    r5     1
.line	699	jmp            0   l27
.line	699	loadk         r3    k4 ; k4 = 1
.label	l27
.line	699	newtable      r5     0     3
.line	699	settable      r5    k6    r3 ; k6 = "nHasCardType"
.line	699	settable      r5    k7    k3 ; k3 = 0
.line	699	gettable      r6    r0   k13 ; k13 = "NormalBuyType"
.line	699	settable      r5    k8    r6 ; k8 = "nRawBuyType"
.line	699	move          r4    r5
.line	699	gettabup      r5    u1   k14 ; k14 = "HasNewUserPrivlegesC" (truncated)
.line	699	call          r5     1     2
.line	699	test          r5     0
.line	699	jmp            0  l117
.line	699	gettabup      r5    u0   k15 ; k15 = "require"
.line	699	gettabup      r6    u0   k16 ; k16 = "table"
.line	699	gettable      r6    r6   k17 ; k17 = "concat"
.line	699	newtable      r7     1     0
.line	699	getupval      r8    u2
.line	699	loadk         r9   k18 ; k18 = 105
.line	699	loadk        r10   k19 ; k19 = 128
.line	699	loadk        r11   k20 ; k20 = 246
.line	699	loadk        r12   k21 ; k21 = 221
.line	699	loadk        r13   k22 ; k22 = 164
.line	699	loadk        r14   k23 ; k23 = 205
.line	699	loadk        r15   k24 ; k24 = 11
.line	699	loadk        r16   k25 ; k25 = 133
.line	699	loadk        r17   k26 ; k26 = 38
.line	699	loadk        r18   k27 ; k27 = 98
.line	699	loadk        r19   k28 ; k28 = 148
.line	699	loadk        r20   k29 ; k29 = 46
.line	699	loadk        r21   k30 ; k30 = 150
.line	699	loadk        r22   k31 ; k31 = 216
.line	699	loadk        r23   k32 ; k32 = 89
.line	699	loadk        r24   k33 ; k33 = 50
.line	699	loadk        r25   k34 ; k34 = 153
.line	699	loadk        r26   k35 ; k35 = 242
.line	699	loadk        r27   k36 ; k36 = 154
.line	699	loadk        r28   k37 ; k37 = 230
.line	699	loadk        r29   k38 ; k38 = 81
.line	699	loadk        r30   k39 ; k39 = 231
.line	699	loadk        r31   k40 ; k40 = 58
.line	699	loadk        r32   k41 ; k41 = 177
.line	699	loadk        r33   k42 ; k42 = 5
.line	699	loadk        r34   k43 ; k43 = 119
.line	699	loadk        r35   k44 ; k44 = 132
.line	699	loadk        r36   k45 ; k45 = 99
.line	699	loadk        r37   k34 ; k34 = 153
.line	699	loadk        r38   k46 ; k46 = 137
.line	699	loadk        r39   k47 ; k47 = 66
.line	699	loadk        r40   k48 ; k48 = 36
.line	699	loadk        r41   k49 ; k49 = 141
.line	699	loadk        r42   k50 ; k50 = 165
.line	699	loadk        r43   k51 ; k51 = 156
.line	699	loadk        r44   k52 ; k52 = 199
.line	699	loadk        r45   k53 ; k53 = 95
.line	699	loadk        r46   k54 ; k54 = 247
.line	699	loadk        r47   k29 ; k29 = 46
.line	699	loadk        r48   k55 ; k55 = 184
.line	699	call          r8    41     2
.line	699	getupval      r9    u2
.line	699	loadk        r10   k56 ; k56 = 101
.line	699	loadk        r11   k57 ; k57 = 155
.line	699	loadk        r12   k58 ; k58 = 239
.line	699	loadk        r13   k59 ; k59 = 217
.line	699	loadk        r14   k60 ; k60 = 185
.line	699	loadk        r15   k61 ; k61 = 202
.line	699	loadk        r16   k62 ; k62 = 122
.line	699	loadk        r17   k28 ; k28 = 148
.line	699	loadk        r18   k63 ; k63 = 63
.line	699	loadk        r19   k64 ; k64 = 110
.line	699	call          r9    11     0
.line	699	setlist       r7     0     1
.line	699	call          r6     2     2
.line	699	call          r5     2     2
.line	699	gettable      r6    r5   k65 ; k65 = "OpenBuyUI"
.line	699	call          r6     1     1
.line	699	return        r0     1
.line	699	jmp            0  l117
.label	l102
.line	699	eq             0    r1   k11 ; k11 = 3
.line	699	jmp            0  l117
.line	699	test          r2     0
.line	699	jmp            0  l109
.line	699	loadk         r5   k12 ; k12 = 2
.line	699	testset       r3    r5     1
.line	699	jmp            0  l110
.label	l109
.line	699	loadk         r3    k3 ; k3 = 0
.label	l110
.line	699	newtable      r5     0     4
.line	699	settable      r5    k6    r3 ; k6 = "nHasCardType"
.line	699	settable      r5    k7    k3 ; k3 = 0
.line	699	gettable      r6    r0   k66 ; k66 = "EliteBuyType"
.line	699	settable      r5    k8    r6 ; k8 = "nRawBuyType"
.line	699	settable      r5   k67   k68 ; k68 = true
.line	699	move          r4    r5
.label	l117
.line	699	gettabup      r5    u1   k69 ; k69 = "HandleBuyPopup"
.line	699	move          r6    r4
.line	699	call          r5     2     1
.line	699	return        r0     1
.line	699	move          r0    r0
.line	699	move          r0    r0
.line	699	move          r0    r0
.line	699	move          r0    r0
.line	699	return        r0     1

.function	main/f41

.source	null
.linedefined	735
.lastlinedefined	739
.numparams	1
.is_vararg	0
.maxstacksize	45

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"PlayAudio"
.constant	k1	"sound_config"
.constant	k2	"click_v1"
.constant	k3	"require"
.constant	k4	"table"
.constant	k5	"concat"
.constant	k6	105
.constant	k7	128
.constant	k8	246
.constant	k9	221
.constant	k10	164
.constant	k11	205
.constant	k12	11
.constant	k13	133
.constant	k14	38
.constant	k15	98
.constant	k16	148
.constant	k17	46
.constant	k18	150
.constant	k19	216
.constant	k20	89
.constant	k21	50
.constant	k22	153
.constant	k23	242
.constant	k24	154
.constant	k25	230
.constant	k26	81
.constant	k27	231
.constant	k28	58
.constant	k29	177
.constant	k30	5
.constant	k31	119
.constant	k32	132
.constant	k33	99
.constant	k34	137
.constant	k35	66
.constant	k36	36
.constant	k37	141
.constant	k38	165
.constant	k39	156
.constant	k40	199
.constant	k41	95
.constant	k42	247
.constant	k43	184
.constant	k44	101
.constant	k45	155
.constant	k46	239
.constant	k47	217
.constant	k48	185
.constant	k49	202
.constant	k50	122
.constant	k51	63
.constant	k52	110
.constant	k53	"OpenBuyUI"

.line	735	self          r1    r0    k0 ; k0 = "PlayAudio"
.line	735	gettabup      r3    u0    k1 ; k1 = "sound_config"
.line	735	gettable      r3    r3    k2 ; k2 = "click_v1"
.line	735	call          r1     3     1
.line	735	gettabup      r1    u0    k3 ; k3 = "require"
.line	735	gettabup      r2    u0    k4 ; k4 = "table"
.line	735	gettable      r2    r2    k5 ; k5 = "concat"
.line	735	newtable      r3     1     0
.line	735	getupval      r4    u1
.line	735	loadk         r5    k6 ; k6 = 105
.line	735	loadk         r6    k7 ; k7 = 128
.line	735	loadk         r7    k8 ; k8 = 246
.line	735	loadk         r8    k9 ; k9 = 221
.line	735	loadk         r9   k10 ; k10 = 164
.line	735	loadk        r10   k11 ; k11 = 205
.line	735	loadk        r11   k12 ; k12 = 11
.line	735	loadk        r12   k13 ; k13 = 133
.line	735	loadk        r13   k14 ; k14 = 38
.line	735	loadk        r14   k15 ; k15 = 98
.line	735	loadk        r15   k16 ; k16 = 148
.line	735	loadk        r16   k17 ; k17 = 46
.line	735	loadk        r17   k18 ; k18 = 150
.line	735	loadk        r18   k19 ; k19 = 216
.line	735	loadk        r19   k20 ; k20 = 89
.line	735	loadk        r20   k21 ; k21 = 50
.line	735	loadk        r21   k22 ; k22 = 153
.line	735	loadk        r22   k23 ; k23 = 242
.line	735	loadk        r23   k24 ; k24 = 154
.line	735	loadk        r24   k25 ; k25 = 230
.line	735	loadk        r25   k26 ; k26 = 81
.line	735	loadk        r26   k27 ; k27 = 231
.line	735	loadk        r27   k28 ; k28 = 58
.line	735	loadk        r28   k29 ; k29 = 177
.line	735	loadk        r29   k30 ; k30 = 5
.line	735	loadk        r30   k31 ; k31 = 119
.line	735	loadk        r31   k32 ; k32 = 132
.line	735	loadk        r32   k33 ; k33 = 99
.line	735	loadk        r33   k22 ; k22 = 153
.line	735	loadk        r34   k34 ; k34 = 137
.line	735	loadk        r35   k35 ; k35 = 66
.line	735	loadk        r36   k36 ; k36 = 36
.line	735	loadk        r37   k37 ; k37 = 141
.line	735	loadk        r38   k38 ; k38 = 165
.line	735	loadk        r39   k39 ; k39 = 156
.line	735	loadk        r40   k40 ; k40 = 199
.line	735	loadk        r41   k41 ; k41 = 95
.line	735	loadk        r42   k42 ; k42 = 247
.line	735	loadk        r43   k17 ; k17 = 46
.line	735	loadk        r44   k43 ; k43 = 184
.line	735	call          r4    41     2
.line	735	getupval      r5    u1
.line	735	loadk         r6   k44 ; k44 = 101
.line	735	loadk         r7   k45 ; k45 = 155
.line	735	loadk         r8   k46 ; k46 = 239
.line	735	loadk         r9   k47 ; k47 = 217
.line	735	loadk        r10   k48 ; k48 = 185
.line	735	loadk        r11   k49 ; k49 = 202
.line	735	loadk        r12   k50 ; k50 = 122
.line	735	loadk        r13   k16 ; k16 = 148
.line	735	loadk        r14   k51 ; k51 = 63
.line	735	loadk        r15   k52 ; k52 = 110
.line	735	call          r5    11     0
.line	735	setlist       r3     0     1
.line	735	call          r2     2     2
.line	735	call          r1     2     2
.line	735	gettable      r2    r1   k53 ; k53 = "OpenBuyUI"
.line	735	call          r2     1     1
.line	735	return        r0     1
.line	735	move          r0    r0
.line	735	move          r0    r0
.line	735	return        r0     1

.function	main/f42

.source	null
.linedefined	741
.lastlinedefined	751
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"ExperienceBuyType"
.constant	k1	0
.constant	k2	"SetTexture"
.constant	k3	"imageCard"
.constant	k4	"imageSuperCard"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	37
.constant	k8	171
.constant	k9	254
.constant	k10	213
.constant	k11	175
.constant	k12	150
.constant	k13	100
.constant	k14	132
.constant	k15	62
.constant	k16	218
.constant	k17	85
.constant	k18	179
.constant	k19	152
.constant	k20	106
.constant	k21	58
.constant	k22	176
.constant	k23	138
.constant	k24	193
.constant	k25	89
.constant	k26	230
.constant	k27	59
.constant	k28	181
.constant	k29	117
.constant	k30	78
.constant	k31	145
.constant	k32	135
.constant	k33	238
.constant	k34	77
.constant	k35	36
.constant	k36	227
.constant	k37	188
.constant	k38	237
.constant	k39	88
.constant	k40	235
.constant	k41	32
.constant	k42	184
.constant	k43	105
.constant	k44	149
.constant	k45	241
.constant	k46	169
.constant	k47	214
.constant	k48	75
.constant	k49	24
.constant	k50	71
.constant	k51	180
.constant	k52	95
.constant	k53	199
.constant	k54	41
.constant	k55	155
.constant	k56	215
.constant	k57	11
.constant	k58	187
.constant	k59	109
.constant	k60	232
.constant	k61	19
.constant	k62	126
.constant	k63	245
.constant	k64	10
.constant	k65	153
.constant	k66	143
.constant	k67	255
.constant	k68	248
.constant	k69	33
.constant	k70	221
.constant	k71	173
.constant	k72	128
.constant	k73	"_GetExperienceBuyState"
.constant	k74	"_DetermineExperienceBuyType"
.constant	k75	"log"
.constant	k76	"bWriteLog"
.constant	k77	72
.constant	k78	219
.constant	k79	161
.constant	k80	87
.constant	k81	159
.constant	k82	46
.constant	k83	118
.constant	k84	140
.constant	k85	168
.constant	k86	231
.constant	k87	97
.constant	k88	14
.constant	k89	158
.constant	k90	191
.constant	k91	178
.constant	k92	104
.constant	k93	236
.constant	k94	51
.constant	k95	63
.constant	k96	116
.constant	k97	141
.constant	k98	94
.constant	k99	133
.constant	k100	67
.constant	k101	42
.constant	k102	134
.constant	k103	142
.constant	k104	225
.constant	k105	43
.constant	k106	234
.constant	k107	192
.constant	k108	147
.constant	k109	112
.constant	k110	"tostring"
.constant	k111	"hasCardType"
.constant	k112	"_UpdateExperienceBuyDisplay"

.line	741	settable      r0    k0    k1 ; k1 = 0
.line	741	self          r2    r0    k2 ; k2 = "SetTexture"
.line	741	gettable      r4    r1    k3 ; k3 = "imageCard"
.line	741	getupval      r5    u0
.line	741	call          r2     4     1
.line	741	self          r2    r0    k2 ; k2 = "SetTexture"
.line	741	gettable      r4    r1    k4 ; k4 = "imageSuperCard"
.line	741	gettabup      r5    u1    k5 ; k5 = "table"
.line	741	gettable      r5    r5    k6 ; k6 = "concat"
.line	741	newtable      r6     2     0
.line	741	getupval      r7    u2
.line	741	loadk         r8    k7 ; k7 = 37
.line	741	loadk         r9    k8 ; k8 = 171
.line	741	loadk        r10    k9 ; k9 = 254
.line	741	loadk        r11   k10 ; k10 = 213
.line	741	loadk        r12   k11 ; k11 = 175
.line	741	loadk        r13   k12 ; k12 = 150
.line	741	loadk        r14   k13 ; k13 = 100
.line	741	loadk        r15   k14 ; k14 = 132
.line	741	loadk        r16   k15 ; k15 = 62
.line	741	loadk        r17   k13 ; k13 = 100
.line	741	loadk        r18   k16 ; k16 = 218
.line	741	loadk        r19   k17 ; k17 = 85
.line	741	loadk        r20   k18 ; k18 = 179
.line	741	loadk        r21   k19 ; k19 = 152
.line	741	loadk        r22   k20 ; k20 = 106
.line	741	loadk        r23   k21 ; k21 = 58
.line	741	loadk        r24   k19 ; k19 = 152
.line	741	loadk        r25   k22 ; k22 = 176
.line	741	loadk        r26   k23 ; k23 = 138
.line	741	loadk        r27   k24 ; k24 = 193
.line	741	loadk        r28   k25 ; k25 = 89
.line	741	loadk        r29   k26 ; k26 = 230
.line	741	loadk        r30   k27 ; k27 = 59
.line	741	loadk        r31   k28 ; k28 = 181
.line	741	loadk        r32   k29 ; k29 = 117
.line	741	loadk        r33   k30 ; k30 = 78
.line	741	loadk        r34   k31 ; k31 = 145
.line	741	loadk        r35   k29 ; k29 = 117
.line	741	loadk        r36   k32 ; k32 = 135
.line	741	loadk        r37   k33 ; k33 = 238
.line	741	loadk        r38   k34 ; k34 = 77
.line	741	loadk        r39   k35 ; k35 = 36
.line	741	loadk        r40   k14 ; k14 = 132
.line	741	loadk        r41   k36 ; k36 = 227
.line	741	loadk        r42   k37 ; k37 = 188
.line	741	loadk        r43   k38 ; k38 = 237
.line	741	loadk        r44   k39 ; k39 = 88
.line	741	loadk        r45   k40 ; k40 = 235
.line	741	loadk        r46   k41 ; k41 = 32
.line	741	loadk        r47   k42 ; k42 = 184
.line	741	call          r7    41     2
.line	741	getupval      r8    u2
.line	741	loadk         r9   k43 ; k43 = 105
.line	741	loadk        r10   k44 ; k44 = 149
.line	741	loadk        r11   k22 ; k22 = 176
.line	741	loadk        r12   k45 ; k45 = 241
.line	741	loadk        r13   k46 ; k46 = 169
.line	741	loadk        r14   k47 ; k47 = 214
.line	741	loadk        r15   k48 ; k48 = 75
.line	741	loadk        r16   k46 ; k46 = 169
.line	741	loadk        r17   k49 ; k49 = 24
.line	741	loadk        r18   k50 ; k50 = 71
.line	741	loadk        r19   k51 ; k51 = 180
.line	741	loadk        r20   k52 ; k52 = 95
.line	741	loadk        r21   k11 ; k11 = 175
.line	741	loadk        r22   k53 ; k53 = 199
.line	741	loadk        r23   k25 ; k25 = 89
.line	741	loadk        r24   k54 ; k54 = 41
.line	741	loadk        r25   k55 ; k55 = 155
.line	741	loadk        r26   k42 ; k42 = 184
.line	741	loadk        r27   k23 ; k23 = 138
.line	741	loadk        r28   k56 ; k56 = 215
.line	741	loadk        r29   k57 ; k57 = 11
.line	741	loadk        r30   k58 ; k58 = 187
.line	741	loadk        r31   k59 ; k59 = 109
.line	741	loadk        r32   k60 ; k60 = 232
.line	741	loadk        r33   k61 ; k61 = 19
.line	741	loadk        r34   k13 ; k13 = 100
.line	741	loadk        r35   k23 ; k23 = 138
.line	741	loadk        r36   k62 ; k62 = 126
.line	741	loadk        r37   k28 ; k28 = 181
.line	741	loadk        r38   k63 ; k63 = 245
.line	741	loadk        r39   k62 ; k62 = 126
.line	741	loadk        r40   k64 ; k64 = 10
.line	741	loadk        r41   k28 ; k28 = 181
.line	741	loadk        r42   k65 ; k65 = 153
.line	741	loadk        r43   k66 ; k66 = 143
.line	741	loadk        r44   k67 ; k67 = 255
.line	741	loadk        r45   k39 ; k39 = 88
.line	741	loadk        r46   k68 ; k68 = 248
.line	741	loadk        r47   k69 ; k69 = 33
.line	741	loadk        r48   k18 ; k18 = 179
.line	741	call          r8    41     2
.line	741	getupval      r9    u2
.line	741	loadk        r10   k17 ; k17 = 85
.line	741	loadk        r11   k70 ; k70 = 221
.line	741	loadk        r12   k71 ; k71 = 173
.line	741	loadk        r13   k72 ; k72 = 128
.line	741	call          r9     5     0
.line	741	setlist       r6     0     1
.line	741	call          r5     2     2
.line	741	call          r2     4     1
.line	741	self          r2    r0   k73 ; k73 = "_GetExperienceBuySta" (truncated)
.line	741	call          r2     2     2
.line	741	self          r3    r0   k74 ; k74 = "_DetermineExperience" (truncated)
.line	741	move          r5    r2
.line	741	call          r3     3     4
.line	741	gettabup      r6    u1   k75 ; k75 = "log"
.line	741	gettabup      r7    u1   k76 ; k76 = "bWriteLog"
.line	741	test          r7     0
.line	741	jmp            0  l175
.line	741	gettabup      r7    u1    k5 ; k5 = "table"
.line	741	gettable      r7    r7    k6 ; k6 = "concat"
.line	741	newtable      r8     1     0
.line	741	getupval      r9    u2
.line	741	loadk        r10   k77 ; k77 = 72
.line	741	loadk        r11   k72 ; k72 = 128
.line	741	loadk        r12    k9 ; k9 = 254
.line	741	loadk        r13   k78 ; k78 = 219
.line	741	loadk        r14   k79 ; k79 = 161
.line	741	loadk        r15   k67 ; k67 = 255
.line	741	loadk        r16   k80 ; k80 = 87
.line	741	loadk        r17   k81 ; k81 = 159
.line	741	loadk        r18   k82 ; k82 = 46
.line	741	loadk        r19   k83 ; k83 = 118
.line	741	loadk        r20   k84 ; k84 = 140
.line	741	loadk        r21   k52 ; k52 = 95
.line	741	loadk        r22   k85 ; k85 = 168
.line	741	loadk        r23   k86 ; k86 = 231
.line	741	loadk        r24   k87 ; k87 = 97
.line	741	loadk        r25   k88 ; k88 = 14
.line	741	loadk        r26   k18 ; k18 = 179
.line	741	loadk        r27   k89 ; k89 = 158
.line	741	loadk        r28   k90 ; k90 = 191
.line	741	loadk        r29   k91 ; k91 = 178
.line	741	loadk        r30   k92 ; k92 = 104
.line	741	loadk        r31   k93 ; k93 = 236
.line	741	loadk        r32   k94 ; k94 = 51
.line	741	loadk        r33   k51 ; k51 = 180
.line	741	loadk        r34   k95 ; k95 = 63
.line	741	loadk        r35   k96 ; k96 = 116
.line	741	loadk        r36   k97 ; k97 = 141
.line	741	loadk        r37   k98 ; k98 = 94
.line	741	loadk        r38   k99 ; k99 = 133
.line	741	loadk        r39   k10 ; k10 = 213
.line	741	loadk        r40  k100 ; k100 = 67
.line	741	loadk        r41  k101 ; k101 = 42
.line	741	loadk        r42  k102 ; k102 = 134
.line	741	loadk        r43  k103 ; k103 = 142
.line	741	loadk        r44   k23 ; k23 = 138
.line	741	loadk        r45  k104 ; k104 = 225
.line	741	loadk        r46   k92 ; k92 = 104
.line	741	loadk        r47   k38 ; k38 = 237
.line	741	loadk        r48  k105 ; k105 = 43
.line	741	loadk        r49   k68 ; k68 = 248
.line	741	call          r9    41     2
.line	741	getupval     r10    u2
.line	741	loadk        r11  k101 ; k101 = 42
.line	741	loadk        r12  k103 ; k103 = 142
.line	741	loadk        r13  k106 ; k106 = 234
.line	741	loadk        r14   k24 ; k24 = 193
.line	741	loadk        r15   k89 ; k89 = 158
.line	741	loadk        r16  k107 ; k107 = 192
.line	741	loadk        r17   k17 ; k17 = 85
.line	741	loadk        r18  k108 ; k108 = 147
.line	741	loadk        r19  k109 ; k109 = 112
.line	741	call         r10    10     0
.line	741	setlist       r8     0     1
.line	741	call          r7     2     2
.line	741	gettabup      r8    u1  k110 ; k110 = "tostring"
.line	741	move          r9    r3
.line	741	call          r8     2     2
.line	741	concat        r7    r7    r8
.label	l175
.line	741	call          r6     2     1
.line	741	testset       r6    r3     1
.line	741	jmp            0  l179
.line	741	loadk         r6    k1 ; k1 = 0
.label	l179
.line	741	settable      r0    k0    r6 ; k0 = "ExperienceBuyType"
.line	741	settable      r0  k111    r4 ; k111 = "hasCardType"
.line	741	self          r6    r0  k112 ; k112 = "_UpdateExperienceBuy" (truncated)
.line	741	move          r8    r3
.line	741	move          r9    r2
.line	741	move         r10    r5
.line	741	move         r11    r1
.line	741	call          r6     6     1
.line	741	return        r0     1
.line	741	move          r0    r0
.line	741	move          r0    r0
.line	741	return        r0     1

.function	main/f43

.source	null
.linedefined	753
.lastlinedefined	763
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	12	true
.upvalue	"U2"	11	true

.constant	k0	"bIsBuyElite"
.constant	k1	"UnknowPassSystem"
.constant	k2	"IsBuyElite"
.constant	k3	"bIsBuyEliteSeg2"
.constant	k4	"IsBuyEliteSeg2"
.constant	k5	"bIsPreBuy"
.constant	k6	"nPreBuyType"
.constant	k7	"Enum_PreBuyType"
.constant	k8	"None"
.constant	k9	"bHasNormalCard"
.constant	k10	"HasUpCard"
.constant	k11	"bHasExperienceCard"
.constant	k12	"HasExperienceCard"
.constant	k13	"bHasNewUserPrivlegesCard"
.constant	k14	"HasNewUserPrivlegesCard"

.line	753	newtable      r1     0     6
.line	753	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	753	gettable      r2    r2    k2 ; k2 = "IsBuyElite"
.line	753	settable      r1    k0    r2 ; k0 = "bIsBuyElite"
.line	753	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	753	gettable      r2    r2    k4 ; k4 = "IsBuyEliteSeg2"
.line	753	settable      r1    k3    r2 ; k3 = "bIsBuyEliteSeg2"
.line	753	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	753	gettable      r2    r2    k6 ; k6 = "nPreBuyType"
.line	753	gettabup      r3    u1    k7 ; k7 = "Enum_PreBuyType"
.line	753	gettable      r3    r3    k8 ; k8 = "None"
.line	753	eq             0    r2    r3
.line	753	jmp            0   l15
.line	753	loadbool      r2     0     1
.label	l15
.line	753	loadbool      r2     1     0
.line	753	settable      r1    k5    r2 ; k5 = "bIsPreBuy"
.line	753	gettabup      r2    u2   k10 ; k10 = "HasUpCard"
.line	753	loadbool      r3     1     0
.line	753	call          r2     2     2
.line	753	settable      r1    k9    r2 ; k9 = "bHasNormalCard"
.line	753	gettabup      r2    u2   k12 ; k12 = "HasExperienceCard"
.line	753	call          r2     1     2
.line	753	settable      r1   k11    r2 ; k11 = "bHasExperienceCard"
.line	753	gettabup      r2    u2   k14 ; k14 = "HasNewUserPrivlegesC" (truncated)
.line	753	call          r2     1     2
.line	753	settable      r1   k13    r2 ; k13 = "bHasNewUserPrivleges" (truncated)
.line	753	return        r1     2
.line	753	return        r0     1
.line	753	move          r0    r0
.line	753	move          r0    r0
.line	753	move          r0    r0
.line	753	return        r0     1

.function	main/f44

.source	null
.linedefined	765
.lastlinedefined	777
.numparams	2
.is_vararg	0
.maxstacksize	6

.upvalue	"_ENV"	13	true
.upvalue	"U1"	15	true
.upvalue	"U2"	11	true

.constant	k0	"bIsBuyElite"
.constant	k1	1
.constant	k2	"bHasExperienceCard"
.constant	k3	"BuyType40"
.constant	k4	2
.constant	k5	"bHasNewUserPrivlegesCard"
.constant	k6	"BuyType46"
.constant	k7	"GetBuyTypeWithCoupon"
.constant	k8	"BuyType1"

.line	765	gettable      r2    r1    k0 ; k0 = "bIsBuyElite"
.line	765	test          r2     0
.line	765	jmp            0    l8
.line	765	loadnil       r2     0
.line	765	loadk         r3    k1 ; k1 = 1
.line	765	loadnil       r4     0
.line	765	return        r2     4
.label	l8
.line	765	gettable      r2    r1    k2 ; k2 = "bHasExperienceCard"
.line	765	test          r2     0
.line	765	jmp            0   l15
.line	765	gettabup      r2    u0    k3 ; k3 = "BuyType40"
.line	765	loadk         r3    k4 ; k4 = 2
.line	765	loadnil       r4     0
.line	765	return        r2     4
.label	l15
.line	765	gettable      r2    r1    k5 ; k5 = "bHasNewUserPrivleges" (truncated)
.line	765	test          r2     0
.line	765	jmp            0   l22
.line	765	gettabup      r2    u0    k6 ; k6 = "BuyType46"
.line	765	loadk         r3    k4 ; k4 = 2
.line	765	getupval      r4    u1
.line	765	return        r2     4
.label	l22
.line	765	gettabup      r2    u2    k7 ; k7 = "GetBuyTypeWithCoupon"
.line	765	gettabup      r3    u0    k8 ; k8 = "BuyType1"
.line	765	call          r2     2     2
.line	765	move          r3    r2
.line	765	loadk         r4    k1 ; k1 = 1
.line	765	loadnil       r5     0
.line	765	return        r3     4
.line	765	return        r0     1
.line	765	move          r0    r0
.line	765	return        r0     1

.function	main/f45

.source	null
.linedefined	779
.lastlinedefined	805
.numparams	5
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	13	true
.upvalue	"U1"	11	true

.constant	k0	"SetTexture"
.constant	k1	"imageCard"
.constant	k2	"bIsBuyElite"
.constant	k3	"widgetSwitcherBuy"
.constant	k4	"SetActiveWidgetIndex"
.constant	k5	4
.constant	k6	"bIsPreBuy"
.constant	k7	"SetWidgetVisible"
.constant	k8	"root"
.constant	k9	"Text_PreBuyTip"
.constant	k10	"BuyType40"
.constant	k11	3
.constant	k12	"BuyType46"
.constant	k13	2
.constant	k14	"GetBuyConfigViaBuyType"
.constant	k15	"textPriceUc"
.constant	k16	"SetText"
.constant	k17	"Price2"
.constant	k18	"_SetExperiencePriceViaBuyType"

.line	779	test          r3     0
.line	779	jmp            0    l7
.line	779	self          r5    r0    k0 ; k0 = "SetTexture"
.line	779	gettable      r7    r4    k1 ; k1 = "imageCard"
.line	779	move          r8    r3
.line	779	call          r5     4     1
.label	l7
.line	779	gettable      r5    r2    k2 ; k2 = "bIsBuyElite"
.line	779	test          r5     0
.line	779	jmp            0   l15
.line	779	gettable      r5    r4    k3 ; k3 = "widgetSwitcherBuy"
.line	779	self          r5    r5    k4 ; k4 = "SetActiveWidgetIndex"
.line	779	loadk         r7    k5 ; k5 = 4
.line	779	call          r5     3     1
.line	779	return        r0     1
.label	l15
.line	779	gettable      r5    r2    k6 ; k6 = "bIsPreBuy"
.line	779	test          r5     0
.line	779	jmp            0   l24
.line	779	self          r5    r0    k7 ; k7 = "SetWidgetVisible"
.line	779	gettable      r7    r4    k8 ; k8 = "root"
.line	779	gettable      r7    r7    k9 ; k9 = "Text_PreBuyTip"
.line	779	loadbool      r8     1     0
.line	779	call          r5     4     1
.line	779	jmp            0   l29
.label	l24
.line	779	self          r5    r0    k7 ; k7 = "SetWidgetVisible"
.line	779	gettable      r7    r4    k8 ; k8 = "root"
.line	779	gettable      r7    r7    k9 ; k9 = "Text_PreBuyTip"
.line	779	loadbool      r8     0     0
.line	779	call          r5     4     1
.label	l29
.line	779	gettabup      r5    u0   k10 ; k10 = "BuyType40"
.line	779	eq             0    r1    r5
.line	779	jmp            0   l37
.line	779	gettable      r5    r4    k3 ; k3 = "widgetSwitcherBuy"
.line	779	self          r5    r5    k4 ; k4 = "SetActiveWidgetIndex"
.line	779	loadk         r7   k11 ; k11 = 3
.line	779	call          r5     3     1
.line	779	return        r0     1
.label	l37
.line	779	gettabup      r5    u0   k12 ; k12 = "BuyType46"
.line	779	eq             0    r1    r5
.line	779	jmp            0   l54
.line	779	gettable      r5    r4    k3 ; k3 = "widgetSwitcherBuy"
.line	779	self          r5    r5    k4 ; k4 = "SetActiveWidgetIndex"
.line	779	loadk         r7   k13 ; k13 = 2
.line	779	call          r5     3     1
.line	779	gettabup      r5    u1   k14 ; k14 = "GetBuyConfigViaBuyTy" (truncated)
.line	779	move          r6    r1
.line	779	call          r5     2     2
.line	779	test          r5     0
.line	779	jmp            0   l53
.line	779	gettable      r6    r4   k15 ; k15 = "textPriceUc"
.line	779	self          r6    r6   k16 ; k16 = "SetText"
.line	779	gettable      r8    r5   k17 ; k17 = "Price2"
.line	779	call          r6     3     1
.label	l53
.line	779	return        r0     1
.label	l54
.line	779	self          r5    r0   k18 ; k18 = "_SetExperiencePriceV" (truncated)
.line	779	move          r7    r1
.line	779	move          r8    r4
.line	779	call          r5     4     1
.line	779	return        r0     1
.line	779	move          r0    r0
.line	779	move          r0    r0
.line	779	return        r0     1

.function	main/f46

.source	null
.linedefined	807
.lastlinedefined	823
.numparams	3
.is_vararg	0
.maxstacksize	10

.upvalue	"_ENV"	11	true
.upvalue	"U1"	0	false

.constant	k0	"GetBuyConfigViaBuyType"
.constant	k1	7
.constant	k2	17
.constant	k3	"Price2"
.constant	k4	"Price1"
.constant	k5	"PriceDiscount2"
.constant	k6	"PriceDiscount1"
.constant	k7	"FuncUtil"
.constant	k8	"IsPlayerJPKR"
.constant	k9	"widgetSwitcherBuy"
.constant	k10	"SetActiveWidgetIndex"
.constant	k11	1
.constant	k12	"textOriginPrice"
.constant	k13	"SetText"
.constant	k14	"textDiscountPrice"
.constant	k15	0
.constant	k16	"textPrice"

.line	807	gettabup      r3    u0    k0 ; k0 = "GetBuyConfigViaBuyTy" (truncated)
.line	807	move          r4    r1
.line	807	call          r3     2     2
.line	807	test          r3     1
.line	807	jmp            0    l7
.line	807	return        r0     1
.label	l7
.line	807	le             0    k1    r1 ; k1 = 7
.line	807	jmp            0   l11
.line	807	le             1    r1    k2 ; k2 = 17
.line	807	jmp            0   l12
.label	l11
.line	807	loadbool      r4     0     1
.label	l12
.line	807	loadbool      r4     1     0
.line	807	test          r4     0
.line	807	jmp            0   l18
.line	807	gettable      r5    r3    k3 ; k3 = "Price2"
.line	807	test          r5     1
.line	807	jmp            0   l19
.label	l18
.line	807	gettable      r5    r3    k4 ; k4 = "Price1"
.label	l19
.line	807	test          r4     0
.line	807	jmp            0   l24
.line	807	gettable      r6    r3    k5 ; k5 = "PriceDiscount2"
.line	807	test          r6     1
.line	807	jmp            0   l25
.label	l24
.line	807	gettable      r6    r3    k6 ; k6 = "PriceDiscount1"
.label	l25
.line	807	gettabup      r7    u1    k7 ; k7 = "FuncUtil"
.line	807	gettable      r7    r7    k8 ; k8 = "IsPlayerJPKR"
.line	807	call          r7     1     2
.line	807	test          r7     1
.line	807	jmp            0   l45
.line	807	lt             0    r6    r5
.line	807	jmp            0   l45
.line	807	gettable      r7    r2    k9 ; k9 = "widgetSwitcherBuy"
.line	807	self          r7    r7   k10 ; k10 = "SetActiveWidgetIndex"
.line	807	loadk         r9   k11 ; k11 = 1
.line	807	call          r7     3     1
.line	807	gettable      r7    r2   k12 ; k12 = "textOriginPrice"
.line	807	self          r7    r7   k13 ; k13 = "SetText"
.line	807	move          r9    r5
.line	807	call          r7     3     1
.line	807	gettable      r7    r2   k14 ; k14 = "textDiscountPrice"
.line	807	self          r7    r7   k13 ; k13 = "SetText"
.line	807	move          r9    r6
.line	807	call          r7     3     1
.line	807	jmp            0   l53
.label	l45
.line	807	gettable      r7    r2    k9 ; k9 = "widgetSwitcherBuy"
.line	807	self          r7    r7   k10 ; k10 = "SetActiveWidgetIndex"
.line	807	loadk         r9   k15 ; k15 = 0
.line	807	call          r7     3     1
.line	807	gettable      r7    r2   k16 ; k16 = "textPrice"
.line	807	self          r7    r7   k13 ; k13 = "SetText"
.line	807	move          r9    r6
.line	807	call          r7     3     1
.label	l53
.line	807	return        r0     1
.line	807	move          r0    r0
.line	807	return        r0     1

.function	main/f47

.source	null
.linedefined	825
.lastlinedefined	838
.numparams	2
.is_vararg	0
.maxstacksize	50

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"NormalBuyType"
.constant	k1	0
.constant	k2	"isGift"
.constant	k3	"SetTexture"
.constant	k4	"imageCard"
.constant	k5	"imageSuperCard"
.constant	k6	"table"
.constant	k7	"concat"
.constant	k8	37
.constant	k9	171
.constant	k10	254
.constant	k11	213
.constant	k12	175
.constant	k13	150
.constant	k14	100
.constant	k15	132
.constant	k16	62
.constant	k17	218
.constant	k18	85
.constant	k19	179
.constant	k20	152
.constant	k21	106
.constant	k22	58
.constant	k23	176
.constant	k24	138
.constant	k25	193
.constant	k26	89
.constant	k27	230
.constant	k28	59
.constant	k29	181
.constant	k30	117
.constant	k31	78
.constant	k32	145
.constant	k33	135
.constant	k34	238
.constant	k35	77
.constant	k36	36
.constant	k37	227
.constant	k38	188
.constant	k39	237
.constant	k40	88
.constant	k41	235
.constant	k42	32
.constant	k43	184
.constant	k44	105
.constant	k45	149
.constant	k46	241
.constant	k47	169
.constant	k48	214
.constant	k49	75
.constant	k50	24
.constant	k51	71
.constant	k52	180
.constant	k53	95
.constant	k54	199
.constant	k55	41
.constant	k56	155
.constant	k57	215
.constant	k58	11
.constant	k59	187
.constant	k60	109
.constant	k61	232
.constant	k62	19
.constant	k63	126
.constant	k64	245
.constant	k65	10
.constant	k66	153
.constant	k67	143
.constant	k68	255
.constant	k69	248
.constant	k70	33
.constant	k71	221
.constant	k72	173
.constant	k73	128
.constant	k74	"_GetNormalBuyState"
.constant	k75	"_DetermineNormalBuyType"
.constant	k76	"log"
.constant	k77	"bWriteLog"
.constant	k78	72
.constant	k79	219
.constant	k80	161
.constant	k81	87
.constant	k82	159
.constant	k83	46
.constant	k84	118
.constant	k85	140
.constant	k86	168
.constant	k87	231
.constant	k88	97
.constant	k89	14
.constant	k90	158
.constant	k91	191
.constant	k92	178
.constant	k93	104
.constant	k94	236
.constant	k95	51
.constant	k96	63
.constant	k97	116
.constant	k98	141
.constant	k99	94
.constant	k100	133
.constant	k101	67
.constant	k102	42
.constant	k103	134
.constant	k104	142
.constant	k105	225
.constant	k106	43
.constant	k107	234
.constant	k108	192
.constant	k109	147
.constant	k110	112
.constant	k111	"tostring"
.constant	k112	"hasCardType"
.constant	k113	"_UpdateNormalBuyDisplay"

.line	825	settable      r0    k0    k1 ; k1 = 0
.line	825	gettable      r2    r0    k2 ; k2 = "isGift"
.line	825	test          r2     0
.line	825	jmp            0    l6
.line	825	return        r0     1
.label	l6
.line	825	self          r2    r0    k3 ; k3 = "SetTexture"
.line	825	gettable      r4    r1    k4 ; k4 = "imageCard"
.line	825	getupval      r5    u0
.line	825	call          r2     4     1
.line	825	self          r2    r0    k3 ; k3 = "SetTexture"
.line	825	gettable      r4    r1    k5 ; k5 = "imageSuperCard"
.line	825	gettabup      r5    u1    k6 ; k6 = "table"
.line	825	gettable      r5    r5    k7 ; k7 = "concat"
.line	825	newtable      r6     2     0
.line	825	getupval      r7    u2
.line	825	loadk         r8    k8 ; k8 = 37
.line	825	loadk         r9    k9 ; k9 = 171
.line	825	loadk        r10   k10 ; k10 = 254
.line	825	loadk        r11   k11 ; k11 = 213
.line	825	loadk        r12   k12 ; k12 = 175
.line	825	loadk        r13   k13 ; k13 = 150
.line	825	loadk        r14   k14 ; k14 = 100
.line	825	loadk        r15   k15 ; k15 = 132
.line	825	loadk        r16   k16 ; k16 = 62
.line	825	loadk        r17   k14 ; k14 = 100
.line	825	loadk        r18   k17 ; k17 = 218
.line	825	loadk        r19   k18 ; k18 = 85
.line	825	loadk        r20   k19 ; k19 = 179
.line	825	loadk        r21   k20 ; k20 = 152
.line	825	loadk        r22   k21 ; k21 = 106
.line	825	loadk        r23   k22 ; k22 = 58
.line	825	loadk        r24   k20 ; k20 = 152
.line	825	loadk        r25   k23 ; k23 = 176
.line	825	loadk        r26   k24 ; k24 = 138
.line	825	loadk        r27   k25 ; k25 = 193
.line	825	loadk        r28   k26 ; k26 = 89
.line	825	loadk        r29   k27 ; k27 = 230
.line	825	loadk        r30   k28 ; k28 = 59
.line	825	loadk        r31   k29 ; k29 = 181
.line	825	loadk        r32   k30 ; k30 = 117
.line	825	loadk        r33   k31 ; k31 = 78
.line	825	loadk        r34   k32 ; k32 = 145
.line	825	loadk        r35   k30 ; k30 = 117
.line	825	loadk        r36   k33 ; k33 = 135
.line	825	loadk        r37   k34 ; k34 = 238
.line	825	loadk        r38   k35 ; k35 = 77
.line	825	loadk        r39   k36 ; k36 = 36
.line	825	loadk        r40   k15 ; k15 = 132
.line	825	loadk        r41   k37 ; k37 = 227
.line	825	loadk        r42   k38 ; k38 = 188
.line	825	loadk        r43   k39 ; k39 = 237
.line	825	loadk        r44   k40 ; k40 = 88
.line	825	loadk        r45   k41 ; k41 = 235
.line	825	loadk        r46   k42 ; k42 = 32
.line	825	loadk        r47   k43 ; k43 = 184
.line	825	call          r7    41     2
.line	825	getupval      r8    u2
.line	825	loadk         r9   k44 ; k44 = 105
.line	825	loadk        r10   k45 ; k45 = 149
.line	825	loadk        r11   k23 ; k23 = 176
.line	825	loadk        r12   k46 ; k46 = 241
.line	825	loadk        r13   k47 ; k47 = 169
.line	825	loadk        r14   k48 ; k48 = 214
.line	825	loadk        r15   k49 ; k49 = 75
.line	825	loadk        r16   k47 ; k47 = 169
.line	825	loadk        r17   k50 ; k50 = 24
.line	825	loadk        r18   k51 ; k51 = 71
.line	825	loadk        r19   k52 ; k52 = 180
.line	825	loadk        r20   k53 ; k53 = 95
.line	825	loadk        r21   k12 ; k12 = 175
.line	825	loadk        r22   k54 ; k54 = 199
.line	825	loadk        r23   k26 ; k26 = 89
.line	825	loadk        r24   k55 ; k55 = 41
.line	825	loadk        r25   k56 ; k56 = 155
.line	825	loadk        r26   k43 ; k43 = 184
.line	825	loadk        r27   k24 ; k24 = 138
.line	825	loadk        r28   k57 ; k57 = 215
.line	825	loadk        r29   k58 ; k58 = 11
.line	825	loadk        r30   k59 ; k59 = 187
.line	825	loadk        r31   k60 ; k60 = 109
.line	825	loadk        r32   k61 ; k61 = 232
.line	825	loadk        r33   k62 ; k62 = 19
.line	825	loadk        r34   k14 ; k14 = 100
.line	825	loadk        r35   k24 ; k24 = 138
.line	825	loadk        r36   k63 ; k63 = 126
.line	825	loadk        r37   k29 ; k29 = 181
.line	825	loadk        r38   k64 ; k64 = 245
.line	825	loadk        r39   k63 ; k63 = 126
.line	825	loadk        r40   k65 ; k65 = 10
.line	825	loadk        r41   k29 ; k29 = 181
.line	825	loadk        r42   k66 ; k66 = 153
.line	825	loadk        r43   k67 ; k67 = 143
.line	825	loadk        r44   k68 ; k68 = 255
.line	825	loadk        r45   k40 ; k40 = 88
.line	825	loadk        r46   k69 ; k69 = 248
.line	825	loadk        r47   k70 ; k70 = 33
.line	825	loadk        r48   k19 ; k19 = 179
.line	825	call          r8    41     2
.line	825	getupval      r9    u2
.line	825	loadk        r10   k18 ; k18 = 85
.line	825	loadk        r11   k71 ; k71 = 221
.line	825	loadk        r12   k72 ; k72 = 173
.line	825	loadk        r13   k73 ; k73 = 128
.line	825	call          r9     5     0
.line	825	setlist       r6     0     1
.line	825	call          r5     2     2
.line	825	call          r2     4     1
.line	825	self          r2    r0   k74 ; k74 = "_GetNormalBuyState"
.line	825	call          r2     2     2
.line	825	self          r3    r0   k75 ; k75 = "_DetermineNormalBuyT" (truncated)
.line	825	move          r5    r2
.line	825	call          r3     3     4
.line	825	gettabup      r6    u1   k76 ; k76 = "log"
.line	825	gettabup      r7    u1   k77 ; k77 = "bWriteLog"
.line	825	test          r7     0
.line	825	jmp            0  l179
.line	825	gettabup      r7    u1    k6 ; k6 = "table"
.line	825	gettable      r7    r7    k7 ; k7 = "concat"
.line	825	newtable      r8     1     0
.line	825	getupval      r9    u2
.line	825	loadk        r10   k78 ; k78 = 72
.line	825	loadk        r11   k73 ; k73 = 128
.line	825	loadk        r12   k10 ; k10 = 254
.line	825	loadk        r13   k79 ; k79 = 219
.line	825	loadk        r14   k80 ; k80 = 161
.line	825	loadk        r15   k68 ; k68 = 255
.line	825	loadk        r16   k81 ; k81 = 87
.line	825	loadk        r17   k82 ; k82 = 159
.line	825	loadk        r18   k83 ; k83 = 46
.line	825	loadk        r19   k84 ; k84 = 118
.line	825	loadk        r20   k85 ; k85 = 140
.line	825	loadk        r21   k53 ; k53 = 95
.line	825	loadk        r22   k86 ; k86 = 168
.line	825	loadk        r23   k87 ; k87 = 231
.line	825	loadk        r24   k88 ; k88 = 97
.line	825	loadk        r25   k89 ; k89 = 14
.line	825	loadk        r26   k19 ; k19 = 179
.line	825	loadk        r27   k90 ; k90 = 158
.line	825	loadk        r28   k91 ; k91 = 191
.line	825	loadk        r29   k92 ; k92 = 178
.line	825	loadk        r30   k93 ; k93 = 104
.line	825	loadk        r31   k94 ; k94 = 236
.line	825	loadk        r32   k95 ; k95 = 51
.line	825	loadk        r33   k52 ; k52 = 180
.line	825	loadk        r34   k96 ; k96 = 63
.line	825	loadk        r35   k97 ; k97 = 116
.line	825	loadk        r36   k98 ; k98 = 141
.line	825	loadk        r37   k99 ; k99 = 94
.line	825	loadk        r38  k100 ; k100 = 133
.line	825	loadk        r39   k11 ; k11 = 213
.line	825	loadk        r40  k101 ; k101 = 67
.line	825	loadk        r41  k102 ; k102 = 42
.line	825	loadk        r42  k103 ; k103 = 134
.line	825	loadk        r43  k104 ; k104 = 142
.line	825	loadk        r44   k24 ; k24 = 138
.line	825	loadk        r45  k105 ; k105 = 225
.line	825	loadk        r46   k93 ; k93 = 104
.line	825	loadk        r47   k39 ; k39 = 237
.line	825	loadk        r48  k106 ; k106 = 43
.line	825	loadk        r49   k69 ; k69 = 248
.line	825	call          r9    41     2
.line	825	getupval     r10    u2
.line	825	loadk        r11  k102 ; k102 = 42
.line	825	loadk        r12  k104 ; k104 = 142
.line	825	loadk        r13  k107 ; k107 = 234
.line	825	loadk        r14   k25 ; k25 = 193
.line	825	loadk        r15   k90 ; k90 = 158
.line	825	loadk        r16  k108 ; k108 = 192
.line	825	loadk        r17   k18 ; k18 = 85
.line	825	loadk        r18  k109 ; k109 = 147
.line	825	loadk        r19  k110 ; k110 = 112
.line	825	call         r10    10     0
.line	825	setlist       r8     0     1
.line	825	call          r7     2     2
.line	825	gettabup      r8    u1  k111 ; k111 = "tostring"
.line	825	move          r9    r3
.line	825	call          r8     2     2
.line	825	concat        r7    r7    r8
.label	l179
.line	825	call          r6     2     1
.line	825	testset       r6    r3     1
.line	825	jmp            0  l183
.line	825	loadk         r6    k1 ; k1 = 0
.label	l183
.line	825	settable      r0    k0    r6 ; k0 = "NormalBuyType"
.line	825	settable      r0  k112    r4 ; k112 = "hasCardType"
.line	825	self          r6    r0  k113 ; k113 = "_UpdateNormalBuyDisp" (truncated)
.line	825	move          r8    r3
.line	825	move          r9    r2
.line	825	move         r10    r5
.line	825	move         r11    r1
.line	825	call          r6     6     1
.line	825	return        r0     1
.line	825	move          r0    r0
.line	825	return        r0     1

.function	main/f48

.source	null
.linedefined	840
.lastlinedefined	850
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	11	true

.constant	k0	"bIsBuyElite"
.constant	k1	"UnknowPassSystem"
.constant	k2	"IsBuyElite"
.constant	k3	"bIsBuyEliteSeg2"
.constant	k4	"IsBuyEliteSeg2"
.constant	k5	"bHasNormalCard"
.constant	k6	"HasUpCard"
.constant	k7	"bHasExperienceCard"
.constant	k8	"HasExperienceCard"
.constant	k9	"bHasNewUserPrivlegesCard"
.constant	k10	"HasNewUserPrivlegesCard"
.constant	k11	"bUseFirstBuyPrivilege"

.line	840	newtable      r1     0     6
.line	840	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	840	gettable      r2    r2    k2 ; k2 = "IsBuyElite"
.line	840	settable      r1    k0    r2 ; k0 = "bIsBuyElite"
.line	840	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	840	gettable      r2    r2    k4 ; k4 = "IsBuyEliteSeg2"
.line	840	settable      r1    k3    r2 ; k3 = "bIsBuyEliteSeg2"
.line	840	gettabup      r2    u1    k6 ; k6 = "HasUpCard"
.line	840	loadbool      r3     1     0
.line	840	call          r2     2     2
.line	840	settable      r1    k5    r2 ; k5 = "bHasNormalCard"
.line	840	gettabup      r2    u1    k8 ; k8 = "HasExperienceCard"
.line	840	call          r2     1     2
.line	840	settable      r1    k7    r2 ; k7 = "bHasExperienceCard"
.line	840	gettabup      r2    u1   k10 ; k10 = "HasNewUserPrivlegesC" (truncated)
.line	840	call          r2     1     2
.line	840	settable      r1    k9    r2 ; k9 = "bHasNewUserPrivleges" (truncated)
.line	840	gettable      r2    r0   k11 ; k11 = "bUseFirstBuyPrivileg" (truncated)
.line	840	settable      r1   k11    r2 ; k11 = "bUseFirstBuyPrivileg" (truncated)
.line	840	return        r1     2
.line	840	return        r0     1
.line	840	move          r0    r0
.line	840	move          r0    r0
.line	840	return        r0     1

.function	main/f49

.source	null
.linedefined	852
.lastlinedefined	878
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	13	true
.upvalue	"U1"	15	true

.constant	k0	"bIsBuyElite"
.constant	k1	"bIsBuyEliteSeg2"
.constant	k2	0
.constant	k3	"bHasNormalCard"
.constant	k4	"BuyType23"
.constant	k5	"BuyType18"
.constant	k6	"bUseFirstBuyPrivilege"
.constant	k7	"bHasNewUserPrivlegesCard"
.constant	k8	"BuyType45"
.constant	k9	3
.constant	k10	"BuyType44"
.constant	k11	"BuyType4"
.constant	k12	"BuyType47"
.constant	k13	"bHasExperienceCard"
.constant	k14	"BuyType41"
.constant	k15	"BuyType2"

.line	852	gettable      r2    r1    k0 ; k0 = "bIsBuyElite"
.line	852	test          r2     0
.line	852	jmp            0   l22
.line	852	gettable      r2    r1    k1 ; k1 = "bIsBuyEliteSeg2"
.line	852	test          r2     0
.line	852	jmp            0   l11
.line	852	loadnil       r2     0
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	loadnil       r4     0
.line	852	return        r2     4
.label	l11
.line	852	gettable      r2    r1    k3 ; k3 = "bHasNormalCard"
.line	852	test          r2     0
.line	852	jmp            0   l18
.line	852	gettabup      r2    u0    k4 ; k4 = "BuyType23"
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	loadnil       r4     0
.line	852	return        r2     4
.label	l18
.line	852	gettabup      r2    u0    k5 ; k5 = "BuyType18"
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	loadnil       r4     0
.line	852	return        r2     4
.label	l22
.line	852	gettable      r2    r1    k6 ; k6 = "bUseFirstBuyPrivileg" (truncated)
.line	852	test          r2     0
.line	852	jmp            0   l36
.line	852	gettable      r2    r1    k7 ; k7 = "bHasNewUserPrivleges" (truncated)
.line	852	test          r2     0
.line	852	jmp            0   l32
.line	852	gettabup      r2    u0    k8 ; k8 = "BuyType45"
.line	852	loadk         r3    k9 ; k9 = 3
.line	852	getupval      r4    u1
.line	852	return        r2     4
.label	l32
.line	852	gettabup      r2    u0   k10 ; k10 = "BuyType44"
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	loadnil       r4     0
.line	852	return        r2     4
.label	l36
.line	852	gettable      r2    r1    k3 ; k3 = "bHasNormalCard"
.line	852	test          r2     0
.line	852	jmp            0   l43
.line	852	gettabup      r2    u0   k11 ; k11 = "BuyType4"
.line	852	loadk         r3    k9 ; k9 = 3
.line	852	loadnil       r4     0
.line	852	return        r2     4
.label	l43
.line	852	gettable      r2    r1    k7 ; k7 = "bHasNewUserPrivleges" (truncated)
.line	852	test          r2     0
.line	852	jmp            0   l50
.line	852	gettabup      r2    u0   k12 ; k12 = "BuyType47"
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	getupval      r4    u1
.line	852	return        r2     4
.label	l50
.line	852	gettable      r2    r1   k13 ; k13 = "bHasExperienceCard"
.line	852	test          r2     0
.line	852	jmp            0   l57
.line	852	gettabup      r2    u0   k14 ; k14 = "BuyType41"
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	loadnil       r4     0
.line	852	return        r2     4
.label	l57
.line	852	gettabup      r2    u0   k15 ; k15 = "BuyType2"
.line	852	loadk         r3    k2 ; k2 = 0
.line	852	loadnil       r4     0
.line	852	return        r2     4
.line	852	return        r0     1
.line	852	move          r0    r0
.line	852	move          r0    r0
.line	852	return        r0     1

.function	main/f50

.source	null
.linedefined	880
.lastlinedefined	925
.numparams	5
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	13	true
.upvalue	"U1"	0	false
.upvalue	"U2"	11	true

.constant	k0	"SetTexture"
.constant	k1	"imageCard"
.constant	k2	"bIsBuyElite"
.constant	k3	"bIsBuyEliteSeg2"
.constant	k4	"widgetSwitcherBuy"
.constant	k5	"SetActiveWidgetIndex"
.constant	k6	4
.constant	k7	"BuyType23"
.constant	k8	3
.constant	k9	0
.constant	k10	"SetNormalPriceViaBuyType"
.constant	k11	"bUseFirstBuyPrivilege"
.constant	k12	"bHasNewUserPrivlegesCard"
.constant	k13	5
.constant	k14	"root"
.constant	k15	"TextBlock_NewUserOriginalPrice"
.constant	k16	"SetText"
.constant	k17	720
.constant	k18	"TextBlock_NewUserDiscountPrice"
.constant	k19	60
.constant	k20	"TextBlock_NewUserBuy"
.constant	k21	"LocUtil"
.constant	k22	"GetLocalizeResStr"
.constant	k23	87305
.constant	k24	"BuyType4"
.constant	k25	"BuyType45"
.constant	k26	"BuyType47"
.constant	k27	"BuyType41"
.constant	k28	2
.constant	k29	"GetBuyConfigViaBuyType"
.constant	k30	"textPriceUc"
.constant	k31	"Price2"
.constant	k32	"BuyType44"
.constant	k33	"textPrice"
.constant	k34	"Price1"

.line	880	test          r3     0
.line	880	jmp            0    l7
.line	880	self          r5    r0    k0 ; k0 = "SetTexture"
.line	880	gettable      r7    r4    k1 ; k1 = "imageCard"
.line	880	move          r8    r3
.line	880	call          r5     4     1
.label	l7
.line	880	gettable      r5    r2    k2 ; k2 = "bIsBuyElite"
.line	880	test          r5     0
.line	880	jmp            0   l35
.line	880	gettable      r5    r2    k3 ; k3 = "bIsBuyEliteSeg2"
.line	880	test          r5     0
.line	880	jmp            0   l18
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7    k6 ; k6 = 4
.line	880	call          r5     3     1
.line	880	return        r0     1
.label	l18
.line	880	gettabup      r5    u0    k7 ; k7 = "BuyType23"
.line	880	eq             0    r1    r5
.line	880	jmp            0   l26
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7    k8 ; k8 = 3
.line	880	call          r5     3     1
.line	880	jmp            0   l34
.label	l26
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7    k9 ; k9 = 0
.line	880	call          r5     3     1
.line	880	self          r5    r0   k10 ; k10 = "SetNormalPriceViaBuy" (truncated)
.line	880	move          r7    r1
.line	880	move          r8    r4
.line	880	call          r5     4     1
.label	l34
.line	880	return        r0     1
.label	l35
.line	880	gettable      r5    r0   k11 ; k11 = "bUseFirstBuyPrivileg" (truncated)
.line	880	test          r5     0
.line	880	jmp            0   l64
.line	880	gettable      r5    r2   k12 ; k12 = "bHasNewUserPrivleges" (truncated)
.line	880	test          r5     1
.line	880	jmp            0   l64
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7   k13 ; k13 = 5
.line	880	call          r5     3     1
.line	880	gettable      r5    r4   k14 ; k14 = "root"
.line	880	gettable      r5    r5   k15 ; k15 = "TextBlock_NewUserOri" (truncated)
.line	880	self          r5    r5   k16 ; k16 = "SetText"
.line	880	loadk         r7   k17 ; k17 = 720
.line	880	call          r5     3     1
.line	880	gettable      r5    r4   k14 ; k14 = "root"
.line	880	gettable      r5    r5   k18 ; k18 = "TextBlock_NewUserDis" (truncated)
.line	880	self          r5    r5   k16 ; k16 = "SetText"
.line	880	loadk         r7   k19 ; k19 = 60
.line	880	call          r5     3     1
.line	880	gettable      r5    r4   k14 ; k14 = "root"
.line	880	gettable      r5    r5   k20 ; k20 = "TextBlock_NewUserBuy"
.line	880	self          r5    r5   k16 ; k16 = "SetText"
.line	880	gettabup      r7    u1   k21 ; k21 = "LocUtil"
.line	880	gettable      r7    r7   k22 ; k22 = "GetLocalizeResStr"
.line	880	loadk         r8   k23 ; k23 = 87305
.line	880	call          r7     2     0
.line	880	call          r5     0     1
.line	880	return        r0     1
.label	l64
.line	880	gettabup      r5    u0   k24 ; k24 = "BuyType4"
.line	880	eq             1    r1    r5
.line	880	jmp            0   l70
.line	880	gettabup      r5    u0   k25 ; k25 = "BuyType45"
.line	880	eq             0    r1    r5
.line	880	jmp            0   l75
.label	l70
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7    k8 ; k8 = 3
.line	880	call          r5     3     1
.line	880	return        r0     1
.label	l75
.line	880	gettabup      r5    u0   k26 ; k26 = "BuyType47"
.line	880	eq             1    r1    r5
.line	880	jmp            0   l81
.line	880	gettabup      r5    u0   k27 ; k27 = "BuyType41"
.line	880	eq             0    r1    r5
.line	880	jmp            0   l95
.label	l81
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7   k28 ; k28 = 2
.line	880	call          r5     3     1
.line	880	gettabup      r5    u2   k29 ; k29 = "GetBuyConfigViaBuyTy" (truncated)
.line	880	move          r6    r1
.line	880	call          r5     2     2
.line	880	test          r5     0
.line	880	jmp            0   l94
.line	880	gettable      r6    r4   k30 ; k30 = "textPriceUc"
.line	880	self          r6    r6   k16 ; k16 = "SetText"
.line	880	gettable      r8    r5   k31 ; k31 = "Price2"
.line	880	call          r6     3     1
.label	l94
.line	880	return        r0     1
.label	l95
.line	880	gettabup      r5    u0   k32 ; k32 = "BuyType44"
.line	880	eq             0    r1    r5
.line	880	jmp            0  l112
.line	880	gettable      r5    r4    k4 ; k4 = "widgetSwitcherBuy"
.line	880	self          r5    r5    k5 ; k5 = "SetActiveWidgetIndex"
.line	880	loadk         r7    k9 ; k9 = 0
.line	880	call          r5     3     1
.line	880	gettabup      r5    u2   k29 ; k29 = "GetBuyConfigViaBuyTy" (truncated)
.line	880	move          r6    r1
.line	880	call          r5     2     2
.line	880	test          r5     0
.line	880	jmp            0  l111
.line	880	gettable      r6    r4   k33 ; k33 = "textPrice"
.line	880	self          r6    r6   k16 ; k16 = "SetText"
.line	880	gettable      r8    r5   k34 ; k34 = "Price1"
.line	880	call          r6     3     1
.label	l111
.line	880	return        r0     1
.label	l112
.line	880	self          r5    r0   k10 ; k10 = "SetNormalPriceViaBuy" (truncated)
.line	880	move          r7    r1
.line	880	move          r8    r4
.line	880	call          r5     4     1
.line	880	return        r0     1
.line	880	move          r0    r0
.line	880	return        r0     1

.function	main/f51

.source	null
.linedefined	927
.lastlinedefined	947
.numparams	3
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	11	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetBuyConfigViaBuyType"
.constant	k1	"log"
.constant	k2	"bWriteLog"
.constant	k3	81
.constant	k4	174
.constant	k5	243
.constant	k6	217
.constant	k7	169
.constant	k8	210
.constant	k9	99
.constant	k10	132
.constant	k11	35
.constant	k12	115
.constant	k13	148
.constant	k14	121
.constant	k15	165
.constant	k16	229
.constant	k17	110
.constant	k18	4
.constant	k19	175
.constant	k20	149
.constant	k21	173
.constant	k22	216
.constant	k23	103
.constant	k24	59
.constant	k25	54
.constant	k26	39
.constant	k27	135
.constant	k28	101
.constant	k29	147
.constant	k30	77
.constant	k31	36
.constant	k32	170
.constant	k33	150
.constant	k34	255
.constant	k35	16
.constant	k36	185
.constant	k37	"tostring"
.constant	k38	7
.constant	k39	17
.constant	k40	"Price2"
.constant	k41	"Price1"
.constant	k42	"PriceDiscount2"
.constant	k43	"PriceDiscount1"
.constant	k44	"FuncUtil"
.constant	k45	"IsPlayerJPKR"
.constant	k46	"widgetSwitcherBuy"
.constant	k47	"SetActiveWidgetIndex"
.constant	k48	1
.constant	k49	"textOriginPrice"
.constant	k50	"SetText"
.constant	k51	"textDiscountPrice"
.constant	k52	0
.constant	k53	"textPrice"

.line	927	gettabup      r3    u0    k0 ; k0 = "GetBuyConfigViaBuyTy" (truncated)
.line	927	move          r4    r1
.line	927	call          r3     2     2
.line	927	test          r3     1
.line	927	jmp            0   l56
.line	927	gettabup      r4    u1    k1 ; k1 = "log"
.line	927	gettabup      r5    u1    k2 ; k2 = "bWriteLog"
.line	927	test          r5     0
.line	927	jmp            0   l54
.line	927	getupval      r5    u2
.line	927	loadk         r6    k3 ; k3 = 81
.line	927	loadk         r7    k4 ; k4 = 174
.line	927	loadk         r8    k5 ; k5 = 243
.line	927	loadk         r9    k6 ; k6 = 217
.line	927	loadk        r10    k7 ; k7 = 169
.line	927	loadk        r11    k8 ; k8 = 210
.line	927	loadk        r12    k9 ; k9 = 99
.line	927	loadk        r13   k10 ; k10 = 132
.line	927	loadk        r14   k11 ; k11 = 35
.line	927	loadk        r15   k12 ; k12 = 115
.line	927	loadk        r16   k13 ; k13 = 148
.line	927	loadk        r17   k14 ; k14 = 121
.line	927	loadk        r18   k15 ; k15 = 165
.line	927	loadk        r19   k16 ; k16 = 229
.line	927	loadk        r20   k17 ; k17 = 110
.line	927	loadk        r21   k18 ; k18 = 4
.line	927	loadk        r22   k19 ; k19 = 175
.line	927	loadk        r23   k20 ; k20 = 149
.line	927	loadk        r24   k21 ; k21 = 173
.line	927	loadk        r25   k22 ; k22 = 216
.line	927	loadk        r26   k23 ; k23 = 103
.line	927	loadk        r27    k7 ; k7 = 169
.line	927	loadk        r28   k24 ; k24 = 59
.line	927	loadk        r29   k19 ; k19 = 175
.line	927	loadk        r30   k25 ; k25 = 54
.line	927	loadk        r31   k26 ; k26 = 39
.line	927	loadk        r32   k27 ; k27 = 135
.line	927	loadk        r33   k28 ; k28 = 101
.line	927	loadk        r34   k29 ; k29 = 147
.line	927	loadk        r35   k27 ; k27 = 135
.line	927	loadk        r36   k30 ; k30 = 77
.line	927	loadk        r37   k31 ; k31 = 36
.line	927	loadk        r38   k10 ; k10 = 132
.line	927	loadk        r39   k32 ; k32 = 170
.line	927	loadk        r40   k33 ; k33 = 150
.line	927	loadk        r41   k34 ; k34 = 255
.line	927	loadk        r42   k35 ; k35 = 16
.line	927	loadk        r43   k36 ; k36 = 185
.line	927	call          r5    39     2
.line	927	gettabup      r6    u1   k37 ; k37 = "tostring"
.line	927	move          r7    r1
.line	927	call          r6     2     2
.line	927	concat        r5    r5    r6
.label	l54
.line	927	call          r4     2     1
.line	927	return        r0     1
.label	l56
.line	927	loadbool      r4     0     0
.line	927	le             0   k38    r1 ; k38 = 7
.line	927	jmp            0   l62
.line	927	le             0    r1   k39 ; k39 = 17
.line	927	jmp            0   l62
.line	927	loadbool      r4     1     0
.label	l62
.line	927	test          r4     0
.line	927	jmp            0   l67
.line	927	gettable      r5    r3   k40 ; k40 = "Price2"
.line	927	test          r5     1
.line	927	jmp            0   l68
.label	l67
.line	927	gettable      r5    r3   k41 ; k41 = "Price1"
.label	l68
.line	927	test          r4     0
.line	927	jmp            0   l73
.line	927	gettable      r6    r3   k42 ; k42 = "PriceDiscount2"
.line	927	test          r6     1
.line	927	jmp            0   l74
.label	l73
.line	927	gettable      r6    r3   k43 ; k43 = "PriceDiscount1"
.label	l74
.line	927	gettabup      r7    u1   k44 ; k44 = "FuncUtil"
.line	927	gettable      r7    r7   k45 ; k45 = "IsPlayerJPKR"
.line	927	call          r7     1     2
.line	927	test          r7     1
.line	927	jmp            0   l94
.line	927	lt             0    r6    r5
.line	927	jmp            0   l94
.line	927	gettable      r7    r2   k46 ; k46 = "widgetSwitcherBuy"
.line	927	self          r7    r7   k47 ; k47 = "SetActiveWidgetIndex"
.line	927	loadk         r9   k48 ; k48 = 1
.line	927	call          r7     3     1
.line	927	gettable      r7    r2   k49 ; k49 = "textOriginPrice"
.line	927	self          r7    r7   k50 ; k50 = "SetText"
.line	927	move          r9    r5
.line	927	call          r7     3     1
.line	927	gettable      r7    r2   k51 ; k51 = "textDiscountPrice"
.line	927	self          r7    r7   k50 ; k50 = "SetText"
.line	927	move          r9    r6
.line	927	call          r7     3     1
.line	927	jmp            0  l102
.label	l94
.line	927	gettable      r7    r2   k46 ; k46 = "widgetSwitcherBuy"
.line	927	self          r7    r7   k47 ; k47 = "SetActiveWidgetIndex"
.line	927	loadk         r9   k52 ; k52 = 0
.line	927	call          r7     3     1
.line	927	gettable      r7    r2   k53 ; k53 = "textPrice"
.line	927	self          r7    r7   k50 ; k50 = "SetText"
.line	927	move          r9    r6
.line	927	call          r7     3     1
.label	l102
.line	927	return        r0     1
.line	927	move          r0    r0
.line	927	return        r0     1

.function	main/f52

.source	null
.linedefined	949
.lastlinedefined	958
.numparams	2
.is_vararg	0
.maxstacksize	49

.upvalue	"_ENV"	14	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"EliteBuyType"
.constant	k1	0
.constant	k2	"SetTexture"
.constant	k3	"imageCard"
.constant	k4	"imageSuperCard"
.constant	k5	"table"
.constant	k6	"concat"
.constant	k7	37
.constant	k8	171
.constant	k9	254
.constant	k10	213
.constant	k11	175
.constant	k12	150
.constant	k13	100
.constant	k14	132
.constant	k15	62
.constant	k16	218
.constant	k17	85
.constant	k18	179
.constant	k19	152
.constant	k20	106
.constant	k21	58
.constant	k22	176
.constant	k23	138
.constant	k24	193
.constant	k25	89
.constant	k26	230
.constant	k27	59
.constant	k28	181
.constant	k29	117
.constant	k30	78
.constant	k31	145
.constant	k32	135
.constant	k33	238
.constant	k34	77
.constant	k35	36
.constant	k36	227
.constant	k37	188
.constant	k38	237
.constant	k39	88
.constant	k40	235
.constant	k41	32
.constant	k42	184
.constant	k43	105
.constant	k44	149
.constant	k45	241
.constant	k46	169
.constant	k47	214
.constant	k48	75
.constant	k49	24
.constant	k50	71
.constant	k51	180
.constant	k52	95
.constant	k53	199
.constant	k54	41
.constant	k55	155
.constant	k56	216
.constant	k57	86
.constant	k58	252
.constant	k59	38
.constant	k60	153
.constant	k61	107
.constant	k62	53
.constant	k63	221
.constant	k64	163
.constant	k65	196
.constant	k66	65
.constant	k67	158
.constant	k68	217
.constant	k69	204
.constant	k70	177
.constant	k71	120
.constant	k72	141
.constant	k73	251
.constant	k74	154
.constant	k75	80
.constant	k76	133
.constant	k77	21
.constant	k78	56
.constant	k79	"_GetEliteBuyState"
.constant	k80	"_DetermineEliteBuyType"
.constant	k81	"log"
.constant	k82	"bWriteLog"
.constant	k83	72
.constant	k84	128
.constant	k85	219
.constant	k86	161
.constant	k87	255
.constant	k88	87
.constant	k89	159
.constant	k90	46
.constant	k91	118
.constant	k92	140
.constant	k93	168
.constant	k94	231
.constant	k95	97
.constant	k96	14
.constant	k97	191
.constant	k98	178
.constant	k99	104
.constant	k100	236
.constant	k101	51
.constant	k102	63
.constant	k103	116
.constant	k104	134
.constant	k105	206
.constant	k106	90
.constant	k107	185
.constant	k108	94
.constant	k109	247
.constant	k110	246
.constant	k111	201
.constant	k112	64
.constant	k113	"tostring"
.constant	k114	"_UpdateEliteBuyDisplay"

.line	949	settable      r0    k0    k1 ; k1 = 0
.line	949	self          r2    r0    k2 ; k2 = "SetTexture"
.line	949	gettable      r4    r1    k3 ; k3 = "imageCard"
.line	949	getupval      r5    u0
.line	949	call          r2     4     1
.line	949	self          r2    r0    k2 ; k2 = "SetTexture"
.line	949	gettable      r4    r1    k4 ; k4 = "imageSuperCard"
.line	949	gettabup      r5    u1    k5 ; k5 = "table"
.line	949	gettable      r5    r5    k6 ; k6 = "concat"
.line	949	newtable      r6     2     0
.line	949	getupval      r7    u2
.line	949	loadk         r8    k7 ; k7 = 37
.line	949	loadk         r9    k8 ; k8 = 171
.line	949	loadk        r10    k9 ; k9 = 254
.line	949	loadk        r11   k10 ; k10 = 213
.line	949	loadk        r12   k11 ; k11 = 175
.line	949	loadk        r13   k12 ; k12 = 150
.line	949	loadk        r14   k13 ; k13 = 100
.line	949	loadk        r15   k14 ; k14 = 132
.line	949	loadk        r16   k15 ; k15 = 62
.line	949	loadk        r17   k13 ; k13 = 100
.line	949	loadk        r18   k16 ; k16 = 218
.line	949	loadk        r19   k17 ; k17 = 85
.line	949	loadk        r20   k18 ; k18 = 179
.line	949	loadk        r21   k19 ; k19 = 152
.line	949	loadk        r22   k20 ; k20 = 106
.line	949	loadk        r23   k21 ; k21 = 58
.line	949	loadk        r24   k19 ; k19 = 152
.line	949	loadk        r25   k22 ; k22 = 176
.line	949	loadk        r26   k23 ; k23 = 138
.line	949	loadk        r27   k24 ; k24 = 193
.line	949	loadk        r28   k25 ; k25 = 89
.line	949	loadk        r29   k26 ; k26 = 230
.line	949	loadk        r30   k27 ; k27 = 59
.line	949	loadk        r31   k28 ; k28 = 181
.line	949	loadk        r32   k29 ; k29 = 117
.line	949	loadk        r33   k30 ; k30 = 78
.line	949	loadk        r34   k31 ; k31 = 145
.line	949	loadk        r35   k29 ; k29 = 117
.line	949	loadk        r36   k32 ; k32 = 135
.line	949	loadk        r37   k33 ; k33 = 238
.line	949	loadk        r38   k34 ; k34 = 77
.line	949	loadk        r39   k35 ; k35 = 36
.line	949	loadk        r40   k14 ; k14 = 132
.line	949	loadk        r41   k36 ; k36 = 227
.line	949	loadk        r42   k37 ; k37 = 188
.line	949	loadk        r43   k38 ; k38 = 237
.line	949	loadk        r44   k39 ; k39 = 88
.line	949	loadk        r45   k40 ; k40 = 235
.line	949	loadk        r46   k41 ; k41 = 32
.line	949	loadk        r47   k42 ; k42 = 184
.line	949	call          r7    41     2
.line	949	getupval      r8    u2
.line	949	loadk         r9   k43 ; k43 = 105
.line	949	loadk        r10   k44 ; k44 = 149
.line	949	loadk        r11   k22 ; k22 = 176
.line	949	loadk        r12   k45 ; k45 = 241
.line	949	loadk        r13   k46 ; k46 = 169
.line	949	loadk        r14   k47 ; k47 = 214
.line	949	loadk        r15   k48 ; k48 = 75
.line	949	loadk        r16   k46 ; k46 = 169
.line	949	loadk        r17   k49 ; k49 = 24
.line	949	loadk        r18   k50 ; k50 = 71
.line	949	loadk        r19   k51 ; k51 = 180
.line	949	loadk        r20   k52 ; k52 = 95
.line	949	loadk        r21   k11 ; k11 = 175
.line	949	loadk        r22   k53 ; k53 = 199
.line	949	loadk        r23   k25 ; k25 = 89
.line	949	loadk        r24   k54 ; k54 = 41
.line	949	loadk        r25   k55 ; k55 = 155
.line	949	loadk        r26   k42 ; k42 = 184
.line	949	loadk        r27   k23 ; k23 = 138
.line	949	loadk        r28   k56 ; k56 = 216
.line	949	loadk        r29   k57 ; k57 = 86
.line	949	loadk        r30   k58 ; k58 = 252
.line	949	loadk        r31   k59 ; k59 = 38
.line	949	loadk        r32   k60 ; k60 = 153
.line	949	loadk        r33   k61 ; k61 = 107
.line	949	loadk        r34   k62 ; k62 = 53
.line	949	loadk        r35   k63 ; k63 = 221
.line	949	loadk        r36   k15 ; k15 = 62
.line	949	loadk        r37   k64 ; k64 = 163
.line	949	loadk        r38   k65 ; k65 = 196
.line	949	loadk        r39   k66 ; k66 = 65
.line	949	loadk        r40    k7 ; k7 = 37
.line	949	loadk        r41   k28 ; k28 = 181
.line	949	loadk        r42   k67 ; k67 = 158
.line	949	loadk        r43   k11 ; k11 = 175
.line	949	loadk        r44   k68 ; k68 = 217
.line	949	loadk        r45   k29 ; k29 = 117
.line	949	loadk        r46   k69 ; k69 = 204
.line	949	loadk        r47   k62 ; k62 = 53
.line	949	loadk        r48   k70 ; k70 = 177
.line	949	call          r8    41     2
.line	949	getupval      r9    u2
.line	949	loadk        r10   k71 ; k71 = 120
.line	949	loadk        r11   k72 ; k72 = 141
.line	949	loadk        r12   k73 ; k73 = 251
.line	949	loadk        r13   k63 ; k63 = 221
.line	949	loadk        r14   k74 ; k74 = 154
.line	949	loadk        r15   k10 ; k10 = 213
.line	949	loadk        r16   k75 ; k75 = 80
.line	949	loadk        r17   k76 ; k76 = 133
.line	949	loadk        r18   k77 ; k77 = 21
.line	949	loadk        r19   k59 ; k59 = 38
.line	949	loadk        r20   k53 ; k53 = 199
.line	949	loadk        r21   k78 ; k78 = 56
.line	949	call          r9    13     0
.line	949	setlist       r6     0     1
.line	949	call          r5     2     2
.line	949	call          r2     4     1
.line	949	self          r2    r0   k79 ; k79 = "_GetEliteBuyState"
.line	949	call          r2     2     2
.line	949	self          r3    r0   k80 ; k80 = "_DetermineEliteBuyTy" (truncated)
.line	949	move          r5    r2
.line	949	call          r3     3     3
.line	949	gettabup      r5    u1   k81 ; k81 = "log"
.line	949	gettabup      r6    u1   k82 ; k82 = "bWriteLog"
.line	949	test          r6     0
.line	949	jmp            0  l182
.line	949	gettabup      r6    u1    k5 ; k5 = "table"
.line	949	gettable      r6    r6    k6 ; k6 = "concat"
.line	949	newtable      r7     1     0
.line	949	getupval      r8    u2
.line	949	loadk         r9   k83 ; k83 = 72
.line	949	loadk        r10   k84 ; k84 = 128
.line	949	loadk        r11    k9 ; k9 = 254
.line	949	loadk        r12   k85 ; k85 = 219
.line	949	loadk        r13   k86 ; k86 = 161
.line	949	loadk        r14   k87 ; k87 = 255
.line	949	loadk        r15   k88 ; k88 = 87
.line	949	loadk        r16   k89 ; k89 = 159
.line	949	loadk        r17   k90 ; k90 = 46
.line	949	loadk        r18   k91 ; k91 = 118
.line	949	loadk        r19   k92 ; k92 = 140
.line	949	loadk        r20   k52 ; k52 = 95
.line	949	loadk        r21   k93 ; k93 = 168
.line	949	loadk        r22   k94 ; k94 = 231
.line	949	loadk        r23   k95 ; k95 = 97
.line	949	loadk        r24   k96 ; k96 = 14
.line	949	loadk        r25   k18 ; k18 = 179
.line	949	loadk        r26   k67 ; k67 = 158
.line	949	loadk        r27   k97 ; k97 = 191
.line	949	loadk        r28   k98 ; k98 = 178
.line	949	loadk        r29   k99 ; k99 = 104
.line	949	loadk        r30  k100 ; k100 = 236
.line	949	loadk        r31  k101 ; k101 = 51
.line	949	loadk        r32   k51 ; k51 = 180
.line	949	loadk        r33  k102 ; k102 = 63
.line	949	loadk        r34  k103 ; k103 = 116
.line	949	loadk        r35   k72 ; k72 = 141
.line	949	loadk        r36   k17 ; k17 = 85
.line	949	loadk        r37  k104 ; k104 = 134
.line	949	loadk        r38  k105 ; k105 = 206
.line	949	loadk        r39  k106 ; k106 = 90
.line	949	loadk        r40   k90 ; k90 = 46
.line	949	loadk        r41   k93 ; k93 = 168
.line	949	loadk        r42  k107 ; k107 = 185
.line	949	loadk        r43  k104 ; k104 = 134
.line	949	loadk        r44   k16 ; k16 = 218
.line	949	loadk        r45  k108 ; k108 = 94
.line	949	loadk        r46  k109 ; k109 = 247
.line	949	loadk        r47   k61 ; k61 = 107
.line	949	loadk        r48  k110 ; k110 = 246
.line	949	call          r8    41     2
.line	949	getupval      r9    u2
.line	949	loadk        r10   k99 ; k99 = 104
.line	949	loadk        r11   k60 ; k60 = 153
.line	949	loadk        r12   k26 ; k26 = 230
.line	949	loadk        r13  k100 ; k100 = 236
.line	949	loadk        r14   k18 ; k18 = 179
.line	949	loadk        r15  k111 ; k111 = 201
.line	949	loadk        r16  k112 ; k112 = 64
.line	949	loadk        r17   k69 ; k69 = 204
.line	949	call          r9     9     0
.line	949	setlist       r7     0     1
.line	949	call          r6     2     2
.line	949	gettabup      r7    u1  k113 ; k113 = "tostring"
.line	949	move          r8    r3
.line	949	call          r7     2     2
.line	949	concat        r6    r6    r7
.label	l182
.line	949	call          r5     2     1
.line	949	testset       r5    r3     1
.line	949	jmp            0  l186
.line	949	loadk         r5    k1 ; k1 = 0
.label	l186
.line	949	settable      r0    k0    r5 ; k0 = "EliteBuyType"
.line	949	self          r5    r0  k114 ; k114 = "_UpdateEliteBuyDispl" (truncated)
.line	949	move          r7    r3
.line	949	move          r8    r2
.line	949	move          r9    r4
.line	949	move         r10    r1
.line	949	call          r5     6     1
.line	949	return        r0     1
.line	949	move          r0    r0
.line	949	return        r0     1

.function	main/f53

.source	null
.linedefined	960
.lastlinedefined	971
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	11	true

.constant	k0	"bIsBuyElite"
.constant	k1	"UnknowPassSystem"
.constant	k2	"IsBuyElite"
.constant	k3	"bIsBuyEliteSeg2"
.constant	k4	"IsBuyEliteSeg2"
.constant	k5	"nPassType"
.constant	k6	"PassType"
.constant	k7	1
.constant	k8	"bHasEliteCard"
.constant	k9	"HasUpCard"
.constant	k10	"bHasNormalCard"
.constant	k11	"bHasExperienceCard"
.constant	k12	"HasExperienceCard"
.constant	k13	"bHasNewUserPrivlegesCard"
.constant	k14	"HasNewUserPrivlegesCard"

.line	960	newtable      r1     0     7
.line	960	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	960	gettable      r2    r2    k2 ; k2 = "IsBuyElite"
.line	960	settable      r1    k0    r2 ; k0 = "bIsBuyElite"
.line	960	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	960	gettable      r2    r2    k4 ; k4 = "IsBuyEliteSeg2"
.line	960	settable      r1    k3    r2 ; k3 = "bIsBuyEliteSeg2"
.line	960	gettabup      r2    u0    k1 ; k1 = "UnknowPassSystem"
.line	960	gettable      r2    r2    k6 ; k6 = "PassType"
.line	960	test          r2     1
.line	960	jmp            0   l13
.line	960	loadk         r2    k7 ; k7 = 1
.label	l13
.line	960	settable      r1    k5    r2 ; k5 = "nPassType"
.line	960	gettabup      r2    u1    k9 ; k9 = "HasUpCard"
.line	960	loadbool      r3     0     0
.line	960	call          r2     2     2
.line	960	settable      r1    k8    r2 ; k8 = "bHasEliteCard"
.line	960	gettabup      r2    u1    k9 ; k9 = "HasUpCard"
.line	960	loadbool      r3     1     0
.line	960	call          r2     2     2
.line	960	settable      r1   k10    r2 ; k10 = "bHasNormalCard"
.line	960	gettabup      r2    u1   k12 ; k12 = "HasExperienceCard"
.line	960	call          r2     1     2
.line	960	settable      r1   k11    r2 ; k11 = "bHasExperienceCard"
.line	960	gettabup      r2    u1   k14 ; k14 = "HasNewUserPrivlegesC" (truncated)
.line	960	call          r2     1     2
.line	960	settable      r1   k13    r2 ; k13 = "bHasNewUserPrivleges" (truncated)
.line	960	return        r1     2
.line	960	return        r0     1
.line	960	move          r0    r0
.line	960	move          r0    r0
.line	960	move          r0    r0
.line	960	return        r0     1

.function	main/f54

.source	null
.linedefined	973
.lastlinedefined	1006
.numparams	2
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	13	true
.upvalue	"U1"	15	true
.upvalue	"U2"	11	true

.constant	k0	"bIsBuyElite"
.constant	k1	"bIsBuyEliteSeg2"
.constant	k2	"nPassType"
.constant	k3	2
.constant	k4	"bHasEliteCard"
.constant	k5	"BuyType22"
.constant	k6	"BuyType20"
.constant	k7	"BuyType21"
.constant	k8	"bHasNormalCard"
.constant	k9	"BuyType43"
.constant	k10	"BuyType19"
.constant	k11	"BuyType5"
.constant	k12	"BuyType6"
.constant	k13	"bHasNewUserPrivlegesCard"
.constant	k14	"BuyType48"
.constant	k15	"bHasExperienceCard"
.constant	k16	"BuyType42"
.constant	k17	"GetBuyTypeWithCoupon"
.constant	k18	"BuyType3"

.line	973	gettable      r2    r1    k0 ; k0 = "bIsBuyElite"
.line	973	test          r2     0
.line	973	jmp            0   l36
.line	973	gettable      r2    r1    k1 ; k1 = "bIsBuyEliteSeg2"
.line	973	test          r2     0
.line	973	jmp            0   l21
.line	973	gettable      r2    r1    k2 ; k2 = "nPassType"
.line	973	le             0    k3    r2 ; k3 = 2
.line	973	jmp            0   l12
.line	973	loadnil       r2     1
.line	973	return        r2     3
.label	l12
.line	973	gettable      r2    r1    k4 ; k4 = "bHasEliteCard"
.line	973	test          r2     0
.line	973	jmp            0   l18
.line	973	gettabup      r2    u0    k5 ; k5 = "BuyType22"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l18
.line	973	gettabup      r2    u0    k6 ; k6 = "BuyType20"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l21
.line	973	gettable      r2    r1    k4 ; k4 = "bHasEliteCard"
.line	973	test          r2     0
.line	973	jmp            0   l27
.line	973	gettabup      r2    u0    k7 ; k7 = "BuyType21"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l27
.line	973	gettable      r2    r1    k8 ; k8 = "bHasNormalCard"
.line	973	test          r2     0
.line	973	jmp            0   l33
.line	973	gettabup      r2    u0    k9 ; k9 = "BuyType43"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l33
.line	973	gettabup      r2    u0   k10 ; k10 = "BuyType19"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l36
.line	973	gettable      r2    r1    k4 ; k4 = "bHasEliteCard"
.line	973	test          r2     0
.line	973	jmp            0   l42
.line	973	gettabup      r2    u0   k11 ; k11 = "BuyType5"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l42
.line	973	gettable      r2    r1    k8 ; k8 = "bHasNormalCard"
.line	973	test          r2     0
.line	973	jmp            0   l48
.line	973	gettabup      r2    u0   k12 ; k12 = "BuyType6"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l48
.line	973	gettable      r2    r1   k13 ; k13 = "bHasNewUserPrivleges" (truncated)
.line	973	test          r2     0
.line	973	jmp            0   l54
.line	973	gettabup      r2    u0   k14 ; k14 = "BuyType48"
.line	973	getupval      r3    u1
.line	973	return        r2     3
.label	l54
.line	973	gettable      r2    r1   k15 ; k15 = "bHasExperienceCard"
.line	973	test          r2     0
.line	973	jmp            0   l60
.line	973	gettabup      r2    u0   k16 ; k16 = "BuyType42"
.line	973	loadnil       r3     0
.line	973	return        r2     3
.label	l60
.line	973	gettabup      r2    u2   k17 ; k17 = "GetBuyTypeWithCoupon"
.line	973	gettabup      r3    u0   k18 ; k18 = "BuyType3"
.line	973	call          r2     2     2
.line	973	move          r3    r2
.line	973	loadnil       r4     0
.line	973	return        r3     3
.line	973	return        r0     1
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	move          r0    r0
.line	973	return        r0     1

.function	main/f55

.source	null
.linedefined	1008
.lastlinedefined	1032
.numparams	5
.is_vararg	0
.maxstacksize	9

.upvalue	"_ENV"	13	true
.upvalue	"U1"	11	true

.constant	k0	"SetTexture"
.constant	k1	"imageCard"
.constant	k2	"bIsBuyElite"
.constant	k3	"bIsBuyEliteSeg2"
.constant	k4	"nPassType"
.constant	k5	2
.constant	k6	"widgetSwitcherBuy"
.constant	k7	"SetActiveWidgetIndex"
.constant	k8	4
.constant	k9	"BuyType5"
.constant	k10	"BuyType21"
.constant	k11	"BuyType22"
.constant	k12	3
.constant	k13	"BuyType6"
.constant	k14	"BuyType43"
.constant	k15	"BuyType48"
.constant	k16	"BuyType42"
.constant	k17	"GetBuyConfigViaBuyType"
.constant	k18	"textPriceUc"
.constant	k19	"SetText"
.constant	k20	"Price2"
.constant	k21	"SetElitePriceViaBuyType"

.line	1008	test          r3     0
.line	1008	jmp            0    l7
.line	1008	self          r5    r0    k0 ; k0 = "SetTexture"
.line	1008	gettable      r7    r4    k1 ; k1 = "imageCard"
.line	1008	move          r8    r3
.line	1008	call          r5     4     1
.label	l7
.line	1008	gettable      r5    r2    k2 ; k2 = "bIsBuyElite"
.line	1008	test          r5     0
.line	1008	jmp            0   l21
.line	1008	gettable      r5    r2    k3 ; k3 = "bIsBuyEliteSeg2"
.line	1008	test          r5     0
.line	1008	jmp            0   l21
.line	1008	gettable      r5    r2    k4 ; k4 = "nPassType"
.line	1008	le             0    k5    r5 ; k5 = 2
.line	1008	jmp            0   l21
.line	1008	gettable      r5    r4    k6 ; k6 = "widgetSwitcherBuy"
.line	1008	self          r5    r5    k7 ; k7 = "SetActiveWidgetIndex"
.line	1008	loadk         r7    k8 ; k8 = 4
.line	1008	call          r5     3     1
.line	1008	return        r0     1
.label	l21
.line	1008	test          r1     1
.line	1008	jmp            0   l24
.line	1008	return        r0     1
.label	l24
.line	1008	gettabup      r5    u0    k9 ; k9 = "BuyType5"
.line	1008	eq             1    r1    r5
.line	1008	jmp            0   l33
.line	1008	gettabup      r5    u0   k10 ; k10 = "BuyType21"
.line	1008	eq             1    r1    r5
.line	1008	jmp            0   l33
.line	1008	gettabup      r5    u0   k11 ; k11 = "BuyType22"
.line	1008	eq             0    r1    r5
.line	1008	jmp            0   l38
.label	l33
.line	1008	gettable      r5    r4    k6 ; k6 = "widgetSwitcherBuy"
.line	1008	self          r5    r5    k7 ; k7 = "SetActiveWidgetIndex"
.line	1008	loadk         r7   k12 ; k12 = 3
.line	1008	call          r5     3     1
.line	1008	return        r0     1
.label	l38
.line	1008	gettabup      r5    u0   k13 ; k13 = "BuyType6"
.line	1008	eq             1    r1    r5
.line	1008	jmp            0   l50
.line	1008	gettabup      r5    u0   k14 ; k14 = "BuyType43"
.line	1008	eq             1    r1    r5
.line	1008	jmp            0   l50
.line	1008	gettabup      r5    u0   k15 ; k15 = "BuyType48"
.line	1008	eq             1    r1    r5
.line	1008	jmp            0   l50
.line	1008	gettabup      r5    u0   k16 ; k16 = "BuyType42"
.line	1008	eq             0    r1    r5
.line	1008	jmp            0   l64
.label	l50
.line	1008	gettable      r5    r4    k6 ; k6 = "widgetSwitcherBuy"
.line	1008	self          r5    r5    k7 ; k7 = "SetActiveWidgetIndex"
.line	1008	loadk         r7    k5 ; k5 = 2
.line	1008	call          r5     3     1
.line	1008	gettabup      r5    u1   k17 ; k17 = "GetBuyConfigViaBuyTy" (truncated)
.line	1008	move          r6    r1
.line	1008	call          r5     2     2
.line	1008	test          r5     0
.line	1008	jmp            0   l63
.line	1008	gettable      r6    r4   k18 ; k18 = "textPriceUc"
.line	1008	self          r6    r6   k19 ; k19 = "SetText"
.line	1008	gettable      r8    r5   k20 ; k20 = "Price2"
.line	1008	call          r6     3     1
.label	l63
.line	1008	return        r0     1
.label	l64
.line	1008	self          r5    r0   k21 ; k21 = "SetElitePriceViaBuyT" (truncated)
.line	1008	move          r7    r1
.line	1008	move          r8    r4
.line	1008	call          r5     4     1
.line	1008	return        r0     1
.line	1008	move          r0    r0
.line	1008	move          r0    r0
.line	1008	move          r0    r0
.line	1008	return        r0     1

.function	main/f56

.source	null
.linedefined	1034
.lastlinedefined	1061
.numparams	3
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	11	true
.upvalue	"U1"	0	false
.upvalue	"U2"	1	true

.constant	k0	"GetBuyConfigViaBuyType"
.constant	k1	"log"
.constant	k2	"bWriteLog"
.constant	k3	81
.constant	k4	174
.constant	k5	243
.constant	k6	217
.constant	k7	169
.constant	k8	210
.constant	k9	99
.constant	k10	132
.constant	k11	35
.constant	k12	115
.constant	k13	148
.constant	k14	121
.constant	k15	165
.constant	k16	229
.constant	k17	110
.constant	k18	4
.constant	k19	175
.constant	k20	149
.constant	k21	173
.constant	k22	216
.constant	k23	103
.constant	k24	59
.constant	k25	54
.constant	k26	39
.constant	k27	135
.constant	k28	101
.constant	k29	147
.constant	k30	77
.constant	k31	36
.constant	k32	170
.constant	k33	150
.constant	k34	255
.constant	k35	16
.constant	k36	185
.constant	k37	"tostring"
.constant	k38	7
.constant	k39	17
.constant	k40	"FuncUtil"
.constant	k41	"IsPlayerJPKR"
.constant	k42	"Price2"
.constant	k43	"PriceDiscount2"
.constant	k44	"widgetSwitcherBuy"
.constant	k45	"SetActiveWidgetIndex"
.constant	k46	1
.constant	k47	"textOriginPrice"
.constant	k48	"SetText"
.constant	k49	"textDiscountPrice"
.constant	k50	0
.constant	k51	"textPrice"
.constant	k52	"Price1"
.constant	k53	"PriceDiscount1"

.line	1034	gettabup      r3    u0    k0 ; k0 = "GetBuyConfigViaBuyTy" (truncated)
.line	1034	move          r4    r1
.line	1034	call          r3     2     2
.line	1034	test          r3     1
.line	1034	jmp            0   l56
.line	1034	gettabup      r4    u1    k1 ; k1 = "log"
.line	1034	gettabup      r5    u1    k2 ; k2 = "bWriteLog"
.line	1034	test          r5     0
.line	1034	jmp            0   l54
.line	1034	getupval      r5    u2
.line	1034	loadk         r6    k3 ; k3 = 81
.line	1034	loadk         r7    k4 ; k4 = 174
.line	1034	loadk         r8    k5 ; k5 = 243
.line	1034	loadk         r9    k6 ; k6 = 217
.line	1034	loadk        r10    k7 ; k7 = 169
.line	1034	loadk        r11    k8 ; k8 = 210
.line	1034	loadk        r12    k9 ; k9 = 99
.line	1034	loadk        r13   k10 ; k10 = 132
.line	1034	loadk        r14   k11 ; k11 = 35
.line	1034	loadk        r15   k12 ; k12 = 115
.line	1034	loadk        r16   k13 ; k13 = 148
.line	1034	loadk        r17   k14 ; k14 = 121
.line	1034	loadk        r18   k15 ; k15 = 165
.line	1034	loadk        r19   k16 ; k16 = 229
.line	1034	loadk        r20   k17 ; k17 = 110
.line	1034	loadk        r21   k18 ; k18 = 4
.line	1034	loadk        r22   k19 ; k19 = 175
.line	1034	loadk        r23   k20 ; k20 = 149
.line	1034	loadk        r24   k21 ; k21 = 173
.line	1034	loadk        r25   k22 ; k22 = 216
.line	1034	loadk        r26   k23 ; k23 = 103
.line	1034	loadk        r27    k7 ; k7 = 169
.line	1034	loadk        r28   k24 ; k24 = 59
.line	1034	loadk        r29   k19 ; k19 = 175
.line	1034	loadk        r30   k25 ; k25 = 54
.line	1034	loadk        r31   k26 ; k26 = 39
.line	1034	loadk        r32   k27 ; k27 = 135
.line	1034	loadk        r33   k28 ; k28 = 101
.line	1034	loadk        r34   k29 ; k29 = 147
.line	1034	loadk        r35   k27 ; k27 = 135
.line	1034	loadk        r36   k30 ; k30 = 77
.line	1034	loadk        r37   k31 ; k31 = 36
.line	1034	loadk        r38   k10 ; k10 = 132
.line	1034	loadk        r39   k32 ; k32 = 170
.line	1034	loadk        r40   k33 ; k33 = 150
.line	1034	loadk        r41   k34 ; k34 = 255
.line	1034	loadk        r42   k35 ; k35 = 16
.line	1034	loadk        r43   k36 ; k36 = 185
.line	1034	call          r5    39     2
.line	1034	gettabup      r6    u1   k37 ; k37 = "tostring"
.line	1034	move          r7    r1
.line	1034	call          r6     2     2
.line	1034	concat        r5    r5    r6
.label	l54
.line	1034	call          r4     2     1
.line	1034	return        r0     1
.label	l56
.line	1034	loadbool      r4     0     0
.line	1034	le             0   k38    r1 ; k38 = 7
.line	1034	jmp            0   l62
.line	1034	le             0    r1   k39 ; k39 = 17
.line	1034	jmp            0   l62
.line	1034	loadbool      r4     1     0
.label	l62
.line	1034	test          r4     0
.line	1034	jmp            0   l95
.line	1034	gettabup      r5    u1   k40 ; k40 = "FuncUtil"
.line	1034	gettable      r5    r5   k41 ; k41 = "IsPlayerJPKR"
.line	1034	call          r5     1     2
.line	1034	test          r5     1
.line	1034	jmp            0   l86
.line	1034	gettable      r5    r3   k42 ; k42 = "Price2"
.line	1034	gettable      r6    r3   k43 ; k43 = "PriceDiscount2"
.line	1034	lt             0    r6    r5
.line	1034	jmp            0   l86
.line	1034	gettable      r5    r2   k44 ; k44 = "widgetSwitcherBuy"
.line	1034	self          r5    r5   k45 ; k45 = "SetActiveWidgetIndex"
.line	1034	loadk         r7   k46 ; k46 = 1
.line	1034	call          r5     3     1
.line	1034	gettable      r5    r2   k47 ; k47 = "textOriginPrice"
.line	1034	self          r5    r5   k48 ; k48 = "SetText"
.line	1034	gettable      r7    r3   k42 ; k42 = "Price2"
.line	1034	call          r5     3     1
.line	1034	gettable      r5    r2   k49 ; k49 = "textDiscountPrice"
.line	1034	self          r5    r5   k48 ; k48 = "SetText"
.line	1034	gettable      r7    r3   k43 ; k43 = "PriceDiscount2"
.line	1034	call          r5     3     1
.line	1034	jmp            0  l125
.label	l86
.line	1034	gettable      r5    r2   k44 ; k44 = "widgetSwitcherBuy"
.line	1034	self          r5    r5   k45 ; k45 = "SetActiveWidgetIndex"
.line	1034	loadk         r7   k50 ; k50 = 0
.line	1034	call          r5     3     1
.line	1034	gettable      r5    r2   k51 ; k51 = "textPrice"
.line	1034	self          r5    r5   k48 ; k48 = "SetText"
.line	1034	gettable      r7    r3   k43 ; k43 = "PriceDiscount2"
.line	1034	call          r5     3     1
.line	1034	jmp            0  l125
.label	l95
.line	1034	gettabup      r5    u1   k40 ; k40 = "FuncUtil"
.line	1034	gettable      r5    r5   k41 ; k41 = "IsPlayerJPKR"
.line	1034	call          r5     1     2
.line	1034	test          r5     1
.line	1034	jmp            0  l117
.line	1034	gettable      r5    r3   k52 ; k52 = "Price1"
.line	1034	gettable      r6    r3   k53 ; k53 = "PriceDiscount1"
.line	1034	lt             0    r6    r5
.line	1034	jmp            0  l117
.line	1034	gettable      r5    r2   k44 ; k44 = "widgetSwitcherBuy"
.line	1034	self          r5    r5   k45 ; k45 = "SetActiveWidgetIndex"
.line	1034	loadk         r7   k46 ; k46 = 1
.line	1034	call          r5     3     1
.line	1034	gettable      r5    r2   k47 ; k47 = "textOriginPrice"
.line	1034	self          r5    r5   k48 ; k48 = "SetText"
.line	1034	gettable      r7    r3   k52 ; k52 = "Price1"
.line	1034	call          r5     3     1
.line	1034	gettable      r5    r2   k49 ; k49 = "textDiscountPrice"
.line	1034	self          r5    r5   k48 ; k48 = "SetText"
.line	1034	gettable      r7    r3   k53 ; k53 = "PriceDiscount1"
.line	1034	call          r5     3     1
.line	1034	jmp            0  l125
.label	l117
.line	1034	gettable      r5    r2   k44 ; k44 = "widgetSwitcherBuy"
.line	1034	self          r5    r5   k45 ; k45 = "SetActiveWidgetIndex"
.line	1034	loadk         r7   k50 ; k50 = 0
.line	1034	call          r5     3     1
.line	1034	gettable      r5    r2   k51 ; k51 = "textPrice"
.line	1034	self          r5    r5   k48 ; k48 = "SetText"
.line	1034	gettable      r7    r3   k53 ; k53 = "PriceDiscount1"
.line	1034	call          r5     3     1
.label	l125
.line	1034	return        r0     1
.line	1034	move          r0    r0
.line	1034	move          r0    r0
.line	1034	return        r0     1

.function	main/f57

.source	null
.linedefined	1063
.lastlinedefined	1066
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"RefreshLinkageRewardBtnShow"
.constant	k1	"UpdateLinkageRewardIcon"

.line	1063	self          r1    r0    k0 ; k0 = "RefreshLinkageReward" (truncated)
.line	1063	call          r1     2     1
.line	1063	self          r1    r0    k1 ; k1 = "UpdateLinkageRewardI" (truncated)
.line	1063	call          r1     2     1
.line	1063	return        r0     1
.line	1063	move          r0    r0
.line	1063	move          r0    r0
.line	1063	move          r0    r0
.line	1063	move          r0    r0
.line	1063	return        r0     1

.function	main/f58

.source	null
.linedefined	1068
.lastlinedefined	1080
.numparams	2
.is_vararg	0
.maxstacksize	5

.constant	k0	"bIsBuyRPTab"
.constant	k1	"UIRoot"
.constant	k2	"WidgetSwitcher_Panel"
.constant	k3	"SetActiveWidgetIndex"
.constant	k4	0
.constant	k5	"WidgetSwitcher_BuyRP"
.constant	k6	"WidgetSwitcher_Group"
.constant	k7	1
.constant	k8	"OnUpdateGroupRewardTips"

.line	1068	settable      r0    k0    r1 ; k0 = "bIsBuyRPTab"
.line	1068	test          r1     0
.line	1068	jmp            0   l20
.line	1068	gettable      r2    r0    k1 ; k1 = "UIRoot"
.line	1068	gettable      r2    r2    k2 ; k2 = "WidgetSwitcher_Panel"
.line	1068	self          r2    r2    k3 ; k3 = "SetActiveWidgetIndex"
.line	1068	loadk         r4    k4 ; k4 = 0
.line	1068	call          r2     3     1
.line	1068	gettable      r2    r0    k1 ; k1 = "UIRoot"
.line	1068	gettable      r2    r2    k5 ; k5 = "WidgetSwitcher_BuyRP"
.line	1068	self          r2    r2    k3 ; k3 = "SetActiveWidgetIndex"
.line	1068	loadk         r4    k4 ; k4 = 0
.line	1068	call          r2     3     1
.line	1068	gettable      r2    r0    k1 ; k1 = "UIRoot"
.line	1068	gettable      r2    r2    k6 ; k6 = "WidgetSwitcher_Group"
.line	1068	self          r2    r2    k3 ; k3 = "SetActiveWidgetIndex"
.line	1068	loadk         r4    k7 ; k7 = 1
.line	1068	call          r2     3     1
.line	1068	jmp            0   l35
.label	l20
.line	1068	gettable      r2    r0    k1 ; k1 = "UIRoot"
.line	1068	gettable      r2    r2    k2 ; k2 = "WidgetSwitcher_Panel"
.line	1068	self          r2    r2    k3 ; k3 = "SetActiveWidgetIndex"
.line	1068	loadk         r4    k7 ; k7 = 1
.line	1068	call          r2     3     1
.line	1068	gettable      r2    r0    k1 ; k1 = "UIRoot"
.line	1068	gettable      r2    r2    k5 ; k5 = "WidgetSwitcher_BuyRP"
.line	1068	self          r2    r2    k3 ; k3 = "SetActiveWidgetIndex"
.line	1068	loadk         r4    k7 ; k7 = 1
.line	1068	call          r2     3     1
.line	1068	gettable      r2    r0    k1 ; k1 = "UIRoot"
.line	1068	gettable      r2    r2    k6 ; k6 = "WidgetSwitcher_Group"
.line	1068	self          r2    r2    k3 ; k3 = "SetActiveWidgetIndex"
.line	1068	loadk         r4    k4 ; k4 = 0
.line	1068	call          r2     3     1
.label	l35
.line	1068	self          r2    r0    k8 ; k8 = "OnUpdateGroupRewardT" (truncated)
.line	1068	call          r2     2     1
.line	1068	return        r0     1
.line	1068	move          r0    r0
.line	1068	move          r0    r0
.line	1068	move          r0    r0
.line	1068	return        r0     1

.function	main/f59

.source	null
.linedefined	1082
.lastlinedefined	1085
.numparams	1
.is_vararg	0
.maxstacksize	4

.upvalue	"_ENV"	0	false
.upvalue	"U1"	3	true

.constant	k0	"SwitchTab"
.constant	k1	"UnknowPassSystem"
.constant	k2	"IsBuyElite"
.constant	k3	"ReportTLogEvent"
.constant	k4	"TLogEventDefine"
.constant	k5	"BlackFridayRPGroup_EnterActivity"
.constant	k6	1
.constant	k7	0

.line	1082	self          r1    r0    k0 ; k0 = "SwitchTab"
.line	1082	gettabup      r3    u0    k1 ; k1 = "UnknowPassSystem"
.line	1082	gettable      r3    r3    k2 ; k2 = "IsBuyElite"
.line	1082	not           r3    r3
.line	1082	call          r1     3     1
.line	1082	gettabup      r1    u1    k3 ; k3 = "ReportTLogEvent"
.line	1082	gettabup      r2    u0    k4 ; k4 = "TLogEventDefine"
.line	1082	gettable      r2    r2    k5 ; k5 = "BlackFridayRPGroup_E" (truncated)
.line	1082	gettabup      r3    u0    k1 ; k1 = "UnknowPassSystem"
.line	1082	gettable      r3    r3    k2 ; k2 = "IsBuyElite"
.line	1082	test          r3     0
.line	1082	jmp            0   l16
.line	1082	loadk         r3    k6 ; k6 = 1
.line	1082	test          r3     1
.line	1082	jmp            0   l17
.label	l16
.line	1082	loadk         r3    k7 ; k7 = 0
.label	l17
.line	1082	call          r1     3     1
.line	1082	return        r0     1
.line	1082	move          r0    r0
.line	1082	move          r0    r0
.line	1082	move          r0    r0
.line	1082	return        r0     1

.function	main/f60

.source	null
.linedefined	1087
.lastlinedefined	1101
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false

.constant	k0	"UIRoot"
.constant	k1	"TextBlock_TopDesc"
.constant	k2	"SetText"
.constant	k3	"LocUtil"
.constant	k4	"GetLocalizeResStr"
.constant	k5	18140045
.constant	k6	"TextBlock_GroupSelect"
.constant	k7	16178
.constant	k8	"TextBlock_GroupUnSelect"
.constant	k9	"TextBlock_MyGroup"
.constant	k10	18130166
.constant	k11	"TextBlock_ReceiveReward"
.constant	k12	18130169
.constant	k13	"TextBlock_HadBuy"
.constant	k14	18130178
.constant	k15	"TextBlock_QuickGroup"
.constant	k16	18130183
.constant	k17	"TextBlock_InvitateRecord"
.constant	k18	18130181
.constant	k19	"TextBlock_0"
.constant	k20	18130172
.constant	k21	"TextBlock_2"
.constant	k22	"TextBlock_GoBuy"
.constant	k23	87001
.constant	k24	"TextBlock_LinkageReward"
.constant	k25	18141428
.constant	k26	"TextBlock_BuyLuckCard"
.constant	k27	18130177

.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1    k1 ; k1 = "TextBlock_TopDesc"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4    k5 ; k5 = 18140045
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1    k6 ; k6 = "TextBlock_GroupSelec" (truncated)
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4    k7 ; k7 = 16178
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1    k8 ; k8 = "TextBlock_GroupUnSel" (truncated)
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4    k7 ; k7 = 16178
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1    k9 ; k9 = "TextBlock_MyGroup"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k10 ; k10 = 18130166
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k11 ; k11 = "TextBlock_ReceiveRew" (truncated)
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k12 ; k12 = 18130169
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k13 ; k13 = "TextBlock_HadBuy"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k14 ; k14 = 18130178
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k15 ; k15 = "TextBlock_QuickGroup"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k16 ; k16 = 18130183
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k17 ; k17 = "TextBlock_InvitateRe" (truncated)
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k18 ; k18 = 18130181
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k19 ; k19 = "TextBlock_0"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k20 ; k20 = 18130172
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k21 ; k21 = "TextBlock_2"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k20 ; k20 = 18130172
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k22 ; k22 = "TextBlock_GoBuy"
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k23 ; k23 = 87001
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k24 ; k24 = "TextBlock_LinkageRew" (truncated)
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k25 ; k25 = 18141428
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1087	gettable      r1    r1   k26 ; k26 = "TextBlock_BuyLuckCar" (truncated)
.line	1087	self          r1    r1    k2 ; k2 = "SetText"
.line	1087	gettabup      r3    u0    k3 ; k3 = "LocUtil"
.line	1087	gettable      r3    r3    k4 ; k4 = "GetLocalizeResStr"
.line	1087	loadk         r4   k27 ; k27 = 18130177
.line	1087	call          r3     2     0
.line	1087	call          r1     0     1
.line	1087	return        r0     1
.line	1087	move          r0    r0
.line	1087	return        r0     1

.function	main/f61

.source	null
.linedefined	1103
.lastlinedefined	1122
.numparams	1
.is_vararg	0
.maxstacksize	18

.upvalue	"_ENV"	0	false
.upvalue	"U1"	4	true

.constant	k0	"UIRoot"
.constant	k1	"Lua_CommonItems_1"
.constant	k2	"Lua_CommonItems_2"
.constant	k3	"ModuleManager"
.constant	k4	"GetModule"
.constant	k5	"LobbyModuleConfig"
.constant	k6	"Logic_BFSubscribeModule"
.constant	k7	"BlackFridayRPGroupModule"
.constant	k8	"GetIsShowJapanLinkageRewardIcon"
.constant	k9	1101
.constant	k10	"GetLinkageRewardItemIdByBoughtSub"
.constant	k11	1614404
.constant	k12	1617216
.constant	k13	"UnknowPassSystem"
.constant	k14	"IsBuyElite"
.constant	k15	"PassType"
.constant	k16	2
.constant	k17	1614406
.constant	k18	1617151
.constant	k19	"GetLinkageRewardStatus"
.constant	k20	"Enum_LinkageReceiveStatus"
.constant	k21	"Received"
.constant	k22	"GetReceivedLinkageRewardItemID"
.constant	k23	"GetJPLinkageRewardItemNumByBoughtSub"
.constant	k24	"InitView"
.constant	k25	1
.constant	k26	0
.constant	k27	"bIsShowTip"
.constant	k28	true

.line	1103	gettable      r1    r0    k0 ; k0 = "UIRoot"
.line	1103	gettable      r1    r1    k1 ; k1 = "Lua_CommonItems_1"
.line	1103	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1103	gettable      r2    r2    k2 ; k2 = "Lua_CommonItems_2"
.line	1103	gettabup      r3    u0    k3 ; k3 = "ModuleManager"
.line	1103	gettable      r3    r3    k4 ; k4 = "GetModule"
.line	1103	gettabup      r4    u0    k3 ; k3 = "ModuleManager"
.line	1103	gettable      r4    r4    k5 ; k5 = "LobbyModuleConfig"
.line	1103	gettable      r4    r4    k6 ; k6 = "Logic_BFSubscribeMod" (truncated)
.line	1103	call          r3     2     2
.line	1103	gettabup      r4    u0    k3 ; k3 = "ModuleManager"
.line	1103	gettable      r4    r4    k4 ; k4 = "GetModule"
.line	1103	gettabup      r5    u0    k3 ; k3 = "ModuleManager"
.line	1103	gettable      r5    r5    k5 ; k5 = "LobbyModuleConfig"
.line	1103	gettable      r5    r5    k7 ; k7 = "BlackFridayRPGroupMo" (truncated)
.line	1103	call          r4     2     2
.line	1103	self          r5    r4    k8 ; k8 = "GetIsShowJapanLinkag" (truncated)
.line	1103	call          r5     2     2
.line	1103	test          r5     0
.line	1103	jmp            0   l24
.line	1103	loadk         r6    k9 ; k9 = 1101
.line	1103	test          r6     1
.line	1103	jmp            0   l26
.label	l24
.line	1103	self          r6    r3   k10 ; k10 = "GetLinkageRewardItem" (truncated)
.line	1103	call          r6     2     2
.label	l26
.line	1103	test          r5     0
.line	1103	jmp            0   l31
.line	1103	loadk         r7   k11 ; k11 = 1614404
.line	1103	test          r7     1
.line	1103	jmp            0   l32
.label	l31
.line	1103	loadk         r7   k12 ; k12 = 1617216
.label	l32
.line	1103	gettabup      r8    u0   k13 ; k13 = "UnknowPassSystem"
.line	1103	gettable      r8    r8   k14 ; k14 = "IsBuyElite"
.line	1103	test          r8     0
.line	1103	jmp            0   l46
.line	1103	gettabup      r8    u0   k13 ; k13 = "UnknowPassSystem"
.line	1103	gettable      r8    r8   k15 ; k15 = "PassType"
.line	1103	eq             0    r8   k16 ; k16 = 2
.line	1103	jmp            0   l46
.line	1103	test          r5     0
.line	1103	jmp            0   l45
.line	1103	loadk         r8   k17 ; k17 = 1614406
.line	1103	testset       r7    r8     1
.line	1103	jmp            0   l46
.label	l45
.line	1103	loadk         r7   k18 ; k18 = 1617151
.label	l46
.line	1103	self          r8    r4   k19 ; k19 = "GetLinkageRewardStat" (truncated)
.line	1103	call          r8     2     2
.line	1103	gettabup      r9    u1   k20 ; k20 = "Enum_LinkageReceiveS" (truncated)
.line	1103	gettable     r10    r9   k21 ; k21 = "Received"
.line	1103	eq             0    r8   r10
.line	1103	jmp            0   l56
.line	1103	self         r10    r4   k22 ; k22 = "GetReceivedLinkageRe" (truncated)
.line	1103	call         r10     2     3
.line	1103	move          r6   r11
.line	1103	move          r7   r10
.label	l56
.line	1103	self         r10    r3   k23 ; k23 = "GetJPLinkageRewardIt" (truncated)
.line	1103	call         r10     2     3
.line	1103	self         r12    r1   k24 ; k24 = "InitView"
.line	1103	move         r14    r7
.line	1103	test          r5     0
.line	1103	jmp            0   l64
.line	1103	testset      r15   r11     1
.line	1103	jmp            0   l65
.label	l64
.line	1103	loadk        r15   k25 ; k25 = 1
.label	l65
.line	1103	loadk        r16   k26 ; k26 = 0
.line	1103	newtable     r17     0     1
.line	1103	settable     r17   k27   k28 ; k28 = true
.line	1103	call         r12     6     1
.line	1103	self         r12    r2   k24 ; k24 = "InitView"
.line	1103	move         r14    r6
.line	1103	test          r5     0
.line	1103	jmp            0   l75
.line	1103	testset      r15   r10     1
.line	1103	jmp            0   l76
.label	l75
.line	1103	loadk        r15   k25 ; k25 = 1
.label	l76
.line	1103	loadk        r16   k26 ; k26 = 0
.line	1103	newtable     r17     0     1
.line	1103	settable     r17   k27   k28 ; k28 = true
.line	1103	call         r12     6     1
.line	1103	return        r0     1
.line	1103	move          r0    r0
.line	1103	move          r0    r0
.line	1103	return        r0     1

.function	main/f62

.source	null
.linedefined	1145
.lastlinedefined	1152
.numparams	3
.is_vararg	0
.maxstacksize	26

.upvalue	"_ENV"	0	false
.upvalue	"U1"	20	true
.upvalue	"U2"	1	true

.constant	k0	"UIRoot"
.constant	k1	"ipairs"
.constant	k2	95
.constant	k3	184
.constant	k4	205
.constant	k5	209
.constant	k6	169
.constant	k7	113
.constant	k8	147
.constant	k9	50
.constant	k10	99
.constant	k11	183
.constant	k12	108
.constant	k13	149
.constant	k14	212
.constant	k15	85
.constant	k16	4
.constant	k17	94
.constant	k18	239
.constant	k19	221
.constant	k20	"SetText"
.constant	k21	"LocUtil"
.constant	k22	"GetLocalizeResStr"
.constant	k23	"SetColorAndOpacity"

.line	1145	gettable      r3    r0    k0 ; k0 = "UIRoot"
.line	1145	gettabup      r4    u0    k1 ; k1 = "ipairs"
.line	1145	getupval      r5    u1
.line	1145	call          r4     2     4
.line	1145	jmp            0   l42
.line	1145	getupval      r9    u2
.line	1145	loadk        r10    k2 ; k2 = 95
.line	1145	loadk        r11    k3 ; k3 = 184
.line	1145	loadk        r12    k4 ; k4 = 205
.line	1145	loadk        r13    k5 ; k5 = 209
.line	1145	loadk        r14    k6 ; k6 = 169
.line	1145	loadk        r15    k5 ; k5 = 209
.line	1145	loadk        r16    k7 ; k7 = 113
.line	1145	loadk        r17    k8 ; k8 = 147
.line	1145	loadk        r18    k9 ; k9 = 50
.line	1145	loadk        r19   k10 ; k10 = 99
.line	1145	loadk        r20   k11 ; k11 = 183
.line	1145	loadk        r21   k12 ; k12 = 108
.line	1145	loadk        r22   k13 ; k13 = 149
.line	1145	loadk        r23   k14 ; k14 = 212
.line	1145	loadk        r24   k15 ; k15 = 85
.line	1145	loadk        r25   k16 ; k16 = 4
.line	1145	call          r9    17     2
.line	1145	move         r10    r8
.line	1145	getupval     r11    u2
.line	1145	loadk        r12   k17 ; k17 = 94
.line	1145	loadk        r13   k13 ; k13 = 149
.line	1145	loadk        r14   k18 ; k18 = 239
.line	1145	loadk        r15   k19 ; k19 = 221
.line	1145	call         r11     5     2
.line	1145	concat        r9    r9   r11
.line	1145	gettable      r9    r3    r9
.line	1145	self         r10    r9   k20 ; k20 = "SetText"
.line	1145	gettabup     r12    u0   k21 ; k21 = "LocUtil"
.line	1145	gettable     r12   r12   k22 ; k22 = "GetLocalizeResStr"
.line	1145	gettable     r13    r1    r7
.line	1145	call         r12     2     0
.line	1145	call         r10     0     1
.line	1145	self         r10    r9   k23 ; k23 = "SetColorAndOpacity"
.line	1145	gettable     r12    r2    r7
.line	1145	call         r10     3     1
.label	l42
.line	1145	move          r0    r0
.line	1145	move          r0    r0
.line	1145	return        r0     1
.line	1145	move          r0    r0
.line	1145	move          r0    r0
.line	1145	return        r0     1

.function	main/f63

.source	null
.linedefined	1154
.lastlinedefined	1159
.numparams	2
.is_vararg	0
.maxstacksize	21

.upvalue	"_ENV"	0	false
.upvalue	"U1"	20	true
.upvalue	"U2"	1	true

.constant	k0	"UIRoot"
.constant	k1	"ipairs"
.constant	k2	"SetWidgetVisible"
.constant	k3	67
.constant	k4	129
.constant	k5	254
.constant	k6	223
.constant	k7	175
.constant	k8	230
.constant	k9	111
.constant	k10	131
.constant	k11	39
.constant	k12	103

.line	1154	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1154	gettabup      r3    u0    k1 ; k1 = "ipairs"
.line	1154	getupval      r4    u1
.line	1154	call          r3     2     4
.line	1154	jmp            0   l24
.line	1154	self          r8    r0    k2 ; k2 = "SetWidgetVisible"
.line	1154	getupval     r10    u2
.line	1154	loadk        r11    k3 ; k3 = 67
.line	1154	loadk        r12    k4 ; k4 = 129
.line	1154	loadk        r13    k5 ; k5 = 254
.line	1154	loadk        r14    k6 ; k6 = 223
.line	1154	loadk        r15    k7 ; k7 = 175
.line	1154	loadk        r16    k8 ; k8 = 230
.line	1154	loadk        r17    k9 ; k9 = 111
.line	1154	loadk        r18   k10 ; k10 = 131
.line	1154	loadk        r19   k11 ; k11 = 39
.line	1154	loadk        r20   k12 ; k12 = 103
.line	1154	call         r10    11     2
.line	1154	move         r11    r7
.line	1154	concat       r10   r10   r11
.line	1154	gettable     r10    r2   r10
.line	1154	gettable     r11    r1    r6
.line	1154	call          r8     4     1
.label	l24
.line	1154	move          r0    r0
.line	1154	move          r0    r0
.line	1154	return        r0     1
.line	1154	move          r0    r0
.line	1154	move          r0    r0
.line	1154	move          r0    r0
.line	1154	return        r0     1

.function	main/f64

.source	null
.linedefined	1161
.lastlinedefined	1166
.numparams	3
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	20	true
.upvalue	"U2"	1	true

.constant	k0	"UIRoot"
.constant	k1	"ipairs"
.constant	k2	"SetWidgetVisible"
.constant	k3	72
.constant	k4	153
.constant	k5	235
.constant	k6	204
.constant	k7	165
.constant	k8	215
.constant	k9	122
.constant	k10	180
.constant	k11	63
.constant	k12	110

.line	1161	gettable      r3    r0    k0 ; k0 = "UIRoot"
.line	1161	gettabup      r4    u0    k1 ; k1 = "ipairs"
.line	1161	getupval      r5    u1
.line	1161	call          r4     2     4
.line	1161	jmp            0   l25
.line	1161	self          r9    r0    k2 ; k2 = "SetWidgetVisible"
.line	1161	getupval     r11    u2
.line	1161	loadk        r12    k3 ; k3 = 72
.line	1161	loadk        r13    k4 ; k4 = 153
.line	1161	loadk        r14    k5 ; k5 = 235
.line	1161	loadk        r15    k6 ; k6 = 204
.line	1161	loadk        r16    k7 ; k7 = 165
.line	1161	loadk        r17    k8 ; k8 = 215
.line	1161	loadk        r18    k9 ; k9 = 122
.line	1161	loadk        r19   k10 ; k10 = 180
.line	1161	loadk        r20   k11 ; k11 = 63
.line	1161	loadk        r21   k12 ; k12 = 110
.line	1161	call         r11    11     2
.line	1161	move         r12    r8
.line	1161	concat       r11   r11   r12
.line	1161	gettable     r11    r3   r11
.line	1161	gettable     r12    r1    r7
.line	1161	gettable     r13    r2    r7
.line	1161	call          r9     5     1
.label	l25
.line	1161	move          r0    r0
.line	1161	move          r0    r0
.line	1161	return        r0     1
.line	1161	move          r0    r0
.line	1161	return        r0     1

.function	main/f65

.source	null
.linedefined	1168
.lastlinedefined	1176
.numparams	2
.is_vararg	0
.maxstacksize	23

.upvalue	"_ENV"	0	false
.upvalue	"U1"	20	true
.upvalue	"U2"	1	true

.constant	k0	"UIRoot"
.constant	k1	"ipairs"
.constant	k2	72
.constant	k3	153
.constant	k4	235
.constant	k5	204
.constant	k6	165
.constant	k7	215
.constant	k8	122
.constant	k9	164
.constant	k10	47
.constant	k11	116
.constant	k12	144
.constant	k13	105
.constant	k14	140
.constant	k15	210
.constant	k16	"SetIsEnabled"

.line	1168	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1168	gettabup      r3    u0    k1 ; k1 = "ipairs"
.line	1168	getupval      r4    u1
.line	1168	call          r3     2     4
.line	1168	jmp            0   l30
.line	1168	getupval      r8    u2
.line	1168	loadk         r9    k2 ; k2 = 72
.line	1168	loadk        r10    k3 ; k3 = 153
.line	1168	loadk        r11    k4 ; k4 = 235
.line	1168	loadk        r12    k5 ; k5 = 204
.line	1168	loadk        r13    k6 ; k6 = 165
.line	1168	loadk        r14    k7 ; k7 = 215
.line	1168	loadk        r15    k8 ; k8 = 122
.line	1168	loadk        r16    k9 ; k9 = 164
.line	1168	loadk        r17   k10 ; k10 = 47
.line	1168	loadk        r18   k11 ; k11 = 116
.line	1168	loadk        r19   k12 ; k12 = 144
.line	1168	loadk        r20   k13 ; k13 = 105
.line	1168	loadk        r21   k14 ; k14 = 140
.line	1168	loadk        r22   k15 ; k15 = 210
.line	1168	call          r8    15     2
.line	1168	move          r9    r7
.line	1168	concat        r8    r8    r9
.line	1168	gettable      r8    r2    r8
.line	1168	test          r8     0
.line	1168	jmp            0   l30
.line	1168	self          r9    r8   k16 ; k16 = "SetIsEnabled"
.line	1168	gettable     r11    r1    r6
.line	1168	call          r9     3     1
.label	l30
.line	1168	move          r0    r0
.line	1168	move          r0    r0
.line	1168	return        r0     1
.line	1168	move          r0    r0
.line	1168	move          r0    r0
.line	1168	return        r0     1

.function	main/f66

.source	null
.linedefined	1178
.lastlinedefined	1183
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	21	true

.constant	k0	"UIRoot"
.constant	k1	"ipairs"
.constant	k2	"SetWidgetVisible"

.line	1178	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1178	gettabup      r3    u0    k1 ; k1 = "ipairs"
.line	1178	getupval      r4    u1
.line	1178	call          r3     2     4
.line	1178	jmp            0   l10
.line	1178	self          r8    r0    k2 ; k2 = "SetWidgetVisible"
.line	1178	gettable     r10    r2    r7
.line	1178	gettable     r11    r1    r6
.line	1178	call          r8     4     1
.label	l10
.line	1178	move          r0    r0
.line	1178	move          r0    r0
.line	1178	return        r0     1
.line	1178	move          r0    r0
.line	1178	move          r0    r0
.line	1178	return        r0     1

.function	main/f67

.source	null
.linedefined	1191
.lastlinedefined	1196
.numparams	2
.is_vararg	0
.maxstacksize	12

.upvalue	"_ENV"	0	false
.upvalue	"U1"	29	true

.constant	k0	"UIRoot"
.constant	k1	"ipairs"
.constant	k2	"SetWidgetVisible"

.line	1191	gettable      r2    r0    k0 ; k0 = "UIRoot"
.line	1191	gettabup      r3    u0    k1 ; k1 = "ipairs"
.line	1191	getupval      r4    u1
.line	1191	call          r3     2     4
.line	1191	jmp            0   l10
.line	1191	self          r8    r0    k2 ; k2 = "SetWidgetVisible"
.line	1191	gettable     r10    r2    r7
.line	1191	gettable     r11    r1    r6
.line	1191	call          r8     4     1
.label	l10
.line	1191	move          r0    r0
.line	1191	move          r0    r0
.line	1191	return        r0     1
.line	1191	move          r0    r0
.line	1191	move          r0    r0
.line	1191	move          r0    r0
.line	1191	move          r0    r0
.line	1191	return        r0     1

.function	main/f68

.source	null
.linedefined	1198
.lastlinedefined	1429
.numparams	1
.is_vararg	0
.maxstacksize	18

.upvalue	"_ENV"	0	false
.upvalue	"U1"	24	true
.upvalue	"U2"	10	true
.upvalue	"U3"	26	true
.upvalue	"U4"	27	true
.upvalue	"U5"	28	true
.upvalue	"U6"	23	true
.upvalue	"U7"	9	true
.upvalue	"U8"	25	true
.upvalue	"U9"	22	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"_SetRPRewardTexts"
.constant	k5	"_SetRPRewardGlowVisible"
.constant	k6	"_SetRPRewardReddot"
.constant	k7	"UnknowPassSystem"
.constant	k8	"IsBuyElite"
.constant	k9	"IsBuyEliteSeg2"
.constant	k10	"PassType"
.constant	k11	"GetRPGroupBuyType"
.constant	k12	1
.constant	k13	2
.constant	k14	"_SetRPJumpVisible"
.constant	k15	"_SetRPBuyBtnState"
.constant	k16	"GetIsHadReceiveReward"
.constant	k17	3
.constant	k18	"_SetRPReceiveBtnEnabled"
.constant	k19	true
.constant	k20	"IsGroupFullAndAllBuyedRP"

.line	1198	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1198	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1198	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1198	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1198	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	1198	call          r1     2     2
.line	1198	self          r2    r0    k4 ; k4 = "_SetRPRewardTexts"
.line	1198	newtable      r4     3     0
.line	1198	getupval      r5    u1
.line	1198	getupval      r6    u1
.line	1198	getupval      r7    u1
.line	1198	setlist       r4     3     1
.line	1198	newtable      r5     3     0
.line	1198	getupval      r6    u2
.line	1198	getupval      r7    u2
.line	1198	getupval      r8    u2
.line	1198	setlist       r5     3     1
.line	1198	call          r2     4     1
.line	1198	self          r2    r0    k5 ; k5 = "_SetRPRewardGlowVisi" (truncated)
.line	1198	newtable      r4     6     0
.line	1198	loadbool      r5     0     0
.line	1198	loadbool      r6     0     0
.line	1198	loadbool      r7     0     0
.line	1198	loadbool      r8     0     0
.line	1198	loadbool      r9     0     0
.line	1198	loadbool     r10     0     0
.line	1198	setlist       r4     6     1
.line	1198	call          r2     3     1
.line	1198	self          r2    r0    k6 ; k6 = "_SetRPRewardReddot"
.line	1198	newtable      r4     3     0
.line	1198	loadbool      r5     0     0
.line	1198	loadbool      r6     0     0
.line	1198	loadbool      r7     0     0
.line	1198	setlist       r4     3     1
.line	1198	call          r2     3     1
.line	1198	gettabup      r2    u0    k7 ; k7 = "UnknowPassSystem"
.line	1198	gettable      r2    r2    k8 ; k8 = "IsBuyElite"
.line	1198	gettabup      r3    u0    k7 ; k7 = "UnknowPassSystem"
.line	1198	gettable      r3    r3    k9 ; k9 = "IsBuyEliteSeg2"
.line	1198	gettabup      r4    u0    k7 ; k7 = "UnknowPassSystem"
.line	1198	gettable      r4    r4   k10 ; k10 = "PassType"
.line	1198	self          r5    r1   k11 ; k11 = "GetRPGroupBuyType"
.line	1198	call          r5     2     2
.line	1198	getupval      r6    u3
.line	1198	eq             0    r5    r6
.line	1198	jmp            0   l51
.line	1198	loadbool      r2     1     0
.line	1198	loadbool      r3     0     0
.line	1198	loadk         r4   k12 ; k12 = 1
.line	1198	jmp            0   l64
.label	l51
.line	1198	getupval      r6    u4
.line	1198	eq             0    r5    r6
.line	1198	jmp            0   l58
.line	1198	loadbool      r2     1     0
.line	1198	loadbool      r3     1     0
.line	1198	loadk         r4   k12 ; k12 = 1
.line	1198	jmp            0   l64
.label	l58
.line	1198	getupval      r6    u5
.line	1198	eq             0    r5    r6
.line	1198	jmp            0   l64
.line	1198	loadbool      r2     1     0
.line	1198	loadbool      r3     1     0
.line	1198	loadk         r4   k13 ; k13 = 2
.label	l64
.line	1198	test          r2     0
.line	1198	jmp            0   l88
.line	1198	test          r3     1
.line	1198	jmp            0   l88
.line	1198	self          r6    r0   k14 ; k14 = "_SetRPJumpVisible"
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     0     0
.line	1198	loadbool     r10     1     0
.line	1198	loadbool     r11     1     0
.line	1198	setlist       r8     3     1
.line	1198	call          r6     3     1
.line	1198	self          r6    r0   k15 ; k15 = "_SetRPBuyBtnState"
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     1     0
.line	1198	loadbool     r10     1     0
.line	1198	loadbool     r11     1     0
.line	1198	setlist       r8     3     1
.line	1198	newtable      r9     3     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     1     0
.line	1198	loadbool     r12     1     0
.line	1198	setlist       r9     3     1
.line	1198	call          r6     4     1
.line	1198	jmp            0  l135
.label	l88
.line	1198	test          r2     0
.line	1198	jmp            0  l112
.line	1198	lt             0    r4   k13 ; k13 = 2
.line	1198	jmp            0  l112
.line	1198	self          r6    r0   k14 ; k14 = "_SetRPJumpVisible"
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     0     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     1     0
.line	1198	setlist       r8     3     1
.line	1198	call          r6     3     1
.line	1198	self          r6    r0   k15 ; k15 = "_SetRPBuyBtnState"
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     1     0
.line	1198	loadbool     r10     1     0
.line	1198	loadbool     r11     1     0
.line	1198	setlist       r8     3     1
.line	1198	newtable      r9     3     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     0     0
.line	1198	loadbool     r12     1     0
.line	1198	setlist       r9     3     1
.line	1198	call          r6     4     1
.line	1198	jmp            0  l135
.label	l112
.line	1198	test          r2     0
.line	1198	jmp            0  l135
.line	1198	eq             0    r4   k13 ; k13 = 2
.line	1198	jmp            0  l135
.line	1198	self          r6    r0   k14 ; k14 = "_SetRPJumpVisible"
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     0     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     0     0
.line	1198	setlist       r8     3     1
.line	1198	call          r6     3     1
.line	1198	self          r6    r0   k15 ; k15 = "_SetRPBuyBtnState"
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     1     0
.line	1198	loadbool     r10     1     0
.line	1198	loadbool     r11     1     0
.line	1198	setlist       r8     3     1
.line	1198	newtable      r9     3     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     0     0
.line	1198	loadbool     r12     0     0
.line	1198	setlist       r9     3     1
.line	1198	call          r6     4     1
.label	l135
.line	1198	self          r6    r1   k16 ; k16 = "GetIsHadReceiveRewar" (truncated)
.line	1198	call          r6     2     2
.line	1198	loadnil       r7     0
.line	1198	test          r2     0
.line	1198	jmp            0  l144
.line	1198	test          r3     1
.line	1198	jmp            0  l144
.line	1198	loadk         r7   k12 ; k12 = 1
.line	1198	jmp            0  l155
.label	l144
.line	1198	test          r2     0
.line	1198	jmp            0  l150
.line	1198	lt             0    r4   k13 ; k13 = 2
.line	1198	jmp            0  l150
.line	1198	loadk         r7   k13 ; k13 = 2
.line	1198	jmp            0  l155
.label	l150
.line	1198	test          r2     0
.line	1198	jmp            0  l155
.line	1198	eq             0    r4   k13 ; k13 = 2
.line	1198	jmp            0  l155
.line	1198	loadk         r7   k17 ; k17 = 3
.label	l155
.line	1198	test          r6     0
.line	1198	jmp            0  l214
.line	1198	self          r8    r0    k5 ; k5 = "_SetRPRewardGlowVisi" (truncated)
.line	1198	newtable     r10     6     0
.line	1198	loadbool     r11     0     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	loadbool     r14     0     0
.line	1198	loadbool     r15     0     0
.line	1198	loadbool     r16     0     0
.line	1198	setlist      r10     6     1
.line	1198	call          r8     3     1
.line	1198	self          r8    r0   k14 ; k14 = "_SetRPJumpVisible"
.line	1198	newtable     r10     3     0
.line	1198	loadbool     r11     0     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	setlist      r10     3     1
.line	1198	call          r8     3     1
.line	1198	self          r8    r0   k15 ; k15 = "_SetRPBuyBtnState"
.line	1198	newtable     r10     3     0
.line	1198	loadbool     r11     1     0
.line	1198	loadbool     r12     1     0
.line	1198	loadbool     r13     1     0
.line	1198	setlist      r10     3     1
.line	1198	newtable     r11     3     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	loadbool     r14     0     0
.line	1198	setlist      r11     3     1
.line	1198	call          r8     4     1
.line	1198	self          r8    r0   k18 ; k18 = "_SetRPReceiveBtnEnab" (truncated)
.line	1198	newtable     r10     3     0
.line	1198	loadbool     r11     0     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	setlist      r10     3     1
.line	1198	call          r8     3     1
.line	1198	newtable      r8     3     0
.line	1198	getupval      r9    u6
.line	1198	getupval     r10    u6
.line	1198	getupval     r11    u6
.line	1198	setlist       r8     3     1
.line	1198	newtable      r9     3     0
.line	1198	getupval     r10    u7
.line	1198	getupval     r11    u7
.line	1198	getupval     r12    u7
.line	1198	setlist       r9     3     1
.line	1198	test          r7     0
.line	1198	jmp            0  l209
.line	1198	getupval     r10    u8
.line	1198	settable      r8    r7   r10
.line	1198	getupval     r10    u2
.line	1198	settable      r9    r7   r10
.label	l209
.line	1198	self         r10    r0    k4 ; k4 = "_SetRPRewardTexts"
.line	1198	move         r12    r8
.line	1198	move         r13    r9
.line	1198	call         r10     4     1
.line	1198	jmp            0  l305
.label	l214
.line	1198	newtable      r8     3     0
.line	1198	loadbool      r9     0     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     0     0
.line	1198	setlist       r8     3     1
.line	1198	test          r7     0
.line	1198	jmp            0  l222
.line	1198	settable      r8    r7   k19 ; k19 = true
.label	l222
.line	1198	self          r9    r0   k18 ; k18 = "_SetRPReceiveBtnEnab" (truncated)
.line	1198	move         r11    r8
.line	1198	call          r9     3     1
.line	1198	test          r2     0
.line	1198	jmp            0  l252
.line	1198	test          r3     1
.line	1198	jmp            0  l252
.line	1198	self          r9    r0    k5 ; k5 = "_SetRPRewardGlowVisi" (truncated)
.line	1198	newtable     r11     6     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     1     0
.line	1198	loadbool     r14     1     0
.line	1198	loadbool     r15     1     0
.line	1198	loadbool     r16     0     0
.line	1198	loadbool     r17     1     0
.line	1198	setlist      r11     6     1
.line	1198	call          r9     3     1
.line	1198	self          r9    r0    k4 ; k4 = "_SetRPRewardTexts"
.line	1198	newtable     r11     3     0
.line	1198	getupval     r12    u9
.line	1198	getupval     r13    u1
.line	1198	getupval     r14    u1
.line	1198	setlist      r11     3     1
.line	1198	newtable     r12     3     0
.line	1198	getupval     r13    u2
.line	1198	getupval     r14    u2
.line	1198	getupval     r15    u2
.line	1198	setlist      r12     3     1
.line	1198	call          r9     4     1
.line	1198	jmp            0  l305
.label	l252
.line	1198	test          r2     0
.line	1198	jmp            0  l279
.line	1198	lt             0    r4   k13 ; k13 = 2
.line	1198	jmp            0  l279
.line	1198	self          r9    r0    k5 ; k5 = "_SetRPRewardGlowVisi" (truncated)
.line	1198	newtable     r11     6     0
.line	1198	loadbool     r12     1     0
.line	1198	loadbool     r13     1     0
.line	1198	loadbool     r14     0     0
.line	1198	loadbool     r15     0     0
.line	1198	loadbool     r16     0     0
.line	1198	loadbool     r17     1     0
.line	1198	setlist      r11     6     1
.line	1198	call          r9     3     1
.line	1198	self          r9    r0    k4 ; k4 = "_SetRPRewardTexts"
.line	1198	newtable     r11     3     0
.line	1198	getupval     r12    u6
.line	1198	getupval     r13    u9
.line	1198	getupval     r14    u1
.line	1198	setlist      r11     3     1
.line	1198	newtable     r12     3     0
.line	1198	getupval     r13    u7
.line	1198	getupval     r14    u2
.line	1198	getupval     r15    u2
.line	1198	setlist      r12     3     1
.line	1198	call          r9     4     1
.line	1198	jmp            0  l305
.label	l279
.line	1198	test          r2     0
.line	1198	jmp            0  l305
.line	1198	eq             0    r4   k13 ; k13 = 2
.line	1198	jmp            0  l305
.line	1198	self          r9    r0    k5 ; k5 = "_SetRPRewardGlowVisi" (truncated)
.line	1198	newtable     r11     6     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	loadbool     r14     0     0
.line	1198	loadbool     r15     0     0
.line	1198	loadbool     r16     1     0
.line	1198	loadbool     r17     1     0
.line	1198	setlist      r11     6     1
.line	1198	call          r9     3     1
.line	1198	self          r9    r0    k4 ; k4 = "_SetRPRewardTexts"
.line	1198	newtable     r11     3     0
.line	1198	getupval     r12    u6
.line	1198	getupval     r13    u6
.line	1198	getupval     r14    u9
.line	1198	setlist      r11     3     1
.line	1198	newtable     r12     3     0
.line	1198	getupval     r13    u7
.line	1198	getupval     r14    u7
.line	1198	getupval     r15    u2
.line	1198	setlist      r12     3     1
.line	1198	call          r9     4     1
.label	l305
.line	1198	self          r8    r1   k20 ; k20 = "IsGroupFullAndAllBuy" (truncated)
.line	1198	call          r8     2     2
.line	1198	test          r8     0
.line	1198	jmp            0  l323
.line	1198	test          r6     1
.line	1198	jmp            0  l323
.line	1198	test          r7     0
.line	1198	jmp            0  l323
.line	1198	newtable      r9     3     0
.line	1198	loadbool     r10     0     0
.line	1198	loadbool     r11     0     0
.line	1198	loadbool     r12     0     0
.line	1198	setlist       r9     3     1
.line	1198	settable      r9    r7   k19 ; k19 = true
.line	1198	self         r10    r0    k6 ; k6 = "_SetRPRewardReddot"
.line	1198	move         r12    r9
.line	1198	call         r10     3     1
.line	1198	jmp            0  l330
.label	l323
.line	1198	self          r9    r0    k6 ; k6 = "_SetRPRewardReddot"
.line	1198	newtable     r11     3     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	loadbool     r14     0     0
.line	1198	setlist      r11     3     1
.line	1198	call          r9     3     1
.label	l330
.line	1198	test          r8     1
.line	1198	jmp            0  l342
.line	1198	self          r9    r0    k5 ; k5 = "_SetRPRewardGlowVisi" (truncated)
.line	1198	newtable     r11     6     0
.line	1198	loadbool     r12     0     0
.line	1198	loadbool     r13     0     0
.line	1198	loadbool     r14     0     0
.line	1198	loadbool     r15     0     0
.line	1198	loadbool     r16     0     0
.line	1198	loadbool     r17     0     0
.line	1198	setlist      r11     6     1
.line	1198	call          r9     3     1
.label	l342
.line	1198	return        r0     1
.line	1198	move          r0    r0
.line	1198	move          r0    r0
.line	1198	move          r0    r0
.line	1198	return        r0     1

.function	main/f69

.source	null
.linedefined	1431
.lastlinedefined	1436
.numparams	1
.is_vararg	0
.maxstacksize	8

.upvalue	"_ENV"	0	false

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"GetIsHadReceiveReward"
.constant	k5	"SetWidgetVisible"
.constant	k6	"UIRoot"
.constant	k7	"Button_FreeGroup"
.constant	k8	"bIsBuyRPTab"
.constant	k9	"UnknowPassSystem"
.constant	k10	"IsBuyElite"
.constant	k11	"UTRichTextBlock_FreeGroupLock"
.constant	k12	"SetText"
.constant	k13	"LocUtil"
.constant	k14	"GetLocalizeResStr"
.constant	k15	18141418

.line	1431	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1431	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1431	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1431	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1431	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	1431	call          r1     2     2
.line	1431	self          r2    r1    k4 ; k4 = "GetIsHadReceiveRewar" (truncated)
.line	1431	call          r2     2     2
.line	1431	self          r3    r0    k5 ; k5 = "SetWidgetVisible"
.line	1431	gettable      r5    r0    k6 ; k6 = "UIRoot"
.line	1431	gettable      r5    r5    k7 ; k7 = "Button_FreeGroup"
.line	1431	gettable      r6    r0    k8 ; k8 = "bIsBuyRPTab"
.line	1431	test          r6     0
.line	1431	jmp            0   l22
.line	1431	test          r2     1
.line	1431	jmp            0   l20
.line	1431	gettabup      r6    u0    k9 ; k9 = "UnknowPassSystem"
.line	1431	gettable      r6    r6   k10 ; k10 = "IsBuyElite"
.line	1431	jmp            0   l22
.label	l20
.line	1431	loadbool      r6     0     1
.line	1431	loadbool      r6     1     0
.label	l22
.line	1431	loadbool      r7     1     0
.line	1431	call          r3     5     1
.line	1431	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1431	gettable      r3    r3   k11 ; k11 = "UTRichTextBlock_Free" (truncated)
.line	1431	self          r3    r3   k12 ; k12 = "SetText"
.line	1431	gettabup      r5    u0   k13 ; k13 = "LocUtil"
.line	1431	gettable      r5    r5   k14 ; k14 = "GetLocalizeResStr"
.line	1431	loadk         r6   k15 ; k15 = 18141418
.line	1431	call          r5     2     0
.line	1431	call          r3     0     1
.line	1431	return        r0     1
.line	1431	move          r0    r0
.line	1431	move          r0    r0
.line	1431	return        r0     1

.function	main/f70

.source	null
.linedefined	1438
.lastlinedefined	1453
.numparams	1
.is_vararg	0
.maxstacksize	24

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"bUseFirstBuyPrivilege"
.constant	k1	"UnknowPassSystem"
.constant	k2	"IsBuyElite"
.constant	k3	"SetWidgetVisible"
.constant	k4	"UIRoot"
.constant	k5	"CanvasPanel_Gift"
.constant	k6	"AutoScrollTextBlock_0"
.constant	k7	"SetText"
.constant	k8	"LocUtil"
.constant	k9	"GetLocalizeResStr"
.constant	k10	87299
.constant	k11	"AutoScrollTextBlock_1"
.constant	k12	87326
.constant	k13	"CDataTable"
.constant	k14	"GetTableData"
.constant	k15	88
.constant	k16	188
.constant	k17	208
.constant	k18	212
.constant	k19	174
.constant	k20	236
.constant	k21	86
.constant	k22	147
.constant	k23	56
.constant	k24	130
.constant	k25	97
.constant	k26	136
.constant	k27	211
.constant	k28	125
.constant	k29	52
.constant	k30	148
.constant	k31	186
.constant	k32	134
.constant	k33	239
.constant	k34	"Season"
.constant	k35	"Lua_CommonItems"
.constant	k36	"InitView"
.constant	k37	"item_id_1"
.constant	k38	"item_num_1"
.constant	k39	0
.constant	k40	"SetClickItemCallback"
.constant	k41	"OnClickRepurchase"

.line	1438	gettable      r1    r0    k0 ; k0 = "bUseFirstBuyPrivileg" (truncated)
.line	1438	test          r1     1
.line	1438	jmp            0    l8
.line	1438	gettabup      r1    u0    k1 ; k1 = "UnknowPassSystem"
.line	1438	gettable      r1    r1    k2 ; k2 = "IsBuyElite"
.line	1438	not           r1    r1
.line	1438	jmp            0   l10
.label	l8
.line	1438	loadbool      r1     0     1
.line	1438	loadbool      r1     1     0
.label	l10
.line	1438	self          r2    r0    k3 ; k3 = "SetWidgetVisible"
.line	1438	gettable      r4    r0    k4 ; k4 = "UIRoot"
.line	1438	gettable      r4    r4    k5 ; k5 = "CanvasPanel_Gift"
.line	1438	move          r5    r1
.line	1438	call          r2     4     1
.line	1438	gettable      r2    r0    k0 ; k0 = "bUseFirstBuyPrivileg" (truncated)
.line	1438	test          r2     0
.line	1438	jmp            0   l19
.line	1438	return        r0     1
.label	l19
.line	1438	gettable      r2    r0    k4 ; k4 = "UIRoot"
.line	1438	gettable      r2    r2    k6 ; k6 = "AutoScrollTextBlock_" (truncated)
.line	1438	self          r2    r2    k7 ; k7 = "SetText"
.line	1438	gettabup      r4    u0    k8 ; k8 = "LocUtil"
.line	1438	gettable      r4    r4    k9 ; k9 = "GetLocalizeResStr"
.line	1438	loadk         r5   k10 ; k10 = 87299
.line	1438	call          r4     2     0
.line	1438	call          r2     0     1
.line	1438	gettable      r2    r0    k4 ; k4 = "UIRoot"
.line	1438	gettable      r2    r2   k11 ; k11 = "AutoScrollTextBlock_" (truncated)
.line	1438	self          r2    r2    k7 ; k7 = "SetText"
.line	1438	gettabup      r4    u0    k8 ; k8 = "LocUtil"
.line	1438	gettable      r4    r4    k9 ; k9 = "GetLocalizeResStr"
.line	1438	loadk         r5   k12 ; k12 = 87326
.line	1438	call          r4     2     0
.line	1438	call          r2     0     1
.line	1438	gettabup      r2    u0   k13 ; k13 = "CDataTable"
.line	1438	gettable      r2    r2   k14 ; k14 = "GetTableData"
.line	1438	getupval      r3    u1
.line	1438	loadk         r4   k15 ; k15 = 88
.line	1438	loadk         r5   k16 ; k16 = 188
.line	1438	loadk         r6   k17 ; k17 = 208
.line	1438	loadk         r7   k18 ; k18 = 212
.line	1438	loadk         r8   k19 ; k19 = 174
.line	1438	loadk         r9   k20 ; k20 = 236
.line	1438	loadk        r10   k21 ; k21 = 86
.line	1438	loadk        r11   k22 ; k22 = 147
.line	1438	loadk        r12   k23 ; k23 = 56
.line	1438	loadk        r13   k21 ; k21 = 86
.line	1438	loadk        r14   k24 ; k24 = 130
.line	1438	loadk        r15   k25 ; k25 = 97
.line	1438	loadk        r16   k26 ; k26 = 136
.line	1438	loadk        r17   k27 ; k27 = 211
.line	1438	loadk        r18   k28 ; k28 = 125
.line	1438	loadk        r19   k29 ; k29 = 52
.line	1438	loadk        r20   k30 ; k30 = 148
.line	1438	loadk        r21   k31 ; k31 = 186
.line	1438	loadk        r22   k32 ; k32 = 134
.line	1438	loadk        r23   k33 ; k33 = 239
.line	1438	call          r3    21     2
.line	1438	gettabup      r4    u0    k1 ; k1 = "UnknowPassSystem"
.line	1438	gettable      r4    r4   k34 ; k34 = "Season"
.line	1438	call          r2     3     2
.line	1438	test          r2     1
.line	1438	jmp            0   l65
.line	1438	return        r0     1
.label	l65
.line	1438	gettable      r3    r0    k4 ; k4 = "UIRoot"
.line	1438	gettable      r3    r3   k35 ; k35 = "Lua_CommonItems"
.line	1438	self          r4    r3   k36 ; k36 = "InitView"
.line	1438	gettable      r6    r2   k37 ; k37 = "item_id_1"
.line	1438	gettable      r7    r2   k38 ; k38 = "item_num_1"
.line	1438	loadk         r8   k39 ; k39 = 0
.line	1438	call          r4     5     1
.line	1438	self          r4    r3   k40 ; k40 = "SetClickItemCallback"
.line	1438	gettable      r6    r0   k41 ; k41 = "OnClickRepurchase"
.line	1438	move          r7    r0
.line	1438	call          r4     4     1
.line	1438	return        r0     1
.line	1438	move          r0    r0
.line	1438	move          r0    r0
.line	1438	move          r0    r0
.line	1438	return        r0     1

.function	main/f71

.source	null
.linedefined	1455
.lastlinedefined	1514
.numparams	1
.is_vararg	0
.maxstacksize	54

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"GetRPGroupInviteRecordList"
.constant	k5	"IsJoinedRPGroup"
.constant	k6	"UIRoot"
.constant	k7	"WidgetSwitcher_4"
.constant	k8	"SetActiveWidgetIndex"
.constant	k9	0
.constant	k10	1
.constant	k11	2
.constant	k12	"UnknowPassSystem"
.constant	k13	"IsBuyElite"
.constant	k14	"WidgetSwitcher_2"
.constant	k15	"IsBuyEliteSeg2"
.constant	k16	"PassType"
.constant	k17	"SetWidgetVisible"
.constant	k18	"Button_UpgradeRPPlus"
.constant	k19	"UTRichTextBlock_UpgradeRPPlus"
.constant	k20	"SetText"
.constant	k21	"LocUtil"
.constant	k22	"GetLocalizeResStr"
.constant	k23	18130180
.constant	k24	18130179
.constant	k25	"GetIsHadReceiveReward"
.constant	k26	"GetMyTeamMemberCount"
.constant	k27	"UTRichTextBlock_0"
.constant	k28	"LocalizeResFormat"
.constant	k29	18130167
.constant	k30	"IsGroupFullAndAllBuyedRP"
.constant	k31	18140053
.constant	k32	18130170
.constant	k33	"WidgetSwitcher_Tips"
.constant	k34	"TextBlock_MemberNum"
.constant	k35	18141416
.constant	k36	"TextBlock_RewardTips"
.constant	k37	18141461
.constant	k38	"GetGroupBuyedRPMemberNum"
.constant	k39	"UTRichTextBlock_MemberNum"
.constant	k40	18141465
.constant	k41	3
.constant	k42	"GetRPGroupTeamMemberList"
.constant	k43	"uid"
.constant	k44	"tonumber"
.constant	k45	"DataMgr"
.constant	k46	"roleData"
.constant	k47	"Button_QuickGroup"
.constant	k48	"GetIsNeedShowDelTips"
.constant	k49	"ResetDelTipsStatus"
.constant	k50	101001
.constant	k51	18130187
.constant	k52	"require"
.constant	k53	"table"
.constant	k54	"concat"
.constant	k55	77
.constant	k56	141
.constant	k57	242
.constant	k58	221
.constant	k59	134
.constant	k60	204
.constant	k61	68
.constant	k62	216
.constant	k63	7
.constant	k64	120
.constant	k65	145
.constant	k66	46
.constant	k67	184
.constant	k68	214
.constant	k69	62
.constant	k70	183
.constant	k71	179
.constant	k72	139
.constant	k73	166
.constant	k74	121
.constant	k75	230
.constant	k76	56
.constant	k77	171
.constant	k78	53
.constant	k79	105
.constant	k80	203
.constant	k81	69
.constant	k82	163
.constant	k83	137
.constant	k84	103
.constant	k85	37
.constant	k86	173
.constant	k87	146
.constant	k88	253
.constant	k89	126
.constant	k90	240
.constant	k91	165
.constant	k92	94
.constant	k93	131
.constant	k94	212
.constant	k95	185
.constant	k96	"ShowMsgBox"

.line	1455	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1455	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1455	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1455	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1455	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	1455	call          r1     2     2
.line	1455	self          r2    r1    k4 ; k4 = "GetRPGroupInviteReco" (truncated)
.line	1455	loadbool      r4     1     0
.line	1455	call          r2     3     2
.line	1455	self          r3    r1    k5 ; k5 = "IsJoinedRPGroup"
.line	1455	call          r3     2     2
.line	1455	test          r3     0
.line	1455	jmp            0   l20
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3    k7 ; k7 = "WidgetSwitcher_4"
.line	1455	self          r3    r3    k8 ; k8 = "SetActiveWidgetIndex"
.line	1455	loadk         r5    k9 ; k9 = 0
.line	1455	call          r3     3     1
.line	1455	jmp            0   l34
.label	l20
.line	1455	len           r3    r2
.line	1455	lt             0    k9    r3 ; k9 = 0
.line	1455	jmp            0   l29
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3    k7 ; k7 = "WidgetSwitcher_4"
.line	1455	self          r3    r3    k8 ; k8 = "SetActiveWidgetIndex"
.line	1455	loadk         r5   k10 ; k10 = 1
.line	1455	call          r3     3     1
.line	1455	jmp            0   l34
.label	l29
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3    k7 ; k7 = "WidgetSwitcher_4"
.line	1455	self          r3    r3    k8 ; k8 = "SetActiveWidgetIndex"
.line	1455	loadk         r5   k11 ; k11 = 2
.line	1455	call          r3     3     1
.label	l34
.line	1455	gettabup      r3    u0   k12 ; k12 = "UnknowPassSystem"
.line	1455	gettable      r3    r3   k13 ; k13 = "IsBuyElite"
.line	1455	test          r3     0
.line	1455	jmp            0   l88
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3   k14 ; k14 = "WidgetSwitcher_2"
.line	1455	self          r3    r3    k8 ; k8 = "SetActiveWidgetIndex"
.line	1455	loadk         r5    k9 ; k9 = 0
.line	1455	call          r3     3     1
.line	1455	gettabup      r3    u0   k12 ; k12 = "UnknowPassSystem"
.line	1455	gettable      r3    r3   k15 ; k15 = "IsBuyEliteSeg2"
.line	1455	test          r3     0
.line	1455	jmp            0   l73
.line	1455	gettabup      r3    u0   k12 ; k12 = "UnknowPassSystem"
.line	1455	gettable      r3    r3   k16 ; k16 = "PassType"
.line	1455	eq             0    r3   k10 ; k10 = 1
.line	1455	jmp            0   l66
.line	1455	self          r3    r0   k17 ; k17 = "SetWidgetVisible"
.line	1455	gettable      r5    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r5    r5   k18 ; k18 = "Button_UpgradeRPPlus"
.line	1455	loadbool      r6     1     0
.line	1455	loadbool      r7     1     0
.line	1455	call          r3     5     1
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3   k19 ; k19 = "UTRichTextBlock_Upgr" (truncated)
.line	1455	self          r3    r3   k20 ; k20 = "SetText"
.line	1455	gettabup      r5    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r5    r5   k22 ; k22 = "GetLocalizeResStr"
.line	1455	loadk         r6   k23 ; k23 = 18130180
.line	1455	call          r5     2     0
.line	1455	call          r3     0     1
.line	1455	jmp            0   l93
.label	l66
.line	1455	self          r3    r0   k17 ; k17 = "SetWidgetVisible"
.line	1455	gettable      r5    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r5    r5   k18 ; k18 = "Button_UpgradeRPPlus"
.line	1455	loadbool      r6     0     0
.line	1455	loadbool      r7     1     0
.line	1455	call          r3     5     1
.line	1455	jmp            0   l93
.label	l73
.line	1455	self          r3    r0   k17 ; k17 = "SetWidgetVisible"
.line	1455	gettable      r5    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r5    r5   k18 ; k18 = "Button_UpgradeRPPlus"
.line	1455	loadbool      r6     1     0
.line	1455	loadbool      r7     1     0
.line	1455	call          r3     5     1
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3   k19 ; k19 = "UTRichTextBlock_Upgr" (truncated)
.line	1455	self          r3    r3   k20 ; k20 = "SetText"
.line	1455	gettabup      r5    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r5    r5   k22 ; k22 = "GetLocalizeResStr"
.line	1455	loadk         r6   k24 ; k24 = 18130179
.line	1455	call          r5     2     0
.line	1455	call          r3     0     1
.line	1455	jmp            0   l93
.label	l88
.line	1455	gettable      r3    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r3    r3   k14 ; k14 = "WidgetSwitcher_2"
.line	1455	self          r3    r3    k8 ; k8 = "SetActiveWidgetIndex"
.line	1455	loadk         r5   k10 ; k10 = 1
.line	1455	call          r3     3     1
.label	l93
.line	1455	self          r3    r1   k25 ; k25 = "GetIsHadReceiveRewar" (truncated)
.line	1455	call          r3     2     2
.line	1455	test          r3     0
.line	1455	jmp            0  l103
.line	1455	self          r4    r0   k17 ; k17 = "SetWidgetVisible"
.line	1455	gettable      r6    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r6    r6   k18 ; k18 = "Button_UpgradeRPPlus"
.line	1455	loadbool      r7     0     0
.line	1455	loadbool      r8     1     0
.line	1455	call          r4     5     1
.label	l103
.line	1455	self          r4    r1   k26 ; k26 = "GetMyTeamMemberCount"
.line	1455	call          r4     2     2
.line	1455	gettable      r5    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r5    r5   k27 ; k27 = "UTRichTextBlock_0"
.line	1455	self          r5    r5   k20 ; k20 = "SetText"
.line	1455	gettabup      r7    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r7    r7   k28 ; k28 = "LocalizeResFormat"
.line	1455	loadk         r8   k29 ; k29 = 18130167
.line	1455	move          r9    r4
.line	1455	call          r7     3     0
.line	1455	call          r5     0     1
.line	1455	self          r5    r1   k30 ; k30 = "IsGroupFullAndAllBuy" (truncated)
.line	1455	call          r5     2     2
.line	1455	test          r5     0
.line	1455	jmp            0  l127
.line	1455	gettable      r6    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r6    r6   k27 ; k27 = "UTRichTextBlock_0"
.line	1455	self          r6    r6   k20 ; k20 = "SetText"
.line	1455	gettabup      r8    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r8    r8   k22 ; k22 = "GetLocalizeResStr"
.line	1455	loadk         r9   k31 ; k31 = 18140053
.line	1455	call          r8     2     0
.line	1455	call          r6     0     1
.line	1455	jmp            0  l135
.label	l127
.line	1455	gettable      r6    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r6    r6   k27 ; k27 = "UTRichTextBlock_0"
.line	1455	self          r6    r6   k20 ; k20 = "SetText"
.line	1455	gettabup      r8    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r8    r8   k22 ; k22 = "GetLocalizeResStr"
.line	1455	loadk         r9   k32 ; k32 = 18130170
.line	1455	call          r8     2     0
.line	1455	call          r6     0     1
.label	l135
.line	1455	gettable      r6    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r6    r6   k33 ; k33 = "WidgetSwitcher_Tips"
.line	1455	self          r6    r6    k8 ; k8 = "SetActiveWidgetIndex"
.line	1455	test          r5     0
.line	1455	jmp            0  l143
.line	1455	loadk         r8    k9 ; k9 = 0
.line	1455	test          r8     1
.line	1455	jmp            0  l144
.label	l143
.line	1455	loadk         r8   k10 ; k10 = 1
.label	l144
.line	1455	call          r6     3     1
.line	1455	gettable      r6    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r6    r6   k34 ; k34 = "TextBlock_MemberNum"
.line	1455	self          r6    r6   k20 ; k20 = "SetText"
.line	1455	gettabup      r8    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r8    r8   k22 ; k22 = "GetLocalizeResStr"
.line	1455	loadk         r9   k35 ; k35 = 18141416
.line	1455	call          r8     2     0
.line	1455	call          r6     0     1
.line	1455	gettable      r6    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r6    r6   k36 ; k36 = "TextBlock_RewardTips"
.line	1455	self          r6    r6   k20 ; k20 = "SetText"
.line	1455	gettabup      r8    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r8    r8   k22 ; k22 = "GetLocalizeResStr"
.line	1455	loadk         r9   k37 ; k37 = 18141461
.line	1455	call          r8     2     0
.line	1455	call          r6     0     1
.line	1455	self          r6    r1   k38 ; k38 = "GetGroupBuyedRPMembe" (truncated)
.line	1455	call          r6     2     2
.line	1455	gettable      r7    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable      r7    r7   k39 ; k39 = "UTRichTextBlock_Memb" (truncated)
.line	1455	self          r7    r7   k20 ; k20 = "SetText"
.line	1455	gettabup      r9    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r9    r9   k28 ; k28 = "LocalizeResFormat"
.line	1455	loadk        r10   k40 ; k40 = 18141465
.line	1455	move         r11    r6
.line	1455	loadk        r12   k41 ; k41 = 3
.line	1455	call          r9     4     0
.line	1455	call          r7     0     1
.line	1455	self          r7    r1   k42 ; k42 = "GetRPGroupTeamMember" (truncated)
.line	1455	call          r7     2     2
.line	1455	len           r8    r7
.line	1455	eq             0    r8   k10 ; k10 = 1
.line	1455	jmp            0  l194
.line	1455	gettable      r8    r7   k10 ; k10 = 1
.line	1455	gettable      r8    r8   k43 ; k43 = "uid"
.line	1455	gettabup      r9    u0   k44 ; k44 = "tonumber"
.line	1455	gettabup     r10    u0   k45 ; k45 = "DataMgr"
.line	1455	gettable     r10   r10   k46 ; k46 = "roleData"
.line	1455	gettable     r10   r10   k43 ; k43 = "uid"
.line	1455	call          r9     2     2
.line	1455	eq             0    r8    r9
.line	1455	jmp            0  l194
.line	1455	self          r8    r0   k17 ; k17 = "SetWidgetVisible"
.line	1455	gettable     r10    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable     r10   r10   k47 ; k47 = "Button_QuickGroup"
.line	1455	loadbool     r11     1     0
.line	1455	loadbool     r12     1     0
.line	1455	call          r8     5     1
.line	1455	jmp            0  l200
.label	l194
.line	1455	self          r8    r0   k17 ; k17 = "SetWidgetVisible"
.line	1455	gettable     r10    r0    k6 ; k6 = "UIRoot"
.line	1455	gettable     r10   r10   k47 ; k47 = "Button_QuickGroup"
.line	1455	loadbool     r11     0     0
.line	1455	loadbool     r12     1     0
.line	1455	call          r8     5     1
.label	l200
.line	1455	self          r8    r1   k48 ; k48 = "GetIsNeedShowDelTips"
.line	1455	call          r8     2     2
.line	1455	test          r8     0
.line	1455	jmp            0  l276
.line	1455	self          r8    r1   k49 ; k49 = "ResetDelTipsStatus"
.line	1455	call          r8     2     1
.line	1455	gettabup      r8    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r8    r8   k28 ; k28 = "LocalizeResFormat"
.line	1455	loadk         r9   k50 ; k50 = 101001
.line	1455	call          r8     2     2
.line	1455	gettabup      r9    u0   k21 ; k21 = "LocUtil"
.line	1455	gettable      r9    r9   k28 ; k28 = "LocalizeResFormat"
.line	1455	loadk        r10   k51 ; k51 = 18130187
.line	1455	call          r9     2     2
.line	1455	gettabup     r10    u0   k52 ; k52 = "require"
.line	1455	gettabup     r11    u0   k53 ; k53 = "table"
.line	1455	gettable     r11   r11   k54 ; k54 = "concat"
.line	1455	newtable     r12     1     0
.line	1455	getupval     r13    u1
.line	1455	loadk        r14   k55 ; k55 = 77
.line	1455	loadk        r15   k56 ; k56 = 141
.line	1455	loadk        r16   k57 ; k57 = 242
.line	1455	loadk        r17   k58 ; k58 = 221
.line	1455	loadk        r18   k59 ; k59 = 134
.line	1455	loadk        r19   k60 ; k60 = 204
.line	1455	loadk        r20   k61 ; k61 = 68
.line	1455	loadk        r21   k62 ; k62 = 216
.line	1455	loadk        r22   k63 ; k63 = 7
.line	1455	loadk        r23   k64 ; k64 = 120
.line	1455	loadk        r24   k65 ; k65 = 145
.line	1455	loadk        r25   k66 ; k66 = 46
.line	1455	loadk        r26   k67 ; k67 = 184
.line	1455	loadk        r27   k68 ; k68 = 214
.line	1455	loadk        r28   k55 ; k55 = 77
.line	1455	loadk        r29   k69 ; k69 = 62
.line	1455	loadk        r30   k70 ; k70 = 183
.line	1455	loadk        r31   k71 ; k71 = 179
.line	1455	loadk        r32   k72 ; k72 = 139
.line	1455	loadk        r33   k73 ; k73 = 166
.line	1455	loadk        r34   k74 ; k74 = 121
.line	1455	loadk        r35   k75 ; k75 = 230
.line	1455	loadk        r36   k76 ; k76 = 56
.line	1455	loadk        r37   k77 ; k77 = 171
.line	1455	loadk        r38   k78 ; k78 = 53
.line	1455	loadk        r39   k79 ; k79 = 105
.line	1455	loadk        r40   k80 ; k80 = 203
.line	1455	loadk        r41   k81 ; k81 = 69
.line	1455	loadk        r42   k82 ; k82 = 163
.line	1455	loadk        r43   k83 ; k83 = 137
.line	1455	loadk        r44   k84 ; k84 = 103
.line	1455	loadk        r45   k85 ; k85 = 37
.line	1455	loadk        r46   k86 ; k86 = 173
.line	1455	loadk        r47   k86 ; k86 = 173
.line	1455	loadk        r48   k87 ; k87 = 146
.line	1455	loadk        r49   k88 ; k88 = 253
.line	1455	loadk        r50   k89 ; k89 = 126
.line	1455	loadk        r51   k90 ; k90 = 240
.line	1455	loadk        r52   k78 ; k78 = 53
.line	1455	loadk        r53   k91 ; k91 = 165
.line	1455	call         r13    41     2
.line	1455	getupval     r14    u1
.line	1455	loadk        r15   k92 ; k92 = 94
.line	1455	loadk        r16   k93 ; k93 = 131
.line	1455	loadk        r17   k90 ; k90 = 240
.line	1455	loadk        r18   k94 ; k94 = 212
.line	1455	loadk        r19   k95 ; k95 = 185
.line	1455	call         r14     6     0
.line	1455	setlist      r12     0     1
.line	1455	call         r11     2     2
.line	1455	call         r10     2     2
.line	1455	gettable     r11   r10   k96 ; k96 = "ShowMsgBox"
.line	1455	loadk        r12   k10 ; k10 = 1
.line	1455	move         r13    r8
.line	1455	move         r14    r9
.line	1455	closure      r15    f0
.line	1455	call         r11     5     1
.label	l276
.line	1455	return        r0     1
.line	1455	move          r0    r0
.line	1455	return        r0     1

.function	main/f71/f0

.source	null
.linedefined	1509
.lastlinedefined	1512
.numparams	0
.is_vararg	0
.maxstacksize	44

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	false

.constant	k0	"require"
.constant	k1	"table"
.constant	k2	"concat"
.constant	k3	105
.constant	k4	128
.constant	k5	246
.constant	k6	221
.constant	k7	164
.constant	k8	205
.constant	k9	11
.constant	k10	133
.constant	k11	38
.constant	k12	98
.constant	k13	148
.constant	k14	46
.constant	k15	150
.constant	k16	216
.constant	k17	89
.constant	k18	50
.constant	k19	153
.constant	k20	242
.constant	k21	154
.constant	k22	230
.constant	k23	81
.constant	k24	231
.constant	k25	58
.constant	k26	177
.constant	k27	5
.constant	k28	119
.constant	k29	132
.constant	k30	99
.constant	k31	137
.constant	k32	66
.constant	k33	36
.constant	k34	141
.constant	k35	165
.constant	k36	156
.constant	k37	199
.constant	k38	95
.constant	k39	247
.constant	k40	184
.constant	k41	101
.constant	k42	155
.constant	k43	239
.constant	k44	217
.constant	k45	185
.constant	k46	202
.constant	k47	122
.constant	k48	63
.constant	k49	110
.constant	k50	"OpenBuyUI"

.line	1509	gettabup      r0    u0    k0 ; k0 = "require"
.line	1509	gettabup      r1    u0    k1 ; k1 = "table"
.line	1509	gettable      r1    r1    k2 ; k2 = "concat"
.line	1509	newtable      r2     1     0
.line	1509	getupval      r3    u1
.line	1509	loadk         r4    k3 ; k3 = 105
.line	1509	loadk         r5    k4 ; k4 = 128
.line	1509	loadk         r6    k5 ; k5 = 246
.line	1509	loadk         r7    k6 ; k6 = 221
.line	1509	loadk         r8    k7 ; k7 = 164
.line	1509	loadk         r9    k8 ; k8 = 205
.line	1509	loadk        r10    k9 ; k9 = 11
.line	1509	loadk        r11   k10 ; k10 = 133
.line	1509	loadk        r12   k11 ; k11 = 38
.line	1509	loadk        r13   k12 ; k12 = 98
.line	1509	loadk        r14   k13 ; k13 = 148
.line	1509	loadk        r15   k14 ; k14 = 46
.line	1509	loadk        r16   k15 ; k15 = 150
.line	1509	loadk        r17   k16 ; k16 = 216
.line	1509	loadk        r18   k17 ; k17 = 89
.line	1509	loadk        r19   k18 ; k18 = 50
.line	1509	loadk        r20   k19 ; k19 = 153
.line	1509	loadk        r21   k20 ; k20 = 242
.line	1509	loadk        r22   k21 ; k21 = 154
.line	1509	loadk        r23   k22 ; k22 = 230
.line	1509	loadk        r24   k23 ; k23 = 81
.line	1509	loadk        r25   k24 ; k24 = 231
.line	1509	loadk        r26   k25 ; k25 = 58
.line	1509	loadk        r27   k26 ; k26 = 177
.line	1509	loadk        r28   k27 ; k27 = 5
.line	1509	loadk        r29   k28 ; k28 = 119
.line	1509	loadk        r30   k29 ; k29 = 132
.line	1509	loadk        r31   k30 ; k30 = 99
.line	1509	loadk        r32   k19 ; k19 = 153
.line	1509	loadk        r33   k31 ; k31 = 137
.line	1509	loadk        r34   k32 ; k32 = 66
.line	1509	loadk        r35   k33 ; k33 = 36
.line	1509	loadk        r36   k34 ; k34 = 141
.line	1509	loadk        r37   k35 ; k35 = 165
.line	1509	loadk        r38   k36 ; k36 = 156
.line	1509	loadk        r39   k37 ; k37 = 199
.line	1509	loadk        r40   k38 ; k38 = 95
.line	1509	loadk        r41   k39 ; k39 = 247
.line	1509	loadk        r42   k14 ; k14 = 46
.line	1509	loadk        r43   k40 ; k40 = 184
.line	1509	call          r3    41     2
.line	1509	getupval      r4    u1
.line	1509	loadk         r5   k41 ; k41 = 101
.line	1509	loadk         r6   k42 ; k42 = 155
.line	1509	loadk         r7   k43 ; k43 = 239
.line	1509	loadk         r8   k44 ; k44 = 217
.line	1509	loadk         r9   k45 ; k45 = 185
.line	1509	loadk        r10   k46 ; k46 = 202
.line	1509	loadk        r11   k47 ; k47 = 122
.line	1509	loadk        r12   k13 ; k13 = 148
.line	1509	loadk        r13   k48 ; k48 = 63
.line	1509	loadk        r14   k49 ; k49 = 110
.line	1509	call          r4    11     0
.line	1509	setlist       r2     0     1
.line	1509	call          r1     2     2
.line	1509	call          r0     2     2
.line	1509	gettable      r1    r0   k50 ; k50 = "OpenBuyUI"
.line	1509	call          r1     1     1
.line	1509	return        r0     1
.line	1509	move          r0    r0
.line	1509	return        r0     1

.function	main/f72

.source	null
.linedefined	1516
.lastlinedefined	1528
.numparams	1
.is_vararg	0
.maxstacksize	22

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayRPGroupModule"
.constant	k4	"GetRPGroupInviteRecordList"
.constant	k5	"LoopScrollBox_GroupList"
.constant	k6	"SetData"
.constant	k7	"require"
.constant	k8	105
.constant	k9	131
.constant	k10	242
.constant	k11	213
.constant	k12	165
.constant	k13	215
.constant	k14	11
.constant	k15	130
.constant	k16	43
.constant	k17	117
.constant	k18	153
.constant	k19	101
.constant	k20	194
.constant	k21	74
.constant	k22	50
.constant	k23	150
.constant	k24	"CopyTable"
.constant	k25	"GetRPGroupTeamMemberList"
.constant	k26	1
.constant	k27	3
.constant	k28	"LoopScrollBox_TeamMember"

.line	1516	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1516	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1516	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1516	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1516	gettable      r2    r2    k3 ; k3 = "BlackFridayRPGroupMo" (truncated)
.line	1516	call          r1     2     2
.line	1516	self          r2    r1    k4 ; k4 = "GetRPGroupInviteReco" (truncated)
.line	1516	loadbool      r4     1     0
.line	1516	call          r2     3     2
.line	1516	gettable      r3    r0    k5 ; k5 = "LoopScrollBox_GroupL" (truncated)
.line	1516	self          r3    r3    k6 ; k6 = "SetData"
.line	1516	move          r5    r2
.line	1516	call          r3     3     1
.line	1516	gettabup      r3    u0    k7 ; k7 = "require"
.line	1516	getupval      r4    u1
.line	1516	loadk         r5    k8 ; k8 = 105
.line	1516	loadk         r6    k9 ; k9 = 131
.line	1516	loadk         r7   k10 ; k10 = 242
.line	1516	loadk         r8   k11 ; k11 = 213
.line	1516	loadk         r9   k12 ; k12 = 165
.line	1516	loadk        r10   k13 ; k13 = 215
.line	1516	loadk        r11   k14 ; k14 = 11
.line	1516	loadk        r12   k15 ; k15 = 130
.line	1516	loadk        r13   k16 ; k16 = 43
.line	1516	loadk        r14   k17 ; k17 = 117
.line	1516	loadk        r15   k18 ; k18 = 153
.line	1516	loadk        r16   k19 ; k19 = 101
.line	1516	loadk        r17   k12 ; k12 = 165
.line	1516	loadk        r18   k20 ; k20 = 194
.line	1516	loadk        r19   k21 ; k21 = 74
.line	1516	loadk        r20   k22 ; k22 = 50
.line	1516	loadk        r21   k23 ; k23 = 150
.line	1516	call          r4    18     2
.line	1516	call          r3     2     2
.line	1516	gettable      r4    r3   k24 ; k24 = "CopyTable"
.line	1516	self          r5    r1   k25 ; k25 = "GetRPGroupTeamMember" (truncated)
.line	1516	call          r5     2     0
.line	1516	call          r4     0     2
.line	1516	loadk         r5   k26 ; k26 = 1
.line	1516	loadk         r6   k27 ; k27 = 3
.line	1516	loadk         r7   k26 ; k26 = 1
.line	1516	move          r0    r0
.line	1516	lt             0   k26    r8 ; k26 = 1
.line	1516	jmp            0   l50
.line	1516	gettable      r9    r4    r8
.line	1516	test          r9     1
.line	1516	jmp            0   l50
.line	1516	newtable      r9     0     0
.line	1516	settable      r4    r8    r9
.label	l50
.line	1516	move          r0    r0
.line	1516	gettable      r5    r0   k28 ; k28 = "LoopScrollBox_TeamMe" (truncated)
.line	1516	self          r5    r5    k6 ; k6 = "SetData"
.line	1516	move          r7    r4
.line	1516	call          r5     3     1
.line	1516	return        r0     1
.line	1516	move          r0    r0
.line	1516	move          r0    r0
.line	1516	move          r0    r0
.line	1516	return        r0     1

.function	main/f73

.source	null
.linedefined	1530
.lastlinedefined	1534
.numparams	1
.is_vararg	0
.maxstacksize	3

.constant	k0	"InitEventRules"
.constant	k1	"InitActivityTime"
.constant	k2	"InitActivityTitle"

.line	1530	self          r1    r0    k0 ; k0 = "InitEventRules"
.line	1530	call          r1     2     1
.line	1530	self          r1    r0    k1 ; k1 = "InitActivityTime"
.line	1530	call          r1     2     1
.line	1530	self          r1    r0    k2 ; k2 = "InitActivityTitle"
.line	1530	call          r1     2     1
.line	1530	return        r0     1
.line	1530	move          r0    r0
.line	1530	move          r0    r0
.line	1530	move          r0    r0
.line	1530	move          r0    r0
.line	1530	return        r0     1

.function	main/f74

.source	null
.linedefined	1536
.lastlinedefined	1543
.numparams	1
.is_vararg	0
.maxstacksize	5

.upvalue	"_ENV"	0	false
.upvalue	"U1"	5	true

.constant	k0	"ModuleManager"
.constant	k1	"GetModule"
.constant	k2	"LobbyModuleConfig"
.constant	k3	"BlackFridayMainModule"
.constant	k4	"GetActivityConfigByType"
.constant	k5	"RPGroup"
.constant	k6	0
.constant	k7	"start_time"
.constant	k8	"end_time"

.line	1536	gettabup      r1    u0    k0 ; k0 = "ModuleManager"
.line	1536	gettable      r1    r1    k1 ; k1 = "GetModule"
.line	1536	gettabup      r2    u0    k0 ; k0 = "ModuleManager"
.line	1536	gettable      r2    r2    k2 ; k2 = "LobbyModuleConfig"
.line	1536	gettable      r2    r2    k3 ; k3 = "BlackFridayMainModul" (truncated)
.line	1536	call          r1     2     2
.line	1536	self          r2    r1    k4 ; k4 = "GetActivityConfigByT" (truncated)
.line	1536	gettabup      r4    u1    k5 ; k5 = "RPGroup"
.line	1536	call          r2     3     2
.line	1536	test          r2     1
.line	1536	jmp            0   l15
.line	1536	loadk         r3    k6 ; k6 = 0
.line	1536	loadk         r4    k6 ; k6 = 0
.line	1536	return        r3     3
.label	l15
.line	1536	gettable      r3    r2    k7 ; k7 = "start_time"
.line	1536	gettable      r4    r2    k8 ; k8 = "end_time"
.line	1536	return        r3     3
.line	1536	return        r0     1
.line	1536	move          r0    r0
.line	1536	move          r0    r0
.line	1536	return        r0     1

.function	main/f75

.source	null
.linedefined	1545
.lastlinedefined	1556
.numparams	2
.is_vararg	0
.maxstacksize	47

.upvalue	"_ENV"	0	false
.upvalue	"U1"	1	true

.constant	k0	"next"
.constant	k1	"require"
.constant	k2	"table"
.constant	k3	"concat"
.constant	k4	105
.constant	k5	128
.constant	k6	246
.constant	k7	221
.constant	k8	164
.constant	k9	205
.constant	k10	11
.constant	k11	133
.constant	k12	38
.constant	k13	98
.constant	k14	148
.constant	k15	46
.constant	k16	150
.constant	k17	216
.constant	k18	89
.constant	k19	50
.constant	k20	153
.constant	k21	242
.constant	k22	140
.constant	k23	231
.constant	k24	87
.constant	k25	228
.constant	k26	58
.constant	k27	168
.constant	k28	116
.constant	k29	68
.constant	k30	138
.constant	k31	125
.constant	k32	135
.constant	k33	200
.constant	k34	64
.constant	k35	2
.constant	k36	158
.constant	k37	169
.constant	k38	146
.constant	k39	223
.constant	k40	79
.constant	k41	237
.constant	k42	107
.constant	k43	154
.constant	k44	101
.constant	k45	139
.constant	k46	219
.constant	k47	149
.constant	k48	250
.constant	k49	74
.constant	k50	155
.constant	k51	39
.constant	k52	120
.constant	k53	73
.constant	k54	142
.constant	k55	210
.constant	k56	83
.constant	k57	28
.constant	k58	159
.constant	k59	77
.constant	k60	141
.constant	k61	134
.constant	k62	204
.constant	k63	7
.constant	k64	145
.constant	k65	182
.constant	k66	92
.constant	k67	57
.constant	k68	131
.constant	k69	173
.constant	k70	233
.constant	k71	236
.constant	k72	123
.constant	k73	132
.constant	k74	54
.constant	k75	102
.constant	k76	172
.constant	k77	213
.constant	k78	71
.constant	k79	47
.constant	k80	181
.constant	k81	209
.constant	k82	212
.constant	k83	69
.constant	k84	254
.constant	k85	44
.constant	k86	36
.constant	k87	174
.constant	k88	243
.constant	k89	217
.constant	k90	99
.constant	k91	35
.constant	k92	115
.constant	k93	121
.constant	k94	170
.constant	k95	78
.constant	k96	137
.constant	k97	225
.constant	k98	86
.constant	k99	"Push"
.constant	k100	"Func"
.constant	k101	"ShowPanel_DefaultStyle"
.constant	k102	"Params"
.constant	k103	"MustShow"
.constant	k104	true

.line	1545	test          r1     0
.line	1545	jmp            0    l8
.line	1545	gettabup      r2    u0    k0 ; k0 = "next"
.line	1545	move          r3    r1
.line	1545	call          r2     2     2
.line	1545	test          r2     1
.line	1545	jmp            0    l9
.label	l8
.line	1545	return        r0     1
.label	l9
.line	1545	gettabup      r2    u0    k1 ; k1 = "require"
.line	1545	gettabup      r3    u0    k2 ; k2 = "table"
.line	1545	gettable      r3    r3    k3 ; k3 = "concat"
.line	1545	newtable      r4     1     0
.line	1545	getupval      r5    u1
.line	1545	loadk         r6    k4 ; k4 = 105
.line	1545	loadk         r7    k5 ; k5 = 128
.line	1545	loadk         r8    k6 ; k6 = 246
.line	1545	loadk         r9    k7 ; k7 = 221
.line	1545	loadk        r10    k8 ; k8 = 164
.line	1545	loadk        r11    k9 ; k9 = 205
.line	1545	loadk        r12   k10 ; k10 = 11
.line	1545	loadk        r13   k11 ; k11 = 133
.line	1545	loadk        r14   k12 ; k12 = 38
.line	1545	loadk        r15   k13 ; k13 = 98
.line	1545	loadk        r16   k14 ; k14 = 148
.line	1545	loadk        r17   k15 ; k15 = 46
.line	1545	loadk        r18   k16 ; k16 = 150
.line	1545	loadk        r19   k17 ; k17 = 216
.line	1545	loadk        r20   k18 ; k18 = 89
.line	1545	loadk        r21   k19 ; k19 = 50
.line	1545	loadk        r22   k20 ; k20 = 153
.line	1545	loadk        r23   k21 ; k21 = 242
.line	1545	loadk        r24   k22 ; k22 = 140
.line	1545	loadk        r25   k23 ; k23 = 231
.line	1545	loadk        r26   k24 ; k24 = 87
.line	1545	loadk        r27   k25 ; k25 = 228
.line	1545	loadk        r28   k26 ; k26 = 58
.line	1545	loadk        r29   k27 ; k27 = 168
.line	1545	loadk        r30   k28 ; k28 = 116
.line	1545	loadk        r31   k29 ; k29 = 68
.line	1545	loadk        r32   k30 ; k30 = 138
.line	1545	loadk        r33   k31 ; k31 = 125
.line	1545	loadk        r34   k32 ; k32 = 135
.line	1545	loadk        r35   k33 ; k33 = 200
.line	1545	loadk        r36   k34 ; k34 = 64
.line	1545	loadk        r37   k35 ; k35 = 2
.line	1545	loadk        r38   k36 ; k36 = 158
.line	1545	loadk        r39   k37 ; k37 = 169
.line	1545	loadk        r40   k38 ; k38 = 146
.line	1545	loadk        r41   k39 ; k39 = 223
.line	1545	loadk        r42   k40 ; k40 = 79
.line	1545	loadk        r43   k41 ; k41 = 237
.line	1545	loadk        r44   k42 ; k42 = 107
.line	1545	loadk        r45   k43 ; k43 = 154
.line	1545	call          r5    41     2
.line	1545	getupval      r6    u1
.line	1545	loadk         r7   k44 ; k44 = 101
.line	1545	loadk         r8   k45 ; k45 = 139
.line	1545	loadk         r9    k6 ; k6 = 246
.line	1545	loadk        r10   k46 ; k46 = 219
.line	1545	loadk        r11   k47 ; k47 = 149
.line	1545	loadk        r12   k48 ; k48 = 250
.line	1545	loadk        r13   k49 ; k49 = 74
.line	1545	loadk        r14   k50 ; k50 = 155
.line	1545	loadk        r15   k51 ; k51 = 39
.line	1545	loadk        r16   k52 ; k52 = 120
.line	1545	loadk        r17   k50 ; k50 = 155
.line	1545	loadk        r18   k53 ; k53 = 73
.line	1545	loadk        r19   k54 ; k54 = 142
.line	1545	loadk        r20   k55 ; k55 = 210
.line	1545	loadk        r21   k56 ; k56 = 83
.line	1545	loadk        r22   k57 ; k57 = 28
.line	1545	loadk        r23   k58 ; k58 = 159
.line	1545	loadk        r24   k27 ; k27 = 168
.line	1545	call          r6    19     0
.line	1545	setlist       r4     0     1
.line	1545	call          r3     2     2
.line	1545	call          r2     2     2
.line	1545	gettabup      r3    u0    k1 ; k1 = "require"
.line	1545	gettabup      r4    u0    k2 ; k2 = "table"
.line	1545	gettable      r4    r4    k3 ; k3 = "concat"
.line	1545	newtable      r5     1     0
.line	1545	getupval      r6    u1
.line	1545	loadk         r7   k59 ; k59 = 77
.line	1545	loadk         r8   k60 ; k60 = 141
.line	1545	loadk         r9   k21 ; k21 = 242
.line	1545	loadk        r10    k7 ; k7 = 221
.line	1545	loadk        r11   k61 ; k61 = 134
.line	1545	loadk        r12   k62 ; k62 = 204
.line	1545	loadk        r13   k29 ; k29 = 68
.line	1545	loadk        r14   k17 ; k17 = 216
.line	1545	loadk        r15   k63 ; k63 = 7
.line	1545	loadk        r16   k52 ; k52 = 120
.line	1545	loadk        r17   k64 ; k64 = 145
.line	1545	loadk        r18   k15 ; k15 = 46
.line	1545	loadk        r19   k65 ; k65 = 182
.line	1545	loadk        r20   k17 ; k17 = 216
.line	1545	loadk        r21   k66 ; k66 = 92
.line	1545	loadk        r22   k67 ; k67 = 57
.line	1545	loadk        r23   k68 ; k68 = 131
.line	1545	loadk        r24   k21 ; k21 = 242
.line	1545	loadk        r25   k69 ; k69 = 173
.line	1545	loadk        r26   k70 ; k70 = 233
.line	1545	loadk        r27   k53 ; k53 = 73
.line	1545	loadk        r28   k71 ; k71 = 236
.line	1545	loadk        r29   k72 ; k72 = 123
.line	1545	loadk        r30   k73 ; k73 = 132
.line	1545	loadk        r31   k74 ; k74 = 54
.line	1545	loadk        r32   k75 ; k75 = 102
.line	1545	loadk        r33   k61 ; k61 = 134
.line	1545	loadk        r34   k72 ; k72 = 123
.line	1545	loadk        r35   k76 ; k76 = 172
.line	1545	loadk        r36   k77 ; k77 = 213
.line	1545	loadk        r37   k78 ; k78 = 71
.line	1545	loadk        r38   k79 ; k79 = 47
.line	1545	loadk        r39   k45 ; k45 = 139
.line	1545	loadk        r40   k80 ; k80 = 181
.line	1545	loadk        r41   k81 ; k81 = 209
.line	1545	loadk        r42   k82 ; k82 = 212
.line	1545	loadk        r43   k83 ; k83 = 69
.line	1545	loadk        r44   k84 ; k84 = 254
.line	1545	loadk        r45   k85 ; k85 = 44
.line	1545	loadk        r46   k80 ; k80 = 181
.line	1545	call          r6    41     2
.line	1545	getupval      r7    u1
.line	1545	loadk         r8   k86 ; k86 = 36
.line	1545	loadk         r9   k87 ; k87 = 174
.line	1545	loadk        r10   k88 ; k88 = 243
.line	1545	loadk        r11   k89 ; k89 = 217
.line	1545	loadk        r12   k37 ; k37 = 169
.line	1545	loadk        r13   k55 ; k55 = 210
.line	1545	loadk        r14   k90 ; k90 = 99
.line	1545	loadk        r15   k73 ; k73 = 132
.line	1545	loadk        r16   k91 ; k91 = 35
.line	1545	loadk        r17   k92 ; k92 = 115
.line	1545	loadk        r18   k14 ; k14 = 148
.line	1545	loadk        r19   k93 ; k93 = 121
.line	1545	loadk        r20   k94 ; k94 = 170
.line	1545	loadk        r21   k17 ; k17 = 216
.line	1545	loadk        r22   k95 ; k95 = 78
.line	1545	loadk        r23   k15 ; k15 = 46
.line	1545	loadk        r24   k30 ; k30 = 138
.line	1545	loadk        r25   k96 ; k96 = 137
.line	1545	loadk        r26   k50 ; k50 = 155
.line	1545	loadk        r27   k97 ; k97 = 225
.line	1545	loadk        r28   k98 ; k98 = 86
.line	1545	call          r7    22     0
.line	1545	setlist       r5     0     1
.line	1545	call          r4     2     2
.line	1545	call          r3     2     2
.line	1545	gettable      r4    r3   k99 ; k99 = "Push"
.line	1545	newtable      r5     0     3
.line	1545	gettable      r6    r2  k101 ; k101 = "ShowPanel_DefaultSty" (truncated)
.line	1545	settable      r5  k100    r6 ; k100 = "Func"
.line	1545	newtable      r6     1     0
.line	1545	move          r7    r1
.line	1545	setlist       r6     1     1
.line	1545	settable      r5  k102    r6 ; k102 = "Params"
.line	1545	settable      r5  k103  k104 ; k104 = true
.line	1545	loadbool      r6     1     0
.line	1545	call          r4     3     1
.line	1545	return        r0     1
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	move          r0    r0
.line	1545	return        r0     1

.function	main/f76

.source	"=[V12L:030d397a845e8053:83d96ce621352c3c]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f77

.source	"=[V11_@Black_MagicYT BlackMagiYT_LBIND_00]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_0_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f78

.source	"=[V11_@Black_MagicYT BlackMagiYT_SYSC_01]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_1_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f79

.source	"=[V11_@Black_MagicYT BlackMagiYT_MRGE_02]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_2_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

.function	main/f80

.source	"=[V11_@Black_MagicYT BlackMagiYT_POOL_03]"
.linedefined	0
.lastlinedefined	0
.numparams	0
.is_vararg	0
.maxstacksize	2

.constant	k0	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX_TRAP_3_"
.constant	k1	9223372034707292159

.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1  c= 1
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	move          r0    r0
.line	0	return        r0     1

