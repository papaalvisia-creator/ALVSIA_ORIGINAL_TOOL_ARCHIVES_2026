do return (require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(63, 173, 54, 89, 88)))(require(((function(...)
  do return table.concat({
    [...] = string.char((({
      ...
    })[...] ~ U1[(... - 1) % 16 + 1] ~ ((... - 1) * 31 + 7) % 256) % 256)
  }) end
  return
end)(63, 173, 62, 79, 69, 75, 201, 14, 247, 104, 205, 94, 44, 137, 32, 205, 205, 156, 66, 109, 180, 125, 252, 125, 197, 115, 204, 87, 53, 163, 20, 206, 207, 132))), nil, {
  ["DefineAndResetData"] = function(_ARG_0_)
    do
      if _ARG_0_._nPendingSmallRPCardBatchTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._nPendingSmallRPCardBatchTimer)
      end
      __super.DefineAndResetData(_ARG_0_)
      _ARG_0_._tActivityDataMap = {}
      _ARG_0_._bBatchPlayerDataReady = false
      _ARG_0_._bBatchPlayerDataRequesting = false
      _ARG_0_._tPendingSmallRPCardCallbackMap = nil
      _ARG_0_._nPendingSmallRPCardBatchTimer = nil
      _ARG_0_._nLuckyRefundClaimTime = nil
      _ARG_0_._nLuckyRefundClaimBenefitId = nil
      _ARG_0_._nLuckyRefundLastClaimTime = nil
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RegistEvents"] = function(_ARG_0_)
    do
      __super.RegistEvents(_ARG_0_)
      _ARG_0_:AddCommonEvent(U1.EVENTTYPE_COMMON_SCORE_PRO_BAR, U1.EVENTID_COMMON_SCORE_PRO_BAR_CHECK_SHOW, function()
        goto lbl_9
        ::lbl_9::
        return
      end, _ARG_0_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["NormalizeActivityId"] = function(_ARG_0_, _ARG_1_)
    do
      if not tonumber(_ARG_1_) or tonumber(_ARG_1_) <= 0 or tonumber(_ARG_1_) ~= math.floor((tonumber(_ARG_1_))) then
        return
      end
      do return (tonumber(_ARG_1_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetActivityData"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) or type(_ARG_2_) ~= U1(40, 160, 53, 70, 78) or type(_ARG_3_) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      if _ARG_2_.act_term_id and _ARG_0_:NormalizeActivityId(_ARG_2_.act_term_id) ~= _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return false
      end
      ;(_ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}).activity_id = _ARG_0_:NormalizeActivityId(_ARG_1_), _ARG_2_.act_term_id, _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}
      ;(_ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}).player_data = _ARG_2_
      ;(_ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}).control_cfg = _ARG_3_
      ;(_ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}).level_cfg = nil
      if not _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] then
        ;(_ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}).cur_level = 1
      end
      _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] = _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or {}, not _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)], _ARG_0_._tActivityDataMap
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetBatchActivityData"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_1_) ~= U1(40, 160, 53, 70, 78) then
        return 0, false
      end
      _ARG_0_._tActivityDataMap = {}
      goto lbl_72
      if type(78) ~= U1(40, 160, 53, 70, 78) or not _ARG_0_:SetActivityData(70, (78).small_rp_data, (78).control_cfg) then
        _ARG_0_._tActivityDataMap = _ARG_0_._tActivityDataMap
        return 0, false
      end
      if (_ARG_0_:NormalizeActivityId(70) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(70)] or nil) and (_ARG_0_:NormalizeActivityId(70) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(70)] or nil) then
        ;(_ARG_0_:NormalizeActivityId(70) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(70)] or nil).level_award_cfg = (_ARG_0_:NormalizeActivityId(70) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(70)] or nil).level_award_cfg
        ;(_ARG_0_:NormalizeActivityId(70) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(70)] or nil).level_group = (_ARG_0_:NormalizeActivityId(70) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(70)] or nil).level_group
      end
      ::lbl_72::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return 0 + 1, true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActivityData"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:NormalizeActivityId(_ARG_1_) and _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetPlayerData"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).player_data or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetControlCfg"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).control_cfg or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActivityId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).activity_id or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActRoundId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityId(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActTime"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return
      end
      if not _ENV((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      do return _ENV((_ARG_0_:NormalizeActivityId(_ARG_1_))).StartTime, _ENV((_ARG_0_:NormalizeActivityId(_ARG_1_))).EndTime end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsOpen"] = function(_ARG_0_, _ARG_1_)
    do
      if type(_ARG_0_:GetActTime(_ARG_1_)) ~= U1(50, 180, 58, 72, 78, 77) or type(_ARG_0_:GetActTime(_ARG_1_)) ~= U1(50, 180, 58, 72, 78, 77) then
        return false
      end
      do return _ARG_0_:GetActTime(_ARG_1_) <= require((U1(63, 173, 62, 79, 69, 75, 201, 0, 247, 97, 213, 93, 39, 248, 50, 214, 193, 148, 120, 111, 175, 102, 251))).GetServerTimeInSec() and _ARG_0_:GetActTime(_ARG_1_) >= require((U1(63, 173, 62, 79, 69, 75, 201, 0, 247, 97, 213, 93, 39, 248, 50, 214, 193, 148, 120, 111, 175, 102, 251))).GetServerTimeInSec() end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActShowCfg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActRoundId(_ARG_1_) then
        return
      end
      if not (CDataTable.GetTableData(U1(15, 172, 54, 70, 71, 109, 183, 34, 251, 120, 209, 68, 32, 162, 63, 236, 196, 158, 80, 89, 189, 104), (_ARG_0_:GetActRoundId(_ARG_1_))) or {}).TemplateBasePath or (CDataTable.GetTableData(U1(15, 172, 54, 70, 71, 109, 183, 34, 251, 120, 209, 68, 32, 162, 63, 236, 196, 158, 80, 89, 189, 104), (_ARG_0_:GetActRoundId(_ARG_1_))) or {}).TemplateBasePath == U1() then
        return
      end
      do return CDataTable.GetTableData(U1(15, 172, 54, 70, 71, 109, 183, 34, 251, 120, 209, 68, 32, 162, 63, 236, 196, 158, 80, 89, 189, 104), (_ARG_0_:GetActRoundId(_ARG_1_))) or {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetSmallRPCardId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).unlock_card_item_id or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetActivityIdBySmallRPCardId"] = function(_ARG_0_, _ARG_1_)
    do
      if not tonumber(_ARG_1_) then
        return
      end
      goto lbl_30
      if tonumber(_ARG_0_:GetOpenActivityList().activity_id) and _ARG_0_:GetIsOpen((tonumber(_ARG_0_:GetOpenActivityList().activity_id))) and tonumber(_ARG_0_:GetSmallRPCardId((tonumber(_ARG_0_:GetOpenActivityList().activity_id)))) == tonumber(_ARG_1_) then
        return (tonumber(_ARG_0_:GetOpenActivityList().activity_id))
      end
      ::lbl_30::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestActivityIdBySmallRPCardId"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not tonumber(_ARG_1_) or type(_ARG_2_) ~= U1(58, 180, 57, 73, 95, 86, 136, 13) then
        return false
      end
      if _ARG_0_:GetActivityIdBySmallRPCardId((tonumber(_ARG_1_))) then
        return true
      end
      if _ARG_0_._bBatchPlayerDataReady then
        return false
      end
      _ARG_0_._tPendingSmallRPCardCallbackMap = _ARG_0_._tPendingSmallRPCardCallbackMap or {}
      if not _ARG_0_._tPendingSmallRPCardCallbackMap[tonumber(_ARG_1_)] then
        _ARG_0_._tPendingSmallRPCardCallbackMap[tonumber(_ARG_1_)] = {}, _ARG_0_._tPendingSmallRPCardCallbackMap
      end
      if not _ARG_0_._bBatchPlayerDataRequesting then
        _ARG_0_._bBatchPlayerDataRequesting = true
        _ARG_0_._nPendingSmallRPCardBatchTimer = _ARG_0_:AddTimerOnce(U2, function()
          _nPendingSmallRPCardBatchTimer = nil
          if _bBatchPlayerDataRequesting then
            _ENV:FlushPendingSmallRPCardCallbacks(false)
          end
          return
        end)
      end
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["FlushPendingSmallRPCardCallbacks"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_._nPendingSmallRPCardBatchTimer then
        _ARG_0_:RemoveTimer(_ARG_0_._nPendingSmallRPCardBatchTimer)
        _ARG_0_._nPendingSmallRPCardBatchTimer = nil
      end
      _ARG_0_._bBatchPlayerDataRequesting = false
      _ARG_0_._bBatchPlayerDataReady = _ARG_1_
      _ARG_0_._tPendingSmallRPCardCallbackMap = nil
      if not _ARG_0_._tPendingSmallRPCardCallbackMap then
        return
      end
      goto lbl_36
      goto lbl_34
      ::lbl_34::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_36::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIPLineActId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).concerned_crossover_id or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIPScoreId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).crossover_score_res_id or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIPLineMaxProgressScore"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetIPLineActId(_ARG_1_) then
        return
      end
      if not _ENV((_ARG_0_:GetIPLineActId(_ARG_1_))) or U1.type(_ENV((_ARG_0_:GetIPLineActId(_ARG_1_))).List) ~= U2(40, 160, 53, 70, 78) or not (U1.ActivityType and U1.ActivityType.PROGRESS_REWARD_ACT or nil) then
        return
      end
      goto lbl_48
      if (70).Type == (U1.ActivityType and U1.ActivityType.PROGRESS_REWARD_ACT or nil) then
      end
      ::lbl_48::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return ({})[#{}] and ({})[#{}].Condition and ({})[#{}].Condition[1] or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevelExtraGetIPScoreNum"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).crossover_score_count or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScoreConversionUCValue"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_2_ = tonumber(_ARG_2_)
      if not _ARG_0_:GetActRoundId(_ARG_1_) or not _ARG_2_ then
        return 0
      end
      do return tonumber((CDataTable.GetTableData(U1(15, 172, 54, 70, 71, 109, 183, 34, 251, 120, 209, 68, 32, 162, 63, 253, 217, 136, 100, 124, 188), (_ARG_0_:GetActRoundId(_ARG_1_))) or {}).ScoreValue) and math.ceil(_ARG_2_ * tonumber((CDataTable.GetTableData(U1(15, 172, 54, 70, 71, 109, 183, 34, 251, 120, 209, 68, 32, 162, 63, 253, 217, 136, 100, 124, 188), (_ARG_0_:GetActRoundId(_ARG_1_))) or {}).ScoreValue)) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetUnlockNeedUC"] = function(_ARG_0_, _ARG_1_)
    do
      if tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).lucky_discount_pay_uc) and tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).lucky_discount_pay_uc) > 0 then
        return (tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).lucky_discount_pay_uc))
      end
      if tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).origin_unlock_cost_uc) and 0 < tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).origin_unlock_cost_uc) then
        return (tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).origin_unlock_cost_uc))
      end
      if not _ARG_0_:GetActRoundId(_ARG_1_) then
        return 0
      end
      do return (CDataTable.GetTableData(U1(15, 172, 54, 70, 71, 109, 183, 34, 251, 120, 209, 68, 32, 162, 63, 253, 217, 136, 100, 124, 188), (_ARG_0_:GetActRoundId(_ARG_1_))) or {}).UnlockCost or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevelAwardCfg"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).level_award_cfg or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllTaskData"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and type(_ARG_0_:GetActivityData(_ARG_1_).task_data) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetActivityData(_ARG_1_).task_data or {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllTaskProReward"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and type(_ARG_0_:GetActivityData(_ARG_1_).stage_awards) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetActivityData(_ARG_1_).stage_awards or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsTaskDataValid"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return false
      end
      do return _ENV() and _ENV() and _ENV():GetCacheData(_ENV()) ~= nil or false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestTaskData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return false
      end
      if not _ENV() or not _ENV() then
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurRoundTaskCfg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return {}
      end
      if _ARG_0_:GetActivityData(_ARG_1_).task_cfg then
        return _ARG_0_:GetActivityData(_ARG_1_).task_cfg
      end
      goto lbl_65
      ::lbl_65::
      _ARG_0_ = _ARG_0_
      _ARG_0_:GetActivityData(_ARG_1_).task_cfg, _ARG_0_ = {}, _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTaskStatusByTaskId"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type((_ARG_0_:GetTaskDataByTaskId(_ARG_1_, _ARG_2_))) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetTaskDataByTaskId(_ARG_1_, _ARG_2_).status or U2.Unfinished end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTaskDataByTaskId"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return (_ENV(_ARG_0_:GetAllTaskData(_ARG_1_), _ARG_2_)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHasTaskCompletedStatus"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_25
      if type(_ARG_0_:GetAllTaskData(_ARG_1_)) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetAllTaskData(_ARG_1_).status == U2.Completed then
        return true
      end
      ::lbl_25::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetFinishTaskPro"] = function(_ARG_0_, _ARG_1_)
    do
      if #_ARG_0_:GetCurRoundTaskCfg(_ARG_1_) <= 0 then
        return 0
      end
      goto lbl_41
      if (type(_ARG_0_:GetAllTaskData(_ARG_1_)) == U1(40, 160, 53, 70, 78) and tonumber(_ARG_0_:GetAllTaskData(_ARG_1_).status) or nil) == U2.Completed or (type(_ARG_0_:GetAllTaskData(_ARG_1_)) == U1(40, 160, 53, 70, 78) and tonumber(_ARG_0_:GetAllTaskData(_ARG_1_).status) or nil) == U2.Received then
      end
      ::lbl_41::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return math.floor((0 + 1) / #_ARG_0_:GetCurRoundTaskCfg(_ARG_1_) * 100) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsReceivedAllTaskProReward"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetAllTaskProReward(_ARG_1_) then
        return false
      end
      goto lbl_30
      if type(nil) == U1(40, 160, 53, 70, 78) and (nil).status == U2.NotReceived then
        return false
      end
      ::lbl_30::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCanReceiveTaskProRewardCount"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetAllTaskProReward(_ARG_1_) then
        return 0, {}
      end
      _ARG_2_ = tonumber(_ARG_2_)
      if _ARG_2_ == nil then
        _ARG_2_ = _ARG_0_:GetFinishTaskPro(_ARG_1_)
      end
      goto lbl_52
      if type(nil) == U1(40, 160, 53, 70, 78) and tonumber(nil) and _ARG_2_ >= tonumber(nil) and (nil).status == U2.NotReceived then
      end
      ::lbl_52::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return #{}, {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTaskProRewardAwardId"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetAllTaskProReward(_ARG_1_) then
        return
      end
      do return type(next((_ARG_0_:GetAllTaskProReward(_ARG_1_)))) == U1(40, 160, 53, 70, 78) and next((_ARG_0_:GetAllTaskProReward(_ARG_1_))).award or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTaskProRewardMinProValue"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return 0
      end
      if _ARG_0_:GetActivityData(_ARG_1_).task_pro_reward_min ~= nil then
        return _ARG_0_:GetActivityData(_ARG_1_).task_pro_reward_min
      end
      if not _ARG_0_:GetActivityData(_ARG_1_).stage_awards then
        return 0
      end
      goto lbl_33
      if tonumber(nil) and (nil == nil or nil > tonumber(nil)) then
      end
      ::lbl_33::
      _ARG_0_ = _ARG_0_
      _ARG_0_:GetActivityData(_ARG_1_).task_pro_reward_min, _ARG_0_ = tonumber(nil), _ARG_0_
      do return (tonumber(nil)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsUnlock"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetPlayerData(_ARG_1_) and _ARG_0_:GetPlayerData(_ARG_1_).is_unlock or false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurScore"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetPlayerData(_ARG_1_) and _ARG_0_:GetPlayerData(_ARG_1_).score or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetScoreShowItemId"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).score_res_id or 1119 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurLevel"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).cur_level or 1 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["InitLevelCfg"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return false
      end
      goto lbl_71
      if tonumber((35).Level) and tonumber((35).Level) > 0 and tonumber((35).Level) == math.floor((tonumber((35).Level))) and tonumber((35).Score) then
      end
      ::lbl_71::
      _ARG_0_ = _ARG_0_
      _ARG_0_:GetActivityData(_ARG_1_).level_cfg, _ARG_0_ = {
        [tonumber((35).Level)] = tonumber((35).Score)
      }, _ARG_0_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevelScore"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return 0
      end
      _ARG_2_ = tonumber(_ARG_2_)
      do return _ARG_2_ and _ARG_0_:GetActivityData(_ARG_1_).level_cfg and _ARG_0_:GetActivityData(_ARG_1_).level_cfg[_ARG_2_] or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetMaxLevel"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return 0
      end
      goto lbl_28
      ::lbl_28::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return (math.max(0, nil)) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsMaxLevelReached"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetMaxLevel(_ARG_1_) > 0 and _ARG_0_:GetMaxLevel(_ARG_1_) <= _ARG_0_:GetCurLevel(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurLevelUpNeedScore"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return 0
      end
      goto lbl_32
      if nil > _ARG_0_:GetCurLevel(_ARG_1_) and (not nil or nil < nil) then
      end
      ::lbl_32::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not nil then
        return 0
      end
      do return math.max(_ARG_0_:GetLevelScore(_ARG_1_, nil) - _ARG_0_:GetLevelScore(_ARG_1_, (_ARG_0_:GetCurLevel(_ARG_1_))), 0) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCanExchangeScore"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:GetMaxLevel(_ARG_1_) <= 0 then
        return 0
      end
      do return math.max(_ARG_0_:GetCurScore(_ARG_1_) - _ARG_0_:GetLevelScore(_ARG_1_, (_ARG_0_:GetMaxLevel(_ARG_1_))), 0) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurRoundLevelRewardCfg"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetLevelAwardCfg(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowItemIdByLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetShowItemDataByLevel(_ARG_1_, _ARG_2_) and _ARG_0_:GetShowItemDataByLevel(_ARG_1_, _ARG_2_).resid or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetItemDataByLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_) then
        return
      end
      do return U1.type((_ENV(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_), _ARG_2_))) == U2(40, 160, 53, 70, 78) and _ENV(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_), _ARG_2_) or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChooseOneFlagByLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return type(_ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_)[1] or nil) == U1(40, 160, 53, 70, 78) and (_ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_)[1] or nil).select_one or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowItemDataByLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_)[1] or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevelRewardIsGot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetPlayerData(_ARG_1_) or type(_ARG_0_:GetPlayerData(_ARG_1_).level_award) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      do return U2(_ARG_0_:GetPlayerData(_ARG_1_).level_award, _ARG_2_) and true or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevelRewardIsAllGot"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) then
        return _ARG_0_:GetLevelRewardIsGot(_ARG_1_, _ARG_2_)
      end
      if not _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) then
        return false
      end
      _ARG_0_ = _ARG_0_
      if not _ARG_0_:GetChooseOneItemHasGot(_ARG_1_, _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_), nil) then
        return false
      end
      _ARG_0_ = _ARG_0_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLevelRewardIsGotByItemIndex"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) then
        return _ARG_0_:GetChooseOneItemHasGot(_ARG_1_, _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_), _ARG_3_)
      end
      do return _ARG_0_:GetLevelRewardIsGot(_ARG_1_, _ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetHaveRewardCanReceive"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetPlayerData(_ARG_1_) or type((_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_))) ~= U1(40, 160, 53, 70, 78) or not next((_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_))) then
        return false
      end
      goto lbl_67
      if tonumber(53) and _ARG_0_:GetCurLevel(_ARG_1_) >= tonumber(53) and type(70) == U1(40, 160, 53, 70, 78) and next(70) and not _ARG_0_:GetLevelRewardIsGot(_ARG_1_, (tonumber(53))) then
        return true
      end
      ::lbl_67::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurLevelCanReceiveReward"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_) then
        return {}
      end
      _ARG_0_ = _ARG_0_
      if not (nil > _ARG_0_:GetCurLevel(_ARG_1_)) then
        _ARG_0_ = _ARG_0_
      end
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChooseOneGroupLevelGroup"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetChooseOneGroup(_ARG_1_) then
        return
      end
      do return U1.type((_ENV(_ARG_0_:GetChooseOneGroup(_ARG_1_), _ARG_2_))) == U2(40, 160, 53, 70, 78) and _ENV(_ARG_0_:GetChooseOneGroup(_ARG_1_), _ARG_2_) or nil end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChooseOneGroupLevelData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetChooseOneGroupLevelGroup(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelGroup(_ARG_1_, _ARG_2_).levelData or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChooseOneGroup"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return
      end
      if _ARG_0_:GetActivityData(_ARG_1_).level_group then
        return _ARG_0_:GetActivityData(_ARG_1_).level_group
      end
      if not _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_) then
        return
      end
      _ARG_0_ = _ARG_0_
      if type(type(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil]) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil][1] or nil) == U1(40, 160, 53, 70, 78) and (type(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil]) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil][1] or nil).select_one or nil then
      end
      _ARG_0_:GetActivityData(_ARG_1_).level_group, _ARG_0_ = {
        [type(type(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil]) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil][1] or nil) == U1(40, 160, 53, 70, 78) and (type(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil]) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil][1] or nil).select_one or nil] = {
          itemCount = #_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil],
          levelData = {}
        }
      }, _ARG_0_
      do return {
        [type(type(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil]) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil][1] or nil) == U1(40, 160, 53, 70, 78) and (type(_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil]) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil][1] or nil).select_one or nil] = {
          itemCount = #_ARG_0_:GetCurRoundLevelRewardCfg(_ARG_1_)[nil],
          levelData = {}
        }
      } end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChooseOneLevelRewardSingleItem"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      _ARG_3_ = _ARG_3_ or 1
      _ARG_4_ = _ARG_4_ or _ARG_0_:GetCurLevel(_ARG_1_)
      if not (_ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) and (_ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelGroup(_ARG_1_, (_ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_))) or nil)) or type((_ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelGroup(_ARG_1_, (_ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_))) or nil).levelData) ~= U1(40, 160, 53, 70, 78) then
        return
      end
      _ARG_0_ = _ARG_0_
      if not _ARG_0_:GetChooseOneItemHasGot(_ARG_1_, _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_), 53) then
      end
      _ARG_0_ = _ARG_0_
      goto lbl_84
      if not _ARG_0_:GetLevelRewardIsGot(_ARG_1_, (_ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_))) then
      end
      if _ARG_4_ >= _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) and _ARG_3_ <= _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) and tonumber(_ARG_2_) == _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) then
      end
      ::lbl_84::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not (0 + 1) or 0 + 1 < 0 + 1 then
        return
      end
      if 0 + 1 <= 0 + 1 then
        _ARG_0_ = _ARG_0_
        if not _ARG_0_:GetChooseOneItemHasGot(_ARG_1_, _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_), _ARG_1_) then
        end
        if 0 + 1 - 1 == 0 then
          return _ARG_1_
        end
        _ARG_0_ = _ARG_0_
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetChooseOneItemHasGot"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if type(((_ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) or nil) and (_ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) or nil[_ARG_3_] or nil) ~= U1(40, 160, 53, 70, 78) or not ((_ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) or nil) and (_ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) or nil[_ARG_3_] or nil.resid then
        return false
      end
      do return require((U1(63, 173, 62, 79, 69, 75, 201, 16, 244, 121, 217, 28, 37, 185, 33, 214, 207, 223, 80, 123, 169, 107, 229, 60, 234, 121, 134, 85, 56, 180, 50, 221, 211, 131, 82, 85, 175, 126, 243, 34))):HasItem(((_ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) or nil) and (_ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) and _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_) and _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, _ARG_2_)[1] or nil) or nil[_ARG_3_] or nil.resid, true) or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOnlyOneItemIndex"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) or not _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) then
        return
      end
      _ARG_0_ = _ARG_0_
      if not _ARG_0_:GetChooseOneItemHasGot(_ARG_1_, _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_), nil) then
      end
      _ARG_0_ = _ARG_0_
      do return 0 + 1 == 1 and nil or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetAllRewardMultiChooseOne"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) or not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      goto lbl_139
      if type(type(_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward[1] or nil) == U1(40, 160, 53, 70, 78) and (type(_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward[1] or nil).select_one or nil then
        goto lbl_122
        if _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).valid_hours ~= nil and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).valid_hours ~= 0 then
          ;({
            level = _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel,
            group_id = type(type(_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward[1] or nil) == U1(40, 160, 53, 70, 78) and (type(_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward[1] or nil).select_one or nil,
            auto_selected_index = _ARG_0_:GetChooseOneLevelRewardSingleItem(_ARG_0_:NormalizeActivityId(_ARG_1_), _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel),
            all_item_ids = {},
            valid_items = {},
            options = {}
          }).valid_items[_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).res_id or _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).resid] = true
        end
        ::lbl_122::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
        if _ARG_0_:GetChooseOneLevelRewardSingleItem(_ARG_0_:NormalizeActivityId(_ARG_1_), _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel) then
          ;({
            activity_id = _ARG_0_:NormalizeActivityId(_ARG_1_),
            is_batch = true,
            selects = {},
            selected_items = {},
            manual_levels = {},
            levels = {}
          }).selects[_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel] = _ARG_0_:GetChooseOneLevelRewardSingleItem(_ARG_0_:NormalizeActivityId(_ARG_1_), _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel), {
            level = _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel,
            group_id = type(type(_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward[1] or nil) == U1(40, 160, 53, 70, 78) and (type(_ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward) == U1(40, 160, 53, 70, 78) and _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).tAllReward[1] or nil).select_one or nil,
            auto_selected_index = _ARG_0_:GetChooseOneLevelRewardSingleItem(_ARG_0_:NormalizeActivityId(_ARG_1_), _ARG_0_:GetCurLevelCanReceiveReward((_ARG_0_:NormalizeActivityId(_ARG_1_))).nLevel),
            all_item_ids = {},
            valid_items = {},
            options = {}
          }, ({
            activity_id = _ARG_0_:NormalizeActivityId(_ARG_1_),
            is_batch = true,
            selects = {},
            selected_items = {},
            manual_levels = {},
            levels = {}
          }).selects
        else
        end
      end
      ::lbl_139::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {
        activity_id = _ARG_0_:NormalizeActivityId(_ARG_1_),
        is_batch = true,
        selects = {},
        selected_items = {},
        manual_levels = {},
        levels = {}
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCurShowBannerLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      goto lbl_23
      if (nil)[1] and (nil)[1].spec_show == 1 then
      end
      ::lbl_23::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if not next({}) then
        return
      end
      if not _ARG_3_ and not _ARG_0_:GetIsUnlock(_ARG_1_) then
        return ({})[#{}]
      end
      _ARG_2_ = _ARG_2_ or _ARG_0_:GetCurLevel(_ARG_1_)
      goto lbl_54
      if table.insert({}, _ARG_1_) >= _ARG_2_ then
        return (table.insert({}, _ARG_1_))
      end
      ::lbl_54::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return ({})[#{}] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetTipRewardLevelData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return
      end
      if _ARG_0_:GetActivityData(_ARG_1_).reward_tip_levels then
        return _ARG_0_:GetActivityData(_ARG_1_).reward_tip_levels
      end
      if not (_ARG_0_:GetActShowCfg(_ARG_1_) and _ARG_0_:GetActShowCfg(_ARG_1_).ShowRewardTipLevel) or _ARG_0_:GetActShowCfg(_ARG_1_).ShowRewardTipLevel == _ENV() then
        return
      end
      _ARG_0_:GetActivityData(_ARG_1_).reward_tip_levels = U1.require((_ENV(63, 174, 58, 71, 68, 81, 201, 16, 236, 126, 209, 92, 46, 137, 51, 203, 197, 157))).Split(_ARG_0_:GetActShowCfg(_ARG_1_).ShowRewardTipLevel, (_ENV(103))), U1.table.sort(U1.require((_ENV(63, 174, 58, 71, 68, 81, 201, 16, 236, 126, 209, 92, 46, 137, 51, 203, 197, 157))).Split(_ARG_0_:GetActShowCfg(_ARG_1_).ShowRewardTipLevel, (_ENV(103))), function(_ARG_0_, _ARG_1_)
        do
          do return _ARG_0_ < _ARG_1_ end
          do return end
          _ARG_0_ = _ARG_0_
        end
      end)
      do return (U1.require((_ENV(63, 174, 58, 71, 68, 81, 201, 16, 236, 126, 209, 92, 46, 137, 51, 203, 197, 157))).Split(_ARG_0_:GetActShowCfg(_ARG_1_).ShowRewardTipLevel, (_ENV(103)))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRichTextScoreIcon"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActShowCfg(_ARG_1_) and _ARG_0_:GetActShowCfg(_ARG_1_).RichTextScoreIcon or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ReplaceTextScoreIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetRichTextScoreIcon(_ARG_1_) or _ARG_0_:GetRichTextScoreIcon(_ARG_1_) == _ENV() then
        return _ARG_2_
      end
      do return U1.require((_ENV(63, 174, 58, 71, 68, 81, 201, 16, 236, 126, 209, 92, 46, 137, 51, 203, 197, 157))).StrReplace(_ARG_2_, _ENV(53, 172, 48, 10, 88, 77, 132, 94, 186, 65, 209, 92, 32, 166, 54, 246, 193, 144, 64, 127, 249), _ENV(53, 172, 48, 10, 88, 77, 132, 94, 186) .. _ARG_0_:GetRichTextScoreIcon(_ARG_1_) .. _ENV(126)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetCostIcon"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ == require((table.concat({
        U1(63, 173, 62, 79, 69, 75, 201, 16, 244, 121, 217, 28, 42, 185, 40, 217, 197, 150, 9, 89, 183, 102, 242, 61, 252, 81, 201, 65, 43, 169, 37, 129, 255, 142, 94, 100, 134, 126, 228, 49),
        U1(51)
      }))).SmallRPScore then
        _ARG_2_ = _ARG_0_:GetScoreShowItemId(_ARG_1_)
      end
      do return require((U1(63, 173, 62, 79, 69, 75, 201, 0, 247, 97, 213, 93, 39, 248, 51, 214, 243, 132, 83, 115, 183))).GetItemBigIcon(_ARG_2_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConcernCfg"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).concerned_cfg and (_ARG_0_:GetControlCfg(_ARG_1_) and _ARG_0_:GetControlCfg(_ARG_1_).concerned_cfg)[_ARG_2_] or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConcernEntranceID"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetConcernCfg(_ARG_1_, _ARG_2_) and _ARG_0_:GetConcernCfg(_ARG_1_, _ARG_2_).id or nil end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConcernEntranceType"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetConcernCfg(_ARG_1_, _ARG_2_) and _ARG_0_:GetConcernCfg(_ARG_1_, _ARG_2_).type or 0 end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetConcernEntranceUrl"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_) == Enum_EntranceType.Invalid then
        return nil, false
      end
      if not _ARG_0_:GetConcernEntranceID(_ARG_1_, _ARG_2_) then
        return nil, false
      end
      if _ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_) == Enum_EntranceType.SportBox then
        return EntranceUrlTemplate[_ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_)] and U1.string.format(EntranceUrlTemplate[_ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_)], (_ARG_0_:GetConcernEntranceID(_ARG_1_, _ARG_2_))) or nil, false
      end
      do return U2((_ARG_0_:GetConcernEntranceID(_ARG_1_, _ARG_2_))) and U2((_ARG_0_:GetConcernEntranceID(_ARG_1_, _ARG_2_))).ImgLink or nil, not U2((_ARG_0_:GetConcernEntranceID(_ARG_1_, _ARG_2_))) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEntranceImagePath"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not EntranceImageName[_ARG_2_] then
        return DefaultEntranceImagePath
      end
      if not _ARG_0_:GetActShowCfg(_ARG_1_) then
        return DefaultEntranceImagePath
      end
      do return U2.require((U1(63, 173, 62, 79, 69, 75, 201, 0, 247, 97, 213, 93, 39, 248, 54, 222, 199, 174, 82, 110, 178, 99))).IsFileExist(_ARG_0_:GetActShowCfg(_ARG_1_).TemplateBasePath .. U1(18, 174, 22, 94, 71, 94, 148, 76) .. EntranceImageName[_ARG_2_]) and _ARG_0_:GetActShowCfg(_ARG_1_).TemplateBasePath .. U1(18, 174, 22, 94, 71, 94, 148, 76) .. EntranceImageName[_ARG_2_] or DefaultEntranceImagePath end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetEntranceTittleID"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return EntranceTittleID[_ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_)] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsEntranceConnectedRPScore"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return _ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_) ~= 0 and not NotRelatedRPScoreTypeMap[_ARG_0_:GetConcernEntranceType(_ARG_1_, _ARG_2_)] end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["JumpToRelatedModule"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetConcernEntranceUrl(_ARG_1_, _ARG_2_) then
        return
      end
      if _ARG_0_:GetConcernEntranceUrl(_ARG_1_, _ARG_2_) then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["UnlockActBuy"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not _ARG_3_ and require((table.concat({
        U1(63, 173, 62, 79, 69, 75, 201, 16, 244, 121, 217, 28, 37, 185, 33, 214, 207, 223, 118, 72, 152, 96, 243, 54, 196, 115, 207, 75, 55, 232, 26, 192, 219, 136, 84, 85, 154, 77, 196, 44),
        U1(56, 164, 5, 79, 88, 75, 149, 10, 251, 120, 237, 70, 32, 186, 53)
      }))).IsUcUseLimit() then
        return
      end
      if not _ARG_3_ and _ARG_0_:GetUnlockNeedUC(_ARG_1_) > DataMgr.ticket then
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowAlreadyHasGiftConfirm"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["send_small_rp_buy_score_req"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return false
      end
      _ARG_0_:GetActivityData(_ARG_1_).buy_score_callback = _ARG_4_
      if not require((table.concat({
        U1(63, 173, 62, 79, 69, 75, 201, 13, 253, 120, 207, 93, 59, 189, 104, 239, 222, 158, 83, 117, 184, 96, 251, 125, 219, 113, 201, 78, 53, 148, 6, 238, 223, 149, 94, 124, 162, 107, 254, 11),
        U1(61, 175, 51, 70, 78, 77)
      }))).send_small_rp_activity_buy_score_req(_ARG_1_, _ARG_2_, _ARG_3_) then
        _ARG_0_:GetActivityData(_ARG_1_).buy_score_callback = nil
        return false
      end
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetRelatedRewardLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetItemDataByLevel(_ARG_1_, _ARG_2_) then
        return
      end
      if _ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_) then
        return _ARG_0_:GetChooseOneGroupLevelData(_ARG_1_, (_ARG_0_:GetChooseOneFlagByLevel(_ARG_1_, _ARG_2_)))
      end
      do return {_ARG_2_} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetCurLevel"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return 1, 1
      end
      if not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return 1, 1
      end
      if _ARG_0_:GetMaxLevel((_ARG_0_:NormalizeActivityId(_ARG_1_))) and (_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1) >= _ARG_0_:GetMaxLevel((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1, _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1
      end
      goto lbl_59
      if (_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1) < _ARG_0_:NormalizeActivityId(_ARG_1_) then
      end
      ::lbl_59::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_79
      if not (_ARG_0_:GetCurScore((_ARG_0_:NormalizeActivityId(_ARG_1_))) < _ARG_0_:GetLevelScore(_ARG_0_:NormalizeActivityId(_ARG_1_), {})) then
        ::lbl_79::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level = {}
      if _ARG_2_ then
        if (_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1) ~= {} then
          _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).b_is_need_upgrade_anim = true
          if not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).n_upgrade_last_level then
            _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).n_upgrade_last_level = _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1
          end
        end
      end
      do return _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1, {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLevelScoreProBarTip"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return
      end
      if not _ARG_0_:GetActShowCfg((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      if U1.UIManager.IsUIShow(U1.UIManager.UI_Config.NewSupplySystem) or U1.UIManager.IsUIShow(U1.UIManager.UI_Config.NewSupplySystemJK) then
        _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).t_score_pro_bar_queue = _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).t_score_pro_bar_queue or {}
        return
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowScoreProBarTip"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return
      end
      if not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      if not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).t_score_pro_bar_queue or #_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).t_score_pro_bar_queue <= 0 then
        return
      end
      goto lbl_31
      ::lbl_31::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).t_score_pro_bar_queue = nil
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowLevelUpUI"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return
      end
      if not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      if not _ARG_0_:GetIsOpen((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).b_is_need_upgrade_anim = false
        _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).n_upgrade_last_level = nil
        return
      end
      if _ARG_2_ or not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).b_is_need_upgrade_anim then
        return
      end
      _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).b_is_need_upgrade_anim = false
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["CheckShowUnlockRewardPop"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return
      end
      if not _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      if _ARG_0_:GetIsUnlock((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      _ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).n_upgrade_last_level = nil
      if not _ARG_0_:GetTipRewardLevelData((_ARG_0_:NormalizeActivityId(_ARG_1_))) then
        return
      end
      goto lbl_446
      if (_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).n_upgrade_last_level or 1) < tonumber(tostring(_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1)) and (_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1) >= tonumber(tostring(_ARG_0_:GetActivityData((_ARG_0_:NormalizeActivityId(_ARG_1_))).cur_level or 1)) then
        return function()
          return
        end
      end
      ::lbl_446::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetOpenActivityList"] = function(_ARG_0_)
    do
      goto lbl_11
      ::lbl_11::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return {} end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetActivityData"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) or not _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] then
        return false
      end
      _ARG_0_._tActivityDataMap[_ARG_0_:NormalizeActivityId(_ARG_1_)] = nil
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ResetAllActivityData"] = function(_ARG_0_)
    do
      _ARG_0_._tActivityDataMap = {}
      _ENV():ResetAllActivityRedData()
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ShowCommonItemGet"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_:NormalizeActivityId(_ARG_1_) then
        return
      end
      _ARG_5_ = type(_ARG_5_) == U1(40, 160, 53, 70, 78) and _ARG_5_ or {}
      if next(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}) ~= nil then
        if (_ARG_0_:GetIPLineMaxProgressScore((_ARG_0_:NormalizeActivityId(_ARG_1_))) or 0) > (_ARG_0_:GetIPScoreId((_ARG_0_:NormalizeActivityId(_ARG_1_))) and require((U1(63, 173, 62, 79, 69, 75, 201, 16, 244, 121, 217, 28, 37, 185, 33, 214, 207, 223, 68, 117, 182, 98, 248, 61, 166, 80, 199, 69, 48, 165, 9, 230, 200, 132, 90, 95, 191, 118, 235, 48))).GetItemCount((_ARG_0_:GetIPScoreId((_ARG_0_:NormalizeActivityId(_ARG_1_))))) or 0) - (tonumber((type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}).count) or 0) then
          U2(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}).nItemGetGroupId = 2
        else
        end
      end
      do return {
        activity_id = _ARG_0_:NormalizeActivityId(_ARG_1_),
        reward_type = _ARG_5_.reward_type,
        is_batch = _ARG_5_.is_batch and true or false,
        source_id = _ARG_5_.source_id,
        level = _ARG_5_.level,
        task_id = _ARG_5_.task_id,
        stage_progresses = U2(_ARG_5_.stage_progresses or {}),
        stage_rewards = U2(_ARG_5_.stage_rewards or {}),
        all_reward = U2(type(_ARG_2_) == U1(40, 160, 53, 70, 78) and _ARG_2_ or {}),
        decompose_list = U2(type(_ARG_3_) == U1(40, 160, 53, 70, 78) and _ARG_3_ or {}),
        addition_awards = U2(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}),
        display_reward = U2(type(_ARG_2_) == U1(40, 160, 53, 70, 78) and _ARG_2_ or {}),
        display_style = U1(46, 164, 32, 75, 89, 91, 184, 4, 234, 99, 205, 66),
        group_title_text_ids = {4328, 76907},
        show_addition_tip = true,
        has_reward = next(type(_ARG_2_) == U1(40, 160, 53, 70, 78) and _ARG_2_ or {}) ~= nil,
        has_decompose = next(type(_ARG_3_) == U1(40, 160, 53, 70, 78) and _ARG_3_ or {}) ~= nil,
        has_addition = next(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}) ~= nil,
        has_display_reward = next((U2(type(_ARG_2_) == U1(40, 160, 53, 70, 78) and _ARG_2_ or {}))) ~= nil
      } end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["TaskReceiveShowCommonItemGet"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if _ARG_2_ and 0 < _ARG_2_ then
      end
      if _ARG_3_ and 0 < _ARG_3_ then
      end
      _ARG_5_ = type(_ARG_5_) == U1(40, 160, 53, 70, 78) and _ARG_5_ or {}
      _ARG_5_.reward_type = U2.Task
      if _ARG_2_ and 0 < _ARG_2_ and _ARG_3_ and 0 < _ARG_3_ and next((U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}))) then
        U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {})[2], U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {})[1] = U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {})[1], nil
      end
      _ARG_5_.display_style = next((U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}))) and U1(56, 164, 52, 69, 70, 79, 136, 16, 253) or U1(56, 164, 49, 75, 94, 83, 147)
      if _ARG_0_:ShowCommonItemGet(_ARG_1_, {}, U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}), nil, _ARG_5_) then
        _ARG_0_:ShowCommonItemGet(_ARG_1_, {}, U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}), nil, _ARG_5_).reward_score = _ARG_2_ or 0
        _ARG_0_:ShowCommonItemGet(_ARG_1_, {}, U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}), nil, _ARG_5_).score_item_id, _ARG_0_:ShowCommonItemGet(_ARG_1_, {}, U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}), nil, _ARG_5_).decompose_score = _ARG_0_:GetScoreShowItemId(_ARG_1_), _ARG_3_ or 0
      end
      do return (_ARG_0_:ShowCommonItemGet(_ARG_1_, {}, U3(type(_ARG_4_) == U1(40, 160, 53, 70, 78) and _ARG_4_ or {}), nil, _ARG_5_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RequestAllRewardMultiChooseOne"] = function(_ARG_0_, _ARG_1_)
    do
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetIsShowUpgradeLevelPanelLine"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).b_is_show_upgrade_panel_line or false end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetIsShowUpgradeLevelPanelLine"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_0_:GetActivityData(_ARG_1_) then
        _ARG_0_:GetActivityData(_ARG_1_).b_is_show_upgrade_panel_line = _ARG_2_
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["IsGuideCheck"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ENV(_ARG_1_).IsGuideCheck == true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SaveGuideCheck"] = function(_ARG_0_, _ARG_1_)
    do
      _ENV(_ARG_1_).IsGuideCheck = true
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetShowUnlockRewardTime"] = function(_ARG_0_, _ARG_1_)
    do
      do return _ENV(_ARG_1_).nShowUnlockRewardTime end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetShowUnlockRewardTime"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ENV(_ARG_1_).nShowUnlockRewardTime = _ARG_2_
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLuckDrawGuideData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        return (_ENV(_ARG_1_).tLuckDrawGuideActIdMap or {})[U1.tostring(U1.tonumber(_ARG_2_))]
      end
      do return _ENV(_ARG_1_).nLuckDrawGuideActId end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetLuckDrawGuideData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ENV(_ARG_1_).tLuckDrawGuideActIdMap = _ENV(_ARG_1_).tLuckDrawGuideActIdMap or {}
        _ENV(_ARG_1_).tLuckDrawGuideActIdMap[U1.tostring(U1.tonumber(_ARG_2_))] = U1.tonumber(_ARG_2_)
      else
        _ENV(_ARG_1_).nLuckDrawGuideActId = U1.tonumber(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetDoubleDrawGuideData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        return (_ENV(_ARG_1_).tDoubleDrawGuideActIdMap or {})[U1.tostring(U1.tonumber(_ARG_2_))]
      end
      do return _ENV(_ARG_1_).nDoubleDrawGuideActId end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["SetDoubleDrawGuideData"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if _ARG_2_ then
        _ENV(_ARG_1_).tDoubleDrawGuideActIdMap = _ENV(_ARG_1_).tDoubleDrawGuideActIdMap or {}
        _ENV(_ARG_1_).tDoubleDrawGuideActIdMap[U1.tostring(U1.tonumber(_ARG_2_))] = U1.tonumber(_ARG_2_)
      else
        _ENV(_ARG_1_).nDoubleDrawGuideActId = U1.tonumber(_ARG_1_)
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_player_data_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if _ARG_0_:SetActivityData(_ARG_1_, _ARG_2_, _ARG_3_) then
      end
      do return (_ARG_0_:SetActivityData(_ARG_1_, _ARG_2_, _ARG_3_)) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_batch_player_data_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      if _ARG_0_:SetBatchActivityData(_ARG_1_) then
        goto lbl_24
        ::lbl_24::
        _ARG_0_ = _ARG_0_
        _ARG_0_ = _ARG_0_
      end
      do return _ARG_0_:SetBatchActivityData(_ARG_1_) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_level_award_cfg_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) or type(_ARG_2_) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      _ARG_0_:GetActivityData(_ARG_1_).level_award_cfg = _ARG_2_
      _ARG_0_:GetActivityData(_ARG_1_).level_group = nil
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_unlock_rsp"] = function(_ARG_0_, _ARG_1_)
    do
      if not _ARG_0_:GetPlayerData(_ARG_1_) then
        return false
      end
      _ARG_0_:GetPlayerData(_ARG_1_).is_unlock = true
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["GetLuckyDiscountRefundInfo"] = function(_ARG_0_, _ARG_1_)
    do
      do return tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).lucky_discount_refund_status) or U1.None, tonumber((_ARG_0_:GetControlCfg(_ARG_1_) or {}).lucky_discount_refund_uc) or 0 end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["HasLuckyDiscountRefundBenefit"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not require((table.concat({
        U1(27, 160, 58, 79, 103, 74, 134, 77, 213, 99, 220, 28, 5, 185, 36, 221, 213, 223, 101, 123, 168, 106, 185, 17, 228, 125, 203, 73, 31, 180, 63, 203, 221, 152, 25, 70, 164, 120, 238, 32),
        U1(114, 131, 59, 75, 72, 84, 161, 17, 241, 104, 217, 75, 5, 163, 37, 212, 213, 178, 70, 104, 191, 75, 254, 32, 248, 112, 201, 91, 26, 169, 56, 201, 213, 134)
      }))).GetActivityCardByActivityID(_ARG_1_) then
        return false
      end
      goto lbl_191
      if tonumber(require((table.concat({
        U1(27, 160, 58, 79, 103, 74, 134, 77, 213, 99, 220, 28, 5, 185, 36, 221, 213, 223, 101, 123, 168, 106, 185, 17, 228, 125, 203, 73, 31, 180, 63, 203, 221, 152, 25, 70, 164, 120, 238, 32),
        U1(114, 131, 59, 75, 72, 84, 161, 17, 241, 104, 217, 75, 5, 163, 37, 212, 213, 178, 70, 104, 191, 75, 254, 32, 248, 112, 201, 91, 26, 169, 56, 201, 213, 134)
      }))).GetBenefitRelationsByCard(require((table.concat({
        U1(27, 160, 58, 79, 103, 74, 134, 77, 213, 99, 220, 28, 5, 185, 36, 221, 213, 223, 101, 123, 168, 106, 185, 17, 228, 125, 203, 73, 31, 180, 63, 203, 221, 152, 25, 70, 164, 120, 238, 32),
        U1(114, 131, 59, 75, 72, 84, 161, 17, 241, 104, 217, 75, 5, 163, 37, 212, 213, 178, 70, 104, 191, 75, 254, 32, 248, 112, 201, 91, 26, 169, 56, 201, 213, 134)
      }))).GetActivityCardByActivityID(_ARG_1_).CardID).SourceType) == require((table.concat({
        U1(27, 160, 58, 79, 103, 74, 134, 77, 213, 99, 220, 28, 5, 185, 36, 221, 213, 223, 101, 123, 168, 106, 185, 17, 228, 125, 203, 73, 31, 180, 63, 203, 221, 152, 25, 70, 164, 120, 238, 32),
        U1(114, 131, 59, 75, 72, 84, 161, 17, 241, 104, 217, 75, 5, 163, 37, 212, 213, 178, 70, 104, 191, 76, 248, 61, 238, 117, 207)
      }))).BenefitSourceType.Benefit and tonumber(require((table.concat({
        U1(27, 160, 58, 79, 103, 74, 134, 77, 213, 99, 220, 28, 5, 185, 36, 221, 213, 223, 101, 123, 168, 106, 185, 17, 228, 125, 203, 73, 31, 180, 63, 203, 221, 152, 25, 70, 164, 120, 238, 32),
        U1(114, 131, 59, 75, 72, 84, 161, 17, 241, 104, 217, 75, 5, 163, 37, 212, 213, 178, 70, 104, 191, 75, 254, 32, 248, 112, 201, 91, 26, 169, 56, 201, 213, 134)
      }))).GetBenefitRelationsByCard(require((table.concat({
        U1(27, 160, 58, 79, 103, 74, 134, 77, 213, 99, 220, 28, 5, 185, 36, 221, 213, 223, 101, 123, 168, 106, 185, 17, 228, 125, 203, 73, 31, 180, 63, 203, 221, 152, 25, 70, 164, 120, 238, 32),
        U1(114, 131, 59, 75, 72, 84, 161, 17, 241, 104, 217, 75, 5, 163, 37, 212, 213, 178, 70, 104, 191, 75, 254, 32, 248, 112, 201, 91, 26, 169, 56, 201, 213, 134)
      }))).GetActivityCardByActivityID(_ARG_1_).CardID).SourceID) == _ARG_2_ then
        return true
      end
      ::lbl_191::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return false end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["ClaimLuckyDiscountRefund"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      _ARG_1_ = _ARG_0_:NormalizeActivityId(_ARG_1_)
      _ARG_2_ = tonumber(_ARG_2_)
      if not (_ARG_1_ and _ARG_2_ and not (_ARG_2_ <= 0) and _ARG_2_ == math.floor(_ARG_2_) and _ARG_0_:GetIsUnlock(_ARG_1_)) or _ARG_0_:GetLuckyDiscountRefundInfo(_ARG_1_) ~= U1.CanClaim or not _ARG_0_:HasLuckyDiscountRefundBenefit(_ARG_1_, _ARG_2_) then
        return false
      end
      if _ARG_0_._nLuckyRefundLastClaimTime and os.time() - _ARG_0_._nLuckyRefundLastClaimTime < 1 or _ARG_0_._nLuckyRefundClaimTime and os.time() - _ARG_0_._nLuckyRefundClaimTime < 5 then
        return false
      end
      _ARG_0_._nLuckyRefundClaimTime = os.time()
      _ARG_0_._nLuckyRefundLastClaimTime, _ARG_0_._nLuckyRefundClaimBenefitId = os.time(), _ARG_2_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["RefreshLuckyDiscountRefundData"] = function(_ARG_0_, _ARG_1_)
    do
      goto lbl_80
      ::lbl_80::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      if _ARG_1_ and not true then
      end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_claim_small_rp_lucky_discount_uc_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      _ARG_3_ = tonumber(_ARG_3_)
      if _ARG_3_ and (_ARG_3_ <= 0 or _ARG_3_ ~= math.floor(_ARG_3_)) then
        _ARG_3_ = nil
      end
      if _ARG_3_ and _ARG_3_ == _ARG_0_._nLuckyRefundClaimBenefitId then
        _ARG_0_._nLuckyRefundClaimTime = nil
        _ARG_0_._nLuckyRefundClaimBenefitId = nil
      end
      _ARG_0_:RefreshLuckyDiscountRefundData(_ARG_3_)
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_lucky_discount_refund_ntf"] = function(_ARG_0_, _ARG_1_)
    do
      if tonumber(_ARG_1_) == U1.Claimed then
        _ARG_0_:RefreshLuckyDiscountRefundData()
      end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_buy_score_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_)
    do
      if not (_ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).player_data) then
        return false, nil
      end
      ;(_ARG_0_:GetActivityData(_ARG_1_) and _ARG_0_:GetActivityData(_ARG_1_).player_data).score = _ARG_3_
      _ARG_0_:GetActivityData(_ARG_1_).buy_score_callback = nil
      if U1.type(_ARG_0_:GetActivityData(_ARG_1_).buy_score_callback) == U2(58, 180, 57, 73, 95, 86, 136, 13) then
        return true, nil
      end
      if _ARG_2_ and 0 < _ARG_2_ then
      end
      do return true, (_ARG_0_:ShowCommonItemGet(_ARG_1_, {
        {
          res_id = _ARG_0_:GetScoreShowItemId(_ARG_1_),
          count = _ARG_2_
        }
      }, nil, nil, {
        reward_type = U3.BuyScore
      })) end
      do return end
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_get_level_award_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_)
    do
      if not _ARG_0_:GetPlayerData(_ARG_1_) then
        return false
      end
      _ARG_0_:GetPlayerData(_ARG_1_).level_award = _ARG_0_:GetPlayerData(_ARG_1_).level_award or {}
      _ARG_0_:GetPlayerData(_ARG_1_).level_award[_ARG_2_] = true
      do return true, (_ARG_0_:ShowCommonItemGet(_ARG_1_, _ARG_3_, _ARG_4_, _ARG_5_, {
        reward_type = U2.Level,
        display_style = U3(56, 164, 52, 69, 70, 79, 136, 16, 253),
        source_id = _ARG_2_,
        level = _ARG_2_
      })) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_batch_get_level_award_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:GetPlayerData(_ARG_1_) then
        return false
      end
      _ARG_0_:GetPlayerData(_ARG_1_).level_award = _ARG_0_:GetPlayerData(_ARG_1_).level_award or {}
      _ARG_0_ = _ARG_0_
      _ARG_0_:GetPlayerData(_ARG_1_).level_award[nil] = true
      _ARG_0_ = _ARG_0_
      do return true, (_ARG_0_:ShowCommonItemGet(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, {
        reward_type = U2.Level,
        display_style = U3(56, 164, 52, 69, 70, 79, 136, 16, 253),
        is_batch = true
      })) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_sync_small_rp_activity_task_data_info"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) or type(_ARG_2_) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      if _ARG_0_:NormalizeActivityId(_ARG_2_.act_term_id) and _ARG_0_:NormalizeActivityId(_ARG_2_.act_term_id) ~= _ARG_0_:GetActivityData(_ARG_1_).activity_id then
        return false
      end
      if _ARG_2_.tasks ~= nil and type(_ARG_2_.tasks) ~= U1(40, 160, 53, 70, 78) or _ARG_2_.stage_awards ~= nil and type(_ARG_2_.stage_awards) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      _ARG_0_:GetActivityData(_ARG_1_).task_data = _ARG_2_.tasks
      _ARG_0_:GetActivityData(_ARG_1_).stage_awards = _ARG_2_.stage_awards
      _ARG_0_:GetActivityData(_ARG_1_).task_pro_reward_min = nil
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_get_task_award_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, _ARG_5_, _ARG_6_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) or type(_ARG_3_) ~= U1(40, 160, 53, 70, 78) or _ARG_0_:GetActivityData(_ARG_1_).task_data ~= nil and type(_ARG_0_:GetActivityData(_ARG_1_).task_data) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      _ARG_0_:GetActivityData(_ARG_1_).task_data = _ARG_0_:GetActivityData(_ARG_1_).task_data or {}
      _ARG_0_:GetActivityData(_ARG_1_).task_data[U2(_ARG_0_:GetActivityData(_ARG_1_).task_data, _ARG_2_) or _ARG_2_] = _ARG_3_
      do return true, (_ARG_0_:TaskReceiveShowCommonItemGet(_ARG_1_, _ARG_4_, _ARG_5_, _ARG_6_, {source_id = _ARG_2_, task_id = _ARG_2_})) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_batch_get_task_award_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) then
        return false
      end
      do return true, (_ARG_0_:TaskReceiveShowCommonItemGet(_ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_, {is_batch = true})) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_batch_get_stage_award_rsp"] = function(_ARG_0_, _ARG_1_, _ARG_2_)
    do
      if not _ARG_0_:GetActivityData(_ARG_1_) or type(_ARG_2_) ~= U1(40, 160, 53, 70, 78) or _ARG_0_:GetActivityData(_ARG_1_).stage_awards ~= nil and type(_ARG_0_:GetActivityData(_ARG_1_).stage_awards) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      goto lbl_75
      if type(70) ~= U1(40, 160, 53, 70, 78) or U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53) ~= nil and type((U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53))) ~= U1(40, 160, 53, 70, 78) then
        return false
      end
      ::lbl_75::
      _ARG_0_ = _ARG_0_
      _ARG_0_:GetActivityData(_ARG_1_).stage_awards, _ARG_0_ = _ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, _ARG_0_
      goto lbl_98
      ::lbl_98::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      goto lbl_134
      if U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, table.insert({}, {
        key = U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53),
        progress = tonumber((U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53))) or U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53),
        rewards = false
      }).key) then
        U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, table.insert({}, {
          key = U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53),
          progress = tonumber((U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53))) or U2(_ARG_0_:GetActivityData(_ARG_1_).stage_awards or {}, 53),
          rewards = false
        }).key).status = U3.Received
      end
      goto lbl_132
      ::lbl_132::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      ::lbl_134::
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      do return true, (_ARG_0_:ShowCommonItemGet(_ARG_1_, {}, nil, nil, {
        reward_type = U5.Stage,
        is_batch = true,
        stage_progresses = {},
        stage_rewards = _ARG_2_
      })) end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end,
  ["on_small_rp_activity_score_notify_change"] = function(_ARG_0_, _ARG_1_, _ARG_2_, _ARG_3_, _ARG_4_)
    do
      if not _ARG_0_:GetPlayerData(_ARG_1_) then
        return false
      end
      _ARG_0_:GetPlayerData(_ARG_1_).score = _ARG_3_
      do return true end
      do return end
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
      _ARG_0_ = _ARG_0_
    end
  end
})) end
return
