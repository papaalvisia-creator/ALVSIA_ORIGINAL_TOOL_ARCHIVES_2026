# LUA_PAK DEWA PRO TOOL — Hasil Lengkap

## Isi paket

```
├── tool.py                  <- TOOL UTAMA (1 file Python, semua menu, unluac tertanam)
├── README.md                <- file ini
├── LAPORAN_VERIFIKASI.txt   <- laporan verifikasi & validasi lengkap
├── HASIL_REKONSTRUKSI/      <- SOURCE LUA MURNI hasil dump-decript-decompile-rekonstruksi
│   ├── pengujian1/ ... pengujian12/   (struktur folder = isi asli pak)
│   ├── test/                          (hasil test.pak)
│   ├── _loose/                        (03704831068.lua dari root zip + disassembly)
│   └── _DECOMPILE_REPORT.json         (status per file)
└── UNPACK_PAK/              <- HASIL UNPACK PENUH semua pak (file mentah per pak)
    ├── pengujian1/ ... pengujian12/
    ├── test/
    └── _manifest.json / _lua_inventory.json
```

## Cara pakai tool.py

```bash
# mode menu interaktif
python3 tool.py

# mode perintah langsung
python3 tool.py unpack <file.pak> [folder_output]        # unpack PAK
python3 tool.py decompile <file.luac> [output.lua]       # decompile 1 file
python3 tool.py batch-decompile <folder> [output]        # decompile semua
python3 tool.py protek <source.lua> [level 1-5] [output] # protek source
python3 tool.py info <file.pak>                          # info index PAK
python3 tool.py all                                      # pipeline satu klik
```

### Menu 1 — PAK
UNPACK (satu/batch) - REPACK folder ke PAK - REBUILD non-destruktif -
PROTEKSI APK (zip + manifest SHA-256 + enkripsi RC4 lua) - VERIFIKASI APK.

### Menu 2 — LUA
ANALISIS - DECOMPILE (dump-decript-decompile-rekonstruksi, nol terlewat) -
PROTEK source (input -> protect -> verifikasi -> validasi, level 1-5, output
dieksekusi identik dgn asli — diuji pada runtime Lua asli) - PROTEK bytecode
(re-encrypt format game) - INJEK lua ke PAK.

### Kekuatan protek
- Level 1: strip komentar
- Level 2: string literal -> string.char XOR-chain
- Level 3: angka -> identitas aritmetika
- Level 4: blok anti-tamper tertanam
- Level 5: **loader terenkapsulasi** — payload di-XOR + base64, checksum
  djb2-48bit tertanam, loader murni-Lua (base64 decoder sendiri), error
  otomatis bila payload dimodifikasi. Output = source Lua sah 100%
  (nol error load & eksekusi — terverifikasi runtime Lua).

## Teknologi yang didukung (dari hasil reverse engineering nyata)
- PAK ShadowTracker v3-v14: ZUC footer, RSA blob index, AES-CBC index,
  SM4 kustom Tencent (SBOX/FK/CK non-standar), DYN_SM4, SM4_NEW, SIMPLE1/2,
  zlib + adler32 anti-tamper, zstd + zstd-dict, block permutation LCG.
- Bytecode Lua 5.3 game: header 33B, string XOR-32B, opcode rotate-17,
  lineinfo hybrid (delta+abs reset) & stock 5.3.5 (abslineinfo),
  debug dummy obfuscator, trailer 0x0BADF00D, trailer '=' banner.
- unluac 1.2.3 tertanam (base64) — diekstrak otomatis ke ~/.lua_pak_dewa_cache.

## Batasan yang jujur
- 450 file asset (uasset/uexp/ini) dari pengujian5/8/10 memakai metode
  enkripsi SM4 #53 & DYN_SM4 id 37/48 yang secret-nya hanya ada di binary
  game (tidak diberikan) — file itu tidak bisa didekripsi tanpa binary.
  SEMUA file lua tetap diekstrak kecuali 4 yang dipulihkan dari pak lain
  (client_entry.lua x3, BRPlayerCharacterBase.lua x1).
- 25 file lua ter-obfuskasi berat + CharacterBase (test.pak) memakai
  obfuscator dgn ekspresi nested puluhan ribu level — dekompilasi penuh
  melebihi stack JVM; pemulihan level-instruksi 100% disediakan via
  disassembly (CharacterBase_DISASM.lua.gz, 5,6 juta baris) + tabel string
  terdekripsi.
