#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALVSIA TOOL PREMIUM — lapisan keamanan klien.

Isi:
  * anti-debug  : deteksi tracer / debugger yang menempel
  * integrity   : verifikasi SHA-256 semua file inti terhadap manifest
  * guard       : pengecekan gabungan sebelum modul dijalankan

Manifest dibuat oleh tools/build_manifest.py dan disimpan di
tool/assets/manifest.sha256. Kalau satu byte saja di file inti berubah,
tool menolak jalan.
"""

from __future__ import annotations

import hashlib
import os
import sys
from pathlib import Path
from typing import Iterable

TOOL_ROOT = Path(__file__).resolve().parent
MANIFEST = TOOL_ROOT / "assets" / "manifest.sha256"


class SecurityError(RuntimeError):
    pass


# ── anti-debug ──────────────────────────────────────────────────────────────
def debugger_attached() -> bool:
    # Python-level tracer
    if sys.gettrace() is not None:
        return True

    # Linux: TracerPid != 0
    try:
        status = Path("/proc/self/status").read_text(encoding="utf-8", errors="ignore")
        for line in status.splitlines():
            if line.startswith("TracerPid:"):
                if int(line.split(":", 1)[1].strip() or 0) != 0:
                    return True
                break
    except Exception:
        pass

    # Windows: IsDebuggerPresent / CheckRemoteDebuggerPresent
    if os.name == "nt":
        try:
            import ctypes

            k32 = ctypes.windll.kernel32
            if k32.IsDebuggerPresent():
                return True
            present = ctypes.c_int(0)
            if k32.CheckRemoteDebuggerPresent(k32.GetCurrentProcess(), ctypes.byref(present)):
                if present.value:
                    return True
        except Exception:
            pass

    # Variabel lingkungan debugger umum
    for var in ("PYTHONINSPECT", "PDB_START"):
        if os.environ.get(var):
            return True

    return False


def assert_no_debugger() -> None:
    if debugger_attached():
        raise SecurityError(
            "Debugger terdeteksi. Tutup debugger/profiler lalu jalankan ulang tool."
        )


# ── integrity ───────────────────────────────────────────────────────────────
def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def iter_core_files() -> Iterable[Path]:
    """File yang dilindungi: launcher, klien lisensi, security, semua modul .py."""
    yield TOOL_ROOT / "alvsia.py"
    yield TOOL_ROOT / "license_client.py"
    yield TOOL_ROOT / "security.py"
    mods = TOOL_ROOT / "modules"
    if mods.is_dir():
        for p in sorted(mods.rglob("*.py")):
            if "__pycache__" in p.parts:
                continue
            yield p


def build_manifest() -> int:
    lines = []
    for p in iter_core_files():
        if not p.is_file():
            continue
        rel = p.relative_to(TOOL_ROOT).as_posix()
        lines.append(f"{_sha256(p)}  {rel}")
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


def _read_manifest() -> dict:
    if not MANIFEST.is_file():
        return {}
    out = {}
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        if len(parts) != 2:
            continue
        digest, rel = parts
        out[rel.strip()] = digest.strip().lower()
    return out


def verify_integrity(strict: bool = True) -> list:
    """Return daftar file yang bermasalah (kosong = bersih)."""
    manifest = _read_manifest()
    if not manifest:
        if strict:
            raise SecurityError(
                "Manifest integritas tidak ditemukan. Jalankan: python tools/build_manifest.py"
            )
        return []

    problems = []
    for rel, digest in manifest.items():
        p = TOOL_ROOT / rel
        if not p.is_file():
            problems.append(f"hilang: {rel}")
            continue
        if _sha256(p) != digest:
            problems.append(f"berubah: {rel}")

    if problems and strict:
        raise SecurityError(
            "Integritas file tidak valid — tool dihentikan.\n  "
            + "\n  ".join(problems[:10])
        )
    return problems


def guard() -> None:
    assert_no_debugger()
    verify_integrity(strict=True)
