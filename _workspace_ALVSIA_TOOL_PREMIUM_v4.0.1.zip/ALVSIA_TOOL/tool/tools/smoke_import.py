#!/usr/bin/env python3
"""Import-smoke setiap modul ALVSIA (tanpa menjalankan menu interaktif).

Dipakai oleh proses verifikasi: memastikan tidak ada ImportError / NameError
saat modul dimuat, karena kesalahan seperti itu baru muncul ketika tool
dijalankan oleh pengguna.
"""
from __future__ import annotations

import importlib.util
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from modules.registry import all_modules  # noqa: E402


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot build spec for {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    failures = []
    for m in all_modules():
        p = m.script_path
        if not p.exists():
            failures.append((m.id, "MISSING", str(p)))
            print(f"[FAIL] {m.id:<10} file tidak ada: {p}")
            continue
        try:
            load(p, f"alvsia_smoke_{m.id}")
            print(f"[ OK ] {m.id:<10} {m.name}")
        except BaseException as exc:  # noqa: BLE001
            failures.append((m.id, type(exc).__name__, str(exc)))
            print(f"[FAIL] {m.id:<10} {type(exc).__name__}: {exc}")
            traceback.print_exc(limit=3)
    print()
    if failures:
        print(f"{len(failures)} modul GAGAL dimuat")
        return 1
    print("Semua modul berhasil dimuat")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
