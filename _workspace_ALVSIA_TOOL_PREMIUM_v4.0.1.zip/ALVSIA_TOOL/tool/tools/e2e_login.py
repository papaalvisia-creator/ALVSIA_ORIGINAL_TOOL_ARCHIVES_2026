#!/usr/bin/env python3
"""Uji end-to-end license_client.py terhadap panel legacy lokal (port 8098)."""
import sys
import json

sys.path.insert(0, "/workspace/ALVSIA_TOOL/tool")
import license_client as lc  # noqa: E402

PANEL = "http://127.0.0.1:8098/api"
KEY = "ALVSIA-TEST-0001-AAAA"

print("panel :", PANEL)
print("hwid  :", lc.machine_hwid())

cl = lc.LicenseClient(base_url=PANEL, timeout=20)
res = cl.login(KEY)
print("LOGIN :", json.dumps(res, indent=2, default=str)[:1500])

ok = bool(res.get("session_token"))
print("STATUS:", "PASS" if ok else "FAIL")

if ok:
    print("session_token:", (res.get("session_token") or "")[:16], "...")
    r2 = cl.refresh()
    print("REFRESH:", "PASS" if r2 else "FAIL")
sys.exit(0 if ok else 1)
