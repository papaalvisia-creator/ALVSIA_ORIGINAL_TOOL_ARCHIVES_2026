#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Bangun ulang manifest integritas ALVSIA TOOL PREMIUM.

Jalankan setiap kali file inti (launcher / modul) selesai diubah:

    python tools/build_manifest.py
"""

import sys
from pathlib import Path

TOOL_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(TOOL_ROOT))

from security import build_manifest  # noqa: E402


def main() -> int:
    n = build_manifest()
    print(f"Manifest dibuat: {n} file -> assets/manifest.sha256")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
