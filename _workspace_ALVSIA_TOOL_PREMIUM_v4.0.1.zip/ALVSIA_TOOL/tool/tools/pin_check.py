#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Cek pin sertifikat host panel terhadap daftar pin di license_client.py.

Dipakai saat sertifikat panel diperbarui: jalankan skrip ini, lihat pin yang
disajikan server, lalu bandingkan dengan TLS_PINS.

    python tools/pin_check.py
    python tools/pin_check.py --host alvsiapanel.unaux.com
"""

from __future__ import annotations

import argparse
import socket
import ssl
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import license_client as lc  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="Cek pin SPKI sertifikat panel ALVSIA")
    ap.add_argument("--host", default="alvsiapanel.unaux.com")
    ap.add_argument("--port", type=int, default=443)
    args = ap.parse_args()

    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((args.host, args.port), timeout=20) as raw:
            with ctx.wrap_socket(raw, server_hostname=args.host) as tls:
                der = tls.getpeercert(binary_form=True)
                info = tls.getpeercert()
    except Exception as exc:
        print(f"GAGAL terhubung ke {args.host}:{args.port} -> {exc}")
        return 2

    subject = dict(x[0] for x in info.get("subject", ()))
    issuer = dict(x[0] for x in info.get("issuer", ()))
    pin = lc.spki_pin(der)

    print(f"host    : {args.host}:{args.port}")
    print(f"subject : {subject.get('commonName', '-')}")
    print(f"issuer  : {issuer.get('commonName', '-')}")
    print(f"valid   : {info.get('notBefore')} -> {info.get('notAfter')}")
    print(f"pin     : sha256/{pin}")
    print(f"status  : {'COCOK dengan daftar pin' if pin in lc.TLS_PINS else 'TIDAK ADA di daftar pin'}")

    if pin not in lc.TLS_PINS:
        print("\nKalau sertifikat ini memang yang baru dan sah, tambahkan pin di atas")
        print("ke TLS_PINS pada license_client.py, lalu jalankan build_manifest.py.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
