#!/usr/bin/env python3
"""Uji negatif: key salah, key kosong, dan integritas file yang diubah."""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import license_client as lc  # noqa: E402
import security  # noqa: E402

PANEL = "http://127.0.0.1:8098/api"
results = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name} {detail}")


# 1. key salah harus ditolak
try:
    lc.LicenseClient(base_url=PANEL, timeout=20).login("ALVSIA-SALAH-9999-ZZZZ")
    check("key salah ditolak", False, "(server menerima key palsu!)")
except lc.LicenseError as exc:
    check("key salah ditolak", True, f"-> {exc}")

# 2. key kosong ditolak di sisi klien
try:
    lc.LicenseClient(base_url=PANEL, timeout=20).login("   ")
    check("key kosong ditolak", False)
except lc.LicenseError as exc:
    check("key kosong ditolak", True, f"-> {exc}")

# 3. panel tak terjangkau -> error jelas, bukan crash
try:
    lc.LicenseClient(base_url="http://127.0.0.1:9/api", timeout=3).login("X")
    check("panel mati -> LicenseError", False)
except lc.LicenseError as exc:
    check("panel mati -> LicenseError", True, f"-> {str(exc)[:60]}")

# 4. integritas: file diubah harus terdeteksi
manifest = ROOT / "assets" / "manifest.sha256"
check("manifest ada", manifest.exists(), str(manifest))

if manifest.exists():
    with tempfile.TemporaryDirectory() as td:
        tmp_root = Path(td) / "tool"
        shutil.copytree(ROOT, tmp_root, ignore=shutil.ignore_patterns("__pycache__", ".venv"))
        security.TOOL_ROOT = tmp_root
        security.MANIFEST = tmp_root / "assets" / "manifest.sha256"
        ok_before = security.verify_integrity(strict=False)
        check("integritas utuh diterima", not ok_before)

        target = tmp_root / "modules" / "registry.py"
        target.write_text(target.read_text() + "\n# tampered\n", encoding="utf-8")
        ok_after = security.verify_integrity(strict=False)
        check("file diubah terdeteksi", bool(ok_after), str(ok_after[:2]))

# 5. anti-debug: TracerPid palsu harus terdeteksi
check("anti-debug aktif", security.debugger_attached() is False, "(tidak ada debugger)")

print()
bad = [r for r in results if not r[1]]
print(f"{len(results) - len(bad)}/{len(results)} uji negatif lulus")
sys.exit(1 if bad else 0)
