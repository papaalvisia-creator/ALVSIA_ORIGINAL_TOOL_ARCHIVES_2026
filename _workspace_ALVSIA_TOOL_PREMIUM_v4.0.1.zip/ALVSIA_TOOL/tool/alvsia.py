#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALVSIA TOOL PREMIUM
Channel : @ALVSIA_PRO
Owner   : @OriginalOnwerALV

Satu pintu untuk seluruh mesin ALVSIA. Launcher memvalidasi lisensi ke panel
resmi, memeriksa integritas file, lalu menjalankan modul terpilih sebagai
proses terpisah (terisolasi).

Contoh:
    python alvsia.py                              # menu interaktif
    python alvsia.py --license ALV-XXXX-XXXX      # login sekali, sesi disimpan
    python alvsia.py core info file.pak           # langsung ke modul
    python alvsia.py --list                       # daftar modul
    python alvsia.py --status                     # cek sesi lisensi
    python alvsia.py --logout                     # hapus sesi lokal
    python alvsia.py --panel https://domain/api   # ganti endpoint panel

Environment:
    ALVSIA_PANEL, ALVSIA_LICENSE
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

TOOL_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOL_ROOT))

from license_client import DEFAULT_PANEL, LicenseClient, LicenseError  # noqa: E402
from modules import registry  # noqa: E402
import security  # noqa: E402

HOME = Path.home() / ".alvsia"
CFG = HOME / "config.json"
SESS = HOME / "session.json"

PRODUCT = "ALVSIA TOOL PREMIUM"
CHANNEL = "@ALVSIA_PRO"
OWNER = "@OriginalOnwerALV"
VERSION = "4.0.1"

BANNER = r"""
    ___    __    __ _____ ___    ___
   / _ |  / /   / / / ___/ _ |  / _ |     ALVSIA TOOL PREMIUM  v{ver}
  / __ | / /__ / /_/ /__/ __ | / // /     {chan}
 /_/ |_|/____//____/\___/_/ |_|/____/     {owner}
"""


def banner() -> None:
    print(BANNER.format(ver=VERSION, chan=CHANNEL, owner=OWNER))


def _load(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(path: Path, obj: dict) -> None:
    HOME.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass


# ── gerbang lisensi ─────────────────────────────────────────────────────────
def ensure_license(args) -> int:
    """0 = sesi valid (baru atau lama). Selain 0 = gagal."""
    cfg = _load(CFG)
    panel = (
        args.panel
        or os.environ.get("ALVSIA_PANEL")
        or cfg.get("panel")
        or DEFAULT_PANEL
    ).strip()
    if cfg.get("panel") != panel:
        _save(CFG, {"panel": panel})

    client = LicenseClient(panel)
    sess = _load(SESS)

    valid = False
    if sess.get("session_token") and sess.get("hwid") == client.hwid:
        client.token = sess["session_token"]
        client.expires = int(sess.get("expires") or 0)
        try:
            valid = client.ensure_session()
        except Exception:
            valid = False
        if valid:
            sess["expires"] = client.expires
            _save(SESS, sess)

    if args.status:
        if valid:
            exp = int(sess.get("expires") or 0)
            when = (
                time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(exp))
                if exp
                else "sesuai masa aktif lisensi"
            )
            print("Status  : AKTIF")
            print("Sesi s/d:", when)
            print("Key     :", sess.get("license_masked", "-"))
            print("HWID    :", client.hwid)
            print("Panel   :", panel)
            return 0
        print("Status  : TIDAK AKTIF (sesi kedaluwarsa / belum login)")
        return 1

    if valid:
        return 0

    key = (args.license or os.environ.get("ALVSIA_LICENSE") or "").strip()
    if not key:
        try:
            key = input("Masukkan license key: ").strip()
        except EOFError:
            return 2
    if not key:
        print("License key kosong.")
        return 2

    print("Menghubungi panel lisensi …")
    try:
        data = client.login(key)
    except LicenseError as exc:
        print("Login lisensi gagal:", exc)
        return 3
    except Exception as exc:  # jaringan / tak terduga
        print("Tidak bisa menghubungi panel:", exc)
        return 3

    _save(
        SESS,
        {
            "session_token": data["session_token"],
            "hwid": client.hwid,
            "expires": int(data.get("session_expires") or int(time.time()) + 21600),
            "license_masked": (key[:4] + "****" + key[-4:]) if len(key) > 8 else "****",
            "product": data.get("msg") or PRODUCT,
        },
    )
    print("Lisensi OK —", data.get("msg") or "")
    print("Masa aktif:", data.get("expiry"), "| Maks device:", data.get("max_devices"))
    return 0


# ── penjalan modul ──────────────────────────────────────────────────────────
def run_module(mod: registry.Module, argv: list) -> int:
    script = mod.script_path
    if not script.is_file():
        print(f"[!] Modul '{mod.id}' tidak lengkap: {script} tidak ditemukan.")
        return 4

    try:
        security.verify_integrity(strict=True)
    except security.SecurityError as exc:
        print("[!] " + str(exc))
        return 5

    env = os.environ.copy()
    env["ALVSIA"] = "1"
    env["ALVSIA_PRODUCT"] = PRODUCT
    env["ALVSIA_CHANNEL"] = CHANNEL
    env["ALVSIA_OWNER"] = OWNER
    env["PYTHONPATH"] = str(TOOL_ROOT) + (
        os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else ""
    )
    env["PATH"] = str(TOOL_ROOT / "assets" / "bin") + os.pathsep + env.get("PATH", "")
    env["PYTHONIOENCODING"] = "utf-8"
    env.setdefault("TERM", "xterm-256color")
    for k, v in mod.env.items():
        env[k] = v

    cmd = [sys.executable, str(script)] + [str(a) for a in argv]
    print(f"\n▸ Menjalankan {mod.name} …\n")
    try:
        return subprocess.call(cmd, cwd=str(mod.path), env=env)
    except KeyboardInterrupt:
        return 130


def show_menu() -> None:
    banner()
    mods = registry.all_modules()
    print("  Modul tersedia:\n")
    for i, m in enumerate(mods, 1):
        print(f"   {i:>2}. {m.name:<22} {m.desc}")
    print("\n   0. Keluar")
    print("\n  Ketik nomor, atau nama modul (contoh: core info file.pak)")


def interactive() -> int:
    mods = registry.all_modules()
    while True:
        show_menu()
        try:
            raw = input("\n  alvsia> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not raw:
            continue
        if raw in ("0", "q", "quit", "exit"):
            return 0
        parts = raw.split()
        if parts[0].isdigit():
            idx = int(parts[0])
            if 1 <= idx <= len(mods):
                run_module(mods[idx - 1], parts[1:])
            else:
                print("  [!] Nomor tidak ada di daftar.")
            continue
        mod = registry.get(parts[0])
        if mod:
            run_module(mod, parts[1:])
        else:
            print(f"  [!] Modul '{parts[0]}' tidak dikenal.")


def main() -> int:
    ap = argparse.ArgumentParser(add_help=False)
    ap.add_argument("--panel", default="")
    ap.add_argument("--license", default="")
    ap.add_argument("--logout", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--help", "-h", action="store_true")
    ap.add_argument("--version", "-v", action="store_true")
    args, rest = ap.parse_known_args()

    if rest and rest[0] == "--":
        rest = rest[1:]

    if args.version:
        print(f"{PRODUCT} v{VERSION}")
        return 0

    if args.help:
        print(__doc__)
        print("Modul:")
        for m in registry.all_modules():
            print(f"  {m.id:<12} {m.name:<22} {m.desc}")
        return 0

    if args.list:
        banner()
        for m in registry.all_modules():
            print(f"  {m.id:<12} {m.name:<22} {m.desc}")
        return 0

    if args.logout:
        try:
            SESS.unlink()
        except FileNotFoundError:
            pass
        print("Sesi lokal dihapus.")
        return 0

    try:
        security.assert_no_debugger()
    except security.SecurityError as exc:
        print("[!] " + str(exc))
        return 5

    rc = ensure_license(args)
    if rc != 0:
        return rc

    if not rest:
        return interactive()

    mod = registry.get(rest[0])
    if not mod:
        print(f"[!] Modul '{rest[0]}' tidak dikenal. Gunakan --list.")
        return 2
    return run_module(mod, rest[1:])


if __name__ == "__main__":
    raise SystemExit(main())
