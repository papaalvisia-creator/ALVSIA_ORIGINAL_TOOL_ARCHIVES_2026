@echo off
REM ALVSIA TOOL - launcher untuk Windows
REM Channel: https://t.me/ALVSIA_PRO   Owner: @OriginalOnwerALV
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  set PY=py
) else (
  set PY=python
)

%PY% -c "import rich,requests,Crypto,zstandard,gmalg,pytz,repak" 2>nul
if errorlevel 1 (
  echo [*] Memasang dependensi...
  %PY% -m pip install -q rich requests pycryptodome zstandard gmalg pytz repak cryptography
)

%PY% alvsia.py %*
endlocal
