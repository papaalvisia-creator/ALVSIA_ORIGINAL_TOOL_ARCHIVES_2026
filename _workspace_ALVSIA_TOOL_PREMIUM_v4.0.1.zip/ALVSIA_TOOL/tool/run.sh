#!/usr/bin/env bash
# ALVSIA TOOL — launcher untuk Linux / Termux
# Channel: https://t.me/ALVSIA_PRO   Owner: @OriginalOnwerALV
set -e
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  echo "[*] Menyiapkan environment pertama kali..."
  python3 -m venv .venv 2>/dev/null || true
fi
if [ -d .venv ]; then
  # shellcheck disable=SC1091
  . .venv/bin/activate
fi

python3 - <<'PY'
import importlib, sys
need = {"rich":"rich","requests":"requests","Crypto":"pycryptodome",
        "zstandard":"zstandard","gmalg":"gmalg","pytz":"pytz","repak":"repak"}
missing = [pkg for mod, pkg in need.items() if importlib.util.find_spec(mod) is None]
if missing:
    print("[*] Memasang dependensi:", ", ".join(missing))
    import subprocess
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", *missing], check=False)
PY

exec python3 alvsia.py "$@"
