#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALVSIA TOOL PREMIUM — License Client
Channel : @ALVSIA_PRO
Owner   : @OriginalOnwerALV

Klien lisensi yang berbicara dengan panel standar (protokol v2):
  1. GET  /api/captcha.php        -> {cid, nonce, mechanic, pow_prefix, pow_diff}
  2. POST /api/connect.php        -> {cid, packet, proto:2}  =>  {status:"login", ip, isp}
  3. POST /api/refresh_session.php-> perpanjang sesi
  4. POST /api/get_asset.php      -> daftar/ambil aset (pakai session_token)
  5. GET  /api/download_asset.php -> unduh aset

Detail kripto (sama persis dengan panel):
  transport_key = SHA256(b"ALVSIA_V2|" + nonce_bin)
  IV request    = 16 karakter hex pertama dari nonce (ASCII)
  IV response   = 16 byte acak dari server (base64 di field "ip")
  AES-256-CBC + PKCS7
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import re
import secrets
import time
import uuid
from pathlib import Path
from typing import Optional

# ── AES backend: pycryptodome dulu, fallback cryptography ────────────────────
try:
    from Crypto.Cipher import AES as _AES
    from Crypto.Util.Padding import pad as _pad, unpad as _unpad

    def _aes_enc(key: bytes, iv: bytes, data: bytes) -> bytes:
        return _AES.new(key, _AES.MODE_CBC, iv).encrypt(_pad(data, 16))

    def _aes_dec(key: bytes, iv: bytes, data: bytes) -> bytes:
        return _unpad(_AES.new(key, _AES.MODE_CBC, iv).decrypt(data), 16)

except ImportError:  # pragma: no cover
    try:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        def _aes_enc(key: bytes, iv: bytes, data: bytes) -> bytes:
            n = 16 - len(data) % 16
            data = data + bytes([n]) * n
            c = Cipher(algorithms.AES(key), modes.CBC(iv)).encryptor()
            return c.update(data) + c.finalize()

        def _aes_dec(key: bytes, iv: bytes, data: bytes) -> bytes:
            c = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
            out = c.update(data) + c.finalize()
            return out[: -out[-1]]

    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "Butuh 'pycryptodome' atau 'cryptography'. Jalankan: pip install pycryptodome"
        ) from exc

try:
    import requests
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("Butuh 'requests'. Jalankan: pip install requests") from exc


PROTO = 2
PROTO_MARKER = b"ALVSIA_V2|"
DEFAULT_PANEL = "https://alvsiapanel.unaux.com/api"

_UA = (
    "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
)

HOME = Path.home() / ".alvsia"
DEVICE_FILE = HOME / "device.id"


class LicenseError(Exception):
    """Kesalahan lisensi yang aman ditampilkan ke pengguna."""


# ── TLS certificate pinning (SPKI SHA-256) ────────────────────────────────
# Pin diambil dari SubjectPublicKeyInfo, bukan dari seluruh sertifikat. Jadi
# sertifikat boleh diperbarui (perpanjangan) selama kunci publiknya sama.
# Bila server menyajikan kunci lain — misalnya karena intersepsi TLS — koneksi
# diputus sebelum satu byte pun data lisensi terkirim.

PINNED_HOSTS = {"alvsiapanel.unaux.com"}

TLS_PINS = frozenset(
    {
        # PIN UTAMA — leaf certificate
        "3dKRo5uvtVM2x5/NJsOEKFEy803l0rPct3Jv0AoiukE=",
        # PIN CADANGAN 1 — ZeroSSL ECC DV SSL CA 2 (s/d 23 Sep 2035)
        "xwyjb5aN7tSRWj02XSZa2cKGLxXLdKHUBfLT/7twjhQ=",
        # PIN CADANGAN 2 — Sectigo Public Server Authentication Root E46 (s/d 18 Jan 2038)
        "sLVjNUaFYfW7n6EtgBeEpjOlcnBdNPMrZDRF36iwBdE=",
    }
)


class PinError(LicenseError):
    """Sertifikat server tidak cocok dengan pin yang tertanam di tool."""


def _der_items(buf: bytes, start: int = 0, end: Optional[int] = None):
    """Pecah isi DER SEQUENCE menjadi (tag, elem_start, content_start, content_end)."""
    if end is None:
        end = len(buf)
    out = []
    i = start
    while i < end:
        elem_start = i
        tag = buf[i]
        i += 1
        if i >= end:
            break
        first = buf[i]
        i += 1
        if first & 0x80:
            n = first & 0x7F
            if n == 0 or n > 4 or i + n > end:
                raise ValueError("panjang DER tidak valid")
            length = int.from_bytes(buf[i : i + n], "big")
            i += n
        else:
            length = first
        cstart = i
        cend = i + length
        if cend > end:
            raise ValueError("DER terpotong")
        out.append((tag, elem_start, cstart, cend))
        i = cend
    return out


def _spki_der(cert_der: bytes) -> bytes:
    """Ambil blok SubjectPublicKeyInfo (DER utuh, termasuk header) dari sertifikat."""
    top = _der_items(cert_der)
    if not top or top[0][0] != 0x30:
        raise ValueError("bukan sertifikat DER")
    tbs = _der_items(cert_der, top[0][2], top[0][3])
    if not tbs or tbs[0][0] != 0x30:
        raise ValueError("TBSCertificate tidak ditemukan")
    fields = _der_items(cert_der, tbs[0][2], tbs[0][3])
    idx = 1 if fields and fields[0][0] == 0xA0 else 0  # [0] EXPLICIT version
    # serialNumber, signature, issuer, validity, subject, subjectPublicKeyInfo
    pos = idx + 5
    if pos >= len(fields) or fields[pos][0] != 0x30:
        raise ValueError("SubjectPublicKeyInfo tidak ditemukan")
    _, elem_start, _, elem_end = fields[pos]
    return cert_der[elem_start:elem_end]


def spki_pin(cert_der: bytes) -> str:
    """Hitung pin gaya HPKP: base64(SHA-256(SubjectPublicKeyInfo))."""
    return base64.b64encode(hashlib.sha256(_spki_der(cert_der)).digest()).decode()


def _pin_enabled(host: str) -> bool:
    if os.environ.get("ALVSIA_PIN_DISABLE") == "1":
        return False
    return (host or "").split(":")[0].lower() in PINNED_HOSTS


def verify_cert_pin(cert_der: bytes, host: str) -> None:
    """Tolak koneksi bila pin sertifikat tidak ada di daftar yang diizinkan."""
    if not _pin_enabled(host):
        return
    try:
        got = spki_pin(cert_der)
    except Exception as exc:
        raise PinError(f"Sertifikat server tidak bisa dibaca: {exc}") from exc
    if got not in TLS_PINS:
        raise PinError(
            "Sertifikat server tidak cocok dengan pin ALVSIA.\n"
            f"  host : {host}\n"
            f"  pin  : sha256/{got}\n"
            "Koneksi dihentikan sebelum data lisensi dikirim."
        )


def _build_pinned_adapter():
    """HTTPAdapter yang memeriksa pin SPKI tepat setelah TLS handshake."""
    from requests.adapters import HTTPAdapter
    from urllib3.connection import HTTPSConnection
    from urllib3.connectionpool import HTTPSConnectionPool

    class _PinnedHTTPSConnection(HTTPSConnection):
        def connect(self):
            super().connect()
            der = self.sock.getpeercert(binary_form=True) if self.sock else None
            if not der:
                raise PinError("Server tidak mengirim sertifikat TLS.")
            verify_cert_pin(der, self.host)

    class _PinnedPool(HTTPSConnectionPool):
        ConnectionCls = _PinnedHTTPSConnection

    class _PinnedAdapter(HTTPAdapter):
        def init_poolmanager(self, connections, maxsize, block=False, **kw):
            super().init_poolmanager(connections, maxsize, block=block, **kw)
            classes = dict(self.poolmanager.pool_classes_by_scheme)
            classes["https"] = _PinnedPool
            self.poolmanager.pool_classes_by_scheme = classes

    return _PinnedAdapter()


# ── identitas perangkat ──────────────────────────────────────────────────────
def _fingerprint() -> bytes:
    parts = [
        platform.system(),
        platform.release(),
        platform.machine(),
        platform.processor(),
        str(uuid.getnode()),
        os.environ.get("COMPUTERNAME", ""),
        os.environ.get("USERNAME", "") or os.environ.get("USER", ""),
    ]
    return "|".join(parts).encode("utf-8", "ignore")


def machine_hwid() -> str:
    """HWID stabil per mesin. Disimpan lokal, dibuat sekali, mode 0600."""
    try:
        if DEVICE_FILE.is_file():
            val = DEVICE_FILE.read_text(encoding="utf-8").strip()
            if len(val) == 64 and all(c in "0123456789abcdef" for c in val):
                return val
    except Exception:
        pass

    salt = secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac("sha256", _fingerprint(), salt, 200_000)
    hwid = hashlib.sha256(salt + derived).hexdigest()

    try:
        HOME.mkdir(parents=True, exist_ok=True)
        DEVICE_FILE.write_text(hwid, encoding="utf-8")
        os.chmod(DEVICE_FILE, 0o600)
    except Exception:
        pass
    return hwid


# ── Unaux / slowAES challenge ────────────────────────────────────────────────
def solve_unaux_challenge(html: str) -> Optional[str]:
    """Halaman challenge Unaux berisi toNumbers("hex") x3: key, iv, ciphertext."""
    matches = re.findall(r'toNumbers\("([a-fA-F0-9]+)"\)', html)
    if len(matches) < 3:
        return None
    try:
        key = bytes.fromhex(matches[0])
        iv = bytes.fromhex(matches[1])
        ct = bytes.fromhex(matches[2])
    except ValueError:
        return None
    if len(key) != 16 or len(iv) != 16 or len(ct) != 16:
        return None
    return _AES.new(key, _AES.MODE_CBC, iv).decrypt(ct).hex()


def _looks_like_challenge(text: str) -> bool:
    return "aes.js" in text or "slowAES" in text or "toNumbers(" in text


# ── klien ────────────────────────────────────────────────────────────────────
class LicenseClient:
    def __init__(self, base_url: str = DEFAULT_PANEL, timeout: int = 25):
        base = (base_url or DEFAULT_PANEL).strip().rstrip("/")
        if base.endswith("/api"):
            base = base[: -len("/api")]
        if not base.startswith("http"):
            base = "https://" + base
        self.base = base
        self.timeout = timeout
        self.hwid = machine_hwid()
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": _UA})
        # Jangan pernah ikut proxy/CA dari environment: rute harus deterministik
        # supaya pinning tidak bisa dilewati lewat HTTP_PROXY.
        self.session.trust_env = False
        self.session.mount("https://", _build_pinned_adapter())
        self.token: Optional[str] = None
        self.expires: int = 0

    # ── HTTP dengan bypass Unaux ────────────────────────────────────────────
    def _request(self, method: str, path: str, body: Optional[dict] = None) -> str:
        url = f"{self.base}/api/{path.lstrip('/')}"
        last = ""
        for _ in range(3):
            try:
                if method == "GET":
                    r = self.session.get(url, timeout=self.timeout)
                else:
                    r = self.session.post(
                        url,
                        json=body,
                        timeout=self.timeout,
                        headers={"Content-Type": "application/json"},
                    )
            except PinError:
                raise
            except requests.RequestException as exc:
                raise LicenseError(f"Tidak bisa menghubungi server: {exc}") from exc

            text = r.text or ""
            last = text

            if _looks_like_challenge(text):
                token = solve_unaux_challenge(text)
                if token:
                    self.session.cookies.set("__test", token, path="/")
                    if "i=1" not in url:
                        url = url + ("&i=1" if "?" in url else "?i=1")
                    continue
                raise LicenseError("Verifikasi server gagal (challenge tidak terbaca).")

            if r.status_code >= 500:
                raise LicenseError(f"Server error (HTTP {r.status_code}).")
            return text

        raise LicenseError("Server tidak merespons dengan benar: " + last[:120])

    def _json(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        raw = self._request(method, path, body)
        try:
            return json.loads(raw)
        except Exception as exc:
            raise LicenseError("Respons server bukan JSON yang valid.") from exc

    # ── PoW ─────────────────────────────────────────────────────────────────
    @staticmethod
    def _solve_pow(prefix: str, difficulty: int, max_iters: int = 8_000_000) -> str:
        if not prefix or difficulty <= 0:
            return "0"
        need = "0" * difficulty
        for i in range(max_iters):
            n = format(i, "x")
            if hashlib.sha256((prefix + n).encode()).hexdigest().startswith(need):
                return n
        raise LicenseError("Gagal menyelesaikan proof-of-work.")

    # ── login ───────────────────────────────────────────────────────────────
    def login(self, license_key: str, game: str = "ALVSIA TOOL PREMIUM") -> dict:
        key = (license_key or "").strip()
        if not key:
            raise LicenseError("License key kosong.")

        cap = self._json("GET", "captcha.php")
        if "cid" not in cap or "nonce" not in cap:
            raise LicenseError(cap.get("msg") or "Handshake ditolak server.")

        try:
            equation = base64.b64decode(cap["mechanic"]).decode()
        except Exception as exc:
            raise LicenseError("Captcha rusak.") from exc

        m = re.match(r"^(\d+)([+\-*])(\d+)$", equation.strip())
        if not m:
            raise LicenseError("Format captcha tidak dikenal.")
        a, op, b = int(m.group(1)), m.group(2), int(m.group(3))
        solution = a + b if op == "+" else (a - b if op == "-" else a * b)

        pow_nonce = self._solve_pow(
            str(cap.get("pow_prefix") or ""), int(cap.get("pow_diff") or 0)
        )

        nonce_hex = str(cap["nonce"])
        try:
            nonce_bin = bytes.fromhex(nonce_hex)
        except ValueError as exc:
            raise LicenseError("Nonce server tidak valid.") from exc

        transport_key = hashlib.sha256(PROTO_MARKER + nonce_bin).digest()
        iv = nonce_hex[:16].encode("ascii")

        payload = {
            "license": key,
            "game": game,
            "hwid": self.hwid,
            "solution": solution,
            "pow_nonce": pow_nonce,
            "ts": int(time.time()),
        }
        packet = base64.b64encode(
            _aes_enc(transport_key, iv, json.dumps(payload, separators=(",", ":")).encode())
        ).decode()

        resp = self._json(
            "POST", "connect.php", {"cid": cap["cid"], "packet": packet, "proto": PROTO}
        )

        if resp.get("status") == "error":
            raise LicenseError(resp.get("msg") or "Lisensi ditolak.")
        if resp.get("status") != "login":
            raise LicenseError("Respons server tidak dikenal.")

        try:
            server_iv = base64.b64decode(resp["ip"])
            ciphertext = base64.b64decode(resp["isp"])
            data = json.loads(_aes_dec(transport_key, server_iv, ciphertext).decode())
        except Exception as exc:
            raise LicenseError("Gagal membuka balasan server (kunci sesi salah).") from exc

        if data.get("status") != "success":
            raise LicenseError(data.get("msg") or "Lisensi ditolak.")
        if data.get("check_token") != cap["cid"]:
            raise LicenseError("Peringatan keamanan: sesi tidak cocok.")
        if abs(time.time() - int(data.get("server_ts") or 0)) > 180:
            raise LicenseError("Peringatan keamanan: waktu server tidak sinkron.")

        token = data.get("session_token")
        if not token:
            raise LicenseError("Server tidak mengirim session token.")

        self.token = token
        self.expires = int(data.get("session_expires") or 0)

        return {
            "msg": data.get("msg"),
            "expiry": data.get("expiry"),
            "seller": data.get("seller"),
            "max_devices": data.get("max_devices"),
            "session_token": token,
            "session_expires": self.expires,
            "session_ttl": data.get("session_ttl"),
            "hwid": self.hwid,
        }

    # ── perpanjang sesi ─────────────────────────────────────────────────────
    def refresh(self) -> bool:
        if not self.token:
            return False
        try:
            data = self._json(
                "POST",
                "refresh_session.php",
                {"session_token": self.token, "hwid": self.hwid},
            )
        except LicenseError:
            return False
        if data.get("status") != "ok":
            self.token = None
            return False
        self.expires = int(data.get("session_expires") or 0)
        return True

    def ensure_session(self) -> bool:
        if not self.token:
            return False
        if self.expires and time.time() > self.expires - 120:
            return self.refresh()
        return True

    # ── aset ────────────────────────────────────────────────────────────────
    def get_asset(self, category: str = "lib", name: str = "") -> dict:
        if not self.token:
            raise LicenseError("Belum login.")
        body = {"session_token": self.token, "category": category, "hwid": self.hwid}
        if name:
            body["name"] = name
        return self._json("POST", "get_asset.php", body)

    def download_asset(self, asset_token: str, dest_path: str) -> bool:
        url = f"{self.base}/api/download_asset.php?token={asset_token}"
        try:
            self._request("GET", f"download_asset.php?token={asset_token}")
            r = self.session.get(url, timeout=120)
        except requests.RequestException:
            return False
        if r.status_code != 200:
            return False
        ctype = r.headers.get("content-type", "")
        if "json" in ctype and r.content[:1] == b"{":
            return False
        Path(dest_path).parent.mkdir(parents=True, exist_ok=True)
        Path(dest_path).write_bytes(r.content)
        return True


# ── CLI kecil untuk diagnosa ────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="ALVSIA TOOL PREMIUM — license client")
    ap.add_argument("--url", default=DEFAULT_PANEL, help="base URL panel")
    ap.add_argument("--key", required=True, help="license key")
    args = ap.parse_args()

    try:
        client = LicenseClient(args.url)
        out = client.login(args.key)
        print("OK  :", out.get("msg"))
        print("Exp :", out.get("expiry"))
        print("Dev :", out.get("max_devices"))
        print("Tok :", (out.get("session_token") or "")[:16], "...")
    except LicenseError as exc:
        print("GAGAL:", exc)
        raise SystemExit(1)
