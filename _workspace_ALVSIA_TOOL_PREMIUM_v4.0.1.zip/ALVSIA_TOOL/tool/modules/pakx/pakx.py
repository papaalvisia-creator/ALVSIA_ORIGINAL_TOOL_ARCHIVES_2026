#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import shutil
import importlib.util
from pathlib import Path

# ============================================================================
# DEPENDENCY CHECK & AUTO-INSTALL
# ============================================================================

def install_pip_package(package):
    subprocess.run([sys.executable, "-m", "pip", "install", package], check=True)

def check_and_install_dependencies():
    """Auto-install required Python packages and system tools for Termux."""
    python_packages = ["rich", "pycryptodome", "zstandard", "gmalg"]
    import_map = {"rich": "rich", "pycryptodome": "Crypto", "zstandard": "zstandard", "gmalg": "gmalg"}
    for pkg in python_packages:
        try:
            __import__(import_map.get(pkg, pkg.replace("-", "_")))
        except ImportError:
            print(f"Installing {pkg}...")
            install_pip_package(pkg)

    if os.name != 'nt':
        pass

check_and_install_dependencies()

# Now safe to import rich and other libs
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box
from rich.prompt import Prompt

import struct
import re
import tempfile
import zlib
import hashlib
from dataclasses import dataclass
from functools import lru_cache
from typing import List, Optional, Tuple
import itertools as it
import math
from pathlib import PurePath

from Crypto.Cipher import AES
from Crypto.Cipher.AES import MODE_CBC
from Crypto.Hash import SHA1
from Crypto.Util.Padding import unpad, pad
from zstandard import ZstdDecompressor, ZstdCompressor, ZstdCompressionDict, DICT_TYPE_AUTO

try:
    import gmalg
except ImportError:
    print("gmalg not found, installing...")
    subprocess.run([sys.executable, "-m", "pip", "install", "gmalg"], check=True)
    import gmalg

console = Console()

# ============================================================================
# DIRECTORY STRUCTURE
# ============================================================================

PAKX_BASE = Path(__file__).resolve().parent / "work"

PAK_BASE = PAKX_BASE / "PAK"
ORIGINAL_PAK_DIR = PAK_BASE / "ORIGINAL_PAK"
EXTRACTED_DIR = PAK_BASE / "EXTRACTED_FILES"
EDITED_FILES_DIR = PAK_BASE / "EDITTED_FILES"
REPACKED_PAK_DIR = PAK_BASE / "REPACKED_PAK"
TEMP_REPACK_DIR = PAK_BASE / "TEMP_REPACK"

LUA_BASE = PAKX_BASE / "LUA"
ORIGINAL_LUA_DIR = LUA_BASE / "ORIGINAL LUA"
SOURCE_LUA_DIR = LUA_BASE / "SOURCE LUA"
EDITED_LUA_DIR = LUA_BASE / "EDITTED LUA"
COMPILED_LUA_DIR = LUA_BASE / "COMPILED LUA"

EXES_DIR = PAKX_BASE / "BIN"

def ensure_dirs():
    for d in [ORIGINAL_PAK_DIR, EXTRACTED_DIR, EDITED_FILES_DIR, REPACKED_PAK_DIR, TEMP_REPACK_DIR,
              ORIGINAL_LUA_DIR, SOURCE_LUA_DIR, EDITED_LUA_DIR, COMPILED_LUA_DIR, EXES_DIR]:
        d.mkdir(parents=True, exist_ok=True)
    set_executable_permissions()

def clear_screen():
    os.system('clear' if os.name != 'nt' else 'cls')

def set_executable_permissions():
    if os.name == 'nt':
        return
    if not EXES_DIR.exists():
        return
    for item in EXES_DIR.iterdir():
        if item.is_file():
            try:
                item.chmod(item.stat().st_mode | 0o111)
            except Exception as e:
                console.print(f"[yellow]Could not chmod {item.name}: {e}[/yellow]")

# ============================================================================
# CONSTANTS
# ============================================================================

_K = bytes.fromhex("112136474657a78d9d8490d8ab008c35261af7e45805b8b31507d02c1e8ff6c8")

OP_MOVE=17; OP_LOADK=18; OP_LOADBOOL=3; OP_LOADNIL=21; OP_GETUPVAL=22
OP_GETTABUP=23; OP_GETTABLE=24; OP_SETTABUP=8; OP_SETTABLE=27
OP_NEWTABLE=28; OP_SELF=29; OP_ADD=13; OP_SUB=14; OP_MUL=2; OP_DIV=5
OP_LEN=20; OP_CONCAT=16; OP_UNM=25; OP_NOT=26; OP_JMP=30; OP_EQ=31
OP_LT=32; OP_LE=33; OP_TEST=34; OP_TESTSET=35; OP_CALL=36; OP_TAILCALL=37
OP_RETURN=38; OP_FORLOOP=39; OP_FORPREP=40; OP_TFORCALL=41; OP_TFORLOOP=42
OP_SETLIST=43; OP_CLOSURE=44; OP_VARARG=45; OP_EXTRAARG=46

LUA_NIL=0; LUA_BOOL=1; LUA_NUM=3; LUA_FLOAT=19; LUA_STR=4; LUA_STRL=20

CUSTOM_TO_STD = {
    17:0, 18:1, 3:3, 21:4, 22:5, 23:6, 24:7, 8:8,
    27:10, 28:11, 29:12, 13:13, 14:14, 2:15, 5:18,
    20:28, 16:29, 25:25, 26:27, 30:30, 31:31, 32:32,
    33:33, 34:34, 35:35, 36:36, 37:37, 38:38, 39:39,
    40:40, 41:41, 42:42, 43:43, 44:44, 45:45, 46:46
}
STD_TO_CUSTOM = {v: k for k, v in CUSTOM_TO_STD.items()}

# ============================================================================
# DECOMPILATION LOGIC
# ============================================================================

def _xor(data, key):
    return bytes([data[i] ^ key[i % len(key)] for i in range(len(data))])

class Reader_new:
    def __init__(self, d, k): self.d=d; self.pos=0; self.k=k
    def read(self, n):
        v=bytes(self.d[self.pos:self.pos+n]); self.pos+=n; return v
    def byte(self):
        v=self.d[self.pos]; self.pos+=1; return v
    def i32(self):
        v=struct.unpack_from('<i',self.d,self.pos)[0]; self.pos+=4; return v
    def i64(self):
        v=struct.unpack_from('<q',self.d,self.pos)[0]; self.pos+=8; return v
    def dbl(self):
        v=struct.unpack_from('<d',self.d,self.pos)[0]; self.pos+=8; return v
    def string(self):
        sz=self.byte()
        if sz==0: return None
        if sz==0xFF:
            sz=struct.unpack_from('<Q',self.d,self.pos)[0]; self.pos+=8
        raw=bytes(self.d[self.pos:self.pos+sz-1]); self.pos+=sz-1
        b=_xor(raw,self.k)
        try: return b.decode('utf-8')
        except: return b.decode('latin-1',errors='replace')

class P:
    __slots__=('src','ld','ll','np','va','ms','ins','K','upvals','upvs','locs','subs')
    def __init__(self):
        self.src=None;self.ld=0;self.ll=0;self.np=0;self.va=0;self.ms=0
        self.ins=[];self.K=[];self.upvals=b'';self.upvs=[];self.locs=[];self.subs=[]

def parse(r):
    p=P()
    try:
        p.src=r.string()
        p.ld=r.i32(); p.ll=r.i32()
        p.np=r.byte(); p.va=r.byte(); p.ms=r.byte()
        n=r.i32()
        p.ins=[struct.unpack_from('<I',r.read(4))[0] for _ in range(n)]
        n=r.i32()
        for _ in range(n):
            t=r.byte()
            if t==LUA_NIL:   p.K.append(('nil',None))
            elif t==LUA_BOOL: b=r.byte(); p.K.append(('bool',bool(b)))
            elif t==LUA_NUM:
                raw=r.i64(); fv=struct.unpack('<d',struct.pack('<q',raw))[0]
                p.K.append(('float',fv))
            elif t==LUA_FLOAT:
                raw=r.dbl(); iv=struct.unpack('<q',struct.pack('<d',raw))[0]
                p.K.append(('int',iv))
            elif t in (LUA_STR,LUA_STRL): s=r.string(); p.K.append(('str',s))
            else: raise ValueError(f'Unknown const {t}')
        n=r.i32()
        p.upvals = r.read(n*2)
        n=r.i32()
        for _ in range(n): p.subs.append(parse(r))
        n=r.i32(); r.read(n); n=r.i32(); r.read(n*8); n=r.i32()
        for _ in range(n):
            nm=r.string(); sp=r.i32(); ep=r.i32()
            if nm: p.locs.append((nm,sp,ep))
        n=r.i32()
        for _ in range(n):
            s=r.string()
            if s: p.upvs.append(s)
        return p
    except Exception: return None

def load_proto(path):
    try:
        with open(path,'rb') as f: d=bytearray(f.read())
        if len(d)<34 or d[:4]!=b'\x1bLua' or d[4]!=0x53: return None
        r=Reader_new(d,_K); r.pos=34
        return parse(r)
    except: return None

class UniversalWriter:
    def __init__(self, mode):
        self.data = bytearray()
        self.mode = mode
        self.is_53 = "5.3" in mode
        self.is_32 = "_32" in mode
    def write(self, b): self.data.extend(b)
    def byte(self, v): self.data.append(v & 0xFF)
    def i32(self, v): self.data.extend(struct.pack('<i', v))
    def i64(self, v): self.data.extend(struct.pack('<q', v))
    def dbl(self, v): self.data.extend(struct.pack('<d', v))
    def string(self, s):
        if s is None:
            self.i32(0) if not self.is_53 else self.byte(0)
        else:
            b = s.encode('utf-8')
            sz = len(b) + 1
            if self.is_53:
                if sz < 0xFF:
                    self.byte(sz)
                else:
                    self.byte(0xFF)
                    fmt = '<I' if self.is_32 else '<Q'
                    self.data.extend(struct.pack(fmt, sz))
                self.write(b)
            else:
                fmt = '<I' if self.is_32 else '<Q'
                self.data.extend(struct.pack(fmt, sz))
                self.write(b)
    def write_proto(self, p):
        self.string(p.src)
        self.i32(p.ld)
        self.i32(p.ll)
        if not self.is_53: self.byte(len(p.upvals) // 2)
        self.byte(p.np)
        self.byte(1 if p.va else 0)
        self.byte(250)
        self.i32(len(p.ins))
        for ins in p.ins:
            op = ins & 0x3F
            std_op = CUSTOM_TO_STD.get(op, op)
            if std_op > 46: std_op = 0
            new_ins = (ins & ~0x3F) | std_op
            self.data.extend(struct.pack('<I', new_ins))
        self.i32(len(p.K))
        for typ, val in p.K:
            if typ == 'nil':
                self.byte(0)
            elif typ == 'bool':
                self.byte(1); self.byte(1 if val else 0)
            elif typ == 'float':
                self.byte(3); self.dbl(val)
            elif typ == 'int':
                if self.is_53:
                    self.byte(19)
                    if "int4" in self.mode: self.i32(int(val))
                    else: self.i64(int(val))
                else:
                    self.byte(3); self.dbl(float(val))
            elif typ == 'str':
                if self.is_53:
                    b = val.encode('utf-8')
                    if len(b) >= 40: self.byte(20)
                    else: self.byte(4)
                else:
                    self.byte(4)
                self.string(val)
        if self.is_53:
            n_ups = len(p.upvals) // 2
            self.i32(n_ups)
            self.write(p.upvals)
        self.i32(len(p.subs))
        for sub in p.subs: self.write_proto(sub)
        self.i32(len(p.ins))
        for _ in range(len(p.ins)): self.i32(1)
        self.i32(len(p.locs))
        for nm, sp, ep in p.locs:
            self.string(nm); self.i32(sp); self.i32(ep)
        n_ups = len(p.upvals) // 2
        self.i32(n_ups)
        for i in range(n_ups):
            name = p.upvs[i] if i < len(p.upvs) else f"upval_{i}"
            self.string(name)

def build_std_file(proto, mode, out_path):
    w = UniversalWriter(mode)
    if mode == "5.3_64":
        w.data.extend(b'\x1bLua\x53\x00\x19\x93\r\n\x1a\n\x04\x08\x04\x08\x08')
        w.data.extend(struct.pack('<q', 0x5678))
        w.data.extend(struct.pack('<d', 370.5))
        w.byte(len(proto.upvals) // 2)
    elif mode == "5.3_32":
        w.data.extend(b'\x1bLua\x53\x00\x19\x93\r\n\x1a\n\x04\x04\x04\x08\x08')
        w.data.extend(struct.pack('<q', 0x5678))
        w.data.extend(struct.pack('<d', 370.5))
        w.byte(len(proto.upvals) // 2)
    elif mode == "5.3_32_int4":
        w.data.extend(b'\x1bLua\x53\x00\x19\x93\r\n\x1a\n\x04\x04\x04\x04\x08')
        w.data.extend(struct.pack('<i', 0x5678))
        w.data.extend(struct.pack('<d', 370.5))
        w.byte(len(proto.upvals) // 2)
    elif mode == "5.1_32":
        w.data.extend(b'\x1bLua\x51\x00\x01\x04\x04\x04\x08\x00')
    elif mode == "5.1_64":
        w.data.extend(b'\x1bLua\x51\x00\x01\x04\x08\x04\x08\x00')
    w.write_proto(proto)
    with open(out_path, 'wb') as f: f.write(w.data)

def find_luadec():
    exes_path = EXES_DIR / "luadec"
    if exes_path.exists():
        if not os.access(exes_path, os.X_OK) and os.name != 'nt':
            try:
                exes_path.chmod(exes_path.stat().st_mode | 0o111)
            except:
                pass
        if os.access(exes_path, os.X_OK) or os.name == 'nt':
            return str(exes_path)
    exes_path = EXES_DIR / "luadec.exe"
    if exes_path.exists():
        return str(exes_path)
    return shutil.which('luadec')

def attempt_decompile(luadec_path, target_bytecode, output_lua):
    try:
        res = subprocess.run([luadec_path, target_bytecode], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        out_data = res.stdout.decode('utf-8', errors='replace')
        if res.returncode == 0 and len(out_data.strip()) > 10:
            with open(output_lua, 'w', encoding='utf-8') as f:
                f.write(out_data)
            return True, ""
        return False, res.stderr.decode('utf-8', errors='replace')
    except Exception as e:
        return False, str(e)

def fix_lua_syntax(content: str) -> str:
    content = re.sub(r'#(\w+):', r'#\1.', content)
    content = re.sub(r'=\s*\.\s*end\b', '= nil', content)
    content = re.sub(r'\bend\.\s*$', 'end', content, flags=re.MULTILINE)
    content = re.sub(r'[^\x20-\x7E\n\t\r]', '', content)
    return content

def remove_lua_comments(content: str) -> str:
    result = []
    i = 0
    n = len(content)
    in_string = False
    string_char = None
    in_long_string = False
    long_string_level = 0
    in_block_comment = False
    block_comment_level = 0
    while i < n:
        ch = content[i]
        if not in_string and not in_long_string and not in_block_comment:
            if ch == '-' and i+1 < n and content[i+1] == '-':
                if i+2 < n and content[i+2] == '[':
                    j = i+3
                    level = 0
                    while j < n and content[j] == '=':
                        level += 1
                        j += 1
                    if j < n and content[j] == '[':
                        in_block_comment = True
                        block_comment_level = level
                        i = j+1
                        continue
                    else:
                        i += 2
                        while i < n and content[i] not in '\r\n':
                            i += 1
                        continue
                else:
                    i += 2
                    while i < n and content[i] not in '\r\n':
                        i += 1
                    continue
        if in_block_comment:
            if ch == ']' and i+1 < n and content[i+1] == ']':
                j = i+2
                level_check = 0
                while j < n and content[j] == '=':
                    level_check += 1
                    j += 1
                if j < n and content[j] == ']' and level_check == block_comment_level:
                    in_block_comment = False
                    i = j+1
                    continue
            i += 1
            continue
        if not in_string and not in_long_string and (ch == '"' or ch == "'"):
            in_string = True
            string_char = ch
            result.append(ch)
            i += 1
            continue
        elif in_string:
            result.append(ch)
            if ch == '\\' and i+1 < n:
                result.append(content[i+1])
                i += 2
                continue
            elif ch == string_char:
                in_string = False
            i += 1
            continue
        if not in_string and not in_long_string and not in_block_comment and ch == '[' and i+1 < n and content[i+1] == '[':
            j = i+2
            level = 0
            while j < n and content[j] == '=':
                level += 1
                j += 1
            if j < n and content[j] == '[':
                in_long_string = True
                long_string_level = level
                result.append(content[i:j+1])
                i = j+1
                continue
        if in_long_string:
            result.append(ch)
            if ch == ']' and i+1 < n and content[i+1] == ']':
                j = i+2
                level_check = 0
                while j < n and content[j] == '=':
                    level_check += 1
                    j += 1
                if j < n and content[j] == ']' and level_check == long_string_level:
                    result.append(content[i+1:j+1])
                    i = j+1
                    in_long_string = False
                    continue
            i += 1
            continue
        result.append(ch)
        i += 1
    return ''.join(result)

def intelligent_decompile_file(in_path, out_path):
    luadec = find_luadec()
    if not luadec:
        return False, "luadec executable not found"
    proto = load_proto(in_path)
    if not proto:
        return False, "Failed to decode bytecode"
    modes = ["5.3_64", "5.3_32", "5.3_32_int4", "5.1_64", "5.1_32"]
    error_logs = []
    for mode in modes:
        with tempfile.NamedTemporaryFile(suffix='.luac', delete=False) as tmp_f:
            std_path = tmp_f.name
        try:
            build_std_file(proto, mode, std_path)
            ok, mode_err = attempt_decompile(luadec, std_path, out_path)
            if ok:
                with open(out_path, 'r', encoding='utf-8') as f:
                    original = f.read()
                cleaned = remove_lua_comments(original)
                cleaned_fixed = fix_lua_syntax(cleaned)
                with open(out_path, 'w', encoding='utf-8') as f:
                    f.write(cleaned_fixed)
                return True, f"Success with {mode}"
            error_logs.append(f"{mode}: {mode_err}")
        finally:
            if os.path.exists(std_path): os.unlink(std_path)
    return False, "\n".join(error_logs)

# ============================================================================
# COMPILATION LOGIC
# ============================================================================

class StdProto:
    __slots__ = ('src', 'ld', 'll', 'np', 'va', 'ms', 'ins', 'K', 'upvals', 'subs')
    def __init__(self):
        self.K = []
        self.subs = []

class StdReader:
    def __init__(self, data):
        self.d = data
        self.pos = 0
        self.sz_int = self.d[12]
        self.sz_size_t = self.d[13]
        self.sz_ins = self.d[14]
        self.sz_lua_int = self.d[15]
        self.sz_lua_num = self.d[16]
        self.fmt_int = '<i' if self.sz_int == 4 else '<q'
        self.fmt_size_t = '<I' if self.sz_size_t == 4 else '<Q'
        self.pos = 34
    def read(self, n): v = self.d[self.pos:self.pos+n]; self.pos += n; return v
    def byte(self): v = self.d[self.pos]; self.pos += 1; return v
    def int(self): v = struct.unpack_from(self.fmt_int, self.d, self.pos)[0]; self.pos += self.sz_int; return v
    def size_t(self): v = struct.unpack_from(self.fmt_size_t, self.d, self.pos)[0]; self.pos += self.sz_size_t; return v
    def lua_int(self): v = struct.unpack_from('<q', self.d, self.pos)[0]; self.pos += self.sz_lua_int; return v
    def lua_num(self): v = struct.unpack_from('<d', self.d, self.pos)[0]; self.pos += self.sz_lua_num; return v
    def string(self):
        sz = self.byte()
        if sz == 0: return None
        if sz == 0xFF:
            sz = self.size_t()
        length = sz - 1
        v = self.d[self.pos : self.pos + length]
        self.pos += length
        return v

def parse_std(r):
    p = StdProto()
    p.src = r.string()
    p.ld = r.int()
    p.ll = r.int()
    p.np = r.byte()
    p.va = r.byte()
    p.ms = r.byte()
    n = r.int()
    p.ins = []
    for _ in range(n):
        ins = struct.unpack_from('<I', r.read(r.sz_ins))[0]
        p.ins.append(ins)
    n = r.int()
    p.K = []
    for _ in range(n):
        t = r.byte()
        if t == 0: p.K.append((t, None))
        elif t == 1: p.K.append((t, r.byte()))
        elif t == 3: p.K.append((t, r.lua_num()))
        elif t == 19: p.K.append((t, r.lua_int()))
        elif t in (4, 20): p.K.append((t, r.string()))
        else: raise ValueError(f"Unknown const type {t}")
    n = r.int()
    p.upvals = r.read(n * 2)
    n = r.int()
    p.subs = [parse_std(r) for _ in range(n)]
    n = r.int(); r.read(n * r.sz_int)
    n = r.int()
    for _ in range(n): r.string(); r.int(); r.int()
    n = r.int()
    for _ in range(n): r.string()
    return p

class CustomWriter:
    def __init__(self, key):
        self.d = bytearray()
        self.key = key
    def write(self, b): self.d.extend(b)
    def byte(self, v): self.d.append(v & 0xFF)
    def i32(self, v): self.d.extend(struct.pack('<i', v))
    def string(self, b):
        if b is None:
            self.byte(0)
        else:
            if isinstance(b, str):
                b = b.encode('utf-8')
            sz = len(b) + 1
            if sz < 0xFF:
                self.byte(sz)
            else:
                self.byte(0xFF)
                self.d.extend(struct.pack('<Q', sz))
            enc = _xor(b, self.key)
            self.write(enc)

def write_custom(p, w):
    w.string(p.src)
    w.i32(p.ld)
    w.i32(p.ll)
    w.byte(p.np)
    w.byte(p.va)
    w.byte(p.ms)
    w.i32(len(p.ins))
    for ins in p.ins:
        w.write(struct.pack('<I', ins))
    w.i32(len(p.K))
    for typ, val in p.K:
        if typ == 'nil':
            w.byte(LUA_NIL)
        elif typ == 'bool':
            w.byte(LUA_BOOL)
            w.byte(1 if val else 0)
        elif typ == 'float':
            w.byte(LUA_NUM)
            w.write(struct.pack('<d', val))
        elif typ == 'int':
            w.byte(LUA_FLOAT)
            w.write(struct.pack('<q', val))
        elif typ == 'str':
            w.byte(LUA_STR)
            w.string(val)
        else:
            raise ValueError(f"Unknown constant type {typ}")
    n_upvals = len(p.upvals) // 2
    w.i32(n_upvals)
    w.write(p.upvals)
    w.i32(len(p.subs))
    for sub in p.subs:
        write_custom(sub, w)
    w.i32(0)
    w.i32(0)
    w.i32(len(p.locs))
    for nm, sp, ep in p.locs:
        w.string(nm)
        w.i32(sp)
        w.i32(ep)
    w.i32(len(p.upvs))
    for uv in p.upvs:
        w.string(uv)

def ensure_luac53():
    exes_luac = EXES_DIR / "luac5.3"
    if exes_luac.exists():
        if not os.access(exes_luac, os.X_OK) and os.name != 'nt':
            try:
                exes_luac.chmod(exes_luac.stat().st_mode | 0o111)
            except:
                pass
        if os.access(exes_luac, os.X_OK) or os.name == 'nt':
            return str(exes_luac)
    exes_luac = EXES_DIR / "luac"
    if exes_luac.exists():
        if not os.access(exes_luac, os.X_OK) and os.name != 'nt':
            try:
                exes_luac.chmod(exes_luac.stat().st_mode | 0o111)
            except:
                pass
        try:
            r = subprocess.run([str(exes_luac), '-v'], capture_output=True, timeout=3)
            if b'5.3' in r.stdout or b'5.3' in r.stderr:
                return str(exes_luac)
        except: pass
    for name in ['luac5.3', 'luac']:
        path = shutil.which(name)
        if path:
            try:
                r = subprocess.run([path, '-v'], capture_output=True, timeout=3)
                if b'5.3' in r.stdout or b'5.3' in r.stderr:
                    return path
            except: pass
    if os.name != 'nt':
        console.print("[yellow]luac5.3 not found. Installing lua5.3 via pkg...[/yellow]")
        try:
            subprocess.run(["pkg", "install", "lua5.3", "-y"], check=True)
            for name in ['luac5.3', 'luac']:
                path = shutil.which(name)
                if path:
                    return path
        except Exception as e:
            console.print(f"[red]Failed to install lua5.3: {e}[/red]")
    return None

def compile_file(src_path, out_path, original_bytecode_path):
    orig_source_path = src_path + ".orig"
    if os.path.exists(orig_source_path):
        with open(src_path, 'r', encoding='utf-8', errors='replace') as f_src:
            cur_source = f_src.read()
        with open(orig_source_path, 'r', encoding='utf-8', errors='replace') as f_orig:
            if cur_source == f_orig.read():
                shutil.copy2(original_bytecode_path, out_path)
                return True, "Unchanged – original bytecode copied"
    luac = ensure_luac53()
    if not luac:
        return False, "luac5.3 not found and could not be installed."
    original_proto = load_proto(original_bytecode_path)
    if not original_proto:
        return False, "Failed to parse original custom bytecode"
    with tempfile.NamedTemporaryFile(suffix='.luac', delete=False) as tf:
        tmp_out = tf.name
    try:
        result = subprocess.run([luac, '-o', tmp_out, src_path], capture_output=True, timeout=30)
        if result.returncode != 0:
            return False, f"Syntax error: {result.stderr.decode('utf-8', errors='replace')[:300]}"
        with open(tmp_out, 'rb') as f:
            std_bytecode = f.read()
        if len(std_bytecode) < 34 or std_bytecode[:4] != b'\x1bLua' or std_bytecode[4] != 0x53:
            return False, "Invalid bytecode generated"
        r = StdReader(std_bytecode)
        std_p = parse_std(r)
        new_ins = []
        for ins in std_p.ins:
            op = ins & 0x3F
            custom_op = STD_TO_CUSTOM.get(op, op)
            new_ins.append((ins & ~0x3F) | custom_op)
        new_K = []
        for t, v in std_p.K:
            if t == 0: new_K.append(('nil', None))
            elif t == 1: new_K.append(('bool', bool(v)))
            elif t == 3: new_K.append(('float', v))
            elif t == 19: new_K.append(('int', v))
            elif t in (4,20): new_K.append(('str', v.decode('utf-8')))
        original_proto.ins = new_ins
        original_proto.K = new_K
        def replace_subs(orig, new):
            if len(orig.subs) != len(new.subs): return
            for i in range(len(orig.subs)):
                orig.subs[i].ins = []
                for ins in new.subs[i].ins:
                    op = ins & 0x3F
                    custom_op = STD_TO_CUSTOM.get(op, op)
                    orig.subs[i].ins.append((ins & ~0x3F) | custom_op)
                orig.subs[i].K = []
                for t, v in new.subs[i].K:
                    if t == 0: orig.subs[i].K.append(('nil', None))
                    elif t == 1: orig.subs[i].K.append(('bool', bool(v)))
                    elif t == 3: orig.subs[i].K.append(('float', v))
                    elif t == 19: orig.subs[i].K.append(('int', v))
                    elif t in (4,20): orig.subs[i].K.append(('str', v.decode('utf-8')))
                replace_subs(orig.subs[i], new.subs[i])
        replace_subs(original_proto, std_p)
        w = CustomWriter(_K)
        write_custom(original_proto, w)
        with open(original_bytecode_path, 'rb') as f_org:
            org_data = f_org.read()
        orig_header = org_data[:34]
        new_proto = bytes(w.d)
        footer = org_data[34 + len(new_proto):] if len(org_data) > 34 + len(new_proto) else b''
        final_bytecode = orig_header + new_proto + footer
        with open(out_path, 'wb') as f:
            f.write(final_bytecode)
        return True, ""
    except Exception as e:
        return False, f"Compiler error: {e}"
    finally:
        if os.path.exists(tmp_out): os.unlink(tmp_out)

# ============================================================================
# PAK HANDLING LOGIC
# ============================================================================

ZUC_KEY = bytes.fromhex('01010101010101010101010101010101')
ZUC_IV = bytes.fromhex('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')

RSA_MOD_1 = bytes.fromhex(
    'CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4')
RSA_MOD_2 = bytes.fromhex(
    '7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8')

SIMPLE1_DECRYPT_KEY = 0x79
SIMPLE2_DECRYPT_KEY = bytes.fromhex('E55B4ED1')
SIMPLE2_BLOCK_SIZE = 16
SM4_SECRET_4 = 'XG2QW5LP7LV2IN5F'
SM4_SECRET_2 = 'Q0hVTKey$as*1ZFlQCiA'
SM4_SECRET_NEW = [
    'xG2qW5lP7lV2iN5fN5pG', 'xT1cJ6dL5wC0kK1rB4dK', 'qC4jS5bZ6fL5xE6nD4zA',
    'gD4jQ2aL3bS3lC3xT0iW', 'xU1yQ8wE9zY3gZ3bT5aE', 'uQ3cO2dX7xY4xU7gH7iS',
    'gW1fR0jK6wQ4oN0oK1kZ', 'aJ4pV7iZ7pU4wP2aC2cZ', 'cX6jT3cM2oT3vK0kJ1qN',
    'iT2vS0cS6yT6cZ1sE1lO', 'hM1pH9iY8wM9hT4lN5uJ', 'kG6bC8jK0fL0dE4sH4mL',
    'dB6lB3vE0eZ8wM8rI0aC'
]

EM_SIMPLE1 = 1
EM_SIMPLE2 = 16
EM_SM4_2 = 2
EM_SM4_4 = 4
EM_SM4_NEW_BASE = 31
EM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE
EM_UNKNOWN_17 = 17

CM_NONE = 0
CM_ZLIB = 1
CM_ZSTD = 6
CM_ZSTD_DICT = 8
CM_MASK = 15

_S_BOX = bytes([
    0x34, 0x66, 0x25, 0x74, 0x89, 0x78, 0xE4, 0xA9, 0x5A, 0x41, 0xBC, 0x7A, 0xD6, 0x16, 0x21, 0x23,
    0x4D, 0x61, 0xDA, 0x94, 0x9B, 0xDF, 0x13, 0x3C, 0x69, 0x3A, 0x31, 0x0A, 0x5F, 0xD7, 0x99, 0x95,
    0xF1, 0xAE, 0x72, 0x3D, 0x07, 0x60, 0x24, 0xB6, 0x98, 0xEE, 0xC4, 0xA2, 0x2D, 0x88, 0xDD, 0x8D,
    0x04, 0xEA, 0xBB, 0x11, 0xCA, 0x3E, 0x5D, 0xA1, 0xF6, 0x3F, 0xB0, 0x97, 0x80, 0x47, 0x2B, 0xA6,
    0xE6, 0xF7, 0xD9, 0xB1, 0x59, 0xC0, 0x7C, 0xBE, 0x54, 0x28, 0xB7, 0x7E, 0x4F, 0xF8, 0x43, 0x6E,
    0xA0, 0x50, 0x0E, 0xF5, 0x90, 0xB8, 0xFB, 0xA3, 0x7B, 0x62, 0x19, 0x46, 0x03, 0x2A, 0xB9, 0x8F,
    0x9F, 0x77, 0xB4, 0x5B, 0x83, 0x87, 0x08, 0xEB, 0xE2, 0x1E, 0x42, 0xF0, 0x0F, 0xE8, 0x71, 0x6A,
    0x75, 0xAD, 0x55, 0x1F, 0xB5, 0xAB, 0x33, 0xFA, 0x7F, 0x15, 0xBD, 0x85, 0xD8, 0x06, 0x68, 0xB3,
    0x52, 0x30, 0x48, 0x0B, 0x00, 0xED, 0xEF, 0xB2, 0x57, 0x8E, 0xE7, 0x6C, 0xD5, 0xE5, 0x2E, 0x53,
    0x82, 0x05, 0xF9, 0x81, 0xF4, 0x56, 0xBF, 0x8C, 0x4B, 0xE3, 0xDB, 0x4A, 0x91, 0x4C, 0x2C, 0xD3,
    0x40, 0x29, 0x4E, 0x20, 0x14, 0x36, 0x79, 0x09, 0x6F, 0xD1, 0x37, 0xE0, 0x39, 0x0C, 0x8A, 0x92,
    0x38, 0x12, 0x35, 0x6D, 0xE1, 0xFD, 0x93, 0x9A, 0x17, 0xD4, 0xC9, 0x9C, 0x6B, 0x84, 0x26, 0x9D,
    0xAF, 0x76, 0xC1, 0x9E, 0xD0, 0x96, 0xC5, 0xCB, 0xE9, 0x73, 0x49, 0xD2, 0xCD, 0x64, 0xC3, 0xC7,
    0x01, 0x7D, 0xF3, 0xAC, 0xFC, 0xDE, 0xA4, 0x44, 0x32, 0x1B, 0xC2, 0xBA, 0x1C, 0x02, 0xC6, 0x27,
    0x45, 0x8B, 0xF2, 0x18, 0xA7, 0x10, 0x51, 0x1D, 0xC8, 0xCF, 0x63, 0xFF, 0x2F, 0x0D, 0x58, 0xCE,
    0x65, 0xA5, 0xDC, 0x1A, 0x3B, 0x86, 0xFE, 0x22, 0x5C, 0xA8, 0x5E, 0x67, 0xAA, 0xEC, 0x70, 0xCC
])

_FK = [0x46970E9C, 0x4BC0685E, 0x59056186, 0xBCA2491E]
_CK = [
    0x000EB92B, 0x3A0AE783, 0x9E3B5C67, 0xADDBDABF, 0x7B7484CB, 0x49156C63, 0xC79AB5E7, 0x79EC9CFF,
    0x1725BEAB, 0x2FB89CA3, 0x24808AD7, 0xDDD28B1F, 0x4740DA4B, 0xBBC3EA73, 0x247B30E7, 0x91BE385F,
    0x0401248B, 0x45FCD3A3, 0x530B4CE7, 0xC68DD35F, 0xE3D16C2B, 0x4F698C13, 0x6B92C747, 0x769EFB1F,
    0x4C73BE9B, 0xC942B193, 0xAD80D827, 0x372FB33F, 0x13CB6AAB, 0x2BDC0AA3, 0x17A4A247, 0xD5E96CAF
]

def _BS(X):
    return ((_S_BOX[(X >> 24) & 0xff] << 24) |
            (_S_BOX[(X >> 16) & 0xff] << 16) |
            (_S_BOX[(X >> 8) & 0xff] << 8) |
            (_S_BOX[X & 0xff]))

def _T0(X):
    X = _BS(X)
    return X ^ ROL32(X, 2) ^ ROL32(X, 10) ^ ROL32(X, 18) ^ ROL32(X, 24)

def _T1(X):
    X = _BS(X)
    return X ^ ROL32(X, 13) ^ ROL32(X, 23)

def ROL32(x, n):
    return ((x << n) & 0xFFFFFFFF) | ((x >> (32 - n)) & 0xFFFFFFFF)

def _key_expand(key: bytes, rkey: List[int]):
    K0 = int.from_bytes(key[0:4], "big") ^ _FK[0]
    K1 = int.from_bytes(key[4:8], "big") ^ _FK[1]
    K2 = int.from_bytes(key[8:12], "big") ^ _FK[2]
    K3 = int.from_bytes(key[12:16], "big") ^ _FK[3]
    for i in range(0, 32, 4):
        K0 = K0 ^ _T1(K1 ^ K2 ^ K3 ^ _CK[i])
        rkey[i] = K0
        K1 = K1 ^ _T1(K2 ^ K3 ^ K0 ^ _CK[i+1])
        rkey[i+1] = K1
        K2 = K2 ^ _T1(K3 ^ K0 ^ K1 ^ _CK[i+2])
        rkey[i+2] = K2
        K3 = K3 ^ _T1(K0 ^ K1 ^ K2 ^ _CK[i+3])
        rkey[i+3] = K3

class SM4:
    def __init__(self, key: bytes):
        self._rkey = [0]*32
        _key_expand(key, self._rkey)
    def encrypt(self, block: bytes) -> bytes:
        RK = self._rkey
        X0 = int.from_bytes(block[0:4], "big")
        X1 = int.from_bytes(block[4:8], "big")
        X2 = int.from_bytes(block[8:12], "big")
        X3 = int.from_bytes(block[12:16], "big")
        for i in range(0, 32, 4):
            X0 = X0 ^ _T0(X1 ^ X2 ^ X3 ^ RK[i])
            X1 = X1 ^ _T0(X2 ^ X3 ^ X0 ^ RK[i+1])
            X2 = X2 ^ _T0(X3 ^ X0 ^ X1 ^ RK[i+2])
            X3 = X3 ^ _T0(X0 ^ X1 ^ X2 ^ RK[i+3])
        return (X3.to_bytes(4, "big") + X2.to_bytes(4, "big") +
                X1.to_bytes(4, "big") + X0.to_bytes(4, "big"))
    def decrypt(self, block: bytes) -> bytes:
        RK = self._rkey
        X0 = int.from_bytes(block[0:4], "big")
        X1 = int.from_bytes(block[4:8], "big")
        X2 = int.from_bytes(block[8:12], "big")
        X3 = int.from_bytes(block[12:16], "big")
        for i in range(0, 32, 4):
            X0 = X0 ^ _T0(X1 ^ X2 ^ X3 ^ RK[31-i])
            X1 = X1 ^ _T0(X2 ^ X3 ^ X0 ^ RK[30-i])
            X2 = X2 ^ _T0(X3 ^ X0 ^ X1 ^ RK[29-i])
            X3 = X3 ^ _T0(X0 ^ X1 ^ X2 ^ RK[28-i])
        return (X3.to_bytes(4, "big") + X2.to_bytes(4, "big") +
                X1.to_bytes(4, "big") + X0.to_bytes(4, "big"))

class Misc:
    @staticmethod
    def pad_to_n(data: bytes, n: int) -> bytes:
        padding = n - (len(data) % n)
        if padding == n: return data
        return data + b'\x00' * padding
    @staticmethod
    def align_up(x: int, n: int) -> int:
        return ((x + n - 1) // n) * n

class Reader_pak:
    def __init__(self, buffer, cursor=0):
        self._buffer = buffer
        self._cursor = cursor
    def u1(self, move_cursor=True) -> int:
        return self.unpack('B', move_cursor=move_cursor)[0]
    def u4(self, move_cursor=True) -> int:
        return self.unpack('<I', move_cursor=move_cursor)[0]
    def u8(self, move_cursor=True) -> int:
        return self.unpack('<Q', move_cursor=move_cursor)[0]
    def i1(self, move_cursor=True) -> int:
        return self.unpack('b', move_cursor=move_cursor)[0]
    def i4(self, move_cursor=True) -> int:
        return self.unpack('<i', move_cursor=move_cursor)[0]
    def i8(self, move_cursor=True) -> int:
        return self.unpack('<q', move_cursor=move_cursor)[0]
    def s(self, n: int, move_cursor=True) -> bytes:
        return self.unpack(f'{n}s', move_cursor=move_cursor)[0]
    def unpack(self, f: str | bytes, offset=0, move_cursor=True):
        x = struct.unpack_from(f, self._buffer, self._cursor + offset)
        if move_cursor:
            self._cursor += struct.calcsize(f)
        return x
    def string(self, move_cursor=True) -> str:
        length = self.i4(move_cursor=move_cursor)
        if length == 0: return str()
        offset = 0 if move_cursor else 4
        return self.unpack(f'{length}s', offset=offset, move_cursor=move_cursor)[0].rstrip(b'\x00').decode()

class PakInfo:
    def __init__(self, buffer, keystream: list[int]):
        def decrypt_index_encrypted(x: int) -> int:
            return (x ^ keystream[3]) & 0xFF
        def decrypt_magic(x: int) -> int:
            return x ^ keystream[2]
        def decrypt_index_hash(x: bytes) -> bytes:
            key = struct.pack('<5I', *keystream[4:][:5])
            return bytes(a ^ b for a,b in zip(x, key))
        def decrypt_index_size(x: int) -> int:
            return x ^ ((keystream[10] << 32) | keystream[11])
        def decrypt_index_offset(x: int) -> int:
            return x ^ ((keystream[0] << 32) | keystream[1])
        reader = Reader_pak(buffer[-PakInfo._mem_size(-1):])
        self.index_encrypted = decrypt_index_encrypted(reader.u1()) == 1
        self.magic = decrypt_magic(reader.u4())
        self.version = reader.u4()
        self.index_hash = decrypt_index_hash(reader.s(20)) if self.version >= 6 else bytes()
        self.index_size = decrypt_index_size(reader.u8())
        self.index_offset = decrypt_index_offset(reader.u8())
        if self.version <= 3:
            self.index_encrypted = False
    @staticmethod
    def _mem_size(_: int) -> int:
        return 1 + 4 + 4 + 20 + 8 + 8

class TencentPakInfo(PakInfo):
    def __init__(self, buffer, keystream: list[int]):
        def decrypt_unk(x: bytes) -> bytes:
            key = struct.pack('<8I', *keystream[7:][:8])
            return bytes(a ^ b for a,b in zip(x, key))
        def decrypt_stem_hash(x: int) -> int:
            return x ^ keystream[8]
        def decrypt_unk_hash(x: int) -> int:
            return x ^ keystream[9]
        super().__init__(buffer, keystream)
        footer_size = TencentPakInfo._mem_size(self.version)
        reader = Reader_pak(buffer[-footer_size:])
        self.unk1 = decrypt_unk(reader.s(32)) if self.version >= 7 else bytes()
        self.packed_key = reader.s(256) if self.version >= 8 else bytes()
        self.packed_iv = reader.s(256) if self.version >= 8 else bytes()
        self.packed_index_hash = reader.s(256) if self.version >= 8 else bytes()
        self.stem_hash = decrypt_stem_hash(reader.u4()) if self.version >= 9 else 0
        self.unk2 = decrypt_unk_hash(reader.u4()) if self.version >= 9 else 0
        self.content_org_hash = reader.s(20) if self.version >= 12 else bytes()
    @staticmethod
    def _mem_size(version: int) -> int:
        size_for_7 = 32 if version >= 7 else 0
        size_for_8 = 256*3 if version >= 8 else 0
        size_for_9 = 4*2 if version >= 9 else 0
        size_for_12 = 20 if version >= 12 else 0
        return PakInfo._mem_size(version) + size_for_7 + size_for_8 + size_for_9 + size_for_12

class PakCompressedBlock:
    def __init__(self, reader: Reader_pak):
        self.start = reader.u8()
        self.end = reader.u8()

@dataclass
class TencentPakEntry:
    def __init__(self, reader: Reader_pak, version: int):
        self.content_hash = reader.s(20)
        if version <= 1:
            _ = reader.u8()
        self.offset = reader.u8()
        self.uncompressed_size = reader.u8()
        self.compression_method = reader.u4() & CM_MASK
        self.size = reader.u8()
        self.unk1 = reader.u1() if version >= 5 else 0
        self.unk2 = reader.s(20) if version >= 5 else bytes()
        block_count = 0
        if self.compression_method != 0 and version >= 3:
            block_count = reader.u4()
            if block_count > 10000: block_count = 0
            self.compressed_blocks = [PakCompressedBlock(reader) for _ in range(block_count)]
        else:
            self.compressed_blocks = []
        self.compression_block_size = reader.u4() if version >= 4 else 0
        self.encrypted = reader.u1() == 1 if version >= 4 else False
        self.encryption_method = reader.u4() if version >= 12 else 0
        self.unk3 = reader.u4() if version >= 14 else 0

class PakCrypto:
    class _LCG:
        def __init__(self, seed: int): self.state = seed
        def next(self) -> int:
            MASK_32 = 0xFFFFFFFF
            MSB_1 = 1 << 31
            def wrap(x: int) -> int:
                x &= MASK_32
                if not x & MSB_1: return x
                else: return ((x + MSB_1) & MASK_32) - MSB_1
            x1 = wrap(0x41C64E6D * self.state)
            self.state = wrap(x1 + 12345)
            x2 = wrap(x1 + 0x13038) if self.state < 0 else self.state
            return ((x2 >> 16) & MASK_32) % 0x7FFF
    @staticmethod
    def zuc_keystream() -> list[int]:
        zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)
        return [struct.unpack('>I', zuc.generate())[0] for _ in range(16)]
    @staticmethod
    def _xorxor(buffer, x) -> bytes:
        return bytes(buffer[i] ^ x[i % len(x)] for i in range(len(buffer)))
    @staticmethod
    def _hashhash(buffer, n: int) -> bytes:
        result = bytes()
        for i in range(math.ceil(n / SHA1.digest_size)):
            result += SHA1.new(buffer).digest()
        if len(result) >= n: result = result[:n]
        else: result += b'\x00' * (n - len(result))
        return result
    @staticmethod
    def _meowmeow(buffer) -> bytes:
        def unpad(x):
            skip = 1 + next((i for i in range(len(x)) if x[i] != 0))
            return x[skip:]
        if len(buffer) < 43: return bytes()
        x1 = buffer[1:][:SHA1.digest_size]
        x2 = buffer[SHA1.digest_size + 1:]
        x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))
        x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))
        part1, m = (x2[:SHA1.digest_size], x2[SHA1.digest_size:])
        if part1 != SHA1.new(b'\x00' * SHA1.digest_size).digest():
            return bytes()
        return unpad(m)
    @staticmethod
    def rsa_extract(signature: bytes, modulus: bytes) -> bytes:
        c = int.from_bytes(signature, 'little')
        n = int.from_bytes(modulus, 'little')
        e = 0x10001
        m = pow(c, e, n).to_bytes(256, 'little').rstrip(b'\x00')
        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))
    @staticmethod
    def _encrypt_simple1(plaintext) -> bytes:
        return bytes(x ^ SIMPLE1_DECRYPT_KEY for x in plaintext)
    @staticmethod
    def _decrypt_simple1(ciphertext) -> bytes:
        return bytes(x ^ SIMPLE1_DECRYPT_KEY for x in ciphertext)
    @staticmethod
    def _encrypt_simple2(plaintext) -> bytes:
        class RollingKey:
            def __init__(self, iv): self._value = iv
            def update(self, x): orig = self._value; self._value = x; return orig ^ x
        assert len(plaintext) % SIMPLE2_BLOCK_SIZE == 0
        initial_key = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)[0]
        rk = RollingKey(initial_key)
        ciphertext = (struct.pack('<I', rk.update(x)) for x in struct.unpack(f'<{len(plaintext)//4}I', plaintext))
        return bytes(it.chain.from_iterable(ciphertext))
    @staticmethod
    def _decrypt_simple2(ciphertext) -> bytes:
        class RollingKey:
            def __init__(self, iv): self._value = iv
            def update(self, x): self._value ^= x; return self._value
        assert len(ciphertext) % SIMPLE2_BLOCK_SIZE == 0
        initial_key = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)[0]
        rk = RollingKey(initial_key)
        plaintext = (struct.pack('<I', rk.update(x)) for x in struct.unpack(f'<{len(ciphertext)//4}I', ciphertext))
        return bytes(it.chain.from_iterable(plaintext))
    @staticmethod
    @lru_cache(maxsize=1)
    def _derive_sm4_key(file_path: PurePath, encryption_method: int) -> bytes:
        part1 = file_path.stem.lower()
        if encryption_method == EM_SM4_2: secret = SM4_SECRET_2
        elif encryption_method == EM_SM4_4: secret = SM4_SECRET_4
        else:
            index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
            secret = f'{SM4_SECRET_NEW[index]}{encryption_method}'
        return SHA1.new(str(part1 + secret).encode()).digest()[:16]
    @staticmethod
    @lru_cache(maxsize=1)
    def _sm4_context_for_key(key: bytes) -> SM4:
        return SM4(key)
    @staticmethod
    def _encrypt_sm4(plaintext, file_path: PurePath, encryption_method: int) -> bytes:
        padded = pad(plaintext, 16)
        key = PakCrypto._derive_sm4_key(file_path, encryption_method)
        sm4 = PakCrypto._sm4_context_for_key(key)
        return b''.join(sm4.encrypt(padded[i:i+16]) for i in range(0, len(padded), 16))
    @staticmethod
    def _decrypt_sm4(ciphertext, file_path: PurePath, encryption_method: int) -> bytes:
        assert len(ciphertext) % 16 == 0
        key = PakCrypto._derive_sm4_key(file_path, encryption_method)
        sm4 = PakCrypto._sm4_context_for_key(key)
        return b''.join(sm4.decrypt(ciphertext[i:i+16]) for i in range(0, len(ciphertext), 16))
    @staticmethod
    def decrypt_index(ciphertext, pak_info: TencentPakInfo) -> bytes:
        if pak_info.version > 7:
            key = PakCrypto.rsa_extract(pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_info.packed_iv, RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            aes = AES.new(key, MODE_CBC, iv[:16])
            return unpad(aes.decrypt(ciphertext), AES.block_size)
        else:
            return bytes(PakCrypto._decrypt_simple1(ciphertext))
    @staticmethod
    def _is_simple1_method(m): return m == EM_SIMPLE1
    @staticmethod
    def _is_simple2_method(m): return m == EM_SIMPLE2
    @staticmethod
    def _is_sm4_method(m): return m == EM_SM4_2 or m == EM_SM4_4 or (m & EM_SM4_NEW_MASK != 0)
    @staticmethod
    def _is_unknown_17_method(m): return m == EM_UNKNOWN_17
    @staticmethod
    def align_encrypted_content_size(n: int, method: int) -> int:
        if PakCrypto._is_simple2_method(method): return Misc.align_up(n, SIMPLE2_BLOCK_SIZE)
        elif PakCrypto._is_sm4_method(method): return Misc.align_up(n, 16)
        else: return n
    @staticmethod
    def encrypt_block(plaintext, file: PurePath, method: int) -> bytes:
        if PakCrypto._is_simple1_method(method): return PakCrypto._encrypt_simple1(plaintext)
        elif PakCrypto._is_simple2_method(method): return PakCrypto._encrypt_simple2(pad(plaintext, SIMPLE2_BLOCK_SIZE))
        elif PakCrypto._is_sm4_method(method): return PakCrypto._encrypt_sm4(plaintext, file, method)
        elif PakCrypto._is_unknown_17_method(method): return plaintext
        else:
            if method == 0: return plaintext
            assert False, f"Unknown encryption method: {method}"
    @staticmethod
    def decrypt_block(ciphertext, file: PurePath, method: int) -> bytes:
        if PakCrypto._is_simple1_method(method): return PakCrypto._decrypt_simple1(ciphertext)
        elif PakCrypto._is_simple2_method(method): return PakCrypto._decrypt_simple2(ciphertext)
        elif PakCrypto._is_sm4_method(method): return PakCrypto._decrypt_sm4(ciphertext, file, method)
        elif PakCrypto._is_unknown_17_method(method): return ciphertext
        else:
            if method == 0: return ciphertext
            assert False, f"Unknown encryption method: {method}"
    @staticmethod
    @lru_cache(maxsize=33)
    def generate_block_indices(n: int, method: int) -> list[int]:
        if not PakCrypto._is_sm4_method(method): return list(range(n))
        perm = []
        lcg = PakCrypto._LCG(n)
        while len(perm) != n:
            x = lcg.next() % n
            if x not in perm: perm.append(x)
        inv = [0]*len(perm)
        for i,x in enumerate(perm): inv[x] = i
        return inv

class PakCompression:
    @staticmethod
    @lru_cache(maxsize=33)
    def _zstd_decompressor(dict_data: bytes | None) -> ZstdDecompressor:
        dict_obj = ZstdCompressionDict(dict_data, DICT_TYPE_AUTO) if dict_data else None
        return ZstdDecompressor(dict_obj)
    @staticmethod
    @lru_cache(maxsize=128)
    def _zstd_compressor(dict_data: bytes | None, level: int) -> ZstdCompressor:
        dict_obj = ZstdCompressionDict(dict_data, DICT_TYPE_AUTO) if dict_data else None
        return ZstdCompressor(level=level, dict_data=dict_obj)
    @staticmethod
    def decompress_block(block, dict_data: bytes | None, method: int) -> bytes:
        if method == CM_ZLIB: return zlib.decompress(block)
        elif method in (CM_ZSTD, CM_ZSTD_DICT):
            if method != CM_ZSTD_DICT: dict_data = None
            return PakCompression._zstd_decompressor(dict_data).decompress(block)
        else: return block  # Return as-is for unknown methods
    @staticmethod
    def compress_block(block, dict_data: bytes | None, method: int, level: int | None = None) -> bytes:
        if method == CM_ZLIB:
            use_level = level if level is not None else 9
            return zlib.compress(block, level=use_level)
        elif method in (CM_ZSTD, CM_ZSTD_DICT):
            use_level = level if level is not None else 22
            if method != CM_ZSTD_DICT: dict_data = None
            return PakCompression._zstd_compressor(dict_data, use_level).compress(block)
        else: return block

class TencentPakFile:
    def __init__(self, file_path: PurePath, is_od=False):
        self._file_path = file_path
        with open(file_path, 'rb') as f:
            self._file_content = memoryview(f.read())
        self._is_od = is_od
        self._mount_point = PurePath()
        self._is_zstd_with_dict = 'zsdic' in str(self._file_path)
        self._zstd_dict = None
        self._files = []
        self._index = {}
        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())
        self._verify_stem_hash()
        self._tencent_load_index()

    def _verify_stem_hash(self):
        if not self._is_od and self._pak_info.version >= 9:
            assert self._pak_info.stem_hash == zlib.crc32(self._file_path.stem.encode('utf-32le'))

    def _tencent_load_index(self):
        index_data = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        if self._pak_info.index_encrypted:
            index_data = PakCrypto.decrypt_index(index_data, self._pak_info)
        self._verify_index_hash(index_data)
        self._load_index(index_data)

    def _verify_index_hash(self, index_data):
        expected = self._pak_info.index_hash
        if not self._is_od and self._pak_info.version >= 8:
            assert expected == PakCrypto.rsa_extract(self._pak_info.packed_index_hash, RSA_MOD_2)
        assert expected == SHA1.new(index_data).digest()

    @staticmethod
    def _construct_mount_point(mount_point: str) -> PurePath:
        res = PurePath()
        for part in PurePath(mount_point).parts:
            if part != '..': res /= part
        return res

    def _peek_content(self, offset: int, size: int, method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(size, method)
        return self._file_content[offset:][:size]

    def _peek_block_content(self, block: PakCompressedBlock, method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(block.end - block.start, method)
        return self._file_content[block.start:][:size]

    def _construct_zstd_dict(self, dict_entry: TencentPakEntry):
        assert not self._zstd_dict
        assert not dict_entry.encrypted
        assert dict_entry.compression_method == CM_NONE
        reader = Reader_pak(self._peek_content(dict_entry.offset, dict_entry.size, 0))
        dict_size = reader.u8()
        _ = reader.u4()
        assert dict_size == reader.u4()
        dict_data = reader.s(dict_size)
        self._zstd_dict = dict_data

    def _load_index(self, index_data):
        reader = Reader_pak(index_data)
        self._mount_point = self._construct_mount_point(reader.string())
        self._files = [TencentPakEntry(reader, self._pak_info.version) for _ in range(reader.u4())]
        try:
            num_dirs = reader.u8()
            for _ in range(num_dirs):
                dir_path = PurePath(reader.string())
                num_files = reader.u8()
                e = {reader.string(): self._files[~reader.i4()] for _ in range(num_files)}
                if self._is_zstd_with_dict and dir_path.name == 'zstddic':
                    assert len(e) == 1
                    self._construct_zstd_dict(e[[*e.keys()][0]])
                    continue
                self._index.update({PurePath(dir_path): e})
        except struct.error:
            pass

    def _write_to_disk(self, file_path: Path, entry: TencentPakEntry):
        if PakCrypto._is_unknown_17_method(entry.encryption_method): return
        try:
            with open(file_path, 'wb') as f:
                if entry.compression_method == CM_NONE:
                    data = self._peek_content(entry.offset, entry.size, entry.encryption_method)
                    if entry.encrypted:
                        data = PakCrypto.decrypt_block(bytes(data), PurePath(file_path), entry.encryption_method)
                    f.write(data)
                    return
                dec_data = bytearray()
                for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), entry.encryption_method):
                    data = self._peek_block_content(entry.compressed_blocks[x], entry.encryption_method)
                    if entry.encrypted:
                        data = PakCrypto.decrypt_block(bytes(data), PurePath(file_path), entry.encryption_method)
                    if not data: continue
                    dec_data.extend(PakCompression.decompress_block(bytes(data), self._zstd_dict, entry.compression_method))
                f.write(dec_data[:entry.uncompressed_size])
        except Exception as e:
            console.print(f"[yellow]Error extracting {file_path.name}: {e}[/yellow]")

    def dump_lua_only(self, out_path: Path):
        out_path.mkdir(parents=True, exist_ok=True)
        lua_count = 0
        for dir_path, dir_content in self._index.items():
            for file_name, entry in dir_content.items():
                if file_name.lower().endswith('.lua'):
                    target = out_path / file_name
                    self._write_to_disk(target, entry)
                    lua_count += 1
        if lua_count == 0:
            console.print(Panel("[yellow]No .lua files found in this PAK.[/yellow]", title="No Results", style="yellow"))
        else:
            console.print(Panel(f"[green]Extracted {lua_count} .lua file(s) to {out_path}[/green]", title="Unpack Complete", style="green"))

    def get_index_path_map(self):
        path_map = {}
        for dir_path, dir_content in self._index.items():
            for file_name in dir_content.keys():
                full_path = (dir_path / file_name).as_posix()
                path_map[file_name] = full_path
        return path_map

    def extract_all_files(self, output_dir: Path) -> dict:
        output_dir.mkdir(parents=True, exist_ok=True)
        extracted_files = {}
        
        for dir_path, dir_content in self._index.items():
            for file_name, entry in dir_content.items():
                if PakCrypto._is_unknown_17_method(entry.encryption_method):
                    continue
                rel_path = (dir_path / file_name).as_posix()
                target_path = output_dir / rel_path
                target_path.parent.mkdir(parents=True, exist_ok=True)
                
                try:
                    if entry.compression_method == CM_NONE:
                        data = self._peek_content(entry.offset, entry.size, entry.encryption_method)
                        if entry.encrypted:
                            data = PakCrypto.decrypt_block(bytes(data), PurePath(file_name), entry.encryption_method)
                        with open(target_path, 'wb') as f:
                            f.write(data)
                    else:
                        dec_data = bytearray()
                        for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), entry.encryption_method):
                            block_data = self._peek_block_content(entry.compressed_blocks[x], entry.encryption_method)
                            if entry.encrypted:
                                block_data = PakCrypto.decrypt_block(bytes(block_data), PurePath(file_name), entry.encryption_method)
                            if not block_data:
                                continue
                            dec_data.extend(PakCompression.decompress_block(bytes(block_data), self._zstd_dict, entry.compression_method))
                        with open(target_path, 'wb') as f:
                            f.write(dec_data[:entry.uncompressed_size])
                    extracted_files[rel_path] = entry
                except Exception as e:
                    console.print(f"[yellow]Warning: Could not extract {rel_path}: {e}[/yellow]")
        
        return extracted_files

    def _build_pak(self, files_to_pack: List[Tuple[str, Path]], output_path: Path):
        PAK_MAGIC = 0x9E2A83C1
        
        keystream = PakCrypto.zuc_keystream()
        
        file_entries = []
        current_offset = 0
        
        header_size = TencentPakInfo._mem_size(self._pak_info.version)
        current_offset = header_size
        
        console.print(f"[yellow]Packing {len(files_to_pack)} files...[/yellow]")
        
        for rel_path, full_path in files_to_pack:
            try:
                with open(full_path, 'rb') as f:
                    file_data = f.read()
            except Exception as e:
                console.print(f"[yellow]Warning: Could not read {full_path}: {e}[/yellow]")
                continue
            
            is_lua = rel_path.lower().endswith('.lua')
            
            if is_lua and len(file_data) > 100:
                comp_method = CM_ZSTD_DICT if self._zstd_dict else CM_ZSTD
                try:
                    compressed = PakCompression.compress_block(file_data, self._zstd_dict, comp_method, level=22)
                    if len(compressed) >= len(file_data) * 0.9:
                        compressed = file_data
                        comp_method = CM_NONE
                except Exception as e:
                    console.print(f"[yellow]Compression failed for {rel_path}, using uncompressed[/yellow]")
                    compressed = file_data
                    comp_method = CM_NONE
            else:
                compressed = file_data
                comp_method = CM_NONE
            
            padding = (16 - (len(compressed) % 16)) % 16
            if padding:
                compressed += b'\x00' * padding
            
            file_entries.append({
                'path': rel_path,
                'full_path': full_path,
                'data': compressed,
                'original_size': len(file_data),
                'compressed_size': len(compressed),
                'comp_method': comp_method,
                'offset': current_offset
            })
            
            current_offset += len(compressed)
        
        # Build index data
        index_data = bytearray()
        
        mount_point = self._mount_point.as_posix()
        index_data.extend(struct.pack('<I', len(mount_point) + 1))
        index_data.extend(mount_point.encode('utf-8') + b'\x00')
        
        index_data.extend(struct.pack('<I', len(file_entries)))
        
        for entry in file_entries:
            try:
                with open(entry['full_path'], 'rb') as f_orig:
                    orig_data = f_orig.read()
            except:
                orig_data = entry['data']
            content_hash = SHA1.new(orig_data).digest()
            index_data.extend(content_hash)
            index_data.extend(struct.pack('<Q', entry['offset']))
            index_data.extend(struct.pack('<Q', entry['original_size']))
            index_data.extend(struct.pack('<I', entry['comp_method']))
            index_data.extend(struct.pack('<Q', entry['compressed_size']))
            index_data.extend(b'\x00')
            index_data.extend(b'\x00' * 20)
            
            if entry['comp_method'] != CM_NONE:
                index_data.extend(struct.pack('<I', 1))
                index_data.extend(struct.pack('<Q', entry['offset']))
                index_data.extend(struct.pack('<Q', entry['offset'] + entry['compressed_size']))
                index_data.extend(struct.pack('<I', 0x10000))
            else:
                index_data.extend(struct.pack('<I', 0))
            
            index_data.extend(b'\x00')
            index_data.extend(struct.pack('<I', 0))
            index_data.extend(struct.pack('<I', 0))
        
        dirs = {}
        for entry in file_entries:
            path = Path(entry['path'])
            parent = path.parent.as_posix()
            if parent not in dirs:
                dirs[parent] = []
            dirs[parent].append(path.name)
        
        index_data.extend(struct.pack('<Q', len(dirs)))
        for dir_path, files_list in dirs.items():
            index_data.extend(struct.pack('<I', len(dir_path) + 1))
            index_data.extend(dir_path.encode('utf-8') + b'\x00')
            index_data.extend(struct.pack('<Q', len(files_list)))
            for file_name in files_list:
                index_data.extend(struct.pack('<I', len(file_name) + 1))
                index_data.extend(file_name.encode('utf-8') + b'\x00')
                for i, entry in enumerate(file_entries):
                    if entry['path'] == f"{dir_path}/{file_name}":
                        index_data.extend(struct.pack('<i', -i - 1))
                        break
        
        while len(index_data) % 16 != 0:
            index_data.append(0)
        
        index_offset = current_offset
        index_size = len(index_data)
        
        with open(output_path, 'wb') as f:
            f.write(b'\x00' * header_size)
            
            for entry in file_entries:
                f.write(entry['data'])
            
            f.write(index_data)
            
            f.seek(0)
            
            f.write(b'\x00')
            magic = PAK_MAGIC ^ keystream[2]
            f.write(struct.pack('<I', magic))
            f.write(struct.pack('<I', self._pak_info.version))
            
            index_hash = SHA1.new(index_data).digest()
            key = struct.pack('<5I', *keystream[4:][:5])
            encrypted_hash = bytes(a ^ b for a, b in zip(index_hash, key))
            f.write(encrypted_hash)
            
            encrypted_size = index_size ^ ((keystream[10] << 32) | keystream[11])
            f.write(struct.pack('<Q', encrypted_size))
            
            encrypted_offset = index_offset ^ ((keystream[0] << 32) | keystream[1])
            f.write(struct.pack('<Q', encrypted_offset))
            
            if self._pak_info.version >= 7:
                f.write(b'\x00' * 32)
            if self._pak_info.version >= 8:
                f.write(b'\x00' * 256)
                f.write(b'\x00' * 256)
                f.write(b'\x00' * 256)
            if self._pak_info.version >= 9:
                f.write(b'\x00' * 4)
                f.write(b'\x00' * 4)
            if self._pak_info.version >= 12:
                f.write(b'\x00' * 20)
        
        console.print(f"[green]PAK written: {output_path} (size: {output_path.stat().st_size} bytes)[/green]")

    def rebuild_pak(self, source_dir: Path, output_path: Path, extracted_files: dict = None):
        if extracted_files is None:
            import tempfile
            temp_dir = Path(tempfile.mkdtemp())
            console.print(f"[yellow]Extracting all files to {temp_dir}...[/yellow]")
            extracted_files = self.extract_all_files(temp_dir)
            source_dir = temp_dir
        
        if not source_dir.exists():
            console.print(f"[red]Source directory {source_dir} does not exist![/red]")
            return False
        
        console.print("[yellow]Rebuilding PAK structure...[/yellow]")
        
        files_to_pack = []
        for root, _, files in os.walk(source_dir):
            root_path = Path(root)
            for file_name in files:
                full_path = root_path / file_name
                try:
                    rel_path = full_path.relative_to(source_dir).as_posix()
                    files_to_pack.append((rel_path, full_path))
                except ValueError:
                    files_to_pack.append((file_name, full_path))
        
        if not files_to_pack:
            console.print("[red]No files found to pack![/red]")
            return False
        
        self._build_pak(files_to_pack, output_path)
        
        if extracted_files is None:
            try:
                shutil.rmtree(source_dir)
            except:
                pass
        
        console.print(f"[green]PAK rebuilt successfully: {output_path}[/green]")
        return True

    def repack(self, source_dir: Path, target_pak: Path):
        import tempfile
        temp_extract_dir = Path(tempfile.mkdtemp())
        
        console.print(f"[yellow]Extracting all files from original PAK...[/yellow]")
        extracted_files = self.extract_all_files(temp_extract_dir)
        
        console.print(f"[yellow]Overlaying modified Lua files...[/yellow]")
        
        idx_map = self.get_index_path_map()
        
        for compiled_file in source_dir.glob("*.lua"):
            if compiled_file.name in idx_map:
                target_rel = idx_map[compiled_file.name]
                target_full = temp_extract_dir / target_rel
                target_full.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(compiled_file, target_full)
                console.print(f"[green]Updated: {compiled_file.name} -> {target_rel}[/green]")
        
        for root, _, files in os.walk(source_dir):
            root_path = Path(root)
            for file_name in files:
                if file_name.endswith('.lua'):
                    continue
                full_path = root_path / file_name
                try:
                    rel_from_src = full_path.relative_to(source_dir).as_posix()
                except ValueError:
                    continue
                
                for orig_path in extracted_files.keys():
                    if orig_path.endswith(file_name) or orig_path == rel_from_src:
                        target_full = temp_extract_dir / orig_path
                        target_full.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(full_path, target_full)
                        console.print(f"[green]Updated non-Lua: {orig_path}[/green]")
                        break
        
        console.print(f"[yellow]Rebuilding PAK...[/yellow]")
        result = self.rebuild_pak(temp_extract_dir, target_pak, extracted_files)
        
        shutil.rmtree(temp_extract_dir)
        
        return result

# ============================================================================
# MENU & UI UTILITIES
# ============================================================================

def display_lua_selection(folder_path: Path, title: str) -> List[Path]:
    files = [f for f in folder_path.iterdir() if f.is_file() and f.suffix == '.lua']
    if not files:
        console.print(Panel(f"❌ No .lua files found in '{folder_path}'", border_style="red"))
        return []
    table = Table(title=title, box=box.ROUNDED, header_style="bold yellow", show_lines=True)
    table.add_column("No.", style="bold green", width=6, justify="center")
    table.add_column("File Name", style="bold white", width=50)
    table.add_column("Size", style="green", width=12, justify="right")
    for i, f in enumerate(files, 1):
        sz = f.stat().st_size
        sz_str = f"{sz/1024:.1f} KB" if sz < 1048576 else f"{sz/(1024*1024):.2f} MB"
        table.add_row(str(i), f.name, sz_str)
    console.print(table)
    choice = Prompt.ask("\n  Enter numbers (comma-separated) or 'all'").strip().lower()
    if choice == 'all':
        return files
    try:
        indices = [int(p.strip())-1 for p in choice.split(',') if p.strip()]
        return [files[i] for i in indices if 0 <= i < len(files)]
    except:
        console.print("  ❌ Invalid input.", style="red")
        return []

def display_pak_files() -> List[Path]:
    paks = list(ORIGINAL_PAK_DIR.glob("*.pak"))
    if not paks:
        console.print(Panel("❌ No PAK files found in ORIGINAL_PAK folder", border_style="red"))
        return []
    table = Table(title="Select PAK File", box=box.ROUNDED, header_style="bold yellow", show_lines=True)
    table.add_column("No.", style="bold green", width=6, justify="center")
    table.add_column("File Name", style="bold white", width=50)
    table.add_column("Size", style="green", width=12, justify="right")
    for i, p in enumerate(paks, 1):
        sz = p.stat().st_size / (1024*1024)
        table.add_row(str(i), p.name, f"{sz:.2f} MB")
    console.print(table)
    choice = Prompt.ask("Enter number").strip()
    try:
        idx = int(choice)-1
        if 0 <= idx < len(paks):
            return [paks[idx]]
        else:
            console.print("Invalid number.", style="red")
            return []
    except:
        console.print("Invalid input.", style="red")
        return []

# ============================================================================
# CORE OPERATIONS
# ============================================================================

def unpack_pak():
    paks = display_pak_files()
    if not paks:
        input("Press Enter to continue...")
        return
    pak_path = paks[0]
    out_dir = EXTRACTED_DIR / pak_path.stem
    console.print(Panel(f"Unpacking [bold]{pak_path.name}[/bold] to [bold]{out_dir}[/bold]", title="Unpack PAK", style="green"))
    try:
        pak = TencentPakFile(PurePath(pak_path))
        pak.dump_lua_only(out_dir)
    except Exception as e:
        console.print(Panel(f"Error: {e}", title="Error", style="red"))
        import traceback
        traceback.print_exc()
    input("Press Enter to continue...")

def decompile_lua():
    if not find_luadec():
        console.print(Panel("[red]luadec executable not found![/]\nPlace 'luadec' in EXES folder or install it and run chmod +x.", title="Error", style="red"))
        input("Press Enter to continue...")
        return
    files = display_lua_selection(ORIGINAL_LUA_DIR, "Select Lua bytecode files to decompile")
    if not files:
        input("Press Enter to continue...")
        return
    for src in files:
        out = SOURCE_LUA_DIR / src.name
        console.print(f"Decompiling {src.name} ...")
        ok, msg = intelligent_decompile_file(str(src), str(out))
        if ok:
            console.print(f"  ✅ {src.name} -> {out}")
        else:
            console.print(f"  ❌ {src.name}: {msg}")
    input("Press Enter to continue...")

def recompile_lua():
    if not ensure_luac53():
        console.print(Panel("[red]luac5.3 not found![/]\nInstall via 'pkg install lua5.3' or place 'luac5.3' in EXES folder.", title="Error", style="red"))
        input("Press Enter to continue...")
        return
    src_files = display_lua_selection(EDITED_LUA_DIR, "Select edited Lua files to recompile")
    if not src_files:
        input("Press Enter to continue...")
        return

    for src in src_files:
        original_bytecode_file = ORIGINAL_LUA_DIR / src.name
        if not original_bytecode_file.exists():
            console.print(f"  ❌ Original bytecode not found for {src.name} in {ORIGINAL_LUA_DIR}")
            continue

        decompiled_source = SOURCE_LUA_DIR / src.name
        if decompiled_source.exists():
            shutil.copy2(decompiled_source, src.with_suffix(".lua.orig"))

        out = COMPILED_LUA_DIR / src.name
        console.print(f"Recompiling {src.name} ...")
        ok, msg = compile_file(str(src), str(out), str(original_bytecode_file))
        if ok:
            console.print(f"  ✅ {src.name} -> {out}")
        else:
            console.print(f"  ❌ {src.name}: {msg}")
    input("Press Enter to continue...")

def repack_pak():
    paks = display_pak_files()
    if not paks:
        input("Press Enter to continue...")
        return
    pak_path = paks[0]
    out_pak = REPACKED_PAK_DIR / pak_path.name
    
    console.print(Panel(f"Repacking [bold]{pak_path.name}[/bold] using compiled Lua from [bold]{COMPILED_LUA_DIR}[/bold]", title="Repack PAK", style="green"))
    try:
        pak = TencentPakFile(PurePath(pak_path))
        
        import tempfile
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            
            console.print("[yellow]Extracting all files from original PAK...[/yellow]")
            extracted = pak.extract_all_files(tmp_path)
            
            idx_map = pak.get_index_path_map()
            console.print("[yellow]Overlaying compiled Lua files...[/yellow]")
            
            for compiled_file in COMPILED_LUA_DIR.glob("*.lua"):
                if compiled_file.name in idx_map:
                    target_rel = idx_map[compiled_file.name]
                    target_full = tmp_path / target_rel
                    target_full.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(compiled_file, target_full)
                    console.print(f"  Mapped {compiled_file.name} -> {target_rel}")
            
            console.print("[yellow]Rebuilding PAK...[/yellow]")
            pak.rebuild_pak(tmp_path, out_pak, extracted)
            
        console.print(Panel(f"Repacked PAK saved to {out_pak}", title="Success", style="green"))
    except Exception as e:
        console.print(Panel(f"Error: {e}", title="Error", style="red"))
        import traceback
        traceback.print_exc()
    input("Press Enter to continue...")

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    ensure_dirs()
    while True:
        clear_screen()
        console.clear()
        console.print(Panel.fit(Text("ALVSIA TOOL PREMIUM  \u00b7  @ALVSIA_PRO  \u00b7  @OriginalOnwerALV", style="bold cyan", justify="center"), border_style="green", padding=(1, 2)))
        table = Table(show_header=True, header_style="bold yellow", box=box.ROUNDED, title="📋 MAIN MENU", title_style="bold green", show_lines=True, border_style="green")
        table.add_column("No.", style="bold green", width=12, justify="center")
        table.add_column("Option", style="bold yellow", width=35)
        table.add_row("1", "UNPACK PAK (Extract Lua files)")
        table.add_row("2", "DECOMPILE LUA (Bytecode → Source)")
        table.add_row("3", "RECOMPILE LUA (Source → Bytecode)")
        table.add_row("4", "REPACK PAK (Inject compiled Lua)")
        table.add_row("0", "EXIT")
        console.print(table)
        console.print("[bold yellow]━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[/]")
        choice = Prompt.ask("  [bold green]PLEASE ENTER YOUR CHOICE[/]", choices=["0","1","2","3","4"])
        if choice == "0":
            console.print(Panel("Goodbye!", border_style="green"))
            sys.exit(0)
        elif choice == "1":
            unpack_pak()
        elif choice == "2":
            decompile_lua()
        elif choice == "3":
            recompile_lua()
        elif choice == "4":
            repack_pak()

if __name__ == "__main__":
    main()