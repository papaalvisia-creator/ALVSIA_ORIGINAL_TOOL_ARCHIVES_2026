# RJTOOL
import os, sys

try:
    import repak
except ImportError:
    sys.exit("pip install repak")

BASE = os.path.dirname(os.path.abspath(__file__))
D_IN, D_DEC, D_EDIT, D_OUT = (os.path.join(BASE, x) for x in ("01_输入_pak", "02_解密", "03_编辑", "04_重包"))


def ask(p, d=""):
    s = input(f"{p}" + (f" [{d}]" if d else "") + ": ").strip()
    return s or d


def paks(d):
    return sorted(os.path.join(r, f) for r, _, fs in os.walk(d) for f in fs if f.endswith(".pak"))


def unpack():
    ps = paks(D_IN)
    if not ps:
        return print(f"{D_IN} 里没有 .pak")
    for i, p in enumerate(ps, 1):
        print(f"  {i}. {os.path.basename(p)}")
    sel = ask("选择(1,3/a)", "1")
    pick = ps if sel == "a" else [ps[int(x) - 1] for x in sel.replace(" ", "").split(",") if x.isdigit()]
    for p in pick:
        r = repak.PakBuilder().reader(p)
        for e in r.entries():
            dst = os.path.join(D_DEC, (r.mount_point + e).replace("\\", "/").lstrip("./").replace("/", os.sep))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            open(dst, "wb").write(r.get(e))
        r.close()
        print(f"{os.path.basename(p)} -> {D_DEC}")


def repack():
    out = []
    for r, _, fs in os.walk(D_EDIT):
        for f in fs:
            full = os.path.join(r, f)
            rel = os.path.relpath(full, D_EDIT).replace(os.sep, "/")
            out.append((rel if rel.split("/")[0] in ("Nuts", "Engine") else "Nuts/Content/" + rel, full))
    if not out:
        return print(f"{D_EDIT} 为空")
    ins = paks(D_IN)
    default = os.path.basename(ins[0]) if len(ins) == 1 else "pakchunk99-WindowsNoEditor.pak"
    name = ask("输出名", default)
    name = name if name.endswith(".pak") else name + ".pak"
    os.makedirs(D_OUT, exist_ok=True)
    dst = os.path.join(D_OUT, name)
    w = repak.PakBuilder().writer(dst)
    for rel, full in out:
        w.write_file(rel, open(full, "rb").read())
    w.write_index()
    print(f"{len(out)} 文件 -> {dst}")


def main():
    for d in (D_IN, D_DEC, D_EDIT, D_OUT):
        os.makedirs(d, exist_ok=True)
    while True:
        print("\n[1]解包  [2]重包  [0]退出")
        c = ask("选择").lower()
        try:
            if c == "1":
                unpack()
            elif c == "2":
                repack()
            elif c in ("0", "q"):
                return
        except KeyboardInterrupt:
            print("\n已中断")
        except Exception as e:
            print(f"!! {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()