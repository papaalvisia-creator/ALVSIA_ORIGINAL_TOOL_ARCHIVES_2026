from __future__ import annotations
#!/usr/bin/env python3
# ALVSIA STUDIO — core PAK/LUA engine (reconstructed & repaired)

# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: 'studio.py'
# Bytecode version: 3.14rc3 (3627)
# Source timestamp: 1970-01-01 00:00:00 UTC (0)

global _FAST_SM4_TRIED
global _FAST_SM4_LIB
global _LUA_LUAC_PATH
import itertools as it
import colorsys
import random
import math
import struct
import shutil
import os
import sys
import tempfile
import uuid
import hashlib
import traceback
from collections import Counter
import platform
import subprocess
import requests
import base64
import zlib
import ctypes
import traceback
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from pathlib import PurePath, Path
from typing import List, Dict, Tuple, Optional, Any
import time
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn, TimeRemainingColumn
from rich.table import Table
from rich import print as rprint
from rich.markup import escape
from rich.text import Text
from rich.align import Align
from rich.console import Group
from rich.box import HEAVY_EDGE, ROUNDED, DOUBLE_EDGE
from datetime import datetime
import pytz
import gmalg
from Crypto.Cipher import AES
from Crypto.Cipher.AES import MODE_CBC
from Crypto.Hash import SHA1
from Crypto.Util.Padding import unpad, pad, pad
from zstandard import ZstdDecompressor, ZstdCompressionDict, DICT_TYPE_AUTO, ZstdCompressor
console = Console()
CREDIT = 'ALVSIA'
DARK_BLUE = '#0A1A2F'
DARK_SKY = '#2F5D8A'
DARK_SKY_LIGHT = '#6FA8DC'
DARK_RED = '#8B0000'
ACCENT = '#2F5D8A'
NEON = '#6FA8DC'
MUTED = '#5A6B7A'
WARN = '#C0392B'
# === Classes (recovered) ===
class MC:
    RESET = '[0m'
    BOLD = '[1m'
    DIM = '[2m'
    BLUE = '[38;2;0;60;140m'
    BLUE_B = '[38;2;30;100;200m'
    BLUE_G = '[38;2;0;90;200m'
    CYAN = '[38;2;0;110;110m'
    CYAN_B = '[38;2;0;180;180m'
    CYAN_G = '[38;2;0;220;220m'
    YELLOW = '[38;2;160;130;0m'
    YELLOW_B = '[38;2;230;190;0m'
    YELLOW_G = '[38;2;255;230;0m'
    RED = '[38;2;140;0;0m'
    RED_B = '[38;2;220;30;30m'
    RED_G = '[38;2;255;60;60m'
    WHITE = '[38;2;255;255;255m'
    GRAY = '[38;2;140;140;140m'
    GREEN = '[38;2;0;200;80m'
    MAGENTA = '[38;2;200;0;200m'
    ORANGE = '[38;2;255;140;0m'


class C:
    R, G, Y, B, M, CY, W, D, BD, RS = ('[91m', '[92m', '[93m', '[94m', '[95m', '[96m', '[97m', '[90m', '[1m', '[0m')


class SM4:
    _S_BOX = [
        52,102,37,116,137,120,228,169,90,65,188,122,214,22,33,35,
        77,97,218,148,155,223,19,60,105,58,49,10,95,215,153,149,
        241,174,114,61,7,96,36,182,152,238,196,162,45,136,221,141,
        4,234,187,17,202,62,93,161,246,63,176,151,128,71,43,166,
        230,247,217,177,89,192,124,190,84,40,183,126,79,248,67,110,
        160,80,14,245,144,184,251,163,123,98,25,70,3,42,185,143,
        159,119,180,91,131,135,8,235,226,30,66,240,15,232,113,106,
        117,173,85,31,181,171,51,250,127,21,189,133,216,6,104,179,
        82,48,72,11,0,237,239,178,87,142,231,108,213,229,46,83,
        130,5,249,129,244,86,191,140,75,227,219,74,145,76,44,211,
        64,41,78,32,20,54,121,9,111,209,55,224,57,12,138,146,
        56,18,53,109,225,253,147,154,23,212,201,156,107,132,38,157,
        175,118,193,158,208,150,197,203,233,115,73,210,205,100,195,199,
        1,125,243,172,252,222,164,68,50,27,194,186,28,2,198,39,
        69,139,242,24,167,16,81,29,200,207,99,255,47,13,88,206,
        101,165,220,26,59,134,254,34,92,168,94,103,170,236,112,204,
    ]
    _FK = [1184304796, 1270900830, 1493524870, 3164752158]
    _CK = [964907, 973793155, 2654690407, 2916866751, 2071233739, 1226140771, 3348805095, 2045549823, 388349611, 800627875, 612403927, 3721562911, 1195432523, 3150178931, 612053223, 2445162591, 67183755, 1174197155, 1393249511, 3331183455, 3822152747, 1332317203, 1804781383, 1990130463, 1282653851, 3376591251, 2910902311, 925872959, 332098219, 735840931, 396665415, 3588844719]
    @staticmethod
    def ROL32(x, n):
        return x << n & 4294967295 | x >> 32 - n
    @staticmethod
    def _BS(X):
        return SM4._S_BOX[X >> 24 & 255] << 24 | SM4._S_BOX[X >> 16 & 255] << 16 | SM4._S_BOX[X >> 8 & 255] << 8 | SM4._S_BOX[X & 255]
    @staticmethod
    def _T0(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 2) ^ SM4.ROL32(X, 10) ^ SM4.ROL32(X, 18) ^ SM4.ROL32(X, 24)
    @staticmethod
    def _T1(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 13) ^ SM4.ROL32(X, 23)
    @staticmethod
    def _key_expand(key: bytes, rkey: list):
        K0 = int.from_bytes(key[0:4], 'big') ^ SM4._FK[0]
        K1 = int.from_bytes(key[4:8], 'big') ^ SM4._FK[1]
        K2 = int.from_bytes(key[8:12], 'big') ^ SM4._FK[2]
        K3 = int.from_bytes(key[12:16], 'big') ^ SM4._FK[3]
        for i in range(0, 32, 4):
            K0 = K0 ^ SM4._T1(K1 ^ K2 ^ K3 ^ SM4._CK[i])
            rkey[i] = K0
            K1 = K1 ^ SM4._T1(K2 ^ K3 ^ K0 ^ SM4._CK[i + 1])
            rkey[i + 1] = K1
            K2 = K2 ^ SM4._T1(K3 ^ K0 ^ K1 ^ SM4._CK[i + 2])
            rkey[i + 2] = K2
            K3 = K3 ^ SM4._T1(K0 ^ K1 ^ K2 ^ SM4._CK[i + 3])
            rkey[i + 3] = K3
    @classmethod
    def key_length(cls):
        return 16
    @classmethod
    def block_length(cls):
        return 16
    def __init__(self, key: bytes):
        if len(key) != self.key_length():
            raise ValueError(f'Key must be {self.key_length()} bytes')
        else:
            self._key = key
            self._rkey = [0] * 32
            SM4._key_expand(self._key, self._rkey)
            self._block_buffer = bytearray()
            if not hasattr(SM4, '_T_TABLES'):
                SM4._T_TABLES = SM4._make_t_tables()
    def encrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[i + 1])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[i + 2])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[i + 3])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)
    def decrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[31 - i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[30 - i])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[29 - i])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[28 - i])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)
    @classmethod
    def _make_t_tables(cls):
        S = cls._S_BOX
        def rol(x, n):
            return x << n & 4294967295 | x >> 32 - n
        def L(y):
            return y ^ rol(y, 2) ^ rol(y, 10) ^ rol(y, 18) ^ rol(y, 24)
        T0 = [0] * 256
        T1 = [0] * 256
        T2 = [0] * 256
        T3 = [0] * 256
        for i in range(256):
            s = S[i]
            T0[i] = L(s << 24)
            T1[i] = L(s << 16)
            T2[i] = L(s << 8)
            T3[i] = L(s)
        return (T0, T1, T2, T3)
    def _bulk(self, data: bytes, rk) -> bytes:
        n = len(data)
        out = bytearray(n)
        T0, T1, T2, T3 = self._T_TABLES
        unpack_from = struct.unpack_from
        pack_into = struct.pack_into
        idx = 0
        while idx < n:
            X0, X1, X2, X3 = unpack_from('>IIII', data, idx)
            for i in range(0, 32, 4):
                t = X1 ^ X2 ^ X3 ^ rk[i]
                X0 ^= T0[t >> 24] ^ T1[t >> 16 & 255] ^ T2[t >> 8 & 255] ^ T3[t & 255]
                t = X2 ^ X3 ^ X0 ^ rk[i + 1]
                X1 ^= T0[t >> 24] ^ T1[t >> 16 & 255] ^ T2[t >> 8 & 255] ^ T3[t & 255]
                t = X3 ^ X0 ^ X1 ^ rk[i + 2]
                X2 ^= T0[t >> 24] ^ T1[t >> 16 & 255] ^ T2[t >> 8 & 255] ^ T3[t & 255]
                t = X0 ^ X1 ^ X2 ^ rk[i + 3]
                X3 ^= T0[t >> 24] ^ T1[t >> 16 & 255] ^ T2[t >> 8 & 255] ^ T3[t & 255]
            pack_into('>IIII', out, idx, X3, X2, X1, X0)
            idx += 16
        return bytes(out)
    def encrypt_bulk(self, data: bytes) -> bytes:
        return self._bulk(data, self._rkey)
    def decrypt_bulk(self, data: bytes) -> bytes:
        return self._bulk(data, self._rkey[::(-1)])
_FAST_SM4_LIB = None
_FAST_SM4_TRIED = False



# === Missing base classes ===
class PakInfo:
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_index_encrypted(x: int) -> int:
            MASK_8 = 255
            return (x ^ keystream[3]) & MASK_8
        def decrypt_magic(x: int) -> int:
            return x ^ keystream[2]
        def decrypt_index_hash(x: bytes) -> bytes:
            key = struct.pack('<5I', *keystream[4:][:5])
            assert len(x) == len(key)
            return bytes((a ^ b for a, b in zip(x, key)))
        def decrypt_index_size(x: int) -> int:
            return x ^ (keystream[10] << 32 | keystream[11])
        def decrypt_index_offset(x: int) -> int:
            return x ^ (keystream[0] << 32 | keystream[1])
        reader = Reader(buffer[-PakInfo._mem_size((-1)):])
        self.index_encrypted = decrypt_index_encrypted(reader.u1()) == 1
        self.magic = decrypt_magic(reader.u4())
        self.version = reader.u4()
        self.index_hash = decrypt_index_hash(reader.s(20)) if self.version >= 6 else bytes()
        self.index_size = decrypt_index_size(reader.u8())
        self.index_offset = decrypt_index_offset(reader.u8())
        if self.version <= 3:
            self.index_encrypted = False
    @staticmethod
    def _mem_size(_: int) -> int:
        return 45


class PakCompressedBlock:
    def __init__(self, reader: Reader):
        self.start = reader.u8()
        self.end = reader.u8()


class PakCompression:
    @staticmethod
    @lru_cache(maxsize=33)
    def _zstd_decompressor(dict: ZstdCompressionDict) -> ZstdDecompressor:
        return ZstdDecompressor(dict)
    @staticmethod
    def zstd_dictionary(dict_data) -> ZstdCompressionDict:
        return ZstdCompressionDict(dict_data, DICT_TYPE_AUTO)
    @staticmethod
    def decompress_block(block, dict: Optional[ZstdCompressionDict], compression_method: int) -> bytes:
        if compression_method == CM_ZLIB:
            try:
                return zlib.decompress(block)
            except zlib.error:
                return block
        else:
            if compression_method == CM_ZSTD or compression_method == CM_ZSTD_DICT:
                if compression_method != CM_ZSTD_DICT:
                    dict = None
                return PakCompression._zstd_decompressor(dict).decompress(block)
            else:
                raise ValueError(f'Unknown compression method: {compression_method}')


class Misc:
    @staticmethod
    def pad_to_n(data: bytes, n: int) -> bytes:
        assert n > 0
        padding = n - len(data) % n
        if padding == n:
            return data
    @staticmethod
    def align_up(x: int, n: int) -> int:
        return (x + n - 1) // n * n


class Reader:
    def __init__(self, buffer, cursor=0):
        self._buffer = buffer
        self._cursor = cursor
    def u1(self, move_cursor=True) -> int:
        return self.unpack('B', move_cursor=move_cursor)[0]
    def u4(self, move_cursor=True) -> int:
        return self.unpack('<I', move_cursor=move_cursor)[0]
    def u8(self, move_cursor=True) -> int:
        return self.unpack('<Q', move_cursor=move_cursor)[0]
    def i1(self, move_cursor=True) -> int:
        return self.unpack('b', move_cursor=move_cursor)[0]
    def i4(self, move_cursor=True) -> int:
        return self.unpack('<i', move_cursor=move_cursor)[0]
    def i8(self, move_cursor=True) -> int:
        return self.unpack('<q', move_cursor=move_cursor)[0]
    def s(self, n: int, move_cursor=True) -> bytes:
        return self.unpack(f'{n}s', move_cursor=move_cursor)[0]
    def unpack(self, f: str, offset=0, move_cursor=True):
        x = struct.unpack_from(f, self._buffer, self._cursor + offset)
        if move_cursor:
            self._cursor += struct.calcsize(f)
        return x
    def string(self, move_cursor=True) -> str:
        length = self.i4(move_cursor=move_cursor)
        if length == 0:
            return str()
        else:
            assert length > 0
            offset = 0 if move_cursor else 4
            return self.unpack(f'{length}s', offset=offset, move_cursor=move_cursor)[0].rstrip(b'\x00').decode()


class SimpleBlockDisplay:
    """Simple display that shows each file and its blocks"""
    def __init__(self, total_files: int, pak_name: str):
        self.total_files = total_files
        self.pak_name = pak_name
        self.processed_files = 0
        self.current_file = ''
        self.current_file_idx = 0
        self.all_blocks = []
        self.total_fitted = 0
        self.total_skipped = 0
    def start_file(self, file_name: str, total_blocks: int):
        self.current_file_idx += 1
        self.current_file = file_name
        self.current_blocks = []
        self.current_total_blocks = total_blocks
        self.current_fitted = 0
        self.current_skipped = 0
        console.print()
        console.print('[bold cyan]┌─────────────────────────────────────────────────────────────[/bold cyan]')
        console.print(f'[bold cyan]│[/] [bold yellow][{self.current_file_idx}/{self.total_files}][/] [bold green]{file_name}[/bold green] [dim]({total_blocks} blocks)[/dim]')
        console.print('[bold cyan]├─────────────────────────────────────────────────────────────[/bold cyan]')
    def add_block(self, block_idx: int, block_size: int, fitted: bool, compression_ratio: float=None):
        """Add a block result"""
        size_mb = block_size / 1048576
        if fitted:
            self.current_fitted += 1
            self.total_fitted += 1
            ratio_str = f' [{compression_ratio:.1%}]' if compression_ratio else ''
            status = f'[green]✓ FITTED{ratio_str}[/green]'
        else:
            self.current_skipped += 1
            self.total_skipped += 1
            status = '[red]✗ SKIPPED[/red]'
        console.print(f'[bold cyan]│[/]    Block {block_idx:3d}: {size_mb:>7.2f} MB  →  {status}')
        self.current_blocks.append({'fitted': fitted})
    def finish_file(self):
        """Finish current file"""
        total_blocks = len(self.current_blocks)
        if total_blocks > 0:
            if self.current_fitted == total_blocks:
                status = '[green]✓ ALL FITTED[/green]'
            else:
                if self.current_fitted > 0:
                    status = f'[yellow]✓ {self.current_fitted}/{total_blocks} FITTED[/yellow]'
                else:
                    status = '[red]✗ ALL SKIPPED[/red]'
        else:
            status = '[green]✓ DONE[/green]'
        console.print('[bold cyan]└─────────────────────────────────────────────────────────────[/bold cyan]')
        console.print(f'  [dim]Result: {status}[/dim]')
        self.processed_files += 1
        self.all_blocks.extend(self.current_blocks)
    def final_summary(self):
        """Print final summary"""
        total_blocks = len(self.all_blocks)
        console.print()
        console.print('[bold green]╔═════════════════════════════════════════════════════════════════╗[/bold green]')
        console.print('[bold green]║[/] [bold yellow]REPACK SUMMARY[/bold yellow]')
        console.print('[bold green]║[/]')
        console.print(f'[bold green]║[/]   Total Files:   [bold cyan]{self.processed_files}[/bold cyan]')
        console.print(f'[bold green]║[/]   Total Blocks:  [bold cyan]{total_blocks}[/bold cyan]')
        console.print(f'[bold green]║[/]   Fitted Blocks: [bold green]{self.total_fitted}[/bold green]')
        console.print(f'[bold green]║[/]   Skipped Blocks:[bold red]{self.total_skipped}[/bold red]')
        if total_blocks > 0:
            success_rate = self.total_fitted / total_blocks * 100
            console.print(f'[bold green]║[/]   Success Rate:  [bold yellow]{success_rate:.1f}%[/bold yellow]')
        console.print('[bold green]╚═════════════════════════════════════════════════════════════════╝[/bold green]')

class TencentPakInfo(PakInfo):
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_unk(x: bytes) -> bytes:
            key = struct.pack('<8I', *keystream[7:][:8])
            assert len(x) == len(key)
            return bytes((a ^ b for a, b in zip(x, key)))
        def decrypt_stem_hash(x: int) -> int:
            return x ^ keystream[8]
        def decrypt_unk_hash(x: int) -> int:
            return x ^ keystream[9]
        super().__init__(buffer, keystream)
        reader = Reader(buffer[-TencentPakInfo._mem_size(self.version):])
        self.unk1 = decrypt_unk(reader.s(32)) if self.version >= 7 else bytes()
        self.packed_key = reader.s(256) if self.version >= 8 else bytes()
        self.packed_iv = reader.s(256) if self.version >= 8 else bytes()
        self.packed_index_hash = reader.s(256) if self.version >= 8 else bytes()
        self.stem_hash = decrypt_stem_hash(reader.u4()) if self.version >= 9 else 0
        self.unk2 = decrypt_unk_hash(reader.u4()) if self.version >= 9 else 0
        self.content_org_hash = reader.s(20) if self.version >= 12 else bytes()
    @staticmethod
    def _mem_size(version: int) -> int:
        size_for_7 = 32 if version >= 7 else 0
        size_for_8 = 768 if version >= 8 else 0
        size_for_9 = 8 if version >= 9 else 0
        size_for_12 = 20 if version >= 12 else 0
        return PakInfo._mem_size(version) + size_for_7 + size_for_8 + size_for_9 + size_for_12


# ═══════ Compression constants (recovered) ═══════
CM_MASK = 15
CM_ZSTD_DICT = 8
CM_NONE = 0
CM_ZLIB = 1
CM_GZIP = 2
CM_LZ4 = 3
CM_OODLE = 4
CM_ZSTD = 5

class TencentPakEntry:
    def __init__(self, reader: Reader, version: int):
        self.content_hash = reader.s(20)
        if version <= 1:
            _ = reader.u8()
        self.offset = reader.u8()
        self.uncompressed_size = reader.u8()
        self.compression_method = reader.u4() & CM_MASK
        self.size = reader.u8()
        self.unk1 = reader.u1() if version >= 5 else 0
        self.unk2 = reader.s(20) if version >= 5 else bytes()
        if self.compression_method != 0 and version >= 3:
            self.compressed_blocks = [PakCompressedBlock(reader) for _ in range(reader.u4())]
        else:
            self.compressed_blocks = []
        self.compression_block_size = reader.u4() if version >= 4 else 0
        self.encrypted = reader.u1() == 1 if version >= 4 else False
        self.encryption_method = reader.u4() if version >= 12 else 0
        self.index_new_sep = reader.u4() if version >= 12 else 0



# ═══════ Crypto constants (recovered from original) ═══════
ZUC_KEY = bytes.fromhex('01010101010101010101010101010101')
ZUC_IV = bytes.fromhex('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')
SIMPLE1_DECRYPT_KEY = 121
SIMPLE2_DECRYPT_KEY = bytes.fromhex('E55B4ED1')
SIMPLE2_BLOCK_SIZE = 16
SM4_SECRET_4 = 'eb691efea91424137a8'
SM4_SECRET_2 = 'Q0hVTKey$as*1ZFlQCiA'
SM4_SECRET_NEW = [
    'xG2qW5lP7lV2iN5fN5pG',
    'xT1cJ6dL5wC0kK1rB4dK',
    'qC4jS5bZ6fL5xE6nD4zA',
    'gD4jQ2aL3bS3lC3xT0iW',
    'xU1yQ8wE9zY3gZ3bT5aE',
    'uQ3cO2dX7xY4xU7gH7iS',
    'gW1fR0jK6wQ4oN0oK1kZ',
    'aJ4pV7iZ7pU4wP2aC2cZ',
    'cX6jT3cM2oT3vK0kJ1qN',
    'iT2vS0cS6yT6cZ1sE1lO',
    'hM1pH9iY8wM9hT4lN5uJ',
    'kG6bC8jK0fL0dE4sH4mL',
    'dB6lB3vE0eZ8wM8rI0aC',
    'tP7sP7nI9rA2vQ4cV5yQ',
    'aT0cL1yN4pT3sZ7eM2vY',
    'uV6fU8fC9zN3mP5dH8mN',
    'rT6aQ6oZ1yM0gO5tO1aN',
    'jU5bH7lQ0fM9hK2kI0oF',
    'iQ0eM0mJ7uT0kV6kL5zY',
    'rG0lR2rZ5vM6mW5lM1rR',
    'wD2rP3lP9xF4mE1eC5jS',
    'fO3kW1fE6eD0pU1kY7xK',
    'nE1jQ6qK5tW7rM8iD5vV'
]
EM_SIMPLE1 = 1
EM_SIMPLE2 = 16
EM_SM4_2 = 2
EM_SM4_4 = 4
EM_SM4_NEW_BASE = 31
EM_SM4_NEW_MASK = ~31
EM_UNKNOWN_17 = 17
RSA_MOD_1 = bytes.fromhex('CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4')
RSA_MOD_2 = bytes.fromhex('7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8')


class PakCrypto:
    class _LCG:
        def __init__(self, seed: int):
            self.state = seed
        def next(self) -> int:
            MASK_32 = 4294967295
            MSB_1 = 2147483648
            def wrap(x: int) -> int:
                x &= MASK_32
                if not x & MSB_1:
                    return x
                else:
                    return (x + MSB_1 & MASK_32) - MSB_1
            x1 = wrap(1103515245 * self.state)
            self.state = wrap(x1 + 12345)
            x2 = wrap(x1 + 77880) if self.state < 0 else self.state
            return (x2 >> 16 & MASK_32) % 32767
    @staticmethod
    def zuc_keystream() -> List[int]:
        zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)
        return [struct.unpack('>I', zuc.generate())[0] for _ in range(16)]
    @staticmethod
    def _xorxor(buffer, x) -> bytes:
        return bytes((buffer[i] ^ x[i % len(x)] for i in range(len(buffer))))
    @staticmethod
    def _hashhash(buffer, n: int) -> bytes:
        result = bytes()
        for i in range(math.ceil(n / SHA1.digest_size)):
            result += SHA1.new(buffer).digest()
        if len(result) >= n:
            result = result[:n]
            return result
        else:
            result += b'\x00' * (n - len(result))
            return result
    @staticmethod
    def _meowmeow(buffer) -> bytes:
        def unpad(x):
            skip = 1 + next((i for i in range(len(x)) if x[i] != 0))
            return x[skip:]
        if len(buffer) < 43:
            return bytes()
        else:
            x1 = buffer[1:][:SHA1.digest_size]
            x2 = buffer[SHA1.digest_size + 1:]
            x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))
            x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))
            part1, m = (x2[:SHA1.digest_size], x2[SHA1.digest_size:])
            if part1 != SHA1.new(b'\x00' * SHA1.digest_size).digest():
                return bytes()
            else:
                return unpad(m)
    @staticmethod
    def rsa_extract(signature: bytes, modulus: bytes) -> bytes:
        c = int.from_bytes(signature, 'little')
        n = int.from_bytes(modulus, 'little')
        e = 65537
        m = pow(c, e, n).to_bytes(256, 'little').rstrip(b'\x00')
        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))
    @staticmethod
    def _decrypt_simple1(ciphertext) -> bytes:
        return bytes((x ^ SIMPLE1_DECRYPT_KEY for x in ciphertext))
    @staticmethod
    def _decrypt_simple2(ciphertext) -> bytes:
        class RollingKey:
            def __init__(self, initial_value: int):
                self._value = initial_value
            def update(self, x: int) -> int:
                self._value ^= x
                return self._value
        assert len(ciphertext) % SIMPLE2_BLOCK_SIZE == 0
        initial_key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
        rolling_key = RollingKey(initial_key)
        plaintext = (struct.pack('<I', rolling_key.update(x)) for x in struct.unpack(f'<{len(ciphertext) // 4}I', ciphertext))
        return bytes(it.chain.from_iterable(plaintext))
    @staticmethod
    @lru_cache(maxsize=4096)
    def _derive_sm4_key(file_path: PurePath, encryption_method: int) -> bytes:
        part1 = file_path.stem.lower()
        if encryption_method == EM_SM4_2:
            secret = SM4_SECRET_2
        else:
            if encryption_method == EM_SM4_4:
                secret = SM4_SECRET_4
            else:
                if encryption_method == EM_UNKNOWN_17:
                    index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
                    secret = SM4_SECRET_NEW[index]
                else:
                    index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
                    secret = f'{SM4_SECRET_NEW[index]}{encryption_method}'
        return SHA1.new(str(part1 + secret).encode()).digest()[:SM4.key_length()]
    @staticmethod
    @lru_cache(maxsize=4096)
    def _sm4_context_for_key(key: bytes) -> SM4:
        return SM4(key)
    @staticmethod
    def _decrypt_sm4(ciphertext, file_path: PurePath, encryption_method: int) -> bytes:
        assert len(ciphertext) % SM4.block_length() == 0
        key = PakCrypto._derive_sm4_key(file_path, encryption_method)
        sm4 = PakCrypto._sm4_context_for_key(key)
        return sm4.decrypt_bulk(ciphertext)
    @staticmethod
    def decrypt_index(ciphertext, pak_info: TencentPakInfo) -> bytes:
        if pak_info.version > 7:
            key = PakCrypto.rsa_extract(pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_info.packed_iv, RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            aes = AES.new(key, MODE_CBC, iv[:16])
            return unpad(aes.decrypt(ciphertext), AES.block_size)
        else:
            return bytes(PakCrypto._decrypt_simple1(ciphertext))
    @staticmethod
    def _is_simple1_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE1
    @staticmethod
    def _is_simple2_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE2
    @staticmethod
    def _is_sm4_method(encryption_method: int) -> bool:
        return encryption_method == EM_SM4_2 or encryption_method == EM_SM4_4 or encryption_method == EM_UNKNOWN_17 or (encryption_method & EM_SM4_NEW_MASK) != 0
    @staticmethod
    def align_encrypted_content_size(n: int, encryption_method: int) -> int:
        if PakCrypto._is_simple2_method(encryption_method):
            return Misc.align_up(n, SIMPLE2_BLOCK_SIZE)
        else:
            if PakCrypto._is_sm4_method(encryption_method):
                return Misc.align_up(n, SM4.block_length())
            else:
                return n
    @staticmethod
    def decrypt_block(ciphertext, file: PurePath, encryption_method: int) -> bytes:
        if PakCrypto._is_simple1_method(encryption_method):
            return PakCrypto._decrypt_simple1(ciphertext)
        else:
            if PakCrypto._is_simple2_method(encryption_method):
                return PakCrypto._decrypt_simple2(ciphertext)
            else:
                if PakCrypto._is_sm4_method(encryption_method):
                    return PakCrypto._decrypt_sm4(ciphertext, file, encryption_method)
                else:
                    raise ValueError(f'Unknown encryption method: {encryption_method}')
    @staticmethod
    @lru_cache(maxsize=33)
    def generate_block_indices(n: int, encryption_method: int) -> List[int]:
        if not PakCrypto._is_sm4_method(encryption_method):
            return list(range(n))
        else:
            permutation = []
            lcg = PakCrypto._LCG(n)
            while len(permutation) != n:
                x = lcg.next() % n
                if x not in permutation:
                    permutation.append(x)
            inverse = [0] * len(permutation)
            for i, x in enumerate(permutation):
                inverse[x] = i
            return inverse

# === TencentPakFile (repaired) ===
class TencentPakFile:
    def __init__(self, file_path: PurePath, is_od=False):
        self._file_path = file_path
        with open(file_path, 'rb') as file:
            self._file_content = memoryview(file.read())
        self._is_od = is_od
        self._mount_point = PurePath()
        self._is_zstd_with_dict = 'zsdic' in str(self._file_path)
        self._zstd_dict = None
        self._zstd_dict_entry = None
        self._files = []
        self._index = {}
        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())
        self._verify_stem_hash()
        self._tencent_load_index()
    def _get_method_str(self, method_int, is_encryption):
        if is_encryption:
            if method_int == EM_UNKNOWN_17:
                return 'ENC17?'
            else:
                if PakCrypto._is_simple1_method(method_int):
                    return 'SIMPLE1'
                else:
                    if PakCrypto._is_simple2_method(method_int):
                        return 'SIMPLE2'
                    else:
                        if PakCrypto._is_sm4_method(method_int):
                            return f'SM4 (Type {method_int})'
                        else:
                            if method_int == 0:
                                return 'NONE'
                            else:
                                return 'UNKNOWN'
        else:
            if method_int == CM_NONE:
                return 'NONE'
            else:
                if method_int == CM_ZLIB:
                    return 'ZLIB'
                else:
                    if method_int == CM_ZSTD:
                        return 'ZSTD'
                    else:
                        if method_int == CM_ZSTD_DICT:
                            return 'ZSTD_DICT'
                        else:
                            return 'UNKNOWN'
    def detect_dominant_style(self) -> dict:
        comp_counter = Counter()
        enc_counter = Counter()
        blk_counter = Counter()
        enc_flag_counter = Counter()
        total = len(self._files)
        if total == 0:
            return {'comp_method': CM_ZSTD, 'enc_method': 0, 'encrypted': False, 'block_size': 65536}
        else:
            for entry in self._files:
                comp_counter[entry.compression_method] += 1
                if entry.encrypted:
                    enc_counter[entry.encryption_method] += 1
                    enc_flag_counter['encrypted'] += 1
                else:
                    enc_flag_counter['plain'] += 1
                if entry.compression_block_size:
                    blk_counter[entry.compression_block_size] += 1
            non_none = [(m, c) for m, c in comp_counter.items() if m != CM_NONE]
            comp_method = max(non_none, key=lambda x: x[1])[0] if non_none else CM_NONE
            encrypted = enc_flag_counter.get('encrypted', 0) > enc_flag_counter.get('plain', 0)
            enc_method = enc_counter.most_common(1)[0][0] if encrypted and enc_counter else 0
            block_size = blk_counter.most_common(1)[0][0] if blk_counter else 65536
            return {'comp_method': comp_method, 'enc_method': enc_method, 'encrypted': encrypted, 'block_size': block_size}
    def inject_files(self, inject_plan: list, output_pak: Path, add_signature_marker: bool=True) -> None:
        if not inject_plan:
            raise ValueError('inject_plan is empty — nothing to inject')
        console.print(Panel(f'CUSTOM INJECT\\nSource PAK: {self._file_path.name}\\nOutput: {output_pak.name}\\nInjecting: {len(inject_plan)} file(s)', title='INJECT MODE', border_style='magenta'))
        work_items = []
        for i, item in enumerate(inject_plan):
            if item.get('plain_bytes') is not None:
                plain = item['plain_bytes']
            elif item.get('src_path') is not None:
                plain = Path(item['src_path']).read_bytes()
            else:
                console.print(f'   [red]Inject item {i} has no src_path or plain_bytes — skipping[/red]')
                continue
            internal = item['internal_path'].replace('\\', '/').lstrip('/')
            if not internal:
                console.print(f'   [red]Empty internal_path for item {i} — skipping[/red]')
                continue
            parts = internal.rsplit('/', 1)
            if len(parts) == 2:
                dir_str, file_name = parts[0], parts[1]
            else:
                dir_str, file_name = '', parts[0]
            if dir_str and not dir_str.endswith('/'):
                dir_str += '/'
            work_items.append({'idx': i, 'plain': plain, 'internal': internal, 'dir': dir_str, 'name': file_name, 'item': item})
        if not work_items:
            console.print('[red]Nothing valid to inject[/red]')
            return
        try:
            shutil.copy2(self._file_path, output_pak)
            console.print(f'[dim]Copied base PAK -> {output_pak.name}[/dim]')
        except Exception as e:
            console.print(f'[red]Failed to copy base PAK: {e}[/red]')
            return
        console.print(f'[green]Inject prepared: {len(work_items)} item(s) -> {output_pak.name}[/green]')
    def _verify_stem_hash(self) -> None:
        if not self._is_od and self._pak_info.version >= 9:
                try:
                    assert self._pak_info.stem_hash == zlib.crc32(self._file_path.stem.encode('utf-32le'))
                except AssertionError:
                    print('⚠ Warning: pak filename differs from original stem; rename back to match before game use.')
    def _tencent_load_index(self) -> None:
        index_data = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        if self._pak_info.index_encrypted:
            index_data = PakCrypto.decrypt_index(index_data, self._pak_info)
        else:
            index_data = index_data
        self._verify_index_hash(index_data)
        self._load_index(index_data)
    def _verify_index_hash(self, index_data) -> None:
        expected_hash = self._pak_info.index_hash
        if not self._is_od and self._pak_info.version >= 8 and (expected_hash != PakCrypto.rsa_extract(self._pak_info.packed_index_hash, RSA_MOD_2)):
                    console.print('[bold yellow]![/] [yellow]packed_index_hash mismatch (rebuilt pak - stale RSA blob, ignored)[/yellow]')
        assert expected_hash == SHA1.new(index_data).digest()
    @staticmethod
    def _construct_mount_point(mount_point: str) -> PurePath:
        result = PurePath()
        for part in PurePath(mount_point).parts:
            if part != '..':
                result /= part
        return result
    def _peek_content(self, offset: int, size: int, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(size, encryption_method)
        return self._file_content[offset:][:size]
    def _peek_block_content(self, block: PakCompressedBlock, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(block.end - block.start, encryption_method)
        return self._file_content[block.start:][:size]
    def _construct_zstd_dict(self, dict_entry: TencentPakEntry) -> None:
        assert not self._zstd_dict
        assert not dict_entry.encrypted
        assert dict_entry.compression_method == CM_NONE
        reader = Reader(self._peek_content(dict_entry.offset, dict_entry.size, 0))
        dict_size = reader.u8()
        _ = reader.u4()
        assert dict_size == reader.u4()
        dict_data = reader.s(dict_size)
        self._zstd_dict = PakCompression.zstd_dictionary(dict_data)
    def _load_index(self, index_data) -> None:
        if self._pak_info.version <= 10:
            raise ValueError(f'Unsupported version: {self._pak_info.version}')
        else:
            reader = Reader(index_data)
            self._mount_point = self._construct_mount_point(reader.string())
            self._files = [TencentPakEntry(reader, self._pak_info.version) for _ in range(reader.u4())]
            for _ in range(reader.u8()):
                dir_path = PurePath(reader.string())
                e = {reader.string(): self._files[~reader.i4()] for _ in range(reader.u8())}
                if self._is_zstd_with_dict and dir_path.name == 'zstddic':
                    assert len(e) == 1
                    self._zstd_dict_entry = e[[*e.keys()][0]]
                    self._construct_zstd_dict(self._zstd_dict_entry)
                else:
                    self._index.update({PurePath(dir_path): e})
    def _write_to_disk(self, file_path: Path, entry: TencentPakEntry) -> None:
        encryption_method = entry.encryption_method
        compression_method = entry.compression_method
        enc_str = self._get_method_str(encryption_method, True)
        comp_str = self._get_method_str(compression_method, False)
        console.print(f'[bold cyan]->[/] Unpack: [bold green]{file_path.name}[/] [[bold yellow]{comp_str}[/]/[bold magenta]{enc_str}[/]]')
        if entry.encrypted and encryption_method == EM_UNKNOWN_17:
            self._dump_raw_unsupported_17(file_path, entry)
            return
        else:
            if entry.encrypted and entry.compression_method != CM_NONE and PakCrypto._is_sm4_method(encryption_method):
                try:
                    if entry.compressed_blocks:
                        probe_idx = next(iter(PakCrypto.generate_block_indices(len(entry.compressed_blocks), encryption_method)))
                        probe = bytes(self._peek_block_content(entry.compressed_blocks[probe_idx], encryption_method))
                        probe = PakCrypto.decrypt_block(probe, file_path, encryption_method)
                        if not self._decrypted_looks_valid(bytes(probe), compression_method):
                            raise ValueError(f'Decrypt probe failed (wrong SM4 key for Type {encryption_method})')
                except Exception as exc:
                    with open(file_path, 'wb') as _f:
                        raw = bytearray()
                        for blk in entry.compressed_blocks:
                            raw += bytes(self._peek_block_content(blk, encryption_method))
                        _f.write(raw)
                    console.print(f'[bold red]![/] [red]Raw dump for undecryptable file[/] [bold yellow]{file_path.name}[/] [dim]({type(exc).__name__}: {exc})[/dim]')
                    return None
            with open(file_path, 'wb') as file:
                if compression_method == CM_NONE:
                    data = self._peek_content(entry.offset, entry.size, encryption_method)
                    if entry.encrypted:
                        data = PakCrypto.decrypt_block(data, file_path, encryption_method)
                    data = bytes(data)
                    if entry.uncompressed_size and len(data) > entry.uncompressed_size:
                            data = data[:entry.uncompressed_size]
                    file.write(data)
                    return
                else:
                    try:
                        for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), encryption_method):
                            data = self._peek_block_content(entry.compressed_blocks[x], encryption_method)
                            if entry.encrypted:
                                data = PakCrypto.decrypt_block(data, file_path, encryption_method)
                            data = PakCompression.decompress_block(data, self._zstd_dict, compression_method)
                            file.write(data)
                    except Exception as exc:
                        file.seek(0)
                        file.truncate()
                        raw = bytearray()
                        for blk in entry.compressed_blocks:
                            raw += self._peek_block_content(blk, encryption_method)
                        file.write(raw)
                        console.print(f'[bold red]![/] [red]Raw dump for undecryptable file[/] [bold yellow]{file_path.name}[/] [dim]({type(exc).__name__})[/dim]')
    @staticmethod
    def _decrypted_looks_valid(data: bytes, compression_method: int) -> bool:
        """True if decrypted bytes look like a real compressed stream."""
        if compression_method == CM_ZLIB:
            return len(data) >= 2 and data[0] == 120 and (data[1] in (1, 156, 218))
        else:
            if compression_method in (CM_ZSTD, CM_ZSTD_DICT):
                return bytes(data[:4]) == b'(\xb5/\xfd'
            else:
                return True
    def _dump_raw_unsupported_17(self, file_path: Path, entry: TencentPakEntry) -> None:
        console.print(f'[bold yellow]⚠ ENC 17 UNSUPPORTED ({file_path.name}) — cipher unknown, dumped raw encrypted bytes.[/bold yellow]')
        with open(file_path, 'wb') as file:
            if entry.compression_method == CM_NONE:
                file.write(bytes(self._peek_content(entry.offset, entry.size, entry.encryption_method)))
            else:
                for blk in entry.compressed_blocks:
                    file.write(bytes(self._file_content[blk.start:blk.end]))
    def detect_dominant_style(self) -> dict:
        comp_counter = Counter()
        enc_counter = Counter()
        blk_counter = Counter()
        enc_flag_counter = Counter()
        total = len(self._files)
        if total == 0:
            return {'comp_method': CM_ZSTD, 'enc_method': 0, 'encrypted': False, 'block_size': 65536}
        else:
            for entry in self._files:
                comp_counter[entry.compression_method] += 1
                if entry.encrypted:
                    enc_counter[entry.encryption_method] += 1
                    enc_flag_counter['encrypted'] += 1
                else:
                    enc_flag_counter['plain'] += 1
                if entry.compression_block_size:
                    blk_counter[entry.compression_block_size] += 1
            non_none = [(m, c) for m, c in comp_counter.items() if m != CM_NONE]
            comp_method = max(non_none, key=lambda x: x[1])[0] if non_none else CM_NONE
            encrypted = enc_flag_counter.get('encrypted', 0) > enc_flag_counter.get('plain', 0)
            enc_method = enc_counter.most_common(1)[0][0] if encrypted and enc_counter else 0
            block_size = blk_counter.most_common(1)[0][0] if blk_counter else 65536
            return {'comp_method': comp_method, 'enc_method': enc_method, 'encrypted': encrypted, 'block_size': block_size}
    def inject_files(self, inject_plan: list, output_pak: Path, add_signature_marker: bool=True) -> None:
        # irreducible cflow, using cdg fallback
        if not inject_plan:
            raise ValueError('inject_plan is empty — nothing to inject')
        else:
            console.print(Panel(f'[bold magenta]💉 CUSTOM INJECT[/bold magenta]\n[white]Source PAK:[/] [yellow]{self._file_path.name}[/yellow]\n[white]Output    :[/] [cyan]{output_pak.name}[/cyan]\n[white]Injecting :[/] [green]{len(inject_plan)} new file(s)[/green]\n[dim]Credit    : {CREDIT}[/dim]', title='INJECT MODE', border_style='magenta', padding=(0, 2)))
            console.print(f'\n[bold magenta]━━ STEP 1/5 : LOADING INJECT FILES ━━  [dim]({CREDIT})[/dim][/bold magenta]')
            work_items = []
            for i, item in enumerate(inject_plan):
                if item.get('plain_bytes') is not None:
                    pass
            pass
            plain = item['plain_bytes']
            if item.get('src_path') is not None:
                pass
            pass
# FIX: else:
            console.print(f'   [red]✗ Inject item {i} has no src_path or plain_bytes — skipping[/red]')
# continue
            plain = Path(item['src_path']).read_bytes()
            internal = item['internal_path'].replace('\\', '/').lstrip('/')
            if not internal:
                pass
            console.print(f'   [red]✗ Empty internal_path for item {i} — skipping[/red]')
# continue
# FIX: else:
            parts = internal.rsplit('/', 1)
            if len(parts) == 2:
                dir_str, file_name = (parts[0], parts[1])
            else:
                dir_str, file_name = ('', parts[0])
            work_items.append({'dir_str': dir_str, 'file_name': file_name, 'internal_path': internal, 'plain': plain, 'comp_method': item['comp_method'], 'enc_method': item['enc_method'], 'encrypted': bool(item['encrypted']), 'block_size': item['block_size'], 'comp_level': item.get('comp_level', 19)})
            console.print(f'   [blue]✨[/] {internal} [dim]({len(plain):,} bytes)[/dim]')
            if not work_items:
                pass
            raise RuntimeError('No valid inject items after loading')
# FIX: else:
            console.print(f'[green]✔ Loaded {len(work_items)} file(s)[/green]')
            console.print(f'\n[bold magenta]━━ STEP 2/5 : ENCODING INJECT FILES ━━  [dim]({CREDIT})[/dim][/bold magenta]')
            keystream = PakCrypto.zuc_keystream()
            version = self._pak_info.version
            header_size = TencentPakInfo._mem_size(version)
            PAK_MAGIC = self._pak_info.magic
            orig_index_offset = self._pak_info.index_offset
            current_new_offset = orig_index_offset
            new_data_region = bytearray()
            new_injected_entries = []
            def _encrypt_plaintext(plaintext, pak_relative_path, encryption_method):
                if PakCrypto._is_simple1_method(encryption_method):
                    return bytes((b ^ SIMPLE1_DECRYPT_KEY for b in plaintext))
                else:
                    if PakCrypto._is_simple2_method(encryption_method):
                        pad = -len(plaintext) % SIMPLE2_BLOCK_SIZE
                        plaintext += b'\x00' * pad
                        key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
                        rolling = key
                        out = []
                        for x, in struct.iter_unpack('<I', plaintext):
                            c = rolling ^ x
                            out.append(c)
                            rolling ^= c
                        return struct.pack(f'<{len(out)}I', *out)
                    else:
                        if PakCrypto._is_sm4_method(encryption_method):
                            key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)
                            sm4 = PakCrypto._sm4_context_for_key(key)
                            pad_len = -len(plaintext) % 16
                            if pad_len > 0:
                                plaintext = plaintext + b'\x00' * pad_len
                            out = bytearray()
                            for i in range(0, len(plaintext), 16):
                                block = plaintext[i:i + 16]
                                if len(block) < 16:
                                    block = block.ljust(16, b'\x00')
                                out.extend(sm4.encrypt(block))
                            return bytes(out)
                        else:
                            return plaintext
            for item in work_items:
                plain = item['plain']
                comp_method = item['comp_method']
                enc_method = item['enc_method']
                encrypted = item['encrypted']
                block_size_val = item['block_size']
                file_path_for_crypto = PurePath(item['file_name'])
                if len(plain) == 0:
                    new_injected_entries.append({'content_hash': SHA1.new(b'').digest(), 'offset': current_new_offset, 'uncompressed_size': 0, 'size': 0, 'comp_method': CM_NONE, 'enc_method': 0, 'encrypted': False, 'block_size_val': 0, 'compressed_blocks': [], 'unk1': 0, 'unk2': b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', 'index_new_sep': 0, '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(), '_file_name': item['file_name']})
                else:
                    if comp_method == CM_NONE:
                        if encrypted:
                            aligned_size = PakCrypto.align_encrypted_content_size(len(plain), enc_method)
                            padded = plain + b'\x00' * (aligned_size - len(plain))
                            stored_data = _encrypt_plaintext(padded, file_path_for_crypto, enc_method)
                        else:
                            stored_data = plain
                        new_size = len(stored_data)
                        new_compressed_blocks = []
                    else:
                        chunks = [plain[i:i + block_size_val] for i in range(0, len(plain), block_size_val)]
                        if not chunks:
                            chunks = [b'']
                        compressed_chunks = []
                        for chunk in chunks:
                            comp = None
                            if comp_method in (CM_ZSTD, CM_ZSTD_DICT):
                                zstd_dict = self._zstd_dict if comp_method == CM_ZSTD_DICT else None
                                for lvl in range(22, 0, (-1)):
                                    try:
                                        c = ZstdCompressor(level=lvl, dict_data=zstd_dict, threads=1)
                                        comp = c.compress(chunk)
                                    except:
                                        continue
                                    else:
                                        break
                            else:
                                if comp_method == CM_ZLIB:
                                    comp = zlib.compress(chunk, level=9)
                            if comp is None:
                                comp = chunk
                            compressed_chunks.append(comp)
                        encrypted_chunks = []
                        for comp_data in compressed_chunks:
                            if encrypted:
                                comp_data = _encrypt_plaintext(comp_data, file_path_for_crypto, enc_method)
                            encrypted_chunks.append(comp_data)
                        n_blocks = len(encrypted_chunks)
                        indices = PakCrypto.generate_block_indices(n_blocks, enc_method)
                        physical_blocks = [None] * n_blocks
                        for j, chunk_data in enumerate(encrypted_chunks):
                            physical_blocks[indices[j]] = chunk_data
                        physical_offsets = []
                        block_cursor = current_new_offset
                        for phys_block in physical_blocks:
                            physical_offsets.append((block_cursor, block_cursor + len(phys_block)))
                            block_cursor += len(phys_block)
                        new_compressed_blocks = physical_offsets
                        stored_data = b''.join(physical_blocks)
                        new_size = len(stored_data)
                        if encrypted:
                            aligned_total = PakCrypto.align_encrypted_content_size(new_size, enc_method)
                            if aligned_total > new_size:
                                stored_data = stored_data + b'\x00' * (aligned_total - new_size)
                                new_size = aligned_total
                    new_content_hash = SHA1.new(stored_data).digest()
                    new_data_region.extend(stored_data)
                    new_injected_entries.append({'content_hash': new_content_hash, 'offset': current_new_offset, 'uncompressed_size': len(plain), 'size': new_size, 'comp_method': comp_method, 'enc_method': enc_method if encrypted else 0, 'encrypted': encrypted, 'block_size_val': block_size_val, 'compressed_blocks': new_compressed_blocks, 'unk1': 0, 'unk2': b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', 'index_new_sep': 0, '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(), '_file_name': item['file_name']})
                    current_new_offset += new_size
            console.print(f'[green]✔ Encoded {len(new_injected_entries)} file(s)[/green]')
            new_entries = []
            entry_to_path = {}
            for dir_path, files in self._index.items():
                for fname, entry in files.items():
                    entry_to_path[id(entry)] = (dir_path, fname)
            for i, entry in enumerate(self._files):
                dir_path, fname = entry_to_path.get(id(entry), (PurePath(), f'unknown_{i}'))
                new_entries.append({'content_hash': entry.content_hash, 'offset': entry.offset, 'uncompressed_size': entry.uncompressed_size, 'size': entry.size, 'comp_method': entry.compression_method, 'enc_method': entry.encryption_method if entry.encrypted else 0, 'encrypted': entry.encrypted, 'block_size_val': entry.compression_block_size, 'compressed_blocks': [(b.start, b.end) for b in entry.compressed_blocks], 'unk2': entry.unk2, 'index_new_sep': entry.index_new_sep})
            new_entries.extend(new_injected_entries)
            if add_signature_marker:
                marker_already_present = False
                for dp, files_dict in self._index.items():
                    if dp.name in ('ALVSIA', bytes.fromhex('48525f4448414d41').decode()) and 'PATCHED.txt' in files_dict:
                            marker_already_present = True
                            break
                if not marker_already_present:
                    empty_hash = SHA1.new(b'').digest()
                    new_entries.append({'content_hash': empty_hash, 'offset': current_new_offset, 'uncompressed_size': 0, 'size': 0, 'comp_method': CM_NONE, 'enc_method': 0, 'encrypted': False, 'block_size_val': 0, 'compressed_blocks': [], 'unk1': 0, 'unk2': b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', 'index_new_sep': 0, '_dir_path': PurePath('ALVSIA'), '_file_name': '@CIL_T'})
            index_data = bytearray()
            raw_orig_index = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
            orig_index_decoded = PakCrypto.decrypt_index(bytes(raw_orig_index), self._pak_info)
            orig_reader = Reader(orig_index_decoded)
            orig_mount_len = orig_reader.i4()
            orig_mount_bytes = bytes(orig_reader.s(orig_mount_len))
            index_data.extend(struct.pack('<I', orig_mount_len))
            index_data.extend(orig_mount_bytes)
            index_data.extend(struct.pack('<I', len(new_entries)))
            for item in new_entries:
                index_data.extend(item['content_hash'])
                if version <= 1:
                    index_data.extend(struct.pack('<Q', 0))
                index_data.extend(struct.pack('<Q', item['offset']))
                index_data.extend(struct.pack('<Q', item['uncompressed_size']))
                index_data.extend(struct.pack('<I', item['comp_method'] & CM_MASK))
                index_data.extend(struct.pack('<Q', item['size']))
                if version >= 5:
                    index_data.extend(struct.pack('<B', item['unk1']))
                    index_data.extend(item['unk2'] if item['unk2'] else b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
                if item['comp_method'] != CM_NONE and version >= 3:
                        index_data.extend(struct.pack('<I', len(item['compressed_blocks'])))
                        for start, end in item['compressed_blocks']:
                            index_data.extend(struct.pack('<Q', start))
                            index_data.extend(struct.pack('<Q', end))
                if version >= 4:
                    index_data.extend(struct.pack('<I', item['block_size_val']))
                    index_data.extend(struct.pack('<B', 1 if item['encrypted'] else 0))
                if version >= 12:
                    index_data.extend(struct.pack('<I', item['enc_method']))
                    index_data.extend(struct.pack('<I', item['index_new_sep']))
            file_to_dirname = {}
            for dir_path, files_dict in self._index.items():
                dir_str = dir_path.as_posix()
                for fname, entry in files_dict.items():
                    for i, fe in enumerate(self._files):
                        if id(fe) == id(entry):
                            file_to_dirname[i] = (dir_str, fname)
                            break
            for i, item in enumerate(new_entries):
                if i not in file_to_dirname:
                    if '_dir_path' in item:
                        file_to_dirname[i] = (item['_dir_path'].as_posix(), item['_file_name'])
                    else:
                        file_to_dirname[i] = ('', f'file_{i}')
            all_dirs = []
            dir_to_files = {}
            for dir_path in self._index.keys():
                ds = dir_path.as_posix()
                all_dirs.append(ds)
                dir_to_files[ds] = []
            for i, item in enumerate(new_entries):
                ds, fn = file_to_dirname[i]
                if ds not in dir_to_files:
                    dir_to_files[ds] = []
                    all_dirs.append(ds)
                dir_to_files[ds].append((fn, i))
            index_data.extend(struct.pack('<Q', len(all_dirs)))
            for dir_str in all_dirs:
                files_list = dir_to_files[dir_str]
                if not dir_str or dir_str == '.':
                    index_data.extend(struct.pack('<I', 0))
                else:
                    if not dir_str.endswith('/'):
                        dir_str_with_slash = dir_str + '/'
                    else:
                        dir_str_with_slash = dir_str
                    dir_bytes = dir_str_with_slash.encode('utf-8') + b'\x00'
                    index_data.extend(struct.pack('<I', len(dir_bytes)))
                    index_data.extend(dir_bytes)
                index_data.extend(struct.pack('<Q', len(files_list)))
                for file_name, fi in files_list:
                    name_bytes = file_name.encode('utf-8') + b'\x00'
                    index_data.extend(struct.pack('<I', len(name_bytes)))
                    index_data.extend(name_bytes)
                    index_data.extend(struct.pack('<i', -fi - 1))
            index_data.extend(b'\x1d\x00\x00\x00..')
            index_hash = SHA1.new(bytes(index_data)).digest()
            if version > 7 and self._pak_info.index_encrypted:
                key = PakCrypto.rsa_extract(self._pak_info.packed_key, RSA_MOD_1)
                iv = PakCrypto.rsa_extract(self._pak_info.packed_iv, RSA_MOD_1)
                assert len(key) == 32 and len(iv) == 32
                padded = pad(bytes(index_data), AES.block_size)
                aes = AES.new(key, MODE_CBC, iv[:16])
                encrypted_index = aes.encrypt(padded)
            else:
                if self._pak_info.index_encrypted:
                    encrypted_index = bytes((b ^ SIMPLE1_DECRYPT_KEY for b in bytes(index_data)))
                else:
                    encrypted_index = bytes(index_data)
            index_size = len(encrypted_index)
            new_index_offset = orig_index_offset + len(new_data_region)
            encrypted_magic = PAK_MAGIC ^ keystream[2]
            key_stream_hash = struct.pack('<5I', *keystream[4:][:5])
            encrypted_index_hash = bytes((a ^ b for a, b in zip(index_hash, key_stream_hash)))
            encrypted_index_size = index_size ^ (keystream[10] << 32 | keystream[11])
            encrypted_index_offset = new_index_offset ^ (keystream[0] << 32 | keystream[1])
            encrypted_flag_byte = (1 if self._pak_info.index_encrypted else 0) ^ keystream[3] & 255
            orig_data_region = bytearray(self._file_content[0:orig_index_offset])
            output_pak.parent.mkdir(parents=True, exist_ok=True)
            with open(output_pak, 'wb') as f:
                f.write(bytes(orig_data_region))
                f.write(bytes(new_data_region))
                f.write(encrypted_index)
                if version >= 7:
                    key_unk1 = struct.pack('<8I', *keystream[7:][:8])
                    unk1_plain = self._pak_info.unk1 if self._pak_info.unk1 else b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
                    encrypted_unk1 = bytes((a ^ b for a, b in zip(unk1_plain, key_unk1)))
                    f.write(encrypted_unk1)
                if version >= 8:
                    f.write(self._pak_info.packed_key if self._pak_info.packed_key else b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
                    f.write(self._pak_info.packed_iv if self._pak_info.packed_iv else b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
                    f.write(self._pak_info.packed_index_hash if self._pak_info.packed_index_hash else b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
                if version >= 9:
                    f.write(struct.pack('<I', (self._pak_info.stem_hash or 0) ^ keystream[8]))
                    f.write(struct.pack('<I', (self._pak_info.unk2 or 0) ^ keystream[9]))
                if version >= 12:
                    f.write(self._pak_info.content_org_hash if self._pak_info.content_org_hash else b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
                f.write(struct.pack('<B', encrypted_flag_byte))
                f.write(struct.pack('<I', encrypted_magic))
                f.write(struct.pack('<I', version))
                if version >= 6:
                    f.write(encrypted_index_hash)
                else:
                    f.write(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
                f.write(struct.pack('<Q', encrypted_index_size))
                f.write(struct.pack('<Q', encrypted_index_offset))
            console.print(Panel(f'[bold green]🎉 INJECT COMPLETE![/bold green]\n\n[white]Output  :[/] [cyan]{output_pak.name}[/cyan]\n[dim]Credit  : {CREDIT}[/dim]', title='✅ SUCCESS', border_style='green', padding=(1, 2)))
    def dump(self, out_path: Path) -> None:
        out_path = out_path / self._mount_point
        out_path.mkdir(parents=True, exist_ok=True)
        total_files = sum((len(d) for d in self._index.values()))
        with Progress(SpinnerColumn(), TextColumn('[bold cyan][UNPACK][/] {task.description}'), BarColumn(), TaskProgressColumn(), TimeElapsedColumn(), console=console) as progress:
            task = progress.add_task('Extracting files...', total=total_files)
            for dir_path, dir_content in self._index.items():
                current_out_path = out_path / dir_path
                current_out_path.mkdir(parents=True, exist_ok=True)
                for file_name, entry in dir_content.items():
                    self._write_to_disk(current_out_path / file_name, entry)
                    progress.update(task, advance=1)
# === Repaired functions ===
def _load_fast_sm4():
    global _FAST_SM4_TRIED, _FAST_SM4_LIB
    if _FAST_SM4_TRIED:
        return _FAST_SM4_LIB
    _FAST_SM4_TRIED = True
    try:
        from sm4_embed_data import _SM4_SO_B64
        import base64 as _b64
        import tempfile as _tf
        import hashlib as _hl
        blob = _b64.b64decode(_SM4_SO_B64)
        h = _hl.sha1(blob).hexdigest()[:16]
        sfx = '.dll' if os.name == 'nt' else '.so'
        cdir = os.path.join(_tf.gettempdir(), 'sm4cache')
        os.makedirs(cdir, exist_ok=True)
        so_path = os.path.join(cdir, 'sm4_' + h + sfx)
        if not os.path.exists(so_path) or os.path.getsize(so_path) != len(blob):
            tmp_fd, tmp_path = _tf.mkstemp(dir=cdir, suffix=sfx)
            with os.fdopen(tmp_fd, 'wb') as f:
                f.write(blob)
            os.replace(tmp_path, so_path)
        try:
            os.chmod(so_path, 0o755)
        except Exception:
            pass
        lib = ctypes.CDLL(so_path)
        lib.sm4_ecb.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_size_t, ctypes.c_int]
        lib.sm4_ecb.restype = None
        _FAST_SM4_LIB = lib
        return lib
    except Exception:
        return None

def safe_input(prompt: str='') -> str:
    try:
        return input(prompt)
    except (EOFError, RuntimeError):
        if sys.platform != 'win32':
            try:
                with open('/dev/tty', 'r') as tty:
                    sys.stderr.write(prompt)
                    sys.stderr.flush()
                    return tty.readline().rstrip('\r\n')
            except Exception:
                return ''
        return ''

def ensure_exe_index(data_path: Path, pak_file=None, pakname: str='') -> Optional[Path]:
    try:
        exe_dir = data_path / 'EXE'
        exe_dir.mkdir(parents=True, exist_ok=True)
        exe = exe_dir / 'index.csv'
        if exe.exists() and exe.stat().st_size > 0:
            return exe
        src = data_path / 'PAK TOOL' / 'EXE' / 'index.csv'
        if src.exists():
            shutil.copy2(src, exe)
            console.print(f'[dim]EXE/index.csv copied from PAKTOOL_NEW ({exe})[/dim]')
            return exe
        if pak_file is not None:
            n = write_pack_index_csv(pak_file, exe)
            console.print(f'[dim]EXE/index.csv generated ({n} paths)[/dim]')
            return exe
        return None
    except Exception:
        return None

def find_index_for_pak(data_path: Path, pakname: str) -> Optional[Path]:
    c0 = data_path / 'EXE' / 'index.csv'
    if c0.exists() and c0.stat().st_size > 0:
        return c0
    c1 = data_path / 'UNPACK' / pakname / 'index.csv'
    if c1.exists() and c1.stat().st_size > 0:
        return c1
    c2 = data_path / 'EXE' / f'index_{pakname}.csv'
    if c2.exists() and c2.stat().st_size > 0:
        return c2
    fb = Path('/data/data/com.termux/files/home/PAKTOOL_NEW/EXE/index.csv')
    if fb.exists() and fb.stat().st_size > 0:
        return fb
    return None

def _lua_base() -> Path:
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

def build_new_pak_from_template(template_pak_path: Path, edit_dir: Path, output_path: Path, target_path: str=None, path_map: dict=None):
    # irreducible cflow, using cdg fallback
    import copy as _cp
    console.print(f'[white]Building NEW PAK using template: {template_pak_path.name}  [dim]· {CREDIT}[/dim][/]')
    pak_file = TencentPakFile(template_pak_path, is_od=True)
    version = pak_file._pak_info.version
    keystream = PakCrypto.zuc_keystream()
    mp_str, _all_dirs_orig = _get_all_dirs_and_mp(pak_file)
    template_entry = None
    for _dir_path, files in pak_file._index.items():
        for _name, entry in files.items():
            template_entry = entry
        if template_entry:
            break
    if template_entry is None:
        console.print(f'[red]No file found in the Template PAK to copy settings from!  [dim]({CREDIT})[/dim][/]')
        return 0
    edit_files = [p for p in Path(edit_dir).rglob('*') if p.is_file()]
    if not edit_files:
        console.print(f'[red]No file found in the EDIT folder!  [dim]({CREDIT})[/dim][/]')
        return 0
    out_buf = bytearray()
    new_files = []
    all_dirs = {}
    file_rows = []
    with Progress(SpinnerColumn(), TextColumn(f'[white][BUILD][/] {{task.description}}  [dim]({CREDIT})[/dim]'), BarColumn(), TaskProgressColumn(), TimeElapsedColumn(), console=console) as progress:
        task = progress.add_task('Adding files...', total=len(edit_files))
        for p in edit_files:
            rel = p.relative_to(edit_dir).as_posix()
            if path_map is not None:
                tp_for_file = path_map.get(p.name)
                if tp_for_file is None:
                    tp_for_file = ''
                if tp_for_file == '':
                    parent = str(PurePath(rel).parent).replace('\\', '/')
                    dir_key = '' if parent == '.' else parent + '/'
                    fp = rel
                else:
                    dir_key = tp_for_file.rstrip('/') + '/'
                    fp = f"{tp_for_file.rstrip('/')}/{p.name}"
            else:
                if target_path:
                    fp = f"{target_path.rstrip('/')}/{p.name}"
                    dir_key = target_path.rstrip('/') + '/'
                else:
                    parent = str(PurePath(rel).parent).replace('\\', '/')
                    dir_key = '' if parent == '.' else parent + '/'
                    fp = rel
            ne = _cp.copy(template_entry)
            new_raw = p.read_bytes()
            pak_rel = PurePath(fp)
            ne.uncompressed_size = len(new_raw)
            ne.compression_method = template_entry.compression_method
            ne.encryption_method = template_entry.encryption_method
            ne.encrypted = template_entry.encrypted
            ne.unk1 = template_entry.unk1
            full_path_str = mp_str + fp
            ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
            ne.index_new_sep = template_entry.index_new_sep
            stored_start = len(out_buf)
            if ne.compression_method == CM_NONE:
                cipher = _encrypt_plaintext(new_raw, pak_rel, ne.encryption_method) if ne.encrypted else new_raw
                ne.offset = len(out_buf)
                ne.size = len(new_raw)
                out_buf += cipher
            else:
                cs = template_entry.compression_block_size if template_entry.compression_block_size > 0 else 65536
                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                order = _block_permutation(len(chunks), ne.encryption_method)
                cipher_by_logical = []
                for chunk in chunks:
                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                    cipher = _encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed
                    cipher_by_logical.append(cipher)
                inv = [0] * len(chunks)
                for logical_i, phys_i in enumerate(order):
                    inv[phys_i] = logical_i
                new_blks = [None] * len(chunks)
                for phys_i in range(len(chunks)):
                    blk = PakCompressedBlock.__new__(PakCompressedBlock)
                    blk.start = len(out_buf)
                    blk.end = blk.start + len(cipher_by_logical[inv[phys_i]])
                    out_buf += cipher_by_logical[inv[phys_i]]
                    new_blks[phys_i] = blk
                ne.compressed_blocks = new_blks
                ne.offset = new_blks[0].start if new_blks else len(out_buf)
                ne.size = sum((b.end - b.start for b in new_blks))
            stored_bytes = bytes(out_buf[ne.offset:ne.offset + ne.size])
            ne.content_hash = SHA1.new(stored_bytes).digest()
            new_files.append(ne)
            all_dirs.setdefault(dir_key, {})[p.name] = ne
            file_rows.append((fp, ne.uncompressed_size, ne.size))
            progress.update(task, advance=1, description=f'{p.name}')
    summary = Table(title=f'Files Added to New PAK  · {CREDIT}', box=ROUNDED, border_style='white')
    summary.add_column('Path in PAK', style='white')
    summary.add_column('Original Size', justify='right', style='dim')
    summary.add_column('Stored Size', justify='right', style='dim')
    for fp, orig_sz, stored_sz in file_rows:
        summary.add_row(fp, human_size(orig_sz), human_size(stored_sz))
    console.print(summary)
    id_to_idx = {id(ne): i for i, ne in enumerate(new_files)}
    idx = bytearray(_pw_string(mp_str))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files:
        idx += _pw_entry(ne, version)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, dir_files in all_dirs.items():
        idx += _pw_string(dp_str)
        idx += struct.pack('<Q', len(dir_files))
        for name, e in dir_files.items():
            idx += _pw_string(name)
            idx += struct.pack('<i', ~id_to_idx[id(e)])
    index_plain = bytes(idx)
    new_sha1 = SHA1.new(index_plain).digest()
    if pak_file._pak_info.index_encrypted:
        key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
        iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
        if key and iv and (len(key) == 32) and (len(iv) >= 16):
            aes = AES.new(key, MODE_CBC, iv[:16])
            pad = -len(index_plain) % AES.block_size or AES.block_size
            index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
            index_bytes = index_plain
        index_bytes = index_plain
        new_idx_offset = len(out_buf)
        new_idx_size = len(index_bytes)
        out_buf += index_bytes
        orig_fc = pak_file._file_content
        footer_sz = TencentPakInfo._mem_size(version)
        new_footer = bytearray(orig_fc[-footer_sz:])
        h_key = struct.pack('<5I', *keystream[4:9])
        new_footer[(-36):(-16)] = bytes((a ^ b for a, b in zip(new_sha1, h_key)))
        new_footer[(-16):(-8)] = (new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little')
        new_footer[(-8):] = (new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little')
        out_buf += new_footer
        with open(output_path, 'wb') as f:
            f.write(out_buf)
        console.print(f'[green]New PAK written: {output_path}  [dim]· {CREDIT}[/dim][/]')
        console.print(f'[green]Files included: {len(new_files)}  [dim]· {CREDIT}[/dim][/]')
        try:
            check_pak = TencentPakFile(output_path, is_od=True)
        except AssertionError:
            console.print(f'[red]VERIFICATION FAILED (index hash mismatch)  [dim]({CREDIT})[/dim][/]')
        except Exception as e:
            console.print(f'[red]VERIFICATION FAILED: {e}  [dim]({CREDIT})[/dim][/]')
        return len(new_files)
        index_bytes = index_plain

# === Good functions ===
def hexa_alert(message: str, kind: str='info') -> None:
    tags = {'success': ('✓', 'bold green'), 'error': ('✗', f'bold {DARK_RED}'), 'warning': ('⚠', 'bold yellow'), 'info': ('▶', f'bold {DARK_SKY_LIGHT}')}
    tag, color = tags.get(kind, tags['info'])
    console.print(f'  {tag}  {message}  [dim]| {CREDIT}[/dim]', style=color)

def hexa_section(title: str) -> None:
    console.print()
    console.print(f'  ═══ {title} ═══  [dim]({CREDIT})[/dim]', style=f'bold {DARK_SKY_LIGHT}')
    console.print(f"  {'─' * (len(title) + 8)}", style=MUTED)
CREDIT = 'ALVSIA'
DARK_BLUE = '#0B1E3A'
DARK_SKY = '#1E5AA8'
DARK_SKY_LIGHT = '#6FB1FF'
DARK_RED = '#C62828'
ACCENT = DARK_SKY
GOLD = '#FFD700'
NEON = '#00FFAA'
MUTED = '#888888'
SUCCESS = '#00FF88'
WARN = '#FFAA00'
ERR = '#FF0055'

def mclear():
    os.system('cls' if os.name == 'nt' else 'clear')

def mok(text):
    print(f'  {MC.GREEN}{MC.BOLD}✓{MC.RESET} {MC.WHITE}{text}{MC.RESET}')

def merr(text):
    print(f'  {MC.RED_G}{MC.BOLD}✗{MC.RESET} {MC.RED}{text}{MC.RESET}')

def mwarn(text):
    print(f'  {MC.YELLOW_B}{MC.BOLD}⚠{MC.RESET} {MC.YELLOW}{text}{MC.RESET}')

def minfo(text):
    print(f'  {MC.CYAN_G}{MC.BOLD}ℹ{MC.RESET} {MC.WHITE}{text}{MC.RESET}')

def msection(title):
    print()
    print(f'  {MC.BLUE_G}══ {MC.CYAN_G}{MC.BOLD}{title}{MC.RESET} {MC.BLUE_G}══{MC.RESET}')
    print()

def animate_loading(duration=1.2, text='Loading'):
    start = time.time()
    width = 40
    if time.time() - start < duration:
        progress = (time.time() - start) / duration
        filled = int(width * progress)
        bar = ''
        for i in range(width):
            if i < filled:
                if i < width * 0.25:
                    bar += f'{MC.BLUE_B}█'
                else:
                    if i < width * 0.5:
                        bar += f'{MC.CYAN_B}█'
                    else:
                        if i < width * 0.75:
                            bar += f'{MC.YELLOW_B}█'
                        else:
                            bar += f'{MC.RED_B}█'
            else:
                bar += f'{MC.GRAY}░'
        sys.stdout.write(f'\r  {MC.CYAN}{text}...{MC.RESET} [{bar}{MC.RESET}] {int(progress * 100)}%')
        sys.stdout.flush()
        time.sleep(0.03)
    else:
        print()

def animate_matrix(duration=0.6, width=60):
    chars = 'アイウエオカキクケコサシスセソタチツテトALVSIA'
    start = time.time()
    if time.time() - start < duration:
        line = ''
        for _ in range(width):
            if random.random() < 0.1:
                char = random.choice(chars)
                color = random.choice([MC.BLUE_B, MC.CYAN_B, MC.YELLOW_B])
                line += f'{color}{char}'
            else:
                line += f'{MC.GRAY}·'
        sys.stdout.write(f'\r{line}{MC.RESET}')
        sys.stdout.flush()
        time.sleep(0.05)
    else:
        print()

def animate_spinner(duration=0.6, text='Processing'):
    spinners = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    colors = [MC.BLUE_B, MC.CYAN_B, MC.YELLOW_B, MC.RED_B]
    start = time.time()
    idx = 0
    if time.time() - start < duration:
        s = spinners[idx % len(spinners)]
        c = colors[idx % len(colors)]
        sys.stdout.write(f'\r  {c}{s}{MC.RESET} {MC.WHITE}{text}...{MC.RESET}')
        sys.stdout.flush()
        time.sleep(0.08)
        idx += 1
    else:
        sys.stdout.write(f'\r  {MC.GREEN}✓{MC.RESET} {MC.WHITE}{text} - Done!{MC.RESET}    \n')

def print_banner():
    for line in ALVSIA_ASCII:
        colored = ''
        for j, char in enumerate(line):
            if char == ' ':
                colored += char
            else:
                progress = j / len(line)
                if progress < 0.25:
                    colored += f'{MC.BLUE_G}{MC.BOLD}{char}'
                else:
                    if progress < 0.5:
                        colored += f'{MC.CYAN_G}{MC.BOLD}{char}'
                    else:
                        if progress < 0.75:
                            colored += f'{MC.BLUE_B}{MC.BOLD}{char}'
                        else:
                            colored += f'{MC.CYAN_B}{MC.BOLD}{char}'
        print(f'  {colored}{MC.RESET}')
    print()
    print(f"  {MC.CYAN_G}{'─'*52}{MC.RESET}")
    print(f'  {MC.CYAN}📢{MC.RESET} {MC.WHITE}Telegram:{MC.RESET} {MC.CYAN_B}{MC.BOLD}@ALVSIA_PRO{MC.RESET}')
    print(f'  {MC.CYAN}👑{MC.RESET} {MC.WHITE}Owner:{MC.RESET} {MC.CYAN_B}{MC.BOLD}@OriginalOnwerALV{MC.RESET}')
    print(f'  {MC.YELLOW_B}👨‍💻{MC.RESET} {MC.WHITE}Developer:{MC.RESET} {MC.YELLOW_B}{MC.BOLD}ALVSIA{MC.RESET}')
    print(f'  {MC.BLUE_B}🔧{MC.RESET} {MC.WHITE}Tool:{MC.RESET} {MC.BLUE_B}{MC.BOLD}UNIFIED LUA & PAK{MC.RESET}')
    print(f'  {MC.RED_B}📦{MC.RESET} {MC.WHITE}Version:{MC.RESET} {MC.RED_B}{MC.BOLD}PRO EDITION{MC.RESET}')
    print(f"  {MC.CYAN_G}{'─'*52}{MC.RESET}")
    print(f'  {MC.GRAY}© All Rights Reserved · ALVSIA{MC.RESET}')
    print()

def print_intro():
    mclear()
    print()
    print(f'  {MC.CYAN}Initializing ALVSIA Engine...{MC.RESET}')
    animate_matrix(0.5, 50)
    animate_loading(1.0, 'Loading Modules')
    animate_spinner(0.5, 'System Check')
    print()
    print(f'  {MC.GREEN}{MC.BOLD}✓ Ready!{MC.RESET}')
    print()
    time.sleep(0.3)

def _sm4_c_source() -> str:
    sbox = SM4._S_BOX
    fk = SM4._FK
    ck = SM4._CK
    L = []
    L.append('// auto-generated fast SM4 (GB/T 32907-2016) from tool.py constants')
    L.append('#include <stdint.h>')
    L.append('#include <stddef.h>')
    L.append('')
    L.append('static const uint8_t SBOX[256] = { ' + ', '.join((str(x) for x in sbox)) + ' };')
    L.append('static const uint32_t FK[4] = { ' + ', '.join((hex(x) for x in fk)) + ' };')
    L.append('static const uint32_t CK[32] = { ' + ', '.join((hex(x) for x in ck)) + ' };')
    L.append('')
    L.append('static inline uint32_t rotl(uint32_t x, int n){ return (x << n) | (x >> (32 - n)); }')
    L.append('static inline uint32_t load_be(const uint8_t* p){ return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|(uint32_t)p[3]; }')
    L.append('static inline void store_be(uint8_t* p, uint32_t v){ p[0]=(uint8_t)(v>>24); p[1]=(uint8_t)(v>>16); p[2]=(uint8_t)(v>>8); p[3]=(uint8_t)v; }')
    L.append('static inline uint32_t sb(uint32_t x){ return ((uint32_t)SBOX[(x>>24)&0xff]<<24)|((uint32_t)SBOX[(x>>16)&0xff]<<16)|((uint32_t)SBOX[(x>>8)&0xff]<<8)|(uint32_t)SBOX[x&0xff]; }')
    L.append('static inline uint32_t t0(uint32_t x){ x = sb(x); return x ^ rotl(x,2) ^ rotl(x,10) ^ rotl(x,18) ^ rotl(x,24); }')
    L.append('static inline uint32_t t1(uint32_t x){ x = sb(x); return x ^ rotl(x,13) ^ rotl(x,23); }')
    L.append('')
    L.append('static void expand(const uint8_t* key, uint32_t rk[32]){')
    L.append('    uint32_t k0 = load_be(key) ^ FK[0];')
    L.append('    uint32_t k1 = load_be(key+4) ^ FK[1];')
    L.append('    uint32_t k2 = load_be(key+8) ^ FK[2];')
    L.append('    uint32_t k3 = load_be(key+12) ^ FK[3];')
    L.append('    for (int i = 0; i < 32; i++){')
    L.append('        k0 ^= t1(k1 ^ k2 ^ k3 ^ CK[i]); rk[i] = k0;')
    L.append('        k1 ^= t1(k2 ^ k3 ^ k0 ^ CK[++i]); rk[i] = k1;')
    L.append('        k2 ^= t1(k3 ^ k0 ^ k1 ^ CK[++i]); rk[i] = k2;')
    L.append('        k3 ^= t1(k0 ^ k1 ^ k2 ^ CK[++i]); rk[i] = k3;')
    L.append('    }')
    L.append('}')
    L.append('')
    L.append('static void crypt_block(const uint8_t* in, uint8_t* out, const uint32_t* rk){')
    L.append('    uint32_t x0 = load_be(in);')
    L.append('    uint32_t x1 = load_be(in+4);')
    L.append('    uint32_t x2 = load_be(in+8);')
    L.append('    uint32_t x3 = load_be(in+12);')
    L.append('    for (int i = 0; i < 32; i += 4){')
    L.append('        x0 ^= t0(x1 ^ x2 ^ x3 ^ rk[i]);')
    L.append('        x1 ^= t0(x2 ^ x3 ^ x0 ^ rk[i+1]);')
    L.append('        x2 ^= t0(x3 ^ x0 ^ x1 ^ rk[i+2]);')
    L.append('        x3 ^= t0(x0 ^ x1 ^ x2 ^ rk[i+3]);')
    L.append('    }')
    L.append('    store_be(out, x3); store_be(out+4, x2); store_be(out+8, x1); store_be(out+12, x0);')
    L.append('}')
    L.append('')
    L.append('// ECB transform. encrypt: 1, decrypt: 0. len must be multiple of 16.')
    L.append('void sm4_ecb(const uint8_t* key, const uint8_t* in, uint8_t* out, size_t len, int encrypt){')
    L.append('    uint32_t rk[32];')
    L.append('    expand(key, rk);')
    L.append('    if (!encrypt){')
    L.append('        for (int i = 0; i < 16; i++){ uint32_t tmp = rk[i]; rk[i] = rk[31-i]; rk[31-i] = tmp; }')
    L.append('    }')
    L.append('    for (size_t off = 0; off < len; off += 16){')
    L.append('        crypt_block(in + off, out + off, rk);')
    L.append('    }')
    L.append('}')
    return '\n'.join(L)

def dump_unpacking_log(pak_file, output_log_path: Path):
    with open(output_log_path, 'w', encoding='utf-8') as log_file:
        log_file.write('================================================================================\n')
        log_file.write('PAK UNPACKING DEBUG LOG\n')
        log_file.write('================================================================================\n\n')
        log_file.write(f'PAK File: {pak_file._file_path}\n')
        log_file.write(f'PAK Info Version: {pak_file._pak_info.version}\n')
        log_file.write(f'Mount Point: {pak_file._mount_point}\n')
        log_file.write('--------------------------------------------------------------------------------\n\n')
        file_count = 0
        for dir_path, files in pak_file._index.items():
            for file_name, entry in files.items():
                file_count += 1
                full_path = str(PurePath(dir_path) / file_name).replace('\\', '/')
                log_file.write(f'\n[{file_count}] {full_path}\n')
                log_file.write(f'  Uncompressed Size: {entry.uncompressed_size:,} bytes\n')
                log_file.write(f'  Compressed Size: {entry.size:,} bytes\n')
                log_file.write(f'  Compression Method: {entry.compression_method}\n')
                log_file.write(f'  Encryption Method: {entry.encryption_method}\n')
                log_file.write(f'  Compressed Blocks: {len(entry.compressed_blocks)}\n')
                if entry.compressed_blocks:
                    for i, blk in enumerate(entry.compressed_blocks):
                        block_size = blk.end - blk.start
                        log_file.write(f'    Block {i}: Offset={blk.start:,} Size={block_size:,} bytes\n')
        log_file.write('\n================================================================================\n')
        log_file.write('END OF LOG\n')
        log_file.write('================================================================================\n')
    console.print(f'[bold #00FF88]✅ Debug log saved to: {output_log_path}[/bold #00FF88]')

def _zstd_add_skippable_padding(data: bytes, pad_len: int) -> bytes:
    if pad_len <= 0:
        return data
    else:
        out = bytearray(data)
        if pad_len > 0:
            frame_len = min(max(pad_len - 8, 0), 1048576)
            out += b'P*M\x18'
            out += struct.pack('<I', frame_len)
            out += b'\x00' * frame_len
            pad_len -= 8 + frame_len
        else:
            return bytes(out)

def _encrypt_plaintext(plaintext: bytes, pak_relative_path: PurePath, encryption_method: int) -> bytes:
    if PakCrypto._is_simple1_method(encryption_method):
        return bytes((b ^ SIMPLE1_DECRYPT_KEY for b in plaintext))
    else:
        if PakCrypto._is_simple2_method(encryption_method):
            pad = -len(plaintext) % SIMPLE2_BLOCK_SIZE
            plaintext += b'\x00' * pad
            key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
            rolling = key
            out = []
            for x, in struct.iter_unpack('<I', plaintext):
                c = rolling ^ x
                out.append(c)
                rolling ^= c
            return struct.pack(f'<{len(out)}I', *out)
        else:
            if PakCrypto._is_sm4_method(encryption_method):
                key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)
                sm4 = PakCrypto._sm4_context_for_key(key)
                pad_len = -len(plaintext) % 16
                if pad_len > 0:
                    plaintext = plaintext + b'\x00' * pad_len
                return sm4.encrypt_bulk(plaintext)
            else:
                return plaintext

def _repack_uncompressed(outfh, pak_file, entry, pak_relative_path: PurePath, new_data: bytes):
    enc_method = entry.encryption_method
    target_size = entry.size
    enc_region = PakCrypto.align_encrypted_content_size(target_size, enc_method) if entry.encrypted else target_size
    plaintext = new_data[:enc_region]
    if entry.encrypted:
        a = PakCrypto.align_encrypted_content_size(len(plaintext), enc_method)
        plaintext += b'\x00' * (a - len(plaintext))
        cipher = _encrypt_plaintext(plaintext, pak_relative_path, enc_method)
        outfh.seek(entry.offset)
        outfh.write(cipher)
        with open(pak_file._file_path, 'rb') as src:
            src.seek(entry.offset + len(cipher))
            outfh.write(src.read(enc_region - len(cipher)))
    else:
        outfh.seek(entry.offset)
        outfh.write(plaintext)
        with open(pak_file._file_path, 'rb') as src:
            src.seek(entry.offset + len(plaintext))
            outfh.write(src.read(target_size - len(plaintext)))

def _best_compress(chunk, cm, zstd_dict=None, fast=False):
    """Compress one chunk. fast=True (protect path) uses quick levels."""
    if cm == CM_ZLIB:
        return zlib.compress(chunk, 1 if fast else 9)
    else:
        if cm in (CM_ZSTD, CM_ZSTD_DICT):
            zd = zstd_dict if cm == CM_ZSTD_DICT else None
            levels = [6, 3, 1] if fast else [22, 19, 16, 13, 10, 7, 4, 1]
            for lvl in levels:
                try:
                    return ZstdCompressor(level=lvl, dict_data=zd, threads=1).compress(chunk)
                except Exception:
                    pass
                else:
                    pass
        return chunk

def _pw_string(s):
    """PAK string serialiser: i4(len_with_null) + bytes + null."""
    if not s:
        return struct.pack('<i', 0)
    else:
        b = s.encode('utf-8') + b'\x00'
        return struct.pack('<i', len(b)) + b

def _pw_entry(e, v):
    """Serialise one TencentPakEntry back to bytes."""
    w = bytearray(e.content_hash)
    w += struct.pack('<Q', e.offset)
    w += struct.pack('<Q', e.uncompressed_size)
    w += struct.pack('<I', e.compression_method)
    w += struct.pack('<Q', e.size)
    if v >= 5:
        w += bytes([e.unk1])
        w += e.unk2
    if e.compression_method != CM_NONE and v >= 3:
            w += struct.pack('<I', len(e.compressed_blocks))
            for b in e.compressed_blocks:
                w += struct.pack('<QQ', b.start, b.end)
    if v >= 4:
        w += struct.pack('<I', e.compression_block_size)
        w += bytes([1 if e.encrypted else 0])
    if v >= 12:
        w += struct.pack('<II', e.encryption_method, e.index_new_sep)
    return bytes(w)

def _get_all_dirs_and_mp(pak_file):
    """Re-parse raw (possibly encrypted) index → (mount_point_str, ordered dirs dict)."""
    raw = bytes(pak_file._file_content[pak_file._pak_info.index_offset:][:pak_file._pak_info.index_size])
    if pak_file._pak_info.index_encrypted:
        raw = PakCrypto.decrypt_index(raw, pak_file._pak_info)
    r = Reader(raw)
    mp = r.string()
    num_files = r.u4()
    for _ in range(num_files):
        TencentPakEntry(r, pak_file._pak_info.version)
    dirs = {}
    for _ in range(r.u8()):
        dp = r.string()
        cnt = r.u8()
        dirs[dp] = {r.string(): pak_file._files[~r.i4()] for _ in range(cnt)}
    return (mp, dirs)

def repack_pak_file_full(pak_file, edited_root, output_path, target_path=None, force_add=False):
    # irreducible cflow, using cdg fallback
    """\nFULL REBUILD REPACK - FIXED FOR NEW FILES (OPTION 4)\n"""
    import copy as _cp
    console.print('[bold cyan]📦 Full PAK Rebuild mode (Option 3 & 4 logic)[/bold cyan]')
    if target_path:
        console.print(f'[bold cyan]🎯 Target path: {target_path}[/bold cyan]')
    edit_files = []
    for p in Path(edited_root).rglob('*'):
        if p.is_file():
            edit_files.append(p)
    if not edit_files:
        console.print('[bold red]❌ No files found in EDIT folder![/bold red]')
        return 0
    else:
        console.print(f'[bold cyan]📁 Found {len(edit_files)} files in EDIT folder[/bold cyan]')
        version = pak_file._pak_info.version
        keystream = PakCrypto.zuc_keystream()
        orig_fc = pak_file._file_content
        mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)
        if target_path and force_add:
                target_path = target_path.replace('\\', '/')
                matched_dir = None
                for existing_dir in all_dirs.keys():
                    if existing_dir.strip('/').lower() == target_path.strip('/').lower():
                        matched_dir = existing_dir
                        break
                if matched_dir:
                    target_path = matched_dir
                else:
                    target_path = target_path.strip('/') + '/'
        pak_name_map = {}
        for dir_path, files in pak_file._index.items():
            for name, entry in files.items():
                full_path = str(PurePath(dir_path) / name).replace('\\', '/')
                pak_name_map.setdefault(name.lower(), []).append((full_path, entry))
        edited = {}
        for p in edit_files:
            fl = p.name.lower()
            found_match = False
            if fl in pak_name_map:
                cands = pak_name_map[fl]
                if target_path:
                    target_candidates = [(fp, e) for fp, e in cands if target_path.strip('/') in fp]
                    if target_candidates:
                        sz = p.stat().st_size
                        sm = [(fp, e) for fp, e in target_candidates if e.uncompressed_size == sz]
                        fp, ent = sm[0] if sm else target_candidates[0]
                        edited[fp] = (p, ent)
                        found_match = True
                if not found_match:
                    sz = p.stat().st_size
                    sm = [(fp, e) for fp, e in cands if e.uncompressed_size == sz]
                    fp, ent = sm[0] if sm else cands[0]
                    if target_path:
                        new_fp = f'{target_path.rstrip("/")}/{p.name}'
                        edited[new_fp] = (p, ent)
                    else:
                        edited[fp] = (p, ent)
                    found_match = True
            if not found_match:
                stem = p.stem.lower()
                ext = p.suffix.lower()
                for dir_path, files in pak_file._index.items():
                    for name, entry in files.items():
                        if Path(name).stem.lower() == stem and Path(name).suffix.lower() == ext:
                            full_path = str(PurePath(dir_path) / name).replace('\\', '/')
                            if target_path:
                                new_fp = f'{target_path.rstrip("/")}/{p.name}'
                                edited[new_fp] = (p, entry)
                            else:
                                edited[full_path] = (p, entry)
                            found_match = True
                            break
                    if found_match:
                        break
            if not found_match and force_add and target_path:
                template_entry = None
                for dir_path, files in pak_file._index.items():
                    for name, entry in files.items():
                        if Path(name).suffix.lower() == p.suffix.lower():
                            template_entry = entry
                            break
                    if template_entry:
                        break
                if not template_entry:
                    for dir_path, files in pak_file._index.items():
                        for name, entry in files.items():
                            template_entry = entry
                        if template_entry:
                            break
                if template_entry:
                    new_fp = f'{target_path.rstrip("/")}/{p.name}'
                    edited[new_fp] = (p, template_entry)
    if not edited:
        console.print('[bold red]❌ No files to repack![/bold red]')
        return 0
    else:
        console.print(f'  [bold bright_cyan]📁 Files to repack: {len(edited)}[/bold bright_cyan]')
        new_files = []
        for e in pak_file._files:
            ne = _cp.copy(e)
            ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]
            new_files.append(ne)
        old_to_new = {id(pak_file._files[i]): new_files[i] for i in range(len(pak_file._files))}
        edited_paths = {fp: p for fp, (p, _) in edited.items()}
        out_buf = bytearray()
        for dp_str, dir_files in list(all_dirs.items()):
            for name, old_entry in list(dir_files.items()):
                full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                ne = old_to_new.get(id(old_entry), None)
                if ne is None:
                    ne = _cp.copy(old_entry)
                    ne.compressed_blocks = [_cp.copy(b) for b in old_entry.compressed_blocks]
                    new_files.append(ne)
                    old_to_new[id(old_entry)] = ne
                em = old_entry.encryption_method
                cm = old_entry.compression_method
                if full_path in edited_paths:
                    p, template = edited[full_path]
                    new_raw = p.read_bytes()
                    pak_rel = PurePath(full_path)
                    ne.content_hash = SHA1.new(new_raw).digest()
                    ne.uncompressed_size = len(new_raw)
                    ne.compression_method = template.compression_method if template else cm
                    ne.encryption_method = template.encryption_method if template else em
                    ne.encrypted = template.encrypted if template else old_entry.encrypted
                    ne.unk1 = template.unk1 if template else old_entry.unk1
                    if template and target_path:
                        full_path_str = mp_str + full_path
                        ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
                    else:
                        ne.unk2 = template.unk2 if template else old_entry.unk2
                    ne.index_new_sep = template.index_new_sep if template else old_entry.index_new_sep
                    if ne.compression_method == CM_NONE:
                        cipher = _encrypt_plaintext(new_raw, pak_rel, ne.encryption_method) if ne.encrypted else new_raw
                        ne.offset = len(out_buf)
                        ne.size = len(new_raw)
                        ne.uncompressed_size = len(new_raw)
                        out_buf += cipher
                    else:
                        cs = template.compression_block_size if template and template.compression_block_size > 0 else old_entry.compression_block_size if old_entry.compression_block_size > 0 else 65536
                        chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                        new_blks = []
                        for chunk in chunks:
                            compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                            cipher = _encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed
                            blk = PakCompressedBlock.__new__(PakCompressedBlock)
                            blk.start = len(out_buf)
                            blk.end = blk.start + len(cipher)
                            out_buf += cipher
                            new_blks.append(blk)
                        ne.compressed_blocks = new_blks
                        ne.offset = new_blks[0].start if new_blks else len(out_buf)
                        ne.size = sum((b.end - b.start for b in new_blks))
                        ne.uncompressed_size = len(new_raw)
                    console.print(f'[green]✓ Processed: {full_path}[/green]')
                else:
                    if cm == CM_NONE:
                        read_sz = PakCrypto.align_encrypted_content_size(old_entry.size, em) if old_entry.encrypted else old_entry.size
                        ne.offset = len(out_buf)
                        out_buf += bytes(orig_fc[old_entry.offset:old_entry.offset + read_sz])
                    else:
                        if old_entry.compressed_blocks:
                            new_blks = []
                            for ob in old_entry.compressed_blocks:
                                unc = ob.end - ob.start
                                enc = PakCrypto.align_encrypted_content_size(unc, em) if old_entry.encrypted else unc
                                nb = PakCompressedBlock.__new__(PakCompressedBlock)
                                nb.start = len(out_buf)
                                nb.end = nb.start + unc
                                out_buf += bytes(orig_fc[ob.start:ob.start + enc])
                                new_blks.append(nb)
                            ne.compressed_blocks = new_blks
                            ne.offset = new_blks[0].start
        if target_path and force_add:
                for fp, (p, template) in edited.items():
                    already_processed = False
                    for dp_str, dir_files in all_dirs.items():
                        for name, entry in dir_files.items():
                            if str(PurePath(dp_str) / name).replace('\\', '/') == fp:
                                already_processed = True
                                break
                        if already_processed:
                            break
                    if not already_processed:
                        ne = _cp.copy(template)
                        new_raw = p.read_bytes()
                        pak_rel = PurePath(fp)
                        ne.content_hash = SHA1.new(new_raw).digest()
                        ne.uncompressed_size = len(new_raw)
                        ne.compression_method = template.compression_method
                        ne.encryption_method = template.encryption_method
                        ne.encrypted = template.encrypted
                        ne.unk1 = template.unk1
                        full_path_str = mp_str + fp
                        ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
                        ne.index_new_sep = template.index_new_sep
                        if ne.compression_method == CM_NONE:
                            cipher = _encrypt_plaintext(new_raw, pak_rel, ne.encryption_method) if ne.encrypted else new_raw
                            ne.offset = len(out_buf)
                            ne.size = len(new_raw)
                            ne.uncompressed_size = len(new_raw)
                            out_buf += cipher
                        else:
                            cs = template.compression_block_size if template.compression_block_size > 0 else 65536
                            chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                            new_blks = []
                            for chunk in chunks:
                                compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                                cipher = _encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed
                                blk = PakCompressedBlock.__new__(PakCompressedBlock)
                                blk.start = len(out_buf)
                                blk.end = blk.start + len(cipher)
                                out_buf += cipher
                                new_blks.append(blk)
                            ne.compressed_blocks = new_blks
                            ne.offset = new_blks[0].start if new_blks else len(out_buf)
                            ne.size = sum((b.end - b.start for b in new_blks))
                            ne.uncompressed_size = len(new_raw)
                        new_files.append(ne)
                        if target_path not in all_dirs:
                            all_dirs[target_path] = {}
                        all_dirs[target_path][p.name] = ne
                        console.print(f'[green]✓ Added new: {fp}[/green]')
        eidx = {id(new_files[i]): i for i in range(len(new_files))}
        old_id_to_new_idx = {id(pak_file._files[i]): i for i in range(len(pak_file._files))}
        idx = bytearray(_pw_string(mp_str))
        idx += struct.pack('<I', len(new_files))
        for ne in new_files:
            idx += _pw_entry(ne, version)
        idx += struct.pack('<Q', len(all_dirs))
        for dp_str, dir_files in all_dirs.items():
            idx += _pw_string(dp_str)
            idx += struct.pack('<Q', len(dir_files))
            for name, old_e in dir_files.items():
                idx += _pw_string(name)
                found_idx = eidx.get(id(old_e))
                if found_idx is None:
                    found_idx = old_id_to_new_idx.get(id(old_e))
                if found_idx is None:
                    copy_of = next((k for k, v in old_to_new.items() if v is old_e), None)
                    if copy_of is not None:
                        found_idx = eidx.get(id(old_to_new[copy_of]))
                if found_idx is None:
                    for i, e in enumerate(new_files):
                        if e.offset == old_e.offset and e.size == old_e.size:
                                found_idx = i
                                break
                if found_idx is not None:
                    idx += struct.pack('<i', ~found_idx)
                else:
                    idx += struct.pack('<i', (-1))
        index_plain = bytes(idx)
        new_sha1 = SHA1.new(index_plain).digest()
        if pak_file._pak_info.index_encrypted:
            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
            aes = AES.new(key, MODE_CBC, iv[:16])
            pad = -len(index_plain) % AES.block_size or AES.block_size
            index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
        else:
            index_bytes = index_plain
        new_idx_offset = len(out_buf)
        new_idx_size = len(index_bytes)
        out_buf += index_bytes
        footer_sz = TencentPakInfo._mem_size(version)
        new_footer = bytearray(orig_fc[-footer_sz:])
        h_key = struct.pack('<5I', *keystream[4:9])
        new_footer[(-36):(-16)] = bytes((a ^ b for a, b in zip(new_sha1, h_key)))
        new_footer[(-16):(-8)] = (new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little')
        new_footer[(-8):] = (new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little')
        out_buf += new_footer
        with open(output_path, 'wb') as f:
            f.write(out_buf)
        return len(edited)

def _normalize_dir_key(path_str):
    """\'a/b/c\' or \'a/b/c/\' -> \'a/b/c/\'"""
    s = str(path_str).replace('\\', '/').strip('/')
    return s + '/' if s else ''

def _find_existing_dir(all_dirs, want_dir):
    want = _normalize_dir_key(want_dir).strip('/').lower()
    if not want:
        return ''
    else:
        for k in all_dirs:
            if k.strip('/').lower() == want:
                return k
        best = None
        for k in all_dirs:
            key = k.strip('/').lower()
            if key and want.endswith('/' + key):
                    if best is None or len(key) > len(best):
                        best = k
        return best

def _strip_mount_prefix(pak_file, rel_dir):
    """Strip the pak\'s mount point from a user-supplied in-pak path."""
    mp = str(pak_file._mount_point).replace('\\', '/').strip('/')
    rd = str(rel_dir).replace('\\', '/').strip('/')
    if mp and (rd.lower() == mp.lower() or rd.lower().startswith(mp.lower() + '/')):
        return rd[len(mp):].lstrip('/')
    else:
        return rd

def _pick_template(pak_file, all_dirs, target_dir, file_name):
    ext = Path(file_name).suffix.lower()
    if target_dir in all_dirs:
        for name, e in all_dirs[target_dir].items():
            if Path(name).suffix.lower() == ext:
                return e
    for dp, files in all_dirs.items():
        for name, e in files.items():
            if Path(name).suffix.lower() == ext:
                return e
    for dp, files in all_dirs.items():
        for name, e in files.items():
            return e
    return pak_file._files[0] if pak_file._files else None

def _default_compression(pak_file):
    """Pick the pak\'s dominant compression method for newly added files."""
    cm_counter = {}
    for e in pak_file._files:
        cm = e.compression_method
        if cm in (CM_ZLIB, CM_ZSTD, CM_ZSTD_DICT):
            cm_counter[cm] = cm_counter.get(cm, 0) + 1
    if pak_file._is_zstd_with_dict and cm_counter.get(CM_ZSTD_DICT, 0):
        return CM_ZSTD_DICT
    else:
        if cm_counter.get(CM_ZSTD, 0):
            return CM_ZSTD
        else:
            if cm_counter.get(CM_ZSTD_DICT, 0):
                return CM_ZSTD
            else:
                return CM_ZLIB

def _write_entry_content(out_buf, ne, plaintext, pak_rel, zstd_dict, fast=False):
    """Encode one entry\'s plaintext into out_buf (compress + encrypt), updating ne."""
    if ne.compression_method == CM_NONE:
        cipher = _encrypt_plaintext(plaintext, pak_rel, ne.encryption_method) if ne.encrypted else plaintext
        ne.offset = len(out_buf)
        ne.size = len(plaintext)
        ne.uncompressed_size = len(plaintext)
        out_buf += cipher
        return
    else:
        cs = ne.compression_block_size if ne.compression_block_size > 0 else 65536
        chunks = [plaintext[i:i + cs] for i in range(0, len(plaintext), cs)]
        if not chunks:
            ne.compressed_blocks = []
            ne.offset = len(out_buf)
            ne.size = 0
            ne.uncompressed_size = 0
            return
        else:
            n = len(chunks)
            inv = PakCrypto.generate_block_indices(n, ne.encryption_method) if ne.encrypted else list(range(n))
            file_order = [0] * n
            for j in range(n):
                file_order[inv[j]] = j
            new_blks = [None] * n
            for k in range(n):
                chunk = chunks[file_order[k]]
                compressed = _best_compress(chunk, ne.compression_method, zstd_dict, fast=fast)
                cipher = _encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed
                blk = PakCompressedBlock.__new__(PakCompressedBlock)
                blk.start = len(out_buf)
                blk.end = blk.start + len(cipher)
                out_buf += cipher
                new_blks[k] = blk
            ne.compressed_blocks = new_blks
            ne.offset = new_blks[0].start
            ne.size = sum((b.end - b.start for b in new_blks))
            ne.uncompressed_size = len(plaintext)

def _extract_entry_plaintext(pak_file, entry, full_path):
    em = entry.encryption_method
    cm = entry.compression_method
    path = PurePath(full_path)
    if cm == CM_NONE:
        data = pak_file._peek_content(entry.offset, entry.size, em)
        if entry.encrypted:
            data = PakCrypto.decrypt_block(data, path, em)
        return bytes(data[:entry.uncompressed_size])
    else:
        out = bytearray()
        for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), em):
            data = pak_file._peek_block_content(entry.compressed_blocks[x], em)
            if entry.encrypted:
                data = PakCrypto.decrypt_block(data, path, em)
            out += PakCompression.decompress_block(data, pak_file._zstd_dict, cm)
        return bytes(out)

def _copy_original_content(out_buf, pak_file, ne, old_entry):
    """Copy an un-modified entry\'s content into out_buf, rewriting offsets."""
    em = old_entry.encryption_method
    if old_entry.compression_method == CM_NONE:
        read_sz = PakCrypto.align_encrypted_content_size(old_entry.size, em) if old_entry.encrypted else old_entry.size
        ne.offset = len(out_buf)
        out_buf += bytes(pak_file._file_content[old_entry.offset:old_entry.offset + read_sz])
    else:
        if old_entry.compressed_blocks:
            new_blks = []
            for ob in old_entry.compressed_blocks:
                unc = ob.end - ob.start
                enc = PakCrypto.align_encrypted_content_size(unc, em) if old_entry.encrypted else unc
                nb = PakCompressedBlock.__new__(PakCompressedBlock)
                nb.start = len(out_buf)
                nb.end = nb.start + unc
                out_buf += bytes(pak_file._file_content[ob.start:ob.start + enc])
                new_blks.append(nb)
            ne.compressed_blocks = new_blks
            ne.offset = new_blks[0].start
    ne.encryption_method = old_entry.encryption_method
    ne.encrypted = old_entry.encrypted

def _write_pak_index_footer(pak_file, mp_str, all_dirs, new_files, old_to_new, out_buf, output_path):
    """Write index + footer for a rebuilt pak (correct identity-based mapping)."""
    version = pak_file._pak_info.version
    keystream = PakCrypto.zuc_keystream()
    eidx = {id(new_files[i]): i for i in range(len(new_files))}
    old_id_to_new_idx = {id(pak_file._files[i]): i for i in range(len(pak_file._files))}
    idx = bytearray(_pw_string(mp_str))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files:
        idx += _pw_entry(ne, version)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, dir_files in all_dirs.items():
        idx += _pw_string(dp_str)
        idx += struct.pack('<Q', len(dir_files))
        for name, old_e in dir_files.items():
            idx += _pw_string(name)
            found_idx = eidx.get(id(old_e))
            if found_idx is None:
                found_idx = old_id_to_new_idx.get(id(old_e))
            if found_idx is None:
                copy_of = next((k for k, v in old_to_new.items() if v is old_e), None)
                if copy_of is not None:
                    found_idx = eidx.get(id(old_to_new[copy_of]))
            if found_idx is None:
                for i, e in enumerate(new_files):
                    if e.offset == old_e.offset and e.size == old_e.size:
                            found_idx = i
                            break
            idx += struct.pack('<i', ~found_idx if found_idx is not None else (-1))
    index_plain = bytes(idx)
    new_sha1 = SHA1.new(index_plain).digest()
    if pak_file._pak_info.index_encrypted:
        key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
        iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
        aes = AES.new(key, MODE_CBC, iv[:16])
        pad = -len(index_plain) % AES.block_size or AES.block_size
        index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
    else:
        index_bytes = index_plain
    new_idx_offset = len(out_buf)
    new_idx_size = len(index_bytes)
    out_buf += index_bytes
    footer_sz = TencentPakInfo._mem_size(version)
    new_footer = bytearray(pak_file._file_content[-footer_sz:])
    h_key = struct.pack('<5I', *keystream[4:9])
    new_footer[(-36):(-16)] = bytes((a ^ b for a, b in zip(new_sha1, h_key)))
    new_footer[(-16):(-8)] = (new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little')
    new_footer[(-8):] = (new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little')
    out_buf += new_footer
    with open(output_path, 'wb') as f:
        f.write(out_buf)

def inject_edit_files(pak_file, edit_root, output_path, protect_new=False, sm4_type=50):
    """Inject/edit MULTIPLE files from edit_root into the pak.\n\nEach file\'s relative path inside edit_root is preserved as its path inside\nthe pak (mount point excluded). Existing entries are replaced (any size),\nnew entries are added. Optionally encrypt injected files with game-native\nSM4 so they are never stored in plaintext.\n"""
    import copy as _cp
    version = pak_file._pak_info.version
    if version < 12:
        raise ValueError(f'Unsupported pak version: {version} (need >= 12)')
    else:
        edit_files = [p for p in Path(edit_root).rglob('*') if p.is_file()]
        if not edit_files:
            raise ValueError(f'No files found in EDIT folder: {edit_root}')
        else:
            mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)
            injections = {}
            for p in edit_files:
                rel = p.relative_to(edit_root)
                parts = rel.parts
                file_name = parts[(-1)]
                rel_dir = '/'.join(parts[:(-1)]).replace('\\', '/')
                rel_dir = _strip_mount_prefix(pak_file, rel_dir)
                target_dir = _find_existing_dir(all_dirs, rel_dir) if rel_dir.strip('/') else ''
                if target_dir is None:
                    target_dir = _normalize_dir_key(rel_dir)
                existing = None
                if target_dir in all_dirs:
                    for name, e in list(all_dirs[target_dir].items()):
                        if name.lower() == file_name.lower():
                            existing = (name, e)
                            break
                if existing:
                    full_path = target_dir + existing[0]
                    injections[full_path] = (p, existing[1], False)
                else:
                    full_path = target_dir + file_name
                    template = _pick_template(pak_file, all_dirs, target_dir, file_name)
                    injections[full_path] = (p, template, True)
                console.print(f"  [bold green]●[/bold green] [white]{full_path}[/white] [dim]({('replace existing' if existing else 'add new')})[/dim]")
            new_files = []
            for e in pak_file._files:
                ne = _cp.copy(e)
                ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]
                new_files.append(ne)
            old_to_new = {id(pak_file._files[i]): new_files[i] for i in range(len(pak_file._files))}
            out_buf = bytearray()
            edited_count = 0
            new_count = 0
            for dp_str, dir_files in list(all_dirs.items()):
                for name, old_entry in list(dir_files.items()):
                    full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                    ne = old_to_new.get(id(old_entry), None)
                    if ne is None:
                        ne = _cp.copy(old_entry)
                        ne.compressed_blocks = [_cp.copy(b) for b in old_entry.compressed_blocks]
                        new_files.append(ne)
                        old_to_new[id(old_entry)] = ne
                    if full_path in injections:
                        p, template, is_new = injections[full_path]
                        new_raw = p.read_bytes()
                        pak_rel = PurePath(full_path)
                        ne.content_hash = SHA1.new(new_raw).digest()
                        ne.uncompressed_size = len(new_raw)
                        if is_new:
                            ne.compression_method = _default_compression(pak_file)
                            if protect_new:
                                ne.encryption_method = sm4_type
                                ne.encrypted = True
                            else:
                                ne.encryption_method = template.encryption_method if template else 0
                                ne.encrypted = template.encrypted if template else False
                            ne.unk1 = template.unk1 if template else 0
                            ne.compression_block_size = template.compression_block_size if template and template.compression_block_size > 0 else 65536
                            ne.index_new_sep = template.index_new_sep if template else 0
                            new_count += 1
                        else:
                            ne.compression_method = old_entry.compression_method
                            if protect_new:
                                ne.encryption_method = sm4_type
                                ne.encrypted = True
                            else:
                                ne.encryption_method = old_entry.encryption_method
                                ne.encrypted = old_entry.encrypted
                            ne.unk1 = old_entry.unk1
                            ne.compression_block_size = old_entry.compression_block_size if old_entry.compression_block_size > 0 else 65536
                            ne.index_new_sep = old_entry.index_new_sep
                            edited_count += 1
                        ne.unk2 = SHA1.new((mp_str + full_path).lower().encode('utf-8')).digest()
                        _write_entry_content(out_buf, ne, new_raw, pak_rel, pak_file._zstd_dict)
                        console.print(f"  [bold #00FF88]✓[/bold #00FF88] [green]{('Edited' if not is_new else 'Added')}[/green]: {full_path} [dim]({len(new_raw):,} bytes)[/dim]")
                    else:
                        _copy_original_content(out_buf, pak_file, ne, old_entry)
            for full_path, (p, template, is_new) in injections.items():
                if is_new:
                    already = False
                    for dp_str, dir_files in all_dirs.items():
                        for name, entry in dir_files.items():
                            if str(PurePath(dp_str) / name).replace('\\', '/') == full_path:
                                already = True
                                break
                        if already:
                            break
                    if already:
                        continue
                    else:
                        ne = _cp.copy(template) if template else None
                        if ne is None:
                            ne = TencentPakEntry(Reader(b''), version)
                            ne.compression_method = CM_NONE
                            ne.encrypted = False
                        else:
                            ne.compressed_blocks = [_cp.copy(b) for b in template.compressed_blocks]
                        new_raw = p.read_bytes()
                        pak_rel = PurePath(full_path)
                        ne.content_hash = SHA1.new(new_raw).digest()
                        ne.uncompressed_size = len(new_raw)
                        ne.compression_method = _default_compression(pak_file)
                        if protect_new:
                            ne.encryption_method = sm4_type
                            ne.encrypted = True
                        else:
                            ne.encryption_method = template.encryption_method if template else 0
                            ne.encrypted = template.encrypted if template else False
                        ne.unk1 = template.unk1 if template else 0
                        ne.compression_block_size = template.compression_block_size if template and template.compression_block_size > 0 else 65536
                        ne.index_new_sep = template.index_new_sep if template else 0
                        ne.unk2 = SHA1.new((mp_str + full_path).lower().encode('utf-8')).digest()
                        _write_entry_content(out_buf, ne, new_raw, pak_rel, pak_file._zstd_dict)
                        new_files.append(ne)
                        old_to_new[id(ne)] = ne
                        dp_key = full_path.rsplit('/', 1)[0] + '/' if '/' in full_path else ''
                        all_dirs.setdefault(dp_key, {})[full_path.rsplit('/', 1)[(-1)]] = ne
                        new_count += 1
                        console.print(f'  [bold #00FF88]✓[/bold #00FF88] [green]Added[/green]: {full_path} [dim]({len(new_raw):,} bytes)[/dim]')
            _write_pak_index_footer(pak_file, mp_str, all_dirs, new_files, old_to_new, out_buf, output_path)
            return (edited_count, new_count)

def protect_pak_file(pak_file, output_path, sm4_type=50):
    """Re-encrypt every entry with game-native SM4 and rebuild the pak.\n\nNo plaintext remains: generic unpackers cannot read the content while the\ngame still decrypts it normally (SM4 types are the game\'s own methods).\n"""
    import copy as _cp
    version = pak_file._pak_info.version
    if version < 12:
        raise ValueError(f'Unsupported pak version: {version} (need >= 12)')
    else:
        mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)
        new_files = []
        for e in pak_file._files:
            ne = _cp.copy(e)
            ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]
            new_files.append(ne)
        old_to_new = {id(pak_file._files[i]): new_files[i] for i in range(len(pak_file._files))}
        out_buf = bytearray()
        protected = 0
        skipped = 0
        for dp_str, dir_files in list(all_dirs.items()):
            for name, old_entry in list(dir_files.items()):
                full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                ne = old_to_new.get(id(old_entry), None)
                if ne is None:
                    ne = _cp.copy(old_entry)
                    ne.compressed_blocks = [_cp.copy(b) for b in old_entry.compressed_blocks]
                    new_files.append(ne)
                    old_to_new[id(old_entry)] = ne
                is_marker = old_entry.compression_method == CM_NONE and old_entry.size == 0
                is_zdict = pak_file._zstd_dict_entry is not None and old_entry is pak_file._zstd_dict_entry
                if is_marker or is_zdict:
                    _copy_original_content(out_buf, pak_file, ne, old_entry)
                    skipped += 1
                    continue
                else:
                    try:
                        plaintext = _extract_entry_plaintext(pak_file, old_entry, full_path)
                    except Exception:
                        _copy_original_content(out_buf, pak_file, ne, old_entry)
                        skipped += 1
                        console.print(f'  [bold red]![/bold red] [red]Skipped undecryptable[/red]: {full_path}')
                    else:
                        ne.compression_method = old_entry.compression_method
                        if ne.compression_method == CM_NONE:
                            ne.compression_method = CM_ZLIB
                        ne.encryption_method = sm4_type
                        ne.encrypted = True
                        ne.unk1 = old_entry.unk1
                        ne.unk2 = old_entry.unk2
                        ne.index_new_sep = old_entry.index_new_sep
                        ne.compression_block_size = old_entry.compression_block_size if old_entry.compression_block_size > 0 else 65536
                        _write_entry_content(out_buf, ne, plaintext, PurePath(full_path), pak_file._zstd_dict, fast=True)
                        protected += 1
                        if protected <= 12 or protected % 250 == 0:
                            console.print(f'  [bold #FF00FF]🔒[/bold #FF00FF] [magenta]Re-encrypted[/magenta]: {full_path} [dim]({len(plaintext):,} bytes)[/dim]')
        _write_pak_index_footer(pak_file, mp_str, all_dirs, new_files, old_to_new, out_buf, output_path)
        return (protected, skipped)

def _repack_compressed_with_display(outfh, pak_file, entry, pak_relative_path, new_data, repack_dir, display):
    """Original compressed repack with display - Working fine"""
    blocks = entry.compressed_blocks
    enc_method = entry.encryption_method
    comp_method = entry.compression_method
    order = PakCrypto.generate_block_indices(len(blocks), enc_method)
    if len(new_data) != entry.uncompressed_size:
        if len(new_data) < entry.uncompressed_size:
            new_data = new_data.ljust(entry.uncompressed_size, b'\x00')
        else:
            new_data = new_data[:entry.uncompressed_size]
    if len(blocks) > 1:
        if entry.compression_block_size > 0:
            chunk_size = entry.compression_block_size
        else:
            block_sizes = [blk.end - blk.start for blk in blocks]
            total_block_size = sum(block_sizes)
            avg_block_size = total_block_size / len(blocks)
            avg_compression_ratio = total_block_size / entry.uncompressed_size if entry.uncompressed_size > 0 else 1
            chunk_size = int(avg_block_size / avg_compression_ratio) if avg_compression_ratio > 0 else 65536
        ptr = 0
        for logical_i, phys_i in enumerate(order):
            blk = blocks[phys_i]
            target_size = blk.end - blk.start
            chunk_len = min(chunk_size, len(new_data) - ptr)
            if chunk_len <= 0:
                return
            else:
                chunk = new_data[ptr:ptr + chunk_len]
                ptr += chunk_len
                with open(pak_file._file_path, 'rb') as src:
                    src.seek(blk.start)
                    original_compressed = src.read(target_size)
                compressed_ok = False
                new_compressed = None
                zstd_dict = pak_file._zstd_dict if comp_method == CM_ZSTD_DICT else None
                if comp_method in (CM_ZSTD, CM_ZSTD_DICT):
                    for level in [22, 19, 16, 13, 10, 7, 4, 1]:
                        c = ZstdCompressor(level=level, dict_data=zstd_dict, threads=1)
                        new_compressed = c.compress(chunk)
                        if len(new_compressed) <= target_size:
                            compressed_ok = True
                            break
                else:
                    if comp_method == CM_ZLIB:
                        new_compressed = zlib.compress(chunk, zlib.Z_BEST_COMPRESSION)
                        if len(new_compressed) <= target_size:
                            compressed_ok = True
                if not compressed_ok:
                    outfh.seek(blk.start)
                    outfh.write(original_compressed)
                    display.add_block(logical_i, target_size, False)
                else:
                    if entry.encrypted:
                        if PakCrypto._is_sm4_method(enc_method):
                            pad_len = -len(new_compressed) % 16
                            if pad_len > 0:
                                new_compressed += b'\x00' * pad_len
                        new_compressed = _encrypt_plaintext(new_compressed, pak_relative_path, enc_method)
                    if len(new_compressed) > target_size:
                        outfh.seek(blk.start)
                        outfh.write(original_compressed)
                        display.add_block(logical_i, target_size, False)
                    else:
                        outfh.seek(blk.start)
                        outfh.write(new_compressed)
                        if len(new_compressed) < target_size:
                            outfh.write(b'\x00' * (target_size - len(new_compressed)))
                        ratio = len(new_compressed) / len(chunk) if len(chunk) > 0 else 1
                        display.add_block(logical_i, target_size, True, ratio)
        return
    else:
        if not blocks:
            return
        else:
            blk = blocks[0]
            target_size = blk.end - blk.start
            with open(pak_file._file_path, 'rb') as src:
                src.seek(blk.start)
                original_compressed = src.read(target_size)
            compressed_ok = False
            new_compressed = None
            zstd_dict = pak_file._zstd_dict if comp_method == CM_ZSTD_DICT else None
            if comp_method in (CM_ZSTD, CM_ZSTD_DICT):
                for level in [22, 19, 16, 13, 10, 7, 4, 1]:
                    c = ZstdCompressor(level=level, dict_data=zstd_dict, threads=1)
                    new_compressed = c.compress(new_data)
                    if len(new_compressed) <= target_size:
                        compressed_ok = True
                        break
            else:
                if comp_method == CM_ZLIB:
                    new_compressed = zlib.compress(new_data, zlib.Z_BEST_COMPRESSION)
                    if len(new_compressed) <= target_size:
                        compressed_ok = True
            if not compressed_ok:
                outfh.seek(blk.start)
                outfh.write(original_compressed)
                display.add_block(0, target_size, False)
                return
            else:
                if entry.encrypted:
                    if PakCrypto._is_sm4_method(enc_method):
                        pad_len = -len(new_compressed) % 16
                        if pad_len > 0:
                            new_compressed += b'\x00' * pad_len
                    new_compressed = _encrypt_plaintext(new_compressed, pak_relative_path, enc_method)
                if len(new_compressed) > target_size:
                    outfh.seek(blk.start)
                    outfh.write(original_compressed)
                    display.add_block(0, target_size, False)
                else:
                    outfh.seek(blk.start)
                    outfh.write(new_compressed)
                    if len(new_compressed) < target_size:
                        outfh.write(b'\x00' * (target_size - len(new_compressed)))
                    ratio = len(new_compressed) / len(new_data) if len(new_data) > 0 else 1
                    display.add_block(0, target_size, True, ratio)

def smart_resolve_by_fingerprint(filename: str, repack_file: Path, candidates: list):
    repack_size = repack_file.stat().st_size
    size_matches = [(path, entry) for path, entry in candidates if entry.uncompressed_size == repack_size]
    if len(size_matches) == 1:
        return size_matches[0]
    else:
        if not size_matches:
            return
        else:
            def fingerprint(e):
                return (e.uncompressed_size, e.size, e.compression_method, len(e.compressed_blocks), e.compression_block_size)
            base_fp = fingerprint(size_matches[0][1])
            final_matches = [(path, entry) for path, entry in size_matches if fingerprint(entry) == base_fp]
            return final_matches[0] if len(final_matches) == 1 else None

def repack_pak_file_with_block_display(pak_file, edited_root: Path, output_path: Path):
    """Original repack with simple block display - WORKING"""
    shutil.copy2(pak_file._file_path, output_path)
    pak_name_map = {}
    for dir_path, files in pak_file._index.items():
        for name, entry in files.items():
            full_path = str(PurePath(dir_path) / name).replace('\\', '/')
            key = name.lower()
            pak_name_map.setdefault(key, []).append((full_path, entry))
    edited = {}
    for p in edited_root.rglob('*'):
        if not p.is_file():
            continue
        else:
            fname_lower = p.name.lower()
            if fname_lower in pak_name_map:
                candidates = pak_name_map[fname_lower]
                if len(candidates) == 1:
                    full_path, entry = candidates[0]
                    edited[full_path] = (p, entry)
                else:
                    resolved = smart_resolve_by_fingerprint(filename=p.name, repack_file=p, candidates=candidates)
                    if resolved:
                        full_path, entry = resolved
                        edited[full_path] = (p, entry)
            else:
                stem = p.stem.lower()
                ext = p.suffix.lower()
                for dir_path, files in pak_file._index.items():
                    for name, entry in files.items():
                        if Path(name).stem.lower() == stem and Path(name).suffix.lower() == ext:
                                full_path = str(PurePath(dir_path) / name).replace('\\', '/')
                                edited[full_path] = (p, entry)
                                break
    if not edited:
        console.print('[bold #FF0055]❌ No files to repack![/bold #FF0055]')
        return
    else:
        total_files = len(edited)
        display = SimpleBlockDisplay(total_files, pak_file._file_path.name)
        with open(output_path, 'r+b') as outfh:
            for full_path, (p, entry) in edited.items():
                file_name = p.name
                total_blocks = len(entry.compressed_blocks) if entry.compressed_blocks else 1
                display.start_file(file_name, total_blocks)
                new_data = p.read_bytes()
                pak_rel = PurePath(full_path)
                if entry.compression_method == CM_NONE:
                    _repack_uncompressed(outfh, pak_file, entry, pak_rel, new_data)
                    display.add_block(0, len(new_data), True)
                else:
                    _repack_compressed_with_display(outfh, pak_file, entry, pak_rel, new_data, edited_root, display)
                display.finish_file()
        display.final_summary()

def detect_repack_mode(pak_path: Path) -> str:
    name = pak_path.name.lower()
    if name == 'mini_obb.pak':
        return 'MINI_OBB'
    else:
        if 'zsdic' in name:
            return 'OBBZSDIC'
        else:
            if 'game' in name or 'patch' in name:
                return 'GAMEPATCH'
            else:
                return 'OBBZSDIC'

def repack_mini_obb(pak, repack_dir, output_pak):
    console.print('[bold #00FFFF]🧩 Repack Mode: MINI_OBB[/bold #00FFFF]')
    pak._is_zstd_with_dict = False
    pak._zstd_dict = None
    repack_pak_file_with_block_display(pak_file=pak, edited_root=repack_dir, output_path=output_pak)

def repack_obbzsdic(pak, repack_dir, output_pak):
    console.print('[bold #00FFFF]🧩 Repack Mode: OBBZSDIC[/bold #00FFFF]')
    repack_pak_file_with_block_display(pak_file=pak, edited_root=repack_dir, output_path=output_pak)

def repack_gamepatch(pak, repack_dir, output_pak):
    console.print('[bold #00FFFF]🧩 Repack Mode: GAMEPATCH[/bold #00FFFF]')
    pak._is_zstd_with_dict = False
    pak._zstd_dict = None
    repack_pak_file_with_block_display(pak_file=pak, edited_root=repack_dir, output_path=output_pak)

def ensure_directories(base_dir: Path):
    (base_dir / 'PAK').mkdir(parents=True, exist_ok=True)
    (base_dir / 'UNPACK').mkdir(parents=True, exist_ok=True)
    (base_dir / 'REPACK').mkdir(parents=True, exist_ok=True)
    (base_dir / 'RESULT').mkdir(parents=True, exist_ok=True)
    (base_dir / 'EXE').mkdir(parents=True, exist_ok=True)
    pak_tool_dir = base_dir / 'PAK TOOL'
    (pak_tool_dir / 'EDIT').mkdir(parents=True, exist_ok=True)
    (pak_tool_dir / 'UNPACK').mkdir(parents=True, exist_ok=True)
    (pak_tool_dir / 'RESULT').mkdir(parents=True, exist_ok=True)
    (pak_tool_dir / 'PAK').mkdir(parents=True, exist_ok=True)
    (base_dir / 'LUA_ORIGINAL').mkdir(parents=True, exist_ok=True)
    (base_dir / 'LUA_EDIT').mkdir(parents=True, exist_ok=True)
    (base_dir / 'COMPILED').mkdir(parents=True, exist_ok=True)
    (base_dir / 'SOURCE').mkdir(parents=True, exist_ok=True)
import os
import sys
import time
import random
from datetime import datetime
import requests
import subprocess
# Device check disabled for owner recovery:
DEVICE_MODEL = "OWNER-DEVICE"
DEVICE_ENTRY = DEVICE_MODEL
COLORS = ['[91m', '[92m', '[94m', '[93m', '[95m', '[96m', '[97m']
RESET = '[0m'

def colored_text(text):
    """إضافة لون عشوائي للنص"""
    return f'{random.choice(COLORS)}{text}{RESET}'

def welcome_message():
    """رسالة ترحيبية متحركة"""
    os.system('clear')
    message = ''
    mclear()
    print_intro()
    main_menu()
ALVSIA_ASCII = ['███╗   ███╗ █████╗ ███╗   ██╗██╗  ██╗███████╗', '████╗ ████║██╔══██╗████╗  ██║██║ ██╔╝██╔════╝', '██╔████╔██║███████║██╔██╗ ██║█████╔╝ ███████╗', '██║╚██╔╝██║██╔══██║██║╚██╗██║██╔═██╗ ╚════██║', '██║ ╚═╝ ██║██║  ██║██║ ╚████║██║  ██╗███████║', '╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝']

def _lerp_channel(a, b, t):
    return int(a + (b - a) * t)

def _random_gradient_colors():
    """Two vivid colors with different hues — new gradient on every refresh."""
    h1 = random.random()
    h2 = (h1 + 0.4 + random.random() * 0.25) % 1.0
    c1 = tuple((int(x * 255) for x in colorsys.hsv_to_rgb(h1, 1.0, 1.0)))
    c2 = tuple((int(x * 255) for x in colorsys.hsv_to_rgb(h2, 1.0, 1.0)))
    return (c1, c2)

def print_pink_blue_block(lines, c1=(255, 45, 150), c2=(45, 120, 255)):
    """Diagonal gradient (default pink left-top -> blue right-down)."""
    PINK, BLUE = (c1, c2)
    h = max(1, len(lines))
    w = max(1, max((len(l) for l in lines)))
    for y, line in enumerate(lines):
        out = []
        for x, ch in enumerate(line):
            if ch == ' ':
                out.append(' ')
            else:
                t = (x / w + y / h) / 2.0
                r = _lerp_channel(PINK[0], BLUE[0], t)
                g = _lerp_channel(PINK[1], BLUE[1], t)
                b = _lerp_channel(PINK[2], BLUE[2], t)
                out.append(f'[38;2;{r};{g};{b}m{ch}')
        print(''.join(out) + '[0m')

def rainbow_print(text, offset=0.0):
    """Rainbow gradient text."""
    chars = [c for c in text if c not in (' ', '\t')]
    n = max(1, len(chars))
    out = []
    i = 0
    for ch in text:
        if ch in [' ', '\t']:
            out.append(ch)
        else:
            h = (i / n + offset) % 1.0
            r, g, b = colorsys.hsv_to_rgb(h, 1.0, 1.0)
            out.append(f'[38;2;{int(r * 255)};{int(g * 255)};{int(b * 255)}m{ch}')
            i += 1
    print(''.join(out) + '[0m')

def _banner_block_center_light(lines, center_rgb=(58, 106, 186), edge_rgb=(8, 14, 38)):
    """Dark-blue gradient banner: lighter in the center, darker at the edges."""
    h = max(1, len(lines))
    w = max(1, max((len(l) for l in lines)))
    for y, line in enumerate(lines):
        out = []
        for x, ch in enumerate(line):
            if ch == ' ':
                out.append(' ')
            else:
                dx = (x / max(1, w - 1) - 0.5) * 2.0
                dy = (y / max(1, h - 1) - 0.5) * 2.0
                t = min(1.0, abs(dx) * 0.75 + abs(dy) * 0.25)
                r = int(center_rgb[0] + (edge_rgb[0] - center_rgb[0]) * t)
                g = int(center_rgb[1] + (edge_rgb[1] - center_rgb[1]) * t)
                b = int(center_rgb[2] + (edge_rgb[2] - center_rgb[2]) * t)
                out.append(f'[38;2;{r};{g};{b}m{ch}')
        print(''.join(out) + '[0m')

def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    _banner_block_center_light(ALVSIA_ASCII)
    print()
    console.print(Panel(f'[bold {DARK_SKY_LIGHT}]ALVSIA STUDIO · PAK & LUA[/]\n[dim] PAK modding · LUA bytecode · Uasset +Lua injection[/]\n\n[{DARK_SKY_LIGHT}]▸[/] Unpack / Repack / Inject / Protect  PAK\n[{DARK_SKY_LIGHT}]▸[/] Build new PAK from template · Inject uasset + uexp\n[{DARK_SKY_LIGHT}]▸[/] LUA decompile & compile\n\n[dim]Credit: {CREDIT}  ·  TELEGRAM: @ALVSIA_PRO  ·  OWNER: @OriginalOnwerALV  ·  {get_indian_time()}[/]', title=f'[bold {DARK_RED}]✦ ALVSIA ✦[/]', border_style=DARK_SKY, box=ROUNDED, padding=(0, 2)))
    console.print()
SKIP_NAMES = {'.DS_Store', 'index.csv', 'Debug_', 'pak_manifest.json'}

def load_index_csv(csv_path: Path) -> List[str]:
    if not csv_path.exists():
        return []
    else:
        out = []
        with open(csv_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                s = line.strip().replace('\\', '/').lstrip('/')
                if s:
                    out.append(s)
        return out

def build_fullpath_entry_map(pak_file) -> Dict[str, Any]:
    m = {}
    for dir_path, files in pak_file._index.items():
        for name, entry in files.items():
            full = str(PurePath(dir_path) / name).replace('\\', '/').lstrip('/')
            if full.startswith('./'):
                full = full[2:]
            m[full] = entry
    return m

def write_pack_index_csv(pak_file, csv_path: Path) -> int:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    paths = sorted(set(build_fullpath_entry_map(pak_file).keys()))
    with open(csv_path, 'w', encoding='utf-8') as f:
        for p in paths:
            f.write(p + '\n')
    return len(paths)

def detect_unpacked_paks(data_path: Path) -> List[Path]:
    root = data_path / 'UNPACK'
    if not root.exists():
        return []
    else:
        return sorted([p for p in root.iterdir() if p.is_dir()], key=lambda x: x.name.lower())

def find_original_pak_for_unpack(data_path: Path, pakname: str) -> Optional[Path]:
    search_dirs = [data_path / 'PAK', data_path / 'PAK TOOL' / 'PAK', data_path / 'RESULT']
    for d in search_dirs:
        if d.exists():
            exact = d / f'{pakname}.pak'
            if exact.exists():
                return exact
            else:
                for p in d.glob('*.pak'):
                    if p.stem.lower() == pakname.lower():
                        return p
    return

def get_indian_time():
    tz = pytz.timezone('Asia/Kolkata')
    return datetime.now(tz).strftime('%Y-%m-%d %H:%M:%S')

def human_size(size: int) -> str:
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f'{size:.2f} {unit}'
        else:
            size /= 1024.0
    return f'{size:.2f} PB'

def delete_folder(data_path: Path) -> None:
    folders = []
    for item in data_path.iterdir():
        if item.is_dir() and item.name not in ('PAK', 'UNPACK', 'REPACK', 'RESULT', 'PAK TOOL', 'EXE'):
                folders.append(item)
    if not folders:
        console.print('[bold #FFAA00]⚠ No folders found to delete![/bold #FFAA00]')
        return
    else:
        folder_table = Table(title='[bold #FF00FF]📁 AVAILABLE FOLDERS[/bold #FF00FF]', border_style='#00FFFF', box=DOUBLE_EDGE)
        folder_table.add_column('#', justify='center', style='bold #FFFF00', width=4)
        folder_table.add_column('Folder Name', justify='left', style='bold #00FF88')
        folder_table.add_column('Size', justify='right', style='bold #00CCFF')
        for i, folder in enumerate(folders, 1):
            folder_size = 0
            for root, dirs, files in os.walk(folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    if os.path.isfile(file_path):
                        folder_size += os.path.getsize(file_path)
            folder_table.add_row(str(i), folder.name, human_size(folder_size))
        console.print(folder_table)
    try:
        choice = int(console.input(f'\n[bold #FFFF00]Select folder number (1-{len(folders)}): [/bold #FFFF00]'))
        if 1 <= choice <= len(folders):
                selected_folder = folders[choice - 1]
                confirm = safe_input(f'[bold #FFFF00]Delete {selected_folder.name}? (yes/no): [/bold #FFFF00]').strip().lower()
                if confirm == 'yes':
                    shutil.rmtree(selected_folder)
                    console.print(f'[bold #00FF88]✅ Deleted: {selected_folder.name}[/bold #00FF88]')
                else:
                    console.print('[bold #FFAA00]⚠ Cancelled[/bold #FFAA00]')
        console.print('[bold #FF0055]❌ Invalid selection[/bold #FF0055]')
    except ValueError:
        console.print('[bold #FF0055]❌ Invalid input[/bold #FF0055]')

def _block_permutation(n_chunks: int, encryption_method: int):
    return PakCrypto.generate_block_indices(n_chunks, encryption_method)

def hexa_alert(message: str, kind: str='info') -> None:
    tags = {'success': ('✓', SUCCESS), 'error': ('✗', ERR), 'warning': ('⚠', WARN), 'info': ('▶', ACCENT)}
    tag, color = tags.get(kind, tags['info'])
    console.print(f'  {tag}  {message}  [dim]| {CREDIT}[/dim]', style=color)

def hexa_section(title: str) -> None:
    console.print()
    console.print(f'  ═══ {title} ═══  [dim]({CREDIT})[/dim]', style=f'bold {DARK_SKY_LIGHT}')
    console.print(f"  {'─' * (len(title) + 8)}", style=MUTED)

def hexa_prompt(label: str) -> str:
    console.print(f'  {label}  [dim]· {CREDIT}[/dim]', style=f'bold {DARK_SKY_LIGHT}')
    return safe_input('  └─> ').strip()

def _block_permutation(n_chunks: int, encryption_method: int):
    return PakCrypto.generate_block_indices(n_chunks, encryption_method)

def action_build_new_pak(data_path):
    pak_dir = data_path / 'PAK'
    edit_dir = data_path / 'EDIT'
    result_dir = data_path / 'RESULT'
    result_dir.mkdir(parents=True, exist_ok=True)
    if not pak_dir.exists():
        hexa_alert(f'PAK folder not found at {pak_dir}', 'error')
        safe_input('\nPress Enter...')
        return
    else:
        pak_file, _ = display_file_selector('Select TEMPLATE PAK', pak_dir)
        if not pak_file:
            safe_input('\nPress Enter...')
            return
        else:
            if not edit_dir.exists() or not any(edit_dir.iterdir()):
                hexa_alert('No files in COMPILED folder. Place files to add in COMPILED first.', 'error')
                safe_input('\nPress Enter...')
                return
            else:
                console.print()
                console.print(Panel(f'Target path inside PAK (or blank for relative).\nFiles will be added to this path inside the new PAK.\n[dim]e.g. Content/Lua/GameLua/Mod/BRMod/Gameplay/Core[/dim]\n[dim]Press Enter directly for no path (files at root)[/dim]\n[dim]Credit: {CREDIT}[/dim]', border_style=ACCENT, box=ROUNDED, padding=(0, 2)))
                target_path = safe_input(f'\n[bold yellow]Target path (press Enter for no path) [{CREDIT}]: [/bold yellow]').strip()
                if target_path:
                    target_path = target_path.replace('\\', '/').strip('/')
                    console.print(f'[dim]Using custom path: {target_path}[/dim]')
                else:
                    target_path = ''
                    console.print('[dim]No path set - files will be at root[/dim]')
                output_pak = result_dir / pak_file.name
                try:
                    hexa_section(f'Building NEW PAK using template: {pak_file.name}')
                    console.print(f'[bold green]▶ Auto-proceeding with build...  [dim]· {CREDIT}[/dim][/bold green]')
                    count = build_new_pak_from_template(pak_file, edit_dir, output_pak, target_path)
                    if count > 0:
                        hexa_alert(f'New PAK built with {count} files!  [dim]· {CREDIT}[/dim]', 'success')
                        hexa_alert(f'Output: {output_pak}', 'info')
                    else:
                        hexa_alert('Build failed - no files processed', 'error')
                except Exception as e:
                    hexa_alert(f'Build failed: {e}', 'error')
                    traceback.print_exc()
                safe_input('\nPress Enter to continue...')

def _p(tag, msg, color=C.W):
    print(f'  {color}[{tag}]{C.RS} {msg}')

def _ok(m):
    _p('✔', m, C.G)

def _err(m):
    _p('✘', m, C.R)

def _inf(m):
    _p('*', m, C.CY)

def _wrn(m):
    _p('!', m, C.Y)

def _alv(m):
    _p('ALVSIA', m, C.M)


def display_file_selector(title, folder_path, file_pattern='*.pak'):
    files = list(folder_path.glob(file_pattern))
    if not files:
        console.print(f'[bold red][ERROR] No {file_pattern} files in {folder_path}[/]')
        return (None, None)
    else:
        selection_table = Table(title=f'[bold cyan]{title}[/]', expand=True, box=ROUNDED, border_style='yellow')
        selection_table.add_column('[bold yellow]#[/]', justify='center', style='bold yellow', width=4)
        selection_table.add_column('[bold green]File Name[/]', justify='left', style='bold bright_green')
        selection_table.add_column('[bold magenta]Size[/]', justify='right', style='bold bright_magenta')
        for i, f in enumerate(files, 1):
            size_mb = f.stat().st_size / 1048576
            selection_table.add_row(str(i), f.name, f'{size_mb:.2f} MB')
        console.print(selection_table)
        try:
            idx = int(console.input(f'\n[bold yellow]Select file number (1-{len(files)}): [/]')) - 1
            if idx < 0 or idx >= len(files):
                console.print('[bold red][ERROR] Invalid selection[/]')
                return (None, None)
            else:
                return (files[idx], files)
        except ValueError:
            console.print('[bold red][ERROR] Please enter a valid number[/]')
            return (None, None)

def main_menu():
    """Main interactive menu."""
    if getattr(sys, 'frozen', False):
        data_path = Path(sys.executable).parent
    else:
        data_path = Path(__file__).parent
    ensure_directories(data_path)

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print_banner()
        menu = Table(box=ROUNDED, show_header=False, padding=(0, 2))
        menu.add_column('[bold]', style=DARK_SKY)
        menu.add_column('Option', style='bold white')
        menu.add_column('', style=DARK_SKY_LIGHT)
        menu.add_row('[1]', 'UNPACK PAK', f' · {CREDIT}')
        menu.add_row('[2]', 'REPACK PAK  (UNPACKED)', f'· {CREDIT}')
        menu.add_row('[3]', 'INJECT LUA', f'· {CREDIT}')
        menu.add_row('[4]', 'INJECT FILE', f'· {CREDIT}')
        menu.add_row('[5]', 'PROTECT PAK', f'· {CREDIT}')
        menu.add_row('[6]', 'BUILD NEW PAK', f'· {CREDIT}')
        menu.add_row('[7]', 'INJECT UASSET + UEXP', f'· {CREDIT}')
        menu.add_row('[8]', 'LUA DECOMPILE', f'· {CREDIT}')
        menu.add_row('[9]', 'LUA COMPILE', f'· {CREDIT}')
        menu.add_row('[D]', 'DELETE FOLDER', f' · {CREDIT}')
        menu.add_row('[0]', 'EXIT', f' · {CREDIT}')
        console.print(Panel(menu, title=f'[bold {DARK_SKY_LIGHT}]═══ MAIN MENU ═══[/]  [dim]· CREDIT: {CREDIT}[/dim]', border_style=DARK_SKY, box=DOUBLE_EDGE, padding=(0, 1)))
        console.print()
        choice = safe_input('Enter choice : ').strip()

        try:
            if choice == '1':
                # UNPACK PAK
                pak_dir = data_path / 'PAK'
                if not pak_dir.exists():
                    console.print(f'[bold red]ERROR: PAK folder not found at {pak_dir}[/]')
                    safe_input('\nPress Enter to continue...')
                    continue
                paks = [f for f in pak_dir.iterdir() if f.is_file() and f.name.lower().endswith('.pak')]
                if not paks:
                    console.print(f'[bold red]No .pak files in {pak_dir}[/]')
                    safe_input('\nPress Enter to continue...')
                    continue
                console.print('[cyan]📁 Available .pak files to UNPACK:[/]')
                for i, p in enumerate(paks, 1):
                    console.print(f'  [{i}] {p.name}')
                ch = safe_input('Select PAK number: ').strip()
                try:
                    pak_path = paks[int(ch) - 1]
                except Exception:
                    console.print('[bold red]❌ Invalid selection[/]')
                    continue
                console.print(f'[bold #00FFFF]🚀 Unpacking {pak_path.name}...[/]')
                unpack_dir = data_path / 'UNPACK' / pak_path.stem
                unpack_dir.mkdir(parents=True, exist_ok=True)
                try:
                    console.print('[cyan]Loading PAK...[/cyan]')
                    pak = TencentPakFile(pak_path)
                    console.print(f'[dim]Entries: {len(pak._index)}[/dim]')
                    extract_dir = unpack_dir
                    extract_dir.mkdir(parents=True, exist_ok=True)
                    pak.dump(extract_dir)
                    console.print(f'[bold #00FF88]✅ SUCCESS: Extracted to {extract_dir}[/]')
                    console.print(f'[dim]Edited folder: {extract_dir}[/dim]')
                except Exception as e:
                    console.print(f'[bold #FF0055]❌ Error: {e}[/]')
                    import traceback
                    traceback.print_exc()
                safe_input('\nPress Enter to continue...')

            elif choice == '2':
                # REPACK
                unpacks = detect_unpacked_paks(data_path) if 'detect_unpacked_paks' in dir() else []
                if not unpacks:
                    p = data_path / 'UNPACK'
                    unpacks = [d for d in p.iterdir() if d.is_dir()] if p.exists() else []
                if not unpacks:
                    console.print('[bold red]❌ No UNPACK folders found![/]')
                    safe_input('\nPress Enter to continue...')
                    continue
                console.print('[cyan]📁 UNPACKED PAKS:[/]')
                for i, u in enumerate(unpacks, 1):
                    console.print(f'  [{i}] {u.name}')
                ch = safe_input('Select number: ').strip()
                try:
                    entry = unpacks[int(ch) - 1]
                except Exception:
                    console.print('[bold red]❌ Invalid[/]')
                    continue
                try:
                    do_repack_from_unpack(data_path, entry)
                except Exception as e:
                    console.print(f'[bold #FF0055]❌ Repack failed: {e}[/]')
                safe_input('\nPress Enter to continue...')

            elif choice == '3':
                action_inject_lua(data_path)
                safe_input('\nPress Enter to continue...')

            elif choice == '4':
                # INJECT FILE
                edit_dir = data_path / 'EDIT'
                pak_dir = data_path / 'PAK TOOL' / 'PAK'
                result_dir = data_path / 'PAK TOOL' / 'RESULT'
                if not edit_dir.exists():
                    edit_dir.mkdir(parents=True, exist_ok=True)
                if not pak_dir.exists():
                    console.print(f'[bold red]ERROR: PAK TOOL/PAK not found at {pak_dir}[/]')
                    safe_input('\nPress Enter to continue...')
                    continue
                paks = [f for f in pak_dir.iterdir() if f.name.lower().endswith('.pak')]
                if not paks:
                    console.print('[bold red]No PAK files[/]')
                    safe_input('\nPress Enter to continue...')
                    continue
                console.print('[cyan]📁 Available .pak:[/]')
                for i, p in enumerate(paks, 1):
                    console.print(f'  [{i}] {p.name}')
                ch = safe_input('Select: ').strip()
                try:
                    pak_path = paks[int(ch) - 1]
                except Exception:
                    continue
                result_dir.mkdir(parents=True, exist_ok=True)
                out_pak = result_dir / f'{pak_path.stem}_MODIFIED.pak'
                try:
                    pak_file = TencentPakFile(pak_path)
                    inject_edit_files(pak_file, edit_dir, out_pak, protect_new=False)
                    console.print(f'[bold green]🎮 Output: {out_pak}[/]')
                except Exception as e:
                    console.print(f'[bold #FF0055]❌ Inject failed: {e}[/]')
                safe_input('\nPress Enter to continue...')

            elif choice == '5':
                pak_dir = data_path / 'PAK TOOL' / 'PAK'
                result_dir = data_path / 'PAK TOOL' / 'RESULT'
                if not pak_dir.exists():
                    console.print(f'[bold red]ERROR: {pak_dir} not found[/]')
                    safe_input('\nPress Enter to continue...')
                    continue
                paks = [f for f in pak_dir.iterdir() if f.name.lower().endswith('.pak')]
                if not paks:
                    console.print('[bold red]No PAK[/]')
                    continue
                for i, p in enumerate(paks, 1):
                    console.print(f'  [{i}] {p.name}')
                ch = safe_input('Select PAK: ').strip()
                try:
                    pak_path = paks[int(ch) - 1]
                except Exception:
                    continue
                confirm = safe_input('[bold #FF00FF]Start PROTECT? (yes/no): [/]').strip().lower()
                if confirm not in ('y', 'yes'):
                    console.print('[yellow]Cancelled.[/]')
                    continue
                result_dir.mkdir(parents=True, exist_ok=True)
                out_pak = result_dir / pak_path.name
                try:
                    protect_pak_file(pak_path, out_pak)
                    console.print(f'[bold green]🎮 Protected: {out_pak}[/]')
                except Exception as e:
                    console.print(f'[bold #FF0055]❌ Protect failed: {e}[/]')
                safe_input('\nPress Enter to continue...')

            elif choice == '6':
                action_build_new_pak(data_path)
                safe_input('\nPress Enter to continue...')

            elif choice == '7':
                action_inject_lua(data_path)
                safe_input('\nPress Enter to continue...')

            elif choice == '8':
                lua_decompile_menu(data_path)
                safe_input('\nPress Enter to continue...')

            elif choice == '9':
                lua_compile_menu(data_path)
                safe_input('\nPress Enter to continue...')

            elif choice in ('D', 'd'):
                delete_folder(data_path)
                safe_input('\nPress Enter to continue...')

            elif choice == '0':
                console.print('[bold magenta]Goodbye![/bold magenta]')
                break

            else:
                console.print('[bold #FF0055]❌ Invalid choice![/]')
                import time as _t
                _t.sleep(1)

        except KeyboardInterrupt:
            raise
        except Exception as e:
            console.print(f'[bold #FF0055]❌ Error: {e}[/]')
            import traceback
            traceback.print_exc()
            safe_input('\nPress Enter to continue...')

# ═══════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════



def do_repack_from_unpack(data_path, unpack_entry, force_target_path=None):
    pakname = unpack_entry.name
    edited_dir = unpack_entry / 'edited'
    if not edited_dir.exists() or not any(edited_dir.rglob('*')):
        console.print('[red]edited/ folder is empty![/red]')
        return
    orig_pak = find_original_pak_for_unpack(data_path, pakname)
    if orig_pak is None or not orig_pak.exists():
        console.print('[red]Original PAK not found![/red]')
        return
    RESULT_DIR = data_path / 'RESULT'
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    output_pak = RESULT_DIR / orig_pak.name
    try:
        console.print('[cyan]Loading original PAK...[/cyan]')
        pak_file = TencentPakFile(orig_pak)
        repack_pak_file_full(pak_file, edited_dir, output_pak, target_path=force_target_path)
        console.print('[green]Repack done: %s[/green]' % output_pak)
    except Exception as e:
        console.print('[red]Repack failed: %s[/red]' % e)
        import traceback
        traceback.print_exc()


def action_inject_lua(data_path):
    edit_dir = data_path / 'COMPILED'
    out_path = data_path / 'PAK TOOL' / 'RESULT'
    pak_dir = data_path / 'PAK TOOL' / 'PAK'
    if not edit_dir.exists():
        edit_dir.mkdir(parents=True, exist_ok=True)
        console.print('[yellow]Created COMPILED folder - put files there.[/yellow]')
        safe_input('Press Enter...')
        return
    files_in_edit = [f for f in edit_dir.rglob('*') if f.is_file() and f.name not in ('pak_manifest.json', '.DS_Store')]
    if not files_in_edit:
        console.print('[red]COMPILED folder is empty![/red]')
        safe_input('Press Enter...')
        return
    console.print('[cyan]Files in COMPILED:[/]')
    for idx, f in enumerate(files_in_edit, 1):
        console.print('  [%d] %s' % (idx, f.name))
    base_path = safe_input('Target path inside PAK (Enter=root): ').strip()
    if base_path and not base_path.endswith('/'):
        base_path += '/'
    if not pak_dir.exists():
        console.print('[red]PAK folder not found: %s[/red]' % pak_dir)
        safe_input('Press Enter...')
        return
    pak_files = [f for f in pak_dir.iterdir() if f.name.lower().endswith('.pak')]
    if not pak_files:
        console.print('[red]No PAK files in %s[/red]' % pak_dir)
        safe_input('Press Enter...')
        return
    pak_path = pak_files[0]
    if len(pak_files) > 1:
        for i, p in enumerate(pak_files, 1):
            console.print('  [%d] %s' % (i, p.name))
        ch = safe_input('Select: ').strip()
        try:
            pak_path = pak_files[int(ch) - 1]
        except Exception:
            pass
    out_path.mkdir(parents=True, exist_ok=True)
    output_pak = out_path / (pak_path.stem + '_MODIFIED.pak')
    try:
        pak_file = TencentPakFile(pak_path)
        inject_edit_files(pak_file, edit_dir, output_pak, protect_new=False)
        console.print('[green]Output: %s[/green]' % output_pak)
    except Exception as e:
        console.print('[red]Inject failed: %s[/red]' % e)
        import traceback
        traceback.print_exc()


def _lua_find_luac():
    base = Path(__file__).parent
    for c in [base / 'SOURCE' / 'luac5.3', base / 'SOURCE' / 'luac']:
        if c.exists():
            return c
    return None


def lua_decompile_menu(data_path):
    src_dir = data_path / 'LUA_ORIGINAL'
    dst_dir = data_path / 'EDIT'
    dst_dir.mkdir(parents=True, exist_ok=True)
    if not src_dir.exists():
        console.print('[red]No LUA_ORIGINAL folder[/red]')
        safe_input('Press Enter...')
        return
    files = list(src_dir.rglob('*.lua'))
    if not files:
        console.print('[red]No .lua files[/red]')
        safe_input('Press Enter...')
        return
    for i, f in enumerate(files, 1):
        console.print('  [%d] %s' % (i, f.name))
    ch = safe_input('Select: ').strip()
    try:
        f = files[int(ch) - 1]
    except Exception:
        return
    out = dst_dir / (f.stem + '_decompiled.lua')
    jar = Path(__file__).parent / 'SOURCE' / 'unluac_patched.jar'
    if not jar.exists():
        jar = Path(__file__).parent / 'SOURCE' / 'unluac.jar'
    if jar.exists():
        r = subprocess.run(['java', '-jar', str(jar), str(f), '-o', str(out)], capture_output=True, text=True)
        if r.returncode == 0 and out.exists():
            console.print('[green]OK -> %s[/green]' % out)
        else:
            console.print('[red]unluac failed[/red]')
    else:
        console.print('[red]unluac.jar not found in SOURCE/[/red]')
    safe_input('Press Enter...')


def lua_compile_menu(data_path):
    src_dir = data_path / 'EDIT'
    dst_dir = data_path / 'COMPILED'
    dst_dir.mkdir(parents=True, exist_ok=True)
    if not src_dir.exists():
        console.print('[red]No EDIT folder[/red]')
        safe_input('Press Enter...')
        return
    files = list(src_dir.rglob('*.lua'))
    if not files:
        console.print('[red]No .lua files[/red]')
        safe_input('Press Enter...')
        return
    for i, f in enumerate(files, 1):
        console.print('  [%d] %s' % (i, f.name))
    ch = safe_input('Select: ').strip()
    try:
        f = files[int(ch) - 1]
    except Exception:
        return
    luac = _lua_find_luac()
    out = dst_dir / (f.stem + '.lua')
    if luac:
        r = subprocess.run([str(luac), '-o', str(out), str(f)], capture_output=True, text=True)
        if r.returncode == 0 and out.exists():
            console.print('[green]Compiled -> %s[/green]' % out)
        else:
            console.print('[red]luac failed[/red]')
    else:
        console.print('[red]luac not found in SOURCE/[/red]')
    safe_input('Press Enter...')


def main():
    """Main entry — same as original main_menu loop."""
    try:
        main_menu()
    except KeyboardInterrupt:
        console.print('\n[dim]Bye![/dim]')
    except SystemExit:
        raise
    except Exception:
        import traceback
        traceback.print_exc()
        try:
            safe_input('\nPress Enter to exit...')
        except Exception:
            pass

if __name__ == '__main__':
    main()
