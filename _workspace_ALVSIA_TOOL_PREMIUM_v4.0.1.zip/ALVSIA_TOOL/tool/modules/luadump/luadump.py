#//━━━━━━━━━━━━━━━━━━━━━━━//
#//    🔧 Developed by: @BASHARIP
#//    📢 Channel:      @MODBASHA
#//━━━━━━━━━━━━━━━━━━━━━━━//

from __future__ import annotations

import itertools as it
import math, struct, shutil, os, sys, hashlib, subprocess, zlib, ctypes, re, time
import base64, secrets, random, tempfile, threading
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import PurePath, Path
from typing import Optional, List, Tuple, Callable, Dict, Any
from datetime import datetime

from rich.console import Console, Group
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text
from rich.align import Align
from rich.box import ROUNDED, DOUBLE_EDGE, HEAVY, SIMPLE, MINIMAL
from rich.live import Live

import pytz, gmalg
from Crypto.Cipher import AES
from Crypto.Cipher.AES import MODE_CBC
from Crypto.Hash import SHA1
from Crypto.Util.Padding import unpad
from zstandard import ZstdDecompressor, ZstdCompressionDict, DICT_TYPE_AUTO, ZstdCompressor

console = Console()

BASE_DIR   = Path("/storage/emulated/0/Download/AQARVIR")
PAK_DIR    = BASE_DIR / "𝖕𝖆𝖐𝖘 ~ 𝖗𝖎𝖕"
EDIT_DIR   = BASE_DIR / "𝖑𝖚𝖆 ~ 𝖗𝖎𝖕"
RESULT_DIR = BASE_DIR / "جـاهـز لـلـدمـجـ🌓"
REPACK_DIR = BASE_DIR / "𝖗𝖊𝖕𝖆𝖐 ~ 𝖗𝖎𝖕"
FORGE_DIR  = BASE_DIR / "𝖋𝖔𝖗𝖌𝖊 ~ 𝖗𝖎𝖕"

TARGET_LUA_PATH = 'Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/BRPlayerCharacterBase.lua'
TARGET_LUA_DIR  = 'Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/'
TARGET_LUA_NAME = 'BRPlayerCharacterBase.lua'

MOUNT_POINT = '../../../ShadowTrackerExtra/'

DEFAULT_SM4_TYPE = 32

def ensure_dirs():
    for d in (BASE_DIR, PAK_DIR, EDIT_DIR, RESULT_DIR, REPACK_DIR, FORGE_DIR):
        d.mkdir(parents=True, exist_ok=True)

_INVALID_PATH_CHARS = re.compile(r'[\x00-\x1f<>:"|?*\\/]')
def _safe_path_component(name: str) -> str:
    if not name: return '_'
    s = _INVALID_PATH_CHARS.sub('_', name).rstrip('. ')
    if not s: s = '_'
    if s in ('.', '..'): s = '_' + s
    return s
def _safe_rel_path(p: PurePath) -> PurePath:
    if not p.parts: return PurePath()
    return PurePath(*[_safe_path_component(x) for x in p.parts])

ZUC_KEY = bytes.fromhex('01010101010101010101010101010101')
ZUC_IV  = bytes.fromhex('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')

RSA_MOD_1 = bytes.fromhex('CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4')
RSA_MOD_2 = bytes.fromhex('7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8')

SIMPLE1_DECRYPT_KEY = 121
SIMPLE2_DECRYPT_KEY = bytes.fromhex('E55B4ED1')

SM4_SECRET_4   = 'eb691efea914241317a8'
SM4_SECRET_2   = 'Q0hVTKey$as*1ZFlQCiA'
SM4_SECRET_NEW = [
    'xG2qW5lP7lV2iN5fN5pG',
    'xT1cJ6dL5wC0kK1rB4dK',
    'qC4jS5bZ6fL5xE6nD4zA',
    'gD4jQ2aL3bS3lC3xT0iW',
    'xU1yQ8wE9zY3gZ3bT5aE',
    'uQ3cO2dX7xY4xU7gH7iS',
    'gW1fR0jK6wQ4oN0oK1kZ',
    'aJ4pV7iZ7pU4wP2aC2cZ',
    'cX6jT3cM2oT3vK0kJ1qN',
    'iT2vS0cS6yT6cZ1sE1lO',
    'hM1pH9iY8wM9hT4lN5uJ',
    'kG6bC8jK0fL0dE4sH4mL',
    'dB6lB3vE0eZ8wM8rI0aC',
    'tP7sP7nI9rA2vQ4cV5yQ',
    'aT0cL1yN4pT3sZ7eM2vY',
    'uV6fU8fC9zN3mP5dH8mN',
    'rT6aQ6oZ1yM0gO5tO1aN',
    'jU5bH7lQ0fM9hK2kI0oF',
    'iQ0eM0mJ7uT0kV6kL5zY',
    'rG0lR2rZ5vM6mW5lM1rR',
    'wD2rP3lP9xF4mE1eC5jS',
    'fO3kW1fE6eD0pU1kY7xK',
    'nE1jQ6qK5tW7rM8iD5vV',
]

EM_SIMPLE1 = 1; EM_SIMPLE2 = 16; EM_SM4_2 = 2; EM_SM4_4 = 4
EM_SM4_NEW_BASE = 31; EM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE; EM_UNKNOWN_17 = 17
CM_NONE = 0; CM_ZLIB = 1; CM_ZSTD = 6; CM_ZSTD_DICT = 8; CM_MASK = 15

def _find_bin(*names):
    for n in names:
        p = shutil.which(n)
        if p: return p
    for p in (f'/data/data/com.termux/files/usr/bin/{n}' for n in names):
        if os.path.exists(p): return p
    for p in (f'/usr/bin/{n}' for n in names):
        if os.path.exists(p): return p
    return None

def _tokenize_lua(source: str):
    i, n, line, col = 0, len(source), 1, 1
    while i < n:
        c = source[i]
        if c == '\n': line += 1; col = 1; i += 1; continue
        if source.startswith('--', i):
            j = i + 2; level = 0
            while j < n and source[j] == '=': level += 1; j += 1
            if j < n and source[j] == '[':
                closer = ']' + '=' * level + ']'
                end = source.find(closer, j + 1)
                if end == -1: yield (line, col, '__COMMENT_UNTERMINATED__'); return
                seg = source[i:end + len(closer)]; line += seg.count('\n')
                col = (len(seg) - seg.rfind('\n')) if '\n' in seg else col + len(seg)
                i = end + len(closer); continue
            while i < n and source[i] != '\n': i += 1
            continue
        if c == '[':
            j = i + 1; level = 0
            while j < n and source[j] == '=': level += 1; j += 1
            if j < n and source[j] == '[':
                closer = ']' + '=' * level + ']'
                end = source.find(closer, j + 1)
                if end == -1: yield (line, col, '__STRING_UNTERMINATED__'); return
                seg = source[i:end + len(closer)]; line += seg.count('\n')
                col = (len(seg) - seg.rfind('\n')) if '\n' in seg else col + len(seg)
                i = end + len(closer); continue
        if c in ("'", '"'):
            q = c; j = i + 1
            while j < n:
                if source[j] == '\\': j += 2; continue
                if source[j] == q: j += 1; break
                if source[j] == '\n': yield (line, col, '__STRING_UNTERMINATED__'); return
                j += 1
            seg = source[i:j]; line += seg.count('\n')
            col = (len(seg) - seg.rfind('\n')) if '\n' in seg else col + len(seg)
            i = j; continue
        if c.isalpha() or c == '_':
            j = i
            while j < n and (source[j].isalnum() or source[j] == '_'): j += 1
            yield (line, col, source[i:j]); col += j - i; i = j; continue
        if c.isdigit() or (c == '.' and i + 1 < n and source[i + 1].isdigit()):
            j = i
            while j < n and (source[j].isalnum() or source[j] in '._'): j += 1
            col += j - i; i = j; continue
        col += 1; i += 1

def _validate_block_structure(source: str) -> List[Tuple[int, int, str]]:
    errors = []; stack = []; waiting_for_do = False
    for ln, cl, tok in _tokenize_lua(source):
        if tok == '__STRING_UNTERMINATED__': errors.append((ln, cl, "unterminated string")); continue
        if tok == '__COMMENT_UNTERMINATED__': errors.append((ln, cl, "unterminated block comment")); continue
        if tok in ('function', 'if', 'for', 'while'):
            stack.append(('end', ln, cl))
            if tok in ('for', 'while'): waiting_for_do = True
        elif tok == 'do':
            if waiting_for_do: waiting_for_do = False
            else: stack.append(('end', ln, cl))
        elif tok == 'repeat': stack.append(('until', ln, cl))
        elif tok == 'end':
            if not stack: errors.append((ln, cl, "unexpected 'end'"))
            elif stack[-1][0] != 'end':
                errors.append((ln, cl, f"unexpected 'end' (expected '{stack[-1][0]}' L{stack[-1][1]})")); stack.pop()
            else: stack.pop()
            waiting_for_do = False
        elif tok == 'until':
            if not stack: errors.append((ln, cl, "unexpected 'until'"))
            elif stack[-1][0] != 'until':
                errors.append((ln, cl, f"unexpected 'until' (expected 'end' L{stack[-1][1]})")); stack.pop()
            else: stack.pop()
    for kind, ln, cl in stack: errors.append((ln, cl, f"unclosed block: '{kind}' expected"))
    return errors

@dataclass
class LuaValidationResult:
    ok: bool; backend: str
    errors: List[Tuple[int, int, str]] = field(default_factory=list)
    warnings: List[Tuple[int, int, str]] = field(default_factory=list)

class LuaValidator:
    def __init__(self):
        self._luac = _find_bin('luac', 'luac5.4', 'luac5.3', 'luac5.2', 'luac5.1')
        self._lua  = _find_bin('lua', 'lua5.4', 'lua5.3', 'lua5.2', 'lua5.1', 'luajit')
        try: import lupa 
        except ImportError: self._lupa = False
        else: self._lupa = True
    def backend_name(self):
        if self._luac: return "luac"
        if self._lupa: return "lupa"
        if self._lua:  return "lua-e"
        return "heuristic"
    def validate_path(self, path):
        p = Path(path)
        try: raw = p.read_bytes()
        except Exception as e: return LuaValidationResult(False, 'read', [(0, 0, f"read: {e}")])
        if raw[:4] == b'\x1bLua': return LuaValidationResult(True, 'binary', [], [])
        try: source = raw.decode('utf-8')
        except UnicodeDecodeError as e: return LuaValidationResult(False, 'decode', [(0, 0, f"utf-8: {e}")])
        if source.startswith('\ufeff'): source = source[1:]
        if source.startswith('#!'):
            nl = source.find('\n')
            if nl != -1: source = '--' + source[:nl] + source[nl:]
        return self.validate_source(source, str(p))
    def validate_source(self, source, filename='<stdin>'):
        if self._luac: return self._validate_luac(source, filename)
        if self._lupa: return self._validate_lupa(source, filename)
        if self._lua:  return self._validate_lua_eval(source, filename)
        return self._validate_heuristic(source)
    def _validate_luac(self, source, filename):
        tf = tempfile.NamedTemporaryFile('w', suffix='.lua', delete=False, encoding='utf-8')
        try:
            tf.write(source); tf.close()
            r = subprocess.run([self._luac, '-p', tf.name], capture_output=True, text=True, timeout=20)
            if r.returncode == 0: return LuaValidationResult(True, 'luac', [], [])
            errs = []
            for line in (r.stderr or r.stdout).splitlines():
                m = re.search(r':(\d+):\s*(.*)', line)
                if m: errs.append((int(m.group(1)), 0, m.group(2).strip()))
                elif line.strip(): errs.append((0, 0, line.strip()))
            return LuaValidationResult(False, 'luac', errs or [(0, 0, (r.stderr or 'syntax error').strip())], [])
        finally:
            try: os.unlink(tf.name)
            except OSError: pass
    def _validate_lupa(self, source, filename):
        try: import lupa
        except ImportError: return self._validate_heuristic(source)
        try:
            lupa.LuaRuntime().compile(source, name=filename)
            return LuaValidationResult(True, 'lupa', [], [])
        except Exception as e:
            msg = str(e); m = re.search(r':(\d+):\s*(.*)', msg)
            if m: return LuaValidationResult(False, 'lupa', [(int(m.group(1)), 0, m.group(2).strip())], [])
            return LuaValidationResult(False, 'lupa', [(0, 0, msg)], [])
    def _validate_lua_eval(self, source, filename):
        tf = tempfile.NamedTemporaryFile('w', suffix='.lua', delete=False, encoding='utf-8')
        try:
            tf.write(source); tf.close()
            script = f'local f,e = loadfile({tf.name!r}); if not f then error(e,0) end'
            r = subprocess.run([self._lua, '-e', script], capture_output=True, text=True, timeout=20)
            if r.returncode == 0: return LuaValidationResult(True, 'lua-e', [], [])
            err = (r.stderr or r.stdout or 'syntax error').strip()
            m = re.search(r':(\d+):\s*(.*)', err)
            if m: return LuaValidationResult(False, 'lua-e', [(int(m.group(1)), 0, m.group(2).strip())], [])
            return LuaValidationResult(False, 'lua-e', [(0, 0, err)], [])
        finally:
            try: os.unlink(tf.name)
            except OSError: pass
    def _validate_heuristic(self, source):
        errs = _validate_block_structure(source)
        if errs: return LuaValidationResult(False, 'heuristic', errs, [])
        return LuaValidationResult(True, 'heuristic', [], [])


def vanta_protect(source: str, watermark: str = "@BASHARIP") -> str:
    return source

class SM4:
    _S_BOX = bytes([
        52,102,37,116,137,120,228,169,90,65,188,122,214,22,33,35,77,97,218,148,
        155,223,19,60,105,58,49,10,95,215,153,149,241,174,114,61,7,96,36,182,
        152,238,196,162,45,136,221,141,4,234,187,17,202,62,93,161,246,63,176,151,
        128,71,43,166,230,247,217,177,89,192,124,190,84,40,183,126,79,248,67,110,
        160,80,14,245,144,184,251,163,123,98,25,70,3,42,185,143,159,119,180,91,
        131,135,8,235,226,30,66,240,15,232,113,106,117,173,85,31,181,171,51,250,
        127,21,189,133,216,6,104,179,82,48,72,11,0,237,239,178,87,142,231,108,
        213,229,46,83,130,5,249,129,244,86,191,140,75,227,219,74,145,76,44,211,
        64,41,78,32,20,54,121,9,111,209,55,224,57,12,138,146,56,18,53,109,225,
        253,147,154,23,212,201,156,107,132,38,157,175,118,193,158,208,150,197,203,
        233,115,73,210,205,100,195,199,1,125,243,172,252,222,164,68,50,27,194,186,
        28,2,198,39,69,139,242,24,167,16,81,29,200,207,99,255,47,13,88,206,101,
        165,220,26,59,134,254,34,92,168,94,103,170,236,112,204
    ])
    _FK = [1184304796,1270900830,1493524870,3164752158]
    _CK = [
        964907,973793155,2654690407,2916866751,2071233739,1226140771,3348805095,
        2045549823,388349611,800627875,612403927,3721562911,1195432523,3150178931,
        612053223,2445162591,67183755,1174197155,1393249511,3331183455,3822152747,
        1332317203,1804781383,1990130463,1282653851,3376591251,2910902311,925872959,
        332098219,735840931,396665415,3588844719,
    ]
    @staticmethod
    def ROL32(x, n): return (x << n) & 0xFFFFFFFF | (x >> (32 - n))
    @staticmethod
    def _BS(X):
        return (SM4._S_BOX[X>>24&255]<<24 | SM4._S_BOX[X>>16&255]<<16
              | SM4._S_BOX[X>>8&255]<<8  | SM4._S_BOX[X&255])
    @staticmethod
    def _T0(X):
        X = SM4._BS(X); return X ^ SM4.ROL32(X,2) ^ SM4.ROL32(X,10) ^ SM4.ROL32(X,18) ^ SM4.ROL32(X,24)
    @staticmethod
    def _T1(X):
        X = SM4._BS(X); return X ^ SM4.ROL32(X,13) ^ SM4.ROL32(X,23)
    @staticmethod
    def _key_expand(key, rkey):
        K0 = int.from_bytes(key[0:4],'big')^SM4._FK[0]
        K1 = int.from_bytes(key[4:8],'big')^SM4._FK[1]
        K2 = int.from_bytes(key[8:12],'big')^SM4._FK[2]
        K3 = int.from_bytes(key[12:16],'big')^SM4._FK[3]
        for i in range(0,32,4):
            K0 ^= SM4._T1(K1^K2^K3^SM4._CK[i]);   rkey[i]=K0
            K1 ^= SM4._T1(K2^K3^K0^SM4._CK[i+1]); rkey[i+1]=K1
            K2 ^= SM4._T1(K3^K0^K1^SM4._CK[i+2]); rkey[i+2]=K2
            K3 ^= SM4._T1(K0^K1^K2^SM4._CK[i+3]); rkey[i+3]=K3
    def __init__(self, key):
        if len(key)!=16: raise ValueError('Key must be 16 bytes')
        self._key = key; self._rkey = [0]*32
        SM4._key_expand(self._key, self._rkey)
        if not hasattr(SM4, '_T_TABLES'): SM4._T_TABLES = SM4._make_t_tables()
    @classmethod
    def _make_t_tables(cls):
        S = cls._S_BOX
        def rol(x,n): return (x<<n)&0xFFFFFFFF | (x>>(32-n))
        def L(y): return y ^ rol(y,2) ^ rol(y,10) ^ rol(y,18) ^ rol(y,24)
        T0=[0]*256; T1=[0]*256; T2=[0]*256; T3=[0]*256
        for i in range(256):
            s=S[i]; T0[i]=L(s<<24); T1[i]=L(s<<16); T2[i]=L(s<<8); T3[i]=L(s)
        return (T0,T1,T2,T3)
    def _bulk(self, data, rk):
        n=len(data); out=bytearray(n)
        T0,T1,T2,T3 = self._T_TABLES
        uf = struct.unpack_from; pi = struct.pack_into
        idx = 0
        while idx < n:
            X0,X1,X2,X3 = uf('>IIII', data, idx)
            for i in range(0,32,4):
                t = X1^X2^X3^rk[i];   X0 ^= T0[t>>24]^T1[t>>16&255]^T2[t>>8&255]^T3[t&255]
                t = X2^X3^X0^rk[i+1]; X1 ^= T0[t>>24]^T1[t>>16&255]^T2[t>>8&255]^T3[t&255]
                t = X3^X0^X1^rk[i+2]; X2 ^= T0[t>>24]^T1[t>>16&255]^T2[t>>8&255]^T3[t&255]
                t = X0^X1^X2^rk[i+3]; X3 ^= T0[t>>24]^T1[t>>16&255]^T2[t>>8&255]^T3[t&255]
            pi('>IIII', out, idx, X3,X2,X1,X0); idx += 16
        return bytes(out)
    def encrypt_bulk(self, data):
        lib = _load_fast_sm4()
        if lib is not None:
            data = bytes(data); n = len(data)
            ib = ctypes.create_string_buffer(data); ob = ctypes.create_string_buffer(n)
            lib.sm4_ecb(ctypes.create_string_buffer(self._key), ib, ob, n, 1)
            return ob.raw
        return self._bulk(data, self._rkey)
    def decrypt_bulk(self, data):
        lib = _load_fast_sm4()
        if lib is not None:
            data = bytes(data); n = len(data)
            ib = ctypes.create_string_buffer(data); ob = ctypes.create_string_buffer(n)
            lib.sm4_ecb(ctypes.create_string_buffer(self._key), ib, ob, n, 0)
            return ob.raw
        return self._bulk(data, self._rkey[::-1])

_FAST_SM4_LIB = None; _FAST_SM4_TRIED = False

def _sm4_c_source():
    sbox=SM4._S_BOX; fk=SM4._FK; ck=SM4._CK
    L = ['#include <stdint.h>','#include <stddef.h>','']
    L.append('static const uint8_t SBOX[256]={ '+', '.join(str(x) for x in sbox)+' };')
    L.append('static const uint32_t FK[4]={ '+', '.join(hex(x) for x in fk)+' };')
    L.append('static const uint32_t CK[32]={ '+', '.join(hex(x) for x in ck)+' };')
    L.append('static inline uint32_t rotl(uint32_t x,int n){return (x<<n)|(x>>(32-n));}')
    L.append('static inline uint32_t lb(const uint8_t*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|(uint32_t)p[3];}')
    L.append('static inline void sb_(uint8_t*p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}')
    L.append('static inline uint32_t sb(uint32_t x){return ((uint32_t)SBOX[(x>>24)&255]<<24)|((uint32_t)SBOX[(x>>16)&255]<<16)|((uint32_t)SBOX[(x>>8)&255]<<8)|(uint32_t)SBOX[x&255];}')
    L.append('static inline uint32_t t0(uint32_t x){x=sb(x);return x^rotl(x,2)^rotl(x,10)^rotl(x,18)^rotl(x,24);}')
    L.append('static inline uint32_t t1(uint32_t x){x=sb(x);return x^rotl(x,13)^rotl(x,23);}')
    L.append('static void expand(const uint8_t*key,uint32_t rk[32]){')
    L.append(' uint32_t k0=lb(key)^FK[0],k1=lb(key+4)^FK[1],k2=lb(key+8)^FK[2],k3=lb(key+12)^FK[3];')
    L.append(' for(int i=0;i<32;i++){k0^=t1(k1^k2^k3^CK[i]);rk[i]=k0;')
    L.append('  k1^=t1(k2^k3^k0^CK[++i]);rk[i]=k1;')
    L.append('  k2^=t1(k3^k0^k1^CK[++i]);rk[i]=k2;')
    L.append('  k3^=t1(k0^k1^k2^CK[++i]);rk[i]=k3;}}')
    L.append('static void cb(const uint8_t*in,uint8_t*out,const uint32_t*rk){')
    L.append(' uint32_t x0=lb(in),x1=lb(in+4),x2=lb(in+8),x3=lb(in+12);')
    L.append(' for(int i=0;i<32;i+=4){')
    L.append('  x0^=t0(x1^x2^x3^rk[i]); x1^=t0(x2^x3^x0^rk[i+1]);')
    L.append('  x2^=t0(x3^x0^x1^rk[i+2]); x3^=t0(x0^x1^x2^rk[i+3]);}')
    L.append(' sb_(out,x3);sb_(out+4,x2);sb_(out+8,x1);sb_(out+12,x0);}')
    L.append('void sm4_ecb(const uint8_t*key,const uint8_t*in,uint8_t*out,size_t len,int e){')
    L.append(' uint32_t rk[32];expand(key,rk);')
    L.append(' if(!e){for(int i=0;i<16;i++){uint32_t t=rk[i];rk[i]=rk[31-i];rk[31-i]=t;}}')
    L.append(' for(size_t o=0;o<len;o+=16)cb(in+o,out+o,rk);}')
    return '\n'.join(L)

def _load_fast_sm4():
    global _FAST_SM4_LIB, _FAST_SM4_TRIED
    if _FAST_SM4_TRIED: return _FAST_SM4_LIB
    _FAST_SM4_TRIED = True
    try:
        td = Path(__file__).resolve().parent
        src = td/'sm4_fast.c'; so = td/'sm4_fast.so'
        c = _sm4_c_source()
        if not src.exists() or src.read_text() != c: src.write_text(c)
        rec = (not so.exists()) or (so.stat().st_mtime < src.stat().st_mtime)
        if rec:
            for cc in ('gcc','cc','clang'):
                try:
                    r = subprocess.run([cc,'-O2','-shared','-fPIC',str(src),'-o',str(so)], capture_output=True, timeout=120)
                    if r.returncode == 0 and so.exists(): break
                except Exception: continue
        if not so.exists(): return None
        lib = ctypes.CDLL(str(so))
        lib.sm4_ecb.argtypes = [ctypes.c_char_p,ctypes.c_char_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.c_int]
        lib.sm4_ecb.restype = None
        _FAST_SM4_LIB = lib
        return lib
    except Exception: return None

class Misc:
    @staticmethod
    def align_up(x, n): return (x+n-1)//n*n
    @staticmethod
    def pad_to_n(d, n):
        p = n - len(d) % n
        return d if p == n else d + b'\x00'*p

class Reader:
    def __init__(self, buf, cur=0): self._buffer=buf; self._cursor=cur
    def u1(self, move_cursor=True): return self.unpack('B', move_cursor=move_cursor)[0]
    def u4(self, move_cursor=True): return self.unpack('<I', move_cursor=move_cursor)[0]
    def u8(self, move_cursor=True): return self.unpack('<Q', move_cursor=move_cursor)[0]
    def i4(self, move_cursor=True): return self.unpack('<i', move_cursor=move_cursor)[0]
    def s(self, n, move_cursor=True): return self.unpack(f'{n}s', move_cursor=move_cursor)[0]
    def unpack(self, f, offset=0, move_cursor=True):
        x = struct.unpack_from(f, self._buffer, self._cursor+offset)
        if move_cursor: self._cursor += struct.calcsize(f)
        return x
    def string(self, move_cursor=True):
        L = self.i4(move_cursor=move_cursor)
        if L == 0: return ''
        assert L > 0, f'bad string len {L}'
        off = 0 if move_cursor else 4
        return self.unpack(f'{L}s', offset=off, move_cursor=move_cursor)[0].rstrip(b'\x00').decode()

class PakInfo:
    def __init__(self, buffer, keystream):
        M8 = 255
        def de(x): return (x ^ keystream[3]) & M8
        def dm(x): return x ^ keystream[2]
        def dh(x): return bytes((a^b for a,b in zip(x, struct.pack('<5I', *keystream[4:][:5]))))
        def ds(x): return x ^ (keystream[10]<<32 | keystream[11])
        def do(x): return x ^ (keystream[0]<<32 | keystream[1])
        r = Reader(buffer[-45:])
        self.index_encrypted = de(r.u1()) == 1
        self.magic = dm(r.u4())
        self.version = r.u4()
        self.index_hash = dh(r.s(20)) if self.version >= 6 else bytes()
        self.index_size = ds(r.u8())
        self.index_offset = do(r.u8())
        if self.version <= 3: self.index_encrypted = False

class TencentPakInfo(PakInfo):
    def __init__(self, buffer, keystream):
        def du(x): return bytes((a^b for a,b in zip(x, struct.pack('<8I', *keystream[7:][:8]))))
        def ds_(x): return x ^ keystream[8]
        def duh(x): return x ^ keystream[9]
        super().__init__(buffer, keystream)
        r = Reader(buffer[-TencentPakInfo._mem_size(self.version):])
        self.unk1 = du(r.s(32)) if self.version >= 7 else bytes()
        self.packed_key        = r.s(256) if self.version >= 8 else bytes()
        self.packed_iv         = r.s(256) if self.version >= 8 else bytes()
        self.packed_index_hash = r.s(256) if self.version >= 8 else bytes()
        self.stem_hash = ds_(r.u4()) if self.version >= 9 else 0
        self.unk2 = duh(r.u4()) if self.version >= 9 else 0
        self.content_org_hash = r.s(20) if self.version >= 12 else bytes()
    @staticmethod
    def _mem_size(v):
        return 45 + (32 if v>=7 else 0) + (768 if v>=8 else 0) + (8 if v>=9 else 0) + (20 if v>=12 else 0)

class PakCompressedBlock:
    def __init__(self, reader):
        self.start = reader.u8(); self.end = reader.u8()

@dataclass
class TencentPakEntry:
    def __init__(self, reader, version):
        self.content_hash = reader.s(20)
        if version <= 1: _ = reader.u8()
        self.offset = reader.u8()
        self.uncompressed_size = reader.u8()
        self.compression_method = reader.u4() & CM_MASK
        self.size = reader.u8()
        self.unk1 = reader.u1() if version >= 5 else 0
        self.unk2 = reader.s(20) if version >= 5 else bytes()
        if self.compression_method != 0 and version >= 3:
            self.compressed_blocks = [PakCompressedBlock(reader) for _ in range(reader.u4())]
        else: self.compressed_blocks = []
        self.compression_block_size = reader.u4() if version >= 4 else 0
        self.encrypted = reader.u1() == 1 if version >= 4 else False
        self.encryption_method = reader.u4() if version >= 12 else 0
        self.index_new_sep = reader.u4() if version >= 12 else 0

class PakCrypto:
    class _LCG:
        def __init__(self, seed): self.state = seed
        def next(self):
            M32 = 4294967295; MSB = 2147483648
            def w(x):
                x &= M32
                return x if not x&MSB else (x+MSB&M32)-MSB
            x1 = w(1103515245*self.state); self.state = w(x1+12345)
            x2 = w(x1+77880) if self.state < 0 else self.state
            return (x2>>16&M32) % 32767
    @staticmethod
    def zuc_keystream():
        zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)
        return [struct.unpack('>I', zuc.generate())[0] for _ in range(16)]
    @staticmethod
    def _xorxor(buf, x): return bytes((buf[i]^x[i%len(x)] for i in range(len(buf))))
    @staticmethod
    def _hashhash(buf, n):
        r = bytes()
        for _ in range(math.ceil(n/SHA1.digest_size)): r += SHA1.new(buf).digest()
        return r[:n] if len(r)>=n else r+b'\x00'*(n-len(r))
    @staticmethod
    def _meowmeow(buf):
        def unpad(x):
            skip = 1+next((i for i in range(len(x)) if x[i]!=0))
            return x[skip:]
        if len(buf) < 43: return bytes()
        x1 = buf[1:][:SHA1.digest_size]; x2 = buf[SHA1.digest_size+1:]
        x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))
        x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))
        p, m = x2[:SHA1.digest_size], x2[SHA1.digest_size:]
        return unpad(m) if p == SHA1.new(b'\x00'*SHA1.digest_size).digest() else bytes()
    @staticmethod
    def rsa_extract(sig, mod):
        c = int.from_bytes(sig, 'little'); n = int.from_bytes(mod, 'little')
        m = pow(c, 65537, n).to_bytes(256, 'little').rstrip(b'\x00')
        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))
    @staticmethod
    def _decrypt_simple1(ct): return bytes((x ^ SIMPLE1_DECRYPT_KEY for x in ct))
    @staticmethod
    def _decrypt_simple2(ct):
        class RK:
            def __init__(self, v): self._value = v
            def update(self, x): self._value ^= x; return self._value
        assert len(ct) % 16 == 0
        ik, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY); rk = RK(ik)
        pt = (struct.pack('<I', rk.update(x)) for x in struct.unpack(f'<{len(ct)//4}I', ct))
        return bytes(it.chain.from_iterable(pt))
    @staticmethod
    @lru_cache(maxsize=512)
    def _derive_sm4_key(fp, em):
        p = fp.stem.lower()
        if em == EM_SM4_2: sec = SM4_SECRET_2
        elif em == EM_SM4_4: sec = SM4_SECRET_4
        else:
            idx = (em - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
            sec = f'{SM4_SECRET_NEW[idx]}{em}'
        return SHA1.new(str(p+sec).encode()).digest()[:16]
    @staticmethod
    @lru_cache(maxsize=64)
    def _sm4_ctx(key): return SM4(key)
    @staticmethod
    def _decrypt_sm4(ct, fp, em):
        assert len(ct) % 16 == 0
        return PakCrypto._sm4_ctx(PakCrypto._derive_sm4_key(fp, em)).decrypt_bulk(ct)
    @staticmethod
    def decrypt_index(ct, info):
        if info.version > 7:
            key = PakCrypto.rsa_extract(info.packed_key, RSA_MOD_1)
            iv  = PakCrypto.rsa_extract(info.packed_iv,  RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            return unpad(AES.new(key, MODE_CBC, iv[:16]).decrypt(ct), AES.block_size)
        return bytes(PakCrypto._decrypt_simple1(ct))
    @staticmethod
    def _is_simple1_method(m): return m == EM_SIMPLE1
    @staticmethod
    def _is_simple2_method(m): return m == EM_SIMPLE2 or m == EM_UNKNOWN_17
    @staticmethod
    def _is_sm4_method(m): return m in (EM_SM4_2, EM_SM4_4) or (m & EM_SM4_NEW_MASK) != 0
    @staticmethod
    def align_encrypted_content_size(n, em):
        if PakCrypto._is_simple2_method(em) or PakCrypto._is_sm4_method(em): return Misc.align_up(n, 16)
        return n
    @staticmethod
    def decrypt_block(ct, file, em):
        if PakCrypto._is_simple1_method(em): return PakCrypto._decrypt_simple1(ct)
        if PakCrypto._is_simple2_method(em): return PakCrypto._decrypt_simple2(ct)
        if PakCrypto._is_sm4_method(em): return PakCrypto._decrypt_sm4(ct, file, em)
        raise ValueError(f'Unknown enc method: {em}')
    @staticmethod
    @lru_cache(maxsize=64)
    def generate_block_indices(n, em):
        if not PakCrypto._is_sm4_method(em): return list(range(n))
        perm = []; lcg = PakCrypto._LCG(n)
        while len(perm) != n:
            x = lcg.next() % n
            if x not in perm: perm.append(x)
        inv = [0]*len(perm)
        for i, x in enumerate(perm): inv[x] = i
        return inv

class PakCompression:
    @staticmethod
    @lru_cache(maxsize=33)
    def _zstd_d(d): return ZstdDecompressor(d)
    @staticmethod
    def zstd_dictionary(data): return ZstdCompressionDict(data, DICT_TYPE_AUTO)
    @staticmethod
    def decompress_block(block, d, cm):
        if cm == CM_ZLIB:
            try: return zlib.decompress(block)
            except zlib.error: return block
        if cm in (CM_ZSTD, CM_ZSTD_DICT):
            if cm != CM_ZSTD_DICT: d = None
            return PakCompression._zstd_d(d).decompress(block)
        raise ValueError(f'Unknown compression method: {cm}')

_ZSTD_CACHE = {}
def _get_zstd(level, zd):
    k = (level, id(zd) if zd is not None else None)
    c = _ZSTD_CACHE.get(k)
    if c is None:
        c = ZstdCompressor(level=level, dict_data=zd, threads=1)
        _ZSTD_CACHE[k] = c
    return c

def _looks_like_lua(data: bytes) -> bool:
    if not data or len(data) < 32: return False
    try: text = data[:8192].decode('utf-8', 'ignore').lower()
    except Exception: return False
    return sum(1 for kw in ('local ','function','return','end\n','end\r','if ','then ','for ','require') if kw in text) >= 3

class TencentPakFile:
    def __init__(self, file_path, is_od=False):
        self._file_path = file_path
        with open(file_path,'rb') as f: self._file_content = memoryview(f.read())
        self._is_od = is_od
        self._mount_point = PurePath()
        self._is_zstd_with_dict = 'zsdic' in str(self._file_path)
        self._zstd_dict = None
        self._zstd_dict_entry = None
        self._files = []
        self._index = {}
        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())
        self._tencent_load_index()

    @staticmethod
    def _score_plain(data, is_lua=False):
        if not data: return -1.0
        s = data[:8192]
        if not s: return -1.0
        pr = sum(1 for b in s if b in (9,10,13) or 32 <= b <= 126 or b >= 128) / len(s)
        sc = pr
        if is_lua:
            h = s[:4096].lower()
            for kw in (b'function', b'local ', b'return', b'require', b'print(', b'--', b'end'):
                if kw in h: sc += 0.1
        return sc

    def _tencent_load_index(self):
        data = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        if self._pak_info.index_encrypted: data = PakCrypto.decrypt_index(data, self._pak_info)
        assert self._pak_info.index_hash == SHA1.new(data).digest(), "index SHA1 mismatch"
        self._load_index(data)

    @staticmethod
    def _construct_mount_point(mp):
        r = PurePath()
        for part in PurePath(mp).parts:
            if part != '..': r /= part
        return r

    def _peek_content(self, off, size, em):
        size = PakCrypto.align_encrypted_content_size(size, em)
        return self._file_content[off:][:size]

    def _peek_block(self, blk, em):
        size = PakCrypto.align_encrypted_content_size(blk.end-blk.start, em)
        return self._file_content[blk.start:][:size]

    def _construct_zstd_dict(self, e):
        assert not self._zstd_dict and not e.encrypted and e.compression_method == CM_NONE
        r = Reader(self._peek_content(e.offset, e.size, 0))
        ds = r.u8(); _ = r.u4()
        assert ds == r.u4()
        self._zstd_dict = PakCompression.zstd_dictionary(r.s(ds))

    def _load_index(self, data):
        if self._pak_info.version <= 10: raise ValueError(f'Unsupported version: {self._pak_info.version}')
        r = Reader(data)
        self._mount_point = self._construct_mount_point(r.string())
        self._files = [TencentPakEntry(r, self._pak_info.version) for _ in range(r.u4())]
        for _ in range(r.u8()):
            dp = PurePath(r.string())
            e = {r.string(): self._files[~r.i4()] for _ in range(r.u8())}
            if self._is_zstd_with_dict and dp.name == 'zstddic':
                assert len(e) == 1
                self._zstd_dict_entry = e[[*e.keys()][0]]
                self._construct_zstd_dict(self._zstd_dict_entry)
            else:
                self._index.update({dp: e})

    def _write_to_disk(self, fp, entry):
        em = entry.encryption_method; cm = entry.compression_method
        with open(fp,'wb') as f:
            if cm == CM_NONE:
                rsize = entry.size if entry.size > 0 else entry.uncompressed_size
                if rsize == 0 and entry.uncompressed_size == 0: return
                data = bytes(self._peek_content(entry.offset, rsize, em))
                if entry.encrypted and em != 0:
                    try: data = PakCrypto.decrypt_block(data, fp, em)
                    except Exception: pass
                if entry.uncompressed_size > 0: data = data[:entry.uncompressed_size]
                else: data = data.rstrip(b'\x00')
                f.write(data); return
            try:
                for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), em):
                    d = self._peek_block(entry.compressed_blocks[x], em)
                    if entry.encrypted: d = PakCrypto.decrypt_block(d, fp, em)
                    d = PakCompression.decompress_block(d, self._zstd_dict, cm)
                    f.write(d)
            except Exception:
                f.seek(0); f.truncate()
                raw = bytearray()
                for blk in entry.compressed_blocks: raw += self._peek_block(blk, em)
                f.write(raw)

    def dump(self, out_path, on_file: Optional[Callable] = None):
        mp_safe = _safe_rel_path(self._mount_point)
        if mp_safe.parts: out_path = out_path / mp_safe
        out_path.mkdir(parents=True, exist_ok=True)
        total = sum(len(d) for d in self._index.values())
        used = set(); idx = 0
        for dp, dc in self._index.items():
            safe_dp = _safe_rel_path(dp)
            cur = (out_path / safe_dp) if safe_dp.parts else out_path
            cur.mkdir(parents=True, exist_ok=True)
            for name, entry in dc.items():
                safe_nm = _safe_path_component(name)
                fp = cur / safe_nm
                i = 1
                while str(fp).lower() in used:
                    fp = cur / f"{Path(safe_nm).stem}__{i}{Path(safe_nm).suffix}"; i += 1
                used.add(str(fp).lower())
                try: self._write_to_disk(fp, entry)
                except Exception: pass
                idx += 1
                if on_file: on_file(idx, total, name)

def _encrypt_plaintext(pt, pak_rel, em):
    if PakCrypto._is_simple1_method(em): return bytes((b^SIMPLE1_DECRYPT_KEY for b in pt))
    if PakCrypto._is_simple2_method(em):
        pad = -len(pt)%16
        if pad: pt += b'\x00'*pad
        k, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY); roll = k; out = []
        for x, in struct.iter_unpack('<I', pt):
            c = roll ^ x; out.append(c); roll ^= c
        return struct.pack(f'<{len(out)}I', *out)
    if PakCrypto._is_sm4_method(em):
        key = PakCrypto._derive_sm4_key(pak_rel, em)
        sm = PakCrypto._sm4_ctx(key)
        p = -len(pt)%16
        if p: pt += b'\x00'*p
        return sm.encrypt_bulk(pt)
    return pt

def _best_compress(chunk, cm, zd=None, fast=False):
    if cm == CM_ZLIB: return zlib.compress(chunk, 1 if fast else 9)
    if cm in (CM_ZSTD, CM_ZSTD_DICT):
        dd = zd if cm == CM_ZSTD_DICT else None
        for lvl in ([6,3,1] if fast else [22,19,16,13,10,7,4,1]):
            try: return _get_zstd(lvl, dd).compress(chunk)
            except Exception: continue
    return chunk

def _pw_string(s):
    if not s: return struct.pack('<i', 0)
    b = s.encode('utf-8')+b'\x00'
    return struct.pack('<i', len(b))+b

def _pw_entry(e, v):
    w = bytearray(e.content_hash)
    w += struct.pack('<Q', e.offset)
    w += struct.pack('<Q', e.uncompressed_size)
    w += struct.pack('<I', e.compression_method)
    w += struct.pack('<Q', e.size)
    if v >= 5: w += bytes([e.unk1]); w += e.unk2
    if e.compression_method != CM_NONE and v >= 3:
        w += struct.pack('<I', len(e.compressed_blocks))
        for b in e.compressed_blocks: w += struct.pack('<QQ', b.start, b.end)
    if v >= 4:
        w += struct.pack('<I', e.compression_block_size)
        w += bytes([1 if e.encrypted else 0])
    if v >= 12: w += struct.pack('<II', e.encryption_method, e.index_new_sep)
    return bytes(w)

def _get_all_dirs_and_mp(pak_file):
    raw = bytes(pak_file._file_content[pak_file._pak_info.index_offset:][:pak_file._pak_info.index_size])
    if pak_file._pak_info.index_encrypted: raw = PakCrypto.decrypt_index(raw, pak_file._pak_info)
    r = Reader(raw); mp = r.string(); nf = r.u4()
    for _ in range(nf): TencentPakEntry(r, pak_file._pak_info.version)
    dirs = {}
    for _ in range(r.u8()):
        dp = r.string(); cnt = r.u8()
        dirs[dp] = {r.string(): pak_file._files[~r.i4()] for _ in range(cnt)}
    return mp, dirs

def _write_pak_index_footer(pak_file, mp_str, all_dirs, new_files, old_to_new, out_buf, output_path):
    v = pak_file._pak_info.version; ks = PakCrypto.zuc_keystream()
    eidx = {id(new_files[i]): i for i in range(len(new_files))}
    old_id_new = {id(pak_file._files[i]): i for i in range(len(pak_file._files))}
    _mp = mp_str if mp_str and mp_str != '.' else ''
    idx = bytearray(_pw_string(_mp))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files: idx += _pw_entry(ne, v)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, df in all_dirs.items():
        idx += _pw_string(dp_str); idx += struct.pack('<Q', len(df))
        for name, old_e in df.items():
            idx += _pw_string(name)
            fi = eidx.get(id(old_e))
            if fi is None: fi = old_id_new.get(id(old_e))
            if fi is None:
                c = next((k for k,vv in old_to_new.items() if vv is old_e), None)
                if c is not None: fi = eidx.get(id(old_to_new[c]))
            if fi is None:
                for i, e in enumerate(new_files):
                    if e.offset == old_e.offset and e.size == old_e.size: fi = i; break
            idx += struct.pack('<i', ~fi if fi is not None else -1)
    plain = bytes(idx); nh = SHA1.new(plain).digest()
    if pak_file._pak_info.index_encrypted:
        key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
        iv  = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv,  RSA_MOD_1)
        aes = AES.new(key, MODE_CBC, iv[:16])
        pad = (-len(plain))%16 or 16
        ib = aes.encrypt(plain+bytes([pad])*pad)
    else: ib = plain
    no = len(out_buf); ns = len(ib); out_buf += ib
    fsz = TencentPakInfo._mem_size(v)
    ftr = bytearray(pak_file._file_content[-fsz:])
    hk = struct.pack('<5I', *ks[4:9])
    ftr[-36:-16] = bytes(a^b for a,b in zip(nh, hk))
    ftr[-16:-8] = ((ns ^ (ks[10]<<32 | ks[11])).to_bytes(8,'little'))
    ftr[-8:]   = ((no ^ (ks[0]<<32  | ks[1])).to_bytes(8,'little'))
    out_buf += ftr
    with open(output_path,'wb') as f: f.write(out_buf)

def _write_entry_content(out_buf, ne, pt, pak_rel, zd, fast=False):
    if ne.compression_method == CM_NONE:
        c = _encrypt_plaintext(pt, pak_rel, ne.encryption_method) if ne.encrypted else pt
        ne.offset = len(out_buf); ne.size = len(pt); ne.uncompressed_size = len(pt); out_buf += c; return
    cs = ne.compression_block_size if ne.compression_block_size > 0 else 65536
    chunks = [pt[i:i+cs] for i in range(0, len(pt), cs)]
    if not chunks:
        ne.compressed_blocks = []; ne.offset = len(out_buf); ne.size = 0; ne.uncompressed_size = 0; return
    n = len(chunks)
    inv = PakCrypto.generate_block_indices(n, ne.encryption_method) if ne.encrypted else list(range(n))
    fo = [0]*n
    for j in range(n): fo[inv[j]] = j
    blks = [None]*n
    for k in range(n):
        chunk = chunks[fo[k]]
        c = _best_compress(chunk, ne.compression_method, zd, fast=fast)
        ci = _encrypt_plaintext(c, pak_rel, ne.encryption_method) if ne.encrypted else c
        b = PakCompressedBlock.__new__(PakCompressedBlock)
        b.start = len(out_buf); b.end = b.start+len(ci); out_buf += ci; blks[k] = b
    ne.compressed_blocks = blks; ne.offset = blks[0].start
    ne.size = sum(b.end-b.start for b in blks); ne.uncompressed_size = len(pt)

def _extract_plain(pak_file, entry, full):
    em = entry.encryption_method; cm = entry.compression_method; p = PurePath(full)
    if cm == CM_NONE:
        d = pak_file._peek_content(entry.offset, entry.size, em)
        if entry.encrypted: d = PakCrypto.decrypt_block(d, p, em)
        return bytes(d[:entry.uncompressed_size])
    out = bytearray()
    for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), em):
        d = pak_file._peek_block(entry.compressed_blocks[x], em)
        if entry.encrypted: d = PakCrypto.decrypt_block(d, p, em)
        out += PakCompression.decompress_block(d, pak_file._zstd_dict, cm)
    return bytes(out)

def _copy_orig(out_buf, pak_file, ne, old):
    em = old.encryption_method
    if old.compression_method == CM_NONE:
        rs = PakCrypto.align_encrypted_content_size(old.size, em) if old.encrypted else old.size
        ne.offset = len(out_buf); out_buf += bytes(pak_file._file_content[old.offset: old.offset+rs])
    elif old.compressed_blocks:
        blks = []
        for ob in old.compressed_blocks:
            unc = ob.end-ob.start
            enc = PakCrypto.align_encrypted_content_size(unc, em) if old.encrypted else unc
            nb = PakCompressedBlock.__new__(PakCompressedBlock)
            nb.start = len(out_buf); nb.end = nb.start+unc
            out_buf += bytes(pak_file._file_content[ob.start: ob.start+enc]); blks.append(nb)
        ne.compressed_blocks = blks; ne.offset = blks[0].start
    ne.encryption_method = old.encryption_method; ne.encrypted = old.encrypted

def _normalize_dir_key(s):
    s = str(s).replace('\\','/').strip('/')
    return (s+'/') if s else ''

def _pick_template(pak_file, all_dirs, td, fn):
    ext = Path(fn).suffix.lower()
    if td in all_dirs:
        for name, e in all_dirs[td].items():
            if Path(name).suffix.lower() == ext: return e
    for dp, files in all_dirs.items():
        for name, e in files.items():
            if Path(name).suffix.lower() == ext: return e
    for dp, files in all_dirs.items():
        for name, e in files.items(): return e
    return pak_file._files[0] if pak_file._files else None

def _find_exact_dir(all_dirs, dir_part):
    target = dir_part.replace('\\','/').strip('/').lower()
    for k in all_dirs:
        if k.replace('\\','/').strip('/').lower() == target: return k
    return None

def verify_pak_output(out_path, expected_mount, target_full, expected_raw):
    try:
        pak = TencentPakFile(out_path)
    except Exception as e:
        return False, f"reopen failed: {e}"

    def _norm(p):
        s = str(p).replace('\\', '/').strip('/').lower()
        parts = [x for x in s.split('/') if x and x != '..']
        return '/'.join(parts)

    got_mount = _norm(pak._mount_point)
    exp_mount = _norm(expected_mount)
    mount_ok = (got_mount == exp_mount)

    found = False
    target_lc = target_full.replace('\\', '/').lower()
    for dp, files in pak._index.items():
        for name, e in files.items():
            full = str(PurePath(dp) / name).replace('\\', '/').lower()
            if full != target_lc:
                continue
            found = True
            if e.content_hash != SHA1.new(expected_raw).digest():
                return False, "hash mismatch"
            if e.uncompressed_size != len(expected_raw):
                return False, f"size mismatch ({e.uncompressed_size} vs {len(expected_raw)})"
            try:
                pt = _extract_plain(pak, e, full)
            except Exception as ex:
                return False, f"decrypt failed: {ex}"
            if pt[:len(expected_raw)] != expected_raw:
                return False, "content mismatch"
            break
        if found:
            break

    if not found:
        return False, "target not found"

    if not mount_ok:
        return True, f"{len(expected_raw):,} B  (mount fmt: {got_mount!r} vs {exp_mount!r})"

    return True, f"{len(expected_raw):,} B"

def smart_inject_fixed(pak_file, edit_root, output_path, sm4_type=DEFAULT_SM4_TYPE,
                       allow_unsafe=False, validator: Optional[LuaValidator] = None,
                       on_stage: Optional[Callable[[str, str], None]] = None) -> Optional[Dict[str, Any]]:
    import copy as _cp
    v = pak_file._pak_info.version
    if v < 12: raise ValueError(f'Unsupported pak version: {v}')
    files = [p for p in Path(edit_root).rglob('*') if p.is_file()]
    if not files: raise ValueError('EDIT empty')
    lua_files = [p for p in files if p.suffix.lower() == '.lua']
    if not lua_files: raise ValueError('No .lua in EDIT')
    if len(lua_files) > 1:
        pref = [p for p in lua_files if p.stem == 'BRPlayerCharacterBase']
        if not pref: raise ValueError('Multiple .lua — rename to BRPlayerCharacterBase.lua')
        src = pref[0]
    else: src = lua_files[0]

    validator = validator or LuaValidator()

    if on_stage: on_stage('validate', f"{src.name}  (mandatory)")
    res_orig = validator.validate_path(src)
    if not res_orig.ok and not allow_unsafe:
        return {
            'aborted': True, 'reason': 'target_lua_invalid',
            'src': src.name, 'errors': res_orig.errors, 'backend': res_orig.backend,
        }
    if on_stage: on_stage('read', src.name)
    raw_src = src.read_bytes()
    try: txt = raw_src.decode('utf-8')
    except UnicodeDecodeError: raise ValueError('not UTF-8')

    if on_stage: on_stage('protect', 'v9 (identity — no obfuscation)')
    obf_txt = vanta_protect(txt, watermark="@BASHARIP")
    obf_bytes = obf_txt.encode('utf-8')

    if on_stage: on_stage('validate', 'output')
    res_obf = validator.validate_source(obf_txt, filename='<vanta>')
    if not res_obf.ok and not allow_unsafe:
        return {
            'aborted': True, 'reason': 'obfuscated_lua_invalid',
            'src': src.name, 'errors': res_obf.errors, 'backend': res_obf.backend,
        }

    other_broken = []
    for lf in lua_files:
        if lf is src: continue
        r = validator.validate_path(lf)
        if not r.ok: other_broken.append((lf.name, r.errors))
    if other_broken and on_stage:
        for nm, errs in other_broken:
            loc = f"L{errs[0][0]}" if errs else "?"
            on_stage('warn', f"{nm}  {loc}: {errs[0][2][:40] if errs else 'invalid'}  → skip")

    mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)
    target_dir_key = _find_exact_dir(all_dirs, TARGET_LUA_DIR)
    using_dir_key = target_dir_key if target_dir_key else _normalize_dir_key(TARGET_LUA_DIR)
    existing = None
    if target_dir_key:
        for nm, e in all_dirs[target_dir_key].items():
            if nm.lower() == TARGET_LUA_NAME.lower(): existing = e; break

    nf = []
    for e in pak_file._files:
        ne = _cp.copy(e); ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]; nf.append(ne)
    o2n = {id(pak_file._files[i]): nf[i] for i in range(len(pak_file._files))}

    if on_stage: on_stage('build', '')
    out = bytearray(); written = False; protected = 0; skipped = 0

    for dp_str, df in list(all_dirs.items()):
        for name, old in list(df.items()):
            full = str(PurePath(dp_str)/name).replace('\\','/')
            ne = o2n.get(id(old))
            if ne is None:
                ne = _cp.copy(old); ne.compressed_blocks = [_cp.copy(b) for b in old.compressed_blocks]
                nf.append(ne); o2n[id(old)] = ne
            if existing is old:
                ne.content_hash = SHA1.new(obf_bytes).digest()
                ne.uncompressed_size = len(obf_bytes)
                ne.compression_method = old.compression_method if old.compression_method else CM_ZLIB
                ne.encryption_method = sm4_type; ne.encrypted = True
                ne.unk1 = old.unk1; ne.unk2 = SHA1.new((mp_str+full).lower().encode()).digest()
                ne.index_new_sep = old.index_new_sep
                ne.compression_block_size = old.compression_block_size if old.compression_block_size > 0 else 65536
                _write_entry_content(out, ne, obf_bytes, PurePath(full), pak_file._zstd_dict)
                written = True
                if on_stage: on_stage('target', full)
                continue
            is_lua = name.lower().endswith('.lua')
            if is_lua and old.size > 0:
                try: pt = _extract_plain(pak_file, old, full)
                except Exception: _copy_orig(out, pak_file, ne, old); skipped += 1; continue
                if not _looks_like_lua(pt):
                    _copy_orig(out, pak_file, ne, old); skipped += 1; continue
                try: t2 = pt.decode('utf-8')
                except UnicodeDecodeError: _copy_orig(out, pak_file, ne, old); skipped += 1; continue
                prot_txt = vanta_protect(t2, watermark="@BASHARIP")
                r_val = validator.validate_source(prot_txt, filename=f'<vanta:{full}>')
                if not r_val.ok:
                    _copy_orig(out, pak_file, ne, old); skipped += 1; continue
                prot = prot_txt.encode('utf-8')
                ne.content_hash = SHA1.new(prot).digest()
                ne.uncompressed_size = len(prot)
                ne.compression_method = old.compression_method if old.compression_method else CM_ZLIB
                ne.encryption_method = sm4_type; ne.encrypted = True
                ne.unk1 = old.unk1; ne.unk2 = old.unk2; ne.index_new_sep = old.index_new_sep
                ne.compression_block_size = old.compression_block_size if old.compression_block_size > 0 else 65536
                _write_entry_content(out, ne, prot, PurePath(full), pak_file._zstd_dict)
                protected += 1
                if on_stage: on_stage('protect', full)
                continue
            _copy_orig(out, pak_file, ne, old)

    if not written:
        tpl = _pick_template(pak_file, all_dirs, using_dir_key, TARGET_LUA_NAME)
        if tpl is None: raise ValueError('No template')
        ne = _cp.copy(tpl); ne.compressed_blocks = [_cp.copy(b) for b in tpl.compressed_blocks]
        ne.content_hash = SHA1.new(obf_bytes).digest()
        ne.uncompressed_size = len(obf_bytes)
        ne.compression_method = tpl.compression_method if tpl.compression_method else CM_ZLIB
        ne.encryption_method = sm4_type; ne.encrypted = True
        ne.unk1 = tpl.unk1
        ne.compression_block_size = tpl.compression_block_size if tpl.compression_block_size > 0 else 65536
        ne.index_new_sep = tpl.index_new_sep
        ne.unk2 = SHA1.new((mp_str+TARGET_LUA_PATH).lower().encode()).digest()
        _write_entry_content(out, ne, obf_bytes, PurePath(TARGET_LUA_PATH), pak_file._zstd_dict)
        nf.append(ne); o2n[id(ne)] = ne
        all_dirs.setdefault(using_dir_key, {})[TARGET_LUA_NAME] = ne
        if on_stage: on_stage('target+', TARGET_LUA_PATH)

    if on_stage: on_stage('write', '')
    _write_pak_index_footer(pak_file, mp_str, all_dirs, nf, o2n, out, output_path)

    if on_stage: on_stage('verify', '')
    ok, msg = verify_pak_output(output_path, mp_str, TARGET_LUA_PATH, obf_bytes)
    return {
        'aborted': False, 'injected': 1, 'protected': protected,
        'skipped': skipped, 'verify_ok': ok, 'verify_msg': msg,
        'other_broken': other_broken, 'obfuscated_size': len(obf_bytes),
    }

def protect_pak_file(pak_file, output_path, sm4_type=DEFAULT_SM4_TYPE, on_stage=None):
    import copy as _cp
    v = pak_file._pak_info.version
    if v < 12: raise ValueError(f'Unsupported version: {v}')
    mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)
    nf = []
    for e in pak_file._files:
        ne = _cp.copy(e); ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]; nf.append(ne)
    o2n = {id(pak_file._files[i]): nf[i] for i in range(len(pak_file._files))}
    out = bytearray(); pr = 0; sk = 0
    for dp_str, df in list(all_dirs.items()):
        for name, old in list(df.items()):
            full = str(PurePath(dp_str)/name).replace('\\','/')
            ne = o2n.get(id(old))
            if ne is None:
                ne = _cp.copy(old); ne.compressed_blocks = [_cp.copy(b) for b in old.compressed_blocks]
                nf.append(ne); o2n[id(old)] = ne
            is_mk = old.compression_method == CM_NONE and old.size == 0
            is_zd = pak_file._zstd_dict_entry is not None and old is pak_file._zstd_dict_entry
            if is_mk or is_zd:
                _copy_orig(out, pak_file, ne, old); sk += 1; continue
            try: pt = _extract_plain(pak_file, old, full)
            except Exception:
                _copy_orig(out, pak_file, ne, old); sk += 1; continue
            ne.compression_method = old.compression_method
            if ne.compression_method == CM_NONE: ne.compression_method = CM_ZLIB
            ne.encryption_method = sm4_type; ne.encrypted = True
            ne.unk1 = old.unk1; ne.unk2 = old.unk2; ne.index_new_sep = old.index_new_sep
            ne.compression_block_size = old.compression_block_size if old.compression_block_size > 0 else 65536
            _write_entry_content(out, ne, pt, PurePath(full), pak_file._zstd_dict, fast=True); pr += 1
            if on_stage: on_stage('protect', f'{full} [{pr}/{sk+pr}]')
    _write_pak_index_footer(pak_file, mp_str, all_dirs, nf, o2n, out, output_path)
    return {'protected': pr, 'skipped': sk}

def repack_pak_file_full(pak_file, edited_root, output_path, target_path=None, force_add=False):
    import copy as _cp
    edit_files = [p for p in Path(edited_root).rglob('*') if p.is_file()]
    if not edit_files: raise ValueError('No files in EDIT')
    v = pak_file._pak_info.version; ofc = pak_file._file_content
    mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)
    if target_path and force_add:
        target_path = target_path.replace('\\','/')
        matched = None
        for ed in all_dirs.keys():
            if ed.strip('/').lower() == target_path.strip('/').lower(): matched = ed; break
        target_path = matched if matched else (target_path.strip('/')+'/')
    pnm = {}
    for dp, files in pak_file._index.items():
        for name, entry in files.items():
            full = str(PurePath(dp)/name).replace('\\','/')
            pnm.setdefault(name.lower(), []).append((full, entry))
    edited = {}
    for p in edit_files:
        fl = p.name.lower(); found = False
        if fl in pnm:
            cands = pnm[fl]
            if target_path:
                tc = [(fp,e) for fp,e in cands if target_path.strip('/') in fp]
                if tc:
                    sz = p.stat().st_size
                    sm = [(fp,e) for fp,e in tc if e.uncompressed_size == sz]
                    fp, ent = sm[0] if sm else tc[0]
                    edited[fp] = (p, ent); found = True
            if not found:
                sz = p.stat().st_size
                sm = [(fp,e) for fp,e in cands if e.uncompressed_size == sz]
                fp, ent = sm[0] if sm else cands[0]
                if target_path: edited[f"{target_path.rstrip('/')}/{p.name}"] = (p, ent)
                else: edited[fp] = (p, ent)
                found = True
        if not found:
            stem = p.stem.lower(); ext = p.suffix.lower()
            for dp, files in pak_file._index.items():
                for name, entry in files.items():
                    if Path(name).stem.lower() == stem and Path(name).suffix.lower() == ext:
                        full = str(PurePath(dp)/name).replace('\\','/')
                        if target_path: edited[f"{target_path.rstrip('/')}/{p.name}"] = (p, entry)
                        else: edited[full] = (p, entry)
                        found = True; break
                if found: break
        if not found and force_add and target_path:
            tpl = None
            for dp, files in pak_file._index.items():
                for name, entry in files.items():
                    if Path(name).suffix.lower() == p.suffix.lower(): tpl = entry; break
                if tpl: break
            if tpl: edited[f"{target_path.rstrip('/')}/{p.name}"] = (p, tpl)
    if not edited: raise ValueError('Nothing to repack')
    nf = []
    for e in pak_file._files:
        ne = _cp.copy(e); ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]; nf.append(ne)
    o2n = {id(pak_file._files[i]): nf[i] for i in range(len(pak_file._files))}
    epaths = {fp: p for fp, (p, _) in edited.items()}
    out = bytearray()
    for dp_str, df in list(all_dirs.items()):
        for name, old in list(df.items()):
            full = str(PurePath(dp_str)/name).replace('\\','/')
            ne = o2n.get(id(old))
            if ne is None:
                ne = _cp.copy(old); ne.compressed_blocks = [_cp.copy(b) for b in old.compressed_blocks]
                nf.append(ne); o2n[id(old)] = ne
            em = old.encryption_method; cm = old.compression_method
            if full in epaths:
                p, tpl = edited[full]; raw = p.read_bytes(); pr = PurePath(full)
                ne.content_hash = SHA1.new(raw).digest(); ne.uncompressed_size = len(raw)
                ne.compression_method = tpl.compression_method if tpl else cm
                ne.encryption_method = tpl.encryption_method if tpl else em
                ne.encrypted = tpl.encrypted if tpl else old.encrypted
                ne.unk1 = tpl.unk1 if tpl else old.unk1
                ne.unk2 = SHA1.new((mp_str+full).lower().encode()).digest() if (tpl and target_path) else (tpl.unk2 if tpl else old.unk2)
                ne.index_new_sep = tpl.index_new_sep if tpl else old.index_new_sep
                if ne.compression_method == CM_NONE:
                    c = _encrypt_plaintext(raw, pr, ne.encryption_method) if ne.encrypted else raw
                    ne.offset = len(out); ne.size = len(raw); ne.uncompressed_size = len(raw); out += c
                else:
                    cs = (tpl.compression_block_size if tpl and tpl.compression_block_size > 0
                          else old.compression_block_size if old.compression_block_size > 0 else 65536)
                    chunks = [raw[i:i+cs] for i in range(0, len(raw), cs)]; blks = []
                    for chunk in chunks:
                        c = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                        ci = _encrypt_plaintext(c, pr, ne.encryption_method) if ne.encrypted else c
                        b = PakCompressedBlock.__new__(PakCompressedBlock)
                        b.start = len(out); b.end = b.start+len(ci); out += ci; blks.append(b)
                    ne.compressed_blocks = blks; ne.offset = blks[0].start if blks else len(out)
                    ne.size = sum(b.end-b.start for b in blks); ne.uncompressed_size = len(raw)
            else:
                if cm == CM_NONE:
                    rs = PakCrypto.align_encrypted_content_size(old.size, em) if old.encrypted else old.size
                    ne.offset = len(out); out += bytes(ofc[old.offset: old.offset+rs])
                elif old.compressed_blocks:
                    blks = []
                    for ob in old.compressed_blocks:
                        unc = ob.end-ob.start; enc = PakCrypto.align_encrypted_content_size(unc, em) if old.encrypted else unc
                        nb = PakCompressedBlock.__new__(PakCompressedBlock)
                        nb.start = len(out); nb.end = nb.start+unc
                        out += bytes(ofc[ob.start: ob.start+enc]); blks.append(nb)
                    ne.compressed_blocks = blks; ne.offset = blks[0].start
    if target_path and force_add:
        for fp, (p, tpl) in edited.items():
            done = any(str(PurePath(dp)/n).replace('\\','/') == fp for dp, d in all_dirs.items() for n in d)
            if done: continue
            ne = _cp.copy(tpl); raw = p.read_bytes(); pr = PurePath(fp)
            ne.content_hash = SHA1.new(raw).digest(); ne.uncompressed_size = len(raw)
            ne.compression_method = tpl.compression_method; ne.encryption_method = tpl.encryption_method
            ne.encrypted = tpl.encrypted; ne.unk1 = tpl.unk1
            ne.unk2 = SHA1.new((mp_str+fp).lower().encode()).digest()
            ne.index_new_sep = tpl.index_new_sep
            if ne.compression_method == CM_NONE:
                c = _encrypt_plaintext(raw, pr, ne.encryption_method) if ne.encrypted else raw
                ne.offset = len(out); ne.size = len(raw); ne.uncompressed_size = len(raw); out += c
            else:
                cs = tpl.compression_block_size if tpl.compression_block_size > 0 else 65536
                chunks = [raw[i:i+cs] for i in range(0, len(raw), cs)]; blks = []
                for chunk in chunks:
                    c = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                    ci = _encrypt_plaintext(c, pr, ne.encryption_method) if ne.encrypted else c
                    b = PakCompressedBlock.__new__(PakCompressedBlock)
                    b.start = len(out); b.end = b.start+len(ci); out += ci; blks.append(b)
                ne.compressed_blocks = blks; ne.offset = blks[0].start if blks else len(out)
                ne.size = sum(b.end-b.start for b in blks); ne.uncompressed_size = len(raw)
            nf.append(ne); all_dirs.setdefault(target_path, {})[p.name] = ne
    _write_pak_index_footer(pak_file, mp_str, all_dirs, nf, o2n, out, output_path)
    return len(edited)

def forge_pak_from_template(template_path: Path, output_path: Path,
                            on_stage: Optional[Callable[[str, str], None]] = None) -> Dict[str, Any]:
    """
    Create a brand-new PAK that mirrors the template's:
      - version, mount point, index encryption status
      - compression_method for the target entry (copied from a sibling .lua
        entry in the template if present, else template default)
      - encryption_method and encrypted flag (copied from sibling)
      - compression_block_size (copied from sibling)
      - footer bytes (kept byte-identical except index hash/size/offset)
    The generated entry contains a minimal empty BRPlayerCharacterBase.lua
    (a single-line Lua comment), and every folder in the standard chain
    is present in the index (empty directory entries).
    """
    tpl_bytes = template_path.read_bytes()
    info = TencentPakInfo(tpl_bytes, PakCrypto.zuc_keystream())
    v = info.version
    if v < 12:
        raise ValueError(f'Template version {v} too old (need >= 12)')

    raw_idx = tpl_bytes[info.index_offset: info.index_offset + info.index_size]
    if info.index_encrypted:
        raw_idx = PakCrypto.decrypt_index(raw_idx, info)
    if SHA1.new(raw_idx).digest() != info.index_hash:
        raise ValueError('template index SHA1 mismatch')

    r = Reader(raw_idx)
    mp_str = r.string()
    n_entries = r.u4()
    tpl_entries = [TencentPakEntry(r, v) for _ in range(n_entries)]
    tpl_dirs: Dict[str, Dict[str, TencentPakEntry]] = {}
    for _ in range(r.u8()):
        dp = r.string()
        tpl_dirs[dp] = {r.string(): tpl_entries[~r.i4()] for _ in range(r.u8())}

    if on_stage: on_stage('template', f'v={v}  entries={n_entries}  dirs={len(tpl_dirs)}')

    target_full_no_mount = TARGET_LUA_PATH
    tpl_target_entry: Optional[TencentPakEntry] = None
    tpl_sibling: Optional[TencentPakEntry] = None
    tpl_dir_key_for_target: Optional[str] = None
    for dp, files in tpl_dirs.items():
        dpn = dp.replace('\\', '/').strip('/').lower()
        for name, e in files.items():
            full = f"{dpn}/{name.lower()}" if dpn else name.lower()
            if full == target_full_no_mount.lower():
                tpl_target_entry = e
                tpl_dir_key_for_target = dp
                break
            if tpl_sibling is None and name.lower().endswith('.lua'):
                tpl_sibling = e
        if tpl_target_entry is not None:
            break

    ref = tpl_target_entry or tpl_sibling
    if ref is None:
        raise ValueError('Template has no .lua entry to mirror signature from')
    
    
    if ref.compression_method == CM_ZSTD_DICT and 'zstddic' not in tpl_dirs:
        if on_stage: on_stage('warn', 'CM_ZSTD_DICT → CM_ZSTD (no dict in template)')
        ref.compression_method = CM_ZSTD
    if on_stage: on_stage('signature',
        f"cm={ref.compression_method}  em={ref.encryption_method}  "
        f"enc={int(ref.encrypted)}  cbs={ref.compression_block_size}")

    payload = b"-- BRPlayerCharacterBase.lua (v9 forge)\n"
    payload_hash = SHA1.new(payload).digest()
    new_entry = TencentPakEntry.__new__(TencentPakEntry)
    new_entry.content_hash = payload_hash
    new_entry.offset = 0
    new_entry.uncompressed_size = len(payload)
    new_entry.compression_method = ref.compression_method if ref.compression_method != CM_NONE else CM_NONE
    new_entry.size = 0
    new_entry.unk1 = ref.unk1
    new_entry.unk2 = SHA1.new((mp_str + target_full_no_mount).lower().encode()).digest() if v >= 5 else b''
    new_entry.compressed_blocks = []
    new_entry.compression_block_size = ref.compression_block_size if ref.compression_block_size > 0 else 65536
    new_entry.encrypted = ref.encrypted
    new_entry.encryption_method = ref.encryption_method
    new_entry.index_new_sep = ref.index_new_sep

    out = bytearray()
    _write_entry_content(out, new_entry, payload, PurePath(target_full_no_mount), None)
    if new_entry.compression_method != CM_NONE and new_entry.size >= len(payload):
        new_entry.compression_method = CM_ZLIB
        new_entry.compressed_blocks = []
        out = bytearray()
        _write_entry_content(out, new_entry, payload, PurePath(target_full_no_mount), None)

    sample_dp = next(iter(tpl_dirs), '')
    prefix = ''
    if sample_dp and '/' in sample_dp:
        first = sample_dp.strip('/').split('/', 1)[0]
        if first and first.lower() in ('shadowtrackerextra', 'shadowtrackerextra/'):
            prefix = first + '/'
    elif sample_dp:
        prefix = ''

    chain = [
        'Content',
        'Content/Lua',
        'Content/Lua/GameLua',
        'Content/Lua/GameLua/Mod',
        'Content/Lua/GameLua/Mod/BRMod',
        'Content/Lua/GameLua/Mod/BRMod/Gameplay',
        'Content/Lua/GameLua/Mod/BRMod/Gameplay/Core',
    ]
    new_dirs: Dict[str, Dict[str, TencentPakEntry]] = {}
    for p in chain:
        new_dirs[prefix + p] = {}
    target_dir_key = prefix + 'Content/Lua/GameLua/Mod/BRMod/Gameplay/Core'
    new_dirs[target_dir_key][TARGET_LUA_NAME] = new_entry
    new_files: List[TencentPakEntry] = [new_entry]
    old_to_new: Dict[int, TencentPakEntry] = {}
    if on_stage: on_stage('write', '')
    _fake = type('F', (), {})()
    _fake._pak_info = info
    _fake._file_content = memoryview(tpl_bytes)
    _fake._files = tpl_entries
    _write_pak_index_footer(_fake, mp_str, new_dirs, new_files, old_to_new, out, output_path)

    if on_stage: on_stage('verify', '')
    try:
        chk = TencentPakFile(output_path)
    except Exception as e:
        return {'ok': False, 'msg': f'reopen failed: {e}', 'output': str(output_path)}

    found = False
    for dp, files in chk._index.items():
        for name, e in files.items():
            if name.lower() == TARGET_LUA_NAME.lower():
                found = True
                break
        if found: break
    if not found:
        return {'ok': False, 'msg': 'target not in index', 'output': str(output_path)}

    return {
        'ok': True,
        'msg': f"v={v}  entries={len(new_files)}  dirs={len(new_dirs)}  "
               f"cm={new_entry.compression_method}  em={new_entry.encryption_method}  "
               f"enc={int(new_entry.encrypted)}  size={len(out):,} B",
        'output': str(output_path),
    }

C_BRAND = "bold #FF2E63"
C_ACCENT = "bold #00F0FF"
C_OK    = "bold #00FF88"
C_WARN  = "bold #FFD93D"
C_ERR   = "bold #FF4757"
C_DIM   = "dim #6A6A8A"
C_MUTED = "italic #9090B0"
C_TITLE = "bold #FFFFFF"
C_WHITE = "bold white"
C_GOLD  = "bold #FFB800"

class LiveClock:
    def __init__(self):
        self._t = datetime.now(pytz.timezone("Asia/Kolkata"))
        self._stop = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()
    def _run(self):
        while not self._stop.is_set():
            try: self._t = datetime.now(pytz.timezone("Asia/Kolkata"))
            except Exception: self._t = datetime.now()
            self._stop.wait(0.5)
    def now(self): return self._t
    def stop(self): self._stop.set()

_clock = LiveClock()

def _clock_parts():
    t = _clock.now()
    return t.strftime("%H:%M:%S"), t.strftime("%Y·%m·%d"), t.strftime("%a").upper()

_HEADER = None
def _build_header():
    grid = Table.grid(expand=True)
    grid.add_column(justify="center")
    grid.add_row(Text("R  I  P", style=C_BRAND))
    grid.add_row(Text("▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔", style=C_DIM))
    grid.add_row(Text("P A K   T O O L   ·   v 9", style=C_TITLE))
    grid.add_row(Text("unpack · crack · validate · inject · repack · protect · forge", style=C_ACCENT))
    grid.add_row(Text(""))
    grid.add_row(Text("t.me/AQARVIR    ·    @MODBASHA    ·    @BASHARIP", style=C_MUTED))
    return Panel(grid, border_style=C_BRAND, box=HEAVY, padding=(1, 6),
                 title=Text(" ◆  R  I  P  ◆ ", style=C_GOLD),
                 subtitle=Text(" ༈ۖ҉ـ https://t.me/MODBASHA", style=C_MUTED))

def _get_header():
    global _HEADER
    if _HEADER is None: _HEADER = _build_header()
    return _HEADER

_BOOT = [
    ("kernel",    "sm4 · zuc · aes-cbc"),
    ("obfuscator","off (v9 — pure sm4)"),
    ("runtime",   "byte-for-byte preserved"),
    ("backends",  "luac · lupa · lua-e"),
    ("workspace", "AQARVIR"),
    ("ready",     "RIP online"),
]

def _intro():
    console.clear()
    for _ in range(2):
        for f in ('◇','◈','◆','◈'):
            line = Text()
            line.append(f"   {f}   ", style=C_BRAND)
            line.append("R  I  P", style=C_WHITE)
            line.append(f"   {f}   ", style=C_BRAND)
            console.print(line, justify="center", end="\r")
            time.sleep(0.05)
    console.print(" "*52, end="\r")
    console.print(_get_header()); console.print()
    for label, detail in _BOOT:
        t0 = time.time()
        for s in ('·','•','●','•'):
            console.print(Text(f"   {s}  ", style=C_ACCENT) + Text(f"{label:<12}", style=C_MUTED) +
                          Text(detail, style=C_DIM), end="\r", soft_wrap=True)
            time.sleep(0.03)
        ms = (time.time()-t0)*1000
        console.print(Text(f"   ✓  ", style=C_OK) + Text(f"{label:<12}", style=C_MUTED) +
                      Text(detail, style=C_DIM) + Text(f"  {ms:>4.0f}ms", style=C_DIM))
    console.print()
    total = 30
    for i in range(total+1):
        bar = "━"*i + "─"*(total-i)
        console.print(Text(f"   [{bar}] ", style=C_ACCENT) + Text(f"{int(i/total*100):>3}%", style=C_GOLD),
                      end="\r", soft_wrap=True)
        time.sleep(0.015)
    console.print(Text("   ready.", style=C_OK))
    time.sleep(0.3); console.clear()

_MENU = [
    ("1", "unpack  ·  crack  ·  unlock",        C_WHITE),
    ("2", "inject  ·  sm4 encrypt  ·  no-obf",  C_BRAND),
    ("3", "repack  ·  full rebuild",            C_WHITE),
    ("4", "repack  ·  to path",                 C_WHITE),
    ("5", "protect  ·  sm4 re-encrypt",         C_BRAND),
    ("6", "forge  ·  matching pak",             C_GOLD),
    ("7", "validate  ·  lua scan",              C_ACCENT),
    ("0", "exit",                               C_ERR),
]

def _render_screen(validator: LuaValidator):
    console.clear()
    console.print(_get_header()); console.print()
    hms, date, wd = _clock_parts()
    bar = Table.grid(expand=True, padding=(0, 1))
    bar.add_column(justify="left", ratio=1)
    bar.add_column(justify="center", ratio=1)
    bar.add_column(justify="right", ratio=1)
    left = Text()
    left.append("  ◷  ", style=C_ACCENT); left.append(hms, style=f"bold {C_ACCENT.split()[-1]}")
    left.append(f"   {date}  ", style=C_MUTED); left.append(wd, style=C_GOLD)
    mid = Text(); mid.append("backend  ", style=C_DIM); mid.append(validator.backend_name(), style=C_ACCENT)
    mid.append("   obf  ", style=C_DIM); mid.append("off", style=C_WARN)
    right = Text(); right.append("sm4  ", style=C_DIM); right.append(str(DEFAULT_SM4_TYPE), style=C_GOLD)
    bar.add_row(left, mid, right)
    console.print(Panel(bar, border_style=C_DIM, box=MINIMAL, padding=(0, 1)))
    console.print()
    grid = Table.grid(expand=True, padding=(0, 2))
    grid.add_column(justify="center", width=5)
    grid.add_column(justify="left", ratio=1)
    for key, label, style in _MENU:
        grid.add_row(Text(f" {key} ", style=f"bold {C_ACCENT.split()[-1]}"), Text(label, style=style))
    body = Group(
        Align.center(Text("─" * 54, style=C_DIM)),
        Align.center(Text("A Q A R V I R V I P", style=C_TITLE)),
        Align.center(Text("─" * 54, style=C_DIM)),
        Text(""),
        grid,
        Text(""),
        Align.center(Text("─" * 54, style=C_DIM)),
        Align.center(Text(f"root  ·  {BASE_DIR}", style=C_DIM)),
    )
    console.print(Panel(body, border_style=C_BRAND, box=HEAVY, padding=(1, 4),
                        title=Text(" ◆  ༈ۖ҉ـ M O D B A S H A  ༈ۖ҉ـ ◆ ", style=C_GOLD)))

def _overlay(lines, border=C_ACCENT, title=""):
    body = Group(*[Align.left(Text(l)) for l in lines])
    console.print()
    console.print(Panel(body, border_style=border, box=ROUNDED, padding=(1, 3), title=title or None))

def _toast(msg, kind="ok"):
    icons = {"ok":"✓","warn":"!","err":"✗","info":"◆"}
    colors = {"ok":C_OK,"warn":C_WARN,"err":C_ERR,"info":C_ACCENT}
    icon = icons.get(kind, "◆"); color = colors.get(kind, C_ACCENT)
    console.print(Text(f"  {icon}  {msg}", style=color))

def _step(stage, detail=""):
    label = {
        "validate": "validating lua", "read": "reading source",
        "build": "building index", "target": "injecting target",
        "target+": "adding target", "protect": "sm4 encrypting",
        "write": "writing pak", "verify": "verifying output",
        "warn": "warning", "template": "reading template",
        "signature": "mirroring signature",
    }.get(stage, stage)
    icon = "!" if stage == "warn" else "◈"
    color = C_WARN if stage == "warn" else C_DIM
    console.print(Text(f"  {icon}  ", style=color) + Text(f"{label:<18}", style=C_MUTED) + Text(detail, style=C_DIM))

def _progress_run(label, func):
    with Progress(SpinnerColumn(spinner_name="dots12", style=C_ACCENT),
                  TextColumn(f"[{C_MUTED}]{label}[/]"),
                  TimeElapsedColumn(), console=console, transient=True) as prog:
        prog.add_task("", total=None)
        return func()

def _select_file(title, folder, pattern="*.pak"):
    files = sorted(folder.glob(pattern)) if folder.exists() else []
    if not files:
        _toast(f"no {pattern} in {folder}", "warn"); return None
    tbl = Table(title=Text(title, style=C_TITLE), box=SIMPLE, border_style=C_DIM,
                header_style=C_ACCENT, padding=(0, 1))
    tbl.add_column("#", justify="right", style=C_ACCENT, width=4)
    tbl.add_column("file", style=C_WHITE)
    tbl.add_column("size", justify="right", style=C_MUTED, width=12)
    for i, f in enumerate(files, 1):
        sz = f.stat().st_size
        szs = f"{sz/(1024*1024):.2f} MB" if sz >= 1024*1024 else f"{sz/1024:.1f} KB"
        tbl.add_row(str(i), f.name, szs)
    console.print(tbl)
    try:
        raw = _safe_input(f"[{C_ACCENT}] › [/{C_ACCENT}]").strip()
        if not raw: return None
        i = int(raw) - 1
        if 0 <= i < len(files): return files[i]
    except Exception: pass
    _toast("cancelled", "warn"); return None

def _safe_input(prompt=''):
    try: return console.input(prompt)
    except (EOFError, RuntimeError):
        try:
            if sys.platform != 'win32':
                with open('/dev/tty','r') as tty:
                    sys.stderr.write(prompt); sys.stderr.flush()
                    return tty.readline().rstrip('\n')
            with open('CON','r') as con:
                sys.stderr.write(prompt); sys.stderr.flush()
                return con.readline().rstrip('\r\n')
        except Exception: return ''
    except Exception: return ''

def _pause():
    try: console.input(Text("  ↵ enter to return", style=C_DIM))
    except Exception: pass

def flow_unpack(pf):
    out_dir = REPACK_DIR / pf.stem
    _overlay([f"PAK     {pf.name}", f"OUTPUT  {out_dir}"],
             border=C_ACCENT, title=Text("  UNPACK  ", style=C_ACCENT))
    pak = _progress_run("opening pak", lambda: TencentPakFile(pf))
    total = sum(len(d) for d in pak._index.values())
    _step("build", f"v={pak._pak_info.version}  entries={total}  mount={pak._mount_point}")
    with Progress(SpinnerColumn("arc", style=C_ACCENT),
                  TextColumn(f"[{C_MUTED}]extracting  {{task.description}}[/]"),
                  BarColumn(bar_width=None, style=C_DIM, complete_style=C_ACCENT),
                  TaskProgressColumn(style=C_MUTED), TimeElapsedColumn(),
                  console=console, transient=False) as prog:
        task = prog.add_task("...", total=total)
        def cb(i, t, n): prog.update(task, advance=1, description=n[:40])
        pak.dump(out_dir, on_file=cb)
    _toast(f"unpacked → {out_dir}", "ok")

def flow_inject(pf, validator):
    _overlay([f"PAK     {pf.name}", f"TARGET  {TARGET_LUA_PATH}",
              f"SM4-T{DEFAULT_SM4_TYPE}  ·  no obfuscation  ·  source preserved"],
             border=C_BRAND, title=Text("  STEALTH INJECT  ·  SM4  ", style=C_BRAND))
    lua = [p for p in EDIT_DIR.rglob('*.lua') if p.is_file()] if EDIT_DIR.exists() else []
    if not lua: _toast("no .lua in EDIT", "err"); return
    for f in lua: console.print(Text(f"  ◈ {f.name}", style=C_MUTED))
    pak = _progress_run("opening pak", lambda: TencentPakFile(pf))
    out = RESULT_DIR / pf.name

    def on_stage(stage, detail):
        if stage in ("target","target+","protect","verify","warn"): _step(stage, detail)

    try:
        result = smart_inject_fixed(pak, EDIT_DIR, out, sm4_type=DEFAULT_SM4_TYPE,
                                    validator=validator, on_stage=on_stage)
    except Exception as e:
        _toast(str(e), "err"); return

    if result is None or result.get('aborted'):
        errs = result.get('errors', []) if result else []
        reason = result.get('reason', '?') if result else '?'
        _overlay([f"reason     {reason}",
                  f"target     {result.get('src', '?') if result else '?'}",
                  f"backend    {result.get('backend', '?') if result else '?'}",
                  f"status     ABORTED — nothing written",
                  "", "errors:"], border=C_ERR, title=Text("  ABORTED  ", style=C_ERR))
        for l, c, m in errs[:10]:
            loc = f"L{l}:{c}" if c else f"L{l}"
            console.print(Text(f"   {loc:<10} {m}", style=C_MUTED))
        if len(errs) > 10:
            console.print(Text(f"   … and {len(errs)-10} more", style=C_DIM))
        return

    other_broken = result.get('other_broken', [])
    _overlay([
        f"injected        {result['injected']}",
        f"protected       {result['protected']}  extra lua",
        f"skipped         {result['skipped']}",
        f"payload size    {result.get('obfuscated_size', 0):,} B",
        f"verify          {'OK  ' if result['verify_ok'] else 'FAIL'}  {result['verify_msg']}",
        f"output          {out}",
    ], border=C_OK if result['verify_ok'] else C_ERR,
       title=Text("  RESULT  ", style=C_OK if result['verify_ok'] else C_ERR))

    if other_broken:
        console.print()
        console.print(Text("  ⚠ secondary .lua skipped (invalid):", style=C_WARN))
        for nm, errs in other_broken:
            loc = f"L{errs[0][0]}" if errs else "?"
            console.print(Text(f"     {nm:<32} {loc}: {errs[0][2][:50] if errs else ''}", style=C_MUTED))

def flow_repack(pf):
    _overlay([f"PAK  {pf.name}", f"EDIT {EDIT_DIR}"],
             border=C_ACCENT, title=Text("  REPACK  ", style=C_ACCENT))
    pak = _progress_run("opening pak", lambda: TencentPakFile(pf))
    out = RESULT_DIR / pf.name
    try: n = _progress_run("rebuilding", lambda: repack_pak_file_full(pak, EDIT_DIR, out))
    except Exception as e: _toast(str(e), "err"); return
    _toast(f"repacked {n} files → {out}", "ok")

def flow_repack_path(pf):
    _overlay([f"PAK  {pf.name}"], border=C_ACCENT,
             title=Text("  REPACK TO PATH  ", style=C_ACCENT))
    tp = _safe_input(f"[{C_ACCENT}]target path › [/{C_ACCENT}]").strip().replace('\\','/').strip('/')
    if not tp: _toast("cancelled", "warn"); return
    pak = _progress_run("opening pak", lambda: TencentPakFile(pf))
    out = RESULT_DIR / pf.name
    try: n = _progress_run("rebuilding", lambda: repack_pak_file_full(pak, EDIT_DIR, out, tp, force_add=True))
    except Exception as e: _toast(str(e), "err"); return
    _toast(f"added {n} files → {out}", "ok")

def flow_protect(pf):
    _overlay([f"PAK  {pf.name}", f"SM4  T{DEFAULT_SM4_TYPE}"],
             border=C_BRAND, title=Text("  PROTECT  ", style=C_BRAND))
    pak = _progress_run("opening pak", lambda: TencentPakFile(pf))
    out = RESULT_DIR / pf.name
    try: res = _progress_run("re-encrypting", lambda: protect_pak_file(pak, out, sm4_type=DEFAULT_SM4_TYPE))
    except Exception as e: _toast(str(e), "err"); return
    _overlay([f"protected  {res['protected']}",
              f"skipped    {res['skipped']}",
              f"output     {out}"],
             border=C_OK, title=Text("  DONE  ", style=C_OK))

def flow_forge(pf):
    """Create a matching PAK from a template with identical signature."""
    out_name = f"{pf.stem}__forged.pak"
    out = FORGE_DIR / out_name
    _overlay([f"TEMPLATE  {pf.name}",
              f"OUTPUT    {out}",
              f"signature  version · mount · cm · em · enc · cbs · footer"],
             border=C_GOLD, title=Text("  PAK FORGE  ·  MATCHING SIGNATURE  ", style=C_GOLD))

    def on_stage(stage, detail):
        _step(stage, detail)

    try:
        res = _progress_run(
            "forging",
            lambda: forge_pak_from_template(pf, out, on_stage=on_stage),
        )
    except Exception as e:
        _toast(f"{type(e).__name__}: {e}", "err"); return

    ok = res.get('ok', False)
    _overlay([
        f"status     {'OK' if ok else 'FAIL'}",
        f"details    {res.get('msg', '')}",
        f"output     {res.get('output', '')}",
    ], border=C_OK if ok else C_ERR,
       title=Text("  FORGE RESULT  ", style=C_OK if ok else C_ERR))

def flow_validate(validator):
    _overlay([f"BACKEND  {validator.backend_name()}"],
             border=C_ACCENT, title=Text("  VALIDATE EDIT  ", style=C_ACCENT))
    if not EDIT_DIR.exists(): _toast("EDIT missing", "err"); return
    lua = sorted([p for p in EDIT_DIR.rglob('*.lua') if p.is_file()])
    if not lua: _toast("no .lua in EDIT", "warn"); return
    tbl = Table(box=SIMPLE, border_style=C_DIM, header_style=C_ACCENT, padding=(0,1))
    tbl.add_column("file", style=C_WHITE)
    tbl.add_column("status", justify="center")
    tbl.add_column("line", justify="right", style=C_DIM)
    tbl.add_column("detail", style=C_MUTED)
    fails = 0
    for lf in lua:
        r = validator.validate_path(lf)
        if r.ok: tbl.add_row(lf.name, Text("✓ ok", style=C_OK), "—", r.backend)
        else:
            fails += 1; l, c, m = r.errors[0]
            tbl.add_row(lf.name, Text(f"✗ {len(r.errors)}", style=C_ERR), f"L{l}", m[:60])
    console.print(tbl)
    if fails:
        for lf in lua:
            r = validator.validate_path(lf)
            if r.ok: continue
            console.print(Text(f"  {lf.name}", style=C_ERR))
            for l, c, m in r.errors[:12]:
                loc = f"L{l}:{c}" if c else f"L{l}"
                console.print(Text(f"    {loc:<8} {m}", style=C_MUTED))
        _toast(f"{fails} file(s) with errors", "err")
    else:
        _toast("all lua valid", "ok")

def main_menu():
    ensure_dirs()
    validator = LuaValidator()
    _intro()
    while True:
        _render_screen(validator)
        ch = _safe_input(f"[{C_ACCENT}] › [/{C_ACCENT}]").strip()
        try:
            if ch == '1':
                pf = _select_file("PAK to UNPACK", PAK_DIR)
                if pf: flow_unpack(pf); _pause()
            elif ch == '2':
                pf = _select_file("PAK to INJECT INTO", PAK_DIR)
                if pf: flow_inject(pf, validator); _pause()
            elif ch == '3':
                pf = _select_file("PAK to REPACK", PAK_DIR)
                if pf: flow_repack(pf); _pause()
            elif ch == '4':
                pf = _select_file("PAK for REPACK-TO-PATH", PAK_DIR)
                if pf: flow_repack_path(pf); _pause()
            elif ch == '5':
                pf = _select_file("PAK to PROTECT", PAK_DIR)
                if pf: flow_protect(pf); _pause()
            elif ch == '6':
                pf = _select_file("PAK template to FORGE", PAK_DIR)
                if pf: flow_forge(pf); _pause()
            elif ch == '7':
                flow_validate(validator); _pause()
            elif ch == '0':
                _toast("goodbye", "info"); time.sleep(0.3); break
            else:
                _toast("invalid", "warn"); time.sleep(0.5)
        except KeyboardInterrupt:
            console.print(); _toast("interrupted", "warn")
        except Exception as e:
            _toast(f"{type(e).__name__}: {e}", "err")

if __name__ == '__main__':
    try: main_menu()
    except KeyboardInterrupt:
        _clock.stop(); console.print(); _toast("interrupted", "warn"); sys.exit(0)
    except Exception as e:
        _clock.stop(); console.print(); _toast(f"{type(e).__name__}: {e}", "err")
        import traceback; traceback.print_exc()
        try: console.input("  ↵ enter  ")
        except Exception: pass
        sys.exit(1)