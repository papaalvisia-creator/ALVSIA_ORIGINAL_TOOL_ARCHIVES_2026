# --------Join us for more https://t.me/AttcTrDevelopers---------@AttcConfigTechnician ---------
import itertools as it
import math
import struct
import shutil
import os
import sys
import uuid
import hashlib
import platform
import subprocess
import requests
import base64
import zlib
from dataclasses import dataclass
from functools import lru_cache
from pathlib import PurePath, Path
from typing import List, Dict, Tuple, Optional, Any
import time
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table
from rich import print as rprint
from rich.markup import escape
import gmalg
from Crypto.Cipher import AES
from Crypto.Cipher.AES import MODE_CBC
from Crypto.Hash import SHA1
from Crypto.Util.Padding import unpad
from zstandard import ZstdDecompressor, ZstdCompressionDict, DICT_TYPE_AUTO, ZstdCompressor

# Initialize console for Rich with Cyberpunk theme
console = Console()

# Cyberpunk Theme Colors
class CyberpunkTheme:
    NEON_PINK = "#FF00FF"
    NEON_BLUE = "#00FFFF"
    NEON_PURPLE = "#9D00FF"
    NEON_GREEN = "#00FF00"
    NEON_YELLOW = "#FFFF00"
    NEON_RED = "#FF0033"

    DARK_BG = "#0A0A14"
    DARK_PANEL = "#121220"
    DARK_ACCENT = "#1A1A2E"

    TEXT_PRIMARY = "#E0E0FF"
    TEXT_SECONDARY = "#A0A0CC"
    TEXT_DIM = "#666699"

    SUCCESS = "#00FF88"
    WARNING = "#FFAA00"
    ERROR = "#FF0055"
    INFO = "#00CCFF"
    HIGHLIGHT = "#FF00FF"

def tprint(msg: str, style: str = "cyan"):
    color_map = {
        "SUCCESS": "bold #00FF88",
        "ERROR": "bold #FF0055",
        "WARNING": "#FFAA00",
        "INFO": "#00CCFF",
        "TITLE": "bold #E0E0FF",
        "BLUE": "#00FFFF",
        "NEON": "#FF00FF",
        "RED": "#FF0033"
    }
    if style in color_map:
        console.print(msg, style=color_map[style])
    else:
        console.print(msg, style=style)

# ========== CONSTANTS ==========
ZUC_KEY = bytes.fromhex('01010101010101010101010101010101')
ZUC_IV = bytes.fromhex('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')

RSA_MOD_1 = bytes.fromhex(
    'CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4')
RSA_MOD_2 = bytes.fromhex(
    '7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8')

SIMPLE1_DECRYPT_KEY = 0x79

SIMPLE2_DECRYPT_KEY = bytes.fromhex('E55B4ED1')
SIMPLE2_BLOCK_SIZE = 16

SIMPLE2_KEY_FULL = bytes([
    0xE5, 0x5B, 0x4E, 0xD1, 0xAD, 0xAE, 0x49, 0x87,
    0x1A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
])

SIMPLE2_IV_FULL = bytes([
    0x65, 0xD3, 0x3C, 0xC1, 0x99, 0x88, 0xD2, 0xA9,
    0xFE, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
])

EM17_STATIC_SECRET = b"48ea7d82db9995f2"
EM17_SALTS: Dict[int, str] = {
    0: "edbcba1dc6b11068b44a",  1: "4fdf06dd5830dea4a927",  2: "92bd3c6ca58d471b03df",
    3: "5267814520c2b1904294",  4: "f31085d8cefbf7e4adaf",  5: "589df0f2a3203ef9b9cc",
    6: "354d3b38e8e518477d8c",  7: "b57b1eeeed9d590e4692",  8: "2cbdd9c8cc6d20867fa2",
    9: "d47158ca2923a75af7ef", 10: "2a1138b5e375c7c9101a", 11: "c9347da5d7111fe9f1d9",
   12: "8e74503f8a94724dbb08", 13: "0259d21abd4adf59ca05", 14: "18ca7d8e7b13f4760404",
   15: "e9528dbafe091b886af5", 16: "d6860287a330f9a92210", 17: "751a5feeb49616d1cceb",
   18: "6955d9dfab070681d752", 19: "068b4cfc607fa13a1ffb", 20: "4fb7a2e36b9d156b79f8",
   21: "44e497e008d6789f2dbf", 22: "0dc887496bb94080f2c4", 23: "032a5c6c206b96db376a",
   24: "e4bb6ceb363e5841d946", 25: "06d780b85eade141e5fd", 26: "a6a915cd11add12a94e9",
   27: "5967e403b057bc02a8a9", 28: "87bae21ce1a1631ad6c9", 29: "14f8efdb5552af690d44",
   30: "9477ecd3fee28c7d2a34", 31: "b4ecef20999b7ccb205e", 32: "ec7c6575fc2a54caeb0d",
   33: "afa22d65c9f5a95f0f73", 34: "e5901d4631734da09feb", 35: "e31c6f4e994cb4330504",
   36: "df473da3aa9b5704ce73", 37: "46e490567d02cdb312b3", 38: "f838b560ec26d4ba67fd",
   42: "56eed0401753d9e5ee86", 43: "5412cc837199fa08d229", 44: "48750e47caff0540e2ee",
}

SM4_SECRET_4 = 'eb691efea914241317a8'
SM4_SECRET_2 = 'Q0hVTKey$as*1ZFlQCiA'
SM4_SECRET_NEW = [
    'xG2qW5lP7lV2iN5fN5pG',
    'xT1cJ6dL5wC0kK1rB4dK',
    'qC4jS5bZ6fL5xE6nD4zA',
    'gD4jQ2aL3bS3lC3xT0iW',
    'xU1yQ8wE9zY3gZ3bT5aE',
    'uQ3cO2dX7xY4xU7gH7iS',
    'gW1fR0jK6wQ4oN0oK1kZ',
    'aJ4pV7iZ7pU4wP2aC2cZ',
    'cX6jT3cM2oT3vK0kJ1qN',
    'iT2vS0cS6yT6cZ1sE1lO',
    'hM1pH9iY8wM9hT4lN5uJ',
    'kG6bC8jK0fL0dE4sH4mL',
    'dB6lB3vE0eZ8wM8rI0aC',
    'tP7sP7nI9rA2vQ4cV5yQ',
    'aT0cL1yN4pT3sZ7eM2vY',
    'uV6fU8fC9zN3mP5dH8mN',
    'rT6aQ6oZ1yM0gO5tO1aN',
    'jU5bH7lQ0fM9hK2kI0oF',
    'iQ0eM0mJ7uT0kV6kL5zY',
    'rG0lR2rZ5vM6mW5lM1rR',
    'wD2rP3lP9xF4mE1eC5jS',
    'fO3kW1fE6eD0pU1kY7xK',
    'nE1jQ6qK5tW7rM8iD5vV'
]

EM_SIMPLE1 = 1
EM_SIMPLE2 = 16
EM_SM4_17 = 17
EM_SM4_2 = 2
EM_SM4_4 = 4
EM_SM4_NEW_BASE = 31
EM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE

CM_NONE = 0
CM_ZLIB = 1
CM_ZSTD = 6
CM_ZSTD_DICT = 8
CM_MASK = 15

# ========== SM4 IMPLEMENTATION ==========
class SM4:
    """SM4 Algorithm Implementation."""

    _S_BOX = bytes([
        0x34, 0x66, 0x25, 0x74, 0x89, 0x78, 0xE4, 0xA9, 0x5A, 0x41, 0xBC, 0x7A, 0xD6, 0x16, 0x21, 0x23,
        0x4D, 0x61, 0xDA, 0x94, 0x9B, 0xDF, 0x13, 0x3C, 0x69, 0x3A, 0x31, 0x0A, 0x5F, 0xD7, 0x99, 0x95,
        0xF1, 0xAE, 0x72, 0x3D, 0x07, 0x60, 0x24, 0xB6, 0x98, 0xEE, 0xC4, 0xA2, 0x2D, 0x88, 0xDD, 0x8D,
        0x04, 0xEA, 0xBB, 0x11, 0xCA, 0x3E, 0x5D, 0xA1, 0xF6, 0x3F, 0xB0, 0x97, 0x80, 0x47, 0x2B, 0xA6,
        0xE6, 0xF7, 0xD9, 0xB1, 0x59, 0xC0, 0x7C, 0xBE, 0x54, 0x28, 0xB7, 0x7E, 0x4F, 0xF8, 0x43, 0x6E,
        0xA0, 0x50, 0x0E, 0xF5, 0x90, 0xB8, 0xFB, 0xA3, 0x7B, 0x62, 0x19, 0x46, 0x03, 0x2A, 0xB9, 0x8F,
        0x9F, 0x77, 0xB4, 0x5B, 0x83, 0x87, 0x08, 0xEB, 0xE2, 0x1E, 0x42, 0xF0, 0x0F, 0xE8, 0x71, 0x6A,
        0x75, 0xAD, 0x55, 0x1F, 0xB5, 0xAB, 0x33, 0xFA, 0x7F, 0x15, 0xBD, 0x85, 0xD8, 0x06, 0x68, 0xB3,
        0x52, 0x30, 0x48, 0x0B, 0x00, 0xED, 0xEF, 0xB2, 0x57, 0x8E, 0xE7, 0x6C, 0xD5, 0xE5, 0x2E, 0x53,
        0x82, 0x05, 0xF9, 0x81, 0xF4, 0x56, 0xBF, 0x8C, 0x4B, 0xE3, 0xDB, 0x4A, 0x91, 0x4C, 0x2C, 0xD3,
        0x40, 0x29, 0x4E, 0x20, 0x14, 0x36, 0x79, 0x09, 0x6F, 0xD1, 0x37, 0xE0, 0x39, 0x0C, 0x8A, 0x92,
        0x38, 0x12, 0x35, 0x6D, 0xE1, 0xFD, 0x93, 0x9A, 0x17, 0xD4, 0xC9, 0x9C, 0x6B, 0x84, 0x26, 0x9D,
        0xAF, 0x76, 0xC1, 0x9E, 0xD0, 0x96, 0xC5, 0xCB, 0xE9, 0x73, 0x49, 0xD2, 0xCD, 0x64, 0xC3, 0xC7,
        0x01, 0x7D, 0xF3, 0xAC, 0xFC, 0xDE, 0xA4, 0x44, 0x32, 0x1B, 0xC2, 0xBA, 0x1C, 0x02, 0xC6, 0x27,
        0x45, 0x8B, 0xF2, 0x18, 0xA7, 0x10, 0x51, 0x1D, 0xC8, 0xCF, 0x63, 0xFF, 0x2F, 0x0D, 0x58, 0xCE,
        0x65, 0xA5, 0xDC, 0x1A, 0x3B, 0x86, 0xFE, 0x22, 0x5C, 0xA8, 0x5E, 0x67, 0xAA, 0xEC, 0x70, 0xCC
    ])

    _FK = [
        0x46970E9C, 0x4BC0685E, 0x59056186, 0xBCA2491E
    ]

    _CK = [
        0x000EB92B, 0x3A0AE783, 0x9E3B5C67, 0xADDBDABF, 0x7B7484CB, 0x49156C63, 0xC79AB5E7, 0x79EC9CFF,
        0x1725BEAB, 0x2FB89CA3, 0x24808AD7, 0xDDD28B1F, 0x4740DA4B, 0xBBC3EA73, 0x247B30E7, 0x91BE385F,
        0x0401248B, 0x45FCD3A3, 0x530B4CE7, 0xC68DD35F, 0xE3D16C2B, 0x4F698C13, 0x6B92C747, 0x769EFB1F,
        0x4C73BE9B, 0xC942B193, 0xAD80D827, 0x372FB33F, 0x13CB6AAB, 0x2BDC0AA3, 0x17A4A247, 0xD5E96CAF
    ]

    @staticmethod
    def ROL32(x, n):
        return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))

    @staticmethod
    def _BS(X):
        return ((SM4._S_BOX[(X >> 24) & 0xff] << 24) |
                (SM4._S_BOX[(X >> 16) & 0xff] << 16) |
                (SM4._S_BOX[(X >> 8) & 0xff] << 8) |
                (SM4._S_BOX[X & 0xff]))

    @staticmethod
    def _T0(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 2) ^ SM4.ROL32(X, 10) ^ SM4.ROL32(X, 18) ^ SM4.ROL32(X, 24)

    @staticmethod
    def _T1(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 13) ^ SM4.ROL32(X, 23)

    @staticmethod
    def _key_expand(key: bytes, rkey: list):
        K0 = int.from_bytes(key[0:4], "big") ^ SM4._FK[0]
        K1 = int.from_bytes(key[4:8], "big") ^ SM4._FK[1]
        K2 = int.from_bytes(key[8:12], "big") ^ SM4._FK[2]
        K3 = int.from_bytes(key[12:16], "big") ^ SM4._FK[3]

        for i in range(0, 32, 4):
            K0 = K0 ^ SM4._T1(K1 ^ K2 ^ K3 ^ SM4._CK[i])
            rkey[i] = K0
            K1 = K1 ^ SM4._T1(K2 ^ K3 ^ K0 ^ SM4._CK[i + 1])
            rkey[i + 1] = K1
            K2 = K2 ^ SM4._T1(K3 ^ K0 ^ K1 ^ SM4._CK[i + 2])
            rkey[i + 2] = K2
            K3 = K3 ^ SM4._T1(K0 ^ K1 ^ K2 ^ SM4._CK[i + 3])
            rkey[i + 3] = K3

    @classmethod
    def key_length(cls):
        return 16

    @classmethod
    def block_length(cls):
        return 16

    def __init__(self, key: bytes):
        if len(key) != self.key_length():
            raise ValueError(f"Key must be {self.key_length()} bytes")

        self._key = key
        self._rkey = [0] * 32
        SM4._key_expand(self._key, self._rkey)
        self._block_buffer = bytearray()

    def encrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f"Block must be {self.block_length()} bytes")

        RK = self._rkey
        X0 = int.from_bytes(block[0:4], "big")
        X1 = int.from_bytes(block[4:8], "big")
        X2 = int.from_bytes(block[8:12], "big")
        X3 = int.from_bytes(block[12:16], "big")

        for i in range(0, 32, 4):
            X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[i])
            X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[i + 1])
            X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[i + 2])
            X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[i + 3])

        BUFFER = self._block_buffer
        BUFFER.clear()
        BUFFER.extend(X3.to_bytes(4, "big"))
        BUFFER.extend(X2.to_bytes(4, "big"))
        BUFFER.extend(X1.to_bytes(4, "big"))
        BUFFER.extend(X0.to_bytes(4, "big"))
        return bytes(BUFFER)

    def decrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f"Block must be {self.block_length()} bytes")

        RK = self._rkey
        X0 = int.from_bytes(block[0:4], "big")
        X1 = int.from_bytes(block[4:8], "big")
        X2 = int.from_bytes(block[8:12], "big")
        X3 = int.from_bytes(block[12:16], "big")

        for i in range(0, 32, 4):
            X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[31 - i])
            X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[30 - i])
            X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[29 - i])
            X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[28 - i])

        BUFFER = self._block_buffer
        BUFFER.clear()
        BUFFER.extend(X3.to_bytes(4, "big"))
        BUFFER.extend(X2.to_bytes(4, "big"))
        BUFFER.extend(X1.to_bytes(4, "big"))
        BUFFER.extend(X0.to_bytes(4, "big"))
        return bytes(BUFFER)

# ========== UTILITY CLASSES ==========
class Misc:
    @staticmethod
    def pad_to_n(data: bytes, n: int) -> bytes:
        assert n > 0
        padding = n - (len(data) % n)
        if padding == n:
            return data
        return data + b'\x00' * padding

    @staticmethod
    def align_up(x: int, n: int) -> int:
        return ((x + n - 1) // n) * n

class Reader:
    def __init__(self, buffer, cursor=0):
        self._buffer = buffer
        self._cursor = cursor

    def u1(self, move_cursor=True) -> int:
        return self.unpack('B', move_cursor=move_cursor)[0]

    def u4(self, move_cursor=True) -> int:
        return self.unpack('<I', move_cursor=move_cursor)[0]

    def u8(self, move_cursor=True) -> int:
        return self.unpack('<Q', move_cursor=move_cursor)[0]

    def i1(self, move_cursor=True) -> int:
        return self.unpack('b', move_cursor=move_cursor)[0]

    def i4(self, move_cursor=True) -> int:
        return self.unpack('<i', move_cursor=move_cursor)[0]

    def i8(self, move_cursor=True) -> int:
        return self.unpack('<q', move_cursor=move_cursor)[0]

    def s(self, n: int, move_cursor=True) -> bytes:
        return self.unpack(f'{n}s', move_cursor=move_cursor)[0]

    def unpack(self, f: str | bytes, offset=0, move_cursor=True):
        x = struct.unpack_from(f, self._buffer, self._cursor + offset)
        if move_cursor:
            self._cursor += struct.calcsize(f)
        return x

    def string(self, move_cursor=True) -> str:
        length = self.i4(move_cursor=move_cursor)
        if length == 0:
            return str()
        assert length > 0
        offset = 0 if move_cursor else 4
        return self.unpack(f'{length}s', offset=offset, move_cursor=move_cursor)[0].rstrip(b'\x00').decode()

# ========== PAK CLASSES ==========
class PakInfo:
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_index_encrypted(x: int) -> int:
            MASK_8 = 0xFF
            return (x ^ keystream[3]) & MASK_8

        def decrypt_magic(x: int) -> int:
            return x ^ keystream[2]

        def decrypt_index_hash(x: bytes) -> bytes:
            key = struct.pack('<5I', *keystream[4:][:5])
            assert len(x) == len(key)
            return bytes(a ^ b for a, b in zip(x, key))

        def decrypt_index_size(x: int) -> int:
            return x ^ ((keystream[10] << 32) | keystream[11])

        def decrypt_index_offset(x: int) -> int:
            return x ^ ((keystream[0] << 32) | keystream[1])

        reader = Reader(buffer[-PakInfo._mem_size(-1):])
        self.index_encrypted: bool = decrypt_index_encrypted(reader.u1()) == 1
        self.magic: int = decrypt_magic(reader.u4())
        self.version: int = reader.u4()
        self.index_hash: bytes = decrypt_index_hash(reader.s(20)) if self.version >= 6 else bytes()
        self.index_size: int = decrypt_index_size(reader.u8())
        self.index_offset: int = decrypt_index_offset(reader.u8())
        if self.version <= 3:
            self.index_encrypted = False

    @staticmethod
    def _mem_size(_: int) -> int:
        return 1 + 4 + 4 + 20 + 8 + 8

class TencentPakInfo(PakInfo):
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_unk(x: bytes) -> bytes:
            key = struct.pack('<8I', *keystream[7:][:8])
            assert len(x) == len(key)
            return bytes(a ^ b for a, b in zip(x, key))

        def decrypt_stem_hash(x: int) -> int:
            return x ^ keystream[8]

        def decrypt_unk_hash(x: int) -> int:
            return x ^ keystream[9]

        super().__init__(buffer, keystream)
        reader = Reader(buffer[-TencentPakInfo._mem_size(self.version):])
        self.unk1: bytes = decrypt_unk(reader.s(32)) if self.version >= 7 else bytes()
        self.packed_key: bytes = reader.s(256) if self.version >= 8 else bytes()
        self.packed_iv: bytes = reader.s(256) if self.version >= 8 else bytes()
        self.packed_index_hash: bytes = reader.s(256) if self.version >= 8 else bytes()
        self.stem_hash: int = decrypt_stem_hash(reader.u4()) if self.version >= 9 else 0
        self.unk2: int = decrypt_unk_hash(reader.u4()) if self.version >= 9 else 0
        self.content_org_hash: bytes = reader.s(20) if self.version >= 12 else bytes()

    @staticmethod
    def _mem_size(version: int) -> int:
        size_for_7 = 32 if version >= 7 else 0
        size_for_8 = 256 * 3 if version >= 8 else 0
        size_for_9 = 4 * 2 if version >= 9 else 0
        size_for_12 = 20 if version >= 12 else 0
        return PakInfo._mem_size(version) + size_for_7 + size_for_8 + size_for_9 + size_for_12

class PakCompressedBlock:
    def __init__(self, reader: Reader):
        self.start: int = reader.u8()
        self.end: int = reader.u8()

@dataclass
class TencentPakEntry:
    def __init__(self, reader: Reader, version: int):
        self.content_hash: bytes = reader.s(20)
        if version <= 1:
            _ = reader.u8()
        self.offset: int = reader.u8()
        self.uncompressed_size: int = reader.u8()
        self.compression_method: int = reader.u4() & CM_MASK
        self.size: int = reader.u8()
        self.unk1: int = reader.u1() if version >= 5 else 0
        self.unk2: bytes = reader.s(20) if version >= 5 else bytes()
        self.compressed_blocks: List[PakCompressedBlock] = [PakCompressedBlock(reader) for _ in range(
            reader.u4())] if self.compression_method != 0 and version >= 3 else []
        self.compression_block_size: int = reader.u4() if version >= 4 else 0
        self.encrypted: bool = reader.u1() == 1 if version >= 4 else False
        self.encryption_method: int = reader.u4() if version >= 12 else 0
        self.index_new_sep: int = reader.u4() if version >= 12 else 0

    def _mem_size(self, version: int) -> int:
        size_for_123 = 20 + 8 + 8 + 4 + 8 + (8 if version == 1 else 0)
        size_for_4 = 4 + 1 if version >= 4 else 0
        size_for_compressed_blocks = 4 + len(self.compressed_blocks) * 16 if self.compressed_blocks else 0
        size_for_5 = 1 + 20 if version >= 5 else 0
        size_for_12 = 4 if version >= 12 else 0
        return size_for_123 + size_for_4 + size_for_5 + size_for_12 + size_for_compressed_blocks

class PakCrypto:
    class _LCG:
        def __init__(self, seed: int):
            self.state = seed

        def next(self) -> int:
            MASK_32 = 0xFFFFFFFF
            MSB_1 = 1 << 31

            def wrap(x: int) -> int:
                x &= MASK_32
                if not x & MSB_1:
                    return x
                else:
                    return ((x + MSB_1) & MASK_32) - MSB_1

            x1 = wrap(0x41C64E6D * self.state)
            self.state = wrap(x1 + 12345)
            x2 = wrap(x1 + 0x13038) if self.state < 0 else self.state
            return ((x2 >> 16) & MASK_32) % 0x7FFF

    @staticmethod
    def _decrypt_simple2_aes(ciphertext: bytes) -> bytes:
        if len(ciphertext) % 16 != 0:
            pad_len = 16 - (len(ciphertext) % 16)
            ciphertext += b'\x00' * pad_len
        try:
            cipher = AES.new(SIMPLE2_KEY_FULL, MODE_CBC, SIMPLE2_IV_FULL[:16])
            return cipher.decrypt(ciphertext)
        except Exception:
            cipher = AES.new(SIMPLE2_KEY_FULL, AES.MODE_CTR, initial_value=SIMPLE2_IV_FULL[:16], nonce=b'')
            return cipher.decrypt(ciphertext)

    @staticmethod
    def zuc_keystream() -> List[int]:
        zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)
        return [struct.unpack('>I', zuc.generate())[0] for _ in range(16)]

    @staticmethod
    def _xorxor(buffer, x) -> bytes:
        return bytes(buffer[i] ^ x[i % len(x)] for i in range(len(buffer)))

    @staticmethod
    def _hashhash(buffer, n: int) -> bytes:
        result = bytes()
        for i in range(math.ceil(n / SHA1.digest_size)):
            result += SHA1.new(buffer).digest()
        if len(result) >= n:
            result = result[:n]
        else:
            result += b'\x00' * (n - len(result))
        return result

    @staticmethod
    def _meowmeow(buffer) -> bytes:
        def unpad(x):
            skip = 1 + next((i for i in range(len(x)) if x[i] != 0))
            return x[skip:]

        if len(buffer) < 43:
            return bytes()

        x1 = buffer[1:][:SHA1.digest_size]
        x2 = buffer[SHA1.digest_size + 1:]
        x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))
        x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))

        part1, m = (x2[:SHA1.digest_size], x2[SHA1.digest_size:])
        if part1 != SHA1.new(b'\x00' * SHA1.digest_size).digest():
            return bytes()

        return unpad(m)

    @staticmethod
    def rsa_extract(signature: bytes, modulus: bytes) -> bytes:
        c = int.from_bytes(signature, 'little')
        n = int.from_bytes(modulus, 'little')
        e = 0x10001
        m = pow(c, e, n).to_bytes(256, 'little').rstrip(b'\x00')
        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))

    @staticmethod
    def _decrypt_simple1(ciphertext) -> bytes:
        return bytes(x ^ SIMPLE1_DECRYPT_KEY for x in ciphertext)

    @staticmethod
    def _decrypt_simple2(ciphertext) -> bytes:
        class RollingKey:
            def __init__(self, initial_value: int):
                self._value = initial_value

            def update(self, x: int) -> int:
                self._value ^= x
                return self._value

        assert len(ciphertext) % SIMPLE2_BLOCK_SIZE == 0
        initial_key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
        rolling_key = RollingKey(initial_key)
        plaintext = (
            struct.pack('<I', rolling_key.update(x)) for x in struct.unpack(f'<{len(ciphertext) // 4}I', ciphertext)
        )
        return bytes(it.chain.from_iterable(plaintext))

    @staticmethod
    @lru_cache(maxsize=1)
    def _derive_sm4_key(file_path: PurePath, encryption_method: int, sep: int = 0) -> bytes:
        if encryption_method == EM_SM4_17:
            salt_index = sep & 0xFF
            salt = EM17_SALTS.get(salt_index)
            if salt is None:
                raise ValueError(f"EM17 salt index {salt_index} is missing in EM17_SALTS")
            return SHA1.new(salt.encode()).digest()[:SM4.key_length()]

        part1 = file_path.stem.lower()
        if encryption_method == EM_SM4_2:
            secret = SM4_SECRET_2
        elif encryption_method == EM_SM4_4:
            secret = SM4_SECRET_4
        else:
            index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
            secret = f'{SM4_SECRET_NEW[index]}{encryption_method}'
        return SHA1.new(str(part1 + secret).encode()).digest()[:SM4.key_length()]

    @staticmethod
    @lru_cache(maxsize=1)
    def _sm4_context_for_key(key: bytes) -> SM4:
        return SM4(key)

    @staticmethod
    def _decrypt_sm4(ciphertext, file_path: PurePath, encryption_method: int, sep: int = 0) -> bytes:
        assert len(ciphertext) % SM4.block_length() == 0
        key = PakCrypto._derive_sm4_key(file_path, encryption_method, sep)
        sm4 = PakCrypto._sm4_context_for_key(key)
        return bytes(
            it.chain.from_iterable(
                sm4.decrypt(ciphertext[i:i+SM4.block_length()]) for i in range(0, len(ciphertext), SM4.block_length())
            )
        )

    @staticmethod
    def decrypt_index(ciphertext, pak_info: TencentPakInfo) -> bytes:
        if pak_info.version > 7:
            key = PakCrypto.rsa_extract(pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_info.packed_iv, RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            aes = AES.new(key, MODE_CBC, iv[:16])
            return unpad(aes.decrypt(ciphertext), AES.block_size)
        else:
            return bytes(PakCrypto._decrypt_simple1(ciphertext))

    @staticmethod
    def _is_simple1_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE1

    @staticmethod
    def _is_simple2_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE2

    @staticmethod
    def _is_sm4_method(encryption_method: int) -> bool:
        return (encryption_method == EM_SM4_2
                or encryption_method == EM_SM4_4
                or encryption_method == EM_SM4_17
                or encryption_method & EM_SM4_NEW_MASK != 0)

    @staticmethod
    def align_encrypted_content_size(n: int, encryption_method: int) -> int:
        if PakCrypto._is_simple2_method(encryption_method):
            return Misc.align_up(n, 16)
        elif PakCrypto._is_sm4_method(encryption_method):
            return Misc.align_up(n, SM4.block_length())
        else:
            return n

    @staticmethod
    def decrypt_block(ciphertext, file: PurePath, encryption_method: int, sep: int = 0) -> bytes:
        if PakCrypto._is_simple1_method(encryption_method):
            return PakCrypto._decrypt_simple1(ciphertext)
        elif PakCrypto._is_simple2_method(encryption_method):
            return PakCrypto._decrypt_simple2(ciphertext)
        elif PakCrypto._is_sm4_method(encryption_method):
            return PakCrypto._decrypt_sm4(ciphertext, file, encryption_method, sep)
        else:
            raise ValueError(f"Unknown encryption method: {encryption_method}")

    @staticmethod
    @lru_cache(maxsize=33)
    def generate_block_indices(n: int, encryption_method: int) -> List[int]:
        if not PakCrypto._is_sm4_method(encryption_method):
            return list(range(n))
        permutation = []
        lcg = PakCrypto._LCG(n)
        while len(permutation) != n:
            x = lcg.next() % n
            if x not in permutation:
                permutation.append(x)
        inverse = [0] * len(permutation)
        for i, x in enumerate(permutation):
            inverse[x] = i
        return inverse

class PakCompression:
    @staticmethod
    @lru_cache(maxsize=33)
    def _zstd_decompressor(dict: ZstdCompressionDict) -> ZstdDecompressor:
        return ZstdDecompressor(dict)

    @staticmethod
    def zstd_dictionary(dict_data) -> ZstdCompressionDict:
        return ZstdCompressionDict(dict_data, DICT_TYPE_AUTO)

    @staticmethod
    def decompress_block(block, dict: Optional[ZstdCompressionDict], compression_method: int) -> bytes:
        if compression_method == CM_NONE:
            return block
        elif compression_method == CM_ZLIB:
            try:
                return zlib.decompress(block)
            except zlib.error:
                return block
        elif compression_method == CM_ZSTD or compression_method == CM_ZSTD_DICT:
            if compression_method != CM_ZSTD_DICT:
                dict = None
            return PakCompression._zstd_decompressor(dict).decompress(block)
        else:
            raise ValueError(f"Unknown compression method: {compression_method}")

class TencentPakFile:
    def __init__(self, file_path: PurePath, is_od=False):
        self._file_path = file_path
        with open(file_path, 'rb') as file:
            self._file_content = memoryview(file.read())
        self._is_od = is_od
        self._mount_point = PurePath()
        self._is_zstd_with_dict = 'zsdic' in str(self._file_path)
        self._zstd_dict = None
        self._files: List[TencentPakEntry] = []
        self._index: Dict[PurePath, Dict[str, TencentPakEntry]] = {}
        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())
        self._verify_stem_hash()
        self._tencent_load_index()

    def _verify_stem_hash(self) -> None:
        if not self._is_od and self._pak_info.version >= 9:
            assert self._pak_info.stem_hash == zlib.crc32(self._file_path.stem.encode('utf-32le'))

    def _tencent_load_index(self) -> None:
        index_data = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        if self._pak_info.index_encrypted:
            index_data = PakCrypto.decrypt_index(index_data, self._pak_info)
        else:
            index_data = index_data
        self._verify_index_hash(index_data)
        self._load_index(index_data)

    def _verify_index_hash(self, index_data) -> None:
        expected_hash = self._pak_info.index_hash
        if not self._is_od and self._pak_info.version >= 8:
            assert expected_hash == PakCrypto.rsa_extract(self._pak_info.packed_index_hash, RSA_MOD_2)
        assert expected_hash == SHA1.new(index_data).digest()

    @staticmethod
    def _construct_mount_point(mount_point: str) -> PurePath:
        result = PurePath()
        for part in PurePath(mount_point).parts:
            if part != '..':
                result /= part
        return result

    def _peek_content(self, offset: int, size: int, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(size, encryption_method)
        return self._file_content[offset:][:size]

    def _peek_block_content(self, block: PakCompressedBlock, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(block.end - block.start, encryption_method)
        return self._file_content[block.start:][:size]

    def _construct_zstd_dict(self, dict_entry: TencentPakEntry) -> None:
        assert not self._zstd_dict
        assert not dict_entry.encrypted
        assert dict_entry.compression_method == CM_NONE
        reader = Reader(self._peek_content(dict_entry.offset, dict_entry.size, 0))
        dict_size = reader.u8()
        _ = reader.u4()
        assert dict_size == reader.u4()
        dict_data = reader.s(dict_size)
        self._zstd_dict = PakCompression.zstd_dictionary(dict_data)

    def _load_index(self, index_data) -> None:
        if self._pak_info.version <= 10:
            raise ValueError(f"Unsupported version: {self._pak_info.version}")
        reader = Reader(index_data)
        self._mount_point = self._construct_mount_point(reader.string())
        self._files = [TencentPakEntry(reader, self._pak_info.version) for _ in range(reader.u4())]
        for _ in range(reader.u8()):
            dir_path = PurePath(reader.string())
            e = {reader.string(): self._files[~reader.i4()] for _ in range(reader.u8())}
            if self._is_zstd_with_dict and dir_path.name == 'zstddic':
                assert len(e) == 1
                self._construct_zstd_dict(e[[*e.keys()][0]])
                continue
            self._index.update({PurePath(dir_path): e})

    def _write_to_disk(self, file_path: PurePath, entry: TencentPakEntry) -> None:
        encryption_method = entry.encryption_method
        compression_method = entry.compression_method

        console.print(f"[#00CCFF]{file_path.name}[/#00CCFF] - Encryption: {encryption_method}, Compression: {compression_method}, Blocks: {len(entry.compressed_blocks)}")

        try:
            with open(file_path, 'wb') as file:
                if compression_method == CM_NONE:
                    data = self._peek_content(entry.offset, entry.size, encryption_method)
                    if entry.encrypted:
                        data = PakCrypto.decrypt_block(data, file_path, encryption_method, entry.index_new_sep)
                    file.write(data)
                    return
                for x in PakCrypto.generate_block_indices(len(entry.compressed_blocks), encryption_method):
                    data = self._peek_block_content(entry.compressed_blocks[x], encryption_method)
                    if entry.encrypted:
                        data = PakCrypto.decrypt_block(data, file_path, encryption_method, entry.index_new_sep)
                    data = PakCompression.decompress_block(data, self._zstd_dict, compression_method)
                    file.write(data)

        except Exception as e:
            console.print(f"[#FF0055]⚠ HATA: {file_path.name} unpack edilemedi ({e}). Atlanıyor...[/#FF0055]")
            safe_path = Path(file_path)
            if safe_path.exists():
                safe_path.unlink()

    def dump(self, out_path: PurePath) -> None:
        out_path /= self._mount_point
        for dir_path, dir in self._index.items():
            current_out_path = Path(out_path / dir_path)
            if not current_out_path.exists():
                current_out_path.mkdir(parents=True, exist_ok=True)
            for file_name, entry in dir.items():
                self._write_to_disk(current_out_path / file_name, entry)

# ========== REPACK FUNCTIONALITY ==========
def dump_unpacking_log(pak_file, output_log_path: Path):
    with open(output_log_path, 'w', encoding='utf-8') as log_file:
        log_file.write("=" * 80 + "\n")
        log_file.write("PAK UNPACKING DEBUG LOG\n")
        log_file.write("=" * 80 + "\n\n")

        log_file.write(f"PAK File: {pak_file._file_path}\n")
        log_file.write(f"PAK Info Version: {pak_file._pak_info.version}\n")
        log_file.write(f"Mount Point: {pak_file._mount_point}\n")
        log_file.write(f"Is ZSTD with Dict: {pak_file._is_zstd_with_dict}\n")
        log_file.write(f"Has ZSTD Dict: {pak_file._zstd_dict is not None}\n")
        log_file.write("-" * 80 + "\n\n")

        file_count = 0
        compression_stats = {}
        encryption_stats = {}
        block_stats = {}

        for dir_path, files in pak_file._index.items():
            for file_name, entry in files.items():
                file_count += 1
                full_path = str(PurePath(dir_path) / file_name).replace("\\", "/")

                comp_method = entry.compression_method
                compression_stats[comp_method] = compression_stats.get(comp_method, 0) + 1

                enc_method = entry.encryption_method
                encryption_stats[enc_method] = encryption_stats.get(enc_method, 0) + 1

                block_count = len(entry.compressed_blocks)
                block_stats[block_count] = block_stats.get(block_count, 0) + 1

                log_file.write(f"\n[{file_count}] {full_path}\n")
                log_file.write(f"  {'─' * 60}\n")
                log_file.write(f"  Uncompressed Size: {entry.uncompressed_size:,} bytes\n")
                log_file.write(f"  Compressed Size:   {entry.size:,} bytes\n")

                comp_method_name = {
                    CM_NONE: "NONE",
                    CM_ZLIB: "ZLIB",
                    CM_ZSTD: "ZSTD",
                    CM_ZSTD_DICT: "ZSTD_DICT"
                }.get(comp_method, f"UNKNOWN({comp_method})")

                log_file.write(f"  Compression Method: {comp_method_name} ({comp_method})\n")

                enc_method_name = "NONE"
                if enc_method == EM_SIMPLE1:
                    enc_method_name = "SIMPLE1"
                elif enc_method == EM_SIMPLE2:
                    enc_method_name = "SIMPLE2"
                elif enc_method == EM_SM4_17:
                    enc_method_name = "SM4_17"
                elif enc_method == EM_SM4_2:
                    enc_method_name = "SM4_2"
                elif enc_method == EM_SM4_4:
                    enc_method_name = "SM4_4"
                elif enc_method & EM_SM4_NEW_MASK != 0:
                    enc_method_name = f"SM4_NEW({enc_method})"
                else:
                    enc_method_name = f"UNKNOWN({enc_method})"

                log_file.write(f"  Encryption Method: {enc_method_name}\n")
                log_file.write(f"  Is Encrypted: {entry.encrypted}\n")
                log_file.write(f"  Compressed Blocks: {len(entry.compressed_blocks)}\n")
                log_file.write(f"  Compression Block Size: {entry.compression_block_size:,} bytes\n")
                log_file.write(f"  {'─' * 60}\n")

        log_file.write("\n" + "=" * 80 + "\n")
        log_file.write("SUMMARY STATISTICS\n")
        log_file.write("=" * 80 + "\n\n")
        log_file.write(f"Total Files: {file_count}\n\n")

    console.print(f"[bold #00FF88]✅ Debug log saved to: {output_log_path}[/bold #00FF88]")

def debug_entry_info(entry):
    console.print(f"[bold #FFFF00]ENTRY DEBUG INFO:[/bold #FFFF00]")
    console.print(f"  • Uncompressed size: {entry.uncompressed_size}")
    console.print(f"  • Compressed size: {entry.size}")
    console.print(f"  • Compression method: {entry.compression_method}")
    console.print(f"  • Encryption method: {entry.encryption_method}")
    console.print(f"  • Encrypted: {entry.encrypted}")
    console.print(f"  • Blocks: {len(entry.compressed_blocks)}")

def _encrypt_plaintext(
    plaintext: bytes,
    pak_relative_path: PurePath,
    encryption_method: int,
    sep: int = 0
) -> bytes:
    if PakCrypto._is_simple1_method(encryption_method):
        return bytes(b ^ SIMPLE1_DECRYPT_KEY for b in plaintext)

    if PakCrypto._is_simple2_method(encryption_method):
        pad = (-len(plaintext)) % SIMPLE2_BLOCK_SIZE
        plaintext += b"\x00" * pad
        key, = struct.unpack("<I", SIMPLE2_DECRYPT_KEY)
        rolling = key
        out = []
        for x, in struct.iter_unpack("<I", plaintext):
            c = rolling ^ x
            out.append(c)
            rolling ^= c
        return struct.pack(f"<{len(out)}I", *out)

    if PakCrypto._is_sm4_method(encryption_method):
        key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method, sep)
        sm4 = PakCrypto._sm4_context_for_key(key)

        pad_len = (-len(plaintext)) % 16
        if pad_len > 0:
            plaintext = plaintext + b'\x00' * pad_len

        out = bytearray()
        for i in range(0, len(plaintext), 16):
            block = plaintext[i:i+16]
            out.extend(sm4.encrypt(block))
        return bytes(out)

    return plaintext

def _repack_uncompressed(outfh, pak_file, entry, pak_relative_path: PurePath, new_data: bytes):
    enc_method = entry.encryption_method
    target_size = entry.size
    enc_region = PakCrypto.align_encrypted_content_size(target_size, enc_method) if entry.encrypted else target_size
    plaintext = new_data[:enc_region]

    if entry.encrypted:
        a = PakCrypto.align_encrypted_content_size(len(plaintext), enc_method)
        plaintext += b"\x00" * (a - len(plaintext))
        cipher = _encrypt_plaintext(plaintext, pak_relative_path, enc_method, entry.index_new_sep)
        outfh.seek(entry.offset)
        outfh.write(cipher)
    else:
        outfh.seek(entry.offset)
        outfh.write(plaintext)

def _repack_compressed(outfh, pak_file, entry, pak_relative_path, new_data, repack_dir):
    blocks = entry.compressed_blocks
    enc_method = entry.encryption_method
    comp_method = entry.compression_method
    order = PakCrypto.generate_block_indices(len(blocks), enc_method)

    if len(blocks) == 1:
        blk = blocks[0]
        target_size = blk.end - blk.start
        zstd_dict = pak_file._zstd_dict if comp_method == CM_ZSTD_DICT else None

        new_compressed = None
        if comp_method in (CM_ZSTD, CM_ZSTD_DICT):
            for level in [22, 19, 16, 13, 10, 7, 4, 1]:
                try:
                    c = ZstdCompressor(level=level, dict_data=zstd_dict, threads=1)
                    comp = c.compress(new_data)
                    if len(comp) <= target_size:
                        new_compressed = comp
                        break
                except:
                    continue
        elif comp_method == CM_ZLIB:
            new_compressed = zlib.compress(new_data, zlib.Z_BEST_COMPRESSION)

        if not new_compressed or len(new_compressed) > target_size:
            return True

        if entry.encrypted:
            new_compressed = _encrypt_plaintext(new_compressed, pak_relative_path, enc_method, entry.index_new_sep)

        outfh.seek(blk.start)
        outfh.write(new_compressed)
        if len(new_compressed) < target_size:
            outfh.write(b'\x00' * (target_size - len(new_compressed)))

    return True

def repack_pak_file_fileA_style(pak_file, edited_root: Path, output_path: Path):
    shutil.copy2(pak_file._file_path, output_path)
    pak_name_map = {}
    for dir_path, files in pak_file._index.items():
        for name, entry in files.items():
            full_path = str(PurePath(dir_path) / name).replace("\\", "/")
            pak_name_map.setdefault(name.lower(), []).append((full_path, entry))

    edited = {}
    for p in edited_root.rglob("*"):
        if not p.is_file():
            continue
        fname_lower = p.name.lower()
        if fname_lower in pak_name_map:
            candidates = pak_name_map[fname_lower]
            if len(candidates) == 1:
                full_path, entry = candidates[0]
                edited[full_path] = (p, entry)

    if not edited:
        console.print("[bold #FF0055]❌ No files to repack![/bold #FF0055]")
        return

    with open(output_path, "r+b") as outfh:
        for full_path, (p, entry) in edited.items():
            new_data = p.read_bytes()
            pak_rel = PurePath(full_path)
            if entry.compression_method == CM_NONE:
                _repack_uncompressed(outfh, pak_file, entry, pak_rel, new_data)
            else:
                _repack_compressed(outfh, pak_file, entry, pak_rel, new_data, edited_root)

    console.print(f"[bold #00FF88]✅ Repack completed! {len(edited)} file(s) replaced.[/bold #00FF88]")

def print_banner():
    os.system('cls' if os.name == 'nt' else 'clear')
    banner = r"""
[bold #FD0363] _______                           .__                       [/bold #FD0363]
[bold #CC095D] \      \   _______  __ ___________|  |   ____  ______ ____  [/bold #CC095D]
[bold #9C1057] /   |   \_/ __ \  \/ // __ \_  __ \  |  /  _ \/  ___// __ \ [/bold #9C1057]
[bold #6B1650]/    |    \  ___/\   /\  ___/|  | \/  |_(  <_> )___ \\  ___/ [/bold #6B1650]
[bold #3B1D4A]\____|__  /\___  >\_/  \___  >__|  |____/\____/____  >\___  >[/bold #3B1D4A]
[bold #0A2344]        \/     \/          \/                      \/     \/ [/bold #0A2344]
[bold #FD0363]
  ✦ ────────────────────────────────────────── ✦
  • Update-By     : [bold #d3f6db]NEVERLOSE (@KYRENİXSOFT)[/bold #d3f6db]  │
  • Channel       : [bold #d3f6db]@KYRENİXSOFT[/bold #d3f6db]                   │
  • Credits       : [bold #d3f6db]@NLJOİN | TWOAM[/bold #d3f6db]           │
  • Platform      : [bold #d3f6db]BGMI|PUBG|KR|TW|JP|VNG[/bold #d3f6db]     │
  • Game Version  : [bold #01befe]4.7[/bold #01befe]                        │
  • Tool Version  : [bold #adff02]3[/bold #adff02]                          │
  ✦ ────────────────────────────────────────── ✦
[/bold #FD0363]
    """
    console.print(banner)
    print()

def detect_pak_files(data_path: Path) -> List[Path]:
    pak_files = list(data_path.glob("*.pak"))
    pak_files.extend(data_path.glob("*.obb"))
    return sorted(pak_files, key=lambda x: x.name)

def safe_input(prompt: str = "") -> str:
    try:
        return input(prompt)
    except (EOFError, RuntimeError):
        return ""

def clear_folders(data_path: Path) -> None:
    for item in data_path.iterdir():
        if item.is_dir() and item.name in ("UNPACK", "REPACK"):
            try:
                shutil.rmtree(item)
            except Exception:
                pass

def main_menu():
    if getattr(sys, 'frozen', False):
        data_path = Path(sys.executable).parent
    else:
        data_path = Path(__file__).parent

    pak_dir    = data_path / "PAK"
    unpack_dir = data_path / "UNPACK"
    repack_dir = data_path / "REPACK"
    result_dir = data_path / "RESULT"

    pak_dir.mkdir(exist_ok=True)
    unpack_dir.mkdir(exist_ok=True)
    repack_dir.mkdir(exist_ok=True)
    result_dir.mkdir(exist_ok=True)

    while True:
        print_banner()
        pak_files = detect_pak_files(pak_dir)

        if not pak_files:
            console.print("[bold #FF0055]⚠  No .pak/.obb files found in the PAK folder![/bold #FF0055]")
            safe_input("\nPress Enter to continue...")
            continue

        for i, pak_file in enumerate(pak_files, 1):
            size_mb = pak_file.stat().st_size / (1024 * 1024)
            console.print(f"[#00CCFF]{i:2}. {pak_file.name}[/#00CCFF] [#FFFF00]({size_mb:.2f} MB)[/#FFFF00]")

        console.print("\n[bold #00FF88]OPTIONS:[/bold #00FF88]")
        console.print("[#00FF00]1. 📂 UNPAK - Extract .pak file[/#00FF00]")
        console.print("[#00FFFF]2. 🔧 REPAK - Rebuild .pak file[/#00FFFF]")
        console.print("[#FF0055]3. 🗑️  CLEAR - Reset UNPACK / REPACK[/#FF0055]")
        console.print("[#FFFF00]0. 🚪 EXIT - Close the tool[/#FFFF00]")

        choice = safe_input("Enter your choice (0-3): ").strip()

        if choice == '1':
            selected_pak = pak_files[0] if len(pak_files) == 1 else pak_files[int(safe_input("Select file number: ")) - 1]
            pak_name = selected_pak.stem
            try:
                console.print(f"[bold #00FFFF]🚀 Unpacking {selected_pak.name}...[/bold #00FFFF]")
                pak = TencentPakFile(selected_pak)
                pak.dump(unpack_dir)
                log_path = unpack_dir / f"RpadDebug_{pak_name}.log"
                dump_unpacking_log(pak, log_path)
                console.print("[bold #00FF88]✅ UNPACK COMPLETED![/bold #00FF88]")
            except Exception as e:
                console.print(f"[bold #FF0055]❌ Unpack error:[/bold #FF0055] {e}")
            safe_input("\nPress Enter to continue...")

        elif choice == '2':
            selected_pak = pak_files[0] if len(pak_files) == 1 else pak_files[int(safe_input("Select file number: ")) - 1]
            try:
                console.print(f"[bold #00FFFF]🚀 Repacking {selected_pak.name}...[/bold #00FFFF]")
                pak = TencentPakFile(selected_pak)
                output_pak = result_dir / selected_pak.name
                repack_pak_file_fileA_style(pak, repack_dir, output_pak)
                console.print("[bold #00FF88]✅ REPAK COMPLETED![/bold #00FF88]")
            except Exception as e:
                console.print(f"[bold #FF0055]❌ Repack failed:[/bold #FF0055] {e}")
            safe_input("\nPress Enter to continue...")

        elif choice == '3':
            clear_folders(data_path)
            safe_input("\nPress Enter to continue...")

        elif choice == '0':
            break

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold #FF0055]💥 UNEXPECTED ERROR:[/bold #FF0055] {escape(str(e))}")
        sys.exit(1)
# --------Join us for more https://t.me/AttcTrDevelopers---------@AttcConfigTechnician ---------
