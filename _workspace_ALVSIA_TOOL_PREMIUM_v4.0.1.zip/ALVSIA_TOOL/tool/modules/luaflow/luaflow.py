#!/usr/bin/env python3
# ┌─────────────────────────────────────────────────────────────────────────────┐
# │                    ALVSIA TOOL PREMIUM · LUAFLOW                          │
# │                         COMPLETE VERSION                                   │
# │                    CHANNEL : @ALVSIA_PRO                                      │
# │                    OWNER   : @OriginalOnwerALV                                │
# └─────────────────────────────────────────────────────────────────────────────┘

import os
import sys
import struct
import glob
import shutil
import subprocess
import time
import re
import tempfile
import colorsys
import math
import zlib
import socket
import base64
import itertools as it
import traceback
import random
import hashlib
import platform
import json
import uuid
import threading
from typing import Tuple, List, Optional, Dict, Any
from dataclasses import dataclass
from functools import lru_cache
from pathlib import PurePath, Path
from datetime import datetime
from collections import Counter

# ═══════════════════════════════════════════════════════════════════════════════
# 🔐 ALVSIA LUA OBFUSCATOR (ENC)
# ═══════════════════════════════════════════════════════════════════════════════

import re as _obf_re
import random as _obf_random

def _obf_is_long_bracket(s, i):
    if i >= len(s) or s[i] != "[":
        return None
    j = i + 1
    while j < len(s) and s[j] == "=":
        j += 1
    if j < len(s) and s[j] == "[":
        return j - i - 1
    return None

def _obf_quoted_end(s, i, q):
    j = i + 1
    while j < len(s):
        if s[j] == "\\":
            j += 2
            continue
        if s[j] == q:
            return j + 1
        j += 1
    raise ValueError(f"Unterminated string at {i}")

def _obf_decode_escape(body):
    out = bytearray()
    i = 0
    simple = {"a":7,"b":8,"f":12,"n":10,"r":13,"t":9,"v":11,"\\":92,'"':34,"'":39}
    while i < len(body):
        c = body[i]
        if c != "\\":
            out.extend(c.encode("utf-8")); i += 1; continue
        if i + 1 >= len(body):
            out.append(92); i += 1; continue
        n = body[i+1]
        if n in simple:
            out.append(simple[n]); i += 2; continue
        if n.isdigit():
            j = i + 1; digs = ""
            while j < len(body) and len(digs) < 3 and body[j].isdigit():
                digs += body[j]; j += 1
            out.append(int(digs) & 0xFF); i = j; continue
        out.extend(n.encode("utf-8")); i += 2
    return bytes(out)

def _obf_extract_strings(src):
    strings = []
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        if c in ("'", '"'):
            try:
                j = _obf_quoted_end(src, i, c)
            except ValueError:
                i += 1; continue
            raw = src[i+1:j-1]
            try:
                decoded = _obf_decode_escape(raw)
            except Exception:
                decoded = raw.encode("utf-8", errors="replace")
            strings.append((i, j, decoded))
            i = j
            continue
        lb = _obf_is_long_bracket(src, i)
        if lb is not None:
            start = i + lb + 2
            close = "]" + ("=" * lb) + "]"
            end = src.find(close, start)
            if end < 0:
                i += 1; continue
            strings.append((i, end + len(close), src[start:end].encode("utf-8")))
            i = end + len(close)
            continue
        if c == "-" and i+1 < n and src[i+1] == "-":
            lb2 = _obf_is_long_bracket(src, i+2)
            if lb2 is not None:
                start = i + 4 + lb2
                close = "]" + ("=" * lb2) + "]"
                end = src.find(close, start)
                i = (end + len(close)) if end >= 0 else n
            else:
                nl = src.find("\n", i+2)
                i = (nl if nl >= 0 else n)
            continue
        i += 1
    return strings

def obfuscate_lua_strings(src: str, seed: int = None) -> str:
    if seed is None:
        seed = _obf_random.randint(100000000, 999999999)
    strings = _obf_extract_strings(src)
    if not strings:
        return src
    final_bytes = bytearray()
    offsets = []
    for (_s, _e, data) in strings:
        start = len(final_bytes) + 1
        for b in data:
            pos = len(final_bytes) + 1
            k = (pos * 31 + 176 + ((pos ^ 176) * 17)) & 0xFF
            final_bytes.append((b ^ k) & 0xFF)
        offsets.append((start, len(data)))
    out = []
    out.append("-- ALVSIA protected chunk")
    out.append("-- ALVSIA TOOL PREMIUM")
    out.append("-- Owner @OriginalOnwerALV")
    out.append("-- Unauthorized decompilation is prohibited")
    out.append('_G["__ALVSIA_OWNER"] = "@OriginalOnwerALV"')
    out.append('_G["__ALVSIA_DEVELOPER"] = "@ALVSIA_PRO"')
    out.append('_G["__ALVSIA_MESSAGE"] = "Protected by ALVSIA TOOL PREMIUM"')
    out.append(f"-- seed={seed}")
    out.append("")
    # ENC data/function are global so this wrapper does not consume a
    # local register in the original Lua chunk (Lua 5.3 limit: 200 locals).
    enc_data_name = "__ALVSIA_ENC_DATA"
    enc_decode_name = "__ALVSIA_ENC_DECODE"
    # Owner/developer marker embedded in generated ENC output
    owner_marker = 'ALVSIA TOOL PREMIUM\nOwner @OriginalOnwerALV\nChannel @ALVSIA_PRO'

    out.append(f"_G[{enc_data_name!r}] = {{}}")
    for i, b in enumerate(final_bytes, 1):
        out.append(f"_G[{enc_data_name!r}][{i}] = {b}")
    out.append("")
    out.append(f"""
function {enc_decode_name}(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L2_2 = {{}}
  L3_2 = 0
  L4_2 = A1_2 - 1
  L5_2 = 1
  for L6_2 = L3_2, L4_2, L5_2 do
    L7_2 = A0_2 + L6_2
    L8_2 = L7_2 * 31
    L8_2 = 176 + L8_2
    L9_2 = L7_2 ~ 176
    L9_2 = L9_2 * 17
    L8_2 = L8_2 + L9_2
    L8_2 = L8_2 & 255
    L9_2 = L6_2 + 1
    L10_2 = string.char
    L11_2 = _G[{enc_data_name!r}][L7_2]
    L11_2 = L11_2 ~ L8_2
    L11_2 = L11_2 & 255
    L10_2 = L10_2(L11_2)
    L2_2[L9_2] = L10_2
  end
  L3_2 = table.concat
  return L3_2(L2_2)
end
""")
    pieces = []
    cursor = 0
    for (s, e, data), (off, ln) in zip(strings, offsets):
        pieces.append(src[cursor:s])
        if ln == 0:
            pieces.append('""')
        else:
            pieces.append(f"{enc_decode_name}({off}, {ln})")
        cursor = e
    pieces.append(src[cursor:])
    out.append("".join(pieces))
    return "\n".join(out)

def protect_lua_file(src_path, dst_path=None, seed=None):
    if dst_path is None:
        dst_path = src_path
    raw = src_path.read_text(encoding="utf-8", errors="replace")
    protected = obfuscate_lua_strings(raw, seed=seed)
    dst_path.write_text(protected, encoding="utf-8")
    return dst_path


# ═══════════════════════════════════════════════════════════════════════════════
# 🔐 LICENSE SYSTEM - KEY SAVE + AUTO LOGIN (FROM g.py)
# ═══════════════════════════════════════════════════════════════════════════════

# ── Rich UI imports ──────────────────────────────────────────────────────────

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn
    from rich.table import Table
    from rich.markup import escape
    from rich.text import Text
    from rich.box import ROUNDED, HEAVY, DOUBLE
    from rich import box
    from rich.align import Align
    from rich.layout import Layout
    from rich.columns import Columns
    from rich.live import Live
    from rich.console import Group
    RICH_AVAILABLE = True
except ImportError:
    print("⚠️ rich module not found! Installing...")
    os.system("pip install rich")
    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn
    from rich.table import Table
    from rich.markup import escape
    from rich.text import Text
    from rich.box import ROUNDED, HEAVY, DOUBLE
    from rich import box
    from rich.align import Align
    from rich.layout import Layout
    from rich.columns import Columns
    from rich.live import Live
    from rich.console import Group
    RICH_AVAILABLE = True

console = Console(color_system="truecolor", highlight=False)
import builtins as _builtins
_original_builtin_print = _builtins.print
REPACK_UI_PLAIN = False
REPACK_RGB_MODE = True

# When REPACK_RGB_MODE is enabled, normal text output is rendered as animated
# RGB while menus/logic remain unchanged. Rich renderables (tables/panels) are
# passed through unchanged so their layout is preserved.
_original_console_print = console.print
def _rgb_console_print(*args, **kwargs):
    """RGB plain text while preserving Rich Panels/Tables/renderables."""
    if not REPACK_RGB_MODE or not args:
        return _original_console_print(*args, **kwargs)
    try:
        from rich.text import Text
        # IMPORTANT: Rich renderables must go straight to Rich. Converting a
        # Panel/Table to str() produces '<rich.panel.Panel object at ...>'.
        if any(not isinstance(arg, (str, Text)) for arg in args):
            return _original_console_print(*args, **kwargs)
        parts = []
        for arg in args:
            if isinstance(arg, Text):
                parts.append(arg.plain)
            else:
                parts.append(Text.from_markup(arg).plain)
        message = " ".join(parts)
        return _original_console_print(_make_rgb_text(message), **kwargs)
    except Exception:
        return _original_console_print(*args, **kwargs)


def _make_rgb_text(message: str, speed: float = 0.30):
    from rich.text import Text
    out = Text()
    chars = list(str(message))
    width = max(1, len(chars) - 1)
    stamp = time.time() * speed
    for i, ch in enumerate(chars):
        p = (stamp + (i / width) * 0.95) % 1.0
        # Red -> Blue -> White -> Red animated RGB cycle.
        if p < 1/3:
            t = p * 3.0
            r, g, b = 255 * (1-t), 0, 255 * t
        elif p < 2/3:
            t = (p - 1/3) * 3.0
            r, g, b = 255 * t, 255 * t, 255
        else:
            t = (p - 2/3) * 3.0
            r, g, b = 255, 255 * (1-t), 255 * (1-t)
        r, g, b = r/255, g/255, b/255
        out.append(ch, style=f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}")
    return out

# Route console.print through the RGB-aware wrapper.
console.print = _rgb_console_print

def _rgb_builtin_print(*args, **kwargs):
    if REPACK_RGB_MODE and RICH_AVAILABLE:
        # Never stringify Rich renderables such as Panel/Table.
        if any(not isinstance(a, (str, int, float, bool, type(None))) for a in args):
            return _original_builtin_print(*args, **kwargs)
        sep = kwargs.pop("sep", " ")
        end = kwargs.pop("end", "\n")
        file = kwargs.pop("file", None)
        flush = kwargs.pop("flush", False)
        if file is None:
            message = sep.join(str(a) for a in args)
            rendered = _make_rgb_text(message)
            result = _original_console_print(rendered, end=end, **kwargs)
            if flush:
                try:
                    console.file.flush()
                except Exception:
                    pass
            return result
        return _original_builtin_print(*args, sep=sep, end=end, file=file, flush=flush, **kwargs)
    return _original_builtin_print(*args, **kwargs)


_builtins.print = _rgb_builtin_print

# ── Themes ──────────────────────────────────────────────────────────────────

NEON = "white"
NEON_DIM = "white"
ERR = "white"
WARN = "white"
ACCENT = "white"
MUTED = "white"
SUCCESS = "white"
GOLD = "white"
PURPLE = "white"
RED = "white"
GREEN = "white"
BLUE = "white"

# ── ANIMATED BORDER ENGINE ──────────────────────────────────────────────────

class AnimatedBorder:
    _instance = None
    
    def __init__(self):
        self._start_time = time.time()
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def get_rainbow_color(self, offset=0, speed=1.0):
        # RGB animation with cyan/blue excluded.
        p = (time.time() * speed + offset) % 1.0
        # Red -> Blue -> White -> Red animated RGB cycle.
        if p < 1/3:
            t = p * 3.0
            r, g, b = 255 * (1-t), 0, 255 * t
        elif p < 2/3:
            t = (p - 1/3) * 3.0
            r, g, b = 255 * t, 255 * t, 255
        else:
            t = (p - 2/3) * 3.0
            r, g, b = 255, 255 * (1-t), 255 * (1-t)
        r, g, b = r/255, g/255, b/255
        return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
    
    def get_moving_border_style(self, position=0, speed=0.8):
        offset = (position / 8.0) + (time.time() * speed * 0.1)
        return self.get_rainbow_color(offset % 1.0, speed)


# ── RGB COMPILE/REBUILD OUTPUT ─────────────────────────────────────────────
def rgb_print(message: str, speed: float = 0.35, phase: float = 0.0) -> None:
    """Print compile/rebuild output; repack workflows use plain text."""
    if REPACK_UI_PLAIN or not RICH_AVAILABLE:
        print(message)
        return
    from rich.text import Text
    line = Text()
    stamp = time.time() * speed + phase
    chars = list(message)
    width = max(1, len(chars) - 1)
    for i, ch in enumerate(chars):
        # RGB palette with CYAN/BLUE completely excluded.
        # Full RGB animation except cyan/blue.
        p = (stamp + (i / width) * 0.95) % 1.0
        # Red -> Blue -> White -> Red animated RGB cycle.
        if p < 1/3:
            t = p * 3.0
            r, g, b = 255 * (1-t), 0, 255 * t
        elif p < 2/3:
            t = (p - 1/3) * 3.0
            r, g, b = 255 * t, 255 * t, 255
        else:
            t = (p - 2/3) * 3.0
            r, g, b = 255, 255 * (1-t), 255 * (1-t)
        r, g, b = r/255, g/255, b/255
        color = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        line.append(ch, style=color)
    console.print(line)

def rgb_compile_step(message: str) -> None:
    """Compile/rebuild output in the reference green/white terminal style.

    This intentionally does not use the animated RGB renderer, so copied/run
    compile output keeps the same stable colors every time.
    """
    if not RICH_AVAILABLE:
        _original_builtin_print(message)
        return

    from rich.text import Text
    text = str(message)

    # Success/progress lines are green; warnings/errors/details stay white.
    if text.lstrip().startswith(("✓", "🚀")):
        style = "bold green"
    elif text.lstrip().startswith(("⚠", "✗")):
        style = "white"
    else:
        style = "white"

    # IMPORTANT: bypass the global RGB console wrapper here.
    # Otherwise console.print(Text(...)) is recolored back to RGB.
    _original_console_print(Text(text, style=style))
# ───────────────────────────────────────────────────────────────────────────


def rgb_text(message: str, speed: float = 0.30, phase: float = 0.0):
    """Return RGB text normally; plain white text during repack workflows."""
    from rich.text import Text
    if not message:
        return Text("")
    stamp = time.time() * speed + phase
    chars = list(str(message))
    width = max(1, len(chars) - 1)
    rendered = Text()
    for i, ch in enumerate(chars):
        # RGB cycle with cyan and blue excluded.
        p = (stamp + (i / width) * 0.95) % 1.0
        # Red -> Blue -> White -> Red animated RGB cycle.
        if p < 1/3:
            t = p * 3.0
            r, g, b = 255 * (1-t), 0, 255 * t
        elif p < 2/3:
            t = (p - 1/3) * 3.0
            r, g, b = 255 * t, 255 * t, 255
        else:
            t = (p - 2/3) * 3.0
            r, g, b = 255, 255 * (1-t), 255 * (1-t)
        r, g, b = r/255, g/255, b/255
        rendered.append(
            ch,
            style=f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        )
    return rendered

def rgb_ui_print(message: str, speed: float = 0.30):
    """RGB UI output for repack/build workflows."""
    if RICH_AVAILABLE:
        console.print(rgb_text(message, speed=speed))
    else:
        print(message)

def safe_input(prompt: str='') -> str:
    try:
        return input(prompt)
    except (EOFError, RuntimeError):
        try:
            if sys.platform != 'win32':
                with open('/dev/tty', 'r') as tty:
                    sys.stderr.write(prompt); sys.stderr.flush()
                    return tty.readline().rstrip('\n')
            else:
                with open('CON', 'r') as con:
                    sys.stderr.write(prompt); sys.stderr.flush()
                    return con.readline().rstrip('\r\n')
        except Exception:
            return ''
    except Exception:
        return ''

# ── LOCAL STARTUP (NO LICENSE LOGIN) ───────────────────────────────────────
def check_license():
    """Start the tool locally without contacting a license server or prompting for a key."""
    return True, None, None


if not hasattr(it, 'batched'):
    def batched(iterable, n):
        it_iter = iter(iterable)
        while True:
            chunk = list(it.islice(it_iter, n))
            if not chunk:
                break
            yield chunk
    it.batched = batched

# ── Optional PAK dependencies ─────────────────────────────────────────────

PAK_MODE_AVAILABLE = True
try:
    import gmalg
    try:
        from gmalg.base import BlockCipher
        from gmalg.errors import IncorrectLengthError
        from gmalg.utils import ROL32
    except ImportError:
        class BlockCipher: pass
        class IncorrectLengthError(Exception):
            def __init__(self, name, expected, actual):
                super().__init__(f"Incorrect length for {name}: expected {expected}, got {actual}")
        def ROL32(x, n): return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))
except ImportError:
    PAK_MODE_AVAILABLE = False
    class BlockCipher: pass
    class IncorrectLengthError(Exception):
        def __init__(self, name, expected, actual):
            super().__init__(f"Incorrect length for {name}: expected {expected}, got {actual}")
    def ROL32(x, n): return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))

try:
    from Crypto.Cipher import AES
    from Crypto.Cipher.AES import MODE_CBC
    from Crypto.Hash import SHA1
    from Crypto.Util.Padding import pad, unpad
except ImportError:
    PAK_MODE_AVAILABLE = False

try:
    from zstandard import ZstdDecompressor, ZstdCompressor, ZstdCompressionDict, DICT_TYPE_AUTO
except ImportError:
    PAK_MODE_AVAILABLE = False

# ==============================================================================
# HEXA CORE UI - PROFESSIONAL
# ==============================================================================

def get_rainbow_color(offset=0, speed=1.0):
    return AnimatedBorder.get_instance().get_rainbow_color(offset, speed)

def get_border_style(position=0, speed=0.8):
    return AnimatedBorder.get_instance().get_moving_border_style(position, speed)

def hexa_alert(message: str, kind: str = "info") -> None:
    tags = {
        "success": ("✓", SUCCESS),
        "error": ("✗", ERR),
        "warning": ("⚠", WARN),
        "info": ("▶", ACCENT),
    }
    tag, color = tags.get(kind, tags["info"])
    console.print(f"  {tag}  {message}", style=color)

def hexa_section(title: str) -> None:
    console.print()
    console.print(f"  ═══ {title} ═══", style="bold white on black")
    console.print(f"  {'─' * (len(title) + 8)}", style=MUTED)

def hexa_prompt(label: str) -> str:
    console.print(f"  {label}", style=f"bold {NEON}")
    return safe_input("").strip()

def format_time(seconds: int) -> str:
    if seconds < 0:
        return "Unlimited"
    if seconds == 0:
        return "Expired"
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    
    if days > 0:
        return f"{days}d {hours}h {minutes}m {secs}s"
    elif hours > 0:
        return f"{hours}h {minutes}m {secs}s"
    else:
        return f"{minutes}m {secs}s"

def _live_expiry_values(key_info):
    """Return live values from the expiry timestamp supplied by the license server."""
    if not key_info:
        return None, "N/A", "Days: N/A"

    expiry = str(key_info.get('expiry', 'N/A')).strip()
    if not expiry or expiry.lower() == 'lifetime':
        return None, "♾️ LIFETIME", "UNLIMITED"

    try:
        expiry_date = datetime.fromisoformat(expiry.replace(' ', 'T'))
        remaining = max(0, int((expiry_date - datetime.now()).total_seconds()))
        days = remaining // 86400
        hours = (remaining % 86400) // 3600
        minutes = (remaining % 3600) // 60
        seconds = remaining % 60
        return remaining, f"Expiry: {expiry}", f"{days}d {hours:02d}h {minutes:02d}m {seconds:02d}s"
    except Exception:
        return None, f"Expiry: {expiry}", "TIME N/A"


def print_main_banner(title="", key_info=None):
    os.system('cls' if os.name == 'nt' else 'clear')

    try:
        term_width = shutil.get_terminal_size().columns
    except Exception:
        term_width = 80

    BOX_WIDTH = min(72, max(52, term_width - 4))
    # UI-only: keep the developer header clean with no empty top border.
    console.print("[bold white on black]ALVSIA TOOL PREMIUM · LUAFLOW[/bold white on black]", justify="center")
    console.print("[bold green on black]CHANNEL @ALVSIA_PRO[/bold green on black]", justify="center")

    if title:
        console.print(f"  {title}", style="bold white on black")
        console.print(f"  {'─' * len(title)}", style=MUTED)


def print_license_status_bottom(key_info=None):
    """Render the server-supplied expiry with a live countdown; UI only."""
    if not key_info:
        return

    _, expiry_text, countdown_text = _live_expiry_values(key_info)

    ab = AnimatedBorder.get_instance()
    status_table = Table(
        box=ROUNDED,
        expand=True,
        border_style=ab.get_moving_border_style(2, 0.5),
        padding=(0, 1),
        show_header=True,
        header_style="bold white on black",
        style="white on black",
    )
    status_table.add_column("TIME LEFT", justify="center", style="bold white on black")
    status_table.add_column("SUBSCRIPTION", justify="center", style="bold white on black")
    status_table.add_column("DATES", justify="center", style="bold white on black")

    subscription_text = "PAID"
    status_table.add_row(countdown_text, subscription_text, expiry_text)
    console.print()
    console.print(status_table)

    # No RGB footer decoration.

def human_size(size: int) -> str:
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f'{size:.2f} {unit}'
        size /= 1024.0
    return f'{size:.2f} PB'

# ==============================================================================
# SHARED DIRECTORY CONFIGURATION
# ==============================================================================

def get_lua_pak_root() -> Path:
    docs_path = Path("/storage/emulated/0/Documents/ALVSIA_TOOL")
    if not docs_path.exists():
        docs_path.mkdir(parents=True, exist_ok=True)
        console.print(f"[{SUCCESS}]✓ Created ALVSIA_TOOL folder at {docs_path}[/{SUCCESS}]")
    return docs_path

LUA_PAK_ROOT = get_lua_pak_root()
SOURCE_DIR = LUA_PAK_ROOT / "SOURCE"
REAL_DIR   = LUA_PAK_ROOT / "LUA_ORIGINAL"
EDIT_DIR   = LUA_PAK_ROOT / "COMPILED"
UNPACK_DIR = LUA_PAK_ROOT / "LUA_EDIT"
PAK_DIR    = LUA_PAK_ROOT / "PAK_ORIGINAL"
PAK_UNPACK_DIR = LUA_PAK_ROOT / "PAK_UNPACK"
RESULT_DIR = LUA_PAK_ROOT / "PAK_RESULT"
CONFIG_FILE_PATH = LUA_PAK_ROOT / "config.json"

FORCE_COMPILE = True
SKIP_ALL_FIXES = True
SKIP_AUTO_FIX = True

def load_config():
    config = {}
    if CONFIG_FILE_PATH.exists():
        try:
            with open(CONFIG_FILE_PATH, 'r') as f:
                config = json.load(f)
        except Exception:
            pass
    return config

def save_config(config):
    try:
        with open(CONFIG_FILE_PATH, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass

def hexa_prompt_with_default(label: str, default: str = "") -> str:
    console.print(f"  {label}", style=f"bold {NEON}")
    if default:
        console.print(f"  └─> [bold white]{default}[/bold white]", style=f"bold")
        console.print(f"  [dim](Press Enter to use default, or type new path)[/dim]")
        result = safe_input("  └─> ").strip()
        return result if result else default
    else:
        return safe_input("  └─> ").strip()

def setup_directories():
    for d in [REAL_DIR, UNPACK_DIR, EDIT_DIR, PAK_DIR, PAK_UNPACK_DIR, RESULT_DIR, SOURCE_DIR]:
        try: d.mkdir(parents=True, exist_ok=True)
        except OSError as e: console.print(f"Error creating {d}: {e}")

def get_real_files():   
    return [f for f in os.listdir(REAL_DIR) if f.lower().endswith((".lua",".luac",".slua"))] if REAL_DIR.exists() else []

def get_unpack_files(): 
    return [f for f in os.listdir(UNPACK_DIR) if f.endswith(".lua")] if UNPACK_DIR.exists() else []

# ==============================================================================
# TOOLCHAIN — LUA CORE (FULL)
# ==============================================================================

def _load_xor_key() -> bytes:
    env_key = os.environ.get('BGMI_XOR_KEY')
    if env_key:
        try:
            key_bytes = bytes.fromhex(env_key.replace(' ', '').replace(':', '').replace('-', ''))
            if len(key_bytes) == 32: return key_bytes
        except ValueError: pass
    return bytes([0x11, 0x21, 0x36, 0x47, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84, 0x90, 0xD8, 0xAB, 0x00, 0x8C, 0x35, 0x26, 0x1A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x15, 0x07, 0xD0, 0x2C, 0x1E, 0x8F, 0xF6, 0xC8])

STRING_XOR_KEY = _load_xor_key()

_BGMI_TO_STD = [13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,0,1,2,3,4,5,6,7,8,9,10,11,12,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46]
BGMI_TO_STD = _BGMI_TO_STD + [i for i in range(len(_BGMI_TO_STD), 64)]
STD_TO_BGMI = {v: k for k, v in enumerate(BGMI_TO_STD) if k < len(BGMI_TO_STD)}
STD_FMT = [0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,2,2,0,2,0,1,0,3]
iABC, iABx, iAsBx, iAx = 0, 1, 2, 3
HEADER_SIZE = 33

class BinaryReader:
    def __init__(self, data: bytes, sizet: int = 4):
        self.data = bytearray(data); self.pos = 0; self.sizet = sizet
    def byte(self) -> int:
        if self.pos >= len(self.data): raise EOFError()
        v = self.data[self.pos]; self.pos += 1; return v
    def int32(self) -> int:
        if self.pos + 4 > len(self.data): raise EOFError()
        v = struct.unpack_from('<i', self.data, self.pos)[0]; self.pos += 4; return v
    def uint32(self) -> int:
        if self.pos + 4 > len(self.data): raise EOFError()
        v = struct.unpack_from('<I', self.data, self.pos)[0]; self.pos += 4; return v
    def double(self) -> float:
        if self.pos + 8 > len(self.data): raise EOFError()
        v = struct.unpack_from('<d', self.data, self.pos)[0]; self.pos += 8; return v
    def int64(self) -> int:
        if self.pos + 8 > len(self.data): raise EOFError()
        v = struct.unpack_from('<q', self.data, self.pos)[0]; self.pos += 8; return v
    def bytes(self, n: int) -> bytes:
        if self.pos + n > len(self.data): raise EOFError()
        v = self.data[self.pos:self.pos+n]; self.pos += n; return bytes(v)
    def pubg_string(self) -> Optional[str]:
        sz = self.byte()
        if sz == 0xFF: sz = self.uint32()
        if sz == 0: return None
        sz -= 1
        enc = self.bytes(sz)
        dec = bytes(enc[i] ^ STRING_XOR_KEY[i % 32] for i in range(len(enc)))
        try: return dec.decode('utf-8', errors='replace')
        except Exception: return dec.decode('latin-1')
    def std_string(self) -> Optional[str]:
        sz = self.byte()
        if sz == 0xFF:
            if self.sizet == 8:
                if self.pos + 8 > len(self.data): raise EOFError()
                sz = struct.unpack_from('<Q', self.data, self.pos)[0]; self.pos += 8
            else: sz = self.uint32()
        if sz == 0: return None
        sz -= 1
        raw = self.bytes(sz)
        try: return raw.decode('utf-8', errors='replace')
        except Exception: return raw.decode('latin-1')

class BinaryWriter:
    def __init__(self): self.buf = bytearray()
    def byte(self, v): self.buf.append(v & 0xFF)
    def int32(self, v): self.buf.extend(struct.pack('<i', v))
    def uint32(self, v): self.buf.extend(struct.pack('<I', v))
    def int64(self, v): self.buf.extend(struct.pack('<q', v))
    def double(self, v): self.buf.extend(struct.pack('<d', v))
    def raw(self, data): self.buf.extend(data)
    def lua_string(self, s: Optional[str], is_pubg: bool = False):
        if s is None: self.byte(0); return
        e = s.encode('utf-8') if isinstance(s, str) else s
        sz = len(e) + 1
        if sz < 0xFF: self.byte(sz)
        else: self.byte(0xFF); self.uint32(sz)
        if is_pubg:
            enc = bytes(e[i] ^ STRING_XOR_KEY[i % 32] for i in range(len(e)))
            self.raw(enc)
        else: self.raw(e)
    def lua_inst(self, op, A, B, C, Bx, sBx, Ax, fmt):
        op &= 0x3F
        if   fmt == iABC:  r = op | ((A & 0xFF)<<6) | ((C & 0x1FF)<<14) | ((B & 0x1FF)<<23)
        elif fmt == iABx:  r = op | ((A & 0xFF)<<6) | ((Bx & 0x3FFFF)<<14)
        elif fmt == iAsBx: r = op | ((A & 0xFF)<<6) | (((sBx+131071) & 0x3FFFF)<<14)
        elif fmt == iAx:   r = op | ((Ax & 0x3FFFFFF)<<6)
        else: r = 0
        self.uint32(r)
    def get_data(self) -> bytes: return bytes(self.buf)

def _convert_function(reader: BinaryReader, writer: BinaryWriter, to_std: bool = True):
    src = reader.pubg_string() if to_std else reader.std_string()
    writer.lua_string(src, is_pubg=(not to_std))
    linedefined = reader.int32(); writer.int32(linedefined)
    writer.int32(reader.int32())
    writer.byte(reader.byte()); writer.byte(reader.byte()); writer.byte(reader.byte())
    csz = reader.uint32(); writer.uint32(csz)
    opmap = BGMI_TO_STD if to_std else STD_TO_BGMI
    for _ in range(csz):
        raw = reader.uint32()
        bop = raw & 0x3F; A = (raw >> 6) & 0xFF; B = (raw >> 23) & 0x1FF; C = (raw >> 14) & 0x1FF
        Bx = (raw >> 14) & 0x3FFFF; sBx = Bx - 131071; Ax = (raw >> 6) & 0x3FFFFFF
        sop = opmap[bop] if bop < len(opmap) else bop
        fmt = STD_FMT[sop] if sop < len(STD_FMT) else iABC
        writer.lua_inst(sop, A, B, C, Bx, sBx, Ax, fmt)
    nk = reader.uint32(); writer.uint32(nk)
    for _ in range(nk):
        t = reader.byte(); writer.byte(t)
        if t == 0: pass
        elif t == 1: writer.byte(reader.byte())
        elif t == 3: writer.double(reader.double())
        elif t == 19: writer.int64(reader.int64())
        elif t in (4, 20):
            s = reader.pubg_string() if to_std else reader.std_string()
            writer.lua_string(s, is_pubg=(not to_std))
        else: raise ValueError(f"Unknown constant type 0x{t:02X}")
    nups = reader.uint32(); writer.uint32(nups)
    for _ in range(nups): writer.byte(reader.byte()); writer.byte(reader.byte())
    npts = reader.uint32(); writer.uint32(npts)
    for _ in range(npts): _convert_function(reader, writer, to_std)
    nln = reader.uint32()
    if to_std:
        lines = []; cur = linedefined
        for _ in range(nln):
            d = reader.byte()
            cur += d if d <= 127 else d - 256
            lines.append(cur)
        writer.uint32(len(lines))
        for ln in lines: writer.int32(ln)
        nab = reader.uint32()
        for _ in range(nab): reader.uint32(); reader.uint32()
    else:
        lines = [reader.int32() for _ in range(nln)]
        writer.uint32(len(lines))
        prev = linedefined
        for ln in lines:
            delta = ln - prev
            if -128 <= delta <= 127: writer.byte(delta & 0xFF)
            else: writer.byte(0x00); writer.int32(delta)
            prev = ln
        writer.uint32(0)
    nloc = reader.uint32(); writer.uint32(nloc)
    for _ in range(nloc):
        s = reader.pubg_string() if to_std else reader.std_string()
        writer.lua_string(s, is_pubg=(not to_std))
        writer.int32(reader.int32()); writer.int32(reader.int32())
    nupn = reader.uint32(); writer.uint32(nupn)
    for _ in range(nupn):
        s = reader.pubg_string() if to_std else reader.std_string()
        writer.lua_string(s, is_pubg=(not to_std))

def bgmi_to_std(data: bytes) -> bytes:
    if data[:4] != b'\x1bLua': raise ValueError("Not a valid Lua bytecode file")
    reader = BinaryReader(data, sizet=4); writer = BinaryWriter()
    hdr = bytearray(data[:HEADER_SIZE]); hdr[13] = 4
    writer.raw(hdr); reader.pos = HEADER_SIZE
    nibble_flag = reader.byte(); writer.byte(nibble_flag)
    _convert_function(reader, writer, to_std=True)
    return writer.get_data()

def std_to_bgmi(data: bytes) -> bytes:
    if data[:4] != b'\x1bLua': raise ValueError("Not a valid Lua bytecode file")
    sizet = data[13] if data[13] in (4, 8) else 4
    reader = BinaryReader(data, sizet=sizet); writer = BinaryWriter()
    hdr = bytearray(data[:HEADER_SIZE]); hdr[13] = 4
    writer.raw(hdr); reader.pos = HEADER_SIZE
    nibble_flag = reader.byte(); writer.byte(nibble_flag)
    _convert_function(reader, writer, to_std=False)
    return writer.get_data()

def convert_file(inp: str, outp: str = None) -> Tuple[bool, str]:
    if not outp: outp = os.path.splitext(inp)[0] + '.std.luac'
    try:
        with open(inp, 'rb') as f: data = f.read()
    except Exception as e: return False, f"Cannot read input file: {e}"
    if len(data) < 34 or data[:4] != b'\x1bLua':
        try: shutil.copy2(inp, outp); return True, outp
        except: return False, "Failed to copy non-Lua file"
    nibble_flag = data[33]
    if nibble_flag > 2: nibble_flag = 0; data = bytearray(data); data[33] = 0; data = bytes(data)
    if nibble_flag > 1:
        fixed = bytearray(data[:34])
        for i in range(34, len(data)):
            b = data[i]; fixed.append(((b << 4) & 0xF0) | ((b >> 4) & 0x0F))
        data = bytes(fixed)
    try:
        std_data = bgmi_to_std(data)
        with open(outp, 'wb') as f: f.write(std_data)
        return True, outp
    except Exception:
        try: shutil.copy2(inp, outp); return True, outp
        except: return False, "Conversion failed"

def repack_to_pubg(std_luac_path: str, original_pubg_path: str, outp: str = None, pad_to_size: int = None) -> Tuple[bool, str]:
    if not outp: outp = os.path.splitext(std_luac_path)[0] + '.pubg.luac'
    try:
        with open(original_pubg_path, 'rb') as f: orig_data = f.read()
    except Exception as e: return False, f"Cannot read original: {e}"
    if len(orig_data) < 34 or orig_data[:4] != b'\x1bLua': return False, "Original not valid Lua bytecode"
    header = orig_data[:33]; nibble_flag = orig_data[33]
    if nibble_flag > 2: nibble_flag = 0
    try:
        with open(std_luac_path, 'rb') as f: std_data = f.read()
    except Exception as e: return False, f"Cannot read std luac: {e}"
    try:
        bgmi_data = std_to_bgmi(std_data)
        bgmi_data = header + bytes([nibble_flag]) + bgmi_data[34:]
        if nibble_flag > 1:
            data_list = bytearray(bgmi_data[:34])
            for i in range(34, len(bgmi_data)):
                b = bgmi_data[i]; data_list.append(((b << 4) & 0xF0) | ((b >> 4) & 0x0F))
            bgmi_data = bytes(data_list)
        if pad_to_size is not None and len(bgmi_data) < pad_to_size:
            bgmi_data += b'\x00' * (pad_to_size - len(bgmi_data))
        with open(outp, 'wb') as f: f.write(bgmi_data)
        return True, outp
    except Exception as e: return False, f"Repack failed: {e}"

UNLUAC_JAR_PATH = SOURCE_DIR / "unluac_patched.jar"
UNLUAC_JAR = str(UNLUAC_JAR_PATH)
JAVA_CMD = "java"
BUNDLED_JDK_CANDIDATES = list(SOURCE_DIR.glob("jdk*/bin/java.exe")) + list(SOURCE_DIR.glob("jdk*/bin/java"))
if BUNDLED_JDK_CANDIDATES: JAVA_CMD = str(BUNDLED_JDK_CANDIDATES[0])

def get_luac_cmd() -> str:
    for name in ["luac5.3", "luac53", "luac5.3.exe", "luac53.exe"]:
        p = SOURCE_DIR / name
        if p.exists(): return str(p)
    for name in ["luac5.3", "luac53.exe"]:
        w = shutil.which(name)
        if w: return w
    return "luac5.3"

LUAC_PATH = get_luac_cmd()
STRIP_DEBUG = True

def decrypt_decompile_file(file_path: str, output_dir: str, progress_callback=None) -> bool:
    try:
        filename = os.path.basename(file_path)
        base_name = os.path.splitext(filename)[0]
        if base_name.lower().endswith('.lua'): base_name = os.path.splitext(base_name)[0]
        output_file = os.path.join(output_dir, base_name + ".lua")
        temp_std = file_path + ".temp.std.luac"
        if progress_callback: progress_callback(f"Converting {filename}...")
        success, msg = convert_file(file_path, temp_std)
        if not success:
            if progress_callback: progress_callback(f"Conversion failed: {msg}")
            shutil.copy2(file_path, os.path.join(output_dir, base_name + ".luac"))
            return False
        if not os.path.exists(UNLUAC_JAR):
            if progress_callback: progress_callback("unluac.jar missing, saving raw bytecode")
            shutil.copy2(temp_std, os.path.join(output_dir, base_name + ".luac"))
            os.remove(temp_std); return False
        try:
            cmd = [JAVA_CMD, "-jar", UNLUAC_JAR, temp_std]
            with open(output_file, "w", encoding="utf-8") as out:
                subprocess.check_call(cmd, stdout=out, stderr=subprocess.PIPE, timeout=30)
            if progress_callback: progress_callback(f"Decompiled {filename}")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            if progress_callback: progress_callback(f"Decompilation failed: {e}")
            shutil.copy2(temp_std, os.path.join(output_dir, base_name + ".luac"))
            return False
        finally:
            if os.path.exists(temp_std): os.remove(temp_std)
        return True
    except Exception as e:
        if progress_callback: progress_callback(f"Exception: {e}")
        return False

def robust_decompile(encrypted_path: str, output_dir: str, tmp_dir: str) -> Tuple[bool, str, List[str]]:
    name = os.path.basename(encrypted_path); base = os.path.splitext(name)[0]
    out_path = os.path.join(output_dir, base + ".lua")
    temp_std = os.path.join(tmp_dir, base + ".std.luac")
    ok, msg = convert_file(encrypted_path, temp_std)
    if not ok: return False, msg, []
    if not os.path.exists(UNLUAC_JAR): return False, "unluac_patched.jar not found", []
    try:
        cmd = [JAVA_CMD, "-jar", UNLUAC_JAR, temp_std]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout:
            with open(out_path, 'w', encoding='utf-8') as f: f.write(result.stdout)
            return True, out_path, []
        else: return False, f"Decompilation failed: {(result.stderr or 'unknown error').strip()[:200]}", []
    except subprocess.TimeoutExpired: return False, "Decompilation timed out", []
    except Exception as e: return False, str(e), []

def select_files_interactive(files: List[str], source_dir: str, action_name: str) -> List[str]:
    if not files: return []
    if len(files) == 1:
        console.print(f"Only 1 file found: {files[0]}")
        confirm = hexa_prompt("Process this file? (Y/n): ").strip().lower()
        return files if confirm != 'n' else []
    console.print(f"\nSelect files to {action_name}:")
    for idx, f in enumerate(files, 1):
        sz = os.path.getsize(os.path.join(source_dir, f))
        console.print(f"  [{idx}] {f} ({sz:,} bytes)")
    console.print("  [A] ALL FILES")
    console.print("  [0] Cancel")
    while True:
        choice = hexa_prompt("Your choice: ").strip().upper()
        if choice == 'A': return files
        if choice == '0': return []
        if choice.isdigit():
            idx = int(choice)
            if 1 <= idx <= len(files): return [files[idx-1]]
        console.print("Invalid selection!")

def action_unpack():
    files = get_real_files()
    if not files: hexa_alert("LUA_ORIGINAL folder is empty!", "error"); safe_input('\nPress Enter...'); return
    selected = select_files_interactive(files, str(REAL_DIR), "UNPACK")
    if not selected: return
    success = 0
    with tempfile.TemporaryDirectory(prefix='bgmi_dec_') as tmp_dir:
        for idx, f in enumerate(selected, 1):
            rgb_compile_step(f"[{idx}/{len(selected)}] {f}")
            inp = REAL_DIR / f
            ok, result, _ = robust_decompile(str(inp), str(UNPACK_DIR), tmp_dir)
            if ok:
                console.print(f"Decompiled: {os.path.basename(result)}"); success += 1
            else:
                console.print(f"Failed: {result}")
                fallback_path = UNPACK_DIR / (os.path.splitext(f)[0] + ".luac")
                ok2, _ = convert_file(str(inp), str(fallback_path))
                if ok2: console.print(f"Saved raw bytecode as {fallback_path}")
    hexa_alert(f"Unpack Complete! {success}/{len(selected)} files decompiled.", "success")
    safe_input('\nPress Enter...')

def recompile_lua_files(selected: List[str], quiet: bool = False) -> Tuple[int, List[str]]:
    success = 0
    failed = []
    for idx, f in enumerate(selected, 1):
        name = os.path.splitext(f)[0]
        inp = UNPACK_DIR / f
        out = EDIT_DIR / (name + ".lua")
        rgb_compile_step(f"[{idx}/{len(selected)}] {f}")

        if FORCE_COMPILE:
            rgb_compile_step("FORCE COMPILE ALVSIA POWERFUL")

        # ── 🔐 STEP A: ALVSIA ENC apply ──────────────────────
        temp_enc_lua = LUA_PAK_ROOT / f"{name}_enc.lua"
        compile_input = str(inp)
        enc_ok = False
        try:
            protect_lua_file(inp, temp_enc_lua)
            if temp_enc_lua.exists() and temp_enc_lua.stat().st_size > 0:
                compile_input = str(temp_enc_lua)
                enc_ok = True
                rgb_compile_step(f"🔐 ENC applied: {temp_enc_lua.name} ({temp_enc_lua.stat().st_size:,} B)")
            else:
                rgb_compile_step("⚠ ENC output empty, using original")
        except Exception as enc_err:
            console.print(f"[white]⚠ ENC failed ({enc_err}), using original source[/white]")
        # ────────────────────────────────────────────────────────────────

        # ── 🔐 STEP B: ENC wali .lua compile karo ──────────────────────
        temp_std = str(LUA_PAK_ROOT / f"{name}_temp_std.luac")
        if STRIP_DEBUG:
            cmd = [LUAC_PATH, "-s", "-o", temp_std, compile_input]
        else:
            cmd = [LUAC_PATH, "-o", temp_std, compile_input]

        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        except subprocess.TimeoutExpired:
            console.print("[white]✗ Compilation timed out[/white]")
            failed.append(f)
            if temp_enc_lua.exists():
                try: temp_enc_lua.unlink()
                except: pass
            continue

        if res.returncode != 0 or not os.path.exists(temp_std):
            err = (res.stderr or res.stdout or "Unknown error").strip()[:300]
            console.print(f"[white]✗ Compile failed: {err}[/white]")
            failed.append(f)
            if temp_enc_lua.exists():
                try: temp_enc_lua.unlink()
                except: pass
            continue

        # ── 🔐 STEP C: Original file dhoondo ──────────────────────────
        orig = None
        candidate_names = [name]
        if name.lower() == "brplayercharacterbase":
            candidate_names.append("CharacterBase")
        elif name.lower() == "characterbase":
            candidate_names.append("BRPlayerCharacterBase")

        for candidate in candidate_names:
            for ext in ['.luac', '.slua', '.lua']:
                p = REAL_DIR / (candidate + ext)
                if p.exists():
                    orig = str(p)
                    break
            if orig:
                break

        if not orig:
            console.print("[white]✗ Original not found in LUA_ORIGINAL[/white]")
            failed.append(f)
            if os.path.exists(temp_std):
                try: os.remove(temp_std)
                except: pass
            if temp_enc_lua.exists():
                try: temp_enc_lua.unlink()
                except: pass
            continue

        # ── 🔐 STEP D: PUBG PAK-ready banao ────────────────────────────
        orig_size = os.path.getsize(orig)
        ok2, msg = repack_to_pubg(temp_std, orig, str(out), pad_to_size=orig_size)

        if ok2:
            new_size = out.stat().st_size if out.exists() else 0
            enc_tag = " [ENC]" if enc_ok else " [PLAIN]"
            rgb_compile_step(f"✓ Recompiled: {out.name} ({new_size:,} B){enc_tag}")
            if new_size > orig_size:
                rgb_compile_step(f"⚠ {new_size - orig_size:,} B bigger than original! PAK mismatch ho sakta hai.")
            success += 1
        else:
            rgb_compile_step(f"✗ Recompile failed: {msg}")
            failed.append(f)

        # ── cleanup ─────────────────────────────────────────────────────
        if os.path.exists(temp_std):
            try: os.remove(temp_std)
            except: pass
        if temp_enc_lua.exists():
            try: temp_enc_lua.unlink()
            except: pass

    return success, failed


def action_repack_unpack():
    global REPACK_UI_PLAIN
    _old_repack_plain = REPACK_UI_PLAIN
    REPACK_UI_PLAIN = False
    try:
        files = get_unpack_files()
        if not files: hexa_alert("LUA_EDIT folder is empty!", "error"); safe_input('\nPress Enter...'); return
        selected = select_files_interactive(files, str(UNPACK_DIR), "REPACK")
        if not selected: return
    
        if FORCE_COMPILE and SKIP_ALL_FIXES:
            rgb_compile_step("🚀 FAST COMPILE MODE — Raw Build Execution")
            rgb_compile_step("Launching high-speed compilation...")
    
        success, failed = recompile_lua_files(selected)
        rgb_compile_step(f"✓ Repack Complete! {success}/{len(selected)} successful.")
        if failed: hexa_alert(f"Failed files: {', '.join(failed)}", "error")
        safe_input('\nPress Enter...')
    finally:
        REPACK_UI_PLAIN = _old_repack_plain

# ==============================================================================
# TOOLCHAIN — PAK CORE (COMPLETE)
# ==============================================================================

ZUC_KEY = bytes.fromhex('01010101010101010101010101010101')
ZUC_IV = bytes.fromhex('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')

RSA_MOD_1 = bytes.fromhex('CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4')
RSA_MOD_2 = bytes.fromhex('7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8')

SIMPLE1_DECRYPT_KEY = 121
SIMPLE2_DECRYPT_KEY = bytes.fromhex('E55B4ED1')
SIMPLE2_BLOCK_SIZE = 16

SM4_SECRET_4 = 'eb691efea914241317a8'
SM4_SECRET_2 = 'Q0hVTKey$as*1ZFlQCiA'

# ═══════════ ✅ FIXED: 52 SM4 KEYS (MATCHES 420.py EXACTLY) ═══════════
SM4_SECRET_NEW = [
    "xG2qW5lP7lV2iN5fN5pG", "xT1cJ6dL5wC0kK1rB4dK", "qC4jS5bZ6fL5xE6nD4zA",
    "gD4jQ2aL3bS3lC3xT0iW", "xU1yQ8wE9zY3gZ3bT5aE", "uQ3cO2dX7xY4xU7gH7iS",
    "gW1fR0jK6wQ4oN0oK1kZ", "aJ4pV7iZ7pU4wP2aC2cZ", "cX6jT3cM2oT3vK0kJ1qN",
    "iT2vS0cS6yT6cZ1sE1lO", "hM1pH9iY8wM9hT4lN5uJ", "kG6bC8jK0fL0dE4sH4mL",
    "dB6lB3vE0eZ8wM8rI0aC", "tP7sP7nI9rA2vQ4cV5yQ", "aT0cL1yN4pT3sZ7eM2vY",
    "uV6fU8fC9zN3mP5dH8mN", "rT6aQ6oZ1yM0gO5tO1aN", "jU5bH7lQ0fM9hK2kI0o",
    "iQ0eM0mJ7uT0kV6kL5zY",
    "0123456789ABCDEF0123456789ABCDEF",
    "0785DE054B3475AF78C7BAC4D80CB72B",
    "0A77C25C826CC107FD266A55D263629B",
    "3F5FC93B338687BC7235B1AB103F47B3",
    "47C79F5181022D8F62602F96F6156FF6",
    "4A5A8F75F6D857E64E281A3A7F4C0B7E",
    "5322fa2e8888277e1fb9bf12ea33d321",
    "62FEBA005FED6096C90F7A9923E56A31",
    "68E477D78BEFF80326E0A76043D9B4BC",
    "6B0CD68886A371B59CE1B9EDCF067801",
    "74fc7d317ebc4e7c912d0c9ffff18edf",
    "79D17033E745CBFF2B4AFEC8631DF581",
    "81DE38845316AABE9490FA8CE4BC1E64",
    "9232EC043A23D8AE9DC9681945E2178A",
    "9CE6F64696EB79E4BCDFBEE7FD553799",
    "A601513C204A4C837CE616BA6C0F2DE4",
    "AB879940BD15B6B25691265F7384B271",
    "B3B8BC3B132C06B22AE707C914264E7F",
    "BAEEE6F9ECFBF765125DA1EA1B340D66",
    "C1B91D02E1248E0010D2DD84D7964F34",
    "CB195DBC3A03ABCD5AC62C5D3FCFF57F",
    "D41F40880A76A02A3D7EE5AD91F13733",
    "E990DE3C9870D1B772C1BDE792A49FFA",
    "EEBC915CE44901401D881E6091423036",
    "EFB929595D312AC8F305D5A794CFEDA1",
    "EFCD8763485FA53E8C2852367C022F34",
    "FD7CA227DE3BED3F380DD0E064B0EC81",
    "FE8EC3BFC7F59FD11C94EE2A285D801D",
    "a0479691c27a190a172b00e0db201ac6",
    "a9d67fa875f19d899b3d26999179518d",
    "b824b78644fb031746dcf9900d3f12fa",
    "d41d8cd98f00b204e9800998ecf8427e",
    "00000000000000000000000000000000",
]

EM_SIMPLE1 = 1
EM_SIMPLE2 = 16
EM_SM4_2 = 2
EM_SM4_4 = 4
EM_SM4_NEW_BASE = 31
EM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE
EM_UNKNOWN_17 = 17   # ✅ NEW

CM_NONE = 0
CM_ZLIB = 1
CM_ZSTD = 6
CM_ZSTD_DICT = 8
CM_MASK = 15

class SM4:
    _S_BOX = bytes([
        52, 102, 37, 116, 137, 120, 228, 169, 90, 65, 188, 122, 214, 22, 33, 35,
        77, 97, 218, 148, 155, 223, 19, 60, 105, 58, 49, 10, 95, 215, 153, 149,
        241, 174, 114, 61, 7, 96, 36, 182, 152, 238, 196, 162, 45, 136, 221, 141,
        4, 234, 187, 17, 202, 62, 93, 161, 246, 63, 176, 151, 128, 71, 43, 166,
        230, 247, 217, 177, 89, 192, 124, 190, 84, 40, 183, 126, 79, 248, 67, 110,
        160, 80, 14, 245, 144, 184, 251, 163, 123, 98, 25, 70, 3, 42, 185, 143,
        159, 119, 180, 91, 131, 135, 8, 235, 226, 30, 66, 240, 15, 232, 113, 106,
        117, 173, 85, 31, 181, 171, 51, 250, 127, 21, 189, 133, 216, 6, 104, 179,
        82, 48, 72, 11, 0, 237, 239, 178, 87, 142, 231, 108, 213, 229, 46, 83,
        130, 5, 249, 129, 244, 86, 191, 140, 75, 227, 219, 74, 145, 76, 44, 211,
        64, 41, 78, 32, 20, 54, 121, 9, 111, 209, 55, 224, 57, 12, 138, 146,
        56, 18, 53, 109, 225, 253, 147, 154, 23, 212, 201, 156, 107, 132, 38, 157,
        175, 118, 193, 158, 208, 150, 197, 203, 233, 115, 73, 210, 205, 100, 195, 199,
        1, 125, 243, 172, 252, 222, 164, 68, 50, 27, 194, 186, 28, 2, 198, 39,
        69, 139, 242, 24, 167, 16, 81, 29, 200, 207, 99, 255, 47, 13, 88, 206,
        101, 165, 220, 26, 59, 134, 254, 34, 92, 168, 94, 103, 170, 236, 112, 204
    ])
    _FK = [1184304796, 1270900830, 1493524870, 3164752158]
    _CK = [964907, 973793155, 2654690407, 2916866751, 2071233739, 1226140771, 3348805095, 2045549823, 388349611, 800627875, 612403927, 3721562911, 1195432523, 3150178931, 612053223, 2445162591, 67183755, 1174197155, 1393249511, 3331183455, 3822152747, 1332317203, 1804781383, 1990130463, 1282653851, 3376591251, 2910902311, 925872959, 332098219, 735840931, 396665415, 3588844719]
    
    @staticmethod
    def ROL32(x, n):
        return (x << n) & 0xFFFFFFFF | (x >> (32 - n))
    
    @staticmethod
    def _BS(X):
        return (SM4._S_BOX[X >> 24 & 255] << 24 | 
                SM4._S_BOX[X >> 16 & 255] << 16 | 
                SM4._S_BOX[X >> 8 & 255] << 8 | 
                SM4._S_BOX[X & 255])
    
    @staticmethod
    def _T0(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 2) ^ SM4.ROL32(X, 10) ^ SM4.ROL32(X, 18) ^ SM4.ROL32(X, 24)
    
    @staticmethod
    def _T1(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 13) ^ SM4.ROL32(X, 23)
    
    @staticmethod
    def _key_expand(key: bytes, rkey: list):
        K0 = int.from_bytes(key[0:4], 'big') ^ SM4._FK[0]
        K1 = int.from_bytes(key[4:8], 'big') ^ SM4._FK[1]
        K2 = int.from_bytes(key[8:12], 'big') ^ SM4._FK[2]
        K3 = int.from_bytes(key[12:16], 'big') ^ SM4._FK[3]
        for i in range(0, 32, 4):
            K0 = K0 ^ SM4._T1(K1 ^ K2 ^ K3 ^ SM4._CK[i])
            rkey[i] = K0
            K1 = K1 ^ SM4._T1(K2 ^ K3 ^ K0 ^ SM4._CK[i + 1])
            rkey[i + 1] = K1
            K2 = K2 ^ SM4._T1(K3 ^ K0 ^ K1 ^ SM4._CK[i + 2])
            rkey[i + 2] = K2
            K3 = K3 ^ SM4._T1(K0 ^ K1 ^ K2 ^ SM4._CK[i + 3])
            rkey[i + 3] = K3
    
    @classmethod
    def key_length(cls):
        return 16
    
    @classmethod
    def block_length(cls):
        return 16
    
    def __init__(self, key: bytes):
        if len(key) != self.key_length():
            raise ValueError(f'Key must be {self.key_length()} bytes')
        else:
            self._key = key
            self._rkey = [0] * 32
            SM4._key_expand(self._key, self._rkey)
            self._block_buffer = bytearray()
    
    def encrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[i + 1])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[i + 2])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[i + 3])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)
    
    def decrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[31 - i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[30 - i])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[29 - i])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[28 - i])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)
    
    def decrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[31 - i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[30 - i])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[29 - i])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[28 - i])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)

class Misc:
    @staticmethod
    def pad_to_n(data: bytes, n: int) -> bytes:
        assert n > 0
        padding = n - len(data) % n
        if padding == n:
            return data
        else:
            return data + b'\x00' * padding

    @staticmethod
    def align_up(x: int, n: int) -> int:
        return (x + n - 1) // n * n

class Reader:
    def __init__(self, buffer, cursor=0):
        self._buffer = buffer
        self._cursor = cursor
    def u1(self, move_cursor=True) -> int:
        return self.unpack('B', move_cursor=move_cursor)[0]
    def u4(self, move_cursor=True) -> int:
        return self.unpack('<I', move_cursor=move_cursor)[0]
    def u8(self, move_cursor=True) -> int:
        return self.unpack('<Q', move_cursor=move_cursor)[0]
    def i1(self, move_cursor=True) -> int:
        return self.unpack('b', move_cursor=move_cursor)[0]
    def i4(self, move_cursor=True) -> int:
        return self.unpack('<i', move_cursor=move_cursor)[0]
    def i8(self, move_cursor=True) -> int:
        return self.unpack('<q', move_cursor=move_cursor)[0]
    def s(self, n: int, move_cursor=True) -> bytes:
        return self.unpack(f'{n}s', move_cursor=move_cursor)[0]
    def unpack(self, f: str, offset=0, move_cursor=True):
        x = struct.unpack_from(f, self._buffer, self._cursor + offset)
        if move_cursor:
            self._cursor += struct.calcsize(f)
        return x
    def string(self, move_cursor=True) -> str:
        length = self.i4(move_cursor=move_cursor)
        if length == 0:
            return str()
        else:
            assert length > 0
            offset = 0 if move_cursor else 4
            raw = self.unpack(f'{length}s', offset=offset, move_cursor=move_cursor)[0].rstrip(b'\x00')
            return raw.replace(b'\x00', b'').decode('utf-8', errors='replace')

class PakInfo:
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_index_encrypted(x: int) -> int:
            MASK_8 = 255
            return (x ^ keystream[3]) & MASK_8
        def decrypt_magic(x: int) -> int:
            return x ^ keystream[2]
        def decrypt_index_hash(x: bytes) -> bytes:
            key = struct.pack('<5I', *keystream[4:][:5])
            assert len(x) == len(key)
            return bytes((a ^ b for a, b in zip(x, key)))
        def decrypt_index_size(x: int) -> int:
            return x ^ (keystream[10] << 32 | keystream[11])
        def decrypt_index_offset(x: int) -> int:
            return x ^ (keystream[0] << 32 | keystream[1])
        reader = Reader(buffer[-PakInfo._mem_size((-1)):])
        self.index_encrypted = decrypt_index_encrypted(reader.u1()) == 1
        self.magic = decrypt_magic(reader.u4())
        self.version = reader.u4()
        self.index_hash = decrypt_index_hash(reader.s(20)) if self.version >= 6 else bytes()
        self.index_size = decrypt_index_size(reader.u8())
        self.index_offset = decrypt_index_offset(reader.u8())
        if self.version <= 3:
            self.index_encrypted = False
    @staticmethod
    def _mem_size(_: int) -> int:
        return 45

class TencentPakInfo(PakInfo):
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_unk(x: bytes) -> bytes:
            key = struct.pack('<8I', *keystream[7:][:8])
            assert len(x) == len(key)
            return bytes((a ^ b for a, b in zip(x, key)))
        def decrypt_stem_hash(x: int) -> int:
            return x ^ keystream[8]
        def decrypt_unk_hash(x: int) -> int:
            return x ^ keystream[9]
        super().__init__(buffer, keystream)
        reader = Reader(buffer[-TencentPakInfo._mem_size(self.version):])
        self.unk1 = decrypt_unk(reader.s(32)) if self.version >= 7 else bytes()
        self.packed_key = reader.s(256) if self.version >= 8 else bytes()
        self.packed_iv = reader.s(256) if self.version >= 8 else bytes()
        self.packed_index_hash = reader.s(256) if self.version >= 8 else bytes()
        self.stem_hash = decrypt_stem_hash(reader.u4()) if self.version >= 9 else 0
        self.unk2 = decrypt_unk_hash(reader.u4()) if self.version >= 9 else 0
        self.content_org_hash = reader.s(20) if self.version >= 12 else bytes()
    @staticmethod
    def _mem_size(version: int) -> int:
        size_for_7 = 32 if version >= 7 else 0
        size_for_8 = 768 if version >= 8 else 0
        size_for_9 = 8 if version >= 9 else 0
        size_for_12 = 20 if version >= 12 else 0
        return PakInfo._mem_size(version) + size_for_7 + size_for_8 + size_for_9 + size_for_12

class PakCompressedBlock:
    def __init__(self, reader: Reader):
        self.start = reader.u8()
        self.end = reader.u8()

@dataclass
class TencentPakEntry:
    def __init__(self, reader: Reader, version: int):
        self.content_hash = reader.s(20)
        if version <= 1:
            _ = reader.u8()
        self.offset = reader.u8()
        self.uncompressed_size = reader.u8()
        self.compression_method = reader.u4() & CM_MASK
        self.size = reader.u8()
        self.unk1 = reader.u1() if version >= 5 else 0
        self.unk2 = reader.s(20) if version >= 5 else bytes()
        if self.compression_method != 0 and version >= 3:
            self.compressed_blocks = [PakCompressedBlock(reader) for _ in range(reader.u4())]
        else:
            self.compressed_blocks = []
        self.compression_block_size = reader.u4() if version >= 4 else 0
        self.encrypted = reader.u1() == 1 if version >= 4 else False
        self.encryption_method = reader.u4() if version >= 12 else 0
        self.index_new_sep = reader.u4() if version >= 12 else 0

class PakCrypto:
    class _LCG:
        def __init__(self, seed: int):
            self.state = seed
        def next(self) -> int:
            MASK_32 = 4294967295
            MSB_1 = 2147483648
            def wrap(x: int) -> int:
                x &= MASK_32
                if not x & MSB_1:
                    return x
                else:
                    return (x + MSB_1 & MASK_32) - MSB_1
            x1 = wrap(1103515245 * self.state)
            self.state = wrap(x1 + 12345)
            x2 = wrap(x1 + 77880) if self.state < 0 else self.state
            return (x2 >> 16 & MASK_32) % 32767
    @staticmethod
    def zuc_keystream() -> List[int]:
        try:
            zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)
            return [struct.unpack('>I', zuc.generate())[0] for _ in range(16)]
        except:
            return [0x9E3779B9, 0x3C6EF372, 0xDA7A5E2B, 0x7895C8E4, 0x16B1339D, 0xB4CC9E56, 0x52E8090F, 0xF10373C8, 0x8F1EDE81, 0x2D3A493A, 0xCB55B3F3, 0x69711EAC, 0x078C8965, 0xA5A7F41E, 0x43C35ED7, 0xE1DEC990]
    @staticmethod
    def _xorxor(buffer, x) -> bytes:
        return bytes((buffer[i] ^ x[i % len(x)] for i in range(len(buffer))))
    @staticmethod
    def _hashhash(buffer, n: int) -> bytes:
        result = bytes()
        for _ in range(math.ceil(n / SHA1.digest_size)):
            result += SHA1.new(buffer).digest()
        if len(result) >= n:
            result = result[:n]
            return result
        else:
            result += b'\x00' * (n - len(result))
            return result
    @staticmethod
    def _meowmeow(buffer) -> bytes:
        def unpad(x):
            skip = 1 + next((i for i in range(len(x)) if x[i]!= 0))
            return x[skip:]
        if len(buffer) < 43:
            return bytes()
        else:
            x1 = buffer[1:][:SHA1.digest_size]
            x2 = buffer[SHA1.digest_size + 1:]
            x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))
            x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))
            part1, m = (x2[:SHA1.digest_size], x2[SHA1.digest_size:])
            if part1!= SHA1.new(b'\x00' * SHA1.digest_size).digest():
                return bytes()
            else:
                return unpad(m)
    @staticmethod
    def rsa_extract(signature: bytes, modulus: bytes) -> bytes:
        c = int.from_bytes(signature, 'little')
        n = int.from_bytes(modulus, 'little')
        e = 65537
        m = pow(c, e, n).to_bytes(256, 'little').rstrip(b'\x00')
        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))
    @staticmethod
    def _decrypt_simple1(ciphertext) -> bytes:
        return bytes((x ^ SIMPLE1_DECRYPT_KEY for x in ciphertext))
    @staticmethod
    def _decrypt_simple2(ciphertext) -> bytes:
        class RollingKey:
            def __init__(self, initial_value: int):
                self._value = initial_value
            def update(self, x: int) -> int:
                self._value ^= x
                return self._value
        assert len(ciphertext) % SIMPLE2_BLOCK_SIZE == 0
        initial_key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
        rolling_key = RollingKey(initial_key)
        plaintext = (struct.pack('<I', rolling_key.update(x)) for x in struct.unpack(f'<{len(ciphertext) // 4}I', ciphertext))
        return bytes(it.chain.from_iterable(plaintext))
    @staticmethod
    @lru_cache(maxsize=1)
    def _derive_sm4_key(file_path: PurePath, encryption_method: int) -> bytes:
        part1 = file_path.stem.lower()
        if encryption_method == EM_SM4_2:
            secret = SM4_SECRET_2
        else:
            if encryption_method == EM_SM4_4:
                secret = SM4_SECRET_4
            else:
                index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
                secret = f'{SM4_SECRET_NEW[index]}{encryption_method}'
        return SHA1.new(str(part1 + secret).encode()).digest()[:SM4.key_length()]
    @staticmethod
    @lru_cache(maxsize=1)
    def _sm4_context_for_key(key: bytes) -> SM4:
        return SM4(key)
    @staticmethod
    def _decrypt_sm4(ciphertext, file_path: PurePath, encryption_method: int) -> bytes:
        assert len(ciphertext) % SM4.block_length() == 0
        key = PakCrypto._derive_sm4_key(file_path, encryption_method)
        sm4 = PakCrypto._sm4_context_for_key(key)
        return bytes(it.chain.from_iterable((sm4.decrypt(x) for x in it.batched(ciphertext, SM4.block_length()))))
    @staticmethod
    def decrypt_index(ciphertext, pak_info: TencentPakInfo) -> bytes:
        if pak_info.version > 7:
            try:
                key = PakCrypto.rsa_extract(pak_info.packed_key, RSA_MOD_1)
                iv = PakCrypto.rsa_extract(pak_info.packed_iv, RSA_MOD_1)
                if key and iv and len(key) == 32 and len(iv) >= 16:
                    aes = AES.new(key, MODE_CBC, iv[:16])
                    decrypted = aes.decrypt(ciphertext)
                    try:
                        return unpad(decrypted, AES.block_size)
                    except ValueError:
                        return decrypted
            except Exception:
                pass
            ks_bytes = struct.pack('<5I', *PakCrypto.zuc_keystream()[4:][:5])
            if len(ciphertext) < len(ks_bytes):
                ks_bytes = ks_bytes[:len(ciphertext)]
            else:
                ks_bytes = (ks_bytes * (len(ciphertext) // len(ks_bytes) + 1))[:len(ciphertext)]
            return bytes(a ^ b for a, b in zip(ciphertext, ks_bytes))
        else:
            return bytes(PakCrypto._decrypt_simple1(ciphertext))
    @staticmethod
    def _is_simple1_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE1
    @staticmethod
    def _is_simple2_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE2 or encryption_method == 17
    @staticmethod
    def _is_sm4_method(encryption_method: int) -> bool:
        return encryption_method == EM_SM4_2 or encryption_method == EM_SM4_4 or encryption_method & EM_SM4_NEW_MASK!= 0
    @staticmethod
    def align_encrypted_content_size(n: int, encryption_method: int) -> int:
        if PakCrypto._is_simple2_method(encryption_method):
            return Misc.align_up(n, SIMPLE2_BLOCK_SIZE)
        else:
            if PakCrypto._is_sm4_method(encryption_method):
                return Misc.align_up(n, SM4.block_length())
            else:
                return n
    @staticmethod
    def decrypt_block(ciphertext, file: PurePath, encryption_method: int) -> bytes:
        if PakCrypto._is_simple1_method(encryption_method):
            return PakCrypto._decrypt_simple1(ciphertext)
        else:
            if PakCrypto._is_simple2_method(encryption_method):
                return PakCrypto._decrypt_simple2(ciphertext)
            else:
                if PakCrypto._is_sm4_method(encryption_method):
                    return PakCrypto._decrypt_sm4(ciphertext, file, encryption_method)
                else:
                    return ciphertext
    @staticmethod
    @lru_cache(maxsize=33)
    def generate_block_indices(n: int, encryption_method: int) -> List[int]:
        if not PakCrypto._is_sm4_method(encryption_method):
            return list(range(n))
        else:
            permutation = []
            lcg = PakCrypto._LCG(n)
            while len(permutation)!= n:
                x = lcg.next() % n
                if x not in permutation:
                    permutation.append(x)
            inverse = [0] * len(permutation)
            for i, x in enumerate(permutation):
                inverse[x] = i
            return inverse

class PakCompression:
    @staticmethod
    @lru_cache(maxsize=33)
    def _zstd_decompressor(dict: ZstdCompressionDict) -> ZstdDecompressor:
        return ZstdDecompressor(dict)
    @staticmethod
    def zstd_dictionary(dict_data) -> ZstdCompressionDict:
        return ZstdCompressionDict(dict_data, DICT_TYPE_AUTO)
    @staticmethod
    def decompress_block(block, dict: Optional[ZstdCompressionDict], compression_method: int) -> bytes:
        if compression_method == CM_ZLIB:
            try:
                return zlib.decompress(block)
            except zlib.error:
                return block
        else:
            if compression_method == CM_ZSTD or compression_method == CM_ZSTD_DICT:
                if compression_method!= CM_ZSTD_DICT:
                    dict = None
                try:
                    return PakCompression._zstd_decompressor(dict).decompress(block)
                except:
                    return block
            else:
                return block

class TencentPakFile:
    def __init__(self, file_path: PurePath, is_od=False):
        self._file_path = file_path
        self._file_handle = open(file_path, 'rb')
        try:
            import mmap
            self._file_mmap = mmap.mmap(self._file_handle.fileno(), 0, access=mmap.ACCESS_READ)
            self._file_content = memoryview(self._file_mmap)
        except:
            self._file_content = memoryview(self._file_handle.read())
            self._file_mmap = None
        self._is_od = is_od
        self._mount_point = PurePath()
        self._is_zstd_with_dict = 'zsdic' in str(self._file_path)
        self._zstd_dict = None
        self._files = []
        self._index = {}
        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())
        self._verify_stem_hash()
        self._tencent_load_index()
    
    def detect_dominant_style(self) -> dict:
        """Detect dominant compression/encryption style from PAK entries"""
        comp_counter = Counter()
        enc_counter = Counter()
        blk_counter = Counter()
        enc_flag_counter = Counter()
        total = len(self._files)
        if total == 0:
            return {'comp_method': CM_ZSTD, 'enc_method': 0, 'encrypted': False, 'block_size': 0x10000}
        for entry in self._files:
            comp_counter[entry.compression_method] += 1
            if entry.encrypted:
                enc_counter[entry.encryption_method] += 1
                enc_flag_counter['encrypted'] += 1
            else:
                enc_flag_counter['plain'] += 1
            if entry.compression_block_size:
                blk_counter[entry.compression_block_size] += 1
        non_none = [(m,c) for m,c in comp_counter.items() if m != CM_NONE]
        comp_method = max(non_none, key=lambda x: x[1])[0] if non_none else CM_NONE
        encrypted = enc_flag_counter.get('encrypted', 0) > enc_flag_counter.get('plain', 0)
        enc_method = enc_counter.most_common(1)[0][0] if encrypted and enc_counter else 0
        block_size = blk_counter.most_common(1)[0][0] if blk_counter else 0x10000
        return {'comp_method': comp_method, 'enc_method': enc_method, 'encrypted': encrypted, 'block_size': block_size}
    
    def inject_files(self, inject_plan: list, output_pak: Path, add_signature_marker: bool = True) -> None:
        """Inject new files into this PAK, producing a new PAK at output_pak."""
        if not inject_plan:
            raise ValueError('inject_plan is empty — nothing to inject')

        console.print(Panel(
            f'[bold white]💉 CUSTOM INJECT[/bold white]\n'
            f'[white]Source PAK:[/] [white]{self._file_path.name}[/white]\n'
            f'[white]Output    :[/] [white]{output_pak.name}[/white]\n'
            f'[white]Injecting :[/] [white]{len(inject_plan)} new file(s)[/white]',
            title='INJECT MODE', border_style=get_border_style(1, 0.55), padding=(0, 2)
        ))

        console.print('\n[bold white]━━ STEP 1/5 : LOADING INJECT FILES ━━[/bold white]')
        work_items = []
        for i, item in enumerate(inject_plan):
            if item.get('plain_bytes') is not None:
                plain = item['plain_bytes']
            elif item.get('src_path') is not None:
                try:
                    plain = Path(item['src_path']).read_bytes()
                except Exception as e:
                    console.print(f'   [white]✗ Cannot read {item["src_path"]}: {e} — skipping[/white]')
                    continue
            else:
                console.print(f'   [white]✗ Inject item {i} has no src_path or plain_bytes — skipping[/white]')
                continue

            internal = item['internal_path'].replace('\\', '/').lstrip('/')
            if not internal:
                console.print(f'   [white]✗ Empty internal_path for item {i} — skipping[/white]')
                continue

            parts = internal.rsplit('/', 1)
            if len(parts) == 2:
                dir_str, file_name = parts[0], parts[1]
            else:
                dir_str, file_name = '', parts[0]

            work_items.append({
                'dir_str':       dir_str,
                'file_name':     file_name,
                'internal_path': internal,
                'plain':         plain,
                'comp_method':   item['comp_method'],
                'enc_method':    item['enc_method'],
                'encrypted':     bool(item['encrypted']),
                'block_size':    item['block_size'],
                'comp_level':    item.get('comp_level', 19),
            })
            console.print(f'   [white]✨[/] {internal} [dim]({len(plain):,} bytes)[/dim]')

        if not work_items:
            raise RuntimeError('No valid inject items after loading')
        console.print(f'[white]✔ Loaded {len(work_items)} file(s)[/white]')

        console.print('\n[bold white]━━ STEP 2/5 : ENCODING INJECT FILES ━━[/bold white]')
        keystream = PakCrypto.zuc_keystream()
        version = self._pak_info.version
        header_size = TencentPakInfo._mem_size(version)
        PAK_MAGIC = self._pak_info.magic

        orig_index_offset = self._pak_info.index_offset
        current_new_offset = orig_index_offset
        new_data_region = bytearray()
        new_injected_entries = []

        def _encrypt_plaintext(plaintext, pak_relative_path, encryption_method):
            if PakCrypto._is_simple1_method(encryption_method):
                return bytes(b ^ SIMPLE1_DECRYPT_KEY for b in plaintext)
            elif PakCrypto._is_simple2_method(encryption_method):
                pad = (-len(plaintext)) % SIMPLE2_BLOCK_SIZE
                plaintext += b"\x00" * pad
                key, = struct.unpack("<I", SIMPLE2_DECRYPT_KEY)
                rolling = key
                out = []
                for x, in struct.iter_unpack("<I", plaintext):
                    c = rolling ^ x
                    out.append(c)
                    rolling ^= c
                return struct.pack(f"<{len(out)}I", *out)
            elif PakCrypto._is_sm4_method(encryption_method):
                key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)
                sm4 = PakCrypto._sm4_context_for_key(key)
                pad_len = (-len(plaintext)) % 16
                if pad_len > 0:
                    plaintext = plaintext + b'\x00' * pad_len
                out = bytearray()
                for i in range(0, len(plaintext), 16):
                    block = plaintext[i:i+16]
                    if len(block) < 16:
                        block = block.ljust(16, b'\x00')
                    out.extend(sm4.encrypt(block))
                return bytes(out)
            return plaintext

        for item in work_items:
            plain = item['plain']
            comp_method = item['comp_method']
            enc_method = item['enc_method']
            encrypted = item['encrypted']
            block_size_val = item['block_size']
            file_path_for_crypto = PurePath(item['file_name'])

            if len(plain) == 0:
                new_injected_entries.append({
                    'content_hash': SHA1.new(b'').digest(),
                    'offset': current_new_offset,
                    'uncompressed_size': 0, 'size': 0,
                    'comp_method': CM_NONE, 'enc_method': 0, 'encrypted': False,
                    'block_size_val': 0, 'compressed_blocks': [],
                    'unk1': 0, 'unk2': b'\x00' * 20, 'index_new_sep': 0,
                    '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(),
                    '_file_name': item['file_name'],
                })
                continue

            if comp_method == CM_NONE:
                if encrypted:
                    aligned_size = PakCrypto.align_encrypted_content_size(len(plain), enc_method)
                    padded = plain + b'\x00' * (aligned_size - len(plain))
                    stored_data = _encrypt_plaintext(padded, file_path_for_crypto, enc_method)
                else:
                    stored_data = plain
                new_size = len(stored_data)
                new_compressed_blocks = []
            else:
                chunks = [plain[i:i+block_size_val] for i in range(0, len(plain), block_size_val)]
                if not chunks: chunks = [b'']
                compressed_chunks = []
                for chunk in chunks:
                    comp = None
                    if comp_method in (CM_ZSTD, CM_ZSTD_DICT):
                        zstd_dict = self._zstd_dict if comp_method == CM_ZSTD_DICT else None
                        for lvl in range(22, 0, -1):
                            try:
                                c = ZstdCompressor(level=lvl, dict_data=zstd_dict, threads=1)
                                comp = c.compress(chunk)
                                break
                            except: continue
                    elif comp_method == CM_ZLIB:
                        comp = zlib.compress(chunk, level=9)
                    if comp is None: comp = chunk
                    compressed_chunks.append(comp)

                encrypted_chunks = []
                for comp_data in compressed_chunks:
                    if encrypted:
                        comp_data = _encrypt_plaintext(comp_data, file_path_for_crypto, enc_method)
                    encrypted_chunks.append(comp_data)

                n_blocks = len(encrypted_chunks)
                indices = PakCrypto.generate_block_indices(n_blocks, enc_method)
                physical_blocks = [None] * n_blocks
                for j, chunk_data in enumerate(encrypted_chunks):
                    physical_blocks[indices[j]] = chunk_data

                physical_offsets = []
                block_cursor = current_new_offset
                for phys_block in physical_blocks:
                    physical_offsets.append((block_cursor, block_cursor + len(phys_block)))
                    block_cursor += len(phys_block)
                new_compressed_blocks = physical_offsets
                stored_data = b''.join(physical_blocks)
                new_size = len(stored_data)
                if encrypted:
                    aligned_total = PakCrypto.align_encrypted_content_size(new_size, enc_method)
                    if aligned_total > new_size:
                        stored_data = stored_data + b'\x00' * (aligned_total - new_size)
                        new_size = aligned_total

            new_content_hash = SHA1.new(stored_data).digest()
            new_data_region.extend(stored_data)

            new_injected_entries.append({
                'content_hash': new_content_hash,
                'offset': current_new_offset,
                'uncompressed_size': len(plain),
                'size': new_size,
                'comp_method': comp_method,
                'enc_method': enc_method if encrypted else 0,
                'encrypted': encrypted,
                'block_size_val': block_size_val,
                'compressed_blocks': new_compressed_blocks,
                'unk1': 0, 'unk2': b'\x00' * 20, 'index_new_sep': 0,
                '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(),
                '_file_name': item['file_name'],
            })
            current_new_offset += new_size

        console.print(f'[white]✔ Encoded {len(new_injected_entries)} file(s)[/white]')

        new_entries = []
        entry_to_path = {}
        for dir_path, files in self._index.items():
            for fname, entry in files.items():
                entry_to_path[id(entry)] = (dir_path, fname)
        for i, entry in enumerate(self._files):
            dir_path, fname = entry_to_path.get(id(entry), (PurePath(), f'unknown_{i}'))
            new_entries.append({
                'content_hash': entry.content_hash,
                'offset': entry.offset,
                'uncompressed_size': entry.uncompressed_size,
                'size': entry.size,
                'comp_method': entry.compression_method,
                'enc_method': entry.encryption_method if entry.encrypted else 0,
                'encrypted': entry.encrypted,
                'block_size_val': entry.compression_block_size,
                'compressed_blocks': [(b.start, b.end) for b in entry.compressed_blocks],
                'unk1': entry.unk1, 'unk2': entry.unk2,
                'index_new_sep': entry.index_new_sep,
            })
        new_entries.extend(new_injected_entries)

        if add_signature_marker:
            marker_already_present = False
            for dp, files_dict in self._index.items():
                if dp.name in ('ALVSIA', bytes.fromhex('48525f4448414d41').decode()) and 'PATCHED.txt' in files_dict:
                    marker_already_present = True
                    break
            if not marker_already_present:
                empty_hash = SHA1.new(b'').digest()
                new_entries.append({
                    'content_hash': empty_hash,
                    'offset': current_new_offset,
                    'uncompressed_size': 0,
                    'size': 0,
                    'comp_method': CM_NONE,
                    'enc_method': 0,
                    'encrypted': False,
                    'block_size_val': 0,
                    'compressed_blocks': [],
                    'unk1': 0,
                    'unk2': b'\x00' * 20,
                    'index_new_sep': 0,
                    '_dir_path': PurePath('ALVSIA'),
                    '_file_name': 'PATCHED.txt',
                })

        index_data = bytearray()
        raw_orig_index = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        orig_index_decoded = PakCrypto.decrypt_index(bytes(raw_orig_index), self._pak_info)
        orig_reader = Reader(orig_index_decoded)
        orig_mount_len = orig_reader.i4()
        orig_mount_bytes = bytes(orig_reader.s(orig_mount_len))
        index_data.extend(struct.pack('<I', orig_mount_len))
        index_data.extend(orig_mount_bytes)
        index_data.extend(struct.pack('<I', len(new_entries)))

        for item in new_entries:
            index_data.extend(item['content_hash'])
            if version <= 1: index_data.extend(struct.pack('<Q', 0))
            index_data.extend(struct.pack('<Q', item['offset']))
            index_data.extend(struct.pack('<Q', item['uncompressed_size']))
            index_data.extend(struct.pack('<I', item['comp_method'] & CM_MASK))
            index_data.extend(struct.pack('<Q', item['size']))
            if version >= 5:
                index_data.extend(struct.pack('<B', item['unk1']))
                index_data.extend(item['unk2'] if item['unk2'] else b'\x00' * 20)
            if item['comp_method'] != CM_NONE and version >= 3:
                index_data.extend(struct.pack('<I', len(item['compressed_blocks'])))
                for (start, end) in item['compressed_blocks']:
                    index_data.extend(struct.pack('<Q', start))
                    index_data.extend(struct.pack('<Q', end))
            if version >= 4:
                index_data.extend(struct.pack('<I', item['block_size_val']))
                index_data.extend(struct.pack('<B', 1 if item['encrypted'] else 0))
            if version >= 12:
                index_data.extend(struct.pack('<I', item['enc_method']))
                index_data.extend(struct.pack('<I', item['index_new_sep']))

        file_to_dirname = {}
        for dir_path, files_dict in self._index.items():
            dir_str = dir_path.as_posix()
            for fname, entry in files_dict.items():
                for i, fe in enumerate(self._files):
                    if id(fe) == id(entry):
                        file_to_dirname[i] = (dir_str, fname)
                        break
        for i, item in enumerate(new_entries):
            if i not in file_to_dirname:
                if '_dir_path' in item:
                    file_to_dirname[i] = (item['_dir_path'].as_posix(), item['_file_name'])
                else:
                    file_to_dirname[i] = ('', f'file_{i}')

        all_dirs = []
        dir_to_files = {}
        for dir_path in self._index.keys():
            ds = dir_path.as_posix()
            all_dirs.append(ds)
            dir_to_files[ds] = []
        for i, item in enumerate(new_entries):
            ds, fn = file_to_dirname[i]
            if ds not in dir_to_files:
                dir_to_files[ds] = []
                all_dirs.append(ds)
            dir_to_files[ds].append((fn, i))

        index_data.extend(struct.pack('<Q', len(all_dirs)))
        for dir_str in all_dirs:
            files_list = dir_to_files[dir_str]
            if not dir_str or dir_str == '.':
                index_data.extend(struct.pack('<I', 0))
            else:
                if not dir_str.endswith('/'): dir_str_with_slash = dir_str + '/'
                else: dir_str_with_slash = dir_str
                dir_bytes = dir_str_with_slash.encode('utf-8') + b'\x00'
                index_data.extend(struct.pack('<I', len(dir_bytes)))
                index_data.extend(dir_bytes)
            index_data.extend(struct.pack('<Q', len(files_list)))
            for file_name, fi in files_list:
                name_bytes = file_name.encode('utf-8') + b'\x00'
                index_data.extend(struct.pack('<I', len(name_bytes)))
                index_data.extend(name_bytes)
                index_data.extend(struct.pack('<i', -fi - 1))
        index_data.extend(b'\x1d\x00\x00\x00\x2e\x2e')

        index_hash = SHA1.new(bytes(index_data)).digest()

        if version > 7 and self._pak_info.index_encrypted:
            key = PakCrypto.rsa_extract(self._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(self._pak_info.packed_iv, RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            padded = pad(bytes(index_data), AES.block_size)
            aes = AES.new(key, MODE_CBC, iv[:16])
            encrypted_index = aes.encrypt(padded)
        elif self._pak_info.index_encrypted:
            encrypted_index = bytes(b ^ SIMPLE1_DECRYPT_KEY for b in bytes(index_data))
        else:
            encrypted_index = bytes(index_data)

        index_size = len(encrypted_index)
        new_index_offset = orig_index_offset + len(new_data_region)

        encrypted_magic = PAK_MAGIC ^ keystream[2]
        key_stream_hash = struct.pack('<5I', *keystream[4:][:5])
        encrypted_index_hash = bytes(a ^ b for a, b in zip(index_hash, key_stream_hash))
        encrypted_index_size = index_size ^ ((keystream[10] << 32) | keystream[11])
        encrypted_index_offset = new_index_offset ^ ((keystream[0] << 32) | keystream[1])
        encrypted_flag_byte = (1 if self._pak_info.index_encrypted else 0) ^ (keystream[3] & 0xFF)

        orig_data_region = bytearray(self._file_content[0:orig_index_offset])
        output_pak.parent.mkdir(parents=True, exist_ok=True)
        with open(output_pak, 'wb') as f:
            f.write(bytes(orig_data_region))
            f.write(bytes(new_data_region))
            f.write(encrypted_index)
            if version >= 7:
                key_unk1 = struct.pack('<8I', *keystream[7:][:8])
                unk1_plain = self._pak_info.unk1 if self._pak_info.unk1 else b'\x00' * 32
                encrypted_unk1 = bytes(a ^ b for a, b in zip(unk1_plain, key_unk1))
                f.write(encrypted_unk1)
            if version >= 8:
                f.write(self._pak_info.packed_key if self._pak_info.packed_key else b'\x00' * 256)
                f.write(self._pak_info.packed_iv if self._pak_info.packed_iv else b'\x00' * 256)
                f.write(self._pak_info.packed_index_hash if self._pak_info.packed_index_hash else b'\x00' * 256)
            if version >= 9:
                f.write(struct.pack('<I', (self._pak_info.stem_hash or 0) ^ keystream[8]))
                f.write(struct.pack('<I', (self._pak_info.unk2 or 0) ^ keystream[9]))
            if version >= 12:
                f.write(self._pak_info.content_org_hash if self._pak_info.content_org_hash else b'\x00' * 20)
            f.write(struct.pack('<B', encrypted_flag_byte))
            f.write(struct.pack('<I', encrypted_magic))
            f.write(struct.pack('<I', version))
            if version >= 6:
                f.write(encrypted_index_hash)
            else:
                f.write(b'\x00' * 20)
            f.write(struct.pack('<Q', encrypted_index_size))
            f.write(struct.pack('<Q', encrypted_index_offset))

        console.print(Panel(
            f'[bold white]🎉 INJECT COMPLETE![/bold white]\n\n'
            f'[white]Output  :[/] [white]{output_pak.name}[/white]',
            title='✅ SUCCESS', border_style=get_border_style(2, 0.55), padding=(1, 2)
        ))
    
    def _get_method_str(self, method_int, is_encryption):
        if is_encryption:
            if PakCrypto._is_simple1_method(method_int): return "SIMPLE1"
            if PakCrypto._is_simple2_method(method_int): return "SIMPLE2"
            if PakCrypto._is_sm4_method(method_int): return f"SM4 (Type {method_int})"
            return "NONE" if method_int == 0 else "UNKNOWN"
        else:
            if method_int == CM_NONE: return "NONE"
            if method_int == CM_ZLIB: return "ZLIB"
            if method_int == CM_ZSTD: return "ZSTD"
            if method_int == CM_ZSTD_DICT: return "ZSTD_DICT"
            return "UNKNOWN"
    
    def _verify_stem_hash(self) -> None:
        if not self._is_od and self._pak_info.version >= 9:
            expected = zlib.crc32(self._file_path.stem.encode('utf-32le'))
            if self._pak_info.stem_hash != expected:
                console.print('[white]Stem hash mismatch (file may be renamed)[/white]')
    def _tencent_load_index(self) -> None:
        index_data = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        if self._pak_info.index_encrypted:
            try:
                index_data = PakCrypto.decrypt_index(index_data, self._pak_info)
            except Exception:
                console.print('[white]Index decryption failed, trying raw[/white]')
        self._verify_index_hash(index_data)
        self._load_index(index_data)
    def _verify_index_hash(self, index_data) -> None:
        expected_hash = self._pak_info.index_hash
        if not self._is_od and self._pak_info.version >= 8:
            try:
                rsa_hash = PakCrypto.rsa_extract(self._pak_info.packed_index_hash, RSA_MOD_2)
                if expected_hash != rsa_hash:
                    console.print('[white]SECURE VIP CONNECTION[/white]')
            except:
                pass
        actual = SHA1.new(index_data).digest()
        if expected_hash != actual:
            console.print('[white]Index hash mismatch (PAK modified?)[/white]')
    @staticmethod
    def _construct_mount_point(mount_point: str) -> PurePath:
        result = PurePath()
        for part in PurePath(mount_point).parts:
            if part!= '..':
                result /= part
        return result
    def _peek_content(self, offset: int, size: int, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(size, encryption_method)
        end = min(offset + size, len(self._file_content))
        return self._file_content[offset:end]
    def _peek_block_content(self, block: PakCompressedBlock, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(block.end - block.start, encryption_method)
        end = min(block.start + size, len(self._file_content))
        return self._file_content[block.start:end]
    def _construct_zstd_dict(self, dict_entry: TencentPakEntry) -> None:
        assert not self._zstd_dict
        assert not dict_entry.encrypted
        assert dict_entry.compression_method == CM_NONE
        reader = Reader(self._peek_content(dict_entry.offset, dict_entry.size, 0))
        dict_size = reader.u8()
        _ = reader.u4()
        assert dict_size == reader.u4()
        dict_data = reader.s(dict_size)
        self._zstd_dict = PakCompression.zstd_dictionary(dict_data)
    def _load_index(self, index_data) -> None:
        if self._pak_info.version <= 10:
            raise ValueError(f'Unsupported version: {self._pak_info.version}')
        else:
            reader = Reader(index_data)
            self._mount_point = self._construct_mount_point(reader.string())
            num_files = reader.u4()
            self._files = []
            for _ in range(num_files):
                self._files.append(TencentPakEntry(reader, self._pak_info.version))
            num_dirs = reader.u8()
            for _ in range(num_dirs):
                dir_path = PurePath(reader.string())
                num_entries = reader.u8()
                dir_content = {}
                for _ in range(num_entries):
                    entry_name = reader.string()
                    idx = reader.i4()
                    if idx < 0:
                        entry_idx = ~idx
                        if 0 <= entry_idx < len(self._files):
                            dir_content[entry_name] = self._files[entry_idx]
                if self._is_zstd_with_dict and dir_path.name == 'zstddic':
                    if len(dir_content) == 1:
                        self._construct_zstd_dict(list(dir_content.values())[0])
                else:
                    if dir_content:
                        self._index[dir_path] = dir_content
    
    def _write_to_disk(self, file_path: Path, entry: TencentPakEntry) -> None:
        encryption_method = entry.encryption_method
        compression_method = entry.compression_method
        total_blocks = len(entry.compressed_blocks)

        if compression_method == CM_NONE:
            data = self._peek_content(entry.offset, entry.size, encryption_method)
            if entry.encrypted:
                data = PakCrypto.decrypt_block(data, file_path, encryption_method)
            with open(file_path, 'wb') as f:
                f.write(data)
            return

        with open(file_path, 'wb') as f:
            for idx in PakCrypto.generate_block_indices(total_blocks, encryption_method):
                if idx >= len(entry.compressed_blocks):
                    continue
                block = entry.compressed_blocks[idx]
                data = self._peek_block_content(block, encryption_method)
                if entry.encrypted:
                    try:
                        data = PakCrypto.decrypt_block(data, file_path, encryption_method)
                    except:
                        pass
                try:
                    decompressed = PakCompression.decompress_block(data, self._zstd_dict, compression_method)
                except:
                    decompressed = data
                f.write(decompressed)
    
    def dump(self, out_path: Path) -> None:
        mp_parts = [_sanitize_part(p) for p in self._mount_point.parts]
        out_path = out_path.joinpath(*mp_parts) if mp_parts else out_path
        out_path.mkdir(parents=True, exist_ok=True)
        total_files = sum(len(d) for d in self._index.values())
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[white][UNPACK][/] {task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            task = progress.add_task("Extracting files...", total=total_files)
            for dir_path, dir_content in self._index.items():
                dp_parts = [_sanitize_part(p) for p in dir_path.parts]
                current_out_path = out_path.joinpath(*dp_parts) if dp_parts else out_path
                current_out_path.mkdir(parents=True, exist_ok=True)
                for file_name, entry in dir_content.items():
                    safe_name = _sanitize_part(file_name)
                    try:
                        self._write_to_disk(current_out_path / safe_name, entry)
                    except Exception as e:
                        console.print(f'[white]  Skipped {safe_name}: {e}[/white]')
                    progress.update(task, advance=1)

    def inject_files_inplace(self, inject_plan: list, output_pak: Path) -> None:
        """
        ANTI-CHEAT SAFE INJECT:
        - Original data region byte-for-byte preserve
        - Sirf naya data append
        - Original footer ke sirf last 36 bytes patch
        - Original unk2 preserve (anti-cheat critical!)
        - PAK ka size minimum change
        """
        if not inject_plan:
            raise ValueError('inject_plan is empty')

        console.print(Panel(
            f'[bold white]💉 SAFE IN-PLACE INJECT[/bold white]\n'
            f'[white]Source:[/] [white]{self._file_path.name}[/white]\n'
            f'[white]Output:[/] [white]{output_pak.name}[/white]',
            title='INJECT MODE', border_style=get_border_style(1, 0.55), padding=(0, 2)
        ))

        # STEP 1: Load inject files
        work_items = []
        for item in inject_plan:
            if item.get('plain_bytes') is not None:
                plain = item['plain_bytes']
            elif item.get('src_path') is not None:
                try: plain = Path(item['src_path']).read_bytes()
                except Exception as e:
                    console.print(f'   [white]✗ Cannot read: {e}[/white]')
                    continue
            else:
                continue

            internal = item['internal_path'].replace('\\', '/').lstrip('/')
            parts = internal.rsplit('/', 1)
            dir_str = parts[0] if len(parts) == 2 else ''
            file_name = parts[1] if len(parts) == 2 else parts[0]

            work_items.append({
                'dir_str': dir_str, 'file_name': file_name,
                'internal_path': internal, 'plain': plain,
                'comp_method': item['comp_method'], 'enc_method': item['enc_method'],
                'encrypted': bool(item['encrypted']), 'block_size': item['block_size'],
            })
            console.print(f'   [white]✨[/] {internal} [dim]({len(plain):,} B)[/dim]')

        # STEP 2: Capture original structure
        keystream = PakCrypto.zuc_keystream()
        version = self._pak_info.version
        footer_size = TencentPakInfo._mem_size(version)
        
        orig_index_offset = self._pak_info.index_offset
        orig_index_size = self._pak_info.index_size
        
        # ⚠️ CRITICAL: Data region byte-for-byte preserve
        orig_data_region = bytes(self._file_content[0:orig_index_offset])
        orig_index_bytes = bytes(self._file_content[orig_index_offset:orig_index_offset + orig_index_size])
        orig_footer = bytes(self._file_content[orig_index_offset + orig_index_size:])
        
        console.print(f'[dim]   Data region : {len(orig_data_region):,} B[/dim]')
        console.print(f'[dim]   Index region: {len(orig_index_bytes):,} B[/dim]')
        console.print(f'[dim]   Footer      : {len(orig_footer):,} B (v{version})[/dim]')

        # STEP 3: Encode new files
        new_data_region = bytearray()
        current_offset = orig_index_offset  # right after orig data region
        new_entries_data = []
        
        for item in work_items:
            plain = item['plain']
            comp_method = item['comp_method']
            enc_method = item['enc_method']
            encrypted = item['encrypted']
            block_size_val = item['block_size']
            file_path_for_crypto = PurePath(item['file_name'])

            if comp_method == CM_NONE:
                if encrypted:
                    aligned_size = PakCrypto.align_encrypted_content_size(len(plain), enc_method)
                    padded = plain + b'\x00' * (aligned_size - len(plain))
                    stored_data = _encrypt_plaintext(padded, file_path_for_crypto, enc_method)
                else:
                    stored_data = plain
                new_size = len(stored_data)
                new_compressed_blocks = []
            else:
                chunks = [plain[i:i+block_size_val] for i in range(0, len(plain), block_size_val)]
                if not chunks: chunks = [b'']
                compressed_chunks = []
                for chunk in chunks:
                    comp = _best_compress(chunk, comp_method, self._zstd_dict)
                    compressed_chunks.append(comp)
                encrypted_chunks = []
                for comp_data in compressed_chunks:
                    if encrypted:
                        comp_data = _encrypt_plaintext(comp_data, file_path_for_crypto, enc_method)
                    encrypted_chunks.append(comp_data)
                n_blocks = len(encrypted_chunks)
                indices = PakCrypto.generate_block_indices(n_blocks, enc_method)
                physical_blocks = [None] * n_blocks
                for j, chunk_data in enumerate(encrypted_chunks):
                    physical_blocks[indices[j]] = chunk_data
                physical_offsets = []
                block_cursor = current_offset
                for phys_block in physical_blocks:
                    physical_offsets.append((block_cursor, block_cursor + len(phys_block)))
                    block_cursor += len(phys_block)
                new_compressed_blocks = physical_offsets
                stored_data = b''.join(physical_blocks)
                new_size = len(stored_data)

            new_content_hash = SHA1.new(stored_data).digest()
            new_data_region.extend(stored_data)

            new_entries_data.append({
                'content_hash': new_content_hash,
                'offset': current_offset,
                'uncompressed_size': len(plain),
                'size': new_size,
                'comp_method': comp_method,
                'enc_method': enc_method if encrypted else 0,
                'encrypted': encrypted,
                'block_size_val': block_size_val,
                'compressed_blocks': new_compressed_blocks,
                'unk1': 0, 'unk2': b'\x00' * 20, 'index_new_sep': 0,
                '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(),
                '_file_name': item['file_name'],
            })
            current_offset += new_size

        # STEP 4: Rebuild index
        orig_index_decoded = PakCrypto.decrypt_index(orig_index_bytes, self._pak_info)
        orig_reader = Reader(orig_index_decoded)
        orig_mount_len = orig_reader.i4()
        orig_mount_bytes = bytes(orig_reader.s(orig_mount_len))
        num_orig_files = orig_reader.u4()
        
        orig_entries = []
        for _ in range(num_orig_files):
            e = TencentPakEntry(orig_reader, version)
            orig_entries.append(e)
        
        # ⚠️ CRITICAL: Original unk2 preserve karo
        all_entries = []
        for e in orig_entries:
            all_entries.append({
                'content_hash': e.content_hash,
                'offset': e.offset,
                'uncompressed_size': e.uncompressed_size,
                'size': e.size,
                'comp_method': e.compression_method,
                'enc_method': e.encryption_method if e.encrypted else 0,
                'encrypted': e.encrypted,
                'block_size_val': e.compression_block_size,
                'compressed_blocks': [(b.start, b.end) for b in e.compressed_blocks],
                'unk1': e.unk1, 
                'unk2': e.unk2,  # ⭐ ORIGINAL PRESERVE
                'index_new_sep': e.index_new_sep,
            })
        all_entries.extend(new_entries_data)

        # Build index binary
        index_data = bytearray()
        index_data.extend(struct.pack('<I', orig_mount_len))
        index_data.extend(orig_mount_bytes)
        index_data.extend(struct.pack('<I', len(all_entries)))

        for item in all_entries:
            index_data.extend(item['content_hash'])
            if version <= 1: index_data.extend(struct.pack('<Q', 0))
            index_data.extend(struct.pack('<Q', item['offset']))
            index_data.extend(struct.pack('<Q', item['uncompressed_size']))
            index_data.extend(struct.pack('<I', item['comp_method'] & CM_MASK))
            index_data.extend(struct.pack('<Q', item['size']))
            if version >= 5:
                index_data.extend(struct.pack('<B', item['unk1']))
                index_data.extend(item['unk2'] if item['unk2'] else b'\x00' * 20)
            if item['comp_method'] != CM_NONE and version >= 3:
                index_data.extend(struct.pack('<I', len(item['compressed_blocks'])))
                for (start, end) in item['compressed_blocks']:
                    index_data.extend(struct.pack('<Q', start))
                    index_data.extend(struct.pack('<Q', end))
            if version >= 4:
                index_data.extend(struct.pack('<I', item['block_size_val']))
                index_data.extend(struct.pack('<B', 1 if item['encrypted'] else 0))
            if version >= 12:
                index_data.extend(struct.pack('<I', item['enc_method']))
                index_data.extend(struct.pack('<I', item['index_new_sep']))

        # Directory structure
        file_to_dirname = {}
        for dir_path, files_dict in self._index.items():
            dir_str = dir_path.as_posix()
            for fname, entry in files_dict.items():
                for i, fe in enumerate(self._files):
                    if id(fe) == id(entry):
                        file_to_dirname[i] = (dir_str, fname)
                        break
        for i, item in enumerate(all_entries):
            if i not in file_to_dirname:
                if '_dir_path' in item:
                    file_to_dirname[i] = (item['_dir_path'].as_posix(), item['_file_name'])
                else:
                    file_to_dirname[i] = ('', f'file_{i}')

        all_dirs = []
        dir_to_files = {}
        for dir_path in self._index.keys():
            ds = dir_path.as_posix()
            if ds not in dir_to_files:
                all_dirs.append(ds)
                dir_to_files[ds] = []
        for i, item in enumerate(all_entries):
            ds, fn = file_to_dirname[i]
            if ds not in dir_to_files:
                dir_to_files[ds] = []
                all_dirs.append(ds)
            dir_to_files[ds].append((fn, i))

        index_data.extend(struct.pack('<Q', len(all_dirs)))
        for dir_str in all_dirs:
            files_list = dir_to_files[dir_str]
            if not dir_str or dir_str == '.':
                index_data.extend(struct.pack('<I', 0))
            else:
                if not dir_str.endswith('/'): dir_str_with_slash = dir_str + '/'
                else: dir_str_with_slash = dir_str
                dir_bytes = dir_str_with_slash.encode('utf-8') + b'\x00'
                index_data.extend(struct.pack('<I', len(dir_bytes)))
                index_data.extend(dir_bytes)
            index_data.extend(struct.pack('<Q', len(files_list)))
            for file_name, fi in files_list:
                name_bytes = file_name.encode('utf-8') + b'\x00'
                index_data.extend(struct.pack('<I', len(name_bytes)))
                index_data.extend(name_bytes)
                index_data.extend(struct.pack('<i', -fi - 1))
        index_data.extend(b'\x1d\x00\x00\x00\x2e\x2e')

        index_hash = SHA1.new(bytes(index_data)).digest()

        # Encrypt index
        if version > 7 and self._pak_info.index_encrypted:
            key = PakCrypto.rsa_extract(self._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(self._pak_info.packed_iv, RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            padded = pad(bytes(index_data), AES.block_size)
            aes = AES.new(key, MODE_CBC, iv[:16])
            encrypted_index = aes.encrypt(padded)
        elif self._pak_info.index_encrypted:
            encrypted_index = bytes(b ^ SIMPLE1_DECRYPT_KEY for b in bytes(index_data))
        else:
            encrypted_index = bytes(index_data)

        index_size = len(encrypted_index)
        new_index_offset = orig_index_offset + len(new_data_region)

        # STEP 5: Write output
        output_pak.parent.mkdir(parents=True, exist_ok=True)
        with open(output_pak, 'wb') as f:
            f.write(orig_data_region)
            f.write(bytes(new_data_region))
            f.write(encrypted_index)
            # Footer: original copy, sirf last 36 bytes patch
            new_footer = bytearray(orig_footer)
            h_key = struct.pack('<5I', *keystream[4:9])
            new_footer[-36:-16] = bytes(a ^ b for a, b in zip(index_hash, h_key))
            new_footer[-16:-8] = ((index_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little'))
            new_footer[-8:] = ((new_index_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little'))
            f.write(bytes(new_footer))

        # VERIFY
        console.print('\n[bold white]🔍 VERIFYING OUTPUT PAK...[/bold white]')
        try:
            with open(output_pak, 'rb') as fv:
                new_bytes = fv.read()
            orig_size = len(self._file_content)
            new_size_actual = len(new_bytes)
            console.print(f'[dim]   Original: {orig_size:,} B[/dim]')
            console.print(f'[dim]   New     : {new_size_actual:,} B[/dim]')
            console.print(f'[dim]   Diff    : {new_size_actual - orig_size:+,} B[/dim]')
            
            if new_bytes[:33] == bytes(self._file_content[:33]):
                console.print('[bold white]   ✅ HEADER MATCH![/bold white]')
            else:
                console.print('[bold white]   ❌ HEADER MISMATCH![/bold white]')
            
            orig_footer_check = bytes(self._file_content[-footer_size:])
            new_footer_check = new_bytes[-footer_size:]
            if orig_footer_check[:-36] == new_footer_check[:-36]:
                console.print(f'[bold white]   ✅ FOOTER (first {footer_size-36} B) MATCH![/bold white]')
            else:
                console.print('[bold white]   ❌ FOOTER MISMATCH![/bold white]')
            
            try:
                test_pak = TencentPakFile(output_pak, is_od=True)
                console.print(f'[bold white]   ✅ OUTPUT LOADS! Files: {len(test_pak._files)}[/bold white]')
            except Exception as ve:
                console.print(f'[bold white]   ❌ LOAD FAILED: {ve}[/bold white]')
        except Exception as ve:
            console.print(f'[white]   ⚠️ Verify skipped: {ve}[/white]')

        console.print(Panel(
            f'[bold white]🎉 SAFE INJECT COMPLETE![/bold white]\n\n'
            f'[white]Output:[/] [white]{output_pak.name}[/white]\n'
            f'[white]Files :[/] [white]{len(new_entries_data)} injected[/white]',
            title='✅ SUCCESS', border_style=get_border_style(2, 0.55), padding=(1, 2)
        ))
    
    def __del__(self):
        if hasattr(self, '_file_handle'):
            try:
                self._file_handle.close()
            except:
                pass

_INVALID_FN_CHARS = re.compile(r'[\x00-\x1f<>:"/\\|?*\x7f]')

def _sanitize_part(name) -> str:
    if name is None:
        return '_'
    s = str(name)
    s = s.replace('\x00', '')
    s = _INVALID_FN_CHARS.sub('', s)
    s = s.rstrip('. ')
    if not s or s in ('.', '..'):
        s = '_'
    return s

def _encrypt_plaintext(plaintext: bytes, pak_relative_path: PurePath, encryption_method: int) -> bytes:
    if PakCrypto._is_simple1_method(encryption_method):
        return bytes((b ^ SIMPLE1_DECRYPT_KEY for b in plaintext))
    else:
        if PakCrypto._is_simple2_method(encryption_method):
            pad = -len(plaintext) % SIMPLE2_BLOCK_SIZE
            plaintext += b'\x00' * pad
            key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
            rolling = key
            out = []
            for x, in struct.iter_unpack('<I', plaintext):
                c = rolling ^ x
                out.append(c)
                rolling ^= c
            return struct.pack(f'<{len(out)}I', *out)
        else:
            if PakCrypto._is_sm4_method(encryption_method):
                key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)
                sm4 = PakCrypto._sm4_context_for_key(key)
                pad_len = -len(plaintext) % 16
                if pad_len > 0:
                    plaintext = plaintext + b'\x00' * pad_len
                out = bytearray()
                for i in range(0, len(plaintext), 16):
                    block = plaintext[i:i + 16]
                    if len(block) < 16:
                        block = block.ljust(16, b'\x00')
                    out.extend(sm4.encrypt(block))
                return bytes(out)
            else:
                return plaintext

def _best_compress(chunk, cm, zstd_dict=None):
    if cm == CM_ZLIB:
        return zlib.compress(chunk, 9)
    if cm in (CM_ZSTD, CM_ZSTD_DICT):
        zd = zstd_dict if cm == CM_ZSTD_DICT else None
        for lvl in [22, 19, 16, 13, 10, 7, 4, 1]:
            try:
                return ZstdCompressor(level=lvl, dict_data=zd, threads=1).compress(chunk)
            except Exception:
                continue
    return chunk

def _block_permutation(n_chunks: int, encryption_method: int):
    return PakCrypto.generate_block_indices(n_chunks, encryption_method)

def _pw_string(s):
    if not s: return struct.pack('<i', 0)
    b = s.encode('utf-8') + b'\x00'
    return struct.pack('<i', len(b)) + b

def _pw_entry(e, v):
    w = bytearray(e.content_hash)
    w += struct.pack('<Q', e.offset)
    w += struct.pack('<Q', e.uncompressed_size)
    w += struct.pack('<I', e.compression_method)
    w += struct.pack('<Q', e.size)
    if v >= 5:
        w += bytes([e.unk1])
        w += e.unk2
    if e.compression_method != CM_NONE and v >= 3:
        w += struct.pack('<I', len(e.compressed_blocks))
        for b in e.compressed_blocks:
            w += struct.pack('<QQ', b.start, b.end)
    if v >= 4:
        w += struct.pack('<I', e.compression_block_size)
        w += bytes([1 if e.encrypted else 0])
    if v >= 12:
        w += struct.pack('<II', e.encryption_method, e.index_new_sep)
    return bytes(w)

def _get_all_dirs_and_mp(pak_file):
    raw = bytes(pak_file._file_content[
        pak_file._pak_info.index_offset:][:pak_file._pak_info.index_size])
    if pak_file._pak_info.index_encrypted:
        try:
            raw = PakCrypto.decrypt_index(raw, pak_file._pak_info)
        except:
            pass
    r = Reader(raw)
    mp = r.string()
    num_files = r.u4()
    for _ in range(num_files):
        TencentPakEntry(r, pak_file._pak_info.version)
    dirs = {}
    for _ in range(r.u8()):
        dp = r.string()
        cnt = r.u8()
        d = {}
        for _ in range(cnt):
            fname = r.string()
            idx = ~r.i4()
            if 0 <= idx < len(pak_file._files):
                d[fname] = (idx, pak_file._files[idx])
        dirs[dp] = d
    return mp, dirs

def repack_pak_file_full(pak_file, edited_root, output_path, target_path=None, force_add=False, path_map=None):
    import copy as _cp
    edit_files = [p for p in Path(edited_root).rglob('*') if p.is_file()]
    if not edit_files:
        console.print('[white]No files in EDIT folder.[/]')
        return 0
    version = pak_file._pak_info.version
    keystream = PakCrypto.zuc_keystream()
    orig_fc = pak_file._file_content
    mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)

    def _norm_dir(tp):
        if not tp:
            return None
        tp = tp.replace('\\', '/')
        matched_dir = None
        for existing_dir in all_dirs.keys():
            if existing_dir.strip('/').lower() == tp.strip('/').lower():
                matched_dir = existing_dir
                break
        return matched_dir if matched_dir else (tp.strip('/') + '/')

    if target_path:
        target_path = _norm_dir(target_path)
    norm_path_map = {}
    if path_map:
        for _name, _tp in path_map.items():
            norm_path_map[_name] = _norm_dir(_tp)

    pak_name_map = {}
    for dp_str, dir_files in all_dirs.items():
        for name, (slot, entry) in dir_files.items():
            full_path = str(PurePath(dp_str) / name).replace('\\', '/')
            pak_name_map.setdefault(name.lower(), []).append((full_path, slot, entry))

    edited = {}
    for p in edit_files:
        fl = p.name.lower()
        found_match = False
        if path_map is not None:
            tp = norm_path_map.get(p.name)
        else:
            tp = target_path

        if not found_match:
            rel_path = p.relative_to(edited_root).as_posix()
            mp_norm = mp_str.strip('/')
            if mp_norm and rel_path.startswith(mp_norm + '/'):
                rel_path = rel_path[len(mp_norm) + 1:]
            for dp_str, dir_files in all_dirs.items():
                for name, (slot, entry) in dir_files.items():
                    full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                    if full_path == rel_path or full_path.endswith('/' + rel_path) or rel_path.endswith('/' + name):
                        edited[full_path] = (p, slot, entry, False)
                        found_match = True
                        break
                if found_match:
                    break

        if fl in pak_name_map:
            cands = pak_name_map[fl]
            if tp:
                target_cands = [(fp, s, e) for fp, s, e in cands if tp.strip('/') in fp]
                if target_cands:
                    sz = p.stat().st_size
                    sm = [(fp, s, e) for fp, s, e in target_cands if e.uncompressed_size == sz]
                    fp, s, e = sm[0] if sm else target_cands[0]
                    edited[fp] = (p, s, e, False)
                    found_match = True
            if not found_match:
                sz = p.stat().st_size
                sm = [(fp, s, e) for fp, s, e in cands if e.uncompressed_size == sz]
                if sm:
                    fp, s, e = sm[0]
                else:
                    fp, s, e = cands[0]
                if tp and force_add:
                    new_fp = f"{tp.rstrip('/')}/{p.name}"
                    edited[new_fp] = (p, s, e, True)
                else:
                    edited[fp] = (p, s, e, False)
                found_match = True

        if not found_match:
            stem = p.stem.lower()
            ext = p.suffix.lower()
            for dp_str, dir_files in all_dirs.items():
                for name, (slot, entry) in dir_files.items():
                    if Path(name).stem.lower() == stem and Path(name).suffix.lower() == ext:
                        full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                        if tp and force_add:
                            new_fp = f"{tp.rstrip('/')}/{p.name}"
                            edited[new_fp] = (p, slot, entry, True)
                        else:
                            edited[full_path] = (p, slot, entry, False)
                        found_match = True
                        break
                if found_match:
                    break

        if not found_match and force_add:
            template_entry = None
            for dp_str, dir_files in all_dirs.items():
                for _n, (_s, e) in dir_files.items():
                    if Path(_n).suffix.lower() == p.suffix.lower():
                        template_entry = e
                        break
                if template_entry:
                    break
            if not template_entry:
                for dp_str, dir_files in all_dirs.items():
                    for _n, (_s, e) in dir_files.items():
                        template_entry = e
                        break
                    if template_entry:
                        break
            rel_path = p.relative_to(edited_root).as_posix()
            mp_norm = mp_str.strip('/')
            if mp_norm and rel_path.startswith(mp_norm + '/'):
                rel_path = rel_path[len(mp_norm) + 1:]
            if tp:
                new_fp = f"{tp.rstrip('/')}/{p.name}"
            else:
                new_fp = rel_path
            if template_entry:
                edited[new_fp] = (p, -1, template_entry, True)
                found_match = True
            else:
                console.print(f'[white]~ Skipped (no entry in PAK): {p.name}[/]')

    if not edited:
        console.print('[white]No files to repack![/]')
        return 0

    slot_to_new = {}
    for i, e in enumerate(pak_file._files):
        ne = _cp.copy(e)
        ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]
        slot_to_new[i] = ne

    import tempfile as _tmpfile
    _tmpfd, _tmppath = _tmpfile.mkstemp(suffix='.pak')
    _outf = open(_tmpfd, 'r+b')
    _pos = [0]

    file_rows = []
    new_added = []
    processed_count = 0
    total_to_process = sum(len(files) for files in all_dirs.values())

    def _out_append(data: bytes):
        start = _pos[0]
        _outf.write(data)
        _pos[0] += len(data)
        return start

    def _out_len() -> int:
        return _pos[0]

    for dp_str, dir_files in list(all_dirs.items()):
        for name, (slot, old_entry) in list(dir_files.items()):
            full_path = str(PurePath(dp_str) / name).replace('\\', '/')
            ne = slot_to_new[slot]
            em = old_entry.encryption_method
            cm = old_entry.compression_method

            if full_path in edited:
                p, _s, template, is_new = edited[full_path]
                new_raw = p.read_bytes()
                pak_rel = PurePath(full_path)

                ne.uncompressed_size = len(new_raw)
                ne.compression_method = cm
                ne.encryption_method = em
                ne.encrypted = old_entry.encrypted
                ne.unk1 = old_entry.unk1
                ne.index_new_sep = old_entry.index_new_sep

                if is_new and (target_path or path_map):
                    full_path_str = mp_str + full_path
                    ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
                else:
                    ne.unk2 = old_entry.unk2

                stored_start = _out_len()
                if cm == CM_NONE:
                    cipher = (_encrypt_plaintext(new_raw, pak_rel, em) if ne.encrypted else new_raw)
                    ne.offset = _out_len()
                    ne.size = len(new_raw)
                    _out_append(cipher)
                else:
                    cs = (old_entry.compression_block_size if old_entry.compression_block_size > 0 else 65536)
                    chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                    order = _block_permutation(len(chunks), em)
                    cipher_by_logical = []
                    for chunk in chunks:
                        compressed = _best_compress(chunk, cm, pak_file._zstd_dict)
                        cipher = (_encrypt_plaintext(compressed, pak_rel, em) if ne.encrypted else compressed)
                        cipher_by_logical.append(cipher)
                    inv = [0] * len(chunks)
                    for logical_i, phys_i in enumerate(order):
                        inv[phys_i] = logical_i
                    new_blks = [None] * len(chunks)
                    for phys_i in range(len(chunks)):
                        blk = PakCompressedBlock.__new__(PakCompressedBlock)
                        blk.start = _out_len()
                        _out_append(cipher_by_logical[inv[phys_i]])
                        blk.end = _out_len()
                        new_blks[phys_i] = blk
                    ne.compressed_blocks = new_blks
                    ne.offset = new_blks[0].start if new_blks else _out_len()
                    ne.size = sum(b.end - b.start for b in new_blks)

                _outf.seek(stored_start)
                stored_bytes = _outf.read(ne.size)
                _outf.seek(0, 2)
                ne.content_hash = SHA1.new(stored_bytes).digest()

                file_rows.append((full_path, len(new_raw), ne.size))
                processed_count += 1
                if processed_count % 5 == 0 or processed_count == total_to_process:
                    sys.stdout.write(f'\r[white]  Processing Assets... [{processed_count}/{total_to_process}][/]')
                    sys.stdout.flush()
            else:
                if cm == CM_NONE:
                    read_sz = (PakCrypto.align_encrypted_content_size(old_entry.size, em)
                               if old_entry.encrypted else old_entry.size)
                    ne.offset = _out_len()
                    _out_append(bytes(orig_fc[old_entry.offset: old_entry.offset + read_sz]))
                elif old_entry.compressed_blocks:
                    new_blks = []
                    for ob in old_entry.compressed_blocks:
                        unc = ob.end - ob.start
                        enc = (PakCrypto.align_encrypted_content_size(unc, em)
                               if old_entry.encrypted else unc)
                        nb = PakCompressedBlock.__new__(PakCompressedBlock)
                        nb.start = _out_len()
                        _out_append(bytes(orig_fc[ob.start: ob.start + enc]))
                        nb.end = _out_len()
                        new_blks.append(nb)
                    ne.compressed_blocks = new_blks
                    ne.offset = new_blks[0].start if new_blks else _out_len()

    sys.stdout.write(f'\r  All {processed_count} assets processed.          \n')
    sys.stdout.flush()

    if force_add:
        for fp, (p, slot, template, is_new) in edited.items():
            if not is_new or slot >= 0:
                continue
            already = False
            for dp_str, dir_files in all_dirs.items():
                for _n, (_s, _e) in dir_files.items():
                    if str(PurePath(dp_str) / _n).replace('\\', '/') == fp:
                        already = True
                        break
                if already:
                    break
            if already:
                continue

            ne = _cp.copy(template)
            new_raw = p.read_bytes()
            pak_rel = PurePath(fp)
            ne.uncompressed_size = len(new_raw)
            ne.compression_method = template.compression_method
            ne.compressed_blocks = []
            ne.compression_block_size = template.compression_block_size
            ne.encryption_method = template.encryption_method
            ne.encrypted = template.encrypted
            ne.unk1 = template.unk1
            full_path_str = mp_str + fp
            ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
            ne.index_new_sep = template.index_new_sep

            stored_start = _out_len()
            if ne.compression_method == CM_NONE:
                cipher = (_encrypt_plaintext(new_raw, pak_rel, ne.encryption_method) if ne.encrypted else new_raw)
                ne.offset = _out_len()
                ne.size = len(new_raw)
                _out_append(cipher)
            else:
                cs = template.compression_block_size if template.compression_block_size > 0 else 65536
                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                order = _block_permutation(len(chunks), ne.encryption_method)
                cipher_by_logical = []
                for chunk in chunks:
                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                    cipher = (_encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed)
                    cipher_by_logical.append(cipher)
                inv = [0] * len(chunks)
                for logical_i, phys_i in enumerate(order):
                    inv[phys_i] = logical_i
                new_blks = [None] * len(chunks)
                for phys_i in range(len(chunks)):
                    blk = PakCompressedBlock.__new__(PakCompressedBlock)
                    blk.start = _out_len()
                    _out_append(cipher_by_logical[inv[phys_i]])
                    blk.end = _out_len()
                    new_blks[phys_i] = blk
                ne.compressed_blocks = new_blks
                ne.offset = new_blks[0].start if new_blks else _out_len()
                ne.size = sum(b.end - b.start for b in new_blks)

            _outf.seek(stored_start)
            stored_bytes = _outf.read(ne.size)
            _outf.seek(0, 2)
            ne.content_hash = SHA1.new(stored_bytes).digest()

            if path_map is not None:
                _nk = norm_path_map.get(p.name)
                _dir_key = _nk if _nk else ''
            else:
                _dir_key = target_path
            new_slot = len(slot_to_new) + len(new_added)
            new_added.append((_dir_key, p.name, ne, new_slot))
            file_rows.append((fp, len(new_raw), ne.size))

    max_slot = max(slot_to_new.keys()) if slot_to_new else -1
    new_files = [slot_to_new[i] for i in range(max_slot + 1)]
    dir_to_added = {}
    for dir_key, name, ne, new_slot in new_added:
        new_files.append(ne)
        dir_to_added.setdefault(dir_key, []).append((name, ne, new_slot))

    for dir_key, items in dir_to_added.items():
        if dir_key not in all_dirs:
            all_dirs[dir_key] = {}
        for name, ne, new_slot in items:
            all_dirs[dir_key][name] = (new_slot, ne)

    idx = bytearray(_pw_string(mp_str))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files:
        idx += _pw_entry(ne, version)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, dir_files in all_dirs.items():
        idx += _pw_string(dp_str)
        idx += struct.pack('<Q', len(dir_files))
        for name, (slot, _old_e) in dir_files.items():
            idx += _pw_string(name)
            idx += struct.pack('<i', ~slot)

    index_plain = bytes(idx)
    new_sha1 = SHA1.new(index_plain).digest()

    if pak_file._pak_info.index_encrypted:
        try:
            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
            if key and iv and len(key) == 32 and len(iv) >= 16:
                aes = AES.new(key, MODE_CBC, iv[:16])
                pad = (-len(index_plain)) % AES.block_size or AES.block_size
                index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
            else:
                index_bytes = index_plain
        except:
            index_bytes = index_plain
    else:
        index_bytes = index_plain

    new_idx_offset = _out_len()
    new_idx_size = len(index_bytes)
    _out_append(index_bytes)

    footer_sz = TencentPakInfo._mem_size(version)
    new_footer = bytearray(orig_fc[-footer_sz:])
    h_key = struct.pack('<5I', *keystream[4:9])
    new_footer[-36:-16] = bytes(a ^ b for a, b in zip(new_sha1, h_key))
    new_footer[-16:-8] = ((new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little'))
    new_footer[-8:] = ((new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little'))
    _out_append(new_footer)

    _outf.flush()
    _outf.close()
    shutil.copy2(_tmppath, output_path)
    os.unlink(_tmppath)

    if file_rows:
        summary = Table(title=rgb_text("Files Processed"), box=ROUNDED, border_style=get_border_style(4, 0.55), style="white on black")
        summary.add_column(rgb_text("Path in PAK"), style="white on black")
        summary.add_column(rgb_text("Original Size"), justify="right", style="white on black")
        summary.add_column(rgb_text("Stored Size"), justify="right", style="white on black")
        for fp, orig_sz, stored_sz in file_rows:
            summary.add_row(rgb_text(fp), rgb_text(human_size(orig_sz)), rgb_text(human_size(stored_sz)))
        console.print(summary)

    return len(edited)

def build_new_pak_from_template(template_pak_path: Path, edit_dir: Path, output_path: Path, target_path: str = None, path_map: dict = None):
    import copy as _cp
    console.print(f'[white]Building NEW PAK using template: {template_pak_path.name}[/]')
    pak_file = TencentPakFile(template_pak_path, is_od=True)
    version = pak_file._pak_info.version
    keystream = PakCrypto.zuc_keystream()
    mp_str, _all_dirs_orig = _get_all_dirs_and_mp(pak_file)

    template_entry = None
    for _dir_path, files in pak_file._index.items():
        for _name, entry in files.items():
            template_entry = entry
            break
        if template_entry:
            break
    if template_entry is None:
        console.print('[white]No file found in the Template PAK to copy settings from![/]')
        return 0

    edit_files = [p for p in Path(edit_dir).rglob('*') if p.is_file()]
    if not edit_files:
        console.print('[white]No file found in the EDIT folder![/]')
        return 0

    out_buf = bytearray()
    new_files = []
    all_dirs = {}
    file_rows = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[white][BUILD][/] {task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console
    ) as progress:
        task = progress.add_task("Adding files...", total=len(edit_files))

        for p in edit_files:
            rel = p.relative_to(edit_dir).as_posix()
            if path_map is not None:
                tp_for_file = path_map.get(p.name)
                if tp_for_file is None:
                    tp_for_file = ''
                if tp_for_file == '':
                    parent = str(PurePath(rel).parent).replace('\\', '/')
                    dir_key = '' if parent == '.' else parent + '/'
                    fp = rel
                else:
                    dir_key = tp_for_file.rstrip('/') + '/'
                    fp = f"{tp_for_file.rstrip('/')}/{p.name}"
            elif target_path:
                fp = f"{target_path.rstrip('/')}/{p.name}"
                dir_key = target_path.rstrip('/') + '/'
            else:
                parent = str(PurePath(rel).parent).replace('\\', '/')
                dir_key = '' if parent == '.' else parent + '/'
                fp = rel

            ne = _cp.copy(template_entry)
            new_raw = p.read_bytes()
            pak_rel = PurePath(fp)

            ne.uncompressed_size = len(new_raw)
            ne.compression_method = template_entry.compression_method
            ne.encryption_method = template_entry.encryption_method
            ne.encrypted = template_entry.encrypted
            ne.unk1 = template_entry.unk1
            full_path_str = mp_str + fp
            ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
            ne.index_new_sep = template_entry.index_new_sep

            stored_start = len(out_buf)
            if ne.compression_method == CM_NONE:
                cipher = (_encrypt_plaintext(new_raw, pak_rel, ne.encryption_method)
                          if ne.encrypted else new_raw)
                ne.offset = len(out_buf)
                ne.size = len(new_raw)
                out_buf += cipher
            else:
                cs = template_entry.compression_block_size if template_entry.compression_block_size > 0 else 65536
                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                order = _block_permutation(len(chunks), ne.encryption_method)
                cipher_by_logical = []
                for chunk in chunks:
                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                    cipher = (_encrypt_plaintext(compressed, pak_rel, ne.encryption_method)
                              if ne.encrypted else compressed)
                    cipher_by_logical.append(cipher)
                inv = [0] * len(chunks)
                for logical_i, phys_i in enumerate(order):
                    inv[phys_i] = logical_i
                new_blks = [None] * len(chunks)
                for phys_i in range(len(chunks)):
                    blk = PakCompressedBlock.__new__(PakCompressedBlock)
                    blk.start = len(out_buf)
                    blk.end = blk.start + len(cipher_by_logical[inv[phys_i]])
                    out_buf += cipher_by_logical[inv[phys_i]]
                    new_blks[phys_i] = blk
                ne.compressed_blocks = new_blks
                ne.offset = new_blks[0].start if new_blks else len(out_buf)
                ne.size = sum(b.end - b.start for b in new_blks)

            stored_bytes = bytes(out_buf[ne.offset:ne.offset + ne.size])
            ne.content_hash = SHA1.new(stored_bytes).digest()

            new_files.append(ne)
            all_dirs.setdefault(dir_key, {})[p.name] = ne
            file_rows.append((fp, ne.uncompressed_size, ne.size))
            progress.update(task, advance=1, description=f"{p.name}")

    summary = Table(title="Files Added to New PAK", box=ROUNDED, border_style="white")
    summary.add_column("Path in PAK", style="white")
    summary.add_column("Original Size", justify="right", style="dim")
    summary.add_column("Stored Size", justify="right", style="dim")
    for fp, orig_sz, stored_sz in file_rows:
        summary.add_row(fp, human_size(orig_sz), human_size(stored_sz))
    console.print(summary)

    id_to_idx = {id(ne): i for i, ne in enumerate(new_files)}

    idx = bytearray(_pw_string(mp_str))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files:
        idx += _pw_entry(ne, version)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, dir_files in all_dirs.items():
        idx += _pw_string(dp_str)
        idx += struct.pack('<Q', len(dir_files))
        for name, e in dir_files.items():
            idx += _pw_string(name)
            idx += struct.pack('<i', ~id_to_idx[id(e)])

    index_plain = bytes(idx)
    new_sha1 = SHA1.new(index_plain).digest()

    if pak_file._pak_info.index_encrypted:
        try:
            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
            if key and iv and len(key) == 32 and len(iv) >= 16:
                aes = AES.new(key, MODE_CBC, iv[:16])
                pad = (-len(index_plain)) % AES.block_size or AES.block_size
                index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
            else:
                index_bytes = index_plain
        except:
            index_bytes = index_plain
    else:
        index_bytes = index_plain

    new_idx_offset = len(out_buf)
    new_idx_size = len(index_bytes)
    out_buf += index_bytes

    orig_fc = pak_file._file_content
    footer_sz = TencentPakInfo._mem_size(version)
    new_footer = bytearray(orig_fc[-footer_sz:])

    h_key = struct.pack('<5I', *keystream[4:9])
    new_footer[-36:-16] = bytes(a ^ b for a, b in zip(new_sha1, h_key))
    new_footer[-16:-8] = ((new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little'))
    new_footer[-8:] = ((new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little'))
    out_buf += new_footer

    with open(output_path, 'wb') as f:
        f.write(out_buf)

    console.print(f'[white]New PAK written: {output_path}[/]')
    console.print(f'[white]Files included: {len(new_files)}[/]')

    try:
        check_pak = TencentPakFile(output_path, is_od=True)
    except AssertionError:
        console.print('[white]VERIFICATION FAILED (index hash mismatch)[/]')
    except Exception as e:
        console.print(f'[white]VERIFICATION FAILED: {e}[/]')

    return len(new_files)

# ==============================================================================
# PAK TOOL FUNCTIONS
# ==============================================================================

def display_file_selector(title, folder_path, file_pattern="*.pak"):
    files = list(folder_path.glob(file_pattern))
    if not files:
        hexa_alert(f"No {file_pattern} files found in {folder_path}", "error")
        return None, None
    
    table = Table(box=ROUNDED, show_header=True, expand=True, padding=(0, 1), border_style=get_border_style(1, 0.55), style="white on black")
    table.add_column("#", justify="right", style="bold white on black", width=4)
    table.add_column("File", style="bold white on black")
    table.add_column("Size", justify="right", style="white on black")
    
    for i, f in enumerate(files, 1):
        size_mb = f.stat().st_size / (1024 * 1024)
        table.add_row(f"[{i}]", f.name, f"{size_mb:.2f} MB")
    
    console.print()
    console.print(Panel(table, title=f"[bold white on black] {title} [/bold white on black]", 
                        border_style=get_border_style(6, 0.55), style="white on black", box=HEAVY, padding=(1, 2)))
    
    try:
        idx = int(hexa_prompt(f"Select file (1-{len(files)})")) - 1
        if idx < 0 or idx >= len(files):
            hexa_alert("Invalid selection", "error")
            return None, None
        return files[idx], files
    except ValueError:
        hexa_alert("Please enter a valid number", "error")
        return None, None

# ==============================================================================
# PAK TOOL ACTIONS
# ==============================================================================

def action_unpack_pak():
    pak_dir = PAK_DIR
    if not pak_dir.exists(): 
        hexa_alert(f"PAK folder not found at {pak_dir}", "error")
        safe_input('\nPress Enter...')
        return
        
    pak_file, _ = display_file_selector("Available .pak files to UNPACK", pak_dir)
    if not pak_file: 
        safe_input('\nPress Enter...')
        return
        
    try:
        hexa_section(f"Unpacking {pak_file.name}")
        pak = TencentPakFile(pak_file)
        unpack_path = PAK_UNPACK_DIR / pak_file.stem
        pak.dump(unpack_path)
        hexa_alert(f"Extracted to {unpack_path}", "success")
    except Exception as e:
        hexa_alert(f"{escape(str(e))}", "error")
    safe_input('\nPress Enter to continue...')

# ==============================================================================
# UTILITY ACTIONS - CLEAN & CLOSE (FROM s2.py)
# ==============================================================================

def action_clean_all():
    """Remove ALVSIA directory and clean up temporary files"""
    try:
        # Define the ALVSIA directory path
        alvsia_dir = Path("/storage/emulated/0/Documents/ALVSIA_TOOL/ALVSIA")
        
        if alvsia_dir.exists():
            console.print("[bold white]⚠ Found ALVSIA directory, removing...[/bold white]")
            shutil.rmtree(alvsia_dir)
            console.print("[bold white]✅ ALVSIA directory removed successfully![/bold white]")
        else:
            console.print("[dim]No ALVSIA directory found.[/dim]")
        
        # Also clean temp files
        temp_files = list(Path("/storage/emulated/0/Documents/ALVSIA_TOOL").glob("*.temp.std.luac"))
        if temp_files:
            for f in temp_files:
                try:
                    f.unlink()
                except:
                    pass
            console.print(f"[white]✅ Removed {len(temp_files)} temporary files.[/white]")
        
        # Clean Python cache files
        cache_dirs = list(Path("/storage/emulated/0/Documents/ALVSIA_TOOL").glob("__pycache__"))
        for cache_dir in cache_dirs:
            try:
                shutil.rmtree(cache_dir)
                console.print(f"[white]✅ Removed {cache_dir}[/white]")
            except:
                pass
        
        console.print("[bold white]✨ Cleanup complete![/bold white]")
    except Exception as e:
        console.print(f"[white]❌ Error during cleanup: {e}[/white]")
    
    safe_input('\nPress Enter to continue...')

def action_close_termux():
    """Close Termux completely with proper cleanup"""
    try:
        console.print()
        ab = AnimatedBorder.get_instance()
        border_color = ab.get_moving_border_style(6, 0.7)
        console.print(Panel(
            "[bold white]═══ ALVSIA TOOL PREMIUM · LUAFLOW ═══[/bold white]\n\n"
            "[bold white]Thank you for using![/bold white]\n\n"
            "[bold white]DEVELOPER[/bold white]  :   @ALVSIA_PRO\n"
            "[bold white]OWNER[/bold white]   :   ALVSIA\n",
            border_style=border_color, style="white on black", box=HEAVY, padding=(1, 2)))
        time.sleep(1.5)
        
        # Close Termux properly
        if sys.platform != 'win32':
            # For Android/Termux - send exit signal
            sys.stdout.flush()
            sys.stderr.flush()
            
            # Try to gracefully exit
            os.system('pkill -9 -f com.termux 2>/dev/null')
            os._exit(0)
        else:
            # For Windows
            sys.exit(0)
    except Exception as e:
        # Force exit if anything fails
        console.print(f"[white]Force closing...[/white]")
        try:
            os.system('pkill -9 -f com.termux 2>/dev/null')
        except:
            pass
        os._exit(0)

def action_repack_inject():
    pak_dir = PAK_DIR
    edit_dir = EDIT_DIR
    result_dir = RESULT_DIR
    
    if not pak_dir.exists(): 
        hexa_alert(f"PAK folder not found at {pak_dir}", "error")
        safe_input('\nPress Enter...')
        return
        
    pak_file, _ = display_file_selector("Available .pak files to REPACK TO PATH", pak_dir)
    if not pak_file: 
        safe_input('\nPress Enter...')
        return
        
    if not edit_dir.exists() or not any(edit_dir.iterdir()):
        hexa_alert("No files in COMPILED folder. Place files to add in COMPILED first.", "error")
        safe_input('\nPress Enter...')
        return
        
    console.print()
    console.print(Panel(f"Target path inside the PAK where files should be added.\n[white]e.g. Content/Lua/GameLua/Mod/BRMod/Gameplay/Core[/white]",
                        border_style=get_border_style(2, 0.55), style="white on black", box=ROUNDED, padding=(0, 2)))
    
    console.print("[dim]Press Enter to use default: Content/Lua/[/dim]")
    
    target_path = safe_input("\n[bold white]Path: [/bold white]").strip()
    
    if not target_path:
        target_path = "Content/Lua/"
        console.print(f"[dim]Using default path: {target_path}[/dim]")
    else:
        console.print(f"[dim]Using custom path: {target_path}[/dim]")
    
    target_path = target_path.replace('\\', '/').strip('/')
    if not target_path: 
        hexa_alert("Invalid target path", "error")
        safe_input('\nPress Enter...')
        return
        
    try:
        console.print(Panel(f"[bold white on black]═══ Adding files to {target_path} · {pak_file.name} ═══[/bold white on black]", border_style=get_border_style(7, 0.55), style="white on black", box=ROUNDED, padding=(0, 2)))
        pak = TencentPakFile(pak_file)
        output_pak = result_dir / pak_file.name
        
        rgb_ui_print("▶ Auto-proceeding with repack...")
        
        count = repack_pak_file_full(pak, edit_dir, output_pak, target_path, force_add=True)
        if count > 0:
            hexa_alert(f"Processed {count} files to {target_path} -> {output_pak}\nPAK is game ready", "success")
        else:
            hexa_alert("No files were processed", "error")
    except Exception as e:
        hexa_alert(f"Repack failed: {e}", "error")
        traceback.print_exc()
    safe_input('\nPress Enter to continue...')

def action_build_new_pak():
    pak_dir = PAK_DIR
    edit_dir = EDIT_DIR
    result_dir = RESULT_DIR
    
    if not pak_dir.exists():
        hexa_alert(f"PAK folder not found at {pak_dir}", "error")
        safe_input('\nPress Enter...')
        return
    
    pak_file, _ = display_file_selector("Select TEMPLATE PAK", pak_dir)
    if not pak_file:
        safe_input('\nPress Enter...')
        return
    
    if not edit_dir.exists() or not any(edit_dir.iterdir()):
        hexa_alert("No files in COMPILED folder. Place files to add in COMPILED first.", "error")
        safe_input('\nPress Enter...')
        return
    
    console.print()
    console.print(Panel(
        "Target path inside PAK (or blank for relative).\n"
        "Files will be added to this path inside the new PAK.\n"
        "[dim]e.g. Content/Lua/GameLua/Mod/BRMod/Gameplay/Core[/dim]\n"
        "[dim]Press Enter directly for no path (files at root)[/dim]",
        border_style=ACCENT, box=ROUNDED, padding=(0, 2)
    ))
    
    target_path = safe_input("\n[bold white]Target path (press Enter for no path): [/bold white]").strip()
    
    if target_path:
        target_path = target_path.replace('\\', '/').strip('/')
        console.print(f"[dim]Using custom path: {target_path}[/dim]")
    else:
        target_path = ""
        console.print("[dim]No path set - files will be at root[/dim]")
    
    output_pak = result_dir / pak_file.name
    
    try:
        hexa_section(f"Building NEW PAK using template: {pak_file.name}")
        rgb_ui_print("▶ Auto-proceeding with build...", speed=0.30)
        count = build_new_pak_from_template(pak_file, edit_dir, output_pak, target_path)
        if count > 0:
            result_msg = (
                f"✓  BUILD_NEW_PAK COMPLETE\n\n"
                f"Processed : {count} file(s)\n"
                f"Output    : {output_pak}\n"
                f"Status    : GAME READY"
            )
            console.print(Panel(
                rgb_text(result_msg),
                title=rgb_text("  📦  BUILD_NEW_PAK RESULT  "),
                border_style=get_border_style(4, 0.55),
                style="white on black",
                box=ROUNDED,
                padding=(1, 2),
            ))
        else:
            hexa_alert("Build failed - no files processed", "error")
    except Exception as e:
        hexa_alert(f"Build failed: {e}", "error")
        traceback.print_exc()
    safe_input('\nPress Enter to continue...')

def action_inject_lua():
    console.print("\n[bold #00AAFF]📦 INJECT LUA - REPACK TO PAK[/bold #00AAFF]")
    console.print("[white]Inject Lua files directly into PAK[/white]")
    console.print()
    
    edit_dir = EDIT_DIR
    out_path = RESULT_DIR
    pak_dir = PAK_DIR
    
    # ========== CHECK: COMPILED folder has files ==========
    if not edit_dir.exists():
        edit_dir.mkdir(parents=True, exist_ok=True)
        console.print(f"[white]⚠ Created empty folder: {edit_dir}[/white]")
        console.print("[white]Please add your LUA files there first![/white]")
        safe_input("\nPress Enter to continue...")
        return
    
    files_in_edit = [f for f in edit_dir.rglob("*") if f.is_file() and f.name not in ['pak_manifest.json','.DS_Store']]
    if not files_in_edit:
        console.print("[bold white]❌ COMPILED folder is empty![/bold white]")
        console.print(f"[white]📁 Please put LUA files in: {edit_dir}[/white]")
        safe_input("\nPress Enter to continue...")
        return
    
    # ========== DISPLAY FILES ==========
    console.print("\n[bold white]📂 Files found in COMPILED folder:[/bold white]")
    files = []
    for idx, f in enumerate(files_in_edit, 1):
        rel_path = str(f.relative_to(edit_dir)).replace("\\", "/")
        files.append((f, rel_path))
        if len(rel_path) > 60:
            display_path = "..." + rel_path[-57:]
        else:
            display_path = rel_path
        console.print(f"  [{idx}] {display_path}")
    
    # ========== SIMPLIFIED: Direct Path Entry ==========
    console.print("\n[bold white]Enter the target path inside the PAK:[/bold white]")
    console.print("[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/[/dim]")
    console.print("[dim]Press Enter to use default: filename only[/dim]")
    
    base_path = safe_input("\n[bold white]Path: [/bold white]").strip()
    
    if not base_path:
        base_path = ""
        console.print("[dim]No base path - files will be at root[/dim]")
    else:
        if not base_path.endswith('/'):
            base_path += '/'
        console.print(f"[dim]Using custom path: {base_path}[/dim]")
    
    # ========== BUILD FILE LOCATIONS ==========
    file_locations = {}
    for f, rel_path in files:
        if base_path:
            file_locations[str(f)] = base_path + f.name
        else:
            file_locations[str(f)] = f.name
    
    console.print(f"\n[white]✅ {len(files)} files will be injected[/white]")
    
    # Show summary
    for f, loc in list(file_locations.items())[:5]:
        short_name = Path(f).name[:30] + "..." if len(Path(f).name) > 30 else Path(f).name
        console.print(f"  [dim]•[/dim] {short_name} → [white]{loc}[/white]")
    if len(file_locations) > 5:
        console.print(f"  [dim]... and {len(file_locations) - 5} more files[/dim]")
    
    console.print(rgb_text("\n▶ Auto-proceeding with injection..."))
    
    # ========== FIND PAK FILE ==========
    console.print("[white]🔍 Searching for PAK files in PAK_ORIGINAL...[/white]")
    pak_files = []
    for file in pak_dir.iterdir():
        if file.name.lower().endswith('.pak'):
            pak_files.append(file)
    
    if not pak_files:
        console.print("[bold white]❌ No PAK file found in PAK_ORIGINAL folder![/bold white]")
        console.print(f"[white]📁 Please put PAK file in: {pak_dir}[/white]")
        safe_input("\nPress Enter to continue...")
        return
    
    if len(pak_files) == 1:
        pak_path = pak_files[0]
        console.print(f"[white]✅ Found PAK: {pak_path.name}[/white]")
    else:
        console.print(f"[white]⚠️ Multiple PAK files found:[/white]")
        for i, pak in enumerate(pak_files, 1):
            console.print(f"  [{i}] {pak.name}")
        console.print("\n[bold white]Enter number to select:[/bold white]")
        try:
            choice_pak = int(safe_input("> ").strip())
            if 1 <= choice_pak <= len(pak_files):
                pak_path = pak_files[choice_pak - 1]
                console.print(f"[white]✅ Selected: {pak_path.name}[/white]")
            else:
                console.print("[bold white]❌ Invalid choice![/bold white]")
                safe_input("\nPress Enter to continue...")
                return
        except:
            console.print("[bold white]❌ Invalid input![/bold white]")
            safe_input("\nPress Enter to continue...")
            return
    
    # ========== BACKUP ==========
    BACKUP_FOLDER = PAK_DIR.parent / "BACKUP"
    BACKUP_FOLDER.mkdir(exist_ok=True)
    backup_name = f"{pak_path.stem}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pak"
    backup_path = BACKUP_FOLDER / backup_name
    shutil.copy2(pak_path, backup_path)
    console.print(f"[bold white]✅ Backup created: {backup_path}[/bold white]")
    
    # ========== INJECT ==========
    try:
        console.print("[white]📦 Loading PAK file...[/white]")
        pak = TencentPakFile(PurePath(pak_path))
        output_name = f"{pak_path.stem}_MODIFIED.pak"
        output_pak = out_path / output_name
        
        rgb_ui_print("🔄 Repacking PAK...", speed=0.30)
        
        dominant = pak.detect_dominant_style()
        console.print(f"[white]Dominant style: comp={dominant['comp_method']}, enc={dominant['enc_method']}, encrypted={dominant['encrypted']}, block={dominant['block_size']}[/white]")
        
        inject_plan = []
        for f, rel_path in files:
            internal_path = file_locations.get(str(f), f.name)
            
            if internal_path.startswith('/'):
                internal_path = internal_path[1:]
            
            inject_plan.append({
                'src_path': f,
                'internal_path': internal_path,
                'comp_method': dominant['comp_method'],
                'enc_method': dominant['enc_method'],
                'encrypted': dominant['encrypted'],
                'block_size': dominant['block_size'],
            })
        
        console.print(f"[white]Plan: {len(inject_plan)} files with custom locations.[/white]")
        
        pak.inject_files(inject_plan, Path(output_pak))
        result_msg = (
            f"✓  INJECT_LUA COMPLETE\n\n"
            f"Processed : {len(inject_plan)} file(s)\n"
            f"Output    : {output_pak}\n"
            f"Status    : GAME READY"
        )
        console.print(Panel(
            rgb_text(result_msg),
            title=rgb_text("  💉  INJECT_LUA RESULT  "),
            border_style=get_border_style(6, 0.55),
            style="white on black",
            box=ROUNDED,
            padding=(1, 2),
        ))
        
    except Exception as e:
        console.print(f"[bold white]❌ Error: {e}[/bold white]")
        import traceback
        traceback.print_exc()
    
    safe_input("\nPress Enter to continue...")



def action_open_alvsia_build_pak():
    """Option 6: run the COMPLETE builder main menu embedded inside luaflow.py.

    The complete STAR engine source is embedded below, so Option 6 does not
    depend on launching a second Python process or on finding an external
    builder file. Its workspace remains the shared ALVSIA_TOOL folder.
    """
    console.print("[white]🚀 Opening COMPLETE STAR main menu...[/white]")
    try:
        namespace = {
            "__name__": "__embedded_builder__",
            "__file__": "/storage/emulated/0/Documents/ALVSIA_TOOL/builder.py",
            "__package__": None,
            "__cached__": None,
        }
        exec(compile(_EMBEDDED_BUILDER_SOURCE, "<embedded builder.py>", "exec"), namespace, namespace)

        # Option 6 uses the embedded STAR menu directly.  Dependencies are
        # expected to already exist in the shared Termux environment, so do not
        # display/install the dependency-check screen here.
        if callable(namespace.get("create_folders")):
            namespace["create_folders"]()
        if not callable(namespace.get("main_menu")):
            raise RuntimeError("Embedded builder main_menu() was not found.")
        namespace["main_menu"]()
    except KeyboardInterrupt:
        console.print("\n[white]STAR main menu stopped.[/white]")
    except Exception as e:
        console.print(f"[white]❌ Embedded builder failed: {e}[/white]")
        import traceback
        traceback.print_exc()
        safe_input("\nPress Enter...")


# COMPLETE builder source is embedded in luaflow.py for Option 6.
# This is the exact current builder source, kept in its own namespace so its
# globals/helpers do not collide with s.py.
_EMBEDDED_BUILDER_SOURCE = '#!/data/data/com.termux/files/usr/bin/python3\n# -*- coding: utf-8 -*-\n# ============================================================\n# ALVSIA_BUILD_PAK v1.0 — Standalone Custom Inject Tool\n# For Termux (Android)\n# ============================================================\n\nimport itertools as it\nimport math\nimport struct\nimport shutil\nimport os\nimport sys\nimport hashlib\nimport subprocess\nimport zlib\nimport json\nimport re\nimport colorsys\nfrom dataclasses import dataclass\nfrom functools import lru_cache\nfrom pathlib import PurePath, Path\nfrom typing import List, Dict, Tuple, Optional, Any, Union\nimport time\nfrom rich.console import Console\nfrom rich.panel import Panel\nfrom rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn\nfrom rich.table import Table\nfrom rich import print as rprint\nfrom rich.markup import escape\nimport gmalg\nfrom datetime import datetime\nfrom collections import Counter\nfrom Crypto.Util.Padding import pad, unpad\nfrom Crypto.Cipher import AES\nfrom Crypto.Cipher.AES import MODE_CBC\nfrom Crypto.Hash import SHA1\ntry:\n    from zstandard import ZstdDecompressor, ZstdCompressionDict, DICT_TYPE_AUTO, ZstdCompressor\nexcept ImportError:\n    print("zstandard not found. Installing...")\n    subprocess.check_call([sys.executable, "-m", "pip", "install", "zstandard"])\n    from zstandard import ZstdDecompressor, ZstdCompressionDict, DICT_TYPE_AUTO, ZstdCompressor\nfrom colorama import init, Fore, Style, Back\ninit(autoreset=True)\n\nconsole = Console(color_system="truecolor", highlight=False)\nREPACK_RGB_MODE = True\n_original_console_print = console.print\ndef _rgb_console_print(*args, **kwargs):\n    if not REPACK_RGB_MODE or not args:\n        return _original_console_print(*args, **kwargs)\n    if len(args) == 1 and isinstance(args[0], str):\n        try:\n            from rich.text import Text\n            plain = Text.from_markup(args[0])\n            out = Text()\n            chars = list(plain.plain)\n            width = max(1, len(chars) - 1)\n            stamp = time.time() * 0.30\n            for i, ch in enumerate(chars):\n                p = (stamp + (i / width) * 0.95) % 1.0\n                # In ALVSIA_BUILD_PAK, cyan/blue are displayed as white.\n                if 0.45 <= p <= 0.72:\n                    out.append(ch, style="#ffffff")\n                else:\n                    r, g, b = colorsys.hsv_to_rgb(p, 0.95, 1.0)\n                    out.append(ch, style=f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}")\n            return _original_console_print(out, **kwargs)\n        except Exception:\n            return _original_console_print(*args, **kwargs)\n    return _original_console_print(*args, **kwargs)\nconsole.print = _rgb_console_print\n\ntry:\n    from itertools import batched\nexcept ImportError:\n    import itertools as _itertools\n    def batched(iterable, n):\n        if n < 1:\n            raise ValueError(\'n must be at least one\')\n        it = iter(iterable)\n        while True:\n            batch = tuple(_itertools.islice(it, n))\n            if not batch:\n                break\n            yield batch\n\n\n# Added PAK engines from s.py (Options 3 and 4)\ntry:\n    from rich.box import ROUNDED\nexcept ImportError:\n    ROUNDED = None\ntry:\n    from rich.progress import TaskProgressColumn, TimeElapsedColumn\nexcept ImportError:\n    TaskProgressColumn = TimeElapsedColumn = None\n\nBASE_DIR = Path("/storage/emulated/0/Documents/ALVSIA_TOOL")\nPAK_ORIGINAL_DIR = BASE_DIR / "PAK_ORIGINAL"\n\nMAGENTA = "\\033[1;35m"\nYELLOW  = "\\033[1;33m"\nGREEN   = "\\033[1;32m"\nRED     = "\\033[1;31m"\nWHITE   = "\\033[1;37m"\nCYAN    = WHITE   # ALVSIA_BUILD_PAK: cyan -> white\nBLUE    = WHITE   # ALVSIA_BUILD_PAK: blue -> white\nRESET   = "\\033[0m"\nBOLD    = "\\033[1m"\nDIM     = "\\033[2m"\n\ndef flush_stdin():\n    """Flush any lingering input from stdin"""\n    try:\n        import termios\n        termios.tcflush(sys.stdin.fileno(), termios.TCIFLUSH)\n    except:\n        pass\n    try:\n        import select\n        if select.select([sys.stdin], [], [], 0.1)[0]:\n            sys.stdin.read()\n    except:\n        pass\n\ndef safe_input(prompt: str = "") -> str:\n    """Safe input function that properly handles stdin"""\n    try:\n        return input(prompt)\n    except (EOFError, RuntimeError, KeyboardInterrupt):\n        try:\n            if sys.platform != "win32":\n                with open("/dev/tty", "r") as tty:\n                    sys.stderr.write(prompt)\n                    sys.stderr.flush()\n                    result = tty.readline().rstrip("\\n")\n                    try:\n                        import termios\n                        termios.tcflush(sys.stdin.fileno(), termios.TCIFLUSH)\n                    except:\n                        pass\n                    return result\n            else:\n                with open("CON", "r") as con:\n                    sys.stderr.write(prompt)\n                    sys.stderr.flush()\n                    result = con.readline().rstrip("\\r\\n")\n                    return result\n        except Exception:\n            return ""\n\ndef install_dependencies():\n    """Install required Python packages for Termux with smart skip"""\n    \n    # Python version check\n    python_ver = sys.version_info\n    console.print(f"[dim]🐍 Python {python_ver.major}.{python_ver.minor}.{python_ver.micro} detected[/dim]")\n    \n    # All required packages with import names\n    deps = {\n        \'rich\': \'rich\',\n        \'pycryptodome\': \'Crypto\',\n        \'zstandard\': \'zstandard\',\n        \'gmalg\': \'gmalg\',\n        \'requests\': \'requests\',\n        \'colorama\': \'colorama\',\n        \'cffi\': \'cffi\',\n        \'six\': \'six\',\n    }\n    \n    missing = []\n    installed = []\n    \n    console.print("[white]📦 Checking dependencies...[/white]")\n    \n    for package_name, import_name in deps.items():\n        try:\n            __import__(import_name)\n            installed.append(package_name)\n            console.print(f"  [white]✅ {package_name}[/white] [dim](already installed)[/dim]")\n        except ImportError:\n            missing.append(package_name)\n            console.print(f"  [white]⚠ {package_name}[/white] [dim](missing)[/dim]")\n    \n    if not missing:\n        console.print("[bold white]✅ All dependencies ready![/bold white]")\n        time.sleep(1)\n        return\n    \n    console.print(f"\\n[white]📥 Installing {len(missing)} missing package(s)...[/white]")\n    \n    # Install missing packages\n    for package_name in missing:\n        console.print(f"[white]⏳ Installing {package_name}...[/white]")\n        try:\n            # Try normal install first\n            subprocess.check_call(\n                [sys.executable, "-m", "pip", "install", package_name],\n                stdout=subprocess.DEVNULL,\n                stderr=subprocess.DEVNULL\n            )\n            console.print(f"  [white]✅ {package_name} installed[/white]")\n        except:\n            # Retry with --no-deps for problematic packages\n            try:\n                console.print(f"  [white]Retrying {package_name} with --no-deps...[/white]")\n                subprocess.check_call(\n                    [sys.executable, "-m", "pip", "install", package_name, "--no-deps"],\n                    stdout=subprocess.DEVNULL,\n                    stderr=subprocess.DEVNULL\n                )\n                console.print(f"  [white]✅ {package_name} installed (no-deps)[/white]")\n            except:\n                console.print(f"  [white]❌ Failed to install {package_name}[/white]")\n                \n                # Special handling for critical packages\n                if package_name == \'pycryptodome\':\n                    console.print("[white]  ↳ Try manual: pkg install python-cryptography[/white]")\n                elif package_name == \'gmalg\':\n                    console.print("[white]  ↳ Try manual: pip install gmalg --no-deps[/white]")\n                elif package_name == \'zstandard\':\n                    console.print("[white]  ↳ Try manual: pkg install libzstd && pip install zstandard[/white]")\n    \n    # Final verification\n    console.print("\\n[white]🔍 Verifying installations...[/white]")\n    failed = []\n    for package_name in missing:\n        import_name = deps.get(package_name, package_name)\n        try:\n            __import__(import_name)\n            console.print(f"  [white]✅ {package_name}[/white]")\n        except ImportError:\n            failed.append(package_name)\n            console.print(f"  [white]❌ {package_name}[/white]")\n    \n    if failed:\n        console.print(f"\\n[bold white]⚠ {len(failed)} package(s) failed to install![/bold white]")\n        console.print("[white]Some features may not work. Continue anyway?[/white]")\n        \n        # Auto-continue after 3 seconds\n        console.print("[dim]Continuing in 3 seconds...[/dim]")\n        time.sleep(3)\n    else:\n        console.print("[bold white]✅ All dependencies ready![/bold white]")\n    \n    time.sleep(1)\n\ndef create_folders():\n    folders = [\n        BASE_DIR,\n        PAK_ORIGINAL_DIR,\n        BASE_DIR / "index",\n    ]\n    for folder in folders:\n        folder.mkdir(parents=True, exist_ok=True)\n\n    # index folder notice\n    index_csv = BASE_DIR / "index" / "PUBG.csv"\n    if not index_csv.exists():\n        console.print(\n            f"[bold #FFAA00]PUBG.csv not found in index/ folder![/bold #FFAA00]\\n"\n            f"[dim]Place PUBG.csv here -> {index_csv}[/dim]\\n"\n            f"[dim]Custom Inject will auto-detect paths once it\'s there.[/dim]"\n        )\n\n# ========== CONSTANTS ==========\nZUC_KEY = bytes.fromhex(\'01010101010101010101010101010101\')\nZUC_IV = bytes.fromhex(\'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF\')\n\nRSA_MOD_1 = bytes.fromhex(\n    \'CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4\')\nRSA_MOD_2 = bytes.fromhex(\n    \'7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8\')\n\nSIMPLE1_DECRYPT_KEY = 0x79\nSIMPLE2_DECRYPT_KEY = bytes.fromhex(\'E55B4ED1\')\nSIMPLE2_BLOCK_SIZE = 16\n\nSM4_SECRET_4 = \'eb691efea914241317a8\'\nSM4_SECRET_2 = \'Q0hVTKey$as*1ZFlQCiA\'\nSM4_SECRET_NEW = [\n    "xG2qW5lP7lV2iN5fN5pG", "xT1cJ6dL5wC0kK1rB4dK", "qC4jS5bZ6fL5xE6nD4zA",\n    "gD4jQ2aL3bS3lC3xT0iW", "xU1yQ8wE9zY3gZ3bT5aE", "uQ3cO2dX7xY4xU7gH7iS",\n    "gW1fR0jK6wQ4oN0oK1kZ", "aJ4pV7iZ7pU4wP2aC2cZ", "cX6jT3cM2oT3vK0kJ1qN",\n    "iT2vS0cS6yT6cZ1sE1lO", "hM1pH9iY8wM9hT4lN5uJ", "kG6bC8jK0fL0dE4sH4mL",\n    "dB6lB3vE0eZ8wM8rI0aC", "tP7sP7nI9rA2vQ4cV5yQ", "aT0cL1yN4pT3sZ7eM2vY",\n    "uV6fU8fC9zN3mP5dH8mN", "rT6aQ6oZ1yM0gO5tO1aN", "jU5bH7lQ0fM9hK2kI0oF",\n    "iQ0eM0mJ7uT0kV6kL5zY"\n]\n\nEM_SIMPLE1 = 1\nEM_SIMPLE2 = 16 \nEM_SM4_2 = 2\nEM_SM4_4 = 4\nEM_SM4_NEW_BASE = 31\nEM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE\nEM_UNKNOWN_17 = 17\n\nCM_NONE = 0\nCM_ZLIB = 1\nCM_ZSTD = 6\nCM_ZSTD_DICT = 8\nCM_MASK = 15\n\n# ========== SM4 IMPLEMENTATION ==========\nclass SM4:\n    """SM4 Algorithm Implementation."""\n    \n    _S_BOX = bytes([\n        0x34, 0x66, 0x25, 0x74, 0x89, 0x78, 0xE4, 0xA9, 0x5A, 0x41, 0xBC, 0x7A, 0xD6, 0x16, 0x21, 0x23,\n        0x4D, 0x61, 0xDA, 0x94, 0x9B, 0xDF, 0x13, 0x3C, 0x69, 0x3A, 0x31, 0x0A, 0x5F, 0xD7, 0x99, 0x95,\n        0xF1, 0xAE, 0x72, 0x3D, 0x07, 0x60, 0x24, 0xB6, 0x98, 0xEE, 0xC4, 0xA2, 0x2D, 0x88, 0xDD, 0x8D,\n        0x04, 0xEA, 0xBB, 0x11, 0xCA, 0x3E, 0x5D, 0xA1, 0xF6, 0x3F, 0xB0, 0x97, 0x80, 0x47, 0x2B, 0xA6,\n        0xE6, 0xF7, 0xD9, 0xB1, 0x59, 0xC0, 0x7C, 0xBE, 0x54, 0x28, 0xB7, 0x7E, 0x4F, 0xF8, 0x43, 0x6E,\n        0xA0, 0x50, 0x0E, 0xF5, 0x90, 0xB8, 0xFB, 0xA3, 0x7B, 0x62, 0x19, 0x46, 0x03, 0x2A, 0xB9, 0x8F,\n        0x9F, 0x77, 0xB4, 0x5B, 0x83, 0x87, 0x08, 0xEB, 0xE2, 0x1E, 0x42, 0xF0, 0x0F, 0xE8, 0x71, 0x6A,\n        0x75, 0xAD, 0x55, 0x1F, 0xB5, 0xAB, 0x33, 0xFA, 0x7F, 0x15, 0xBD, 0x85, 0xD8, 0x06, 0x68, 0xB3,\n        0x52, 0x30, 0x48, 0x0B, 0x00, 0xED, 0xEF, 0xB2, 0x57, 0x8E, 0xE7, 0x6C, 0xD5, 0xE5, 0x2E, 0x53,\n        0x82, 0x05, 0xF9, 0x81, 0xF4, 0x56, 0xBF, 0x8C, 0x4B, 0xE3, 0xDB, 0x4A, 0x91, 0x4C, 0x2C, 0xD3,\n        0x40, 0x29, 0x4E, 0x20, 0x14, 0x36, 0x79, 0x09, 0x6F, 0xD1, 0x37, 0xE0, 0x39, 0x0C, 0x8A, 0x92,\n        0x38, 0x12, 0x35, 0x6D, 0xE1, 0xFD, 0x93, 0x9A, 0x17, 0xD4, 0xC9, 0x9C, 0x6B, 0x84, 0x26, 0x9D,\n        0xAF, 0x76, 0xC1, 0x9E, 0xD0, 0x96, 0xC5, 0xCB, 0xE9, 0x73, 0x49, 0xD2, 0xCD, 0x64, 0xC3, 0xC7,\n        0x01, 0x7D, 0xF3, 0xAC, 0xFC, 0xDE, 0xA4, 0x44, 0x32, 0x1B, 0xC2, 0xBA, 0x1C, 0x02, 0xC6, 0x27,\n        0x45, 0x8B, 0xF2, 0x18, 0xA7, 0x10, 0x51, 0x1D, 0xC8, 0xCF, 0x63, 0xFF, 0x2F, 0x0D, 0x58, 0xCE,\n        0x65, 0xA5, 0xDC, 0x1A, 0x3B, 0x86, 0xFE, 0x22, 0x5C, 0xA8, 0x5E, 0x67, 0xAA, 0xEC, 0x70, 0xCC\n    ])\n\n    _FK = [\n        0x46970E9C, 0x4BC0685E, 0x59056186, 0xBCA2491E\n    ]\n\n    _CK = [\n        0x000EB92B, 0x3A0AE783, 0x9E3B5C67, 0xADDBDABF, 0x7B7484CB, 0x49156C63, 0xC79AB5E7, 0x79EC9CFF,\n        0x1725BEAB, 0x2FB89CA3, 0x24808AD7, 0xDDD28B1F, 0x4740DA4B, 0xBBC3EA73, 0x247B30E7, 0x91BE385F,\n        0x0401248B, 0x45FCD3A3, 0x530B4CE7, 0xC68DD35F, 0xE3D16C2B, 0x4F698C13, 0x6B92C747, 0x769EFB1F,\n        0x4C73BE9B, 0xC942B193, 0xAD80D827, 0x372FB33F, 0x13CB6AAB, 0x2BDC0AA3, 0x17A4A247, 0xD5E96CAF\n    ]\n\n    @staticmethod\n    def ROL32(x, n):\n        return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))\n\n    @staticmethod\n    def _BS(X):\n        return ((SM4._S_BOX[(X >> 24) & 0xff] << 24) |\n                (SM4._S_BOX[(X >> 16) & 0xff] << 16) |\n                (SM4._S_BOX[(X >> 8) & 0xff] << 8) |\n                (SM4._S_BOX[X & 0xff]))\n\n    @staticmethod\n    def _T0(X):\n        X = SM4._BS(X)\n        return X ^ SM4.ROL32(X, 2) ^ SM4.ROL32(X, 10) ^ SM4.ROL32(X, 18) ^ SM4.ROL32(X, 24)\n\n    @staticmethod\n    def _T1(X):\n        X = SM4._BS(X)\n        return X ^ SM4.ROL32(X, 13) ^ SM4.ROL32(X, 23)\n\n    @staticmethod\n    def _key_expand(key: bytes, rkey: list):\n        K0 = int.from_bytes(key[0:4], "big") ^ SM4._FK[0]\n        K1 = int.from_bytes(key[4:8], "big") ^ SM4._FK[1]\n        K2 = int.from_bytes(key[8:12], "big") ^ SM4._FK[2]\n        K3 = int.from_bytes(key[12:16], "big") ^ SM4._FK[3]\n\n        for i in range(0, 32, 4):\n            K0 = K0 ^ SM4._T1(K1 ^ K2 ^ K3 ^ SM4._CK[i])\n            rkey[i] = K0\n            K1 = K1 ^ SM4._T1(K2 ^ K3 ^ K0 ^ SM4._CK[i + 1])\n            rkey[i + 1] = K1\n            K2 = K2 ^ SM4._T1(K3 ^ K0 ^ K1 ^ SM4._CK[i + 2])\n            rkey[i + 2] = K2\n            K3 = K3 ^ SM4._T1(K0 ^ K1 ^ K2 ^ SM4._CK[i + 3])\n            rkey[i + 3] = K3\n\n    @classmethod\n    def key_length(cls):\n        return 16\n\n    @classmethod\n    def block_length(cls):\n        return 16\n\n    def __init__(self, key: bytes):\n        if len(key) != self.key_length():\n            raise ValueError(f"Key must be {self.key_length()} bytes")\n\n        self._key = key\n        self._rkey = [0] * 32\n        SM4._key_expand(self._key, self._rkey)\n        self._block_buffer = bytearray()\n\n    def encrypt(self, block: bytes) -> bytes:\n        if len(block) != self.block_length():\n            raise ValueError(f"Block must be {self.block_length()} bytes")\n\n        RK = self._rkey\n        X0 = int.from_bytes(block[0:4], "big")\n        X1 = int.from_bytes(block[4:8], "big")\n        X2 = int.from_bytes(block[8:12], "big")\n        X3 = int.from_bytes(block[12:16], "big")\n\n        for i in range(0, 32, 4):\n            X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[i])\n            X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[i + 1])\n            X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[i + 2])\n            X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[i + 3])\n\n        BUFFER = self._block_buffer\n        BUFFER.clear()\n        BUFFER.extend(X3.to_bytes(4, "big"))\n        BUFFER.extend(X2.to_bytes(4, "big"))\n        BUFFER.extend(X1.to_bytes(4, "big"))\n        BUFFER.extend(X0.to_bytes(4, "big"))\n        return bytes(BUFFER)\n\n    def decrypt(self, block: bytes) -> bytes:\n        if len(block) != self.block_length():\n            raise ValueError(f"Block must be {self.block_length()} bytes")\n\n        RK = self._rkey\n        X0 = int.from_bytes(block[0:4], "big")\n        X1 = int.from_bytes(block[4:8], "big")\n        X2 = int.from_bytes(block[8:12], "big")\n        X3 = int.from_bytes(block[12:16], "big")\n\n        for i in range(0, 32, 4):\n            X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[31 - i])\n            X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[30 - i])\n            X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[29 - i])\n            X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[28 - i])\n\n        BUFFER = self._block_buffer\n        BUFFER.clear()\n        BUFFER.extend(X3.to_bytes(4, "big"))\n        BUFFER.extend(X2.to_bytes(4, "big"))\n        BUFFER.extend(X1.to_bytes(4, "big"))\n        BUFFER.extend(X0.to_bytes(4, "big"))\n        return bytes(BUFFER)\n\n# ========== UTILITY CLASSES ==========\nclass Misc:\n    @staticmethod\n    def pad_to_n(data: bytes, n: int) -> bytes:\n        assert n > 0\n        padding = n - (len(data) % n)\n        if padding == n:\n            return data\n        return data + b\'\\x00\' * padding\n\n    @staticmethod\n    def align_up(x: int, n: int) -> int:\n        return ((x + n - 1) // n) * n\n\nclass Reader:\n    def __init__(self, buffer, cursor=0):\n        self._buffer = buffer\n        self._cursor = cursor\n\n    def u1(self, move_cursor=True) -> int:\n        return self.unpack(\'B\', move_cursor=move_cursor)[0]\n\n    def u4(self, move_cursor=True) -> int:\n        return self.unpack(\'<I\', move_cursor=move_cursor)[0]\n\n    def u8(self, move_cursor=True) -> int:\n        return self.unpack(\'<Q\', move_cursor=move_cursor)[0]\n\n    def i1(self, move_cursor=True) -> int:\n        return self.unpack(\'b\', move_cursor=move_cursor)[0]\n\n    def i4(self, move_cursor=True) -> int:\n        return self.unpack(\'<i\', move_cursor=move_cursor)[0]\n\n    def i8(self, move_cursor=True) -> int:\n        return self.unpack(\'<q\', move_cursor=move_cursor)[0]\n\n    def s(self, n: int, move_cursor=True) -> bytes:\n        return self.unpack(f\'{n}s\', move_cursor=move_cursor)[0]\n\n    def unpack(self, f: Union[str, bytes], offset=0, move_cursor=True):\n        x = struct.unpack_from(f, self._buffer, self._cursor + offset)\n        if move_cursor:\n            self._cursor += struct.calcsize(f)\n        return x\n\n    def string(self, move_cursor=True) -> str:\n        length = self.i4(move_cursor=move_cursor)\n        if length == 0:\n            return str()\n        assert length > 0\n        offset = 0 if move_cursor else 4\n        return self.unpack(f\'{length}s\', offset=offset, move_cursor=move_cursor)[0].rstrip(b\'\\x00\').decode()\n\n# ========== PAK CLASSES ==========\nclass PakInfo:\n    def __init__(self, buffer, keystream: List[int]):\n        def decrypt_index_encrypted(x: int) -> int:\n            MASK_8 = 0xFF\n            return (x ^ keystream[3]) & MASK_8\n\n        def decrypt_magic(x: int) -> int:\n            return x ^ keystream[2]\n\n        def decrypt_index_hash(x: bytes) -> bytes:\n            key = struct.pack(\'<5I\', *keystream[4:][:5])\n            assert len(x) == len(key)\n            return bytes(a ^ b for a, b in zip(x, key))\n\n        def decrypt_index_size(x: int) -> int:\n            return x ^ ((keystream[10] << 32) | keystream[11])\n\n        def decrypt_index_offset(x: int) -> int:\n            return x ^ ((keystream[0] << 32) | keystream[1])\n\n        reader = Reader(buffer[-PakInfo._mem_size(-1):])\n        self.index_encrypted: bool = decrypt_index_encrypted(reader.u1()) == 1\n        self.magic: int = decrypt_magic(reader.u4())\n        self.version: int = reader.u4()\n        self.index_hash: bytes = decrypt_index_hash(reader.s(20)) if self.version >= 6 else bytes()\n        self.index_size: int = decrypt_index_size(reader.u8())\n        self.index_offset: int = decrypt_index_offset(reader.u8())\n        if self.version <= 3:\n            self.index_encrypted = False\n\n    @staticmethod\n    def _mem_size(_: int) -> int:\n        return 1 + 4 + 4 + 20 + 8 + 8\n\nclass TencentPakInfo(PakInfo):\n    def __init__(self, buffer, keystream: List[int]):\n        def decrypt_unk(x: bytes) -> bytes:\n            key = struct.pack(\'<8I\', *keystream[7:][:8])\n            assert len(x) == len(key)\n            return bytes(a ^ b for a, b in zip(x, key))\n\n        def decrypt_stem_hash(x: int) -> int:\n            return x ^ keystream[8]\n\n        def decrypt_unk_hash(x: int) -> int:\n            return x ^ keystream[9]\n\n        super().__init__(buffer, keystream)\n        reader = Reader(buffer[-TencentPakInfo._mem_size(self.version):])\n        self.unk1: bytes = decrypt_unk(reader.s(32)) if self.version >= 7 else bytes()\n        self.packed_key: bytes = reader.s(256) if self.version >= 8 else bytes()\n        self.packed_iv: bytes = reader.s(256) if self.version >= 8 else bytes()\n        self.packed_index_hash: bytes = reader.s(256) if self.version >= 8 else bytes()\n        self.stem_hash: int = decrypt_stem_hash(reader.u4()) if self.version >= 9 else 0\n        self.unk2: int = decrypt_unk_hash(reader.u4()) if self.version >= 9 else 0\n        self.content_org_hash: bytes = reader.s(20) if self.version >= 12 else bytes()\n\n    @staticmethod\n    def _mem_size(version: int) -> int:\n        size_for_7 = 32 if version >= 7 else 0\n        size_for_8 = 256 * 3 if version >= 8 else 0\n        size_for_9 = 4 * 2 if version >= 9 else 0\n        size_for_12 = 20 if version >= 12 else 0\n        return PakInfo._mem_size(version) + size_for_7 + size_for_8 + size_for_9 + size_for_12\n\nclass PakCompressedBlock:\n    def __init__(self, reader: Reader):\n        self.start: int = reader.u8()\n        self.end: int = reader.u8()\n\n@dataclass\nclass TencentPakEntry:\n    def __init__(self, reader: Reader, version: int):\n        self.content_hash: bytes = reader.s(20)\n        if version <= 1:\n            _ = reader.u8()\n        self.offset: int = reader.u8()\n        self.uncompressed_size: int = reader.u8()\n        self.compression_method: int = reader.u4() & CM_MASK\n        self.size: int = reader.u8()\n        self.unk1: int = reader.u1() if version >= 5 else 0\n        self.unk2: bytes = reader.s(20) if version >= 5 else bytes()\n        self.compressed_blocks: List[PakCompressedBlock] = [PakCompressedBlock(reader) for _ in range(\n            reader.u4())] if self.compression_method != 0 and version >= 3 else []\n        self.compression_block_size: int = reader.u4() if version >= 4 else 0\n        self.encrypted: bool = reader.u1() == 1 if version >= 4 else False\n        self.encryption_method: int = reader.u4() if version >= 12 else 0\n        self.index_new_sep: int = reader.u4() if version >= 12 else 0\n\n    def _mem_size(self, version: int) -> int:\n        size_for_123 = 20 + 8 + 8 + 4 + 8 + (8 if version == 1 else 0)\n        size_for_4 = 4 + 1 if version >= 4 else 0\n        size_for_compressed_blocks = 4 + len(self.compressed_blocks) * 16 if self.compressed_blocks else 0\n        size_for_5 = 1 + 20 if version >= 5 else 0\n        size_for_12 = 4 if version >= 12 else 0\n        return size_for_123 + size_for_4 + size_for_5 + size_for_12 + size_for_compressed_blocks\n\nclass PakCrypto:\n    class _LCG:\n        def __init__(self, seed: int):\n            self.state = seed\n\n        def next(self) -> int:\n            MASK_32 = 0xFFFFFFFF\n            MSB_1 = 1 << 31\n\n            def wrap(x: int) -> int:\n                x &= MASK_32\n                if not x & MSB_1:\n                    return x\n                else:\n                    return ((x + MSB_1) & MASK_32) - MSB_1\n\n            x1 = wrap(0x41C64E6D * self.state)\n            self.state = wrap(x1 + 12345)\n            x2 = wrap(x1 + 0x13038) if self.state < 0 else self.state\n            return ((x2 >> 16) & MASK_32) % 0x7FFF\n\n    @staticmethod\n    def zuc_keystream() -> List[int]:\n        zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)\n        return [struct.unpack(\'>I\', zuc.generate())[0] for _ in range(16)]\n\n    @staticmethod\n    def _xorxor(buffer, x) -> bytes:\n        return bytes(buffer[i] ^ x[i % len(x)] for i in range(len(buffer)))\n\n    @staticmethod\n    def _hashhash(buffer, n: int) -> bytes:\n        result = bytes()\n        for i in range(math.ceil(n / SHA1.digest_size)):\n            result += SHA1.new(buffer).digest()\n        if len(result) >= n:\n            result = result[:n]\n        else:\n            result += b\'\\x00\' * (n - len(result))\n        return result\n\n    @staticmethod\n    def _meowmeow(buffer) -> bytes:\n        def unpad(x):\n            skip = 1 + next((i for i in range(len(x)) if x[i] != 0))\n            return x[skip:]\n\n        if len(buffer) < 43:\n            return bytes()\n\n        x1 = buffer[1:][:SHA1.digest_size]\n        x2 = buffer[SHA1.digest_size + 1:]\n        x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))\n        x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))\n\n        part1, m = (x2[:SHA1.digest_size], x2[SHA1.digest_size:])\n        if part1 != SHA1.new(b\'\\x00\' * SHA1.digest_size).digest():\n            return bytes()\n\n        return unpad(m)\n\n    @staticmethod\n    def rsa_extract(signature: bytes, modulus: bytes) -> bytes:\n        c = int.from_bytes(signature, \'little\')\n        n = int.from_bytes(modulus, \'little\')\n        e = 0x10001\n        m = pow(c, e, n).to_bytes(256, \'little\').rstrip(b\'\\x00\')\n        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))\n\n    @staticmethod\n    def _decrypt_simple1(ciphertext) -> bytes:\n        return bytes(x ^ SIMPLE1_DECRYPT_KEY for x in ciphertext)\n\n    @staticmethod\n    def _decrypt_simple2(ciphertext) -> bytes:\n        class RollingKey:\n            def __init__(self, initial_value: int):\n                self._value = initial_value\n\n            def update(self, x: int) -> int:\n                self._value ^= x\n                return self._value\n\n        assert len(ciphertext) % SIMPLE2_BLOCK_SIZE == 0\n        initial_key, = struct.unpack(\'<I\', SIMPLE2_DECRYPT_KEY)\n        rolling_key = RollingKey(initial_key)\n        plaintext = (\n            struct.pack(\'<I\', rolling_key.update(x)) for x in struct.unpack(f\'<{len(ciphertext) // 4}I\', ciphertext)\n        )\n        return bytes(it.chain.from_iterable(plaintext))\n\n    @staticmethod\n    @lru_cache(maxsize=1)\n    def _derive_sm4_key(file_path: PurePath, encryption_method: int) -> bytes:\n        part1 = file_path.stem.lower()\n        if encryption_method == EM_SM4_2:\n            secret = SM4_SECRET_2\n        elif encryption_method == EM_SM4_4:\n            secret = SM4_SECRET_4\n        elif encryption_method == EM_UNKNOWN_17:\n            index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)\n            secret = SM4_SECRET_NEW[index]\n        else:\n            index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)\n            secret = f\'{SM4_SECRET_NEW[index]}{encryption_method}\'\n        return SHA1.new(str(part1 + secret).encode()).digest()[:SM4.key_length()]\n\n    @staticmethod\n    @lru_cache(maxsize=1)\n    def _sm4_context_for_key(key: bytes) -> SM4:\n        return SM4(key)\n\n    @staticmethod\n    def _decrypt_sm4(ciphertext, file_path: PurePath, encryption_method: int) -> bytes:\n        assert len(ciphertext) % SM4.block_length() == 0\n        key = PakCrypto._derive_sm4_key(file_path, encryption_method)\n        sm4 = PakCrypto._sm4_context_for_key(key)\n        return bytes(\n            it.chain.from_iterable(\n                sm4.decrypt(x) for x in it.batched(ciphertext, SM4.block_length())\n            )\n        )\n\n    @staticmethod\n    def decrypt_index(ciphertext, pak_info: TencentPakInfo) -> bytes:\n        if pak_info.version > 7:\n            key = PakCrypto.rsa_extract(pak_info.packed_key, RSA_MOD_1)\n            iv = PakCrypto.rsa_extract(pak_info.packed_iv, RSA_MOD_1)\n            assert len(key) == 32 and len(iv) == 32\n            aes = AES.new(key, MODE_CBC, iv[:16])\n            return unpad(aes.decrypt(ciphertext), AES.block_size)\n        else:\n            return bytes(PakCrypto._decrypt_simple1(ciphertext))\n\n    @staticmethod\n    def _is_simple1_method(encryption_method: int) -> bool:\n        return encryption_method == EM_SIMPLE1\n\n    @staticmethod\n    def _is_simple2_method(encryption_method: int) -> bool:\n        return encryption_method == EM_SIMPLE2 or encryption_method == 17\n\n    @staticmethod\n    def _is_sm4_method(encryption_method: int) -> bool:\n        return (encryption_method == EM_SM4_2\n                or encryption_method == EM_SM4_4\n                or encryption_method == EM_UNKNOWN_17\n                or encryption_method & EM_SM4_NEW_MASK != 0)\n\n    @staticmethod\n    def align_encrypted_content_size(n: int, encryption_method: int) -> int:\n        if PakCrypto._is_simple2_method(encryption_method):\n            return Misc.align_up(n, SIMPLE2_BLOCK_SIZE)\n        elif PakCrypto._is_sm4_method(encryption_method):\n            return Misc.align_up(n, SM4.block_length())\n        else:\n            return n\n\n    @staticmethod\n    def decrypt_block(ciphertext, file: PurePath, encryption_method: int) -> bytes:\n        if PakCrypto._is_simple1_method(encryption_method):\n            return PakCrypto._decrypt_simple1(ciphertext)\n        elif PakCrypto._is_simple2_method(encryption_method):\n            return PakCrypto._decrypt_simple2(ciphertext)\n        elif PakCrypto._is_sm4_method(encryption_method):\n            return PakCrypto._decrypt_sm4(ciphertext, file, encryption_method)\n        else:\n            raise ValueError(f"Unknown encryption method: {encryption_method}")\n\n    @staticmethod\n    @lru_cache(maxsize=33)\n    def generate_block_indices(n: int, encryption_method: int) -> List[int]:\n        if not PakCrypto._is_sm4_method(encryption_method):\n            return list(range(n))\n        permutation = []\n        lcg = PakCrypto._LCG(n)\n        while len(permutation) != n:\n            x = lcg.next() % n\n            if x not in permutation:\n                permutation.append(x)\n        inverse = [0] * len(permutation)\n        for i, x in enumerate(permutation):\n            inverse[x] = i\n        return inverse\n\nclass PakCompression:\n    @staticmethod\n    @lru_cache(maxsize=33)\n    def _zstd_decompressor(dict: ZstdCompressionDict) -> ZstdDecompressor:\n        return ZstdDecompressor(dict)\n\n    @staticmethod\n    def zstd_dictionary(dict_data) -> ZstdCompressionDict:\n        return ZstdCompressionDict(dict_data, DICT_TYPE_AUTO)\n\n    @staticmethod\n    def decompress_block(block, dict: Optional[ZstdCompressionDict], compression_method: int) -> bytes:\n        if compression_method == CM_ZLIB:\n            try:\n                return zlib.decompress(block)\n            except zlib.error:\n                return block\n        elif compression_method == CM_ZSTD or compression_method == CM_ZSTD_DICT:\n            if compression_method != CM_ZSTD_DICT:\n                dict = None\n            return PakCompression._zstd_decompressor(dict).decompress(block)\n        else:\n            raise ValueError(f"Unknown compression method: {compression_method}")\n\nclass TencentPakFile:\n    def __init__(self, file_path: PurePath, is_od=True):\n        self._file_path = file_path\n        with open(file_path, \'rb\') as file:\n            self._file_content = memoryview(file.read())\n        self._is_od = is_od\n        self._mount_point = PurePath()\n        self._is_zstd_with_dict = \'zsdic\' in str(self._file_path)\n        self._zstd_dict = None\n        self._files: List[TencentPakEntry] = []\n        self._index: Dict[PurePath, Dict[str, TencentPakEntry]] = {}\n        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())\n        self._verify_stem_hash()\n        self._tencent_load_index()\n\n    def _verify_stem_hash(self) -> None:\n        if not self._is_od and self._pak_info.version >= 9:\n            assert self._pak_info.stem_hash == zlib.crc32(self._file_path.stem.encode(\'utf-32le\'))\n\n    def _tencent_load_index(self) -> None:\n        index_data = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]\n        if self._pak_info.index_encrypted:\n            index_data = PakCrypto.decrypt_index(index_data, self._pak_info)\n        else:\n            index_data = index_data\n        self._verify_index_hash(index_data)\n        self._load_index(index_data)\n\n    def _verify_index_hash(self, index_data) -> None:\n        expected_hash = self._pak_info.index_hash\n        if not self._is_od and self._pak_info.version >= 8:\n            assert expected_hash == PakCrypto.rsa_extract(self._pak_info.packed_index_hash, RSA_MOD_2)\n        assert expected_hash == SHA1.new(index_data).digest()\n\n    @staticmethod\n    def _construct_mount_point(mount_point: str) -> PurePath:\n        result = PurePath()\n        for part in PurePath(mount_point).parts:\n            if part != \'..\':\n                result /= part\n        return result\n\n    def _peek_content(self, offset: int, size: int, encryption_method: int) -> memoryview:\n        size = PakCrypto.align_encrypted_content_size(size, encryption_method)\n        return self._file_content[offset:][:size]\n\n    def _peek_block_content(self, block: PakCompressedBlock, encryption_method: int) -> memoryview:\n        size = PakCrypto.align_encrypted_content_size(block.end - block.start, encryption_method)\n        return self._file_content[block.start:][:size]\n\n    def _construct_zstd_dict(self, dict_entry: TencentPakEntry) -> None:\n        assert not self._zstd_dict\n        assert not dict_entry.encrypted\n        assert dict_entry.compression_method == CM_NONE\n        reader = Reader(self._peek_content(dict_entry.offset, dict_entry.size, 0))\n        dict_size = reader.u8()\n        _ = reader.u4()\n        assert dict_size == reader.u4()\n        dict_data = reader.s(dict_size)\n        self._zstd_dict = PakCompression.zstd_dictionary(dict_data)\n\n    def _load_index(self, index_data) -> None:\n        if self._pak_info.version <= 10:\n            raise ValueError(f"Unsupported version: {self._pak_info.version}")\n        reader = Reader(index_data)\n        self._mount_point = self._construct_mount_point(reader.string())\n        self._files = [TencentPakEntry(reader, self._pak_info.version) for _ in range(reader.u4())]\n        for _ in range(reader.u8()):\n            dir_path = PurePath(reader.string())\n            e = {reader.string(): self._files[~reader.i4()] for _ in range(reader.u8())}\n            if self._is_zstd_with_dict and dir_path.name == \'zstddic\':\n                assert len(e) == 1\n                self._construct_zstd_dict(e[[*e.keys()][0]])\n                continue\n            self._index.update({PurePath(dir_path): e})\n\n    def detect_dominant_style(self) -> dict:\n        comp_counter = Counter()\n        enc_counter = Counter()\n        blk_counter = Counter()\n        enc_flag_counter = Counter()\n        total = len(self._files)\n        if total == 0:\n            return {\'comp_method\': CM_ZSTD, \'enc_method\': 0, \'encrypted\': False, \'block_size\': 0x10000}\n        for entry in self._files:\n            comp_counter[entry.compression_method] += 1\n            if entry.encrypted:\n                enc_counter[entry.encryption_method] += 1\n                enc_flag_counter[\'encrypted\'] += 1\n            else:\n                enc_flag_counter[\'plain\'] += 1\n            if entry.compression_block_size:\n                blk_counter[entry.compression_block_size] += 1\n        non_none = [(m,c) for m,c in comp_counter.items() if m != CM_NONE]\n        comp_method = max(non_none, key=lambda x: x[1])[0] if non_none else CM_NONE\n        encrypted = enc_flag_counter.get(\'encrypted\', 0) > enc_flag_counter.get(\'plain\', 0)\n        enc_method = enc_counter.most_common(1)[0][0] if encrypted and enc_counter else 0\n        block_size = blk_counter.most_common(1)[0][0] if blk_counter else 0x10000\n        return {\'comp_method\': comp_method, \'enc_method\': enc_method, \'encrypted\': encrypted, \'block_size\': block_size}\n\n    def list_existing_paths(self) -> List[str]:\n        out = []\n        for dir_path, files in self._index.items():\n            for fname in files.keys():\n                out.append(str(dir_path / fname).replace(\'\\\\\', \'/\').lstrip(\'/\'))\n        return out\n\n    def _make_signature_marker(self, current_offset: int) -> dict:\n        empty_hash = SHA1.new(b\'\').digest()\n        return {\n            \'content_hash\': empty_hash,\n            \'offset\': current_offset,\n            \'uncompressed_size\': 0,\n            \'size\': 0,\n            \'comp_method\': CM_NONE,\n            \'enc_method\': 0,\n            \'encrypted\': False,\n            \'block_size_val\': 0,\n            \'compressed_blocks\': [],\n            \'unk1\': 0,\n            \'unk2\': b\'\\x00\' * 20,\n            \'index_new_sep\': 0,\n            \'_file_name\': \'PATCHED.txt\',\n        }\n\n    @staticmethod\n    def _extract_entry_plain(pak_buffer: memoryview, entry: TencentPakEntry,\n                             file_path_for_crypto: PurePath, zstd_dict) -> bytes:\n        """Extract a single entry\'s plaintext (decrypted + decompressed) bytes."""\n        if entry.compression_method == CM_NONE:\n            sz = PakCrypto.align_encrypted_content_size(entry.size, entry.encryption_method)\n            data = bytes(pak_buffer[entry.offset:][:sz])\n            if entry.encrypted:\n                data = PakCrypto.decrypt_block(data, file_path_for_crypto, entry.encryption_method)\n            return data\n\n        parts = []\n        for real_idx in PakCrypto.generate_block_indices(len(entry.compressed_blocks), entry.encryption_method):\n            block = entry.compressed_blocks[real_idx]\n            bsz = PakCrypto.align_encrypted_content_size(block.end - block.start, entry.encryption_method)\n            blk = bytes(pak_buffer[block.start:][:bsz])\n            if entry.encrypted:\n                blk = PakCrypto.decrypt_block(blk, file_path_for_crypto, entry.encryption_method)\n            dec = PakCompression.decompress_block(blk, zstd_dict, entry.compression_method)\n            parts.append(dec)\n        return b\'\'.join(parts)\n\n    def inject_files(self, inject_plan: list, output_pak: Path, add_signature_marker: bool = True) -> None:\n        """Inject new files into this PAK, producing a new PAK at output_pak."""\n        if not inject_plan:\n            raise ValueError(\'inject_plan is empty — nothing to inject\')\n\n        console.print(Panel(\n            f\'[bold white]💉 CUSTOM INJECT[/bold white]\\n\'\n            f\'[white]Source PAK:[/] [white]{self._file_path.name}[/white]\\n\'\n            f\'[white]Output    :[/] [white]{output_pak.name}[/white]\\n\'\n            f\'[white]Injecting :[/] [white]{len(inject_plan)} new file(s)[/white]\',\n            title=\'INJECT MODE\', border_style=\'magenta\', padding=(0, 2)\n        ))\n\n        console.print(\'\\n[bold white]━━ STEP 1/5 : LOADING INJECT FILES ━━[/bold white]\')\n        work_items = []\n        for i, item in enumerate(inject_plan):\n            if item.get(\'plain_bytes\') is not None:\n                plain = item[\'plain_bytes\']\n            elif item.get(\'src_path\') is not None:\n                try:\n                    plain = Path(item[\'src_path\']).read_bytes()\n                except Exception as e:\n                    console.print(f\'   [white]✗ Cannot read {item["src_path"]}: {e} — skipping[/white]\')\n                    continue\n            else:\n                console.print(f\'   [white]✗ Inject item {i} has no src_path or plain_bytes — skipping[/white]\')\n                continue\n\n            internal = item[\'internal_path\'].replace(\'\\\\\', \'/\').lstrip(\'/\')\n            if not internal:\n                console.print(f\'   [white]✗ Empty internal_path for item {i} — skipping[/white]\')\n                continue\n\n            parts = internal.rsplit(\'/\', 1)\n            if len(parts) == 2:\n                dir_str, file_name = parts[0], parts[1]\n            else:\n                dir_str, file_name = \'\', parts[0]\n\n            work_items.append({\n                \'dir_str\':       dir_str,\n                \'file_name\':     file_name,\n                \'internal_path\': internal,\n                \'plain\':         plain,\n                \'comp_method\':   item[\'comp_method\'],\n                \'enc_method\':    item[\'enc_method\'],\n                \'encrypted\':     bool(item[\'encrypted\']),\n                \'block_size\':    item[\'block_size\'],\n                \'comp_level\':    item.get(\'comp_level\', 19),\n            })\n            console.print(f\'   [white]✨[/] {internal} [dim]({len(plain):,} bytes)[/dim]\')\n\n        if not work_items:\n            raise RuntimeError(\'No valid inject items after loading\')\n        console.print(f\'[white]✔ Loaded {len(work_items)} file(s)[/white]\')\n\n        console.print(\'\\n[bold white]━━ STEP 2/5 : ENCODING INJECT FILES ━━[/bold white]\')\n        keystream = PakCrypto.zuc_keystream()\n        version = self._pak_info.version\n        header_size = TencentPakInfo._mem_size(version)\n        PAK_MAGIC = self._pak_info.magic\n\n        orig_index_offset = self._pak_info.index_offset\n        current_new_offset = orig_index_offset\n        new_data_region = bytearray()\n        new_injected_entries = []\n\n        def _encrypt_plaintext(plaintext, pak_relative_path, encryption_method):\n            if PakCrypto._is_simple1_method(encryption_method):\n                return bytes(b ^ SIMPLE1_DECRYPT_KEY for b in plaintext)\n            elif PakCrypto._is_simple2_method(encryption_method):\n                pad = (-len(plaintext)) % SIMPLE2_BLOCK_SIZE\n                plaintext += b"\\x00" * pad\n                key, = struct.unpack("<I", SIMPLE2_DECRYPT_KEY)\n                rolling = key\n                out = []\n                for x, in struct.iter_unpack("<I", plaintext):\n                    c = rolling ^ x\n                    out.append(c)\n                    rolling ^= c\n                return struct.pack(f"<{len(out)}I", *out)\n            elif PakCrypto._is_sm4_method(encryption_method):\n                key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)\n                sm4 = PakCrypto._sm4_context_for_key(key)\n                pad_len = (-len(plaintext)) % 16\n                if pad_len > 0:\n                    plaintext = plaintext + b\'\\x00\' * pad_len\n                out = bytearray()\n                for i in range(0, len(plaintext), 16):\n                    block = plaintext[i:i+16]\n                    if len(block) < 16:\n                        block = block.ljust(16, b\'\\x00\')\n                    out.extend(sm4.encrypt(block))\n                return bytes(out)\n            return plaintext\n\n        for item in work_items:\n            plain = item[\'plain\']\n            comp_method = item[\'comp_method\']\n            enc_method = item[\'enc_method\']\n            encrypted = item[\'encrypted\']\n            block_size_val = item[\'block_size\']\n            file_path_for_crypto = PurePath(item[\'file_name\'])\n\n            if len(plain) == 0:\n                new_injected_entries.append({\n                    \'content_hash\': SHA1.new(b\'\').digest(),\n                    \'offset\': current_new_offset,\n                    \'uncompressed_size\': 0, \'size\': 0,\n                    \'comp_method\': CM_NONE, \'enc_method\': 0, \'encrypted\': False,\n                    \'block_size_val\': 0, \'compressed_blocks\': [],\n                    \'unk1\': 0, \'unk2\': b\'\\x00\' * 20, \'index_new_sep\': 0,\n                    \'_dir_path\': PurePath(item[\'dir_str\']) if item[\'dir_str\'] else PurePath(),\n                    \'_file_name\': item[\'file_name\'],\n                })\n                continue\n\n            if comp_method == CM_NONE:\n                if encrypted:\n                    aligned_size = PakCrypto.align_encrypted_content_size(len(plain), enc_method)\n                    padded = plain + b\'\\x00\' * (aligned_size - len(plain))\n                    stored_data = _encrypt_plaintext(padded, file_path_for_crypto, enc_method)\n                else:\n                    stored_data = plain\n                new_size = len(stored_data)\n                new_compressed_blocks = []\n            else:\n                chunks = [plain[i:i+block_size_val] for i in range(0, len(plain), block_size_val)]\n                if not chunks: chunks = [b\'\']\n                compressed_chunks = []\n                for chunk in chunks:\n                    comp = None\n                    if comp_method in (CM_ZSTD, CM_ZSTD_DICT):\n                        zstd_dict = self._zstd_dict if comp_method == CM_ZSTD_DICT else None\n                        for lvl in range(22, 0, -1):\n                            try:\n                                c = ZstdCompressor(level=lvl, dict_data=zstd_dict, threads=1)\n                                comp = c.compress(chunk)\n                                break\n                            except: continue\n                    elif comp_method == CM_ZLIB:\n                        comp = zlib.compress(chunk, level=9)\n                    if comp is None: comp = chunk\n                    compressed_chunks.append(comp)\n\n                encrypted_chunks = []\n                for comp_data in compressed_chunks:\n                    if encrypted:\n                        comp_data = _encrypt_plaintext(comp_data, file_path_for_crypto, enc_method)\n                    encrypted_chunks.append(comp_data)\n\n                n_blocks = len(encrypted_chunks)\n                indices = PakCrypto.generate_block_indices(n_blocks, enc_method)\n                physical_blocks = [None] * n_blocks\n                for j, chunk_data in enumerate(encrypted_chunks):\n                    physical_blocks[indices[j]] = chunk_data\n\n                physical_offsets = []\n                block_cursor = current_new_offset\n                for phys_block in physical_blocks:\n                    physical_offsets.append((block_cursor, block_cursor + len(phys_block)))\n                    block_cursor += len(phys_block)\n                new_compressed_blocks = physical_offsets\n                stored_data = b\'\'.join(physical_blocks)\n                new_size = len(stored_data)\n                if encrypted:\n                    aligned_total = PakCrypto.align_encrypted_content_size(new_size, enc_method)\n                    if aligned_total > new_size:\n                        stored_data = stored_data + b\'\\x00\' * (aligned_total - new_size)\n                        new_size = aligned_total\n\n            new_content_hash = SHA1.new(stored_data).digest()\n            new_data_region.extend(stored_data)\n\n            new_injected_entries.append({\n                \'content_hash\': new_content_hash,\n                \'offset\': current_new_offset,\n                \'uncompressed_size\': len(plain),\n                \'size\': new_size,\n                \'comp_method\': comp_method,\n                \'enc_method\': enc_method if encrypted else 0,\n                \'encrypted\': encrypted,\n                \'block_size_val\': block_size_val,\n                \'compressed_blocks\': new_compressed_blocks,\n                \'unk1\': 0, \'unk2\': b\'\\x00\' * 20, \'index_new_sep\': 0,\n                \'_dir_path\': PurePath(item[\'dir_str\']) if item[\'dir_str\'] else PurePath(),\n                \'_file_name\': item[\'file_name\'],\n            })\n            current_new_offset += new_size\n\n        console.print(f\'[white]✔ Encoded {len(new_injected_entries)} file(s)[/white]\')\n\n        new_entries = []\n        entry_to_path = {}\n        for dir_path, files in self._index.items():\n            for fname, entry in files.items():\n                entry_to_path[id(entry)] = (dir_path, fname)\n        for i, entry in enumerate(self._files):\n            dir_path, fname = entry_to_path.get(id(entry), (PurePath(), f\'unknown_{i}\'))\n            new_entries.append({\n                \'content_hash\': entry.content_hash,\n                \'offset\': entry.offset,\n                \'uncompressed_size\': entry.uncompressed_size,\n                \'size\': entry.size,\n                \'comp_method\': entry.compression_method,\n                \'enc_method\': entry.encryption_method if entry.encrypted else 0,\n                \'encrypted\': entry.encrypted,\n                \'block_size_val\': entry.compression_block_size,\n                \'compressed_blocks\': [(b.start, b.end) for b in entry.compressed_blocks],\n                \'unk1\': entry.unk1, \'unk2\': entry.unk2,\n                \'index_new_sep\': entry.index_new_sep,\n            })\n        new_entries.extend(new_injected_entries)\n\n        if add_signature_marker:\n            marker_already_present = False\n            for dp, files_dict in self._index.items():\n                if dp.name == \'ALVSIA\' and \'PATCHED.txt\' in files_dict:\n                    marker_already_present = True\n                    break\n            if not marker_already_present:\n                empty_hash = SHA1.new(b\'\').digest()\n                new_entries.append({\n                    \'content_hash\': empty_hash,\n                    \'offset\': current_new_offset,\n                    \'uncompressed_size\': 0,\n                    \'size\': 0,\n                    \'comp_method\': CM_NONE,\n                    \'enc_method\': 0,\n                    \'encrypted\': False,\n                    \'block_size_val\': 0,\n                    \'compressed_blocks\': [],\n                    \'unk1\': 0,\n                    \'unk2\': b\'\\x00\' * 20,\n                    \'index_new_sep\': 0,\n                    \'_dir_path\': PurePath(\'ALVSIAxPUBG\'),\n                    \'_file_name\': \'PATCHED.txt\',\n                })\n\n        index_data = bytearray()\n        raw_orig_index = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]\n        orig_index_decoded = PakCrypto.decrypt_index(bytes(raw_orig_index), self._pak_info)\n        orig_reader = Reader(orig_index_decoded)\n        orig_mount_len = orig_reader.i4()\n        orig_mount_bytes = bytes(orig_reader.s(orig_mount_len))\n        index_data.extend(struct.pack(\'<I\', orig_mount_len))\n        index_data.extend(orig_mount_bytes)\n        index_data.extend(struct.pack(\'<I\', len(new_entries)))\n\n        for item in new_entries:\n            index_data.extend(item[\'content_hash\'])\n            if version <= 1: index_data.extend(struct.pack(\'<Q\', 0))\n            index_data.extend(struct.pack(\'<Q\', item[\'offset\']))\n            index_data.extend(struct.pack(\'<Q\', item[\'uncompressed_size\']))\n            index_data.extend(struct.pack(\'<I\', item[\'comp_method\'] & CM_MASK))\n            index_data.extend(struct.pack(\'<Q\', item[\'size\']))\n            if version >= 5:\n                index_data.extend(struct.pack(\'<B\', item[\'unk1\']))\n                index_data.extend(item[\'unk2\'] if item[\'unk2\'] else b\'\\x00\' * 20)\n            if item[\'comp_method\'] != CM_NONE and version >= 3:\n                index_data.extend(struct.pack(\'<I\', len(item[\'compressed_blocks\'])))\n                for (start, end) in item[\'compressed_blocks\']:\n                    index_data.extend(struct.pack(\'<Q\', start))\n                    index_data.extend(struct.pack(\'<Q\', end))\n            if version >= 4:\n                index_data.extend(struct.pack(\'<I\', item[\'block_size_val\']))\n                index_data.extend(struct.pack(\'<B\', 1 if item[\'encrypted\'] else 0))\n            if version >= 12:\n                index_data.extend(struct.pack(\'<I\', item[\'enc_method\']))\n                index_data.extend(struct.pack(\'<I\', item[\'index_new_sep\']))\n\n        file_to_dirname = {}\n        for dir_path, files_dict in self._index.items():\n            dir_str = dir_path.as_posix()\n            for fname, entry in files_dict.items():\n                for i, fe in enumerate(self._files):\n                    if id(fe) == id(entry):\n                        file_to_dirname[i] = (dir_str, fname)\n                        break\n        for i, item in enumerate(new_entries):\n            if i not in file_to_dirname:\n                if \'_dir_path\' in item:\n                    file_to_dirname[i] = (item[\'_dir_path\'].as_posix(), item[\'_file_name\'])\n                else:\n                    file_to_dirname[i] = (\'\', f\'file_{i}\')\n\n        all_dirs = []\n        dir_to_files = {}\n        for dir_path in self._index.keys():\n            ds = dir_path.as_posix()\n            all_dirs.append(ds)\n            dir_to_files[ds] = []\n        for i, item in enumerate(new_entries):\n            ds, fn = file_to_dirname[i]\n            if ds not in dir_to_files:\n                dir_to_files[ds] = []\n                all_dirs.append(ds)\n            dir_to_files[ds].append((fn, i))\n\n        index_data.extend(struct.pack(\'<Q\', len(all_dirs)))\n        for dir_str in all_dirs:\n            files_list = dir_to_files[dir_str]\n            if not dir_str or dir_str == \'.\':\n                index_data.extend(struct.pack(\'<I\', 0))\n            else:\n                if not dir_str.endswith(\'/\'): dir_str_with_slash = dir_str + \'/\'\n                else: dir_str_with_slash = dir_str\n                dir_bytes = dir_str_with_slash.encode(\'utf-8\') + b\'\\x00\'\n                index_data.extend(struct.pack(\'<I\', len(dir_bytes)))\n                index_data.extend(dir_bytes)\n            index_data.extend(struct.pack(\'<Q\', len(files_list)))\n            for file_name, fi in files_list:\n                name_bytes = file_name.encode(\'utf-8\') + b\'\\x00\'\n                index_data.extend(struct.pack(\'<I\', len(name_bytes)))\n                index_data.extend(name_bytes)\n                index_data.extend(struct.pack(\'<i\', -fi - 1))\n        index_data.extend(b\'\\x1d\\x00\\x00\\x00\\x2e\\x2e\')\n\n        index_hash = SHA1.new(bytes(index_data)).digest()\n\n        if version > 7 and self._pak_info.index_encrypted:\n            key = PakCrypto.rsa_extract(self._pak_info.packed_key, RSA_MOD_1)\n            iv = PakCrypto.rsa_extract(self._pak_info.packed_iv, RSA_MOD_1)\n            assert len(key) == 32 and len(iv) == 32\n            padded = pad(bytes(index_data), AES.block_size)\n            aes = AES.new(key, MODE_CBC, iv[:16])\n            encrypted_index = aes.encrypt(padded)\n        elif self._pak_info.index_encrypted:\n            encrypted_index = bytes(b ^ SIMPLE1_DECRYPT_KEY for b in bytes(index_data))\n        else:\n            encrypted_index = bytes(index_data)\n\n        index_size = len(encrypted_index)\n        new_index_offset = orig_index_offset + len(new_data_region)\n\n        encrypted_magic = PAK_MAGIC ^ keystream[2]\n        key_stream_hash = struct.pack(\'<5I\', *keystream[4:][:5])\n        encrypted_index_hash = bytes(a ^ b for a, b in zip(index_hash, key_stream_hash))\n        encrypted_index_size = index_size ^ ((keystream[10] << 32) | keystream[11])\n        encrypted_index_offset = new_index_offset ^ ((keystream[0] << 32) | keystream[1])\n        encrypted_flag_byte = (1 if self._pak_info.index_encrypted else 0) ^ (keystream[3] & 0xFF)\n\n        orig_data_region = bytearray(self._file_content[0:orig_index_offset])\n        output_pak.parent.mkdir(parents=True, exist_ok=True)\n        with open(output_pak, \'wb\') as f:\n            f.write(bytes(orig_data_region))\n            f.write(bytes(new_data_region))\n            f.write(encrypted_index)\n            if version >= 7:\n                key_unk1 = struct.pack(\'<8I\', *keystream[7:][:8])\n                unk1_plain = self._pak_info.unk1 if self._pak_info.unk1 else b\'\\x00\' * 32\n                encrypted_unk1 = bytes(a ^ b for a, b in zip(unk1_plain, key_unk1))\n                f.write(encrypted_unk1)\n            if version >= 8:\n                f.write(self._pak_info.packed_key if self._pak_info.packed_key else b\'\\x00\' * 256)\n                f.write(self._pak_info.packed_iv if self._pak_info.packed_iv else b\'\\x00\' * 256)\n                f.write(self._pak_info.packed_index_hash if self._pak_info.packed_index_hash else b\'\\x00\' * 256)\n            if version >= 9:\n                f.write(struct.pack(\'<I\', (self._pak_info.stem_hash or 0) ^ keystream[8]))\n                f.write(struct.pack(\'<I\', (self._pak_info.unk2 or 0) ^ keystream[9]))\n            if version >= 12:\n                f.write(self._pak_info.content_org_hash if self._pak_info.content_org_hash else b\'\\x00\' * 20)\n            f.write(struct.pack(\'<B\', encrypted_flag_byte))\n            f.write(struct.pack(\'<I\', encrypted_magic))\n            f.write(struct.pack(\'<I\', version))\n            if version >= 6:\n                f.write(encrypted_index_hash)\n            else:\n                f.write(b\'\\x00\' * 20)\n            f.write(struct.pack(\'<Q\', encrypted_index_size))\n            f.write(struct.pack(\'<Q\', encrypted_index_offset))\n\n        console.print(Panel(\n            f\'[bold white]🎉 INJECT COMPLETE![/bold white]\\n\\n\'\n            f\'[white]Output  :[/] [white]{output_pak.name}[/white]\',\n            title=\'✅ SUCCESS\', border_style=\'green\', padding=(1, 2)\n        ))\n\ndef human_size(size: int) -> str:\n    for unit in [\'B\', \'KB\', \'MB\', \'GB\', \'TB\']:\n        if size < 1024.0:\n            return f"{size:.2f} {unit}"\n        size /= 1024.0\n    return f"{size:.2f} PB"\n\ndef _load_bgmi_path_index() -> Dict[str, List[str]]:\n    """\n    Load PUBG.csv from the \'index\' subfolder next to the tool.\n    Returns a dict: lowercase_filename -> [list of full internal paths].\n    Supports hundreds of thousands of entries via streaming read.\n    """\n    # Try multiple candidate locations for the index folder\n    script_dir = Path(__file__).resolve().parent\n    candidates = [\n        script_dir / "index" / "PUBG.csv",\n        BASE_DIR / "index" / "PUBG.csv",\n    ]\n\n    csv_path: Optional[Path] = None\n    for c in candidates:\n        if c.exists():\n            csv_path = c\n            break\n\n    if csv_path is None:\n        return {}\n\n    index: Dict[str, List[str]] = {}\n    try:\n        with open(csv_path, "r", encoding="utf-8", errors="replace") as fh:\n            first = True\n            for line in fh:\n                line = line.strip().strip("\\r\\n")\n                if not line:\n                    continue\n                if first:\n                    first = False\n                    # Skip header row (FilePath)\n                    if line.lower() == "filepath":\n                        continue\n                internal = line.replace("\\\\", "/").lstrip("/")\n                fname = Path(internal).name.lower()\n                index.setdefault(fname, []).append(internal)\n    except Exception:\n        pass\n\n    return index\n\ndef _resolve_path_from_index(\n    file_path: Path,\n    index: Dict[str, List[str]],\n    already_resolved: Dict[str, str],\n) -> Optional[str]:\n    """\n    Given a local file path, try to find its canonical internal PAK path\n    from the pre-built BGMI index.\n\n    Resolution priority:\n      1. Exact filename match with a unique result -> use it\n      2. Multiple matches -> try to narrow by stem+ext, then by parent folder hint\n      3. No match -> return None (caller will fall back to manual path)\n    """\n    fname_lower = file_path.name.lower()\n\n    # Cache hit\n    if fname_lower in already_resolved:\n        return already_resolved[fname_lower]\n\n    matches = index.get(fname_lower, [])\n\n    if not matches:\n        return None\n\n    if len(matches) == 1:\n        result = matches[0]\n        already_resolved[fname_lower] = result\n        return result\n\n    # --- Ambiguous: multiple paths share the same filename ---\n    # Strategy A: match by the immediate parent directory name\n    parent_hint = file_path.parent.name.lower()\n    if parent_hint:\n        narrowed = [m for m in matches if Path(m).parent.name.lower() == parent_hint]\n        if len(narrowed) == 1:\n            result = narrowed[0]\n            already_resolved[fname_lower] = result\n            return result\n        if narrowed:\n            matches = narrowed  # still ambiguous but smaller set\n\n    # Strategy B: pick the shortest path (most likely a base asset, not a variant)\n    result = min(matches, key=lambda p: len(p))\n    already_resolved[fname_lower] = result\n    return result\n\ndef _create_star_pak_workspace(pak_stem: str) -> tuple:\n    """Use the shared ALVSIA_TOOL folders directly.\n\n    No per-PAK workspace is created.\n    Source/edit files come from COMPILED and generated PAKs go to PAK_RESULT.\n    """\n    workspace_root = BASE_DIR\n    custom_files_dir = BASE_DIR / "COMPILED"\n    result_pak_dir = BASE_DIR / "PAK_RESULT"\n    for folder in (custom_files_dir, result_pak_dir):\n        folder.mkdir(parents=True, exist_ok=True)\n    return workspace_root, custom_files_dir, result_pak_dir\n\ndef _patch_output_stem_hash(output_pak: Path) -> bool:\n    """Update Tencent PAK stem_hash when the output PAK was custom-renamed."""\n    output_pak = Path(output_pak)\n    data = bytearray(output_pak.read_bytes())\n    if len(data) < 45:\n        return False\n    version = struct.unpack_from(\'<I\', data, len(data) - 41)[0]\n    if version < 9:\n        return True\n    ks = PakCrypto.zuc_keystream()\n    after = 4 + 4 + 45 + (20 if version >= 12 else 0)\n    pos = len(data) - after\n    if pos < 0 or pos + 4 > len(data):\n        raise RuntimeError(\'Invalid PAK footer while patching stem hash.\')\n    stem_hash = zlib.crc32(output_pak.stem.encode(\'utf-32le\')) & 0xffffffff\n    struct.pack_into(\'<I\', data, pos, stem_hash ^ ks[8])\n    output_pak.write_bytes(data)\n    return True\n\ndef run_inject():\n    console.print("[white]Auto-detects internal PAK path from PUBG.csv index[/white]")\n\n    out_path = BASE_DIR\n\n    # ── PAK file selection (early — needed to derive workspace name) ─────────\n    console.print("[white]🔍 Searching for PAK files...[/white]")\n    pak_files = [f for f in PAK_ORIGINAL_DIR.iterdir() if f.name.lower().endswith(".pak")]\n\n    if not pak_files:\n        console.print("[bold white]❌ No PAK file found in folder![/bold white]")\n        console.print(f"[white]📁 Please put a PAK file in: {PAK_ORIGINAL_DIR}[/white]")\n        flush_stdin()\n        safe_input("\\nPress Enter to continue...")\n        return\n\n    if len(pak_files) == 1:\n        pak_path = pak_files[0]\n        console.print(f"[white]✅ Found PAK: {pak_path.name}[/white]")\n    else:\n        console.print(f"[white]⚠️ Multiple PAK files found:[/white]")\n        for i, pak in enumerate(pak_files, 1):\n            console.print(f"  [{i}] {pak.name}")\n        console.print("\\n[bold white]Enter number to select:[/bold white]")\n        try:\n            choice_pak = int(safe_input("> ").strip())\n            if 1 <= choice_pak <= len(pak_files):\n                pak_path = pak_files[choice_pak - 1]\n                console.print(f"[white]✅ Selected: {pak_path.name}[/white]")\n            else:\n                console.print("[bold white]❌ Invalid choice![/bold white]")\n                flush_stdin()\n                safe_input("\\nPress Enter to continue...")\n                return\n        except Exception:\n            console.print("[bold white]❌ Invalid input![/bold white]")\n            flush_stdin()\n            safe_input("\\nPress Enter to continue...")\n            return\n\n    # ── Use shared ALVSIA_TOOL folders ─────────────────────────────────────\n    workspace_root, custom_files_dir, result_pak_dir = \\\n        _create_star_pak_workspace(pak_path.stem)\n\n    console.print(\n        f"\\n[bold white]📁 ALVSIA_TOOL:[/bold white] [white]{workspace_root.name}[/white]"\n    )\n    console.print(f"  [dim]├── COMPILED/  ← drop mod files here[/dim]")\n    console.print(f"  [dim]└── PAK_RESULT/    ← modded PAK output[/dim]")\n\n    # edit_dir is now the COMPILED subfolder inside workspace\n    edit_dir = custom_files_dir\n\n    # ── Folder existence checks ──────────────────────────────────────────────\n    files_in_edit = [\n        f for f in edit_dir.rglob("*")\n        if f.is_file() and f.name not in ["pak_manifest.json", ".DS_Store"]\n    ]\n    if not files_in_edit:\n        console.print(f"\\n[bold white]⚠ COMPILED folder is empty![/bold white]")\n        console.print(f"[white]📁 Drop your mod files into:[/white]")\n        console.print(f"  [white]{edit_dir}[/white]")\n        console.print("[dim]Then run Custom Inject again.[/dim]")\n        flush_stdin()\n        safe_input("\\nPress Enter to continue...")\n        return\n\n    # ── Load BGMI path index ─────────────────────────────────────────────────\n    console.print("\\n[bold #FF00FF]📖 Loading PUBGM path index...[/bold #FF00FF]")\n    bgmi_index = _load_bgmi_path_index()\n\n    if bgmi_index:\n        console.print(\n            f"[white]✅ Index loaded — {len(bgmi_index):,} unique filenames mapped[/white]"\n        )\n        use_auto_path = True\n    else:\n        console.print(\n            "[white]⚠ PUBG.csv not found in \'index/\' folder — falling back to manual path[/white]"\n        )\n        console.print(\n            "[dim]Tip: place PUBG.csv inside a folder named \'index\' next to the tool[/dim]"\n        )\n        use_auto_path = False\n\n    # ── Fallback manual path (used when index is missing or file not found) ──\n    fallback_path: Optional[str] = None\n    if not use_auto_path:\n        console.print("\\n[bold white]Enter Target Repacking Path in PAK:[/bold white]")\n        console.print("[dim](Press Enter for default: Content/Lua/)[/dim]")\n        console.print("[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/[/dim]")\n        raw = safe_input("> ").strip()\n        flush_stdin()\n        if not raw:\n            fallback_path = "Content/Lua/"\n        else:\n            fallback_path = raw if raw.endswith("/") else raw + "/"\n        console.print(f"[white]🎯 Fallback path: {fallback_path}[/white]")\n\n    # ── Build inject plan ────────────────────────────────────────────────────\n    try:\n        console.print("[white]📦 Loading PAK file...[/white]")\n        pak = TencentPakFile(PurePath(pak_path))\n        default_output_name = pak_path.name\n        console.print("\\n[bold #FF00FF]📝 Custom output PAK name[/bold #FF00FF]")\n        console.print(f"[dim]Default: {default_output_name}[/dim]")\n        output_name = safe_input("Output name: ").strip() or default_output_name\n        output_name = Path(output_name).name\n        if not output_name.lower().endswith(".pak"):\n            output_name += ".pak"\n        output_name = re.sub(r\'[<>:"/\\\\|?*\\x00-\\x1f]\', \'_\', output_name)\n        # Output modded PAK goes into PAK_RESULT/ folder\n        output_pak = result_pak_dir / output_name\n\n        inject_folder = edit_dir\n        files = [\n            f for f in inject_folder.rglob("*")\n            if f.is_file() and f.name not in ["pak_manifest.json", ".DS_Store"]\n        ]\n\n        if not files:\n            console.print("[white]No files to inject.[/white]")\n            flush_stdin()\n            safe_input("\\nPress Enter to continue...")\n            return\n\n        dominant = pak.detect_dominant_style()\n        console.print(\n            f"[white]Dominant style: comp={dominant[\'comp_method\']}, "\n            f"enc={dominant[\'enc_method\']}, encrypted={dominant[\'encrypted\']}, "\n            f"block={dominant[\'block_size\']}[/white]"\n        )\n\n        # ── REPACK OVERRIDE: PAK-aware config ───────────────────────────────\n        pak_name_lower = pak_path.name.lower()\n        if "res_pufferpatch" in pak_name_lower:\n            dominant["comp_method"] = 1       # CM_ZLIB\n            dominant["enc_method"]  = 47      # SM4_NEW(47)\n            dominant["encrypted"]   = True\n            dominant["block_size"]  = 54326\n            console.print(\n                f"[bold white]⚡ res_pufferpatch override: "\n                f"comp=ZLIB(1), enc=SM4_NEW(47), encrypted=True, block=54326[/bold white]"\n            )\n        else:\n            # game_patch and all other PAKs — keep dominant style as-is\n            console.print(\n                f"[bold white]⚡ Using detected dominant style (no override)[/bold white]"\n            )\n        # ────────────────────────────────────────────────────────────────────\n\n        inject_plan = []\n        resolution_cache: Dict[str, str] = {}   # fname_lower -> resolved internal path\n        unresolved_files: List[Path] = []\n\n        console.print("\\n[bold #FF00FF]🧭 Resolving internal PAK paths...[/bold #FF00FF]")\n\n        for f in files:\n            internal_path: Optional[str] = None\n\n            # Keep PUBG.csv behavior unchanged for non-Lua files.\n            # Only COMPILED Lua files use a manual internal PAK path.\n            if f.suffix.lower() == \'.lua\':\n                console.print(f"\\n[bold white]Manual path needed for Lua:[/bold white] {f.name}")\n                console.print("[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/{file.lua}[/dim]")\n                manual = safe_input(f"  Internal path for {f.name}: ").strip().replace(\'\\\\\', \'/\')\n                flush_stdin()\n                if manual:\n                    internal_path = manual.lstrip(\'/\')\n                    console.print(f"  [white]✓[/white] {f.name} → {internal_path}")\n                else:\n                    console.print(f"  [white]✗ Skipping {f.name}[/white]")\n                    continue\n\n            if internal_path is None and use_auto_path:\n                resolved = _resolve_path_from_index(f, bgmi_index, resolution_cache)\n                if resolved:\n                    internal_path = resolved\n                    console.print(\n                        f"  [white]✓[/white] [white]{f.name}[/white] "\n                        f"[dim]→ {internal_path}[/dim]"\n                    )\n                else:\n                    console.print(\n                        f"  [white]⚠[/white] [white]{f.name}[/white] "\n                        f"[dim]not found in index[/dim]"\n                    )\n                    unresolved_files.append(f)\n\n            if internal_path is None:\n                # Use fallback: either manual path or relative path inside inject_folder\n                if fallback_path:\n                    rel = str(f.relative_to(inject_folder)).replace("\\\\", "/")\n                    internal_path = (\n                        fallback_path + rel\n                        if not rel.startswith(fallback_path)\n                        else rel\n                    )\n                else:\n                    # auto mode but file not in index — ask user for this specific file\n                    console.print(\n                        f"\\n[bold white]Manual path needed for:[/bold white] {f.name}"\n                    )\n                    console.print("[dim]Press Enter to skip this file[/dim]")\n                    manual = safe_input(f"  Internal path for {f.name}: ").strip()\n                    flush_stdin()\n                    if not manual:\n                        console.print(f"  [white]✗ Skipping {f.name}[/white]")\n                        continue\n                    internal_path = manual.replace("\\\\", "/").lstrip("/")\n\n            inject_plan.append({\n                "src_path":      f,\n                "internal_path": internal_path,\n                "comp_method":   dominant["comp_method"],\n                "enc_method":    dominant["enc_method"],\n                "encrypted":     dominant["encrypted"],\n                "block_size":    dominant["block_size"],\n            })\n\n        # ── Summary before inject ────────────────────────────────────────────\n        console.print("\\n[bold #FF00FF]📊 Inject Summary:[/bold #FF00FF]")\n        console.print(f"  [white]✓ Resolved  : {len(inject_plan)} file(s)[/white]")\n        if unresolved_files and not fallback_path:\n            skipped = len(files) - len(inject_plan)\n            if skipped:\n                console.print(f"  [white]✗ Skipped   : {skipped} file(s)[/white]")\n\n        if not inject_plan:\n            console.print("[bold white]❌ Nothing to inject — aborting.[/bold white]")\n            flush_stdin()\n            safe_input("\\nPress Enter to continue...")\n            return\n\n        # Print the resolved plan as a table\n        table = Table(title="Inject Plan", show_lines=False, box=None)\n        table.add_column("File", style="#FF00AA", no_wrap=True)\n        table.add_column("→ Internal PAK Path", style="#FFFF00")\n        for item in inject_plan:\n            table.add_row(\n                Path(str(item["src_path"])).name,\n                item["internal_path"],\n            )\n        console.print(table)\n\n        # ── Confirm ─────────────────────────────────────────────────────────\n        console.print("\\n[bold white]Proceed with inject? (Y/n):[/bold white]")\n        confirm = safe_input("> ").strip().lower()\n        flush_stdin()\n        if confirm == "n":\n            console.print("[white]Inject cancelled.[/white]")\n            return\n\n        console.print("[white]🔄 Running inject...[/white]")\n        pak.inject_files(inject_plan, Path(output_pak))\n        _patch_output_stem_hash(Path(output_pak))\n        console.print(f"\\n[bold white]✅ Inject complete![/bold white]")\n        console.print(\n            f"\\n[bold white]📁 ALVSIA_TOOL/[/bold white]"\n        )\n        console.print(f"  [white]├── COMPILED/[/white]  [dim]← your mod files[/dim]")\n        console.print(f"  [bold white]└── PAK_RESULT/{output_name}[/bold white]  [dim]← modded PAK[/dim]")\n        console.print(f"\\n[white]Processed {len(inject_plan)} file(s).[/white]")\n\n    except Exception as e:\n        console.print(f"[bold white]❌ Error: {e}[/bold white]")\n        import traceback\n        traceback.print_exc()\n\n    flush_stdin()\n\ndef print_inject_banner():\n    os.system(\'clear\' if os.name == \'posix\' else \'cls\')\n    now = datetime.now()\n    CY = "\x1b[1;37m"; GD = "\x1b[1;33m"; WH = "\x1b[1;37m"\n    GR = "\x1b[1;32m"; DM = "\x1b[2m"; RS = "\x1b[0m"\n    print()\n    print(f\'  {CY}S A M E E R _ B U I L D _ P A K{RS}   {GD}v1.0{RS}\')\n    print(f\'  {DM}ALVSIA_TOOL / COMPILED → PAK_RESULT  |  Termux{RS}\')\n    print(f\'  {GD}{now.strftime("%d-%m-%Y")}{RS}  {CY}{now.strftime("%H:%M:%S")}{RS}\')\n    print()\n\ndef _list_pak_contents(pak_files):\n    if not pak_files:\n        console.print("[white]❌ No PAK files found in PAK_ORIGINAL![/white]")\n        flush_stdin()\n        safe_input("\\nPress Enter to continue...")\n        return\n\n    console.print("\\n[white]Select PAK file to list:[/white]")\n    for i, p in enumerate(pak_files, 1):\n        console.print(f"  [{i}] {p.name} ({human_size(p.stat().st_size)})")\n    try:\n        choice = int(safe_input("> ").strip())\n        flush_stdin()\n        if 1 <= choice <= len(pak_files):\n            pak_path = pak_files[choice - 1]\n        else:\n            console.print("[white]Invalid choice.[/white]")\n            return\n    except:\n        console.print("[white]Invalid input.[/white]")\n        return\n\n    console.print(f"\\n[white]📦 Loading {pak_path.name}...[/white]")\n    try:\n        pak = TencentPakFile(PurePath(pak_path))\n        paths = pak.list_existing_paths()\n        console.print(f"[white]✅ {len(paths):,} file(s) found[/white]")\n\n        table = Table(title=f"PAK Contents: {pak_path.name}", show_lines=False, box=None)\n        table.add_column("#", style="dim", width=6)\n        table.add_column("Internal Path", style="#FF00AA")\n\n        for idx, p in enumerate(paths, 1):\n            table.add_row(str(idx), p)\n\n        console.print(table)\n\n        console.print(f"\\n[dim]Total: {len(paths):,} files[/dim]")\n    except Exception as e:\n        console.print(f"[white]❌ Error loading PAK: {e}[/white]")\n\n    flush_stdin()\n    safe_input("\\nPress Enter to continue...")\n\ndef _clean_workspaces(star_dirs):\n    if not star_dirs:\n        console.print("[white]⚠ No ALVSIA_TOOL ALVSIA_TOOL folders found.[/white]")\n    else:\n        console.print(f"[white]Found {len(star_dirs)} workspace folder(s):[/white]")\n        for d in star_dirs:\n            console.print(f"  [dim]• {d.name}[/dim]")\n        console.print("\\n[white]Delete all? (y/N):[/white]")\n        confirm = safe_input("> ").strip().lower()\n        flush_stdin()\n        if confirm == "y":\n            removed = 0\n            for d in star_dirs:\n                try:\n                    shutil.rmtree(d)\n                    console.print(f"  [white]✓ Removed {d.name}[/white]")\n                    removed += 1\n                except Exception as e:\n                    console.print(f"  [white]✗ Error removing {d.name}: {e}[/white]")\n            console.print(f"\\n[white]✔ Cleaned {removed} workspace(s).[/white]")\n        else:\n            console.print("[dim]Cancelled.[/dim]")\n\n    flush_stdin()\n    safe_input("\\nPress Enter to continue...")\n\n\n# ============================================================\n# CUSTOM INJECT ENGINES\n# 1 = STAR inject_files()\n# 2 = s.py REPACK_LUA_PAK engine\n# 3 = s.py BUILD_NEW_PAK engine\n# ============================================================\ndef _encrypt_plaintext(plaintext: bytes, pak_relative_path: PurePath, encryption_method: int) -> bytes:\n    """Encode file payload using the same crypto mapping expected by the PAK engine."""\n    if PakCrypto._is_simple1_method(encryption_method):\n        return bytes((b ^ SIMPLE1_DECRYPT_KEY for b in plaintext))\n    if PakCrypto._is_simple2_method(encryption_method):\n        pad_len = (-len(plaintext)) % SIMPLE2_BLOCK_SIZE\n        if pad_len:\n            plaintext += b"\\x00" * pad_len\n        (key,) = struct.unpack(\'<I\', SIMPLE2_DECRYPT_KEY)\n        rolling = key\n        out = []\n        for (x,) in struct.iter_unpack(\'<I\', plaintext):\n            c = rolling ^ x\n            out.append(c)\n            rolling ^= c\n        return struct.pack(f\'<{len(out)}I\', *out) if out else b\'\'\n    if PakCrypto._is_sm4_method(encryption_method):\n        key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)\n        sm4 = PakCrypto._sm4_context_for_key(key)\n        pad_len = (-len(plaintext)) % 16\n        if pad_len:\n            plaintext += b"\\x00" * pad_len\n        out = bytearray()\n        for i in range(0, len(plaintext), 16):\n            out.extend(sm4.encrypt(plaintext[i:i + 16].ljust(16, b"\\x00")))\n        return bytes(out)\n    return plaintext\n\ndef _best_compress(chunk, cm, zstd_dict=None):\n    if cm == CM_ZLIB:\n        return zlib.compress(chunk, 9)\n    if cm in (CM_ZSTD, CM_ZSTD_DICT):\n        zd = zstd_dict if cm == CM_ZSTD_DICT else None\n        for lvl in [22, 19, 16, 13, 10, 7, 4, 1]:\n            try:\n                return ZstdCompressor(level=lvl, dict_data=zd, threads=1).compress(chunk)\n            except Exception:\n                continue\n    return chunk\n\ndef _block_permutation(n_chunks: int, encryption_method: int):\n    return PakCrypto.generate_block_indices(n_chunks, encryption_method)\n\ndef _pw_string(s):\n    if not s: return struct.pack(\'<i\', 0)\n    b = s.encode(\'utf-8\') + b\'\\x00\'\n    return struct.pack(\'<i\', len(b)) + b\n\ndef _pw_entry(e, v):\n    w = bytearray(e.content_hash)\n    w += struct.pack(\'<Q\', e.offset)\n    w += struct.pack(\'<Q\', e.uncompressed_size)\n    w += struct.pack(\'<I\', e.compression_method)\n    w += struct.pack(\'<Q\', e.size)\n    if v >= 5:\n        w += bytes([e.unk1])\n        w += e.unk2\n    if e.compression_method != CM_NONE and v >= 3:\n        w += struct.pack(\'<I\', len(e.compressed_blocks))\n        for b in e.compressed_blocks:\n            w += struct.pack(\'<QQ\', b.start, b.end)\n    if v >= 4:\n        w += struct.pack(\'<I\', e.compression_block_size)\n        w += bytes([1 if e.encrypted else 0])\n    if v >= 12:\n        w += struct.pack(\'<II\', e.encryption_method, e.index_new_sep)\n    return bytes(w)\n\ndef _get_all_dirs_and_mp(pak_file):\n    raw = bytes(pak_file._file_content[\n        pak_file._pak_info.index_offset:][:pak_file._pak_info.index_size])\n    if pak_file._pak_info.index_encrypted:\n        try:\n            raw = PakCrypto.decrypt_index(raw, pak_file._pak_info)\n        except:\n            pass\n    r = Reader(raw)\n    mp = r.string()\n    num_files = r.u4()\n    for _ in range(num_files):\n        TencentPakEntry(r, pak_file._pak_info.version)\n    dirs = {}\n    for _ in range(r.u8()):\n        dp = r.string()\n        cnt = r.u8()\n        d = {}\n        for _ in range(cnt):\n            fname = r.string()\n            idx = ~r.i4()\n            if 0 <= idx < len(pak_file._files):\n                d[fname] = (idx, pak_file._files[idx])\n        dirs[dp] = d\n    return mp, dirs\n\ndef repack_pak_file_full(pak_file, edited_root, output_path, target_path=None, force_add=False, path_map=None):\n    import copy as _cp\n    edit_files = [p for p in Path(edited_root).rglob(\'*\') if p.is_file()]\n    if not edit_files:\n        console.print(\'[white]No files in EDIT folder.[/]\')\n        return 0\n    version = pak_file._pak_info.version\n    keystream = PakCrypto.zuc_keystream()\n    orig_fc = pak_file._file_content\n    mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)\n\n    def _norm_dir(tp):\n        if not tp:\n            return None\n        tp = tp.replace(\'\\\\\', \'/\')\n        matched_dir = None\n        for existing_dir in all_dirs.keys():\n            if existing_dir.strip(\'/\').lower() == tp.strip(\'/\').lower():\n                matched_dir = existing_dir\n                break\n        return matched_dir if matched_dir else (tp.strip(\'/\') + \'/\')\n\n    if target_path:\n        target_path = _norm_dir(target_path)\n    norm_path_map = {}\n    if path_map:\n        for _name, _tp in path_map.items():\n            norm_path_map[_name] = _norm_dir(_tp)\n\n    pak_name_map = {}\n    for dp_str, dir_files in all_dirs.items():\n        for name, (slot, entry) in dir_files.items():\n            full_path = str(PurePath(dp_str) / name).replace(\'\\\\\', \'/\')\n            pak_name_map.setdefault(name.lower(), []).append((full_path, slot, entry))\n\n    edited = {}\n    for p in edit_files:\n        fl = p.name.lower()\n        found_match = False\n        if path_map is not None:\n            tp = norm_path_map.get(p.name)\n        else:\n            tp = target_path\n\n        if not found_match:\n            rel_path = p.relative_to(edited_root).as_posix()\n            mp_norm = mp_str.strip(\'/\')\n            if mp_norm and rel_path.startswith(mp_norm + \'/\'):\n                rel_path = rel_path[len(mp_norm) + 1:]\n            for dp_str, dir_files in all_dirs.items():\n                for name, (slot, entry) in dir_files.items():\n                    full_path = str(PurePath(dp_str) / name).replace(\'\\\\\', \'/\')\n                    if full_path == rel_path or full_path.endswith(\'/\' + rel_path) or rel_path.endswith(\'/\' + name):\n                        edited[full_path] = (p, slot, entry, False)\n                        found_match = True\n                        break\n                if found_match:\n                    break\n\n        if fl in pak_name_map:\n            cands = pak_name_map[fl]\n            if tp:\n                target_cands = [(fp, s, e) for fp, s, e in cands if tp.strip(\'/\') in fp]\n                if target_cands:\n                    sz = p.stat().st_size\n                    sm = [(fp, s, e) for fp, s, e in target_cands if e.uncompressed_size == sz]\n                    fp, s, e = sm[0] if sm else target_cands[0]\n                    edited[fp] = (p, s, e, False)\n                    found_match = True\n            if not found_match:\n                sz = p.stat().st_size\n                sm = [(fp, s, e) for fp, s, e in cands if e.uncompressed_size == sz]\n                if sm:\n                    fp, s, e = sm[0]\n                else:\n                    fp, s, e = cands[0]\n                if tp and force_add:\n                    new_fp = f"{tp.rstrip(\'/\')}/{p.name}"\n                    edited[new_fp] = (p, s, e, True)\n                else:\n                    edited[fp] = (p, s, e, False)\n                found_match = True\n\n        if not found_match:\n            stem = p.stem.lower()\n            ext = p.suffix.lower()\n            for dp_str, dir_files in all_dirs.items():\n                for name, (slot, entry) in dir_files.items():\n                    if Path(name).stem.lower() == stem and Path(name).suffix.lower() == ext:\n                        full_path = str(PurePath(dp_str) / name).replace(\'\\\\\', \'/\')\n                        if tp and force_add:\n                            new_fp = f"{tp.rstrip(\'/\')}/{p.name}"\n                            edited[new_fp] = (p, slot, entry, True)\n                        else:\n                            edited[full_path] = (p, slot, entry, False)\n                        found_match = True\n                        break\n                if found_match:\n                    break\n\n        if not found_match and force_add:\n            template_entry = None\n            for dp_str, dir_files in all_dirs.items():\n                for _n, (_s, e) in dir_files.items():\n                    if Path(_n).suffix.lower() == p.suffix.lower():\n                        template_entry = e\n                        break\n                if template_entry:\n                    break\n            if not template_entry:\n                for dp_str, dir_files in all_dirs.items():\n                    for _n, (_s, e) in dir_files.items():\n                        template_entry = e\n                        break\n                    if template_entry:\n                        break\n            rel_path = p.relative_to(edited_root).as_posix()\n            mp_norm = mp_str.strip(\'/\')\n            if mp_norm and rel_path.startswith(mp_norm + \'/\'):\n                rel_path = rel_path[len(mp_norm) + 1:]\n            if tp:\n                new_fp = f"{tp.rstrip(\'/\')}/{p.name}"\n            else:\n                new_fp = rel_path\n            if template_entry:\n                edited[new_fp] = (p, -1, template_entry, True)\n                found_match = True\n            else:\n                console.print(f\'[white]~ Skipped (no entry in PAK): {p.name}[/]\')\n\n    if not edited:\n        console.print(\'[white]No files to repack![/]\')\n        return 0\n\n    slot_to_new = {}\n    for i, e in enumerate(pak_file._files):\n        ne = _cp.copy(e)\n        ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]\n        slot_to_new[i] = ne\n\n    import tempfile as _tmpfile\n    _tmpfd, _tmppath = _tmpfile.mkstemp(suffix=\'.pak\')\n    _outf = open(_tmpfd, \'r+b\')\n    _pos = [0]\n\n    file_rows = []\n    new_added = []\n    processed_count = 0\n    total_to_process = sum(len(files) for files in all_dirs.values())\n\n    def _out_append(data: bytes):\n        start = _pos[0]\n        _outf.write(data)\n        _pos[0] += len(data)\n        return start\n\n    def _out_len() -> int:\n        return _pos[0]\n\n    for dp_str, dir_files in list(all_dirs.items()):\n        for name, (slot, old_entry) in list(dir_files.items()):\n            full_path = str(PurePath(dp_str) / name).replace(\'\\\\\', \'/\')\n            ne = slot_to_new[slot]\n            em = old_entry.encryption_method\n            cm = old_entry.compression_method\n\n            if full_path in edited:\n                p, _s, template, is_new = edited[full_path]\n                new_raw = p.read_bytes()\n                pak_rel = PurePath(full_path)\n\n                ne.uncompressed_size = len(new_raw)\n                ne.compression_method = cm\n                ne.encryption_method = em\n                ne.encrypted = old_entry.encrypted\n                ne.unk1 = old_entry.unk1\n                ne.index_new_sep = old_entry.index_new_sep\n\n                if is_new and (target_path or path_map):\n                    full_path_str = mp_str + full_path\n                    ne.unk2 = SHA1.new(full_path_str.lower().encode(\'utf-8\')).digest()\n                else:\n                    ne.unk2 = old_entry.unk2\n\n                stored_start = _out_len()\n                if cm == CM_NONE:\n                    cipher = (_encrypt_plaintext(new_raw, pak_rel, em) if ne.encrypted else new_raw)\n                    ne.offset = _out_len()\n                    ne.size = len(new_raw)\n                    _out_append(cipher)\n                else:\n                    cs = (old_entry.compression_block_size if old_entry.compression_block_size > 0 else 65536)\n                    chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]\n                    order = _block_permutation(len(chunks), em)\n                    cipher_by_logical = []\n                    for chunk in chunks:\n                        compressed = _best_compress(chunk, cm, pak_file._zstd_dict)\n                        cipher = (_encrypt_plaintext(compressed, pak_rel, em) if ne.encrypted else compressed)\n                        cipher_by_logical.append(cipher)\n                    inv = [0] * len(chunks)\n                    for logical_i, phys_i in enumerate(order):\n                        inv[phys_i] = logical_i\n                    new_blks = [None] * len(chunks)\n                    for phys_i in range(len(chunks)):\n                        blk = PakCompressedBlock.__new__(PakCompressedBlock)\n                        blk.start = _out_len()\n                        _out_append(cipher_by_logical[inv[phys_i]])\n                        blk.end = _out_len()\n                        new_blks[phys_i] = blk\n                    ne.compressed_blocks = new_blks\n                    ne.offset = new_blks[0].start if new_blks else _out_len()\n                    ne.size = sum(b.end - b.start for b in new_blks)\n\n                _outf.seek(stored_start)\n                stored_bytes = _outf.read(ne.size)\n                _outf.seek(0, 2)\n                ne.content_hash = SHA1.new(stored_bytes).digest()\n\n                file_rows.append((full_path, len(new_raw), ne.size))\n                processed_count += 1\n                if processed_count % 5 == 0 or processed_count == total_to_process:\n                    sys.stdout.write(f\'\\r[white]  Processing Assets... [{processed_count}/{total_to_process}][/]\')\n                    sys.stdout.flush()\n            else:\n                if cm == CM_NONE:\n                    read_sz = (PakCrypto.align_encrypted_content_size(old_entry.size, em)\n                               if old_entry.encrypted else old_entry.size)\n                    ne.offset = _out_len()\n                    _out_append(bytes(orig_fc[old_entry.offset: old_entry.offset + read_sz]))\n                elif old_entry.compressed_blocks:\n                    new_blks = []\n                    for ob in old_entry.compressed_blocks:\n                        unc = ob.end - ob.start\n                        enc = (PakCrypto.align_encrypted_content_size(unc, em)\n                               if old_entry.encrypted else unc)\n                        nb = PakCompressedBlock.__new__(PakCompressedBlock)\n                        nb.start = _out_len()\n                        _out_append(bytes(orig_fc[ob.start: ob.start + enc]))\n                        nb.end = _out_len()\n                        new_blks.append(nb)\n                    ne.compressed_blocks = new_blks\n                    ne.offset = new_blks[0].start if new_blks else _out_len()\n\n    sys.stdout.write(f\'\\r  All {processed_count} assets processed.          \\n\')\n    sys.stdout.flush()\n\n    if force_add:\n        for fp, (p, slot, template, is_new) in edited.items():\n            if not is_new or slot >= 0:\n                continue\n            already = False\n            for dp_str, dir_files in all_dirs.items():\n                for _n, (_s, _e) in dir_files.items():\n                    if str(PurePath(dp_str) / _n).replace(\'\\\\\', \'/\') == fp:\n                        already = True\n                        break\n                if already:\n                    break\n            if already:\n                continue\n\n            ne = _cp.copy(template)\n            new_raw = p.read_bytes()\n            pak_rel = PurePath(fp)\n            ne.uncompressed_size = len(new_raw)\n            ne.compression_method = template.compression_method\n            ne.compressed_blocks = []\n            ne.compression_block_size = template.compression_block_size\n            ne.encryption_method = template.encryption_method\n            ne.encrypted = template.encrypted\n            ne.unk1 = template.unk1\n            full_path_str = mp_str + fp\n            ne.unk2 = SHA1.new(full_path_str.lower().encode(\'utf-8\')).digest()\n            ne.index_new_sep = template.index_new_sep\n\n            stored_start = _out_len()\n            if ne.compression_method == CM_NONE:\n                cipher = (_encrypt_plaintext(new_raw, pak_rel, ne.encryption_method) if ne.encrypted else new_raw)\n                ne.offset = _out_len()\n                ne.size = len(new_raw)\n                _out_append(cipher)\n            else:\n                cs = template.compression_block_size if template.compression_block_size > 0 else 65536\n                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]\n                order = _block_permutation(len(chunks), ne.encryption_method)\n                cipher_by_logical = []\n                for chunk in chunks:\n                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)\n                    cipher = (_encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed)\n                    cipher_by_logical.append(cipher)\n                inv = [0] * len(chunks)\n                for logical_i, phys_i in enumerate(order):\n                    inv[phys_i] = logical_i\n                new_blks = [None] * len(chunks)\n                for phys_i in range(len(chunks)):\n                    blk = PakCompressedBlock.__new__(PakCompressedBlock)\n                    blk.start = _out_len()\n                    _out_append(cipher_by_logical[inv[phys_i]])\n                    blk.end = _out_len()\n                    new_blks[phys_i] = blk\n                ne.compressed_blocks = new_blks\n                ne.offset = new_blks[0].start if new_blks else _out_len()\n                ne.size = sum(b.end - b.start for b in new_blks)\n\n            _outf.seek(stored_start)\n            stored_bytes = _outf.read(ne.size)\n            _outf.seek(0, 2)\n            ne.content_hash = SHA1.new(stored_bytes).digest()\n\n            if path_map is not None:\n                _nk = norm_path_map.get(p.name)\n                _dir_key = _nk if _nk else \'\'\n            else:\n                _dir_key = target_path\n            new_slot = len(slot_to_new) + len(new_added)\n            new_added.append((_dir_key, p.name, ne, new_slot))\n            file_rows.append((fp, len(new_raw), ne.size))\n\n    max_slot = max(slot_to_new.keys()) if slot_to_new else -1\n    new_files = [slot_to_new[i] for i in range(max_slot + 1)]\n    dir_to_added = {}\n    for dir_key, name, ne, new_slot in new_added:\n        new_files.append(ne)\n        dir_to_added.setdefault(dir_key, []).append((name, ne, new_slot))\n\n    for dir_key, items in dir_to_added.items():\n        if dir_key not in all_dirs:\n            all_dirs[dir_key] = {}\n        for name, ne, new_slot in items:\n            all_dirs[dir_key][name] = (new_slot, ne)\n\n    idx = bytearray(_pw_string(mp_str))\n    idx += struct.pack(\'<I\', len(new_files))\n    for ne in new_files:\n        idx += _pw_entry(ne, version)\n    idx += struct.pack(\'<Q\', len(all_dirs))\n    for dp_str, dir_files in all_dirs.items():\n        idx += _pw_string(dp_str)\n        idx += struct.pack(\'<Q\', len(dir_files))\n        for name, (slot, _old_e) in dir_files.items():\n            idx += _pw_string(name)\n            idx += struct.pack(\'<i\', ~slot)\n\n    index_plain = bytes(idx)\n    new_sha1 = SHA1.new(index_plain).digest()\n\n    if pak_file._pak_info.index_encrypted:\n        try:\n            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)\n            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)\n            if key and iv and len(key) == 32 and len(iv) >= 16:\n                aes = AES.new(key, MODE_CBC, iv[:16])\n                pad = (-len(index_plain)) % AES.block_size or AES.block_size\n                index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))\n            else:\n                index_bytes = index_plain\n        except:\n            index_bytes = index_plain\n    else:\n        index_bytes = index_plain\n\n    new_idx_offset = _out_len()\n    new_idx_size = len(index_bytes)\n    _out_append(index_bytes)\n\n    footer_sz = TencentPakInfo._mem_size(version)\n    new_footer = bytearray(orig_fc[-footer_sz:])\n\n    # Keep the filename metadata consistent with the actual output name.\n    # Tencent/Unreal PAK v9+ stores a CRC32 of the UTF-32LE filename stem\n    # in the footer. This is metadata repair only; it does not create or\n    # bypass any production signing key.\n    if version >= 9:\n        output_stem = Path(output_path).stem\n        stem_hash = zlib.crc32(output_stem.encode(\'utf-32le\')) & 0xFFFFFFFF\n        stem_pos = len(new_footer) - 45 - (20 if version >= 12 else 0) - 8\n        if 0 <= stem_pos <= len(new_footer) - 4:\n            new_footer[stem_pos:stem_pos + 4] = struct.pack(\'<I\', stem_hash ^ keystream[8])\n\n    h_key = struct.pack(\'<5I\', *keystream[4:9])\n    new_footer[-36:-16] = bytes(a ^ b for a, b in zip(new_sha1, h_key))\n    new_footer[-16:-8] = ((new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, \'little\'))\n    new_footer[-8:] = ((new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, \'little\'))\n    _out_append(new_footer)\n\n    _outf.flush()\n    _outf.close()\n    shutil.copy2(_tmppath, output_path)\n    os.unlink(_tmppath)\n\n    if file_rows:\n        summary = Table(title="Files Processed", box=ROUNDED, border_style="white")\n        summary.add_column("Path in PAK", style="white")\n        summary.add_column("Original Size", justify="right", style="dim")\n        summary.add_column("Stored Size", justify="right", style="dim")\n        for fp, orig_sz, stored_sz in file_rows:\n            summary.add_row(fp, human_size(orig_sz), human_size(stored_sz))\n        console.print(summary)\n\n    return len(edited)\n\ndef build_new_pak_from_template(template_pak_path: Path, edit_dir: Path, output_path: Path, target_path: str = None, path_map: dict = None):\n    import copy as _cp\n    console.print(f\'[white]Building NEW PAK using template: {template_pak_path.name}[/]\')\n    pak_file = TencentPakFile(template_pak_path, is_od=True)\n    version = pak_file._pak_info.version\n    keystream = PakCrypto.zuc_keystream()\n    mp_str, _all_dirs_orig = _get_all_dirs_and_mp(pak_file)\n\n    template_entry = None\n    for _dir_path, files in pak_file._index.items():\n        for _name, entry in files.items():\n            template_entry = entry\n            break\n        if template_entry:\n            break\n    if template_entry is None:\n        console.print(\'[white]No file found in the Template PAK to copy settings from![/]\')\n        return 0\n\n    edit_files = [p for p in Path(edit_dir).rglob(\'*\') if p.is_file()]\n    if not edit_files:\n        console.print(\'[white]No file found in the EDIT folder![/]\')\n        return 0\n\n    out_buf = bytearray()\n    new_files = []\n    all_dirs = {}\n    file_rows = []\n\n    with Progress(\n        SpinnerColumn(),\n        TextColumn("[white][BUILD][/] {task.description}"),\n        BarColumn(),\n        TaskProgressColumn(),\n        TimeElapsedColumn(),\n        console=console\n    ) as progress:\n        task = progress.add_task("Adding files...", total=len(edit_files))\n\n        for p in edit_files:\n            rel = p.relative_to(edit_dir).as_posix()\n            if path_map is not None:\n                tp_for_file = path_map.get(p.name)\n                if tp_for_file is None:\n                    tp_for_file = \'\'\n                if tp_for_file == \'\':\n                    parent = str(PurePath(rel).parent).replace(\'\\\\\', \'/\')\n                    dir_key = \'\' if parent == \'.\' else parent + \'/\'\n                    fp = rel\n                else:\n                    dir_key = tp_for_file.rstrip(\'/\') + \'/\'\n                    fp = f"{tp_for_file.rstrip(\'/\')}/{p.name}"\n            elif target_path:\n                fp = f"{target_path.rstrip(\'/\')}/{p.name}"\n                dir_key = target_path.rstrip(\'/\') + \'/\'\n            else:\n                parent = str(PurePath(rel).parent).replace(\'\\\\\', \'/\')\n                dir_key = \'\' if parent == \'.\' else parent + \'/\'\n                fp = rel\n\n            ne = _cp.copy(template_entry)\n            new_raw = p.read_bytes()\n            pak_rel = PurePath(fp)\n\n            ne.uncompressed_size = len(new_raw)\n            ne.compression_method = template_entry.compression_method\n            ne.encryption_method = template_entry.encryption_method\n            ne.encrypted = template_entry.encrypted\n            ne.unk1 = template_entry.unk1\n            full_path_str = mp_str + fp\n            ne.unk2 = SHA1.new(full_path_str.lower().encode(\'utf-8\')).digest()\n            ne.index_new_sep = template_entry.index_new_sep\n\n            stored_start = len(out_buf)\n            if ne.compression_method == CM_NONE:\n                cipher = (_encrypt_plaintext(new_raw, pak_rel, ne.encryption_method)\n                          if ne.encrypted else new_raw)\n                ne.offset = len(out_buf)\n                ne.size = len(new_raw)\n                out_buf += cipher\n            else:\n                cs = template_entry.compression_block_size if template_entry.compression_block_size > 0 else 65536\n                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]\n                order = _block_permutation(len(chunks), ne.encryption_method)\n                cipher_by_logical = []\n                for chunk in chunks:\n                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)\n                    cipher = (_encrypt_plaintext(compressed, pak_rel, ne.encryption_method)\n                              if ne.encrypted else compressed)\n                    cipher_by_logical.append(cipher)\n                inv = [0] * len(chunks)\n                for logical_i, phys_i in enumerate(order):\n                    inv[phys_i] = logical_i\n                new_blks = [None] * len(chunks)\n                for phys_i in range(len(chunks)):\n                    blk = PakCompressedBlock.__new__(PakCompressedBlock)\n                    blk.start = len(out_buf)\n                    blk.end = blk.start + len(cipher_by_logical[inv[phys_i]])\n                    out_buf += cipher_by_logical[inv[phys_i]]\n                    new_blks[phys_i] = blk\n                ne.compressed_blocks = new_blks\n                ne.offset = new_blks[0].start if new_blks else len(out_buf)\n                ne.size = sum(b.end - b.start for b in new_blks)\n\n            stored_bytes = bytes(out_buf[ne.offset:ne.offset + ne.size])\n            ne.content_hash = SHA1.new(stored_bytes).digest()\n\n            new_files.append(ne)\n            all_dirs.setdefault(dir_key, {})[p.name] = ne\n            file_rows.append((fp, ne.uncompressed_size, ne.size))\n            progress.update(task, advance=1, description=f"{p.name}")\n\n    summary = Table(title="Files Added to New PAK", box=ROUNDED, border_style="white")\n    summary.add_column("Path in PAK", style="white")\n    summary.add_column("Original Size", justify="right", style="dim")\n    summary.add_column("Stored Size", justify="right", style="dim")\n    for fp, orig_sz, stored_sz in file_rows:\n        summary.add_row(fp, human_size(orig_sz), human_size(stored_sz))\n    console.print(summary)\n\n    id_to_idx = {id(ne): i for i, ne in enumerate(new_files)}\n\n    idx = bytearray(_pw_string(mp_str))\n    idx += struct.pack(\'<I\', len(new_files))\n    for ne in new_files:\n        idx += _pw_entry(ne, version)\n    idx += struct.pack(\'<Q\', len(all_dirs))\n    for dp_str, dir_files in all_dirs.items():\n        idx += _pw_string(dp_str)\n        idx += struct.pack(\'<Q\', len(dir_files))\n        for name, e in dir_files.items():\n            idx += _pw_string(name)\n            idx += struct.pack(\'<i\', ~id_to_idx[id(e)])\n\n    index_plain = bytes(idx)\n    new_sha1 = SHA1.new(index_plain).digest()\n\n    if pak_file._pak_info.index_encrypted:\n        try:\n            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)\n            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)\n            if key and iv and len(key) == 32 and len(iv) >= 16:\n                aes = AES.new(key, MODE_CBC, iv[:16])\n                pad = (-len(index_plain)) % AES.block_size or AES.block_size\n                index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))\n            else:\n                index_bytes = index_plain\n        except:\n            index_bytes = index_plain\n    else:\n        index_bytes = index_plain\n\n    new_idx_offset = len(out_buf)\n    new_idx_size = len(index_bytes)\n    out_buf += index_bytes\n\n    orig_fc = pak_file._file_content\n    footer_sz = TencentPakInfo._mem_size(version)\n    new_footer = bytearray(orig_fc[-footer_sz:])\n\n    h_key = struct.pack(\'<5I\', *keystream[4:9])\n    new_footer[-36:-16] = bytes(a ^ b for a, b in zip(new_sha1, h_key))\n    new_footer[-16:-8] = ((new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, \'little\'))\n    new_footer[-8:] = ((new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, \'little\'))\n    out_buf += new_footer\n\n    with open(output_path, \'wb\') as f:\n        f.write(out_buf)\n\n    console.print(f\'[white]New PAK written: {output_path}[/]\')\n    console.print(f\'[white]Files included: {len(new_files)}[/]\')\n\n    try:\n        check_pak = TencentPakFile(output_path, is_od=True)\n    except AssertionError:\n        console.print(\'[white]VERIFICATION FAILED (index hash mismatch)[/]\')\n    except Exception as e:\n        console.print(f\'[white]VERIFICATION FAILED: {e}[/]\')\n\n    return len(new_files)\n\n\n\ndef _select_star_pak_for_engine(title: str):\n    pak_files = sorted(\n        [f for f in PAK_ORIGINAL_DIR.iterdir() if f.is_file() and f.name.lower().endswith(\'.pak\')],\n        key=lambda x: x.name.lower()\n    )\n    if not pak_files:\n        console.print(\'[white]❌ No PAK files found.[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return None\n    console.print(f\'\\n[bold #FF00FF]{title}[/bold #FF00FF]\')\n    for i, p in enumerate(pak_files, 1):\n        console.print(f\'  [{i}] {p.name}\')\n    try:\n        idx=int(safe_input(\'Select PAK: \').strip())-1\n        if idx<0 or idx>=len(pak_files): raise ValueError\n        return pak_files[idx]\n    except Exception:\n        console.print(\'[white]❌ Invalid PAK selection.[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return None\n\n\ndef _get_star_edit_dir(pak_path: Path):\n    workspace, edit_dir, result_dir = _create_star_pak_workspace(pak_path.stem)\n    files=[f for f in edit_dir.rglob(\'*\') if f.is_file() and f.name not in [\'pak_manifest.json\',\'.DS_Store\']]\n    if not files:\n        console.print(f\'[white]⚠ COMPILED is empty: {edit_dir}[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return None, None, None\n    return edit_dir, result_dir, files\n\n\ndef run_repack_lua_engine():\n    """Option 2: use the same CUSTOM PAK/CSV workflow as STAR INJECT, but\n    send the resolved files through s.py\'s REPACK_LUA_PAK engine."""\n    console.print("[white]CUSTOM PAK workflow + PUBG.csv path mapping[/white]")\n\n    pak_files = sorted(\n        [f for f in PAK_ORIGINAL_DIR.iterdir() if f.is_file() and f.name.lower().endswith(\'.pak\')],\n        key=lambda x: x.name.lower()\n    )\n    if not pak_files:\n        console.print(\'[white]❌ No PAK file found.[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return\n\n    console.print(\'\\n[bold #FF00FF]📦 CUSTOM PAK — Select source PAK:[/bold #FF00FF]\')\n    for i, f in enumerate(pak_files, 1):\n        console.print(f\'  [{i}] {f.name}  [dim]{human_size(f.stat().st_size)}[/dim]\')\n    try:\n        n=int(safe_input(\'Select PAK: \').strip())\n        if not 1 <= n <= len(pak_files): raise ValueError\n        pak_path=pak_files[n-1]\n    except Exception:\n        console.print(\'[white]❌ Invalid PAK selection.[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return\n\n    workspace_root, edit_dir, result_dir = _create_star_pak_workspace(pak_path.stem)\n    console.print(f\'\\n[bold white]📁 ALVSIA_TOOL/[/bold white]\')\n    console.print(f\'  [white]├── COMPILED/[/white] {edit_dir}\')\n    console.print(f\'  [white]└── PAK_RESULT/[/white]    {result_dir}\')\n\n    files=[f for f in edit_dir.rglob(\'*\') if f.is_file() and f.name not in (\'pak_manifest.json\',\'.DS_Store\')]\n    if not files:\n        console.print(\'[white]⚠ COMPILED folder is empty.[/white]\')\n        console.print(f\'[dim]Drop files into: {edit_dir}[/dim]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return\n\n    # Same CSV/index resolution used by the normal STAR injector.\n    console.print(\'\\n[bold #FF00FF]📖 Loading PUBGM path index...[/bold #FF00FF]\')\n    bgmi_index=_load_bgmi_path_index()\n    path_map={}\n    unresolved=[]\n    cache={}\n    if bgmi_index:\n        console.print(f\'[white]✅ Index loaded — {len(bgmi_index):,} unique filenames mapped[/white]\')\n        for f in files:\n            # Keep PUBG.csv behavior unchanged for non-Lua files.\n            # Only COMPILED Lua files use a manual PAK directory.\n            if f.suffix.lower() == \'.lua\':\n                console.print(f\'\\n[bold white]🎯 Manual path for Lua:[/bold white] {f.name}\')\n                console.print(\'[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/[/dim]\')\n                manual=safe_input(\'Path: \').strip().replace(\'\\\\\',\'/\').strip(\'/\')\n                if manual:\n                    path_map[f.name]=manual+\'/\'\n                    console.print(f\'  [white]✓[/white] {f.name} → {manual}/\')\n                else:\n                    unresolved.append(f)\n                    console.print(f\'  [white]⚠[/white] {f.name} skipped: no manual path entered\')\n                continue\n            resolved=_resolve_path_from_index(f,bgmi_index,cache)\n            if resolved:\n                # repack_pak_file_full expects directory path for path_map.\n                path_map[f.name]=str(PurePath(resolved).parent).replace(\'\\\\\',\'/\') + \'/\'\n                console.print(f\'  [white]✓[/white] {f.name} → {resolved}\')\n            else:\n                unresolved.append(f)\n                console.print(f\'  [white]⚠[/white] {f.name} not found in CSV index\')\n    else:\n        console.print(\'[white]⚠ PUBG.csv not found — manual target path will be used.[/white]\')\n        unresolved=files[:]\n\n    fallback=None\n    if unresolved:\n        console.print(\'\\n[bold white]Target path inside PAK for unresolved files:[/bold white]\')\n        console.print(\'[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/[/dim]\')\n        fallback=safe_input(\'Path: \').strip().replace(\'\\\\\',\'/\').strip(\'/\')\n        if not fallback:\n            fallback=\'Content/Lua\'\n        console.print(f\'[white]🎯 Fallback path: {fallback}[/white]\')\n        for f in unresolved:\n            path_map[f.name]=fallback+\'/\'\n\n    # Custom output PAK name — same custom-name requirement as the main workflow.\n    default_name=pak_path.name\n    console.print(f\'\\n[bold #FF00FF]📝 Custom output PAK name[/bold #FF00FF]\')\n    console.print(f\'[dim]Default: {default_name}[/dim]\')\n    out_name=safe_input(\'Output name: \').strip()\n    if not out_name:\n        out_name=default_name\n    out_name=Path(out_name).name\n    if not out_name.lower().endswith(\'.pak\'):\n        out_name += \'.pak\'\n    out_name=re.sub(r\'[<>:"/\\\\|?*\\x00-\\x1f]\',\'_\',out_name)\n    output=result_dir/out_name\n\n    if output.exists():\n        ans=safe_input(f\'[white]{output.name} exists. Overwrite? (y/N): [/white]\').strip().lower()\n        if ans!=\'y\':\n            console.print(\'[white]Cancelled.[/white]\')\n            return\n\n    try:\n        console.print(\'\\n[white]🔄 Running REPACK_LUA_PAK engine...[/white]\')\n        pak=TencentPakFile(pak_path)\n        count=repack_pak_file_full(\n            pak, edit_dir, output,\n            target_path=None,\n            force_add=True,\n            path_map=path_map,\n        )\n        if not count:\n            raise RuntimeError(\'No files were repacked.\')\n        _patch_output_stem_hash(output)\n        console.print(f\'\\n[bold white]✅ REPACK_LUA_PAK SUCCESS[/bold white]\')\n        console.print(f\'[white]Processed: {count} file(s)[/white]\')\n        console.print(f\'[white]Output: {output}[/white]\')\n        _verify_engine_output(output,pak_path)\n    except Exception as e:\n        console.print(f\'[bold white]❌ REPACK_LUA_PAK failed: {e}[/bold white]\')\n        import traceback; traceback.print_exc()\n    safe_input(\'\\nPress Enter to return to Home...\')\n\ndef _load_exact_s_module():\n    """Load the user\'s original s.py so its Option-4 implementation runs with\n    its own globals/helpers instead of a copied implementation inside builder.py."""\n    import importlib.util\n    candidates = [\n        Path(__file__).resolve().with_name(\'s.py\'),\n        BASE_DIR / \'s.py\',\n    ]\n    s_path = next((x for x in candidates if x.exists()), None)\n    if s_path is None:\n        # The full BUILD_NEW_PAK engine is already embedded in this namespace.\n        # Fall back to it when this tool is launched under another filename (e.g. t.py).\n        from types import SimpleNamespace\n        local_engine = globals().get(\'build_new_pak_from_template\')\n        if callable(local_engine):\n            return SimpleNamespace(build_new_pak_from_template=local_engine)\n        raise FileNotFoundError(\'s.py not found and embedded BUILD_NEW_PAK engine is unavailable\')\n    spec = importlib.util.spec_from_file_location(\'_original_s_engine\', str(s_path))\n    if spec is None or spec.loader is None:\n        raise ImportError(f\'Cannot load {s_path}\')\n    mod = importlib.util.module_from_spec(spec)\n    spec.loader.exec_module(mod)\n    if not hasattr(mod, \'build_new_pak_from_template\'):\n        raise AttributeError(\'s.py does not contain build_new_pak_from_template()\')\n    return mod\n\n\ndef run_build_new_pak_engine():\n    """Option 3: use s.py\'s BUILD_NEW_PAK engine with the same CUSTOM PAK/CSV UI."""\n    console.print("[white]BUILD_NEW_PAK — Custom PAK workflow (stable engine)[/white]")\n\n    pak_files = sorted(\n        [f for f in PAK_ORIGINAL_DIR.iterdir() if f.is_file() and f.name.lower().endswith(\'.pak\')],\n        key=lambda x: x.name.lower()\n    )\n    if not pak_files:\n        console.print(\'[white]❌ No PAK file found.[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return\n\n    console.print(\'\\n[bold #FF00FF]📦 CUSTOM PAK — Select source PAK:[/bold #FF00FF]\')\n    for i, f in enumerate(pak_files, 1):\n        console.print(f\'  [{i}] {f.name}  [dim]{human_size(f.stat().st_size)}[/dim]\')\n    try:\n        n = int(safe_input(\'Select PAK: \').strip())\n        if not 1 <= n <= len(pak_files):\n            raise ValueError\n        pak_path = pak_files[n - 1]\n    except Exception:\n        console.print(\'[white]❌ Invalid PAK selection.[/white]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return\n\n    workspace_root, edit_dir, result_dir = _create_star_pak_workspace(pak_path.stem)\n    console.print(f\'\\n[bold white]📁 ALVSIA_TOOL/[/bold white]\')\n    console.print(f\'  [white]├── COMPILED/[/white] {edit_dir}\')\n    console.print(f\'  [white]└── PAK_RESULT/[/white]    {result_dir}\')\n\n    files = [f for f in edit_dir.rglob(\'*\') if f.is_file() and f.name not in (\'pak_manifest.json\', \'.DS_Store\')]\n    if not files:\n        console.print(\'[white]⚠ COMPILED folder is empty.[/white]\')\n        console.print(f\'[dim]Drop files into: {edit_dir}[/dim]\')\n        safe_input(\'\\nPress Enter to continue...\')\n        return\n\n    console.print(\'\\n[bold #FF00FF]📖 Loading PUBGM path index...[/bold #FF00FF]\')\n    bgmi_index = _load_bgmi_path_index()\n    path_map = {}\n    unresolved = []\n    cache = {}\n\n    if bgmi_index:\n        console.print(f\'[white]✅ Index loaded — {len(bgmi_index):,} unique filenames mapped[/white]\')\n        for f in files:\n            # Keep PUBG.csv behavior unchanged for non-Lua files.\n            # Only COMPILED Lua files use a manual PAK directory.\n            if f.suffix.lower() == \'.lua\':\n                console.print(f\'\\n[bold white]🎯 Manual path for Lua:[/bold white] {f.name}\')\n                console.print(\'[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/[/dim]\')\n                manual = safe_input(\'Path: \').strip().replace(\'\\\\\', \'/\').strip(\'/\')\n                if manual:\n                    path_map[f.name] = manual + \'/\'\n                    console.print(f\'  [white]✓[/white] {f.name} → {manual}/\')\n                else:\n                    unresolved.append(f)\n                    console.print(f\'  [white]⚠[/white] {f.name} skipped: no manual path entered\')\n                continue\n            resolved = _resolve_path_from_index(f, bgmi_index, cache)\n            if resolved:\n                parent = str(PurePath(resolved).parent).replace(\'\\\\\', \'/\').strip(\'/\')\n                path_map[f.name] = (parent + \'/\') if parent else \'\'\n                console.print(f\'  [white]✓[/white] {f.name} → {resolved}\')\n            else:\n                unresolved.append(f)\n                console.print(f\'  [white]⚠[/white] {f.name} not found in CSV index\')\n    else:\n        console.print(\'[white]⚠ PUBG.csv not found — manual target path will be used.[/white]\')\n        unresolved = files[:]\n\n    if unresolved:\n        console.print(\'\\n[bold white]Target path inside PAK:[/bold white]\')\n        console.print(\'[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/[/dim]\')\n        fallback = safe_input(\'Path: \').strip().replace(\'\\\\\', \'/\').strip(\'/\')\n        if not fallback:\n            fallback = \'Content/Lua\'\n        console.print(f\'[white]🎯 Fallback path: {fallback}[/white]\')\n        for f in unresolved:\n            path_map[f.name] = fallback + \'/\'\n\n    default_name = pak_path.name\n    console.print(\'\\n[bold #FF00FF]📝 Custom output PAK name[/bold #FF00FF]\')\n    console.print(f\'[dim]Default: {default_name}[/dim]\')\n    out_name = safe_input(\'Output name: \').strip() or default_name\n    out_name = Path(out_name).name\n    if not out_name.lower().endswith(\'.pak\'):\n        out_name += \'.pak\'\n    out_name = re.sub(r\'[<>:"/\\\\|?*\\x00-\\x1f]\', \'_\', out_name)\n    output = result_dir / out_name\n\n    if output.exists():\n        ans = safe_input(f\'[white]{output.name} exists. Overwrite? (y/N): [/white]\').strip().lower()\n        if ans != \'y\':\n            console.print(\'[white]Cancelled.[/white]\')\n            return\n\n    try:\n        console.print(\'\\n[white]🔄 Running s.py BUILD_NEW_PAK engine...[/white]\')\n        s_engine = _load_exact_s_module()\n        console.print(\'[white]✓ Using exact BUILD_NEW_PAK implementation from s.py[/white]\')\n        count = s_engine.build_new_pak_from_template(\n            pak_path,\n            edit_dir,\n            output,\n            target_path=None,\n            path_map=path_map,\n        )\n        if not count:\n            raise RuntimeError(\'No files were repacked.\')\n        _patch_output_stem_hash(output)\n        console.print(f\'\\n[bold white]✅ BUILD_NEW_PAK SUCCESS[/bold white]\')\n        console.print(f\'[white]Processed: {count} file(s)[/white]\')\n        console.print(f\'[white]Output: {output}[/white]\')\n        _verify_engine_output(output, pak_path)\n    except Exception as e:\n        console.print(f\'[bold white]❌ BUILD_NEW_PAK failed: {e}[/bold white]\')\n        import traceback\n        traceback.print_exc()\n    safe_input(\'\\nPress Enter to return to Home...\')\n\ndef _verify_engine_output(output, source=None):\n    """Validate that the generated PAK can be parsed and its index hash verified."""\n    output = Path(output)\n    if not output.exists():\n        raise RuntimeError(f\'Output PAK was not created: {output}\')\n    size = output.stat().st_size\n    if size <= 0:\n        raise RuntimeError(\'Output PAK is empty.\')\n\n    console.print(\'[white]🔎 Verifying generated PAK...[/white]\')\n    try:\n        check = TencentPakFile(PurePath(output), is_od=True)\n        paths = check.list_existing_paths()\n        if not paths:\n            raise RuntimeError(\'Generated PAK index contains no entries.\')\n\n        if source is not None and Path(source).exists():\n            source_pak = TencentPakFile(PurePath(source), is_od=True)\n            if check._pak_info.version != source_pak._pak_info.version:\n                raise RuntimeError(\n                    f\'PAK version mismatch: source={source_pak._pak_info.version}, \'\n                    f\'output={check._pak_info.version}\'\n                )\n\n        console.print(f\'[white]✅ Verification passed — {len(paths):,} PAK entries loaded.[/white]\')\n        console.print(f\'[white]✅ Index/hash validation passed.[/white]\')\n        console.print(f\'[white]✅ Output size: {human_size(size)}[/white]\')\n        return True\n    except Exception as e:\n        raise RuntimeError(f\'Generated PAK verification failed: {e}\') from e\n\ndef custom_inject_menu():\n    global REPACK_RGB_MODE\n    REPACK_RGB_MODE = True\n    while True:\n        console.print(\'\\n[bold #FF00FF]═══ CUSTOM INJECT ENGINE ═══[/bold #FF00FF]\')\n        console.print(\'  [1] 💉 INJECT        — current STAR.py injector\')\n        console.print(\'  [2] 📦 REPACK_LUA_PAK — s.py Option 3 engine\')\n        console.print(\'  [3] 🛠 BUILD_NEW_PAK  — s.py Option 4 engine\')\n        console.print(\'  [0] ↩ BACK\')\n        choice=safe_input(\'Select (0-3): \').strip()\n        flush_stdin()\n        if choice==\'1\': run_inject()\n        elif choice==\'2\': run_repack_lua_engine()\n        elif choice==\'3\': run_build_new_pak_engine()\n        elif choice==\'0\':\n            REPACK_RGB_MODE = False\n            return\n        else: console.print(\'[white]Invalid choice.[/white]\')\n\n\ndef main_menu():\n    # Single shared workspace for every STAR operation.\n    BASE_DIR.mkdir(parents=True, exist_ok=True)\n    for folder in (BASE_DIR / "COMPILED", BASE_DIR / "PAK_RESULT", BASE_DIR / "index"):\n        folder.mkdir(parents=True, exist_ok=True)\n\n    while True:\n        # Upper banner/path information hidden; action menu remains visible.\n        pak_files = sorted(\n            [f for f in PAK_ORIGINAL_DIR.iterdir() if f.is_file() and f.name.lower().endswith(\'.pak\')],\n            key=lambda x: x.name.lower()\n        )\n        console.print(f\'  [bold #00FF88][1] 💉 CUSTOM INJECT[/bold #00FF88]   [dim]inject mod files into PAK[/dim]\')\n        console.print(f\'  [bold #FF00AA][2] 📋 LIST CONTENTS[/bold #FF00AA]   [dim]view files inside a PAK[/dim]\')\n        console.print(f\'  [bold #FF0055][0] EXIT[/bold #FF0055]\')\n\n        choice = safe_input(\'[bold white]Select (0-2):[/bold white] \').strip()\n        flush_stdin()\n\n        if choice == \'1\':\n            custom_inject_menu()\n        elif choice == \'2\':\n            _list_pak_contents(pak_files)\n        elif choice == \'0\':\n            console.print()\n            time.sleep(0.5)\n            break\n        else:\n            console.print(\'[white]Invalid choice.[/white]\')\n            time.sleep(1)\n\nif __name__ == \'__main__\':\n    try:\n        # Dependencies are expected to be installed in the ALVSIA_TOOL environment.\n        # Do not show/install the dependency-check screen at startup.\n        create_folders()\n        main_menu()\n    except KeyboardInterrupt:\n        print(f\'\\n{RED}Interrupted.{RESET}\')\n    except Exception as e:\n        print(f\'\\n{RED}Fatal error: {e}{RESET}\')\n        import traceback\n        traceback.print_exc()\n'
def action_make_only_lua_pak():
    """420.py Option 6 engine using UX's existing directory layout."""
    pak_dir = PAK_DIR
    add_dir = EDIT_DIR
    out_dir = RESULT_DIR

    for d in (pak_dir, add_dir, out_dir):
        d.mkdir(parents=True, exist_ok=True)

    console.print()
    console.print(Panel(
        "[bold white]MAKE ONLY LUA PAK[/bold white]\n"
        "[dim]420 build engine • UX directory layout[/dim]",
        border_style=NEON, box=ROUNDED, padding=(1, 2)
    ))

    pak_path, _ = display_file_selector(
        "📁 Select TEMPLATE PAK:", pak_dir, "*.pak"
    )
    if not pak_path:
        safe_input('\nPress Enter...')
        return

    add_files = [
        f for f in add_dir.rglob("*")
        if f.is_file() and f.name not in ('.DS_Store', 'pak_manifest.json')
    ]
    if not add_files:
        hexa_alert(f"COMPILED folder is empty. Put files in:\n{add_dir}", "error")
        safe_input('\nPress Enter...')
        return

    console.print()
    console.print(Panel(
        "Enter target path inside the new PAK.\n"
        "[dim]Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core[/dim]",
        border_style=ACCENT, box=ROUNDED, padding=(1, 2)
    ))
    target = safe_input("\n[bold white]Target path (required): [/bold white]").strip()
    target = target.replace('\\', '/').strip('/')
    if not target:
        hexa_alert("Target path cannot be empty.", "error")
        safe_input('\nPress Enter...')
        return

    backup_dir = pak_dir.parent / "BACKUP"
    backup_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = backup_dir / f"{pak_path.stem}_backup_{ts}{pak_path.suffix}"

    try:
        shutil.copy2(pak_path, backup_path)
        console.print(f"[bold white]✓ Backup:[/bold white] {backup_path}")
    except Exception as e:
        hexa_alert(f"Backup failed: {e}", "error")
        safe_input('\nPress Enter...')
        return

    output_pak = out_dir / pak_path.name

    try:
        hexa_section(f"Building NEW PAK: {pak_path.name}")
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(), TextColumn("[progress.percentage:>3.0f]%"), console=console
        ) as progress:
            task = progress.add_task("Loading Template PAK…", total=100)
            pak = TencentPakFile(pak_path)
            progress.update(task, advance=20)

            dominant = pak.detect_dominant_style()
            console.print(
                f"[dim]comp={dominant['comp_method']}  enc={dominant['enc_method']}  "
                f"encrypted={dominant['encrypted']}  block={dominant['block_size']}[/dim]"
            )
            progress.update(task, advance=20)
            progress.update(task, description="Building new PAK…", advance=10)

            count = build_new_pak_from_template(
                pak_path, add_dir, output_pak, target
            )
            progress.update(task, advance=40)
            progress.update(task, completed=100, description="Done ✓")

        new_size = output_pak.stat().st_size if output_pak.exists() else 0
        result_msg = (
            f"✓  MAKE_ONLY_LUA_PAK COMPLETE\n\n"
            f"Template   : {pak_path.name}\n"
            f"Target path: {target}\n"
            f"Files added: {count if count else 0}\n"
            f"Output     : {output_pak}\n"
            f"Size       : {new_size:,} bytes\n"
            f"Status     : GAME READY"
        )
        console.print(Panel(
            rgb_text(result_msg),
            title=rgb_text("  📁  MAKE ONLY LUA PAK RESULT  "),
            border_style=get_border_style(8, 0.55),
            style="white on black",
            box=ROUNDED,
            padding=(1, 2),
        ))
    except Exception as e:
        hexa_alert(f"Build failed: {e}", "error")
        traceback.print_exc()

    safe_input('\nPress Enter to continue...')



# =====================================================================
# Module: NewPakBuilder
# Purpose: Assemble a fresh PAK by injecting user files into a template
# Source: cp.py
# =====================================================================

def get_theme():
    return {"hi": NEON, "accent": ACCENT, "primary": ACCENT}

def is_termux():
    return Path("/data/data/com.termux/files/usr").exists()

def _ui_prompt(label):
    console.print(f"[bold {NEON}]{label}[/bold {NEON}]")

def _ui_error(message):
    console.print(f"[bold {ERR}]✗ {message}[/bold {ERR}]")

def _ui_info(message):
    console.print(f"[{ACCENT}]{message}[/{ACCENT}]")

def _ui_ok(message):
    console.print(f"[bold {SUCCESS}]✓ {message}[/bold {SUCCESS}]")

def print_credit():
    return


class NewPakBuilder:
    """Encapsulates the workflow for creating a new PAK from a template."""

    def __init__(self):
        self.theme = get_theme()
        self.hi = self.theme['hi']
        self.accent = self.theme['accent']
        self.primary = self.theme['primary']

    # -----------------------------------------------------------------
    # Directory resolution
    # -----------------------------------------------------------------
    def _ensure_layout(self) -> dict:
        # Reuse the existing ALVSIA_TOOL folders directly:
        #   PAK_ORIGINAL -> template PAKs
        #   COMPILED     -> files to add
        #   PAK_RESULT  -> generated PAKs
        #   BACKUP      -> template backups
        # No separate builder workspace folder is needed.
        layout = {
            "templates": PAK_DIR,
            "payload": LUA_PAK_ROOT / "COMPILED",
            "results": RESULT_DIR,
            "backup": LUA_PAK_ROOT / "BACKUP",
        }
        for key in ("templates", "payload", "results", "backup"):
            layout[key].mkdir(parents=True, exist_ok=True)
        return layout

    # -----------------------------------------------------------------
    # Payload scanning
    # -----------------------------------------------------------------
    @staticmethod
    def _scan_payload(payload_dir: Path) -> list:
        ignored = {'.DS_Store', 'pak_manifest.json'}
        return [
            item for item in payload_dir.rglob("*")
            if item.is_file() and item.name not in ignored
        ]

    # -----------------------------------------------------------------
    # Interactive prompt for the in-PAK destination path
    # -----------------------------------------------------------------
    def _ask_target_path(self) -> str:
        console.print(f"\n[bold {self.hi}]Enter Target Path in New PAK:[/bold {self.hi}]")
        console.print("[dim](like = Content/Lua/GameLua/Mod/BRMod/Gameplay/Core )[/dim]")
        while True:
            _ui_prompt("Target path")
            value = input().strip()
            if value:
                break
            _ui_error("Target path cannot be empty. Please enter a valid path.")
        if not value.endswith('/'):
            value += '/'
        _ui_info(f"Target path set: {value}")
        return value

    # -----------------------------------------------------------------
    # Template backup
    # -----------------------------------------------------------------
    def _make_backup(self, src: Path, backup_dir: Path) -> Path:
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        name = f"{src.stem}_backup_{stamp}{src.suffix}"
        dest = backup_dir / name
        shutil.copy2(src, dest)
        _ui_ok(f"Backup saved → {dest.name}")
        return dest

    # -----------------------------------------------------------------
    # Core build routine with progress feedback
    # -----------------------------------------------------------------
    def _run_build(self, template: Path, payload: Path,
                   destination: Path, target: str) -> int:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=console,
        ) as bar:
            job = bar.add_task(f"[{self.primary}]Loading Template PAK…", total=100)

            pak = TencentPakFile(template)
            bar.update(job, advance=20)

            bar.update(job, advance=10,
                       description="Detecting template style…")
            style = pak.detect_dominant_style()
            rgb_ui_print(f"comp={style['comp_method']}  enc={style['enc_method']}  encrypted={style['encrypted']}  block={style['block_size']}")

            bar.update(job, advance=10,
                       description="Building new PAK…")
            rgb_ui_print(f"Files to inject: {len(list(payload.rglob('*')))}")
            bar.update(job, advance=10)

            bar.update(job, advance=10,
                       description="Injecting files…")

            injected = build_new_pak_from_template(
                template, payload, destination, target.rstrip('/')
            )
            bar.update(job, advance=10)
            bar.update(job, completed=100,
                       description="Done ✅")
            return injected

    # -----------------------------------------------------------------
    # Public entry point
    # -----------------------------------------------------------------
    def execute(self):
        layout = self._ensure_layout()

        console.print()
        template, _ = display_file_selector(
            "📁 Select TEMPLATE PAK:", layout["templates"], "*.pak"
        )
        if not template:
            safe_input("\nPress Enter to continue...")
            return

        payload_files = self._scan_payload(layout["payload"])
        if not payload_files:
            _ui_error(
                f"FILES folder is empty — put your files in:  {layout['payload']}"
            )
            safe_input("\nPress Enter to continue...")
            return

        target = self._ask_target_path()
        self._make_backup(template, layout["backup"])

        output = layout["results"] / template.name

        try:
            injected = self._run_build(
                template, layout["payload"], output, target
            )

            old_bytes = template.stat().st_size
            new_bytes = output.stat().st_size if output.exists() else 0

            _build_msg = (
                f"✅  Build complete!\n\n"
                f"Template   :   {template.name}\n"
                f"Target path:   {target}\n"
                f"Files added:   {injected or 0}\n"
                f"Output     :   {output}\n\n"
                f"✅  New PAK created — {new_bytes:,} bytes"
            )
            console.print(Panel(
                rgb_text(_build_msg),
                title=rgb_text("  📁  BUILD NEW PAK  "),
                border_style=get_border_style(5, 0.55),
                style="white on black",
                padding=(1, 2),
            ))
            print_credit()

        except Exception as err:
            _ui_error(f"Build failed: {err}")
            import traceback
            traceback.print_exc()

        safe_input("\nPress Enter to continue...")


def repack_system_menu():
    global REPACK_UI_PLAIN, REPACK_RGB_MODE
    REPACK_UI_PLAIN = False
    REPACK_RGB_MODE = True
    try:
        """Group the existing REPACK_LUA_PAK, BUILD_NEW_PAK and INJECT_LUA actions."""
        ab = AnimatedBorder.get_instance()
        while True:
            # Reference-style table only; existing menu entries/actions stay intact.
            menu_table = Table(
                box=ROUNDED, show_header=True, header_style="bold white on black",
                padding=(0, 2), border_style=ab.get_moving_border_style(3, 0.55), style="white on black", expand=True
            )
            menu_table.add_column("OPTION", justify="center", style="bold white on black", width=8)
            menu_table.add_column("TOOL NAME", justify="left", style="bold white on black", min_width=24)
            menu_table.add_column("STATUS", justify="center", style="bold white on black", min_width=16)

            menu_table.add_row("1", "REPACK_LUA_PAK", "ONLINE")
            menu_table.add_row("2", "BUILD_NEW_PAK", "ONLINE")
            menu_table.add_row("3", "INJECT_LUA", "ONLINE")
            menu_table.add_row("4", "MAKE_ONLY_LUA_PAK", "ONLINE")
            menu_table.add_row("5", "NewPakBuilder", "ONLINE")
            menu_table.add_row("0", "BACK", "EXIT")

            border_color = ab.get_moving_border_style(3, 0.5)
            console.print(Panel(
                menu_table,
                title="[bold white on black]═══ REPACK SYSTEM ═══[/bold white on black]",
                border_style=border_color,
                style="white on black",
                box=HEAVY,
                padding=(1, 2)
            ))
            console.print()

            choice = hexa_prompt("Select option: ").strip()
            if choice == '1':
                action_repack_inject()
            elif choice == '2':
                action_build_new_pak()
            elif choice == '3':
                action_inject_lua()
            elif choice == '4':
                action_make_only_lua_pak()
            elif choice == '5':
                NewPakBuilder().execute()
            elif choice == '0':
                return
            else:
                hexa_alert("Invalid option", "error")
                time.sleep(1)
    finally:
        REPACK_UI_PLAIN = False
        REPACK_RGB_MODE = False

def main_menu():
    valid, license_key, key_info = check_license()
    if not valid:
        console.print("[white]License verification failed. Exiting...[/white]")
        time.sleep(2)
        return
    
    setup_directories()
    ab = AnimatedBorder.get_instance()
    
    while True:
        print_main_banner(key_info=key_info)
        
        # Visual-only menu styling: keep the existing options and actions unchanged.
        menu_table = Table(
            box=ROUNDED,
            show_header=True,
            header_style="bold white on black",
            padding=(0, 2),
            border_style=ab.get_moving_border_style(0, 0.55),
            row_styles=["white on black", "white on black"],
            style="white on black",
            expand=True,
        )
        menu_table.add_column("OPTION", justify="center", style="bold white on black", width=8)
        menu_table.add_column("TOOL NAME", justify="left", style="bold white on black", min_width=22)
        menu_table.add_column("STATUS", justify="center", style="bold white on black", min_width=16)

        menu_table.add_row("1", "UNPACK_PAK", "ONLINE")
        menu_table.add_row("2", "LUA_MAKE", "ONLINE")
        menu_table.add_row("3", "REPACK_SYSTEM", "ONLINE")
        menu_table.add_row("4", "ALVSIA_BUILD_PAK", "ONLINE")
        menu_table.add_row("5", "CLEAN_ALL", "ONLINE")
        menu_table.add_row("6", "CLOSE_TERMUX", "EXIT")

        border_color = ab.get_moving_border_style(0, 0.5)
        console.print(Panel(
            menu_table,
            title="[bold white on black]═══ MAIN MENU ═══[/bold white on black]",
            border_style=border_color,
            style="white on black",
            box=HEAVY,
            padding=(1, 1),
        ))

        # UI-only: expiry/license panel moved below the main menu.
        print_license_status_bottom(key_info)
        # Keep the input area OUTSIDE the animated panel.  The RGB frame is
        # calculated once per screen refresh; nothing redraws while input()
        # is waiting, so typing 1/2/etc. cannot corrupt the menu.
        console.print()
        console.print("[bold white on black]Enter your choice[/bold white on black]")
        choice = safe_input("").strip()

        # Do not flush stdin here. input() already consumed the newline;
        # flushing at this point can eat the next keystroke on Termux.
        if choice == '1':
            action_unpack_pak()
        elif choice == '2':
            lua_mode_menu()
        elif choice == '3':
            repack_system_menu()
        elif choice == '4':
            action_open_alvsia_build_pak()
        elif choice == '5':
            action_clean_all()
        elif choice == '6':
            action_close_termux()
            break
        else:
            hexa_alert("Invalid choice", "error")
            time.sleep(1)

def lua_mode_menu():
    ab = AnimatedBorder.get_instance()
    
    while True:
        print_main_banner("LUA_MAKE")
        
        # Same visual language as the reference screen; actions are unchanged.
        menu_table = Table(
            box=ROUNDED, show_header=True, header_style="bold white on black",
            padding=(0, 2), border_style=ab.get_moving_border_style(3, 0.55), style="white on black", expand=True
        )
        menu_table.add_column("OPTION", justify="center", style="bold white on black", width=8)
        menu_table.add_column("TOOL NAME", justify="left", style="bold white on black", min_width=22)
        menu_table.add_column("STATUS", justify="center", style="bold white on black", min_width=16)
        
        menu_table.add_row("1", "RECOMPILE", "ONLINE")
        menu_table.add_row("2", "DECOMPILE", "ONLINE")
        menu_table.add_row("3", "BACK", "EXIT")
        
        border_color = ab.get_moving_border_style(4, 0.5)
        console.print(Panel(menu_table, title="[bold white on black]═══ LUA_MAKE ═══[/bold white on black]", 
                            border_style=border_color, style="white on black", box=HEAVY, padding=(1, 2)))
        console.print()
        
        choice = hexa_prompt("Select option: ").strip()
        if choice == '1':
            action_repack_unpack()
        elif choice == '2':
            action_unpack()
        elif choice == '3':
            return
        else:
            hexa_alert("Invalid option", "error")
            time.sleep(1)

if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        console.print(f"\n[bold {WARN}]Interrupted. Exiting...[/bold {WARN}]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold {ERR}]FATAL: {escape(str(e))}[/bold {ERR}]")
        traceback.print_exc()
        safe_input('\nPress Enter to exit...')
        sys.exit(1)