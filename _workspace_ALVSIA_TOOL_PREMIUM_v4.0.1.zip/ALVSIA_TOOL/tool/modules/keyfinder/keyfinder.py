# DEV = @hacker420 official
# WP = 03313553052

import sys
import os
import time
import io
from pathlib import Path
from collections import defaultdict

# --- 
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
else:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    MAGENTA = '\033[35m'
    WHITE = '\033[97m'

CURRENT_LANG = 'en'

# ---
TEXTS = {
    'en': {
        'app_title': "SM4 KEY FINDER TOOL",
        'app_subtitle': "PUBG Mobile - RPAD Bypass",
        'developer': "Coded by HACKER420",
        'telegram': "Telegram",
        'whatsapp': "WhatsApp",
        'lang_prompt': "🌐 Select Language:",
        'lang_1': "1. English",
        'lang_2': "2. Urdu (Romanized)",
        'lang_3': "3. Chinese",
        'lang_4': "4. Vietnamese",
        'menu_scan': "📁 Scan Folder (.so files)",
        'menu_info': "🍑  Information / Introduction",
        'menu_exit': "🚪 Exit",
        'prompt_choice': "➜ Enter your choice (1/2/3)",
        'prompt_folder': "📂 Enter folder path",
        'prompt_return': "⏎ Press Enter to return to menu...",
        'error_path': "❌ Error: Path not found!",
        'error_no_so': "❌ Error: No .so files found!",
        'error_invalid': "⚠️ Invalid option! Please choose 1, 2, or 3.",
        'scan_total': "🔄 Processing {count} files...",
        'scan_complete': "✅ Complete!",
        'scan_error': "ERROR",
        'results_header': "🔍 SCAN RESULTS",
        'results_no': "⚠️ No SM4 keys found.",
        'results_found': "▶ {key_type}:",
        'info_what': "What is this tool?",
        'info_what_desc': "This is a state-of-the-art SM4 security key finder tool,\nspecifically designed to scan .so libraries of PUBG Mobile.",
        'info_what_does': "What does it do?",
        'info_what_does_desc': "It extracts the secret keys required to bypass the game's\nRPAD (Runtime Protection Anti-Debug) system, aiding in modding and analysis.",
        'info_how': "How does it work?",
        'info_how_desc': "It scans each .so file at the binary level and searches for\nspecific 20-character patterns:\n\n  1. SM4_SECRET_4 → At least 10 digits, 5 lowercase, no uppercase.\n  2. SM4_SECRET_2 → At least 1 symbol ($ or *), 5 uppercase, 3 lowercase, and 1 digit.\n  3. SM4_SECRET_NEW → Sequence pattern (lowercase, uppercase, digit).",
        'info_dev': "Developer",
        'info_version': "Version",
        'info_contact': "Contact Us",
        'goodbye': "👋 Goodbye! Thank you for using the tool developed by HACKER420."
    },
    'ur': {
        'app_title': "SM4 KEY FINDER TOOL",
        'app_subtitle': "PUBG Mobile - RPAD Bypass",
        'developer': "Coded by HACKER420",
        'telegram': "Telegram",
        'whatsapp': "WhatsApp",
        'lang_prompt': "🌐 Zabaan muntakhib karein:",
        'lang_1': "1. English",
        'lang_2': "2. Urdu (Romanized)",
        'lang_3': "3. Chinese",
        'lang_4': "4. Vietnamese",
        'menu_scan': "📁 Folder scan karein (.so files)",
        'menu_info': "🍑  Malumaat / Taaruf",
        'menu_exit': "🚪 Bahar niklein",
        'prompt_choice': "➜ Apna intikhab darj karein (1/2/3)",
        'prompt_folder': "📂 Folder ka path darj karein",
        'prompt_return': "⏎ Menu par wapas jaane ke liye Enter dabayein...",
        'error_path': "❌ Khata: Path nahi mila!",
        'error_no_so': "❌ Khata: Koi .so file nahi mili!",
        'error_invalid': "⚠️ Ghalat option! Baraye meharbani 1, 2 ya 3 mein se intekhab karein.",
        'scan_total': "🔄 Total {count} files process ho rahi hain...",
        'scan_complete': "✅ Mukammal!",
        'scan_error': "KHATA",
        'results_header': "🔍 SCAN KE NATAYEJ",
        'results_no': "⚠️ Koi bhi SM4 key nahi mili.",
        'results_found': "▶ {key_type}:",
        'info_what': "Yeh tool kya hai?",
        'info_what_desc': "Yeh ek jadeed tareen SM4 security key dhoondne wala tool hai,\njo khas tor par PUBG Mobile ki .so libraries ko scan karta hai.",
        'info_what_does': "Yeh kya karta hai?",
        'info_what_does_desc': "Yeh game ke RPAD (Runtime Protection Anti-Debug) system ko\nbypass karne ke liye zaroori secret keys nikalta hai,\njis se modding aur tajziye mein madad milti hai.",
        'info_how': "Yeh kaise kaam karta hai?",
        'info_how_desc': "Yeh har .so file ko binary level par scan karta hai aur 20 characters\nke khaas patterns ko dhoondta hai:\n\n  1. SM4_SECRET_4 → Kam az kam 10 digits, 5 chhote letters, koi bara letter nahi.\n  2. SM4_SECRET_2 → Kam az kam 1 symbol ($ ya *), 5 bare, 3 chhote, aur 1 digit.\n  3. SM4_SECRET_NEW → Letters ki tarteeb (chhota, bara, digit).",
        'info_dev': "Developer",
        'info_version': "Version",
        'info_contact': "Rabta karein",
        'goodbye': "👋 Alwida! HACKER420 ki taraf se tayyar karda tool istemal karne ka shukriya."
    },
    'zh': {
        'app_title': "SM4 KEY FINDER TOOL",
        'app_subtitle': "PUBG Mobile - RPAD Bypass",
        'developer': "Coded by HACKER420",
        'telegram': "Telegram",
        'whatsapp': "WhatsApp",
        'lang_prompt': "🌐 选择语言：",
        'lang_1': "1. 英语",
        'lang_2': "2. 乌尔都语（罗马化）",
        'lang_3': "3. 中文",
        'lang_4': "4. 越南语",
        'menu_scan': "📁 扫描文件夹 (.so 文件)",
        'menu_info': "🍑  信息 / 介绍",
        'menu_exit': "🚪 退出",
        'prompt_choice': "➜ 请输入您的选择 (1/2/3)",
        'prompt_folder': "📂 请输入文件夹路径",
        'prompt_return': "⏎ 按 Enter 键返回菜单...",
        'error_path': "❌ 错误: 路径未找到!",
        'error_no_so': "❌ 错误: 未找到 .so 文件!",
        'error_invalid': "⚠️ 无效选项! 请选择 1、2 或 3。",
        'scan_total': "🔄 共处理 {count} 个文件...",
        'scan_complete': "✅ 完成!",
        'scan_error': "错误",
        'results_header': "🔍 扫描结果",
        'results_no': "⚠️ 未找到任何 SM4 密钥。",
        'results_found': "▶ {key_type}:",
        'info_what': "这是什么工具？",
        'info_what_desc': "这是一款最先进的 SM4 安全密钥查找工具，\n专门设计用于扫描 PUBG Mobile 的 .so 库。",
        'info_what_does': "它有什么作用？",
        'info_what_does_desc': "它提取绕过游戏 RPAD（运行时保护反调试）系统\n所需的密钥，有助于修改和分析。",
        'info_how': "它是如何工作的？",
        'info_how_desc': "它在二进制级别扫描每个 .so 文件，并搜索\n特定的 20 个字符模式：\n\n  1. SM4_SECRET_4 → 至少 10 位数字，5 个小写字母，没有大写字母。\n  2. SM4_SECRET_2 → 至少 1 个符号（$ 或 *），5 个大写字母，3 个小写字母和 1 个数字。\n  3. SM4_SECRET_NEW → 序列模式（小写、大写、数字）。",
        'info_dev': "开发者",
        'info_version': "版本",
        'info_contact': "联系我们",
        'goodbye': "👋 再见！感谢使用由 HACKER420 开发的工具。"
    },
    'vi': {
        'app_title': "SM4 KEY FINDER TOOL",
        'app_subtitle': "PUBG Mobile - RPAD Bypass",
        'developer': "Coded by HACKER420",
        'telegram': "Telegram",
        'whatsapp': "WhatsApp",
        'lang_prompt': "🌐 Chọn ngôn ngữ:",
        'lang_1': "1. Tiếng Anh",
        'lang_2': "2. Tiếng Urdu (Latin hóa)",
        'lang_3': "3. Tiếng Trung",
        'lang_4': "4. Tiếng Việt",
        'menu_scan': "📁 Quét thư mục (tệp .so)",
        'menu_info': "🍑  Thông tin / Giới thiệu",
        'menu_exit': "🚪 Thoát",
        'prompt_choice': "➜ Nhập lựa chọn của bạn (1/2/3)",
        'prompt_folder': "📂 Nhập đường dẫn thư mục",
        'prompt_return': "⏎ Nhấn Enter để trở về menu...",
        'error_path': "❌ Lỗi: Không tìm thấy đường dẫn!",
        'error_no_so': "❌ Lỗi: Không tìm thấy tệp .so nào!",
        'error_invalid': "⚠️ Tùy chọn không hợp lệ! Vui lòng chọn 1, 2 hoặc 3.",
        'scan_total': "🔄 Đang xử lý {count} tệp...",
        'scan_complete': "✅ Hoàn tất!",
        'scan_error': "LỖI",
        'results_header': "🔍 KẾT QUẢ QUÉT",
        'results_no': "⚠️ Không tìm thấy khóa SM4 nào.",
        'results_found': "▶ {key_type}:",
        'info_what': "Công cụ này là gì?",
        'info_what_desc': "Đây là công cụ tìm kiếm khóa bảo mật SM4 tiên tiến,\nđược thiết kế đặc biệt để quét các thư viện .so của PUBG Mobile.",
        'info_what_does': "Nó làm gì?",
        'info_what_does_desc': "Nó trích xuất các khóa bí mật cần thiết để vượt qua hệ thống\nRPAD (Bảo vệ chống gỡ lỗi khi chạy) của trò chơi,\n hỗ trợ việc mod và phân tích.",
        'info_how': "Nó hoạt động như thế nào?",
        'info_how_desc': "Nó quét từng tệp .so ở cấp độ nhị phân để tìm kiếm\ncác mẫu cụ thể dài 20 ký tự:\n\n  1. SM4_SECRET_4 → Ít nhất 10 chữ số, 5 chữ thường, không có chữ hoa.\n  2. SM4_SECRET_2 → Ít nhất 1 ký hiệu ($ hoặc *), 5 chữ hoa, 3 chữ thường và 1 chữ số.\n  3. SM4_SECRET_NEW → Mẫu tuần tự (chữ thường, chữ hoa, chữ số).",
        'info_dev': "Nhà phát triển",
        'info_version': "Phiên bản",
        'info_contact': "Liên hệ",
        'goodbye': "👋 Tạm biệt! Cảm ơn bạn đã sử dụng công cụ được phát triển bởi HACKER420."
    }
}

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def t(key, **kwargs):
    text = TEXTS[CURRENT_LANG].get(key, key)
    if kwargs:
        return text.format(**kwargs)
    return text

# ---  HACKER420 ہیڈر (پیشہ ورانہ) ---
def print_beautiful_header():
    """رنگین ASCII آرٹ کے ساتھ HACKER420 ہیڈر"""
    print(f"""{Colors.RED}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║ {Colors.CYAN}██╗  ██╗ █████╗  ██████╗██╗  ██╗███████╗██████╗                      {Colors.RED}║
║ {Colors.CYAN}██║  ██║██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗                     {Colors.RED}║
║ {Colors.CYAN}███████║███████║██║     █████╔╝ █████╗  ██████╔╝                     {Colors.RED}║
║ {Colors.CYAN}██╔══██║██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗                     {Colors.RED}║
║ {Colors.CYAN}██║  ██║██║  ██║╚██████╗██║  ██╗███████╗██║  ██║                     {Colors.RED}║
║ {Colors.CYAN}╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                     {Colors.RED}║
║                                                                      ║
║                        {Colors.WHITE}HACKER                                        {Colors.RED}║
║                         {Colors.YELLOW}420                                          {Colors.RED}║
║                                                                      ║
║ {Colors.CYAN}Developer : HACKER 420                                               {Colors.RED}║
║ {Colors.CYAN}Telegram  : @hacker420official                                       {Colors.RED}║
║ {Colors.CYAN}WhatsApp  : +923313553052                                            {Colors.RED}║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
{Colors.ENDC}""")
def print_menu():
    
    print(f"{Colors.BOLD}┌──────────────────────────────────────────────────────────┐")
    print(f"│  {Colors.GREEN}1.{Colors.ENDC} {t('menu_scan')}{' ' * (42 - len(t('menu_scan')))}          │")
    print(f"│  {Colors.GREEN}2.{Colors.ENDC} {t('menu_info')}{' ' * (42 - len(t('menu_info')))}          │")
    print(f"│  {Colors.GREEN}3.{Colors.ENDC} {t('menu_exit')}{' ' * (42 - len(t('menu_exit')))}          │")
    print(f"└──────────────────────────────────────────────────────────┘{Colors.ENDC}")
    # --- رابطہ کی معلومات (Contact Info) نیچے رنگین ---

def draw_progress_bar(current, total, filename, length=30):
    percent = ("{0:.1f}").format(100 * (current / float(total)))
    filled_length = int(length * current // total)
    bar = '█' * filled_length + '░' * (length - filled_length)
    sys.stdout.write(f'\r{Colors.MAGENTA}[ {t("scan_error")} ]{Colors.ENDC} {Colors.YELLOW}{filename[:20]}{Colors.ENDC} |{Colors.GREEN}{bar}{Colors.ENDC}| {Colors.CYAN}{percent}%{Colors.ENDC} ')
    sys.stdout.flush()

def is_sm4_new_candidate(s):
    if len(s) != 20: return False
    for i in range(20):
        pos = i % 3
        if pos == 0 and not s[i].islower(): return False
        elif pos == 1 and not s[i].isupper(): return False
        elif pos == 2 and not s[i].isdigit(): return False
    return True

def is_sm4_4_candidate(s):
    if len(s) != 20: return False
    u = sum(1 for c in s if c.isupper())
    l = sum(1 for c in s if c.islower())
    d = sum(1 for c in s if c.isdigit())
    return d >= 10 and l >= 5 and u == 0 and all(c.isalnum() for c in s)

def is_sm4_2_candidate(s):
    if len(s) != 20: return False
    u = sum(1 for c in s if c.isupper())
    l = sum(1 for c in s if c.islower())
    d = sum(1 for c in s if c.isdigit())
    s_char = sum(1 for c in s if c in '$*')
    return s_char >= 1 and u >= 5 and l >= 3 and d >= 1

def scan_file_with_bar(filepath):
    results = {'SM4_SECRET_4': [], 'SM4_SECRET_2': [], 'SM4_SECRET_NEW': []}
    try:
        content = filepath.read_bytes()
        total_len = len(content)
        target_len = 20
        for i in range(0, total_len - (target_len * 2), 2):
            if i % 500000 == 0:
                draw_progress_bar(i, total_len, filepath.name)
            chunk = content[i:i + target_len * 2]
            if all(b == 0 for b in chunk[1::2]) and all(32 <= b < 127 for b in chunk[0::2]):
                s = bytes(chunk[0::2]).decode('ascii', errors='ignore')
                if ' ' not in s:
                    if is_sm4_4_candidate(s): results['SM4_SECRET_4'].append(s)
                    elif is_sm4_2_candidate(s): results['SM4_SECRET_2'].append(s)
                    elif is_sm4_new_candidate(s): results['SM4_SECRET_NEW'].append(s)
        draw_progress_bar(total_len, total_len, filepath.name)
        print(f" {Colors.GREEN}{t('scan_complete')}{Colors.ENDC}")
    except Exception as e:
        print(f"\n{Colors.RED}❌ {t('scan_error')}: {e}{Colors.ENDC}")
    return results

def show_info():
    clear_screen()
    print(f"{Colors.MAGENTA}{Colors.BOLD}╔════════════════════════════════════════════════════════════════════╗")
    print(f"║  {Colors.YELLOW}                    📚 {t('menu_info').upper()} 📚{Colors.MAGENTA}                    ║")
    print(f"╚════════════════════════════════════════════════════════════════════╝{Colors.ENDC}")
    print(f"""
{Colors.CYAN}📌 {t('info_what')}{Colors.ENDC}
    {t('info_what_desc')}

{Colors.CYAN}🎯 {t('info_what_does')}{Colors.ENDC}
    {t('info_what_does_desc')}

{Colors.CYAN}🔍 {t('info_how')}{Colors.ENDC}
    {t('info_how_desc')}

{Colors.MAGENTA}{Colors.BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.ENDC}
{Colors.CYAN}⚙️  {t('info_dev')}{Colors.ENDC}  : {Colors.YELLOW}{Colors.BOLD}HACKER420{Colors.ENDC}
{Colors.CYAN}📅 {t('info_version')}{Colors.ENDC} : {Colors.GREEN}5.0 (Colorful Edition){Colors.ENDC}
{Colors.MAGENTA}{Colors.BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.ENDC}
{Colors.YELLOW}📱 {t('telegram')}{Colors.ENDC}  : {Colors.BLUE}@hacker420official{Colors.ENDC}
{Colors.YELLOW}📞 {t('whatsapp')}{Colors.ENDC} : {Colors.GREEN}03313553052{Colors.ENDC}
{Colors.MAGENTA}{Colors.BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.ENDC}
    """)
    input(f"{Colors.BLUE}{t('prompt_return')}{Colors.ENDC}")

def scan_folder_process():
    print(f"\n{Colors.MAGENTA}{Colors.BOLD}╔══════════════════════════════════════════════════════════════╗{Colors.ENDC}")
    input_path = input(f"{Colors.BOLD}║  {Colors.GREEN}{t('prompt_folder')} {Colors.ENDC}➜ ")
    folder = Path(input_path) if input_path else Path(".")
    if not folder.exists():
        print(f"{Colors.RED}❌ {t('error_path')}{Colors.ENDC}")
        time.sleep(1)
        return
    so_files = list(folder.glob("**/*.so"))
    if not so_files:
        print(f"{Colors.RED}❌ {t('error_no_so')}{Colors.ENDC}")
        time.sleep(1)
        return
    print(f"{Colors.MAGENTA}{Colors.BOLD}╚══════════════════════════════════════════════════════════════╝{Colors.ENDC}")
    print(f"\n{Colors.BOLD}{Colors.CYAN}🔄 {t('scan_total', count=len(so_files))}{Colors.ENDC}")
    all_secrets = defaultdict(set)
    for idx, so_file in enumerate(so_files, 1):
        print(f"{Colors.YELLOW}[{idx}/{len(so_files)}]{Colors.ENDC}", end=" ")
        file_results = scan_file_with_bar(so_file)
        for k, v in file_results.items():
            for secret in v:
                all_secrets[k].add(secret)
    # --- نتائج ---
    print(f"\n\n{Colors.BOLD}{Colors.HEADER}╔════════════════════════════════════════════════════╗")
    print(f"║           {Colors.RED}🔍 {t('results_header')} {Colors.MAGENTA}🔍           ║")
    print(f"╚════════════════════════════════════════════════════╝{Colors.ENDC}")
    if not any(all_secrets.values()):
        print(f"\n{Colors.RED}{t('results_no')}{Colors.ENDC}")
    else:
        for key_type in ['SM4_SECRET_4', 'SM4_SECRET_2', 'SM4_SECRET_NEW']:
            secrets = sorted(all_secrets[key_type])
            if secrets:
                print(f"\n{Colors.YELLOW}▶ {key_type}:{Colors.ENDC}")
                for s in secrets:
                    print(f"  {Colors.GREEN}▪{Colors.ENDC} '{s}'")
    input(f"\n{Colors.BLUE}{t('prompt_return')}{Colors.ENDC}")

def main():
    global CURRENT_LANG
    clear_screen()
    
    print(f"{Colors.MAGENTA}{Colors.BOLD}╔══════════════════════════════════════════════════════════════╗")
    print(f"║  {Colors.YELLOW}🌍 {t('lang_prompt')}{Colors.MAGENTA}                                      ║")
    print(f"║  {Colors.GREEN}1.{Colors.ENDC} {t('lang_1')}{' ' * (45 - len(t('lang_1')))}            ║")
    print(f"║  {Colors.BLUE}2.{Colors.ENDC} {t('lang_2')}{' ' * (45 - len(t('lang_2')))}            ║")
    print(f"║  {Colors.RED}3.{Colors.ENDC} {t('lang_3')}{' ' * (45 - len(t('lang_3')))}            ║")
    print(f"║  {Colors.CYAN}4.{Colors.ENDC} {t('lang_4')}{' ' * (45 - len(t('lang_4')))}            ║")
    print(f"╚══════════════════════════════════════════════════════════════╝{Colors.ENDC}")
    while True:
        choice = input(f"\n{Colors.GREEN}➜ {t('prompt_choice')} (1/2/3/4) > {Colors.ENDC}")
        if choice == '1':
            CURRENT_LANG = 'en'
            break
        elif choice == '2':
            CURRENT_LANG = 'ur'
            break
        elif choice == '3':
            CURRENT_LANG = 'zh'
            break
        elif choice == '4':
            CURRENT_LANG = 'vi'
            break
        else:
            print(f"{Colors.RED}⚠️ {t('error_invalid')}{Colors.ENDC}")
    # --- مرکزی لوپ ---
    while True:
        clear_screen()
        print_beautiful_header()
        print()
        print_menu()
        print()
        choice = input(f"{Colors.GREEN}➜ {t('prompt_choice')} > {Colors.ENDC}")
        if choice == '1':
            scan_folder_process()
        elif choice == '2':
            show_info()
        elif choice == '3':
            print(f"\n{Colors.YELLOW}{t('goodbye')}{Colors.ENDC}")
            sys.exit(0)
        else:
            print(f"{Colors.RED}⚠️ {t('error_invalid')}{Colors.ENDC}")
            time.sleep(1)

if __name__ == "__main__":
    main()