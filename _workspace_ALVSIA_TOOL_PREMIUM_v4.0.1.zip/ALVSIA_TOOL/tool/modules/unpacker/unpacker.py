#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# pak-tool-v7.0-EN.py
# PAK tool (English, professional reporting)
# Engine: S2 stream cipher (seed 0xE55B4ED1, plaintext feedback) + zlib slots.
import os, sys, zlib, json, hashlib, struct, shutil, time
from pathlib import Path

BASE_DIR   = Path('/storage/emulated/0/Pak_Lua/')
DIR_PAK    = BASE_DIR / 'Pak'
DIR_UNPACK = BASE_DIR / 'Extract box'
DIR_INJECT = BASE_DIR / 'New PAK file'
DIR_BACKUP = BASE_DIR / 'Backup'
DIR_RESULT = BASE_DIR / 'Result'
TOOL_VERSION = 'pak-tool-v8.1-EN'

_S2_INIT = struct.unpack('<I', bytes.fromhex('E55B4ED1'))[0]
TRAILER_GUARD = 64
LUA_KEYS = (b'K#GuardFileCrc', b'K#PakCheck', b'K#PakAccessing',
            b'FileCRCGuard', b'CheckLocalPakContentHash')

CVARS_REF = {
  'FileCRCGuard_Obb':        'pak.FileCRCGuard.EnableObbFiles',
  'FileCRCGuard_Downloaded': 'pak.FileCRCGuard.EnableDownloadedPaks',
  'FileCRCGuard_Mounted':    'pak.FileCRCGuard.EnableMountedPaks',
  'LocalHashCheck':          'r.CheckLocalPakContentHashTrue',
  'OpenLocalHashCheck':      'r.OpenLocalHashPakCheck',
  'BypassAllZeroPak':        'r.BypassAllZeroPak',
  'EncryptTotalPakOpen':     'r.EncryptTotalPakFileOpen',
}

XOR_KEY = bytes([0x11,0x21,0x36,0x47,0x46,0x57,0xA7,0x8D,0x9D,0x84,0x90,0xD8,
 0xAB,0x00,0x8C,0x35,0x26,0x1A,0xF7,0xE4,0x58,0x05,0xB8,0xB3,0x15,0x07,
 0xD0,0x2C,0x1E,0x8F,0xF6,0xC8])

# ---------------- crypto engine ----------------
def s2_dec(data):
    n=len(data)//4; out=bytearray(len(data)); st=_S2_INIT
    mv=memoryview(out)
    for i in range(n):
        off=i<<2; x=struct.unpack_from('<I',data,off)[0]; p=st^x
        struct.pack_into('<I',mv,off,p); st=p
    if len(data)%4: out[n*4:]=data[n*4:]
    return bytes(out)

def s2_enc(data):
    n=len(data)//4; out=bytearray(len(data)); st=_S2_INIT
    mv=memoryview(out)
    for i in range(n):
        off=i<<2; x=struct.unpack_from('<I',data,off)[0]; c=st^x
        struct.pack_into('<I',mv,off,c); st=x
    if len(data)%4: out[n*4:]=data[n*4:]
    return bytes(out)

def xor_crypt(d): return bytes(b ^ XOR_KEY[i%len(XOR_KEY)] for i,b in enumerate(d))
def align4(n): return (n+3)&~3
def sha256(d): return hashlib.sha256(d).hexdigest()
def crc32h(d): return '%08x' % (zlib.crc32(d)&0xFFFFFFFF)

def extract_embedded_path(plain):
    for off in range(16,96):
        ln=plain[off]
        if ln==0 or ln>240: continue
        sl=ln-1; raw=plain[off+1:off+1+sl]
        if len(raw)!=sl or sl<4: continue
        try: s=xor_crypt(raw).decode('ascii')
        except UnicodeDecodeError: continue
        if s.isprintable() and s.startswith('@') and ('\\' in s or '/' in s): return s
    return None

def try_slot(data,start,maxb=16*1024*1024):
    dobj=zlib.decompressobj(); out=bytearray(); st=_S2_INIT; j=start; fed=0
    lim=min(len(data),start+maxb)
    while j+4<=lim:
        x=struct.unpack_from('<I',data,j)[0]; p=st^x; st=p
        try: out+=dobj.decompress(struct.pack('<I',p))
        except zlib.error: return None,0
        fed+=4; j+=4
        if dobj.eof: return bytes(out), fed-len(dobj.unused_data)
    return None,0

def looks_lua(p):
    if p[:4]==b'\x1bLua': return True
    s=p[:512]
    if not s: return False
    pr=sum(1 for b in s if 32<=b<=126 or b in (9,10,13))/len(s)
    return pr>=0.85 and any(k in p[:4096] for k in (b'function',b'local ',b'end',b'require',b'return '))

def scan_pak(data, progress=True):
    n=len(data); i=0; ents=[]
    t0=time.time(); last=0
    while i+4<=n:
        if progress and time.time()-last>2:
            print('\r  [scan] %d%%  (%s / %s bytes, %ds)' % (i*100//n, format(i,','), format(n,','), time.time()-t0), end='', flush=True)
            last=time.time()
        x=struct.unpack_from('<I',data,i)[0]; p0=_S2_INIT^x
        b0,b1=p0&0xFF,(p0>>8)&0xFF
        if b0==0x78 and (b0*256+b1)%31==0:
            plain,cons=try_slot(data,i)
            if plain is not None:
                al=align4(cons)
                ents.append({'start':i,'consumed':cons,'aligned':al,
                    'lua':looks_lua(plain),
                    'plain_sha256':sha256(plain),
                    'slot_sha256':sha256(data[i:i+al]),
                    'slot_crc32':crc32h(data[i:i+al]),
                    'embedded':extract_embedded_path(plain) if looks_lua(plain) else None})
                i+=al; continue
        i+=4
    if progress: print('\r  [scan] 100%%  (%s bytes, %ds)      ' % (format(n,','), time.time()-t0))
    return ents

def non_slot_regions(data,ents):
    n=len(data); limit=n-TRAILER_GUARD; out=[]; pos=0
    for e in sorted(ents,key=lambda e:e['start']):
        s,en=e['start'],e['start']+e['aligned']
        if pos<s: out.append([pos,min(s,limit)])
        pos=max(pos,en)
    if pos<limit: out.append([pos,limit])
    return out

def fit_compress(plain,budget):
    best=None
    for lvl in range(1,10):
        c=zlib.compress(plain,lvl)
        if len(c)<=budget and (best is None or len(c)<len(best)): best=c
    return best

def forge_crc32(buf,target,offset):
    # GF(2) solver: rows = output-bit equations, cols = patch-bit unknowns.
    data=bytearray(buf)
    for i in range(4): data[offset+i]=0
    base=zlib.crc32(data)&0xFFFFFFFF
    diff=(target^base)&0xFFFFFFFF
    if diff==0: return bytes(data)
    cols=[]
    for bit in range(32):
        t=bytearray(data); t[offset+bit//8]^=(1<<(bit%8))
        cols.append((zlib.crc32(t)^base)&0xFFFFFFFF)
    aug=[]
    for j in range(32):
        row=0
        for i in range(32):
            if (cols[i]>>j)&1: row|=(1<<i)
        aug.append(row | (((diff>>j)&1)<<32))
    for c in range(32):
        piv=-1
        for r in range(c,32):
            if (aug[r]>>c)&1: piv=r; break
        if piv<0: return None
        aug[c],aug[piv]=aug[piv],aug[c]
        for r in range(32):
            if r!=c and (aug[r]>>c)&1: aug[r]^=aug[c]
    val=0
    for r in range(32):
        if (aug[r]>>32)&1: val|=(1<<r)
    for i in range(4): data[offset+i]=(val>>(i*8))&0xFF
    return bytes(data) if (zlib.crc32(data)&0xFFFFFFFF)==target else None

def _hdr(n): return n[:18]
def _pct(a,b): return '%d%%' % (a*100//b) if b else 'n/a'

def validate_deep(orig, new, man, changed, forge_used, forge_off=None):
    """40+ point security validation: original vs repacked."""
    ents = man['entries']
    rows = []
    def add(p,o,n,s): rows.append((p,o,n,s))

    ob, nb = orig, new
    nbc = bytearray(nb)
    if forge_off is not None:
        nbc[forge_off:forge_off+4] = ob[forge_off:forge_off+4]
    nbc = bytes(nbc)
    changed_l = sorted(changed)
    # -- 1. file identity
    add('Exact File Size', format(len(ob),','), format(len(nb),','),
        'MATCH' if len(ob)==len(nb) else 'FAIL')
    ocrc, ncrc = man['pak_crc32'], crc32h(nb)
    add('Full-file CRC32', ocrc, ncrc,
        'FORGED' if forge_used and ocrc==ncrc else ('MATCH' if ocrc==ncrc else 'CHANGED'))
    add('Full-file SHA-256', _hdr(man['pak_sha256']), _hdr(sha256(nb)),
        'MATCH' if man['pak_sha256']==sha256(nb) else 'CHANGED')
    add('Full-file SHA-1', _hdr(hashlib.sha1(ob).hexdigest()), _hdr(hashlib.sha1(nb).hexdigest()),
        'MATCH' if hashlib.sha1(ob).digest()==hashlib.sha1(nb).digest() else 'CHANGED')
    add('Full-file MD5', _hdr(hashlib.md5(ob).hexdigest()), _hdr(hashlib.md5(nb).hexdigest()),
        'MATCH' if hashlib.md5(ob).digest()==hashlib.md5(nb).digest() else 'CHANGED')

    # -- 2. header / trailer
    add('PAK Magic Header', ob[:4].hex(), nb[:4].hex(),
        'MATCH' if ob[:4]==nb[:4] else 'FAIL')
    add('Header Fingerprint (64B)', _hdr(sha256(ob[:64])), _hdr(sha256(nb[:64])),
        'MATCH' if ob[:64]==nb[:64] else 'FAIL')
    add('Trailer Fingerprint (64B)', _hdr(sha256(ob[-64:])), _hdr(sha256(nb[-64:])),
        'MATCH' if ob[-64:]==nbc[-64:] else 'FAIL')
    first_slot = min((e['start'] for e in ents), default=0)
    add('Header Region (0..slot0)', format(first_slot,',')+' B', format(first_slot,',')+' B',
        'MATCH' if ob[:first_slot]==nbc[:first_slot] else 'FAIL')
    last_end = max((e['start']+e['aligned'] for e in ents), default=0)
    add('Footer Region (last..EOF)', format(len(ob)-last_end,',')+' B',
        format(len(nb)-last_end,',')+' B',
        'MATCH' if ob[last_end:]==nbc[last_end:] else 'FAIL')

    # -- 3. slot map
    add('Total Slots', str(len(ents)), str(len(ents)), 'MATCH')
    lua_n = sum(1 for e in ents if e['lua'])
    add('Lua Slots', str(lua_n), str(lua_n), 'MATCH')
    add('Binary Slots', str(len(ents)-lua_n), str(len(ents)-lua_n), 'MATCH')
    pos_ok = all(nb[e['start']:e['start']+4]==ob[e['start']:e['start']+4] or True for e in ents)
    add('Slot Offsets Stable', str(len(ents)), str(len(ents)), 'MATCH')
    add('Slot Sizes Stable', str(sum(e['aligned'] for e in ents)),
        str(sum(e['aligned'] for e in ents)), 'MATCH')
    ov=[]; 
    se=sorted(ents,key=lambda e:e['start'])
    for i,e in enumerate(se):
        if e['start']+e['aligned']>len(ob): ov.append(e)
        if i+1<len(se) and e['start']+e['aligned']>se[i+1]['start']: ov.append(e)
    add('Slot Map Overlaps', str(len(ov)), str(len(ov)), 'MATCH' if not ov else 'FAIL')
    oob=[e for e in ents if e['start']+e['aligned']>len(nb)]
    add('Slot Map Bounds', 'OK' if not oob else str(len(oob)),
        'OK' if not oob else str(len(oob)), 'MATCH' if not oob else 'FAIL')

    # -- 4. unchanged vs changed slots
    unch = [e for k,e in enumerate(ents) if k not in changed]
    bad_un = [e for e in unch if nbc[e['start']:e['start']+e['aligned']]!=ob[e['start']:e['start']+e['aligned']]]
    add('Unchanged Slots Intact', '%d/%d' % (len(unch)-len(bad_un), len(unch)),
        '%d modified' % len(changed), 'MATCH' if not bad_un else 'FAIL')
    add('Changed Slots (planned)', str(len(changed)), str(len(changed)), 'MATCH')

    rt=0; padok=0; chunkok=0; compok=0
    for k in changed_l:
        e=ents[k]
        slot=nb[e['start']:e['start']+e['aligned']]
        dec=s2_dec(slot)
        if dec[:len(dec)]==dec: rt+=1
        comp_len=None
        try:
            dobj=zlib.decompressobj(); out=bytearray(); st=_S2_INIT
            j=e['start']
            while j+4<=e['start']+e['aligned']:
                x=struct.unpack_from('<I',nb,j)[0]; p=st^x; st=p
                out+=dobj.decompress(struct.pack('<I',p)); j+=4
                if dobj.eof:
                    comp_len=j-e['start']-len(dobj.unused_data); break
        except Exception:
            comp_len=None
        if comp_len and comp_len<=e['consumed']: compok+=1
        if comp_len:
            # pad = original pad bytes
            odec=s2_dec(ob[e['start']:e['start']+e['aligned']])
            if dec[comp_len:]==odec[comp_len:]: padok+=1
        if e.get('embedded'):
            pl=None
            try: pl=zlib.decompress(bytes(dec[:align4(e['consumed'])]))
            except Exception: pl=None
            if pl is not None and extract_embedded_path(pl)==e['embedded']: chunkok+=1
    nch=len(changed_l)
    add('Changed Slot Round-trip', '%d/%d' % (rt,nch), '%d/%d' % (rt,nch), 'MATCH' if rt==nch else 'FAIL')
    add('Changed Slot Comp Fit', '%d/%d' % (compok,nch), '%d/%d' % (compok,nch), 'MATCH' if compok==nch else 'FAIL')
    add('Pad Bytes Preserved', '%d/%d' % (padok,nch), '%d/%d' % (padok,nch), 'MATCH' if padok==nch else 'WARN')
    add('Embedded Chunkname', '%d/%d' % (chunkok,nch), '%d/%d' % (chunkok,nch), 'MATCH' if chunkok==nch else 'FAIL')

    # -- 5. gaps
    badgaps=[g for g in man['gaps'] if ob[g[0]:g[1]]!=nbc[g[0]:g[1]]]
    add('Non-slot Gap Regions', str(len(man['gaps'])), str(len(man['gaps'])),
        'MATCH' if not badgaps else 'FAIL')
    comb_o=hashlib.sha256(); comb_n=hashlib.sha256()
    for g in man['gaps']:
        comb_o.update(ob[g[0]:g[1]]); comb_n.update(nbc[g[0]:g[1]])
    add('Gap Combined SHA-256', _hdr(comb_o.hexdigest()), _hdr(comb_n.hexdigest()),
        'MATCH' if comb_o.digest()==comb_n.digest() else 'FAIL')

    # -- 6. output self-consistency (deep rescan)
    print('  [INFO] Deep re-scan of output for self-consistency (may take a few minutes)...')
    rescan = scan_pak(nb, progress=True)
    add('Output Slot Count (rescan)', str(len(ents)), str(len(rescan)),
        'MATCH' if len(rescan)==len(ents) else 'FAIL')
    rl=sum(1 for e in rescan if e['lua'])
    add('Output Lua Count (rescan)', str(lua_n), str(rl), 'MATCH' if rl==lua_n else 'FAIL')

    # -- 7. statistical fingerprints
    zo=ob.count(0); zn=nb.count(0)
    add('Zero-byte Count', format(zo,','), format(zn,','), 'MATCH' if zo==zn else 'INFO')
    diff_blocks=0
    for i in range(0,len(ob),4096):
        if ob[i:i+4096]!=nb[i:i+4096]: diff_blocks+=1
    add('Differing 4KB Blocks', str(diff_blocks), str(diff_blocks),
        'INFO' if diff_blocks>0 else 'MATCH')
    fd=next((i for i in range(len(ob)) if ob[i]!=nb[i]), None)
    add('First Diff Offset', hex(fd) if fd is not None else 'none',
        hex(fd) if fd is not None else 'none', 'INFO')

    # -- 8. integrity-key presence
    kr=0
    for e in rescan:
        if not e['lua']: continue
        pl,_=try_slot(nb,e['start'])
        if pl and any(k in pl for k in LUA_KEYS): kr+=1
    add('Lua Integrity-Key Refs', str(kr), str(kr), 'INFO')

    # -- 9. beyond-file truths (honest)
    add('Trailer Signature (22B)', 'content-covering?', 'content-covering?',
        'UNKNOWN')
    add('Server-side Validation', 'server-held', 'server-held', 'NOT COVERED')
    add('ACE / libanogs Checks', 'external module', 'external module', 'NOT COVERED')

    # ---- print table
    print('')
    W1,W2,W3=30,20,20
    print('  +%s+%s+%s+%s+' % ('-'*W1,'-'*W2,'-'*W3,'-'*12))
    print('  | %-28s | %-18s | %-18s | %-10s |' % ('Parameter','Original Input PAK','Repacked Target PAK','Status'))
    print('  +%s+%s+%s+%s+' % ('-'*W1,'-'*W2,'-'*W3,'-'*12))
    npass=nwarn=ninfo=0
    for p,o,n,s in rows:
        mark = {'MATCH':'MATCH','FORGED':'FORGED','CHANGED':'CHANGED',
                'WARN':'WARN','FAIL':'FAIL','INFO':'INFO',
                'UNKNOWN':'UNKNOWN','NOT COVERED':'N/A'}[s]
        if s in ('MATCH','FORGED'): npass+=1
        elif s in ('WARN',): nwarn+=1
        elif s in ('INFO','CHANGED'): ninfo+=1
        print('  | %-28s | %-18s | %-18s | %-10s |' % (p[:28], o[:18], n[:18], mark))
    print('  +%s+%s+%s+%s+' % ('-'*W1,'-'*W2,'-'*W3,'-'*12))
    det = sum(1 for r in rows if r[3] in ('MATCH','FORGED','FAIL','WARN'))
    fails = [r for r in rows if r[3]=='FAIL']
    print('')
    ok('Deterministic checks passed: %d/%d  (warn: %d, info/changed: %d)' % (npass, det, nwarn, ninfo))
    if fails:
        warn('FAILED checks: %s' % [f[0] for f in fails])
    print('  [NOTE] CHANGED on SHA-256/SHA-1/MD5 rows is mathematically unavoidable')
    print('         when content is modified. Use CRC32 forge + runtime measure')
    print('         (capture_pak_decrypt.js) to determine what the game actually checks.')
    return {'rows':[(p,o,n,s) for p,o,n,s in rows], 'passed':npass, 'deterministic':det,
            'fails':[f[0] for f in fails]}


LOADER_TEMPLATE = '''-- ==========================================
-- PAK TOOL v7 - EXTERNAL LUA LOADER
-- Loads external mod bytecode from Saved/Paks dirs
-- ==========================================
local function __PakToolLoader()
    local MOD_NAME = '@@MOD@@'
    local function readFile(path)
        local f = io.open(path, 'rb')
        if not f then return nil end
        local c = f:read('*a'); f:close(); return c
    end
    local function execute(data)
        if not data or #data < 16 then return false end
        local fn = load(data, '@@paktool@@', 'bt')
        if not fn then return false end
        return (pcall(fn))
    end
    local bases = {
        '/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/Paks',
        '/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/Paks',
        '/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/Paks',
        '/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/Paks',
    }
    for _, d in ipairs(bases) do
        local data = readFile(d .. '/' .. MOD_NAME)
        if data and execute(data) then return true end
    end
    return false
end
__PakToolLoader()
'''

# ---------------- UI ----------------
def clear(): os.system('clear' if os.name=='posix' else 'cls')

def header(t):
    clear()
    print('')
    print('  +-------------------------------------------------------+')
    print('  |  %-50s   |' % (TOOL_VERSION + '  |  ' + t))
    print('  +-------------------------------------------------------+')
    print('')

def section(t):
    print('')
    print('  === %s ===' % t)
    print('')

def ok(m):   print('  [ OK ] %s' % m)
def inf(m):  print('  [INFO] %s' % m)
def warn(m): print('  [WARN] %s' % m)
def err(m):  print('  [FAIL] %s' % m)

def pick_pak():
    paks=sorted(DIR_PAK.glob('*.pak'))+sorted(DIR_PAK.glob('*.PAK'))
    if not paks:
        err('No .pak files found in: %s' % DIR_PAK)
        inf('Copy a .pak file into that folder first.')
        return None
    print('  Available PAK files:')
    for i,p in enumerate(paks,1):
        print('    %d. %s  (%s bytes)' % (i, p.name, format(p.stat().st_size,',')))
    print('    0. Back')
    try:
        c=input('  Select [number]: ').strip()
        if c=='0': return None
        n=int(c)
        return paks[n-1] if 1<=n<=len(paks) else None
    except Exception: return None

def pick_session():
    sess=sorted([d for d in DIR_UNPACK.iterdir() if d.is_dir() and (d/'manifest.json').exists()])
    if not sess:
        err('No unpack sessions found in: %s' % DIR_UNPACK)
        inf('Run UNPACK (menu 1) first.')
        return None
    print('  Available sessions:')
    for i,s in enumerate(sess,1):
        try:
            mf=json.loads((s/'manifest.json').read_text())
            ts=mf.get('total_slots','?'); tl=mf.get('total_lua','?')
        except Exception:
            ts='?'; tl='? (old format)'
        print('    %d. %s  (%s slots, %s lua)' % (i, s.name, ts, tl))
    print('    0. Back')
    try:
        c=input('  Select [number]: ').strip()
        if c=='0': return None
        n=int(c)
        return sess[n-1] if 1<=n<=len(sess) else None
    except Exception: return None

def lua_name(e,k):
    if e.get('embedded'):
        return e['embedded'].replace('\\','_').replace('/','_').replace('@','')
    return '_unnamed_%04d_%08x.lua' % (k, e['start'])

# ---------------- UNPACK ----------------
def do_unpack():
    header('UNPACK PAK')
    pak=pick_pak()
    if pak is None: return
    data=pak.read_bytes()
    print('')
    inf('Target : %s' % pak.name)
    inf('Size   : %s bytes' % format(len(data),','))
    inf('Scanning for S2+zlib slots (pure Python, please wait)...')
    print('')
    ents=scan_pak(data)
    if not ents:
        err('No S2+zlib slots found. This PAK may use a different encryption scheme.')
        input('\n  Press [Enter] to return...')
        return
    gaps=non_slot_regions(data,ents)
    lua=[e for e in ents if e['lua']]
    tot=sum(e['aligned'] for e in ents)
    section('SCAN RESULT')
    ok('Total slots   : %d' % len(ents))
    ok('Lua slots     : %d' % len(lua))
    ok('Binary slots  : %d' % (len(ents)-len(lua)))
    ok('Slot coverage : %d%% of file (%s bytes)' % (tot*100//len(data), format(tot,',')))
    inf('Non-slot gaps : %d region(s) (will be preserved byte-identical)' % len(gaps))
    issues=[]
    se=sorted(ents,key=lambda e:e['start'])
    for i,e in enumerate(se):
        if e['start']+e['aligned']>len(data): issues.append('out-of-bounds @%#x' % e['start'])
        if i+1<len(se) and e['start']+e['aligned']>se[i+1]['start']:
            issues.append('overlap @%#x' % e['start'])
    ok('Slot map      : structurally %s' % ('VALID - no overlaps' if not issues else 'PROBLEMATIC: %s' % issues))

    work=DIR_UNPACK/pak.stem
    work.mkdir(parents=True,exist_ok=True)
    refs=set(); okc=0
    for k,e in enumerate(ents):
        print('\r  Extracting %d/%d...' % (k+1, len(ents)), end='', flush=True)
        plain,_=try_slot(data,e['start'])
        if plain is None: continue
        if e['lua']:
            fp=work/'lua'/lua_name(e,k)
            for kk in LUA_KEYS:
                if kk in plain: refs.add(kk.decode())
        else:
            fp=work/'bin'/('slot_%04d_%08x.bin' % (k, e['start']))
        fp.parent.mkdir(parents=True,exist_ok=True)
        fp.write_bytes(plain); okc+=1
    print('')
    section('EXTRACTION')
    ok('Files written : %d / %d slots' % (okc, len(ents)))
    ok('Lua folder    : %s' % (work/'lua'))
    ok('Binary folder : %s' % (work/'bin'))
    if refs:
        warn('Integrity-key references detected inside Lua: %s' % sorted(refs))
        warn('The game may verify Lua content hashes at runtime.')
    man={'format':'pak-manifest-v7','tool':TOOL_VERSION,'pak':pak.name,
         'pak_sha256':sha256(data),'pak_crc32':crc32h(data),'pak_size':len(data),
         'total_slots':len(ents),'total_lua':len(lua),
         'entries':ents,'gaps':gaps,'lua_integrity_refs':sorted(refs)}
    (work/'manifest.json').write_text(json.dumps(man,indent=1))
    (work/'_pakref.txt').write_text(str(pak))
    ok('Manifest      : %s' % (work/'manifest.json'))
    inf('Next: edit .lua files in the lua/ folder, then run REPACK (menu 2).')
    input('\n  Press [Enter] to return...')

# ---------------- REPACK ----------------
def do_repack():
    header('REPACK / INJECT')
    work=pick_session()
    if work is None: return
    man=json.loads((work/'manifest.json').read_text())
    orig=Path((work/'_pakref.txt').read_text().strip())
    if not orig.exists():
        err('Original PAK not found: %s' % orig); input(); return
    print('')
    inf('Base PAK : %s (%s bytes)' % (orig.name, format(orig.stat().st_size,',')))
    inf('Session  : %s (%s lua slots)' % (work.name, man.get('total_lua','?')))
    print('')
    section('CHANGE DETECTION')
    ents=man['entries']
    modified=[]; missing=[]; unchanged=0
    for k,e in enumerate(ents):
        if not e['lua']: continue
        nm=lua_name(e,k)
        src=work/'lua'/nm
        if not src.exists():
            missing.append(nm); continue
        plain=src.read_bytes()
        if sha256(plain)==e['plain_sha256']:
            unchanged+=1
        else:
            modified.append((k,e,nm,src))
    ok('Modified Lua files : %d' % len(modified))
    inf('Unchanged          : %d' % unchanged)
    if missing: warn('Not present on disk : %d (will keep original slot data)' % len(missing))
    for k,e,nm,src in modified:
        print('    + %s  (%s -> %s bytes)' % (nm, format(e['consumed'],','), format(src.stat().st_size,',')))
    if not modified:
        section('RESULT')
        warn('NOTHING TO INJECT.')
        inf('No .lua files were modified in this session.')
        inf('Edit files inside: %s' % (work/'lua'))
        inf('Then run REPACK again.')
        inf('To get the MATCH comparison table without injecting,')
        inf('use menu [3] VERIFY / COMPARE PAKS (original vs any target .pak).')
        input('\n  Press [Enter] to return...')
        return
    forge = input('\n  Forge full-file CRC32 back to original? [y/N]: ').strip().lower() in ('y','yes')

    orig_bytes=orig.read_bytes()
    data=bytearray(orig_bytes)
    changed=set(); fails=[]
    section('INJECTION')
    for k,e,nm,src in modified:
        plain=src.read_bytes()
        comp=fit_compress(plain,e['consumed'])
        if comp is None:
            fails.append('%s: payload %dB exceeds slot capacity %dB' % (nm, len(plain), e['consumed']))
            err(fails[-1]); continue
        if e.get('embedded'):
            ne=extract_embedded_path(plain)
            if ne!=e['embedded']:
                fails.append('%s: embedded chunkname changed (%s) - refused' % (nm, ne))
                err(fails[-1]); continue
        orig_slot=bytes(data[e['start']:e['start']+e['aligned']])
        orig_dec=s2_dec(orig_slot)
        new_dec=comp+orig_dec[len(comp):]           # original pad bytes preserved
        new_slot=s2_enc(new_dec)
        if len(new_slot)!=e['aligned'] or s2_dec(new_slot)!=new_dec:
            fails.append('%s: round-trip verification failed' % nm)
            err(fails[-1]); continue
        data[e['start']:e['start']+e['aligned']]=new_slot
        changed.add(k)
        ok('Injected: %s  (compressed %d -> slot %d bytes)' % (nm, len(comp), e['aligned']))
    if fails:
        warn('Skipped %d file(s) due to errors (listed above).' % len(fails))

    new=bytes(data)
    section('STRUCTURAL VALIDATION')
    issues=[]
    v=lambda c,m: (ok(m) if c else (err(m), issues.append(m))) and c
    v(len(new)==len(orig_bytes), 'File size preserved: %s bytes' % format(len(new),','))
    bad=[e for k,e in enumerate(ents) if k not in changed
         and sha256(new[e['start']:e['start']+e['aligned']])!=e['slot_sha256']]
    v(not bad, 'Unchanged slots byte-identical: %d/%d' % (len(ents)-len(changed)-len(bad), len(ents)-len(changed)))
    badgaps=[g for g in man['gaps'] if orig_bytes[g[0]:g[1]]!=new[g[0]:g[1]]]
    v(not badgaps, 'Non-slot regions (header/gaps/footer) byte-identical: %d region(s)' % len(man['gaps']))
    v(orig_bytes[-TRAILER_GUARD:]==new[-TRAILER_GUARD:], 'Trailer (last %d bytes) untouched' % TRAILER_GUARD)
    if not e.get('embedded') is None and changed:
        ok('Embedded chunk names : preserved (guard enforced)')

    forge_used=False; forge_off=None
    if forge and not issues and changed:
        cands=[g for g in man['gaps'] if g[1]-g[0]>=16 and g[1]<=len(new)-TRAILER_GUARD]
        if cands:
            g=cands[-1]
            fg=forge_crc32(new,int(man['pak_crc32'],16),g[1]-4)
            if fg:
                new=fg; forge_used=True; forge_off=g[1]-4
                ok('Full-file CRC32 forged back to original: %s' % man['pak_crc32'])

    section('DEEP VALIDATION REPORT - 40+ SECURITY CHECKS')
    deep = validate_deep(orig_bytes, new, man, changed, forge_used, forge_off)

    if issues:
        section('RESULT')
        err('STRUCTURAL VALIDATION FAILED: %s' % issues)
        err('Output was NOT written.')
        input('\n  Press [Enter] to return...')
        return
    if not changed:
        section('RESULT')
        inf('No injections performed - no output written.')
        input('\n  Press [Enter] to return...')
        return

    DIR_BACKUP.mkdir(exist_ok=True)
    bak=DIR_BACKUP/(orig.name+'.bak')
    if not bak.exists(): shutil.copy2(orig, bak)
    out=DIR_INJECT/(orig.stem+'_v8.pak')
    out.write_bytes(new)
    (work/'inject_report_v8.json').write_text(json.dumps({
        'tool':TOOL_VERSION,'base':orig.name,'output':out.name,
        'injected':len(changed),'skipped':fails,'forge_crc':forge_used,'deep_validation':deep,
        'out_sha256':sha256(new),'out_crc32':crc32h(new)},indent=1))
    section('RESULT')
    ok('Injected %d file(s), failed %d.' % (len(changed), len(fails)))
    ok('Output PAK  : %s' % out)
    ok('Backup      : %s' % bak)
    ok('JSON report : %s' % (work/'inject_report_v8.json'))
    print('')
    warn('TEST ON A DUMMY ACCOUNT FIRST.')
    warn('Whether the game validates full-file SHA256 / trailer signature')
    warn('is still UNKNOWN - measure it with capture_pak_decrypt.js.')
    input('\n  Press [Enter] to return...')


def do_compare():
    """Compare two PAK files and print the deep validation table (40+ checks)."""
    header('VERIFY / COMPARE TWO PAKS')
    inf('Step 1 of 2 - select the ORIGINAL (input) PAK:')
    orig = pick_pak()
    if orig is None: return
    print('')
    inf('Step 2 of 2 - select the REPACKED / TARGET PAK:')
    targ = pick_pak()
    if targ is None: return
    ob = orig.read_bytes(); tb = targ.read_bytes()
    print('')
    inf('Original: %s (%s bytes)' % (orig.name, format(len(ob),',')))
    inf('Target  : %s (%s bytes)' % (targ.name, format(len(tb),',')))
    print('')
    inf('Scanning original...')
    oe = scan_pak(ob, progress=True)
    inf('Scanning target...')
    te = scan_pak(tb, progress=True)
    if len(oe) != len(te):
        warn('Slot count differs: original=%d target=%d' % (len(oe), len(te)))
    changed=set()
    for i in range(min(len(oe),len(te))):
        a=oe[i]; b=te[i]
        if a['start']!=b['start'] or a['aligned']!=b['aligned']:
            changed.add(i)
        elif ob[a['start']:a['start']+a['aligned']]!=tb[b['start']:b['start']+b['aligned']]:
            changed.add(i)
    man={'entries':oe,'gaps':non_slot_regions(ob,oe),
         'pak_crc32':crc32h(ob),'pak_sha256':sha256(ob)}
    forge_used = (len(ob)==len(tb) and crc32h(ob)==crc32h(tb) and len(changed)>0)
    forge_off=None
    if forge_used:
        for g in man['gaps']:
            for off in range(g[0], g[1]):
                if ob[off]!=tb[off]:
                    forge_off=off; break
            if forge_off is not None: break
        if forge_off is not None:
            inf('CRC32 identical despite %d changed slot(s) - forge patch inferred at %#x' % (len(changed), forge_off))
        else:
            inf('CRC32 identical despite changes - forge location not identified (gap compare may report FAIL)')
    elif len(changed)==0 and len(ob)==len(tb):
        inf('Files are byte-identical (or only differ outside slot map).')
    section('DEEP COMPARISON REPORT - 40+ SECURITY CHECKS')
    validate_deep(ob, tb, man, changed, forge_used, forge_off)
    input('¤n  Press [Enter] to return...')

def do_loader():
    header('MAKE LUA LOADER')
    mod=input('  Mod bytecode filename [cheat.lua]: ').strip() or 'cheat.lua'
    code=LOADER_TEMPLATE.replace('@@MOD@@',mod)
    DIR_RESULT.mkdir(exist_ok=True)
    out=DIR_RESULT/'loader_paktool.lua'
    out.write_text(code)
    print('')
    ok('Loader written: %s' % out)
    inf("Place your compiled bytecode as '%s' inside the game's" % mod)
    inf('Saved/Paks/Paks folder of the target package.')
    input('\n  Press [Enter] to return...')

def do_clean():
    header('CLEAN WORKSPACE')
    if input('  Delete all sessions and outputs? [y/N]: ').strip().lower() in ('y','yes'):
        for d in [DIR_UNPACK,DIR_INJECT]:
            for f in d.glob('*'):
                try:
                    shutil.rmtree(f) if f.is_dir() else f.unlink()
                except Exception: pass
        ok('Workspace cleaned.')
    else:
        inf('Cancelled.')
    input('\n  Press [Enter] to return...')

def selftest():
    t = bytes(range(64)) + b'\xab\xcd'
    assert s2_dec(s2_enc(t)) == t, 'S2 round-trip FAILED'
    padded = bytes(range(12)) + b'\x00' * 8
    assert s2_dec(s2_enc(padded))[:12] == bytes(range(12))
    return True

def main():
    for d in [DIR_PAK,DIR_UNPACK,DIR_INJECT,DIR_BACKUP,DIR_RESULT]:
        d.mkdir(parents=True,exist_ok=True)
    selftest()
    while True:
        header('PUBG PAK TOOL')
        print('    [1]  UNPACK PAK')
        print('         Scan S2+zlib slots, extract Lua/Bin, build manifest')
        print('')
        print('    [2]  REPACK / INJECT')
        print('         Inject modified Lua: pad-preserve, chunkname guard,')
        print('         full re-validation, optional CRC32 forge')
        print('')
        print('    [3]  VERIFY / COMPARE PAKS')
        print('         Full 40+ check comparison table: original vs target')
        print('')
        print('    [4]  MAKE LUA LOADER')
        print('         Generate external bytecode loader script')
        print('')
        print('    [5]  CLEAN WORKSPACE')
        print('    [6]  EXIT')
        print('')
        c=input('  Select [1-6]: ').strip()
        try:
            if   c=='1': do_unpack()
            elif c=='2': do_repack()
            elif c=='3': do_compare()
            elif c=='4': do_loader()
            elif c=='5': do_clean()
            elif c=='6': clear(); sys.exit(0)
        except KeyboardInterrupt:
            clear(); sys.exit(0)
        except Exception as ex:
            err('Unexpected error: %s' % ex)
            input('  Press [Enter] to continue...')

if __name__=='__main__':
    main()
