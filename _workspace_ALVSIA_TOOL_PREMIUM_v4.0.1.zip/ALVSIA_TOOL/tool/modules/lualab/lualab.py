#!/usr/bin/env python3
"""ALVSIA LUALAB: compile Lua 5.3 sources and restore embedded source from chunks."""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import shutil
import struct
import subprocess
import sys
import time
from pathlib import Path

NAME = "ALVSIA LUALAB"
DEVELOPER = "ALVSIA"
TELEGRAM_CHANNEL = "@ALVSIA_PRO"
TELEGRAM_BOT = "@OriginalOnwerALV"
MAGIC = b"ALVSIALABSRC\x01"
# This key identifies the tool's private round-trip container; it is not secret.
FORMAT_KEY = b"ALVSIA LUALAB format key v1"
ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT / "Original Lua"
DECOMPILED = ROOT / "Decompiled Lua"
COMPILED = ROOT / "Compiled Lua"
COMPILER = ROOT / "luac"


def _candidate_compilers() -> list[Path]:
    """Local-first compiler discovery; never downloads anything."""
    out = [COMPILER]
    here = Path(__file__).resolve()
    # assets/bin relative to the product root (modules/lualab -> tool/assets/bin)
    out.append(here.parents[2] / "assets" / "bin" / "luac")
    for name in ("luac5.3", "luac5.4", "luac"):
        found = shutil.which(name)
        if found:
            out.append(Path(found))
    return out


def compiler_version(path: Path) -> str | None:
    try:
        result = subprocess.run(
            [str(path), "-v"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=10,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    output = (result.stdout + result.stderr).decode(errors="replace").strip()
    if result.returncode == 0 and "Lua" in output:
        return output.splitlines()[0]
    return None


def ensure_compiler() -> bool:
    global COMPILER
    for candidate in _candidate_compilers():
        if not candidate.is_file():
            continue
        try:
            candidate.chmod(candidate.stat().st_mode | 0o100)
        except OSError:
            pass
        version = compiler_version(candidate)
        if version:
            COMPILER = candidate
            print(f"Lua compiler check passed: {version}")
            return True
    print("No working luac compiler found (expected beside the script or in assets/bin).")
    return False


def tool_ready(tool: Path) -> bool:
    if not tool.is_file():
        print(f"Missing required tool: {tool.name} (place it beside this script).")
        return False
    if not os.access(tool, os.X_OK):
        try:
            tool.chmod(tool.stat().st_mode | 0o100)
        except OSError as exc:
            print(f"Cannot run {tool.name}: {exc}")
            return False
    return True


def ensure_folders() -> None:
    for folder in (ORIGINAL, DECOMPILED, COMPILED):
        folder.mkdir(parents=True, exist_ok=True)
    # Normalize prior tool outputs in place; never touch files in Original Lua.
    for compiled_path in sorted(COMPILED.rglob("*")):
        if not compiled_path.is_file():
            continue
        try:
            if compiled_path.suffix.lower() == ".lhc":
                new_path = compiled_path.with_suffix(".lua")
                if new_path.exists():
                    print(f"Kept {compiled_path.name}: {new_path.name} already exists.")
                    continue
                compiled_path.rename(new_path)
                print(f"Renamed compiled output: {new_path.name}")
        except OSError as exc:
            print(f"Could not convert {compiled_path.name}: {exc}")


def run(command: list[str]) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def keystream(nonce: bytes, size: int) -> bytes:
    result = bytearray()
    counter = 0
    while len(result) < size:
        result.extend(hashlib.sha256(FORMAT_KEY + nonce + struct.pack(">Q", counter)).digest())
        counter += 1
    return bytes(result[:size])


def wrap_source(source: bytes, bytecode: bytes) -> bytes:
    payload = struct.pack(">Q", len(source)) + source + bytecode
    nonce = secrets.token_bytes(16)
    stream = keystream(nonce, len(payload))
    encrypted = bytes(a ^ b for a, b in zip(payload, stream))
    body = MAGIC + nonce + encrypted
    return body + hmac.new(FORMAT_KEY, body, hashlib.sha256).digest()


def unwrap_source(data: bytes) -> tuple[bytes, bytes]:
    minimum = len(MAGIC) + 16 + 8 + hashlib.sha256().digest_size
    if len(data) < minimum or not data.startswith(MAGIC):
        raise ValueError("not an ALVSIA LUALAB source-preserving compiled file")
    body, tag = data[:-32], data[-32:]
    expected = hmac.new(FORMAT_KEY, body, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected):
        raise ValueError("compiled file is damaged or has an invalid tool wrapper")
    nonce = data[len(MAGIC):len(MAGIC) + 16]
    encrypted = data[len(MAGIC) + 16:-32]
    stream = keystream(nonce, len(encrypted))
    payload = bytes(a ^ b for a, b in zip(encrypted, stream))
    source_size = struct.unpack_from(">Q", payload)[0]
    if source_size > len(payload) - 8:
        raise ValueError("compiled file has an invalid source section")
    return payload[8:8 + source_size], payload[8 + source_size:]


def inputs() -> list[Path]:
    return sorted(p for p in ORIGINAL.rglob("*") if p.is_file())


def file_label(path: Path) -> str:
    for folder in (ORIGINAL, COMPILED):
        try:
            return f"{folder.name}/{path.relative_to(folder)}"
        except ValueError:
            pass
    return str(path)


def choose_file(candidates: list[Path], task: str) -> Path | None:
    if not candidates:
        print("No matching files found in the folders used for this operation.")
        print("Add a source file to Original Lua, then try again.")
        return None
    print(f"\nFiles available to {task}:")
    for index, path in enumerate(candidates, start=1):
        print(f"  {index}. {file_label(path)}")
    print("  0. Cancel")
    while True:
        try:
            answer = input("Enter file number: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if answer == "0":
            return None
        if answer.isdigit() and 1 <= int(answer) <= len(candidates):
            return candidates[int(answer) - 1]
        print(f"Enter a number from 1 to {len(candidates)}, or 0 to cancel.")


def compile_lua() -> None:
    if not tool_ready(COMPILER):
        return
    source_candidates = []
    for path in inputs():
        if path.suffix.lower() != ".lua":
            continue
        try:
            contents = path.read_bytes()
            if not contents.startswith(MAGIC) and not contents.startswith(b"\x1bLua"):
                source_candidates.append(path)
        except OSError:
            continue
    source = choose_file(source_candidates, "compile")
    if source is None:
        return
    relative = source.relative_to(ORIGINAL).with_suffix(".lua")
    destination = COMPILED / relative
    if destination.resolve() == source.resolve():
        print("Safety stop: compiled output would overwrite the source file.")
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    result = run([str(COMPILER), "-s", "-o", "-", str(source)])
    if result.returncode:
        print(f"[FAIL] {file_label(source)}")
        print((result.stderr or result.stdout).decode(errors="replace").strip())
        return
    try:
        destination.write_bytes(wrap_source(source.read_bytes(), result.stdout))
        print(f"\nCompiled successfully for ALVSIA LUALAB: {destination.relative_to(ROOT)}")
        print(f"Original source kept unchanged: {source.relative_to(ORIGINAL)}")
    except OSError as exc:
        print(f"Could not write {destination}: {exc}")


def decompile_lua() -> None:
    # Only accept files created by this tool; their embedded source restores exactly.
    candidates = []
    all_paths = sorted(p for p in COMPILED.rglob("*") if p.is_file())
    all_paths += inputs()
    for path in all_paths:
        if path.suffix.lower() not in {".lua", ".luac", ".lhc", ".out"}:
            continue
        try:
            if path.read_bytes().startswith(MAGIC):
                candidates.append(path)
        except OSError:
            continue
    if not candidates:
        print("No ALVSIA LUALAB compiled files found.")
        print("Compile a readable .lua source with option 1, then decompile that output with option 2.")
        print("External or game-compiled Lua chunks are not accepted by this tool.")
        return
    source = choose_file(candidates, "decompile")
    if source is None:
        return
    try:
        restored_source, _bytecode = unwrap_source(source.read_bytes())
        try:
            relative = source.relative_to(ORIGINAL)
        except ValueError:
            relative = source.relative_to(COMPILED)
        destination = DECOMPILED / relative.with_suffix(".lua")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(restored_source)
        print(f"\nRestored original source: {destination.relative_to(ROOT)}")
    except (OSError, ValueError) as exc:
        print(f"Could not restore {file_label(source)}: {exc}")


def supports_color() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None and os.environ.get("TERM") != "dumb"


def paint(text: str, code: str) -> str:
    if not supports_color():
        return text
    return f"\033[{code}m{text}\033[0m"


def show_banner() -> None:
    rainbow = ["91", "93", "92", "96", "94", "95", "91", "93", "92"]
    title = "".join(paint(char, rainbow[i % len(rainbow)]) for i, char in enumerate("ALVSIA"))
    border = paint("\u2554" + "\u2550" * 46 + "\u2557", "96;1")
    footer = paint("\u255a" + "\u2550" * 46 + "\u255d", "96;1")
    print()
    print(border)
    print(paint("\u2551", "96;1") + f"              \u2726 {title} \u2726               " + paint("\u2551", "96;1"))
    print(paint("\u2551", "96;1") + paint("          LUA COMPILER & SOURCE RESTORER       ", "95;1") + paint("\u2551", "96;1"))
    print(footer)
    print(paint(f"  Developer: {DEVELOPER}", "93"))
    print(paint(f"  Telegram : {TELEGRAM_CHANNEL}  |  {TELEGRAM_BOT}", "96"))
    if supports_color():
        for frame in range(1, 13):
            bar = paint("\u2501" * frame, "92;1") + paint("\u00b7" * (12 - frame), "90")
            sys.stdout.write("\r  Starting ALVSIA LUALAB  [" + bar + "]")
            sys.stdout.flush()
            time.sleep(0.035)
        sys.stdout.write("\r  " + paint("Ready.                         ", "92;1") + "\n")
        sys.stdout.flush()
    else:
        print("  Ready.")


def show_menu() -> None:
    print("\n" + paint("\u2550" * 48, "96;1"))
    print("  " + paint("ALVSIA LUALAB", "95;1"))
    print(paint("\u2550" * 48, "96;1"))
    print("  " + paint("[1]", "92;1") + " Compile a Lua source file")
    print("  " + paint("[2]", "96;1") + " Restore source from an ALVSIA LUALAB compiled file")
    print("  " + paint("[0]", "91;1") + " Exit")
    print(paint("\u2500" * 48, "90"))


def main() -> int:
    if not ensure_compiler():
        print("Tool startup stopped because no working luac compiler is available.")
        return 1
    try:
        ensure_folders()
    except OSError as exc:
        print(f"Could not create the tool folders: {exc}")
        return 1
    show_banner()
    print(paint("Setup complete. Working folders are ready:", "92;1"))
    print(f"  Original  : {ORIGINAL}")
    print(f"  Decompiled: {DECOMPILED}")
    print(f"  Compiled  : {COMPILED}")
    while True:
        show_menu()
        try:
            choice = input("Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n" + paint("Goodbye from ALVSIA LUALAB!", "96;1"))
            return 0
        if choice == "1":
            compile_lua()
        elif choice == "2":
            decompile_lua()
        elif choice == "0":
            print(paint("Goodbye from ALVSIA LUALAB!", "96;1"))
            return 0
        else:
            print("Choose 1, 2, or 0.")


if __name__ == "__main__":
    raise SystemExit(main())
