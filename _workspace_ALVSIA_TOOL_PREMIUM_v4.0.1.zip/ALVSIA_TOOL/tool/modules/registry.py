"""ALVSIA TOOL PREMIUM — registry modul.

Seluruh mesin lama dibungkus menjadi satu produk: satu gerbang lisensi,
16 modul. Tiap modul dijalankan sebagai proses terpisah supaya satu mesin
yang gagal tidak menjatuhkan yang lain, dan supaya mesin yang memakai path
relatif (PAK/, SOURCE/, RESULT/) tetap bekerja seperti aslinya.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

MODULES_DIR = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Module:
    id: str
    name: str
    desc: str
    folder: str
    script: str
    kind: str = "menu"          # "menu" = interaktif, "cli" = butuh argumen
    aliases: tuple = ()
    env: dict = field(default_factory=dict)
    needs_luac: bool = False

    @property
    def path(self) -> Path:
        return MODULES_DIR / self.folder

    @property
    def script_path(self) -> Path:
        return self.path / self.script


MODULES: List[Module] = [
    Module("core", "ALVSIA CORE",
           "Mesin utama: baca/ekstrak/repack PAK UE4 v3-v14, SM4, Zstd, Lua 5.3",
           "core", "engine.py", kind="cli", aliases=("engine", "pak", "tool")),
    Module("studio", "ALVSIA STUDIO",
           "Suite lengkap: PAK, LUA, SM4, repack, kompilasi, unluac",
           "studio", "studio.py", aliases=("suite", "mk"), needs_luac=True),
    Module("forge", "ALVSIA FORGE",
           "OBB, ZSDIC, game patch, SM4 key finder, encrypt/decrypt",
           "forge", "forge.py", aliases=("allinone", "hr"), env={"ALVSIA_DEV": "1"}),
    Module("luaflow", "ALVSIA LUAFLOW",
           "Alur kerja Lua: unpack, edit, repack, emulator helper",
           "luaflow", "luaflow.py", aliases=("flow",)),
    Module("lualab", "ALVSIA LUALAB",
           "Laboratorium Lua: kompilasi & dekompilasi batch (luac disertakan)",
           "lualab", "lualab.py", aliases=("lab",), needs_luac=True),
    Module("pakx", "ALVSIA PAKX",
           "Utilitas PAK/Lua serbaguna",
           "pakx", "pakx.py", aliases=("x",)),
    Module("compiler", "ALVSIA COMPILER",
           "Kompilasi/dekompilasi Lua, kelola folder SOURCE & LUA",
           "compiler", "compiler.py", needs_luac=True,
           env={"ALVSIA_BASEDIR": str(MODULES_DIR / "compiler")}),
    Module("decoder", "ALVSIA DECODER",
           "Dekode file Python/Lua yang diobfuskasi",
           "decoder", "decoder.py", aliases=("dec",)),
    Module("keyfinder", "ALVSIA KEYFINDER",
           "Cari key SM4 di dalam file PAK/binary",
           "keyfinder", "keyfinder.py", aliases=("sm4", "keys")),
    Module("unpacker", "ALVSIA UNPACKER",
           "Unpack PAK: scan slot S2+zlib, ekstrak Lua/Bin, manifest",
           "unpacker", "unpacker.py", aliases=("loader", "unpack")),
    Module("obbx", "ALVSIA OBBX",
           "Kelola OBB: unpack, repack, extract asset",
           "obbx", "obbx.py", aliases=("obb",)),
    Module("scanner", "ALVSIA SCANNER",
           "Ekstrak sub-function & offset dari library native",
           "scanner", "scanner.py", kind="cli", aliases=("scan",)),
    Module("layerx", "ALVSIA LAYERX",
           "Layer lanjutan: SM4 layer, config technician",
           "layerx", "layerx.py", aliases=("layer", "17")),
    Module("luadump", "ALVSIA LUADUMP",
           "Dump, decompile, edit, repack Lua",
           "luadump", "luadump.py", aliases=("dump", "rip")),
    Module("battlepak", "ALVSIA BATTLEPAK",
           "PAK khusus game battle royale (repak based)",
           "battlepak", "battlepak.py", aliases=("bpak",)),
    Module("shield", "ALVSIA SHIELD",
           "Mesin terproteksi (modul terkompilasi + integrity check)",
           "shield", "main.py"),
]

_BY_ID = {}
for _m in MODULES:
    _BY_ID[_m.id] = _m
    for _a in _m.aliases:
        _BY_ID.setdefault(_a, _m)


def get(module_id: str) -> Optional[Module]:
    return _BY_ID.get((module_id or "").strip().lower())


def all_modules() -> List[Module]:
    return list(MODULES)
