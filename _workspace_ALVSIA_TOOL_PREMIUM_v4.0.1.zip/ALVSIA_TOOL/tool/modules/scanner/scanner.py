#!/usr/bin/env python3
import sys
import re
import urllib.request
import urllib.parse
import json

# ANSI Color Codes
CYAN = "\033[1;36m"
YELLOW = "\033[1;33m"
GREEN = "\033[1;32m"
RED = "\033[1;31m"
RESET = "\033[0m"

# Server Endpoint Details
PANEL_URL = "https://paidnew.myvipsite.fun/connect"
HARDCODED_KEY = "MASTER TOOL"  # Hardcoded key for direct activation

def print_banner():
    banner = r"""
┌──────────────────────────────────────────────┐
│          ★ MASTER BYPASS TOOL ★              │
└──────────────────────────────────────────────┘"""
    print(f"{CYAN}{banner}{RESET}\n")

def verify_key():
    """Verify license key online or via fallback key validation."""
    print(f"{YELLOW}[*] License Verification Required{RESET}")
    user_key = input(f"{CYAN}[+] Enter Key: {RESET}").strip()

    if not user_key:
        print(f"{RED}[!] Error: Key cannot be empty!{RESET}")
        sys.exit(1)

    # 1. Direct Hardcoded Key Check
    if user_key == HARDCODED_KEY:
        print(f"{GREEN}[+] Key Activated Successfully! Access Granted.{RESET}\n")
        return True

    # 2. Online Server Panel Verification Check
    print(f"{YELLOW}[*] Validating key with online server...{RESET}")
    try:
        post_data = urllib.parse.urlencode({'key': user_key}).encode('utf-8')
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        req = urllib.request.Request(PANEL_URL, data=post_data, headers=headers)
        
        with urllib.request.urlopen(req, timeout=10) as response:
            res_text = response.read().decode('utf-8', errors='ignore')

            if "success" in res_text.lower() or "true" in res_text.lower():
                print(f"{GREEN}[+] Key Activated Successfully via Online Server!{RESET}\n")
                return True
            else:
                print(f"{RED}[!] Invalid or Expired Key! Access Denied.{RESET}")
                sys.exit(1)

    except Exception as e:
        print(f"{RED}[!] Connection/Authentication Failed: {str(e)}{RESET}")
        sys.exit(1)

# Target strings for searching
TARGET_STRINGS = [
    "AnoSDKInit", "ptrace", "mprotect", "dlopen", "dlsym", "dlclose", "dladdr",
    "pthread_create", "fork", "mmap", "munmap", "mincore", "prctl", "syscall",
    "sendmsg", "recvfrom", "sendto", "socket", "connect", "bind", "listen",
    "accept", "memmem", "strstr", "strcasestr", "memchr", "memcmp", "strcmp",
    "strncmp", "strcasecmp", "strlen", "snprintf", "vsnprintf", "vfprintf",
    "fprintf", "sscanf", "mktime", "localtime", "gmtime", "gettimeofday",
    "clock_gettime", "time", "kill", "raise", "signal", "sigaction",
    "inotify_init", "inotify_add_watch", "pclose", "popen", "fopen", "read",
    "write", "open", "close", "unlink", "stat", "fstat", "fstatat", "access"
]

def export_to_file(records, output_filename="extracted_offsets.txt"):
    """Export extracted records to a formatted text file."""
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            f.write("=====================================================\n")
            f.write("           MASTER BYPASS TOOL - EXTRACTED OFFSETS     \n")
            f.write("=====================================================\n\n")
            f.write(f"{'TARGET STRING':<20} | {'SUB FUNCTION':<20} | {'HEX OFFSET':<15} | {'LINE NO'}\n")
            f.write("-" * 75 + "\n")
            for target, sub_name, hex_off, line_num in records:
                f.write(f"{target:<20} | {sub_name:<20} | {hex_off:<15} | Line {line_num}\n")
            f.write("-" * 75 + "\n")
            f.write(f"Total Unique Offsets Extracted: {len(records)}\n")
        print(f"\n{GREEN}[+] All extracted offsets successfully exported to '{output_filename}'{RESET}")
    except Exception as e:
        print(f"{RED}[!] Failed to write export file: {str(e)}{RESET}")

def parse_all_subs_and_crc(c_file_path):
    try:
        with open(c_file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        print(f"{YELLOW}[*] Parsing All Matching Sub-Functions from '{c_file_path}'...{RESET}\n")
        print(f"{YELLOW}{'TARGET STRING':<18} | {'SUB FUNCTION':<20} | {'HEX OFFSET':<18} | {'LINE NO'}{RESET}")
        print(f"{CYAN}" + "─" * 75 + f"{RESET}")

        current_sub = None
        current_sub_offset = None
        found_records = set()
        export_list = []

        for line_num, line in enumerate(lines, 1):
            line_str = line.strip()

            offset_match = re.search(r'//\s*\(([0-9a-fA-F]{8,16})\)', line_str)
            if offset_match:
                current_sub_offset = "0x" + offset_match.group(1).lstrip('0')
                if not current_sub_offset or current_sub_offset == "0x":
                    current_sub_offset = "0x0"

            sub_def_match = re.search(r'\b(sub_[0-9a-fA-F]+)\s*\(', line_str)
            if sub_def_match and ("__fastcall" in line_str or "void" in line_str or "int" in line_str or "__noreturn" in line_str or "time_t" in line_str or "char" in line_str):
                current_sub = sub_def_match.group(1)

            for target in TARGET_STRINGS:
                if re.search(rf'\b{re.escape(target)}\b', line_str, re.IGNORECASE):
                    called_subs = re.findall(r'sub_[0-9a-fA-F]+', line_str)
                    
                    if called_subs:
                        for sub_name in called_subs:
                            hex_off = "0x" + sub_name.replace("sub_", "")
                            rec_key = f"{target}:{sub_name}:{line_num}"
                            if rec_key not in found_records:
                                found_records.add(rec_key)
                                export_list.append((target, sub_name, hex_off, line_num))
                                print(f"{GREEN}{target:<18}{RESET} | {CYAN}{sub_name:<20}{RESET} | {YELLOW}{hex_off:<18}{RESET} | Line {line_num}")
                    elif current_sub:
                        off_val = current_sub_offset if current_sub_offset else ("0x" + current_sub.replace("sub_", ""))
                        rec_key = f"{target}:{current_sub}:{line_num}"
                        if rec_key not in found_records:
                            found_records.add(rec_key)
                            export_list.append((target, current_sub, off_val, line_num))
                            print(f"{GREEN}{target:<18}{RESET} | {CYAN}{current_sub:<20}{RESET} | {YELLOW}{off_val:<18}{RESET} | Line {line_num}")

        print(f"{CYAN}" + "─" * 75 + f"{RESET}")
        print(f"{GREEN}[+] Total Sub-Functions Extracted: {len(found_records)}{RESET}")

        if export_list:
            export_to_file(export_list)

    except Exception as e:
        print(f"{RED}[!] Error: {str(e)}{RESET}")

def run(argv=None):
    """Entry point used by the ALVSIA launcher (licence handled upstream)."""
    import sys as _s
    if argv is not None:
        _s.argv = [__file__] + list(argv)
    print_banner()
    if len(_s.argv) < 2:
        print(f"{YELLOW}Usage: alvsia.py scanner <library.c>{RESET}")
        return 1
    parse_all_subs_and_crc(_s.argv[1])
    return 0


if __name__ == "__main__":
    raise SystemExit(run(sys.argv[1:]))
