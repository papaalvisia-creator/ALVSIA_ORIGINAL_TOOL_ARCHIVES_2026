TESLA patched build

Run: python3 main.py
The launcher verifies the patched tool.so hash and imports the original compiled module.
See PATCH_REPORT.txt for exact byte changes.
