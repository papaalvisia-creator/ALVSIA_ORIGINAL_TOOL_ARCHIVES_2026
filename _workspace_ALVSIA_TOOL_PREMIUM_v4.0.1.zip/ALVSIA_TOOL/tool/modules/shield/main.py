#!/usr/bin/env python3
import hashlib
import importlib
import os
from pathlib import Path

BASE = Path(__file__).resolve().parent
BINARY = BASE / 'tool.so'
EXPECTED_SHA256 = '829decfd6f4c2de0dccd17e8332767730bbec652e221381528f59c3f07145a95'

def verify_binary():
    if not BINARY.exists():
        raise FileNotFoundError(f"Protected module missing: {BINARY.name}")
    h = hashlib.sha256()
    with BINARY.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    if h.hexdigest().lower() != EXPECTED_SHA256.lower():
        raise RuntimeError("Integrity check failed: protected module was modified.")

def main():
    os.chdir(BASE)
    verify_binary()
    importlib.import_module("tool")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        raise SystemExit(0)
    except Exception as exc:
        print(f"\n❌ Protected launcher error: {exc}")
        raise SystemExit(1)
