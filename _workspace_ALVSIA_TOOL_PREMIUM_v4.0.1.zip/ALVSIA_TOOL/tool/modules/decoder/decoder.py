#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import base64
import hashlib
import hmac
import re
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

MAGIC_LAB = bytes.fromhex("4c55434b59485542505901")  # format signature
LAB_STREAM_LABEL = bytes.fromhex("4c55434b592d4855422d50592d53545245414d2d7631")
LUA_SIGNATURE = b"\x1bLua"
BASE_DIR = Path("/storage/emulated/0/ALVSIA_TOOL/decoder")
ENCRYPTED_DIR = BASE_DIR / "encrypted"
EXTRACTED_DIR = BASE_DIR / "extracted"


class DecryptError(Exception):
    pass


@dataclass
class Result:
    data: bytes
    extension: str
    description: str
    verified: bool = False


def _name_targets(node: ast.AST) -> set[str]:
    if isinstance(node, ast.Name):
        return {node.id}
    if isinstance(node, (ast.Tuple, ast.List)):
        result: set[str] = set()
        for item in node.elts:
            result.update(_name_targets(item))
        return result
    return set()


def _constant_string(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, (ast.Tuple, ast.List)):
        values = [_constant_string(item) for item in node.elts]
        if all(value is not None for value in values):
            return "".join(value for value in values if value is not None)
    return None


def _literal_hex_fromhex(node: ast.AST) -> bytes | None:
    if not isinstance(node, ast.Call) or node.keywords:
        return None
    if not isinstance(node.func, ast.Attribute) or node.func.attr != "fromhex":
        return None
    if not isinstance(node.func.value, ast.Name) or node.func.value.id != "bytes":
        return None
    if len(node.args) != 1 or not isinstance(node.args[0], ast.Constant):
        return None
    value = node.args[0].value
    if not isinstance(value, str):
        return None
    try:
        return bytes.fromhex(value)
    except ValueError:
        return None


def _python_assignments(text: str) -> dict[str, ast.AST]:
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError) as exc:
        raise DecryptError(f"Input is not parseable Python: {exc}") from exc
    found: dict[str, ast.AST] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                for name in _name_targets(target):
                    if name in {"_P", "_E", "_M"}:
                        found[name] = node.value
        elif isinstance(node, ast.AnnAssign):
            for name in _name_targets(node.target):
                if name in {"_P", "_E", "_M"} and node.value is not None:
                    found[name] = node.value
    return found


def decode_lualab(data: bytes) -> Result:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise DecryptError("Python wrapper is not valid UTF-8") from exc
    if bytes.fromhex("4c55434b595f4855425f50595f4c41554e434845525f5632").decode() not in text:
        raise DecryptError("ALVSIA LUALAB launcher marker was not found")
    values = _python_assignments(text)
    if not {"_P", "_E", "_M"}.issubset(values):
        raise DecryptError("Required _P, _E, and _M fields were not found")
    encoded = _constant_string(values["_P"])
    enc_key = _literal_hex_fromhex(values["_E"])
    mac_key = _literal_hex_fromhex(values["_M"])
    if encoded is None or enc_key is None or mac_key is None:
        raise DecryptError("Encryption fields are not literal constants in the expected format")
    if len(enc_key) != 32 or len(mac_key) != 32:
        raise DecryptError("Unexpected encryption or verification key length")
    try:
        blob = base64.b85decode(encoded.encode("ascii"))
    except (ValueError, UnicodeEncodeError) as exc:
        raise DecryptError(f"Base85 decoding failed: {exc}") from exc
    header_len = len(MAGIC_LAB) + 32
    if len(blob) < header_len + hashlib.sha256().digest_size:
        raise DecryptError("Data is shorter than the expected ALVSIA LUALAB structure")
    if not blob.startswith(MAGIC_LAB):
        raise DecryptError("ALVSIA LUALAB header does not match")
    body, tag = blob[:-32], blob[-32:]
    expected_tag = hmac.new(mac_key, body, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected_tag):
        raise DecryptError("HMAC verification failed; the file is damaged or uses another format")
    nonce = blob[len(MAGIC_LAB) + 16:header_len]
    ciphertext = blob[header_len:-32]
    stream = bytearray()
    counter = 0
    while len(stream) < len(ciphertext):
        block = hmac.new(
            enc_key,
            LAB_STREAM_LABEL + nonce + struct.pack(">Q", counter),
            hashlib.sha256,
        ).digest()
        stream.extend(block)
        counter += 1
    plaintext = bytes(a ^ b for a, b in zip(ciphertext, stream))
    return Result(plaintext, ".py", "ALVSIA LUALAB Python wrapper; HMAC verified", True)


def _decode_lua_unicode_body(text: str) -> bytes:
    if text.startswith("\r\n"):
        text = text[2:]
    elif text.startswith(("\n", "\r")):
        text = text[1:]
    codepoints: list[int] = []
    for ch in text:
        value = ord(ch)
        if value >= 131072:
            value -= 131072
            if not 0 <= value <= 0xFFFF:
                raise DecryptError("Unicode value is outside the expected encoding range")
            codepoints.append(value)
        elif ch.isspace():
            continue
        else:
            raise DecryptError(f"Unexpected character in payload: U+{ord(ch):04X}")
    if not codepoints:
        raise DecryptError("Unicode payload is empty")
    high = [value // 256 for value in codepoints]
    low = [value % 256 for value in codepoints]
    out_high: list[int] = []
    out_low: list[int] = []
    for start in range(0, len(high), 8):
        out_high.extend(reversed(high[start:start + 8]))
        out_low.extend(reversed(low[start:start + 8]))
    return bytes(a ^ b for a, b in zip(out_high, out_low))


def decode_lua_unicode(data: bytes) -> Result:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise DecryptError("Lua wrapper is not valid UTF-8") from exc
    if "local _b=8" not in text or "131072" not in text or "string.char" not in text:
        raise DecryptError("Expected Lua Unicode-wrapper markers were not found")
    match = re.search(r"\[==\[(.*?)\]==\]", text, flags=re.DOTALL)
    if not match:
        raise DecryptError("Lua long-string payload [==[ ... ]==] was not found")
    plaintext = _decode_lua_unicode_body(match.group(1))
    if b"\x00" in plaintext:
        raise DecryptError("Output contains NUL bytes and was not accepted as Lua source")
    try:
        plaintext.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise DecryptError("Output is not valid UTF-8 Lua source") from exc
    return Result(plaintext, ".lua", "Lua Unicode wrapper; 8-byte reversal and XOR decoded", True)


def decode_lua_b64_xor(data: bytes) -> Result:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise DecryptError("Lua wrapper is not valid UTF-8") from exc
    if not re.search(r"local\s+encData\s*=\s*\(", text):
        raise DecryptError("Expected encData declaration was not found")
    block = re.search(r"local\s+encData\s*=\s*\((.*?)\n\)", text, flags=re.DOTALL)
    if not block:
        raise DecryptError("encData block is incomplete")
    fragments = re.findall(r'"([A-Za-z0-9+/=\s]*)"', block.group(1))
    if not fragments:
        raise DecryptError("No Base64 strings were found in encData")
    encoded = re.sub(r"\s+", "", "".join(fragments))
    key_match = re.search(r"local\s+key\s*=\s*(\d+)", text)
    if not key_match:
        raise DecryptError("Numeric XOR key was not found")
    key = int(key_match.group(1))
    if not 0 <= key <= 255:
        raise DecryptError("XOR key is outside the byte range")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, base64.binascii.Error) as exc:
        raise DecryptError(f"Base64 decoding failed: {exc}") from exc
    plaintext = bytes(value ^ key for value in raw)
    if not plaintext.startswith(LUA_SIGNATURE):
        raise DecryptError("Decoded data has no Lua bytecode signature; output was rejected")
    version = plaintext[4] if len(plaintext) > 4 else 0
    version_name = f"Lua bytecode 5.{version & 0x0F}" if (version >> 4) == 5 else "Lua bytecode"
    return Result(plaintext, ".luac", f"Base64 + XOR decoded; {version_name}", True)


def detect_and_decode(data: bytes, forced: str = "auto") -> Result:
    decoders: dict[str, Callable[[bytes], Result]] = {
        "lualab": decode_lualab,
        "lua-unicode": decode_lua_unicode,
        "lua-b64-xor": decode_lua_b64_xor,
    }
    if forced != "auto":
        return decoders[forced](data)
    if data.startswith(LUA_SIGNATURE):
        version = data[4] if len(data) > 4 else 0
        label = f"Lua bytecode 5.{version & 0x0F}" if (version >> 4) == 5 else "Lua bytecode"
        return Result(data, ".luac", f"{label} is already unwrapped", True)
    errors: list[str] = []
    for name in ("lualab", "lua-b64-xor", "lua-unicode"):
        try:
            return decoders[name](data)
        except DecryptError as exc:
            errors.append(f"{name}: {exc}")
    raise DecryptError("No supported format detected. " + " | ".join(errors))


def default_output(source: Path, extension: str) -> Path:
    return source.with_name(f"{source.stem}_decrypted{extension}")


def extract_file(source: Path, destination: Path, forced: str = "auto", overwrite: bool = False) -> Result:
    result = detect_and_decode(source.read_bytes(), forced)
    if destination.resolve() == source.resolve():
        raise DecryptError("Refusing to overwrite the input file")
    if destination.exists() and not overwrite:
        raise DecryptError(f"Output already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(result.data)
    return result


def _termux_output(source: Path, extension: str) -> Path:
    relative = source.relative_to(ENCRYPTED_DIR)
    return EXTRACTED_DIR / relative.parent / f"{relative.stem}_decrypted{extension}"


def _pause() -> None:
    try:
        input("\nPress Enter to continue...")
    except (EOFError, KeyboardInterrupt):
        pass


def _list_encrypted_files() -> list[Path]:
    return sorted(path for path in ENCRYPTED_DIR.rglob("*") if path.is_file())


def _decode_menu() -> None:
    try:
        files = _list_encrypted_files()
    except OSError as exc:
        print(f"Error reading encrypted folder: {exc}")
        _pause()
        return
    if not files:
        print(f"No files found in: {ENCRYPTED_DIR}")
        _pause()
        return
    print("\nEncrypted files:")
    for index, path in enumerate(files, 1):
        print(f"  {index}. {path.relative_to(ENCRYPTED_DIR)}")
    print("  0. Back")
    try:
        choice = input("Select a file number: ").strip()
    except (EOFError, KeyboardInterrupt):
        return
    if choice == "0":
        return
    if not choice.isdigit() or not 1 <= int(choice) <= len(files):
        print("Error: invalid selection.")
        _pause()
        return
    source = files[int(choice) - 1]
    try:
        result = detect_and_decode(source.read_bytes())
        destination = _termux_output(source, result.extension)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            try:
                answer = input(f"{destination.name} already exists. Overwrite? [y/N]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("Cancelled. Existing output was kept.")
                _pause()
                return
            if answer not in {"y", "yes"}:
                print("Cancelled. Existing output was kept.")
                _pause()
                return
        destination.write_bytes(result.data)
        print("\nSuccessfully decoded.")
        print(f"Format: {result.description}")
        print(f"Output: {destination}")
        if result.extension == ".luac":
            print("Note: Lua bytecode is not readable Lua source.")
    except (OSError, DecryptError) as exc:
        print(f"\nFailed: {exc}")
    _pause()


def _show_folders() -> None:
    print(f"\nMain folder:      {BASE_DIR}")
    print(f"Encrypted folder: {ENCRYPTED_DIR}")
    print(f"Extracted folder: {EXTRACTED_DIR}")
    try:
        print(f"Files to decode:  {len(_list_encrypted_files())}")
    except OSError as exc:
        print(f"Folder error: {exc}")
    _pause()


def interactive_mode() -> int:
    try:
        ENCRYPTED_DIR.mkdir(parents=True, exist_ok=True)
        EXTRACTED_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"Storage access error: {exc}")
        print("In Termux, run termux-setup-storage and allow storage access, then restart this tool.")
        return 2
    while True:
        print("\n========================================")
        print("       ALVSIA DECODER  \u00b7  PYTHON / LUA")
        print("========================================")
        print("1. Decodea file")
        print("2. Show folders")
        print("0. Exit")
        try:
            choice = input("Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            return 0
        if choice == "1":
            _decode_menu()
        elif choice == "2":
            _show_folders()
        elif choice == "0":
            print("Goodbye.")
            return 0
        else:
            print("Error: choose 1, 2, or 0.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Statically decode supported Lua and Python wrappers.")
    parser.add_argument("input", nargs="?", type=Path, help="Input file; omit to open the Termux menu")
    parser.add_argument("-o", "--output", type=Path, help="Output file path")
    parser.add_argument(
        "--format",
        choices=("auto", "lualab", "lua-b64-xor", "lua-unicode"),
        default="auto",
        help="Format to decode (default: auto)",
    )
    parser.add_argument("--force", action="store_true", help="Overwrite an existing output file")
    args = parser.parse_args(argv)
    if args.input is None:
        return interactive_mode()
    try:
        source = args.input.expanduser().resolve(strict=True)
        if not source.is_file():
            raise DecryptError("Input path is not a regular file")
        result = detect_and_decode(source.read_bytes(), args.format)
        destination = args.output.expanduser().resolve() if args.output else default_output(source, result.extension).resolve()
        if destination == source:
            raise DecryptError("Refusing to overwrite the input file")
        if destination.exists() and not args.force:
            raise DecryptError(f"Output already exists: {destination} (use --force to overwrite)")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(result.data)
    except (OSError, DecryptError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    print(f"Decoded: {result.description}")
    print(f"Verification: {'passed' if result.verified else 'unavailable'}; payload was not executed")
    print(f"Size: {len(result.data)} bytes")
    print(f"Output: {destination}")
    if result.extension == ".luac":
        print("Note: Lua bytecode is not readable source; source recovery depends on bytecode compatibility and a decompiler.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
