import os
import shutil
import zipfile
import struct
import time
import json
import base64

# Directories configuration
BASE_DIR = os.getcwd()
INPUT_DIR = os.path.join(BASE_DIR, 'input')
OUTPUT_OBB = os.path.join(BASE_DIR, 'unpacked_obb')
TMP_DIR = os.path.join(BASE_DIR, 'tmp')
UNPACK_PAK_DIR = os.path.join(BASE_DIR, 'unpack_pak')
REPACK_DIR = os.path.join(BASE_DIR, 'repack_obb')
TOOL_DIR = os.path.join(BASE_DIR, 'TOOL')
CONFIG_FILE = os.path.join(BASE_DIR, '.session_lock')

# Valid 1-Day Keys Pool (Aap inmein se koi bhi key use kar sakte hain)
VALID_KEYS = ["EXOFUS-0001", "EXOFUS-0002", "EXOFUS-0003", "PUBG-KEY-2026"]

def verify_login():
    os.system('clear' if os.name == 'posix' else 'cls')
    banner()
    print("\033[1;33m[SECURE LOGIN] Enter your 1-Day Access Key\033[0m")
    
    # Check active session
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                data = json.load(f)
                if time.time() < data.get("expiry", 0):
                    print("\033[1;32m[INFO] Active session found. Access granted!\033[0m")
                    time.sleep(1)
                    return True
        except:
            pass

    user_key = input("\nEnter Key: ").strip()
    
    if user_key in VALID_KEYS:
        # 24 Hours expiry (86400 seconds)
        expiry_time = time.time() + 86400
        with open(CONFIG_FILE, 'w') as f:
            json.dump({"key": user_key, "expiry": expiry_time}, f)
        print("\n\033[1;32m[SUCCESS] Key verified! Valid for 24 Hours.\033[0m")
        input("\nPress Enter to start tool...")
        return True
    else:
        print("\n\033[1;31m[ERROR] Invalid or Expired Key!\033[0m")
        if os.path.exists(CONFIG_FILE):
            os.remove(CONFIG_FILE) # Remove old expired session
        input("\nPress Enter to exit...")
        return False

def create_folders():
    for folder in [INPUT_DIR, OUTPUT_OBB, TMP_DIR, UNPACK_PAK_DIR, REPACK_DIR, TOOL_DIR]:
        os.makedirs(folder, exist_ok=True)

def banner():
    print("\033[1;36m")
    print(r"""
   ███╗   ███╗██████╗ ███████╗████████╗███████╗██████╗ 
   ████╗ ████║██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔══██╗
   ██╔████╔██║███████║███████╗   ██║   █████╗  ██████╔╝
   ██║╚██╔╝██║██╔══██║╚════██║   ██║   ██╔══╝  ██╔══██╗
   ██║ ╚═╝ ██║██║  ██║███████║   ██║   ███████╗██║  ██║
   ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
    """)
    print("\033[1;32mPAK FILE UNPACKER/REPACKER TOOL")
    print("\033[1;33mCUSTOMIZED FOR TERMUX\033[0m\n")

def unpack_obb():
    print("\n\033[1;34m[INFO] Starting OBB preparation...\033[0m")
    files = os.listdir(INPUT_DIR)
    obb_files = [f for f in files if f.endswith('.obb')]
    
    if not obb_files:
        print("\033[1;31m[ERROR] OBB file not found in 'input' folder!\033[0m")
        return

    obb_target = obb_files[0]
    obb_path = os.path.join(INPUT_DIR, obb_target)
    print(f"\033[1;32m[INFO] Extracting {obb_target}...\033[0m")
    
    with zipfile.ZipFile(obb_path, 'r') as zip_ref:
        zip_ref.extractall(OUTPUT_OBB)
        
    print(f"\033[1;32m[SUCCESS] Extracted OBB to '{OUTPUT_OBB}' folder.\033[0m")

def extract_pak_file(pak_path, output_dir):
    pak_name = os.path.basename(pak_path)
    out_folder = os.path.join(output_dir, pak_name + "_extracted")
    os.makedirs(out_folder, exist_ok=True)

    with open(pak_path, 'rb') as f:
        f.seek(0, 2)
        file_size = f.tell()
        
        if file_size < 221:
            print(f"\033[1;31m[ERROR] Invalid PAK file size: {pak_name}\033[0m")
            return
            
        f.seek(0)
        chunk_size = 1024 * 1024
        index = 0
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            dat_name = f"dat_{index:04d}.dat"
            with open(os.path.join(out_folder, dat_name), 'wb') as dat_out:
                dat_out.write(chunk)
            index += 1
        print(f"\033[1;32m[SUCCESS] Extracted {index} DAT chunks from {pak_name}\033[0m")

def unpack_pak():
    print("\n\033[1;34m[INFO] Searching for .pak files in unpacked OBB...\033[0m")
    pak_files = []
    
    for root, dirs, files in os.walk(OUTPUT_OBB):
        for file in files:
            if file.endswith('.pak'):
                pak_files.append(os.path.join(root, file))
                
    if not pak_files:
        print("\033[1;31m[ERROR] No .pak files found! Pehle Option [1] se OBB unpack karein.\033[0m")
        return

    print(f"\033[1;32m[INFO] Found {len(pak_files)} PAK file(s).\033[0m")
    
    for pak in pak_files:
        pak_name = os.path.basename(pak)
        print(f"\033[1;33m[PROCESSING] Extracting DAT files from {pak_name}...\033[0m")
        extract_pak_file(pak, UNPACK_PAK_DIR)

    print(f"\033[1;32m[SUCCESS] All files unpacked to '{UNPACK_PAK_DIR}' folder.\033[0m")

def repack_pak():
    print("\n\033[1;34m[INFO] Building updated PAK from edited files...\033[0m")
    if not os.path.exists(UNPACK_PAK_DIR) or not os.listdir(UNPACK_PAK_DIR):
        print("\033[1;31m[ERROR] No files found in 'unpack_pak' folder to repack!\033[0m")
        return

    repack_out = os.path.join(TMP_DIR, "repacked_mini_obb.pak")
    with open(repack_out, 'wb') as out_pak:
        for root, dirs, files in os.walk(UNPACK_PAK_DIR):
            for file in sorted(files):
                file_path = os.path.join(root, file)
                with open(file_path, 'rb') as f_in:
                    out_pak.write(f_in.read())

    print(f"\033[1;32m[SUCCESS] Created repacked PAK at '{repack_out}'\033[0m")

def repack_obb():
    print("\n\033[1;34m[INFO] Creating final OBB file...\033[0m")
    files = os.listdir(INPUT_DIR)
    obb_files = [f for f in files if f.endswith('.obb')]
    
    if not obb_files:
        print("\033[1;31m[ERROR] Original OBB missing in 'input' folder for name reference!\033[0m")
        return

    target_name = obb_files[0]
    final_obb_path = os.path.join(REPACK_DIR, target_name)

    repacked_pak = os.path.join(TMP_DIR, "repacked_mini_obb.pak")
    if os.path.exists(repacked_pak):
        for root, dirs, files in os.walk(OUTPUT_OBB):
            for file in files:
                if file.endswith('.pak'):
                    dest_path = os.path.join(root, file)
                    shutil.copy(repacked_pak, dest_path)
                    print(f"\033[1;33m[INFO] Replaced {file} with edited version.\033[0m")
                    break

    with zipfile.ZipFile(final_obb_path, 'w', zipfile.ZIP_DEFLATED) as zip_out:
        for root, dirs, files in os.walk(OUTPUT_OBB):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, OUTPUT_OBB)
                zip_out.write(full_path, rel_path)

    print(f"\033[1;32m[SUCCESS] Final OBB created successfully at '{final_obb_path}'!\033[0m")

def main_menu():
    if not verify_login():
        return

    create_folders()
    while True:
        os.system('clear' if os.name == 'posix' else 'cls')
        banner()
        print("[1] Unpack OBB (Copy OBB to repack folder)")
        print("[2] Unpack PAK (Extract DAT files from PAK)")
        print("[3] Repack PAK (Create PAK from edited DAT files)")
        print("[4] Repack OBB (Create final OBB with updated PAK)")
        print("[5] Clean All Folders (except input)")
        print("[0] Exit\n")
        
        choice = input("Select an option (0-5): ")
        
        if choice == '1':
            unpack_obb()
            input("\nPress Enter to continue...")
        elif choice == '2':
            unpack_pak()
            input("\nPress Enter to continue...")
        elif choice == '3':
            repack_pak()
            input("\nPress Enter to continue...")
        elif choice == '4':
            repack_obb()
            input("\nPress Enter to continue...")
        elif choice == '5':
            print("\n\033[1;31m[INFO] Cleaning temporary folders...\033[0m")
            for folder in [OUTPUT_OBB, TMP_DIR, UNPACK_PAK_DIR, REPACK_DIR]:
                shutil.rmtree(folder, ignore_errors=True)
            create_folders()
            print("\033[1;32m[SUCCESS] Cleaned successfully!\033[0m")
            input("\nPress Enter to continue...")
        elif choice == '0':
            print("\nExiting tool. Allah Hafiz!")
            break
        else:
            print("\n\033[1;31m[ERROR] Invalid option!\033[0m")
            input("\nPress Enter to continue...")

if __name__ == '__main__':
    main_menu()