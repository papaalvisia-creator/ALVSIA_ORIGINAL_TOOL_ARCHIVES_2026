# SECURITY — ALVSIA TOOL PREMIUM

Dokumen ini menjelaskan apa yang sebenarnya dilakukan lapisan keamanan, apa yang bisa
ia cegah, dan — sama pentingnya — apa yang **tidak** bisa ia cegah. Anda meminta
keamanan yang membuat penyerang profesional butuh waktu lama dan banyak metode. Itu
bisa dicapai, tetapi hanya kalau kita jujur soal batasnya. Klien yang berjalan di
perangkat pengguna selalu bisa dibongkar oleh orang yang memegang perangkat itu; yang
bisa kita lakukan adalah membuat pembongkaran itu mahal, berlapis, dan mudah terdeteksi.

---

## 1. Tiga lapis pertahanan

### Lapis 1 — Anti-debug

Sebelum apa pun dijalankan, launcher memeriksa apakah ada debugger yang menempel.
Empat pemeriksaan dipakai bersamaan, karena masing-masing bisa dilewati sendiri-sendiri
tetapi sulit dilewati semuanya sekaligus.

Pertama, `sys.gettrace()` — kalau tidak `None`, ada tracer Python aktif, dan itu berarti
seseorang sedang menelusuri eksekusi baris per baris. Kedua, `/proc/self/status` di Linux:
baris `TracerPid` harus `0`; nilai selain nol berarti proses ini adalah anak dari sebuah
debugger. Ketiga, di Windows, `IsDebuggerPresent` dan `CheckRemoteDebuggerPresent` dari
`kernel32` dipanggil langsung lewat `ctypes`, karena keduanya membaca struktur PEB yang
tidak bisa dipalsukan dari sisi Python. Keempat, variabel lingkungan `PYTHONINSPECT` dan
`PDB_START` diperiksa, karena keduanya adalah cara paling malas untuk masuk ke interpreter
setelah skrip selesai.

Kalau salah satu terpenuhi, tool berhenti dengan pesan yang jelas. Ia tidak mencoba
"melawan" debugger, karena melawan hanya membuang waktu dan memberi petunjuk.

### Lapis 2 — Integritas file

`assets/manifest.sha256` mencatat SHA-256 dari 22 file inti: launcher, klien lisensi,
lapisan keamanan, dan seluruh berkas `.py` di dalam `modules/`. Sebelum modul dijalankan,
setiap file dihitung ulang dan dibandingkan. Kalau ada yang hilang atau berubah satu byte
saja, tool berhenti dan menyebutkan file mana yang bermasalah.

Ini menutup kelas serangan yang paling sering dipakai terhadap tool seperti ini: menambal
satu baris di klien lisensi supaya `login()` selalu mengembalikan sukses, atau menanam
hook di `requests` supaya balasan panel dipalsukan. Kedua trik itu mengubah file, dan
perubahan file langsung terlihat.

Manifest dibangun ulang dengan `python tools/build_manifest.py`. Itu memang sengaja
mudah — Anda pemiliknya, dan Anda akan sering mengedit kode. Yang membuat manifest
berguna bukan kerumitan membuatnya, tetapi kenyataan bahwa klien **menolak jalan** kalau
isinya tidak cocok.

### Lapis 3 — Isolasi proses

Modul tidak diimpor ke dalam proses launcher. Ia dijalankan sebagai proses anak lewat
`subprocess`. Konsekuensinya: session token, kunci transport AES, dan seluruh state
lisensi tetap hidup di memori launcher, dan tidak pernah ikut masuk ke ruang alamat
proses yang sedang mengolah file PAK milik orang lain. Kalau sebuah modul di-crash-kan
dengan file masukan yang dibuat khusus, yang jatuh hanya proses anak itu.

Isolasi ini juga alasan teknis mengapa tool tetap kompatibel: setiap modul mendapat
direktori kerja sendiri, jadi mesin yang masih memakai path relatif berjalan seperti
aslinya tanpa perlu ditulis ulang.

---

## 2. Yang dijaga pada lapisan lisensi

Kunci transport diturunkan dari `SHA256("ALVSIA_V2|" + nonce)` dan nonce dibuat baru oleh
server untuk setiap handshake. Artinya tidak ada kunci statis yang bisa dicuri sekali
lalu dipakai selamanya. IV permintaan diambil dari 16 karakter hex pertama nonce,
sedangkan IV balasan dikirim server secara acak di field `ip` — jadi dua arah memakai IV
berbeda, dan menyadap satu sesi tidak membantu membuka sesi lain.

Proof-of-work SHA-256 dengan `pow_diff` dari server membuat pengiriman paket secara massal
menjadi mahal: setiap percobaan harus dihitung dulu, dan itu membatasi laju tebakan key.
Captcha aritmetika yang dikirim dalam base64 menambah satu langkah lagi yang harus
diselesaikan dengan benar sebelum paket diterima.

Di sisi klien, tiga pemeriksaan dilakukan setelah balasan dibuka. `check_token` harus
sama dengan `cid` handshake — kalau tidak, balasan itu bukan untuk permintaan kita.
Selisih `server_ts` dengan jam lokal tidak boleh lebih dari 180 detik — ini menutup
replay balasan lama. Dan `session_token` harus ada; tanpa itu, tidak ada sesi.

### Pinning sertifikat TLS

Sejak v4.0.1, klien memeriksa kunci publik sertifikat server sebelum data lisensi
dikirim. Yang dipin adalah **SubjectPublicKeyInfo** (gaya HPKP), bukan seluruh
sertifikat — jadi sertifikat boleh diperpanjang atau diterbitkan ulang selama kunci
publiknya tetap sama.

Tiga pin tertanam, dan koneksi diterima bila cocok dengan salah satunya:

| Peran | Keterangan | Pin |
|---|---|---|
| Utama | leaf certificate | `sha256/3dKRo5uvtVM2x5/NJsOEKFEy803l0rPct3Jv0AoiukE=` |
| Cadangan 1 | ZeroSSL ECC DV SSL CA 2 (s/d 23 Sep 2035) | `sha256/xwyjb5aN7tSRWj02XSZa2cKGLxXLdKHUBfLT/7twjhQ=` |
| Cadangan 2 | Sectigo Public Server Authentication Root E46 (s/d 18 Jan 2038) | `sha256/sLVjNUaFYfW7n6EtgBeEpjOlcnBdNPMrZDRF36iwBdE=` |

Pin cadangan membuat tool tetap bisa login saat sertifikat leaf diperbarui, tanpa
Anda harus merilis ulang tool. Kalau kunci publik benar-benar berganti (misalnya
pindah CA), pin di `license_client.py` harus diperbarui — lihat bagian 5.

Pinning hanya berlaku untuk host `alvsiapanel.unaux.com`. Kalau Anda mengarahkan
tool ke endpoint lain lewat `--panel`, verifikasi CA standar tetap dipakai, tetapi
pin tidak ditegakkan — karena pin hanya bermakna untuk host yang Anda tentukan.

Selain itu `session.trust_env = False` dimatikan untuk environment: variabel
`HTTP_PROXY`/`HTTPS_PROXY` dan `REQUESTS_CA_BUNDLE` diabaikan, sehingga pinning
tidak bisa dilewati dengan menyuntikkan proxy. Ini menutup trik MITM paling umum.

Perlu ditegaskan: **panel tidak diubah**. Tidak ada tabel, kolom, atau endpoint baru.
Semua pemeriksaan di atas memakai field yang memang sudah dikirim panel standar Anda.

---

## 3. Sesi lokal

Sesi disimpan di `~/.alvsia/session.json` dengan permission `0600`, bersama `device.id`
dan `config.json`. HWID diturunkan dari identitas perangkat dan dinormalisasi menjadi
huruf kecil dengan karakter `[a-z0-9_\-:]`, sehingga nilai yang sama selalu menghasilkan
HWID yang sama di panel.

Sesi diperpanjang lewat `refresh_session.php` sebelum kedaluwarsa. Kalau perpanjangan
gagal, token lokal dihapus dan tool meminta login ulang — lebih baik menolak daripada
melanjutkan dengan sesi yang mungkin sudah dicabut.

Satu hal yang sering disalahpahami: menyalin `~/.alvsia/` ke perangkat lain tidak akan
memberi akses. Sesi terikat pada HWID, dan panel akan menolaknya. Itu memang tujuannya.

---

## 4. Batas yang harus Anda tahu

Klien berjalan di perangkat pengguna. Siapa pun yang memegang perangkat itu bisa, dengan
usaha cukup, membaca memori proses, menambal bytecode, atau menjalankan tool di mesin
virtual. Tidak ada skema klien yang bisa mencegah itu sepenuhnya, dan siapa pun yang
mengklaim sebaliknya sedang menjual ilusi.

Yang bisa dilakukan lapisan ini adalah menaikkan biaya: setiap trik pembongkaran yang
umum (patch fungsi login, hook HTTP, dump memori sederhana, jalankan di bawah debugger)
harus dihadapi satu per satu, dan sebagian besar meninggalkan jejak berupa file yang
berubah atau debugger yang terdeteksi. Penyerang yang sabar dan terampil tetap akan
menang pada akhirnya — tetapi ia butuh waktu, dan selama waktu itu ia harus melewati
tiga lapis yang berbeda, bukan satu.

Karena itu, pertahanan yang paling menentukan bukan ada di klien, melainkan di panel:
`max_devices`, pembatasan laju `api_connect` (15 permintaan per 60 detik), blokir IP,
penghitung `crack_attempt` dengan auto-ban pada tiga percobaan, dan pencatatan HWID.
Semua itu sudah ada di panel standar Anda dan tidak kami sentuh. Klien yang hardened
adalah lapisan tambahan di atasnya, bukan pengganti.

---

## 5. Kalau Anda menemukan file yang berubah

Kalau tool berhenti dengan pesan integritas, jangan langsung membangun ulang manifest.
Periksa dulu file yang disebut. Kalau Anda sendiri yang mengeditnya, bangun ulang:

```bash
cd tool
python tools/build_manifest.py
```

Kalau Anda **tidak** mengeditnya, jangan bangun ulang. Salin file itu ke tempat lain,
bandingkan dengan salinan bersih dari arsip asli, dan cari tahu apa yang berubah. Membangun
ulang manifest pada file yang tidak Anda kenal sama saja mematikan lapis kedua tepat pada
saat ia bekerja.

### Kalau sertifikat panel berganti

Gejalanya: tool menolak login dengan pesan `Sertifikat server tidak cocok dengan pin
ALVSIA`, dan pesan itu menampilkan pin yang sedang disajikan server. Ambil pin tersebut,
lalu cocokkan dengan sertifikat panel Anda. Kalau memang benar sertifikat baru:

1. Buka `tool/license_client.py`, cari `TLS_PINS`.
2. Tambahkan pin baru ke daftar. Jangan hapus pin lama sekaligus — simpan sebagai
   cadangan sampai yakin tidak ada perangkat yang masih memakai versi lama.
3. Jalankan `python tools/build_manifest.py`.
4. Bagikan ulang tool ke pengguna.

Untuk melihat pin yang sedang aktif pada sebuah host tanpa menjalankan tool:

```bash
cd tool
python tools/pin_check.py
```

Skrip itu mencetak subject, issuer, masa berlaku, dan pin sertifikat server, lalu
memberi tahu apakah pin tersebut sudah ada di daftar.

Untuk keperluan debugging saja, `ALVSIA_PIN_DISABLE=1` mematikan penegakan pin. Jangan
pernah membagikan tool dengan variabel ini aktif, dan jangan jadikan kebiasaan.

---

## 6. Melaporkan masalah keamanan

Kalau Anda menemukan celah, laporkan lewat channel **@ALVSIA_PRO** atau langsung ke
**@OriginalOnwerALV**. Sertakan langkah reproduksi yang jelas. Jangan mempublikasikan
detailnya sebelum ada perbaikan — tool ini sudah cukup sering dibongkar dan diposting
orang lain, dan setiap detail yang beredar terlalu cepat memperpendek umur pertahanan
yang sudah dibangun.
