# CARA INSTALL — ALVSIA TOOL PREMIUM

Panduan ini ditulis urut dari nol sampai tool benar-benar jalan. Ikuti dari atas, jangan
dilompati, karena setiap langkah bergantung pada langkah sebelumnya.

---

## 1. Yang harus ada di perangkat

Anda butuh Python 3.9 atau lebih baru. Versi 3.11 adalah yang paling banyak diuji dan
paling aman dipakai. Selain Python, tidak ada yang wajib — semua dependensi lain adalah
paket Python yang dipasang dengan satu perintah.

Kalau Anda memakai Termux di Android, pasang Python lebih dulu:

```bash
pkg update && pkg upgrade -y
pkg install python git -y
```

Kalau Anda memakai Linux biasa, Python biasanya sudah ada. Periksa dengan:

```bash
python3 --version
```

Kalau Anda memakai Windows, pasang Python dari python.org dan **centang** pilihan
"Add Python to PATH" saat instalasi. Tanpa centang itu, perintah `python` tidak dikenali
di Command Prompt.

Satu hal lagi yang sering terlewat: beberapa modul memanggil Java untuk dekompilasi Lua
penuh. `unluac` sudah tertanam di dalam paket, jadi yang perlu Anda pasang hanya
runtime-nya. Di Termux cukup `pkg install openjdk-17`, di Debian/Ubuntu
`sudo apt install default-jre`, di Windows pasang JRE dari situs Oracle atau Adoptium.
Kalau Java tidak ada, tool tetap jalan — hanya fitur dekompilasi penuh yang memberi
peringatan dan melewati langkah itu.

---

## 2. Menaruh file di tempat yang benar

Ekstrak paket sehingga Anda punya struktur seperti ini:

```
ALVSIA_TOOL/
├── README.md
├── CARA_INSTALL.md
├── SECURITY.md
└── tool/
    ├── alvsia.py
    ├── license_client.py
    ├── security.py
    └── modules/
```

Yang penting: `alvsia.py`, `license_client.py`, `security.py`, dan folder `modules/`
harus berada dalam satu folder yang sama. Jangan memindahkan salah satunya keluar,
karena launcher mencari modul secara relatif terhadap lokasinya sendiri.

Hindari juga menaruh folder ini di dalam folder yang namanya mengandung spasi atau
karakter aneh di Windows. Beberapa mesin lama memanggil proses eksternal dengan path
mentah, dan spasi bisa memecah argumen.

---

## 3. Memasang dependensi

Masuk ke folder `tool`, lalu:

```bash
cd ALVSIA_TOOL/tool
pip install -r requirements.txt
```

Isi `requirements.txt` sengaja dibuat pendek dan semuanya paket populer: `rich` untuk
tampilan, `requests` untuk komunikasi panel, `pycryptodome` untuk AES-256-CBC,
`cryptography` sebagai cadangan kalau pycryptodome tidak bisa dipasang, `zstandard`
untuk dekompresi PAK modern, `gmalg` untuk algoritma ZUC, `pytz` untuk zona waktu, dan
`repak` untuk mesin PAK berbasis Unreal.

Kalau `pip` menolak karena masalah izin di Linux, jangan pakai `sudo pip`. Buat
virtual environment:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
```

`run.sh` melakukan ini otomatis kalau `.venv` belum ada, jadi Anda sebenarnya bisa
langsung menjalankan `./run.sh` dan membiarkannya mengurus semuanya.

Kalau `zstandard` gagal dikompilasi di Termux, pasang dulu pustaka sistemnya:

```bash
pkg install libzstd -y
pip install zstandard
```

Kalau `gmalg` gagal, biasanya karena ia butuh `cffi`; pasang `pkg install libffi` lalu
ulangi. Kalau tetap gagal, tool masih bisa jalan untuk sebagian besar pekerjaan PAK —
hanya fitur yang memakai ZUC yang akan menolak.

---

## 4. Login pertama

Jalankan launcher:

```bash
python alvsia.py
```

Pada percobaan pertama, tool akan meminta license key. Ketik key Anda, tekan Enter.
Yang terjadi di belakang layar: tool mengambil captcha dari panel, menyelesaikan soal
aritmetika, menyelesaikan proof-of-work, mengirim paket terenkripsi, lalu menerima
`session_token`. Kalau berhasil, Anda langsung masuk ke menu enam belas modul.

Kalau Anda lebih suka login sekali lalu tidak pernah ditanya lagi:

```bash
python alvsia.py --license ALV-XXXX-XXXX-XXXX
```

Sesi disimpan di `~/.alvsia/` dengan permission `0600`. Periksa kapan saja dengan
`python alvsia.py --status`, dan hapus dengan `python alvsia.py --logout`.

Kalau panel Anda bukan panel bawaan, arahkan sekali saja:

```bash
python alvsia.py --panel https://domain-anda.com/api --license ALV-XXXX-XXXX
```

Endpoint itu ikut tersimpan di `~/.alvsia/config.json`, jadi pemanggilan berikutnya
tidak perlu `--panel` lagi.

---

## 5. Menjalankan modul

Dari menu, ketik nomor modul atau namanya. Anda juga bisa langsung menuju satu modul
tanpa melewati menu:

```bash
python alvsia.py core
python alvsia.py forge
python alvsia.py lualab
```

Kalau modul butuh argumen, argumen setelah nama modul diteruskan apa adanya:

```bash
python alvsia.py core info game.pak
```

Setiap modul punya folder kerjanya sendiri di bawah `modules/<nama>/`. File masukan
diletakkan di folder yang diminta modul tersebut (biasanya `PAK/`, `SOURCE/`, atau
`INPUT/`), dan hasilnya muncul di folder keluaran modul itu (`RESULT/`, `OUTPUT/`, atau
`COMPILED/`). Modul akan memberi tahu path persisnya saat dijalankan, jadi Anda tidak
perlu menebak.

---

## 6. Kalau muncul masalah

**"Integritas file tidak valid"** — ada file inti yang berubah. Ini normal kalau Anda
baru mengedit kode. Bangun ulang daftar hash:

```bash
python tools/build_manifest.py
```

**"Tidak bisa menghubungi server"** — panel tidak terjangkau. Periksa koneksi, lalu
pastikan endpoint benar lewat `--status`. Kalau Anda di jaringan yang memblokir domain
tertentu, coba dari jaringan lain.

**"Peringatan keamanan: waktu server tidak sinkron"** — jam perangkat Anda melenceng
lebih dari tiga menit. Sinkronkan jam sistem, lalu login ulang.

**"Max devices reached"** — HWID perangkat ini sudah memenuhi kuota `max_devices` untuk
key tersebut. Kelola perangkat dari panel, atau pakai key dengan kuota lebih besar.

**"Lisensi ditolak"** — key salah ketik, sudah kedaluwarsa, atau diblokir. Cek di panel.

**Modul langsung menutup** — jalankan langsung tanpa launcher untuk melihat pesan
error lengkapnya:

```bash
cd modules/core
python engine.py
```

Pesan dari proses anak itulah yang biasanya menunjukkan penyebab sebenarnya.

---

## 7. Memindahkan tool ke perangkat lain

Salin seluruh folder `ALVSIA_TOOL`. Jangan menyalin `~/.alvsia/` kecuali Anda memang
ingin memakai sesi yang sama — file itu terikat pada HWID perangkat asal, dan menyalinnya
ke mesin lain hanya akan menghasilkan penolakan sesi. Lebih bersih: login ulang di
perangkat baru, dan pastikan kuota `max_devices` masih mencukupi.
