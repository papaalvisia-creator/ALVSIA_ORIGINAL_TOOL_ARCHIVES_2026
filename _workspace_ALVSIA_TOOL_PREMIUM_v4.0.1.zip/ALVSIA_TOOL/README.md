# ALVSIA TOOL PREMIUM

**Satu launcher, enam belas mesin, satu gerbang lisensi.**

- Nama produk: **ALVSIA TOOL PREMIUM**
- Owner: **@OriginalOnwerALV**
- Channel: **@ALVSIA_PRO**
- Versi: **4.0.1**
- Panel lisensi: panel standar Anda di `https://alvsiapanel.unaux.com/api` (tidak diubah sama sekali)

---

## 1. Apa yang Anda pegang sekarang

Dulu setiap mesin berdiri sendiri: masing-masing punya menu, punya cara login, punya
folder kerja, dan sebagian menempel ke panel pihak lain. Sekarang semuanya duduk di
bawah satu pintu bernama ALVSIA TOOL PREMIUM. Anda menjalankan satu perintah,
memasukkan satu license key, lalu memilih mesin dari satu menu. Kode tiap mesin tetap
kode aslinya — kemampuan yang sudah Anda kenal tidak berkurang — tetapi namanya,
tampilannya, dan lapisan lisensinya sudah diseragamkan.

Enam belas mesin itu adalah:

| No | Modul | Isi |
|----|-------|-----|
| 1 | `core` — ALVSIA CORE | Mesin utama: baca/ekstrak/repack PAK UE4 v3–v14, SM4, Zstd, Lua 5.3 |
| 2 | `studio` — ALVSIA STUDIO | Suite lengkap: PAK, LUA, SM4, repack, kompilasi, unluac |
| 3 | `forge` — ALVSIA FORGE | OBB, ZSDIC, game patch, SM4 key finder, encrypt/decrypt |
| 4 | `luaflow` — ALVSIA LUAFLOW | Alur kerja Lua: unpack, edit, repack, emulator helper |
| 5 | `lualab` — ALVSIA LUALAB | Laboratorium Lua: kompilasi & dekompilasi batch (luac disertakan) |
| 6 | `pakx` — ALVSIA PAKX | Utilitas PAK/Lua serbaguna |
| 7 | `compiler` — ALVSIA COMPILER | Kompilasi/dekompilasi Lua, kelola folder SOURCE & LUA |
| 8 | `decoder` — ALVSIA DECODER | Dekode file Python/Lua yang diobfuskasi |
| 9 | `keyfinder` — ALVSIA KEYFINDER | Cari key SM4 di dalam file PAK/binary |
| 10 | `unpacker` — ALVSIA UNPACKER | Unpack PAK: scan slot S2+zlib, ekstrak Lua/Bin, manifest |
| 11 | `obbx` — ALVSIA OBBX | Kelola OBB: unpack, repack, extract asset |
| 12 | `scanner` — ALVSIA SCANNER | Ekstrak sub-function & offset dari library native |
| 13 | `layerx` — ALVSIA LAYERX | Layer lanjutan: SM4 layer, config technician |
| 14 | `luadump` — ALVSIA LUADUMP | Dump, decompile, edit, repack Lua |
| 15 | `battlepak` — ALVSIA BATTLEPAK | PAK khusus game battle royale (repak based) |
| 16 | `shield` — ALVSIA SHIELD | Mesin terproteksi (modul terkompilasi + integrity check) |

Setiap modul dijalankan sebagai **proses terpisah**. Ini bukan kemewahan teknis, ini
pertahanan: kalau satu mesin crash karena file PAK yang rusak, mesin lain tidak ikut
mati, dan launcher tetap memegang kendali. Efek sampingnya juga menguntungkan — mesin
yang masih memakai path relatif (`PAK/`, `SOURCE/`, `RESULT/`) tetap bekerja persis
seperti aslinya karena direktori kerjanya di-set ke folder modulnya sendiri.

---

## 2. Cara menjalankan

Pasang dependensi sekali saja:

```bash
cd tool
pip install -r requirements.txt
```

Lalu:

```bash
python alvsia.py                 # menu interaktif
python alvsia.py --license ALV-XXXX-XXXX
python alvsia.py core            # langsung ke satu modul
python alvsia.py --list          # daftar modul
python alvsia.py --status        # cek sesi lisensi yang tersimpan
python alvsia.py --logout        # hapus sesi lokal
```

Di Linux/Termux Anda bisa memakai `./run.sh`, di Windows `run.bat`. Keduanya hanya
membungkus perintah di atas dan memasang dependensi yang belum ada.

Endpoint panel bisa diganti tanpa menyentuh kode:

```bash
python alvsia.py --panel https://domain-anda.com/api
# atau
export ALVSIA_PANEL=https://domain-anda.com/api
```

Bawaan pabriknya adalah panel standar Anda, `https://alvsiapanel.unaux.com/api`.

---

## 3. Alur lisensi

Launcher memakai protokol panel yang sama persis dengan panel standar Anda, tanpa
satu pun perubahan di sisi server. Urutannya: ambil captcha (`captcha.php`), selesaikan
soal aritmetika yang dikirim dalam base64, selesaikan proof-of-work SHA-256 sesuai
`pow_diff`, lalu kirim paket terenkripsi AES-256-CBC ke `connect.php` dengan penanda
protokol v2. Kunci transport diturunkan dari `SHA256("ALVSIA_V2|" + nonce)`, IV
permintaan adalah 16 karakter hex pertama dari nonce, dan IV balasan dikirim server di
field `ip`. Balasan berisi `session_token`, `expiry`, `max_devices`, dan `seller`.

Setelah login, sesi disimpan di `~/.alvsia/session.json` dengan permission `0600`
beserta `device.id` dan `config.json`. Sesi diperpanjang lewat `refresh_session.php`
sebelum kedaluwarsa, jadi Anda tidak perlu mengetik ulang key setiap kali membuka tool.
Kalau panel memakai proteksi Unaux, klien otomatis menyelesaikan challenge
`toNumbers(...)` + AES dan memasang cookie `__test` sebelum mengulang permintaan —
tanpa interaksi manual.

Yang perlu Anda tahu: **panel tidak diubah**. Tidak ada tabel baru, tidak ada endpoint
baru, tidak ada kolom baru. Tool baru ini hanya klien yang taat protokol.

---

## 4. Keamanan

Bagian ini diringkas di sini; detail lengkapnya ada di `SECURITY.md`.

Ada tiga lapis yang bekerja berurutan. Pertama, **anti-debug**: launcher menolak jalan
kalau mendeteksi `sys.gettrace()`, `TracerPid` di `/proc/self/status`, `PYTHONINSPECT`,
`PDB_START`, atau (di Windows) `IsDebuggerPresent` dan `CheckRemoteDebuggerPresent`.
Kedua, **integritas**: 22 file inti (launcher, klien lisensi, lapisan keamanan, dan
seluruh modul `.py`) dicatat SHA-256-nya di `assets/manifest.sha256`; satu byte berubah
maka tool berhenti dan menyebut file mana yang bermasalah. Ketiga, **isolasi**: modul
berjalan di subprocess, sehingga memori launcher — tempat session token dan kunci
transport hidup — tidak pernah ikut masuk ke ruang proses mesin yang sedang bekerja.

Di samping tiga lapis itu, koneksi ke panel dilindungi **pinning sertifikat TLS**.
Klien memeriksa kunci publik sertifikat server (SubjectPublicKeyInfo) sebelum satu byte
data lisensi dikirim, dan menerima koneksi hanya bila cocok dengan salah satu dari tiga
pin yang tertanam: satu pin leaf dan dua pin CA cadangan. Proxy dari environment juga
diabaikan, jadi pinning tidak bisa dilewati lewat `HTTP_PROXY`. Kalau suatu saat
sertifikat panel benar-benar berganti kunci, cara memperbarui pin ada di `SECURITY.md`
bagian 5.

---

## 5. Struktur folder

```
ALVSIA_TOOL/
├── README.md
├── CARA_INSTALL.md
├── SECURITY.md
└── tool/
    ├── alvsia.py            launcher + menu + verifikasi
    ├── license_client.py    klien panel (protokol v2, Unaux, sesi, aset)
    ├── security.py          anti-debug + manifest SHA-256
    ├── requirements.txt
    ├── run.sh / run.bat
    ├── assets/
    │   └── manifest.sha256  daftar hash file inti
    ├── tools/
    │   ├── build_manifest.py
    │   ├── smoke_import.py
    │   ├── e2e_login.py
    │   └── negative_tests.py
    └── modules/
        ├── registry.py      katalog 16 modul
        ├── core/ studio/ forge/ luaflow/ lualab/ pakx/ compiler/
        ├── decoder/ keyfinder/ unpacker/ obbx/ scanner/ layerx/
        └── luadump/ battlepak/ shield/
```

---

## 6. Kalau ada yang tidak jalan

Kalau launcher menolak start dan menyebut integritas file, itu artinya ada file inti
yang berubah — biasanya karena Anda sendiri baru mengeditnya. Bangun ulang manifest
setelah edit yang sah:

```bash
cd tool
python tools/build_manifest.py
```

Kalau lisensi ditolak padahal key benar, cek tiga hal berurutan: apakah `--status`
menunjukkan panel yang benar, apakah jam sistem Anda melenceng lebih dari tiga menit
dari jam server (klien menolak selisih di atas 180 detik), dan apakah HWID perangkat
ini sudah mencapai `max_devices` di panel.

Kalau sebuah modul butuh Java untuk dekompilasi penuh, modul akan memberi tahu sendiri
saat dijalankan; `unluac` sudah tertanam di dalam paket, jadi cukup pasang Java.

---

## 7. Catatan kepemilikan

Seluruh mesin di dalam paket ini adalah hasil kerja Anda. Nama lama sudah tidak dipakai
lagi di mana pun — tidak di nama file, nama folder, banner, komentar, string runtime,
maupun pesan error. Yang tersisa hanyalah satu identitas: ALVSIA TOOL PREMIUM, dengan
channel @ALVSIA_PRO dan owner @OriginalOnwerALV.
