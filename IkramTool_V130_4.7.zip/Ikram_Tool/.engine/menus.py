"""IkramTool V130 — menu handlers + canonical menu definitions.

Every real operation stays the ORIGINAL flow, run exactly as shipped:

    PAK  1 Unpack    -> ikram.pak_extract
         2 Inject    -> ikram.pak_inject
         3 Repack    -> ikram.pak_repack_folder
         4 Custom    -> ikram.pak_costom_pak
    LUA  1 Compile   -> ikram.lua_compile_one
         2 Decompile -> ikram.lua_decompile_one

Delegating (instead of re-implementing) is what guarantees Section G:
paths, prompt order, numbered displays, auto-replace, never-modify-original,
new-folder creation, example/help text, repack + costom logic and output
path behaviour are byte-identical to the shipped tool. The shell (vip_ui.py)
only adds the theme, the menu loops and the C/R/VIP utilities below.

This module is also the SINGLE SOURCE OF TRUTH for menu order + labels
(``MENU_SPECS``) and for the "one result box / one continue" contract
(``finish``). The delegated PAK/LUA operations already render their own
result panel and call ``ikram.pause()`` exactly once, so they are NOT wrapped
again here — doing so was the classic double-continue bug. Operations owned
by this module go through ``finish()``, which guarantees one box + one pause.

Public API kept backwards-compatible: all original handler names/signatures
are unchanged. New helpers are additive.

`ikram` is the module loaded by ikram_patch.py (compiled core + patched
overlay). Vip passes it in at construction time.
"""
import time
from pathlib import Path

import paths
from theme_engine import glyph


def mark_outcome(vip, outcome):
    """Record cancel/failure outcomes that do not raise their own result box."""
    try:
        fn = getattr(vip, "_mark_outcome", None)
        if callable(fn):
            fn(outcome)
        else:
            vip._last_outcome = outcome
    except Exception:
        pass


# ================================================================== menu specs
# Canonical order + labels. vip_ui.py may render from these instead of keeping
# its own copies; the tuples are (key, label, help_lines, target).
# ``target`` is a symbolic name resolved by ``dispatch()`` or by the shell.
CATEGORY_MAIN      = "MAIN"
CATEGORY_PAK       = "PAK"
CATEGORY_LUA       = "LUA"
CATEGORY_SAVEGAMES = "SAVEGAMES"
CATEGORY_THEMES    = "THEMES"
CATEGORY_CLEAN     = "CLEAN"

BACK_KEY = "0"

# Context shown on the top border of every menu prompt. The old shell printed
# a generic choice label on all of them, so PAK and LUA looked identical.
CHOICE_TITLES = {
    CATEGORY_MAIN: "Pick a Number",
    CATEGORY_PAK: "PAKTOOL CHOICE",
    CATEGORY_LUA: "LUA TOOL CHOICE",
    CATEGORY_SAVEGAMES: "SAVEGAMES CHOICE",
    CATEGORY_THEMES: "THEMES CHOICE",
    CATEGORY_CLEAN: "CLEAN CHOICE",
}

MENU_SPECS = {
    CATEGORY_MAIN: [
        ("1", "📦 PAK TOOL (UNPACK, INJECT, REPACK, COSTOMPAK)",
         ["UNPACK: DROP/pak/ -> RESULT/extracted/ + RESULT/processed/",
          "INJECT: DROP/pak/ + DROP/inject/ -> RESULT/injected/",
          "REPACK: RESULT/extracted/ -> RESULT/Repacked/",
          "CUSTOM PAK: DROP/pak/ -> RESULT/CostomPak/"], "run_pak"),
        ("2", "📜 LUA TOOL (COMPILING, DECOMPILING)",
         ["compile / decompile lua (engine picker)"], "run_lua"),
        ("3", "💾 SAVEGAMES (ENCRYPT, DECRYPT)",
         ["encrypt / decrypt PUBG .sav (GVAS) files",
          "PUT FILE IN: DROP/SaveGames",
          "OUTPUT: RESULT/SaveGames/"], "run_savegames"),
        ("4", "🎨 THEMES",
         ["switch the color theme of the whole tool"], "run_themes"),
        ("5", "🧹 CLEAN",
         ["clear DROP / RESULT folders in one place"], "run_clean"),
        ("0", "EXIT", ["close the tool"], "exit"),
    ],
    CATEGORY_PAK: [
        ("1", "📦 Unpack PAK",
         ["WORK: take all files out of the pak.",
          "PUT FILE IN: DROP/pak", "OUTPUT: RESULT/extracted/"], "pak_unpack"),
        ("2", "📦 Inject File",
         ["WORK: put any file into the pak (auto type detect).",
          "PUT FILE IN: DROP/inject + DROP/pak",
          "OUTPUT: RESULT/injected/"], "pak_inject"),
        ("3", "📦 Repack PAK",
         ["WORK: rebuild a pak from RESULT/extracted.",
          "OUTPUT: RESULT/Repacked/"], "pak_repack"),
        ("4", "📦 Custom Pak",
         ["WORK: PATH MODE + FILE MODE.",
          "PATH: 1 ONE PATH · 2 HOW MANY · 3 ALL + EMPTY FILES.",
          "EXISTING PATH = COPY FILES · NEW PATH = ASK FILE NAMES.",
          "PUT FILE IN: DROP/pak", "OUTPUT: RESULT/CostomPak/"], "pak_custom"),
        ("0", "← Back", [], "back"),
    ],
    CATEGORY_LUA: [
        ("1", "📜 Compile",
         ["WORK: make a game-ready compiled file.",
          "PUT FILE IN: DROP/lua", "OUTPUT: RESULT/lua/"], "lua_compile"),
        ("2", "📜 Decompile",
         ["WORK: readable source from a compiled file.",
          "engine picker (ENTER = AUTO / SKUY VIP)",
          "PUT FILE IN: DROP/lua", "OUTPUT: RESULT/lua/"], "lua_decompile"),
        ("0", "← Back", [], "back"),
    ],
    CATEGORY_SAVEGAMES: [
        ("1", "🔒 Encrypt", ["compile .json source back to .sav",
                             "OUTPUT: RESULT/SaveGames/"], "savegames_encrypt"),
        ("2", "🔓 Decrypt", [".sav -> editable .json source",
                             "OUTPUT: RESULT/SaveGames/"], "savegames_decrypt"),
        ("3", "🔁 Process all", ["batch: decrypt every .sav/.gvas",
                                 "skips bad files and keeps going",
                                 "OUTPUT: RESULT/SaveGames/"], "savegames_process_all"),
        ("0", "← Back", [], "back"),
    ],
    CATEGORY_THEMES: [
        ("0", "← Back", [], "back"),
    ],
    CATEGORY_CLEAN: [
        ("1", "Clear ALL DROP/", [], "clear_all_drop"),
        ("2", "Clear RESULT/ (all)", [], "clear_result"),
        ("3", "Clear DROP/pak/", [], "clear_drop_pak"),
        ("4", "Clear DROP/lua/", [], "clear_drop_lua"),
        ("5", "Clear DROP/inject/", [], "clear_drop_inject"),
        ("6", "Clear DROP/SaveGames/", [], "clear_drop_savegames"),
        ("7", "Clear RESULT/extracted/", [], "clear_result_extracted"),
        ("8", "Clear RESULT/injected/", [], "clear_result_injected"),
        ("9", "Clear RESULT/lua/", [], "clear_result_lua"),
        ("10", "Clear RESULT/processed/", [], "clear_result_processed"),
        ("11", "Clear RESULT/CostomPak/", [], "clear_result_custompak"),
        ("12", "Clear RESULT/Repacked/", [], "clear_result_repacked"),
        ("13", "Clear RESULT/SaveGames/", [], "clear_result_savegames"),
        ("0", "← Back", [], "back"),
    ],
}

# CLEAN rows are generated from one target table. No second copy of the
# operation name is rendered: the number row names the folder and its own
# sub-box carries the coloured FILES/SIZE values.
CLEAN_BOUNDED_FILES = 4096
CLEAN_TARGET_PATHS = {
    "clear_all_drop": [paths.DROP_PAK, paths.DROP_LUA, paths.DROP_INJ,
                       paths.DROP_SAVEGAMES],
    "clear_result": [paths.RESULT_EXTRACTED, paths.RESULT_INJECTED,
                     paths.RESULT_LUA, paths.RESULT_PROCESSED,
                     paths.RESULT_CUSTOMPAK, paths.RESULT_REPACKED,
                     paths.RESULT_SAVEGAMES],
    "clear_drop_pak": [paths.DROP_PAK],
    "clear_drop_lua": [paths.DROP_LUA],
    "clear_drop_inject": [paths.DROP_INJ],
    "clear_drop_savegames": [paths.DROP_SAVEGAMES],
    "clear_result_extracted": [paths.RESULT_EXTRACTED],
    "clear_result_injected": [paths.RESULT_INJECTED],
    "clear_result_lua": [paths.RESULT_LUA],
    "clear_result_processed": [paths.RESULT_PROCESSED],
    "clear_result_custompak": [paths.RESULT_CUSTOMPAK],
    "clear_result_repacked": [paths.RESULT_REPACKED],
    "clear_result_savegames": [paths.RESULT_SAVEGAMES],
    "back": [],
}


def _clean_stats_values(target):
    """Return (files, bytes, known, pending) for one CLEAN target.

    Fresh cache first. A bounded scan fills small folders immediately; large
    trees reuse the last persisted snapshot. Nothing blocks on a full walk
    and no row is left saying "calculating" after a confirmation.
    """
    files = 0
    size = 0
    known = True
    pending = False
    for p in CLEAN_TARGET_PATHS.get(target, ()):
        n, b = paths.cached_count_dir(p)
        if n is None:
            pending = True
            qn, qb, exact = paths.count_dir_bounded(p, CLEAN_BOUNDED_FILES)
            if exact:
                n, b = qn, qb
                paths.remember_count(p, n, b)
            else:
                ln, lb = paths.last_count_dir(p)
                if ln is None:
                    n, b = 0, 0
                    known = False
                else:
                    n, b = ln, lb
        files += int(n or 0)
        size += int(b or 0)
    return files, size, known, pending


def _clean_stats_text_values(files, size, known):
    if not known:
        return "FILES : --  ·  SIZE : --"
    return "FILES : %d  ·  SIZE : %s" % (files, paths.human(size))


def _clean_stats_text(target):
    """Plain one-line stats, kept for probes and non-colour terminals."""
    files, size, known, _pending = _clean_stats_values(target)
    return _clean_stats_text_values(files, size, known)


def _clean_stat_line_values(vip, files, size, known):
    """One coloured sub-box row: FILES in accent, SIZE in warn, values bright."""
    file_value = str(files) if known else "--"
    size_value = paths.human(size) if known else "--"
    theme = getattr(vip, "theme", None)
    if theme is None:
        theme = getattr(getattr(vip, "box", None), "theme", None)
    if theme is None:
        return "FILES : %s  ·  SIZE : %s" % (file_value, size_value)
    sep = "   " + theme.apply("·", "separator") + "   "
    return (theme.apply("FILES", "accent", bold=True) + ": "
            + theme.apply(file_value, "primary", bold=True) + sep
            + theme.apply("SIZE", "warn", bold=True) + ": "
            + theme.apply(size_value, "success", bold=True))


def clean_menu_rows(vip):
    """Canonical CLEAN rows for every renderer: name row + one stat sub-box."""
    rows = []
    for k, lab, _help, t in menu_entries(CATEGORY_CLEAN):
        if t == "back":
            rows.append((k, lab, []))
            continue
        files, size, known, _pending = _clean_stats_values(t)
        rows.append((k, lab, [_clean_stat_line_values(vip, files, size, known)]))
    return rows


def menu_entries(category):
    """Return a fresh list of (key, label, help_lines, target) for a menu.

    Always returns a NEW list so a caller mutating it cannot poison the
    canonical spec (no stale state between menu loops).
    """
    return [tuple(row) for row in MENU_SPECS.get(str(category).upper(), ())]


def menu_choices(category, include_back=True):
    """Valid input keys for a category, in canonical order."""
    out = [normalize_choice(row[0]) for row in menu_entries(category)
           if row[0] != BACK_KEY or include_back]
    return tuple(out)


def normalize_choice(raw):
    """Normalise one menu keystroke: strip, lower, drop a trailing dot.

    Returns "" for EOF/blank. Used by every loop that reads its own input so
    invalid input never becomes a stale value on the next pass.
    """
    if raw is None:
        return ""
    return str(raw).strip().lower().rstrip(".")


# ================================================================ navigation
BREADCRUMBS = {
    CATEGORY_MAIN: ("MAIN MENU",),
    CATEGORY_PAK: ("MAIN MENU", "PAK TOOL"),
    CATEGORY_LUA: ("MAIN MENU", "LUA TOOL"),
    CATEGORY_SAVEGAMES: ("MAIN MENU", "SAVEGAMES"),
    CATEGORY_THEMES: ("MAIN MENU", "THEMES"),
    CATEGORY_CLEAN: ("MAIN MENU", "CLEAN"),
}

MENU_TITLES = {
    CATEGORY_MAIN: "MAIN MENU",
    CATEGORY_PAK: "PAK TOOL",
    CATEGORY_LUA: "LUA TOOL",
    CATEGORY_SAVEGAMES: "SAVEGAMES",
    CATEGORY_THEMES: "THEMES",
    CATEGORY_CLEAN: "CLEAN",
}


def breadcrumb(category):
    """Canonical category trail kept for logs. The UI does not render it."""
    return BREADCRUMBS.get(str(category).upper(), (CATEGORY_MAIN,))


def menu_title(category):
    cat = str(category).upper()
    if cat == CATEGORY_MAIN:
        return "IkramTOOL %s" % paths.read_version().upper()
    return MENU_TITLES.get(cat, "MENU")


def menu_choice_title(category):
    """Top-border label for the choice prompt owned by a category."""
    return CHOICE_TITLES.get(str(category).upper(), "SELECT CHOICE")


def menu_view(category, extra_rows=()):
    """Render-ready view derived from the canonical spec: title, crumbs,
    (key, label, help_lines) rows, valid choices, and the back key.
    `extra_rows` is only for dynamic menus (THEMES) — it never mutates spec.
    """
    cat = str(category).upper()
    rows = [(k, label, list(help_lines))
            for k, label, help_lines, _target in menu_entries(cat)]
    if extra_rows:
        insert_at = len(rows) - 1 if rows and rows[-1][0] == BACK_KEY else len(rows)
        rows[insert_at:insert_at] = [
            (str(k), str(label), list(help_lines))
            for k, label, help_lines in extra_rows
        ]
    return menu_title(cat), breadcrumb(cat), rows, menu_choices(cat), BACK_KEY


# ================================================================== plumbing
def _ikram(vip):
    """Return the compiled core, or None after showing ONE error + continue.

    A missing/partial core is a broken install; never let it raise an
    AttributeError deeper in a handler (that produced a blank screen).
    """
    ik = getattr(vip, "ikram", None)
    if ik is None:
        finish(vip, [
            "✗ Ikram core not loaded",
            "Run the tool through run.sh / ikram_patch.py.",
        ], ok=False)
        return None
    if not hasattr(ik, "pause"):
        # A stub without the compiled UI surface would crash every delegated
        # handler. Treat it exactly like a missing core.
        finish(vip, [
            "✗ Ikram core is incomplete",
            "Reinstall the tool (compiled core is missing).",
        ], ok=False)
        return None
    return ik


def _call(vip, ik, method):
    """Call a compiled handler with a clean error box if it is missing.

    Delegated operations render their own result + pause; this helper never
    adds a second one.
    """
    fn = getattr(ik, method, None)
    if not callable(fn):
        finish(vip, [
            "✗ Operation unavailable",
            "Core is missing %s(). Reinstall the tool." % method,
        ], ok=False)
        return False
    try:
        fn()
    except Exception as exc:
        finish(vip, ["✗ Operation failed", str(exc)[:100]], ok=False)
    return True


def finish(vip, rows, ok=True, warn=False, pause=True):
    """ONE result box + ONE continue for every menus.py-owned operation.

    ``success_box``/``error_box``/``warn_box`` also set ``vip._last_outcome``
    which the main-menu "Last:" line reads. Callers must NOT add a second
    ``wait_enter()``/``pause()`` — that was the double-continue bug.
    """
    rows = [str(r) for r in rows]
    try:
        if warn:
            vip.warn_box(rows)
        elif ok:
            vip.success_box(rows)
        else:
            vip.error_box(rows)
    except Exception:
        # A shell without these primitives must still get a readable result,
        # never a blank screen or a raw traceback.
        try:
            vip.write("\n".join(rows) + "\n")
        except Exception:
            pass
        try:
            vip._last_outcome = "WARN" if warn else ("SUCCESS" if ok else "ERROR")
        except Exception:
            pass
    if pause:
        try:
            vip.wait_enter()
        except Exception:
            pass
    return ok and not warn


def finish_paged(vip, rows, title="RESULT", ok=True, warn=False,
                 page_lines=8, dump_name=None, pause=True):
    """One bounded, paged result panel + the same single continue as finish().
    Falls back to head/tail `finish()` when the shell has no pager so a long
    list can never spill outside a box."""
    rows = [str(r) for r in rows]
    pager = getattr(vip, "result_panel", None)
    if callable(pager):
        try:
            pager(rows, title=title, summary=[], ok=(ok and not warn),
                  page_lines=page_lines, dump_name=dump_name)
            if warn:
                try:
                    vip._last_outcome = "WARN"
                except Exception:
                    pass
            if pause:
                vip.wait_enter()
            return ok and not warn
        except Exception:
            pass
    head = rows[:3]
    if len(rows) > 6:
        head += ["... +%d more" % (len(rows) - 6)] + rows[-3:]
    else:
        head = rows
    return finish(vip, head, ok=ok, warn=warn, pause=pause)


def reset_runtime_state(vip=None):
    """Clear any per-loop state. menus.py is deliberately stateless, but the
    shell's remembered outcome must not leak into the next operation."""
    if vip is not None:
        try:
            vip._last_outcome = None
        except Exception:
            pass
        try:
            vip.ikram._EOF = False
        except Exception:
            pass


def _counts(targets, bounded=False):
    """Counts for a CLEAN action. Returns (total, rows, known).

    Confirm/result counts use a bounded scandir on a cold cache. The scan is
    capped, so a GB tree never blocks the UI; small folders keep their real
    count and bytes in the result box after purge invalidates the cache.
    """
    rows = []
    total = 0
    known = True
    for t in targets:
        n, b = paths.cached_count_dir(t)
        if n is None and bounded:
            qn, qb, exact = paths.count_dir_bounded(t, CLEAN_BOUNDED_FILES)
            if exact:
                n, b = qn, qb
                paths.remember_count(t, n, b)
            else:
                ln, lb = paths.last_count_dir(t)
                if ln is not None:
                    n, b = ln, lb
        if n is None:
            n, b = 0, 0
            known = False
        n = int(n)
        b = int(b or 0)
        total += n
        rows.append([paths.folder_label(t), n, b])
    return total, rows, known


# ================================================================== PAK
# Delegated: the patched/compiled handler renders its own result panel and
# calls ikram.pause() once. We intentionally add NO extra pause/box here.
def pak_unpack(vip):
    ik = _ikram(vip)
    if ik is not None:
        _call(vip, ik, "pak_extract")


def pak_inject(vip):
    ik = _ikram(vip)
    if ik is not None:
        _call(vip, ik, "pak_inject")


def pak_repack(vip):
    ik = _ikram(vip)
    if ik is not None:
        _call(vip, ik, "pak_repack_folder")


def pak_custom(vip):
    ik = _ikram(vip)
    if ik is not None:
        _call(vip, ik, "pak_costom_pak")


# ================================================================== LUA
def lua_compile(vip):
    ik = _ikram(vip)
    if ik is not None:
        _call(vip, ik, "lua_compile_one")


def lua_decompile(vip):
    ik = _ikram(vip)
    if ik is not None:
        _call(vip, ik, "lua_decompile_one")


# ============================================================ clear utils
def _clear(vip, targets, title, label):
    """Count -> confirm -> purge -> recount -> ONE batch result box -> continue.

    Cancel/EOF/back never leaves a blank screen: confirm_box() treats an empty
    answer as "no" and returns to the caller, which redisplays the menu.
    """
    targets = [Path(t) for t in targets]
    before, per_before, known_before = _counts(targets, bounded=True)
    if known_before and before == 0:
        finish(vip, [
            "✓ Nothing to clear",
            "  %s" % " + ".join(paths.folder_label(t) for t in targets),
        ], warn=True)
        return
    main = paths.folder_label(targets[0])
    if len(targets) > 1:
        main = paths.folder_label(targets[0].parent)
    confirm = getattr(vip, "confirm_context_box", None)
    if callable(confirm):
        # main already names the folder in the top border. A label that repeats
        # the same path is the second copy the CLEAN screen used to show.
        short_label = ("Delete all files here?"
                       if main.lower() in str(label).lower() else label)
        ok = confirm(main, paths.affected_files(targets), title=title,
                     label=short_label)
    else:
        ok = vip.confirm_box(title, label)
    if not ok:
        mark_outcome(vip, "CANCEL")
        return  # cancelled — no box, no pause, straight back to the menu
    # The confirmation prompt leaves the cursor on its marker row. A visible
    # WORKING box immediately after Y proves the purge started; a large tree
    # no longer looks frozen while scandir/rmtree do their bounded work.
    try:
        vip.working_box([
            "Removing files from:",
            "  %s" % " + ".join(paths.folder_label(t) for t in targets),
        ])
    except Exception:
        try:
            vip.info_box(["Working..."])
        except Exception:
            pass
    failures = []
    for t in targets:
        try:
            failures.extend(paths.purge(t))
        except Exception as exc:
            failures.append("%s (%s)" % (t, str(exc)[:48]))
    after, per_after, known_after = _counts(targets, bounded=True)
    if not known_after:
        after = 0
    cleared = max(0, before - after)
    if known_before:
        before_bytes = sum(int(r[2]) for r in per_before)
        rows = ["✓ Cleared %d of %d file(s)  ·  %s"
                % (cleared, before, paths.human(before_bytes)),
                "  %s" % " + ".join(paths.folder_label(t) for t in targets)]
    else:
        rows = ["✓ Clear finished",
                "  %s" % " + ".join(paths.folder_label(t) for t in targets)]
    # Per-folder breakdown only uses counts we actually have. A fresh purge
    # invalidates the cache, so an immediate recount is expected to be pending.
    if len(targets) > 1 and known_before and known_after:
        for (name, n, _b), (_n2, n2, b2) in zip(per_before, per_after):
            rows.append("    %-24s %d left  ·  %s"
                        % (name, n2, paths.human(b2)))
    if failures:
        rows.append("✗ %d item(s) could not be removed" % len(failures))
        for f in failures[:6]:
            rows.append("    " + f[:96])
    elif known_after and after:
        rows.append("  %d file(s) could not be removed" % after)
    ok = not failures and (cleared > 0 if known_before else True)
    finish(vip, rows, ok=ok, warn=not ok)


def clear_drop_pak(vip):
    _clear(vip, [paths.DROP_PAK], "CLEAR DROP FOLDER",
           "Delete all files from DROP/pak/?")


def clear_drop_lua(vip):
    _clear(vip, [paths.DROP_LUA], "CLEAR DROP FOLDER",
           "Delete all files from DROP/lua/?")


def clear_drop_inject(vip):
    _clear(vip, [paths.DROP_INJ], "CLEAR DROP FOLDER",
           "Delete all files from DROP/inject/?")


def clear_drop_savegames(vip):
    _clear(vip, [paths.DROP_SAVEGAMES], "CLEAR DROP FOLDER",
           "Delete all files from DROP/SaveGames/?")


def clear_result(vip):
    _clear(vip, [paths.RESULT_EXTRACTED, paths.RESULT_INJECTED,
                 paths.RESULT_LUA, paths.RESULT_PROCESSED,
                 paths.RESULT_CUSTOMPAK, paths.RESULT_REPACKED,
                 paths.RESULT_SAVEGAMES],
           "CLEAR RESULT FOLDER", "Delete everything from RESULT/?")


def clear_result_extracted(vip):
    _clear(vip, [paths.RESULT_EXTRACTED], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/extracted/?")


def clear_result_injected(vip):
    _clear(vip, [paths.RESULT_INJECTED], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/injected/?")


def clear_result_lua(vip):
    _clear(vip, [paths.RESULT_LUA], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/lua/?")


def clear_result_processed(vip):
    _clear(vip, [paths.RESULT_PROCESSED], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/processed/?")


def clear_result_custompak(vip):
    _clear(vip, [paths.RESULT_CUSTOMPAK], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/CostomPak/?")


def clear_result_repacked(vip):
    _clear(vip, [paths.RESULT_REPACKED], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/Repacked/?")


def clear_result_savegames(vip):
    _clear(vip, [paths.RESULT_SAVEGAMES], "CLEAR RESULT FOLDER",
           "Delete everything from RESULT/SaveGames/?")


_DROP_TARGETS = (paths.DROP_PAK, paths.DROP_LUA, paths.DROP_INJ,
                 paths.DROP_SAVEGAMES)


def clear_all_drop(vip):
    _clear(vip, list(_DROP_TARGETS), "CLEAR ALL DROP FOLDERS",
           "Delete every file from all DROP folders?")


# ============================================================ CLEAN menu loop
def _draw_clean(vip):
    """Render CLEAN rows once. Returns (plain_rows, counts_pending)."""
    rows = []
    text_rows = []
    pending = False
    for k, lab, _help, t in menu_entries(CATEGORY_CLEAN):
        if t == "back":
            rows.append((k, lab, []))
            text_rows.append("%s  %s" % (k, lab))
            continue
        files, size, known, row_pending = _clean_stats_values(t)
        pending = pending or row_pending
        plain = _clean_stats_text_values(files, size, known)
        rows.append((k, lab, [_clean_stat_line_values(vip, files, size, known)]))
        text_rows.append("%s  %s  %s" % (k, lab, plain))
    try:
        vip.cls()
        vip.write(vip.box.draw_menu(rows, title=menu_title(CATEGORY_CLEAN),
                                    subtitle="PICK A FOLDER") + "\n")
    except Exception:
        vip.write("CLEAN\n" + "\n".join(text_rows) + "\n")
    return text_rows, pending


def run_clean(vip):
    """Self-contained CLEAN category. Renders from MENU_SPECS, validates input,
    supports 0/Esc/EOF back, and leaves no stale state between passes."""
    handlers = {
        "clear_drop_pak": clear_drop_pak,
        "clear_drop_lua": clear_drop_lua,
        "clear_drop_inject": clear_drop_inject,
        "clear_drop_savegames": clear_drop_savegames,
        "clear_all_drop": clear_all_drop,
        "clear_result": clear_result,
        "clear_result_extracted": clear_result_extracted,
        "clear_result_injected": clear_result_injected,
        "clear_result_lua": clear_result_lua,
        "clear_result_processed": clear_result_processed,
        "clear_result_custompak": clear_result_custompak,
        "clear_result_repacked": clear_result_repacked,
        "clear_result_savegames": clear_result_savegames,
    }
    choices = menu_choices(CATEGORY_CLEAN)
    reset_runtime_state(vip)
    while True:
        text_rows = []
        last_rows = None
        for attempt in range(16):
            text_rows, pending = _draw_clean(vip)
            if not pending:
                break
            if attempt and text_rows == last_rows:
                break
            last_rows = text_rows
            time.sleep(0.05)
        try:
            got = normalize_choice(vip.prompt_in(
                choices, glyph("arrow") + " SELECT:",
                main=menu_choice_title(CATEGORY_CLEAN)))
        except Exception:
            mark_outcome(vip, "CANCEL")
            return
        if not got or got == BACK_KEY:
            mark_outcome(vip, "CANCEL")
            return
        target = next((t for k, _l, _h, t in menu_entries(CATEGORY_CLEAN)
                       if k == got), None)
        fn = handlers.get(target)
        if fn is None:
            try:
                vip.invalid_box(got)
            except Exception:
                pass
            continue
        fn(vip)


# ========================================================= SAVEGAMES / THEMES
def savegames_run(vip):
    """Delegate to the SAVEGAMES engine (savegames.run owns its result boxes)."""
    try:
        import savegames
        savegames.run(vip)
    except Exception as exc:
        finish(vip, ["✗ SAVEGAMES could not start", str(exc)[:80]], ok=False)


def themes_open(vip):
    """Open the shell theme switcher (it owns its own screen + continue)."""
    fn = getattr(vip, "run_themes", None)
    if callable(fn):
        fn()
        return
    try:
        from theme_engine import THEMES
        finish(vip, ["🎨 Themes: " + ", ".join(THEMES),
                     "Theme switcher is not available in this shell."], warn=True)
    except Exception:
        finish(vip, ["🎨 Theme switcher is not available in this shell."], warn=True)


def dispatch(vip, category, raw_choice):
    """Optional single-entry dispatcher for shells that want one route table.

    Returns one of "OK", "BACK", "INVALID", "EXIT". Handlers own their own
    result/continue; this function never adds one.
    """
    key = normalize_choice(raw_choice)
    choices = menu_choices(category)
    if not key:
        return "BACK"  # EOF / blank = graceful exit, no loop spinning
    if key not in choices:
        try:
            vip.invalid_box(key)
        except Exception:
            pass
        return "INVALID"
    target = next((t for k, _l, _h, t in menu_entries(category) if k == key), None)
    if target in (None, "back"):
        return "BACK"
    if target == "exit":
        return "EXIT"
    _LOCAL = {
        "pak_unpack": pak_unpack, "pak_inject": pak_inject,
        "pak_repack": pak_repack, "pak_custom": pak_custom,
        "lua_compile": lua_compile, "lua_decompile": lua_decompile,
        "clear_drop_pak": clear_drop_pak, "clear_drop_lua": clear_drop_lua,
        "clear_drop_inject": clear_drop_inject,
        "clear_drop_savegames": clear_drop_savegames,
        "clear_all_drop": clear_all_drop, "clear_result": clear_result,
        "clear_result_extracted": clear_result_extracted,
        "clear_result_injected": clear_result_injected,
        "clear_result_lua": clear_result_lua,
        "clear_result_processed": clear_result_processed,
        "clear_result_custompak": clear_result_custompak,
        "clear_result_repacked": clear_result_repacked,
        "clear_result_savegames": clear_result_savegames,
        "savegames_encrypt": savegames_run, "savegames_decrypt": savegames_run,
        "savegames_process_all": savegames_run,
        "run_clean": run_clean,
    }
    fn = _LOCAL.get(target)
    if fn is None:
        fn = getattr(vip, target, None)
    if callable(fn):
        fn(vip) if fn in _LOCAL.values() else fn()
        return "OK"
    finish(vip, ["✗ Action unavailable: %s" % target], ok=False)
    return "INVALID"
