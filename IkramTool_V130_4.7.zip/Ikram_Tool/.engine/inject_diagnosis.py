"""Read-only audit for the real Pak Inject result flow.

This module never writes a file, never changes an edit, never prints a panel,
and never calls pause(). The inject wizard owns the only result panel and the
only continue. The audit is computed after the writer has returned, then
consumed without adding rows to the visible panel.

The verdict is evidence-only. It says which tool-visible artifact needs
review. It cannot observe the game server's real enforcement reason.
"""

from __future__ import annotations

import hashlib
import os
import struct

_HASH_CHUNK = 1 << 20
_EMPTY_SHA1 = hashlib.sha1(b"").digest()
_ZERO_SHA1 = b"\x00" * 20

_LUA_MAGIC = b"\x1bLua"
_LUAJIT_MAGIC = b"\x1bLJ"
_IKRM_MAGIC = b"IKRM"
_IKRM_MIN_SIZE = 73
_IKRM_VERSION = 1

_SUPPORTED_CM = (0, 1, 6)
_SUPPORTED_EM = (0, 1, 2, 4, 16, 17, *range(31, 56))
_MAX_ROWS = 8
_MAX_REASONS = 6

_META_FIELDS = (
    "uncompressed_size",
    "compression_method",
    "encryption_method",
    "compression_block_size",
    "index_new_sep",
    "unk1",
    "unk2",
)
_FOOTER_INFO_FIELDS = (
    "magic",
    "stem_hash",
    "content_org_hash",
    "unk1",
    "unk2",
    "index_encrypted",
)

_STATE = None


# ---------------------------------------------------------------- state
def begin():
    """Open a fresh one-shot diagnosis window for one Pak Inject run."""
    global _STATE
    _STATE = {
        "active": True,
        "labels": [],
        "context": None,
        "pak": None,
        "write": None,
    }


def active() -> bool:
    return bool(_STATE and _STATE.get("active"))


def end():
    """Close the diagnosis window without producing rows."""
    global _STATE
    _STATE = None


def record_working_file(path, label, data=None) -> None:
    """Record the label chosen by compiled _inject_working_bytes.

    Order is preserved. The wizard builds its edit list from the same ordered
    list, so index N here belongs to edit N in set_context().
    """
    if not active():
        return
    try:
        raw = bytes(data or b"")
    except Exception:
        raw = b""
    _STATE["labels"].append({
        "path": str(path),
        "label": str(label or "raw"),
        "size": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest()[:8],
    })


def set_branch(name) -> None:
    """Record which writer branch actually ran."""
    if not active() or not _STATE.get("context"):
        return
    _STATE["context"]["branch"] = str(name or "unknown")


def set_context(pakf, edits, source_paths=None) -> None:
    """Capture the selected pak and the exact payload list before writing."""
    if not active():
        return
    labels = list(_STATE.get("labels") or ())
    norm = []
    for i, item in enumerate(edits or ()):
        try:
            raw_target = item[0]
            body = item[1]
        except Exception:
            continue
        if isinstance(body, (tuple, list)):
            data = body[0] if body else b""
        else:
            data = body
        try:
            payload = bytes(data or b"")
        except Exception:
            payload = b""
        path = _norm_path(raw_target)
        label = labels[i]["label"] if i < len(labels) else _infer_label(payload)
        norm.append({
            "path": path,
            "raw_path": str(raw_target),
            "data": payload,
            "label": label,
        })
    _STATE["context"] = {
        "pakf": str(pakf),
        "edits": norm,
        "source_paths": {_norm_path(p) for p in (source_paths or ())},
        "branch": "unknown",
    }


def on_writer_result(src_path, output_path, writer_edits, mod, result,
                     target_path=None, force_add=False) -> None:
    """Read the written pak after the writer returns. Never raises."""
    if not active() or not _STATE.get("context"):
        return
    context = _STATE["context"]
    _STATE["write"] = {
        "src_path": str(src_path or ""),
        "output_path": str(output_path or ""),
        "writer_edits": len(list(writer_edits or ())),
        "target_path": str(target_path or ""),
        "force_add": bool(force_add),
        "result": result,
    }
    try:
        _STATE["pak"] = _audit_pak(
            str(src_path or ""), str(output_path or ""), context, mod)
    except Exception as exc:
        _STATE["pak"] = (True, ["audit exception: %s" % _short(exc)])


def finish():
    """Consume the state and return rows for the existing success panel."""
    global _STATE
    if not active():
        return []
    rows = _build_rows(_STATE)
    _STATE = None
    return rows


# ---------------------------------------------------------------- helpers
def _short(value) -> str:
    text = str(value).replace("\r", " ").replace("\n", " ")
    return text[:120]


def _norm_path(value) -> str:
    text = str(value or "").replace("\\", "/").strip()
    while text.startswith("./"):
        text = text[2:]
    return text.lstrip("/").lower()


def _infer_label(data: bytes) -> str:
    if not data:
        return "empty source"
    if data.startswith(_LUA_MAGIC) or data.startswith(_LUAJIT_MAGIC):
        return "bytecode"
    try:
        import lua_pipeline as lp
        report = lp.detect_report(data)
        if report.get("family") == "Lua source":
            return "source"
    except Exception:
        pass
    return "raw"


def _sha_range(path: str, offset: int, size: int) -> bytes:
    digest = hashlib.sha1()
    left = max(0, int(size))
    with open(path, "rb") as stream:
        stream.seek(max(0, int(offset)))
        while left > 0:
            chunk = stream.read(min(_HASH_CHUNK, left))
            if not chunk:
                break
            digest.update(chunk)
            left -= len(chunk)
    return digest.digest()


def _read_range(path: str, offset: int, size: int) -> bytes:
    left = max(0, int(size))
    with open(path, "rb") as stream:
        stream.seek(max(0, int(offset)))
        return stream.read(left)


def _footer_size(info):
    fn = getattr(info, "footer_size", None)
    return int(fn() if callable(fn) else getattr(info, "footer_size", 0))


def _entries(reader):
    ordered = []
    by_path = {}
    for directory, items in reader.dirs.items():
        for name, entry in items.items():
            path = _norm_path(str(directory) + str(name))
            ordered.append(path)
            by_path[path] = entry
    return ordered, by_path


def _field(entry, name, default=None):
    return getattr(entry, name, default)


def _bytes_field(value) -> bytes:
    try:
        return bytes(value or b"")
    except Exception:
        return b""


def _stored_sha_ok(expected, stored: bytes, size: int) -> bool:
    expected = _bytes_field(expected)
    if int(size) == 0 and expected in (_EMPTY_SHA1, _ZERO_SHA1):
        return True
    return stored == expected


def _same_field(left, right) -> bool:
    if isinstance(left, (bytes, bytearray)) or isinstance(right, (bytes, bytearray)):
        return _bytes_field(left) == _bytes_field(right)
    return left == right


def _expected_footer_tail(info, index_hash, index_size, index_offset):
    ks = getattr(info, "_keystream", None)
    if ks is None or len(ks) < 12:
        raise ValueError("footer keystream unavailable")
    tail = bytearray(45)
    tail[0] = (1 if info.index_encrypted else 0) ^ (int(ks[3]) & 0xFF)
    struct.pack_into("<I", tail, 1, int(info.magic) ^ int(ks[2]))
    struct.pack_into("<I", tail, 5, int(getattr(info, "version", 14)))
    raw_hash = _bytes_field(index_hash) + bytes(20 - len(_bytes_field(index_hash)))
    tail[9:29] = bytes(
        a ^ b for a, b in zip(raw_hash, struct.pack("<5I", *[int(x) for x in ks[4:9]])))
    struct.pack_into("<Q", tail, 29,
                     int(index_size) ^ ((int(ks[10]) << 32) | int(ks[11])))
    struct.pack_into("<Q", tail, 37,
                     int(index_offset) ^ ((int(ks[0]) << 32) | int(ks[1])))
    return bytes(tail)


def _path_risk(path: str) -> str:
    parts = [p for p in path.split("/") if p]
    if not parts:
        return "empty"
    if any(p == ".." for p in parts):
        return "traversal"
    if any(("\\" in p) or (":" in p) for p in parts):
        return "foreign"
    return "new"


# ---------------------------------------------------------------- Lua side
def _detect_report_safe(data: bytes) -> dict:
    try:
        import lua_pipeline as lp
        return dict(lp.detect_report(data) or {})
    except Exception:
        return {}


def _dialect_safe(data: bytes):
    try:
        import mega_lua as ml
        return ml._detect_dialect(data)
    except Exception:
        return None


def _bgmi_safe(data: bytes) -> bool:
    try:
        import mega_lua as ml
        return bool(ml._is_bgmi(data))
    except Exception:
        return False


def _loads_safe(data: bytes, label: str) -> bool:
    if label in ("source", "empty source"):
        return False
    try:
        import mega_lua as ml
        return bool(ml._loads_ok(data))
    except Exception:
        return False


def _source_ok(data: bytes) -> bool:
    try:
        import lua_pipeline as lp
        text = data.decode("utf-8", errors="replace")
        return bool(lp.validate_source(text).get("ok"))
    except Exception:
        return False


def _register_cap(data: bytes, bgmi: bool) -> int:
    if not bgmi:
        return 0
    try:
        import mega_lua as ml
        stats = ml._proto_stats(data) or {}
        return int(stats.get("max") or 0)
    except Exception:
        return 0


def _lua_evidence(context):
    reasons = []
    lines = []
    edits = list(context.get("edits") or ())
    source_paths = set(context.get("source_paths") or ())
    if not edits:
        return True, ["no Lua payload was captured"]

    for edit in edits:
        path = edit["path"]
        data = edit["data"]
        label = edit["label"]
        report = _detect_report_safe(data)
        dialect = _dialect_safe(data)
        bgmi = _bgmi_safe(data)
        loads = _loads_safe(data, label)
        entropy = float(report.get("entropy") or 0.0)
        band = str(report.get("band") or "unknown")
        if label in ("source", "empty source"):
            band = "source"
        protection = str(report.get("protection") or "")
        wrapper = int(report.get("wrapper") or 0)
        wrap = len(data) >= _IKRM_MIN_SIZE and data[:4] == _IKRM_MAGIC \
            and data[4] == _IKRM_VERSION
        known_path = path in source_paths
        path_state = "existing" if known_path else _path_risk(path)
        family = "unknown"
        if label == "bytecode":
            family = str(dialect or report.get("family") or "unknown")
        elif label in ("source", "empty source"):
            family = "unknown"

        local = []
        if label == "source":
            local.append("readable source passed through")
            if not _source_ok(data):
                local.append("source luac rejected")
        elif label == "empty source":
            local.append("empty source")
        elif wrap:
            local.append("IKRM wrapper")
        elif protection in ("ikrm", "encrypted", "obfuscated", "modified-version"):
            local.append("%s wrapper" % protection)
        elif wrapper:
            local.append("%dB wrapper" % wrapper)
        if label in ("bytecode", "raw") and not loads:
            local.append("load probe failed")
        if label == "bytecode" and dialect not in ("lua53", "lua54"):
            local.append("dialect=%s" % (dialect or "unknown"))
        if label == "bytecode" and dialect in ("lua53", "lua54") and not bgmi:
            local.append("BGMI format not proven")
        regs = _register_cap(data, bgmi) if label not in ("source", "empty source") else 0
        if regs > 255:
            local.append("regs=%d" % regs)
        if not known_path:
            local.append("path=%s" % path_state)
        if local:
            reasons.extend(local)

        head = local[0] if local else ("bytecode load probe passed" if loads else "payload accepted")
        lines.append(
            "%s[%dB sha=%s] %s; family=%s; entropy=%.2f/%s; "
            "load probe=%s; path=%s" % (
                path or "?", len(data), hashlib.sha256(data).hexdigest()[:8],
                head, family, entropy, band,
                "PASS" if loads else "FAIL", path_state,
            )
        )

    if len(lines) > _MAX_ROWS:
        lines = lines[:_MAX_ROWS] + ["+%d more file(s)" % (len(lines) - _MAX_ROWS)]
    return bool(reasons), lines


# ---------------------------------------------------------------- PAK side
def _audit_pak(src_path: str, out_path: str, context, mod):
    reasons = []
    if not src_path or not os.path.isfile(src_path):
        return True, ["write source missing"]
    if not out_path or not os.path.isfile(out_path):
        return True, ["output pak missing"]
    if mod is None or not hasattr(mod, "PakReader"):
        return True, ["pak reader unavailable"]

    src_size = os.path.getsize(src_path)
    out_size = os.path.getsize(out_path)
    edits = list(context.get("edits") or ())
    targets = {e["path"]: e["data"] for e in edits}

    with mod.PakReader(src_path) as src, mod.PakReader(out_path) as out:
        s_info, o_info = src.info, out.info
        s_order, s_map = _entries(src)
        o_order, o_map = _entries(out)

        if str(getattr(src, "mount_point", "") or "") != \
                str(getattr(out, "mount_point", "") or ""):
            reasons.append("mount changed")
        if int(getattr(s_info, "version", 0)) != int(getattr(o_info, "version", 0)):
            reasons.append("version changed")
        source_set = set(s_order)
        source_order = [path for path in o_order if path in source_set]
        if source_order != s_order:
            reasons.append("entry order changed")
        write_state = _STATE.get("write") or {}
        if isinstance(write_state, dict) and write_state.get("result") is not None:
            try:
                result = int(write_state.get("result"))
            except (TypeError, ValueError):
                reasons.append("result count invalid")
            else:
                if result != len(o_map):
                    reasons.append("result count %d != %d" % (result, len(o_map)))

        s_fsz = _footer_size(s_info)
        o_fsz = _footer_size(o_info)
        if s_fsz < 46 or o_fsz < 46:
            reasons.append("footer size")
        else:
            s_mem = _sha_range(src_path, src_size - s_fsz, s_fsz - 45)
            o_mem = _sha_range(out_path, out_size - o_fsz, o_fsz - 45)
            if s_mem != o_mem:
                reasons.append("footer memory block")
            for field in _FOOTER_INFO_FIELDS:
                if not _same_field(_field(s_info, field), _field(o_info, field)):
                    reasons.append("footer %s" % field)

            o_tail = _read_range(out_path, out_size - 45, 45)
            try:
                tail = _expected_footer_tail(
                    o_info, o_info.index_hash, o_info.index_size,
                    o_info.index_offset)
                if o_tail != tail:
                    reasons.append("footer tail")
            except Exception as exc:
                reasons.append("footer tail (%s)" % _short(exc))

        if out_size != int(o_info.index_offset) + int(o_info.index_size) + o_fsz:
            reasons.append("file size")
        if int(o_info.index_offset) % 16:
            reasons.append("index alignment")

        try:
            raw_index = _read_range(
                out_path, int(o_info.index_offset), int(o_info.index_size))
            plain = mod.pc.decrypt_index(raw_index, o_info)
            if hashlib.sha1(plain).digest() != _bytes_field(o_info.index_hash):
                reasons.append("index SHA1")
        except Exception as exc:
            reasons.append("index SHA1 (%s)" % _short(exc))

        for path, old in s_map.items():
            new = o_map.get(path)
            if new is None:
                reasons.append("missing %s" % path)
                continue
            old_off, old_size = int(_field(old, "offset", 0)), int(_field(old, "size", 0))
            new_off, new_size = int(_field(new, "offset", 0)), int(_field(new, "size", 0))
            if path in targets:
                continue
            for field in _META_FIELDS:
                if not _same_field(_field(old, field), _field(new, field)):
                    reasons.append("%s %s" % (path, field))
            if old_size != new_size:
                reasons.append("%s size" % path)
            old_hash = _sha_range(src_path, old_off, old_size)
            new_hash = _sha_range(out_path, new_off, new_size)
            if old_hash != new_hash:
                reasons.append("%s body" % path)
            if not _stored_sha_ok(_field(new, "content_hash"), new_hash, new_size):
                reasons.append("%s entry SHA1" % path)
            delta = new_off - old_off
            old_blocks = list(_field(old, "compressed_blocks") or ())
            new_blocks = list(_field(new, "compressed_blocks") or ())
            if len(old_blocks) != len(new_blocks):
                reasons.append("%s blocks" % path)
            else:
                for a, b in zip(old_blocks, new_blocks):
                    if (int(_field(b, "start", 0)) - int(_field(a, "start", 0)) != delta
                            or int(_field(b, "end", 0)) - int(_field(a, "end", 0)) != delta):
                        reasons.append("%s block window" % path)
                        break

        for path, payload in targets.items():
            entry = o_map.get(path)
            if entry is None:
                reasons.append("target missing %s" % path)
                continue
            size = int(_field(entry, "size", 0))
            stored_hash = _sha_range(out_path, int(_field(entry, "offset", 0)), size)
            if not _stored_sha_ok(_field(entry, "content_hash"), stored_hash, size):
                reasons.append("%s entry SHA1" % path)
            try:
                readback = bytes(out.read_entry(entry) or b"")
            except Exception as exc:
                readback = None
                reasons.append("%s readback (%s)" % (path, _short(exc)))
            if readback is not None:
                if hashlib.sha1(readback).digest() != hashlib.sha1(payload).digest():
                    reasons.append("%s readback" % path)
                if int(_field(entry, "uncompressed_size", -1)) != len(payload):
                    reasons.append("%s usize" % path)
                md = hashlib.md5(payload).digest()
                want_unk2 = md + md[4:8]
                if _bytes_field(_field(entry, "unk2")) != want_unk2:
                    reasons.append("%s unk2" % path)
            cm = int(_field(entry, "compression_method", -1))
            em = int(_field(entry, "encryption_method", -1))
            sep = int(_field(entry, "index_new_sep", -1))
            cbs = int(_field(entry, "compression_block_size", -1))
            if cm not in _SUPPORTED_CM or em not in _SUPPORTED_EM:
                reasons.append("%s cm/em" % path)
            if sep != 0xFFFFFFFF:
                reasons.append("%s sep" % path)
            if payload and cm == 0 and cbs:
                reasons.append("%s cbs" % path)
            if payload and cm in (1, 6) and cbs != min(65536, len(payload)):
                reasons.append("%s cbs" % path)
            if not payload and (cm or em or size or cbs):
                reasons.append("%s empty metadata" % path)

    if _path_risk(context["pakf"]) == "traversal":
        reasons.append("source path traversal")
    if reasons:
        return True, reasons[:_MAX_REASONS]
    return False, []


# ---------------------------------------------------------------- rows
def _build_rows(state):
    if not state.get("pak"):
        return [
            "Read-only audit:",
            "PAK container: FAIL - writer did not report a completed pak",
            "Verdict      : PAK STRUCTURE needs review first.",
        ]
    context = state.get("context") or {}
    pak_risk, pak_reasons = state["pak"]
    lua_risk, lua_lines = _lua_evidence(context)
    write = state.get("write") or {}

    pak_line = "PASS - bytes, footer, index SHA1, entry SHA1, readback OK"
    if pak_risk:
        pak_line = "FAIL - " + "; ".join(pak_reasons)

    lua_line = ""
    if lua_risk:
        lua_line = "HIGH RISK - " + "; ".join(lua_lines)
    else:
        lua_line = "OK - " + "; ".join(lua_lines)

    if pak_risk:
        verdict = "PAK STRUCTURE needs review first."
    elif lua_risk:
        verdict = "LUA PAYLOAD is the only tool-visible risk. PAK structure is excluded."
    else:
        verdict = "INCONCLUSIVE from the tool. No file-level fault found."

    branch = str(context.get("branch") or write.get("src_path") or "unknown")
    return [
        "Read-only audit:",
        "Writer path  : %s" % branch,
        "PAK container: %s" % pak_line,
        "Lua payload  : %s" % lua_line,
        "Verdict      : %s" % verdict,
    ]
