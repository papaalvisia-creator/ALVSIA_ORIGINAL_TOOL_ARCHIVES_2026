"""IkramTool V130 — startup system (PREMIUM Area 1).

Everything between a valid key and the first main menu lives here:

  * boot — the silent deep gate. It runs `preflight.check()`, which inspects
    every engine, the crypto layer, the Lua toolchain, the working trees and
    the key file. If anything essential is missing it hands the report to
    `installer.run()`, which installs the missing pieces and re-checks. Then
    boot returns True; the caller paints the splash and opens the menu.
  * quick_deps — a cheap stat-only probe kept for callers that must not import
    the heavy Lua pipeline (it mirrors a subset of preflight without the
    imports).
  * last_action — a tiny JSON record inside .engine/ remembering what the user
    last did, surfaced on the main menu.

Every entry point is non-raising: a fault in startup must never stop the tool
from reaching its menu. This module only reads tool state; it never touches
DROP/RESULT contents.
"""
import json
import time
from pathlib import Path

import ikram_logger
import paths
import preflight
from theme_engine import glyph

BRAND = "IkramTool"
LAST_ACTION_NAME = "last_action.json"


def _tool_dir() -> Path:
    return Path(__file__).resolve().parent


def last_action_path() -> Path:
    # The record lives INSIDE the engine (.engine/last_action.json), not at the
    # tool root. Keeping it here means the install leaves exactly three folders
    # behind (.engine, DROP, RESULT) and nothing else at the top level.
    return Path(paths.ENGINE_DIR) / LAST_ACTION_NAME


# --------------------------------------------------------------- last action
def _ago(ts) -> str:
    try:
        delta = time.time() - float(ts)
    except Exception:
        return "unknown"
    if delta < 0:
        return "just now"
    if delta < 45:
        return "just now"
    if delta < 3600:
        return "%dm ago" % int(delta // 60)
    if delta < 86400:
        return "%dh ago" % int(delta // 3600)
    return "%dd ago" % int(delta // 86400)


def read_last():
    """The stored last-action record, or None when absent/unreadable."""
    try:
        p = last_action_path()
        if p.is_file():
            data = json.loads(p.read_text(errors="ignore"))
            if isinstance(data, dict) and data.get("kind"):
                return data
    except Exception as _ikram_exc:
        ikram_logger.log_exc("startup.read_last:83", _ikram_exc)
    return None


def write_last(kind, summary, ok) -> None:
    """Record the last action. Best-effort: a failure here is cosmetic only."""
    try:
        data = {
            "kind": str(kind),
            "summary": str(summary),
            "ok": bool(ok),
            "ts": time.time(),
            "version": paths.read_version(),
        }
        last_action_path().write_text(json.dumps(data, indent=1))
    except Exception as _ikram_exc:
        ikram_logger.log_exc("startup.write_last:96", _ikram_exc)


def remember(kind, before_n, before_b, after_n, after_b, outcome) -> None:
    """Derive a human summary for a finished menu action.

    Counts are optional. Interactive callers pass None and skip the recursive
    RESULT walk; explicit callers can still pass before/after counts.
    """
    have_counts = before_n is not None and after_n is not None
    if have_counts:
        try:
            dn = int(after_n) - int(before_n)
        except Exception:
            have_counts = False
            dn = 0
    else:
        dn = 0
    if outcome == "ERROR":
        ok, summary = False, "stopped with an error"
    elif outcome == "CANCEL":
        ok, summary = True, "cancelled"
    elif outcome == "WARN":
        ok, summary = True, "finished with a warning"
    elif have_counts and dn > 0:
        ok, summary = True, "%d new file(s)" % dn
    elif have_counts and dn < 0:
        ok, summary = True, "%d file(s) removed" % (-dn)
    elif outcome is None and have_counts:
        ok, summary = True, "no files changed"
    else:
        ok, summary = True, "done"
    write_last(kind, summary, ok)


def last_action_line(theme):
    """One themed line for the main menu, or None when nothing is stored."""
    data = read_last()
    if not data:
        return None
    ok = bool(data.get("ok"))
    icon = glyph("ok") if ok else glyph("fail")
    role = "success" if ok else "error"
    text = "%s %s — %s  (%s)" % (icon, data.get("kind", "action"),
                                 data.get("summary", "done"),
                                 _ago(data.get("ts")))
    return (theme.apply("Last ", "text")
            + theme.apply(": ", "dim")
            + theme.apply(text, role))


# ------------------------------------------------------------- dependencies
def quick_deps() -> list:
    """[(name, fix)] for every required tool that is missing.

    Kept for callers that must not import preflight/heavy engines at launch.
    The authoritative deep check is `preflight.check()`.
    """
    import shutil
    here = _tool_dir()
    checks = (
        ("luac 5.3", bool(shutil.which("luac5.3") or shutil.which("luac")),
         "pkg install lua53"),
        ("luac 5.1", bool(shutil.which("luac5.1")), "pkg install lua51"),
        ("luac 5.2", bool(shutil.which("luac5.2")), "pkg install lua52"),
        ("luac 5.4", bool(shutil.which("luac5.4")), "pkg install lua54"),
        ("luajit", bool(shutil.which("luajit")), "pkg install luajit"),
    )
    return [(name, fix) for name, ok, fix in checks if not ok]


# -------------------------------------------------------------- boot / check

def boot(vip) -> bool:
    """Deep preflight, install anything missing, then report readiness.

    Returns True when the essentials are present (the tool can run). A missing
    optional host tool (luac/luajit) does not fail the boot: the bundled Lua
    engines cover the job. Never raises.
    """
    report = None
    check_failed = False
    try:
        # Optional host tools stay out of interactive boot: the bundled engines
        # cover them. Full PATH probing remains available in the CLI installer.
        report = preflight.check(include_host_tools=False)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("startup.boot:preflight", _ikram_exc)
        check_failed = True

    if check_failed or report is None:
        try:
            vip.error_box([
                "X System check could not run",
                "The tool cannot confirm its components are ready.",
                "Restart or reinstall; details are in the log.",
            ])
        except Exception as _ikram_exc:
            ikram_logger.log_exc("startup.boot:check-failed", _ikram_exc)
        return False

    if report is not None and not report.essential_ok:
        try:
            import installer
            report = installer.run(vip, report, animate=False)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("startup.boot:install", _ikram_exc)

    if report is None or not report.essential_ok:
        try:
            vip.error_box([
                "X Components missing",
                "Required files are not ready.",
                "Restart or reinstall; details are in the log.",
            ])
        except Exception as _ikram_exc:
            ikram_logger.log_exc("startup.boot:missing", _ikram_exc)
        return False

    return True
