# -*- coding: utf-8 -*-
"""Unified engine wrapper — my main entry used by ikram.pyc via `import univ`.

Loads the original `univ.pyc` for all non-Lua engines and overlays the
BGMI-aware Lua pipeline (mega_lua) so Decompile/Compile handle real game
bytecode with readable output and game-ready recompilation.

Keeps the exact API surface ikram.pyc calls:
    detect(src) -> str
    decompile_any(src, out, progress=None) -> (ok, msg)
    decompile_multi_engines(src, out_root, progress=None) -> [(label, ok, out, msg)]
    compile_any(src, out, progress=None) -> (ok, msg)
plus every other attribute of the original univ module.

Implementation detail: the legacy `univ.pyc` sits in the same directory.
Python resolves `univ.py` before `univ.pyc`, so this file wins. We load the
original code via importlib and re-export everything under _legacy, then
return our pipeline for the Lua calls.
"""

# Error log. Hard import on purpose: ikram_logger ships in this directory
# and its own entry points are non-raising by construction, so a missing
# logger is a broken install that must fail loudly at import -- not a
# silent no-op that would swallow every record of what went wrong.
from __future__ import annotations

import ikram_logger
import importlib.util
import sys
from pathlib import Path

import mega_lua as _mega

_TOOL_DIR = Path(__file__).resolve().parent
_PYC = _TOOL_DIR / "univ.pyc"


def _load_legacy():
    """Import the original univ.pyc as a private module `_univ_legacy`."""
    if "_univ_legacy" in sys.modules:
        return sys.modules["_univ_legacy"]
    spec = importlib.util.spec_from_file_location("_univ_legacy", str(_PYC))
    mod = importlib.util.module_from_spec(spec)
    sys.modules["_univ_legacy"] = mod
    try:
        spec.loader.exec_module(mod)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("univ._load_legacy:48", _ikram_exc)
        sys.modules.pop("_univ_legacy", None)
        raise
    return mod


_legacy = None
try:
    _legacy = _load_legacy()
except Exception as _ikram_exc:
    ikram_logger.log_exc("univ.<module>:58", _ikram_exc)
    _legacy = None

# ---- re-export every legacy attribute so nothing breaks -----------------
if _legacy is not None:
    for _n in dir(_legacy):
        if _n.startswith("__") and _n not in ("__builtins__",):
            continue
        globals()[_n] = getattr(_legacy, _n)

# ---- graceful-failure handling -------------------------------------------
# A compile/decompile that returns (ok=False, msg) never raises, so it never
# reaches the compiled core's exception reporters. These hooks are where such
# results were turned into an outbound alert; the reporting channel has been
# removed, so the caller keeps full ownership of the result it returns. The
# local error log in ikram_logger is the only record now.

# ---- public callables ikram.pyc relies on -------------------------------


def detect(src):
    """Classify a file. Lua handled by mega_lua, else legacy detect."""
    kind = _mega.detect_lua(src)
    if kind != "unknown":
        return kind
    if _legacy is not None:
        try:
            return _legacy.detect(src)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("univ.detect:145", _ikram_exc)
            pass
    return kind


_LUA_KINDS = ("Lua source", "Lua", "Lua 5.1", "Lua 5.2", "Lua 5.3",
              "Lua 5.4", "LuaJIT", "Lua 5.3 (encrypted)", "Luau")

# lua_pipeline TIER 1 calls decompile_multi_engines(), so a cascade that
# calls lua_pipeline.run() would recurse forever. This flag makes the
# fallback strictly one-way: outer run() -> mega -> cascade(inner run).
_in_cascade = False


def _cascade(src, out_root, progress, results):
    """Fall back to lua_pipeline's multi-engine cascade and append its single
    winning artifact to `results` in place. Keeps mega_lua's exact
    (label, ok, path, msg) shape so the compiled UI renders it unchanged.
    Returns True on recovery."""
    global _in_cascade
    if _in_cascade:
        return False
    import lua_pipeline as _lp
    _in_cascade = True
    try:
        got = _lp.run(str(src), str(out_root), progress)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("univ._cascade:170", _ikram_exc)
        return False
    finally:
        _in_cascade = False
    if not got.get("ok"):
        return False
    out = got.get("out")
    if not out or not Path(str(out)).is_file():
        return False
    # One entry, not one per attempt: the compiled UI prints every entry as a
    # separate "OK" line and the trail already contains the failed methods.
    results.append(("Decompile (cascade: %s)" % (got.get("quality") or "recovered"),
                    True, out, "recovered by full engine cascade"))
    fail = got.get("fail_path")
    if fail:
        try:
            Path(str(fail)).unlink()
        except OSError as _ikram_exc:
            ikram_logger.log_exc("univ._cascade:187", _ikram_exc)
    return True


def decompile_any(src, out, progress=None):
    """Decompile a Lua file to readable source; returns (ok, msg)."""
    src = Path(src)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    kind = detect(src)
    if kind not in _LUA_KINDS:
        if _legacy is not None:
            return _legacy.decompile_any(src, out, progress)
        return False, "unsupported"
    results = decompile_multi_engines(src, out.parent, progress)
    # Prefer the game-ready artifact, but accept ANY successful artifact: the
    # cascade fallback legitimately produces *_decompiled.lua when no engine
    # can emit a recompilable *_GAME.lua, and returning results[0][1] there
    # reported failure for a file that was in fact decompiled.
    for _l, ok, p, _m in results:
        if ok and p and str(p).endswith("_GAME.lua"):
            try:
                out.write_bytes(Path(str(p)).read_bytes())
                return True, str(p)
            except Exception as _ikram_exc:
                ikram_logger.log_exc("univ.decompile_any.game", _ikram_exc)
    for _l, ok, p, m in results:
        if ok and p and Path(str(p)).is_file():
            try:
                out.write_bytes(Path(str(p)).read_bytes())
            except Exception as _ikram_exc:
                ikram_logger.log_exc("univ.decompile_any:203", _ikram_exc)
                return False, m
            return True, str(p)
    ok = results[0][1] if results else False
    msg = results[0][3] if results else "decompile failed"
    return ok, msg


def decompile_multi_engines(src, out_root, progress=None):
    """Return [(label, ok, out_path, msg)] for all produced artifacts."""
    src = Path(src)
    out_root = Path(out_root)
    if str(src).lower().endswith((".py", ".pyc", ".java", ".class", ".dex")):
        if _legacy is not None:
            return _legacy.decompile_multi_engines(src, out_root, progress)
        return [("Legacy", False, out_root, "unsupported")]
    kind = detect(src)
    if kind in _LUA_KINDS:
        results = _mega.decompile_bgmi(src, out_root, progress)
        if results and all(str(r[0]).lower().startswith("decompile") and not r[1] for r in results):
            # mega_lua is ONE engine. The compiled ikram.pyc UI calls this
            # function directly, so without the cascade below a file that only
            # ljd / unluac.jar / unluac-rs can read (e.g. LuaJIT v3 chunks)
            # reported zero output even though lua_pipeline.run reads it.
            # Escalate before giving up.
            _cascade(src, out_root, progress, results)
        return results
    if _legacy is not None:
        return _legacy.decompile_multi_engines(src, out_root, progress)
    return [("Legacy", False, out_root, "unsupported")]


_COMPILE_KINDS = ("Lua source", "Lua", "Lua 5.1", "Lua 5.2", "Lua 5.3",
                  "Lua 5.4", "LuaJIT", "Luau")


def compile_any(src, out, progress=None, strip=False):
    """Compile readable Lua -> BGMI bytecode; returns (ok, msg)."""
    src = Path(src)
    out = Path(out)
    kind = detect(src)
    if kind in _COMPILE_KINDS:
        ok, msg = _mega.compile_bgmi(src, out, progress, strip=strip)
        return ok, msg
    if _legacy is not None:
        return _legacy.compile_any(src, out, progress)
    return False, "unsupported"


# Compat shim: legacy `compile_lua(src, out, version, strip)` compiles Lua
# source to STANDARD bytecode at `out` and returns '' on success / err string.
# lua_protect.protect_compile then converts std -> BGMI itself.
def compile_lua(src, out, version="5.3", strip=False) -> str:
    try:
        src = Path(src)
        data = src.read_bytes()
        if not data.strip():
            return "empty source file"
        if _mega._detect_dialect(data) or _mega._is_bgmi(data):
            return (
                "input is already compiled bytecode. "
                "Use Decompile (option 2) to get readable source first."
            )
        text = data.decode("utf-8", errors="replace")
        std = _mega._compile_std(text, strip=strip,
                                 chunk_name="@" + src.name)
        out = Path(out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(std)
        return ""
    except Exception as e:
        ikram_logger.log_exc("univ.compile_lua:231", e)
        return str(e)
