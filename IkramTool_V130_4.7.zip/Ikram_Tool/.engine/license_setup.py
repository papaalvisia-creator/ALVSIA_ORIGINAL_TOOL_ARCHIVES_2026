#!/usr/bin/env python3
"""Validate the shipped tool key file. Writes nothing.

There is no activation file and no remembered key. The installer only checks
that ``ikram_key.json`` is present and complete; the tool asks for the key on
every launch and keeps it in memory for that process only.
"""

import json
import re
import sys
from pathlib import Path

KEY_FILE_NAME = "ikram_key.json"
REQUIRED = ("version", "key_hash", "kdf", "kdf_salt", "kdf_rounds",
            "kdf_verifier")
# The V130 salt is 36 hex characters (ASCII "IKRAM_V130_SALT_01"); keep the
# shape check compatible with the shipped contract while still rejecting any
# non-hex, odd-length or implausibly sized value.
HEX_SALT = re.compile(r"[0-9a-fA-F]{32,64}")
HEX64 = re.compile(r"[0-9a-fA-F]{64}")


def main() -> int:
    key_file = Path(__file__).resolve().parent / KEY_FILE_NAME
    try:
        data = json.loads(key_file.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("invalid key file")
        for name in REQUIRED:
            if not str(data.get(name, "")).strip():
                raise ValueError("missing %s" % name)

        # Presence alone is not enough: reject a malformed shape here with a
        # clear reason instead of letting it fail later at the key gate.
        if data["version"] != "V130":
            raise ValueError("version must be V130")
        if not HEX64.fullmatch(str(data["key_hash"])):
            raise ValueError("key_hash must be 64 hex characters")
        if data["kdf"] != "pbkdf2_sha256":
            raise ValueError("kdf must be pbkdf2_sha256")
        salt = str(data["kdf_salt"])
        if not HEX_SALT.fullmatch(salt) or len(salt) % 2:
            raise ValueError("kdf_salt must be even-length hex (32-64 characters)")
        try:
            rounds = int(data["kdf_rounds"])
        except (TypeError, ValueError):
            raise ValueError("kdf_rounds must be an integer >= 100000") from None
        if rounds < 100000:
            raise ValueError("kdf_rounds must be an integer >= 100000")
        if not HEX64.fullmatch(str(data["kdf_verifier"])):
            raise ValueError("kdf_verifier must be 64 hex characters")
    except Exception as exc:
        print("Tool key check failed: %s" % exc, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
