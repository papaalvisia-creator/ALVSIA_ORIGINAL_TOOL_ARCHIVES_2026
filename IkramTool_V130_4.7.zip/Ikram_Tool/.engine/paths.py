"""IkramTool V130 - centralized, validated filesystem layout.

Single source of truth for every folder the tool touches:

    <tool>/.engine/     runtime state (theme config, last action)
    <tool>/DROP/        user input (pak / lua / inject / SaveGames)
    <tool>/RESULT/      tool output (extracted / injected / lua / processed /
                        CustomPak / Repacked / SaveGames)

Installed layout puts the tool under $HOME/Ikram_Tool (Termux:
/data/data/com.termux/files/home/Ikram_Tool, WSL: /home/user/Ikram_Tool);
dev layout falls back to this checkout. IKRAM_TOOL_DIR overrides both.
"""
import json
import os
import tempfile
import threading
import time
from pathlib import Path

TOOL_DIR_ENV = "IKRAM_TOOL_DIR"
VERSION_FILE = "VERSION"
CFG_NAME = "theme_config.json"
LAST_ACTION_NAME = "last_action.json"
LOG_DIR_NAME = ".ikram_secure"
MAX_UNIQUE_SUFFIX = 9999
DEV_ROOT = Path(__file__).resolve().parent


def _detect_platform() -> str:
    try:
        import platform
        _sys = platform.system().lower()
        if _sys == "darwin":
            return "macos"
        if _sys == "windows":
            return "windows"
    except Exception:
        pass
    try:
        with open("/proc/version", "r", errors="ignore") as _f:
            _v = _f.read().lower()
        if "microsoft" in _v or "wsl" in _v:
            return "wsl"
    except Exception:
        pass
    _prefix = os.environ.get("PREFIX") or ""
    if "com.termux" in _prefix:
        return "termux"
    return "linux"


def _resolve_tool_dir() -> Path:
    _env = os.environ.get(TOOL_DIR_ENV) or ""
    if _env.strip():
        return Path(_env.strip()).resolve()
    # Installed layout: the whole runtime lives in <tool>/.engine, so the data
    # root (DROP/RESULT) and the VERSION file are one level up. Dev layout has
    # paths.py at the tool root and falls through to the platform defaults.
    if DEV_ROOT.name == ".engine":
        return DEV_ROOT.parent
    _plat = _detect_platform()
    if _plat == "termux":
        return Path("/data/data/com.termux/files/home/Ikram_Tool")
    if _plat == "wsl":
        return Path("/home/user/Ikram_Tool")
    return DEV_ROOT


class PathConfig:
    """Validated layout. Refuses anything that escapes the tool dir."""

    def __init__(self):
        self.tool_dir = _resolve_tool_dir()
        self.engine_dir = self.tool_dir / ".engine"
        self.drop_dir = self.tool_dir / "DROP"
        self.result_dir = self.tool_dir / "RESULT"
        self.drop_pak = self.drop_dir / "pak"
        self.drop_lua = self.drop_dir / "lua"
        self.drop_inject = self.drop_dir / "inject"
        self.drop_savegames = self.drop_dir / "SaveGames"
        self.result_extracted = self.result_dir / "extracted"
        self.result_injected = self.result_dir / "injected"
        self.result_lua = self.result_dir / "lua"
        self.result_processed = self.result_dir / "processed"
        self.result_custompak = self.result_dir / "CostomPak"
        self.result_repacked = self.result_dir / "Repacked"
        self.result_savegames = self.result_dir / "SaveGames"
        # Internal guard data lives outside RESULT. An unpacked tree must
        # contain only the files that came from the pak, so repacking that
        # tree cannot leak a tool manifest into the game archive.
        self.source_store = self.engine_dir / ".ikram_tool" / "source_manifests"
        self.validate(self.tool_dir)

    def validate(self, p, base=None):
        _b = Path(base) if base is not None else self.tool_dir
        _r = Path(p)
        if ".." in _r.parts:
            raise ValueError("path traversal refused: %s" % _r)
        _rp = _r.resolve()
        _bp = _b.resolve()
        try:
            _rp.relative_to(_bp)
        except ValueError:
            raise ValueError("path outside tool dir refused: %s" % _rp)
        return _rp


_pc = PathConfig()

DROP_DIR = _pc.drop_dir
DROP_PAK = _pc.drop_pak
DROP_LUA = _pc.drop_lua
DROP_INJ = _pc.drop_inject
DROP_SAVEGAMES = _pc.drop_savegames

RESULT_DIR = _pc.result_dir
RESULT_EXTRACTED = _pc.result_extracted
RESULT_INJECTED = _pc.result_injected
RESULT_LUA = _pc.result_lua
RESULT_PROCESSED = _pc.result_processed
RESULT_CUSTOMPAK = _pc.result_custompak
RESULT_REPACKED = _pc.result_repacked
RESULT_SAVEGAMES = _pc.result_savegames
SOURCE_STORE = _pc.source_store

ENGINE_DIR = _pc.engine_dir
TOOL_DIR = _pc.tool_dir


def validate_path(p, base=None) -> Path:
    return Path(_pc.validate(p, base))


def extended_path(p) -> Path:
    """Return a Windows extended-length path for filesystem calls only.

    On Windows a path longer than MAX_PATH needs the ``\\\\?\\`` prefix to
    reach the filesystem instead of failing with OSError. Only absolute
    paths can take the prefix: relative paths, non-Windows platforms and
    already-prefixed paths are returned unchanged. Callers keep the logical
    path for display and pass this result only to filesystem operations.
    """
    _p = Path(p)
    if os.name != "nt":
        return _p
    try:
        if not _p.is_absolute():
            return _p
    except (OSError, ValueError):
        return _p
    _text = str(_p)
    if _text.startswith("\\\\?\\"):
        return _p
    try:
        _text = os.path.abspath(_text)
    except (OSError, ValueError):
        pass
    if _text.startswith("\\\\"):
        return Path("\\\\?\\UNC\\" + _text[2:])
    return Path("\\\\?\\" + _text)


def is_internal_rel(rel) -> bool:
    """True for hidden, tool-internal or staging paths.

    One predicate for UNPACK rows, the processed mirror, inject input and
    repack context. A path under `.hidden/`, `_quarantine/` or `_stage/` is
    never a game payload, even when its own basename looks normal.
    """
    return any(part.startswith((".", "_")) for part in
               str(rel).replace("\\", "/").split("/") if part)


def should_process_rel(rel) -> bool:
    """True for a payload that belongs in the readable processed mirror."""
    return (not is_internal_rel(rel)
            and Path(str(rel)).suffix.lower() not in (".lua", ".luac"))


def read_version() -> str:
    for _p in (Path(_pc.tool_dir) / VERSION_FILE, DEV_ROOT / VERSION_FILE):
        try:
            if _p.is_file():
                _t = _p.read_text(errors="ignore").strip()
                if _t:
                    return _t
        except Exception:
            pass
    return "V130"


def human(num) -> str:
    try:
        _n = float(num)
    except Exception:
        return "0 B"
    if _n < 1024.0:
        return "%d B" % int(_n)
    _units = (("KB", 1024.0), ("MB", 1024.0 ** 2), ("GB", 1024.0 ** 3), ("TB", 1024.0 ** 4))
    _val = _n
    _u = "B"
    for _name, _f in _units:
        if _n >= _f:
            _val = _n / _f
            _u = _name
    return "%s %s" % (round(_val, 2), _u)


def count_dir(p) -> tuple:
    """Exact file count and bytes. scandir avoids rglob's sort+stat storm.

    Long Windows paths use the extended namespace at the filesystem boundary;
    callers keep their logical path for display and logs.
    """
    _p = extended_path(p)
    _n, _b = 0, 0
    try:
        if _p.is_file():
            try:
                return 1, _p.stat().st_size
            except OSError:
                return 1, 0
        if not _p.is_dir():
            return 0, 0
    except OSError:
        return 0, 0
    _stack = [str(_p)]
    while _stack:
        _cur = _stack.pop()
        try:
            _entries = os.scandir(_cur)
        except OSError:
            continue
        with _entries:
            for _e in _entries:
                try:
                    if _e.is_dir(follow_symlinks=False):
                        _stack.append(_e.path)
                    elif _e.is_file(follow_symlinks=True):
                        _n += 1
                        try:
                            _b += _e.stat(follow_symlinks=True).st_size
                        except OSError:
                            pass
                except OSError:
                    continue
    return _n, _b


def count_dir_bounded(p, limit=4096) -> tuple:
    """Count up to `limit` files. Returns (files, bytes, complete).

    A CLEAN row must show real numbers for small folders without walking a
    huge tree on the UI thread. Hitting the cap returns `complete=False` and
    the caller falls back to the persisted snapshot, never to a bare
    "calculating" row that looks like a hang.
    """
    _cap = max(1, int(limit))
    _p = extended_path(p)
    _n, _b = 0, 0
    try:
        if _p.is_file():
            try:
                return 1, _p.stat().st_size, True
            except OSError:
                return 1, 0, True
        if not _p.is_dir():
            return 0, 0, True
    except OSError:
        return 0, 0, True
    _stack = [str(_p)]
    while _stack:
        _cur = _stack.pop()
        try:
            _entries = os.scandir(_cur)
        except OSError:
            continue
        with _entries:
            for _e in _entries:
                try:
                    if _e.is_dir(follow_symlinks=False):
                        _stack.append(_e.path)
                    elif _e.is_file(follow_symlinks=True):
                        if _n >= _cap:
                            return _n, _b, False
                        _n += 1
                        try:
                            _b += _e.stat(follow_symlinks=True).st_size
                        except OSError:
                            pass
                except OSError:
                    continue
    return _n, _b, True


# ---------------------------------------------------------- folder row stats
# The main menu used to walk the whole RESULT tree on every render. After a big
# unpack that walk alone cost over a minute on Windows. Folder rows now use a
# cached count; the full walk, when needed, runs off the UI thread.
_STATS_FILE = ENGINE_DIR / "folder_stats.json"
_STATS_LOCK = threading.Lock()
_STATS_CACHE = {}
_STATS_PENDING = set()
_STATS_GEN = {}
_STATS_SCHEMA = 1
_STATS_MAX_AGE = 300.0


def _stats_key(p) -> str:
    try:
        return str(Path(p).resolve())
    except Exception:
        return str(p)


def _stats_sig(p) -> tuple:
    """Cheap fingerprint of the root's immediate children."""
    _p = extended_path(p)
    try:
        if _p.is_file():
            _st = _p.stat()
            return ["file", int(_st.st_mtime_ns), int(_st.st_size)]
        if not _p.is_dir():
            return ["absent"]
        _items = []
        with os.scandir(str(_p)) as _it:
            for _e in _it:
                try:
                    _st = _e.stat(follow_symlinks=False)
                    _items.append([_e.name,
                                   bool(_e.is_dir(follow_symlinks=False)),
                                   int(_st.st_mtime_ns), int(_st.st_size)])
                except OSError:
                    _items.append([_e.name, False, 0, 0])
        return ["dir", sorted(_items, key=lambda x: x[0].lower())]
    except Exception:
        return ["unknown"]


def _valid_stats_record(value):
    """Reject malformed or foreign cache records instead of crashing menus."""
    if not isinstance(value, dict):
        return None
    try:
        if int(value.get("schema", -1)) != _STATS_SCHEMA:
            return None
        _sig = list(value.get("sig", []))
        _n = int(value["n"])
        _b = int(value["b"])
        _ts = float(value["ts"])
        if _n < 0 or _b < 0 or _ts < 0:
            return None
    except (KeyError, TypeError, ValueError, OverflowError):
        return None
    return {"schema": _STATS_SCHEMA, "sig": _sig,
            "n": _n, "b": _b, "ts": _ts}


def _load_stats_locked():
    global _STATS_CACHE
    if _STATS_CACHE:
        return
    _data = {}
    try:
        _raw = json.loads(_STATS_FILE.read_text(encoding="utf-8"))
        if isinstance(_raw, dict):
            _data = _raw
    except Exception:
        _data = {}
    _clean = {}
    for _key, _value in _data.items():
        _rec = _valid_stats_record(_value)
        if _rec is not None:
            _clean[str(_key)] = _rec
    _STATS_CACHE = _clean


def _save_stats_locked():
    """Atomic persist: a crash or second instance never sees a half JSON."""
    _tmp = None
    try:
        _fd, _name = tempfile.mkstemp(
            prefix=".folder_stats.", suffix=".tmp", dir=str(_STATS_FILE.parent))
        _tmp = Path(_name)
        with os.fdopen(_fd, "w", encoding="utf-8") as _fh:
            json.dump(_STATS_CACHE, _fh, sort_keys=True)
            _fh.flush()
            os.fsync(_fh.fileno())
        os.replace(str(_tmp), str(_STATS_FILE))
    except Exception:
        pass
    finally:
        if _tmp is not None:
            try:
                _tmp.unlink()
            except Exception:
                pass


def _refresh_stats(key, p, sig, gen):
    try:
        _n, _b = count_dir(p)
        _rec = {"schema": _STATS_SCHEMA, "sig": list(sig),
                "n": int(_n), "b": int(_b), "ts": time.time()}
    except Exception:
        _rec = {"schema": _STATS_SCHEMA, "sig": list(sig),
                "n": 0, "b": 0, "ts": time.time()}
    with _STATS_LOCK:
        if gen != _STATS_GEN.get(key, 0):
            _STATS_PENDING.discard(key)
            return
        _STATS_CACHE[key] = _rec
        _STATS_PENDING.discard(key)
        _save_stats_locked()


def cached_count_dir(p):
    """Return (n, bytes) or (None, None) while a fresh count is pending."""
    _p = Path(p)
    _key = _stats_key(_p)
    _sig = _stats_sig(_p)
    _now = time.time()
    with _STATS_LOCK:
        _load_stats_locked()
        _rec = _STATS_CACHE.get(_key)
        _match = bool(_rec and list(_rec.get("sig", ())) == list(_sig))
        if _match:
            try:
                _fresh = _now - float(_rec.get("ts", 0)) < _STATS_MAX_AGE
            except (TypeError, ValueError, OverflowError):
                _fresh = False
            if _fresh:
                return int(_rec["n"]), int(_rec["b"])
        _need_scan = _key not in _STATS_PENDING
        if _need_scan:
            _STATS_PENDING.add(_key)
        _gen = _STATS_GEN.get(_key, 0)
    if _need_scan:
        threading.Thread(target=_refresh_stats, args=(_key, _p, _sig, _gen),
                         daemon=True).start()
    if _match:
        return int(_rec["n"]), int(_rec["b"])
    return None, None


def remember_count(p, n, b):
    """Persist an exact bounded count so later renders never re-scan it."""
    _key = _stats_key(Path(p))
    _sig = _stats_sig(Path(p))
    with _STATS_LOCK:
        _load_stats_locked()
        _STATS_CACHE[_key] = {
            "schema": _STATS_SCHEMA, "sig": list(_sig),
            "n": int(n), "b": int(b), "ts": time.time(),
        }
        _STATS_GEN[_key] = _STATS_GEN.get(_key, 0) + 1
        _STATS_PENDING.discard(_key)
        _save_stats_locked()


def last_count_dir(p):
    """Return the last persisted snapshot for a folder as (files, bytes).

    Used only by CLEAN display rows while a background refresh is pending.
    A stale number with real colours is better than a bare "calculating"
    row that reads as a stuck operation.
    """
    _key = _stats_key(Path(p))
    with _STATS_LOCK:
        _load_stats_locked()
        _rec = _STATS_CACHE.get(_key)
    if _rec is None:
        return None, None
    try:
        return int(_rec["n"]), int(_rec["b"])
    except (KeyError, TypeError, ValueError):
        return None, None


def invalidate_tree_stats(p=None):
    """Drop a cached folder count after a write; None drops every count."""
    with _STATS_LOCK:
        _load_stats_locked()
        if p is None:
            for _key in list(_STATS_GEN):
                _STATS_GEN[_key] += 1
            _STATS_CACHE.clear()
            _STATS_PENDING.clear()
        else:
            _key = _stats_key(p)
            _STATS_GEN[_key] = _STATS_GEN.get(_key, 0) + 1
            _STATS_CACHE.pop(_key, None)
            _STATS_PENDING.discard(_key)
        _save_stats_locked()


def affected_files(targets, limit=8) -> list:
    """First few file names for CLEAN confirmation. Bounded, never sorts a tree."""
    limit = max(0, int(limit))
    if not limit:
        return []
    rows = []
    stack = [Path(t) for t in reversed(list(targets))]
    while stack and len(rows) < limit:
        p = stack.pop()
        try:
            xp = extended_path(p)
            if xp.is_file():
                rows.append(folder_label(p))
                continue
            if not xp.is_dir():
                continue
            with os.scandir(str(xp)) as it:
                for entry in it:
                    if len(rows) >= limit:
                        break
                    child = p / entry.name
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            stack.append(child)
                        elif entry.is_file(follow_symlinks=False):
                            rows.append(folder_label(child))
                    except OSError:
                        continue
        except OSError:
            continue
    return rows[:limit]


def folder_label(p) -> str:
    _p = Path(p)
    _base = _pc.tool_dir
    _parts = None
    try:
        _rel = _p.resolve().relative_to(_base.resolve())
        _parts = [x for x in _rel.parts if x not in (".",)]
    except Exception:
        _parts = [x for x in _p.parts if x not in (".", "..")]
        _parts = _parts[-1:] or [str(_p)]
    return "/".join(str(x) for x in _parts)


def purge(p) -> list:
    """Remove everything under p and return paths that could not be removed.

    Streaming scandir avoids materialising and sorting a huge directory before
    the first delete. rmtree handles deep trees in C; a onexc/onerror callback
    keeps going after a locked entry instead of aborting the whole clear.
    """
    import shutil

    _p = Path(p)
    _xp = extended_path(_p)
    _failed = []
    invalidate_tree_stats(_p)

    def _describe(_exc):
        if isinstance(_exc, tuple) and len(_exc) >= 2:
            return str(_exc[1])[:48]
        return str(_exc)[:48]

    def _rmtree_error(_func, _path, _exc):
        _failed.append("%s (%s)" % (_path, _describe(_exc)))

    try:
        if _xp.is_dir():
            _children = []
            with os.scandir(str(_xp)) as _it:
                for _entry in _it:
                    _children.append(_p / _entry.name)
            for _child in _children:
                try:
                    _cx = extended_path(_child)
                    if _cx.is_dir() and not _cx.is_symlink():
                        try:
                            shutil.rmtree(str(_cx), onexc=_rmtree_error)
                        except TypeError:
                            shutil.rmtree(str(_cx), onerror=_rmtree_error)
                    else:
                        _cx.unlink()
                except Exception as _exc:
                    _failed.append("%s (%s)" % (_child, _describe(_exc)))
        elif _xp.exists() or _xp.is_symlink():
            _xp.unlink()
    except Exception as _exc:
        _failed.append("%s (%s)" % (_p, _describe(_exc)))
    return _failed


def unique_path(p) -> Path:
    _p = Path(p)
    for _i in range(MAX_UNIQUE_SUFFIX + 1):
        _cand = (_p if _i == 0 else
                 _p.parent / ("%s_%d%s" % (_p.stem, _i, _p.suffix)))
        if not extended_path(_cand).exists():
            return _cand
    raise FileExistsError("no free output name for %s" % _p)


def list_drop(folder) -> list:
    _p = extended_path(folder)
    _out = []
    try:
        if not _p.is_dir():
            return _out
        for _c in sorted(_p.iterdir(), key=lambda x: x.name.lower()):
            if _c.is_file():
                _out.append(Path(folder) / _c.name)
    except OSError:
        return _out
    return _out


def ensure_dirs() -> None:
    for _d in (DEV_ROOT, _pc.engine_dir, _pc.drop_dir, _pc.result_dir):
        try:
            _d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass


