"""IkramTool — deep preflight.

Before the tool reaches its menu it must KNOW, not guess, that every part it
needs is present and usable. `startup.quick_deps()` only stats a handful of
paths; this module is the real gate. It verifies:

  * the interpreter that is actually running (and that it can load ikram.pyc),
  * every compiled / source engine the menu can dispatch into,
  * the crypto layer (SM4 + pak crypto),
  * the Lua toolchain (bundled luac/luadec/repak/unluac + host luac/luajit),
  * the DROP / RESULT working trees,
  * the licence file.

`check()` returns a `Report`. The UI renders it as a live checklist; the
installer consumes `report.missing` as its work list. Nothing here raises —
a broken probe becomes a failed Item, never an exception.

Run directly for a terminal report:  python preflight.py
"""
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# The embedded python314 distribution ships a `._pth`, which suppresses the
# usual "script directory on sys.path" rule. Bootstrap our own directory so
# the import probes below (and `import paths`) resolve inside the tool.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

try:
    import paths
except Exception:  # pragma: no cover - only when run from a broken install
    paths = None

BRAND = "IkramTool"


def _tool_dir() -> Path:
    return _HERE


def _root_dir() -> Path:
    """The install root that owns DROP/RESULT. Installed layout keeps the
    runtime in <tool>/.engine, so the data root is one level up."""
    return _HERE.parent if _HERE.name == ".engine" else _HERE


# --------------------------------------------------------------------- items
class Item:
    __slots__ = ("id", "label", "ok", "detail", "fix", "kind")

    def __init__(self, id, label, ok, detail="", fix="", kind="file"):
        self.id = id
        self.label = label
        self.ok = bool(ok)
        self.detail = detail
        self.fix = fix
        self.kind = kind            # file | tool | dir | interp | key

    def __repr__(self):
        return "Item(%s ok=%s)" % (self.id, self.ok)


class Report:
    def __init__(self, items):
        self.items = list(items)

    @property
    def ok(self):
        return all(i.ok for i in self.items)

    @property
    def missing(self):
        return [i for i in self.items if not i.ok]

    @property
    def present(self):
        return [i for i in self.items if i.ok]

    @property
    def essential_ok(self):
        """True when every non-optional component is present. Host tools
        (kind == "tool") are optional: the bundled Lua engines cover them, so a
        missing luac/luajit must not block the boot."""
        return all(i.ok for i in self.items if i.kind != "tool")

    @property
    def optional_missing(self):
        """Missing host tools that the bundled engines can stand in for."""
        return [i for i in self.items if not i.ok and i.kind == "tool"]

    def counts(self):
        return len(self.present), len(self.items)

    def to_dict(self):
        return {
            "brand": BRAND,
            "ok": self.ok,
            "counts": {"present": len(self.present), "total": len(self.items)},
            "items": [
                {"id": i.id, "label": i.label, "ok": i.ok, "detail": i.detail,
                 "fix": i.fix, "kind": i.kind}
                for i in self.items
            ],
        }


# ------------------------------------------------------------- sub-checks
# Required engine files. (id, human label, relative path, fix hint)
_ENGINE_FILES = (
    ("core",      "core engine (ikram.pyc)",   "ikram.pyc",       "reinstall tool"),
    ("entry",     "entry point",               "ikram_patch.py",  "reinstall tool"),
    ("paths",     "paths",                     "paths.py",        "reinstall tool"),
    ("theme",     "theme engine",              "theme_engine.py", "reinstall tool"),
    ("box",       "box engine",                "box_engine.py",   "reinstall tool"),
    ("vip_ui",    "interface",                 "vip_ui.py",       "reinstall tool"),
    ("startup",   "startup",                   "startup.py",      "reinstall tool"),
    ("menus",     "menus",                     "menus.py",        "reinstall tool"),
    ("engines",   "engines",                   "engines.py",      "reinstall tool"),
    ("pak",       "pak engine",                "pak.pyc",         "reinstall tool"),
    ("tencent_pak", "tencent writer",           "tencent_pak.py",  "reinstall tool"),
    ("inject_diagnosis", "inject diagnosis",    "inject_diagnosis.py", "reinstall tool"),
    ("lua_engine", "lua engine",               "lua_engine.pyc",  "reinstall tool"),
    ("lua_pipe",  "lua pipeline",              "lua_pipeline.py", "reinstall tool"),
    ("univ",      "universal engine",          "univ.py",         "reinstall tool"),
)

_CRYPTO_FILES = (
    ("sm4",     "SM4 (custom)",   "sm4_custom.pyc",    "reinstall tool"),
    ("pakcrypto", "pak crypto",   "pakcrypto.pyc",     "reinstall tool"),
    ("crypto",  "crypto engine",  "crypto_engine.pyc", "reinstall tool"),
)

# Bundled Lua toolchain shipped inside the tool directory.
_LUA_BUNDLED = (
    ("luac_patched", "luac (patched)",  "luac_patched", "reinstall tool"),
    ("luac_deep",    "luac (deep)",     "luac_deep",    "reinstall tool"),
    ("lua_patched",  "lua (patched)",   "lua_patched",  "reinstall tool"),
    ("luadec",       "luadec",          "luadec.fresh", "reinstall tool"),
    ("repak",        "repak",           "repak",        "reinstall tool"),
    ("unluac_jar",   "unluac.jar",      "unluac.jar",   "reinstall tool"),
    ("unluac_rs",    "unluac-rs",       "unluac_rs",    "reinstall tool"),
)

# Windows cannot exec the ELF builds at the tool root; the real runtime
# resolves the same tools out of lua_bin/windows under their PE names. Keys
# absent from this map (unluac.jar) stay at the tool root on both platforms.
# luadec has no Windows build: it is optional there (kind="tool"), and the
# bundled unluac-rs covers the same dialects.
_WIN_BUNDLED = {
    "luac_patched": "luac.exe",
    "luac_deep": "luac.exe",
    "lua_patched": "lua.exe",
    "repak": "repak.exe",
    "unluac_rs": "unluac_rs.exe",
}

# Host tools we can only look for on PATH.
_LUA_HOST = (
    ("java",   "java (JDK)",  ("java",),         "pkg install openjdk-17"),
    ("luac51", "luac 5.1",    ("luac5.1",),      "pkg install lua51"),
    ("luac52", "luac 5.2",    ("luac5.2",),      "pkg install lua52"),
    ("luac53", "luac 5.3",    ("luac5.3", "luac"), "pkg install lua53"),
    ("luac54", "luac 5.4",    ("luac5.4",),      "pkg install lua54"),
    ("luajit", "luajit",      ("luajit",),       "pkg install luajit"),
)

_DIRS = (
    ("engine_dir", "engine data", ".engine"),
    ("drop",       "DROP",        "DROP"),
    ("result",     "RESULT",      "RESULT"),
)


def _check_interpreter(here):
    """The interpreter must be able to load the compiled core."""
    items = []
    v = "%d.%d.%d" % sys.version_info[:3]
    items.append(Item("python", "interpreter", True, "Python %s" % v, kind="interp"))

    core = here / "ikram.pyc"
    if not core.is_file():
        items.append(Item("core_magic", "core bytecode magic", False,
                          "ikram.pyc missing", "reinstall tool", kind="interp"))
        return items
    try:
        with core.open("rb") as fh:
            head = fh.read(4)
        want = importlib.util.MAGIC_NUMBER
        ok = head == want
        detail = ("loadable by %s" % v) if ok else (
            "magic %s != this interpreter %s" % (head.hex(), want.hex()))
        items.append(Item("core_magic", "core bytecode", ok, detail,
                          "run the bundled python314 interpreter", kind="interp"))
    except Exception as exc:
        items.append(Item("core_magic", "core bytecode", False, str(exc),
                          "reinstall tool", kind="interp"))
    return items


def _check_files(here, spec, kind):
    out = []
    for id, label, rel, fix in spec:
        p = here / rel
        ok = p.is_file()
        detail = rel if ok else "missing: %s" % rel
        out.append(Item(id, label, ok, detail, "" if ok else fix, kind=kind))
    return out


def _check_dirs(here, dirs):
    out = []
    root = _root_dir()
    for id, label, rel in dirs:
        # "engine data" is the runtime directory itself (this file's folder);
        # DROP/RESULT live at the install root, one level up in .engine layout.
        p = here if rel == ".engine" else (root / rel)
        ok = p.is_dir()
        out.append(Item(id, label, ok, str(p) if ok else "missing: %s" % p,
                        "" if ok else "run installer", kind="dir"))
    return out


def _host_binary(name):
    """Real PATH probe. A bare `luac` only counts when it reports 5.3."""
    p = shutil.which(name)
    if not p:
        return None
    if name == "luac":
        try:
            proc = subprocess.run([p, "-v"], capture_output=True, timeout=15)
            txt = (proc.stdout + proc.stderr).decode("utf-8", "replace")
        except Exception:
            return None
        if "5.3" not in txt:
            return None
    return p


def _check_host_tools():
    out = []
    win = os.name == "nt"
    for id, label, names, fix in _LUA_HOST:
        if win:
            # Optional everywhere, but the Termux package hint is nonsense on
            # Windows. The bundled engines already cover these dialects.
            fix = "optional on Windows - install %s and add it to PATH" % label
        found = next((p for p in (_host_binary(n) for n in names) if p), None)
        out.append(Item(id, label, bool(found),
                        (found or "not on PATH"),
                        "" if found else fix, kind="tool"))
    return out


def _check_bundled(here):
    """Verify the bundled Lua tools where the RUNTIME looks for them.

    On Windows that is lua_bin/windows with PE names; the ELF files at the
    tool root are inert there, so stat-ing them would report a false OK and a
    dead toolchain would only surface at first compile.
    """
    out = []
    win = os.name == "nt"
    for id, label, rel, fix in _LUA_BUNDLED:
        winexe = _WIN_BUNDLED.get(id) if win else None
        if win and winexe:
            # Same order the runtime resolvers use (mega_lua._tool_bin,
            # engines._pak_tool_candidates): lua_bin/windows first, then the
            # tool root. repak.exe lives at the root, lua/luac under lua_bin.
            for cand in (here / "lua_bin" / "windows" / winexe,
                         here / winexe):
                if cand.is_file():
                    p = cand
                    break
            else:
                p = here / "lua_bin" / "windows" / winexe
            detail_ok = str(p.relative_to(here)).replace(os.sep, "/")
        elif win and id == "luadec":
            out.append(Item(id, label, True, "optional on Windows "
                                             "(unluac-rs covers it)",
                            kind="tool"))
            continue
        else:
            p = here / rel
            detail_ok = rel
        ok = p.is_file()
        out.append(Item(id, label, ok, detail_ok if ok else "missing: %s" % p,
                        "" if ok else fix, kind="file"))
    return out


def _check_key(here):
    f = here / "ikram_key.json"
    if not f.is_file():
        return Item("key", "licence file", False, "missing: ikram_key.json",
                    "reinstall tool", kind="key")
    try:
        data = json.loads(f.read_text(errors="ignore"))
        ver = data.get("version")
        good = bool(data.get("key_hash")) and bool(ver)
        detail = "version %s" % ver if good else "malformed key file"
        return Item("key", "licence file", good, detail,
                    "" if good else "reinstall tool", kind="key")
    except Exception as exc:
        return Item("key", "licence file", False, str(exc), "reinstall tool",
                    kind="key")


def _check_imports():
    """Real imports of the two modules the UI cannot live without."""
    out = []
    for id, mod, label in (("imp_theme", "theme_engine", "theme module loads"),
                           ("imp_box", "box_engine", "box module loads")):
        try:
            __import__(mod)
            out.append(Item(id, label, True, mod, kind="file"))
        except Exception as exc:
            out.append(Item(id, label, False, "%s: %s" % (mod, exc),
                            "reinstall tool", kind="file"))
    return out


# ------------------------------------------------------------------- run
def check(deep=True, include_host_tools=True) -> Report:
    """Run preflight. `deep` adds import probes; host tool PATH probes are
    optional and can be skipped for interactive boot."""
    here = _tool_dir()
    items = []
    items += _check_interpreter(here)
    items += _check_files(here, _ENGINE_FILES, "file")
    items += _check_files(here, _CRYPTO_FILES, "file")
    items += _check_bundled(here)
    if include_host_tools:
        items += _check_host_tools()
    items += _check_dirs(here, _DIRS)
    items.append(_check_key(here))
    if deep:
        items += _check_imports()
    return Report(items)


def summarize(report):
    present, total = report.counts()
    if report.ok:
        return "all %d components ready" % total
    return "%d/%d ready, %d missing" % (present, total, len(report.missing))


# ------------------------------------------------------------------- CLI
def _main(argv):
    report = check(deep="--fast" not in argv)
    if "--json" in argv:
        print(json.dumps(report.to_dict(), indent=2))
        return 0 if report.essential_ok else 1
    print("%s preflight — %s" % (BRAND, summarize(report)))
    for it in report.items:
        mark = "OK " if it.ok else "!! "
        line = "%s%-14s %s" % (mark, it.label, it.detail)
        if not it.ok and it.fix:
            line += "   -> %s" % it.fix
        print(line)
    return 0 if report.essential_ok else 1


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
