@echo off
rem IkramTool launcher (run from inside .engine; DROP/RESULT are ..\DROP ..\RESULT)
rem
rem The UI core is CPython 3.14 bytecode and the magic is version-exact: 3.15
rem raises "bad magic number" and 3.13 cannot even read the file. Every
rem fallback below asks the interpreter for its own version first, so a
rem machine with only 3.15 gets an honest one-line fix instead of a wall.
setlocal EnableExtensions
cd /d "%~dp0"

set "PY=%~dp0python314\python.exe"
if not exist "%PY%" set "PY="

if not defined PY (
    for /f "delims=" %%I in ('py -3.14 -c "import sys;print(sys.executable)" 2^>nul') do (
        if not defined PY set "PY=%%I"
    )
)
if not defined PY (
    for /f "delims=" %%I in ('python3.14 -c "import sys;print(sys.executable)" 2^>nul') do (
        if not defined PY set "PY=%%I"
    )
)
rem last resort: any python on PATH, but only if it really is 3.14
if not defined PY (
    for /f "delims=" %%I in ('python -c "import sys;print(sys.executable if sys.version_info[:2]==(3,14) else '')" 2^>nul') do (
        if not defined PY set "PY=%%I"
    )
)
if not defined PY (
    for /f "delims=" %%I in ('py -c "import sys;print(sys.executable if sys.version_info[:2]==(3,14) else '')" 2^>nul') do (
        if not defined PY set "PY=%%I"
    )
)

if not defined PY (
    echo   +--------------------------------------------------------------+
    echo   ^| IkramTool V130 - LAUNCHER ERROR                              ^|
    echo   +--------------------------------------------------------------+
    echo   ^| Main : CPython 3.14                                          ^|
    echo   ^| Issue: UI core ships as version-locked 3.14 bytecode.         ^|
    echo   ^| Fix  : run install.bat or use .engine\python314\python.exe    ^|
    echo   ^| CLI  : python PakTool.py --help                               ^|
    echo   +--------------------------------------------------------------+
    pause
    exit /b 1
)

chcp 65001 >nul 2>nul
set "PYTHONDONTWRITEBYTECODE=1"
"%PY%" -X utf8 "%~dp0ikram_patch.py" %*
set "EC=%ERRORLEVEL%"
endlocal & exit /b %EC%
