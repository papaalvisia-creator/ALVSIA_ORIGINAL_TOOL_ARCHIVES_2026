"""IkramTool V130 — Lua Intelligence Engine.

Full multi-tier decompile cascade + game-ready validator + honest reporting.

Detection (auto, no user input needed): IKRM wrapper, bare magic (standard
Lua 1B 4C 75 61 50..54 / LuaJIT 1B 4C 4A 01..03 / Luau 1B 62 75 6C 75),
magic behind a wrapper (PUBG/BGMI/UE4 length prefix, TPF loader, filler),
readable source, then Shannon entropy bands (<4.0 source, 4.0-6.5 bytecode,
6.5-7.5 lightly encrypted, >7.5 encrypted) to infer an encrypted chunk.

Tiers (tried in order, first fully-validated pass wins):
  T0 wrapper   strip a proven PUBG/BGMI/UE4 length prefix so every engine
                downstream sees a normal header.
  T4 pre-pass   XOR / additive key sweep, key lengths 1..12. That range is
               DERIVED, not chosen: _XOR_LENGTHS = range(1, header_len+1)
               where header_len is len(_LUA_HEADERS[0]). The old docstring
               claimed 1,2,4,8,16,32,64,128 - a ladder the code never ran.
                + string-extraction heuristic for encrypted candidates.
  T1 standard   mega_lua game engine (BGMI+standard+LuaJIT), unluac_rs,
                unluac.jar, luadec (if installed).
  T2 luajit     unluac_rs, unluac.jar, ljd rawdump->pseudoasm, luajit -bL.
  T3 disasm     luac -l -l listing, luajit -bL (-bl), r2 pdl (if installed).
  T5 large      >1MB files: scaled timeouts; chunk-split is refused honestly
                (unsafe on arbitrary protection) and reported as such.
  T6 fallback   best readable disassembly is SAVED as <name>_disassembled.lua
                and signalled so the UI can show the honest warn box.
  T7 fail       <name>_FAILED.txt with the full method-by-method trail.

Validator — 8 checks, ALL must pass (matches the game-ready standard):
  len > 50, >=5 lua keywords, garbage < 2%, question-marks < 1%, >=2 code
  structures, avg line 5..300, round-trip recompile with luac, no line
  mostly-binary.  Anything less is not a success — never kept, never shown.
"""

# Error log. Hard import on purpose: ikram_logger ships in this directory
# and its own entry points are non-raising by construction, so a missing
# logger is a broken install that must fail loudly at import -- not a
# silent no-op that would swallow every record of what went wrong.
import ikram_logger
import math
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import univ
import mega_lua as _mega

LUA_KEYWORDS = ("function", "local", "return", "end", "if", "then", "else",
                "while", "for", "do", "and", "or", "not", "nil", "true",
                "false", "repeat", "until", "break", "in")

STRUCTURE_TOKENS = ("function", "if", "while", "for", "repeat", "do", "end")

_LUA_MAGICS = (b"\x1bLuaQ", b"\x1bLuaR", b"\x1bLuaS", b"\x1bLuaT",
               b"\x1bLua", b"\x1bLJ")

# Full 12-byte headers used as known plaintext by the key sweep. A real chunk
# header is deterministic (signature, version, format byte, then either the
# machine-word size bytes on 5.1/5.2 or the LUAC_DATA tail on 5.3+), so using
# all 12 bytes instead of a 5-byte magic is what makes key recovery reliable
# and lets it cover key lengths up to 12 with zero guessing. Anything longer
# cannot be recovered from the header alone, and the sweep would rather report
# nothing than hand back a wrong key.
#
# The 5.1/5.2 layout is bytes[6:12] = endian/int/size_t/instruction/number/
# integral-flag; 5.3+ is the LUAC_DATA escape. These were hand-verified.
_LUA_DATA = b"\x19\x93\x0d\x0a\x1a\x0a"
_LUA_HEADERS = tuple(
    b"\x1bLua" + bytes((v,)) + b"\x00" + _LUA_DATA
    for v in (0x53, 0x54)
) + tuple(
    b"\x1bLua" + bytes((v,)) + b"\x00\x01\x04\x08\x04\x08\x00"
    for v in (0x51, 0x52)
) + (b"\x1bLJ\x01" + b"\x00" * 5, b"\x1bLJ\x02" + b"\x00" * 5)

# Recoverable key lengths are bounded by how much known plaintext exists, so
# the range is derived from the header length rather than hand-written. A
# 12-byte header pins a 12-byte repeating key completely; beyond that the
# remaining key bytes are not determined by anything we know, so guessing
# would only manufacture corrupt chunks. This is why the old 16/32/64/128
# entries were quietly dead: `_xor_key_recover` rejected them on sight.
_XOR_LENGTHS = tuple(range(1, len(_LUA_HEADERS[0]) + 1))

# How many distinct decryptions the sweep hands to the engine cascade. More than
# one matters because the cascade can only judge a candidate by decompiling it,
# and with a single candidate there was never a choice to make.
_MAX_SWEEP_CANDIDATES = 6

# Stamped into the decompile-FAILED report. Read from the
# VERSION file at call time, not hardcoded: this shipped as "v120" while the
# tool actually ran V121, so every failure report named a version the user was
# not running. Same reader the menu header uses, one source of truth.
def _version():
    import paths
    return paths.read_version()

# Offsets a wrapper may occupy before the real chunk starts. The offset is
# never trusted on its own: find_wrapper only accepts one where a real
# Lua/LuaJIT/Luau header actually parses, so PUBG Mobile / BGMI / UE4
# length prefixes, TPF-style loader blocks and fixed mod fillers are all
# handled by the same proof-based check.
_WRAPPER_SCAN = (1, 2, 3, 4, 5, 6, 7, 8, 12, 16, 24, 32, 48, 64, 96, 128, 256)

# Layer peeling scans its own offsets because `find_wrapper` only accepts an
# offset where a *readable* Lua header parses. An encrypted body has no
# readable header, so a wrapper in front of AES/zlib is invisible to it.
# Dense for the first 17 bytes (loaders use 1-4 byte magics), then wider.
_LAYER_SCAN = tuple(list(range(17)) + [24, 32, 48, 64, 96, 128, 192, 256])

# A file nests at most a handful of layers deep. The cap also stops a
# pathological input from spinning: every pass either peels one real layer
# or returns, so this is a hard ceiling on work, not a retry budget.
_MAX_LAYERS = 6


# ---------------------------------------------------------------- detection
def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    counts = {}
    for b in data:
        counts[b] = counts.get(b, 0) + 1
    n = len(data)
    return -sum(c / n * math.log2(c / n) for c in counts.values())


def entropy_band(e: float) -> str:
    if e < 4.0:
        return "source"
    if e < 6.5:
        return "standard bytecode"
    if e < 7.5:
        return "lightly encrypted"
    return "encrypted"


def _lua_family_at(head: bytes):
    """(family, kind) for a real Lua/LuaJIT/Luau header, else (None, None).

    Delegates to mega_lua._detect_dialect, the authoritative header reader.
    A bare \x1bLua\x53 prefix with a broken format byte or missing magic tail
    used to be accepted here, so find_wrapper() picked the wrong offset and
    the whole engine cascade ran against a fake header. Probe with a padded
    view because callers pass 12-byte slices and _detect_dialect wants 15.
    """
    if len(head) < 4:
        return None, None
    probe = head if len(head) >= 15 else head + b"\x00" * (15 - len(head))
    dia = _mega._detect_dialect(probe)
    if dia == "luajit":
        return "LuaJIT", "LuaJIT bytecode"
    if dia == "luau":
        return "Luau", "Luau bytecode"
    if dia and dia.startswith("lua") and len(dia) == 5:
        return "Lua 5.%s" % dia[4], "standard Lua bytecode"
    return None, None


def find_wrapper(data: bytes) -> int:
    """Byte offset where the real Lua chunk starts, 0 when there is no wrapper.

    Proves a candidate offset with a real family header instead of guessing:
    the bytes at that offset must parse as Lua/LuaJIT/Luau.
    """
    for off in _WRAPPER_SCAN:
        if off + 12 > len(data):
            break
        fam, _k = _lua_family_at(data[off:off + 12])
        if fam:
            return off
    return 0


def detect_report(data: bytes) -> dict:
    """Deep auto-detect -> family/dialect/entropy/kind/protection labels.

    Order: IKRM wrapper, then a bare magic, then a wrapped magic, then
    source, then encryption inference. Never guesses a family it cannot prove.
    """
    e = shannon_entropy(data)
    head = data[:12]
    report = {
        "family": None,
        "kind": "unknown",
        "entropy": round(e, 3),
        "band": entropy_band(e),
        "magic": head[:5].hex(),
        "wrapper": 0,
        "protection": None,
    }

    if not data:
        report["kind"] = "empty"
        return report

    # --- IKRM (IkramTool's own wrapper) — checked before everything else
    if data[:4] == b"IKRM":
        report["family"] = "IKRM"
        report["kind"] = "IKRM protected chunk"
        report["protection"] = "ikrm"
        return report


    # --- private / modified version byte (>=0x80)
    private_ver = _mega._private_version(head)
    if private_ver is not None:
        if head[:3] == b"\x1bLJ":
            report["family"] = "LuaJIT (private/modified)"
            report["kind"] = "private LuaJIT header (version 0x%02X)" % private_ver
        else:
            report["family"] = "Lua (private/modified)"
            report["kind"] = "private Lua header (version 0x%02X)" % private_ver
        report["protection"] = "modified-version"
        return report

    # --- bare magic
    fam, kind = _lua_family_at(head)
    if fam:
        report["family"] = fam
        report["kind"] = kind
        return report

    # --- magic behind a wrapper (PUBG/BGMI length prefix, TPF loader, filler)
    off = find_wrapper(data)
    if off:
        fam, kind = _lua_family_at(data[off:off + 12])
        report["family"] = fam
        report["kind"] = "%s (wrapped, %d-byte header)" % (kind, off)
        report["wrapper"] = off
        return report

    # --- readable source
    try:
        text = data[:4096].decode("utf-8", errors="strict")
        if _mega._looks_like_lua_source(text) or _mega._compiles_as_lua(text):
            report["family"] = "Lua source"
            report["kind"] = "readable Lua source"
            return report
    except (UnicodeDecodeError, ValueError) as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline.detect_report:224", _ikram_exc)
        pass

    # --- encrypted / obfuscated: infer from entropy + structure
    if e >= 6.5:
        report["family"] = None
        report["kind"] = "encrypted chunk (no readable header)"
        report["protection"] = "encrypted"
        return report

    # No magic, not source, not high entropy: still not trustworthy as a chunk,
    # so the key sweep must run and the report must not claim "unknown".
    report["family"] = None
    report["kind"] = "obfuscated chunk (no readable header)"
    report["protection"] = "obfuscated"
    return report


def _garbage_ratio(text: str) -> float:
    if not text:
        return 1.0
    bad = 0
    for ch in text[:4000]:
        o = ord(ch)
        if ch == "\ufffd" or (0 <= o < 9) or (0x0B <= o < 0x20):
            bad += 1
    return bad / min(len(text), 4000)


def _binary_line_ratio(text: str) -> float:
    """Fraction of non-empty lines that are mostly non-printable."""
    if not text:
        return 1.0
    total = bad = 0
    for ln in text.splitlines():
        if not ln.strip():
            continue
        total += 1
        if len(ln) and sum(1 for c in ln[:200] if ord(c) > 126 or ord(c) < 9) / max(1, len(ln)) > 0.1:
            bad += 1
    return bad / max(1, total)


def _structure_count(text: str) -> int:
    import re
    low = text.lower()
    count = 0
    for token in STRUCTURE_TOKENS:
        count += len(re.findall(r"\b%s\b" % token, low))
    return max(count, 0)


# A table key assignment at the head of a line. Pure data modules (PUBG's
# QuestConfig, UIConfig, task_ui_configs) are hundreds of lines of these and
# contain no function/if/for at all, so counting only control-flow tokens
# rejects their decompiles even when the output is perfect.
_TABLE_ASSIGN = re.compile(
    r"^\s*(?:local\s+)?(?:[A-Za-z_]\w*\s*=\s*[^=]|\[[^\]]+\]\s*=\s*[^=])",
    re.MULTILINE,
)


def _table_assign_count(text: str) -> int:
    return len(_TABLE_ASSIGN.findall(text or ""))


def validate(text: str, progress=None) -> dict:
    """Run the 8 checks; return check keys, score and passed flag."""
    text = text or ""
    if len(text) > _mega._HEAVY_TEXT_LIMIT:
        # 1.4M-line monster dumps take seconds per check: say so instead of
        # leaving the screen frozen on a run that is healthy.
        _phase(progress, "Validating decompiled source (%.1f MB)..."
               % (len(text) / 1e6))
    lines = [l for l in text.splitlines() if l.strip()]
    avg = (sum(len(l) for l in lines) / len(lines)) if lines else 0
    lower = text.lower()
    keywords = sum(k in lower for k in LUA_KEYWORDS)
    structures = _structure_count(text)
    assigns = _table_assign_count(text)
    roundtrip = _mega._compiles_as_lua(text)
    checks = {
        "len > 50": len(text) > 50,
        "keywords >= 5": keywords >= 5,
        "garbage < 2%": _garbage_ratio(text) < 0.02,
        "? < 1%": (text.count("?") / max(1, len(text))) < 0.01,
        "structures >= 2": structures >= 2 or assigns >= 2,
        "avg line 5..300": 5 <= avg <= 300,
        "round-trip recompile": roundtrip,
        "no binary lines": _binary_line_ratio(text) < 0.5,
    }
    # luac accepting the output is the authoritative validity signal. The
    # shape heuristics cannot outrank it: PUBG Mobile data modules such as
    # FaceIntroUIConfig (287 lines of one table literal, no control flow) score
    # 3 keywords and still recompile perfectly, so a hard keyword floor
    # reported good decompiles as broken. Garbage markers stay hard because
    # they mean the decompiler emitted junk luac happens to parse.
    soft = ("keywords >= 5", "structures >= 2", "avg line 5..300")
    hard_fail = [k for k, v in checks.items() if not v and k not in soft]
    passed = [k for k, v in checks.items() if v]
    return {
        "checks": checks,
        # top-level alias: older panels read this key directly
        "round-trip recompile": roundtrip,
        "passed": len(passed),
        "total": len(checks),
        "score": len(passed),
        "ok": not hard_fail,
        "soft_warnings": [k for k in soft if not checks[k]],
        "avg_line": round(avg, 1),
        "keywords": keywords,
        "structures": structures,
        "assigns": assigns,
        # measured ratios, so a FAILED report can show HOW far off a candidate
        # was instead of a bare PASS/FAIL with no context
        "garbage": _garbage_ratio(text),
        "qmarks": (text.count("?") / max(1, len(text))),
        "binary": _binary_line_ratio(text),
        "lines": len(lines),
    }


def validate_source(text: str) -> dict:
    """Gate for a file that is ALREADY readable Lua source.

    The 8-check validator exists to catch decompiler garbage. Running it on a
    genuine source file is the wrong test: a real data module (PUBG Mobile's
    pubgm_patch.lua is 32 lines of assignments plus one table) fails
    'keywords >= 5' and 'structures >= 2' while compiling perfectly. The
    question that actually matters for source is whether luac accepts it and
    whether it is text at all, so that is what gets checked here.
    """
    text = text or ""
    checks = {
        "not empty": bool(text.strip()),
        "no binary lines": _binary_line_ratio(text) < 0.5,
        "garbage < 2%": _garbage_ratio(text) < 0.02,
        "compiles with luac": _mega._compiles_as_lua(text),
    }
    passed = [k for k, v in checks.items() if v]
    return {"checks": checks, "passed": len(passed), "total": len(checks),
            "score": len(passed), "ok": len(passed) == len(checks)}


def _quality_label(score: int, total: int = 8) -> str:
    if score >= total:
        return "Excellent"
    if score >= total - 1:
        return "Very good"
    if score >= total - 2:
        return "Good"
    if score >= total - 3:
        return "Fair"
    return "Poor"


# ------------------------------------------------------------- tool lookup
_TOOL_DIR = Path(__file__).resolve().parent
DEPS_DIR = _TOOL_DIR / "deps"
LJD_DIR = DEPS_DIR / "ljd"


# wanted name -> bundled file stem, per platform.  The two payloads disagree:
# Linux ships renamed ELF binaries at the tool root (lua_patched/luac_patched)
# and Windows ships plain PE names under lua_bin/windows.  One flat table that
# hard-coded the Linux names silently resolved to nothing on Windows, so the
# bundled luac.exe was never found and the T3 `luac -l -l` tier could not run.
# It also mapped `luajit` -> lua_patched, which is PUC Lua 5.3 and rejects
# -bL outright; that alias is gone.  lua_patched is not a LuaJIT.
_BUNDLED_LUA_ALIASES = {
    "nt": {"luac": "luac", "luac5.1": "luac", "luac5.2": "luac",
           "luac5.3": "luac", "luac5.4": "luac", "lua": "lua"},
    "posix": {"luac": "luac_patched", "luac5.1": "luac_patched",
              "luac5.2": "luac_patched", "luac5.3": "luac_patched",
              "luac5.4": "luac_patched", "lua": "lua_patched"},
}


def _resolve_bundled_lua(name: str):
    """Prefer the tool's own bundled Lua binaries when the host lacks them.

    Linux ELF tools live at the tool root; Windows PE tools live under
    lua_bin/windows. Trying the ELF name first on Windows would return a file
    the OS cannot execute, so the search order is platform-specific - and the
    Windows branch is not searched on POSIX, where an .exe is not runnable.
    """
    table = _BUNDLED_LUA_ALIASES["nt" if os.name == "nt" else "posix"]
    cand = table.get(name, name)
    if os.name == "nt":
        order = [(_TOOL_DIR / "lua_bin" / "windows", cand + ".exe"),
                 (_TOOL_DIR / "lua_bin" / "windows", cand),
                 (_TOOL_DIR, cand + ".exe"),
                 (_TOOL_DIR, cand)]
    else:
        order = [(_TOOL_DIR, cand),
                 (_TOOL_DIR / "lua_bin" / "linux", cand),
                 (_TOOL_DIR / "lua_bin" / "linux", cand + ".exe")]
    for base, fname in order:
        p = Path(base) / fname
        if p.is_file():
            return str(p)
    return None


# NOTE: lua_ops.pyc (detect_lua / compile_lua / decompile_lua / compile_batch)
# ships in the payload but has NO importer in the whole tree. Everything it
# does is already done better here and in mega_lua: detection by _lua_family_at
# (full 5-byte family, not just a magic prefix), compilation by the bundled
# luac_patched, decompilation by unluac_rs/unluac.jar/ljd. It is left in the
# bundle untouched rather than deleted, but importing it would only add a
# weaker second implementation of the same three jobs.
def _host_luac(ver: str):
    """Exact Lua compiler for one version.

    luac_patched is a 5.3 compiler, so it only satisfies 5.3. A bare `luac` is
    whatever update-alternatives points at, so it counts only when `luac -v`
    actually reports the wanted version - never just because a file exists.
    """
    exact = shutil.which("luac" + ver)
    if exact:
        return exact
    if ver == "5.3":
        bundled = _resolve_bundled_lua("luac")
        if bundled:
            return bundled
    p = shutil.which("luac")
    if not p:
        return None
    try:
        out = subprocess.run([p, "-v"], capture_output=True, timeout=15)
        txt = (out.stdout + out.stderr).decode("utf-8", "replace")
    except Exception:
        return None
    return p if ver in txt else None


def _host_luajit():
    """A real LuaJIT. lua_patched is 5.3 PUC-Lua, so it does not count."""
    return shutil.which("luajit")


def _on_path(name: str) -> bool:
    return shutil.which(name) is not None


def _call(cmd, timeout=60, data=None):
    try:
        p = subprocess.run(cmd, input=data, capture_output=True, timeout=timeout)
        return p.returncode, p.stdout.decode("utf-8", errors="replace")
    except subprocess.TimeoutExpired:
        return -1, "timed out after %ss" % timeout
    except Exception as e:
        ikram_logger.log_exc("lua_pipeline._call:387", e)
        return -1, str(e)


def _luac_disasm(data: bytes) -> list:
    """Built-in `luac -l -l` bytecode listing for standard chunks.

    The chunk is written to a temp file instead of piped through `-`. Windows
    luac opens stdin in text mode and aborts with "truncated precompiled
    chunk" on any bytecode containing 0x0D or 0x1A, so the piped form failed
    on every Windows box even with a correct compiler.
    """
    out = []
    tmpdir = tempfile.mkdtemp(prefix="ikram_luac_")
    src = os.path.join(tmpdir, "chunk.luac")
    try:
        with open(src, "wb") as fh:
            fh.write(data)
        seen = set()
        for name in ("luac", "luac5.3", "luac5.4", "luac5.2", "luac5.1"):
            exe = _resolve_bundled_lua(name) or shutil.which(name)
            if not exe or exe in seen:
                continue
            seen.add(exe)
            rc, txt = _call([exe, "-l", "-l", src], timeout=40)
            if rc == 0 and txt and "main <" in txt:
                out.append((name, txt))
                break
    except Exception as e:
        ikram_logger.log_exc("lua_pipeline._luac_disasm", e)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    return out


def _luajit_disasm(data: bytes) -> list:
    """Readable bytecode listing via `luajit -bL` (works for any LuaJIT chunk).

    Output goes to a real temp file. The shipped version wrote to
    `/dev/stdout`, which does not exist on Windows, so the listing tier was a
    guaranteed no-op for every Windows and non-rooted Termux install.
    """
    luajit = _resolve_bundled_lua("luajit") or shutil.which("luajit")
    if not luajit:
        return []
    res = []
    tmpdir = tempfile.mkdtemp(prefix="ikram_luajit_")
    src = os.path.join(tmpdir, "chunk.luac")
    try:
        with open(src, "wb") as fh:
            fh.write(data)
        for flag, label in (("-bL", "luajit -bL"), ("-bl", "luajit -bl")):
            dst = os.path.join(tmpdir, "listing.txt")
            try:
                if os.path.exists(dst):
                    os.remove(dst)
            except OSError:
                pass
            try:
                rc, err = _call([luajit, flag, src, dst], timeout=40)
                txt = ""
                if os.path.exists(dst):
                    with open(dst, "rb") as fh:
                        txt = fh.read().decode("utf-8", errors="replace")
                # -bL prints a "-- BYTECODE --" header plus `=>` arrows; -bl is
                # a flat numeric dump.  Require a marker so a LuaJIT usage
                # error written into the listing file is not reported as a
                # successful disassembly.
                if rc == 0 and txt and ("----" in txt or "->" in txt
                                        or "BYTECODE" in txt):
                    res.append((label, txt))
            except Exception as e:
                ikram_logger.log_exc("lua_pipeline._luajit_disasm", e)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    return res



def _unluac_rs(data: bytes, timeout=120) -> str | None:
    """Bundled Rust unluac_rs — the fastest standard-Lua tier.

    Same shape as _unluac_jar: returns text or None. Kept as its own tier so a
    meg_lua miss does not cost the whole file when the Rust engine can read it.
    """
    exe = _mega.UNLUAC_RS
    if not Path(exe).exists():
        return None
    fd, tmp = tempfile.mkstemp(suffix=".luac")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        p = subprocess.run([str(exe), "-i", tmp],
                           capture_output=True, timeout=timeout)
        if p.returncode != 0:
            return None
        txt = p.stdout.decode("utf-8", errors="replace")
        if not txt.strip():
            return None
        if "function " not in txt and "local " not in txt and txt.strip().count("\n") < 2:
            return None
        return txt
    except subprocess.TimeoutExpired:
        return None
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._unluac_rs:445", _ikram_exc)
        return None
    finally:
        try:
            os.unlink(tmp)
        except OSError as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._unluac_rs:451", _ikram_exc)
            pass


def _unluac_jar(data: bytes, timeout=90) -> str | None:
    jar = _mega.UNLUAC_JAR
    if not Path(jar).exists():
        return None
    fd, tmp = tempfile.mkstemp(suffix=".luac")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        p = subprocess.run(
            ["java", "-jar", str(jar), tmp],
            capture_output=True, timeout=timeout)
        if p.returncode != 0:
            return None
        txt = p.stdout.decode("utf-8", errors="replace")
        if not txt.strip():
            return None
        if "function " not in txt and "local " not in txt and txt.strip().count("\n") < 2:
            return None
        return txt
    except subprocess.TimeoutExpired:
        return None
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._unluac_jar:477", _ikram_exc)
        return None
    finally:
        try:
            os.unlink(tmp)
        except OSError as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._unluac_jar:483", _ikram_exc)
            pass


def _ljd_decompile(data: bytes, timeout=60) -> str | None:
    """LuaJIT decompiler (Andrian Nord ljd) via bundled deps/ljd.

    Mirrors deps/ljd/main.py.decompile() exactly: parse with an
    on_parse_header callback that selects the LuaJIT opcode table, then
    ast.builder.build -> validator/mutator passes -> slotworks/unwarper ->
    lua.writer. The earlier variant imported a non-existent ljd.tools module
    and never initialised the opcode table, so every real .lj returned None.
    """
    if not LJD_DIR.is_dir():
        return None
    import sys
    try:
        old = list(sys.path)
        sys.path.insert(0, str(LJD_DIR))
        import ljd
        from ljd.rawdump import parser, code
        from ljd.pseudoasm import instructions as pseudoasm_instructions
        import ljd.ast.builder as builder
        import ljd.ast.validator as validator
        import ljd.ast.mutator as mutator
        import ljd.ast.locals as locals_m
        import ljd.ast.slotworks as slotworks
        import ljd.ast.unwarper as unwarper
        import ljd.lua.writer as lua_writer
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._ljd_decompile:setup", _ikram_exc)
        return None
    finally:
        sys.path[:] = old

    # ljd internals keep numpy-ish global state; initialise once per version.
    _ljd_bc_version = {"v": None}

    def _set_luajit_version(bc_version):
        if _ljd_bc_version["v"] == bc_version:
            return
        _ljd_bc_version["v"] = bc_version
        if bc_version == 2.0:
            from ljd.rawdump.luajit.v2_0.luajit_opcode import _OPCODES as opcodes
        elif bc_version == 2.1:
            from ljd.rawdump.luajit.v2_1.luajit_opcode import _OPCODES as opcodes
        else:
            raise Exception("unsupported LuaJIT bytecode version %r" % bc_version)
        ljd.CURRENT_VERSION = bc_version
        code.init(opcodes)
        builder.init()
        pseudoasm_instructions.init()

    def _on_parse_header(preheader):
        if preheader.version == 1:
            _set_luajit_version(2.0)
        elif preheader.version == 2:
            _set_luajit_version(2.1)
        elif preheader.version == 130:
            _set_luajit_version(2.1)
        else:
            raise Exception("unsupported bytecode version %r" % preheader.version)

    import io as _io, tempfile, os, contextlib
    tmp = tempfile.NamedTemporaryFile(prefix="ljd_", suffix=".luac", delete=False)
    try:
        tmp.write(data)
        tmp.close()
        header, prototype = None, None
        with contextlib.redirect_stderr(_io.StringIO()), contextlib.redirect_stdout(_io.StringIO()):
            header, prototype = parser.parse(tmp.name, _on_parse_header)
            if not prototype:
                return None
            ast = builder.build(header, prototype)
            validator.validate(ast, warped=True)
            mutator.pre_pass(ast)
            validator.validate(ast, warped=True)
            locals_m.mark_locals(ast)
            try:
                slotworks.eliminate_temporary(ast, identify_slots=True)
            except AssertionError:
                pass
            unwarper.unwarp(ast, False)
            locals_m.mark_local_definitions(ast)
            mutator.primary_pass(ast)
            validator.validate(ast, warped=False)
            locals_m.mark_locals(ast, alt_mode=True)
            locals_m.mark_local_definitions(ast)
        buf = _io.StringIO()
        lua_writer.write(buf, ast)
        txt = buf.getvalue()
        return txt if txt and txt.strip() else None
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._ljd_decompile:run", _ikram_exc)
        return None
    finally:
        try:
            os.unlink(tmp.name)
        except OSError as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._ljd_decompile:532", _ikram_exc)
            pass


def _luadec(data: bytes, timeout=90) -> str | None:
    """luadec (Lua 5.x bytecode decompiler) — optional, only if on PATH.

    Luadec's CLI is `luadec [options] file.lua`, so the chunk goes to a temp
    file rather than stdin. Not bundled: it is a large C build, so it is only
    used on devices where the user installed it themselves.
    """
    exe = shutil.which("luadec")
    if not exe:
        return None
    fd, tmp = tempfile.mkstemp(suffix=".luac")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        p = subprocess.run([exe, tmp], capture_output=True, timeout=timeout)
        if p.returncode != 0:
            return None
        txt = p.stdout.decode("utf-8", errors="replace")
        if not txt.strip():
            return None
        if "function " not in txt and "local " not in txt and txt.strip().count("\n") < 2:
            return None
        return txt
    except subprocess.TimeoutExpired:
        return None
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._luadec:562", _ikram_exc)
        return None
    finally:
        try:
            os.unlink(tmp)
        except OSError as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._luadec:568", _ikram_exc)
            pass


def _string_extraction(data: bytes) -> list:
    """Extract printable sequences (min 4 chars), keep the long ones."""
    import re
    seqs = re.findall(rb"[\x20-\x7e]{4,}", data)
    return [s.decode("latin-1") for s in seqs]


def _layer_plausible(cand: bytes, ik) -> bool:
    """Would peeling continue from `cand`, or has a bare chunk surfaced?

    A layer can legitimately reveal another layer instead of the final chunk,
    so a zlib container or a fresh IKRM header counts as progress. Anything
    else is a wrong guess and is dropped before it can corrupt a later pass.
    """
    if not cand or len(cand) < 8:
        return False
    if _lua_family_at(cand[:12])[0]:
        return True
    if ik is not None and ik.is_protected(cand):
        return True
    if _mega._looks_like_zlib_container(cand):
        return True
    return False


def _decode_text_wrapper(data: bytes):
    """Undo a base64 / base64url / hex text envelope. Returns (bytes, label).

    Plenty of "encrypted" mod files are not encrypted at all - they are the
    chunk run through base64 (often then zlib'd) so the file greps clean. That
    is fully reversible with no key, so it belongs ahead of every key-recovery
    pass. The test is deliberately strict: the whole buffer must be in the
    alphabet, long enough to hold a chunk, and the result must be smaller, so
    a Lua source file can never be mistaken for an envelope.
    """
    body = data.strip()
    if len(body) < 64:
        return None, ""
    sample = body[:4096]
    hexset = b"0123456789abcdefABCDEF\r\n \t"
    if len(body) >= 128 and all(c in hexset for c in sample):
        try:
            out = bytes.fromhex(body.decode("ascii", "ignore"))
        except Exception as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._decode_text_wrapper:735", _ikram_exc)
            out = None
        if out and len(out) >= 20:
            return out, "hex decoded"
    b64set = (b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
              b"+/=_-")
    core = body.rstrip(b"=")
    if all(c in b64set for c in sample) and all(c in b64set for c in core[-64:]):
        import base64 as _b64
        for name, alt in (("base64", b"+/"), ("base64url", b"-_")):
            fixed = body.replace(b"-", b"+").replace(b"_", b"/") if name == "base64url" else body
            pad = b"=" * (-len(fixed) % 4)
            try:
                out = _b64.b64decode(fixed + pad, validate=False)
            except Exception as _ikram_exc:
                ikram_logger.log_exc("lua_pipeline._decode_text_wrapper:752", _ikram_exc)
                continue
            if out and len(out) >= 20 and b"\x1bLua" in out[:64]:
                return out, "%s decoded with lua header" % name
            if out and len(out) >= 20 and (out[:1] in (b"\x78", b"\x1f")
                                          or out[:2] == b"BZ"
                                          or out[:4] == b"\x28\xb5\x2f\xfd"):
                return out, "%s decoded (compressed body)" % name
        # Last resort: a base64 body whose plaintext header is itself masked.
        # Hand it back only when the decode is clearly not printable text, so
        # a base64-encoded SOURCE file still works through the source path.
        fixed = body
        pad = b"=" * (-len(fixed) % 4)
        try:
            out = _b64.b64decode(fixed + pad, validate=False)
        except Exception:
            out = None
        if out and len(out) >= 20 and b"\x1bLua" in out[:4096]:
            return out, "base64 decoded"
    return None, ""


def _inflate_at(data: bytes, off: int):
    """Inflate a zlib stream that starts at `off`. Returns bytes or None.

    wbits 15 is a zlib wrapper, -15 is raw deflate, 47 auto-detects gzip.
    The multi-section reconstruction is the fallback for files that store
    several deflate blocks in one container instead of one framed stream.
    """
    if off >= len(data):
        return None
    try:
        import zlib
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._inflate_at:609", _ikram_exc)
        return None
    for wbits in (15, -15, 47):
        try:
            d = zlib.decompressobj(wbits)
            out = d.decompress(data[off:]) + d.flush()
            if out:
                return out
        except Exception as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._inflate_at:618", _ikram_exc)
            continue
    # Every other container a modder is likely to reach for. The magic test is
    # done on the bytes at `off`, so a loader prefix in front of the container
    # costs nothing extra.
    tail = data[off:]
    try:
        if tail[:3] == b"BZh":
            import bz2
            return bz2.decompress(tail)
        if tail[:6] == b"\xfd7zXZ\x00" or tail[:5] == b"\x5d\x00\x00\x00\x01":
            import lzma
            return lzma.decompress(tail)
        if tail[:4] == b"\x28\xb5\x2f\xfd":
            try:
                import zstandard as _zstd
            except Exception:
                return None
            return _zstd.ZstdDecompressor().decompressobj().decompress(tail)
        if tail[:4] == b"\x04\x22\x4d\x18":
            try:
                import lz4.frame as _lz4
            except Exception:
                return None
            return _lz4.decompress(tail)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._inflate_at:640", _ikram_exc)
    try:
        out = _mega._reconstruct_zlib_sections(data[off:])
        if out:
            return out
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._inflate_at:625", _ikram_exc)
        pass
    return None


def _aes_key_at(data: bytes, off: int):
    """Cheaply test which known AES key, if any, decrypts a header at `off`.

    Only the first 32 bytes are decrypted. A chunk's first bytes are its
    signature and version, so 32 bytes is enough to prove the key is right,
    and it turns a full-file decrypt per candidate into a 32-byte one. That
    matters: the scan visits ~25 offsets x 7 keys x 2 modes, which is 350
    full-file decrypts if the probe is skipped.
    """
    head = data[off:off + 32]
    if len(head) < 32:
        return None
    try:
        from Crypto.Cipher import AES
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._aes_key_at:645", _ikram_exc)
        return None
    for key in _mega._AES_KEYS:
        for mode, mk in (("ECB", lambda k: AES.new(k, AES.MODE_ECB)),
                         ("CBC", lambda k: AES.new(k, AES.MODE_CBC,
                                                   data[off:off + 16]))):
            try:
                probe = mk(key).decrypt(head)
            except Exception as _ikram_exc:
                ikram_logger.log_exc("lua_pipeline._aes_key_at:654", _ikram_exc)
                continue
            if _lua_family_at(probe[:12])[0]:
                return key, mode
    return None


def _aes_body_at(data: bytes, off: int, key: bytes, mode: str):
    """Full AES decrypt of `data[off:]` with an already-proven key/mode."""
    try:
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import unpad
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._aes_body_at:667", _ikram_exc)
        return None
    body = data[off:]
    if not body:
        return None
    try:
        if mode == "CBC":
            iv, body = body[:16], body[16:]
            if len(body) < 16 or len(body) % 16:
                return None
            return unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(body), 16)
        full = body[: len(body) - len(body) % 16] if len(body) % 16 else body
        if len(full) < 16:
            return None
        return unpad(AES.new(key, AES.MODE_ECB).decrypt(full), 16)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._aes_body_at:683", _ikram_exc)
        return None


def _peel_layers(data: bytes, ik) -> tuple:
    """Peel stacked protection until a bare chunk remains.

    Real game files stack layers: an IKRM container whose payload is itself
    AES-encrypted, a loader prefix in front of a compressed body, a wrapper
    around an IKRM blob. The V118 pipeline unwrapped exactly one layer, so
    every composed case failed while each single layer passed.

    Each pass peels one layer and re-validates before looping, so a wrong
    guess is discarded instead of being compounded by the next pass. The
    peel order is fixed and cheapest-first: bare chunk, IKRM, then prefix
    scan (IKRM / zlib / AES). Returns (chunk_or_None, [labels]).
    """
    notes = []
    for _ in range(_MAX_LAYERS):
        if not data:
            return None, notes
        if _lua_family_at(data[:12])[0]:
            return data, notes
        if ik is not None and ik.is_protected(data):
            nxt = ik.try_unwrap(data)
            if nxt:
                notes.append("IKRM container unwrapped")
                data = nxt
                continue
        peeled = None
        for off in _LAYER_SCAN:
            if off >= len(data):
                break
            body = data[off:]
            if ik is not None and ik.is_protected(body):
                nxt = ik.try_unwrap(body)
                if nxt:
                    peeled = ("IKRM container unwrapped @%d" % off, nxt)
                    break
            if (off == 0) or body[:4] in (b"BZh9", b"\xfd7zXZ", b"\x28\xb5\x2f\xfd",
                                          b"\x04\x22\x4d\x18"):
                dec_bytes, dec_label = _decode_text_wrapper(body)
                if dec_bytes and (_layer_plausible(dec_bytes, ik)
                                  or detect_report(dec_bytes)["kind"]
                                  == "readable Lua source"):
                    peeled = ("%s @%d" % (dec_label, off), dec_bytes)
                    break
            if (body[:1] in (b"\x78", b"\x1f", b"\x5e")
                    or body[:3] == b"BZh"
                    or body[:6] == b"\xfd7zXZ\x00"
                    or body[:4] in (b"\x28\xb5\x2f\xfd", b"\x04\x22\x4d\x18")):
                nxt = _inflate_at(data, off)
                if nxt and _layer_plausible(nxt, ik):
                    peeled = ("compressed stream inflated @%d" % off, nxt)
                    break
            hit = _aes_key_at(data, off)
            if hit:
                key, mode = hit
                nxt = _aes_body_at(data, off, key, mode)
                if nxt and _layer_plausible(nxt, ik):
                    peeled = ("AES-%s %s decrypted @%d"
                              % (mode, key[:8].hex(), off), nxt)
                    break
        if peeled is None:
            break
        notes.append(peeled[0])
        data = peeled[1]
    if _lua_family_at(data[:12])[0]:
        return data, notes
    return None, notes


def _rolling_decrypts(data: bytes) -> list:
    """Chained ("rolling") ciphers that _xor_sweep can never express.

    _xor_sweep only tries REPEATING keys (enc[i] = plain[i] ^ key[i%n]) and
    additive equivalents. A common modder variant instead chains each byte off
    its neighbour, which no key length can represent. There are four real
    permutations, and every one of them is a single linear pass with no key
    search at all:

        xor / enc-chain : enc[i] = plain[i] ^ enc[i-1]   enc[-1] = 0
        xor / plain-chain: enc[i] = plain[i] ^ plain[i-1] plain[-1] = 0
        add / enc-chain : enc[i] = plain[i] + enc[i-1]   mod 256
        add / plain-chain: enc[i] = plain[i] + plain[i-1] mod 256

    The first and third are self-inverting straight off the ciphertext. The
    second and fourth decrypt as a forward recurrence once the first plaintext
    byte is known - and for these the seed is forced, because plain[-1] == 0
    means plain[0] == enc[0].

    All four cost one pass each, so they are always tried ahead of the
    offset x key-length grid, which is O(offsets x key_lengths x headers x 2).
    Every candidate is confirmed with the same _loads_ok gate the repeating
    sweep uses, so a lucky first-header alignment cannot pass as a real chunk.

    Returns [(label, plaintext)] for each permutation that both yields a
    recognised Lua family AND loads as a real chunk.
    """
    out = []
    if len(data) < 12 or _lua_family_at(data[:12])[0]:
        return out                      # bare chunk, or too short to chain

    variants = []
    # A chain is seeded by one byte, and modders rarely pick 0. The seed is
    # not a secret: for the ciphertext chain plain[0] = enc[0] ^ seed, so any
    # candidate header byte pins it exactly. Deriving the seed from every known
    # header turns 4 blind guesses into 4 x (headers + 1) certain ones.
    seeds = {0}
    for op, hdr in (("xor", h) for h in _LUA_HEADERS):
        seeds.add(data[0] ^ hdr[0])
    for op, hdr in (("add", h) for h in _LUA_HEADERS):
        seeds.add((data[0] - hdr[0]) & 0xFF)
    for op in ("xor", "add"):
        for seed in sorted(seeds):
            # chain off CIPHERTEXT: previous encrypted byte
            v = bytearray(len(data))
            prev = seed
            for i, byte in enumerate(data):
                v[i] = (byte ^ prev) if op == "xor" else (byte - prev) & 0xFF
                prev = byte
            variants.append(("%s rolling (ciphertext chain, seed %#04x)" % (op, seed),
                             bytes(v)))
        # chain off PLAINTEXT: previous recovered plaintext byte. plain[0] is
        # forced to enc[0] (the previous plaintext byte is 0), so this chain
        # carries no free seed.
        v = bytearray(len(data))
        prev = 0
        for i, byte in enumerate(data):
            v[i] = (byte ^ prev) if op == "xor" else (byte - prev) & 0xFF
            prev = v[i]
        variants.append(("%s rolling (plaintext chain)" % op, bytes(v)))

    for label, cand in variants:
        if _lua_family_at(cand[:12])[0] and _mega._loads_ok(cand):
            out.append((label, cand))
    return out


# ------------------------------------------------------ stripped-header XOR
# The header (12 bytes) is the cheapest known plaintext there is, but modders
# who strip it still leave the body's first prototype prefix in the clear.
# 04 04 04 08 is the common Lua 5.3/5.4 body crib and pins the first four key
# bytes; the header's word-size window then pins byte five, so a 5- or 6-byte
# key costs a few hundred probes, not 256^n.
_STRIP_CRIB = b"\x04\x04\x04\x08"
_STRIP_HEADERS = tuple(h for h in _LUA_HEADERS if h[4] in (0x53, 0x54))


def _strip_key_byte(enc: int, plain: int, mode: str) -> int:
    return (enc ^ plain) if mode == "xor" else (enc - plain) & 0xFF


def _stripped_header_recover(data: bytes) -> list:
    """Recover a chunk whose 12-byte header was deleted, optionally under a
    repeating XOR/additive key. Returns [(label, full_chunk)]."""
    out = []
    if len(data) < 24:
        return out

    # Plain stripped body: put a matching header back and validate.
    if data[:4] == _STRIP_CRIB:
        for hdr in _STRIP_HEADERS:
            cand = hdr + data
            if _mega._loads_ok(cand):
                out.append(("stripped header restored", cand))
        if out:
            return out

    for mode in ("xor", "add"):
        for key_len in range(1, 7):
            if key_len > len(data) - 4:
                break
            head = bytearray(key_len)
            for i in range(min(4, key_len)):
                head[i] = _strip_key_byte(data[i], _STRIP_CRIB[i], mode)
            keys = []
            if key_len <= 4:
                keys.append(bytes(head))
            else:
                # body[4] must be a native word size (4 or 8); body[5+] is not
                # constrained by the header check, so 6-byte keys stay bounded
                # to 2 * 256 candidates.
                for b4 in (4, 8):
                    head[4] = _strip_key_byte(data[4], b4, mode)
                    if key_len == 5:
                        keys.append(bytes(head))
                    else:
                        for b5 in range(256):
                            head[5] = b5
                            keys.append(bytes(head[:6]))
            for key in keys:
                if not any(key):
                    continue
                body = _decrypt_prefix(data, key, key_len, mode)
                for hdr in _STRIP_HEADERS:
                    cand = hdr + body
                    if not _chunk_body_ok(cand, hdr):
                        continue
                    # The crib pins body[0:4] and we set body[4] to a legal
                    # word size, so _chunk_body_ok passes by construction for
                    # 5/6-byte keys. The real filter is whether the BGMI
                    # converter finds a payload; that is pure Python, while
                    # _loads_ok falls back to a subprocess probe on garbage.
                    try:
                        std = _mega._bgmi_to_std(cand)
                    except Exception:
                        std = b""
                    if not (std and _mega._std_has_payload(std)):
                        continue
                    if not _mega._loads_ok(cand):
                        continue
                    out.append(("%s stripped-header key (len %d)"
                                % (mode.upper(), key_len), cand))
                    if len(out) >= _MAX_SWEEP_CANDIDATES:
                        return out
    return out


def _validate_decrypted_output(dec: bytes, original_size: int) -> bool:
    """Security gate: reject decrypted candidates that are structurally or
    content-wise implausible before they ever reach the engine cascade.

    The authoritative test is structural, not textual. A correctly decrypted
    game chunk is bytecode: its body is binary, so requiring the whole buffer
    to read as UTF-8 text with Lua keywords rejected every real BGMI chunk -
    rolling-XOR and additive-pipeline students were recovered correctly and
    then thrown away one line before the decompiler saw them.

    The order is: signature, then "does the body actually load". Only when the
    chunk does NOT load is the text heuristic consulted, so an all-text wrapper
    (a base64 blob, a stub loader) still gets rejected instead of being run
    through six decompilers as noise.
    """
    if len(dec) < 20:
        return False
    if not _lua_family_at(dec[:12])[0]:
        return False
    try:
        if _mega._loads_ok(dec):
            return True
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._validate_decrypted_output:930", _ikram_exc)
    try:
        text = dec.decode("utf-8")
    except UnicodeDecodeError:
        return False
    binary_ratio = sum(1 for b in dec if b < 9 or (b > 13 and b < 32)) / len(dec)
    if binary_ratio > 0.05:
        return False
    if not any(k in text.lower() for k in ("function", "local", "return", "end", "if", "then")):
        return False
    return True


def _xor_sweep(data: bytes) -> list:
    """Tier-4 sweep: recover repeating XOR/additive keys against known lua
    headers, at the file start and at a few early offsets. Returns
    [(label, dec)] where dec is the bare chunk with any prefix dropped.

    The prefix is dropped on purpose. A real protected game file is a wrapper
    followed by an encrypted body, so the bytes from `offset` onward ARE the
    chunk: keeping the wrapper in place would leave the engines looking at
    wrapper+chunk, which no decompiler accepts. At offset 0 this is
    byte-identical to decrypting the whole file.

    Security: every candidate is validated through _validate_decrypted_output
    before it is accepted, so garbage decryption results never reach the
    engine cascade.
    """
    found = []
    if _lua_family_at(data[:12])[0]:
        return found            # already a bare chunk: nothing to decrypt
    # Rolling keys are tried first: they cost two linear passes total, so
    # putting them ahead of the offset x key-length grid means the cheap
    # common case is answered before the expensive search begins.
    for label, dec in _rolling_decrypts(data):
        if _validate_decrypted_output(dec, len(data)):
            found.append((label, dec))
        if len(found) >= _MAX_SWEEP_CANDIDATES:
            return found
    # Header-stripped chunks come next: they are already validated inside the
    # recovery path, and they cannot be found by the header sweep because the
    # header it keys against has been deleted.
    for label, dec in _stripped_header_recover(data):
        found.append((label, dec))
        if len(found) >= _MAX_SWEEP_CANDIDATES:
            return found
    # Offsets are dense for the first 16 bytes on purpose: loaders put a
    # 1/2/3/4-byte magic in front of the body, and a power-of-two list simply
    # skipped a 3-byte "TPF" header. After that the steps widen, since large
    # prefixes are rare and each offset costs a full key search.
    for offset in list(range(17)) + [24, 32, 48, 64, 96, 128, 192, 256]:
        if offset + 4 > len(data):
            break
        window = data[offset:]
        # key_len is the OUTER loop on purpose. Trying every header at
        # key_len=1 before touching key_len=8 is what stops the sweep from
        # settling on a longer key that merely *looks* like a valid header:
        # assuming the wrong version byte mangles that one byte and the size
        # field, and the resulting chunk still parses far enough to slip past
        # a header check while carrying corrupted bytes.
        for key_len in _XOR_LENGTHS:
            if key_len > len(window):
                break
            for plain in _LUA_HEADERS:
                if len(plain) > len(window):
                    continue
                for mode, fn in (("xor", _mega._xor_key_recover),
                                 ("add", _mega._add_key_recover)):
                    key = fn(window, plain, key_len)
                    if key is None:
                        continue
                    if not any(key):
                        continue          # all-zero key is a no-op, not a decrypt
                    # Decrypt a 64-byte probe first. A wrong key dies here for
                    # the price of 64 byte-ops, so the full-file pass (which
                    # costs minutes on a 200 KB chunk across this grid) only
                    # ever runs for candidates the header and the standard
                    # size block both already agree with.
                    probe = _decrypt_prefix(window[:64], key, key_len, mode)
                    if not _chunk_body_ok(probe, plain):
                        continue
                    dec = _decrypt_prefix(window, key, key_len, mode)
                    if not _mega._loads_ok(dec):
                        continue      # plausible header, but the body is not real
                    found.append(("%s key (len %d)" % (mode.upper(), key_len),
                                  dec))
                    if len(found) >= _MAX_SWEEP_CANDIDATES:
                        return found
                    break            # take the first hit at this key_len only
    return found


def _decrypt_prefix(window: bytes, key: bytes, key_len: int, mode: str) -> bytes:
    """Apply a repeating key to `window`. Only the bytes given are touched."""
    out = bytearray(window)
    for i in range(len(out)):
        k = key[i % key_len]
        out[i] = (out[i] ^ k) if mode == "xor" else (out[i] - k) & 0xFF
    return bytes(out)


def _chunk_body_ok(head: bytes, plain: bytes) -> bool:
    """Reject a decryption that lines up the signature but nothing after it.

    The 12-byte known-plaintext header ends exactly where a Lua chunk stores
    its size/endianness block, so the five bytes at offset 12 are free extra
    proof for 5.3/5.4 chunks: every real build puts a 4 or an 8 there (int,
    size_t, instruction, lua_Integer, lua_Number - all native word sizes).
    A wrong key lands in that window at 1-in-2^35 odds.
    """
    if len(head) < 20:
        return False
    if not head.startswith(plain[:len(plain)]):
        return False
    if plain[4] in (0x53, 0x54):
        return all(head[12 + i] in (4, 8) for i in range(5))
    return True


# ---------------------------------------------------------------- pipeline
def run(src, out_dir, progress=None) -> dict:
    """Public entry point. Signature and return contract are unchanged.

    The body lives in _run_impl purely so the scratch chunks it writes can be
    removed on EVERY exit path. The cascade returns from inside its own loop on
    success, so cleanup that sat at the end of the body never ran - leaving
    _tmp_*_peel.luac / _tmp_*_strip.luac / _tmp_*_dec.luac next to the output
    on every successful decompile.
    """
    scratch = []
    try:
        return _run_impl(src, out_dir, progress, scratch)
    finally:
        for _t in scratch:
            try:
                if _t.exists():
                    _t.unlink()
            except Exception as _ikram_exc:
                ikram_logger.log_exc("lua_pipeline.run:884", _ikram_exc)
                pass


def _run_impl(src, out_dir, progress, _tmps) -> dict:
    """Decompile one Lua file through the full tier cascade.

    Returns {"ok": bool, "status": "success"|"disassembled"|"failed",
             "out": Path|None, "disasm_path": Path|None,
             "fail_path": Path|None, "meta": dict,
             "attempts": [(label, msg)], "lines": int|None,
             "quality": str|None, "msg": str}
    """
    src = Path(src)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = src.stem
    data = src.read_bytes()
    # A pack's key usually travels with it (key.txt, decryptor stub, config).
    # Harvest those before any tier runs so the AES step has real candidates.
    attempts_seed_note = 0
    try:
        _n = _mega.harvest_key_seeds(src)
        if _n:
            attempts_seed_note = _n
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline.run:harvest", _ikram_exc)
    _skuy_raw = data
    # Captured here because a decompiler may unlink the input it was handed,
    # and the failure report still has to be able to name the file's size.
    src_size = len(data)
    try:
        import ikram_upgrade as _ik
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._run_impl:908", _ikram_exc)
        _ik = None
    meta = detect_report(data)
    attempts = []
    if attempts_seed_note:
        attempts.append(("Key harvest",
                         "%d candidate key(s) picked up from sibling files"
                         % attempts_seed_note))

    bytes_for_methods = data
    decrypt_note = ""
    dec_src = src
    last_validator = None
    if not data:
        attempts.append(("Input", "file is empty"))
        return _finish_failure(src, out_dir, stem, meta, attempts, src_size,
                           last_validator)

    # ----- TIER -1 — peel stacked protection. Runs before detection so the
    # report describes the chunk the engines will actually see. V118 unwrapped
    # a single IKRM layer here and nothing else, which left every composed
    # file (IKRM-around-AES, prefix-around-zlib, ...) failing.
    if (_ik is not None and _ik.is_protected(data)) or not _lua_family_at(data[:12])[0]:
        _phase(progress, "Peeling protection layers...")
        peeled, notes = _peel_layers(data, _ik)
        for note in notes:
            attempts.append(("Layer peel", note))
        if peeled is not None and len(peeled) != len(data):
            data = peeled
            bytes_for_methods = data
            meta = detect_report(data)
            decrypt_note = " | " + "; ".join(notes)
            dec_tmp = out_dir / ("_tmp_%s_peel.luac" % stem)
            _tmps.append(dec_tmp)
            dec_tmp.write_bytes(data)
            dec_src = dec_tmp

    if not data:
        attempts.append(("Input", "file is empty after layer peel"))
        return _finish_failure(src, out_dir, stem, meta, attempts, src_size)

    # Plain source pass-through. detect_report already proved this file has no
    # lua magic and reads as source, so running six decompilers over it is
    # pointless — and worse, the disassembly fallback would then save noise
    # that looks like a result. Keep the file, prove it compiles, be done.
    if meta["kind"] == "readable Lua source":
        text = data.decode("utf-8", errors="replace")
        v = validate_source(text)
        if v["ok"]:
            final = _mega.game_output_path(out_dir, stem)
            final.write_text(text, encoding="utf-8")
            why = "readable source (as-is)"
            attempts.append(("Source passthrough",
                             "already Lua source, compiles with luac (%d/%d checks)"
                             % (v["score"], v["total"])))
            return {
                "ok": True, "status": "success", "out": final,
                "disasm_path": None, "fail_path": None,
                "meta": meta, "attempts": attempts,
                "lines": len([l for l in text.splitlines() if l.strip()]),
                 "quality": why, "msg": why, "validate": v,
            }
        attempts.append(("Source passthrough",
                         "reads as source but fails %s"
                         % ", ".join(k for k, o in v["checks"].items() if not o)))

    # ----- TIER 0 — wrapper strip (PUBG/BGMI/UE4 length prefix, TPF loader).
    # detect_report already proved a real family header sits at meta["wrapper"];
    # hand the engines the bare chunk so every tier sees a normal header.
    if meta["wrapper"]:
        off = meta["wrapper"]
        _phase(progress, "Stripping %d-byte wrapper..." % off)
        data = data[off:]
        bytes_for_methods = data
        dec_tmp = out_dir / ("_tmp_%s_strip.luac" % stem)
        _tmps.append(dec_tmp)
        dec_tmp.write_bytes(data)
        dec_src = dec_tmp
        decrypt_note = " | stripped %d-byte wrapper" % off
        attempts.append(("Wrapper strip",
                         "%d-byte header removed, real chunk starts at offset %d"
                         % (off, off)))

    # ----- TIER 4 — encryption bypass prepass (before any decompiler)
    if (meta["protection"]
            or meta["band"] in ("lightly encrypted", "encrypted")
            or meta["kind"] == "unknown"):
        _phase(progress, "Encryption sweep...")
        sweep = _xor_sweep(data)
        if sweep:
            # More than one candidate can now survive the _loads_ok gate, so
            # pick on the cheapest real signal available: a correct decryption
            # turns back into text, so it exposes far more recognisable Lua
            # keywords than a wrong key that merely lined the header up. Ties
            # keep sweep order (rolling first, then key_len ascending), so the
            # old first-match choice remains the fallback and nothing regresses.
            def _kwscore(_cand):
                try:
                    return sum(1 for s in _string_extraction(_cand[1])
                               if any(k in s.lower() for k in
                                      ("function", "return", "local", "end",
                                       "then", "while", "self")))
                except Exception as _ikram_exc:
                    ikram_logger.log_exc("lua_pipeline._run_impl:1007", _ikram_exc)
                    return 0
            _scores = [_kwscore(c) for c in sweep]
            _best = max(range(len(sweep)), key=lambda j: (_scores[j], -j))
            if len(sweep) > 1:
                attempts.append(("Sweep shortlist",
                                 "%d candidates survived, keyword scores %s"
                                 % (len(sweep), ", ".join(str(s) for s in _scores))))
            label, dec = sweep[_best]
            attempts.append(("XOR/SKIP", "decrypted with %s" % label))
            bytes_for_methods = dec
            decrypt_note = " | decrypted %s" % label
            dec_tmp = out_dir / ("_tmp_%s_dec.luac" % stem)
            _tmps.append(dec_tmp)
            dec_tmp.write_bytes(dec)
            dec_src = dec_tmp
        else:
            strings = _string_extraction(data)
            kw_hits = [s for s in strings if any(k in s.lower()
                                                for k in ("function", "return", "local", "end"))]
            if kw_hits:
                attempts.append(("String probe",
                                 "%d printable strings, >0 lua keywords → trying decompilers anyway" % len(strings)))
            else:
                attempts.append(("String probe",
                                 "%d printable strings, no lua keywords found" % len(strings)))

    # ----- prepare the standard disassembly tier (cheap, always)
    disasm = []

    # order depends on detected family
    if meta["family"] == "LuaJIT":
        order = ("mega", "unluacrs", "unluac", "ljd", "luadec", "luajit",
                 "skuy")
    elif meta["family"] and meta["family"].startswith("Lua 5."):
        order = ("mega", "unluacrs", "unluac", "luadec", "luacdis", "skuy")
    else:
        order = ("mega", "unluacrs", "unluac", "ljd", "luadec", "luacdis",
                 "luajit", "skuy")

    for step in order:
        # ----- TIER 1 — mega_lua game engine (the proven core)
        if step == "mega":
            _phase(progress, "MegaLua engine...")
            try:
                results = univ.decompile_multi_engines(str(dec_src), str(out_dir),
                                                       progress=progress)
            except Exception as e:
                ikram_logger.log_exc("lua_pipeline._run_impl:1053", e)
                results = []
                attempts.append(("MegaLua", "engine error: %s" % str(e)[:80]))
            for label, ok, path, msg in results:
                if not (ok and path and Path(path).exists()):
                    attempts.append((label, "%s" % str(msg)[:120]))
                    continue
                _pth = Path(path)
                # Game-ready bytecode: on monster builds (BRPlayer-class,
                # GameStateBase-class) the source exceeds stock luac's hard
                # limits and cannot recompile; _bgmi_recover then hands over
                # the EXACT game .luac bytes through the disassemble-assisted
                # round-trip. That bytecode IS the game-ready deliverable, so
                # a .luac result is accepted outright instead of being fed to
                # the text validator (which would reject binary on sight).
                if _pth.suffix.lower() == ".luac":
                    _final_bc = out_dir / (stem + "_GAME.luac")
                    # The engine can write the deliverable UNDER ITS FINAL
                    # NAME itself (BGMI recover hands over the exact game
                    # bytes as <stem>_GAME.luac). Unlinking "the stale copy"
                    # then killed the source and the rename crashed with a
                    # raw FileNotFoundError (B11). Skip the dance when the
                    # source already IS the destination.
                    _same = (_pth.exists() and _final_bc.exists()
                             and _pth.resolve() == _final_bc.resolve())
                    try:
                        if not _same:
                            if _final_bc.exists():
                                _final_bc.unlink()
                            _pth.rename(_final_bc)
                    except OSError as _ikram_exc:
                        ikram_logger.log_exc("lua_pipeline._run_impl:luac", _ikram_exc)
                        if _pth.exists():
                            _final_bc.write_bytes(_pth.read_bytes())
                    _src_dump = None
                    for _r2 in results:
                        if _r2[1] and _r2[2] and str(_r2[2]).lower().endswith("_game.lua"):
                            _sd = Path(_r2[2])
                            if _sd.exists():
                                _src_dump = _sd
                                break
                    quality = "game-ready bytecode (exact round-trip)"
                    if _src_dump:
                        quality += " | readable edit dump: %s" % _src_dump.name
                    return {
                        "ok": True, "status": "success", "out": _final_bc,
                        "source": str(_src_dump) if _src_dump else None,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            label, str(msg)[:120])],
                        "lines": 0,
                        "quality": quality, "msg": str(msg),
                         "validate": last_validator,
                    }
                text = _pth.read_text(errors="replace")
                v = validate(text, progress); last_validator = v
                if v["ok"]:
                    final = _mega.game_output_path(out_dir, stem)
                    try:
                        Path(path).rename(final)
                    except OSError as _ikram_exc:
                        ikram_logger.log_exc("lua_pipeline._run_impl:1065", _ikram_exc)
                        final.write_text(text, encoding="utf-8")
                    quality = "%s (%d/8)%s | avg line %.1f" % (
                        _quality_label(v["score"]), v["score"], decrypt_note,
                        v["avg_line"])
                    return {
                        "ok": True, "status": "success", "out": final,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            label, str(msg)[:120])],
                        "lines": len([l for l in text.splitlines() if l.strip()]),
                        "quality": quality, "msg": str(msg),
                    }
                attempts.append(("MegaLua", "%s rejected by validator (%d/8: %s)"
                                 % (label, v["score"],
                                    ", ".join(k for k, okk in v["checks"].items() if not okk))))
        # ----- TIER 1/2 — unluac_rs (bundled Rust engine, fastest)
        elif step == "unluacrs":
            _phase(progress, "unluac_rs...")
            text = _unluac_rs(bytes_for_methods)
            if text:
                v = validate(text, progress); last_validator = v
                if v["ok"]:
                    final = _mega.game_output_path(out_dir, stem)
                    final.write_text(text, encoding="utf-8")
                    quality = "%s (%d/8)%s | avg line %.1f" % (
                        _quality_label(v["score"]), v["score"], decrypt_note,
                        v["avg_line"])
                    return {
                        "ok": True, "status": "success", "out": final,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            "unluac_rs", "validated %d/8" % v["score"])],
                        "lines": len([l for l in text.splitlines() if l.strip()]),
                        "quality": quality, "msg": "unluac_rs decompile",
                         "validate": v,
                    }
                attempts.append(("unluac_rs", "output rejected by validator (%d/8: %s)"
                                 % (v["score"], ", ".join(k for k, o in v["checks"].items() if not o))))
            else:
                attempts.append(("unluac_rs", "failed to parse this chunk"))
        # ----- TIER 1/2 — unluac.jar (standard + LuaJIT)
        elif step == "unluac":
            _phase(progress, "unluac.jar...")
            text = _unluac_jar(bytes_for_methods)
            if text:
                v = validate(text, progress); last_validator = v
                if v["ok"]:
                    final = _mega.game_output_path(out_dir, stem)
                    final.write_text(text, encoding="utf-8")
                    quality = "%s (%d/8)%s | avg line %.1f" % (
                        _quality_label(v["score"]), v["score"], decrypt_note,
                        v["avg_line"])
                    return {
                        "ok": True, "status": "success", "out": final,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            "unluac.jar", "validated %d/8" % v["score"])],
                        "lines": len([l for l in text.splitlines() if l.strip()]),
                        "quality": quality, "msg": "unluac.jar decompile",
                         "validate": v,
                    }
                attempts.append(("unluac.jar", "output rejected by validator (%d/8: %s)"
                                 % (v["score"], ", ".join(k for k, o in v["checks"].items() if not o))))
            else:
                attempts.append(("unluac.jar", "failed to parse this chunk"))
        # ----- TIER 2 — ljd (LuaJIT)
        elif step == "ljd":
            _phase(progress, "ljd (LuaJIT)...")
            text = _ljd_decompile(bytes_for_methods)
            if text:
                v = validate(text, progress); last_validator = v
                if v["ok"]:
                    final = _mega.game_output_path(out_dir, stem)
                    final.write_text(text, encoding="utf-8")
                    quality = "%s (%d/8)%s | avg line %.1f" % (
                        _quality_label(v["score"]), v["score"], decrypt_note,
                        v["avg_line"])
                    return {
                        "ok": True, "status": "success", "out": final,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            "ljd", "validated %d/8" % v["score"])],
                        "lines": len([l for l in text.splitlines() if l.strip()]),
                        "quality": quality, "msg": "ljd decompile",
                         "validate": v,
                    }
                attempts.append(("ljd", "output rejected by validator (%d/8)" % v["score"]))
            else:
                attempts.append(("ljd", "could not parse chunk (unsupported opcodes)"))
        # ----- TIER 2 — luadec (optional; only runs when the user installed it)
        elif step == "luadec":
            if not _on_path("luadec"):
                continue
            _phase(progress, "luadec...")
            text = _luadec(bytes_for_methods)
            if text:
                v = validate(text, progress); last_validator = v
                if v["ok"]:
                    final = _mega.game_output_path(out_dir, stem)
                    final.write_text(text, encoding="utf-8")
                    quality = "%s (%d/8)%s | avg line %.1f" % (
                        _quality_label(v["score"]), v["score"], decrypt_note,
                        v["avg_line"])
                    return {
                        "ok": True, "status": "success", "out": final,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            "luadec", "validated %d/8" % v["score"])],
                        "lines": len([l for l in text.splitlines() if l.strip()]),
                        "quality": quality, "msg": "luadec decompile",
                         "validate": v,
                    }
                attempts.append(("luadec", "output rejected by validator (%d/8)" % v["score"]))
            else:
                attempts.append(("luadec", "failed to parse this chunk"))
        # ----- TIER 3 — built-in disassemblers
        elif step == "luacdis":
            for name, txt in _luac_disasm(bytes_for_methods):
                disasm.append((name, txt))
                attempts.append((name, "bytecode listing (%d lines)" % txt.count("\n")))
        elif step == "luajit":
            for name, txt in _luajit_disasm(bytes_for_methods):
                disasm.append((name, txt))
                attempts.append((name, "bytecode listing (%d lines)" % txt.count("\n")))
        # ----- TIER 4 — SKUY VIP: native Cython custom-chunk (NADEEM/BYRJ6)
        # decoder. Every other tier only sees standard chunks; this one unwraps
        # the custom VM layer even when the standard engines all failed.
        elif step == "skuy":
            try:
                import skuy_runner as _skuyr
            except Exception as _ikram_exc:
                ikram_logger.log_exc("lua_pipeline._run_impl:skuy-import", _ikram_exc)
                attempts.append(("SKUY VIP", "engine module unavailable"))
                continue
            _phase(progress, "SKUY VIP (custom chunk decode)...")
            _rr = _skuyr.decompile(_skuy_raw, timeout=min(1800, 300 + len(data) // 9000))
            if _rr.get("ok"):
                text = _rr.get("text", "")
                v = validate(text, progress); last_validator = v
                if v["ok"]:
                    final = _mega.game_output_path(out_dir, stem)
                    final.write_text(text, encoding="utf-8")
                    quality = "SKUY VIP %s (%d/8)%s | avg line %.1f" % (
                        str(_rr.get("via", "")), v["score"], decrypt_note,
                        v["avg_line"])
                    return {
                        "ok": True, "status": "success", "out": final,
                        "disasm_path": None, "fail_path": None,
                        "meta": meta, "attempts": attempts + [(
                            "SKUY VIP %s" % _rr.get("via", ""),
                            "validated %d/8" % v["score"])],
                        "lines": len([l for l in text.splitlines() if l.strip()]),
                        "quality": quality, "msg": "SKUY VIP decompile",
                         "validate": v,
                    }
                attempts.append(("SKUY VIP", "output rejected by validator (%d/8)"
                                 % v["score"]))
            else:
                attempts.append(("SKUY VIP", "%s" % str(_rr.get("error"))[:120]))

    # ----- TIER 5 — large-file note
    if len(data) > 1024 * 1024:
        attempts.append(("Large-file",
                         "chunk-split refused: unsafe on arbitrary/protected bytecode; "
                         "scaled timeouts already applied in the engine tiers"))

    if dec_src is not src:
        try:
            dec_src.unlink()
        except OSError as _ikram_exc:
            ikram_logger.log_exc("lua_pipeline._run_impl:1199", _ikram_exc)
            pass

    # ----- TIER 6 — disassembly fallback: keep the best readable listing
    best_disasm = None
    if disasm:
        best_disasm = max(disasm, key=lambda pair: pair[1].count("\n"))
        name, txt = best_disasm
        if txt and len(txt) > 50 and _garbage_ratio(txt) < 0.05:
            dis_path = out_dir / (stem + "_disassembled.lua")
            dis_path.write_text(txt, encoding="utf-8")
            attempts.append(("Disassembly", "%s → saved as %s" % (name, dis_path.name)))
            return {
                "ok": False, "status": "disassembled", "out": None,
                "disasm_path": dis_path, "fail_path": None,
                "meta": meta, "attempts": attempts, "lines": None,
                "quality": None,
                "msg": "Full decompile not possible; best result: disassembly saved.",
            }

    # ----- TIER 7 — honest failure (never garbage)
    return _finish_failure(src, out_dir, stem, meta, attempts, src_size)


def _phase(progress, text: str) -> None:
    if progress is None:
        return
    try:
        if isinstance(progress, dict):
            progress["phase"](text)
        elif hasattr(progress, "phase"):
            progress.phase(text)
        elif callable(progress):
            progress(text)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._phase:1228", _ikram_exc)
        pass


# ---------------------------------------------------------------- reporting
def _safe_size(src, known=None):
    """Byte size for the failure report, tolerating a vanished input.

    A decompiler handed the caller's file may unlink it while probing. The
    report still has to be written, so prefer the size captured before any
    engine ran and only stat the file when that is unavailable.
    """
    if known is not None:
        return known
    try:
        return src.stat().st_size
    except OSError as _ikram_exc:
        ikram_logger.log_exc("lua_pipeline._safe_size:1245", _ikram_exc)
        return "unknown (input removed by a decompiler)"


def _write_failed(src, out_dir, stem, meta, attempts, validator=None,
                  src_size=None) -> Path:
    fail = out_dir / (stem + "_FAILED.txt")
    now = time.strftime("%Y-%m-%d %H:%M:%S")
    lines = [
          "IkramTool %s — decompile FAILED" % _version(),
        "Timestamp : %s" % now,
        "File      : %s" % src.name,
        "Size      : %s bytes" % _safe_size(src, src_size),
        "Detected  : %s" % meta["kind"],
        "Family    : %s" % (meta["family"] or "unresolved"),
        "Entropy   : %.3f (%s)" % (meta["entropy"], meta["band"]),
    ]
    if meta.get("wrapper"):
        lines.append("Wrapper   : %d-byte header stripped" % meta["wrapper"])
    if meta.get("protection"):
        lines.append("Protection: %s" % meta["protection"])
    lines += [
        "",
        "Methods tried:",
    ]
    for label, msg in attempts:
        # engine errors carry their own newlines (java stack traces, python
        # tracebacks). Emitting them raw split one "  - label: msg" bullet
        # across several lines and made the method list unreadable - exactly
        # when the user most needs to read it.
        flat = " ".join(str(msg).split())
        if len(flat) > 300:
            flat = flat[:300].rstrip() + "..."
        lines.append("  - %s: %s" % (label, flat))
    if validator is not None:
        lines.append("")
        lines.append("Output validator:")
        _ratios = {
            "len > 50": "%d lines" % validator.get("lines", 0),
            "keywords >= 5": "%d distinct of %d" % (validator.get("keywords", 0),
                                                    len(LUA_KEYWORDS)),
            "garbage < 2%": "%.4f (limit 0.02)" % validator.get("garbage", 0.0),
            "? < 1%": "%.4f (limit 0.01)" % validator.get("qmarks", 0.0),
            "structures >= 2": "%d structures, %d table assigns" % (
                validator.get("structures", 0), validator.get("assigns", 0)),
            "avg line 5..300": "%.1f (limit 5..300)" % validator.get("avg_line", 0.0),
            "round-trip recompile": "rejected by patched luac",
            "no binary lines": "%.4f (limit 0.50)" % validator.get("binary", 0.0),
        }
        for k, v in validator["checks"].items():
            lines.append("  %-4s %-24s %s" % ("PASS" if v else "FAIL", k,
                                              _ratios.get(k, "")))
        lines.append("  score %d/8 (%s)" % (validator["score"],
                                             _quality_label(validator["score"], total=8)))
        _failed = [k for k, v in validator["checks"].items() if not v]
        if _failed:
            lines.append("  blocked by: %s" % ", ".join(_failed))
    lines.append("")
    lines.append("Checked: magic-header + entropy, every decompiler on this")
    lines.append(
        "device, XOR/additive key sweep (1..%d), string probing, and"
        % max(_XOR_LENGTHS))
    lines.append("bytecode disassembly. The file is either properly encrypted,")
    lines.append("locked by its owner, truncated, or not Lua. No garbage was")
    lines.append("kept as a 'success'.")
    fail.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return fail


def _finish_failure(src, out_dir, stem, meta, attempts, src_size=None,
                    validator=None) -> dict:
    # validator= is what makes the report actionable: without it the user sees
    # "decompile failed" and no idea which quality gate rejected the output.
    fail = _write_failed(src, out_dir, stem, meta, attempts,
                         validator=validator, src_size=src_size)
    return {
        "ok": False, "status": "failed", "out": None,
        "disasm_path": None, "fail_path": fail,
        "meta": meta, "attempts": attempts, "lines": None,
        "quality": None, "msg": fail.name, "validate": validator,
    }


# ------------------------------------------------------------ dependencies
# Tools the pipeline can live without. They never appear in `missing`, so the
# first-run prompt only ever asks for something it can actually fix.
_OPTIONAL_LUA = {"luadec", "radare2 (native ELF/PE only)"}

# On Windows there is no package manager the tool will drive, so anything the
# bundle already substitutes cannot be "fixed" by the user. Listing it as
# missing printed Termux commands to Windows users and made a healthy install
# look broken. These stay visible in the table, never in `missing`.
_WIN_BUNDLED_ONLY = {"luac 5.1", "luac 5.2", "luac 5.4", "luajit"}


def _fix_line(item_id: str, fallback: str) -> str:
    """Install hint for one dependency, correct for the host platform.

    Previously every missing row carried a hard-coded Termux command, so a
    Windows install told the user to run `pkg install lua51`.
    """
    if os.name == "nt":
        if item_id == "java":
            return "install JRE 17 (adoptium.net) - needed for unluac.jar"
        return "not installable here - bundled tools used instead"
    try:
        import installer as _inst
        mgr = _inst.detect_manager()
        if mgr:
            pkg = _inst._package_for(item_id, mgr[0])
            if pkg:
                base = list(mgr[1])
                if base and base[-1] in ("-y", "--noconfirm", "-n"):
                    base.pop()
                return " ".join(base + [pkg])
    except Exception as e:
        ikram_logger.log_exc("lua_pipeline._fix_line", e)
    return fallback


def tool_table() -> list:
    """[(tool, ok, detail)] for the live dependency box."""
    rows = []
    import shutil

    def row(name, ok, detail):
        rows.append((name, bool(ok), detail))

    # One PATH probe per tool. The old table called shutil.which("java") twice
    # (once for the flag, once inside the detail) and stat()'d UNLUAC_RS twice,
    # so every repaint rescanned PATH for a value it already had.
    jv = shutil.which("java")
    row("java (JDK)", jv, "bundled" if jv else _fix_line("java", "install a JRE"))
    j = _mega.UNLUAC_JAR
    row("unluac.jar", Path(j).exists(), "bundled")
    _has_rs = _mega.UNLUAC_RS.exists()
    rows.append(("unluac_rs", _has_rs, "bundled" if _has_rs else "missing"))
    row("luac (5.3)", _host_luac("5.3"), _fix_line("luac53", "lua53"))
    row("luac 5.1", _host_luac("5.1"), _fix_line("luac51", "install lua5.1"))
    row("luac 5.2", _host_luac("5.2"), _fix_line("luac52", "install lua5.2"))
    row("luac 5.4", _host_luac("5.4"), _fix_line("luac54", "install lua5.4"))
    row("luajit", _host_luajit(), _fix_line("luajit", "install luajit"))
    row("ljd (LuaJIT)", LJD_DIR.is_dir(), "bundled deps/ljd" if LJD_DIR.is_dir() else "missing")
    row("luadec", shutil.which("luadec"), "optional, used when present")
    # radare2 disassembles native code (ELF/PE/Mach-O). It cannot decompile
    # Lua bytecode, so it is deliberately NOT part of the Lua cascade -
    # install_missing pulled it in, but tool_table never declared it, which
    # made deps_status hide it and the install look like dead weight.
    row("radare2 (native ELF/PE only)", shutil.which("r2") or shutil.which("radare2"),
        "native binaries only, not used for Lua")
    return rows


def deps_status() -> dict:
    """First-run dependency check with install commands for every missing one."""
    # Probe once. deps_status called tool_table() twice, so the whole table was
    # rebuilt (one PATH scan per tool) just to fill the "tools" key.
    table = tool_table()
    skip = set(_OPTIONAL_LUA)
    if os.name == "nt":
        skip |= _WIN_BUNDLED_ONLY
    missing = []
    for name, ok, fix in table:
        if not ok and name not in skip:
            missing.append("%s  →  %s" % (name, fix))
    return {"java": shutil.which("java"), "missing": missing,
            "tools": table}


def install_missing(progress=None) -> list:
    """Auto-install the missing tools. Returns [(cmd, ok, out_tail)].

    Real work only: the package names come from the shared installer table,
    every command runs through installer._run (logged, bounded), and the last
    row is a live re-probe of PATH so the count cannot lie about success.
    """
    import shutil

    import installer as _inst

    want = []
    if not shutil.which("java"):
        want.append("java")
    if not _host_luac("5.1"):
        want.append("luac51")
    if not _host_luac("5.2"):
        want.append("luac52")
    if not _host_luac("5.3"):
        want.append("luac53")
    if not _host_luac("5.4"):
        want.append("luac54")
    if not _host_luajit():
        want.append("luajit")

    results = []
    if not LJD_DIR.is_dir():
        results.append(("ljd (bundled deps/ljd)", False,
                        "ljd.zip missing from the tool bundle"))
    if not want:
        return results

    manager = _inst.detect_manager()
    if manager is None:
        if os.name == "nt":
            results.append(("host tools", False,
                            "no package manager on Windows - bundled luac/lua/unluac_rs "
                            "cover everything except unluac.jar (needs JRE 17 from "
                            "adoptium.net); install that manually if you want the jar tier"))
        else:
            results.append(("host tools", False,
                            "no package manager on this platform - bundled engines used"))
        return results
    name, tpl, _needs_root = manager
    cmds = []
    for item in want:
        pkg = _inst._package_for(item, name)
        if not pkg:
            results.append((item, False, "no package named %s on %s" % (item, name)))
            continue
        cmds.append((item, tpl + [pkg]))

    for i, (item, cmd) in enumerate(cmds):
        _phase(progress, "[%d/%d] %s" % (i + 1, len(cmds), " ".join(cmd)))
        good, tail = _inst._run(cmd, timeout=900)
        results.append((" ".join(cmd), good, tail or "ok"))

    still = [m for m in deps_status()["missing"]
             if any(k in m.lower() for k in ("java", "luac", "luajit"))]
    results.append(("verify", not still,
                    "all Lua tools present" if not still
                    else "%d still missing: %s" % (len(still), ", ".join(
                        s.split("  →  ")[0] for s in still[:4]))))
    return results