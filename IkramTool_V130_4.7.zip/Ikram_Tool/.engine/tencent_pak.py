"""Byte-correct writer for Tencent PUBG .pak archives (version 14 family).

The reader in pak.pyc stays the source of truth for the format.  This module
only WRITES, and it was derived from that reader plus 41 real paks:

    * index plaintext:
        wstring(mount) | u32 file_count | file records | u64 dir_count
        | ( wstring(dir) | u64 n | ( wstring(name) | i32 -(file_pos+1) )* )*
        | trailing bytes
      File records are serialized in `pak.files` order.  Directory references
      are NEGATIVE: -1 is files[0], -2 is files[1], ...
    * index crypto: AES-256-CBC with PKCS7 over the plaintext.  Key and IV are
      unpacked from the footer blobs through RSA_MOD_1.  index_hash is the
      SHA-1 of the *unpadded* plaintext.
    * footer: 28/48/... bytes of memory block (copied verbatim from the
      source) followed by a 45-byte tail masked with the footer keystream.
    * bodies are never re-encoded unless the payload actually changed.  Kept
      entries are streamed byte-for-byte from the source, so SM4 bodies
      (encryption_method 31..55, block order not reproducible) stay intact.
    * a re-encoded body is chunked by compression_block_size, each chunk
      compressed (zlib/zstd), then encrypted (simple2).  Block windows record
      the PRE-encryption compressed length; the next block starts at the next
      16-byte boundary and entry.size is the padded stored length.
    * entry.content_hash is SHA-1 over the stored body region; entry.unk2 is
      md5(plain) + md5(plain)[4:8].

Everything here is streaming: paks are read from disk in bounded chunks and
written straight to the output file, so multi-gigabyte data paks do not have
to fit in RAM.
"""

from __future__ import annotations

import hashlib
import os
import struct
from pathlib import Path

try:
    from Crypto.Cipher import AES
except Exception:  # pragma: no cover - pycryptodome ships with the tool
    AES = None

CM_NONE = 0
CM_ZLIB = 1
CM_ZSTD = 6
EM_SIMPLE1 = 1
EM_SIMPLE2 = 16
EMPTY_SHA1 = hashlib.sha1(b"").digest()
_EMPTY_MD5 = hashlib.md5(b"").digest()
EMPTY_UNK2 = _EMPTY_MD5 + _EMPTY_MD5[4:8]
CHUNK = 1 << 24


def _wstr(s):
    if not s:
        return struct.pack("<i", 0)
    raw = s.encode("utf-8")
    return struct.pack("<i", len(raw) + 1) + raw + b"\x00"


def _quarantine_partial(output_path):
    final = str(output_path)
    partial = final + ".PARTIAL"
    for index in range(100):
        candidate = partial if index == 0 else "%s.%d" % (partial, index)
        if os.path.exists(candidate):
            continue
        try:
            os.replace(final, candidate)
            return
        except FileExistsError:
            continue
        except OSError:
            break
    try:
        os.remove(final)
    except OSError:
        pass


class _Core:
    """One write session over one source archive."""

    def __init__(self, pak, mod):
        self.pak = pak
        self.mod = mod
        self.pc = mod.pc
        self.info = pak.info
        self.version = int(self.info.version)
        self._content = None
        self._fh = None
        self._closed = False

    # -- source -----------------------------------------------------------
    def _file_size(self):
        content = getattr(self.pak, "content", None)
        if content is not None:
            return len(content)
        return os.path.getsize(self.pak.file_path)

    def _open_source(self):
        content = getattr(self.pak, "content", None)
        if content is not None:
            # PakReader.content is an mmap-backed memoryview. Copying it here
            # doubled peak RSS on every repack/inject. Slices below are bounded
            # and file.write()/hashlib both accept buffer protocol.
            self._content = memoryview(content)
            return
        self._content = None
        self._fh = open(self.pak.file_path, "rb")

    def _read(self, off, n):
        if n <= 0:
            return b""
        if self._content is not None:
            return self._content[off:off + n]
        self._fh.seek(off)
        return self._fh.read(n)

    def _close_source(self):
        if self._fh is not None:
            try:
                self._fh.close()
            except Exception:
                pass
            self._fh = None
        self._closed = True

    def _copy_region(self, out, off, n, on_bytes=None):
        left = int(n)
        while left > 0:
            chunk = self._read(off, min(CHUNK, left))
            if not chunk:
                raise IOError(
                    "source pak ended early at offset %d (%d bytes left)"
                    % (int(off), left))
            out.write(chunk)
            off += len(chunk)
            left -= len(chunk)
            if on_bytes:
                on_bytes(len(chunk))

    # -- paths ------------------------------------------------------------
    def _rel(self, p):
        p = str(p).replace("\\", "/")
        while p.startswith("./"):
            p = p[2:]
        p = p.lstrip("/")
        mount = str(getattr(self.pak, "mount_point", "") or "")
        if mount:
            base = mount.rstrip("/")
            if mount.endswith("/"):
                if p.startswith(mount):
                    p = p[len(mount):]
            elif p == base:
                p = ""
            elif p.startswith(base + "/"):
                p = p[len(base) + 1:]
        return p.lstrip("/")

    def _resolve(self, raw, index, target_path, fold=None):
        rel = self._rel(raw)
        if rel in index:
            return rel

        def canon(key):
            if fold:
                return fold.get(key.lower(), key)
            return key

        # A caller may type a path in different case. The pak stores one
        # canonical spelling; editing a case variant must hit that same entry,
        # not append a duplicate that case-insensitive loaders cannot tell
        # apart from the original.
        c = canon(rel)
        if c in index:
            return c
        # Extracted trees may carry the mount's last component ("ShadowTrackerExtra/...").
        mount = str(getattr(self.pak, "mount_point", "") or "")
        leaf = mount.rstrip("/").rsplit("/", 1)[-1] if mount else ""
        if leaf and rel.startswith(leaf + "/"):
            cand = rel[len(leaf) + 1:]
            if cand in index:
                return cand
            c = canon(cand)
            if c in index:
                return c
        if target_path:
            tp = self._rel(target_path)
            if tp and not tp.endswith("/"):
                tp += "/"
            cand = (tp + rel) if tp else rel
            if cand in index:
                return cand
            c = canon(cand)
            if c in index:
                return c
            if tp and not rel.startswith(tp):
                # --target is also the destination prefix for new files.
                # Without this, additions land at the pak root even when the
                # caller asked for Content/Lua/client/<name> or similar.
                return cand
        return rel

    # -- entries ----------------------------------------------------------
    def _pick_template(self):
        for e in self.pak.files:
            if getattr(e, "encrypted", False) and e.encryption_method in (
                    EM_SIMPLE1, EM_SIMPLE2) and e.size:
                return e
        for e in self.pak.files:
            if e.size:
                return e
        if self.pak.files:
            return self.pak.files[0]
        # A structural/custom pak can have directory entries but zero files.
        # Inject still needs one record to clone. Build a minimal in-memory
        # template; _new_entry writes a normal zstd + simple2 body for it.
        cls = getattr(self.mod, "TencentPakEntry", None)
        if cls is None:
            return None
        e = cls.__new__(cls)
        e.content_hash = EMPTY_SHA1
        e.offset = 0
        e.uncompressed_size = 0
        e.compression_method = CM_ZSTD
        e.size = 0
        e.unk1 = 0
        e.unk2 = EMPTY_UNK2
        e.compressed_blocks = []
        e.compression_block_size = 0
        e.encrypted = True
        e.encryption_method = EM_SIMPLE2
        e.index_new_sep = 0xFFFFFFFF
        e.stem = ""
        return e

    def _new_entry(self, data, tmpl, stem, name, entry=None):
        base = tmpl if tmpl is not None else entry
        if base is None:
            base = self._pick_template()
        if base is None:
            raise ValueError("pak has no entry to use as a template")
        # A Custom skeleton has only zero-body entries.  Cloning one of those
        # for a real payload used to inherit cm=0/em=0 and write the body raw,
        # which no game loader accepts as a lua/uasset.  Nonempty additions
        # get the corpus convention (zstd + simple2) when the template is
        # empty, while nonempty templates keep their own cm/em.
        base_empty = data and int(getattr(base, "size", 0) or 0) == 0
        e = base.clone()
        e.stem = stem or Path(name).stem
        e.compressed_blocks = []
        e.compression_block_size = 0
        e.unk1 = 0
        e.index_new_sep = 0xFFFFFFFF
        if base_empty:
            e.compression_method = CM_ZSTD
            e.encryption_method = EM_SIMPLE2
            e.encrypted = True
        if not data:
            e.content_hash = EMPTY_SHA1
            e.unk2 = EMPTY_UNK2
            e.offset = 0
            e.size = 0
            e.uncompressed_size = 0
            e.compression_method = CM_NONE
            e.encryption_method = 0
            e.encrypted = False
            return e
        cm = int(getattr(e, "compression_method", CM_ZSTD))
        if cm not in (CM_NONE, CM_ZLIB, CM_ZSTD):
            cm = CM_ZSTD
        encrypted = bool(getattr(e, "encrypted", True))
        em = int(getattr(e, "encryption_method", EM_SIMPLE2)) if encrypted else 0
        if encrypted and em not in (EM_SIMPLE1, EM_SIMPLE2):
            # SM4 bodies cannot be re-encoded reproducibly; write a valid
            # simple2 body instead.
            em = EM_SIMPLE2
        e.compression_method = cm
        e.encryption_method = em
        e.encrypted = em != 0
        e.uncompressed_size = len(data)
        md = hashlib.md5(data).digest()
        e.unk2 = md + md[4:8]
        e.size = 0
        e.offset = 0
        return e

    def _encode(self, data, e, abs_off):
        pc = self.pc
        e.offset = int(abs_off)
        e.uncompressed_size = len(data)
        e.compressed_blocks = []
        if not data:
            e.size = 0
            e.content_hash = EMPTY_SHA1
            e.unk2 = EMPTY_UNK2
            return b""
        cm = int(e.compression_method)
        em = int(e.encryption_method) if e.encrypted else 0
        e.encryption_method = em
        if cm == CM_NONE:
            body = bytes(data)
            if em:
                body = pc.encrypt_block(body, e.stem, em)
            e.compression_block_size = 0
        else:
            # Real paks use one block per 65536 plaintext bytes, and a single
            # block whose size equals the payload for anything smaller.  That
            # rule reproduces compression_block_size on the whole corpus.
            cs = min(65536, len(data))
            e.compression_block_size = cs
            Block = self.mod.PakCompressedBlock
            out = bytearray()
            rel = 0
            zstd_dict = getattr(self.pak, "_zstd_dict", None)
            for i in range(0, len(data), cs):
                chunk = data[i:i + cs]
                comp = pc.best_compress(chunk, cm, zstd_dict)
                # Block windows record the PRE-encryption compressed length;
                # the next block starts at the next 16-byte boundary because
                # each encrypted chunk is padded to 16.
                e.compressed_blocks.append(
                    Block(abs_off + rel, abs_off + rel + len(comp)))
                if em:
                    comp = pc.encrypt_block(comp, e.stem, em)
                out += comp
                rel += len(comp)
            body = bytes(out)
        if em:
            want = int(pc.align_encrypted_size(len(body), em))
            if want > len(body):
                body += b"\x00" * (want - len(body))
        e.size = len(body)
        e.content_hash = hashlib.sha1(body).digest()
        md = hashlib.md5(data).digest()
        e.unk2 = md + md[4:8]
        return body

    # -- index ------------------------------------------------------------
    def _source_plain(self):
        try:
            raw = self._read(int(self.info.index_offset), int(self.info.index_size))
            return self.pc.decrypt_index(raw, self.info)
        except Exception:
            return b""

    def _index_plain(self, files, dirs):
        out = bytearray()
        out += _wstr(str(getattr(self.pak, "mount_point", "") or ""))
        out += struct.pack("<I", len(files))
        ipos = {id(e): i for i, e in enumerate(files)}
        for e in files:
            out += self.mod.pw_entry(e, self.version)
        out += struct.pack("<Q", len(dirs))
        for d, items in dirs.items():
            out += _wstr(d)
            out += struct.pack("<Q", len(items))
            for name, e in items.items():
                out += _wstr(name)
                out += struct.pack("<i", -(ipos[id(e)] + 1))
        return bytes(out)

    def _pad_index(self, real):
        """Originals wrap the index plaintext head around to a 16-byte
        multiple before PKCS7 adds its full block, and index_hash covers the
        copy too (verified on 217/217 corpus paks).  Reproduce it exactly."""
        if not self.info.index_encrypted:
            return real
        pad = (-len(real)) % 16
        return real + real[:pad]

    def _encrypt_index(self, plain):
        if not self.info.index_encrypted:
            return plain
        if AES is None:
            raise RuntimeError("pycryptodome is required to encrypt the index")
        pc = self.pc
        key = pc.rsa_extract(self.info.packed_key, pc.RSA_MOD_1)
        iv = pc.rsa_extract(self.info.packed_iv, pc.RSA_MOD_1)[:16]
        pad = 16 - (len(plain) % 16)
        return AES.new(key, AES.MODE_CBC, iv).encrypt(
            plain + bytes([pad]) * pad)

    def _footer(self, index_hash, index_size, index_offset, mem):
        ks = self.info._keystream
        tail = bytearray(45)
        tail[0] = (1 if self.info.index_encrypted else 0) ^ (ks[3] & 0xFF)
        struct.pack_into("<I", tail, 1, int(self.info.magic) ^ ks[2])
        struct.pack_into("<I", tail, 5, self.version)
        tail[9:29] = bytes(
            a ^ b for a, b in
            zip(index_hash, struct.pack("<5I", *ks[4:9])))
        struct.pack_into(
            "<Q", tail, 29, int(index_size) ^ ((ks[10] << 32) | ks[11]))
        struct.pack_into(
            "<Q", tail, 37, int(index_offset) ^ ((ks[0] << 32) | ks[1]))
        return bytes(mem) + bytes(tail)

    # -- main -------------------------------------------------------------
    def inject_files(self, edits, output_path, force_add=False,
                     target_path=None, progress=None, on_file=None):
        pak = self.pak
        output_path = str(output_path)
        src_path = str(getattr(pak, "file_path", "") or "")
        if src_path and os.path.exists(output_path):
            try:
                if os.path.samefile(src_path, output_path):
                    raise ValueError(
                        "repack output must not overwrite the source pak")
            except ValueError:
                raise
            except OSError:
                pass

        self._open_source()
        try:
            files = list(pak.files)
            orig_order = list(files)
            dirs = {d: dict(items) for d, items in pak.dirs.items()}
            index = {}
            for d, items in dirs.items():
                for name, e in items.items():
                    index[d + name] = (d, name, e)
            fold = {}
            for key in index:
                fold.setdefault(key.lower(), key)
            orig = {}
            for e in files:
                orig[id(e)] = (int(e.offset), int(e.size))

            payload = {}
            handled = {}
            handled_fold = {}
            replaced = {}
            new_ids = set()
            changed = False
            entries_total = len(files)
            total_bytes = sum(sz for _, sz in orig.values())
            done_bytes = 0
            item_total = max(1, len(edits or ()))
            item_done = 0
            reported_items = set()

            def _report(fp):
                if progress and total_bytes > 0 and done_bytes > 0:
                    try:
                        progress(done_bytes, total_bytes, fp)
                    except Exception:
                        pass

            def _done(fp, size=None):
                nonlocal item_done
                if on_file:
                    try:
                        on_file(fp, size)
                    except TypeError:
                        try:
                            on_file(fp)
                        except Exception:
                            pass
                    except Exception:
                        pass
                key = str(fp).casefold()
                if key not in reported_items:
                    reported_items.add(key)
                    item_done += 1
                    if progress and total_bytes <= 0:
                        try:
                            progress(min(item_done, item_total), item_total, fp)
                        except Exception:
                            pass

            for item in edits or ():
                try:
                    raw = item[0]
                    body = item[1]
                except Exception:
                    continue
                if isinstance(body, (tuple, list)):
                    if not body:
                        continue
                    data = body[0]
                    tmpl = body[1] if len(body) > 1 else None
                    stem = body[2] if len(body) > 2 else None
                else:
                    data, tmpl, stem = body, None, None
                if data is None:
                    continue
                try:
                    data = bytes(data)
                except Exception:
                    continue
                rel = self._resolve(raw, index, target_path, fold)
                # Two new paths differing only by case are one entry on any
                # case-insensitive game loader. Keep the first spelling and
                # let the later payload win, like any repeated target.
                low = rel.lower()
                if rel not in handled and low in handled_fold:
                    rel = handled_fold[low]
                if rel in handled:
                    # Last write wins for a repeated target. Re-chain the
                    # already-built entry instead of appending a second body
                    # that the rebuilt index would never reference.
                    prev_id = handled[rel]
                    prev = payload.get(prev_id, b"")
                    payload[prev_id] = data
                    total_bytes += len(data) - len(prev)
                    if prev != data:
                        changed = True
                    _done(rel, len(data))
                    continue
                hit = index.get(rel)
                if hit is not None:
                    d, name, old = hit
                    md = hashlib.md5(data).digest()
                    old_size = int(getattr(old, "size", 0) or 0)
                    if (int(old.uncompressed_size) == len(data)
                            and bytes(old.unk2) == md + md[4:8]):
                        _done(rel, len(data))
                        continue
                    # SM4 bodies do not carry md5(plain) in unk2, and em17
                    # .uexp entries read back longer than uncompressed_size.
                    # Compare decoded payloads for stored bodies and for true
                    # zero-body source records so untouched entries stay
                    # verbatim source copies.  The writer's own empty-entry
                    # convention differs from the source (zero unk2 / em1),
                    # so a zero-body edit must never be sent through _new_entry.
                    zero_source = (old_size == 0 and len(data) == 0
                                   and int(old.uncompressed_size) == 0)
                    if zero_source or (old_size > 0 and len(data) > 0):
                        try:
                            if self.pak.read_entry(old) == data:
                                _done(rel, len(data))
                                continue
                        except Exception:
                            pass
                    ne = self._new_entry(data, tmpl, stem, name, entry=old)
                    for i, f in enumerate(files):
                        if f is old:
                            files[i] = ne
                            break
                    dirs[d][name] = ne
                    index[rel] = (d, name, ne)
                    replaced[id(old)] = ne
                    payload[id(ne)] = data
                    handled[rel] = id(ne)
                    handled_fold.setdefault(low, rel)
                    new_ids.add(id(ne))
                    total_bytes += len(data)
                    changed = True
                else:
                    name = rel.rsplit("/", 1)[-1]
                    dp = rel[:len(rel) - len(name)] if "/" in rel else ""
                    if dp and not dp.endswith("/"):
                        dp += "/"
                    parts = [p for p in rel.split("/") if p]
                    for i in range(1, len(parts)):
                        dkey = "/".join(parts[:i]) + "/"
                        if dkey not in dirs:
                            dirs[dkey] = {}
                    dirs.setdefault(dp, {})
                    ne = self._new_entry(data, tmpl, stem, name)
                    dirs[dp][name] = ne
                    files.append(ne)
                    index[rel] = (dp, name, ne)
                    payload[id(ne)] = data
                    handled[rel] = id(ne)
                    handled_fold.setdefault(low, rel)
                    new_ids.add(id(ne))
                    total_bytes += len(data)
                    entries_total += 1
                    changed = True

            # A no-op edit list on an untouched tree is a byte-for-byte copy
            # of the source, index and footer included.  Anything else is
            # rebuilt below.
            src_plain = self._source_plain()
            if self.info.index_encrypted and files and not src_plain:
                raise ValueError(
                    "source pak index could not be decrypted; refusing to rewrite")
            real_base = self._index_plain(files, dirs)
            # An unchanged tree reproduces every record of the source index
            # (the plaintext plus its wrap-around pad), so the whole file is
            # still a byte copy.
            if not changed and src_plain and src_plain.startswith(real_base):
                self._copy_whole(output_path)
                if progress and total_bytes > 0:
                    try:
                        progress(total_bytes, total_bytes, "")
                    except Exception:
                        pass
                return len(files)

            # Layout: kept bodies stay in source-offset order, additions go on
            # the end.  When the archive keeps its whole entry set, source
            # padding gaps and the pre-index pad are reproduced too, so only
            # the entries that actually changed move.
            layout = []
            placed = set()
            for oe in orig_order:
                off, sz = orig[id(oe)]
                ne = replaced.get(id(oe))
                layout.append((off, ne if ne is not None else oe,
                               ne is not None, sz))
                placed.add(id(ne if ne is not None else oe))
            layout.sort(key=lambda t: t[0])
            for e in files:
                if id(e) not in placed:
                    layout.append((None, e, True, None))
                    placed.add(id(e))

            preserve = self._same_tree(index)

            fsz = int(self.info.footer_size())
            mem = self._read(self._file_size() - fsz, fsz - 45)

            out_fh = open(output_path, "wb")
            complete = False
            try:
                dst = 0
                src_cursor = 0
                for off, e, is_new, old_size in layout:
                    name = str(getattr(e, "stem", "")) or ""
                    if not is_new:
                        size = int(old_size)
                        if size == 0:
                            # Real paks keep a live offset on zero-body entries
                            # (it points at the next body's start), so mirror
                            # the current write position instead of zeroing it.
                            e.offset = dst
                            _report(name)
                            _done(name, 0)
                            continue
                        if preserve and int(off) > src_cursor:
                            gap = int(off) - src_cursor
                            self._copy_region(out_fh, src_cursor, gap)
                            dst += gap
                        start = dst
                        self._copy_region(out_fh, int(off), size)
                        # The reader walks compressed_blocks, not entry.offset,
                        # so a body that moves must carry its block windows
                        # with it.  Miss this and a copied subtree reads the
                        # old absolute range (wrong bytes, silently).
                        delta = start - int(off)
                        if delta:
                            for blk in e.compressed_blocks:
                                blk.start += delta
                                blk.end += delta
                        e.offset = start
                        dst += size
                        src_cursor = int(off) + size
                        done_bytes += size
                    else:
                        body = self._encode(payload.get(id(e), b""), e, dst)
                        out_fh.write(body)
                        dst += len(body)
                        done_bytes += len(payload.get(id(e), b""))
                        if off is not None and old_size is not None:
                            src_cursor = int(off) + int(old_size)
                    _report(name)
                    _done(name, len(payload.get(id(e), b"")) if is_new
                          else int(old_size or 0))

                # Keep the original pad between the last body and the index
                # when the layout is still the source layout.  A tree of empty
                # entries writes no bodies, so the source data region must not
                # be carried over.
                if preserve and dst > 0:
                    gap = int(self.info.index_offset) - src_cursor
                    if gap > 0:
                        self._copy_region(out_fh, src_cursor, gap)
                        dst += gap
                index_offset = dst

                real = self._index_plain(files, dirs)
                plain = self._pad_index(real)
                cipher = self._encrypt_index(plain)
                index_hash = hashlib.sha1(plain).digest()
                out_fh.write(cipher)
                out_fh.write(self._footer(
                    index_hash, len(cipher), index_offset, mem))
                complete = True
            finally:
                out_fh.close()
                if not complete:
                    _quarantine_partial(output_path)
        finally:
            self._close_source()

        if progress:
            try:
                if total_bytes > 0:
                    progress(total_bytes, total_bytes, "")
                else:
                    progress(item_total, item_total, "")
            except Exception:
                pass
        return len(files)

    def _same_tree(self, index):
        """True when the tree being written holds exactly the source paths."""
        cached = getattr(self, "_tree_match", None)
        if cached is not None:
            return cached
        path = str(getattr(self.pak, "file_path", "") or "")
        result = False
        if path and os.path.exists(path):
            try:
                other = self.mod.PakReader(path)
            except Exception:
                other = None
            if other is not None:
                try:
                    paths = set()
                    for d, items in other.dirs.items():
                        for name in items:
                            paths.add(d + name)
                    result = paths == set(index)
                finally:
                    close = getattr(other, "close", None)
                    if close is not None:
                        try:
                            close()
                        except Exception:
                            pass
        self._tree_match = result
        return result

    def _copy_whole(self, output_path):
        out_fh = open(output_path, "wb")
        complete = False
        try:
            left = int(self._file_size())
            off = 0
            while left > 0:
                chunk = self._read(off, min(CHUNK, left))
                if not chunk:
                    raise IOError("source pak ended early at offset %d" % off)
                out_fh.write(chunk)
                off += len(chunk)
                left -= len(chunk)
            complete = True
        finally:
            out_fh.close()
            if not complete:
                _quarantine_partial(output_path)


def _notify_inject_write(pak, mod, edits, output_path, result,
                         target_path, force_add):
    """Give the read-only diagnosis a completed write. Never raises.

    This is a post-write observation only: the writer's return value is
    unchanged, and no diagnosis result feeds back into edits or byte layout.
    """
    try:
        import inject_diagnosis as diag
        if not diag.active():
            return
        fn = getattr(diag, "on_writer_result", None)
        if fn is not None:
            fn(getattr(pak, "file_path", ""), output_path, edits, mod,
               result, target_path=target_path, force_add=force_add)
    except Exception:
        pass


def make_inject(mod):
    """Return an ``inject_files`` method bound to the given pak module."""

    def inject_files(self, edits, output_path, force_add=False,
                     target_path=None, progress=None, on_file=None):
        result = _Core(self.pak, mod).inject_files(
            edits, output_path, force_add=force_add,
            target_path=target_path, progress=progress, on_file=on_file)
        _notify_inject_write(self.pak, mod, edits, output_path, result,
                             target_path, force_add)
        return result

    return inject_files
