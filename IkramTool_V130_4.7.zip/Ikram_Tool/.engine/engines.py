"""Engine dispatch layer for the shipped IkramTool PAK TOOL.

Loads the SAME flat compiled runtime modules the tool already runs on
(pak.pyc / ue4.pyc via importlib) and implements the fallback chains
from paktoolproject.txt behind the three PAK TOOL options:

  UNPACK : tencent -> ikram-custom
           ue4     -> repak -> python-ue4 (Ue4Pak + AES key)
  INJECT : tencent -> ikram-custom (PakWriter.inject_files)
           ue4     -> repak-inject (v10+) -> python-ue4 (Ue4Pak.repack)
  REPACK : tencent -> ikram-custom (PakWriter full-tree)
           ue4     -> repak-pack -> python-ue4 (Ue4Pak.repack)

Works in the shipped flat runtime (ikram_patch.py entry) with no
.pyc recompile needed -- engines.py ships as source.
"""

# Error log. Hard import on purpose: ikram_logger ships in this directory
# and its own entry points are non-raising by construction, so a missing
# logger is a broken install that must fail loudly at import -- not a
# silent no-op that would swallow every record of what went wrong.
import ikram_logger
import hashlib
import importlib.util
import json
import os
import paths
import shutil
import tempfile
import time
from pathlib import Path, PurePosixPath

MAGIC_BYTES = b"\xe1\x12\x6f\x5a"
REPAK_TIMEOUT = 1800
TOOL_DIR = Path(__file__).resolve().parent

# Footer scan is bounded but wider than the old 4 KiB window. Tencent footer
# and UE4 magic both sit at EOF; a larger window removes classification drift
# on paks with large encrypted index trailers without scanning the whole file.
FOOTER_WINDOW = 64 * 1024
HASH_CHUNK = 1024 * 1024
_PAK_INVALID_CHARS = frozenset(':*?"<>|\x00\\')

# Deterministic unpack state. The compiled reader hashes every entry again
# during verification; the source unpacker records SHA1 once in the same pass
# and verification reuses it. Keyed by path/size/mtime so a stale cache can
# never vouch for a different pak.
_LAST_UNPACK_HASHES = {"key": None, "hashes": {}}
_LAST_TENCENT_EXTRACT_ERRORS = []
_LAST_TENCENT_STATE = {
    "key": None,
    "dirs": None,
    "file_size": 0,
    "mount": "",
    "hashes": {},
    "undec": [],
}
_LAST_EXTRACT_REPORT = None

SKIP_DECOY = "DECOY"
SKIP_UNSAFE_PATH = "UNSAFE_PATH"
SKIP_CASE_COLLISION = "CASE_COLLISION"
EXTRACT_FAILED = "EXTRACT_FAILED"
SKIP_UNSUPPORTED_ENC = "UNSUPPORTED_ENC"
EXTRACT_REASONS = (
    SKIP_DECOY,
    SKIP_UNSAFE_PATH,
    SKIP_CASE_COLLISION,
    SKIP_UNSUPPORTED_ENC,
    EXTRACT_FAILED,
)


def _new_extract_report():
    return {
        "written": 0,
        "on_disk": 0,
        "skipped": [],
        "by_reason": {reason: 0 for reason in EXTRACT_REASONS},
        "good": 0,
        "bad": 0,
        "trimmed": 0,
        "consumed": False,
    }


def _record_skip(report, rel, reason, detail=None):
    text = _normalized_rel(rel) or str(rel)
    report["skipped"].append({
        "rel": text,
        "reason": reason,
        "detail": str(detail or "")[:300],
    })
    report["by_reason"][reason] += 1


def consume_extract_report():
    """One-shot handoff of the last extraction report to the UI/harness."""
    global _LAST_EXTRACT_REPORT
    report = _LAST_EXTRACT_REPORT
    if report is not None:
        report["consumed"] = True
    return report


def _pak_cache_key(pakf):
    try:
        p = Path(pakf).resolve()
        st = p.stat()
        return (str(p), int(st.st_size), int(st.st_mtime_ns))
    except OSError:
        return (str(pakf), None, None)


def _clean_pak_part(part):
    text = "".join(ch for ch in str(part or "") if ch not in _PAK_INVALID_CHARS)
    text = text.strip().strip(".")
    return text or "file"


def _normalized_rel(value):
    """One separator and traversal policy for Windows, Linux and Termux."""
    out = []
    for part in str(value or "").replace("\\", "/").split("/"):
        if not part or part in (".", ".."):
            continue
        out.append(_clean_pak_part(part))
    return "/".join(out)


def _safe_mount_rel(mount):
    """DeterministicPurePath replacement for pak.pyc's OS-selected PurePath."""
    parts = []
    for part in str(mount or "").replace("\\", "/").split("/"):
        if not part or part in (".", ".."):
            continue
        parts.append(_clean_pak_part(part))
    return "/".join(parts)


def _fake_pak_entry(entry, file_size):
    """Mirror pak.pyc's decoy guard: entries whose data is outside the file."""
    try:
        if int(entry.offset) >= int(file_size):
            return True
        if int(entry.size) > int(file_size):
            return True
        blocks = getattr(entry, "compressed_blocks", None)
        if blocks:
            return any(int(b.start) >= int(file_size) or int(b.end) > int(file_size)
                       for b in blocks)
        return int(entry.offset) + int(entry.size) > int(file_size)
    except (AttributeError, TypeError, ValueError):
        return True


def _entry_stored_sha1(reader, entry):
    """Hash the raw stored bytes without buffering a whole 200 MB entry."""
    digest = hashlib.sha1()
    try:
        pos = int(entry.offset)
        left = int(entry.size)
    except (AttributeError, TypeError, ValueError):
        return digest.digest()
    while left > 0:
        chunk = reader._read_at(pos, min(HASH_CHUNK, left))
        if not chunk:
            break
        digest.update(chunk)
        pos += len(chunk)
        left -= len(chunk)
    return digest.digest()


def _fs_case_sensitive(base=None):
    """True when two names differing only by case can coexist on ``base``.

    Case-only renames in an extracted tree are only representable on a
    case-sensitive filesystem. On Windows the rename is cosmetic, so keeping
    the source casing is correct instead of creating two game entries.
    """
    root = Path(base) if base is not None else Path(tempfile.gettempdir())
    token = "ikram_case_{}_Aa".format(os.getpid())
    upper = root / token
    lower = root / token.lower()
    try:
        root.mkdir(parents=True, exist_ok=True)
        if upper.exists() or lower.exists():
            return False
        upper.write_bytes(b"")
        try:
            lower.write_bytes(b"")
        except FileExistsError:
            return False
        return upper.exists() and lower.exists() and upper != lower
    except OSError:
        return False
    finally:
        for p in (upper, lower):
            try:
                p.unlink(missing_ok=True)
            except OSError:
                pass


def _pak_tool_candidates(name):
    """Tool-root candidates for this OS.

    Windows cannot execute the ELF builds that sit at the tool root, and does
    need the .exe suffix on the name; keep the two lists separate so a stray
    ELF file never wins on Windows.
    """
    if os.name == "nt":
        return [TOOL_DIR / (name + ".exe"),
                TOOL_DIR / "lua_bin" / "windows" / (name + ".exe"),
                Path.home() / ".cargo" / "bin" / (name + ".exe"),
                TOOL_DIR / "engines" / (name + ".exe")]
    return [Path.home() / ".cargo" / "bin" / name,
            TOOL_DIR / name,
            TOOL_DIR / "lua_bin" / "linux" / name,
            TOOL_DIR / "engines" / name]


REPAK_CANDIDATES = _pak_tool_candidates("repak")
QUICKBMS_CANDIDATES = [
    Path.home() / "quickbms" / "quickbms",
    Path.home() / "bin" / "quickbms",
]
U4PAK_CANDIDATES = [
    Path.home() / ".local" / "bin" / "u4pak",
    Path.home() / "bin" / "u4pak",
]

_pakmod = None
_ue4mod = None


def _load_flat(name):
    """Load a flat compiled module (pak.pyc / ue4.pyc) like ikram_patch does."""
    spec = importlib.util.spec_from_file_location(name, TOOL_DIR / f"{name}.pyc")
    if spec is None or spec.loader is None:
        raise ImportError(f"{name}.pyc not found in {TOOL_DIR}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _install_unk2_fix(pak):
    """Install the byte-correct Tencent writer over pak.pyc's PakWriter.

    The compiled writer kept the OLD entry's unk2 on replaced files, wrote a
    path hash in place of unk2 on new ones, padded shrunken payloads with a
    text marker, spliced block windows instead of re-encoding, and appended a
    zero pad before the index.

    tencent_pak.py is derived from the reader and 41 real paks: it reproduces
    the index plaintext, the AES index ciphertext and the masked footer tail
    of every one of them byte-for-byte, copies kept bodies verbatim (so SM4
    bodies survive), and re-encodes only bodies whose payload actually
    changed.
    """
    if getattr(pak, "_unk2_fix", False):
        return
    spec = importlib.util.spec_from_file_location(
        "tencent_pak", TOOL_DIR / "tencent_pak.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    pak.PakWriter.inject_files = mod.make_inject(pak)
    pak._unk2_fix = True


def _tencent_unpack(pak_path, out_dir, log=None, progress=None, on_file=None):
    """Source replacement for pak.pyc.unpack_pak.

    One pass over the index, one open reader, one hash per payload. The UI gets
    the real row when an entry starts (not five minutes later), byte callbacks
    during large entries, and a deterministic tree on Windows and Termux.
    Unsupported encryption is skipped before the compiled reader can retry the
    same payload through twenty alternate methods.
    """
    log = log or (lambda *a, **k: None)
    progress = progress or (lambda *a, **k: None)
    on_file = on_file or None
    global _LAST_UNPACK_HASHES, _LAST_TENCENT_EXTRACT_ERRORS
    global _LAST_TENCENT_STATE, _LAST_EXTRACT_REPORT
    pak_path = Path(pak_path)
    cache_key = _pak_cache_key(pak_path)
    hashes = {}
    errors = []
    undecryptable = set()
    report = _new_extract_report()
    reader = pakmod().PakReader(str(pak_path))
    with reader:
        file_size = reader._file_size()
        mount_rel = _safe_mount_rel(getattr(reader, "mount_point", ""))
        base = Path(out_dir) / mount_rel
        fs_base = paths.extended_path(base)
        fs_base.mkdir(parents=True, exist_ok=True)

        dirs_snapshot = {dp: dict(files) for dp, files in reader.dirs.items()}
        candidates = []
        seen_case = set()
        for dirpath, files in dirs_snapshot.items():
            for name, entry in files.items():
                raw = "{}{}".format(dirpath, name) if dirpath else name
                safe = _normalized_rel(raw)
                if not safe:
                    _record_skip(report, raw, SKIP_UNSAFE_PATH)
                    continue
                if _fake_pak_entry(entry, file_size):
                    _record_skip(report, safe, SKIP_DECOY)
                    continue
                if (getattr(entry, "encrypted", False)
                        and getattr(entry, "encryption_method", 0)
                        not in TENCENT_SUPPORTED_ENC):
                    undecryptable.add(getattr(entry, "encryption_method", 0))
                    _record_skip(report, safe, SKIP_UNSUPPORTED_ENC,
                                 "method " + str(getattr(entry, "encryption_method", 0)))
                    continue
                case_key = safe.casefold()
                if case_key in seen_case:
                    _record_skip(report, safe, SKIP_CASE_COLLISION)
                    continue
                seen_case.add(case_key)
                candidates.append((safe, entry))
        candidates.sort(key=lambda item: (item[0].casefold(), item[0]))

        entry_out_size = getattr(pakmod(), "_entry_out_size", None)
        total_bytes = sum(entry_out_size(e) for _, e in candidates) if entry_out_size else 0
        done = 0
        last_tick = 0.0

        for safe, entry in candidates:
            hashes[safe] = _entry_stored_sha1(reader, entry)
            target = fs_base.joinpath(*safe.split("/"))
            expected_size = int(getattr(entry, "uncompressed_size", 0) or 0)
            reported = False
            if on_file:
                try:
                    on_file(safe, expected_size)
                    reported = True
                except Exception as _ikram_exc:
                    ikram_logger.log_exc("engines._tencent_unpack:on_file", _ikram_exc)
            entry_done = [0]

            def _on_bytes(amount, _safe=safe, _expected=expected_size):
                nonlocal last_tick
                try:
                    if isinstance(amount, (bytes, bytearray, memoryview)):
                        n = len(amount)
                    else:
                        n = int(amount or 0)
                except (TypeError, ValueError):
                    n = 0
                # Several encrypted methods read back longer than the index's
                # authoritative uncompressed_size. Never report more bytes than
                # the entry can legitimately own.
                entry_done[0] += min(max(0, n), max(0, _expected - entry_done[0]))
                now = time.monotonic()
                if total_bytes > 0 and (now - last_tick >= 0.12 or
                                        done + entry_done[0] >= total_bytes):
                    progress(done + entry_done[0], total_bytes, _safe)
                    last_tick = now

            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                with open(target, "wb") as out_fh:
                    size = reader.read_entry_stream(entry, out_fh,
                                                    on_bytes=_on_bytes)
                    out_fh.flush()
                    actual = out_fh.tell()
                    if actual > expected_size:
                        out_fh.truncate(expected_size)
                        report["trimmed"] += 1
                        size = expected_size
                    else:
                        size = int(size or actual)
                done += int(size or entry_done[0])
                if total_bytes > 0:
                    progress(done, total_bytes, safe)
                report["written"] += 1
                if not reported:
                    log("  {}  ({} bytes)".format(safe, size))
            except Exception as exc:
                ikram_logger.log_exc("engines._tencent_unpack:entry", exc)
                errors.append((safe, str(exc)))
                _record_skip(report, safe, EXTRACT_FAILED, exc)
                try:
                    target.unlink(missing_ok=True)
                except OSError:
                    pass

    report["on_disk"] = report["written"]
    _LAST_UNPACK_HASHES = {"key": cache_key, "hashes": hashes}
    _LAST_TENCENT_EXTRACT_ERRORS = errors
    _LAST_TENCENT_STATE = {
        "key": cache_key,
        "dirs": dirs_snapshot,
        "file_size": file_size,
        "mount": mount_rel,
        "hashes": hashes,
        "undec": sorted(undecryptable),
    }
    _LAST_EXTRACT_REPORT = report
    return report["written"]


def _install_pak_fixes(pak):
    """Guarded source overrides for the compiled Tencent runtime."""
    if getattr(pak, "_ikram_unpack_patched", False):
        return
    for needed in ("PakReader", "unpack_pak", "Reader", "_entry_out_size"):
        if not hasattr(pak, needed):
            pak._ikram_unpack_patch_error = (
                "pak.pyc no longer exposes %r; deterministic unpack skipped" % needed)
            return

    # pak.pyc uses the module global PurePath in index/mount parsing. On
    # Windows that is PureWindowsPath and on Termux PurePosixPath, so a
    # backslash in an index row changes crypto stems and canonical keys per OS.
    # Filesystem I/O keeps the native Path; only the parser becomes POSIX.
    pak._original_PurePath = getattr(pak, "PurePath", None)
    pak.PurePath = PurePosixPath
    pak._ikram_purepath_patched = True

    orig_zstd = pak.PakReader._load_zstd_dict

    def _load_zstd_dict(self):
        # Same format as pak.pyc, but Path(dp).name is POSIX on Termux and
        # Windows on PC. Normalising here keeps zstd dictionary paks identical.
        for dirpath, files in self.dirs.items():
            name = _normalized_rel(dirpath).rsplit("/", 1)[-1]
            if name != "zstddic" or len(files) != 1:
                continue
            entry = next(iter(files.values()))
            data = self.read_entry(entry)
            r = pak.Reader(data)
            dict_size = r.u8()
            r.u4()
            if dict_size == r.u4():
                import zstandard
                self._zstd_dict = zstandard.ZstdCompressionDict(r.s(dict_size))
            return None
        return None

    pak.PakReader_original_load_zstd_dict = orig_zstd
    pak.PakReader._load_zstd_dict = _load_zstd_dict
    pak.PakReader_original_unpack = pak.unpack_pak
    pak.unpack_pak = _tencent_unpack
    pak._ikram_unpack_patched = True


def pakmod():
    global _pakmod
    if _pakmod is None:
        _pakmod = _load_flat("pak")
        _install_unk2_fix(_pakmod)
        _install_pak_fixes(_pakmod)
    return _pakmod


def ue4mod():
    global _ue4mod
    if _ue4mod is None:
        _ue4mod = _load_flat("ue4")
        _patch_ue4module(_ue4mod)
    return _ue4mod


def _patch_ue4module(mod):
    """Fix compiled ue4.pyc flaws without recompiling:

    1. _parse_full_directory_index read the FDI blob RAW and never
       decrypted it when the pak index is encrypted -> crash on
       v10+ encrypted paks. Mirror repak: seek fdi_off, read
       fdi_size, AES-ECB decrypt when footer.encrypted.
    2. Same method joined paths as dir_name.strip('/') + fname,
       wiping the trailing '/' -> 'ContentLuagame.lua'. Mirror
       repak: prefix-strip only, keep the separator.
    3. _parse_footer only assigns self.compression_u8 when version == 8.
       For every other version (V1-V7, which is what real game paks ship)
       the attribute keeps its __init__ default of False. _compression_method
       then compared that bool against int (TypeError: '<' not supported
       between instances of 'str' and 'int'), and read_file fell through to
       zstd on zlib blocks -> 'Error -5 while decompressing data'. Fix:
       normalise the method string, and let _decompress sniff the stream when
       the declared method fails. zlib/gzip/zstd/lz4 frames are
       self-identifying, so sniffing is safe across versions instead of
       guessing a per-version footer offset repak does not always write.

    WHY THIS STAYS A MONKEYPATCH INSTEAD OF A REBUILD
    ue4.pyc ships as a compiled payload artifact. Rebuilding it from
    source re-marshals the module and changes its bytecode, and every
    sibling .pyc in the release is marshalled against the same Python
    3.14 header - so the fix is cheaper to maintain as a guarded
    override than as a recompile the release cannot reproduce. The cost
    is coupling to ue4.pyc internals, which is what the attribute checks
    above exist to police.
    """
    # Idempotence: ue4mod() may be called many times per session.
    if getattr(mod, "_ikram_fdi_patched", False):
        return

    # The closure below captures these off `mod`. The old code wrapped
    # everything in a bare `except: return`, so if a future rebuild of
    # ue4.pyc renamed any of them the override failed SILENTLY and every
    # encrypted pak went back to crashing with no hint the fix was gone.
    for _needed in ("aes_ecb_decrypt", "Reader", "read_encoded_entry",
                    "Ue4Pak", "align"):
        if not hasattr(mod, _needed):
            mod._ikram_fdi_patch_error = (
                "ue4.pyc no longer exposes %r; FDI override skipped - a rebuilt"
                " ue4.pyc needs this fix merged into its own"
                " _parse_full_directory_index" % _needed)
            return
    for _needed in ("_parse_full_directory_index", "_decompress",
                    "_compression_method", "read_file"):
        if not hasattr(mod.Ue4Pak, _needed):
            mod._ikram_fdi_patch_error = (
                "ue4.pyc Ue4Pak no longer exposes %r; FDI/decompression"
                " overrides skipped - a rebuilt ue4.pyc needs these fixes"
                " merged into its own methods" % _needed)
            return
    try:
        orig = mod.Ue4Pak._parse_full_directory_index
    except AttributeError as _ikram_exc:
        ikram_logger.log_exc("engines._patch_ue4module:115", _ikram_exc)
        mod._ikram_fdi_patch_error = (
            "ue4.pyc Ue4Pak has no _parse_full_directory_index;"
            " the FDI override target moved")
        return
    aes_ecb_decrypt = mod.aes_ecb_decrypt
    import struct as _st

    def _parse_full_directory_index(self, fdi_off, fdi_size, non_encoded, encoded_blob):
        blob = bytes(self.content[fdi_off:fdi_off + fdi_size])
        if self.encrypted_index:
            if not self.aes_key:
                raise ValueError("Index encrypted — AES key required (FDI)")
            blob = aes_ecb_decrypt(blob, self.aes_key)
        r = mod.Reader(blob)
        dir_count = r.u4()
        for _ in range(dir_count):
            dir_name = r.fstring()
            file_count = r.u4()
            for _ in range(file_count):
                file_name = r.fstring()
                encoded_offset = _st.unpack_from("<i", blob, r.c)[0]
                r.c += 4
                d = dir_name
                if d.startswith("/"):
                    d = d[1:]
                path = d + file_name
                if encoded_offset == -2147483648:
                    continue
                if encoded_offset >= 0:
                    er = mod.Reader(encoded_blob, encoded_offset)
                    self.entries[path] = mod.read_encoded_entry(er, self.version)
                else:
                    self.entries[path] = non_encoded[(-encoded_offset) - 1]
        return None

    mod.Reader_original_fdi = orig

    # ---- fix 3: compression method normalisation + stream sniffing -------
    _VALID_COMPRESSION = ("zlib", "gzip", "zstd", "lz4")
    orig_decompress = mod.Ue4Pak._decompress
    orig_compression_method = mod.Ue4Pak._compression_method

    def _sniff_decompress(blob):
        """Last-resort decompress when the declared method is wrong/absent."""
        import zlib as _zlib
        try:
            return _zlib.decompress(blob)
        except Exception:
            pass
        try:
            import gzip as _gzip
            return _gzip.decompress(blob)
        except Exception:
            pass
        try:
            import zstandard as _zstd
            return _zstd.ZstdDecompressor().decompress(blob)
        except Exception:
            pass
        try:
            import zstandard as _zstd
            _dobj = _zstd.ZstdDecompressor().decompressobj()
            _out = _dobj.decompress(blob)
            if _out:
                return _out
        except Exception:
            pass
        try:
            import lz4.block as _lz4b
            return _lz4b.decompress(blob)
        except Exception:
            pass
        raise ValueError(
            "No known decompressor could read this pak block "
            "(tried zlib, gzip, zstd, lz4)")

    def _compression_method(self, slot):
        try:
            method = orig_compression_method(self, slot)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("engines._compression_method", _ikram_exc)
            method = None
        if isinstance(method, bytes):
            method = method.decode("utf-8", "replace")
        if isinstance(method, str) and method.lower() in _VALID_COMPRESSION:
            return method.lower()
        if method is None or method is False:
            return "zlib"
        return "zlib"

    def _decompress(self, blob, comp):
        if isinstance(comp, bytes):
            comp = comp.decode("utf-8", "replace")
        name = comp.lower() if isinstance(comp, str) else None
        if name in _VALID_COMPRESSION:
            try:
                return orig_decompress(self, blob, comp)
            except Exception as _ikram_exc:
                ikram_logger.log_exc("engines._decompress:declared", _ikram_exc)
        return _sniff_decompress(blob)

    mod.Ue4Pak._compression_method = _compression_method
    mod.Ue4Pak._decompress = _decompress
    mod._ikram_decompress_patched = True

    # ---- fix 4: read_file double-added the entry offset ------------------
    # read_encoded_entry already stores ABSOLUTE content offsets in
    # Block.start/.end, but read_file computed block_off = e.offset + b.start.
    # That lands past EOF for every entry except the one at offset 0 (which
    # is why a single-entry pak 'worked'), so the slice came back empty and the
    # block decompressed to b'' instead of raising. Mirror repak: use b.start
    # as-is.
    orig_read_file = mod.Ue4Pak.read_file

    def _read_file(self, path):
        e = self.entries.get(path)
        if e is None:
            return None
        off = e.offset
        hdr = e.serialized_size(self.version, self.compression_u8)
        if off + hdr > len(self.content):
            return None
        data_off = off + hdr
        encrypted = e.is_encrypted()
        total = mod.align(e.compressed) if encrypted else e.compressed
        raw = bytes(self.content[data_off:data_off + total])
        if encrypted:
            if not self.aes_key:
                raise ValueError(
                    "Encrypted data - AES key required (%s)" % path)
            raw = mod.aes_ecb_decrypt(raw, self.aes_key)
        if e.compression_slot is None:
            return raw
        comp = self._compression_method(e.compression_slot)
        if not e.blocks:
            return self._decompress(raw, comp)
        out = bytearray()
        for b in e.blocks:
            block_off = b.start
            piece = bytes(self.content[block_off:block_off + (b.end - b.start)])
            out += self._decompress(piece, comp)
        return bytes(out)

    mod.Ue4Pak_original_read_file = orig_read_file
    mod.Ue4Pak.read_file = _read_file
    mod._ikram_read_file_patched = True

    # compiled extract_all fed raw index strings to PosixPath on Termux, which
    # turned 'Content\Lua\game.lua' into one literal filename and let '..'
    # escape out_dir. Replace it with the same normaliser Tencent unpack uses.
    orig_extract_all = mod.Ue4Pak.extract_all

    def _extract_all(self, out_dir):
        out = Path(out_dir)
        errors = []
        seen = set()
        count = 0
        for raw_path in self.files():
            safe = _normalized_rel(raw_path)
            if not safe:
                errors.append((str(raw_path), "unsafe path"))
                continue
            key = safe.casefold()
            if key in seen:
                continue
            seen.add(key)
            target = paths.extended_path(out.joinpath(*safe.split("/")))
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                data = self.read_file(raw_path)
                if data is None:
                    errors.append((str(raw_path), "no data"))
                    continue
                target.write_bytes(data)
                count += 1
            except Exception as exc:
                ikram_logger.log_exc("engines._extract_all:entry", exc)
                errors.append((str(raw_path), str(exc)))
                try:
                    target.unlink(missing_ok=True)
                except OSError:
                    pass
        self._ikram_extract_errors = errors
        return count

    mod.Ue4Pak_original_extract_all = orig_extract_all
    mod.Ue4Pak.extract_all = _extract_all
    mod._ikram_extract_all_patched = True
    mod.Ue4Pak._parse_full_directory_index = _parse_full_directory_index
    mod._ikram_fdi_patched = True


def _which_try(first, *extra):
    for cmd in (first,) + extra:
        p = shutil.which(cmd)
        if p:
            return Path(p)
    return None


def find_repak():
    p = _which_try("repak")
    if p:
        return p
    for c in REPAK_CANDIDATES:
        if c.is_file() and os.access(c, os.X_OK):
            return c
    return None


def find_quickbms():
    p = _which_try("quickbms")
    if p:
        return p
    for c in QUICKBMS_CANDIDATES:
        if c.is_file() and os.access(c, os.X_OK):
            return c
    return None


def find_u4pak():
    p = _which_try("u4pak")
    if p:
        return p
    for c in U4PAK_CANDIDATES:
        if c.is_file() and os.access(c, os.X_OK):
            return c
    return None


def repak_hint():
    return ("repak install: pkg install rust && cargo install repak_cli "
            "--git https://github.com/trumank/repak --no-default-features --locked")


def detect_kind(path):
    """'ue4' | 'tencent' | None from magic bytes."""
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - FOOTER_WINDOW))
            tail = f.read(FOOTER_WINDOW)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("engines.detect_kind:208", _ikram_exc)
        return None
    if MAGIC_BYTES in tail:
        return "ue4"
    if size >= 45 and len(tail) >= 44:
        try:
            import struct
            magic = struct.unpack_from("<I", tail[-44:-40])[0]
            if magic ^ pakmod().pc.zuc_keystream()[2] == 0x4C515443:
                return "tencent"
        except Exception as _ikram_exc:
            ikram_logger.log_exc("engines.detect_kind:219", _ikram_exc)
            return None
    return None


def _run(args, log=None, timeout=REPAK_TIMEOUT):
    import subprocess as sp
    log = log or (lambda *a, **k: None)
    log("  engine: {} ...".format(" ".join(str(a) for a in args[:3])))
    r = sp.run([str(a) for a in args], capture_output=True, timeout=timeout)
    if r.stdout:
        log("  " + r.stdout.decode(errors="replace").strip())
    if r.returncode != 0:
        raise RuntimeError(
            "repak failed: "
            + (r.stderr.decode(errors="replace").strip()[-300:] or f"exit {r.returncode}")
        )
    return r


def _ue4_meta(pakf, aes_key=None):
    aes_key = _resolve_ue4_key(pakf, aes_key or None, (lambda *a, **k: None))
    p = ue4mod().Ue4Pak(pakf, aes_key=aes_key)
    v = getattr(p, "version", None) or getattr(p, "version_num", None)
    mount = getattr(p, "mount_point", None) or "../../../"
    comp = getattr(p, "compression_u8", None)
    return v, mount, comp


def _repak_version_str(version, compression_u8):
    if version == 8:
        return "V8A" if compression_u8 else "V8B"
    if isinstance(version, int) and 1 <= version <= 11:
        return f"V{version}"
    return "V8B"


# ---------------------------------------------------------------------------
# V112 — multi-AES-key auto-try + working-key persistence (PakEngine keys).
# Keys are stored INSIDE the tool's runtime dir (.engine/pak_keys.json) so the
# install leaves exactly .engine / DROP / RESULT and no file is ever written
# to the home directory.
# ---------------------------------------------------------------------------
DEFAULT_UE4_KEYS = [
    # PUBG/BGMI global UE4 AES key (shipped default).
    "8A75AFDF1C74AB55B79DC1DD4ABE4B01360A059D77F243EF4EFADA41A59D71A0",
]

KEY_STORE = Path(__file__).resolve().parent / "pak_keys.json"


def _khex(key):
    """Hex key (0x/-/space tolerant) -> lowercase hex, or None."""
    if key is None:
        return None
    h = str(key).strip().replace("0x", "").replace("0X", "").replace("-", "").replace(" ", "")
    try:
        b = bytes.fromhex(h)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("engines._khex:279", _ikram_exc)
        return None
    return b.hex().lower() if len(b) in (16, 24, 32) else None


def _load_saved_keys():
    try:
        import json
        if KEY_STORE.is_file():
            d = json.loads(KEY_STORE.read_text(errors="ignore"))
            return [_khex(k) for k in dict.fromkeys(d.get("keys", ())) if _khex(k)]
    except Exception as _ikram_exc:
        ikram_logger.log_exc("engines._load_saved_keys:291", _ikram_exc)
        pass
    return []


def _save_keys(keys):
    try:
        import json
        KEY_STORE.parent.mkdir(parents=True, exist_ok=True)
        KEY_STORE.write_text(json.dumps({"keys": keys}, indent=1))
    except Exception as _ikram_exc:
        ikram_logger.log_exc("engines._save_keys:302", _ikram_exc)
        pass


def _key_candidates(aes_key=None):
    """Ordered, deduped key list: explicit > saved > shipped defaults."""
    out = []
    if aes_key:
        out.append(_khex(aes_key))
    for k in _load_saved_keys() + DEFAULT_UE4_KEYS:
        h = _khex(k)
        if h and h not in out:
            out.append(h)
    return out


def _ue4_path_score(paths):
    """Reject garbage indexes: a wrong AES key decrypts random bytes."""
    if not paths:
        return 0.0
    good = 0
    for raw in paths[:64]:
        text = str(raw).replace("\\", "/").strip("/")
        if not text or any(ord(ch) < 32 for ch in text):
            continue
        if "/" not in text and "." not in text:
            continue
        good += 1
    return float(good) / float(min(64, len(paths)))


def _try_ue4_key(pakf, key_hex):
    """True only when the key parses a plausible index and reads real bytes."""
    key = bytes.fromhex(key_hex)
    p = ue4mod().Ue4Pak(pakf, aes_key=key)
    ents = list(p.files())
    if not ents or _ue4_path_score(ents) < 0.6:
        return False
    checked = 0
    for path in ents[:5]:
        try:
            data = p.read_file(path)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("engines._try_ue4_key:330", _ikram_exc)
            return False
        if not data:
            return False
        checked += 1
    return checked > 0


def _resolve_ue4_key(pakf, aes_key=None, log=None):
    """AES key for a UE4 pak. None given -> auto-try saved-then-default keys,
    persist whichever one works first. Falls back to the shipped default so
    existing behaviour is never a regression."""
    log = log or (lambda *a, **k: None)
    if _khex(aes_key):
        return aes_key
    if not _khex(DEFAULT_UE4_KEYS[0]):
        return aes_key
    cands = _key_candidates(aes_key)
    tried = []
    for h in cands[1:] if aes_key else cands:
        tried.append(h)
        try:
            if _try_ue4_key(pakf, h):
                saved = _load_saved_keys()
                if not saved or saved[0] != h:
                    _save_keys([h] + [s for s in saved if s != h])
                log("  ue4 key: auto -> %s… (saved)" % h[:8])
                return h
        except Exception as _ikram_exc:
            ikram_logger.log_exc("engines._resolve_ue4_key:359", _ikram_exc)
            continue
    log("  ue4 key: none matched (%d tried) — default fallback" % len(tried))
    return _khex(aes_key) or DEFAULT_UE4_KEYS[0]


def _oodle_stats(pakf, aes_key=None):
    """Count Oodle-compressed (method slot) entries.
    0 for uncompressed/none; -1 when the whole pak is unreadable."""
    try:
        p = ue4mod().Ue4Pak(pakf, aes_key=aes_key)
        n = 0
        for e in __import__("itertools").chain(
            getattr(p, "entries", {}).values(), ()
        ):
            slot = getattr(e, "compression_slot", None)
            if slot is None:
                continue
            try:
                if p._compression_method(slot) == "oodle":
                    n += 1
            except Exception as _ikram_exc:
                ikram_logger.log_exc("engines._oodle_stats:381", _ikram_exc)
                continue
        return n
    except Exception as _ikram_exc:
        ikram_logger.log_exc("engines._oodle_stats:385", _ikram_exc)
        return -1


# Method 17 uses the same SIMPLE2 xor-chain as method 16. Methods 31..55 use the
# full 25-entry secret table; ikram_patch extends pakcrypto.SM4_SECRET_NEW from
# the shipped 19 entries to 25 at import, so 53..55 decrypt correctly and must
# not be quarantined. The old range stopped at 52 and moved good em=55 payloads
# (a real uasset/uexp pair read back with a valid 0x9E2A83C1 header) into
# _quarantine as "undecryptable".
TENCENT_SUPPORTED_ENC = (0, 1, 2, 4, 16, 17, *range(31, 56))

# Last tencent verification result, so the UI layer can re-print it AFTER the
# live progress region closes. Log lines passed into unpack_pak land inside
# ikram._ProgressUI and are wiped the moment its `with` block exits, so a
# quarantine warning printed through log= vanishes before the user can read it.
_LAST_TENCENT_VERIFY = (None, None, None)


def verify_tencent_unpack(pakf, out_dir, log=None):
    """Check an extracted Tencent tree against the pak's own SHA1 index.

    Every Tencent entry stores `content_hash` = SHA1 of its raw stored bytes
    (verified empirically: sha1(raw[offset:offset+size]) == content_hash, for
    both compressed and empty entries). That makes a faithful, self-describing
    integrity check available without trusting the decompressor.

    Two distinct faults get named instead of being passed off as a good unpack:
      CORRUPT - the pak's own stored bytes no longer match its index, so the
                data on disk is provably not what the archive declares.
      MISSING - the index is clean but nothing landed at that path, i.e. the
                extract dropped an entry.

    A third fault was added after testing real PUBG paks: UNDECRYPTABLE. The
    SHA1 index only proves the STORED bytes are intact. A Tencent entry with an
    encryption_method this build cannot decrypt passes that check while the file
    written to disk is the raw encrypted payload - which looks like a normal
    extracted file and is not one. Measured on game_patch_4.6.0.21550.pak:
    method 16 entries extracted as readable text, every method 50 entry came out
    as noise, and the old verifier still reported "0 mismatched". Verified
    methods live in TENCENT_SUPPORTED_ENC; anything else is reported and
    quarantined instead of being passed off as a good extract.

    Returns (good, bad) as lists of pak-relative paths.

    When quarantine=True (the default) every path named in `bad` is MOVED out
    of out_dir into out_dir/_quarantine/, mirroring its relative position. A
    user who ignores the warning is otherwise left holding garbage that looks
    exactly like a good extract, and the whole point of this check is that they
    should not be able to.
    """
    log = log or (lambda *a, **k: None)
    out_dir = Path(out_dir)
    good, bad = [], []
    cache_key = _pak_cache_key(pakf)
    state = (_LAST_TENCENT_STATE
             if _LAST_TENCENT_STATE.get("key") == cache_key else None)
    reader = None
    if state is not None:
        dirs = state["dirs"]
        file_size = state["file_size"]
        mount_rel = state.get("mount", "")
        cache = state["hashes"]
    else:
        reader = pakmod().PakReader(str(pakf))
        dirs = reader.dirs
        file_size = reader._file_size()
        mount_rel = _safe_mount_rel(getattr(reader, "mount_point", ""))
        cache = (_LAST_UNPACK_HASHES["hashes"]
                 if _LAST_UNPACK_HASHES.get("key") == cache_key else {})
    root, disk = _extracted_root(out_dir, dirs=dirs, file_size=file_size,
                                 mount_rel=mount_rel, log=log)
    seen = set()
    for dirpath, files in dirs.items():
        for fname, entry in files.items():
            raw = "{}{}".format(dirpath, fname) if dirpath else fname
            rel = _normalized_rel(raw)
            case_key = rel.casefold()
            if not rel or case_key in seen or _fake_pak_entry(entry, file_size):
                continue
            seen.add(case_key)
            if (getattr(entry, "encrypted", False)
                    and getattr(entry, "encryption_method", 0)
                    not in TENCENT_SUPPORTED_ENC):
                bad.append(rel)
                log("  ✗ UNDECRYPTABLE {} — encryption method {} is not "
                    "implemented. The pak stores it fine (SHA1 index is clean), "
                    "so this is NOT damage: the bytes on disk are the "
                    "undecrypted payload, not the real file.".format(
                        rel, entry.encryption_method))
                continue
            _stored_sha = cache.get(rel)
            if _stored_sha is None and reader is None:
                bad.append(rel)
                log("  ✗ UNREADABLE {} — verification state was lost".format(rel))
                continue
            if _stored_sha is None:
                try:
                    _stored_sha = _entry_stored_sha1(reader, entry)
                except Exception as e:
                    ikram_logger.log_exc("engines.verify_tencent_unpack:422", e)
                    bad.append(rel)
                    log("  ✗ UNREADABLE {} — index read failed: {}".format(rel, e))
                    continue
            # Zero-length sentinel entries store an all-zero content_hash by
            # design (real empty files store sha1(b"") and pass the plain
            # compare). Flagging them said "pak is damaged" about a clean pak
            # and quarantined good files (STEP4 B10).
            if _stored_sha != entry.content_hash and not (
                    entry.size == 0 and entry.content_hash == b"\x00" * 20):
                bad.append(rel)
                log("  ✗ CORRUPT {} — pak bytes fail the archive's own SHA1 "
                    "index (the pak is damaged, not the tool)".format(rel))
                continue
            if rel not in disk:
                bad.append(rel)
                log("  ✗ MISSING {} — index verified but the file was not "
                    "extracted".format(rel))
                continue
            if disk[rel] != entry.uncompressed_size:
                bad.append(rel)
                log("  ✗ SIZE {} — extracted {} bytes, index requires {}".format(
                    rel, disk[rel], entry.uncompressed_size))
                continue
            good.append(rel)
    if bad:
        _quarantine_bad(out_dir, root, bad, log)
    if reader is not None and hasattr(reader, "close"):
        reader.close()
    return good, bad


def _quarantine_bad(out_dir, root, bad, log=None):
    """Move verified-bad entries into out_dir/_quarantine/ and report where.

    Never deletes: the user may want to inspect a damaged pak, and a wrong
    quarantine that destroys data is worse than the bug it fixes. The move is
    best-effort per file so one locked path cannot abort the rest.
    """
    log = log or (lambda *a, **k: None)
    out_dir = Path(out_dir)
    moved, stuck = 0, 0
    for rel in bad:
        src = paths.extended_path(out_dir / root / rel)
        if not src.is_file():
            continue  # MISSING: nothing on disk to move
        dest = paths.extended_path(out_dir / "_quarantine" / rel)
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                dest.unlink()
            src.replace(dest)
            moved += 1
        except OSError as e:
            ikram_logger.log_exc("engines._quarantine_bad:464", e)
            stuck += 1
            log("  ⚠ could not quarantine {} — still in place: {}".format(rel, e))
    if moved:
        log("  → {} damaged file(s) moved to {}/_quarantine/ (not deleted, "
            "nothing trustworthy left in the extract tree)".format(
                moved, out_dir.name))
    if stuck:
        log("  ⚠ {} damaged file(s) could NOT be moved and remain in the "
            "extract tree. Do not use them.".format(stuck))


def _extracted_root(out_dir, reader=None, log=None, dirs=None, file_size=None,
                    mount_rel=None):
    """Find the real extract root and index disk paths in one tree walk.

    The unpacker writes below the pak's mount point, e.g. a 972-file pak with
    mount '../../../ShadowTrackerExtra/' lands in out/ShadowTrackerExtra while
    its index rows stay root-relative. Stripping that mount before matching is
    what keeps 972 good files from being reported as 972 MISSING files.
    """
    log = log or (lambda *a, **k: None)
    out_dir = Path(out_dir)
    fs_out = paths.extended_path(out_dir)
    if dirs is None and reader is not None:
        dirs = reader.dirs
    if file_size is None and reader is not None:
        try:
            file_size = reader._file_size()
        except Exception:
            file_size = 0
    if mount_rel is None and reader is not None:
        mount_rel = _safe_mount_rel(getattr(reader, "mount_point", ""))
    mount_rel = _normalized_rel(mount_rel or "")
    mount_prefix = mount_rel + "/" if mount_rel else ""
    dirs = dirs or {}
    file_size = int(file_size or 0)

    rels = set()
    for dp, files in dirs.items():
        for fn, entry in files.items():
            raw = "{}{}".format(dp, fn) if dp else fn
            safe = _normalized_rel(raw)
            if safe and not _fake_pak_entry(entry, file_size):
                rels.add(safe)
    if not rels or not fs_out.is_dir():
        return Path(""), {}

    all_by_rel = {}
    by_prefix = {}
    for child in fs_out.rglob("*"):
        try:
            if not child.is_file():
                continue
            rel = child.relative_to(fs_out).as_posix().replace("\\", "/")
        except (OSError, ValueError):
            continue
        safe = _normalized_rel(rel)
        if not safe:
            continue
        if mount_prefix and safe.startswith(mount_prefix):
            safe = safe[len(mount_prefix):]
        elif mount_rel and safe == mount_rel:
            safe = ""
        if not safe:
            continue
        try:
            size = child.stat().st_size
        except OSError:
            size = 0
        all_by_rel[safe] = size
        parts = safe.split("/", 1)
        prefix = parts[0] if len(parts) > 1 else ""
        by_prefix.setdefault(prefix, {})[parts[1] if len(parts) > 1 else safe] = size

    candidates = [""]
    try:
        for child in fs_out.iterdir():
            if child.is_dir():
                candidates.append(child.name)
    except OSError as _ikram_exc:
        ikram_logger.log_exc("engines._extracted_root:500", _ikram_exc)
    best, best_hits = "", -1
    for candidate in candidates:
        table = all_by_rel if not candidate else by_prefix.get(candidate, {})
        hits = sum(1 for rel in rels if rel in table)
        if hits > best_hits:
            best, best_hits = candidate, hits
    if best_hits <= 0:
        return Path(""), {}
    if best:
        log("  (extracted tree sits under {}/)".format(best))
    root = Path(mount_rel) if not best else Path(mount_rel) / best
    return root, (all_by_rel if not best else by_prefix.get(best, {}))


def unpack_pak(pakf, out_dir, kind=None, aes_key=None, log=None, progress=None,
               on_file=None):
    """Unpack any pak -> out_dir. Returns file count."""
    log = log or (lambda *a, **k: None)
    progress = progress or (lambda *a, **k: None)
    pakf = Path(pakf)
    kind = kind or detect_kind(pakf)

    if kind == "tencent":
        log("  engine: ikram-custom (tencent)")
        out_dir = Path(out_dir)
        fs_out = paths.extended_path(out_dir)
        fs_out.mkdir(parents=True, exist_ok=True)
        pakmod().unpack_pak(pakf, fs_out, log=log, progress=progress,
                            on_file=on_file)
        if _LAST_TENCENT_EXTRACT_ERRORS:
            log("  ⚠ {} entr{} failed extraction and were removed — no partial "
                "file left in the tree".format(
                    len(_LAST_TENCENT_EXTRACT_ERRORS),
                    "y" if len(_LAST_TENCENT_EXTRACT_ERRORS) == 1 else "ies"))
        # The compiled unpacker is happy to write out bytes that no longer match
        # the archive's own index, and it still reports the full file count. Left
        # unchecked, a damaged pak comes back looking like a clean success and the
        # user edits garbage. Verify, name the bad entries, quarantine them, and
        # hand back only the count we can actually vouch for.
        good, bad = verify_tencent_unpack(pakf, out_dir, log)
        state = (_LAST_TENCENT_STATE
                 if _LAST_TENCENT_STATE.get("key") == _pak_cache_key(pakf) else None)
        undec = list((state or {}).get("undec", []))
        if state is None and bad:
            fallback = pakmod().PakReader(str(pakf))
            try:
                undec = sorted({
                    getattr(e, "encryption_method", None)
                    for files in fallback.dirs.values()
                    for e in files.values()
                    if getattr(e, "encrypted", False)
                    and getattr(e, "encryption_method", 0)
                    not in TENCENT_SUPPORTED_ENC
                })
            finally:
                if hasattr(fallback, "close"):
                    fallback.close()
        if _LAST_EXTRACT_REPORT is not None:
            _LAST_EXTRACT_REPORT["good"] = len(good)
            _LAST_EXTRACT_REPORT["bad"] = len(bad)
        if bad and undec:
            log("  ⚠ {}/{} entries could NOT be decrypted (encryption "
                "method {} not supported by this build). The pak is NOT "
                "damaged - those files were moved to _quarantine/ so you "
                "do not edit undecrypted bytes by mistake.".format(
                    len(bad), len(good) + len(bad),
                    "/".join(str(u) for u in undec)))
        elif bad:
            log("  ⚠ {}/{} entries FAILED verification — the pak itself is "
                "damaged. Only the unlisted files are trustworthy.".format(
                    len(bad), len(good) + len(bad)))
        global _LAST_TENCENT_VERIFY
        _LAST_TENCENT_VERIFY = (list(good), list(bad), undec)
        return len(good)

    if kind == "ue4":
        aes_key = _resolve_ue4_key(pakf, aes_key or None, log)
        try:
            oodle = _oodle_stats(pakf, aes_key)
            if oodle > 0:
                log(
                    "  ⚠ %d Oodle-compressed entries — repak/python are "
                    "Zlib-only, those entries may be partial/dropped"
                    % oodle
                )
            elif oodle < 0:
                log("  ⚠ pak index could not be read for Oodle detection — "
                    "key or archive may be invalid")
        except Exception as _ikram_exc:
            ikram_logger.log_exc("engines.unpack_pak:548", _ikram_exc)
            pass
        out = Path(out_dir)
        fs_out = paths.extended_path(out)
        fs_out.mkdir(parents=True, exist_ok=True)
        repak = find_repak()
        if repak is not None:
            aes_args = ["-a", aes_key] if aes_key else []
            try:
                _run([repak] + aes_args + ["unpack", pakf, "--output", out, "-f"], log)
                return sum(1 for p in fs_out.rglob("*") if p.is_file())
            except Exception as e:
                ikram_logger.log_exc("engines.unpack_pak:559", e)
                log(f"  repak tried, python fallback: {e}")
        p = ue4mod().Ue4Pak(pakf, aes_key=aes_key)
        if p.files() and getattr(p, "encrypted_index", False) and not aes_key:
            log("  (pak index encrypted -- pass AES key)")
        log("  engine: python-ue4 (standard UE4)")
        count = p.extract_all(str(fs_out))
        errors = getattr(p, "_ikram_extract_errors", ())
        if errors:
            log("  ⚠ {} UE4 entr{} failed extraction and were removed".format(
                len(errors), "y" if len(errors) == 1 else "ies"))
        return count

    raise ValueError(f"Unknown pak format (no UE4/Tencent magic): {pakf.name}")


def _repack_skip(rel: str) -> bool:
    """True for tool-internal trees that must never enter a shipped pak.

    `_quarantine/` holds entries Unpack moved aside because they failed the
    readback check, and any `_`/`.` prefixed segment is staging (editor
    backups, IDE state). Packing those built a pak with phantom paths the
    game never had.
    """
    return paths.is_internal_rel(rel)


def repack_folder(pakf, edit_dir, out, kind=None, aes_key=None, log=None):
    """Repack a whole edited folder tree into a pak. Returns file count."""
    log = log or (lambda *a, **k: None)
    pakf = Path(pakf)
    edit_dir = Path(edit_dir)
    out = Path(out)
    if pakf.resolve() == out.resolve():
        raise ValueError("repack output must not overwrite the source pak")
    kind = kind or detect_kind(pakf)

    if kind == "tencent":
        log("  engine: ikram-custom (tencent)")
        with pakmod().PakReader(pakf) as pak:
            existing = pak.full_paths()
            # The extracted tree carries the mount-point path (e.g.
            # ShadowTrackerExtra/...) while full_paths() keys are
            # mount-relative. Normalise before matching so exact path
            # lookup wins and duplicate basenames don't collide.
            mount_rel = str(getattr(pak, "mount_point", "") or "")
            mount_dir = ""
            if mount_rel.count("/") >= 2:
                mount_dir = mount_rel.rstrip("/").rsplit("/", 1)[-1] + "/"
            edits = []
            expected = {}
            output_paths = {}

            def _simple2_template(template, data_len=0):
                safe = template.clone()
                safe.encryption_method = 16
                safe.encrypted = True
                safe.compressed_blocks = []
                if safe.compression_method == 0:
                    safe.compression_method = pakmod().CM_ZLIB
                # The writer derives block geometry itself (one 65536-byte
                # block per chunk), so no block size is forced here.
                return safe

            def _new_file_template(suffix, data_len=0):
                candidates = [e for e in pak.files
                              if Path(existing_path_by_id[id(e)]).suffix.lower() == suffix]
                candidates += [e for e in pak.files if e not in candidates]
                template = next((e for e in candidates
                                 if e.encrypted and e.encryption_method == 16), None)
                if template is None:
                    template = next(iter(candidates), None)
                if template is None:
                    raise ValueError("cannot add files to an empty Tencent pak without a template")
                return _simple2_template(template, data_len)

            existing_path_by_id = {id(e): fp for fp, e in existing.items()}
            # Snapshot before additions: anything here that no edit tree file
            # claims is carried into the output verbatim (merge, not replace).
            original_paths = set(existing)
            case_sensitive = _fs_case_sensitive(edit_dir)

            def _register_new_file(rel, template, data, stem):
                """Route additions through the writer's safe replace path."""
                from pathlib import PurePosixPath
                path = PurePosixPath(rel)
                parent = "" if str(path.parent) == "." else str(path.parent) + "/"
                entry = template.clone()
                entry.compressed_blocks = []
                entry.uncompressed_size = len(data)
                entry.size = 0
                entry.offset = 0
                entry.stem = stem
                if not data:
                    # The writer treats a size-0 record as already encoded and
                    # keeps its template hash. A brand-new empty file has an
                    # empty body, so give it the real empty-body signature or
                    # the readback check rejects it as a stale hash.
                    entry.content_hash = hashlib.sha1(b"").digest()
                    empty_md5 = hashlib.md5(b"").digest()
                    entry.unk2 = empty_md5 + empty_md5[4:8]
                pak.dirs.setdefault(parent, {})[path.name] = entry
                pak.files.append(entry)
                existing[rel] = entry
                existing_path_by_id[id(entry)] = rel
                output_paths[rel] = str(path)

            for p in sorted(edit_dir.rglob("*")):
                if p.is_symlink() or not p.is_file() or p.name.startswith("."):
                    continue
                rel = str(p.relative_to(edit_dir)).replace("\\", "/")
                rel = rel.lstrip("/")
                if _repack_skip(rel):
                    continue
                if rel.startswith(mount_dir):
                    rel = rel[len(mount_dir):]
                target = None
                source_entry = None
                if rel in existing:
                    target = rel
                    source_entry = existing[rel]
                else:
                    for fp in existing:
                        if fp.lower() != rel.lower():
                            continue
                        source_entry = existing[fp]
                        if case_sensitive:
                            # A case-only rename is real on this filesystem.
                            # Re-key the source entry instead of writing the
                            # edited body under the old source casing.
                            from pathlib import PurePosixPath
                            new_path = PurePosixPath(rel)
                            parent_dir = ("" if str(new_path.parent) == "."
                                          else str(new_path.parent) + "/")
                            old_path = PurePosixPath(fp)
                            old_parent = ("" if str(old_path.parent) == "."
                                          else str(old_path.parent) + "/")
                            pak.dirs.get(old_parent, {}).pop(old_path.name, None)
                            pak.dirs.setdefault(parent_dir, {})[new_path.name] = source_entry
                            existing.pop(fp, None)
                            existing[rel] = source_entry
                            existing_path_by_id[id(source_entry)] = rel
                            original_paths.discard(fp)
                            target = rel
                        else:
                            target = fp
                        break
                if target is None:
                    target = rel
                data = p.read_bytes()
                template = None
                if source_entry is None:
                    template = _new_file_template(p.suffix.lower(), len(data))
                    _register_new_file(target, template, data, p.stem)
                elif (source_entry.encrypted
                      and source_entry.encryption_method in range(31, 56)):
                    # Keep original SM4 bytes for untouched files (writer reuses
                    # the exact compressed/encrypted blocks byte-for-byte).
                    # Only re-encode to SIMPLE2 if the file was actually modified.
                    original_data = pak.read_entry(source_entry)
                    if data == original_data:
                        template = source_entry.clone()
                    else:
                        # Keep original SM4 bytes for untouched files. Modified files
                        # use the well-tested SIMPLE2 method so a stale SM4 secret
                        # cannot silently produce a game-invalid payload.
                        template = _simple2_template(source_entry, len(data))
                edits.append((target, (data, template, p.stem)))
                expected[target] = data
                output_paths.setdefault(target, target)
            kept = original_paths - set(expected)
            if kept:
                log("  merge: %d source entries not in the edit tree kept "
                    "verbatim (repack never deletes)" % len(kept))
            pakmod().PakWriter(pak).inject_files(
                edits, str(out), force_add=True
            )
            try:
                with pakmod().PakReader(str(out)) as check:
                    written = check.full_paths()
                    for rel, source in expected.items():
                        entry = written.get(output_paths[rel])
                        if entry is None:
                            raise ValueError("repacked entry missing: " + rel)
                        stored = check._read_at(entry.offset, entry.size)
                        # Empty bodies are legitimately written with an all-zero
                        # content hash by the game's own packer (38 of them in
                        # the corpus) instead of SHA1("") -- so only hold a
                        # non-empty body to the hash.
                        digest = hashlib.sha1(stored).digest()
                        chash = bytes(entry.content_hash)
                        if int(entry.size) or chash.strip(b"\x00"):
                            if digest != chash:
                                raise ValueError("stored SHA1 mismatch: " + rel)
                        if check.read_entry(entry) != source:
                            raise ValueError("payload readback mismatch: " + rel)
            except Exception:
                # Keep failed output beside the result index, not as a loose
                # sibling that the next repack can overwrite.
                quarantine = Path(out).parent / "_UNVERIFIED"
                quarantine.mkdir(parents=True, exist_ok=True)
                failed = quarantine / (Path(out).name + ".UNVERIFIED")
                if failed.exists():
                    n = 1
                    while True:
                        candidate = quarantine / "{}.{}.UNVERIFIED".format(
                            Path(out).name, n)
                        if not candidate.exists():
                            failed = candidate
                            break
                        n += 1
                if Path(out).exists():
                    Path(out).replace(failed)
                raise
            # Report the number of edits applied, not the writer's total entry
            # count: a one-file repack of a 459-entry pak must say 1, not 459.
            return len(edits)

    if kind == "ue4":
        aes_key = _resolve_ue4_key(pakf, aes_key or None, log)
        version, mount_point, compression_u8 = _ue4_meta(pakf, aes_key=aes_key)
        repak = find_repak()
        if repak is not None:
            log("  engine: repak-pack (standard UE4)")
            with tempfile.TemporaryDirectory(prefix="ikram_repack_") as tmp:
                stage = Path(tmp) / "tree"
                stage.mkdir(parents=True, exist_ok=True)
                aes_args = ["-a", aes_key] if aes_key else []
                try:
                    _run([repak] + aes_args + ["unpack", pakf, "--output", stage, "-f"], log)
                except Exception as e:
                    ikram_logger.log_exc("engines.repack_folder:628", e)
                    log(f"  repak unpack failed ({e}) -- python fallback")
                    p0 = ue4mod().Ue4Pak(pakf, aes_key=aes_key)
                    p0.extract_all(str(stage))
                for p in sorted(edit_dir.rglob("*")):
                    if p.is_symlink() or not p.is_file() or p.name.startswith("."):
                        continue
                    rel = str(p.relative_to(edit_dir)).replace("\\", "/")
                    if _repack_skip(rel):
                        continue
                    dst = stage / rel
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    dst.write_bytes(p.read_bytes())
                out = Path(out)
                out.parent.mkdir(parents=True, exist_ok=True)
                if out.exists():
                    out.unlink()
                _run([repak, "pack", stage, "--mount-point", mount_point,
                      "--version", _repak_version_str(version, compression_u8),
                      "--compression", "Zlib", out], log)
            return sum(1 for p in edit_dir.rglob("*") if p.is_file())

        log("  engine: python-ue4 (standard UE4)")
        p = ue4mod().Ue4Pak(pakf, aes_key=aes_key)
        existing = p.files()
        repl, adds = {}, {}
        for fp in sorted(edit_dir.rglob("*")):
            if fp.is_symlink() or not fp.is_file() or fp.name.startswith("."):
                continue
            rel = str(fp.relative_to(edit_dir)).replace("\\", "/")
            data = fp.read_bytes()
            if rel in existing:
                repl[rel] = data
            else:
                adds[rel] = data
        return p.repack(str(out), replacements=repl, add_files=adds)

    raise ValueError(f"Unknown pak format (no UE4/Tencent magic): {pakf.name}")


def engine_status():
    out = []
    out.append(f"custom-tencent: ready (pak.pyc)")
    r = find_repak()
    out.append(f"repak: {r.name if r else 'MISSING -- ' + repak_hint()}")
    q = find_quickbms()
    out.append(f"quickbms: {q.name if q else 'not installed (optional fallback)'}")
    u = find_u4pak()
    out.append(f"u4pak: {u.name if u else 'not installed (optional fallback)'}")
    return "\n".join(out)
