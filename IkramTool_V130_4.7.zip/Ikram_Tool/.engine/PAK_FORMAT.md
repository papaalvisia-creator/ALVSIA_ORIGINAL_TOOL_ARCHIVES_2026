# PUBG (Tencent) .pak — format map and what "genuine" means

Everything below was derived from real paks in
`ORGINAL-PAKS/` using the tool's own reader
(`.engine/pak.pyc`, `.engine/pakcrypto.pyc`) plus hand parsing of
the bytes. Where a statement is a measurement, the sample size is given.

Corpus: a 41-pak measurement subset (drawn from the 126 paks in
`ORGINAL-PAKS`), all `version = 14`, all `magic = 1280398403 (0x4C515443)`,
all `footer_size = 873`. No UE4 magic (`0x5A6F12E1`) appears anywhere.

Measured on the two reference archives A (GL 21770) and B (KR 21767), the
decoded magic is `0x4c515443` (bytes `43 54 51 4c`, ASCII `CTQL`). The tail
suffix `b4 7a d1 a6` is not a signature: it is little-endian ZUC word `ks[0]`
(`0xa6d17ab4`) masking the always-zero high dword of `index_offset`.

---

## 1. Container layout

There is **no file header**. The body region starts at offset 0 and the
footer sits at the end:

```
0                      index_offset                    index_offset+index_size      EOF
+--------------------------+-----------------------------------+---------------------+
| body region (raw bytes)  | AES-CBC index ciphertext (padded)  | footer (873 bytes)  |
+--------------------------+-----------------------------------+---------------------+
```

* Body bytes are stored back to back with free gaps; each entry records its
  absolute `offset` and stored `size`.
* `index_offset + index_size == filesize - footer_size` in every real pak.
* Entries are **not** required to be sorted by offset in the index, but in all
  41 paks the first real entry starts at offset 0 and offsets rise with the
  record order. The writer keeps that property.

## 2. Footer size

```
footer_size(version) = 45                      # tail
                     + 32   if version >= 7    # unk1 block
                     + 768  if version >= 8    # key / iv / index-hash blobs
                     + 8    if version >= 9    # stem_hash + unk2
                     + 20   if version >= 12   # content_org_hash
                     = 873 for version 14
```

## 3. Footer memory block (828 bytes, stored verbatim in the clear)

| offset   | len | field |
|----------|-----|-------|
| 0        | 32  | `unk1` — opaque per-pak blob (XORs to the ZUC keystream words 7..14) |
| 32       | 256 | `packed_key` — RSA-stripped AES key |
| 288      | 256 | `packed_iv` — RSA-stripped AES IV |
| 544      | 256 | `packed_index_hash` — RSA-sealed hash blob when extractable; the tail field is authoritative |
| 800      | 4   | `stem_hash` ^ keystream[8] |
| 804      | 4   | `unk2` ^ keystream[9] |
| 808      | 20  | `content_org_hash` |

`packed_*` are *not* encrypted: `rsa_extract(blob, RSA_MOD_1)` (one `pow(x, 65537)`
with the 256-byte modulus from `pakcrypto.RSA_MOD_1`) recovers
`1 + 20 + payload`, and the payload slice follows at `[21:]`.

* AES key   = `rsa_extract(packed_key)` (32 bytes)
* AES IV    = `rsa_extract(packed_iv)[:16]`
* index SHA1 = tail field at offset 9. In A and B `rsa_extract(packed_index_hash)`
  returns empty, so the embedded blob must never override the tail hash.

`stem_hash`, `unk2` (footer) and `content_org_hash` are **opaque**. Across the
corpus they match none of: crc32/adler32/SHA-1/MD5/SHA-256 of the pak name,
the mount point, the sorted name list, the record list, the content-hash list,
the plaintext index, the bodies, or the whole file — nor are they 4-byte
prefixes of any of those. Treat them as build-time identifiers and **copy them
verbatim**; that is also what every working community tool does.

## 4. Footer tail (45 bytes, masked)

The tail is XOR-masked with the footer keystream so the plaintext values are
not visible in a hex dump:

| offset | len | field | mask |
|--------|-----|-------|------|
| 0      | 1   | `index_encrypted` (0/1) | `keystream[3] & 0xFF` |
| 1      | 4   | `magic` | `keystream[2]` (u32) |
| 5      | 4   | `version` | **plain** |
| 9      | 20  | `index_hash` | `keystream[4..8]` (5 × u32 BE) |
| 29     | 8   | `index_size` | `keystream[10] << 32 \| keystream[11]` |
| 37     | 8   | `index_offset` | `keystream[0] << 32 \| keystream[1]` |

The constant tail suffix `b4 7a d1 a6` is `struct.pack('<I', ks[0])`; do not
treat it as a magic value.

`keystream` is `pakcrypto.zuc_keystream()`: ZUC with the fixed key `01 * 16`,
IV `ff * 16`, emitted as big-endian 32-bit words. It is the same for every pak;
the masks differ only because the *values* differ.

## 5. Index plaintext

```
wstring   mount_point              # UTF-8, i32 byte length includes NUL
u32       file_count
          file_count × record
u64       dir_count
          dir_count × ( wstring dir | u64 n | n × ( wstring name | i32 ref ) )
[wrap]    first (-real_end % 16) bytes of the same plaintext
```

`wstring` = `i32 length` then `length` bytes of UTF-8 **including a 1-byte
NUL**; length 0 or negative means empty. The mount in A/B is
`../../../ShadowTrackerExtra/` encoded as 28 ASCII bytes plus NUL, length 29.

The wrap is a prefix copy appended to make the AES-CBC plaintext 16-byte
aligned. A wraps 8 bytes (`1d 00 00 00 2e 2e 2f 2e`); B wraps 5 bytes
(`1d 00 00 00 2e`). The wrap is part of the hashed plaintext but is not a
logical index field.

* `ref` is a **negative** index into the file array: `-1` = `files[0]`,
  `-2` = `files[1]`, … So `name` binds a stem to a record; the stem itself is
  not stored in the record.
* `dirs` always contains `''` (root) and every parent path, each with a
  trailing `/`.
* `mount_point` decides what the names are relative to:
  * patch paks mount `../../../ShadowTrackerExtra/` and use plain paths
    (`Content/Lua/client/config/pubgm_patch.lua`).
  * base/map paks mount `../../../` and their dirs start with
    `ShadowTrackerExtra/…`.
* `parse_index_data` consumes the logical index exactly; the wrap tail remains
  as alignment padding and is included in `index_hash`. (An earlier manual
  parser that shifted record fields desynced — see §6.)

## 6. File record

Header, 69 bytes:

| offset | len | field |
|--------|-----|-------|
| 0      | 20  | `content_hash` — SHA-1 of the **stored** body bytes |
| 20     | 8   | `offset` (u64, absolute) |
| 28     | 8   | `uncompressed_size` (u64) |
| 36     | 4   | `cm_raw` (u32); `cm = cm_raw & 0x0f` |
| 40     | 8   | `size` (u64, **stored** bytes, i.e. after compression + encryption + 16-align pad) |
| 48     | 1   | `unk1` (always 0 in v14 corpus) |
| 49     | 20  | `unk2` = `md5(plain)[:16] + md5(plain)[4:8]` |

Block table, present only when `cm != 0`:

| offset | len | field |
|--------|-----|-------|
| 69     | 4   | `block_count` (u32) |
| 73     | 16 × n | `(start, end)` u64 pairs |

Trailer, always 13 bytes after the optional block table:

| offset | len | field |
|--------|-----|-------|
| tail+0 | 4   | `compression_block_size` (u32) |
| tail+4 | 1   | `encrypted` (u8) |
| tail+5 | 4   | `encryption_method` (u32) |
| tail+9 | 4   | `index_new_sep`, always `0xffffffff` |

So a record is `86 + 16·n` bytes when `cm != 0`, and **82** bytes when `cm == 0`
(no block count and no block array). Verified sizes in A/B: 82 (empty),
1126 (`cm=6`, 65 blocks). Empty convention: `cm=0 em=0 cbs=0 size=0 usize=0
blocks=0 sep=0xffffffff sha1(b'')`. The `em` field is still present in the
trailer of an empty record; skipping it desyncs every following record.

Block windows are **pre-encryption compressed lengths**, absolute file offsets:
`block[0].start == entry.offset`, each `end` is the length written for that
chunk, and the *next* block starts 16 bytes later than the previous `end`
because each encrypted chunk is padded to a 16-byte boundary.
`compression_block_size = min(65536, uncompressed_size)`, 0 when `cm == 0`.

## 7. Compression

| cm | meaning |
|----|---------|
| 0  | stored (no compression) |
| 1  | zlib (deflate) |
| 6  | zstd |
| 8  | zstd with per-pak dictionary (`CM_ZSTD_DICT`) |

One block per 65536 plaintext bytes; a payload ≤ 65536 is a single block.
`cm=8` is zstd+dict, not `cm=7`. zstd paks optionally carry a per-pak
dictionary (`pak._zstd_dict`).

## 8. Encryption

| em | meaning |
|----|---------|
| 0   | none |
| 1   | simple1 — XOR every byte with `SIMPLE1_KEY` (0x79) |
| 16  | simple2 — rolling 32-bit XOR, `SIMPLE2_KEY = 0xe55b4ed1`, block 16, zero pad |
| 17  | simple2 variant (same algorithm) |
| 2, 4| SM4, `SM4_SECRET_2` / `SM4_SECRET_4` |
| 32..55 | custom SM4; `em=31` is **not** SM4 |

`is_sm4(m)` is `m == 2 or m == 4 or (m & -32) != 0`. For a NEW method:
`secret = SM4_SECRET_NEW[(em - 31) % len] + str(em)` and
`key = SHA-1((stem.lower() + secret).encode()).digest()[:16]`. The `+ str(em)`
part is mandatory. The full table has 25 entries; the shipped 19-entry table
silently mis-decodes `em=50..55` because `(em-31) % 19` wraps onto the wrong
secret. `ikram_patch.py::_REF_TAIL` supplies the missing six.

`encrypted` byte == `em != 0`. simple2 and SM4 pad the stored body to a
multiple of 16; simple1 does not.

Observed families: base/map/res paks → `cm=1, em ∈ {1,16,17,55}`;
patch paks → `cm=6, em ∈ {16,17,53}`. A/B contain only `cm=0` and `cm=6`.

## 9. What a genuine output must satisfy

A pak the game will load is not "a file that our reader can parse"; it must
satisfy every invariant the runtime checks:

1. `filesize == index_offset + index_size + footer_size`.
2. Footer memory block **byte-identical** to the source (keys, hashes,
   `stem_hash`, `unk2`, `content_org_hash`, `unk1`), tail recomputed from the
   new `index_offset`, `index_size`, `index_hash`.
3. `index_hash == SHA-1(post-PKCS7-unpad plaintext including the wrap copy)`;
   ciphertext = AES-256-CBC/PKCS7 with the RSA-unpacked key/IV, length a
   multiple of 16.
4. Index plaintext well formed: mount, count, records, dir count, dirs, refs in
   range and negative, no stray bytes.
5. Every record: `content_hash == SHA-1(stored bytes)`, `unk2` consistent,
   `size` includes the 16-align pad, block windows start at `offset`, are
   contiguous modulo the 16-byte pad, and `cbs == min(65536, usize)` for
   `cm != 0` (`cbs == 0` for `cm == 0`).
6. Bodies of kept entries are **copied verbatim**, never re-encoded — that is
   the only way SM4 bodies (whose per-block ordering is not reproduced by the
   writer) and zstd-dictionary bodies survive.
7. Only changed/new entries are re-encoded, with a template taken from the
   source so `cm`/`em`/`cbs` match the archive family. New files default to
   simple2 when no simple1/simple2 template exists, because every corpus pak
   accepts simple2.

## 10. Writer verification (round trip)

`tencent_pak.py` was checked against the real corpus:

* **No-op repack**: `inject_files([], …)` on `game_patch_4.7.0.21756.pak`
  produces a file that is `filecmp`-identical to the source (196 841 bytes).
* **Add** one file (`Content/Lua/client/zz_inject_test.lua`, 46 bytes) into the
  same pak: output 197 017 bytes, source and output are byte-identical for the
  first 193 824 bytes (every body and the pre-index region), then the index is
  rewritten. Reader re-reads 6 entries; the new entry's SHA-1 matches; all five
  original entries keep their exact SHA-1.
* **Replace** entry `1`: entry hash matches the new payload, the other five are
  untouched.
* Footer decode on the output: `magic` ok, `version 14`, `index_size`/`index_offset`
  match the shard, `index_hash == SHA-1(plain including wrap)` ok, ciphertext
  length equals the padded plaintext.
* Body check on the output: all 6 `content_hash` values match the bytes on
  disk, 70 block windows consistent, `block[0].start == entry.offset`.

That is the same set of invariants the reader enforces when it opens a real
pak, so the output is in-format with the originals.

## 11. Non-pak files found next to the paks

`Saved/CachePaks/{1.pak,HEADER.pak,HEADERBACK.pak,HEADERBackUp.pak}` are not
version-14 archives — `PakReader` rejects them and they begin with plaintext
length-prefixed strings (`HEADERBACK.pak` starts `2c 00 00 00 "../.."`).
They are cache/manifest blobs, not pak archives, and must stay out of the
pak pipeline (the tool already refuses them).
