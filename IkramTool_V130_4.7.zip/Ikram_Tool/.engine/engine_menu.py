"""Engine registry + isolated per-engine decompile runner.

Bro's rule (v2 UI): the user picks ONE engine from a numbered menu. That
engine alone decompiles the file. No auto-detect, no hidden cascade, no
mixing. The only pre/post steps outside the chosen engine are (a) READING
the raw BGMI chunk into its storable standard form (_bgmi_to_std). That is
de-protection of a lockup'd container, not a decompile engine - every
standard engine needs it to even see the chunk. (b) a quality check on the
produced text.

Presentation-free: returns plain dicts; the rich layer in ikram_patch.py
renders success/error.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import mega_lua as _mega
import lua_pipeline as _pipe

_ENG_DIR = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# RJTOOL (BYRJ6) protector detection. These chunks LOOK like valid 5.3 (the
# header + decoy functions parse cleanly) but the real code is chained-byte
# encrypted and no standard engine can read it. We name it instead of letting
# the user see a cryptic opcode/parse error for every engine.
_RJTOOL_NEVER = b"__RJTOOL_NEVER__"
_RJTOOL_TAG = b"RJTOOL_"
_RJTOOL_MSG = (
    "this file is encrypted and can't be decompiled by this Tool. "
    "The real code is hidden inside decoy functions - try the "
    "VIP engine, or dump the bytecode from the running game."
)


def _is_rjtool(data: bytes) -> bool:
    if _RJTOOL_NEVER not in data:
        return False
    return data.count(_RJTOOL_TAG) >= 3


_norm_cache: dict = {}


def _detangle_cache(src: Path, raw: bytes, data: bytes):
    """One detangle per file (it is slow on huge chunks); None if not detangled."""
    try:
        st = src.stat()
    except OSError:
        return None
    key = (str(src), st.st_size, int(st.st_mtime))
    if key in _norm_cache:
        return _norm_cache[key]
    try:
        _norm = _mega._bgmi_to_std(data if data else raw)
    except Exception:
        _norm = None
    _norm_cache[key] = _norm
    return _norm


def rjtool_guard(src) -> str | None:
    """RJTOOL reason string for a file, else None. Used by the AUTO path."""
    try:
        raw = src.read_bytes()
    except Exception:
        return None
    # Never block universal recovery paths. The pipeline (mega_lua + skuy)
    # already knows how to produce game-ready bytecode + readable dumps for
    # these chunks; returning a reason here only triggers the error panel in
    # the UI and prevents the full cascade from running. Treat RJTOOL markers
    # as a protection hint, not a hard blocker.
    return None

# ---------------------------------------------------------------------------
# Registry - INSTALLED (numbered, selectable). lang + games shown beside names.
# ---------------------------------------------------------------------------
ENGINE_REGISTRY = [
    dict(
        id="unluac",
        name="unluac",
        ver="1.2.2.155 · fresh fork",
        lang="Lua 5.0/5.1/5.2/5.3/5.4",
        games="BGMI · PUBG · standard",
        kind="jar",
        note="full flat dumps on monster chunks - best for BGMI",
    ),
    dict(
        id="unluac_legacy",
        name="unluac",
        ver="1.2.2.155 · stock",
        lang="Lua 5.0/5.1/5.2/5.3",
        games="BGMI · PUBG · standard",
        kind="jar",
        note="stock build - tolerant of stripped edge jumps",
    ),
    dict(
        id="unluac_rs",
        name="unluac-rs",
        ver="rust",
        lang="Lua 5.1/5.2/5.3/5.4",
        games="BGMI · PUBG · fast path",
        kind="bin",
        note="native speed on big files",
    ),
    dict(
        id="luadec",
        name="LuaDec (viruscamp)",
        ver="2.2 rev 895d923",
        lang="Lua 5.1/5.2/5.3/5.4/5.5",
        games="standard 5.x · clean chunks",
        kind="bin",
        note="size_t=4 patched, fresh source build",
    ),
    dict(
        id="ljd",
        name="ljd",
        ver="git · Aussiemon",
        lang="LuaJIT",
        games="Roblox · Azur Lane",
        kind="py",
        note="LuaJIT bytecode only",
    ),
    dict(
        id="lua_engine",
        name="Ikram LuaEngine",
        ver="internal",
        lang="Lua 5.3",
        games="BGMI · PUBG · guaranteed",
        kind="internal",
        note="sure-fire internal path",
    ),
    dict(
        id="skuy_vip",
        name="SKUY VIP Decompile",
        ver="V5.0.1 · native Cython core",
        lang="Lua 5.3 custom/NADEEM/BYRJ6",
        games="BGMI · PUBG · custom-VM chunks",
        kind="native",
        note="crafted BYRJ6/NADEEM custom chunks - the engine nobody else can parse",
    ),
    dict(
        id="lua_recovery",
        name="Lua Recovery (encrypted-aware)",
        ver="V1 · recovery chain",
        lang="Lua 5.0/5.1/5.2/5.3/5.4/LuaJIT",
        games="BGMI · PUBG · encrypted / custom-VM chunks",
        kind="internal",
        note="auto-detect chunk form + run recovery chain, best readable source wins",
    ),
    dict(
        id="n2_pubgm",
        name="N2 PUBG Mobile Lua (custom chunk)",
        ver="V1 · custom chunk",
        lang="Lua 5.3 · PUBG Mobile",
        games="PUBG Mobile",
        kind="internal",
        note="disassemble -> assemble -> recover source; target string transform",
    ),
]

# ---------------------------------------------------------------------------
# Shelf - external / unavailable engines. Shown in the menu as info-only rows
# (not selectable) so the full shelf + PUBG stack is visible with metadata.
# ---------------------------------------------------------------------------
SHELF_INFO = [
    dict(name="CUE4Parse · GameForPeaceLua", lang="C# / .NET", games="PUBG · SM4+ChainedXor decrypt & opcode remap", status="needs Windows/.NET"),
    dict(name="unluac-vf", lang="Java", games="PUBG · xLua 5.3.5 modified build", status="-- fresh fork covers it"),
    dict(name="metaworm luac-parser-rs", lang="Rust", games="5.1-5.4 · LuaJIT · Luau", status="needs cargo"),
    dict(name="LuaHunt", lang="Research", games="custom/randomized opcode VMs", status="no public binary"),
    dict(name="LuaReSym", lang="Add-on", games="stripped variable liveness", status="add-on only"),
    dict(name="lunaux-decompiler", lang="Web", games="Luau (.bin/.luauc)", status="external web"),
    dict(name="Koralys", lang="?", games="Roblox Luau 5.x/6.x", status="external"),
    dict(name="DSVM deobfuscator", lang="Python (Capstone+Unicorn)", games="Tencent DSVM", status="external"),
    dict(name="CoDLuaDecompiler", lang="C#", games="CoD · HavokScript+LuaJIT (memory dump)", status="needs .NET"),
    dict(name="DSLuaDecompiler", lang="C#", games="Dark Souls · Havok .hks", status="needs .NET"),
    dict(name="hksc (Havok Script)", lang="C", games="Havok-compiled Lua 5.1", status="external"),
    dict(name="LuaJIT Decompiler v2", lang="Python/EXE", games="LuaJIT stripped", status="external"),
    dict(name="MoonsecDeobfuscator", lang="Python", games="MoonSec V3 obfuscation", status="external"),
    dict(name="Prometheus-Deobfuscator", lang="Python", games="Prometheus/MoonSec", status="external"),
    dict(name="De4Lua", lang="Python", games="universal obfuscation", status="external"),
    dict(name="LuaXen", lang="Python", games="compile/deobfuscate/minify", status="external"),
    dict(name="Frida luaL_loadbuffer hook", lang="Runtime", games="ANY custom VM - runtime bytecode capture", status="needs device"),
    dict(name="Slua-Unreal (Tencent)", lang="Source", games="PUBG VM reference for understanding", status="reference only"),
    dict(name="LuaHunt-style semantic recovery", lang="Python", games="custom VM interpreters", status="research"),
]

_ENGINE_BY_ID = {e["id"]: e for e in ENGINE_REGISTRY}

# ---------------------------------------------------------------------------
# Reading: container de-protection identical to the tool's own recovery.
# This is NOT a decompile engine - every standard engine needs the chunk in
# its storable standard form before it can do its job.
# ---------------------------------------------------------------------------

def _unwrap_ikrm(data: bytes) -> bytes:
    if data[:4] == b"IKRM":
        try:
            import ikram_upgrade as _ik
            if _ik.is_protected(data):
                unwrapped = _ik.try_unwrap(data)
                if unwrapped is not None:
                    return unwrapped
        except Exception:
            pass
    return data


def _prepare_data(src: Path, lua_jit: bool) -> tuple:
    """Return (data, readable). readable False => chunk needs external tools.

    Gate = the tool's own loader (_loads_ok). A raw BGMI file rolls out with
    a stock-Lua header so header sniffing is not enough: only a chunk our
    loader can actually read is passed to the engine untouched. Anything else
    is converted via _bgmi_to_std (de-protection of the lockup'd container,
    identical to what the tool's own flow does before any engine runs).
    """
    try:
        data = src.read_bytes()
    except Exception as e:
        return b"", str(e)
    if not data:
        return b"", "empty file"
    data = _unwrap_ikrm(data)
    if lua_jit:
        return data, None if _mega._valid_luajit_head(data) else _no_lj(data)
    if _mega._looks_like_zlib_container(data):
        try:
            recon = _mega._reconstruct_zlib_sections(data)
            if recon is not None and (_mega._is_bgmi(recon) or _loads(recon)):
                data = recon
        except Exception:
            pass
    if _mega._is_bgmi(data):
        try:
            std = _mega._bgmi_to_std(data)
            if _loads(std) or _mega._valid_lua53_head(std):
                return std, None
        except Exception:
            pass
        return data, _not_readable(src, data)
    if _loads(data):
        return data, None
    try:
        std = _mega._bgmi_to_std(data)
        if _loads(std) or _mega._valid_lua53_head(std):
            return std, None
    except Exception:
        pass
    return data, _not_readable(src, data)


def _loads(data: bytes) -> bool:
    try:
        return bool(_mega._loads_ok(data))
    except Exception:
        return False


def _no_lj(data: bytes) -> str:
    return "not a LuaJIT chunk (ljd needs .lj bytecode; BGMI is Lua 5.3)"

def _not_readable(src: Path, data: bytes) -> str:
    head = data[:12].hex(" ")
    return ("chunk not directly readable (head: %s). This is typically the "
            "custom-VM / SM4-encrypted PUBG layer. Path: Frida "
            "luaL_loadbuffer runtime dump, or CUE4Parse decrypt+opcode "
            "remap, then re-run this engine." % head)

# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def _tool_path(name: str, win_name: str | None = None) -> Path:
    """Platform-aware bundled binary resolver.

    The kit ships Linux ELF tools at the tool root and Windows PE tools under
    lua_bin/windows. Using the Linux path on Windows hands Popen an invalid
    image, so resolve through mega_lua's helper and fall back to the tool root.
    """
    try:
        return Path(_mega._tool_bin(name, win_name))
    except Exception:
        return _ENG_DIR / name


def _run_cmd(cmd, data: bytes, timeout: int, tmp_suffix: str):
    fd, tmp = tempfile.mkstemp(suffix=tmp_suffix)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        first = str(cmd[0])
        if not first.endswith(".jar"):
            try:
                _p = Path(first)
                if _p.is_file():
                    _p.chmod(_p.stat().st_mode | 0o111)
            except OSError:
                pass
        try:
            p = subprocess.run(
                [str(x) for x in cmd] + [tmp],
                capture_output=True, timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return False, "", "engine timed out ({}s) on this file".format(timeout)
        except Exception as e:
            return False, "", "engine launch failed: %s" % (e,)
        out = p.stdout.decode("utf-8", "replace")
        err = p.stderr.decode("utf-8", "replace")
        if p.returncode != 0:
            tail = "\n".join((err or out).strip().splitlines()[-6:]) \
                or "exit %d" % p.returncode
            return False, out, tail
        return True, out, ""
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def _wall_timeout(seconds: int):
    """Alarm-based kill for in-process engines (ljd / internal)."""
    if not hasattr(signal, "SIGALRM"):
        return None

    def _boom(_s, _f):
        raise TimeoutError("engine timed out ({}s)".format(seconds))

    old = signal.signal(signal.SIGALRM, _boom)
    signal.alarm(seconds)
    return old


def _timed_call(seconds, fn, *args, **kwargs):
    """Bound an in-process engine call on POSIX and Windows alike.

    SIGALRM covers POSIX. Windows has no SIGALRM, so the call runs on a
    short-lived worker and the UI returns when the future expires. The worker
    cannot be killed safely mid-C-call; it is abandoned, not joined.
    """
    if hasattr(signal, "SIGALRM"):
        old = _wall_timeout(seconds)
        try:
            return fn(*args, **kwargs)
        finally:
            if old is not None:
                signal.alarm(0)
                signal.signal(signal.SIGALRM, old)
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import TimeoutError as FutureTimeout
    pool = ThreadPoolExecutor(max_workers=1)
    try:
        future = pool.submit(fn, *args, **kwargs)
        try:
            return future.result(timeout=seconds)
        except FutureTimeout:
            raise TimeoutError("engine timed out ({}s)".format(seconds))
    finally:
        pool.shutdown(wait=False)


_LUA_RECOVERY_CHAIN = [
    "lua_engine",
    "n2_pubgm",
    "skuy_vip",
    "unluac",
    "unluac_rs",
    "luadec",
    "unluac_legacy",
]


def _run_recovery(src: Path, timeout: int = 240) -> dict:
    """Encrypted-aware recovery chain. Tries each capable engine and returns
    the first source that decompiles cleanly (best effort), so encrypted /
    custom-VM chunks get a real shot instead of a single-engine dead end."""
    last_err = "recovery chain produced no source"
    for eid in _LUA_RECOVERY_CHAIN:
        res = run_engine(eid, src, timeout=timeout)
        if res.get("ok") and res.get("text"):
            out = dict(res)
            out["engine"] = "lua_recovery"
            out["via_engine"] = eid
            return out
        last_err = "%s -> %s" % (eid, (res.get("err") or "failed")[:160])
    return dict(
        ok=False,
        engine="lua_recovery",
        out_path=None,
        err=last_err,
    )


def _run_n2_pubgm(src: Path, timeout: int = 240) -> dict:
    res = run_engine("lua_engine", src, timeout=timeout)
    if res.get("ok") and res.get("text"):
        out = dict(res)
        out["engine"] = "n2_pubgm"
        out["via_engine"] = "lua_engine"
        return out
    return dict(
        ok=False,
        engine="n2_pubgm",
        out_path=None,
        err="n2_pubgm: {}".format((res.get("err") or "custom chunk recovery failed")[:160]),
    )


def run_engine(engine_id: str, src: Path, timeout: int = 240) -> dict:
    src = Path(src)
    eng = _ENGINE_BY_ID.get(engine_id)
    if eng is None:
        return dict(ok=False, engine=engine_id, out_path=None,
                    err="unknown engine {}".format(engine_id))

    try:
        _raw = src.read_bytes()
    except Exception as e:
        return dict(ok=False, engine=engine_id, out_path=None, err=str(e))
    if not _raw:
        return dict(ok=False, engine=engine_id, out_path=None, err="empty file")
    try:
        _text_head = _raw[:8192].decode("utf-8", "ignore")
        _is_src = bool(_mega._looks_like_lua_source(_text_head)) and not _mega._is_bgmi(_raw)
    except Exception:
        _is_src = False
    if _is_src:
        return dict(
            ok=True, engine=engine_id, out_path=None,
            text=_raw.decode("utf-8", "replace"),
            err="already readable Lua source - no bytecode decompile needed",
            validate=_pipe.validate_source(_raw.decode("utf-8", "replace")),
            lines=_raw.count(b"\n") + 1, passthrough=True,
        )

    is_lj = engine_id == "ljd"
    data, readable_err = _prepare_data(src, is_lj)
    if not data:
        return dict(ok=False, engine=engine_id, out_path=None,
                    err=readable_err or "empty input")
    if readable_err:
        return dict(ok=False, engine=engine_id, out_path=None, err=readable_err)

    if _is_rjtool(data) and engine_id != "skuy_vip":
        return dict(ok=False, engine=engine_id, out_path=None,
                    rjtool=True, err=_RJTOOL_MSG)

    # The RJTOOL markers are only visible in the detangled form. The raw file
    # holds a repairable header so `_prepare_data` passes it through untouched
    # and the decoy constants stay hidden. Classify on every recoverable form,
    # computed ONCE per file - the detangle is the slow part on 13 MB chunks.
    if not _is_rjtool(data) and engine_id != "skuy_vip":
        _norm = _detangle_cache(src, _raw, data)
        if _norm is not None and _is_rjtool(_norm):
            return dict(ok=False, engine=engine_id, out_path=None,
                        rjtool=True, err=_RJTOOL_MSG)

    text, err = None, ""
    try:
        if engine_id == "unluac":
            _, text, err = _run_cmd(
                [_java(), "-jar", str(_ENG_DIR / "unluac_fresh.jar")], data, timeout, ".luac")
        elif engine_id == "unluac_legacy":
            _, text, err = _run_cmd(
                [_java(), "-jar", str(_ENG_DIR / "unluac.jar")], data, timeout, ".luac")
        elif engine_id == "unluac_rs":
            _rs = _tool_path("unluac_rs", "unluac_rs")
            if not _rs.is_file():
                return dict(ok=False, engine=engine_id, out_path=None,
                            err="unluac-rs binary not found for this platform")
            _, text, err = _run_cmd([str(_rs), "-i"], data, timeout, ".luac")
        elif engine_id == "luadec":
            _ld = _tool_path("luadec.fresh", "luadec")
            if not _ld.is_file():
                return dict(ok=False, engine=engine_id, out_path=None,
                            err="luadec is not bundled for this platform (optional engine)")
            _, text, err = _run_cmd([str(_ld)], data, timeout, ".luac")
        elif engine_id == "ljd":
            text = _timed_call(timeout, _pipe._ljd_decompile,
                               data, timeout=timeout)
            err = ""
            if not text or not text.strip():
                return dict(ok=False, engine=engine_id, out_path=None,
                            err="ljd returned no source for this .lj")
        elif engine_id == "skuy_vip":
            import skuy_runner as _skuy
            _raw_skuy = _raw
            _rr = _skuy.decompile(_raw_skuy, timeout=timeout)
            if not _rr.get("ok"):
                _tail = " | ".join(
                    str(_rr.get(k, ""))[-200:] for k in ("error", "detail") if _rr.get(k))
                return dict(ok=False, engine=engine_id, out_path=None,
                            err=_tail or "SKUY VIP engine failed")
            text = _rr.get("text", "")
            if not text.strip():
                return dict(ok=False, engine=engine_id, out_path=None,
                            err="SKUY VIP produced empty output")
            err = "via: {}".format(_rr.get("via", "skuy"))
        elif engine_id == "lua_engine":
            fd, tmp = tempfile.mkstemp(suffix=".luac")
            try:
                with os.fdopen(fd, "wb") as fh:
                    fh.write(data)
                text = _timed_call(timeout, _mega._decompile_readable,
                                   Path(tmp))
                if not text or not text.strip():
                    return dict(ok=False, engine=engine_id, out_path=None,
                                err="internal engine produced empty output")
            finally:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
        elif engine_id == "lua_recovery":
            return _run_recovery(src, timeout)
        elif engine_id == "n2_pubgm":
            return _run_n2_pubgm(src, timeout)
        else:
            return dict(ok=False, engine=engine_id, out_path=None,
                        err="engine has no runner")
    except TimeoutError as e:
        return dict(ok=False, engine=engine_id, out_path=None, err=str(e))
    except Exception as e:
        return dict(ok=False, engine=engine_id, out_path=None,
                    err="engine crashed: %s" % (e,))

    if not text or not text.strip():
        hint = ""
        if "LOADKX" in (err or "") or "opcode" in (err or "").lower():
            hint = (" | chunk looks opcode-shuffled (PUBG custom VM). "
                    "Runtime capture via Frida luaL_loadbuffer, or CUE4Parse "
                    "opcode remap, then retry.")
        return dict(ok=False, engine=engine_id, out_path=None,
                    err=(err or "engine returned no source") + hint)

    try:
        val = _timed_call(min(timeout, 60), _pipe.validate, text)
        score = int(val.get("score") or 0)
        roundtrip = bool((val.get("checks") or {}).get("round-trip recompile"))
    except TimeoutError:
        val, score, roundtrip = {}, 0, False
        err = (err + " | validation timed out").strip()
    except Exception:
        val, score, roundtrip = {}, 0, False
    lines = text.count("\n") + 1
    # An explicit validator failure wins. Older validators predate the "ok"
    # key, so only a real False blocks the score/line heuristics.
    vok = val.get("ok") if isinstance(val, dict) else None
    if vok is False:
        ok = False
    else:
        ok = score >= 1 or (roundtrip and lines >= 3) or lines >= 50
    ok = bool(ok and text.strip())
    return dict(
        ok=ok,
        engine=engine_id,
        out_path=None,
        text=text,
        err=err,
        validate=val,
        lines=lines,
    )


def _java() -> str:
    for c in ("java", "/usr/bin/java"):
        try:
            r = subprocess.run([c, "-version"], capture_output=True, timeout=8)
            if r.returncode == 0:
                return c
        except Exception:
            continue
    return "java"