import sys, os, json, traceback, subprocess, tempfile, time
for m in ["monolithic","tool_runtime","runtime_facade","skuy_native_bootstrap","lua_subsystem","protection_subsystem","pak_subsystem"]:
    try: __import__(m)
    except Exception: pass
import lua_subsystem as L
import protection_subsystem as P
P._skuy_require_operation = lambda *a, **k: True
L._skuy_require_operation = lambda *a, **k: True
from pathlib import Path

inp = Path(os.environ["SKUY_IN"])
out = Path(os.environ["SKUY_OUT"])
tmp_root = Path(os.environ.get("SKUY_TMP", str(out.parent))).resolve()
engine = os.environ.get("SKUY_ENGINE", "auto")
base = Path(__file__).resolve().parent
luadec = base / "luadec"
unluac = base / "unluac_pro.jar"
luac = base / "luac"

def run(cmd, data, timeout=900):
    fd, tmp = tempfile.mkstemp(suffix=".luac")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        p = subprocess.run([str(x) for x in cmd] + [tmp], capture_output=True, timeout=timeout)
        return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"
    finally:
        try: os.unlink(tmp)
        except OSError: pass

result = {"ok": False, "engine": engine}
try:
    raw = inp.read_bytes()
    try:
        hdr, root, off = L.parse_custom_chunk(raw)
        is_custom = True
    except Exception:
        is_custom = False
    steps = []
    try:
        if is_custom:
            with tempfile.TemporaryDirectory(prefix="skuy_") as td:
                std = Path(td) / "std.luac"
                L.custom_to_standard_file(inp, std)
                std_raw = std.read_bytes()
                steps.append("custom->standard")
                for name, cmd in (("luadec", [luadec]), ("unluac", ["java", "-Xmx6g", "-jar", str(unluac)])):
                    rc, txt, err = run(cmd, std_raw)
                    steps.append("%s(%d)" % (name, rc))
                    if rc == 0 and txt.strip() and "-- Decompilation Crashed" not in txt[:200]:
                        out.write_text(txt, encoding="utf-8")
                        result.update(ok=True, via="skuy-custom->"+name, size=out.stat().st_size)
                        break
                if not result.get("ok"):
                    raise RuntimeError("external tools failed on custom-converted: %s" % ", ".join(steps))
        else:
            for name, cmd in (("luadec", [luadec]), ("unluac", ["java", "-Xmx6g", "-jar", str(unluac)])):
                rc, txt, err = run(cmd, raw)
                steps.append("%s(%d)" % (name, rc))
                if rc == 0 and txt.strip() and "-- Decompilation Crashed" not in txt[:200]:
                    out.write_text(txt, encoding="utf-8")
                    result.update(ok=True, via=name, size=out.stat().st_size)
                    break
            if not result.get("ok"):
                raise RuntimeError("external tools failed: %s" % ", ".join(steps))
    except Exception as e:
        steps.append("external-fail")
        # SKUY native fallback
        try:
            t0 = time.time()
            r = L.native_disassemble(inp, out.with_suffix(".disasm"), None, True)
            disasm = out.with_suffix(".disasm")
            if (disasm.is_file() and disasm.stat().st_size
                    and disasm.resolve().is_relative_to(tmp_root)):
                result.update(ok=True, via="skuy-native-disasm",
                              path=str(disasm), size=disasm.stat().st_size,
                              text=disasm.read_text(encoding="utf-8", errors="replace"),
                              detail=str(r)[:200])
            else:
                result.update(error="native disasm empty", detail=repr(e)[:400])
        except Exception as e2:
            result.update(error="native disasm failed: %s" % repr(e2)[:300], detail=repr(e)[:300])
    result.setdefault("detail", "steps: " + "; ".join(steps))
except Exception as e:
    result["error"] = repr(e)[:600]
    result.setdefault("detail", "see parent error log")
print("SKUYRESULT:" + json.dumps(result))
sys.stdout.flush()
os._exit(0)
