"""IkramTool — component installer.

Takes a `preflight.Report` and brings the missing pieces in. Two classes of
gap, handled differently:

  * bundled files (engines, crypto, Lua binaries shipped inside the tool) —
    these are part of the tool tree. If one is gone the tree is incomplete and
    the honest fix is a reinstall; the installer reports that rather than
    pretending it can fabricate a 6 MB binary.
  * host tools (luac 5.1..5.4, luajit, java) — optional extra engines the Lua
    pipeline can use. They are installed through whatever package manager the
    platform provides (Termux `pkg`, Debian `apt-get`, Fedora `dnf`, Arch
    `pacman`, openSUSE `zypper`, macOS `brew`). When no manager exists (plain
    Windows) they stay optional: the bundled Lua engines already cover the job.

`run()` animates every step and re-checks at the end, so the caller gets a
fresh Report. Nothing here raises: a failed install is a failed step.
"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

# The embedded python314 distribution ships a `._pth`, which suppresses the
# usual "script directory on sys.path" rule. Bootstrap our own directory so the
# imports below (and `import preflight`) resolve when this file is run directly
# as `python installer.py`. At runtime ikram_patch already did this.
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import ikram_logger
import paths
import preflight
from theme_engine import glyph

# ------------------------------------------------------------------ platform
def detect_manager():
    """Return (manager, install_template, needs_root) or None."""
    prefix = os.environ.get("PREFIX", "")
    if prefix.startswith("/data/data/com.termux"):
        return ("termux", ["pkg", "install", "-y"], False)
    if os.name == "nt":
        # No universal package manager; winget/choco are too fragile to drive
        # blind. Bundled engines cover the Lua job on Windows.
        return None
    root = hasattr(os, "geteuid") and os.geteuid() == 0
    if shutil.which("apt-get"):
        base = [] if root else ["sudo"]
        return ("apt", base + ["apt-get", "install", "-y"], not root)
    if shutil.which("dnf"):
        base = [] if root else ["sudo"]
        return ("dnf", base + ["dnf", "install", "-y"], not root)
    if shutil.which("pacman"):
        base = [] if root else ["sudo"]
        return ("pacman", base + ["pacman", "-S", "--noconfirm"], not root)
    if shutil.which("zypper"):
        base = [] if root else ["sudo"]
        return ("zypper", base + ["zypper", "-n", "install"], not root)
    if shutil.which("brew"):
        return ("brew", ["brew", "install"], False)
    return None


# id -> per-manager package name. A missing key means "no package on this
# manager", which the installer reports instead of guessing.
_PKG = {
    "java":   {"termux": "openjdk-17", "apt": "default-jre-headless",
               "dnf": "java-17-openjdk", "pacman": "jre-openjdk",
               "zypper": "java-17-openjdk", "brew": "openjdk"},
    "luac51": {"termux": "lua51", "apt": "lua5.1", "dnf": "lua",
               "pacman": "lua51", "zypper": "lua51", "brew": "lua@5.1"},
    "luac52": {"termux": "lua52", "apt": "lua5.2", "dnf": "lua",
               "pacman": "lua52", "zypper": "lua52", "brew": "lua@5.2"},
    "luac53": {"termux": "lua53", "apt": "lua5.3", "dnf": "lua",
               "pacman": "lua53", "zypper": "lua53", "brew": "lua"},
    "luac54": {"termux": "lua54", "apt": "lua5.4", "dnf": "lua",
               "pacman": "lua54", "zypper": "lua54", "brew": "lua@5.4"},
    "luajit": {"termux": "luajit", "apt": "luajit", "dnf": "luajit",
               "pacman": "luajit", "zypper": "luajit", "brew": "luajit"},
}


def _package_for(item_id, manager):
    table = _PKG.get(item_id)
    if not table:
        return None
    return table.get(manager)


def _run(cmd, timeout=600):
    """Run a command, capturing output to the log. Returns (ok, tail)."""
    try:
        proc = subprocess.run(
            cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=timeout, check=False,
            start_new_session=True)
        out = proc.stdout.decode("utf-8", "replace") if proc.stdout else ""
        tail = "\n".join(out.strip().splitlines()[-3:])
        ikram_logger.log_info("installer: %s -> rc=%d" % (" ".join(cmd), proc.returncode))
        if tail:
            ikram_logger.log_info(tail)
        return proc.returncode == 0, tail
    except FileNotFoundError as exc:
        ikram_logger.log_exc("installer._run:missing", exc)
        return False, "command not found: %s" % cmd[0]
    except subprocess.TimeoutExpired:
        return False, "timed out"
    except Exception as exc:
        ikram_logger.log_exc("installer._run", exc)
        return False, str(exc)


# --------------------------------------------------------------- plan/build
def _plan(report, manager, include_tools=False):
    """[(item, action, arg)] where action is 'pkg' | 'manual' | 'skip'.

    Host packages (kind == "tool": java/luac/luajit) are optional because the
    bundled Lua engines do the same job. They are skipped unless the caller
    explicitly asks for them, so a normal boot never shells out to a package
    manager and never blocks on a download.
    """
    plan = []
    for it in report.missing:
        if it.kind == "tool":
            if not include_tools:
                plan.append((it, "skip", "optional — bundled engine used"))
                continue
            if manager is None:
                plan.append((it, "skip", "no package manager (bundled engines used)"))
                continue
            pkg = _package_for(it.id, manager[0])
            if pkg is None:
                plan.append((it, "manual", it.fix or "install manually"))
            else:
                plan.append((it, "pkg", pkg))
        else:
            # bundled component gone -> tree incomplete
            plan.append((it, "manual", it.fix or "reinstall the tool"))
    return plan


# ------------------------------------------------------------------- animate
def _render(vip, title, steps, done_i, note=""):
    """One file-context installer frame: main item in the top border, step
    rows and progress inside. Height is constant for in-place repaint."""
    th = vip.theme
    rows = [th.apply(title, "primary") + th.apply("   " + note, "dim")]
    for idx, (label, state, detail) in enumerate(steps):
        if state == "ok":
            mark, mrole = glyph("ok"), "success"
        elif state == "fail":
            mark, mrole = glyph("fail"), "error"
        elif state == "skip":
            mark, mrole = glyph("bullet"), "dim"
        elif idx == done_i:
            mark, mrole = glyph("arrow"), "accent"
        else:
            mark, mrole = glyph("bullet"), "dim"
        rows.append("  " + th.apply(mark, mrole) + "  "
                    + th.apply("%-16s" % label, "text") + " "
                    + th.apply(detail[:34], "dim"))
    n = max(1, len(steps))
    pct = int(done_i * 100 / n)
    rows.append("")
    rows.append(vip.box.progress_row(pct, width=34))
    return vip.box.draw_file_context(
        "%s  %s" % (preflight.BRAND, paths.read_version()), (),
        title="INSTALL", extra=rows, token="info", limit=0, width=60)


def run(vip, report, animate=True, include_tools=False):
    """Install everything missing from `report`; return a fresh Report."""
    manager = detect_manager()
    plan = _plan(report, manager, include_tools=include_tools)

    # Nothing to do (only optional host tools are missing, or nothing at all).
    if not plan or all(action == "skip" for _it, action, _g in plan):
        return report

    steps = [(it.label, "wait", (it.fix or "")) for it, _a, _g in plan]

    if not animate:
        for idx, (it, action, arg) in enumerate(plan):
            _apply(it, action, arg, manager)
        return preflight.check()

    import time
    try:
        from theme_engine import is_tty
        live = is_tty()
    except Exception:
        live = False

    # Draw an initial frame, then one frame per finished step.
    def paint(done_i, note=""):
        try:
            vip._paint_frame(_render(vip, "checking & installing components",
                                     steps, done_i, note))
        except Exception as exc:
            ikram_logger.log_exc("installer.paint", exc)

    if live:
        paint(0)
    for idx, (it, action, arg) in enumerate(plan):
        ok, note = _apply(it, action, arg, manager)
        steps[idx] = (it.label, "ok" if ok else ("skip" if action == "skip" else "fail"), note)
        if live:
            paint(idx + 1, it.label)
            try:
                time.sleep(0.05)
            except Exception:
                pass
    if live:
        paint(len(plan), "re-checking")
    return preflight.check()


def _apply(item, action, arg, manager):
    """Carry out one plan entry. Returns (ok, note)."""
    if action == "skip":
        return True, arg or "optional"
    if action == "manual":
        return False, arg or "needs manual fix"
    if action == "pkg":
        assert manager is not None
        cmd = list(manager[1]) + [arg]
        ok, tail = _run(cmd)
        # verify by re-probing this single item
        fresh = preflight.check(deep=False)
        for it in fresh.items:
            if it.id == item.id:
                return it.ok, ("installed" if it.ok else (tail or "install failed"))
        return ok, ("installed" if ok else (tail or "install failed"))
    return False, "unknown action"


# ------------------------------------------------------------------- CLI
def _main(argv):
    rep = preflight.check(deep=False)
    if not rep.missing:
        print("%s: nothing to install — %s" % (preflight.BRAND, preflight.summarize(rep)))
        return 0
    mgr = detect_manager()
    want_tools = "--tools" in argv
    print("package manager:", mgr[0] if mgr else "none")
    for it, action, arg in _plan(rep, mgr, include_tools=want_tools):
        print("  %-16s %-7s %s" % (it.label, action, arg))
    if "--apply" in argv:
        # headless apply path (no UI); used by install.sh / CI
        for it, action, arg in _plan(rep, mgr, include_tools=want_tools):
            ok, note = _apply(it, action, arg, mgr)
            print("  %-16s %s  %s" % (it.label, "OK" if ok else "FAIL", note))
        print(preflight.summarize(preflight.check(deep=False)))
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
