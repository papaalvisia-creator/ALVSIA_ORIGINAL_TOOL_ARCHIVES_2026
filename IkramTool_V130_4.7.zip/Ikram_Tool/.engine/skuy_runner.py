"""Shared SKUY VIP bridge — used by engine_menu (manual pick) and
lua_pipeline (AUTO cascade). One subprocess wrapper, one JSON contract.

The SKUY core is a Cython module inside a custom CPython 3.14 interpreter
hosted by `skuy_engine` (its own dlopen + PyImport_AppendInittab bootstrap).
It cannot be imported in a normal python3, so every caller talks to it
through this one subprocess and parses the `SKUYRESULT:` line on stdout.
"""
import json
import os
import subprocess
import tempfile
from pathlib import Path

import ikram_logger

_ENG_DIR = Path(__file__).resolve().parent
_HOST = _ENG_DIR / "skuy_engine" / "skuy_engine"
_DRIVER = _ENG_DIR / "skuy_engine" / "skuy_decompile.py"
# The SKUY host is a Linux ELF bootstrap (dlopen + PyImport_AppendInittab);
# there is no Windows build, so the bridge reports itself unavailable there
# instead of letting Popen die with WinError 193.
_IS_WINDOWS = os.name == "nt"


def available() -> bool:
    if _IS_WINDOWS:
        return False
    return _HOST.is_file() and _DRIVER.is_file()


def _ensure_exec() -> None:
    """Restrictive umasks (Termux 0077) leave unpacked binaries owner-only and
    non-executable; install.sh fixes this at install time, but a plain unzip of
    the kit (or a dev tree) skips that step. Re-apply exec bits at call time so
    the bridge never dies with 'Permission denied' on the host binary."""
    try:
        for _bin in (_HOST, _ENG_DIR / "skuy_engine" / "luadec",
                     _ENG_DIR / "skuy_engine" / "luac"):
            if _bin.is_file() and not os.access(str(_bin), os.X_OK):
                _bin.chmod(_bin.stat().st_mode | 0o111)
    except OSError as _ikram_exc:
        ikram_logger.log_exc("skuy_runner.ensure_exec", _ikram_exc)


def decompile(data: bytes, timeout: int = 900) -> dict:
    """Run SKUY VIP on chunk bytes. Returns dict:
        cross-engine "ok" (bool) + "text" / "error" / "via".
    Never raises on SKUY failure (returns error dict); raises on bad config.
    """
    if not available():
        return dict(ok=False, error="SKUY VIP engine is not installed")
    _ensure_exec()
    with tempfile.TemporaryDirectory(prefix="skuy_") as td:
        inp = Path(td) / "in.lua"
        out = Path(td) / "out.lua"
        inp.write_bytes(data)
        env = os.environ.copy()
        env["SKUY_SCRIPT"] = str(_DRIVER)
        env["SKUY_IN"] = str(inp)
        env["SKUY_OUT"] = str(out)
        env["SKUY_ENGINE"] = "auto"
        env["SKUY_TMP"] = str(td)
        try:
            p = subprocess.run(
                [str(_HOST)], capture_output=True, timeout=timeout, env=env,
            )
        except subprocess.TimeoutExpired:
            return dict(ok=False, error="SKUY VIP timed out ({}s)".format(timeout))
        except OSError as _ikram_exc:
            ikram_logger.log_exc("skuy_runner.decompile:run", _ikram_exc)
            return dict(ok=False, error="SKUY VIP failed to start")
        if p.returncode != 0:
            _err = p.stderr or b""
            if isinstance(_err, bytes):
                _err = _err.decode("utf-8", "replace")
            _tail = str(_err).strip().splitlines()[-3:]
            return dict(
                ok=False,
                error="SKUY VIP failed (rc=%d)" % p.returncode,
                detail=" | ".join(_tail)[:300],
            )
        _rr = {}
        for _line in (p.stdout or b"").decode("utf-8", "replace").splitlines():
            if _line.startswith("SKUYRESULT:"):
                try:
                    _rr = json.loads(_line[len("SKUYRESULT:"):])
                except Exception as _ikram_exc:
                    ikram_logger.log_exc("skuy_runner.decompile:parse", _ikram_exc)
                    _rr = {"error": "SKUYRESULT malformed"}
                break
        if not _rr:
            _tail = (p.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-3:]
            return dict(ok=False, error="SKUY VIP engine produced no result",
                        detail=" | ".join(_tail))
        if not _rr.get("ok"):
            return dict(
                ok=False,
                error=str(_rr.get("error") or "SKUY VIP failed"),
                detail=str(_rr.get("detail") or "")[:300],
            )
        if str(_rr.get("via", "")).endswith("native-disasm"):
            return dict(ok=True, text=str(_rr.get("text") or ""),
                        via=str(_rr.get("via")), size=_rr.get("size"),
                        is_disassembly=True)
        try:
            result_path = Path(_rr.get("path") or out)
            if not result_path.resolve().is_relative_to(Path(td).resolve()):
                return dict(ok=False, error="SKUY VIP returned an unsafe output path")
            text = result_path.read_text(encoding="utf-8", errors="replace")
        except Exception as _ikram_exc:
            ikram_logger.log_exc("skuy_runner.decompile:read", _ikram_exc)
            return dict(ok=False, error="SKUY VIP output unreadable")
        if not text.strip():
            return dict(ok=False, error="SKUY VIP produced empty output")
        return dict(
            ok=True,
            text=text,
            via=str(_rr.get("via") or "skuy-vip"),
            size=_rr.get("size"),
        )
