"""Pure-Python implementation of the custom (modified) SM4 used by Tencent paks.

This module intentionally shadows the shipped `sm4_custom.pyc`.  The compiled
module tried to build `ikram_sm4_fast.so` with a local C compiler at import
time and fell back to `_lib = False`, which made `encrypt_ecb` / `decrypt_ecb`
raise `AttributeError: 'bool' object has no attribute 'sm4_ecb'` on every
machine without gcc (all Windows boxes, most Termux installs).

The cipher itself is a *modified* SM4: custom S-box, custom FK, custom CK.
Stock SM4 (gmalg, openssl) will not interoperate, so the constants below are
taken verbatim from `ikram_sm4_fast.c` and verified byte-for-byte against the
previously working `encrypt_block` / `decrypt_block` in the shipped bytecode.

Round structure is standard SM4 (32 rounds, reversed output, reversed keys on
decrypt); only the tables differ.

API kept identical to the compiled module:
    encrypt_block(block: bytes, key: bytes) -> bytes   (16 -> 16)
    decrypt_block(block: bytes, key: bytes) -> bytes   (16 -> 16)
    encrypt_ecb(data: bytes, key: bytes) -> bytes
    decrypt_ecb(data: bytes, key: bytes) -> bytes
    self_test() -> bool
"""

import struct
from functools import lru_cache

_S_BOX = (
    52, 102, 37, 116, 137, 120, 228, 169, 90, 65, 188, 122, 214, 22, 33, 35,
    77, 97, 218, 148, 155, 223, 19, 60, 105, 58, 49, 10, 95, 215, 153, 149,
    241, 174, 114, 61, 7, 96, 36, 182, 152, 238, 196, 162, 45, 136, 221, 141,
    4, 234, 187, 17, 202, 62, 93, 161, 246, 63, 176, 151, 128, 71, 43, 166,
    230, 247, 217, 177, 89, 192, 124, 190, 84, 40, 183, 126, 79, 248, 67, 110,
    160, 80, 14, 245, 144, 184, 251, 163, 123, 98, 25, 70, 3, 42, 185, 143,
    159, 119, 180, 91, 131, 135, 8, 235, 226, 30, 66, 240, 15, 232, 113, 106,
    117, 173, 85, 31, 181, 171, 51, 250, 127, 21, 189, 133, 216, 6, 104, 179,
    82, 48, 72, 11, 0, 237, 239, 178, 87, 142, 231, 108, 213, 229, 46, 83,
    130, 5, 249, 129, 244, 86, 191, 140, 75, 227, 219, 74, 145, 76, 44, 211,
    64, 41, 78, 32, 20, 54, 121, 9, 111, 209, 55, 224, 57, 12, 138, 146,
    56, 18, 53, 109, 225, 253, 147, 154, 23, 212, 201, 156, 107, 132, 38, 157,
    175, 118, 193, 158, 208, 150, 197, 203, 233, 115, 73, 210, 205, 100, 195, 199,
    1, 125, 243, 172, 252, 222, 164, 68, 50, 27, 194, 186, 28, 2, 198, 39,
    69, 139, 242, 24, 167, 16, 81, 29, 200, 207, 99, 255, 47, 13, 88, 206,
    101, 165, 220, 26, 59, 134, 254, 34, 92, 168, 94, 103, 170, 236, 112, 204,
)

_FK = (0x46970E9C, 0x4BC0685E, 0x59056186, 0xBCA2491E)

_CK = (
    0x00EB92B, 0x3A0AE783, 0x9E3B5C67, 0xADDBDABF, 0x7B7484CB, 0x49156C63,
    0xC79AB5E7, 0x79EC9CFF, 0x1725BEAB, 0x2FB89CA3, 0x24808AD7, 0xDDD28B1F,
    0x4740DA4B, 0xBBC3EA73, 0x247B30E7, 0x91BE385F, 0x0401248B, 0x45FCD3A3,
    0x530B4CE7, 0xC68DD35F, 0xE3D16C2B, 0x4F698C13, 0x6B92C747, 0x769EFB1F,
    0x4C73BE9B, 0xC942B193, 0xAD80D827, 0x372FB33F, 0x13CB6AAB, 0x2BDC0AA3,
    0x17A4A247, 0xD5E96CAF,
)

_M32 = 0xFFFFFFFF


def _rol32(x, n):
    return ((x << n) | (x >> (32 - n))) & _M32


def _sub_bytes(x):
    return (_S_BOX[(x >> 24) & 0xFF] << 24) | (_S_BOX[(x >> 16) & 0xFF] << 16) \
        | (_S_BOX[(x >> 8) & 0xFF] << 8) | _S_BOX[x & 0xFF]


def _t0_word(x):
    y = _sub_bytes(x)
    return y ^ _rol32(y, 2) ^ _rol32(y, 10) ^ _rol32(y, 18) ^ _rol32(y, 24)


def _t1_word(x):
    y = _sub_bytes(x)
    return y ^ _rol32(y, 13) ^ _rol32(y, 23)


_T0_ZERO = _t0_word(0)
_T1_ZERO = _t1_word(0)
_T0 = tuple(tuple(_t0_word(b << shift) ^ _T0_ZERO for b in range(256))
            for shift in (24, 16, 8, 0))
_T1 = tuple(tuple(_t1_word(b << shift) ^ _T1_ZERO for b in range(256))
            for shift in (24, 16, 8, 0))


def _t0(x):
    tables = _T0
    return (tables[0][x >> 24] ^ tables[1][(x >> 16) & 0xFF]
            ^ tables[2][(x >> 8) & 0xFF] ^ tables[3][x & 0xFF]
            ^ _T0_ZERO)


def _t1(x):
    tables = _T1
    return (tables[0][x >> 24] ^ tables[1][(x >> 16) & 0xFF]
            ^ tables[2][(x >> 8) & 0xFF] ^ tables[3][x & 0xFF]
            ^ _T1_ZERO)


@lru_cache(maxsize=32)
def _expand_key(key):
    if len(key) != 16:
        raise ValueError("sm4 key must be 16 bytes, got %d" % len(key))
    unpack = struct.unpack_from
    k = [unpack(">I", key, i * 4)[0] ^ _FK[i] for i in range(4)]
    rk = []
    a, b, c, d = _T1
    z = _T1_ZERO
    for i in range(0, 32, 4):
        for j in range(4):
            if j == 0:
                v = k[1] ^ k[2] ^ k[3] ^ _CK[i]
            elif j == 1:
                v = k[2] ^ k[3] ^ k[0] ^ _CK[i + 1]
            elif j == 2:
                v = k[3] ^ k[0] ^ k[1] ^ _CK[i + 2]
            else:
                v = k[0] ^ k[1] ^ k[2] ^ _CK[i + 3]
            k[j] ^= (a[v >> 24] ^ b[(v >> 16) & 0xFF]
                     ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z)
            rk.append(k[j])
    return tuple(rk)


def _crypt_block(block, rk):
    if len(block) != 16:
        raise ValueError("sm4 block must be 16 bytes, got %d" % len(block))
    x0, x1, x2, x3 = struct.unpack(">4I", block)
    a, b, c, d = _T0
    z = _T0_ZERO
    for i in range(0, 32, 4):
        v = x1 ^ x2 ^ x3 ^ rk[i]
        x0 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
        v = x2 ^ x3 ^ x0 ^ rk[i + 1]
        x1 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
        v = x3 ^ x0 ^ x1 ^ rk[i + 2]
        x2 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
        v = x0 ^ x1 ^ x2 ^ rk[i + 3]
        x3 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
    return struct.pack(">4I", x3, x2, x1, x0)


def encrypt_block(block, key):
    """Encrypt one 16-byte block."""
    return _crypt_block(block, _expand_key(bytes(key)))


def decrypt_block(block, key):
    """Decrypt one 16-byte block."""
    return _crypt_block(block, _expand_key(bytes(key))[::-1])


def _run_ecb(data, key, decrypt=False):
    data = bytes(data)
    n = len(data) - (len(data) % 16)
    k = _expand_key(bytes(key))
    rk = k[::-1] if decrypt else k
    out = bytearray(n)
    unpack = struct.unpack_from
    pack = struct.pack_into
    a, b, c, d = _T0
    z = _T0_ZERO
    for off in range(0, n, 16):
        x0, x1, x2, x3 = unpack(">4I", data, off)
        for i in range(0, 32, 4):
            v = x1 ^ x2 ^ x3 ^ rk[i]
            x0 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
            v = x2 ^ x3 ^ x0 ^ rk[i + 1]
            x1 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
            v = x3 ^ x0 ^ x1 ^ rk[i + 2]
            x2 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
            v = x0 ^ x1 ^ x2 ^ rk[i + 3]
            x3 ^= a[v >> 24] ^ b[(v >> 16) & 0xFF] ^ c[(v >> 8) & 0xFF] ^ d[v & 0xFF] ^ z
        pack(">4I", out, off, x3, x2, x1, x0)
    if n != len(data):
        out += data[n:]
    return bytes(out)


def encrypt_ecb(data, key):
    """ECB over the whole buffer; a ragged tail is passed through untouched."""
    return _run_ecb(data, key, False)


def decrypt_ecb(data, key):
    """ECB over the whole buffer; a ragged tail is passed through untouched."""
    return _run_ecb(data, key, True)


def self_test():
    """Round-trip + known-answer check.  Never raises."""
    try:
        key = bytes(range(16))
        pt = bytes(range(16))
        ct = encrypt_block(pt, key)
        if decrypt_block(ct, key) != pt:
            return False
        if encrypt_ecb(pt * 3, key) != ct * 3:
            return False
        if decrypt_ecb(ct * 3, key) != pt * 3:
            return False
        # known answer produced by the reference curve for key 000102...0f
        if ct != bytes.fromhex("0973d9599088067b7f8fa23655951332"):
            return False
        return True
    except Exception:
        return False
