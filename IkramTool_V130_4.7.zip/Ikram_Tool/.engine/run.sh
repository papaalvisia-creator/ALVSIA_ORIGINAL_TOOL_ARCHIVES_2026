#!/usr/bin/env bash
# IkramTool launcher (runs from inside .engine; DROP/RESULT are ../DROP ../RESULT)
#
# The core is CPython 3.14 bytecode and the magic is version-exact, so every
# candidate below is version-checked before use. A 3.15 on PATH is a valid
# python and an invalid core host; silently picking it produced the
# "cannot load the core" wall on launch.

cd "$(dirname "$0")" || exit 1
export PYTHONDONTWRITEBYTECODE=1
if [ -z "${IKRAM_SAFE_TERM:-}" ] && { [ -n "${ANDROID_ROOT:-}" ] || [ -n "${TERMUX_VERSION:-}" ] || [ -f /system/build.prop ] || [ "${TERM:-}" = dumb ]; }; then
    export IKRAM_SAFE_TERM=1
fi

py_ok() {
    [ -n "${1:-}" ] || return 1
    "$1" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3,14) else 1)' \
        >/dev/null 2>&1
}

PY=""
# 1. interpreter shipped inside the tree (windows embeddable is inert here,
#    but a linux build dropped into python314/ is not)
for cand in python314/bin/python3.14 python314/bin/python3 \
            python314/python3.14 python314/python3 \
            python314/python.exe python314/python; do
    if [ -x "$cand" ] && py_ok "$cand"; then PY="$PWD/$cand"; break; fi
done

# 2. the installer's cached source build - previously missing from this list,
#    so a successful 15-minute Termux build still left run.sh dead
if [ -z "$PY" ]; then
    for cand in "$HOME/.ikram/py314/bin/python3.14" "$HOME/.ikram/py314/bin/python3"; do
        if [ -x "$cand" ] && py_ok "$cand"; then PY="$cand"; break; fi
    done
fi

# 3. system interpreters, version-checked in preference order
if [ -z "$PY" ]; then
    for cand in python3.14 python3 python; do
        q="$(command -v "$cand" 2>/dev/null)" || continue
        if py_ok "$q"; then PY="$q"; break; fi
    done
fi

if [ -z "$PY" ]; then
    found="$(command -v python3 2>/dev/null || command -v python 2>/dev/null || true)"
    echo "  +--------------------------------------------------------------+"
    echo "  | IkramTool V130 - LAUNCHER ERROR                              |"
    echo "  +--------------------------------------------------------------+"
    echo "  | Main  : CPython 3.14                                         |"
    if [ -n "$found" ]; then
        echo "  | Found : $found ($("$found" -V 2>&1)) - magic differs, cannot load |"
    else
        echo "  | Found : no python on PATH                                    |"
    fi
    echo "  | Fix   : bash install.sh (installs or builds 3.14, cached)    |"
    echo "  | CLI   : python3 PakTool.py --help                             |"
    echo "  +--------------------------------------------------------------+"
    exit 1
fi

exec "$PY" -X utf8 ikram_patch.py "$@"
