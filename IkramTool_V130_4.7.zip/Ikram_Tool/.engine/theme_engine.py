"""IkramTool VIP theme engine (V130).

One terminal-aware ANSI colour engine. Every colour the tool prints comes
from here — 10 hand-curated, mutually distinct themes, one persisted
selection. Nothing is generated.

Config lives at `.engine/theme_config.json` (inside the tool's own runtime
directory, so the install leaves exactly .engine / DROP / RESULT and nothing
else, and no file is ever written to the home directory).

Rules (Phase 8):
  - ROLE, not hardcoded colour. Callers say "success" / "error" / "title".
  - Every theme defines every role.
  - No ANSI is emitted when the stream is not a real terminal.
"""

# Error log. Hard import on purpose: ikram_logger ships in this directory
# and its own entry points are non-raising by construction, so a missing
# logger is a broken install that must fail loudly at import -- not a
# silent no-op that would swallow every record of what went wrong.
import ikram_logger
import json
import locale
import os
import re
import sys
from pathlib import Path

import paths

CFG_NAME = "theme_config.json"


def config_file() -> Path:
    return Path(paths.ENGINE_DIR) / CFG_NAME

C = "\x1b["
RESET = C + "0m"
BOLD = "1"
DIM = "2"

# Fallback roles when a palette omits one (Red is a sane default accent).
ROLES = (
    "border", "border_dark", "title", "brand", "secondary", "text", "dim", "number",
    "prompt", "separator", "success", "error", "warn", "accent", "primary",
    "info",
)

# One role -> one box style/title. Status boxes, diagnosis and progress all
# come from this table so no flow invents its own visual language.
# One font/attribute policy for every user-visible role. Terminals cannot swap
# a typeface per word, so "font" here is the SGR face: bold, underline, dim.
# IKRAM always uses the same vivid magenta bold-underlined face in every theme.
FONT_ROLES = {
    "brand": "bold+underline magenta",
    "title": "bold themed",
    "number": "bold themed",
    "prompt": "bold themed",
    "success": "bold themed",
    "error": "bold themed",
    "warn": "bold themed",
    "accent": "bold themed",
    "primary": "bold themed",
    "text": "normal bright",
    "secondary": "dim themed",
    "info": "dim themed",
    "dim": "dim themed",
}
BRAND_CODE = 201

BOX_TOKENS = {
    "info": ("light", "INFO", "info"),
    "success": ("rounded", "DONE", "success"),
    "warn": ("light", "NOTICE", "warn"),
    "error": ("thick", "ERROR", "error"),
    "diagnosis": ("light", "EVIDENCE ONLY", "info"),
    "working": ("light", "WORKING", "accent"),
}

# ---- xterm-256 colour space --------------------------------------------------
# Theme.paint_code() can emit ANY 256-colour code, so ansi_rgb() stays for
# callers that want an exact code by number. The theme list itself is the 10
# curated palettes below; nothing is generated from the cube.

_LEVELS = (0, 95, 135, 175, 215, 255)

_SYS16_RGB = (
    (0, 0, 0), (128, 0, 0), (0, 128, 0), (128, 128, 0),
    (0, 0, 128), (128, 0, 128), (0, 128, 128), (192, 192, 192),
    (128, 128, 128), (255, 0, 0), (0, 255, 0), (255, 255, 0),
    (0, 0, 255), (255, 0, 255), (0, 255, 255), (255, 255, 255),
)


def ansi_rgb(code):
    """xterm-256 code -> (r, g, b)."""
    if code < 16:
        return _SYS16_RGB[code]
    if code < 232:
        i = code - 16
        return (_LEVELS[i // 36], _LEVELS[(i // 6) % 6], _LEVELS[i % 6])
    v = 8 + (code - 232) * 10
    return (v, v, v)


# ---- the 10 curated themes ---------------------------------------------------
# Ten distinct hues, each fully specified. Order is the menu order; index 0 is
# the default. Every palette defines every role in ROLES.
_PALETTES = {
    "Original Color": dict(
        primary=228, secondary=51, accent=141, border=135, border_dark=61,
        title=228, number=45, text=231, dim=103, prompt=51, separator=135,
        success=46, error=196, warn=214, info=141, bg=(14, 8, 23),
    ),
    "Cyber Blue": dict(
        primary=117, secondary=159, accent=81, border=117, border_dark=24,
        title=87, number=45, text=231, dim=253, prompt=87, separator=117,
        success=48, error=196, warn=214, info=159, bg=(5, 10, 20),
    ),
    "Neon Pink": dict(
        primary=213, secondary=218, accent=205, border=213, border_dark=133,
        title=213, number=45, text=231, dim=253, prompt=213, separator=177,
        success=48, error=196, warn=220, info=218, bg=(20, 8, 18),
    ),
    "Blood Red": dict(
        primary=210, secondary=216, accent=203, border=210, border_dark=124,
        title=203, number=45, text=231, dim=253, prompt=203, separator=167,
        success=48, error=196, warn=208, info=222, bg=(22, 5, 8),
    ),
    "Matrix Green": dict(
        primary=114, secondary=158, accent=82, border=114, border_dark=28,
        title=46, number=154, text=231, dim=253, prompt=46, separator=114,
        success=46, error=196, warn=220, info=159, bg=(3, 14, 6),
    ),
    "Gold VIP": dict(
        primary=220, secondary=229, accent=220, border=220, border_dark=172,
        title=229, number=220, text=231, dim=253, prompt=220, separator=178,
        success=48, error=196, warn=208, info=229, bg=(18, 14, 4),
    ),
    "Purple Reign": dict(
        primary=183, secondary=189, accent=147, border=183, border_dark=140,
        title=207, number=183, text=231, dim=253, prompt=207, separator=140,
        success=48, error=196, warn=220, info=189, bg=(20, 6, 26),
    ),
    "Ice White": dict(
        primary=152, secondary=195, accent=117, border=152, border_dark=60,
        title=231, number=152, text=231, dim=255, prompt=231, separator=152,
        success=48, error=196, warn=214, info=159, bg=(4, 6, 10),
    ),
    "Ocean Teal": dict(
        primary=80, secondary=123, accent=44, border=80, border_dark=23,
        title=87, number=45, text=231, dim=253, prompt=45, separator=80,
        success=48, error=196, warn=220, info=159, bg=(4, 16, 18),
    ),
    "Sunset Orange": dict(
        primary=215, secondary=216, accent=209, border=215, border_dark=172,
        title=222, number=215, text=231, dim=253, prompt=214, separator=172,
        success=48, error=196, warn=202, info=216, bg=(24, 10, 5),
    ),
}

THEMES = (
    "Original Color", "Cyber Blue", "Neon Pink", "Blood Red", "Matrix Green",
    "Gold VIP", "Purple Reign", "Ice White", "Ocean Teal", "Sunset Orange",
)
THEME_NAMES = {
    "Original Color": "Original Color",
    "Cyber Blue": "Cyber Blue",
    "Neon Pink": "Neon Pink",
    "Blood Red": "Blood Red",
    "Matrix Green": "Matrix Green",
    "Gold VIP": "Gold VIP",
    "Purple Reign": "Purple Reign",
    "Ice White": "Ice White",
    "Ocean Teal": "Ocean Teal",
    "Sunset Orange": "Sunset Orange",
}

_EMOJI = {
    "Original Color": "👑", "Cyber Blue": "💙", "Neon Pink": "🌸",
    "Blood Red": "❤️", "Matrix Green": "💚", "Gold VIP": "💛",
    "Purple Reign": "💜", "Ice White": "🤍", "Ocean Teal": "🩵",
    "Sunset Orange": "🧡",
}


def is_tty(stream=None) -> bool:
    """Pure terminal capability. NO_COLOR must not disable cursor control,
    repaint, or prompt cursor placement — only colour emission."""
    stream = stream or sys.stdout
    try:
        return bool(stream.isatty())
    except Exception as _ikram_exc:
        ikram_logger.log_exc("theme_engine.is_tty:303", _ikram_exc)
        return False


def color_support() -> int:
    """0 = none, 8 = basic, 256 = full."""
    if not is_tty() or os.environ.get("NO_COLOR") is not None:
        return 0
    if os.environ.get("COLORTERM") in ("truecolor", "24bit"):
        return 256
    term = os.environ.get("TERM", "")
    if "256" in term:
        return 256
    return 8


def terminal_width(default=80) -> int:
    # os.get_terminal_size() asks the kernel for the window size. On Termux it
    # raises PermissionError (errno 13) rather than OSError when stdout is a
    # pipe, so a perfectly normal `ikram | tee log` filled error.log with a
    # traceback for a condition that is not an error at all. A missing or
    # unusable terminal just means "assume the default", so fall back quietly
    # and keep the log for conditions a user can actually act on.
    try:
        w = os.get_terminal_size().columns
    except Exception:
        return default
    return w if w and w > 20 else default


def terminal_height(default=24) -> int:
    """Terminal rows, or a safe default when stdout is a pipe."""
    try:
        h = os.get_terminal_size().lines
    except Exception:
        return default
    return h if h and h > 5 else default


def terminal_metrics(width_default=80, height_default=24):
    try:
        size = os.get_terminal_size()
        w = size.columns if size.columns and size.columns > 20 else width_default
        h = size.lines if size.lines and size.lines > 5 else height_default
        return w, h
    except Exception:
        return width_default, height_default


# Glyph capability. Box borders are GBK-safe; ✓/✗/emoji/░ are not. A direct
# `python ikram_patch.py` on cp936 used to raise UnicodeEncodeError mid-panel.
# Menus keep their stored text; callers apply `safe_text()` at draw time.
_GLYPHS_UNICODE = {
    "ok": "✓", "fail": "✗", "warn": "!", "info": "i",
    "arrow": "→", "bullet": "·", "symbol": "◆", "ellipsis": "…", "bar_full": "▓",
    "bar_empty": "░", "spinner": "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏",
}
_GLYPHS_ASCII = {
    "ok": "OK", "fail": "X", "warn": "!", "info": "i",
    "arrow": "->", "bullet": "-", "symbol": "*", "ellipsis": "...", "bar_full": "#",
    "bar_empty": ".", "spinner": "-\\|/",
}

# Characters that must never reach a non-UTF-8 console, even as literals.
_UNSAFE_GLYPHS = {
    "✓", "✗", "✔", "✘", "»", "░", "▸", "⚙", "⇢", "⚠", "➜",
    "👑", "💙", "🌸", "❤️", "❤", "\ufe0f",
    "💚", "💛", "💜", "🤍", "🩵", "🧡",
    "📦", "📜", "💾", "🎨", "🧹", "🔒", "🔓", "⏳", "🔁", "↺",
}
_GLYPH_FALLBACK = {
    "✓": "OK", "✗": "X", "✔": "OK", "✘": "X",
    "»": ">", "░": ".", "▸": ">", "⚙": "*", "⇢": "->",
    "⚠": "!", "➜": "->",
    "⏳": "...", "📦": "", "📜": "", "💾": "", "🎨": "",
    "🧹": "", "🔒": "", "🔓": "",
    "👑": "", "💙": "", "🌸": "", "❤️": "", "❤": "", "\ufe0f": "",
    "💚": "", "💛": "", "💜": "", "🤍": "", "🩵": "", "🧡": "",
    "🔁": "->", "↺": "->",
}
_GLYPH_CACHE = {}


def console_encoding() -> str:
    enc = getattr(sys.stdout, "encoding", None) or locale.getpreferredencoding(False)
    return str(enc or "utf-8")


def _unicode_ok(ch: str, encoding: str) -> bool:
    if ch in _UNSAFE_GLYPHS:
        return False
    try:
        ch.encode(encoding)
        return True
    except Exception:
        return False


def glyph(name: str) -> str:
    """Return a glyph safe for this console's encoding."""
    enc = console_encoding().lower().replace("-", "").replace("_", "")
    unicode_ok = enc.startswith("utf") or enc in ("cp65001", "65001")
    token = _GLYPHS_UNICODE.get(name, str(name))
    if unicode_ok:
        return token
    return _GLYPHS_ASCII.get(name, token if _unicode_ok(token, enc) else "?")


def safe_text(text) -> str:
    """Downgrade glyphs that this console cannot encode. No-op on UTF-8."""
    s = "" if text is None else str(text)
    enc = console_encoding().lower().replace("-", "").replace("_", "")
    if enc.startswith("utf") or enc in ("cp65001", "65001"):
        return s
    out = []
    for ch in s:
        if ch in _UNSAFE_GLYPHS or not _unicode_ok(ch, enc):
            out.append(_GLYPH_FALLBACK.get(ch, "?"))
        else:
            out.append(ch)
    return "".join(out)


def _fansi(code: int, bold=False, dim=False, bg=None, underline=False) -> str:
    if color_support() == 0:
        return ""
    parts = []
    if bold:
        parts.append(BOLD)
    if dim:
        parts.append(DIM)
    if underline:
        parts.append("4")
    if code:
        parts.append("38;5;%d" % code)
    if bg:
        parts.append("48;2;%d;%d;%d" % (bg[0], bg[1], bg[2]))
    if not parts:
        return ""
    return C + ";".join(parts) + "m"


class Theme:
    def __init__(self, name):
        if name not in THEMES:
            name = "Original Color"
        self.name = name
        pal = _PALETTES.get(name, _PALETTES["Original Color"])
        self._pal = dict(pal)
        self._pal.setdefault("brand", BRAND_CODE)
        for r in ROLES:
            self._pal.setdefault(r, 231)
        self._bg = tuple(pal.get("bg", (0, 0, 0)))

    def apply(self, text, role="text", bold=None):
        if role not in ROLES:
            role = "text"
        text = "" if text is None else str(text)
        code = self._pal[role]
        if bold is None:
            bold = role in ("brand", "title", "success", "error", "accent",
                            "warn", "number", "primary", "prompt")
        dim = role in ("dim", "secondary", "info")
        underline = role == "brand"
        fg = _fansi(code, bold=bold, dim=dim, underline=underline)
        if not fg:
            return text
        return fg + text + RESET

    def paint_code(self, text, code, bold=True):
        """Exact ANSI colour by 256-code (V111 `_vip_num` cycle)."""
        text = "" if text is None else str(text)
        fg = _fansi(code, bold=bold)
        if not fg:
            return text
        return fg + text + RESET

    @property
    def bg(self):
        return self._bg

    def paint(self, text, role="text"):
        return self.apply(text, role)

    def emoji(self):
        return _EMOJI.get(self.name, "")

    def numbers(self, text):
        """Number slots: the theme's number colour."""
        return self.apply(text, "number")

    def number_cycle(self):
        """Per-digit ANSI codes for menu numbers, mapped through this theme.

        Original Color keeps the fixed V111 cycle byte-for-byte. Every other
        theme reuses the same six slots through its own palette so all menus
        follow the active theme instead of showing the old fixed colours.
        """
        if self.name == "Original Color":
            return {"0": 183, "1": 45, "2": 51, "3": 39, "4": 118, "5": 119}
        pal = self._pal
        base = pal.get("number", 45)
        return {"0": base, "1": base, "2": pal.get("secondary", 51),
                "3": pal.get("accent", 141), "4": pal.get("warn", 214),
                "5": pal.get("primary", 228)}


_BRAND_RE = re.compile(r"Ikram(?:TOOL|Tool| PakTool| Tool)?(?:\s+V\d+)?", re.I)


def brand_text(text, theme=None):
    """Give every IKRAM phrase one fixed bold-underlined gold face."""
    if text is None:
        return ""
    raw = str(text)
    if not raw:
        return raw
    th = theme or Theme("Original Color")
    return _BRAND_RE.sub(lambda m: th.apply(m.group(0), "brand"), raw)


def load_theme() -> Theme:
    """Saved config -> Original Color (default on fresh/no config)."""
    try:
        cfg = config_file()
        if cfg.is_file():
            d = json.loads(cfg.read_text(errors="ignore"))
            name = str(d.get("theme", ""))
            if name and name in THEMES:
                return Theme(name)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("theme_engine.load_theme:403", _ikram_exc)
        pass
    return Theme("Original Color")


def save_theme(name: str) -> None:
    if name not in THEMES:
        return
    try:
        cfg = config_file()
        cfg.parent.mkdir(parents=True, exist_ok=True)
        cfg.write_text(json.dumps({"theme": name}, indent=1))
    except Exception as _ikram_exc:
        ikram_logger.log_exc("theme_engine.save_theme:416", _ikram_exc)
        pass


def strip_ansi(text: str) -> str:
    import re
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


_EMOJI_VS16_BASES = {"❤"}


def display_width(text: str) -> int:
    """True terminal column width: ANSI stripped, wide chars (emoji/CJK) = 2,
    combining marks = 0. Used by the box engine so every row lines up edge
    to edge even with emoji in the title lines."""
    import unicodedata
    chars = list(strip_ansi(str(text)))
    w = 0
    i = 0
    while i < len(chars):
        ch = chars[i]
        o = ord(ch)
        if (unicodedata.combining(ch) or o in (0x200B, 0x00AD, 0xFEFF)
                or 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF):
            i += 1
            continue
        if (ch in _EMOJI_VS16_BASES and i + 1 < len(chars)
                and ord(chars[i + 1]) == 0xFE0F):
            w += 2
            i += 2
            continue
        if unicodedata.east_asian_width(ch) in ("W", "F"):
            w += 2
        else:
            w += 1
        i += 1
    return w
