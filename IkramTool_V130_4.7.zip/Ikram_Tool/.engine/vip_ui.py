"""IkramTool V130 — VIP shell.

Owns the screen: header, menu loops, submenus, folder status, prompts,
PROCEED box, progress frames, status boxes, invalid-input box, theme
switcher, clears, exit + terminal restore. Every menu option is dispatched
to a REAL handler in menus.py or lua_pipeline.py. Nothing on screen is
un-boxed; the only non-boxed line allowed anywhere is the Press-ENTER
`minimal` divider.

All user input funnels through `_ask()`, so tests can script whole flows
without a terminal.
"""

# Error log. Hard import on purpose: ikram_logger ships in this directory
# and its own entry points are non-raising by construction, so a missing
# logger is a broken install that must fail loudly at import -- not a
# silent no-op that would swallow every record of what went wrong.
import ikram_logger
import os
import re
import sys
import time
from pathlib import Path

from theme_engine import (
    Theme, load_theme, save_theme, THEMES, is_tty, glyph, safe_text,
    strip_ansi, terminal_metrics, display_width, BOX_TOKENS, color_support,
    brand_text,
)
from box_engine import BoxEngine, SEP, _BOXES, _truncate, _wrap_line
import paths
import startup

# No module-level version constant. It shipped as "v120" for two releases while
# the VERSION file said V121, so the menu header lied on every launch.
# paths.read_version() reads the file install.sh writes; it cannot drift from
# what is installed.
BRAND = "IkramTool"
C = "\x1b["
RESET = C + "0m"
CLS = C + "3J" + C + "2J" + C + "H" + C + "0m"


def safe_terminal_mode():
    """ABI shells that blank on ANSI clear or cursor-up use scroll text.

    The compiled splash calls `os.system("clear")`, and several screens repaint
    by moving the cursor upward. Android wrappers with partial terminfo swallowed
    both, so the key was accepted and the next screen stayed black. Opt in with
    IKRAM_SAFE_TERM=1; Android/Termux and dumb terminals get it automatically.
    Termux itself is handled separately: its terminal understands ANSI clear.
    """
    raw = os.environ.get("IKRAM_SAFE_TERM", "").strip().lower()
    if raw:
        return raw in ("1", "true", "yes", "on")
    if os.environ.get("TERMUX_VERSION") or os.environ.get("ANDROID_ROOT"):
        return True
    term = os.environ.get("TERM", "").strip().lower()
    if term in ("dumb", "unknown"):
        return True
    try:
        return os.path.isfile("/system/build.prop")
    except Exception:
        return False


def termux_mode():
    """True for real Termux sessions, even when safe mode is forced on."""
    if os.environ.get("TERMUX_VERSION", "").strip():
        return True
    try:
        path = os.environ.get("PATH", "")
        return any("/com.termux/" in part for part in path.split(os.pathsep))
    except Exception:
        return False


def ansi_screen_mode():
    """Termux can clear the viewport and home the cursor without blanking."""
    return is_tty() and termux_mode()


def prompt_cursor_mode():
    """Termux can place typed answers on the marker row; broken ABI cannot."""
    return is_tty() and (termux_mode() or not safe_terminal_mode())

CLEAR_PAK_DROP = "CLEAR DROP FOLDER"
CLEAR_RESULT = "CLEAR RESULT FOLDER"


def _w(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def _markup(code: int) -> str:
    """Compiled engine markup colour `color(N)` from a theme palette code."""
    return "color(%d)" % code


# compiled ikram module attributes -> theme roles (A-to-Z theming)
_ATTR_ROLE = {
    "INP": "prompt", "ACCENT": "accent", "VIP": "accent", "VIP2": "secondary",
    "CYAN": "secondary", "MUTED": "dim", "SUCCESS": "success",
    "ERROR": "error", "ERROR_TITLE": "error", "WARN": "warn",
    "BORDER": "border", "BORDER_DARK": "border_dark", "LINE": "border",
    "TITLE": "title", "GOLD": "brand", "GOLD_BRIGHT": "brand",
    "MATRIX": "accent",
}


def _vip_num_cycle(pal, theme_name="Original Color"):
    """Number colour cycle for the active theme (single source of truth)."""
    from theme_engine import Theme
    return Theme(theme_name).number_cycle()


def _sync_compiled_theme(vip):
    """Push the active theme into the compiled engine's global colour attrs,
    so the WHOLE tool — welcome, key screen, wizards, numbers, every menu —
    follows the chosen theme."""
    ik = vip.ikram
    if ik is None:
        return
    pal = vip.theme._pal
    for attr, role in _ATTR_ROLE.items():
        if hasattr(ik, attr):
            code = pal.get(role, 231)
            if role == "brand":
                setattr(ik, attr, "bold underline color(%d)" % code)
            else:
                setattr(ik, attr, _markup(code))
    cyc = _vip_num_cycle(pal, vip.theme.name)
    if hasattr(ik, "_vip"):
        codes = [cyc.get(str(d), cyc.get("5", 228)) for d in range(10)]
        ik._vip = lambda i, _c=codes: "bold color(%d)" % _c[
            (int(i) if str(i).lstrip("-").isdigit() else 0) % 10]
    if hasattr(ik, "_vip_num"):
        ik._vip_num = lambda n, _m=cyc: "bold color(%d)" % _m.get(
            str(n), _m.get("5", 228))


def _fmt_dur(seconds) -> str:
    """Compact duration: 8s / 1m 04s / 1h 02m."""
    try:
        s = int(round(float(seconds)))
    except Exception:
        return "-"
    if s < 60:
        return "%ds" % s
    m, sec = divmod(s, 60)
    if m < 60:
        return "%dm %02ds" % (m, sec)
    h, m2 = divmod(m, 60)
    return "%dh %02dm" % (h, m2)


def _eta_text(elapsed, done, total):
    """ETA string from elapsed time and progress, or None when it is not
    meaningful (nothing done yet, or already finished)."""
    try:
        elapsed = float(elapsed)
        done = int(done)
        total = int(total)
    except Exception:
        return None
    if done <= 0 or total <= 0 or done >= total or elapsed <= 0:
        return None
    per = elapsed / done
    return _fmt_dur(per * (total - done))


# Log producers use two stable shapes. The compiled pak unpacker emits
# "  name  (N bytes)"; asset processing emits "[i/N] rel/path  (N bytes)".
# The size group must start with a digit: "engine: ikram-custom (tencent)"
# is a phase line, not a file, and must never become a numbered row.
_SIZE_RE = r"(?P<size>\d[\d,.]*\s*(?i:bytes?|[kmgt]b)?)"
_FILE_LOG_PATTERNS = (
    re.compile(
        r"^\[(?P<index>\d+)/(?P<total>\d+)\]\s+(?P<name>.+?)"
        r"(?:\s{1,}\(" + _SIZE_RE + r"\))?$"
    ),
    re.compile(r"^(?P<name>.+?)\s{1,}\(" + _SIZE_RE + r"\)$"),
)
_MAX_COLLECTED_FILES = 100000

# Bright basic ANSI. 256-colour palettes went dim/purple on a few Termux
# builds; these are the plain bright slots every ANSI terminal honours.
LIVE_BOX_ROWS = 100
_FILE_NAMES = (92, 96, 93, 94, 91, 92, 96, 93, 94, 91)


def live_box_rows():
    """Rows per live file box. 100 keeps Termux smooth; env can raise it."""
    try:
        value = int(os.environ.get("IKRAM_LIVE_BOX_ROWS", LIVE_BOX_ROWS))
    except (OSError, TypeError, ValueError):
        return LIVE_BOX_ROWS
    if value <= 0:
        return LIVE_BOX_ROWS
    return max(20, min(500, value))


LIVE_MAX_ROWS = 500


def live_max_rows():
    """Cap rendered file rows on huge paks; counting never stops."""
    try:
        value = int(os.environ.get("IKRAM_LIVE_MAX_ROWS", LIVE_MAX_ROWS))
    except (OSError, TypeError, ValueError):
        return LIVE_MAX_ROWS
    if value <= 0:
        return LIVE_MAX_ROWS
    return max(100, min(50000, value))


_FILE_NUMBER = 93
_FILE_SIZE = 96


def basic_paint(text, code, bold=True):
    """One bright basic-ANSI slot, or plain text when colour is disabled."""
    if color_support() == 0:
        return safe_text(text)
    mode = "1;%d" % code if bold else str(code)
    return "\x1b[%sm%s%s" % (mode, safe_text(text), RESET)


def _size_text(value):
    text = safe_text(value).strip()
    if text.lower().endswith(" bytes"):
        text = text[:-6].strip()
    return text


def format_file_row(index, name, size="", offset=0):
    """One real file row: number, name, byte count. No dim or purple-only."""
    try:
        number = int(index)
    except Exception:
        number = int(offset) + 1
    col = _FILE_NAMES[(number - 1 + int(offset)) % len(_FILE_NAMES)]
    row = basic_paint("%6d" % number, _FILE_NUMBER) + "  " \
        + basic_paint(safe_text(name).strip(), col)
    text_size = _size_text(size)
    if text_size:
        row += "  " + basic_paint("(" + text_size + " bytes)", _FILE_SIZE)
    return row.rstrip()


def _split_width(text, width):
    chunks, current, used = [], "", 0
    for ch in str(text):
        cw = display_width(ch)
        if used + cw > width and current:
            chunks.append(current)
            current, used = "", 0
        current += ch
        used += cw
    if current:
        chunks.append(current)
    return chunks or [""]


def format_file_lines(index, name, size="", width=72, offset=0):
    """Numbered file entry wrapped to the real box width, never truncated."""
    try:
        number = int(index)
    except Exception:
        number = int(offset) + 1
    col = _FILE_NAMES[(number - 1 + int(offset)) % len(_FILE_NAMES)]
    available = max(20, int(width or 72))
    indent = " " * 8
    chunks = _split_width(safe_text(name).strip(), available - 8)
    lines = []
    for i, chunk in enumerate(chunks):
        prefix = basic_paint("%6d" % number, _FILE_NUMBER) + "  " if i == 0 \
            else indent
        lines.append(prefix + basic_paint(chunk, col))
    text_size = _size_text(size)
    if text_size:
        suffix = "(" + text_size + " bytes)"
        if display_width(strip_ansi(lines[-1])) + 2 + display_width(suffix) <= available:
            lines[-1] += "  " + basic_paint(suffix, _FILE_SIZE)
        else:
            lines.append(indent + basic_paint(suffix, _FILE_SIZE))
    return lines


def _match_file_log(text):
    """Return (name, size, index, total) for a known per-file log line."""
    raw = safe_text(text).strip()
    for pattern in _FILE_LOG_PATTERNS:
        match = pattern.match(raw)
        if not match:
            continue
        fields = match.groupdict()
        name = (fields.get("name") or "").strip()
        if not name:
            return None
        size = (fields.get("size") or "").strip() if fields.get("size") else ""
        if size.endswith(" bytes"):
            size = size[:-6]
        index = fields.get("index")
        total = fields.get("total")
        return name, size, int(index) if index else None, int(total) if total else None
    return None


class ProgressFrame:
    """Fixed-height progress box. TTY repaints in place; a pipe gets one box
    per redraw, never a raw `[frame N]` line. All state is monotonic so a
    clock change cannot freeze or run the spinner backwards."""

    REDRAW_INTERVAL = 0.12

    def __init__(self, vip, title="Working...", total=None):
        self.vip = vip
        self.title = title
        self.total = total
        self._t0 = time.monotonic()
        self._last_paint = 0.0
        self._paints = 0
        self._h = 0
        self._finished = False
        self._started = False
        self._pct = 0.0
        self._done = 0
        self._total = total or 0
        self._cur = ""
        self._bytes = bool(total and int(total) >= 1048576)

    def _elapsed(self):
        try:
            return max(0.0, time.monotonic() - self._t0)
        except Exception:
            return 0.0

    def elapsed(self):
        return self._elapsed()

    def show(self, pct=None, done=None, total=None, cur=None,
             speed=None, eta=None, status=None, spinner=None, force=False):
        if self._finished and not force:
            return
        now = self._elapsed()
        # Record every state update before the paint throttle. Skipping a
        # repaint must never drop the final percentage/count, or the forced
        # closing frame shows stale numbers.
        if pct is not None:
            self._pct = pct
        if done is not None:
            self._done = done
        if total is not None:
            self._total = total
        if cur is not None:
            self._cur = cur
        try:
            if pct is not None and float(pct) > 0:
                self._started = True
            if done is not None and int(done) > 0:
                self._started = True
        except (TypeError, ValueError):
            pass
        # A phase/on_file message before the first real counter must not paint
        # a 0% frame. Record the text above, then wait for a measured update.
        if (not force and not self._started
                and pct is None and done is None and total is None):
            return
        if not force and self._paints and (now - self._last_paint) < self.REDRAW_INTERVAL:
            return
        box = self.vip.box.draw_progress_box(
            title=self.title, pct=self._pct, done=self._done, total=self._total,
            cur=self._cur, speed=speed, eta=eta, elapsed=_fmt_dur(now),
            status=status, spinner=spinner, bytes_mode=self._bytes)
        self.vip._paint_frame(box, prev_h=self._h, reset=self._paints == 0)
        self._h = box.count("\n") + 1
        self._paints += 1
        self._last_paint = now

    def step(self, done, total, cur=None, bytes_mode=None):
        """Progress across N units. One adapter for tencent_pak, compiled
        `_ProgressUI` and savegames — (done, total, path)."""
        elapsed = self._elapsed()
        speed = None
        try:
            if done and elapsed > 0:
                speed = "%.1f/s" % (float(done) / elapsed)
        except Exception:
            speed = None
        if bytes_mode is None:
            try:
                bytes_mode = bool(total and int(total) >= 1048576)
            except (TypeError, ValueError):
                bytes_mode = False
        if bytes_mode:
            self._bytes = True
        pct = (100.0 * float(done) / float(total)) if total else 0.0
        self.show(pct=pct, done=done, total=total, cur=cur, speed=speed,
                  eta=_eta_text(elapsed, done, total), status="working",
                  spinner=glyph("spinner")[
                      self._paints % max(1, len(glyph("spinner")))])

    def phase(self, text):
        self.show(cur=text, status="working", spinner=glyph("spinner")[
            self._paints % max(1, len(glyph("spinner")))])

    def close(self, cur=None):
        """Final frame. Keep the last real counters; never invent a value."""
        self.show(cur=cur, status="done", spinner=glyph("ok"), force=True)
        self._finished = True

    def handoff(self, result_box):
        """Erase the progress frame (TTY) and emit one result box once."""
        if not self._finished:
            self.close()
        if is_tty() and self._h and not safe_terminal_mode():
            self.vip.write(C + "%dA" % self._h + C + "J")
        self.vip.write(result_box + "\n")

    def clear(self):
        """Erase the live frame without writing anything in its place."""
        if not self._finished:
            self.close()
        if is_tty() and self._h and not safe_terminal_mode():
            self.vip.write(C + "%dA" % self._h + C + "J")
        self._h = 0


class _ProgressAdapter:
    """One callback object satisfying every progress convention in the tool.

    With `collect_files=True`, per-file log lines are buffered once instead of
    repainting the single `Current :` row. The caller prints the buffered rows
    in one result box and clears the live frame first, so nothing is shown
    twice. Default callbacks keep the old live behaviour for other flows.
    """

    def __init__(self, frame, collect_files=False):
        self.frame = frame
        self.collect_files = bool(collect_files)
        self.files = []
        self._seen = set()
        self._file_no = 0
        self._closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def _record_file(self, text, index=None, total=None, repaint=False):
        if not self.collect_files or self._closed:
            return False
        parsed = _match_file_log(text)
        if parsed is None:
            return False
        name, size, parsed_index, parsed_total = parsed
        stored = name + ("  (%s bytes)" % size if size else "")
        key = stored.strip().casefold()
        if key in self._seen:
            return True
        self._seen.add(key)
        if len(self.files) < _MAX_COLLECTED_FILES:
            self.files.append(stored)
        use_index = index if index is not None else parsed_index
        use_total = total if total is not None else parsed_total
        if use_index is not None and use_total:
            self.frame.step(use_index, use_total)
        elif repaint:
            self.frame.phase(name)
        return True

    def progress(self, done, total, fp=None):
        if fp is not None and self._record_file(str(fp), repaint=False):
            return
        # on_file owns the Current row: it has the real byte size and a stable
        # number. A progress callback's fp is only a path hint and must not
        # replace that row with an unnumbered path.
        self.frame.step(done, total, None)

    def on_file(self, fp=None, size=None):
        if fp is None:
            return
        if isinstance(fp, (tuple, list)):
            name = str(fp[0]) if fp else ""
            size = size if size is not None else (
                fp[1] if len(fp) > 1 else None)
        else:
            name = str(fp)
        self._file_no += 1
        size_text = _size_text(str(size)) if size is not None else ""
        raw = safe_text(name).strip()
        record_text = raw + (("  (%s bytes)" % size_text) if size_text else "")
        text = "%6d  %s" % (self._file_no, raw)
        if size_text:
            text += "  (%s bytes)" % size_text
        self._record_file(record_text, repaint=False)
        self.frame.phase(safe_text(text))

    def step(self, done, total, cur=None):
        self.frame.step(done, total, cur)

    def phase(self, text):
        self.frame.phase(safe_text(text))

    def log(self, text):
        value = safe_text(text)
        if self._record_file(value, repaint=False):
            return
        self.frame.phase(value)

    def close(self, cur=None):
        if self._closed:
            return
        self._closed = True
        self.frame.close(cur)

    def handoff(self, result_box):
        self.frame.handoff(result_box)

    def clear(self):
        self.frame.clear()

    def elapsed(self):
        return self.frame.elapsed()


def _stat_size(root, name):
    """Real byte count for a direct path callback, never a guessed number."""
    raw = safe_text(name).strip()
    if not raw:
        return ""
    candidates = [Path(raw)]
    if root is not None:
        try:
            candidates.append(Path(root) / raw)
        except Exception:
            pass
    for candidate in candidates:
        try:
            if candidate.is_file():
                return str(candidate.stat().st_size)
        except OSError:
            continue
    return ""


class LiveFileBoxes:
    """One streaming box for a whole operation.

    The header and operation rows open once. Every reported file is appended
    immediately as a real numbered row. The footer closes the same box with the
    final count, so 5,000 paths and 100,000 files stay in one scrollable frame
    on PC and Termux. No repaint, no cursor-up, no throttled 0% frame.
    """

    def __init__(self, vip, title, per_box=None, root=None, context=None,
                 max_rows=None):
        self.vip = vip
        self.title = safe_text(title)
        self.per_box = max(1, int(per_box or live_box_rows()))
        self.max_rows = max(1, int(max_rows or live_max_rows()))
        self.context = [tuple(x) for x in (context or ()) if len(x) == 2]
        self.root = root
        self.rows = []
        self.count = 0
        self.total = 0
        self.files = []
        self._seen = set()
        self._closed = False
        self._t0 = time.monotonic()
        self._b = _BOXES["heavy"]
        self._inner_w = max(20, int(vip.box._resolve_width(None)) - 4)
        header = []
        for label, value in self.context:
            text = safe_text(value).strip()
            if text:
                header.append(basic_paint(safe_text(label) + " : ", 93)
                              + basic_paint(text, 96))
        header.append(basic_paint("OPER : " + self.title, 94)
                      + "   "
                      + basic_paint("STATUS : LIVE", 92))
        prefix = vip.box.draw_box(header, "heavy", title=self.title,
                                  color_role="accent").splitlines()
        self._bottom = prefix[-1]
        self._write_lines(prefix[:-1])

    def _write_lines(self, lines):
        writer = getattr(self.vip, "write", None)
        if callable(writer):
            writer("\n".join(str(x) for x in lines) + "\n")
        else:
            sys.stdout.write("\n".join(str(x) for x in lines) + "\n")
            sys.stdout.flush()

    def elapsed(self):
        return max(0.0, time.monotonic() - self._t0)

    def add_file(self, name, size=None, index=None, total=None):
        if self._closed:
            return False
        shown_name = safe_text(name).strip()
        if not shown_name:
            return False
        text_size = _size_text(size)
        if not text_size:
            text_size = _stat_size(self.root, shown_name)
        key = (shown_name.casefold(), text_size.casefold())
        if key in self._seen:
            return True
        self._seen.add(key)
        self.count += 1
        if total:
            try:
                self.total = int(total)
            except Exception:
                pass
        try:
            number = int(index) if index is not None else self.count
        except (TypeError, ValueError):
            number = self.count
        stored = shown_name + (("  (%s bytes)" % text_size) if text_size else "")
        if len(self.files) < _MAX_COLLECTED_FILES:
            self.files.append(stored)
        # Counting and collection never stop; only painted rows are capped so a
        # 100k-file pak emits one placeholder instead of megabytes of rows.
        if self.count > self.max_rows:
            return True
        if self.count == self.max_rows:
            self._write_lines([self.vip.box._row(
                self._b, _truncate("… +more", self._inner_w),
                self._inner_w, "left")])
            return True
        painted = []
        for line in format_file_lines(number, shown_name, text_size,
                                      width=self._inner_w):
            painted.append(self.vip.box._row(
                self._b, _truncate(line, self._inner_w), self._inner_w, "left"))
        self._write_lines(painted)
        return True

    def _summary(self):
        return (basic_paint("FILES : %d" % self.count, _FILE_NUMBER)
                + "   " + basic_paint("ELAPSED : " + _fmt_dur(self.elapsed()),
                                      _FILE_SIZE)
                + "   " + basic_paint("STATUS : DONE", 92))

    def close(self):
        if self._closed:
            return
        self._closed = True
        footer = [
            self.vip.box._divider(self._b, self._inner_w, "accent"),
            self.vip.box._row(self._b, _truncate(self._summary(), self._inner_w),
                              self._inner_w, "left"),
            self._bottom,
        ]
        self._write_lines(footer)


class _LiveFileAdapter:
    """The engine-facing callback over :class:`LiveFileBoxes`.

    Engines in this tool call one or more of `log`, `on_file`, `progress`,
    `step` and `phase`. All of them funnel into one deduplicated file stream;
    phase text that is not a real file is ignored so no raw line escapes a box.
    """

    def __init__(self, boxes):
        self.boxes = boxes
        self.vip = boxes.vip
        self.files = boxes.files
        self._closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def set_root(self, root):
        self.boxes.root = root

    def _add(self, name, size=None, index=None, total=None):
        return self.boxes.add_file(name, size, index, total)

    def _record_text(self, text):
        parsed = _match_file_log(safe_text(text))
        if parsed is None:
            return False
        name, size, index, total = parsed
        return self._add(name, size, index, total)

    def _add_direct(self, value, index=None, total=None, size=None):
        if value is None:
            return False
        if isinstance(value, dict):
            name = value.get("name") or value.get("path") or value.get("file")
            size = size if size is not None else value.get("size")
        elif isinstance(value, (tuple, list)):
            name = value[0] if value else ""
            size = size if size is not None else (value[1] if len(value) > 1 else None)
        else:
            name, size = value, size
        if name is None:
            return False
        return self._add(name, size, index, total)

    def log(self, text):
        # Log lines are file evidence only when they parse as a file row.
        # Phase strings such as "engine: ikram-custom (tencent)" are not files.
        if not self._closed:
            self._record_text(text)

    def on_file(self, fp=None, size=None):
        if self._closed:
            return
        self._add_direct(fp, size=size)

    def progress(self, done, total, fp=None):
        # The unpacker logs each row with its real byte count immediately after
        # this call. Waiting for that log avoids duplicate rows and keeps bytes
        # in brackets instead of guessing from a possibly partial file.
        if not self._closed and total:
            self.boxes.total = int(total)

    def step(self, done, total, cur=None):
        if not self._closed and total:
            self.boxes.total = int(total)

    def phase(self, text):
        # Never promote a phase line into a numbered file row.
        return

    def close(self, cur=None):
        if self._closed:
            return
        self._closed = True
        self.boxes.close()

    def clear(self):
        # One streaming box cannot be erased. Engines call clear() when handing
        # off to a result panel; closing it writes the final footer exactly once.
        self.close()

    def handoff(self, result_box):
        self.close()
        self.vip.write(result_box + "\n")

    def elapsed(self):
        return self.boxes.elapsed()


def make_live_file_callback(vip, title, per_box=None, root=None, context=None,
                            max_rows=None):
    return _LiveFileAdapter(
        LiveFileBoxes(vip, title, per_box, root, context=context,
                      max_rows=max_rows))


def make_progress_callback(vip, title="Working...", total=None, collect_files=False):
    return _ProgressAdapter(
        ProgressFrame(vip, title=title, total=total),
        collect_files=collect_files,
    )


class Vip:
    def __init__(self, ikram=None, stream=None):
        self.ikram = ikram
        self.stream = stream or sys.stdout
        self.theme = load_theme()
        self.box = BoxEngine(self.theme)
        self._frame_no = 0
        self._frame_h = 0
        self._last_outcome = None
        # Held for this process only. A restart always asks again.
        self._ikram_session_key = ""
        # The compiled engine panels (ikram_patch._engine_error_panel and
        # _engine_success_panel) draw their own tables and never call back into
        # this class, so their result used to be invisible to `remember()`:
        # a run where EVERY file failed still showed "✓ done" on the main menu.
        # A back-reference lets those panels record the real outcome.
        try:
            if self.ikram is not None:
                self.ikram._vip_ref = self
                if safe_terminal_mode():
                    # Compiled screens call the module-global clear_screen and
                    # rich's console.clear. Both emit terminfo sequences that
                    # blank ABI sessions, so route them through our own clear.
                    # Termux clears the viewport and scrollback; other ABI
                    # shells keep the older scroll-clear path.
                    self.ikram.clear_screen = self.cls
                    console = getattr(self.ikram, "console", None)
                    if console is not None:
                        if termux_mode():
                            console.clear = lambda *a, **k: self.cls()
                        else:
                            console.clear = lambda *a, **k: None
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.Vip.__init__:169", _ikram_exc)
        _sync_compiled_theme(self)

    # ------------------------------------------------------ io primitives
    def write(self, text):
        text = brand_text(text, getattr(self, "theme", None))
        try:
            self.stream.write(text)
            flush = getattr(self.stream, "flush", None)
            if flush:
                flush()
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.write:135", _ikram_exc)
            _w(text)

    def write_prompt_box(self, box, marker, fallback=None):
        """Write a box and put the typed answer on its marker row.

        Terminal echo starts wherever the cursor sits. Leaving it below the
        box made every answer look detached from the prompt, so TTY sessions
        move back onto the marked row. Pipes and scripted `_ask` overrides
        keep the plain box + newline path. The marker is already visible in
        the box; no extra input row is printed.
        """
        self.write(box + "\n")
        if not prompt_cursor_mode():
            return
        lines = box.splitlines()
        if not lines:
            return
        target = strip_ansi(safe_text(str(marker)))
        # Search each candidate across the whole box before falling back.
        # The contextual title also lives in the box, so a per-line scan that
        # checks every candidate at once put the cursor in the top border and
        # made typed answers appear after the title instead of after SELECT.
        hit = None
        for needle in (x for x in (target, fallback, "SELECT") if x):
            for i, line in enumerate(lines[:-1]):
                pos = strip_ansi(line).find(needle)
                if pos >= 0:
                    hit = (i, pos + len(needle))
                    break
            if hit is not None:
                break
        if hit is None:
            return
        idx, end = hit
        up = len(lines) - idx
        width = self.box._resolve_width(None)
        col = min(max(1, end + 2), max(1, width - 1))
        self.write(C + "%dA" % up + C + "%dG" % col)

    def _ask(self, prompt):
        """Read one line. Overridable in tests."""
        try:
            ans = input(prompt)
        except EOFError as _ikram_exc:
            ikram_logger.log_exc("vip_ui._ask:143", _ikram_exc)
            try:
                self.ikram._EOF = True
            except Exception:
                pass
            return ""
        except KeyboardInterrupt:
            try:
                self.ikram._EOF = True
            except Exception:
                pass
            return ""
        if is_tty():
            # Termux doesn't echo the Enter newline — advance the cursor so
            # the next screen/panel starts on a fresh line, never glued to
            # the "Choose ..." prompt.
            self.write("\n")
        # A successful read clears a prior EOF/Ctrl+C. Without this, one dry
        # piped line poisons every later handler's eof_exit() guard forever.
        try:
            self.ikram._EOF = False
        except Exception:
            pass
        return ans

    def cls(self):
        if termux_mode():
            # Termux understands the standard clear sequence. Newline padding
            # kept old screens in scrollback, so every menu looked shifted into
            # the middle of the screen. Clear the viewport and scrollback, then
            # home the cursor so each screen starts at row one.
            if is_tty():
                self.write(CLS)
            return
        if safe_terminal_mode():
            height = terminal_metrics()[1]
            self.write("\n" * max(2, min(40, height)))
            return
        if is_tty():
            self.write(CLS)

    def reset_term(self):
        if is_tty():
            self.write(C + "0m")

    def pause(self, sec=1.0):
        try:
            time.sleep(sec)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.pause:166", _ikram_exc)
            pass

    def wait_enter(self, label="Press ENTER to continue"):
        """Manual continue on a real terminal; scripted runs cannot hang."""
        if label:
            self.write(self.theme.apply("  " + label + " ", "dim") + "\n")
        if is_tty():
            self._ask("")

    def result_panel(self, lines, title="RESULT", summary=(), ok=True,
                     page_lines=8, dump_name=None, keep_page=False):
        """One bounded result panel, paged in place. `F` dumps all lines to
        RESULT. This owns NO continue: the caller supplies the single
        `wait_enter()` or compiled `pause()` so the count stays at one."""
        rows = [safe_text(str(x)).replace("\r", " ").replace("\n", " ")
                for x in lines]
        head = [safe_text(str(x)) for x in summary]
        self._last_outcome = "SUCCESS" if ok else "ERROR"
        style, _title, role = BOX_TOKENS["success" if ok else "error"]
        page_lines = max(3, min(12, int(page_lines or 8)))
        pages = max(1, (len(rows) + page_lines - 1) // page_lines)
        page = 0
        dump_note = ""
        first_h = 0
        while True:
            a, b = page * page_lines, min(len(rows), (page + 1) * page_lines)
            body = list(head)
            if head and rows:
                body.append(SEP)
            body.extend(rows[a:b])
            if dump_note:
                body.append("")
                body.append(dump_note)
            if pages > 1:
                body.append(SEP)
                body.append("Page %d/%d   lines %d-%d of %d   [ENTER] next  [Q] quit  [F] dump"
                            % (page + 1, pages, a + 1, b, len(rows)))
            box = self.box.draw_box(body, style, title=safe_text(title),
                                    color_role=role)
            self._paint_frame(box, prev_h=first_h, reset=page == 0)
            first_h = box.count("\n") + 1
            if pages == 1:
                break
            if keep_page:
                break
            ans = self._ask("").strip().lower()
            if ans == "q":
                break
            if ans == "f" and dump_name:
                try:
                    paths.RESULT_DIR.mkdir(parents=True, exist_ok=True)
                    stamp = time.strftime("%Y%m%d_%H%M%S")
                    base = safe_text(dump_name).strip() or "result"
                    base = "".join(ch if ch.isalnum() or ch in "-_" else "_"
                                   for ch in base)[:40]
                    p = paths.RESULT_DIR / ("%s_%s.txt" % (base, stamp))
                    unique = getattr(paths, "unique_path", None)
                    if unique:
                        p = unique(p)
                    with open(p, "w", encoding="utf-8", errors="replace") as fh:
                        fh.write("\n".join(rows))
                    dump_note = "Dump -> %s" % p
                except Exception as _ikram_exc:
                    ikram_logger.log_exc("vip_ui.result_panel:dump", _ikram_exc)
                    dump_note = "Dump failed (see error.log)"
                continue
            if ans in ("n", "enter", "next") or len(ans) == 0:
                was_last = page == pages - 1
                if was_last:
                    break
                page += 1
                continue
        return pages

    def _paint_frame(self, box, prev_h=None, reset=False):
        h = box.count("\n") + 1
        if not is_tty() or safe_terminal_mode():
            # Pipes and ABI shells cannot be trusted with cursor-up repaint.
            # Append the whole frame so every screen stays visible in order.
            self._frame_no += 1
            self.write("\n" + box + "\n")
            self._frame_h = h
            return
        if self._frame_no == 0 or reset:
            self.write(box + "\n")
        else:
            # Cursor-up must use the PREVIOUS box height. Using the new height
            # left ghost rows whenever a progress line changed length.
            up = prev_h if prev_h and prev_h > 0 else (self._frame_h or h)
            self.write(C + "%dA" % up + C + "J" + box + "\n")
        self._frame_no += 1
        self._frame_h = h

    # ------------------------------------------------------------- screens
    def header(self):
          return self.box.draw_box(
              [], "thick",
              title="%s  %s" % (BRAND, paths.read_version()), padding=0)

    def folder_rows(self):
        lines = []
        any_files = False
        for label, folder in (("DROP/pak/", paths.DROP_PAK),
                              ("DROP/lua/", paths.DROP_LUA),
                              ("DROP/inject/", paths.DROP_INJ),
                              ("DROP/SaveGames/", paths.DROP_SAVEGAMES)):
            files = paths.list_drop(folder)
            if files:
                any_files = True
                n = len(files)
                total_bytes = 0
                for f in files:
                    try:
                        total_bytes += f.stat().st_size
                    except OSError:
                        continue
                size = paths.human(total_bytes)
                line = (self.theme.apply(label, "text")
                        + self.theme.apply(" %d files   %s" % (n, size),
                                           "success"))
            else:
                line = (self.theme.apply(label, "text")
                        + self.theme.apply(" (empty)", "dim"))
            lines.append(line)
        rn, rb = paths.cached_count_dir(paths.RESULT_DIR)
        if rn is None:
            # Full RESULT walk stays off the UI thread. Show a neutral state
            # until the cached count lands; the next render is instant.
            lines.append(self.theme.apply("RESULT/", "text")
                         + self.theme.apply(" (ready)", "dim"))
        elif rn:
            any_files = True
            lines.append(self.theme.apply("RESULT/", "text")
                         + self.theme.apply(" %d files   %s"
                                            % (rn, paths.human(rb)),
                                            "success"))
        else:
            lines.append(self.theme.apply("RESULT/", "text")
                         + self.theme.apply(" (empty)", "dim"))
        if not any_files:
            lines.append(self.theme.apply(
                "→ drop a .pak into DROP/pak/ to start", "dim"))
        last = startup.last_action_line(self.theme)
        if last:
            lines.append(last)
        return [(None, lines)]

    def main_menu(self):
        import menus

        rows = [(key, label, help_lines)
                for key, label, help_lines, _target
                in menus.menu_entries(menus.CATEGORY_MAIN)
                if key != menus.BACK_KEY]
        return [
            self.box.draw_menu(
                rows + self.folder_rows()
                + [("0", "EXIT", ["close the tool"])],
                title=safe_text("IkramTOOL %s" % paths.read_version().upper())),
        ]

    def pak_menu(self):
        import menus
        return self.render_menu(menus.CATEGORY_PAK)

    def lua_menu(self):
        import menus
        return self.render_menu(menus.CATEGORY_LUA)

    def themes_menu(self):
        rows = []
        for i, name in enumerate(THEMES, 1):
            th = Theme(name)
            line = (self.theme.apply(str(i), "number") + "  "
                    + th.emoji() + " "
                    + th.apply(name, "primary"))
            if name == self.theme.name:
                line += self.theme.apply("   ← ✓", "success")
            rows.append(line)
        rows.append(("0", "← Back", []))
        return [self.box.draw_menu(rows, title="🎨 THEMES 🎨")]

    def _opt(self, digit, label, role="text"):
        cyc = _vip_num_cycle(self.theme._pal, self.theme.name)
        n = self.theme.paint_code(str(digit), cyc.get(str(digit), cyc["5"]))
        return "  " + n + "  " + self.theme.apply(label, role)

    def _opt_box(self, opt, style="light"):
        digit, name, help_lines = opt
        rows = [self._opt(digit, name, "primary")]
        for h in help_lines:
            rows.append("    " + self.theme.apply(h, "dim"))
        return self.box.draw_box(rows, style)

    def file_context_box(self, main, files=(), title="WORKING FILE",
                         mode=None, target=None, output=None, extra=(),
                         limit=8, style=None, token=None):
        """One box: main file centered in the TOP BORDER, secondary files
        listed inside it. Pure renderer — no input, no pause, no second box."""
        return self.box.draw_file_context(
            str(main) if main is not None else "-", files, mode, target,
            output, title, token, style, extra, limit)

    def show_file_context(self, main, files=(), title="WORKING FILE", **kwargs):
        self.write(self.file_context_box(main, files, title, **kwargs) + "\n")

    def path_prompt_box(self, question, rows=(), title="PATH", main=None,
                        token=None):
        q = safe_text(question)
        if "\x1b[" not in q:
            q = self.theme.apply(q, "prompt")
        colored = []
        for row in rows:
            text = safe_text(str(row))
            if "\x1b[" not in text:
                text = self.theme.apply(text, "text")
            colored.append(text)
        # The question is the cursor marker. It stays inside the box, after
        # every path/option row, so a typed number lands below the paths and
        # no second "INPUT" row is rendered under SELECT.
        lines = colored + [q]
        return self.file_context_box(main or title, (), title=title,
                                     extra=lines, token=token)

    def render_menu(self, category, extra_rows=(), subtitle=None):
        import menus
        title, _crumbs, rows, _choices, _back = menus.menu_view(category, extra_rows)
        if str(category).upper() == menus.CATEGORY_CLEAN and not extra_rows:
            # The CLEAN shell owns the same coloured per-option stat boxes as
            # run_clean(). No second CLEAN renderer is allowed to drift.
            title = menus.menu_title(menus.CATEGORY_CLEAN)
            rows = menus.clean_menu_rows(self)
        kwargs = {}
        if subtitle is not None:
            kwargs["subtitle"] = safe_text(subtitle)
        return [
            self.box.draw_menu(rows, title=safe_text(title), **kwargs),
        ]

    def read_choice(self, choices, label=None, main=None):
        label = label or (glyph("arrow") + " SELECT:")
        # prompt_in() owns the one invalid box + one wait per bad key, and maps
        # EOF/Ctrl+C to "" so a pipe cannot spin forever.
        return self.prompt_in(choices, label, main=main)

    def menu_loop(self, category, actions, extra_rows=(), extra_choices=(),
                  subtitle=None):
        import menus
        choices = tuple(menus.menu_choices(category)) + tuple(extra_choices)
        main = menus.menu_choice_title(category)
        while True:
            self.cls()
            self.write("\n\n".join(self.render_menu(category, extra_rows, subtitle)) + "\n")
            got = self.read_choice(choices, glyph("arrow") + " SELECT:", main=main)
            if not got or got == menus.BACK_KEY:
                return "BACK"
            target = next((t for k, _l, _h, t
                           in menus.menu_entries(category) if k == got), None)
            if target is None and got in extra_choices:
                target = got
            fn = actions.get(target)
            if fn is None:
                self.invalid_box(got)
                continue
            if not self.require_key():
                return "LOCKED"
            fn(self)

    # ------------------------------------------------------------- flows
    def prompt_in(self, choices, label, main=None):
        import menus  # local import: keeps the module import graph unchanged
        context = safe_text(main or "SELECT CHOICE")
        while True:
            box = self.path_prompt_box(label, (), title="SELECT", main=context)
            self.write_prompt_box(box, label, fallback=context)
            ans = menus.normalize_choice(self._ask(""))
            if ans in choices:
                return ans
            # _ask() maps EOF and Ctrl+C to "" — there is no line left to read.
            # "" is never a valid choice, so looping on it printed the same
            # "Invalid option" box forever (38 boxes in 25s under a pipe) and a
            # Ctrl+C at a prompt could never escape. An empty answer means the
            # input stream is gone, so hand "" back and let the caller return.
            if not ans:
                return ""
            self.invalid_box(ans)

    def invalid_box(self, got=None):
        rows = [glyph("fail") + " Invalid option"]
        if got is not None and str(got).strip():
            shown = safe_text(got).strip()
            if len(shown) > 24:
                shown = shown[:24] + glyph("ellipsis")
            rows.append("You typed: \"%s\"" % shown)
        rows.append("Enter a number from the menu")
        self._token_box("warn", rows)  # invalid input is not an operation outcome
        self.wait_enter()

    def _status_box(self, lines, style, role, title=None):
        rows = []
        for line in lines:
            rows.extend(_wrap_line(safe_text(line), max(8, self.box._resolve_width(None) - 4),
                                   max_lines=4))
        b = self.box.draw_box(rows, style, title=title, color_role=role)
        self.write(b + "\n")

    def _token_box(self, token, lines, outcome=None):
        style, title, role = BOX_TOKENS.get(token, BOX_TOKENS["info"])
        if outcome:
            self._last_outcome = outcome
        self._status_box(lines, style, role, title=safe_text(title))

    def success_box(self, lines):
        self._token_box("success", lines, outcome="SUCCESS")

    def error_box(self, lines, next_step=None, where=None, why=None):
        rows = []
        if where:
            rows.append("Where : " + safe_text(where))
        if why:
            rows.append("Why   : " + safe_text(why))
        rows.extend(list(lines))
        if next_step:
            rows.append("")
            rows.append("Next  : " + safe_text(next_step))
        self._token_box("error", rows, outcome="ERROR")

    def warn_box(self, lines):
        self._token_box("warn", lines, outcome="WARN")

    def info_box(self, lines):
        self._token_box("info", lines)

    def working_box(self, lines):
        """Immediate visible feedback for a bounded operation. No continue."""
        self._token_box("working", lines)

    def diagnosis_box(self, lines):
        # Evidence only. No outcome flag, no second continue.
        self._token_box("diagnosis", lines)

    def proceed_box(self, operation, src_label, files, out_label, extra=None):
        rows = [
            self.box.draw_labeled_row("Operation", str(operation), "secondary", "accent"),
            self.box.draw_labeled_row("Input", str(src_label)),
        ]
        if files:
            shown = list(files[:3])
            if len(files) > 3:
                shown.append("  %s +%d more" % (glyph("ellipsis"), len(files) - 3))
            for f in shown:
                rows.append(self.theme.apply("  " + glyph("bullet") + " " + safe_text(f), "text"))
        rows.append(self.box.draw_labeled_row("Output", str(out_label)))
        if extra:
            for e in extra:
                rows.append(self.theme.apply("  " + str(e), "secondary"))
        rows.append(SEP)
        rows.append("  " + self.theme.apply("[ Y ] Proceed", "success")
                    + "   " + self.theme.apply("[ N ] Cancel", "warn"))
        marker = "Proceed? (Y/N)"
        rows.append("  " + marker)
        self.write_prompt_box(
            self.box.draw_box(rows, "thick", title="PREFLIGHT"), marker)
        ans = self._ask("").strip().lower()
        while ans not in ("y", "n"):
            if not ans:
                return False
            self.invalid_box(ans)
            self.write_prompt_box(
                self.box.draw_box(rows, "thick", title="PREFLIGHT"), marker)
            ans = self._ask("").strip().lower()
        return ans == "y"

    def confirm_box(self, title, label, yes_label="Delete"):
        marker = "Confirm? (Y/N)"
        rows = [
            "  " + self.theme.apply(label, "text"),
            SEP,
            "  " + self.theme.apply("[ Y ] %s" % yes_label, "error")
            + "      " + self.theme.apply("[ N ] Cancel", "warn"),
            "  " + marker,
        ]
        box = self.box.draw_box(rows, "heavy", title=title)
        self.write_prompt_box(box, marker)
        ans = self._ask("").strip().lower()
        while ans not in ("y", "n"):
            if not ans:
                return False
            self.invalid_box()
            self.write_prompt_box(box, marker)
            ans = self._ask("").strip().lower()
        return ans == "y"

    def confirm_context_box(self, main, files=(), title="CONFIRM",
                            label=None, yes_label="Delete"):
        """One box: main folder in the top border, files + Y/N inside it."""
        extra = []
        if label:
            extra.append(label)
        marker = "Confirm? (Y/N)"
        extra.extend(["[ Y ] %s     [ N ] Cancel" % yes_label, marker])
        box = self.file_context_box(main, files, title=title, extra=extra,
                                    token="warn")
        self.write_prompt_box(box, marker)
        ans = self._ask("").strip().lower()
        while ans not in ("y", "n"):
            if not ans:
                return False
            self.invalid_box()
            self.write_prompt_box(box, marker)
            ans = self._ask("").strip().lower()
        return ans == "y"

    # ------------------------------------------------------------- returns
    def exit_screen(self):
        self.cls()
        self.write(self.box.draw_box([
            self.theme.apply("Thanks for using %s" % BRAND, "primary"),
          ], "rounded", title="%s  %s" % (BRAND, paths.read_version())) + "\n")
        self.wait_enter()
        self.reset_term()

    # ------------------------------------------------------------- run
    def run(self):
        # One greppable line per launch: which build ran, which log file, which
        # python. Without it, a report that only says "it crashed" cannot be
        # tied to a run. Logged, never printed -- the UI owns the terminal.
        try:
            ikram_logger.log_startup("entry=vip_ui.run")
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.run:407", _ikram_exc)
        paths.ensure_dirs()
        # Order: key -> full file check + install -> splash -> menu.
        # Nothing is touched before a valid key. If the gate itself cannot
        # load, fail closed; there is no alternate unlock path.
        try:
            import keygate
            unlocked = keygate.enforce(self)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.run:keygate", _ikram_exc)
            self._key_locked_box()
            self.wait_enter()
            return
        if not unlocked:
            # The key box already named the failure. On a double-clicked
            # launcher the window still needs one manual continue to read it.
            self.wait_enter()
            return
        ready = True
        try:
            ready = startup.boot(self)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.run:441", _ikram_exc)
        if not ready:
            # The deep check (or the install that followed it) could not make
            # the essentials present. Opening the menu now would only fail
            # later, mid-operation; stop here with the reason already on screen.
            self.wait_enter()
            return
        # Splash last, right before the menu. Check/install work is already done.
        try:
            if self.ikram is not None:
                self.ikram.welcome_splash()
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.run:welcome", _ikram_exc)
        got = None
        try:
            import menus
            while True:
                self.cls()
                self.write("\n\n".join(self.main_menu()) + "\n")
                got = self.prompt_in(menus.menu_choices(menus.CATEGORY_MAIN),
                                     glyph("arrow") + " SELECT:",
                                     main=menus.menu_choice_title(menus.CATEGORY_MAIN))
                if not got or got == "0":
                    self.exit_screen()
                    return
                target = next((t for k, _l, _h, t
                               in menus.menu_entries(menus.CATEGORY_MAIN)
                               if k == got), None)
                self.cls()
                if target == "run_pak":
                    self.run_pak()
                elif target == "run_lua":
                    self.run_lua()
                elif target == "run_savegames":
                    self.run_savegames()
                elif target == "run_themes":
                    self.run_themes()
                elif target == "run_clean":
                    self.run_clean()
        except KeyboardInterrupt:
            self.exit_screen()
        except Exception as e:
            ikram_logger.log_exc("vip_ui.run:446", e)
            self.cls()
            self.reset_term()
            # log_exc above already wrote the type, message and full traceback
            # to the local error log. The user still gets a clean styled box
            # with no raw traceback, but the box now points at the log and
            # echoes the newest line so the failure is diagnosable on the spot.
            logp = last = ""
            try:
                logp = ikram_logger.log_path()
                tail = ikram_logger.recent(1)
                last = tail[-1] if tail else ""
            except Exception as _ikram_exc:
                ikram_logger.log_exc("vip_ui.run:460", _ikram_exc)
            rows = ["✗ Unexpected error", str(e)[:80]]
            if last:
                rows.append("log : " + last[:96])
            next_step = ("full detail in %s" % logp) if logp else "Restart and try again."
            self.error_box(rows, next_step=next_step)
            self.wait_enter()
            return

    def _mark_outcome(self, outcome):
        """Set the outcome a runner wants preserved for the main-menu line."""
        try:
            self._last_outcome = outcome
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui._mark_outcome", _ikram_exc)

    def require_key(self):
        """Re-verify the session key before an operation. Fail closed."""
        try:
            import keygate
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.require_key:import", _ikram_exc)
            self._key_locked_box()
            return False
        try:
            return bool(keygate.require(self))
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui.require_key", _ikram_exc)
        self._key_locked_box()
        return False

    def _key_locked_box(self):
        try:
            rows = [self.theme.apply("Key required.", "error"),
                    self.theme.apply("Restart and enter the key.", "warn")]
            self.write(self.box.draw_box(rows, "heavy", title="KEY REQUIRED",
                                         color_role="error") + "\n")
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui._key_locked_box", _ikram_exc)
        try:
            self.wait_enter()
        except Exception as _ikram_exc:
            ikram_logger.log_exc("vip_ui._key_locked_box.wait", _ikram_exc)

    def _run_action(self, label, fn):
        """Run one menu operation, then remember it for the main menu.

        RESULT is not walked here. With large unpack trees that walk alone cost
        seconds on every menu choice. Operations report their own outcome; the
        menu record stays cheap and does not touch output data.
        """
        if not self.require_key():
            return
        self._last_outcome = None
        try:
            fn(self)
        finally:
            try:
                paths.invalidate_tree_stats()
            except Exception as _ikram_exc:
                ikram_logger.log_exc("vip_ui._run_action:stats", _ikram_exc)
            try:
                startup.remember(label, None, None, None, None,
                                 self._last_outcome)
            except Exception as _ikram_exc:
                ikram_logger.log_exc("vip_ui._run_action:496", _ikram_exc)

    def run_pak(self):
        import menus
        while True:
            self.cls()
            self.write("\n\n".join(self.render_menu(menus.CATEGORY_PAK)) + "\n")
            got = self.prompt_in(menus.menu_choices(menus.CATEGORY_PAK),
                                 glyph("arrow") + " SELECT:",
                                 main=menus.menu_choice_title(menus.CATEGORY_PAK))
            if not got or got == "0":
                return
            self.cls()
            if got == "1":
                self._run_action("PAK Unpack", menus.pak_unpack)
            elif got == "2":
                self._run_action("PAK Inject", menus.pak_inject)
            elif got == "3":
                self._run_action("PAK Repack", menus.pak_repack)
            elif got == "4":
                self._run_action("Custom Pak", menus.pak_custom)

    def run_lua(self):
        if not self.require_key():
            return
        import menus
        import lua_pipeline
        if not getattr(self, "_deps_checked", False):
            self._deps_checked = True
            deps = lua_pipeline.deps_status()
            if deps["missing"]:
                self.cls()
                want = self.confirm_box(
                    "DEPENDENCY CHECK",
                    "Some Lua tools are missing:\n  %s\n\n  Install them now?"
                    % "\n  ".join(deps["missing"][:6]),
                    yes_label="Install")
                if want:
                    frame = ProgressFrame(self, title="Installing missing tools")
                    results = lua_pipeline.install_missing(progress=frame)
                    frame.close(cur="Finished")
                    ok_n = sum(1 for _c, ok, _t in results if ok)
                    self.cls()
                    self.write(self.box.draw_box([
                        self.theme.apply("✓ Tools installed: %d/%d"
                                         % (ok_n, len(results)), "success"),
                    ], "rounded", title="Setup") + "\n")
                    self.wait_enter()
        while True:
            self.cls()
            self.write("\n\n".join(self.render_menu(menus.CATEGORY_LUA)) + "\n")
            got = self.prompt_in(menus.menu_choices(menus.CATEGORY_LUA),
                                 glyph("arrow") + " SELECT:",
                                 main=menus.menu_choice_title(menus.CATEGORY_LUA))
            if not got or got == "0":
                return
            self.cls()
            if got == "1":
                self._run_action("Lua Compile", menus.lua_compile)
            elif got == "2":
                self._run_action("Lua Decompile", menus.lua_decompile)

    def run_savegames(self):
        if not self.require_key():
            return
        import savegames
        self._run_action("SaveGames", savegames.run)

    def run_clean(self):
        import menus
        self._run_action("CLEAN", menus.run_clean)

    def run_themes(self):
        import menus
        choices = tuple(str(i) for i in range(1, len(THEMES) + 1))
        while True:
            extra = []
            for i, name in enumerate(THEMES, 1):
                th = Theme(name)
                symbol = th.apply(glyph("symbol"), "primary")
                label = symbol + " " + th.apply(safe_text(name), "primary")
                if name == self.theme.name:
                    label += self.theme.apply("  " + glyph("ok"), "success")
                extra.append((str(i), label, []))
            self.cls()
            self.write("\n\n".join(
                self.render_menu(menus.CATEGORY_THEMES, extra, "choose theme")) + "\n")
            got = self.read_choice(choices + ("0",), glyph("arrow") + " SELECT:",
                                   main=menus.menu_choice_title(menus.CATEGORY_THEMES))
            if not got or got == "0":
                self._mark_outcome("CANCEL")
                return
            name = THEMES[int(got) - 1]
            if not self.require_key():
                continue
            applied = False
            error = None
            try:
                if name != self.theme.name:
                    save_theme(name)
                    self.theme = Theme(name)
                    self.box = BoxEngine(self.theme)
                    _sync_compiled_theme(self)
                    applied = True
            except Exception as _ikram_exc:
                error = _ikram_exc
                ikram_logger.log_exc("vip_ui.run_themes.apply", _ikram_exc)
            self.cls()
            if error is not None:
                self._mark_outcome("ERROR")
                self.error_box(["✗ Theme was not changed",
                                str(error)[:80]],
                               next_step="check .ikram_secure/error.log")
            elif applied:
                self._mark_outcome("SUCCESS")
                self.write(self.box.draw_box([
                    self.theme.apply(name, "primary"),
                ], "rounded", title="Theme set") + "\n")
            else:
                self._mark_outcome("CANCEL")
                self.write(self.box.draw_box([
                    self.theme.apply(name + " is already active", "info"),
                ], "rounded", title="Theme unchanged") + "\n")
            self.wait_enter()
            continue  # theme list stays open; 0 goes back to MAIN
