"""IkramTool V130 — session-only key gate.

One fixed key unlocks the process. The plaintext key is kept only in the
running Vip object. Nothing is written to disk on success: no activation file,
no token, no remembered key. A restart always asks again.

Verification is high level and local:

  * PBKDF2-HMAC-SHA256 with a fixed per-build salt and 480000 rounds,
    compared in constant time against the verifier in ikram_key.json.
  * a plain SHA-256 check against the same file, so the compiled `key.pyc`
    verifier and source gate agree on one key.

`require(vip)` re-runs the full check before every operation. A missing,
cleared, or replaced session key blocks the operation with one short box.
"""

import hashlib
import hmac
import json

import ikram_logger
import paths
from theme_engine import glyph

_EXIT_WORDS = ("exit", "quit", "q", ":q", "/exit", "/quit")
_MAX_TRIES = 5
_MARKER = glyph("arrow") + " KEY :"

_KDF = "pbkdf2_sha256"
_ITERATIONS = 480000
_SALT = "494b52414d5f563133305f53414c545f3031"
_VERIFIER = "423960e0480083b8a14f16ba2b3419df26d07e028fea3126a2c7692d7549cc5a"
_SHA256 = "da4202ca18f231f0c069ba165f5a52ac18b2a4eb47fbc71efcb7d1b85a81b67f"

# Full KDF proof is expensive. A successful boot caches the exact normalized
# key together with a fingerprint of the key file. Every later require() still
# checks the live session value and key file, but skips the repeated KDF work.
_VERIFIED = {}
_VERIFIED_MAX = 16


def _proof_key(entered, data):
    try:
        stamp = json.dumps(data, sort_keys=True, separators=(",", ":"))
    except Exception:
        stamp = repr(data)
    return (entered, stamp, paths.read_version())


def _load():
    try:
        data = json.loads((paths.ENGINE_DIR / "ikram_key.json").read_text(
            encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        ikram_logger.log_exc("keygate._load", exc)
        return {}


def _normalize(value):
    return "" if value is None else str(value).strip().upper()


def verify(value) -> bool:
    """Full high-level verification. No persistence, no activation state."""
    entered = _normalize(value)
    if not entered:
        return False
    data = _load()
    if not data:
        return False
    if str(data.get("version", "")).strip() != paths.read_version():
        return False
    proof_key = _proof_key(entered, data)
    if _VERIFIED.get(proof_key):
        return True
    raw = entered.encode("utf-8")
    try:
        digest = hashlib.sha256(raw).hexdigest().lower()
        stored_sha = str(data.get("key_hash", "")).strip().lower()
        if not stored_sha or not hmac.compare_digest(digest, stored_sha):
            return False
        salt = bytes.fromhex(str(data.get("kdf_salt", _SALT)).strip())
        rounds = int(data.get("kdf_rounds", _ITERATIONS))
        if rounds < 100000:
            return False
        proof = hashlib.pbkdf2_hmac("sha256", raw, salt, rounds, dklen=32).hex()
        stored_proof = str(data.get("kdf_verifier", _VERIFIER)).strip().lower()
        if not stored_proof or not hmac.compare_digest(proof, stored_proof):
            return False
        if str(data.get("kdf", _KDF)).strip().lower() != _KDF:
            return False
        if len(_VERIFIED) >= _VERIFIED_MAX:
            _VERIFIED.clear()
        _VERIFIED[proof_key] = True
        return True
    except Exception as exc:
        ikram_logger.log_exc("keygate.verify", exc)
        return False


def session_key(vip):
    """Return the in-memory session key without touching any storage."""
    return getattr(vip, "_ikram_session_key", "")


def require(vip) -> bool:
    """Verify the session before an action. Blocks silently on failure."""
    if verify(session_key(vip)):
        return True
    try:
        vip._ikram_session_key = ""
    except Exception:
        pass
    _error(vip, "Key required.", "No operation started. Restart and enter the key.")
    return False


def _title():
    return "IkramTOOL  %s" % paths.read_version()


def _prompt_box(vip, tries=0):
    """One box. Errors stay inside it; no extra error box is printed."""
    th = vip.theme
    rows = [
        th.apply("%s  KEY REQUIRED" % glyph("symbol"), "primary"),
        th.apply("  Enter the TOOL key to continue.", "dim"),
    ]
    if tries:
        head = "SESSION LOCKED" if tries >= _MAX_TRIES else "KEY REJECTED"
        rows.append(th.apply("%s  %s" % (glyph("fail"), head), "error"))
        rows.append(th.apply("  Key does not match this build.  %d/%d"
                             % (tries, _MAX_TRIES), "warn"))
    rows.append(th.apply(_MARKER, "prompt"))
    return vip.file_context_box(_title(), (), title="LICENSE KEY",
                                extra=rows, token="warn" if tries else "info")


def _error(vip, headline, detail):
    """One red box: short line, then one colored detail line."""
    th = vip.theme
    rows = [th.apply(headline, "error"), th.apply(detail, "warn")]
    try:
        vip.write(vip.box.draw_box(rows, "heavy", title="KEY REQUIRED",
                                   color_role="error") + "\n")
    except Exception as exc:
        ikram_logger.log_exc("keygate._error", exc)
    try:
        vip.wait_enter()
    except Exception as exc:
        ikram_logger.log_exc("keygate._error.wait", exc)


def enforce(vip) -> bool:
    """Ask for the key before boot. True only with a verified session key."""
    tries = 0
    while True:
        vip.cls()
        box = _prompt_box(vip, tries)
        writer = getattr(vip, "write_prompt_box", None)
        if callable(writer):
            writer(box, _MARKER)
        else:
            vip.write(box + "\n")
        try:
            raw = vip._ask("")
        except (EOFError, KeyboardInterrupt):
            vip._ikram_session_key = ""
            return False
        entered = (raw or "").strip()
        if not entered or entered.lower() in _EXIT_WORDS:
            vip._ikram_session_key = ""
            return False
        if verify(entered):
            vip._ikram_session_key = entered
            return True
        tries += 1
        if tries >= _MAX_TRIES:
            vip.cls()
            vip.write(_prompt_box(vip, tries) + "\n")
            vip._ikram_session_key = ""
            try:
                vip.wait_enter()
            except Exception as exc:
                ikram_logger.log_exc("keygate.enforce.locked.wait", exc)
            return False
