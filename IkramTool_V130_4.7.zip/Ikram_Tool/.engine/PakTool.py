#!/usr/bin/env python3
"""
Ikram PakTool - Tencent PUBG (v14/ODPaks) oriented pak utility.
Uses Ikram engine stack (pak.pyc + tencent_pak.py writer) for byte-faithful
index/footer handling and verbatim-preserve of unchanged bodies.

Commands:
  info      <pak>                         inspect pak
  list      <pak> [prefix]                list entries
  unpack    <pak> <out_dir>               extract all entries (read_entry bytes)
  extract   <pak> <internal_path> <out>   extract one entry to file
  inject    <src_pak> <out_pak> <in_dir> [--target <pak_prefix>] [--force-add]
                                          replace/add files from in_dir
  replace   <src_pak> <internal_path> <file> <out_pak>
                                          replace/add one file at internal pak path
  repack    <src_pak> <in_dir> <out_pak> [--target <pak_prefix>]
                                          apply folder edits over template tree
  custom    <src_template_pak> <file> <internal_path> <out_pak>
                                          template pak + one file at custom path
  verify    <pak>                         parse + read all entries (integrity check)
  batch-unpack <in_dir> <out_dir>         unpack every *.pak under in_dir

Notes:
  - Tencent v14: index encrypted (AES-256-CBC, RSA-extracted key/iv), masked 45-byte
    footer tail (CTQL magic), negative dir refs, block-compressed bodies, SHA1 hashes,
    unk2=md5(plain)+slice. em 31..55 (SM4-family) bodies must stay verbatim when unchanged.
  - Custom/repack/inject are template-based on src_pak crypto/index context (original logic).
  - Paths are pak-internal; --target helps map relative files into pak subtree.
"""
import argparse
import hashlib
import os
import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
# support both layouts: this file in .engine/ (new) or in tool root (old)
_CANDIDATES = [_HERE, _HERE / ".engine", _HERE.parent / ".engine"]
for _p in _CANDIDATES:
    if (_p / "engines.py").is_file() or (_p / "engines.pyc").is_file() or (_p / "pak.pyc").is_file():
        ENGINE_DIR = _p
        break
else:
    ENGINE_DIR = _HERE
if str(ENGINE_DIR) not in sys.path:
    sys.path.insert(0, str(ENGINE_DIR))

import engines  # noqa: E402


def _pakmod():
    return engines.pakmod()


def _open_pak(path):
    pakmod = _pakmod()
    r = pakmod.PakReader(str(path))
    return r


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(1 << 22)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _iter_entries(reader):
    # dirs: {dir_path: {name: entry}}
    for d, items in reader.dirs.items():
        for name, e in items.items():
            yield (d + name), e


def cmd_info(args):
    p = args.pak
    kind = engines.detect_kind(p)
    print(f"path: {p}")
    print(f"size: {os.path.getsize(p)}")
    print(f"sha256: {_sha256_file(p)}")
    print(f"kind: {kind}")
    r = _open_pak(p)
    info = r.info
    print(f"version: {info.version}")
    print(f"magic: 0x{info.magic:08x}")
    print(f"index_encrypted: {info.index_encrypted}")
    print(f"index_offset: {info.index_offset}")
    print(f"index_size: {info.index_size}")
    print(f"footer_size: {info.footer_size()}")
    print(f"mount: {getattr(r, 'mount_point', '')!r}")
    files = list(_iter_entries(r))
    print(f"entries: {len(files)}")
    enc = {}
    comp = {}
    total_u = 0
    for _, e in files:
        enc[e.encryption_method] = enc.get(e.encryption_method, 0) + 1
        comp[e.compression_method] = comp.get(e.compression_method, 0) + 1
        total_u += int(getattr(e, "uncompressed_size", 0) or 0)
    print(f"uncompressed_total: {total_u}")
    print(f"compression_methods: {comp}")
    print(f"encryption_methods: {enc}")


def cmd_list(args):
    r = _open_pak(args.pak)
    prefix = args.prefix or ""
    for path, e in _iter_entries(r):
        if prefix and not path.startswith(prefix):
            continue
        print(
            f"{path}\tstored={e.size}\tuncompressed={e.uncompressed_size}\t"
            f"comp={e.compression_method}\tenc={e.encryption_method}\tencrypted={e.encrypted}"
        )


def _safe_join(out_dir: Path, rel: str) -> Path:
    rel = rel.replace("\\", "/").lstrip("/")
    # prevent traversal
    parts = [p for p in rel.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise ValueError(f"unsafe path: {rel}")
    dest = out_dir.joinpath(*parts) if parts else out_dir
    return dest


def cmd_unpack(args):
    r = _open_pak(args.pak)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for path, e in _iter_entries(r):
        dest = _safe_join(out_dir, path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        data = _read_entry_data(r, path, e)
        with open(dest, "wb") as f:
            f.write(data)
        count += 1
        print(f"extracted: {path} ({len(data)} bytes)")
    print(f"done: {count} entries -> {out_dir}")


def cmd_extract(args):
    r = _open_pak(args.pak)
    want = args.internal_path.replace("\\", "/").lstrip("/")
    found = None
    for path, e in _iter_entries(r):
        if path == want:
            found = (path, e)
            break
    if not found:
        raise SystemExit(f"entry not found: {want}")
    path, e = found
    data = _read_entry_data(r, path, e)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    print(f"extracted: {path} -> {out} ({len(data)} bytes)")


def _collect_edits(in_dir: Path):
    edits = []
    for root, dirs, files in os.walk(in_dir):
        dirs[:] = [d for d in dirs
                   if not d.startswith(".") and d != "_quarantine"]
        for fn in files:
            if fn.startswith("."):
                continue
            full = Path(root) / fn
            rel = full.relative_to(in_dir).as_posix()
            data = full.read_bytes()
            edits.append((rel, data))
    return sorted(edits, key=lambda item: item[0])


def _progress(done, total, fp):
    pct = (done * 100 // total) if total else 100
    sys.stderr.write(f"\r[{pct:3d}%] {fp}    ")
    sys.stderr.flush()


def _on_file(fp):
    if fp:
        sys.stderr.write(f"\r[ok] {fp}                    \n")
        sys.stderr.flush()


def _read_entry_data(reader, path, e):
    try:
        data = reader.read_entry(e)
    except Exception:
        data = reader.read_file(path) if hasattr(reader, "read_file") else None
    if data is None:
        raise RuntimeError(f"failed to read: {path}")
    return data


def _internal_path(raw):
    p = str(raw or "").replace("\\", "/").lstrip("/")
    parts = [x for x in p.split("/") if x not in ("", ".")]
    if not parts:
        raise SystemExit("internal path must not be empty")
    if any(x == ".." for x in parts):
        raise SystemExit(f"unsafe internal path: {p}")
    return "/".join(parts)


def _stored_bytes(reader, e):
    off = int(getattr(e, "offset", 0) or 0)
    size = int(getattr(e, "size", 0) or 0)
    if off < 0 or size < 0:
        raise RuntimeError(f"invalid stored range: offset={off} size={size}")
    if hasattr(reader, "_read_at"):
        raw = reader._read_at(off, size)
    elif getattr(reader, "content", None) is not None:
        raw = bytes(reader.content[off:off + size])
    else:
        with open(reader.file_path, "rb") as fh:
            fh.seek(off)
            raw = fh.read(size)
    if raw is None or len(raw) != size:
        raise RuntimeError(f"short stored body: expected {size} got {len(raw or b'')}")
    return bytes(raw)


def _do_inject(src_pak, out_pak, edits, target_path=None, force_add=False):
    src = Path(src_pak).resolve()
    out = Path(out_pak).resolve()
    if src == out:
        raise SystemExit("out_pak must not be the original/source pak")
    pakmod = _pakmod()
    engines._install_unk2_fix(pakmod)
    reader = pakmod.PakReader(str(src_pak))
    writer = pakmod.PakWriter(reader)
    n = writer.inject_files(
        edits,
        str(out_pak),
        force_add=force_add,
        target_path=target_path,
        progress=_progress,
        on_file=_on_file,
    )
    sys.stderr.write("\n")
    digest = _sha256_file(out_pak)
    print(f"wrote: {out_pak} (files indexed: {n}, sha256: {digest})")


def cmd_inject(args):
    in_dir = Path(args.in_dir)
    if not in_dir.is_dir():
        raise SystemExit(f"input dir not found: {in_dir}")
    edits = _collect_edits(in_dir)
    if not edits:
        raise SystemExit("no files found in input dir")
    print(f"edits: {len(edits)} from {in_dir}")
    _do_inject(args.src_pak, args.out_pak, edits, target_path=args.target, force_add=args.force_add)


def cmd_repack(args):
    # repack = apply all files in in_dir as edits over src_pak (replace matching, keep others)
    in_dir = Path(args.in_dir)
    if not in_dir.is_dir():
        raise SystemExit(f"input dir not found: {in_dir}")
    edits = _collect_edits(in_dir)
    if not edits:
        raise SystemExit("no files found in input dir")
    print(f"repack edits: {len(edits)} from {in_dir}")
    _do_inject(args.src_pak, args.out_pak, edits, target_path=args.target, force_add=True)


def cmd_custom(args):
    fpath = Path(args.file)
    if not fpath.is_file():
        raise SystemExit(f"file not found: {fpath}")
    data = fpath.read_bytes()
    internal = _internal_path(args.internal_path)
    edits = [(internal, data)]
    print(f"custom: {internal} ({len(data)} bytes) from template {args.src_template_pak}")
    _do_inject(args.src_template_pak, args.out_pak, edits, target_path=None, force_add=True)


def cmd_replace(args):
    fpath = Path(args.file)
    if not fpath.is_file():
        raise SystemExit(f"file not found: {fpath}")
    internal = _internal_path(args.internal_path)
    edits = [(internal, fpath.read_bytes())]
    print(f"replace: {internal} from {fpath}")
    _do_inject(args.src_pak, args.out_pak, edits, target_path=None, force_add=True)


def cmd_verify(args):
    r = _open_pak(args.pak)
    kind = engines.detect_kind(args.pak)
    ok = 0
    bad = 0
    for path, e in _iter_entries(r):
        try:
            data = _read_entry_data(r, path, e)
            if int(getattr(e, "uncompressed_size", 0) or 0) != len(data):
                raise RuntimeError(f"size mismatch: expected {e.uncompressed_size} got {len(data)}")
            expected = getattr(e, "content_hash", None)
            if expected is not None:
                stored = _stored_bytes(r, e)
                actual = hashlib.sha1(stored).digest()
                if actual != bytes(expected):
                    raise RuntimeError(
                        "content hash mismatch: expected %s got %s"
                        % (bytes(expected).hex(), actual.hex()))
            ok += 1
        except Exception as ex:
            bad += 1
            print(f"BAD: {path}: {ex}")
    print(f"verify: kind={kind} entries={ok+bad} ok={ok} bad={bad}")
    if bad:
        raise SystemExit(2)


def cmd_batch_unpack(args):
    in_dir = Path(args.in_dir)
    out_dir = Path(args.out_dir)
    paks = sorted(in_dir.rglob("*.pak"))
    if not paks:
        raise SystemExit(f"no .pak files under {in_dir}")
    ok = 0
    bad = 0
    for p in paks:
        rel = p.relative_to(in_dir)
        dest = out_dir / rel.with_suffix("")
        print(f"==> {p} -> {dest}")
        try:
            r = _open_pak(str(p))
            dest.mkdir(parents=True, exist_ok=True)
            n = 0
            for path, e in _iter_entries(r):
                d = _safe_join(dest, path)
                d.parent.mkdir(parents=True, exist_ok=True)
                d.write_bytes(_read_entry_data(r, path, e))
                n += 1
            ok += 1
            print(f"    ok: {n} entries")
        except Exception as ex:
            bad += 1
            print(f"FAILED: {p}: {ex}")
    print(f"batch-unpack done: paks={len(paks)} ok={ok} failed={bad}")
    if bad:
        raise SystemExit(2)


def main():
    ap = argparse.ArgumentParser(prog="PakTool", description="Ikram Tencent PUBG PakTool")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("info")
    p.add_argument("pak")
    p.set_defaults(func=cmd_info)

    p = sub.add_parser("list")
    p.add_argument("pak")
    p.add_argument("prefix", nargs="?")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("unpack")
    p.add_argument("pak")
    p.add_argument("out_dir")
    p.set_defaults(func=cmd_unpack)

    p = sub.add_parser("extract")
    p.add_argument("pak")
    p.add_argument("internal_path")
    p.add_argument("out")
    p.set_defaults(func=cmd_extract)

    p = sub.add_parser("inject")
    p.add_argument("src_pak")
    p.add_argument("out_pak")
    p.add_argument("in_dir")
    p.add_argument("--target", default=None, help="pak path prefix to resolve relative files against")
    p.add_argument("--force-add", action="store_true")
    p.set_defaults(func=cmd_inject)

    p = sub.add_parser("replace")
    p.add_argument("src_pak")
    p.add_argument("internal_path")
    p.add_argument("file")
    p.add_argument("out_pak")
    p.set_defaults(func=cmd_replace)

    p = sub.add_parser("repack")
    p.add_argument("src_pak")
    p.add_argument("in_dir")
    p.add_argument("out_pak")
    p.add_argument("--target", default=None)
    p.set_defaults(func=cmd_repack)

    p = sub.add_parser("custom")
    p.add_argument("src_template_pak")
    p.add_argument("file")
    p.add_argument("internal_path")
    p.add_argument("out_pak")
    p.set_defaults(func=cmd_custom)

    p = sub.add_parser("verify")
    p.add_argument("pak")
    p.set_defaults(func=cmd_verify)

    p = sub.add_parser("batch-unpack")
    p.add_argument("in_dir")
    p.add_argument("out_dir")
    p.set_defaults(func=cmd_batch_unpack)

    args = ap.parse_args()
    try:
        args.func(args)
    except SystemExit:
        raise
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as ex:
        msg = str(ex).strip()
        type_prefix = type(ex).__name__ + ": "
        if msg.startswith(type_prefix):
            msg = msg[len(type_prefix):].strip()
        if msg.lower().startswith("error:"):
            msg = msg[6:].strip()
        raise SystemExit(f"error: {msg}")


if __name__ == "__main__":
    main()
