# Ikram PakTool (A–Z) — PUBG Mobile Tencent `.pak` (v14 / ODPaks)

Workspace analysis base: `C:\Users\LENOVO\opencode\ORGINAL-PAKS` (126 paks).

## Phase 1 findings (original logic, verified)

- **Type:** Tencent PUBG pak (not plain UE4). `engines.detect_kind` => `tencent` for all corpus samples.
- **Version/magic/mount:** v14, index encrypted, magic `0x4C515443` (masked), mount `../../../`.
- **Observed entry methods:** compression mostly `1` (zlib), some `0`; encryption `55` and `16` dominant, some `0/17`.
- **Footer:** 45-byte masked tail (keystream/XOR with fields) + preceding memory block copied; writer reproduces tail/index from crypto context.
- **Index:** AES-256-CBC (PKCS7) over plaintext when encrypted; key/IV derived from `packed_key`/`packed_iv` via `rsa_extract(..., RSA_MOD_1)`. `index_hash = SHA1(unpadded plaintext)`.
- **Index layout:** `wstring(mount) | u32 file_count | file_records | u64 dir_count | (wstring(dir)|u64 n|(wstring(name)|i32 -(file_pos+1))*)* | trailing`. Dir refs negative (`-1 => files[0]`).
- **Bodies:** chunked (~64K), compressed (zlib/zstd/none), encrypted per method; block windows store pre-encryption compressed lengths; 16-byte alignment/padding; `entry.size` padded stored length.
- **Hashes:** `content_hash = SHA1(stored body)`, `unk2 = md5(plain)+md5(plain)[4:8]`.
- **Critical fidelity rule:** encryption methods **31..55** (SM4-family, e.g. 55) are not reproducibly re-encoded generically — **unchanged bodies must be copied byte-for-byte**. Changed/new bodies are re-encoded through the engine/writer path valid for the pak.
- **Engine stack used:** `.engine/pak.pyc` (reader/writer structs), `.engine/tencent_pak.py` (byte-correct Tencent writer), `.engine/engines.py`, `.engine/pakcrypto.pyc` (ZUC/RSA/SIMPLE1/SM4 key derivation paths).

## PakTool CLI

Path: `Ikram_Tool/.engine/PakTool.py` (uses `.engine` automatically).

```bash
cd ~/opencode/Ikram_Tool/.engine

# inspect
python3 PakTool.py info <pak>
python3 PakTool.py list <pak> [prefix]
python3 PakTool.py verify <pak>

# unpack
python3 PakTool.py unpack <pak> <out_dir>
python3 PakTool.py extract <pak> <internal_path> <out_file>
python3 PakTool.py batch-unpack <in_dir> <out_dir>

# inject (replace/add files from folder; original logic for unchanged bodies)
python3 PakTool.py inject <src_pak> <out_pak> <in_dir> [--target <pak_prefix>] [--force-add]
python3 PakTool.py replace <src_pak> <internal_path> <file> <out_pak>

# repack (apply folder edits over template tree)
python3 PakTool.py repack <src_pak> <in_dir> <out_pak> [--target <pak_prefix>]

# custom pak: add/override ONE file at arbitrary internal path (real template-based pak)
python3 PakTool.py custom <src_template_pak> <file> <internal_path> <out_pak>
```

## Workflows

### Unpack original
```bash
python3 PakTool.py unpack /path/to/original.pak /path/to/out_dir
```
Extracts entries via reader (`read_entry`), preserving internal paths and uncompressed bytes.

### Inject mod/lua/asset (original logic, keeps other entries intact)
```bash
mkdir -p /tmp/mods/ShadowTrackerExtra/Content/Paks/Mods
cp my_mod.lua /tmp/mods/ShadowTrackerExtra/Content/Paks/Mods/my_mod.lua
python3 PakTool.py inject original.pak injected.pak /tmp/mods --force-add
python3 PakTool.py verify injected.pak
```
- Unchanged entries/bodies preserved verbatim (critical for SM4 em55 assets).
- Modified/added entries encoded with correct hashes/block windows/index/footer by writer.

### Custom pak with one file at custom ("ransod"/arbitrary) path
```bash
python3 PakTool.py custom template_small.pak ./my_mod.lua \
  "ShadowTrackerExtra/Content/Custom/Any/Path/my_mod.lua" custom.pak
python3 PakTool.py verify custom.pak
```
- **Template-based:** use a real original small pak from the same game/version as `template_small.pak` so crypto/index/footer context is authentic.

### Repack folder edits
```bash
python3 PakTool.py repack original.pak ./edited_tree repacked.pak --force-add
```

## Practical notes
- Use a **real original pak from the same build** as template/source for inject/repack/custom to keep encryption/index/footer context “original”.
- `--target <prefix>` helps map local relative files into a pak subtree.
- Always `verify` output: `python3 PakTool.py verify out.pak`.
- Paths inside pak are case/path sensitive (use `list` to confirm).
- This is for legitimate modding/research on files you own; in-game acceptance/anti-cheat behavior depends on game-side checks beyond pak structure.

## Limits
- Some crypto/reader internals live in compiled `.pyc` modules; full from-scratch keyless synthesis for every encryption method is constrained by what the engine exposes. Template-based operations provide highest fidelity.
- No guarantee against game bans or crashes in all scenarios — fidelity reduces structural issues but cannot override runtime/game integrity rules.
