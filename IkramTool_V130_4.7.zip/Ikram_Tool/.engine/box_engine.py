"""IkramTool VIP box engine (V112).

The ONLY printer in the tool. No raw print() anywhere else — every line a
box, every box terminal-width aware ((term - 4), clamped 50..90), every
overflow truncated with an ellipsis, every border theme-aware.

Styles (Phase 8):
  heavy   ╔═╗  double  ╠ ╣  rounded ╭─╮  thick ┏━┓  light ┌─┐  minimal ▌
  `minimal` is only legal for the Press-ENTER wait line.

Internal divider rows: a content row equal to the SEP sentinel renders a
full-width divider (╠═╣ / ├─┤ ...) per the box style.
"""
import re

from theme_engine import (
    Theme, terminal_width, strip_ansi, display_width, safe_text, glyph,
    BOX_TOKENS, RESET,
)

_ANSI_SGR = re.compile(r"\x1b\[[0-9;]*m")

SEP = "__SEP__"

# Last-resort cycle for themes that do not expose number_cycle().
_VIP_NUM = Theme("Original Color").number_cycle()

_BOXES = {
    "heavy":   {"tl": "╔", "tr": "╗", "bl": "╚", "br": "╝",
                "h": "═", "v": "║", "jt": "╠", "je": "╣"},
    "double":  {"tl": "╔", "tr": "╗", "bl": "╚", "br": "╝",
                "h": "═", "v": "║", "jt": "╠", "je": "╣"},
    "rounded": {"tl": "╭", "tr": "╮", "bl": "╰", "br": "╯",
                "h": "─", "v": "│", "jt": "├", "je": "┤"},
    "thick":   {"tl": "┏", "tr": "┓", "bl": "┗", "br": "┛",
                "h": "━", "v": "┃", "jt": "┣", "je": "┫"},
    "light":   {"tl": "┌", "tr": "┐", "bl": "└", "br": "┘",
                "h": "─", "v": "│", "jt": "├", "je": "┤"},
    "minimal": {"tl": "▌", "tr": "", "bl": "▌", "br": "",
                "h": "", "v": "", "jt": "", "je": ""},
}


def visible_len(s: str) -> int:
    return display_width(s)


def _truncate(line: str, inner_w: int) -> str:
    """Truncate a pre-coloured line to inner_w visible chars.

    Walk the raw string so SGR escapes inside the kept range survive; a long
    numbered file row must not silently lose its per-file colour. A trailing
    RESET is appended whenever styling was present, or white bleeds into the
    next border row.
    """
    line = safe_text(line)
    ell = glyph("ellipsis")
    if visible_len(line) <= inner_w:
        return line
    limit = max(0, inner_w - display_width(ell))
    kept, used, i = [], 0, 0
    had_ansi = False
    while i < len(line):
        m = _ANSI_SGR.match(line, i)
        if m:
            kept.append(m.group(0))
            had_ansi = True
            i = m.end()
            continue
        ch = line[i]
        cw = display_width(ch)
        if used + cw > limit:
            break
        kept.append(ch)
        used += cw
        i += 1
    result = "".join(kept) + ell
    if had_ansi and not result.endswith(RESET):
        result += RESET
    return result


def _wrap_line(text, inner_w, max_lines=4, indent="    "):
    """Wrap one row without splitting it across box borders."""
    text = safe_text(text)
    if visible_len(text) <= inner_w:
        return [text]
    pm = re.match(r"^(?:\x1b\[[0-9;]*m)+", text)
    prefix = pm.group(0) if pm else ""
    plain = strip_ansi(text)
    out, cur = [], ""
    indent_w = display_width(indent)
    avail = max(8, inner_w - indent_w)
    for word in plain.split(" "):
        piece = word if not cur else cur + " " + word
        if visible_len(piece) <= avail:
            cur = piece
            continue
        if cur:
            out.append(indent + cur)
        cur = word
        while visible_len(cur) > avail:
            kept, used = [], 0
            for ch in cur:
                cw = display_width(ch)
                if used + cw > avail:
                    break
                kept.append(ch)
                used += cw
            out.append(indent + "".join(kept))
            cur = cur[len("".join(kept)):]
    if cur:
        out.append(indent + cur)
    def finish(rows):
        if not prefix:
            return rows
        return [prefix + r + RESET for r in rows]

    if len(out) > max_lines:
        kept = out[:max_lines]
        kept[-1] = _truncate(kept[-1], inner_w - display_width(glyph("ellipsis")) * 2) \
            + " " + glyph("ellipsis")
        return finish(kept)
    return finish(out)


def _human_counter(value, as_bytes=False):
    """Readable counter for byte-sized progress; raw ints stay raw elsewhere."""
    try:
        number = int(value)
    except (TypeError, ValueError):
        return "0"
    if not as_bytes or number < 1048576:
        return str(number)
    units = ("B", "KB", "MB", "GB", "TB", "PB")
    scaled = float(number)
    unit = units[0]
    for unit in units:
        if scaled < 1024.0 or unit == units[-1]:
            break
        scaled /= 1024.0
    if unit == "B":
        return "%d B" % number
    if scaled >= 100.0:
        return "%.0f %s" % (scaled, unit)
    if scaled >= 10.0:
        return "%.1f %s" % (scaled, unit)
    return "%.2f %s" % (scaled, unit)


class ProgressBar:
    """A single-line progress bar: «[▓▓▓▒░░░░]  62%»."""

    def __init__(self, theme):
        self.theme = theme

    def render(self, pct, width=34):
        pct = max(0.0, min(100.0, pct if isinstance(pct, (int, float)) else 0.0))
        width = max(6, int(width))
        filled = int(round(pct / 100.0 * width))
        # Positive sub-1% frames must never read 0%. Keep one cell lit.
        if pct > 0 and filled == 0:
            filled = 1
        shown_pct = 1 if 0 < pct < 1 else int(pct)
        full, empty = glyph("bar_full"), glyph("bar_empty")
        bar = full * filled + empty * (width - filled)
        colored = (self.theme.apply(full * filled, "accent")
                   + self.theme.apply(empty * (width - filled), "dim"))
        return "  [%s]  %3d%%" % (colored, shown_pct)


class BoxEngine:
    def __init__(self, theme: Theme | None = None):
        self.theme = theme or Theme("Cyber Blue")
        self._bar = ProgressBar(self.theme)

    # ------------------------------------------------------------- public
    def draw_box(self, content, style="heavy", title=None, subtitle=None,
                 width=None, align="left", padding=1, color_role="border"):
        lines = self._resolve(content)
        w = self._resolve_width(width)
        b = _BOXES.get(style, _BOXES["heavy"])
        inner_w = w - 4
        body = []

        if title is not None:
            body.append(self._row(b, self.theme.apply(str(title), "title"),
                                  inner_w, "center"))
            if subtitle is not None:
                body.append(self._row(b, self.theme.apply(str(subtitle), "secondary"),
                                      inner_w, "center"))
            body.append(self._divider(b, inner_w + 2, color_role))
        body.append(self._gap(b, inner_w))

        for ln in lines:
            if ln == SEP:
                body.append(self._divider(b, inner_w + 2, color_role))
                continue
            chunk = _truncate(str(ln), inner_w)
            body.append(self._row(b, chunk, inner_w, align))

        if style == "minimal":
            out = []
            for l in body[1:]:
                if visible_len(l) <= len(b["tl"]):
                    continue
                if "\x1b[" in l:
                    out.append(l.rstrip())
                else:
                    out.append(self.theme.apply(b["tl"] + " ", color_role)
                              + l.rstrip())
            return "\n".join(out or [" "])

        top = self.theme.apply(b["tl"] + b["h"] * (w - 2) + b["tr"], color_role)
        bottom = self.theme.apply(b["bl"] + b["h"] * (w - 2) + b["br"], color_role)
        return "\n".join([top] + body + [bottom])

    def draw_menu(self, opts, title=None, subtitle=None, width=None,
                  sub_role="border_dark"):
        """V111-exact menu: outer MENU_BOX (thick) frame with the title
        embedded in the top border; each option is a number+name row
        followed by its own ROUNDED sub-box (border_dark) holding the
        description lines; subtitle embedded in the bottom border.

        `opts` items may be:
        - `(digit, name, help_lines)` option tuple (digit row + sub-box), or
        - `(None, text, [help_lines])` bare text inside its own sub-box
          (no number row), or
        - raw row strings (rendered as-is)."""
        w = self._resolve_width(width)
        b = _BOXES["thick"]
        inner_w = w - 4
        body = [self._gap(b, inner_w)]

        for item in opts:
            if isinstance(item, (tuple, list)):
                digit, name = item[0], item[1]
                help_lines = list(item[2]) if len(item) > 2 else []
                if digit is None and isinstance(name, (tuple, list)):
                    lines = [" " + _truncate(str(l), inner_w - 6)
                             for l in name]
                    sb = self._menu_subbox(w - 6, lines, sub_role)
                    for sl in sb.split("\n"):
                        body.append(self._row(b, _truncate(sl, inner_w),
                                              inner_w, "left"))
                elif digit is None:
                    lines = [" " + self._detail_line(name, inner_w - 6)]
                    lines += [" " + self._detail_line(h, inner_w - 6)
                              for h in help_lines]
                    sb = self._menu_subbox(w - 6, lines, sub_role)
                    for sl in sb.split("\n"):
                        body.append(self._row(b, _truncate(sl, inner_w),
                                              inner_w, "left"))
                else:
                    cycle = getattr(self.theme, "number_cycle", None)
                    codes = cycle() if callable(cycle) else _VIP_NUM
                    name_row = "   " + self.theme.paint_code(
                        str(digit).rjust(3),
                        codes.get(str(digit), codes.get("5", 228)),
                        bold=True) + "  " \
                        + self.theme.apply(str(name), "text", bold=True)
                    body.append(self._row(b, _truncate(name_row, inner_w),
                                          inner_w, "left"))
                    if help_lines:
                        lines = [" " + self._detail_line(h, inner_w - 6)
                                 for h in help_lines]
                        sb = self._menu_subbox(w - 6, lines, sub_role)
                        for sl in sb.split("\n"):
                            body.append(self._row(b, _truncate(sl, inner_w),
                                                  inner_w, "left"))
            else:
                body.append(self._row(b, _truncate(str(item), inner_w),
                                      inner_w, "left"))
            body.append(self._row(b, "", inner_w, "left"))

        top = self._border_embed_fit(b, "top", title, inner_w + 2)
        bottom = self._border_embed_fit(b, "bottom", subtitle, inner_w + 2)
        return "\n".join([top] + body + [bottom])

    def _border_embed(self, b, pos, text, inner_w):
        """Border line with text embedded on it (┏━text━┓ / ┗━text━┛)."""
        if pos == "top":
            corner_a, corner_b = b["tl"], b["tr"]
            role = "title"
        else:
            corner_a, corner_b = b["bl"], b["br"]
            role = "secondary"
        if not text:
            return self.theme.apply(corner_a + b["h"] * inner_w + corner_b,
                                    "border")
        txt = self.theme.apply(safe_text(text), role)
        tw = visible_len(txt)
        if tw + 2 >= inner_w:
            return self.theme.apply(corner_a + b["h"] * inner_w + corner_b,
                                    "border")
        side = (inner_w - tw - 2) // 2
        line = (corner_a
                + self.theme.apply(b["h"] * side, "border")
                + " " + txt + " "
                + self.theme.apply(b["h"] * (inner_w - tw - 2 - side), "border")
                + corner_b)
        return line

    def _border_embed_fit(self, b, pos, text, inner_w, color_role="border"):
        """Border with centered text that ALWAYS fits. The older
        `_border_embed` dropped the text when it was too long; the main file
        name must never disappear from the top border."""
        text = _truncate(safe_text(text), max(1, inner_w - 2))
        role = "title" if pos == "top" else "secondary"
        if pos == "top":
            corner_a, corner_b = b["tl"], b["tr"]
        else:
            corner_a, corner_b = b["bl"], b["br"]
        txt = self.theme.apply(text, role)
        tw = display_width(txt)
        space = max(0, inner_w - tw - 2)
        left = space // 2
        right = space - left
        return (self.theme.apply(corner_a, color_role)
                + self.theme.apply(b["h"] * left, color_role)
                + " " + txt + " "
                + self.theme.apply(b["h"] * right, color_role)
                + self.theme.apply(corner_b, color_role))

    def draw_file_context(self, main, files=(), mode=None, target=None,
                          output=None, title=None, token=None, style=None,
                          extra=(), limit=8, width=None):
        """One box naming the main file in the TOP BORDER and listing
        secondary files under it. Pure: returns a string, no input/pause."""
        style, token_title, role = (BOX_TOKENS.get(token)
                                    if token else (style or "thick", "FILE", "border"))
        if not style:
            style = "thick"
        w = self._resolve_width(width)
        b = _BOXES.get(style, _BOXES["heavy"])
        inner_w = w - 4
        main_txt = safe_text(main) if main is not None else "-"
        label = safe_text(title) if title else token_title
        top = self._border_embed_fit(b, "top", main_txt, inner_w + 2, role)
        bottom = self._border_embed_fit(b, "bottom", label, inner_w + 2, role)
        body = [self._gap(b, inner_w)]
        if inner_w < 12:
            body.append(self._row(b, _truncate(main_txt, inner_w), inner_w, "left"))
        if mode:
            body.append(self._row(
                b, _truncate(self.draw_labeled_row("Mode", safe_text(mode)), inner_w),
                inner_w, "left"))
        if target:
            body.append(self._row(
                b, _truncate(self.draw_labeled_row("Target", safe_text(target)), inner_w),
                inner_w, "left"))
        if output:
            body.append(self._row(
                b, _truncate(self.draw_labeled_row("Output", safe_text(output)), inner_w),
                inner_w, "left"))
        items = [safe_text(x) for x in files]
        if items:
            body.append(self._divider(b, inner_w + 2, role))
            for item in items[:max(0, limit)]:
                body.append(self._row(
                    b, self.theme.apply("  " + glyph("bullet") + " " + item,
                                        "text"),
                    inner_w, "left"))
            if len(items) > limit:
                body.append(self._row(
                    b, self.theme.apply("  %s +%d more"
                                        % (glyph("ellipsis"), len(items) - limit),
                                        "text"),
                    inner_w, "left"))
        for line in extra:
            body.append(self._row(b, _truncate(safe_text(line), inner_w),
                                  inner_w, "left"))
        return "\n".join([top] + body + [bottom])

    def _menu_subbox(self, width, lines, role):
        """ROUNDED sub-box (border_dark) holding detail lines — V111's
        `detail_box`."""
        b = _BOXES["rounded"]
        inner_w = width - 4
        body = [self._gap(b, inner_w)]
        for ln in lines:
            chunk = _truncate(str(ln), inner_w)
            # Pad to the box's inner width. Without this the right border is
            # drawn right after the text and the top/bottom borders hang out
            # to the right of it, which reads as a broken frame.
            pad = inner_w - visible_len(chunk)
            if pad > 0:
                chunk += " " * pad
            body.append(self.theme.apply(b["v"] + " ", role)
                        + chunk + " "
                        + self.theme.apply(b["v"], role))
        top = self.theme.apply(b["tl"] + b["h"] * (width - 2) + b["tr"], role)
        bottom = self.theme.apply(b["bl"] + b["h"] * (width - 2) + b["br"],
                                  role)
        return "\n".join([top] + body + [bottom])

    def _detail_line(self, text, inner_w):
        """`LABEL: value` -> label bold flashy (228) + value muted (103),
        exactly the compiled V111 detail_box format. Pre-painted lines keep
        their own colours so CLEAN can tint FILES and SIZE separately."""
        text = str(text)
        if _ANSI_SGR.search(text):
            return "  " + text
        if ": " in text or ":" in text:
            if ": " in text:
                label, _, value = text.partition(": ")
            else:
                label, _, value = text.partition(":")
            if label.strip() and value.strip():
                return ("  " + self.theme.apply(label.strip(), "title",
                                                bold=True) + ": "
                        + self.theme.apply(value.strip(), "dim"))
        return "  " + self.theme.apply(text, "dim")

    def draw_progress(self, pct=None, done=None, total=None, cur=None,
                      speed=None, eta=None, style="heavy", width=None,
                      title="Working..."):
        w = self._resolve_width(width)
        b = _BOXES.get(style, _BOXES["heavy"])
        inner_w = w - 4
        lines = []
        hdr = self.theme.apply(str(title), "title")
        lines.append(self._row(b, _truncate(hdr, inner_w), inner_w, "center"))
        lines.append(self._divider(b, inner_w + 2, "border"))
        lines.append(self._gap(b, inner_w))

        if isinstance(pct, (int, float)):
            lines.append(self._row(b, self._bar.render(pct), inner_w, "left"))
        if done is not None or total is not None:
            f = int(done) if done is not None else 0
            t = int(total) if total is not None else 0
            txt = "Files   : %d / %d" % (f, t) if t else "Files   : %d" % f
            lines.append(self._row(b, self.theme.apply(txt, "secondary"),
                                   inner_w, "left"))
        if cur:
            lines.append(self._row(
                b, "Current : " + _truncate(self.theme.apply(str(cur), "text"), inner_w - 10),
                inner_w, "left"))
        if speed:
            lines.append(self._row(b, self.theme.apply("Speed   : " + str(speed), "info"),
                                   inner_w, "left"))
        if eta:
            lines.append(self._row(b, self.theme.apply("Remaining: " + str(eta), "info"),
                                   inner_w, "left"))
        top = self.theme.apply(b["tl"] + b["h"] * (w - 2) + b["tr"], "border")
        bottom = self.theme.apply(b["bl"] + b["h"] * (w - 2) + b["br"], "border")
        return "\n".join([top] + lines + [bottom])

    def draw_progress_box(self, title="Working...", pct=None, done=None,
                          total=None, cur=None, speed=None, eta=None,
                          elapsed=None, status=None, spinner=None,
                          style="heavy", width=None, bytes_mode=False):
        """Fixed-height progress frame: 11 physical lines in every state.
        Constant height is what lets the TTY renderer repaint in place."""
        w = self._resolve_width(width)
        b = _BOXES.get(style, _BOXES["heavy"])
        inner_w = w - 4
        pct_v = pct if isinstance(pct, (int, float)) else 0.0
        cur_txt = safe_text(cur) if cur else "-"
        speed_txt = safe_text(speed) if speed else "-"
        eta_txt = safe_text(eta) if eta else "-"
        elapsed_txt = safe_text(elapsed) if elapsed else "-"
        status_txt = safe_text(status) if status else "-"
        status_role = "success" if status in ("done", "ok", "complete") else "dim"
        if spinner:
            status_txt = "%s %s" % (safe_text(spinner), status_txt)
        bar_w = max(6, min(34, inner_w - 18))
        done_txt = _human_counter(done or 0, bytes_mode)
        total_txt = _human_counter(total or 0, bytes_mode)
        rows = [
            self._row(b, _truncate(self.theme.apply(str(title), "title"), inner_w),
                      inner_w, "center"),
            self._gap(b, inner_w),
            self._divider(b, inner_w + 2, "border"),
            self._row(b, self._bar.render(pct_v, bar_w), inner_w, "left"),
            self._row(b, self.theme.apply(
                "Files   : %s / %s" % (done_txt, total_txt), "secondary"),
                inner_w, "left"),
            self._row(b, "Current : " + _truncate(cur_txt, inner_w - 10),
                      inner_w, "left"),
            self._row(b, self.theme.apply("Speed   : " + speed_txt, "info"),
                      inner_w, "left"),
            self._row(b, self.theme.apply(
                "Elapsed : %s   Remaining: %s" % (elapsed_txt, eta_txt), "info"),
                inner_w, "left"),
            self._row(b, self.theme.apply("Status  : " + status_txt, status_role),
                      inner_w, "left"),
        ]
        top = self.theme.apply(b["tl"] + b["h"] * (w - 2) + b["tr"], "border")
        bottom = self.theme.apply(b["bl"] + b["h"] * (w - 2) + b["br"], "border")
        return "\n".join([top] + rows + [bottom])

    def progress_row(self, pct, width=34):
        """A single, un-boxed progress-bar row (▓▓░░ 62%). For callers that
        compose their own frame (the boot screen) instead of draw_progress."""
        return self._bar.render(pct, width)

    def draw_labeled_row(self, label, value, label_role="dim", value_role="text"):
        # Pad before colouring. Padding ANSI text counted escape bytes and
        # pushed the value column out of alignment on coloured themes.
        l = self.theme.apply(str(label).rstrip().ljust(14), label_role)
        v = self.theme.apply(str(value), value_role)
        return "  " + l + " :  " + v.rstrip()

    # ------------------------------------------------------------- internal
    def _resolve(self, content):
        if isinstance(content, str):
            items = content.split("\n")
        else:
            items = []
            for x in content:
                items.extend(safe_text(x).split("\n"))
        return [safe_text(x) for x in items]

    def _resolve_width(self, width):
        if width is None:
            width = terminal_width() - 4
        width = int(width or 80)
        # 90 keeps a box legible on wide screens. The old floor of 50 broke
        # 40-column Termux sessions: borders wrapped and rows left the box.
        hard_max = max(12, terminal_width() - 2)
        return max(12, min(width, 90, hard_max))

    def _gap(self, b, inner_w):
        """One blank content row under every title/top border. Central gap
        agent: menus, boxes, context, progress and sub-boxes all use it."""
        return self._row(b, "", inner_w, "left")

    def _row(self, b, inner, inner_w, align, color_role="border"):
        inner = self._align(inner, inner_w, align)
        if not b["v"]:
            if "\x1b[" in inner:
                return inner
            return self.theme.apply(b["v"] + " " + inner, color_role)
        if "\x1b[" in inner:
            return (self.theme.apply(b["v"] + " ", color_role)
                    + inner + " "
                    + self.theme.apply(b["v"], color_role))
        return self.theme.apply(b["v"] + " " + inner + " " + b["v"], color_role)

    def _divider(self, b, inner_w, color_role):
        return self.theme.apply(b["jt"] + b["h"] * inner_w + b["je"], color_role)

    def _align(self, inner, inner_w, align):
        inner = _truncate(safe_text(inner), inner_w)
        vis = visible_len(inner)
        gap = max(0, inner_w - vis)
        if align == "center":
            l = gap // 2
            r = gap - l
            return (" " * l) + inner + (" " * r)
        if align == "right":
            return (" " * gap) + inner
        return inner + (" " * gap)


def file_context_box(main, files=(), mode=None, target=None, output=None,
                     title=None, token=None, style=None, extra=(), limit=8,
                     width=None, theme=None):
    return (theme or BoxEngine()).draw_file_context(
        main, files, mode, target, output, title, token, style, extra,
        limit, width)


def box(content, style="heavy", title=None, subtitle=None, width=None,
        align="left", padding=1):
    return BoxEngine().draw_box(content, style, title, subtitle, width,
                                align, padding)