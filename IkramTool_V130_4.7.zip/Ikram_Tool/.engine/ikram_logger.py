"""IkramTool V130 — rotating local error journal.

All records live inside .engine/error.log so the tool root stays clean.
Every entry point is non-raising and never writes to stdout/stderr; a failure
to log must never change the outcome of the operation being logged.
"""
from __future__ import annotations

import datetime as _dt
import os
import threading
import traceback
from pathlib import Path

MAX_BYTES = 512 * 1024
BACKUP_COUNT = 2
MAX_LINES = 4000
LOG_DIR_NAME = ".engine"
LOG_FILE_NAME = "error.log"
_LOCK = threading.RLock()


def _log_path() -> Path:
    try:
        import paths
        root = Path(paths.ENGINE_DIR)
    except Exception:
        root = Path(__file__).resolve().parent
    if root.name != LOG_DIR_NAME:
        root = root / LOG_DIR_NAME
    return root / LOG_FILE_NAME


def log_path() -> str:
    try:
        return str(_log_path())
    except Exception:
        return ""


def get_log_path() -> str:
    return log_path()


def _stamp() -> str:
    try:
        return _dt.datetime.now().astimezone().isoformat(timespec="seconds")
    except Exception:
        return _dt.datetime.now().isoformat(timespec="seconds")


def _safe_text(value) -> str:
    try:
        return str(value).replace("\r", " ").replace("\n", " ")[:400]
    except Exception:
        return "<unprintable>"


def _rotate_if_needed(path: Path) -> None:
    try:
        if not path.is_file() or path.stat().st_size < MAX_BYTES:
            return
        for i in range(BACKUP_COUNT, 0, -1):
            src = path if i == 1 else Path(str(path) + ".%d" % (i - 1))
            dst = Path(str(path) + ".%d" % i)
            if src.exists():
                try:
                    src.replace(dst)
                except Exception:
                    pass
    except Exception:
        pass


def _append(level: str, message: str) -> None:
    try:
        path = _log_path()
        with _LOCK:
            path.parent.mkdir(parents=True, exist_ok=True)
            _rotate_if_needed(path)
            line = "%s %-5s %s\n" % (_stamp(), level, _safe_text(message))
            with open(path, "a", encoding="utf-8", errors="replace") as fh:
                fh.write(line)
    except Exception:
        pass


def recent(n=6) -> list:
    try:
        path = _log_path()
        if not path.is_file():
            return []
        with _LOCK:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return [ln for ln in lines[-max(1, min(int(n), MAX_LINES)):] if ln.strip()]
    except Exception:
        return []


def log_info(msg):
    _append("INFO", msg)


def log_warn(msg):
    _append("WARN", msg)


def log_debug(msg):
    _append("DEBUG", msg)


def log_error(msg, exc=None):
    text = _safe_text(msg)
    if exc is not None:
        text += " | %s: %s" % (type(exc).__name__, _safe_text(exc))
    _append("ERROR", text)


def log_exception(msg, exc):
    log_error(msg, exc)


def log_exc(where, exc):
    text = "%s | %s: %s" % (where, type(exc).__name__, _safe_text(exc))
    try:
        tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        if tb:
            text += " | " + _safe_text(tb)
    except Exception:
        pass
    _append("EXC", text)


def log_startup(extra=""):
    try:
        import paths
        ver = paths.read_version()
    except Exception:
        ver = "unknown"
    bits = ["startup", "version=%s" % ver, "pid=%d" % os.getpid()]
    if extra:
        bits.append(_safe_text(extra))
    _append("INFO", " ".join(bits))


if __name__ == "__main__":
    print("log file :", log_path() or "<unavailable>")
    log_info("self-test info")
    log_error("self-test error", exc=ValueError("self-test"))
    log_exc("self-test", RuntimeError("self-test"))
    log_startup("entry=ikram_logger")
    print("recent", len(recent(4)))
