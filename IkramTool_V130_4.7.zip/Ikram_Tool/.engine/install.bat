@echo off
rem ============================================================================
rem  Ikram Tool V130 - Windows installer
rem
rem  Layout produced (mirrors install.sh):
rem
rem      <tool>\
rem          .engine\      every runtime file + the bundled python314\
rem          DROP\         input  (pak / lua / inject / SaveGames)
rem          RESULT\       output
rem          ikram.cmd     launcher
rem
rem  The UI core is CPython 3.14 bytecode and the magic is version-exact:
rem  3.15 raises "bad magic number", 3.13 cannot parse the file at all. So no
rem  interpreter is accepted here unless it reports 3.14, which is what makes
rem  a "successful" install actually launch afterwards.
rem
rem  Usage: install.bat [--force] [--no-deps] [--python PATH] [--help]
rem ============================================================================
setlocal EnableExtensions

set "FORCE=0"
set "NO_DEPS=0"
set "PY_OVERRIDE="
set "PYCMD="
set "SCRIPT_VERSION=V130"

set "ENGINE=%~dp0"
if "%ENGINE:~-1%"=="\" set "ENGINE=%ENGINE:~0,-1%"
for %%I in ("%ENGINE%\..") do set "ROOT=%%~fI"

rem UTF-8 so the tool's box drawing and arrows survive the console.
chcp 65001 >nul 2>nul
for /F %%a in ('echo prompt $E^| cmd') do set "ESC=%%a"
set "C_BRAND=%ESC%[1;4;38;5;201m"
set "C_RESET=%ESC%[0m"

echo.
echo   ------------------------------------------------------------
echo    %C_BRAND%Ikram Tool %SCRIPT_VERSION%%C_RESET%  -  installer
echo    windows
echo   ------------------------------------------------------------

rem ---------------------------------------------------------------- args ----
:parse
if "%~1"=="" goto :parsed
set "ARG=%~1"
if /i "%ARG%"=="-h" goto :usage
if /i "%ARG%"=="--help" goto :usage
if /i "%ARG%"=="-f" goto :arg_force
if /i "%ARG%"=="--force" goto :arg_force
if /i "%ARG%"=="--no-deps" goto :arg_nodeps
if /i "%ARG%"=="--python" goto :arg_python
if /i "%ARG%"=="--python=" goto :die_python_value
if /i "%ARG:~0,9%"=="--python=" goto :arg_python_inline
echo   [x] unknown option: %ARG%
echo       try: install.bat --help
goto :fail

:arg_force
set "FORCE=1"
shift
goto :parse

:arg_nodeps
set "NO_DEPS=1"
shift
goto :parse

:arg_python
shift
if "%~1"=="" goto :die_python_value
set "PY_OVERRIDE=%~1"
shift
goto :parse

:arg_python_inline
set "PY_OVERRIDE=%ARG:~9%"
if "%PY_OVERRIDE%"=="" goto :die_python_value
shift
goto :parse

:usage
echo.
echo   Ikram Tool installer - Windows
echo.
echo   Usage:
echo     install.bat [OPTIONS]
echo.
echo   Options:
echo     -f, --force        reinstall python packages and rewrite launchers
echo         --no-deps      skip python packages and preflight
echo         --python PATH  use this interpreter - must be exactly 3.14
echo     -h, --help         show this help
echo.
echo   The runtime lives in .engine next to this script.
echo   DROP gets pak / lua / inject / SaveGames, RESULT gets the output.
echo.
exit /b 0

:die_python_value
echo   [x] --python needs a path to a CPython 3.14 executable
goto :fail

:parsed

rem ------------------------------------------------------------ python ----
echo.
echo   [1/6] python 3.14
if defined PY_OVERRIDE goto :py_override

set "BUNDLED=%ENGINE%\python314\python.exe"
if not exist "%BUNDLED%" goto :try_py314
"%BUNDLED%" -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :try_py314
set PYCMD="%BUNDLED%"
set "RELOC_PY=1"
goto :have_python

:try_py314
py -3.14 -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :try_python314
set "PYCMD=py -3.14"
goto :have_python

:try_python314
python3.14 -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :try_python
set "PYCMD=python3.14"
goto :have_python

:try_python
python -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :try_py
set "PYCMD=python"
goto :have_python

:try_py
py -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :no_python
set "PYCMD=py"
goto :have_python

:py_override
if /i "%PY_OVERRIDE%"=="python" goto :py_override_bare
if /i "%PY_OVERRIDE%"=="py" goto :py_override_bare
if not exist "%PY_OVERRIDE%" goto :no_python
"%PY_OVERRIDE%" -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :bad_python
set PYCMD="%PY_OVERRIDE%"
goto :have_python

:py_override_bare
"%PY_OVERRIDE%" -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,14) else 1)" >nul 2>nul
if errorlevel 1 goto :bad_python
set "PYCMD=%PY_OVERRIDE%"
goto :have_python

:have_python
%PYCMD% -c "import sys; print('  [ok] python   : ' + sys.executable + '  ' + str(sys.version_info[:3]))"
goto :stage

:no_python
echo   [x] no CPython 3.14 found.
echo.
echo       The UI core ships as 3.14 bytecode - 3.15 and older cannot load it.
echo.
echo       fix one of these, then run this script again:
echo         1. use the bundled interpreter shipped with the tool
echo              .engine\python314\python.exe
echo         2. install Python 3.14 from python.org and tick "Add to PATH"
echo         3. point at an existing 3.14
echo              install.bat --python "C:\path\to\python314\python.exe"
echo.
echo       paktool CLI only: python PakTool.py --help
goto :fail

:bad_python
%PYCMD% -c "import sys" >nul 2>nul
echo   [x] --python is not a CPython 3.14 interpreter: %PY_OVERRIDE%
echo       install.bat --python is version-locked, not a preference.
goto :fail

rem ----------------------------------------------------------- staging ----
:stage
echo   [2/6] runtime files
if not exist "%ENGINE%\ikram_patch.py" goto :die_no_runtime
if not exist "%ENGINE%\ikram.pyc" goto :die_no_runtime
if not exist "%ENGINE%\ikram_key.json" goto :die_no_runtime
echo   [ok] runtime in place - .engine
mkdir "%ROOT%\DROP\pak" 2>nul
mkdir "%ROOT%\DROP\lua" 2>nul
mkdir "%ROOT%\DROP\inject" 2>nul
mkdir "%ROOT%\DROP\SaveGames" 2>nul
mkdir "%ROOT%\RESULT" 2>nul
mkdir "%ROOT%\RESULT\extracted" 2>nul
mkdir "%ROOT%\RESULT\injected" 2>nul
mkdir "%ROOT%\RESULT\lua" 2>nul
mkdir "%ROOT%\RESULT\processed" 2>nul
mkdir "%ROOT%\RESULT\CostomPak" 2>nul
mkdir "%ROOT%\RESULT\Repacked" 2>nul
mkdir "%ROOT%\RESULT\SaveGames" 2>nul
if not exist "%ENGINE%\VERSION" echo V130>"%ENGINE%\VERSION"
echo   [ok] DROP / RESULT ready

rem --------------------------------------------------------- tool key ----
echo   [3/6] tool key file
if not exist "%ENGINE%\license_setup.py" goto :die_no_keyfile
%PYCMD% -X utf8 "%ENGINE%\license_setup.py"
if errorlevel 1 goto :die_keyfile
echo   [ok] tool key file ready

rem ------------------------------------------------------------- deps ----
echo   [4/6] python packages
if "%NO_DEPS%"=="1" goto :deps_skipped
%PYCMD% -m pip --version >nul 2>nul
if not errorlevel 1 goto :deps_pip_ok
%PYCMD% -m ensurepip --upgrade >nul 2>nul
%PYCMD% -m pip --version >nul 2>nul
if errorlevel 1 goto :deps_no_pip

:deps_pip_ok
set "PIPFLAGS=--upgrade --quiet --disable-pip-version-check"
if "%FORCE%"=="1" set "PIPFLAGS=--upgrade --force-reinstall --quiet --disable-pip-version-check"
echo   ...      rich  pycryptodome  lz4  zstandard  gmalg
%PYCMD% -m pip install %PIPFLAGS% rich pycryptodome lz4 zstandard gmalg
if errorlevel 1 goto :deps_failed
echo   [ok] python packages ready
goto :preflight

:deps_failed
echo   [!] package install failed - rerun with network access:
echo       %PYCMD% -m pip install rich pycryptodome lz4 zstandard gmalg
goto :preflight

:deps_no_pip
echo   [!] pip is unavailable in this interpreter. The tool needs:
echo       rich  pycryptodome  lz4  zstandard  gmalg
echo       fix: %PYCMD% -m ensurepip --upgrade
goto :preflight

:deps_skipped
echo   [!] skipped - dependency step disabled by --no-deps

rem -------------------------------------------------------- preflight ----
:preflight
echo   [5/6] preflight
if "%NO_DEPS%"=="1" goto :preflight_skipped
set "PFJSON=%TEMP%\ikram_preflight.json"
set "PFERR=%TEMP%\ikram_preflight.err"
%PYCMD% -X utf8 "%ENGINE%\preflight.py" --json >"%PFJSON%" 2>"%PFERR%"
if not exist "%PFJSON%" goto :pf_crashed
%PYCMD% -c "import json,sys; d=json.load(open(sys.argv[1],encoding='utf-8')); c=d['counts']; bad=[i['label'] for i in d['items'] if not i['ok'] and i['kind']!='tool']; opt=[i['label'] for i in d['items'] if not i['ok'] and i['kind']=='tool']; print('  [ok] ' + str(c['present']) + '/' + str(c['total']) + ' components ready'); print('       optional host tools missing: ' + (', '.join(opt) if opt else 'none')); [print('  [x] MISSING: ' + b) for b in bad]; sys.exit(1 if bad else 0)" "%PFJSON%"
if errorlevel 1 goto :pf_bad
goto :launchers

:preflight_skipped
echo   [!] skipped - dependency step disabled by --no-deps
goto :launchers

:pf_crashed
echo   [!] preflight produced no report:
type "%PFERR%" 2>nul
goto :launchers

:pf_bad
echo   [x] essentials missing - see the MISSING lines above
echo       bundled engines cover the Lua job, so host luac/luajit are optional.
goto :fail

rem -------------------------------------------------------- launchers ----
:launchers
echo   [6/6] launchers
>"%ROOT%\ikram.cmd" echo @echo off
>>"%ROOT%\ikram.cmd" echo rem Ikram Tool launcher - generated by install.bat
>>"%ROOT%\ikram.cmd" echo chcp 65001 ^>nul 2^>nul
>>"%ROOT%\ikram.cmd" echo set "PYTHONDONTWRITEBYTECODE=1"
>>"%ROOT%\ikram.cmd" echo cd /d "%%~dp0.engine"
if defined RELOC_PY (
  >>"%ROOT%\ikram.cmd" echo "%%~dp0.engine\python314\python.exe" -X utf8 "%%~dp0.engine\ikram_patch.py" %%*
) else (
  >>"%ROOT%\ikram.cmd" echo %PYCMD% -X utf8 "%%~dp0.engine\ikram_patch.py" %%*
)
>>"%ROOT%\ikram.cmd" echo exit /b %%ERRORLEVEL%%
>>"%ROOT%\ikram-paktool.cmd" echo @echo off
>>"%ROOT%\ikram-paktool.cmd" echo rem Ikram Tool paktool - generated by install.bat
>>"%ROOT%\ikram-paktool.cmd" echo chcp 65001 ^>nul 2^>nul
>>"%ROOT%\ikram-paktool.cmd" echo set "PYTHONDONTWRITEBYTECODE=1"
>>"%ROOT%\ikram-paktool.cmd" echo cd /d "%%~dp0.engine"
if defined RELOC_PY (
  >>"%ROOT%\ikram-paktool.cmd" echo "%%~dp0.engine\python314\python.exe" -X utf8 "%%~dp0.engine\PakTool.py" %%*
) else (
  >>"%ROOT%\ikram-paktool.cmd" echo %PYCMD% -X utf8 "%%~dp0.engine\PakTool.py" %%*
)
>>"%ROOT%\ikram-paktool.cmd" echo exit /b %%ERRORLEVEL%%
echo   [ok] launchers
echo   [ok] %ROOT%\ikram.cmd
echo   [ok] %ROOT%\ikram-paktool.cmd

echo.
echo   ------------------------------------------------------------
echo    installation complete
echo   ------------------------------------------------------------
echo    location : %ROOT%   - only DROP\ and RESULT\ in root
echo    runtime  : %ENGINE%   - all tool files
echo    launcher : %ROOT%\ikram.cmd
echo    paktool  : %ROOT%\ikram-paktool.cmd
echo.
echo    run UI   : ikram.cmd        or   .engine\run.bat
echo    paktool  : ikram-paktool.cmd --help
echo.
endlocal
exit /b 0

rem ----------------------------------------------------------- failures ----
:die_no_runtime
echo   [x] runtime incomplete - missing ikram_patch.py, ikram.pyc or ikram_key.json
echo       re-extract the tool archive so .engine\ is whole:
echo         %ENGINE%
goto :fail

:die_no_keyfile
echo   [x] Tool key file missing - license_setup.py is not in .engine
echo       re-extract the tool archive so .engine\ is whole:
echo         %ENGINE%
goto :fail

:die_keyfile
echo   [x] Tool key file invalid - ikram_key.json is missing or incomplete
goto :fail

:fail
echo.
pause
endlocal
exit /b 1
