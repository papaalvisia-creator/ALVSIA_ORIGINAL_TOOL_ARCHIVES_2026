# Install-Lua-Tools: bundled Lua distribution installer
# Paths come from this script's location (.engine/scripts -> .engine), never
# from the current directory or a hard-coded user profile.
param([switch]$Force)

$EngineDir = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$LuaBin    = Join-Path $EngineDir 'lua_bin'
$WinDir    = Join-Path $LuaBin 'windows'
$LinDir    = Join-Path $LuaBin 'linux'
$IsWindowsHost = ($env:OS -eq 'Windows_NT') -or `
    ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT)

# What the bundle actually ships: PE tools with plain names under
# lua_bin/windows, ELF tools renamed at the engine root (a few payloads put
# those ELF files under lua_bin/linux instead).  No fabricated luajit stubs.
$WinTools = @(
    @{ Name = 'luac.exe';      Sources = @('lua_bin/windows/luac.exe',      'luac_patched.exe') }
    @{ Name = 'lua.exe';       Sources = @('lua_bin/windows/lua.exe',       'lua_patched.exe') }
    @{ Name = 'unluac_rs.exe'; Sources = @('lua_bin/windows/unluac_rs.exe', 'unluac_rs.exe') }
    @{ Name = 'lua53.dll';     Sources = @('lua_bin/windows/lua53.dll',     'lua53.dll') }
)
$LinTools = @(
    @{ Name = 'luac_patched'; Sources = @('lua_bin/linux/luac_patched', 'luac_patched') }
    @{ Name = 'lua_patched';  Sources = @('lua_bin/linux/lua_patched',  'lua_patched') }
    @{ Name = 'unluac_rs';    Sources = @('lua_bin/linux/unluac_rs',    'unluac_rs') }
)

function Get-ProbeFlag([string]$Name) {
    if ($Name -like 'unluac_rs*') { return '--version' }
    if ($Name -eq 'lua53.dll')   { return '' }
    return '-v'
}

function Install-One([string]$Name, [string[]]$Sources, [string]$DestDir) {
    $dest = Join-Path $DestDir $Name
    $src  = $null
    foreach ($rel in $Sources) {
        $cand = Join-Path $EngineDir $rel
        if ((Test-Path -LiteralPath $cand -PathType Leaf) -and
            (Get-Item -LiteralPath $cand).Length -gt 0) {
            $src = $cand
            break
        }
    }
    if (-not $src) {
        Write-Host "ERROR: no bundled binary for '$Name' (looked in: $($Sources -join ', '))" -ForegroundColor Red
        return $false
    }

    # Never copy a file onto itself: an already-staged bundle is verified in place.
    if ([System.IO.Path]::GetFullPath($src) -ne [System.IO.Path]::GetFullPath($dest)) {
        if (-not (Test-Path -LiteralPath $DestDir -PathType Container)) {
            New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
        }
        try {
            Copy-Item -LiteralPath $src -Destination $dest -Force -ErrorAction Stop
        } catch {
            Write-Host "ERROR: cannot copy '$src' -> '$dest': $_" -ForegroundColor Red
            return $false
        }
        Write-Host "  copied $Name from $src"
    } else {
        Write-Host "  $Name already staged in place (no self-copy)"
    }

    if (-not (Test-Path -LiteralPath $dest -PathType Leaf)) {
        Write-Host "ERROR: '$dest' was not created" -ForegroundColor Red
        return $false
    }
    $len = (Get-Item -LiteralPath $dest).Length
    if ($len -le 0) {
        Write-Host "ERROR: '$dest' is empty" -ForegroundColor Red
        return $false
    }
    Write-Host ("OK {0}: {1} ({2} bytes)" -f $Name, $dest, $len)
    return $true
}

function Test-VersionProbe([string]$Bin, [string]$Flag) {
    try {
        $out = & $Bin $Flag 2>&1
        if ($LASTEXITCODE -ne 0) { throw "exit code $LASTEXITCODE" }
        $first = @($out)[0]
        if ($null -eq $first) { throw 'no version output' }
        Write-Host ("  version: {0}" -f ([string]$first).Trim())
        return $true
    } catch {
        Write-Host "ERROR: version probe failed for '$Bin $Flag': $_" -ForegroundColor Red
        return $false
    }
}

Write-Host "Installing bundled Lua distribution from $EngineDir..."
if ($Force) { Write-Host '  force reinstall requested' }

$failed = 0
foreach ($t in $WinTools) {
    if (-not (Install-One $t.Name $t.Sources $WinDir)) { $failed++; continue }
    $flag = Get-ProbeFlag $t.Name
    if (-not $flag) {
        Write-Host "  version probe skipped ($($t.Name) is a library, no version flag)"
        continue
    }
    if ($IsWindowsHost) {
        if (-not (Test-VersionProbe (Join-Path $WinDir $t.Name) $flag)) { $failed++ }
    } else {
        Write-Host "  version probe skipped ($($t.Name) is a Windows binary on this host)"
    }
}

foreach ($t in $LinTools) {
    if (-not (Install-One $t.Name $t.Sources $LinDir)) { $failed++; continue }
    $flag = Get-ProbeFlag $t.Name
    if ($IsWindowsHost) {
        Write-Host "  version probe skipped ($($t.Name) is a POSIX binary on this host)"
    } elseif (-not (Test-VersionProbe (Join-Path $LinDir $t.Name) $flag)) {
        $failed++
    }
}

if ($IsWindowsHost) {
    $env:PATH = "$WinDir;$env:PATH"
    Write-Host "Lua tools installed to PATH: $WinDir"
}

if ($failed -gt 0) {
    Write-Host "Lua tool installation FAILED ($failed issue(s))" -ForegroundColor Red
    exit 1
}
Write-Host 'Lua tool installation complete.'
