# Verify Lua tools available and functional.
# Paths come from this script's location (.engine/scripts -> .engine).
$EngineDir = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$LuaBin    = Join-Path $EngineDir 'lua_bin'
$WinDir    = Join-Path $LuaBin 'windows'
$LinDir    = Join-Path $LuaBin 'linux'
$IsWindowsHost = ($env:OS -eq 'Windows_NT') -or `
    ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT)

$WinTools = @(
    @{ Name = 'luac.exe';      Fallback = 'luac_patched.exe' }
    @{ Name = 'lua.exe';       Fallback = 'lua_patched.exe' }
    @{ Name = 'unluac_rs.exe'; Fallback = 'unluac_rs.exe' }
    @{ Name = 'lua53.dll';     Fallback = 'lua53.dll' }
)
$LinTools = @(
    @{ Name = 'luac_patched'; Fallback = 'luac_patched' }
    @{ Name = 'lua_patched';  Fallback = 'lua_patched' }
    @{ Name = 'unluac_rs';    Fallback = 'unluac_rs' }
)

function Get-ProbeFlag([string]$Name) {
    if ($Name -like 'unluac_rs*') { return '--version' }
    if ($Name -eq 'lua53.dll')   { return '' }
    return '-v'
}

function Test-One([string]$Label, [string]$Bin, [string]$Fallback, [bool]$Native) {
    if (-not (Test-Path -LiteralPath $Bin -PathType Leaf)) {
        Write-Host "MISSING $Label`: $Bin (bundle source: $Fallback)" -ForegroundColor Red
        return $false
    }
    $len = (Get-Item -LiteralPath $Bin).Length
    if ($len -le 0) {
        Write-Host "EMPTY $Label`: $Bin" -ForegroundColor Red
        return $false
    }
    $flag = Get-ProbeFlag (Split-Path -Leaf $Bin)
    if ($Native -and $flag) {
        try {
            $out = & $Bin $flag 2>&1
            if ($LASTEXITCODE -ne 0) { throw "exit code $LASTEXITCODE" }
            $first = @($out)[0]
            if ($null -eq $first) { throw 'no version output' }
            Write-Host ("OK {0}: {1} ({2} bytes, {3})" -f $Label, $Bin, $len, ([string]$first).Trim()) -ForegroundColor Green
            return $true
        } catch {
            Write-Host "BROKEN $Label`: $Bin ($flag failed: $_)" -ForegroundColor Red
            return $false
        }
    }
    if ((Split-Path -Leaf $Bin) -eq 'lua53.dll') {
        Write-Host ("OK {0} staged: {1} ({2} bytes; library, no version flag)" -f $Label, $Bin, $len) -ForegroundColor Yellow
    } else {
        Write-Host ("OK {0} staged: {1} ({2} bytes; version probe skipped: non-native binary)" -f $Label, $Bin, $len) -ForegroundColor Yellow
    }
    return $true
}

Write-Host '=== Lua Tool Verification ==='
Write-Host "engine: $EngineDir"

$failures = 0
foreach ($t in $LinTools) {
    $bin = Join-Path $LinDir $t.Name
    if (-not (Test-One "Linux $($t.Name)" $bin (Join-Path $EngineDir $t.Fallback) (-not $IsWindowsHost))) {
        $failures++
    }
}
foreach ($t in $WinTools) {
    $bin = Join-Path $WinDir $t.Name
    $native = $IsWindowsHost -and ($t.Name -ne 'lua53.dll')
    if (-not (Test-One "Windows $($t.Name)" $bin (Join-Path $EngineDir $t.Fallback) $native)) {
        $failures++
    }
}

Write-Host 'Lua tool verification completed.'
if ($failures -gt 0) {
    Write-Host "Lua tool verification FAILED ($failures issue(s))" -ForegroundColor Red
    exit 1
}
exit 0
