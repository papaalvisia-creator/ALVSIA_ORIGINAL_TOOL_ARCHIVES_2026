#!/bin/bash
# Lua Tool Installation Script for Linux/macOS
# Paths are resolved from this script (.engine/scripts -> .engine), never $PWD.
set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ENGINE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
LUA_BIN_DIR="$ENGINE_DIR/lua_bin"
LINUX_DIR="$LUA_BIN_DIR/linux"
WINDOWS_DIR="$LUA_BIN_DIR/windows"

case "$(uname -s 2>/dev/null || echo unknown)" in
    MINGW*|MSYS*|CYGWIN*) HOST=windows ;;
    *)                    HOST=posix ;;
esac

# Real bundle contents. Linux ELF tools ship renamed at the engine root (some
# payloads place them in lua_bin/linux); Windows PE tools ship in lua_bin/windows.
LINUX_TOOLS="luac_patched lua_patched unluac_rs"
WINDOWS_TOOLS="luac.exe lua.exe unluac_rs.exe lua53.dll"

fail() { echo "ERROR: $*" >&2; exit 1; }
size_of() { wc -c < "$1" | tr -d '[:space:]'; }
nonempty() { [ -f "$1" ] && [ -s "$1" ]; }

probe_flag() {
    case "$1" in
        unluac_rs|unluac_rs.exe) echo '--version' ;;
        lua53.dll)               echo '' ;;
        *)                       echo '-v' ;;
    esac
}

# Real copy only when source and destination differ; never fabricate a binary.
copy_or_verify() {
    local src="$1" dst="$2"
    if [ "$src" = "$dst" ]; then
        echo "  $dst already staged in place (no self-copy)"
        return 0
    fi
    mkdir -p "$(dirname "$dst")" || return 1
    cp -f "$src" "$dst" || return 1
    echo "  copied $src -> $dst"
    return 0
}

install_tool() {
    local name="$1" dst_dir="$2" fallback_dir="$3"
    local dst="$dst_dir/$name" src="" cand len
    for cand in "$dst" "$fallback_dir/$name"; do
        if nonempty "$cand"; then src="$cand"; break; fi
    done
    [ -n "$src" ] || fail "no bundled binary for '$name' (looked in $dst_dir and $fallback_dir)"
    copy_or_verify "$src" "$dst" || fail "cannot install '$name' from $src to $dst"
    [ -f "$dst" ] || fail "'$dst' was not created"
    [ -s "$dst" ] || fail "'$dst' is empty"
    len="$(size_of "$dst")"
    echo "OK $name: $dst ($len bytes)"
}

probe_tool() {
    local bin="$1" flag="$2" out rc
    [ -n "$flag" ] || return 0
    if [ ! -x "$bin" ]; then fail "'$bin' is not executable"; fi
    out="$("$bin" "$flag" 2>&1)"; rc=$?
    if [ "$rc" -eq 0 ]; then
        echo "  version: $(printf '%s\n' "$out" | head -n 1)"
    else
        fail "version probe failed for '$bin $flag' (rc=$rc): $(printf '%s\n' "$out" | head -n 1)"
    fi
}

echo "Installing bundled Lua tools from $ENGINE_DIR..."

for name in $LINUX_TOOLS; do
    install_tool "$name" "$LINUX_DIR" "$ENGINE_DIR"
    if [ "$HOST" = posix ]; then
        probe_tool "$LINUX_DIR/$name" "$(probe_flag "$name")"
    else
        echo "  version probe skipped ($name is a POSIX binary on this host)"
    fi
done

for name in $WINDOWS_TOOLS; do
    install_tool "$name" "$WINDOWS_DIR" "$ENGINE_DIR"
    if [ "$name" = "lua53.dll" ]; then
        echo "  version probe skipped ($name is a library, no version flag)"
    elif [ "$HOST" = windows ]; then
        probe_tool "$WINDOWS_DIR/$name" "$(probe_flag "$name")"
    else
        echo "  version probe skipped ($name is a Windows binary on this POSIX host)"
    fi
done

echo 'Lua tool installation complete.'
