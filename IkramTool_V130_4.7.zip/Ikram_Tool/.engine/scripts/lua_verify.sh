#!/bin/bash
# Verify Lua tools for Linux/macOS (and the staged Windows PE tools).
# Paths are resolved from this script (.engine/scripts -> .engine), never $PWD.
set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ENGINE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
LUA_BIN_DIR="$ENGINE_DIR/lua_bin"
LINUX_DIR="$LUA_BIN_DIR/linux"
WINDOWS_DIR="$LUA_BIN_DIR/windows"

case "$(uname -s 2>/dev/null || echo unknown)" in
    MINGW*|MSYS*|CYGWIN*) HOST=windows ;;
    *)                    HOST=posix ;;
esac

LINUX_TOOLS="luac_patched lua_patched unluac_rs"
WINDOWS_TOOLS="luac.exe lua.exe unluac_rs.exe lua53.dll"
failures=0

probe_flag() {
    case "$1" in
        unluac_rs|unluac_rs.exe) echo '--version' ;;
        lua53.dll)               echo '' ;;
        *)                       echo '-v' ;;
    esac
}

check_tool() {
    local label="$1" bin="$2" fallback="$3" native="$4"
    local flag len out rc
    if [ ! -f "$bin" ]; then
        echo "MISSING $label: $bin (bundle source: $fallback)"
        failures=$((failures + 1))
        return 1
    fi
    if [ ! -s "$bin" ]; then
        echo "EMPTY $label: $bin"
        failures=$((failures + 1))
        return 1
    fi
    len="$(wc -c < "$bin" | tr -d '[:space:]')"
    flag="$(probe_flag "${bin##*/}")"
    if [ "$native" -eq 1 ] && [ -n "$flag" ]; then
        if [ ! -x "$bin" ]; then
            echo "NOT EXECUTABLE $label: $bin"
            failures=$((failures + 1))
            return 1
        fi
        out="$("$bin" "$flag" 2>&1)"; rc=$?
        if [ "$rc" -ne 0 ]; then
            echo "BROKEN $label: $bin ($flag rc=$rc: $(printf '%s\n' "$out" | head -n 1))"
            failures=$((failures + 1))
            return 1
        fi
        echo "OK $label: $bin ($len bytes, $(printf '%s\n' "$out" | head -n 1))"
    elif [ "${bin##*/}" = "lua53.dll" ]; then
        echo "OK $label staged: $bin ($len bytes; library, no version flag)"
    else
        echo "OK $label staged: $bin ($len bytes; version probe skipped: non-native binary)"
    fi
    return 0
}

echo "=== Lua Tool Verification ==="
echo "engine: $ENGINE_DIR"

for name in $LINUX_TOOLS; do
    native=0; [ "$HOST" = posix ] && native=1
    check_tool "Linux $name" "$LINUX_DIR/$name" "$ENGINE_DIR/$name" "$native"
done

for name in $WINDOWS_TOOLS; do
    native=0; [ "$HOST" = windows ] && [ "$name" != "lua53.dll" ] && native=1
    check_tool "Windows $name" "$WINDOWS_DIR/$name" "$ENGINE_DIR/$name" "$native"
done

echo "Lua tool verification completed."
if [ "$failures" -ne 0 ]; then
    echo "Lua tool verification FAILED ($failures issue(s))" >&2
    exit 1
fi
exit 0
