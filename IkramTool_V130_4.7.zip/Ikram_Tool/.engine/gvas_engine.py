"""IkramTool — GVAS engine (Unreal Engine SaveGame reader/writer).

This module is the real thing: it parses the tagged-property tree that
PUBG Mobile / BGMI stores in ``.sav`` files and rebuilds it byte-for-byte.
It does NOT obfuscate, XOR, or fake anything — the file it reads and the
file it writes are the same Unreal ``GVAS`` container the game itself uses,
just exposed as editable JSON in between.

Container layout (little endian):

    "GVAS" magic (i32 0x53415647)
    SaveGameFileVersion        i32
    PackageFileVersion         i32 (+ UE5 i32 when version >= 3)
    EngineVersion major/minor/patch  u16 x3
    EngineVersion changelist   u32
    EngineVersion branch       FString
    CustomVersionFormat        i32 (3)
    CustomVersions             i32 count + count x (GUID(16) + i32)
    SaveGameClassName          FString
    <property block> ... terminated by the FString "None"
    <trailer>                  usually 4 zero bytes

Every property is:

    name   FString
    type   FString
    size   u64  (low 32 = value size, high 32 = array index)
    <type extras> + optional GUID + value

The tree is round-tripped through plain Python dicts so it can be dumped to
JSON (dump()/load()), edited by hand, and written back with write().

Hardening notes (audit pass):
  * every read is bounds-checked; corrupt/truncated blobs raise GvasError
    instead of struct.error / MemoryError / an unbounded loop;
  * counts (custom versions, arrays, maps, properties) and recursion depth are
    capped, so a hostile header cannot make the parser spin;
  * the original 8-byte property header ("size/index") is kept in ``_size``
    so an unedited Decrypt -> Encrypt is byte-for-byte identical;
  * repeated property names (legal in UE for array elements) are kept under a
    mangled key with ``_name`` holding the real name, instead of being silently
    dropped by the dict.
"""

import base64
import binascii
import hashlib
import io
import json
import struct

__all__ = [
    "GvasError", "GvasFile", "read_file", "write_file", "loads", "dumps",
    "sha256_bytes", "sha256_file", "is_gvas", "read_info",
]


class GvasError(Exception):
    """Raised for anything that is not a valid/complete GVAS file."""


# FString sign marks UTF-16: len < 0 means (len * 2) bytes of UTF-16-LE.
# FString length of 0 means the empty string.

# Defensive caps. Real PUBG/BGMI saves are far below these; they only stop a
# corrupt file from turning a 2-byte count into a multi-minute loop.
MAX_INPUT_BYTES = 512 * 1024 * 1024
MAX_STRING_BYTES = 64 * 1024 * 1024
MAX_PROPERTIES = 200000
MAX_CUSTOM_VERSIONS = 4096
MAX_ARRAY_ITEMS = 2000000
MAX_MAP_ITEMS = 2000000
MAX_DEPTH = 64
_DUP_MARK = "::dup"

_SCALAR_TYPES = {
    "IntProperty": ("i32", 4),
    "UInt16Property": ("u16", 2),
    "UInt32Property": ("u32", 4),
    "Int64Property": ("i64", 8),
    "FloatProperty": ("f32", 4),
    "DoubleProperty": ("f64", 8),
    "StrProperty": ("str", None),
    "NameProperty": ("str", None),
    "ObjectProperty": ("str", None),
}


# ------------------------------------------------------------------- helpers
def sha256_bytes(data) -> str:
    """SHA-256 hex of a bytes-like object (reporting helper)."""
    return hashlib.sha256(bytes(data)).hexdigest()


def sha256_file(path, limit=MAX_INPUT_BYTES) -> str:
    """SHA-256 of a file, streamed. Raises GvasError on unreadable input."""
    try:
        h = hashlib.sha256()
        left = int(limit)
        with open(path, "rb") as fh:
            while left > 0:
                chunk = fh.read(min(1024 * 1024, left))
                if not chunk:
                    break
                h.update(chunk)
                left -= len(chunk)
        return h.hexdigest()
    except (OSError, ValueError) as exc:
        raise GvasError("cannot hash %s: %s" % (path, exc))


def is_gvas(data) -> bool:
    """Cheap magic/version probe; never raises."""
    try:
        if len(data) < 8:
            return False
        return struct.unpack_from("<I", bytes(data), 0)[0] == 0x53415647 \
            and struct.unpack_from("<i", bytes(data), 4)[0] in (2, 3)
    except Exception:
        return False


# --------------------------------------------------------------------- reader
class _Reader:
    def __init__(self, data):
        self.b = data
        self.n = len(data)
        self.o = 0

    def need(self, k):
        if k < 0 or self.o + k > self.n:
            raise GvasError("unexpected end of file (want %d at %d/%d)"
                            % (k, self.o, self.n))

    def i32(self):
        self.need(4)
        v = struct.unpack_from("<i", self.b, self.o)[0]
        self.o += 4
        return v

    def u16(self):
        self.need(2)
        v = struct.unpack_from("<H", self.b, self.o)[0]
        self.o += 2
        return v

    def u32(self):
        self.need(4)
        v = struct.unpack_from("<I", self.b, self.o)[0]
        self.o += 4
        return v

    def u64(self):
        self.need(8)
        v = struct.unpack_from("<Q", self.b, self.o)[0]
        self.o += 8
        return v

    def i64(self):
        self.need(8)
        v = struct.unpack_from("<q", self.b, self.o)[0]
        self.o += 8
        return v

    def f32(self):
        self.need(4)
        v = struct.unpack_from("<f", self.b, self.o)[0]
        self.o += 4
        return v

    def f64(self):
        self.need(8)
        v = struct.unpack_from("<d", self.b, self.o)[0]
        self.o += 8
        return v

    def byte(self):
        self.need(1)
        v = self.b[self.o]
        self.o += 1
        return v

    def skip(self, k):
        self.need(k)
        self.o += k

    def guid_hex(self):
        self.need(16)
        h = self.b[self.o:self.o + 16].hex()
        self.o += 16
        return h

    def optional_guid(self):
        if self.byte():
            return self.guid_hex()
        return None

    def fstring(self):
        size = self.i32()
        if size == 0:
            return ""
        if size > 0:
            if size > MAX_STRING_BYTES:
                raise GvasError("string too large (%d bytes)" % size)
            self.need(size)
            raw = self.b[self.o:self.o + size - 1]
            self.o += size
            try:
                return raw.decode("ascii", "surrogateescape")
            except UnicodeDecodeError as exc:
                raise GvasError("bad ascii string: %s" % exc)
        count = -size
        if count > MAX_STRING_BYTES // 2:
            raise GvasError("wide string too large (%d chars)" % count)
        nbytes = count * 2
        self.need(nbytes)
        raw = self.b[self.o:self.o + nbytes - 2]
        self.o += nbytes
        try:
            return raw.decode("utf-16-le", "surrogatepass")
        except UnicodeDecodeError as exc:
            raise GvasError("bad utf16 string: %s" % exc)


# --------------------------------------------------------------------- writer
class _Writer:
    def __init__(self):
        self.b = bytearray()

    def raw(self, data):
        self.b += data

    def i32(self, v):
        self.b += struct.pack("<i", _as_int(v, "i32"))

    def u16(self, v):
        self.b += struct.pack("<H", _as_int(v, "u16"))

    def u32(self, v):
        self.b += struct.pack("<I", _as_int(v, "u32"))

    def u64(self, v):
        self.b += struct.pack("<Q", _as_int(v, "u64") & 0xFFFFFFFFFFFFFFFF)

    def i64(self, v):
        self.b += struct.pack("<q", _as_int(v, "i64"))

    def f32(self, v):
        if v is None:
            v = float("nan")
        self.b += struct.pack("<f", float(v))

    def f64(self, v):
        if v is None:
            v = float("nan")
        self.b += struct.pack("<d", float(v))

    def byte(self, v):
        self.b.append(_as_int(v, "byte") & 0xFF)

    def guid_hex(self, h):
        try:
            raw = bytes.fromhex(str(h))
        except (ValueError, TypeError) as exc:
            raise GvasError("bad GUID %r: %s" % (h, exc))
        if len(raw) != 16:
            raise GvasError("bad GUID length: %r" % (h,))
        self.b += raw

    def optional_guid(self, h):
        if h:
            self.byte(1)
            self.guid_hex(h)
        else:
            self.byte(0)

    def fstring(self, s):
        start = len(self.b)
        if s == "":
            self.i32(0)
            return 0
        if not isinstance(s, str):
            s = str(s)
        try:
            enc = s.encode("ascii")
            self.i32(len(enc) + 1)
            self.b += enc + b"\x00"
        except UnicodeEncodeError:
            enc = s.encode("utf-16-le", "surrogatepass")
            self.i32(-(len(enc) // 2 + 1))
            self.b += enc + b"\x00\x00"
        return len(self.b) - start

    def bytes(self):
        return bytes(self.b)


def _as_int(v, what):
    """Coerce JSON scalars to int, with a clear error instead of struct.error."""
    if isinstance(v, bool):
        return int(v)
    try:
        return int(v)
    except (TypeError, ValueError, OverflowError):
        raise GvasError("invalid %s value: %r" % (what, v))


def _check_depth(depth):
    if depth > MAX_DEPTH:
        raise GvasError("property nesting too deep (> %d)" % MAX_DEPTH)


# ----------------------------------------------------------------- main class
class GvasFile:
    def __init__(self):
        self.header = {}
        self.properties = {}
        self.trailer = b""

    # ----------------------------------------------------------- header read
    @staticmethod
    def _read_header(r):
        magic = r.i32()
        if magic != 0x53415647:
            raise GvasError("not a GVAS file (bad magic)")
        sgv = r.i32()
        if sgv not in (2, 3):
            raise GvasError("unsupported SaveGameFileVersion %d" % sgv)
        ue4 = r.i32()
        ue5 = r.i32() if sgv >= 3 else 0
        major = r.u16()
        minor = r.u16()
        patch = r.u16()
        changelist = r.u32()
        branch = r.fstring()
        cvf = r.i32()
        if cvf != 3:
            raise GvasError("unsupported CustomVersionFormat %d" % cvf)
        cnt = r.i32()
        if cnt < 0 or cnt > MAX_CUSTOM_VERSIONS:
            raise GvasError("bad custom-version count %d" % cnt)
        customs = []
        for _ in range(cnt):
            customs.append([r.guid_hex(), r.i32()])
        cls = r.fstring()
        return {
            "magic": "GVAS",
            "save_game_version": sgv,
            "package_file_version_ue4": ue4,
            "package_file_version_ue5": ue5,
            "engine_version": {
                "major": major, "minor": minor, "patch": patch,
                "changelist": changelist, "branch": branch,
            },
            "custom_version_format": cvf,
            "custom_versions": customs,
            "save_game_class": cls,
        }

    # ----------------------------------------------------------- header write
    @staticmethod
    def _write_header(w, h):
        if not isinstance(h, dict):
            raise GvasError("header must be an object")
        sgv = _as_int(h.get("save_game_version", 2), "SaveGameFileVersion")
        if sgv not in (2, 3):
            raise GvasError("unsupported SaveGameFileVersion %d" % sgv)
        w.i32(0x53415647)
        w.i32(sgv)
        w.i32(h.get("package_file_version_ue4", 0))
        if sgv >= 3:
            w.i32(h.get("package_file_version_ue5", 0))
        ev = h.get("engine_version", {})
        if not isinstance(ev, dict):
            raise GvasError("engine_version must be an object")
        w.u16(ev.get("major", 0))
        w.u16(ev.get("minor", 0))
        w.u16(ev.get("patch", 0))
        w.u32(ev.get("changelist", 0))
        w.fstring(ev.get("branch", ""))
        w.i32(_as_int(h.get("custom_version_format", 3), "CustomVersionFormat"))
        cvs = h.get("custom_versions", [])
        if not isinstance(cvs, list):
            raise GvasError("custom_versions must be a list")
        if len(cvs) > MAX_CUSTOM_VERSIONS:
            raise GvasError("too many custom versions")
        w.i32(len(cvs))
        for entry in cvs:
            if not isinstance(entry, (list, tuple)) or len(entry) != 2:
                raise GvasError("bad custom version entry: %r" % (entry,))
            w.guid_hex(entry[0])
            w.i32(entry[1])
        w.fstring(h.get("save_game_class", ""))

    # -------------------------------------------------------- value decoding
    def _read_scalar(self, r, typ, prop):
        kind, _sz = _SCALAR_TYPES[typ]
        prop["id"] = r.optional_guid()
        if kind == "str":
            prop["value"] = r.fstring()
        else:
            prop["value"] = getattr(r, kind)()

    def _read_value(self, r, typ, prop, depth=0):
        if typ in _SCALAR_TYPES:
            self._read_scalar(r, typ, prop)
        elif typ == "BoolProperty":
            prop["value"] = bool(r.byte())
            prop["id"] = r.optional_guid()
        elif typ == "EnumProperty":
            enum_type = r.fstring()
            prop["id"] = r.optional_guid()
            prop["value"] = {"type": enum_type, "value": r.fstring()}
        elif typ == "ByteProperty":
            enum_type = r.fstring()
            prop["id"] = r.optional_guid()
            if enum_type == "None":
                prop["value"] = {"type": "None", "value": r.byte()}
            else:
                prop["value"] = {"type": enum_type, "value": r.fstring()}
        elif typ == "StructProperty":
            prop["struct_type"] = r.fstring()
            prop["struct_id"] = r.guid_hex()
            prop["id"] = r.optional_guid()
            prop["value"] = self._read_struct_value(r, prop["struct_type"], depth + 1)
        elif typ == "ArrayProperty":
            array_type = r.fstring()
            prop["array_type"] = array_type
            prop["id"] = r.optional_guid()
            prop["value"] = self._read_array(r, array_type, depth + 1)
        elif typ == "MapProperty":
            prop["key_type"] = r.fstring()
            prop["value_type"] = r.fstring()
            prop["id"] = r.optional_guid()
            prop["_map_flags"] = r.u32()
            count = r.u32()
            if count > MAX_MAP_ITEMS:
                raise GvasError("map too large (%d items)" % count)
            key_struct_type = "Guid" if prop["key_type"] == "StructProperty" else None
            val_struct_type = "StructProperty" if prop["value_type"] == "StructProperty" else None
            prop["key_struct_type"] = key_struct_type
            prop["value_struct_type"] = val_struct_type
            items = []
            for _ in range(count):
                k = self._read_map_value(r, prop["key_type"], key_struct_type, depth + 1)
                v = self._read_map_value(r, prop["value_type"], val_struct_type, depth + 1)
                items.append({"key": k, "value": v})
            prop["value"] = items
        else:
            raise GvasError("unsupported property type %r" % typ)

    def _read_struct_value(self, r, struct_type, depth=0):
        _check_depth(depth)
        if struct_type == "Vector":
            return {"x": r.f64(), "y": r.f64(), "z": r.f64()}
        if struct_type == "Quat":
            return {"x": r.f64(), "y": r.f64(), "z": r.f64(), "w": r.f64()}
        if struct_type == "DateTime":
            return r.u64()
        if struct_type == "Guid":
            return r.guid_hex()
        if struct_type == "LinearColor":
            return {"r": r.f32(), "g": r.f32(), "b": r.f32(), "a": r.f32()}
        return self._read_props(r, depth + 1)

    def _read_array(self, r, array_type, depth=0):
        _check_depth(depth)
        count = r.u32()
        if count > MAX_ARRAY_ITEMS:
            raise GvasError("array too large (%d items)" % count)
        if array_type == "StructProperty":
            prop_name = r.fstring()
            prop_type = r.fstring()
            inner_size_word = r.u64()
            type_name = r.fstring()
            gid = r.guid_hex()
            r.byte()
            inner_start = r.o
            values = [self._read_struct_value(r, type_name, depth + 1)
                      for _ in range(count)]
            inner_bytes = r.b[inner_start:r.o]
            return {"prop_name": prop_name, "prop_type": prop_type,
                    "type_name": type_name, "id": gid, "values": values,
                    "_inner_size_word": inner_size_word,
                    "_inner_sha": sha256_bytes(inner_bytes)}
        if array_type == "ByteProperty":
            # Untagged byte arrays are a raw block.
            r.need(count)
            vals = list(r.b[r.o:r.o + count])
            r.o += count
            return {"values": vals}
        return {"values": [self._array_elem(r, array_type) for _ in range(count)]}

    def _array_elem(self, r, array_type):
        if array_type in _SCALAR_TYPES:
            kind, _sz = _SCALAR_TYPES[array_type]
            return getattr(r, kind)() if kind != "str" else r.fstring()
        if array_type == "BoolProperty":
            return bool(r.byte())
        raise GvasError("unsupported array element type %r" % array_type)

    def _read_map_value(self, r, type_name, struct_type, depth=0):
        _check_depth(depth)
        if type_name == "StructProperty":
            return self._read_struct_value(r, struct_type, depth + 1)
        if type_name in _SCALAR_TYPES:
            kind, _sz = _SCALAR_TYPES[type_name]
            return getattr(r, kind)() if kind != "str" else r.fstring()
        if type_name == "BoolProperty":
            return bool(r.byte())
        if type_name in ("EnumProperty", "NameProperty"):
            return r.fstring()
        raise GvasError("unsupported map value type %r" % type_name)

    def _read_props(self, r, depth=0):
        _check_depth(depth)
        props = {}
        while True:
            name = r.fstring()
            if name == "None":
                break
            if len(props) >= MAX_PROPERTIES:
                raise GvasError("too many properties (> %d)" % MAX_PROPERTIES)
            typ = r.fstring()
            pack = r.u64()
            prop = {"type": typ, "index": pack >> 32}
            # Keep the exact header low word so an unedited read->write cycle
            # reproduces the original bytes even for odd UE size conventions.
            # The payload hash tells write() whether the value is still the one
            # that produced that size; edited values must use the fresh size.
            prop["_size"] = pack & 0xFFFFFFFF
            payload_start = r.o
            self._read_value(r, typ, prop, depth + 1)
            prop["_payload_sha"] = sha256_bytes(r.b[payload_start:r.o])
            if name in props:
                # Legal in UE (array elements share a property name and differ
                # by index). A plain dict would silently discard all but the
                # last one, breaking the roundtrip. Keep the true name aside.
                key = name
                i = 1
                while key in props:
                    key = "%s%s%d" % (name, _DUP_MARK, i)
                    i += 1
                prop["_name"] = name
                props[key] = prop
            else:
                props[name] = prop
        return props

    # -------------------------------------------------------- value encoding
    def _write_scalar(self, w, typ, prop):
        kind, down = _SCALAR_TYPES[typ]
        w.optional_guid(prop.get("id"))
        if kind == "str":
            return w.fstring(prop.get("value", ""))
        getattr(w, kind)(prop.get("value", 0))
        return down

    def _write_value(self, w, typ, prop, depth=0):
        _check_depth(depth)
        if typ in _SCALAR_TYPES:
            return self._write_scalar(w, typ, prop)
        if typ == "BoolProperty":
            w.byte(1 if prop.get("value") else 0)
            w.optional_guid(prop.get("id"))
            return 1
        if typ in ("EnumProperty", "ByteProperty"):
            val = prop.get("value", {})
            if not isinstance(val, dict):
                raise GvasError("bad %s value: %r" % (typ, val))
            w.fstring(val.get("type", "None"))
            w.optional_guid(prop.get("id"))
            if typ == "ByteProperty" and val.get("type", "None") == "None":
                w.byte(_as_int(val.get("value", 0), "byte"))
                return 1
            return w.fstring(val.get("value", ""))
        if typ == "StructProperty":
            w.fstring(prop["struct_type"])
            w.guid_hex(prop["struct_id"])
            w.optional_guid(prop.get("id"))
            start = len(w.b)
            self._write_struct_value(w, prop["struct_type"], prop.get("value", {}),
                                     depth + 1)
            return len(w.b) - start
        if typ == "ArrayProperty":
            w.fstring(prop["array_type"])
            w.optional_guid(prop.get("id"))
            start = len(w.b)
            self._write_array(w, prop["array_type"], prop.get("value", {}),
                              depth + 1)
            return len(w.b) - start
        if typ == "MapProperty":
            w.fstring(prop["key_type"])
            w.fstring(prop["value_type"])
            w.optional_guid(prop.get("id"))
            start = len(w.b)
            vals = prop.get("value", [])
            if not isinstance(vals, list):
                raise GvasError("bad MapProperty value: %r" % (vals,))
            if len(vals) > MAX_MAP_ITEMS:
                raise GvasError("map too large")
            w.u32(_as_int(prop.get("_map_flags", 0), "map flags"))
            w.u32(len(vals))
            for entry in vals:
                if not isinstance(entry, dict) or "key" not in entry or "value" not in entry:
                    raise GvasError("bad map entry: %r" % (entry,))
                self._write_map_value(w, prop["key_type"],
                                      prop.get("key_struct_type"), entry["key"],
                                      depth + 1)
                self._write_map_value(w, prop["value_type"],
                                      prop.get("value_struct_type"), entry["value"],
                                      depth + 1)
            return len(w.b) - start
        raise GvasError("unsupported property type %r" % typ)

    def _write_struct_value(self, w, struct_type, value, depth=0):
        _check_depth(depth)
        if not isinstance(value, dict):
            value = {"value": value}
        if struct_type == "Vector":
            w.f64(value.get("x", 0)); w.f64(value.get("y", 0)); w.f64(value.get("z", 0))
        elif struct_type == "Quat":
            w.f64(value.get("x", 0)); w.f64(value.get("y", 0))
            w.f64(value.get("z", 0)); w.f64(value.get("w", 0))
        elif struct_type == "DateTime":
            w.u64(value.get("value", value) if isinstance(value, dict) else value)
        elif struct_type == "Guid":
            w.guid_hex(value.get("value", value) if isinstance(value, dict) else value)
        elif struct_type == "LinearColor":
            w.f32(value.get("r", 0)); w.f32(value.get("g", 0))
            w.f32(value.get("b", 0)); w.f32(value.get("a", 0))
        else:
            self._write_props(w, value, depth + 1)

    def _write_array(self, w, array_type, value, depth=0):
        _check_depth(depth)
        vals = value.get("values", []) if isinstance(value, dict) else value
        if not isinstance(vals, list):
            raise GvasError("bad array values: %r" % (vals,))
        if len(vals) > MAX_ARRAY_ITEMS:
            raise GvasError("array too large")
        w.u32(len(vals))
        if array_type == "StructProperty":
            w.fstring(value.get("prop_name", ""))
            w.fstring(value.get("prop_type", "StructProperty"))
            inner = _Writer()
            for v in vals:
                self._write_struct_value(inner, value.get("type_name", ""), v,
                                         depth + 1)
            data = inner.bytes()
            size_word = value.get("_inner_size_word") if isinstance(value, dict) else None
            inner_sha = value.get("_inner_sha") if isinstance(value, dict) else None
            if size_word is not None and inner_sha == sha256_bytes(data):
                w.u64(_as_int(size_word, "array inner size"))
            else:
                w.u64(len(data))
            w.fstring(value.get("type_name", ""))
            w.guid_hex(value.get("id", "0" * 32))
            w.byte(0)
            w.raw(data)
        elif array_type == "ByteProperty":
            for v in vals:
                w.byte(v)
        else:
            for v in vals:
                self._write_array_elem(w, array_type, v)

    def _write_array_elem(self, w, array_type, v):
        if array_type in _SCALAR_TYPES:
            kind, _d = _SCALAR_TYPES[array_type]
            if kind == "str":
                w.fstring(v)
            else:
                getattr(w, kind)(v)
            return
        if array_type == "BoolProperty":
            w.byte(1 if v else 0)
            return
        raise GvasError("unsupported array element type %r" % array_type)

    def _write_map_value(self, w, type_name, struct_type, v, depth=0):
        _check_depth(depth)
        if type_name == "StructProperty":
            self._write_struct_value(w, struct_type, v, depth + 1)
            return
        if type_name in _SCALAR_TYPES:
            kind, _d = _SCALAR_TYPES[type_name]
            if kind == "str":
                w.fstring(v)
            else:
                getattr(w, kind)(v)
            return
        if type_name == "BoolProperty":
            w.byte(1 if v else 0)
            return
        if type_name in ("EnumProperty", "NameProperty"):
            w.fstring(v)
            return
        raise GvasError("unsupported map value type %r" % type_name)

    def _write_props(self, w, props, depth=0):
        _check_depth(depth)
        if not isinstance(props, dict):
            raise GvasError("properties must be an object")
        if len(props) > MAX_PROPERTIES:
            raise GvasError("too many properties")
        for name, prop in props.items():
            if not isinstance(prop, dict):
                raise GvasError("bad property %r: %r" % (name, prop))
            w.fstring(prop.get("_name", name))
            w.fstring(prop["type"])
            inner = _Writer()
            computed = self._write_value(inner, prop["type"], prop, depth + 1)
            payload = inner.bytes()
            index = _as_int(prop.get("index", 0) or 0, "array index")
            # Prefer the preserved original size only while the serialized value
            # is unchanged. That keeps odd UE size conventions byte-exact, but
            # an edit that changes the payload length updates the header size.
            original_sha = prop.get("_payload_sha")
            keep_size = original_sha is not None and original_sha == sha256_bytes(payload)
            size = prop.get("_size", computed) if keep_size else computed
            w.u64(((index & 0xFFFFFFFF) << 32) | (_as_int(size, "size") & 0xFFFFFFFF))
            w.raw(payload)
        w.fstring("None")

    # ------------------------------------------------------------- public API
    @classmethod
    def read(cls, data):
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise GvasError("read() needs bytes")
        data = bytes(data)
        if len(data) > MAX_INPUT_BYTES:
            raise GvasError("file too large (%d bytes)" % len(data))
        if len(data) < 8:
            raise GvasError("file too short to be GVAS")
        r = _Reader(data)
        g = cls()
        try:
            g.header = g._read_header(r)
            g.properties = g._read_props(r)
            g.trailer = data[r.o:]
        except GvasError:
            raise
        except (struct.error, ValueError, IndexError, RecursionError) as exc:
            raise GvasError("malformed GVAS: %s" % exc)
        return g

    def write(self):
        w = _Writer()
        try:
            self._write_header(w, self.header)
            self._write_props(w, self.properties)
            trailer = self.trailer
            if isinstance(trailer, str):
                try:
                    trailer = base64.b64decode(trailer, validate=True)
                except (binascii.Error, ValueError) as exc:
                    raise GvasError("bad trailer: %s" % exc)
            w.raw(bytes(trailer))
        except GvasError:
            raise
        except (struct.error, ValueError, TypeError, KeyError,
                OverflowError, RecursionError) as exc:
            raise GvasError("cannot compile GVAS: %s" % exc)
        return w.bytes()

    def dump(self):
        return {
            "header": self.header,
            "properties": self.properties,
            "trailer": base64.b64encode(self.trailer).decode("ascii"),
        }

    @classmethod
    def load(cls, doc):
        if not isinstance(doc, dict):
            raise GvasError("source must be a JSON object")
        g = cls()
        g.header = doc["header"]
        g.properties = doc["properties"]
        raw = doc.get("trailer", "")
        try:
            g.trailer = base64.b64decode(raw, validate=True) if raw else b""
        except (binascii.Error, ValueError, TypeError) as exc:
            raise GvasError("bad trailer base64: %s" % exc)
        return g

    # ------------------------------------------------------- reporting helpers
    def iter_properties(self):
        """Yield (real_name, prop) — resolves the duplicate-name mangling."""
        for key, prop in self.properties.items():
            yield prop.get("_name", key), prop

    def summary(self):
        """Small, JSON-friendly report (counts + size + sha256)."""
        data = self.write()
        return {
            "properties": len(self.properties),
            "bytes": len(data),
            "sha256": sha256_bytes(data),
            "save_game_class": str(self.header.get("save_game_class", "")),
            "save_game_version": self.header.get("save_game_version"),
        }

    def validate(self):
        """Round-trip check: re-read compiled bytes, return True on match."""
        return GvasFile.read(self.write()).dump() == self.dump()


# ------------------------------------------------------------------ helpers
def read_file(path, max_bytes=MAX_INPUT_BYTES):
    try:
        with open(path, "rb") as fh:
            data = fh.read(max_bytes + 1)
    except OSError as exc:
        raise GvasError("cannot read %s: %s" % (path, exc))
    if len(data) > max_bytes:
        raise GvasError("file too large: %s" % path)
    return GvasFile.read(data)


def write_file(path, gvas):
    data = gvas.write() if isinstance(gvas, GvasFile) else GvasFile.load(gvas).write()
    with open(path, "wb") as fh:
        fh.write(data)
    return path


def read_info(path, max_bytes=MAX_INPUT_BYTES):
    """Non-raising report dict for a .sav/.gvas path (sha, size, validity)."""
    info = {"path": str(path), "name": str(path.name if hasattr(path, "name") else path),
            "bytes": 0, "sha256": "", "valid": False, "error": ""}
    try:
        info["bytes"] = int(path.stat().st_size)
    except Exception:
        pass
    try:
        info["sha256"] = sha256_file(path, limit=max_bytes)
        g = read_file(path, max_bytes=max_bytes)
        info["valid"] = True
        info["properties"] = len(g.properties)
        info.update(g.summary())
    except Exception as exc:
        info["error"] = str(exc)
    return info


def dumps(gvas):
    return json.dumps(gvas.dump(), indent=2, ensure_ascii=True)


def loads(text):
    try:
        doc = json.loads(text)
    except json.JSONDecodeError as exc:
        raise GvasError("invalid JSON: %s" % exc)
    return GvasFile.load(doc)
