import hashlib
import importlib.util
import inspect
import json
import ntpath
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

_TOOL_DIR = Path(__file__).resolve().parent
if str(_TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(_TOOL_DIR))

# Distinct non-user answers used by the boxed prompt layer. Strings such as
# "0" already mean cancel; EOF needs its own value so it cannot silently become
# "auto first" and write a pak without consent.
_EOF_CHOICE = object()
_INJECT_SKIP = object()

from theme_engine import glyph, safe_text


def _enable_windows_vt():
    """Turn on ANSI escape processing in the Windows console.

    Modern Windows 10/11 ships the VT processor but cmd.exe/PowerShell hosts
    start with it off, so every box-drawing glyph and colour code the UI emits
    comes out as literal "←[36m" garbage. ENABLE_VIRTUAL_TERMINAL_PROCESSING
    (0x0004) fixes stdout and stderr. Best effort only: a redirected console,
    an old build, or a restricted token makes this raise, and the UI already
    degrades to plain text when colour is unsupported.
    """
    try:
        import ctypes

        _k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        _k32.GetStdHandle.restype = ctypes.c_void_p
        _k32.GetConsoleMode.argtypes = [ctypes.c_void_p,
                                        ctypes.POINTER(ctypes.c_uint32)]
        _k32.SetConsoleMode.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
        for _hid in (-11, -12):          # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            _h = _k32.GetStdHandle(_hid)
            _mode = ctypes.c_uint32(0)
            if _h in (None, 0) or _h == ctypes.c_void_p(-1).value:
                continue
            if not _k32.GetConsoleMode(_h, ctypes.byref(_mode)):
                continue
            if not (_mode.value & 0x0004):
                _k32.SetConsoleMode(_h, _mode.value | 0x0004)
    except Exception:
        pass


if sys.platform == "win32":
    _enable_windows_vt()

# The core ships as 3.14 bytecode (ikram.pyc). On a Python whose bytecode
# magic differs (e.g. a 3.13 distro python), exec_module raises a bare
# "bad magic number" ImportError. Load it directly when possible, fall back to
# ikram.py source if present, and otherwise stop with an actionable message
# instead of a traceback. Only this is version-locked; the rest of the tool is
# plain .py and runs on any 3.x.
_CORE_PY = (3, 14)


def _core_load_error(detail):
    cur = "%d.%d.%d" % sys.version_info[:3]
    line = "=" * 60
    sys.stderr.write(
        "\n%s\n"
        "  Ikram Tool: cannot load the core (ikram.pyc)\n"
        "%s\n"
        "  required python : %d.%d  (core is shipped as %d.%d bytecode)\n"
        "  running python  : %s   (%s)\n"
        "\n"
        "  fix:\n"
        "    - windows : use the bundled interpreter\n"
        "                .engine\\python314\\python.exe .engine\\ikram_patch.py\n"
        "    - termux  : pkg install python   (needs 3.%d)\n"
        "    - linux   : run with python3.%d\n"
        "\n"
        "  this message is only about the interpreter version or a corrupt\n"
        "  ikram.pyc. A missing third-party module is reported separately.\n"
        "%s\n\n"
        % (line, line, _CORE_PY[0], _CORE_PY[1], _CORE_PY[0], _CORE_PY[1],
           cur, sys.executable or "?", _CORE_PY[1], _CORE_PY[1], line)
    )
    if detail:
        sys.stderr.write("  detail: %s\n\n" % detail)
    raise SystemExit(1)


# import name -> pip distribution. `sm4_custom` and the bundled engines are
# part of the payload, so a missing one means the install is incomplete, not
# that pip is needed.
_DIST_NAME = {
    "Crypto": "pycryptodome",
    "Cryptodome": "pycryptodome",
    "zstandard": "zstandard",
    "lz4": "lz4",
    "gmalg": "gmalg",
    "rich": "rich",
    "univ": None,
    "mega_lua": None,
    "sm4_custom": None,
}


def _missing_dep_error(mod_name, detail):
    """Report a missing import by name instead of blaming the python version.

    The old single failure path printed "cannot load the core / required python
    3.14" for every ImportError, so an install missing `rich` sent the user off
    to change interpreters when one `pip install` was the whole fix.
    """
    dist = _DIST_NAME.get(mod_name, mod_name)
    line = "=" * 60
    sys.stderr.write(
        "\n%s\n"
        "  Ikram Tool: missing python module %r\n"
        "%s\n"
        "  the core is present and the interpreter version is fine - one\n"
        "  dependency is absent from this python environment.\n"
        "\n"
        "  fix:\n"
        % (line, mod_name, line)
    )
    if dist:
        sys.stderr.write(
            "    - windows : .engine\\python314\\python.exe -m pip install %s\n"
            "    - termux  : python -m pip install %s\n"
            "    - linux   : python3 -m pip install %s\n"
            % (dist, dist, dist)
        )
    else:
        sys.stderr.write(
            "    %r ships with the tool, so this is an incomplete install.\n"
            "    re-extract the tool archive (or reinstall) so .engine/ is whole.\n"
            % mod_name
        )
    sys.stderr.write("%s\n\n" % line)
    if detail:
        sys.stderr.write("  detail: %s\n\n" % detail)
    raise SystemExit(1)


def _load_core():
    errors = []
    missing_dep = None
    version_locked = False
    for name in ("ikram.pyc", "ikram.py"):
        path = _TOOL_DIR / name
        if not path.exists():
            continue
        try:
            spec = importlib.util.spec_from_file_location("ikram", path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
        except ImportError as exc:
            txt = str(exc)
            if "bad magic number" in txt or "invalid pyc" in txt:
                version_locked = True
            else:
                nm = getattr(exc, "name", None)
                if nm and nm != "ikram":
                    missing_dep = nm
            errors.append("%s: %s" % (name, exc))
        except Exception as exc:  # noqa: BLE001 - surface any core import failure
            errors.append("%s: %r" % (name, exc))
    detail = "; ".join(errors)
    if missing_dep and not version_locked:
        _missing_dep_error(missing_dep, detail)
    _core_load_error(detail)



ikram = _load_core()


def _install_console_safety():
    """Downgrade unsafe glyphs before any Rich panel parses the text.

    The compiled core still stores Unicode check marks in a few panel titles.
    Sanitizing at the boundary keeps cp936/GBK sessions from dying with
    UnicodeEncodeError without changing the shipped byte contracts.
    """
    print_fn = getattr(getattr(ikram, "console", None), "print", None)
    if callable(print_fn):
        def _clean_renderable(obj):
            if isinstance(obj, str):
                return safe_text(obj)
            for attr in ("renderable", "title", "subtitle"):
                value = getattr(obj, attr, None)
                if isinstance(value, str):
                    try:
                        setattr(obj, attr, safe_text(value))
                    except Exception:
                        pass
            return obj

        def _safe_print(*args, **kwargs):
            clean = tuple(_clean_renderable(a) for a in args)
            clean_kw = {
                k: safe_text(v) if isinstance(v, str) else v
                for k, v in kwargs.items()
            }
            return print_fn(*clean, **clean_kw)
        ikram.console.print = _safe_print

    panel_fn = getattr(ikram, "panel", None)
    if callable(panel_fn):
        def _safe_panel(*args, **kwargs):
            clean_args = tuple(safe_text(a) if isinstance(a, str) else a
                               for a in args)
            clean_kwargs = {
                k: safe_text(v) if isinstance(v, str) else v
                for k, v in kwargs.items()
            }
            return panel_fn(*clean_args, **clean_kwargs)
        ikram.panel = _safe_panel

    for name in ("show_success", "show_error", "show_info"):
        fn = getattr(ikram, name, None)
        if not callable(fn):
            continue

        def _make_safe(fn):
            def _safe_show(msg, *args, **kwargs):
                return fn(safe_text(msg) if isinstance(msg, str) else msg,
                          *args, **kwargs)
            return _safe_show

        setattr(ikram, name, _make_safe(fn))


_install_console_safety()

import engines as _engines
import assetprocs as _assets
import inject_diagnosis as _inject_diag

# The compiled PAK Inject wizard writes through `ikram.pakmod.PakWriter`, a
# SEPARATE pak.pyc module object from the one engines.pakmod() patches. Left
# alone, wizard writes use the old writer and emit cm=1/cbs=65536 on added
# files instead of the corpus convention (cm=6/cbs=payload_size). Bind the
# byte-correct writer onto the wizard's module too.
_engines._install_unk2_fix(ikram.pakmod)

# ---- Phase-1 decrypt fix: the shipped pakcrypto froze SM4_SECRET_NEW at 19
# of the game's 25 entries. derive_sm4_key indexes (method-31) % len, so
# methods 50..55 wrapped onto the wrong secret and read_entry silently
# returned garbage instead of failing (method 55 -> index 5 instead of 24).
# Extend to the full 25-entry table; the list mutation reaches every alias
# (pak.pyc holds one as `pc`) and the derive cache is cleared so no
# pre-patch key can survive.
import pakcrypto as _pakcrypto
_REF_TAIL = (
    "wD2rP3lP9xF4mE1eC5jS",
    "rG0lR2rZ5vM6mW5lM1rR",
    "fO3kW1fE6eD0pU1kY7xK",
    "nE1jQ6qK5tW7rM8iD5vV",
    "cR0hW3gJ7cA1fJ9uR0kV",
    "iK3bV6wA7jP8aN8iI9nP",
)
_missing = 25 - len(_pakcrypto.SM4_SECRET_NEW)
if _missing > 0:
    _pakcrypto.SM4_SECRET_NEW.extend(_REF_TAIL[-_missing:])
    for _fn_name in ("_derive_sm4_key_cached", "derive_sm4_key"):
        _fn = getattr(_pakcrypto, _fn_name, None)
        if hasattr(_fn, "cache_clear"):
            _fn.cache_clear()
    del _fn, _fn_name
    del _pakcrypto

# ---- SM4 crypto lib-poison + flag fix (V130 em=50 blocker):
# sm4_custom's bootstrap compiles a tiny native .so via subprocess (no compiler
# on this host) -> raises -> caches _lib=False -> later crypto calls hit
# `lib.sm4_ecb` on a bool -> "'bool' object has no attribute 'sm4_ecb'".
# The pure-python fallback then re-reads the module-level `encrypt` flag, which
# is absent -> NameError -> poisons _lib=False -> crypto calls die.
# Fix lives in OUR layer (ikram_patch): rebind sm4_custom.encrypt_ecb /
# decrypt_ecb to wrappers that pin the flag (_lib=None first) and delegate.
import sm4_custom as _sm4c
import pakcrypto as _pakcrypto2

_sm4_enc0 = _sm4c.encrypt_ecb
_sm4_dec0 = _sm4c.decrypt_ecb

# Bind the module and the original callables as default arguments so the
# wrappers keep working after the names below are deleted from the module
# namespace (a bare closure over a deleted global raised NameError and made
# every SM4 decrypt fail).
def _ikram_sm4_encrypt(*_a, _mod=_sm4c, _orig=_sm4_enc0, **_k):
    try:
        setattr(_mod, "encrypt", True)
        setattr(_mod, "_lib", None)
    except Exception:
        pass
    return _orig(*_a, **_k)

def _ikram_sm4_decrypt(*_a, _mod=_sm4c, _orig=_sm4_dec0, **_k):
    try:
        setattr(_mod, "encrypt", False)
        setattr(_mod, "_lib", None)
    except Exception:
        pass
    return _orig(*_a, **_k)

_sm4c.encrypt_ecb = _ikram_sm4_encrypt
_sm4c.decrypt_ecb = _ikram_sm4_decrypt
_pakcrypto2.encrypt_ecb = _ikram_sm4_encrypt
_pakcrypto2.decrypt_ecb = _ikram_sm4_decrypt
del _sm4c, _pakcrypto2, _sm4_enc0, _sm4_dec0

# ---- real DROP/RESULT override (installed layout: engine files live directly
# in ~/Ikram_Tool, so DROP/RESULT are its uppercase sibling folders. The
# compiled module points at its own __file__ dir, which must NEVER hold data.
# Legacy .engine installs are migrated by install.sh before this runs.)
import paths as _paths

# Error log. Hard import on purpose: ikram_logger ships in this directory
# and its own entry points are non-raising by construction, so a missing
# logger is a broken install that must fail loudly at import -- not a
# silent no-op that would swallow every record of what went wrong.
import ikram_logger
for _name, _val in (
    ("DROP", _paths.DROP_DIR),
    ("DROP_PAK", _paths.DROP_PAK),
    ("DROP_LUA", _paths.DROP_LUA),
    ("DROP_INJ", _paths.DROP_INJ),
    ("DROP_SAVEGAMES", _paths.DROP_SAVEGAMES),
    ("RESULT", _paths.RESULT_DIR),
):
    setattr(ikram, _name, _val)

for _d in (
    ikram.DROP,
    ikram.DROP_INJ,
    ikram.DROP_LUA,
    ikram.DROP_PAK,
    ikram.DROP_SAVEGAMES,
    ikram.RESULT,
):
      _d.mkdir(parents=True, exist_ok=True)
for _sub in ("injected", "extracted", "lua", "processed", "CostomPak",
             "Repacked", "SaveGames"):
    (ikram.RESULT / _sub).mkdir(parents=True, exist_ok=True)


def _silence_owner_handoff():
    """Stop every error path from telling the user to send the file to an owner.

    contact_owner() is compiled into ikram.pyc and reached by six different
    error paths -- _unsupported_pak, report_error, report_unluac_error,
    pak_inject, lua_compile_path and lua_decompile_path. Each of those called it
    to print an external-contact line, so a failed Lua compile or any raised
    exception still ended with the user being told to hand the file over.

    It cannot be edited at the source level: there is no source for it, only
    Python 3.14 bytecode, and the decompilers that exist do not read 3.14. Every
    one of those call sites loads the name with LOAD_GLOBAL, which is a plain
    namespace lookup performed when the call happens. Rebinding the attribute on
    the module therefore intercepts all six at once, with no bytecode surgery
    and no risk to the menus, the key gate or the update-free startup path.

    The user still gets the real error: every caller prints its own message
    first, and ikram_logger already writes the full traceback to the local
    error log. This removes only the hand-off instruction.
    """
    ikram.contact_owner = lambda *args, **kwargs: None


_silence_owner_handoff()


def _purge_stray_engine_data_folders():
    """ikram.pyc's own module-level code builds DROP/RESULT from its own
    __file__ dir, so the exec_module() above creates Ikram_Tool/.engine/DROP
    and .engine/RESULT *before* the override above can redirect them. Those two
    folders stay empty forever once the override is in place - every real read
    and write goes to the install root - but leaving them behind ships the
    tool with five folders instead of the three it promises.

    Only runs in the .engine layout: in the dev tree the tool dir IS the data
    dir, so these paths are the real ones and must never be touched. Anything
    still holding a file is left alone as well - that is user data, and
    install.sh is what migrates it.
    """
    if _TOOL_DIR.name != ".engine":
        return
    for name in ("DROP", "RESULT"):
        stray = _TOOL_DIR / name
        if stray.is_symlink() or not stray.is_dir():
            continue
        if any(p.is_file() or p.is_symlink() for p in stray.rglob("*")):
            ikram_logger.log("[!] %s still holds files - left in place." % stray)
            continue
        shutil.rmtree(stray, ignore_errors=True)


_purge_stray_engine_data_folders()



def _legacy_repacked_dir():
    """The lowercase RESULT/repacked/ twin - but only when it is genuinely a
    DIFFERENT directory from RESULT/Repacked/.

    Windows and macOS are case-insensitive: 'repacked' and 'Repacked' are the
    same folder there. Treating lowercase 'repacked' as a legacy leftover on
    those platforms deleted the repack that had just been written, and because
    the purge also runs at import time, every launch wiped RESULT/Repacked
    before the user could open it. Measured on Windows 11: Repack reported
    "5 files repacked", printed the output path, and RESULT/ was left with no
    Repacked folder at all.

    Returns None when the two names collapse onto one directory.
    """
    good = ikram.RESULT / "Repacked"
    legacy = ikram.RESULT / "repacked"
    try:
        if not legacy.is_dir():
            return None
        # Path.__eq__ is case-insensitive on WindowsPath and case-sensitive on
        # PosixPath, so this is exactly the platform question being asked.
        # resolve() also folds symlinks and case-variant spellings.
        if legacy.resolve() == good.resolve():
            return None
    except OSError as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._legacy_repacked_dir:96", _ikram_exc)
        return None
    return legacy


def _purge_legacy_repacked_folders():
    """Double-repack bug, folder side: older releases + the stale one-liner
    install.sh created the LOWERCASE RESULT/repacked/ twin (compiled engine
    era wrote RESULT+'repacked'). Android's case-sensitive FS then keeps
    BOTH 'Repacked' and 'repacked' forever -> "Result/ me 2 folders". Remove
    every leftover file under the legacy twin, then the empty folder.

    Never runs on a case-insensitive filesystem - see _legacy_repacked_dir()."""
    legacy = _legacy_repacked_dir()
    if legacy is None:
        return
    try:
        for p in list(legacy.iterdir()):
            if p.is_file():
                p.unlink(missing_ok=True)
            elif p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
        legacy.rmdir()
    except OSError as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._purge_legacy_repacked_folders:96", _ikram_exc)
        pass


_purge_legacy_repacked_folders()

# ENTER (nothing typed) in Custom Pak -> full skeleton (all folders + all
# file names, zero-byte bodies). Sentinel returned by _pick_folders.
_SKELETON = "\x00_COSTOM_SKELETON_"

# CustomPak plan bounds. The full original path list is painted in one box;
# these only bound how many paths/files the operator may choose.
_MAX_CUSTOM_PATHS = 500
_MAX_CUSTOM_FILES = 5000

# ---- default Unreal Engine AES key for UE4 paks ---------------------------
# The user's real UE4 AES key. Auto-applied to UE4-standard paks across
# UNPACK / REPACK / INJECT (Ue4Pak.aes_key drives BOTH extract and repack).
# A blank AES key input now means "use this default" instead of "no key".
# Publg/tencent paks are NOT affected (their own SM4/SIMPLE crypto needs no
# key and runs through the `pak` module, not Ue4Pak). If you get a *different*
# pak set with its own key, just change this hex to that key.
DEFAULT_UE4_AES_KEY_HEX = (
    "8A75AFDF1C74AB55B79DC1DD4ABE4B01360A059D77F243EF4EFADA41A59D71A0"
)


def _ue4_key_bytes(hex_str=None):
    """Hex string (optionally 0x/- prefixed) -> AES-128/192/256 key bytes."""
    h = (hex_str or DEFAULT_UE4_AES_KEY_HEX).strip()
    h = h.replace("0x", "").replace("0X", "").replace("-", "").replace(" ", "")
    try:
        b = bytes.fromhex(h)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._ue4_key_bytes:125", _ikram_exc)
        return None
    return b if len(b) in (16, 24, 32) else None


def _patch_ue4_default_key():
    """Make Ue4Pak use DEFAULT_UE4_AES_KEY when no aes_key is passed.

    Covers UNPACK, REPACK and INJECT at a single point because all three build
    Ue4Pak and Ue4Pak.aes_key drives both extract (read_encoded_entry) and
    repack (write_entry). The key is only ever applied to *encrypted* entries
    / encrypted index, so an edited or un-encrypted ue4 pak is untouched and
    the tencent (PUBG) path is untouched -> nothing breaks.
    """
    base = ikram.ue4mod.Ue4Pak
    if getattr(base, "_ikram_default_key_wrapped", False):
        return

    class _DefaultKeyUe4Pak(base):
        def __init__(self, file_path, aes_key=None):
            if not aes_key:
                aes_key = _ue4_key_bytes(DEFAULT_UE4_AES_KEY_HEX)
            super().__init__(file_path, aes_key)

    _DefaultKeyUe4Pak._ikram_default_key_wrapped = True
    ikram.ue4mod.Ue4Pak = _DefaultKeyUe4Pak
    # also expose the wrapper under the same module name for any direct use
    ikram.ue4mod.Ue4Pak._ikram_original = base


_patch_ue4_default_key()


# Set when _pak_problem_box() has already told the user, in plain words, that a
# specific file is not a supported pak. The batch summary checks it so one bad
# file does not produce three separate complaints: the box, a per-file info
# line, and a closing "no files were extracted" error that restates the same
# thing. The box alone is enough.
_PAK_BOX_SHOWN = False

# Repeated at the top of every live file box. Long runs scroll the original
# pick menu off screen, so each continuation box must restate what was chosen.
_LIVE_CONTEXT = []


def _boxed_progress(title, collect_files=False):
    """Use the shell's fixed-height progress box when a shell is attached.
    Fall back to the compiled progress UI for bare CLI runs. The compiled
    `_ProgressUI.log` writes raw per-file lines outside every box, which is
    exactly what the shell adapter replaces."""
    vip = getattr(ikram, "_vip_ref", None)
    if vip is not None:
        try:
            import vip_ui
            return vip_ui.make_progress_callback(
                vip, title=title, collect_files=collect_files)
        except Exception as _exc:
            ikram_logger.log_exc("ikram_patch._boxed_progress", _exc)
    return ikram._ProgressUI(title=title)


def _vip_ref():
    return getattr(ikram, "_vip_ref", None)


def _vip_num(digit):
    """Rich markup for a displayed menu digit from the active theme."""
    fn = getattr(ikram, "_vip_num", None)
    if callable(fn):
        return fn(digit)
    vip = _vip_ref()
    theme = getattr(vip, "theme", None)
    try:
        from theme_engine import Theme
        cyc = Theme(getattr(theme, "name", "Original Color")).number_cycle()
    except Exception:
        cyc = {"5": 228}
    return "bold color(%d)" % cyc.get(str(digit), cyc.get("5", 228))


def _stdin_can_wait():
    """A manual continue is only legal when a human terminal can answer."""
    try:
        return bool(sys.stdin is not None and sys.stdin.isatty())
    except Exception:
        return False


def _write_pause_prompt():
    vip = _vip_ref()
    if vip is not None:
        try:
            vip.write(vip.theme.apply("  Press ENTER to continue", "dim") + "\n")
            return
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._write_pause_prompt:vip", _ikram_exc)
    try:
        sys.stdout.write("  Press ENTER to continue\n")
        sys.stdout.flush()
    except Exception:
        pass


def pause(sec=None):
    """Manual continue on PC and Termux; piped or scripted runs never hang."""
    _write_pause_prompt()
    if not _stdin_can_wait():
        return
    vip = _vip_ref()
    if vip is not None:
        try:
            vip.wait_enter(label="")
            return
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch.pause:vip", _ikram_exc)
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        pass


ikram.pause = pause


def _show_context(main, files=(), title="WORKING FILE", **kwargs):
    """One context box for every operation that works on named files."""
    vip = _vip_ref()
    if vip is None:
        return
    fn = getattr(vip, "show_file_context", None)
    if not callable(fn):
        return
    try:
        fn(main, files, title=title, **kwargs)
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._show_context", _exc)


def _render_path_prompt(title, question, rows=(), main=None, token=None):
    """Paint one selection box with SELECT as the only typed-input marker.

    The question text stays in the compiled fallback. In the boxed UI the
    title and the numbered rows already carry the meaning; using the question
    as the marker made answers read as "Choose pak to unpack: 5" and put the
    cursor after a sentence instead of after SELECT.
    """
    vip = _vip_ref()
    if vip is None:
        return False
    fn = getattr(vip, "path_prompt_box", None)
    if not callable(fn):
        return False
    try:
        kwargs = {}
        if token:
            kwargs["token"] = token
        marker = glyph("arrow") + " SELECT:"
        box = fn(marker, rows, title=title, main=main, **kwargs)
        writer = getattr(vip, "write_prompt_box", None)
        if callable(writer):
            writer(box, marker, fallback=title)
        else:
            vip.write(box + "\n")
        return True
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._render_path_prompt", _exc)
        return False


def _ask_boxed(title, question, rows=(), main=None, fallback=None, token=None):
    """Read one answer. Boxed when the shell is attached, compiled otherwise."""
    if _render_path_prompt(title, question, rows, main, token):
        vip = _vip_ref()
        return vip._ask("")
    if fallback is not None:
        return str(fallback or "")
    if rows:
        print(title)
        print(question)
        for row in rows:
            if isinstance(row, (tuple, list)):
                print("{}  {}".format(row[0], row[1]))
            else:
                print(str(row))
    return str(ikram.safe_input("→ SELECT:") or "")


def _consume_eof():
    """Report and clear EOF once, so a later prompt cannot act on stale EOF."""
    try:
        eof = bool(ikram.eof_exit())
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._consume_eof", _ikram_exc)
        return False
    if not eof:
        return False
    try:
        ikram._EOF = False
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._consume_eof:clear", _ikram_exc)
    return True


def _inject_abort(message="Cancelled — nothing injected."):
    """One cancel/failure panel and one continue for every Inject early exit."""
    ikram.show_error(message)
    ikram.pause()
    return None


def _canonical_inject_target(value, paths=()):
    """Return a safe pak-relative target, or None for an unsafe path.

    The pak index is a virtual game path. A drive letter, leading slash or an
    unresolved ``..`` can never name a game file: the shipped unpacker silently
    quarantines those entries instead, so the user sees success while the game
    never loads the edit. Reject them before dedup and before the writer.
    """
    text = str(value or "").strip().strip("'\"`").replace("\\", "/")
    if not text:
        return None
    drive, tail = ntpath.splitdrive(text)
    if drive or tail.startswith("/"):
        return None
    parts = []
    for seg in tail.split("/"):
        if not seg or seg == ".":
            continue
        if seg == "..":
            if not parts:
                return None
            parts.pop()
            continue
        parts.append(seg)
    if not parts:
        return None
    normalized = "/".join(parts)
    return _canonical_pak_path(paths, normalized)


def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


_LEGACY_SOURCE_NAME = ".ikram_source.json"


def _source_manifest_path(edit_dir):
    """Store the source guard outside the extracted tree.

    The old manifest sat at the root of RESULT/extracted/<pak>. Repack walked
    that tree and packed it into the game archive, and Unpack showed it as an
    extra file that did not come from the pak. The guard still needs to follow
    one exact extracted directory, so key the file by that directory's resolved
    path inside .engine/.ikram_tool/source_manifests/.
    """
    key = hashlib.sha256(
        str(Path(edit_dir).resolve()).encode("utf-8", "replace")
    ).hexdigest()[:32]
    return Path(_paths.SOURCE_STORE) / ("source_{}.json".format(key))


def _remove_legacy_source_manifest(edit_dir):
    """Remove an old in-tree manifest without touching any pak file."""
    legacy = Path(edit_dir) / _LEGACY_SOURCE_NAME
    try:
        if legacy.is_file():
            legacy.unlink()
    except OSError as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._remove_legacy_source_manifest", _ikram_exc)


def _write_source_manifest(pakf, edit_dir):
    """Record the exact pak bytes an extracted tree was produced from."""
    try:
        src = Path(pakf)
        manifest = {
            "version": 1,
            "name": src.name,
            "size": src.stat().st_size,
            "sha256": _sha256_file(src),
            "edit_dir": str(Path(edit_dir).resolve()),
        }
        target = _source_manifest_path(edit_dir)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                          encoding="utf-8")
    except Exception as _ikram_exc:
        # A manifest is a guard, not the operation. Never turn a good unpack
        # into a failure because a read-only/odd filesystem refused metadata.
        ikram_logger.log_exc("ikram_patch._write_source_manifest", _ikram_exc)
    _remove_legacy_source_manifest(edit_dir)


def _stale_source_message(pakf, edit_dir):
    """Refuse repack unless this exact tree has a valid guard for this pak.

    A missing or unreadable guard is not freshness. It means an unpack failed
    to record metadata, the tree was copied, or the guard was edited. Every
    one of those must fail closed before a writer is touched.
    """
    _remove_legacy_source_manifest(edit_dir)
    manifest_file = _source_manifest_path(edit_dir)
    if not manifest_file.is_file():
        return (
            "This extracted tree has no source guard.\n\n"
            "Re-unpack the current pak, apply the same edits again, then "
            "repack. The original pak was not modified."
        )
    try:
        old = json.loads(manifest_file.read_text(encoding="utf-8"))
        src = Path(pakf)
        size = src.stat().st_size
        digest = _sha256_file(src)
        bound = str(old.get("edit_dir", ""))
        want_dir = str(Path(edit_dir).resolve())
        if (not isinstance(old, dict) or bound != want_dir
                or int(old.get("size", -1)) < 0
                or not str(old.get("sha256", ""))):
            raise ValueError("source guard is incomplete")
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._stale_source_message", _ikram_exc)
        return (
            "This extracted tree's source guard could not be read.\n\n"
            "Re-unpack the current pak, apply the same edits again, then "
            "repack. The original pak was not modified."
        )
    if int(old.get("size", -1)) == size and str(old.get("sha256", "")).lower() == digest:
        return None
    return (
        "This pak changed after it was unpacked.\n"
        "The extracted tree belongs to the earlier {}\n"
        "file ({} bytes, SHA-256 {}).\n\n"
        "Re-unpack the current pak, apply the same edits again, then repack. "
        "The original pak was not modified.".format(
            str(old.get("name") or src.name), old.get("size", "?"),
            str(old.get("sha256", "?"))[:16]
        )
    )


def _migrate_legacy_source_manifests():
    """Move manifests from old unpacked trees into the hidden guard store."""
    extracted = Path(_paths.RESULT_EXTRACTED)
    if not extracted.is_dir():
        return
    try:
        children = sorted(extracted.iterdir(), key=lambda p: p.name)
    except OSError as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._migrate_legacy_source_manifests:list", _ikram_exc)
        return
    for child in children:
        if not child.is_dir():
            continue
        legacy = child / _LEGACY_SOURCE_NAME
        if not legacy.is_file():
            continue
        try:
            raw = legacy.read_bytes()
            json.loads(raw.decode("utf-8"))
            target = _source_manifest_path(child)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            legacy.unlink()
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._migrate_legacy_source_manifests:move", _ikram_exc)


_migrate_legacy_source_manifests()


def _tint(text, role):
    """Colour one choice row by role; stays plain in the compiled fallback."""
    vip = _vip_ref()
    theme = getattr(vip, "theme", None) if vip is not None else None
    if theme is None:
        return str(text)
    try:
        return theme.apply(str(text), role)
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._tint", _exc)
        return str(text)


# Old numbered file view: bold gold number, one colour per file from the
# original 20-colour cycle, white size. No line is emitted outside the box.
_OLD_FILE_COLOURS = (
    45, 51, 39, 118, 119, 155, 82, 208, 214, 220,
    228, 198, 204, 213, 218, 147, 141, 105, 177, 183,
)


def _empty_unpack_stats():
    return {"file_rows": [], "elapsed": 0.0, "output": ""}


def _numbered_file_rows(vip, messages):
    from vip_ui import _match_file_log, format_file_lines

    try:
        width = vip.box._resolve_width(None) - 4
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._numbered_file_rows:width", _exc)
        width = 72
    rows = []
    number = 0
    for message in messages or ():
        parsed = _match_file_log(message)
        if parsed is None:
            name, size = safe_text(message).strip(), ""
        else:
            name, size = parsed[0], parsed[1]
        name = safe_text(name).strip()
        if not name:
            continue
        number += 1
        rows.extend(format_file_lines(number, name, size, width=width))
    return rows


def _display_path(value):
    """Keep destinations readable without losing the tool-relative path."""
    from paths import TOOL_DIR

    parts = []
    for raw in str(value or "").split("; "):
        text = raw.strip()
        if not text:
            continue
        try:
            candidate = Path(text)
            if candidate.is_absolute():
                text = candidate.resolve().relative_to(Path(TOOL_DIR).resolve()).as_posix()
        except Exception:
            pass
        parts.append(text)
    return "; ".join(parts) or "-"


def _live_progress(title, root=None, context=None):
    """Live append-only file boxes. Falls back to the old frame only when no
    VIP shell exists; compiled CLI runs keep their original behaviour."""
    vip = _vip_ref()
    if vip is None:
        return None
    try:
        import vip_ui

        return vip_ui.make_live_file_callback(
            vip, title=title, root=root,
            context=_LIVE_CONTEXT if context is None else context)
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._live_progress", _exc)
        return None


def _tree_bytes(root):
    rootp = Path(root)
    try:
        if rootp.is_file():
            return int(rootp.stat().st_size)
    except OSError:
        return 0
    total = 0
    try:
        items = list(rootp.rglob("*"))
    except OSError as _exc:
        ikram_logger.log_exc("ikram_patch._tree_bytes:walk", _exc)
        return 0
    for path in items:
        try:
            if not path.is_file() or _paths.is_internal_rel(path.relative_to(rootp)):
                continue
            total += int(path.stat().st_size)
        except (OSError, ValueError) as _exc:
            ikram_logger.log_exc("ikram_patch._tree_bytes:stat", _exc)
    return total


def _folder_paths(root):
    """Countable real folders under a result root, deduplicated and internal-free."""
    rootp = Path(root)
    found = []
    try:
        if rootp.is_dir():
            found.append(_display_path(rootp))
        elif rootp.exists():
            found.append(_display_path(rootp.parent))
        for path in sorted(rootp.rglob("*")):
            if not path.is_dir():
                continue
            rel = path.relative_to(rootp)
            if _paths.is_internal_rel(rel):
                continue
            found.append(_display_path(path))
    except (OSError, ValueError) as _exc:
        ikram_logger.log_exc("ikram_patch._folder_paths", _exc)
    out, seen = [], set()
    for folder in found:
        if folder and folder not in seen:
            seen.add(folder)
            out.append(folder)
    return out


def _rows_from_tree(root):
    """Real file rows from disk. Used when a worker reports a count but no
    per-file log — the detail box must never invent a row."""
    rootp = Path(root)
    rows = []
    try:
        if rootp.is_file():
            return ["{}  ({} bytes)".format(rootp.name, rootp.stat().st_size)]
        items = list(sorted(rootp.rglob("*")))
    except OSError as _exc:
        ikram_logger.log_exc("ikram_patch._rows_from_tree:walk", _exc)
        return rows
    for path in items:
        try:
            if not path.is_file() or _paths.is_internal_rel(path.relative_to(rootp)):
                continue
            rows.append("{}  ({} bytes)".format(
                path.relative_to(rootp).as_posix(), path.stat().st_size))
        except (OSError, ValueError) as _exc:
            ikram_logger.log_exc("ikram_patch._rows_from_tree:stat", _exc)
    return rows


def _short_out(value):
    """Readable tool-relative output, without a second folder-path block."""
    text = _display_path(value)
    return text[7:] if text.startswith("RESULT/") else text


def _size_label(size_bytes):
    try:
        value = int(size_bytes or 0)
    except Exception:
        value = 0
    return "{:,} bytes ({:.2f} MB)".format(value, value / 1048576.0)


def _emit_detail_box(vip, title, pak_name, size_bytes, folders, count, elapsed,
                     messages, notes=None, style="heavy", role="success",
                     extra=None):
    """One final box: real totals and context. File rows stay in the live box."""
    from vip_ui import SEP, _fmt_dur, basic_paint

    folder_list = [x for x in (folders or ()) if str(x).strip()]
    body = [
        basic_paint("PAK : ", 93) + basic_paint(safe_text(pak_name), 96),
        basic_paint("SIZE : ", 93) + basic_paint(_size_label(size_bytes), 92),
        basic_paint("FOLDERS : ", 93) + basic_paint(str(len(folder_list)), 92),
        basic_paint("FILES : ", 93) + basic_paint(str(count), 92),
        basic_paint("ELAPSED : ", 93)
        + basic_paint(_fmt_dur(elapsed), 94),
    ]
    for label, value in (extra or ()):
        text = safe_text(value).strip()
        if text:
            body.append(basic_paint(safe_text(label) + " : ", 93)
                        + basic_paint(text, 96))
    notes = [safe_text(x) for x in (notes or ()) if str(x).strip()]
    if notes:
        body.append(SEP)
        for note in notes[:4]:
            body.append(basic_paint("NOTE : " + note, 93))
        if len(notes) > 4:
            body.append(basic_paint("NOTE : +%d more (see error.log)"
                                    % (len(notes) - 4), 93))
    box = vip.box.draw_box(body, style, title=safe_text(title),
                           color_role=role)
    try:
        vip._last_outcome = "SUCCESS" if not notes else "WARN"
    except Exception:
        pass
    vip._paint_frame(box, reset=True)


def _emit_unpacked_detail(pakf, out, stats, n, notes=None):
    vip = _vip_ref()
    if vip is None:
        return
    stats = stats or _empty_unpack_stats()
    rows = stats.get("file_rows") or _rows_from_tree(out)
    try:
        source_size = Path(pakf).stat().st_size
    except OSError as _exc:
        ikram_logger.log_exc("ikram_patch._emit_unpacked_detail:stat", _exc)
        source_size = 0
    try:
        kind = ikram.detect_pak_type(pakf) or "raw asset"
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._emit_unpacked_detail:kind", _exc)
        kind = "-"
    _emit_detail_box(
        vip, "UNPACKED", _PakName(pakf), source_size, _folder_paths(out),
        int(n or len(rows)), float(stats.get("elapsed") or 0.0), rows, notes,
        extra=[("KIND", kind), ("OUTPUT", _short_out(out))])


def _emit_processed_detail(pakf, processed, notes=None):
    vip = _vip_ref()
    if vip is None or not processed:
        return
    root = processed.get("output") or "RESULT/processed"
    rows = processed.get("file_rows") or _rows_from_tree(root)
    if notes is None:
        notes = []
        if processed.get("errors"):
            notes = ["%d file(s) could not be processed"
                     % int(processed["errors"])]
    try:
        kind = ikram.detect_pak_type(pakf) or "raw asset"
    except Exception as _exc:
        ikram_logger.log_exc("ikram_patch._emit_processed_detail:kind", _exc)
        kind = "-"
    _emit_detail_box(
        vip, "PROCESSED", _PakName(pakf), _tree_bytes(root),
        _folder_paths(root), int(processed.get("files") or len(rows)),
        float(processed.get("elapsed") or 0.0), rows, notes,
        extra=[("SOURCE", _PakName(pakf)), ("KIND", kind),
               ("OUTPUT", _short_out(root)),
               ("FILTER", ".lua/.luac skipped")])


def _emit_result_box(vip, title, count, out, elapsed, messages, notes=None):
    """One direct result box. No paging input, no dump file, no extra text.

    Notes stay inside the same box, capped, so a quarantine or processor
    problem is never silently swallowed just because the run had files.
    """
    from vip_ui import SEP, _fmt_dur

    theme = getattr(vip, "theme", None)
    paint = theme.apply if theme is not None else (lambda s, role="text": safe_text(s))
    rows = _numbered_file_rows(vip, messages)
    body = [
        paint("DONE", "success") + paint("  {} file(s)".format(count), "text"),
        paint("Where : {}".format(_display_path(out)), "text"),
        paint("Elapsed: {}".format(_fmt_dur(elapsed)), "text"),
    ]
    if rows:
        body.append(SEP)
        body.extend(rows)
    notes = [safe_text(x) for x in (notes or ()) if str(x).strip()]
    if notes:
        if not rows:
            body.append(SEP)
        shown = notes[:4]
        for note in shown:
            body.append(paint("WARN: " + note, "warn"))
        if len(notes) > len(shown):
            body.append(paint("WARN: ... +%d more (see error.log)"
                              % (len(notes) - len(shown)), "warn"))
    box = vip.box.draw_box(body, "rounded", title=safe_text(title),
                           color_role="success")
    try:
        vip._last_outcome = "WARN" if notes else "SUCCESS"
    except Exception:
        pass
    vip._paint_frame(box, reset=True)


def _pak_problem_box(pakf, kind, heading, box=True, problems=None, note=None):
    """Plain, self-contained failure box for a pak the tool cannot open.

    The compiled core's own handler for this case also printed an "owner"
    line telling the user to hand the file to somebody, which is noise: the
    user only needs to know the file is not a pak this tool supports, or that
    the folder is empty. Kept local so the wording is fully under our control.
    Batch callers pass ``box=False`` and collect the same wording in
    ``problems`` for one summary panel.
    """
    global _PAK_BOX_SHOWN
    name = _PakName(pakf)
    if kind == "zip":
        detail = '"{}" is a ZIP archive, not a PAK file.'.format(name)
    else:
        detail = '"{}" is not a supported PAK format.'.format(name)
    if note:
        detail += "\n" + str(note)[:160]
    if not box:
        if problems is not None:
            problems.append("{} {}".format(heading.rstrip("."), detail))
        return
    _PAK_BOX_SHOWN = True
    ikram.show_error(
        "{}\n{}\n\nCheck that you are using the original .pak file.".format(
            heading, detail
        )
    )


def _show_handler_error(exc):
    """One visible error panel in UI mode; compiled logging alone is silent."""
    msg = str(exc) or "Operation failed."
    low = msg.lower()
    mapped = False
    if ("stored sha1 mismatch" in low or "payload readback mismatch" in low
            or "repacked entry missing" in low):
        msg = (
            "The repack failed verification: the source pak or the extracted "
            "files changed after unpack.\n"
            "Re-unpack this pak, apply the edits again, then repack.\n"
            "The unverified output is kept for inspection in "
            "RESULT/Repacked/_UNVERIFIED/."
        )
        mapped = True
    if not mapped:
        friendly = getattr(ikram, "friendly_error", None)
        if callable(friendly):
            try:
                msg = str(friendly(exc)) or msg
            except Exception as _ikram_exc:
                ikram_logger.log_exc("ikram_patch._show_handler_error:friendly", _ikram_exc)
    vip = _vip_ref()
    if vip is not None:
        fn = getattr(vip, "error_box", None)
        if callable(fn):
            try:
                fn([msg])
                return
            except Exception as _ikram_exc:
                ikram_logger.log_exc("ikram_patch._show_handler_error:box", _ikram_exc)
    if hasattr(ikram, "show_error"):
        ikram.show_error(msg)


def _unpack_one(pakf, out, log=None, progress=None, box=True, problems=None,
                show_context=True, stats=None):
    """Unpack a single pak -> out. Returns (n, kind). IETA: engines layer.

    `stats` is an optional out-parameter: harness callers keep the historic
    two-value return while UI callers receive the file rows and elapsed time
    needed by the result box.
    """
    if stats is not None:
        stats.clear()
        stats.update(_empty_unpack_stats())
    kind = ikram.detect_pak_type(pakf)
    if kind not in ("tencent", "ue4"):
        _pak_problem_box(pakf, kind, "This pak is not supported.",
                         box=box, problems=problems)
        return 0, kind
    if show_context:
        _show_context(_PakName(pakf), (), title="PAK FILE", mode=kind)
    n = 0
    ui = None
    t0 = time.monotonic()
    rows = []
    elapsed = 0.0
    # V112: engines layer auto-tries saved/shipped AES keys now; passing
    # None (instead of the default) lets a user's working key win first.
    aes_key = None
    try:
        if log is None or progress is None:
            # UI runs get append-only live boxes. The compiled CLI path keeps
            # its own progress object, which has no VIP shell to write to.
            ui = _live_progress("UNPACKING", root=out)
            if ui is None:
                ui = _boxed_progress("PAK | {}".format(_PakName(pakf)),
                                     collect_files=True)
            with ui:
                kwargs = {"kind": kind, "aes_key": aes_key, "log": ui.log}
                try:
                    params = inspect.signature(_engines.unpack_pak).parameters
                    if "progress" in params:
                        kwargs["progress"] = (
                            getattr(progress, "progress", progress)
                            if progress is not None
                            else getattr(ui, "progress", ui))
                    if "on_file" in params and hasattr(ui, "on_file"):
                        kwargs["on_file"] = ui.on_file
                except Exception:
                    pass
                n = _engines.unpack_pak(pakf, out, **kwargs)
        else:
            kwargs = {"kind": kind, "aes_key": aes_key, "log": log}
            if progress is not None:
                kwargs["progress"] = progress
            n = _engines.unpack_pak(pakf, out, **kwargs)
    except Exception as e:
        ikram_logger.log_exc("ikram_patch._unpack_one", e)
        _pak_problem_box(pakf, kind, "Could not unpack this pak.",
                         box=box, problems=problems, note=str(e))
        if ui is not None and hasattr(ui, "clear"):
            ui.clear()
        if stats is not None:
            stats["elapsed"] = max(0.0, time.monotonic() - t0)
        return 0, kind
    try:
        elapsed = float(ui.elapsed()) if (ui is not None and hasattr(ui, "elapsed")) \
            else max(0.0, time.monotonic() - t0)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._unpack_one:elapsed", _ikram_exc)
        elapsed = max(0.0, time.monotonic() - t0)
    if ui is not None:
        rows = [safe_text(x) for x in (getattr(ui, "files", None) or ())]
        if hasattr(ui, "clear"):
            ui.clear()
    if n > 0 and not rows:
        # A worker that only reported a count is not an excuse to show an empty
        # detail box. Read the files it actually wrote instead of inventing any.
        rows = _rows_from_tree(out)
    if stats is not None:
        stats.update({
            "file_rows": rows,
            "elapsed": elapsed,
            "output": str(out),
        })
    if n > 0:
        _write_source_manifest(pakf, out)
    if kind == "tencent":
        _warn_undecrypted(pakf, box=box, problems=problems)
    return n, kind


def _warn_undecrypted(pakf, box=True, problems=None):
    """Re-print the tencent quarantine warning after the progress UI closed."""
    global _PAK_BOX_SHOWN
    good, bad, undec = getattr(_engines, "_LAST_TENCENT_VERIFY", (None, None, None))
    if not bad:
        return
    methods = "/".join(str(u) for u in (undec or [])) or "unknown"
    if not box:
        if problems is not None:
            problems.append(
                "{}: {}/{} entries could NOT be decrypted (method {}); "
                "raw payloads were quarantined.".format(
                    _PakName(pakf), len(bad), len(good) + len(bad), methods))
        return
    _PAK_BOX_SHOWN = True
    ikram.show_error(
        "{}/{} entries could NOT be decrypted (encryption method {}).\n\n"
        "The pak is NOT damaged and its SHA1 index is clean - this build "
        "just cannot decrypt method {}.\nThose files were MOVED to:\n"
        "  {}\n\nThey are the raw encrypted payload, not the real files. Do "
        "not edit them.".format(
            len(bad), len(good) + len(bad), methods, methods,
            _extracted_root_display(pakf)))


def _extracted_root_display(pakf):
    try:
        return str(Path(ikram.RESULT / "extracted" / Path(pakf).stem) / "_quarantine")
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._extracted_root_display", _ikram_exc)
        return "RESULT/extracted/_quarantine/"

def _PakName(pakf):
    try:
        return Path(pakf).name
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._PakName:188", _ikram_exc)
        return str(pakf)


def _normalized_pak_path(value):
    return str(value or "").strip("/").replace("\\", "/")


def _canonical_path_map(paths):
    """lower-case pak path -> exact stored path from the pak index."""
    out = {}
    for p in paths or ():
        got = _normalized_pak_path(p)
        out.setdefault(got.lower(), got)
    return out


def _pak_name_map(paths):
    """lower-case basename -> all exact stored paths with that basename."""
    out = {}
    for p in paths or ():
        got = _normalized_pak_path(p)
        out.setdefault(got.rsplit("/", 1)[-1].lower(), []).append(got)
    return out


def _canonical_pak_path(paths, target):
    """Return the pak's exact stored case for a case-insensitive match."""
    want = _normalized_pak_path(target)
    return _canonical_path_map(paths).get(want.lower(), want)


def _unique_out_dir(base):
    """base, base (1), base (2) ... — existing files are never overwritten."""
    out = Path(base)
    if not out.exists():
        return out
    i = 1
    while True:
        cand = out.parent / "{} ({})".format(out.name, i)
        if not cand.exists():
            return cand
        i += 1


def _unique_out_file(path):
    """Same as _unique_out_dir but for a single file — keep original name,
    suffix (1), (2) ... — existing files are never overwritten."""
    if not path.exists():
        return path
    i = 1
    while True:
        cand = path.with_name("{} ({}){}".format(path.stem, i, path.suffix))
        if not cand.exists():
            return cand
        i += 1


def _show_unpack_options(nfiles):
    t = ikram.Table(
        box=ikram.ROUNDED,
        show_header=False,
        pad_edge=False,
        border_style=ikram.BORDER,
        style="on {}".format(ikram.BG_DEEP),
    )
    t.add_column(width=3)
    t.add_column(style="bright_white")
    t.add_row(
        "[{}]1[/]".format(_vip_num(1)),
        "[bold {}]UNPACK ONE FILE[/]  [bold {}]— choose 1 pak[/]".format(
            ikram.SUCCESS, ikram.MUTED
        ),
    )
    t.add_row(
        "[{}]2[/]".format(_vip_num(2)),
        "[bold {}]UNPACK ALL {} FILES[/]  [bold {}]— every pak + asset in DROP/pak[/]".format(
            ikram.ACCENT, nfiles, ikram.MUTED
        ),
    )
    t.add_row(
        "[{}]0[/]".format(_vip_num(0)),
        "[bold {}]CANCEL[/]".format(ikram.ERROR),
    )
    ikram.console.print(
        ikram.panel(t, title="📦 UNPACK MODE ({})".format(nfiles), box=ikram.ROUNDED, style=ikram._next_green())
    )


def _show_pak_list(paks):
    t = ikram.Table(
        box=ikram.ROUNDED,
        show_header=False,
        pad_edge=False,
        border_style=ikram.BORDER,
        style="on {}".format(ikram.BG_DEEP),
    )
    t.add_column(width=4)
    t.add_column(style="bright_white")
    t.add_column(style=ikram.MUTED, width=14)
    rows = 0
    for i, p in enumerate(paks, 1):
        try:
            size = p.stat().st_size
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._show_pak_list:265", _ikram_exc)
            size = 0
        hsize = (
            "{:.1f} MB".format(size / 1048576)
            if size >= 1048576
            else "{:.0f} KB".format(size / 1024)
        )
        t.add_row("[{}]{}[/]".format(_vip_num(i % 10), i), p.name, hsize)
        rows += 1
    title = "📦 FILES IN DROP/pak ({})".format(rows)
    ikram.console.print(
        ikram.panel(t, title=title, box=ikram.ROUNDED, style=ikram._next_green())
    )


def _choose_pak_index(n, paks, label, question="Choose a pak:",
                      main="CHOOSE PAK"):
    """Choose one item. One box owns the list and the prompt."""
    boxed = _vip_ref() is not None
    if not boxed:
        _show_pak_list(paks)
        ikram.console.print(
            "[bold {}]0 = cancel[/bold {}]".format(ikram.MUTED, ikram.MUTED)
        )
    names = [_PakName(p) for p in paks]
    rows = [_tint("{} = {}".format(i, name), "text")
            for i, name in enumerate(names, 1)]
    rows.append(_tint("0 = cancel", "error"))
    rows.append(_tint("ENTER = auto first", "success"))
    base_rows = list(rows)
    bad = ""
    while True:
        shown = list(base_rows)
        if bad:
            shown.append(bad)
        c = _ask_boxed(label, question, shown, main=main)
        if not c:
            if _consume_eof():
                return _EOF_CHOICE
            return 0
        if c.strip() == "0":
            return None
        try:
            i = int(c.strip()) - 1
            if 0 <= i < n:
                return i
        except ValueError as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._choose_pak_index:296", _ikram_exc)
        bad = _tint("Invalid number. Pick 1 to {}.".format(n), "error")


def ensure_input_folder():
    """Pick only .pak files from DROP/pak (OBB support removed)."""
    paks = [p for p in ikram.drop_files(ikram.DROP_PAK, [".pak"])
            if not _paths.is_internal_rel(
                Path(p).relative_to(Path(ikram.DROP_PAK)))]
    if not paks:
        ikram.show_error(
            "The pak folder is empty.\nAdd your .pak file to DROP/pak and try again."
        )
        ikram.pause()
        return None
    return ikram.pick_file(
        ikram.DROP_PAK,
        "📦 Choose a PAK file [bold {}](DROP/pak)[/bold {}]".format(ikram.MUTED, ikram.MUTED),
        [".pak"],
    )


def _is_pak(p):
    try:
        return Path(p).suffix.lower() == ".pak"
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._is_pak:321", _ikram_exc)
        return False


def _drop_items():
    """ALL files in DROP/pak — .pak files are paks, everything else is assets/raw."""
    base = Path(ikram.DROP_PAK)
    if not base.is_dir():
        return []
    return [p for p in sorted(base.rglob("*"))
            if p.is_file()
            and not _paths.is_internal_rel(p.relative_to(base))]


def _process_standalone(f):
    """Standalone non-pak file: raw copy -> RESULT/extracted/<name>/,
    processed sidecars -> RESULT/processed/<name>/."""
    f = Path(f)
    raw_dir = _unique_out_dir(ikram.RESULT / "extracted" / f.stem)
    raw_dir.mkdir(parents=True, exist_ok=True)
    # Keyed off the uniquified raw dir name so repeat runs stay paired
    # (extracted/foo (1) <-> processed/foo (1)) instead of overwriting.
    proc_dir = _unique_out_dir(ikram.RESULT / "processed" / raw_dir.name)
    # LUA has its own tool and output tree. The raw file still lands in the
    # extracted mirror, but no readable sidecar belongs in PROCCESSED.
    if _paths.should_process_rel(f.name):
        msg = _assets.process_file(f, proc_dir)
        if str(msg).startswith("process failed"):
            return {"raw": str(raw_dir), "processed": str(proc_dir),
                    "error": str(msg)}
    shutil.copy2(f, raw_dir / f.name)
    return {"raw": str(raw_dir), "processed": str(proc_dir)}


def _auto_process_tree(out_dir, pakstem=None):
    """After pak unpack, the inner files are auto-processed:
    RESULT/extracted/<pak> -> sidecars RESULT/processed/<pak> (raw tree clean).

    The sidecar root is keyed off the *uniquified* output dir name and
    uniquified itself. Before, a second unpack of the same pak wrote into
    extracted/<pak> (1) but still targeted processed/<pak>, so run 2's
    sidecars collided with run 1's — the "(1)" guarantee bought nothing.
    """
    proc_root = _unique_out_dir(ikram.RESULT / "processed" / Path(out_dir).name)
    context = list(_LIVE_CONTEXT)
    ui = _live_progress("PROCESSING", root=out_dir, context=context)
    if ui is None:
        ui = _boxed_progress("PROCESSING FILES", collect_files=True)
    t0 = time.monotonic()
    with ui:
        kwargs = {"log": ui.log, "every": 1}
        try:
            params = inspect.signature(_assets.process_tree).parameters
            if "progress" in params:
                kwargs["progress"] = getattr(ui, "progress", ui)
        except Exception:
            pass
        n, stats, errs = _assets.process_tree(out_dir, proc_root, **kwargs)
    rows = [safe_text(x) for x in (getattr(ui, "files", None) or ())]
    if n > 0 and not rows:
        rows = _rows_from_tree(proc_root)
    try:
        elapsed = float(ui.elapsed()) if hasattr(ui, "elapsed") \
            else max(0.0, time.monotonic() - t0)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._auto_process_tree:elapsed", _ikram_exc)
        elapsed = max(0.0, time.monotonic() - t0)
    if hasattr(ui, "clear"):
        ui.clear()
    type_rows = sorted(stats.items(), key=lambda x: -x[1])[:6]
    detail = "  ".join("{}:{}".format(k, v) for k, v in type_rows)
    # Return evidence to the caller. Printing here put the last lines of an
    # unpack AFTER the success box — the reported "lines outside the box".
    return {
        "files": n,
        "output": str(proc_root),
        "errors": len(errs),
        "stats": detail,
        "file_rows": rows,
        "elapsed": elapsed,
    }


def pak_extract():
    global _PAK_BOX_SHOWN, _LIVE_CONTEXT
    _LIVE_CONTEXT = []
    # Cleared per run: a stale True from an earlier batch would silently mute
    # the summary error for the next, genuinely different, batch.
    _PAK_BOX_SHOWN = False
    items = _drop_items()
    if not items:
        ikram.show_error(
            "The pak folder is empty.\nAdd your .pak file to DROP/pak and try again."
        )
        ikram.pause()
        return
    if ikram.eof_exit():
        return
    # Mode first. Mode 2 needs no file pick; mode 1 asks for one pak after.
    boxed = _vip_ref() is not None
    if not boxed:
        _show_unpack_options(len(items))
    mode = _ask_boxed(
        "UNPACK MODE",
        "Choose mode:",
        [_tint("1 = one file", "success"),
         _tint("2 = all files", "accent"),
         _tint("0 = cancel", "error")],
        main="UNPACK MODE",
    ).strip()
    if ikram.eof_exit():
        return
    if mode == "0":
        ikram.show_error("Cancelled — nothing unpacked.")
        ikram.pause()
        return

    if mode == "1":
        idx = _choose_pak_index(
            len(items), items, "UNPACK ONE",
            question="Choose pak to unpack:", main="CHOOSE PAK")
        if idx is _EOF_CHOICE or idx is None:
            ikram.show_error("Cancelled — nothing unpacked.")
            ikram.pause()
            return
        f = items[idx] if idx else items[0]
        _LIVE_CONTEXT = []
        if _is_pak(f):
            out = _unique_out_dir(ikram.RESULT / "extracted" / f.stem)
            _show_context(_PakName(f), (), title="UNPACK FILE",
                          mode="extract", output=str(out))
            unpack_stats = _empty_unpack_stats()
            n, kind = _unpack_one(f, out, show_context=False,
                                  stats=unpack_stats)
            if n > 0:
                # Live UNPACKING and PROCESSING boxes stay on screen. Close the
                # PROCESSED detail first, then place the UNPACKED detail below it
                # so the two final boxes follow the order the operator asked for.
                processed = _auto_process_tree(out)
                _emit_processed_detail(f, processed)
                _emit_unpacked_detail(f, out, unpack_stats, n)
            else:
                _finish_report(f, n, kind, out, None, unpack_stats)
        else:
            _show_context(_PakName(f), (), title="PROCESSING FILE",
                          mode="standalone", output="RESULT/extracted")
            try:
                t0 = time.monotonic()
                info = _process_standalone(f)
                elapsed = max(0.0, time.monotonic() - t0)
                try:
                    raw_size = Path(f).stat().st_size
                except OSError as _ikram_exc:
                    ikram_logger.log_exc("ikram_patch.pak_extract:raw_stat", _ikram_exc)
                    raw_size = 0
                vip = _vip_ref()
                if vip is not None:
                    proc_dir = Path(info["processed"])
                    unpack_rows = ["{}  ({} bytes)".format(Path(f).name, raw_size)]
                    made = [p for p in sorted(proc_dir.rglob("*"))
                            if p.is_file()
                            and not _paths.is_internal_rel(p.relative_to(proc_dir))]
                    proc_rows = []
                    for p in made:
                        try:
                            made_size = p.stat().st_size
                        except OSError as _ikram_exc:
                            ikram_logger.log_exc(
                                "ikram_patch.pak_extract:proc_stat", _ikram_exc)
                            made_size = 0
                        proc_rows.append("{}  ({} bytes)".format(
                            p.relative_to(proc_dir).as_posix(), made_size))
                    proc_count = len(made)
                    notes = []
                    if info.get("error"):
                        notes.append("{}: {}".format(
                            Path(f).name, str(info["error"])[:96]))
                    _emit_unpacked_detail(
                        f, str(info["raw"]),
                        {"file_rows": unpack_rows, "elapsed": elapsed}, 1)
                    _emit_processed_detail(
                        f, {"output": str(info["processed"]),
                            "files": proc_count, "file_rows": proc_rows,
                            "elapsed": elapsed,
                            "errors": 1 if info.get("error") else 0},
                        notes=notes)
                else:
                    ikram.show_success(
                        "✔ {} unpacked/processed\nRaw: {}\nProcessed: {}".format(
                            f.name, info["raw"], info["processed"]
                        )
                    )
            except Exception as e:
                ikram_logger.log_exc("ikram_patch.pak_extract:411", e)
                ikram.report_error(e)
        ikram.pause()
        return

    if mode == "2":
        total_n = 0
        npak = 0
        nasset = 0
        npak_fail = 0
        problems = []
        proc_problems = []
        processed = []
        asset_rows = []
        unpack_rows = []
        unpack_outputs = []
        unpack_elapsed = 0.0
        proc_rows = []
        proc_outputs = []
        proc_total = 0
        proc_elapsed = 0.0
        _show_context(
            _PakName(items[0]), [_PakName(x) for x in items[1:]],
            title="UNPACK ALL", mode="all", output="RESULT/extracted",
            limit=len(items))
        for item_no, f in enumerate(items, 1):
            _LIVE_CONTEXT = []
            if _is_pak(f):
                out = _unique_out_dir(ikram.RESULT / "extracted" / f.stem)
                unpack_stats = _empty_unpack_stats()
                n, kind = _unpack_one(f, out, box=False, problems=problems,
                                      show_context=False, stats=unpack_stats)
                if n == 0:
                    # Counted as FAILED, not as "unpacked": an unsupported or
                    # encrypted pak used to be added to npak before the check,
                    # so the summary claimed "2 pak(s) unpacked" when only one
                    # pak actually produced files.
                    npak_fail += 1
                else:
                    total_n += n
                    npak += 1
                    unpack_rows.extend(unpack_stats.get("file_rows") or ())
                    unpack_outputs.append(str(out))
                    unpack_elapsed += float(unpack_stats.get("elapsed") or 0.0)
                    proc = _auto_process_tree(out)
                    if proc:
                        proc_rows.extend(proc.get("file_rows") or ())
                        proc_outputs.append(str(proc["output"]))
                        proc_total += int(proc.get("files") or 0)
                        proc_elapsed += float(proc.get("elapsed") or 0.0)
                        _emit_processed_detail(f, proc)
                        processed.append("%s: %d processed -> %s (%d error)"
                                         % (f.name, proc["files"], proc["output"],
                                            proc["errors"]))
                        if proc.get("errors"):
                            proc_problems.append(
                                "%s: %d file(s) could not be processed"
                                % (f.name, int(proc["errors"])))
                    _emit_unpacked_detail(f, out, unpack_stats, n)
            else:
                try:
                    t0 = time.monotonic()
                    info = _process_standalone(f)
                    elapsed = max(0.0, time.monotonic() - t0)
                    nasset += 1
                    try:
                        raw_size = Path(f).stat().st_size
                    except OSError as _ikram_exc:
                        ikram_logger.log_exc("ikram_patch.pak_extract:raw_stat", _ikram_exc)
                        raw_size = 0
                    unpack_rows.append("{}  ({} bytes)".format(Path(f).name, raw_size))
                    unpack_outputs.append(str(info["raw"]))
                    proc_dir = Path(info["processed"])
                    made = [p for p in sorted(proc_dir.rglob("*"))
                            if p.is_file()
                            and not _paths.is_internal_rel(p.relative_to(proc_dir))]
                    if info.get("error"):
                        proc_problems.append(
                            "{}: {}".format(f.name, str(info["error"])[:96]))
                    asset_proc_rows = []
                    for p in made:
                        try:
                            made_size = p.stat().st_size
                        except OSError as _ikram_exc:
                            ikram_logger.log_exc("ikram_patch.pak_extract:proc_stat", _ikram_exc)
                            made_size = 0
                        asset_proc_rows.append("{}  ({} bytes)".format(
                            p.relative_to(proc_dir).as_posix(), made_size))
                    proc_rows.extend(asset_proc_rows)
                    proc_outputs.append(str(proc_dir))
                    asset_proc_count = len(made)
                    proc_total += asset_proc_count
                    asset_rows.append("{}: raw {} / processed {}".format(
                        f.name, info["raw"], info["processed"]))
                    _emit_unpacked_detail(
                        f, str(info["raw"]),
                        {"file_rows": unpack_rows[-1:], "elapsed": elapsed}, 1)
                    _emit_processed_detail(
                        f, {"output": str(proc_dir), "files": asset_proc_count,
                            "file_rows": asset_proc_rows, "elapsed": elapsed,
                            "errors": 1 if info.get("error") else 0})
                except Exception as e:
                    ikram_logger.log_exc("ikram_patch.pak_extract:439", e)
                    problems.append("{}: {}".format(f.name, str(e)[:96]))
        if total_n + nasset > 0:
            vip = _vip_ref()
            if vip is not None:
                # Every successful pak already emitted its own UNPACKED and
                # PROCESSED boxes in order. Only real failures need one more
                # box; a second summary would duplicate the numbered rows.
                failures = list(problems) + list(proc_problems)
                if failures:
                    shown = failures[:6]
                    lines = shown + (["... +%d more (see error.log)"
                                      % (len(failures) - 6)]
                                     if len(failures) > 6 else [])
                    vip.error_box(lines)
            else:
                notes = ""
                if problems:
                    shown = problems[:4]
                    notes = "\n\n" + "\n".join("· " + line for line in shown)
                    if len(problems) > len(shown):
                        notes += "\n· ... +%d more (see log)" % (len(problems) - len(shown))
                if proc_problems:
                    shown_w = proc_problems[:4]
                    notes += "\n\n" + "\n".join("! " + line for line in shown_w)
                    if len(proc_problems) > len(shown_w):
                        notes += "\n! ... +%d more (see error.log)" % (
                            len(proc_problems) - len(shown_w))
                if processed:
                    shown_p = processed[:3]
                    notes += "\n\n" + "\n".join("· " + line for line in shown_p)
                    if len(processed) > len(shown_p):
                        notes += "\n· ... +%d more" % (len(processed) - len(shown_p))
                if asset_rows:
                    shown_a = asset_rows[:3]
                    notes += "\n\n" + "\n".join("· " + line for line in shown_a)
                    if len(asset_rows) > len(shown_a):
                        notes += "\n· ... +%d more" % (len(asset_rows) - len(shown_a))
                msg = "✔ Total: {} pak(s) unpacked ({} files) + {} asset file(s) processed".format(
                    npak, total_n, nasset
                )
                if npak_fail:
                    msg += "  [bold {}]({} pak(s) produced 0 files)[/]".format(
                        ikram.WARN, npak_fail
                    )
                ikram.show_success(msg + notes)
        else:
            ikram.show_error(
                "No files were extracted. The pak may be encrypted or "
                "not supported."
            )
        ikram.pause()
        return

    ikram.invalid_choice()
    ikram.pause()


def _finish_report(pakf, n, kind, out, processed=None, unpack=None):
    if n == 0 and _PAK_BOX_SHOWN:
        return
    if n == 0:
        ikram.show_error(
            "{}: no files extracted. The pak may be encrypted or "
            "not supported.".format(pakf.name)
        )
        return
    unpack = unpack or _empty_unpack_stats()
    vip = _vip_ref()
    if vip is not None:
        _emit_unpacked_detail(pakf, out, unpack, n)
        if processed:
            _emit_processed_detail(pakf, processed)
        return
    lines = ["✔ {} files unpacked -> {}".format(n, out)]
    if processed:
        lines.append("{} file(s) processed -> {}".format(
            processed["files"], processed["output"]))
        if processed.get("stats"):
            lines.append("Types: " + processed["stats"])
        if processed.get("errors"):
            lines.append("{} processing error(s) (see error.log)".format(
                processed["errors"]))
    ikram.show_success("\n".join(lines))


_compiled_pak_inject = ikram.pak_inject
_compiled_inject_working_bytes = getattr(ikram, "_inject_working_bytes", None)
_show_success_original = None


def _inject_filename_error(f):
    """Reject names the pak writer cannot round-trip as UTF-8 text."""
    try:
        str(Path(f).name).encode("utf-8")
    except UnicodeEncodeError:
        return "filename uses an unsupported encoding"
    return None


def _inject_working_bytes(f):
    """Keep the compiled byte contract, record only the chosen label."""
    if _compiled_inject_working_bytes is None:
        raise RuntimeError("_inject_working_bytes is unavailable in ikram.pyc")
    prepared = _compiled_inject_working_bytes(f)
    try:
        data, label = prepared
        _inject_diag.record_working_file(f, label, data)
    except Exception:
        pass
    return prepared


if _compiled_inject_working_bytes is not None:
    ikram._inject_working_bytes = _inject_working_bytes


def _install_inject_result_shim():
    """Consume the read-only diagnosis without adding UI noise."""
    global _show_success_original
    if _show_success_original is not None:
        return
    original = getattr(ikram, "show_success", None)
    if original is None:
        return
    _show_success_original = original

    def _show_success(msg, *args, **kwargs):
        text = str(msg)
        if text.startswith("Done: ") and " files injected (game-ready)" in text:
            try:
                _inject_diag.finish()
            except Exception as _ikram_exc:
                ikram_logger.log_exc("ikram_patch._show_success:894", _ikram_exc)
        return _show_success_original(text, *args, **kwargs)

    ikram.show_success = _show_success


def _restore_inject_result_shim():
    """Restore the compiled global so no other flow sees the shim."""
    global _show_success_original
    if _show_success_original is None:
        return
    try:
        if getattr(ikram, "show_success", None) is not None:
            ikram.show_success = _show_success_original
    finally:
        _show_success_original = None


def _boxed_pick_match(matches, f):
    rows = ["{} = {}".format(i, m) for i, m in enumerate(matches, 1)]
    ans = _ask_boxed("PAK PATH", "Several paths match:",
                     rows, main=f.name)
    if not ans:
        if _consume_eof():
            return _EOF_CHOICE
        return matches[0]
    try:
        i = int(ans.strip()) - 1
    except ValueError:
        return None
    return matches[i] if 0 <= i < len(matches) else None


def _boxed_resolve_inject_path(f, pakf, kind, paths, folders):
    """Resolve one target. Returns (path, is_new), EOF, skip, or None cancel.

    Skips carry their reason so the caller can report every skipped file in the
    single result panel instead of stacking error panels above that panel.
    """
    name_map = _pak_name_map(paths)
    matches = list(name_map.get(f.name.lower(), ()))
    suggestion = matches[0] if matches else None
    existing_low = set(_canonical_path_map(paths))
    rows = []
    if suggestion:
        rows.append("auto -> " + suggestion)
    else:
        rows.append("{} not found in this pak".format(f.name))
    rows.append("ENTER = auto | number = folder | path = full path")
    for i, folder in enumerate(folders, 1):
        rows.append("{} = {}".format(i, folder))
    answer = _ask_boxed("WHERE TO PUT FILE", "Choose target path:",
                        rows, main=f.name)
    inp = str(answer or "").strip()
    if not inp:
        if _consume_eof():
            return _EOF_CHOICE
        inp = ""
    if inp.isdigit():
        try:
            i = int(inp)
        except (TypeError, ValueError):
            return (_INJECT_SKIP, "Invalid folder number ({})".format(inp))
        if 1 <= i <= len(folders):
            target = _canonical_inject_target(
                "{}/{}".format(folders[i - 1], f.name), paths)
            if target is None:
                return (_INJECT_SKIP, "Invalid folder number ({})".format(inp))
            return target, target.lower() not in existing_low
        return (_INJECT_SKIP, "Invalid folder number ({})".format(inp))
    if inp:
        typed = _canonical_inject_target(inp, paths)
        if typed is None:
            return (_INJECT_SKIP, "Invalid target path for {}".format(f.name))
        if typed.lower() in existing_low:
            return typed, False
        last = typed.split("/")[-1]
        target = typed if last == f.name or "." in last else \
            _canonical_inject_target("{}/{}".format(typed, f.name), paths)
        if target is None:
            return (_INJECT_SKIP, "Invalid target path for {}".format(f.name))
        return target, target.lower() not in existing_low
    if len(matches) == 1:
        target = _canonical_inject_target(matches[0], paths)
        return (target, False) if target else (_INJECT_SKIP, "Invalid pak path")
    if len(matches) > 1:
        chosen = _boxed_pick_match(matches, f)
        if chosen is _EOF_CHOICE:
            return _EOF_CHOICE
        if chosen:
            target = _canonical_inject_target(chosen, paths)
            return (target, False) if target else (_INJECT_SKIP, "Invalid pak path")
        return None
    if not folders:
        return (_INJECT_SKIP, "No folders exist in this pak")
    rows = ["{} = {}".format(i, x) for i, x in enumerate(folders, 1)]
    ans = _ask_boxed("PAK FOLDER", "Choose a folder for {}:".format(f.name),
                     rows, main=f.name)
    if not ans:
        if _consume_eof():
            return _EOF_CHOICE
        return None
    try:
        i = int(str(ans).strip()) - 1
    except ValueError:
        return (_INJECT_SKIP, "Invalid folder number")
    if not (0 <= i < len(folders)):
        return (_INJECT_SKIP, "Invalid folder number")
    target = _canonical_inject_target(
        "{}/{}".format(folders[i], f.name), paths)
    if target is None:
        return (_INJECT_SKIP, "Invalid folder number")
    return target, target.lower() not in existing_low


def _inject_tencent_only(pakf, kind):
    """One actionable refusal for any non-Tencent inject path."""
    ikram.show_error(
        "Inject works on Tencent paks only.\n"
        '"{}" is a {} pak, and the writer this option uses reads a Tencent\n'
        "index, so it cannot open this archive.\n\n"
        "For a UE4 pak use Unpack -> edit -> Repack instead.".format(
            _PakName(pakf), str(kind or "unknown").upper()
        )
    )


def _inject_skip_rows(skips, limit=12):
    rows = ["  {}: {}".format(label, reason) for label, reason in skips[:limit]]
    if len(skips) > limit:
        rows.append("  ... and {} more".format(len(skips) - limit))
    return rows


def _inject_result_message(out, injected, skips):
    """One panel: one count, one Output row, optional consolidated skips."""
    msg = "Done: {} files injected (game-ready)\nOutput: {}".format(injected, out)
    if skips:
        msg += "\nSkipped {} file(s):".format(len(skips))
        msg += "\n" + "\n".join(_inject_skip_rows(skips))
    return msg


def _inject_nothing_message(skips):
    """One panel for a run that applied no edits, listing every reason once."""
    msg = "Nothing injected — no file could be applied."
    if skips:
        msg += "\n\nSkipped {} file(s):".format(len(skips))
        msg += "\n" + "\n".join(_inject_skip_rows(skips))
    return msg


def _inject_resolve_result(res, f, placed, skips):
    """Consume one target resolver result without stacking error panels."""
    if res is _EOF_CHOICE:
        return "eof"
    if res is None:
        return "cancel"
    if isinstance(res, tuple) and res and res[0] is _INJECT_SKIP:
        skips.append((f.name, str(res[1])))
        return "skip"
    if not isinstance(res, tuple) or len(res) != 2:
        skips.append((f.name, "invalid target"))
        return "skip"
    target, is_new = res
    if not target:
        skips.append((f.name, "invalid target"))
        return "skip"
    placed.append((f, target, is_new))
    return "ok"


def pak_inject():
    """INJECT FILE — choose main PAK, then mode, then files, all in one box
    language. Writer inputs stay byte-identical; only prompts/telemetry move."""
    _inject_diag.begin()
    _install_inject_result_shim()
    skips = []
    try:
        items = sorted(Path(ikram.DROP_INJ).rglob("*"))
        items = [p for p in items if p.is_file()
                 and not _paths.is_internal_rel(
                     p.relative_to(Path(ikram.DROP_INJ)))]
        if not items:
            ikram.show_error(
                "No files found in DROP/inject.\n"
                "Add the files you want to inject there, then try again.\n"
                "DROP/inject: {}".format(ikram.DROP_INJ))
            ikram.pause()
            return None
        paks = [p for p in ikram.drop_files(ikram.DROP_PAK, [".pak"])
                if not _paths.is_internal_rel(
                    Path(p).relative_to(Path(ikram.DROP_PAK)))]
        if not paks:
            ikram.show_error(
                "The pak folder is empty.\n"
                "Add your .pak file to DROP/pak and try again."
            )
            ikram.pause()
            return None
        raw_mode = _ask_boxed(
            "INJECT MODE",
            "Choose mode:",
            [_tint("1 = one file", "success"),
             _tint("ENTER = all files", "accent"),
             _tint("0 = cancel", "error")],
            main="INJECT MODE",
        )
        if _consume_eof():
            return _inject_abort()
        mode = str(raw_mode or "").strip()
        if mode == "0":
            return _inject_abort()
        if mode not in ("", "1"):
            ikram.show_error(
                "Invalid option — choose 1 = one file, ENTER = all files, "
                "or 0 = cancel."
            )
            ikram.pause()
            return None
        pi = _choose_pak_index(
            len(paks), paks, "INJECT PAK",
            question="Choose target pak:", main="CHOOSE PAK")
        if pi is _EOF_CHOICE or pi is None:
            return _inject_abort()
        pakf = paks[pi] if pi else paks[0]
        kind = ikram.detect_pak_type(pakf)
        if kind == "ue4":
            _inject_tencent_only(pakf, kind)
            ikram.pause()
            return None
        if kind not in ("tencent",):
            _pak_problem_box(pakf, kind, "This pak is not supported.")
            ikram.pause()
            return None
        paths = ikram._pak_paths(pakf, kind)
        if not paths:
            ikram.show_error(
                "This pak has no file entries. Inject needs a pak with an "
                "index template.\nUse a folder-based Custom Pak or another pak."
            )
            ikram.pause()
            return None
        folders = [x for x in ikram._unique_folders(paths)
                   if not str(x).lower().endswith(".txt")]
        name_map = _pak_name_map(paths)
        canonical_map = _canonical_path_map(paths)
        _show_context(_PakName(pakf), [p.name for p in items],
                      title="INJECT FILES", mode=kind,
                      target="DROP/inject", output="RESULT/injected",
                      limit=len(items))
        placed = []
        if mode == "1":
            fi = _choose_pak_index(
                len(items), items, "INJECT ONE",
                question="Choose file to inject:", main="CHOOSE FILE")
            if fi is _EOF_CHOICE or fi is None:
                return _inject_abort()
            f = items[fi] if fi else items[0]
            name_error = _inject_filename_error(f)
            if name_error:
                skips.append((f.name, name_error))
            else:
                outcome = _inject_resolve_result(
                    _boxed_resolve_inject_path(f, pakf, kind, paths, folders),
                    f, placed, skips)
                if outcome in ("eof", "cancel"):
                    return _inject_abort()
        else:
            for f in items:
                name_error = _inject_filename_error(f)
                if name_error:
                    skips.append((f.name, name_error))
                    continue
                matches = list(name_map.get(f.name.lower(), ()))
                if len(matches) == 1:
                    target = canonical_map.get(
                        _normalized_pak_path(matches[0]).lower(),
                        _normalized_pak_path(matches[0]))
                    if target:
                        placed.append((f, target, False))
                    else:
                        skips.append((f.name, "invalid pak path"))
                elif len(matches) > 1:
                    chosen = _boxed_pick_match(matches, f)
                    if chosen is _EOF_CHOICE:
                        return _inject_abort()
                    if chosen:
                        target = canonical_map.get(
                            _normalized_pak_path(chosen).lower(),
                            _normalized_pak_path(chosen))
                        if target:
                            placed.append((f, target, False))
                        else:
                            skips.append((f.name, "invalid pak path"))
                    else:
                        skips.append((f.name, "cancelled at path prompt"))
                else:
                    outcome = _inject_resolve_result(
                        _boxed_resolve_inject_path(f, pakf, kind, paths, folders),
                        f, placed, skips)
                    if outcome == "eof":
                        return _inject_abort()
        prep = []
        for f, target, _is_new in placed:
            try:
                data, label = ikram._inject_working_bytes(f)
            except Exception as exc:
                ikram_logger.log_exc("ikram_patch.pak_inject:prepare", exc)
                skips.append((f.name, str(exc) or "could not be prepared"))
                continue
            if data is None:
                skips.append((f.name, str(label or "could not be prepared")))
                continue
            prep.append((f, target, data, label))
        if not prep:
            ikram.show_error(_inject_nothing_message(skips))
            ikram.pause()
            return None
        # Two selected files can resolve to one pak path (same name under two
        # folders, or a case variant). The writer's last-write-wins rule still
        # applies, but the panel must count edits actually applied, not every
        # selected file or every entry in the finished pak.
        unique = {}
        for row in prep:
            unique[str(row[1]).strip("/").lower()] = row
        prep = list(unique.values())
        out = str(ikram.RESULT / "injected" / Path(pakf).name)
        try:
            ui = _boxed_progress("INJECTING")
            with ui:
                applied = _inject_many_into_pak(
                    pakf, [(t, d) for _f, t, d, _l in prep], ui)
            if applied == 0:
                raise RuntimeError(
                    "Inject applied 0 files - the writer refused this pak "
                    "or the target list was empty")
        except Exception as e:
            ikram_logger.log_exc("ikram_patch.pak_inject:write", e)
            _show_handler_error(e)
            ikram.pause()
            return None
        ikram.show_success(_inject_result_message(out, len(prep), skips))
        ikram.pause()
        return None
    finally:
        _restore_inject_result_shim()
        _inject_diag.end()


_compiled_inject_many = ikram._inject_many_into_pak


def _pak_base_name(name):
    """Strip the tool's "(1)/(2)" version suffix from a pak file name."""
    return re.sub(r"\s+\(\d+\)(?=\.[^.]+$)", "", str(name), flags=re.I)


def _reference_pak_candidates(pakf):
    """Original paks that can explain a Custom pak built from the same name."""
    target = Path(pakf)
    try:
        target_resolved = target.resolve()
    except OSError:
        target_resolved = target.absolute()
    want = _pak_base_name(target.name).lower()
    bases = [
        Path(ikram.DROP_PAK),
        Path(ikram.DROP_PAK).parent / "Paks",
        _TOOL_DIR.parent / "Paks",
        _TOOL_DIR / "Paks",
        _TOOL_DIR.parent / "ORGINAL-PAKS",
    ]
    seen = set()
    out = []
    for base in bases:
        try:
            if not base.is_dir():
                continue
            walker = base.rglob("*.pak") if base.name.lower() == "orginal-paks" \
                else base.glob("*.pak")
            for f in walker:
                key = str(f).lower()
                if key in seen:
                    continue
                seen.add(key)
                try:
                    if f.resolve() == target_resolved:
                        continue
                except OSError:
                    continue
                if f.name.lower() == want or _pak_base_name(f.name).lower() == want:
                    out.append(f)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._reference_pak_candidates", _ikram_exc)
            continue
    return out


def _reference_original(pakf, mount, version, edits):
    """Find a real pak that shares the Custom pak's mount, version and paths.

    A Custom pak stores empty bodies, so it cannot preserve the original SM4
    metadata by itself. When the original pak is still in DROP/pak (or in the
    corpus beside the tool), injecting into a Custom copy writes through THAT
    pak. Unchanged entries are then copied byte-for-byte and changed entries
    inherit the original cm/em convention instead of being rebuilt from empty
    template entries.
    """
    wanted = {str(t).strip("/").lower() for t, _ in edits}
    best = None
    best_rank = (-1, -1)
    for candidate in _reference_pak_candidates(pakf):
        try:
            with _engines.pakmod().PakReader(candidate) as ref:
                ref_mount = str(getattr(ref, "mount_point", "") or "")
                ref_version = int(getattr(ref, "version", 0)
                                  or getattr(ref, "version_num", 0) or 0)
                if ref_mount != mount or (version and ref_version != version):
                    continue
                if not any(int(getattr(e, "size", 0) or 0) > 0
                           for e in ref.files):
                    # A Custom pak has the same name and mount but zero bodies.
                    # It cannot supply original metadata or SM4 bytes.
                    continue
                paths = {str(p).strip("/").lower() for p in ref.full_paths()}
                score = len(wanted & paths)
                exact = 1 if candidate.name.lower() == \
                    _pak_base_name(Path(pakf).name).lower() else 0
                rank = (score, exact)
                if rank > best_rank:
                    best, best_rank = candidate, rank
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._reference_original", _ikram_exc)
            continue
    return best


def _inject_many_into_pak(pakf, edits, ui=None):
    """Never clobber a previous inject result.

    The compiled writer emits RESULT/injected/<pak name> unconditionally, so a
    second inject into the same pak silently OVERWROTE the first run's pak —
    a finished 4-file mod pak was replaced by a 1-file one with no warning and
    no "(1)" suffix. Relocate any existing output first (same _unique_out_file
    rule Unpack/Repack use) so every run is kept.

    Also refuses non-Tencent paks up front. The writer this path uses is
    pak.pyc's PakWriter, which is built on the Tencent PakReader; handed a UE4
    archive it raised deep inside the compiled reader, the wizard swallowed it,
    printed the "N FILE(S) READY" screen and then returned to the menu having
    written NOTHING -- no output pak, no error, no log line. Silent no-op on a
    main feature. Now it says why and what to use instead.
    """
    try:
        _kind = _engines.detect_kind(pakf)
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._inject_many_into_pak:kind", _ikram_exc)
        _kind = None
    if _kind and _kind != "tencent":
        _inject_diag.set_branch("refused/non-tencent")
        ikram.show_error(
            "Inject works on Tencent paks only.\n"
            '"{}" is a {} pak, and the writer this option uses reads a Tencent\n'
            "index, so it cannot open this archive.\n\n"
            "For a UE4 pak use Unpack -> edit -> Repack instead.".format(
                _PakName(pakf), _kind.upper()
            )
        )
        return 0
    out_dir = ikram.RESULT / "injected"
    out_dir.mkdir(parents=True, exist_ok=True)
    try:
        existing = out_dir / Path(pakf).name
        if existing.exists():
            keep = _unique_out_file(existing)
            existing.rename(keep)
            ikram.console.print(
                "[bold {}]-> previous result kept ->[/] [bold {}]{}[/]".format(
                    ikram.MUTED, ikram.WARN, keep.name
                )
            )
    except Exception as _ikram_exc:
        # A failed relocate must never block the inject itself.
        ikram_logger.log_exc("ikram_patch._inject_many_into_pak:relocate", _ikram_exc)

    # The wizard's WHERE prompt accepts full game paths.  The pak index is
    # mount-relative, so a pasted "ShadowTrackerExtra/Content/..." would embed
    # the mount leaf twice and the game would never load the file.  Strip that
    # one component from Inject inputs only; Repack's extracted tree keeps its
    # own path handling.
    mount = ""
    version = 0
    source_paths = set()
    try:
        with _engines.pakmod().PakReader(str(pakf)) as _r:
            mount = str(getattr(_r, "mount_point", "") or "")
            version = int(getattr(_r, "version", 0)
                          or getattr(_r, "version_num", 0) or 0)
            source_paths = {str(p).replace("\\", "/").strip("/").lower()
                            for p in _r.full_paths()}
        _leaf = mount.rstrip("/").rsplit("/", 1)[-1] if mount else ""
        if _leaf:
            _norm = []
            for _raw, _body in edits:
                _p = str(_raw).replace("\\", "/")
                while _p.startswith("./"):
                    _p = _p[2:]
                _p = _p.lstrip("/")
                if _p == _leaf:
                    _p = ""
                elif _p.startswith(_leaf + "/"):
                    _p = _p[len(_leaf) + 1:]
                _norm.append((_p, _body))
            edits = _norm
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._inject_many_into_pak:normalize", _ikram_exc)

    _inject_diag.set_context(pakf, edits, source_paths)

    # A Custom pak stores the original file names but zero bodies.  Writing
    # through it would re-encode every SM4 entry as simple2.  When the original
    # pak is available, write through that instead: unchanged bodies stay
    # byte-identical, changed bodies inherit the original convention, and a
    # no-op inject of every extracted file reproduces the source pak exactly.
    ref = _reference_original(pakf, mount, version, edits)
    if ref is not None:
        try:
            pm = _engines.pakmod()
            with pm.PakReader(ref) as rp:
                full = list(rp.full_paths())
                existing_map = {
                    str(p).strip("/").replace("\\", "/").lower():
                    str(p).strip("/").replace("\\", "/")
                    for p in full
                }
                existing = set(existing_map)

                def _canon_target(t):
                    key = str(t).strip("/").replace("\\", "/").lower()
                    return existing_map.get(key, str(t).strip("/").replace("\\", "/"))

                force = not all(
                    str(t).strip("/").lower() in existing for t, _ in edits)
                writer_edits = [
                    (_canon_target(t), (d, None, Path(_canon_target(t)).stem))
                    for t, d in edits
                ]
                progress = getattr(ui, "progress", None) if ui is not None else None
                on_file = getattr(ui, "on_file", None) if ui is not None else None
                _inject_diag.set_branch("tencent_pak(reference)")
                return pm.PakWriter(rp).inject_files(
                    writer_edits, str(out_dir / Path(pakf).name),
                    force_add=force, target_path="/",
                    progress=progress, on_file=on_file)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._inject_many_into_pak:reference", _ikram_exc)
    _inject_diag.set_branch("compiled fallback")
    if ui is None:
        class _NullProgress:
            def progress(self, *a, **k):
                pass

            def on_file(self, *a, **k):
                pass

        ui = _NullProgress()
    return _compiled_inject_many(pakf, edits, ui)


def pak_repack_folder():
    pakf = ensure_input_folder()
    if not pakf:
        return
    edit_dir = ikram.RESULT / "extracted" / pakf.stem
    if not edit_dir.is_dir():
        # Unpack uniquifies repeat runs, so a second unpack lands in
        # extracted/<stem> (1). Repacking hardcoded extracted/<stem> would
        # silently rebuild the STALE first tree while the user edits the new
        # one. Fall back to the newest sibling and say which folder is used.
        pat = re.compile(re.escape(pakf.stem) + r" \((\d+)\)$")
        sibs = []
        for p in edit_dir.parent.glob(pakf.stem + " (*)"):
            m = pat.fullmatch(p.name)
            if p.is_dir() and m:
                sibs.append((int(m.group(1)), p))
        if sibs:
            sibs.sort(key=lambda item: item[0])
            if len(sibs) == 1:
                rows = ["Use: " + sibs[0][1].name,
                        "ENTER = use this folder | 0 = cancel"]
                ans = _ask_boxed(
                    "EXTRACTED FOLDER",
                    "Exact folder is missing. Use this extracted folder?",
                    rows, main=_PakName(pakf))
                inp = str(ans or "").strip().lower()
                if _consume_eof():
                    ikram.show_error("Repack cancelled.")
                    ikram.pause()
                    return
                if inp in ("0", "n", "no"):
                    ikram.show_error("Repack cancelled.")
                    ikram.pause()
                    return
                if inp not in ("", "1", "y", "yes"):
                    ikram.show_error("Invalid folder choice.")
                    ikram.pause()
                    return
                edit_dir = sibs[0][1]
            else:
                rows = ["{} = {}".format(i, p.name)
                        for i, (_num, p) in enumerate(sibs, 1)]
                rows.append("ENTER = 1 | 0 = cancel")
                ans = _ask_boxed(
                    "EXTRACTED FOLDER",
                    "Exact folder is missing. Choose the edited folder:",
                    rows, main=_PakName(pakf))
                inp = str(ans or "").strip().lower()
                if _consume_eof():
                    ikram.show_error("Repack cancelled.")
                    ikram.pause()
                    return
                if inp in ("0", "n", "no"):
                    ikram.show_error("Repack cancelled.")
                    ikram.pause()
                    return
                try:
                    idx = 0 if not inp else int(inp) - 1
                except ValueError:
                    idx = -1
                if not (0 <= idx < len(sibs)):
                    ikram.show_error("Invalid folder choice.")
                    ikram.pause()
                    return
                edit_dir = sibs[idx][1]
        else:
            ikram.show_error(
                "Extracted folder not found: RESULT/extracted/{}\n"
                "First UNPACK this pak, then REPACK it.".format(pakf.stem)
            )
            ikram.pause()
            return
    stale = _stale_source_message(pakf, edit_dir)
    if stale:
        ikram.show_error(stale)
        ikram.pause()
        return
    out_dir = ikram.RESULT / "Repacked"
    out_dir.mkdir(parents=True, exist_ok=True)
    # Never clobber a previous repack. This used to be a bare
    # `if out.exists(): out.unlink()`, so repacking the same pak twice threw
    # away the first result with no warning and no "(1)" — the same
    # silent-overwrite bug the Unpack processed/ tree and the Inject result
    # had. Unpack -> edit -> repack -> edit -> repack is a normal loop, so the
    # earlier build has to survive. Same _unique_out_file rule as Custom pak.
    out = _unique_out_file(out_dir / "{}.pak".format(pakf.stem))
    try:
        kind = ikram.detect_pak_type(pakf)
        files = sorted(p.relative_to(edit_dir).as_posix()
                       for p in edit_dir.rglob("*")
                       if p.is_file()
                       and not _paths.is_internal_rel(p.relative_to(edit_dir)))
        if not files:
            ikram.show_error(
                "Extracted folder is empty: RESULT/extracted/{}\n"
                "Unpack the pak first, then edit a file before repacking.".format(
                    edit_dir.name)
            )
            ikram.pause()
            return
        _show_context(_PakName(pakf), files, title="REPACK FILES",
                      mode=kind, target="RESULT/extracted/" + edit_dir.name,
                      output=str(out), limit=12)
        aes_key = None
        if kind == "ue4":
            key = _ask_boxed(
                "UE4 AES KEY",
                "AES key for {} (ENTER = default, 0 = cancel):".format(_PakName(pakf)),
                ["ENTER = built-in default", "0 = cancel"], main=_PakName(pakf),
                fallback="  [bold {}]-> {} AES key (ENTER = default, 0 = cancel): [/]".format(
                    ikram.INP, pakf.name),
            )
            if ikram.eof_exit() or (key and key.strip() == "0"):
                ikram.show_error("Cancelled — nothing repacked.")
                ikram.pause()
                return
            key = (key.strip() if key and key.strip() else "")
            aes_key = key or None
        log = (lambda *a, **k: None) if _vip_ref() is not None else ikram.console.print
        n = _engines.repack_folder(pakf, edit_dir, out, kind=kind, aes_key=aes_key,
                                   log=log)
        # Double-repack fix: older releases wrote the result to the lowercase
        # RESULT/repacked/ twin; on case-sensitive Android both then coexist
        # ("Result/ shows TWO repacked files"). Purge the legacy twin so one
        # repack == exactly one output. Guarded: on Windows/macOS 'repacked'
        # IS 'Repacked', so an unguarded unlink here deleted the pak that was
        # written one line above.
        _legacy_dir = _legacy_repacked_dir()
        if _legacy_dir is not None:
            _legacy = _legacy_dir / "{}.pak".format(pakf.stem)
            if _legacy.exists():
                try:
                    _legacy.unlink()
                except OSError as _ikram_exc:
                    ikram_logger.log_exc("ikram_patch.pak_repack_folder:557", _ikram_exc)
                    pass
        _purge_legacy_repacked_folders()
        ikram.show_success("{} files repacked -> {}".format(n, out))
    except Exception as e:
        ikram_logger.log_exc("ikram_patch.pak_repack_folder:562", e)
        _show_handler_error(e)
    ikram.pause()


def _chain_dirs(target):
    """Target rel-dir se full ancestor chain — har level mount-relative,
    trailing '/' ke saath (PakWriter index format).
    'ShadowTrackerExtra/Content/Lua' -> ['ShadowTrackerExtra/',
    'ShadowTrackerExtra/Content/', 'ShadowTrackerExtra/Content/Lua/']"""
    parts = [p for p in str(target).replace("\\", "/").split("/") if p]
    return ["/".join(parts[:i]) + "/" for i in range(1, len(parts) + 1)]


def _sanitize_custom_path(p, mount):
    """Custom path — resolved under the auto source-mount.
    If the mount already ends with 'ShadowTrackerExtra' (e.g.
    '../../../ShadowTrackerExtra/'), the path stays under it,
    otherwise the 'ShadowTrackerExtra/' prefix is added automatically.
    'Content/Lua/...' never creates a doubled ShadowTrackerExtra."""
    import ntpath
    raw = str(p).strip().strip("'\"`")
    # Root-anchored, UNC and drive-qualified pastes are not pak-internal paths.
    if raw.startswith(("/", "\\")) or ntpath.splitdrive(
            raw.replace("/", "\\"))[0]:
        return None
    s = raw.replace("\\", "/")
    segs = s.split("/")
    # ../../../ShadowTrackerExtra/... is a common paste from extracted
    # trees. Drop only leading parent hops, then refuse real traversal.
    while segs and segs[0] == "..":
        segs.pop(0)
    if ".." in segs:
        return None
    parts = [seg for seg in segs if seg and seg != "."]
    if not parts:
        return None
    mount_has_st = any(
        seg.lower() in ("shadowtracker", "shadowtrackerextra")
        for seg in str(mount).replace("\\", "/").split("/")
    )
    # A pasted extracted path can repeat the mount leaf several times, and a
    # drive-qualified paste can hide it after "C:". The mount supplies that
    # component already; leaving extra copies creates unreachable index paths.
    while parts and parts[0].lower() in ("shadowtracker", "shadowtrackerextra"):
        parts.pop(0)
    if not parts:
        return None
    if any(":" in seg for seg in parts):
        return None
    _reserved = {
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5",
        "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5",
        "LPT6", "LPT7", "LPT8", "LPT9",
    }
    if any(seg.split(".")[0].upper() in _reserved for seg in parts):
        return None
    if mount_has_st and any(
            seg.lower() in ("shadowtracker", "shadowtrackerextra")
            for seg in parts):
        return None
    if mount_has_st:
        return "/".join(parts)
    return "ShadowTrackerExtra/" + "/".join(parts)


def _pick_folders(pakf):
    """All FOLDER paths inside the pak — choose by number, 0 = cancel,
    or type your own path (auto under ShadowTrackerExtra).
    Returns (mount-relative target dir, exists_in_source), or None on cancel."""
    with _engines.pakmod().PakReader(pakf) as r:
        mount = r.mount_point
        all_paths = [k.rstrip("/") for k in r.dirs if k.strip("/")]
        file_map = r.full_paths()
    paths = [p for p in all_paths if p]
    if not paths and not file_map:
        ikram.show_error(
            "No folders inside this pak — can't build a structure pak."
        )
        ikram.pause()
        return None
    boxed = _vip_ref() is not None
    if not boxed:
        t = ikram.Table(
            box=ikram.ROUNDED, show_header=False, pad_edge=False,
            border_style=ikram.BORDER, style="on {}".format(ikram.BG_DEEP),
        )
        t.add_column(justify="right", width=4)
        t.add_column(style="bright_white")
        for i, p in enumerate(paths, 1):
            t.add_row("[{}]{}[/]".format(_vip_num(i % 10), i), p)
        ikram.console.print(
            ikram.panel(
                t, title='📦 "{}" — {} folders'.format(pakf.name, len(paths)),
                box=ikram.ROUNDED,
            )
        )
        ikram.console.print(
            "[bold {}]number = choose folder · 0 = cancel · type new path = auto under ShadowTrackerExtra[/bold {}]".format(ikram.MUTED, ikram.MUTED)
        )
    rows = [_tint("{} = {}".format(i, p), "text")
            for i, p in enumerate(paths, 1)]
    rows.append(_tint("ENTER = ALL (skeleton)", "success"))
    rows.append(_tint("0 = cancel", "error"))
    rows.append(_tint("typed path = new folder under ShadowTrackerExtra",
                      "secondary"))
    c = _ask_boxed(
        "Custom Pak TARGET FOLDER",
        "Choose target folder in {}:".format(_PakName(pakf)),
        rows, main=_PakName(pakf),
        fallback="[bold {}]> Select: [/]".format(ikram.INP),
    ).strip()
    if ikram.eof_exit():
        ikram.show_info("Cancelled.")
        ikram.pause()
        return None
    if not c:
        # ENTER (nothing typed) -> FULL SKELETON mode: all folders + all
        # file names, every file EMPTY (engine-valid, for inject-into pak).
        return _SKELETON, False
    if c == "0":
        ikram.show_info("Cancelled.")
        ikram.pause()
        return None
    if c.isdigit():
        try:
            i = int(c)
        except ValueError:
            # Unicode digits pass isdigit() but int() rejects them (e.g. "²").
            ikram.show_error("Invalid number — cancelled.")
            ikram.pause()
            return None
        if 1 <= i <= len(paths):
            return paths[i - 1], True
        ikram.show_error("Invalid number — cancelled.")
        ikram.pause()
        return None
    target = _sanitize_custom_path(c, mount)
    if not target:
        ikram.show_error("Invalid path — cancelled.")
        ikram.pause()
        return None
    exists = target in all_paths
    return target, exists


def _prompt_empty_file_name(target):
    """Target folder not found in source — ask for a name for the empty file.
    '0' or empty = cancel. Path separators / '..' rejected."""
    boxed = _vip_ref() is not None
    if not boxed:
        ikram.console.print(
            "[bold {}]Folder '{}' not found in source pak → an empty file will be created.[/bold {}]".format(
                ikram.WARN, target, ikram.WARN
            )
        )
        ikram.console.print(
            "[bold {}]0 = cancel[/bold {}]".format(ikram.MUTED, ikram.MUTED)
        )
    while True:
        nm = _ask_boxed(
            "EMPTY FILE NAME",
            "Folder '{}' is missing. Name the empty file:".format(target),
            ["basename only", "0 = cancel"], main=str(target),
            fallback="[bold {}]> File name (e.g. Xxx.lua): [/]".format(ikram.INP),
        ).strip()
        if not nm or ikram.eof_exit() or nm == "0":
            return None
        if (
            "/" in nm
            or "\\" in nm
            or ".." in nm
            or nm in (".", "", ".")
            or nm.startswith(".")
        ):
            if not boxed:
                ikram.console.print(
                    "[bold {}]Invalid name — bas file name, no slashes.[/]".format(ikram.WARN)
                )
            continue
        return nm


def _custom_ordinal(n):
    """1st / 2nd / 3rd / 4th / 11th / 21st for FILE MODE prompts."""
    n = int(n)
    if 10 <= (n % 100) <= 20:
        suffix = "th"
    else:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return "{}{}".format(n, suffix)


def _valid_custom_file_name(name):
    """One basename only. No traversal, no drive letters, no control chars."""
    s = str(name or "").strip()
    if not s or s in (".", "..") or s.startswith("."):
        return False
    if "/" in s or "\\" in s or ".." in s or ":" in s:
        return False
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in s):
        return False
    if s.endswith((" ", ".")):
        return False
    if s.split(".")[0].upper() in {
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7",
            "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5",
            "LPT6", "LPT7", "LPT8", "LPT9"}:
        return False
    return True


def _custom_source_index(pakf):
    """Read once: mount, folder paths, file map, and files grouped by folder."""
    with _engines.pakmod().PakReader(pakf) as r:
        mount = r.mount_point
        fp_map = {str(k).replace("\\", "/"): v for k, v in r.full_paths().items()}
        raw_dirs = [str(k) for k in r.dirs]
    paths = set()
    for raw in raw_dirs:
        clean = raw.replace("\\", "/").strip("/")
        if clean:
            paths.add(clean)
    for fp in fp_map:
        parts = [p for p in fp.split("/") if p]
        for i in range(1, len(parts)):
            paths.add("/".join(parts[:i]))
    ordered = sorted(paths)
    lookup = {p.lower(): p for p in ordered}
    files_by_path = {}
    for fp in fp_map:
        folder, _, name = fp.rpartition("/")
        files_by_path.setdefault(folder, []).append(name)
    for folder in files_by_path:
        files_by_path[folder].sort()
    return mount, ordered, lookup, fp_map, files_by_path


def _custom_path_has_files(path, fp_map):
    target = str(path).replace("\\", "/").rstrip("/")
    prefix = (target + "/") if target else ""
    for fp in fp_map:
        if fp == target or (prefix and fp.startswith(prefix)):
            return True
    return False


def _ask_custom_path_mode():
    """PATH MODE box. Returns 'skeleton', a path count, or None on cancel."""
    while True:
        rows = [
            _tint("1 ONLY ONE PATH", "primary"),
            _tint("2 CHOOSE HOW MANY PATHS", "primary"),
            _tint("3 ALL FOLDERS + EMPTY FILES", "success"),
            _tint("ENTER = ALL FOLDERS + EMPTY FILES", "success"),
            _tint("0 = CANCEL", "error"),
        ]
        c = _ask_boxed(
            "PATH MODE", "Choose PATH MODE:", rows,
            main="CUSTOM PAK",
        ).strip()
        if ikram.eof_exit() or c == "0":
            _custom_cancel()
            return None
        if not c or c == "3":
            return "skeleton"
        if c == "1":
            return 1
        if c == "2":
            return _ask_custom_path_count()
        ikram.show_error("Invalid PATH MODE. Choose 1, 2, 3, or 0.")
        ikram.pause()


def _ask_custom_path_count():
    while True:
        rows = [
            _tint("1 .. {}".format(_MAX_CUSTOM_PATHS), "text"),
            _tint("0 = CANCEL", "error"),
        ]
        c = _ask_boxed(
            "PATH COUNT", "How many paths?", rows,
            main="CUSTOM PAK",
        ).strip()
        if ikram.eof_exit() or c == "0":
            _custom_cancel()
            return None
        if c.isdigit():
            try:
                n = int(c)
            except ValueError:
                n = 0
            if 1 <= n <= _MAX_CUSTOM_PATHS:
                return n
        ikram.show_error(
            "Enter a number from 1 to {}.".format(_MAX_CUSTOM_PATHS)
        )
        ikram.pause()


def _ask_custom_path(mount, paths, lookup, files_by_path, ordinal, total):
    """Number = original path. Typed path = original copy or new FILE MODE."""
    for _attempt in range(12):
        rows = []
        for i, p in enumerate(paths, 1):
            n = len(files_by_path.get(p, ()))
            rows.append(_tint("{} = {}  ({} file{})".format(
                i, p, n, "" if n == 1 else "s"), "text"))
        rows.append(_tint("TYPE PATH = use or create this path", "secondary"))
        rows.append(_tint("0 = CANCEL", "error"))
        c = _ask_boxed(
            "PATH {} OF {}".format(ordinal, total),
            "Choose a path number or type a path:",
            rows, main="CUSTOM PAK",
        ).strip()
        if ikram.eof_exit() or c == "0":
            _custom_cancel()
            return None
        if not c:
            ikram.show_error("Type a path or choose a number.")
            ikram.pause()
            continue
        if c.isdigit():
            try:
                i = int(c)
            except ValueError:
                i = 0
            if 1 <= i <= len(paths):
                return paths[i - 1], True
            ikram.show_error("No path with that number. Choose from the box.")
            ikram.pause()
            continue
        target = _sanitize_custom_path(c, mount)
        if not target:
            ikram.show_error("Invalid path. Use a pak-relative folder path.")
            ikram.pause()
            continue
        canonical = lookup.get(target.lower())
        if canonical:
            return canonical, True
        return target, False
    _custom_cancel("Too many invalid path entries. Cancelled.")
    return None


def _ask_custom_file_mode(path):
    """FILE MODE box. Returns file count, or None on cancel."""
    while True:
        rows = [
            _tint("1 ONE FILE", "primary"),
            _tint("2 CHOOSE HOW MANY FILES", "primary"),
            _tint("0 = CANCEL", "error"),
        ]
        c = _ask_boxed(
            "FILE MODE", "Choose FILE MODE for {}:".format(path), rows,
            main="CUSTOM PAK",
        ).strip()
        if ikram.eof_exit() or c == "0":
            _custom_cancel()
            return None
        if c == "1":
            return 1
        if c == "2":
            while True:
                n_raw = _ask_boxed(
                    "FILE COUNT", "How many files for {}?".format(path),
                    [_tint("1 .. {}".format(_MAX_CUSTOM_FILES), "text"),
                     _tint("0 = CANCEL", "error")],
                    main="CUSTOM PAK",
                ).strip()
                if ikram.eof_exit() or n_raw == "0":
                    _custom_cancel()
                    return None
                if n_raw.isdigit():
                    try:
                        n = int(n_raw)
                    except ValueError:
                        n = 0
                    if 1 <= n <= _MAX_CUSTOM_FILES:
                        return n
                ikram.show_error(
                    "Enter a number from 1 to {}.".format(_MAX_CUSTOM_FILES)
                )
                ikram.pause()
        ikram.show_error("Invalid FILE MODE. Choose 1, 2, or 0.")
        ikram.pause()


def _ask_custom_file_names(path, count, existing_names=()):
    """One FILE box per file, labelled 1st file, 2nd file, 3rd file, ..."""
    names = []
    seen = set()
    suggestions = list(existing_names or ())[:12]
    for index in range(1, count + 1):
        label = "{} file".format(_custom_ordinal(index))
        while True:
            rows = [
                _tint("Enter the " + label, "primary"),
                _tint("basename only — no slashes", "dim"),
                _tint("0 = CANCEL", "error"),
            ]
            if suggestions:
                rows.append(_tint("examples: " + ", ".join(suggestions[:6]),
                                  "secondary"))
            if names:
                rows.append(_tint("added: " + ", ".join(names[-4:]), "dim"))
            nm = _ask_boxed(
                "FILE MODE", "{} under {}:".format(label.capitalize(), path),
                rows, main="CUSTOM PAK",
            ).strip()
            if ikram.eof_exit() or nm == "0" or not nm:
                _custom_cancel()
                return None
            if not _valid_custom_file_name(nm):
                ikram.show_error("Invalid file name. Use one basename, no slashes.")
                ikram.pause()
                continue
            key = nm.lower()
            if key in seen:
                ikram.show_error("That file name was already added.")
                ikram.pause()
                continue
            seen.add(key)
            names.append(nm)
            break
    return names


def _plan_custom_pak(pakf):
    """Build a bounded path/file plan from PATH MODE and FILE MODE."""
    mount, paths, lookup, fp_map, files_by_path = _custom_source_index(pakf)
    if not paths and not fp_map:
        ikram.show_error("No folders or files in this pak — Custom Pak cannot run.")
        ikram.pause()
        return None
    mode = _ask_custom_path_mode()
    if mode is None:
        return None
    if mode == "skeleton":
        return True, None
    count = int(mode)
    plans = []
    seen_paths = set()
    guard = 0
    while len(plans) < count:
        guard += 1
        if guard > count * 4:
            _custom_cancel("Too many invalid path entries. Cancelled.")
            return None
        picked = _ask_custom_path(
            mount, paths, lookup, files_by_path,
            len(plans) + 1, count,
        )
        if picked is None:
            return None
        path, exists = picked
        key = path.lower()
        if key in seen_paths:
            ikram.show_error("That path was already added. Choose another.")
            ikram.pause()
            continue
        if exists and _custom_path_has_files(path, fp_map):
            files = None
        else:
            n = _ask_custom_file_mode(path)
            if n is None:
                return None
            files = _ask_custom_file_names(
                path, n, files_by_path.get(path, ())
            )
            if files is None:
                return None
        seen_paths.add(key)
        plans.append({"path": path, "files": files})
    return False, plans


def _inject_custom_plan(r, out, plans, log, ui=None):
    """Write a mixed plan: copied original bodies + new empty-body files."""
    fp_map = {str(k).replace("\\", "/"): v for k, v in r.full_paths().items()}
    version = getattr(r, "version", None)
    if version is None:
        version = getattr(r, "version_num", 14)
    all_dirs = {}

    def add_dirs(raw):
        clean = str(raw or "").replace("\\", "/").rstrip("/")
        if not clean:
            all_dirs.setdefault("", {})
            return
        for d in _chain_dirs(clean):
            all_dirs.setdefault(d, {})

    template_cache = {}

    def template_for(suffix):
        if suffix in template_cache:
            return template_cache[suffix]
        found = None
        for old, e in sorted(fp_map.items()):
            if Path(old).suffix.lower() == suffix:
                found = e
                break
        if found is None:
            found = _corpus_templates(log).get(suffix)
        template_cache[suffix] = found
        return found

    payloads = {}
    entries = []
    edits = []
    seen = set()
    for plan in plans:
        path = str(plan.get("path") or "").replace("\\", "/").rstrip("/")
        if not path:
            continue
        files = plan.get("files")
        add_dirs(path)
        if files is None:
            for fp, e in sorted(_subtree_files(r, path).items()):
                fp = str(fp).replace("\\", "/")
                key = fp.lower()
                if key in seen:
                    continue
                seen.add(key)
                body = r.read_entry(e)
                payloads[fp] = body
                entries.append(e)
                edits.append((fp, (body, None, e.stem)))
                d, _, nm = fp.rpartition("/")
                # Register the original entry so the writer preserves its raw
                # bytes and encryption state verbatim. Without this the copy is
                # treated as a new file, downgrading em 53 -> 16 and re-encoding.
                all_dirs.setdefault((d + "/") if d else "", {})[nm] = e
                add_dirs(d)
            continue
        for name in files:
            fp = path + "/" + str(name)
            key = fp.lower()
            if key in seen:
                continue
            seen.add(key)
            suffix = Path(str(name)).suffix.lower()
            ne = _make_empty_entry(template_for(suffix), version)
            ne.stem = Path(str(name)).stem
            payloads[fp] = b""
            entries.append(ne)
            edits.append((fp, (b"", None, ne.stem)))
            all_dirs.setdefault(path + "/", {})[str(name)] = ne

    r.dirs = all_dirs
    r.files = entries
    progress, on_file = _writer_ui_callbacks(ui)
    _engines.pakmod().PakWriter(r).inject_files(
        edits, str(out), force_add=False,
        progress=progress, on_file=on_file)
    if progress:
        total_bytes = sum(len(v) for v in payloads.values())
        done, total = ((total_bytes, total_bytes) if total_bytes
                       else (max(1, len(edits)), max(1, len(edits))))
        try:
            progress(done, total, "")
        except Exception:
            pass
    bad = _verify_written_subtree(out, payloads, log)
    if bad:
        log("  ⚠ {}/{} custom entries failed verification.".format(
            len(bad), len(edits)))
        _discard_unverified(out, bad, log)
        return len(all_dirs), len(edits) - len(bad)
    return len(all_dirs), len(edits)


_CORPUS_TEMPLATES = None


def _candidate_paks():
    """Accessible pak corpus: Paks/ next to the tool, DROP/pak, home — whenever.
    Returns sorted list of .pak paths, deduped, no double scans."""
    seen = set()
    out = []
    bases = []
    for b in (
        _TOOL_DIR.parent / "Paks",
        _TOOL_DIR / "Paks",
        Path(ikram.DROP_PAK),
        Path(ikram.DROP_PAK).parent / "Paks",
        Path.home(),
    ):
        try:
            if b.is_dir():
                bases.append(b)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._candidate_paks:711", _ikram_exc)
            continue
    for b in bases:
        try:
            for f in sorted(b.glob("*.pak")):
                key = str(f).lower()
                if key in seen:
                    continue
                seen.add(key)
                out.append(f)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._candidate_paks:722", _ikram_exc)
            continue
    return out


def _corpus_templates(log=None):
    """First entry per file-extension (a→z order) from corpus as template —
    so an empty file of ANY extension can be engine-valid.
    Lazy memoised: scanned on first empty-file need, then cached."""
    global _CORPUS_TEMPLATES
    if _CORPUS_TEMPLATES is not None:
        return _CORPUS_TEMPLATES
    log = log or (lambda *a, **k: None)
    _CORPUS_TEMPLATES = {}
    paks = _candidate_paks()
    scanned = 0
    for pf in paks:
        tmpl_key = _PakName(pf)
        try:
            with _engines.pakmod().PakReader(pf) as r:
                for fp, e in r.full_paths().items():
                    ext = Path(fp).suffix.lower()
                    if ext and ext not in _CORPUS_TEMPLATES:
                        _CORPUS_TEMPLATES[ext] = e
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._corpus_templates:747", _ikram_exc)
            continue
        scanned += 1
        if scanned % 10 == 0:
            log("  corpus: {} paks scanned, {} templates...".format(scanned, len(_CORPUS_TEMPLATES)))
    log(
        "  corpus: {} paks scanned, {} extension templates cached".format(
            scanned, len(_CORPUS_TEMPLATES)
        )
    )
    return _CORPUS_TEMPLATES


def _make_empty_entry(tmpl, version):
    """Engine-valid empty entry. Template clone (if found) inherits ONLY the
    compression/encryption fields for its extension; otherwise a raw CM_NONE
    entry. compressed_blocks/offset/size zero. Content-derived fields are
    ALWAYS computed from the empty payload (B6): a clone must not keep the
    template's foreign signature, and a raw entry must not carry zeros --
    the real empty file in the corpus (em0 '1.txt') carries
    unk2 = md5(b"")+dup4 and content_hash = sha1(b"")."""
    import hashlib
    pak = _engines.pakmod()
    if tmpl is not None:
        ne = tmpl.clone()
        ne.compressed_blocks = []
    else:
        ne = pak.TencentPakEntry.__new__(pak.TencentPakEntry)
        ne.compression_method = pak.CM_NONE
        ne.unk1 = 0
        ne.compressed_blocks = []
        ne.compression_block_size = 65536
        ne.encrypted = False
        ne.encryption_method = 0
        ne.index_new_sep = 0
        ne.stem = ""
    # A zero-body entry is ALWAYS written as the corpus writes 1.txt: no
    # compression, no encryption, no block size.  Cloning a template's cm/em/cbs
    # onto an empty body produced phantom SM4/zstd entries the game rejects.
    ne.compression_method = pak.CM_NONE
    ne.encryption_method = 0
    ne.encrypted = False
    ne.compression_block_size = 0
    ne.index_new_sep = 0xFFFFFFFF
    ne.offset = 0
    ne.size = 0
    ne.uncompressed_size = 0
    ne.content_hash = hashlib.sha1(b"").digest()
    _md = hashlib.md5(b"").digest()
    ne.unk2 = _md + _md[4:8]
    return ne


def _subtree_files(r, target):
    """All files under the target folder: {full_path: entry}.
    If target itself is a file, it is also included."""
    target_r = str(target).replace("\\", "/").rstrip("/")
    prefix = target_r + "/"
    fp_map = r.full_paths()
    return {
        fp: e
        for fp, e in fp_map.items()
        if fp == target_r or fp.startswith(prefix)
    }


def _inject_empty_file(r, out, target, fname, mount, version, log, ui=None):
    """Chain + one empty file (engine-valid entry). Template = source/same-suffix
    entry, else a corpus scan template, else a raw CM_NONE."""
    target_r = str(target).replace("\\", "/").rstrip("/")
    fname_p = Path(fname)
    fp = target_r + "/" + fname
    stem = fname_p.stem
    suffix = fname_p.suffix.lower()
    chain = _chain_dirs(target)
    # B5.1: scan the INTACT source tree BEFORE the dirs wipe. The old order
    # wiped r.dirs first, so this loop ran over an empty tree, always missed,
    # and the same-suffix template branch was dead code.
    tmpl = None
    for old, e in r.full_paths().items():
        if Path(old).suffix.lower() == suffix:
            tmpl = e
            break
    if tmpl is None:
        tmpl = _corpus_templates(log).get(suffix)
    r.dirs = {d: {} for d in chain}
    ne = _make_empty_entry(tmpl, version)
    ne.stem = stem
    # B5.2: no more sha1((mount+fp)) fallback here -- _make_empty_entry always
    # computes the real empty-payload signature (md5(b"")+dup4 / sha1(b"")).
    r.dirs[target_r + "/"] = {fname: ne}
    r.files = [ne]
    edits = [(fp, (b"", None, stem))]
    progress, on_file = _writer_ui_callbacks(ui)
    _engines.pakmod().PakWriter(r).inject_files(
        edits, str(out), force_add=False,
        progress=progress, on_file=on_file)
    if progress:
        try:
            progress(1, 1, "")
        except Exception:
            pass
    return len(chain), 1


def _verify_written_subtree(out_pak, payloads, log=None):
    """Confirm a freshly written pak really carries the source bytes.

    tencent_pak.py copies kept bodies verbatim and rewrites the index from the
    tree, so a subtree pak should read back byte-identical. This check exists
    because "should" is not "does": it reads every entry through the real
    reader and compares against the source payload captured before the write.
    `payloads` is the {rel-path: source bytes} map. Returns the list of
    rel-paths that came back wrong; the caller must not present those as
    delivered.
    """
    log = log or (lambda *a, **k: None)
    mod = _engines.pakmod()
    bad = []
    try:
        out = mod.PakReader(str(out_pak))
    except Exception as e:
        ikram_logger.log_exc("ikram_patch._verify_written_subtree:855", e)
        log("  ✗ verification could not open the written pak: {}".format(e))
        return sorted(payloads)
    written = {"%s%s" % (dp, fn): e
               for dp, entries in out.dirs.items()
               for fn, e in entries.items()}
    import hashlib as _hl
    for rel, src_bytes in payloads.items():
        got = written.get(rel)
        if got is None:
            bad.append(rel)
            log("  ✗ MISSING {} — not present in the written pak".format(rel))
            continue
        # An entry we cannot read back is an entry we cannot vouch for, so a
        # raise here counts as failed rather than aborting the whole check.
        try:
            if _hl.sha1(out._read_at(got.offset, got.size)).digest() != got.content_hash:
                bad.append(rel)
                log("  ✗ CORRUPT {} — written bytes fail the pak's own SHA1 "
                    "index".format(rel))
                continue
            payload = out.read_entry(got)
        except Exception as e:
            ikram_logger.log_exc("ikram_patch._verify_written_subtree:878", e)
            bad.append(rel)
            log("  ✗ UNVERIFIED {} — written pak could not be read back: "
                "{}".format(rel, e))
            continue
        if src_bytes != payload:
            bad.append(rel)
            log("  ✗ ALTERED {} — written content differs from the source "
                "payload".format(rel))
    return bad


def _discard_unverified(out_pak, bad, log=None):
    """Make an output pak that failed verification un-shippable, in place.

    An injected entry that does not read back as the source payload is a
    silently broken game file, and the user asked for their own bytes back.
    Renames to .pak.UNVERIFIED rather than unlinking, so a mistaken click is
    recoverable and the directory listing is self-explanatory.

    A read-only or otherwise stubborn file is reported by name, because
    "silently still there" is exactly the failure this whole check exists to
    prevent.
    """
    log = log or (lambda *a, **k: None)
    p = Path(out_pak)
    dest = p.with_name(p.name + ".UNVERIFIED")
    try:
        if dest.exists():
            dest.unlink()
        p.replace(dest)
        log("  → output pak withheld as {} — it contains {} entry/entries that "
            "could not be verified byte-for-byte. Rename it back only if you "
            "accept altered content.".format(dest.name, len(bad)))
    except OSError as e:
        ikram_logger.log_exc("ikram_patch._discard_unverified:915", e)
        log("  ⚠ could not withhold {}: {}. IT STILL CONTAINS ALTERED CONTENT "
            "({} entries) — do not ship it.".format(p.name, e, len(bad)))


def _writer_ui_callbacks(ui):
    """Writer progress/on_file pair for a fixed-height shell frame."""
    if ui is None:
        return None, None
    return (getattr(ui, "progress", None), getattr(ui, "on_file", None))


def _inject_subtree_copy(r, out, target, log, ui=None):
    """Files of the target folder — kept entries keep their original bodies and
    block windows, the index is rebuilt from the new tree.

    tencent_pak.py copies every unchanged body region verbatim (so SM4 and
    multi-block encrypted entries survive untouched) and rebases block windows
    when a body lands at a different offset. The written pak is still verified
    against the source before it is handed back.
    """
    sel = _subtree_files(r, target)
    if not sel:
        return None
    payloads = {fp: r.read_entry(e) for fp, e in sorted(sel.items())}
    chain = _chain_dirs(target)
    r.dirs = {d: {} for d in chain}
    for fp, e in sorted(sel.items()):
        d, _, nm = fp.rpartition("/")
        key = (d + "/") if d else ""
        r.dirs.setdefault(key, {})[nm] = e
    r.files = [e for _, e in sorted(sel.items())]
    edits = [(fp, (payloads[fp], None, e.stem)) for fp, e in sorted(sel.items())]
    progress, on_file = _writer_ui_callbacks(ui)
    _engines.pakmod().PakWriter(r).inject_files(
        edits, str(out), force_add=False,
        progress=progress, on_file=on_file)
    if progress:
        total_bytes = sum(len(v) for v in payloads.values())
        done, total = (total_bytes, total_bytes) if total_bytes \
            else (len(edits), len(edits))
        try:
            progress(done, total, "")
        except Exception:
            pass
    return len(r.dirs), len(sel), payloads


def _inject_skeleton(r, out, target, log, ui=None):
    """Custom Pak ENTER-mode: the index gets ALL folder paths + ALL file NAMES
    from the source pak, but every file body is EMPTY (engine-valid zero entries).
    Templates come from a same-suffix entry in source (else corpus) — so the
    skeleton pak loads in the real game, and the user injects into it later."""
    fp_map = r.full_paths()
    # The caller hands us the source mount ("../../../ShadowTrackerExtra/") as
    # `target`. _chain_dirs() on that turned the mount into four junk index
    # records — '../', '../../', '../../../', '../../../ShadowTrackerExtra/' —
    # none of which exist in the source, and it STILL dropped the ten real
    # ancestor folders that hold no files of their own (Content, Content/Lua,
    # Content/Lua/GameLua, ...). The pak index is mount-relative and the mount
    # lives in the footer, so mirror the source's OWN dir records instead of
    # deriving them from the mount. Every folder the source declares survives,
    # and no "../" noise is invented.
    all_dirs = {d: {} for d in r.dirs}
    for fp in fp_map:
        d, _, nm = fp.rpartition("/")
        key = (d + "/") if d else ""
        all_dirs.setdefault(key, {})
    version = getattr(r, "version", None)
    if version is None:
        version = getattr(r, "version_num", 14)
    edits = []
    all_files = []
    for fp, e in sorted(fp_map.items()):
        d, _, nm = fp.rpartition("/")
        key = (d + "/") if d else ""
        stem_p = Path(fp).stem
        tmpl = e
        suffix = Path(fp).suffix.lower()
        if tmpl is None:
            tmpl = _corpus_templates(log).get(suffix)
        ne = _make_empty_entry(tmpl, version)
        ne.stem = stem_p
        # B5.3/B6: no sha1((mount+fp)) override here -- _make_empty_entry
        # already computes the empty-payload signature on both branches, and
        # the old override was the wrong RULE 12 formula anyway.
        all_dirs.setdefault(key, {})[nm] = ne
        all_files.append(ne)
        edits.append((fp, (b"", None, stem_p)))
    r.dirs = all_dirs
    r.files = all_files
    progress, on_file = _writer_ui_callbacks(ui)
    _engines.pakmod().PakWriter(r).inject_files(
        edits, str(out), force_add=False,
        progress=progress, on_file=on_file)
    if progress:
        total = max(1, len(edits))
        try:
            progress(total, total, "")
        except Exception:
            pass
    return len(all_dirs), len(edits)


def _make_costom_pak(pakf, out, target, kind=None, aes_key=None, log=None,
                     empty_name=None, ui=None, plan=None):
    """Build a Custom Pak from source pakf:

      empty_name None  + target in source → keep chain-dir + copy the chosen
                                     folder's files byte-identical (real pak)
      empty_name None  + target missing  → folderless / structure-only pak
                                     (chain-dirs only, files = 0, tencent)
      empty_name set   + target missing  → chain + one empty file (valid entry)

    tencent: keep the source mount_point, index only the chosen chain +
    files. The writer rebuilds the index and footer from the new tree and
    copies kept bodies verbatim.

    ue4: standard UE4 pak has no folder-only records — build an
    empty twin (mount + version preserved, zero records)."""
    log = log or (lambda *a, **k: None)
    pakf = Path(pakf)
    out = Path(out)
    kind = kind or ikram.detect_pak_type(pakf)
    if kind == "tencent":
        log("  engine: ikram-custom (tencent)")
        out.parent.mkdir(parents=True, exist_ok=True)
        with _engines.pakmod().PakReader(pakf) as r:
            if plan is not None:
                return _inject_custom_plan(r, out, plan, log, ui=ui)
            chain = _chain_dirs(target)
            version = getattr(r, "version", None)
            if version is None:
                version = getattr(r, "version_num", 14)
            mount = r.mount_point
            if target == _SKELETON:
                # ENTER pressed: ALL folders + ALL file names, EMPTY bodies.
                return _inject_skeleton(r, out, mount, log, ui=ui)
            if empty_name is not None:
                got = _inject_empty_file(
                    r, out, target, empty_name, mount, version, log, ui=ui
                )
                return got
            got = _inject_subtree_copy(r, out, target, log, ui=ui)
            if got is not None:
                chain, n, payloads = got
                bad = _verify_written_subtree(out, payloads, log)
                if bad:
                    log("  ⚠ {}/{} entries came back altered — they are NOT "
                        "safe to ship.".format(len(bad), n))
                    _discard_unverified(out, bad, log)
                return chain, n - len(bad)
            r.files = []
            r.dirs = {d: {} for d in chain}
            progress, on_file = _writer_ui_callbacks(ui)
            _engines.pakmod().PakWriter(r).inject_files(
                [], str(out), force_add=False,
                progress=progress, on_file=on_file
            )
            if progress:
                try:
                    progress(1, 1, "")
                except Exception:
                    pass
            return len(chain), 0
    if kind == "ue4":
        log("  engine: repak-pack (standard UE4)")
        repak = _engines.find_repak()
        if repak is None:
            raise RuntimeError(
                "repak missing — can't build an empty UE4 pak (install repak)"
            )
        version, mount_point, compression_u8 = _engines._ue4_meta(
            pakf, aes_key=aes_key
        )
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists():
            out.unlink()
        with tempfile.TemporaryDirectory(prefix="ikram_costom_") as tmp:
            _engines._run(
                [
                    repak, "pack", tmp,
                    "--mount-point", mount_point,
                    "--version", _engines._repak_version_str(version, compression_u8),
                    "--compression", "Zlib", out,
                ],
                log,
            )
        if not out.exists() or out.stat().st_size == 0:
            raise RuntimeError("UE4 empty-pak write produced no output")
        return 0, 0
    _pak_problem_box(pakf, kind, "This pak is not supported.")
    return 0, 0


def _custom_cancel(message="Cancelled."):
    ikram.show_info(message)
    ikram.pause()
    return None


def pak_costom_pak():
    """Custom Pak — pak pick → folder pick (number / 0 cancel / custom path) →
    empty pak with just that folder chain -> RESULT/CostomPak/<same name>.pak"""
    paks = ikram.drop_files(ikram.DROP_PAK, [".pak"])
    if not paks:
        ikram.show_error(
            "The pak folder is empty.\nAdd your .pak file to DROP/pak and try again."
        )
        ikram.pause()
        return
    if ikram.eof_exit():
        return
    idx = _choose_pak_index(
        len(paks), paks, "Custom Pak",
        question="Choose source pak:", main="CHOOSE PAK")
    if idx is _EOF_CHOICE or idx is None:
        return _custom_cancel()
    pakf = paks[idx]
    out_root = ikram.RESULT / "CostomPak"
    out_root.mkdir(parents=True, exist_ok=True)
    out = _unique_out_file(out_root / pakf.name)
    try:
        kind = ikram.detect_pak_type(pakf)
        aes_key = None
        target = None
        empty_name = None
        plan = None
        skeleton = False
        if kind == "ue4":
            key = _ask_boxed(
                "UE4 AES KEY",
                "AES key for {} (ENTER = default, 0 = cancel):".format(_PakName(pakf)),
                ["ENTER = built-in default", "0 = cancel"], main=_PakName(pakf),
                fallback="  [bold {}]-> {} AES key (ENTER = default, 0 = cancel): [/]".format(
                    ikram.INP, pakf.name),
            )
            if ikram.eof_exit():
                return _custom_cancel()
            key = (key.strip() if key and key.strip() else "")
            if key == "0":
                return _custom_cancel()
            aes_key = key or None
        else:
            built = _plan_custom_pak(pakf)
            if built is None:
                return
            skeleton, plan = built
            if skeleton:
                target = _SKELETON
        detail = []
        if skeleton:
            detail.append("ALL folders + all file names, EMPTY bodies")
        elif plan:
            for item in plan[:12]:
                p = str(item.get("path") or "")
                detail.append(p)
                files = item.get("files")
                if files is None:
                    detail.append("  original files copied")
                else:
                    detail.extend("  " + str(n) for n in files[:3])
            if len(plan) > 12:
                detail.append("+ {} more path(s)".format(len(plan) - 12))
        elif target:
            detail.extend(_chain_dirs(target))
        if empty_name is not None:
            detail.append("{} (empty file)".format(Path(empty_name).name))
        _show_context(
            str(target) if target else _PakName(pakf), detail,
            title="Custom Pak", mode=kind, target="DROP/pak",
            output=str(out), limit=12)
        ui = _boxed_progress("CUSTOM PAK")
        vip = _vip_ref()

        def log(*a, **k):
            msg = " ".join(str(x) for x in a)
            if vip is not None:
                try:
                    vip.write(msg + "\n")
                    return
                except Exception:
                    pass
            ikram.console.print(msg)

        with ui:
            ndirs, nfiles = _make_costom_pak(
                pakf, out, target, kind=kind, aes_key=aes_key,
                log=log, empty_name=empty_name, ui=ui, plan=plan,
            )
            frame = getattr(ui, "frame", None)
            if getattr(frame, "_paints", 1) == 0:
                ui.progress(1, 1, "")
        if Path(out).exists():
            ikram.show_success(
                "Custom Pak ready: {} folders, {} files -> {}".format(
                    ndirs, nfiles, out
                )
            )
        else:
            ikram.show_error(
                "Custom Pak withheld (verification failed): {}".format(
                    str(out) + ".UNVERIFIED"
                )
            )
    except Exception as e:
        ikram_logger.log_exc("ikram_patch.pak_costom_pak:1254", e)
        _show_handler_error(e)
    ikram.pause()


def pak_tool_menu():
    """PAK TOOL menu (patched): original 4 options + '4. Custom Pak'.
    Mirrors the compiled pak_tool_menu byte-for-byte in style/flow."""
    while True:
        ikram.clear_screen()
        opts = [
            ("[1]", "📦 Unpack PAK",
             "WORK: take all files out of the pak.\nPUT FILE IN: DROP/pak\nOUTPUT: RESULT/extracted/"),
            ("[2]", "📦 Inject File",
             "WORK: put any file (lua/uasset/asset) into the pak —\ntype is found automatically and added to the game.\n1 file or all files at once — auto or manual path.\nPUT FILE IN: DROP/inject + DROP/pak\nOUTPUT: RESULT/injected/"),
            ("[3]", "📦 Repack PAK",
             "WORK: build the pak again.\n1) first UNPACK the pak\n2) edit files in RESULT/extracted\n3) old pak files are NEVER touched\nOUTPUT: RESULT/Repacked/"),
            ("[4]", "📦 Custom Pak",
             "WORK: build a pak from PATH MODE + FILE MODE.\nPATH MODE: 1 ONE PATH - 2 HOW MANY PATHS -\n3 ALL FOLDERS + EMPTY FILES.\nExisting pak paths are shown; choosing one copies\nits files. A new path opens FILE MODE for names.\nPUT FILE IN: DROP/pak\nOUTPUT: RESULT/CostomPak/"),
            ("[0]", "Back", "back to main menu"),
        ]
        t = ikram.build_menu_table(opts)
        ikram.console.print(
            ikram.panel(t, title="📦 PAK TOOL 📦", box=ikram.MENU_BOX)
        )
        c = ikram.safe_input("[bold {}]-> Select: [/]".format(ikram.INP))
        if ikram.eof_exit():
            return
        if c == "1":
            ikram.pak_extract()
        elif c == "2":
            ikram.pak_inject()
        elif c == "3":
            ikram.pak_repack_folder()
        elif c == "4":
            ikram.pak_costom_pak()
        elif c == "0":
            return
        else:
            ikram.invalid_choice()
            ikram.pause()


ikram.pak_extract = pak_extract
ikram.ensure_input_folder = ensure_input_folder
ikram.pak_inject = pak_inject
# Bind the wrapper the same way: the compiled wizard resolves
# _inject_many_into_pak from module globals at CALL time, so this takes effect
# inside the original wizard without recompiling ikram.pyc.
ikram._inject_many_into_pak = _inject_many_into_pak
ikram.pak_repack_folder = pak_repack_folder
ikram.pak_costom_pak = pak_costom_pak
ikram.pak_tool_menu = pak_tool_menu

# =========================================================================
# DECOMPILE REDESIGN - one file, one engine, chosen by the user from a
# numbered menu. Every engine shown with LANGUAGE + GAMES metadata. No
# auto-detect, no hidden cascade. Chosen engine alone does the work.
# =========================================================================
from engine_menu import ENGINE_REGISTRY, _tool_path, run_engine


def _engine_available(e):
    """Only offer engines that can actually start on this platform."""
    kind = e.get("kind")
    engine_id = str(e.get("id", "")).lower()
    if kind == "jar":
        try:
            from engine_menu import _ENG_DIR
        except Exception:
            _ENG_DIR = Path(__file__).resolve().parent
        return (_ENG_DIR / "unluac.jar").is_file() and shutil.which("java") is not None
    if engine_id == "unluac_rs":
        return _tool_path("unluac_rs", "unluac_rs").is_file()
    if engine_id == "luadec":
        return _tool_path("luadec.fresh", "luadec").is_file()
    return True


def _engine_registry():
    rows = [e for e in ENGINE_REGISTRY if _engine_available(e)]
    return rows or list(ENGINE_REGISTRY)


def _boxed_invalid_choice():
    vip = _vip_ref()
    if vip is not None and hasattr(vip, "warn_box"):
        vip.warn_box(["Invalid option. Choose a listed number."])
        return
    ikram.invalid_choice()


def _pick_lua_items_all(items, title):
    """Replace the compiled item picker: ENTER = ALL files, number = one file,
    A = ALL, 0 = cancel. The compiled picker forces a number and shows an ERROR
    panel on ENTER, which contradicts the tool-wide 'ENTER = auto default' -- the
    same promise the engine step already keeps."""
    rows = sorted(Path(x) for x in items)
    boxed = _vip_ref() is not None
    while True:
        if not boxed:
            t = ikram.Table(show_header=False, box=ikram.ROUNDED,
                            border_style=ikram.BORDER,
                            style="on {}".format(ikram.BG_DEEP), expand=True,
                            pad_edge=False, padding=(0, 1))
            for i, p in enumerate(rows, 1):
                try:
                    sz = p.stat().st_size
                    hs = "{}".format(
                        sz // (1024 * 1024) and "{:.1f} MB".format(sz / (1024 * 1024))
                        or (sz // 1024 and "{:.1f} KB".format(sz / 1024)) or "{} B".format(sz))
                except Exception:
                    hs = "?"
                t.add_row("[{}]{}[/]".format(_vip_num(i % 10), i),
                          "[{}]{}[/]   [{}]{}[/]".format(ikram.CYAN, p.name,
                                                         ikram.MUTED, hs))
            ikram.console.print(ikram.panel(t, title="{} — choose a file".format(title),
                                            box=ikram.MENU_BOX, style=ikram._next_green()))
        chosen_rows = [_tint("{} = {}".format(i, p.name), "number")
                       for i, p in enumerate(rows, 1)]
        chosen_rows.extend([_tint("ENTER = ALL files", "success"),
                            _tint("0 = cancel", "error")])
        c = _ask_boxed(
            "LUA FILE",
            "{}:".format(title),
            chosen_rows, main=rows[0].name if rows else "-",
            fallback="\n[bold {}]-> enter = ALL files   ·   number = one file   ·   0 = cancel: [/]".format(
                ikram.INP),
        )
        if ikram.eof_exit():
            return None
        s = c.strip().rstrip(".")
        if s == "" or s.lower() == "a":
            return list(rows)
        if s == "0":
            return None
        try:
            n = int(s)
            if 1 <= n <= len(rows):
                return [rows[n - 1]]
        except ValueError:
            pass
        ikram.invalid_choice()
        ikram.pause()


# Same trick as _silence_owner_handoff: the picker lives inside ikram.pyc, so
# rebind it on the module -- every caller already resolves the name at call
# time. This gives the whole tool (not just Decompile) the same ENTER=AUTO
# default without touching bytecode.
ikram._pick_lua_items = _pick_lua_items_all


_compiled_lua_compile_path = getattr(ikram, "lua_compile_path", None)


def _lua_compile_path_single_result(src):
    """Skip the compiled per-file error+pause for already-compiled input.

    lua_compile_one() already renders one summary panel and owns the only
    continue. The compiled helper showed a second error box and paused before
    returning False, which produced two continues for one selected file.
    """
    try:
        import univ
        kind = str(univ.detect(src) or "")
        if ((kind.startswith("Lua") and kind != "Lua source")
                or kind == "LuaJIT"):
            return False
    except Exception as _ikram_exc:
        ikram_logger.log_exc("ikram_patch._lua_compile_path:detect", _ikram_exc)
    if _compiled_lua_compile_path is None:
        return False
    return _compiled_lua_compile_path(src)


_lua_compile_path_single_result._ikram_lua_compile_overlay = True
if (_compiled_lua_compile_path is not None
        and not getattr(_compiled_lua_compile_path,
                        "_ikram_lua_compile_overlay", False)):
    ikram.lua_compile_path = _lua_compile_path_single_result


def _engine_boxes():
    """One numbered box per runnable engine. No shelf, no 'nothing' rows."""
    for i, e in enumerate(_engine_registry(), 1):
        t = ikram.Table(
            show_header=False,
            box=ikram.ROUNDED,
            border_style=ikram.BORDER,
            style="on {}".format(ikram.BG_DEEP),
            expand=True,
            pad_edge=False,
            padding=(0, 1),
        )
        t.add_row("[{}]{}[/]   [bold {}]{}[/]".format(
            _vip_num(i % 10), i, ikram.ACCENT, e["name"]))
        t.add_row("Lua", e["lang"])
        t.add_row("Games", e["games"])
        if e.get("note"):
            t.add_row("Note", e["note"])
        ikram.console.print(
            ikram.panel(
                t,
                title="ENGINE {} — {}".format(i, e["name"]),
                box=ikram.MENU_BOX,
                style=ikram._next_green(),
            )
        )


def _pick_engine(src=None):
    boxed = _vip_ref() is not None
    main = Path(src).name if src else "LUA ENGINE"
    engines = _engine_registry()
    while True:
        if not boxed:
            _engine_boxes()
        rows = [_tint("{} = {}".format(i, e["name"]), "number")
                for i, e in enumerate(engines, 1)]
        rows.append(_tint("ENTER = AUTO (game-ready)", "success"))
        rows.append(_tint("0 = cancel", "error"))
        c = _ask_boxed(
            "LUA ENGINE",
            "Choose decompile engine:",
            rows, main=main,
            fallback="[bold {}]-> engine number (1-{}), ENTER = AUTO (game-ready), 0 = cancel: [/]".format(
                ikram.INP, len(engines)
            ),
        )
        if ikram.eof_exit():
            return None
        s = c.strip().rstrip(".")
        if s == "":
            return dict(
                id="AUTO",
                name="Auto (game-ready)",
                ver="full pipeline",
                lang="Lua 5.x / LuaJIT",
                games="any file",
                kind="auto",
                note="runs every recovery until one works",
            )
        if s == "0":
            return None
        try:
            n = int(s)
            if 1 <= n <= len(engines):
                return engines[n - 1]
        except ValueError:
            pass
        _boxed_invalid_choice()
        ikram.pause()


def _lua_check_text(n):
    """Robust 'score · roundtrip · garbage' line for the validator result.

    The validator dict has drifted between callers (the round-trip key is
    spelled 'round-trip recompile' in one builder and 'roundtrip' in another),
    so read both spellings and never let a missing field raise inside a panel.
    Returns None when there is nothing to show."""
    if not n:
        return None
    score = n.get("score", "-")
    checks = n.get("checks") or n
    rt = checks.get("round-trip recompile")
    if rt is None:
        rt = checks.get("roundtrip", "-")
    garbage = n.get("garbage", 0)
    try:
        g = "{:.0%}".format(float(garbage))
    except Exception:
        g = str(garbage)
    return "score {} · roundtrip {} · garbage {}".format(score, rt, g)


def _mark_outcome(state):
    """Record this operation's result for the main menu's 'Last:' line."""
    try:
        ref = getattr(ikram, "_vip_ref", None)
        if ref is not None:
            ref._last_outcome = state
    except Exception:
        pass


def _engine_success_panel(eng, src, res):
    _mark_outcome("SUCCESS")
    n = res.get("validate") or {}
    text = res.get("text") or ""
    rows = ["ENGINE : {} · {}".format(eng["name"], eng["ver"]),
            "FILE   : {}".format(Path(src).name)]
    if eng.get("lang"):
        rows.append("LANG   : {}".format(eng["lang"]))
    if eng.get("games"):
        rows.append("GAMES  : {}".format(eng["games"]))
    check = _lua_check_text(n)
    if check:
        rows.append("CHECK  : {}".format(check))
    if res.get("bytecode_only"):
        rows.append("OUTPUT : game-ready bytecode (exact round-trip)")
    else:
        rows.append("LINES  : {}".format(text.count("\n") + 1))
        try:
            rows.append("SIZE   : {}".format(_paths.human(len(text.encode("utf-8")))))
        except Exception:
            pass
    rows.append("OUT    : {}".format(res["out_root"]))
    vip = _vip_ref()
    if vip is not None and hasattr(vip, "success_box"):
        vip.success_box(rows + ["NEXT   : PAK TOOL -> inject / repack this file"])
        return
    t = ikram.Table(show_header=False, box=ikram.ROUNDED,
                    border_style=ikram.BORDER,
                    style="on {}".format(ikram.BG_DEEP), pad_edge=False)
    t.add_row("[bold {}]ENGINE[/]".format(ikram.SUCCESS), "[{}]{} · {}[/]".format(
        ikram.ACCENT, eng["name"], eng["ver"]))
    t.add_row("[bold {}]FILE[/]".format(ikram.SUCCESS), "[{}]{}[/]".format(ikram.CYAN, Path(src).name))
    if eng.get("lang"):
        t.add_row("[bold {}]LANG[/]".format(ikram.SUCCESS), eng["lang"])
    if eng.get("games"):
        t.add_row("[bold {}]GAMES[/]".format(ikram.SUCCESS), eng["games"])
    if check:
        t.add_row("[bold {}]CHECK[/]".format(ikram.SUCCESS), check)
    if res.get("bytecode_only"):
        t.add_row("[bold {}]OUTPUT[/]".format(ikram.SUCCESS),
                  "[{}]game-ready bytecode (exact round-trip)[/]".format(ikram.GOLD))
    else:
        t.add_row("[bold {}]LINES[/]".format(ikram.SUCCESS),
                  "[{}]{}[/]".format(ikram.GOLD, text.count("\n") + 1))
        try:
            size = _paths.human(len(text.encode("utf-8")))
            t.add_row("[bold {}]SIZE[/]".format(ikram.SUCCESS),
                      "[{}]{}[/]".format(ikram.GOLD, size))
        except Exception:
            pass
    t.add_row("[bold {}]OUT[/]".format(ikram.SUCCESS),
              "[{}]{}[/]".format(ikram.CYAN, res["out_root"]))
    t.add_row("[bold {}]NEXT[/]".format(ikram.SUCCESS),
              "PAK TOOL → inject / repack this file")
    ikram.console.print(ikram.panel(t, title="DONE",
                                    box=ikram.ROUNDED, style=ikram.SUCCESS))


def _engine_error_panel(eng, src, res):
    _mark_outcome("ERROR")
    rows = ["FILE   : {}".format(Path(src).name)]
    if res.get("rjtool"):
        rows.extend([
            "REASON : this file is encrypted and can't be decompiled by this Tool",
            "NOTE   : the real code is hidden inside decoy functions - only the "
                     "VIP engine can read it",
        ])
        next_step = "choose ENTER for AUTO (VIP / SKUY engine)"
    else:
        rows.append("REASON : this file is not supported by {}".format(eng["name"]))
        next_step = "pick a different engine number"
    err = (res.get("err") or "").strip().replace("\n", " / ")
    if err:
        rows.append("DETAIL : {} — {}".format(eng["name"], err[:140]))
    vip = _vip_ref()
    if vip is not None and hasattr(vip, "error_box"):
        vip.error_box(rows, next_step="run DECOMPILE again and " + next_step)
        return
    t = ikram.Table(show_header=False, box=ikram.ROUNDED,
                    border_style=ikram.BORDER,
                    style="on {}".format(ikram.BG_DEEP), pad_edge=False)
    t.add_row("[bold {}]FILE[/]".format(ikram.ERROR), "[{}]{}[/]".format(ikram.CYAN, Path(src).name))
    if res.get("rjtool"):
        t.add_row("[bold {}]REASON[/]".format(ikram.ERROR),
                  "this file is encrypted and can't be decompiled by this Tool")
        t.add_row("[bold {}]NOTE[/]".format(ikram.ERROR),
                  "the real code is hidden inside decoy functions - only the "
                  "VIP engine can read it")
        t.add_row("[bold {}]FIX[/]".format(ikram.ERROR),
                  "choose ENTER for AUTO (VIP / SKUY engine)")
    else:
        t.add_row("[bold {}]REASON[/]".format(ikram.ERROR),
                  "this file is not supported by {}".format(eng["name"]))
        t.add_row("[bold {}]FIX[/]".format(ikram.ERROR),
                  "pick a different engine number")
    err = (res.get("err") or "").strip()
    if err:
        err = err.replace("\n", " / ").strip()
        t.add_row("[bold {}]DETAIL[/]".format(ikram.ERROR),
                  "{} — {}".format(eng["name"], err[:140]))
    t.add_row("[bold {}]NEXT[/]".format(ikram.ERROR),
              "run DECOMPILE again and try another engine")
    ikram.console.print(ikram.panel(t, title="ERROR",
                                    box=ikram.ROUNDED, style=ikram.ERROR))


def _ensure_work_dirs():
    """Recreate tool folders lost when empty dirs don't survive the zip."""
    for d in ("lua", "pak", "inject"):
        p = Path(getattr(ikram, "DROP", Path("DROP"))) / d
        p.mkdir(parents=True, exist_ok=True)
    r = Path(getattr(ikram, "RESULT", Path("RESULT")))
    (r / "lua").mkdir(parents=True, exist_ok=True)
    (r / "extracted").mkdir(parents=True, exist_ok=True)


def _safe(fn):
    """Wrap a user-facing handler so NOTHING escapes as an 'Unexpected error'."""
    try:
        fn()
    except Exception as e:
        ikram_logger.log_exc("ikram_flow", e)
        try:
            _show_handler_error(e)
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_patch._safe:show", _ikram_exc)
            try:
                ikram.show_error(
                    "Something went wrong\n"
                    "This operation could not be completed.\nTry again."
                )
            except Exception:
                pass
        try:
            ikram.pause()
        except Exception:
            pass


def _lua_phase_progress(title, fallback_fmt):
    """Phase messages go through the fixed progress box when a shell is live."""
    ui = _boxed_progress(title)
    phase = getattr(ui, "phase", None)
    close = getattr(ui, "close", None)
    if callable(phase):
        if callable(close):
            return phase, close
        # Compiled _ProgressUI has phase() but no close(); its phase() is a
        # no-op, so the CLI fallback print is the honest visible behaviour.
        return (lambda m: ikram.console.print(fallback_fmt.format(m)),
                lambda: None)
    return (lambda m: ikram.console.print(fallback_fmt.format(m)),
            lambda: None)


def _auto_decompile(eng, src):
    """AUTO = the full recovery cascade (encryption sweep, wrap strip, every
    decompiler, validation). Produces the same game-ready result the compiled
    flow used to give on Enter-without-typing."""
    import lua_pipeline as _pipe
    _rjt_why = None
    try:
        _rjt_why = _engine_menu_rjtool(src)
    except Exception:
        _rjt_why = None
    if _rjt_why:
        # RJTOOL-marked: STANDARD engines can't read it, but universal pipeline
        # (mega_lua + lua_pipeline) already produces game-ready output (bytecode+readable)
        # for these chunks. Try full pipeline FIRST; if it fails, fall back to SKUY VIP.
        try:
            out_dir = ikram.RESULT / "lua"
            out_dir.mkdir(parents=True, exist_ok=True)
            _pr, _pr_close = _lua_phase_progress(
                "LUA DECOMPILE | {}".format(Path(src).name),
                "[dim]  ⇢ [/][bold {}]{{}}[/dim]".format(ikram.ACCENT))
            try:
                ret = _pipe.run(src, out_dir, progress=_pr)
            finally:
                _pr_close()
            if ret and ret.get("ok"):
                out_p = ret.get("out")
                if out_p and Path(out_p).exists():
                    if Path(out_p).suffix.lower() == ".luac":
                        src_p = ret.get("source")
                        text = ""
                        if src_p and Path(src_p).exists():
                            text = Path(src_p).read_text(errors="replace")
                        eng_used = dict(
                            id="AUTO", name=ret.get("msg") or "Auto · game-ready bytecode",
                            ver="exact round-trip", lang="", games="",
                            kind="bytecode", note="",
                        )
                        _engine_success_panel(eng_used, src, {
                            "text": text or ("game-ready bytecode -> %s" % out_p),
                            "validate": ret.get("validate"), "out_root": Path(out_p),
                            "bytecode_only": text == "",
                        })
                        return
                    text = Path(out_p).read_text(errors="replace")
                    win = str(ret.get("msg") or (ret.get("attempts") or [("", "")])[-1][0])
                    eng_used = dict(
                        id="AUTO", name=win or "Auto", ver="game-ready",
                        lang="", games="", kind="auto", note="",
                    )
                    _engine_success_panel(eng_used, src, {
                        "text": text, "validate": ret.get("validate"),
                        "out_root": Path(out_p),
                    })
                    return
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_flow.auto-rjtool-pipe", _ikram_exc)

        # fallback to SKUY VIP if pipeline failed
        try:
            import skuy_runner as _skuyr
            _phase_probe, _phase_close = _lua_phase_progress(
                "LUA DECOMPILE | {}".format(Path(src).name),
                "[dim]  ⇢ [/][bold {}]{{}}[/dim]".format(ikram.ACCENT))
            _phase_probe("SKUY VIP (custom chunk decode)...")
            _phase_close()
            _rr = _skuyr.decompile(src.read_bytes(),
                                   timeout=min(1800, 400 + src.stat().st_size // 8000))
        except Exception as _ikram_exc:
            ikram_logger.log_exc("ikram_flow.auto-rjtool", _ikram_exc)
            _rr = {"ok": False, "error": "SKUY VIP unavailable"}
        if _rr.get("ok") and (_rr.get("text") or "").strip():
            out_dir = ikram.RESULT / "lua"
            out_dir.mkdir(parents=True, exist_ok=True)
            from mega_lua import game_output_path as _game_output_path
            out_p = _game_output_path(out_dir, src.stem)
            out_p.write_text(_rr["text"], encoding="utf-8")
            eng_used = dict(
                id="AUTO", name="SKUY VIP · custom chunk",
                ver="native Cython core", lang="Lua 5.3 custom/NADEEM/BYRJ6",
                games="BGMI · PUBG", kind="native", note="",
            )
            try:
                _val = _pipe.validate(_rr["text"])
            except Exception:
                _val = {}
            _engine_success_panel(eng_used, src, {
                "text": _rr["text"], "validate": _val, "out_root": out_p,
            })
            return
        _engine_error_panel(eng, src, dict(ok=False, rjtool=True, err=_rjt_why))
        return
    try:
        out_dir = ikram.RESULT / "lua"
        out_dir.mkdir(parents=True, exist_ok=True)
        _pr, _pr_close = _lua_phase_progress(
            "LUA DECOMPILE | {}".format(Path(src).name),
            "[dim]  ⇢ [/][bold {}]{{}}[/][dim] …[/dim]".format(ikram.ACCENT))
        _show_context(Path(src).name, (), title="LUA AUTO RECOVERY",
                      mode="decompile", output="RESULT/lua")
        try:
            ret = _pipe.run(src, out_dir, progress=_pr)
        finally:
            _pr_close()
    except Exception as e:
        ikram_logger.log_exc("ikram_flow.auto", e)
        _engine_error_panel(eng, src, dict(ok=False, err=str(e)))
        return
    if ret and ret.get("ok"):
        out_p = ret.get("out")
        if out_p and Path(out_p).exists():
            if Path(out_p).suffix.lower() == ".luac":
                src_p = ret.get("source")
                text = ""
                if src_p and Path(src_p).exists():
                    text = Path(src_p).read_text(errors="replace")
                eng_used = dict(
                    id="AUTO", name=ret.get("msg") or "Auto · game-ready bytecode",
                    ver="exact round-trip", lang="", games="",
                    kind="bytecode", note="",
                )
                _engine_success_panel(eng_used, src, {
                    "text": text or ("game-ready bytecode -> %s" % out_p),
                    "validate": ret.get("validate"), "out_root": Path(out_p),
                    "bytecode_only": text == "",
                })
                return
            text = Path(out_p).read_text(errors="replace")
            win = str(ret.get("msg") or (ret.get("attempts") or [("", "")])[-1][0])
            eng_used = dict(
                id="AUTO", name=win or "Auto", ver="game-ready",
                lang="", games="", kind="auto", note="",
            )
            _engine_success_panel(eng_used, src, {
                "text": text, "validate": ret.get("validate"),
                "out_root": Path(out_p),
            })
            return
    try:
        _last = (ret.get("attempts") or [])[-1]
        err = "{}: {}".format(*_last)[:160].replace("[", "").replace("]", "")
    except Exception:
        err = "no engine in the pipeline could read this file"
    _engine_error_panel(eng, src, dict(ok=False, err=err))


def _engine_menu_rjtool(src):
    from engine_menu import rjtool_guard
    return rjtool_guard(src)


def lua_decompile_one():
    _ensure_work_dirs()
    _safe(lambda: _lua_decompile_one_inner())


# Files that ride along with a pack to carry its key, not to be decompiled.
# Picking them as targets wasted a full cascade on `key.txt` and printed an
# error panel for a file nobody asked to open.
_SIDECAR_EXT = {".txt", ".key", ".json", ".ini", ".cfg", ".conf", ".xml",
                ".yml", ".yaml", ".env", ".md"}
_SIDECAR_HINT = re.compile(
    r"(?i)(?:^|[._\-])(key|keys|pass|passwd|password|secret|pwd|salt|iv)(?:$|[._\-])")
_LUA_MAGIC = b"\x1bLua"


def _is_key_sidecar(p):
    """True for a small text file that only carries a key/passphrase."""
    try:
        p = Path(p)
        if p.suffix.lower() not in _SIDECAR_EXT:
            return False
        if p.stat().st_size > 4096:
            return False
        with p.open("rb") as fh:
            head = fh.read(16)
    except Exception:
        return False
    if head.startswith(_LUA_MAGIC):
        return False
    return bool(_SIDECAR_HINT.search(p.stem))


def _lua_decompile_one_inner():
    # 1) scan DROP/lua
    items = ikram._scan_lua_inputs("decompile")
    if len(items) > 1:
        # Keep a lone key.txt selectable (a user may point at it deliberately),
        # but never treat a sidecar as a target when real payloads are present.
        payloads = [p for p in items if not _is_key_sidecar(p)]
        if payloads:
            items = payloads
    if not items:
        ikram.show_error(
            "Decompile\n"
            "No files found in DROP/lua.\nPut a file there and try again.",
        )
        ikram.pause()
        return
    # 2) user picks files
    selected = ikram._pick_lua_items(items, "📜 Decompile — choose a file")
    if not selected:
        return
    # 3) user picks ONE engine (one box per engine)
    eng = _pick_engine()
    if not eng:
        return
    # 4) that engine alone decompiles each file (AUTO = full pipeline, game-ready)
    _total = len(selected)
    for _idx, src in enumerate(selected, 1):
        src = Path(src)
        if _total > 1:
            ikram.console.print("[bold {}][{}/{}][/] [{}]{}[/]".format(
                ikram.ACCENT, _idx, _total, ikram.CYAN, src.name))
        if eng["id"] == "AUTO":
            _auto_decompile(eng, src)
            continue
        try:
            res = run_engine(eng["id"], src)
        except Exception as e:
            res = dict(ok=False, err=str(e))
        if res.get("ok") and res.get("text"):
            out_dir = ikram.RESULT / "lua"
            out_dir.mkdir(parents=True, exist_ok=True)
            out_p = _unique_out_file(
                out_dir / "{}.{}.lua".format(src.stem, eng["id"]))
            out_p.write_text(res["text"], encoding="utf-8")
            res["out_root"] = out_p
            _engine_success_panel(eng, src, res)
            continue
        # V130 RULE 5/6: chosen engine only, honest failure (engine + reason).
        _engine_error_panel(eng, src, res)
    ikram.pause()


def lua_decompile_path(src, univ=None, out_root=None, kind=None):
    """Single-engine path used by any compiled caller: pick engine, run it."""
    _ensure_work_dirs()
    _safe(lambda: _lua_decompile_path_inner(src, out_root))


def _lua_decompile_path_inner(src, out_root):
    src = Path(src)
    if not src.is_file():
        ikram.show_error("Decompile\nfile not found: {}".format(src))
        ikram.pause()
        return
    eng = _pick_engine()
    if not eng:
        return
    if eng["id"] == "AUTO":
        _auto_decompile(eng, src)
        ikram.pause()
        return
    try:
        res = run_engine(eng["id"], src)
    except Exception as e:
        res = dict(ok=False, err=str(e))
    if res.get("ok") and res.get("text"):
        out_root = (Path(out_root) if out_root else ikram.RESULT / "lua")
        out_root.mkdir(parents=True, exist_ok=True)
        out_p = _unique_out_file(
            out_root / "{}.{}.lua".format(src.stem, eng["id"]))
        out_p.write_text(res["text"], encoding="utf-8")
        res["out_root"] = out_p
        _engine_success_panel(eng, src, res)
        ikram.pause()
        return
    # V130 RULE 5/6: the chosen engine is the ONLY engine. No silent
    # pipeline cascade. Failure is reported with the engine name and its
    # exact reason (rjtool marker, timeout, crash, format mismatch) so the
    # user can pick a different engine from the menu themselves.
    _engine_error_panel(eng, src, res)
    ikram.pause()


ikram.lua_decompile_one = lua_decompile_one
ikram.lua_decompile_path = lua_decompile_path

if __name__ == "__main__":
    import vip_ui
    # Last line of defence. Vip.run() already contains its own errors, but a
    # failure in the setup path (theme load, terminal probe, first import)
    # used to escape as a raw traceback that told the user nothing and left
    # the terminal in whatever state the crash found it. Log it, say one plain
    # sentence, and where to look - never a stack dump on a phone screen.
    try:
        vip_ui.Vip(ikram=ikram).run()
    except KeyboardInterrupt:
        pass
    except Exception as _e:
        try:
            ikram_logger.log_exc("main", _e)
        except Exception:
            pass
        try:
            print("\n  " + safe_text(glyph("fail"))
                  + " IkramTool stopped on an unexpected error.")
            print("    Detail: %s"
                  % safe_text(ikram_logger.log_path() or "unavailable"))
        except Exception:
            pass
