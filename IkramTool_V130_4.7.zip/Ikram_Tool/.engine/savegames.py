"""IkramTool — SaveGames (PUBG Mobile / BGMI .sav) engine.

A PUBG/BGMI ``.sav`` is a real Unreal Engine ``GVAS`` file. The container is
plaintext: magic ``GVAS`` + engine header + a tagged property tree. There is
no cipher and nothing to "crack" — the job is to expose that tree as an
editable source, and to compile the edited source back into the exact same
binary the game reads.

Two operations, mirroring the LUA tool:

    Decrypt :  .sav / .gvas  ->  .json   (source — every property, editable)
    Encrypt :  .json         ->  .sav    (compile the source back to GVAS bytes)

``Decrypt`` then ``Encrypt`` with no edits is byte-for-byte identical to the
input, because ``gvas_engine`` round-trips the whole container (header,
property tree, trailer). Editing a number in the JSON and encrypting writes
that value back.

    PUT FILE IN: DROP/SaveGames      (.sav/.gvas to decrypt, .json to encrypt)
    OUTPUT:      RESULT/SaveGames/

Audit pass additions (all backwards compatible):
  * optional ``progress``/``log`` callbacks and ``wait`` flag on decrypt/encrypt;
  * bounded reads and SHA-256/count/path reports on every success;
  * ``.gvas`` recognised alongside ``.sav``;
  * ``run_all`` batch mode that keeps going after a bad file (continue option).
"""

import hashlib
import json

import gvas_engine
import ikram_logger
import paths
from theme_engine import glyph

try:
    from vip_ui import ProgressFrame
except Exception:  # imported before the shell in some entry points
    ProgressFrame = None


def _mark_outcome(vip, outcome):
    try:
        fn = getattr(vip, "_mark_outcome", None)
        if callable(fn):
            fn(outcome)
        else:
            vip._last_outcome = outcome
    except Exception:
        pass

SAV_EXT = ".sav"
GVAS_EXT = ".gvas"
SRC_EXT = ".json"
SAVE_EXTS = (SAV_EXT, GVAS_EXT)

# Refuse absurd files before allocating. Matches gvas_engine's own cap.
MAX_INPUT_BYTES = getattr(gvas_engine, "MAX_INPUT_BYTES", 512 * 1024 * 1024)


# ------------------------------------------------------------------- file io
def _list_files(folder, ext):
    folder = paths.Path(folder)
    xfolder = paths.extended_path(folder)
    if not xfolder.is_dir():
        return []
    # Filesystem calls use the extended namespace; returned paths stay logical
    # so display and reports never expose the \\?\ prefix.
    return sorted((folder / p.name for p in xfolder.iterdir()
                   if p.is_file() and p.suffix.lower() == ext),
                  key=lambda p: p.name.lower())


def _list_save_files(folder):
    """Both .sav and .gvas, sorted case-insensitively (new helper)."""
    folder = paths.Path(folder)
    xfolder = paths.extended_path(folder)
    if not xfolder.is_dir():
        return []
    return sorted((folder / p.name for p in xfolder.iterdir()
                   if p.is_file() and p.suffix.lower() in SAVE_EXTS),
                  key=lambda p: p.name.lower())


def _out_path(src, new_ext, unique=True):
    out_dir = paths.RESULT_SAVEGAMES
    paths.extended_path(out_dir).mkdir(parents=True, exist_ok=True)
    target = out_dir / (src.stem + new_ext)
    return paths.unique_path(target) if unique else target


def _atomic_write_bytes(path, data):
    """Write to a sibling temp first, then replace the target atomically.

    A failed write must never leave a truncated file with a finished name;
    the next run's unique_path() would otherwise preserve the broken file.
    """
    tmp = path.with_name(path.name + ".tmp")
    xtmp = paths.extended_path(tmp)
    xtarget = paths.extended_path(path)
    try:
        xtmp.write_bytes(data)
        xtmp.replace(xtarget)
    finally:
        try:
            xtmp.unlink(missing_ok=True)
        except OSError:
            pass


def _write_text(path, text):
    _atomic_write_bytes(path, text.encode("utf-8"))


def _read_bytes_capped(src):
    """Read a source file with a hard size cap; raises OSError on oversize."""
    xsrc = paths.extended_path(src)
    try:
        size = xsrc.stat().st_size
    except OSError:
        size = 0
    if size > MAX_INPUT_BYTES:
        raise OSError("file too large (%s)" % paths.human(size))
    with open(xsrc, "rb") as fh:
        data = fh.read(MAX_INPUT_BYTES + 1)
    if len(data) > MAX_INPUT_BYTES:
        raise OSError("file too large")
    return data


def _sha(data):
    try:
        return hashlib.sha256(data).hexdigest()
    except Exception:
        return ""


def _sha_file(path):
    try:
        return gvas_engine.sha256_file(paths.extended_path(path))
    except Exception:
        return ""


def _report_line(label, value):
    return "%s: %s" % (label, value)


def _out_label(tgt):
    return paths.folder_label(paths.RESULT_SAVEGAMES) + "/" + tgt.name


def _frame_or_callback(vip, title, phase, progress):
    """Return (frame, emit) where emit(text) drives frame or custom callback."""
    frame = None
    if progress is None and ProgressFrame is not None:
        try:
            frame = ProgressFrame(vip, title=title)
            frame.phase(phase)
        except Exception as exc:
            ikram_logger.log_exc("savegames.frame", exc)
            frame = None
    def emit(text, done=None, total=None):
        try:
            if progress is not None:
                progress(text, done, total)
            elif frame is not None:
                if done is not None and total is not None:
                    frame.step(done, total, cur=text)
                else:
                    frame.phase(text)
        except Exception as exc:
            ikram_logger.log_exc("savegames.progress", exc)
    return frame, emit


def _close_frame(frame, text):
    if frame is None:
        return
    try:
        frame.close(cur=text)
    except Exception as exc:
        ikram_logger.log_exc("savegames.frame.close", exc)


def _notify(log, message):
    if log is None:
        return
    try:
        log(message)
    except Exception as exc:
        ikram_logger.log_exc("savegames.log", exc)


# --------------------------------------------------------------- operations
def decrypt(vip, src, progress=None, log=None, wait=True, box=True):
    """.sav/.gvas -> editable .json source.

    Returns a report dict (or None on failure). ``progress(text, done, total)``
    and ``log(message)`` are optional; ``wait=False`` suppresses the final
    "Press ENTER" and ``box=False`` suppresses the panel itself, so batch
    callers can show one summary instead of N duplicate results.
    """
    show_error = vip.error_box if box else (lambda *a, **k: None)
    show_success = vip.success_box if box else (lambda *a, **k: None)
    report = None
    try:
        raw = _read_bytes_capped(src)
    except OSError as exc:
        show_error(["✗ Could not read %s" % src.name, str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "decrypt failed: %s: %s" % (src.name, exc))
        return None

    frame, emit = _frame_or_callback(vip, "Decrypting %s" % src.name,
                                    "parsing GVAS...", progress)
    try:
        gvas = gvas_engine.GvasFile.read(raw)
        emit("serializing JSON...")
        text = gvas_engine.dumps(gvas)
        props = list(gvas.iter_properties())
        report = {
            "operation": "decrypt", "input": str(src), "input_sha256": _sha(raw),
            "input_bytes": len(raw), "properties": len(props),
        }
    except gvas_engine.GvasError as exc:
        _close_frame(frame, "Failed")
        show_error([
            "✗ Not a readable GVAS save",
            "%s: %s" % (src.name, str(exc)[:60]),
        ], next_step="this .sav is not a PUBG/BGMI GVAS file")
        if wait:
            vip.wait_enter()
        _notify(log, "decrypt failed: %s: %s" % (src.name, exc))
        return None
    except Exception as exc:
        ikram_logger.log_exc("savegames.decrypt", exc)
        _close_frame(frame, "Failed")
        show_error(["✗ Decrypt failed", str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "decrypt failed: %s: %s" % (src.name, exc))
        return None

    tgt = _out_path(src, SRC_EXT)
    try:
        emit("writing source...")
        _write_text(tgt, text)
    except OSError as exc:
        _close_frame(frame, "Failed")
        show_error(["✗ Could not write source", str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "decrypt failed: %s: %s" % (tgt.name, exc))
        return None
    _close_frame(frame, "Decrypt done")

    report["output"] = str(tgt)
    report["output_sha256"] = _sha_file(tgt)
    report["output_bytes"] = len(text.encode("utf-8"))
    show_success([
        "✓ Decrypted (source ready)",
        "File  : %s" % src.name,
        "Output: %s" % _out_label(tgt),
        "Properties: %d" % len(props),
        _report_line("SHA256", report["output_sha256"][:16] + "..."),
        "Edit the values in the .json, then Encrypt it back.",
    ])
    if wait:
        vip.wait_enter()
    _notify(log, "decrypt ok: %s -> %s (%d properties, sha=%s)"
            % (src.name, tgt.name, len(props), report["output_sha256"]))
    return report


def encrypt(vip, src, progress=None, log=None, wait=True, box=True):
    """Editable .json source -> compiled .sav bytes.

    Same optional callbacks/return contract as :func:`decrypt`.
    """
    show_error = vip.error_box if box else (lambda *a, **k: None)
    show_success = vip.success_box if box else (lambda *a, **k: None)
    try:
        text = _read_bytes_capped(src).decode("utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        show_error(["✗ Could not read %s" % src.name, str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "encrypt failed: %s: %s" % (src.name, exc))
        return None

    frame, emit = _frame_or_callback(vip, "Encrypting %s" % src.name,
                                    "compiling GVAS...", progress)
    try:
        gvas = gvas_engine.loads(text)
        emit("building binary...")
        out = gvas.write()
        props = list(gvas.iter_properties())
    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        _close_frame(frame, "Failed")
        show_error([
            "✗ Source file is not valid",
            "%s: %s" % (src.name, str(exc)[:64]),
        ], next_step="use a .json produced by Decrypt")
        if wait:
            vip.wait_enter()
        _notify(log, "encrypt failed: %s: %s" % (src.name, exc))
        return None
    except gvas_engine.GvasError as exc:
        _close_frame(frame, "Failed")
        show_error(["✗ Encrypt failed", str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "encrypt failed: %s: %s" % (src.name, exc))
        return None
    except Exception as exc:
        ikram_logger.log_exc("savegames.encrypt", exc)
        _close_frame(frame, "Failed")
        show_error(["✗ Encrypt failed", str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "encrypt failed: %s: %s" % (src.name, exc))
        return None

    tgt = _out_path(src, SAV_EXT)
    try:
        emit("writing .sav...")
        _atomic_write_bytes(tgt, out)
    except OSError as exc:
        _close_frame(frame, "Failed")
        show_error(["✗ Could not write .sav", str(exc)[:64]])
        if wait:
            vip.wait_enter()
        _notify(log, "encrypt failed: %s: %s" % (tgt.name, exc))
        return None
    _close_frame(frame, "Encrypt done")

    sha = _sha(out)
    show_success([
        "✓ Encrypted (.sav compiled)",
        "File  : %s" % src.name,
        "Output: %s" % _out_label(tgt),
        "Size  : %s" % paths.human(len(out)),
        "Properties: %d" % len(props),
        _report_line("SHA256", sha[:16] + "..."),
    ])
    if wait:
        vip.wait_enter()
    report = {
        "operation": "encrypt", "input": str(src),
        "input_sha256": _sha(text.encode("utf-8")),
        "output": str(tgt), "output_sha256": sha, "output_bytes": len(out),
        "properties": len(props),
    }
    _notify(log, "encrypt ok: %s -> %s (%d properties, sha=%s)"
            % (src.name, tgt.name, len(props), sha))
    return report


# ------------------------------------------------------------------------ run
def _pick_file(vip, files, title, subtitle):
    """File picker. Returns the chosen Path or None (caller goes back)."""
    while True:
        vip.cls()
        # Name alone is ambiguous once Encrypt lists both DROP and RESULT, so
        # every row carries where the file came from.
        rows = []
        for i, p in enumerate(files, 1):
            try:
                detail = "%s   ·   %s" % (paths.human(paths.extended_path(p).stat().st_size),
                                           paths.folder_label(p.parent))
            except OSError as exc:
                detail = "?   ·   %s (unreadable: %s)" % (paths.folder_label(p.parent),
                                                          str(exc)[:24])
            rows.append((str(i), p.name, [detail]))
        rows.append(("0", "← Back", []))
        vip.write(vip.box.draw_menu(rows, title=title, subtitle=subtitle) + "\n")
        got = vip.prompt_in(tuple(str(i) for i in range(1, len(files) + 1))
                            + ("0",), glyph("arrow") + " SELECT:",
                            main="SAVEGAMES CHOICE")
        if not got or got == "0":
            return None
        try:
            return files[int(got) - 1]
        except (ValueError, IndexError):
            continue


def _collect_encrypt_files():
    """DROP first, then RESULT sources; DROP wins on a name clash."""
    files = list(_list_files(paths.DROP_SAVEGAMES, SRC_EXT))
    have = {p.name.lower() for p in files}
    for p in _list_files(paths.RESULT_SAVEGAMES, SRC_EXT):
        if p.name.lower() not in have:
            files.append(p)
            have.add(p.name.lower())
    return files


def run_all(vip, encrypt_mode=False, progress=None, log=None,
            continue_on_error=True):
    """Batch helper: process every matching file, report totals (new helper).

    Returns a report dict with per-file results and counts. ``continue_on_error``
    controls whether a corrupt file aborts the batch or is skipped.
    """
    folder = paths.DROP_SAVEGAMES
    paths.extended_path(folder).mkdir(parents=True, exist_ok=True)
    if encrypt_mode:
        files = _collect_encrypt_files()
    else:
        files = _list_save_files(folder)
    action = encrypt if encrypt_mode else decrypt
    results = []
    total = len(files)
    show_context = getattr(vip, "show_file_context", None)
    if callable(show_context):
        show_context(
            files[0].name if files else "-",
            [p.name for p in files[1:]],
            title="SAVEGAMES BATCH",
            mode="encrypt" if encrypt_mode else "decrypt",
            target=paths.folder_label(folder),
            output=paths.folder_label(paths.RESULT_SAVEGAMES),
            limit=12)
    for i, src in enumerate(files, 1):
        def emit(text, done=None, total=total, _i=i, _total=total):  # noqa: B023
            if progress is not None:
                try:
                    progress("[%d/%d] %s" % (_i, _total, text), done, total)
                except Exception as exc:
                    ikram_logger.log_exc("savegames.run_all.progress", exc)
        rep = action(vip, src, progress=emit, log=log,
                     wait=False, box=False)
        if rep is None:
            results.append({"input": str(src), "ok": False})
            if not continue_on_error:
                break
        else:
            rep["ok"] = True
            results.append(rep)
    # A fail-fast batch stops before the discovered end: report what was
    # actually attempted, and keep `discovered` for the full scan count.
    attempted = len(results) if not continue_on_error else total
    report = {
        "operation": "encrypt_all" if encrypt_mode else "decrypt_all",
        "attempted": attempted, "processed": len(results),
        "discovered": total,
        "succeeded": sum(1 for r in results if r.get("ok")),
        "failed": sum(1 for r in results if not r.get("ok")),
        "results": results,
    }
    failed = report["failed"]
    rows = [
        "%s Batch %s %s" % ("✓" if failed == 0 else "!" if failed < total else "✗",
                            "encrypt" if encrypt_mode else "decrypt",
                            "complete" if failed == 0 else "with failures"),
        "Attempted: %d" % attempted,
        "Succeeded: %d  Failed: %d" % (report["succeeded"], failed),
        "Output: %s" % paths.folder_label(paths.RESULT_SAVEGAMES),
    ]
    if not total:
        vip.warn_box([
            "! Batch %s complete: no files found" % (
                "encrypt" if encrypt_mode else "decrypt"),
        ])
    elif failed == total and total:
        vip.error_box(rows, next_step="check DROP/SaveGames and retry")
    elif failed:
        vip.warn_box(rows)
    else:
        vip.success_box(rows)
    vip.wait_enter()
    _notify(log, "batch %s: %d/%d ok" % (report["operation"],
                                         report["succeeded"], total))
    return report


def run(vip):
    """SaveGames flow, dispatched from the main menu.

    Two options first (Encrypt / Decrypt, like the LUA tool), then the file
    picker for the chosen operation, then the work. A third option processes
    every discovered file in one pass (continue-on-error).
    """
    folder = paths.DROP_SAVEGAMES
    paths.extended_path(folder).mkdir(parents=True, exist_ok=True)

    while True:
        vip.cls()
        vip.write(vip.box.draw_menu([
            ("1", "🔒 Encrypt", ["compile a source .json back into a .sav",
                                 "PUT IN: DROP/SaveGames (.json)",
                                 "OUTPUT: RESULT/SaveGames/"]),
            ("2", "🔓 Decrypt", ["turn a .sav/.gvas into an editable .json source",
                                 "PUT IN: DROP/SaveGames (.sav/.gvas)",
                                 "OUTPUT: RESULT/SaveGames/"]),
            ("3", "🔁 Process all", ["batch: decrypt every .sav/.gvas",
                                    "skips bad files and keeps going",
                                    "OUTPUT: RESULT/SaveGames/"]),
            ("0", "← Back", []),
        ], title="💾 SAVEGAMES TOOL 💾",
            subtitle="PICK AN OPERATION") + "\n")
        got = vip.prompt_in(("1", "2", "3", "0"), glyph("arrow") + " SELECT:",
                            main="SAVEGAMES CHOICE")
        if not got or got == "0":
            _mark_outcome(vip, "CANCEL")
            return

        if got == "3":
            run_all(vip, encrypt_mode=False)
            continue

        encrypt_mode = got == "1"
        label = "Encrypt" if encrypt_mode else "Decrypt"
        ext = SRC_EXT if encrypt_mode else SAV_EXT
        files = (_collect_encrypt_files() if encrypt_mode
                 else _list_save_files(folder))

        if not files:
            vip.cls()
            try:
                folder_has_entries = any(paths.extended_path(folder).iterdir())
            except OSError:
                folder_has_entries = True
            message = [
                "✗ No %s files found" % ext,
                "%s/ has no %s file" % (paths.folder_label(folder), ext),
            ]
            if folder_has_entries:
                vip.warn_box(message)
            else:
                vip.error_box(
                    message,
                    next_step="drop a %s into %s/"
                              % (".json source" if encrypt_mode
                                 else ".sav/.gvas",
                                 paths.folder_label(folder)))
            vip.wait_enter()
            continue

        src = _pick_file(vip, files,
                         "💾 SAVEGAMES TOOL 💾",
                         "%s — PICK %s FILE" % (label.upper(), ext.upper()))
        if src is None:
            _mark_outcome(vip, "CANCEL")
            continue

        vip.cls()
        show_context = getattr(vip, "show_file_context", None)
        if callable(show_context):
            show_context(
                src.name, [p.name for p in files if p != src],
                title="SAVEGAMES FILE", mode=label,
                target=paths.folder_label(src.parent),
                output=paths.folder_label(paths.RESULT_SAVEGAMES),
                limit=12)
        action = (lambda v, _s=src: encrypt(v, _s)) if encrypt_mode \
            else (lambda v, _s=src: decrypt(v, _s))
        action(vip)
