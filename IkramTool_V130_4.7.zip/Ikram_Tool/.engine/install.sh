#!/usr/bin/env bash
# ============================================================================
#  Ikram Tool V130 - installer (Termux / Linux / WSL / macOS)
#
#  Layout it produces:
#
#      $HOME/Ikram_Tool/
#          .engine/      every runtime file (python, engines, engines' bins)
#          DROP/         your input    (pak / lua / inject / SaveGames)
#          RESULT/       tool output
#          VERSION
#          install.sh
#          run.sh  run.bat
#
#  The core is CPython 3.14 bytecode, so the installer guarantees a 3.14
#  interpreter before anything runs: existing python3.14 -> package -> build
#  from source once (cached in $HOME/.ikram/py314).
#
#  Usage: bash install.sh [--force] [--no-deps] [--no-anim]
#                         [--python PATH] [--help]
# ============================================================================
set -uo pipefail

SCRIPT_NAME="Ikram Tool"
SCRIPT_VERSION="V130"
NEED_MAJOR=3
NEED_MINOR=14

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${IKRAM_HOME:-$HOME/Ikram_Tool}"
PYROOT="${IKRAM_PYROOT:-$HOME/.ikram/py314}"
ENGINE="$TARGET/.engine"
PY_OVERRIDE=""
BUILD_STEP_DONE=0

FORCE=0
NO_DEPS=0
NO_TOOLS=0
ANIM=1
PLAT="unix"
PKG=""
BIN_DIR="/usr/local/bin"
PY=""

# ------------------------------------------------------------------ output ---
# Called for a non-TTY and again when --no-anim is parsed, so a coloured TTY
# banner can never leak ANSI bytes into plain output.
plain_output() {
    C_RESET=""; C_DIM=""; C_B=""; C_CY=""; C_GR=""; C_RD=""; C_YL=""; C_MG=""
    C_BRAND=""
}

if [ -t 1 ]; then
    C_RESET=$'\033[0m'; C_DIM=$'\033[2m'; C_B=$'\033[1m'
    C_CY=$'\033[36m'; C_GR=$'\033[32m'; C_RD=$'\033[31m'
    C_YL=$'\033[33m'; C_MG=$'\033[35m'
    C_BRAND=$'\033[1;4;38;5;201m'
else
    plain_output
    ANIM=0
fi

hr()    { printf '  %s\n' "${C_DIM}────────────────────────────────────────────────────────────${C_RESET}"; }
info()  { printf '  %s\n' "$*"; }
ok()    { printf '  %s[OK]%s %s\n' "${C_GR}" "${C_RESET}" "$*"; }
warn()  { printf '  %s[!]%s %s\n' "${C_YL}" "${C_RESET}" "$*"; }
die()   { printf '  %s[X]%s %s\n' "${C_RD}" "${C_RESET}" "$*" >&2; exit 1; }
step()  { printf '\n  %s%s%s  %s\n' "${C_MG}${C_B}" "$1" "${C_RESET}" "$2"; }

banner() {
    printf '\n'
    hr
    printf '  %s%s%s  %s%s%s\n' "${C_BRAND}" "$SCRIPT_NAME" "${C_RESET}" \
           "${C_DIM}" "$SCRIPT_VERSION  ·  installer" "${C_RESET}"
    printf '  %s\n' "${C_DIM}termux · linux · wsl · macos${C_RESET}"
    hr
    if [ "$ANIM" -eq 1 ]; then
        local bar="" i
        for i in 1 2 3 4 5 6 7 8 9 10 11 12; do
            bar+="█"
            printf '\r  %s%s%s' "${C_CY}" "$bar" "${C_RESET}"
            sleep 0.02
        done
        printf '\r  %s%s%s\n' "${C_DIM}" "────────────────────────────────────────────────────────────" "${C_RESET}"
    fi
}

# ---------------------------------------------------------------- spinner ---
_spin() {
    local label="$1"; shift
    if [ "$ANIM" -ne 1 ]; then
        info "$label"
        "$@" >/dev/null 2>&1
        return $?
    fi
    local frames=(⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏)
    local i=0 rc=0 start=$SECONDS pid
    "$@" >/dev/null 2>&1 &
    pid=$!
    while kill -0 "$pid" 2>/dev/null; do
        printf '\r  %s%s%s %-46s %s%3ds%s' \
            "${C_CY}" "${frames[$i]}" "${C_RESET}" "$label" \
            "${C_DIM}" "$((SECONDS - start))" "${C_RESET}"
        i=$(( (i + 1) % 10 ))
        sleep 0.1
    done
    wait "$pid"; rc=$?
    printf '\r\033[2K'
    if [ "$rc" -eq 0 ]; then
        printf '  %s[OK]%s %s\n' "${C_GR}" "${C_RESET}" "$label"
    else
        printf '  %s[X]%s %s\n' "${C_RD}" "${C_RESET}" "$label"
    fi
    return "$rc"
}

# ------------------------------------------------------------------- args ---
usage() {
    cat <<'EOF'

  Ikram Tool installer

  Usage:
    bash install.sh [OPTIONS]

  Options:
    -f, --force        clean reinstall (wipes the target first)
        --no-deps      skip python packages + preflight
        --no-tools     skip java + lua 5.1-5.4 + luajit (lua menu installs later)
        --no-anim      plain output (no spinner, no colour)
        --python PATH  use this interpreter (must be >= 3.14)
    -h, --help         show this help

  Install location : $HOME/Ikram_Tool          (IKRAM_HOME=/path)
  Private python   : $HOME/.ikram/py314        (IKRAM_PYROOT=/path)

  After install:  ikram
EOF
}

parse_args() {
    while [ $# -gt 0 ]; do
        case "$1" in
            -h|--help)   usage; exit 0 ;;
            -f|--force)  FORCE=1 ;;
            --no-deps)   NO_DEPS=1 ;;
            --no-tools)  NO_TOOLS=1 ;;
            --no-anim)   ANIM=0; plain_output ;;
            --python)    shift; PY_OVERRIDE="${1:-}"; [ -n "$PY_OVERRIDE" ] || die "--python needs a path" ;;
            --python=*)  PY_OVERRIDE="${1#*=}" ;;
            *)           die "unknown option: $1  (try --help)" ;;
        esac
        shift
    done
}

# --------------------------------------------------------------- platform ---
detect_platform() {
    local uname_s
    uname_s="$(uname -s 2>/dev/null || echo unknown)"

    if [ -n "${TERMUX_VERSION:-}" ] || [ -d /data/data/com.termux/files/usr/bin ]; then
        PLAT="termux"; PKG="pkg"
        BIN_DIR="${PREFIX:-/data/data/com.termux/files/usr}/bin"
    elif [ "$uname_s" = "Darwin" ]; then
        PLAT="macos"; PKG="brew"; BIN_DIR="/usr/local/bin"
    elif command -v apt-get >/dev/null 2>&1; then
        PLAT="debian"; PKG="apt"
    elif command -v dnf >/dev/null 2>&1; then
        PLAT="fedora"; PKG="dnf"
    elif command -v pacman >/dev/null 2>&1; then
        PLAT="arch"; PKG="pacman"
    elif command -v zypper >/dev/null 2>&1; then
        PLAT="suse"; PKG="zypper"
    elif [ "$uname_s" = "Linux" ]; then
        PLAT="linux"; PKG=""
    fi

    if [ ! -d "$BIN_DIR" ] || [ ! -w "$BIN_DIR" ]; then
        BIN_DIR="$HOME/.local/bin"
        mkdir -p "$BIN_DIR"
    fi

    ok "platform  : $PLAT${PKG:+   (pkg: $PKG)}"
    ok "bin dir   : $BIN_DIR"
    ok "install   : $TARGET"
}

pkg_install() {
    [ -n "$PKG" ] || return 1
    case "$PKG" in
        pkg)    pkg install -y "$@" </dev/null >/dev/null 2>&1 ;;
        apt)    sudo apt-get install -y "$@" </dev/null >/dev/null 2>&1 || apt-get install -y "$@" </dev/null >/dev/null 2>&1 ;;
        dnf)    sudo dnf install -y "$@" </dev/null >/dev/null 2>&1 || dnf install -y "$@" </dev/null >/dev/null 2>&1 ;;
        pacman) sudo pacman -S --noconfirm --needed "$@" </dev/null >/dev/null 2>&1 || pacman -S --noconfirm --needed "$@" </dev/null >/dev/null 2>&1 ;;
        zypper) sudo zypper -n install "$@" </dev/null >/dev/null 2>&1 || zypper -n install "$@" </dev/null >/dev/null 2>&1 ;;
        brew)   brew install "$@" </dev/null >/dev/null 2>&1 ;;
        *)      return 1 ;;
    esac
}

# ----------------------------------------------------------------- python ---
# EXACT minor match, not >=. CPython bumps the bytecode magic every minor
# release, so a 3.15 interpreter raises "bad magic number" on ikram.pyc and the
# tool cannot start. `>= (3,14)` declared installs healthy on a 3.15 box and
# then the app died at launch - the single most common broken-install report.
py_version_ok() {
    [ -n "${1:-}" ] || return 1
    "$1" -c 'import sys; raise SystemExit(0 if sys.version_info[:2] == (3,14) else 1)' \
        >/dev/null 2>&1
}

py_version_of() {
    "$1" -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])' 2>/dev/null || printf '?'
}

find_python() {
    local c
    if [ -n "$PY_OVERRIDE" ]; then
        [ -x "$PY_OVERRIDE" ] || command -v "$PY_OVERRIDE" >/dev/null 2>&1 \
            || die "--python not executable: $PY_OVERRIDE"
        py_version_ok "$PY_OVERRIDE" \
            || die "--python $(py_version_of "$PY_OVERRIDE") cannot load the core - it is 3.14 bytecode, and 3.14 is an exact requirement"
        PY="$PY_OVERRIDE"
        ok "python    : $(py_version_of "$PY")   [--python]"
        return 0
    fi
    if [ -x "$PYROOT/bin/python3" ] && py_version_ok "$PYROOT/bin/python3"; then
        PY="$PYROOT/bin/python3"
        ok "python    : $(py_version_of "$PY")   [cached build]"
        return 0
    fi
    for c in python3.14 python3 python; do
        command -v "$c" >/dev/null 2>&1 || continue
        if py_version_ok "$c"; then
            PY="$(command -v "$c")"
            ok "python    : $(py_version_of "$PY")   [system]"
            return 0
        fi
    done
    return 1
}

try_pkg_python() {
    _spin "installing a packaged python $NEED_MAJOR.$NEED_MINOR" _pkg_python_body
    find_python
}

_pkg_python_body() {
    case "$PLAT" in
        termux) pkg update -y >/dev/null 2>&1 || true
                pkg_install python || true
                pkg_install python3.14 || true ;;
        debian) pkg_install "python$NEED_MAJOR.$NEED_MINOR" \
                            "python$NEED_MAJOR.$NEED_MINOR-venv" || true ;;
        fedora) pkg_install "python$NEED_MAJOR.$NEED_MINOR" || true ;;
        arch)   pkg_install python || true ;;
        suse)   pkg_install "python$NEED_MAJOR$NEED_MINOR" || true ;;
        macos)  pkg_install "python@$NEED_MAJOR.$NEED_MINOR" || true ;;
        *)      return 1 ;;
    esac
}

fetch() {
    if command -v curl >/dev/null 2>&1; then
        curl -fL --retry 3 --connect-timeout 20 -o "$2" "$1" && return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q -O "$2" "$1" && return 0
    fi
    return 1
}

build_python() {
    BUILD_STEP_DONE=1
    step "3/10" "building CPython $NEED_MAJOR.$NEED_MINOR (one time, cached)"
    warn "this can take 15-30 min on a phone - keep it charging"
    _spin "installing build tools" _build_tools || die "build tools failed"
    command -v cc >/dev/null 2>&1 || command -v clang >/dev/null 2>&1 \
        || command -v gcc >/dev/null 2>&1 \
        || die "no C compiler - install clang/gcc first, then rerun"

    local work="$HOME/.ikram/build"
    mkdir -p "$work" || die "cannot create $work"
    local ver tarball url have=""
    for ver in 3.14.3 3.14.2 3.14.1 3.14.0; do
        tarball="$work/Python-$ver.tar.xz"
        [ -s "$tarball" ] && { have="$ver"; break; }
        url="https://www.python.org/ftp/python/$ver/Python-$ver.tar.xz"
        if _spin "download python $ver" fetch "$url" "$tarball"; then have="$ver"; break; fi
        rm -f "$tarball"
    done
    [ -n "$have" ] || die "could not download CPython 3.14 (check network)"
    _spin "extract python $have" tar -C "$work" -xf "$work/Python-$have.tar.xz" \
        || die "extract failed"
    local src="$work/Python-$have"
    local jobs
    jobs="$( (command -v nproc >/dev/null 2>&1 && nproc) || echo 2 )"
    case "$jobs" in ''|*[!0-9]*) jobs=2 ;; esac
    [ "$jobs" -gt 4 ] && jobs=4

    _spin "configure  (prefix $PYROOT)" bash -c \
        "cd '$src' && ./configure --prefix='$PYROOT' --with-ensurepip=install \
            --disable-test-modules --without-static-libpython >/dev/null 2>&1" \
        || die "configure failed"
    step "3/10" "compiling with $jobs jobs - this is the long part"
    ( cd "$src" && make -j"$jobs" ) || die "make failed"
    _spin "install" bash -c "cd '$src' && make install >/dev/null 2>&1" \
        || die "make install failed"
    rm -f "$PYROOT/bin/python3.14-config" 2>/dev/null || true
    [ -x "$PYROOT/bin/python3" ] || die "python3 missing in $PYROOT/bin"
    py_version_ok "$PYROOT/bin/python3" || die "built interpreter is wrong version"
    PY="$PYROOT/bin/python3"
    ok "python    : $(py_version_of "$PY")   [built]"
}

_build_tools() {
    case "$PLAT" in
        termux) pkg_install clang make binutils pkg-config openssl libffi zlib \
                            bzip2 xz-utils sqlite readline ncurses \
                            libandroid-support ca-certificates || true ;;
        debian) pkg_install build-essential pkg-config libssl-dev libffi-dev \
                            zlib1g-dev libbz2-dev liblzma-dev libsqlite3-dev \
                            libreadline-dev libncursesw5-dev curl || true ;;
        fedora) pkg_install gcc make pkgconf-pkg-config openssl-devel libffi-devel \
                            zlib-devel bzip2-devel xz-devel sqlite-devel \
                            readline-devel ncurses-devel curl || true ;;
        arch)   pkg_install base-devel openssl libffi zlib bzip2 xz sqlite \
                            readline ncurses curl || true ;;
        suse)   pkg_install gcc make pkg-config libopenssl-devel libffi-devel \
                            zlib-devel libbz2-devel xz-devel sqlite3-devel \
                            readline-devel ncurses-devel curl || true ;;
        macos)  pkg_install openssl readline sqlite3 xz zlib || true ;;
    esac
}

ensure_python() {
    find_python && return 0
    try_pkg_python && return 0
    build_python
}

# ------------------------------------------------------------------ files ---
_CLEAN_EXCLUDES=(__pycache__ .ikram_tool last_action.json error.log backups rollback luac.out)
_UNIX_SKIP=(python314)

copy_runtime() { # copy engine-shaped tree, no caches
    local src="$1" dst="$2"
    mkdir -p "$dst" || return 1
    if command -v rsync >/dev/null 2>&1; then
        local ex=() x
        for x in "${_CLEAN_EXCLUDES[@]}" "${_UNIX_SKIP[@]}"; do
            ex+=(--exclude "$x")
        done
        rsync -a "${ex[@]}" "$src"/ "$dst"/ && return 0
    fi
    local tarx=() x
    for x in "${_CLEAN_EXCLUDES[@]}" "${_UNIX_SKIP[@]}"; do
        tarx+=(--exclude="$x")
    done
    tar -C "$src" "${tarx[@]}" -cf - . | tar -C "$dst" -xf -
}

copy_flat_root() { # dev layout: root runtime files -> .engine
    local src="$1" dst="$2"
    mkdir -p "$dst" || return 1
    tar -C "$src" \
        --exclude='./DROP' --exclude='./RESULT' --exclude='./.engine' \
        --exclude='./__pycache__' --exclude='./.ikram_tool' \
        --exclude='./error.log' --exclude='./*.log' \
        --exclude='./backups' --exclude='./rollback' --exclude='./luac.out' \
        -cf - . | tar -C "$dst" -xf -
}

stage_files() {
    step "4/10" "staging runtime -> .engine"
    if [ "$SRC" = "$TARGET" ] || [ "$SRC" = "$ENGINE" ]; then
        mkdir -p "$ENGINE"
        if [ -f "$SRC/ikram_patch.py" ]; then
            # engine-dir layout (all files in .engine, root keeps only DROP/RESULT)
            if [ "$SRC" != "$ENGINE" ]; then
                _spin "copy runtime -> .engine" copy_runtime "$SRC" "$ENGINE" || die "copy failed"
            fi
            ok "runtime in place (.engine)"
        else
            local e moved=0
            shopt -s dotglob nullglob 2>/dev/null || true
            for e in "$SRC"/*; do
                case "$(basename "$e")" in
                    .engine|DROP|RESULT) continue ;;
                esac
                mv -- "$e" "$ENGINE"/ && moved=$((moved + 1))
            done
            shopt -u dotglob nullglob 2>/dev/null || true
            ok "runtime in place ($moved items in .engine)"
        fi
    else
        mkdir -p "$TARGET" || die "cannot create $TARGET"
        if [ -f "$SRC/ikram_patch.py" ]; then
            _spin "copy runtime -> .engine" copy_runtime "$SRC" "$ENGINE" || die "copy failed"
        elif [ -d "$SRC/.engine" ]; then
            _spin "copy runtime -> .engine" copy_runtime "$SRC/.engine" "$ENGINE" || die "copy failed"
        else
            _spin "copy runtime -> .engine" copy_flat_root "$SRC" "$ENGINE" || die "copy failed"
        fi
        # layout: only DROP and RESULT in tool root; all runtime files in .engine
        ok "runtime copied"
    fi

    [ -f "$ENGINE/ikram_patch.py" ] || die "staging failed - ikram_patch.py missing"
    [ -f "$ENGINE/ikram.pyc" ]      || die "staging failed - ikram.pyc missing"
    mkdir -p "$TARGET/DROP/pak" "$TARGET/DROP/lua" "$TARGET/DROP/inject" \
             "$TARGET/DROP/SaveGames" "$TARGET/RESULT" \
             "$TARGET/RESULT/extracted" "$TARGET/RESULT/injected" \
             "$TARGET/RESULT/lua" "$TARGET/RESULT/processed" \
             "$TARGET/RESULT/CostomPak" "$TARGET/RESULT/Repacked" \
             "$TARGET/RESULT/SaveGames"
    [ -f "$ENGINE/VERSION" ] || printf 'V130\n' > "$ENGINE/VERSION"
    [ -f "$ENGINE/ikram_key.json" ] || die "staging failed - ikram_key.json missing"
    ok "DROP / RESULT ready"
}

validate_key_file() {
    step "5/10" "tool key file"
    [ -f "$ENGINE/license_setup.py" ] || die "key file helper missing"
    _spin "checking key file" "$PY" -X utf8 "$ENGINE/license_setup.py" \
        || die "tool key file invalid"
}

fix_perms() {
    step "6/10" "marking engines executable"
    local f
    for f in luac_patched luac_deep lua_patched luadec.fresh repak unluac_rs PakTool.py paktool run.sh install.sh; do
        [ -f "$ENGINE/$f" ] && chmod +x "$ENGINE/$f" 2>/dev/null || true
    done
    [ -d "$ENGINE/scripts" ] && find "$ENGINE/scripts" -name '*.sh' -exec chmod +x {} + 2>/dev/null || true
    [ -d "$ENGINE/skuy_engine" ] && find "$ENGINE/skuy_engine" -maxdepth 1 -type f \
        ! -name '*.py' ! -name '*.so' ! -name '*.jar' -exec chmod +x {} + 2>/dev/null || true
    ok "engines executable"
}

# ------------------------------------------------------------- host tools ---
have_java() { command -v java >/dev/null 2>&1; }
have_luajit() { command -v luajit >/dev/null 2>&1; }
have_luac() {
    case "$1" in
        51) command -v luac5.1 >/dev/null 2>&1 ;;
        52) command -v luac5.2 >/dev/null 2>&1 ;;
        53) command -v luac5.3 >/dev/null 2>&1 && return 0
            command -v luac >/dev/null 2>&1 || return 1
            luac -v 2>&1 | grep -q '5\.3' ;;
        54) command -v luac5.4 >/dev/null 2>&1 ;;
        *)  return 1 ;;
    esac
}

host_tools() {
    if [ "$NO_TOOLS" -eq 1 ]; then
        step "7/10" "host engines (java + lua)"
        warn "skipped (--no-tools) - the Lua menu will offer the install"
        return 0
    fi
    step "7/10" "host engines (java + lua)"

    local pkgs=""
    case "$PLAT" in
        termux) have_java || pkgs="$pkgs openjdk-17"
                have_luac 51 || pkgs="$pkgs lua51"
                have_luac 52 || pkgs="$pkgs lua52"
                have_luac 53 || pkgs="$pkgs lua53"
                have_luac 54 || pkgs="$pkgs lua54"
                have_luajit  || pkgs="$pkgs luajit" ;;
        debian) have_java || pkgs="$pkgs default-jre-headless"
                have_luac 51 || pkgs="$pkgs lua5.1"
                have_luac 52 || pkgs="$pkgs lua5.2"
                have_luac 53 || pkgs="$pkgs lua5.3"
                have_luac 54 || pkgs="$pkgs lua5.4"
                have_luajit  || pkgs="$pkgs luajit" ;;
        fedora) have_java || pkgs="$pkgs java-17-openjdk"
                have_luac 53 || pkgs="$pkgs lua"
                have_luajit  || pkgs="$pkgs luajit" ;;
        arch)   have_java || pkgs="$pkgs jre-openjdk"
                have_luac 51 || pkgs="$pkgs lua51"
                have_luac 52 || pkgs="$pkgs lua52"
                have_luac 53 || pkgs="$pkgs lua53"
                have_luac 54 || pkgs="$pkgs lua54"
                have_luajit  || pkgs="$pkgs luajit" ;;
        suse)   have_java || pkgs="$pkgs java-17-openjdk"
                have_luac 51 || pkgs="$pkgs lua51"
                have_luac 52 || pkgs="$pkgs lua52"
                have_luac 53 || pkgs="$pkgs lua53"
                have_luac 54 || pkgs="$pkgs lua54"
                have_luajit  || pkgs="$pkgs luajit" ;;
        macos)  have_java || pkgs="$pkgs openjdk"
                have_luac 51 || pkgs="$pkgs lua@5.1"
                have_luac 52 || pkgs="$pkgs lua@5.2"
                have_luac 53 || pkgs="$pkgs lua@5.3"
                have_luac 54 || pkgs="$pkgs lua@5.4"
                have_luajit  || pkgs="$pkgs luajit" ;;
        *)      : ;;
    esac

    if [ -z "$PKG" ]; then
        warn "no package manager - bundled lua engines will be used"
    elif [ -z "$pkgs" ]; then
        ok "java + lua 5.1/5.2/5.3/5.4 + luajit already present"
    else
        info "installing:$pkgs"
        _spin "package manager is downloading" pkg_install $pkgs || true
    fi

    # Real verification: every line below is a live PATH probe, not a plan.
    local miss=0
    if have_java; then ok "java (JDK)"; else warn "java (JDK) missing"; miss=$((miss+1)); fi
    if have_luac 51; then ok "luac 5.1"; else warn "luac 5.1 missing"; miss=$((miss+1)); fi
    if have_luac 52; then ok "luac 5.2"; else warn "luac 5.2 missing"; miss=$((miss+1)); fi
    if have_luac 53; then ok "luac 5.3"; else warn "luac 5.3 missing"; miss=$((miss+1)); fi
    if have_luac 54; then ok "luac 5.4"; else warn "luac 5.4 missing"; miss=$((miss+1)); fi
    if have_luajit;  then ok "luajit";   else warn "luajit missing";   miss=$((miss+1)); fi
    [ "$miss" -eq 0 ] || warn "$miss engine(s) missing - the Lua menu installs them on demand"
}

install_deps() {
    if [ "$NO_DEPS" -eq 1 ]; then
        step "8/10" "python packages"
        warn "skipped (--no-deps)"
        return 0
    fi
    step "8/10" "python packages"
    "$PY" -m ensurepip --upgrade >/dev/null 2>&1 || true
    if ! "$PY" -m pip --version >/dev/null 2>&1; then
        warn "pip unavailable - the tool needs: rich pycryptodome lz4 zstandard gmalg"
        return 0
    fi
    _pip_flags="--upgrade --quiet --disable-pip-version-check"
    [ "$FORCE" -eq 1 ] && _pip_flags="--upgrade --force-reinstall --quiet --disable-pip-version-check"
    _spin "rich  pycryptodome  lz4  zstandard  gmalg" \
        "$PY" -m pip install $_pip_flags \
        rich pycryptodome lz4 zstandard gmalg \
        && ok "core python packages ready" \
        || warn "some packages failed - run again with network"
}

run_preflight() {
    if [ "$NO_DEPS" -eq 1 ]; then
        step "9/10" "deep preflight"
        warn "skipped (--no-deps)"
        return 0
    fi
    step "9/10" "deep preflight"
    local report rc
    report="$( cd "$ENGINE" && "$PY" preflight.py 2>&1 )"; rc=$?
    local ready total
    ready="$(printf '%s\n' "$report" | sed -n 's/.*— \([0-9]*\)\/\([0-9]*\) ready.*/\1/p' | head -1)"
    total="$(printf '%s\n' "$report" | sed -n 's/.*— \([0-9]*\)\/\([0-9]*\) ready.*/\2/p' | head -1)"
    if [ -z "$ready" ]; then
        # all-green summary line: "IkramTool preflight — all 37 components ready"
        total="$(printf '%s\n' "$report" | sed -n 's/.*all \([0-9]*\) components ready.*/\1/p' | head -1)"
        ready="$total"
    fi
    ready="${ready:-?}"; total="${total:-?}"
    if ! printf '%s\n' "$report" | grep -q '!!'; then
        ok "$ready/$total components ready"
    else
        local bad
        bad="$(printf '%s\n' "$report" | sed -n 's/^!! /  ! /p')"
        if printf '%s\n' "$report" | sed -n 's/^!! *//p' \
             | grep -qiE 'java|luac|luajit'; then
            printf '%s\n' "$report" | grep '^!!' | sed 's/^!! /  /' | while IFS= read -r l; do
                printf '  %s·%s %s\n' "${C_DIM}" "${C_RESET}" "$l"
            done
            ok "$ready/$total ready  ·  optional host tools skipped (bundled engines used)"
        else
            warn "preflight found missing essentials:"
            printf '%s\n' "$bad"
            die "installation incomplete - see the lines above"
        fi
    fi
}

setup_launcher() {
    step "10/10" "launchers"
    local launcher="$BIN_DIR/ikram"
    local paktool_launcher="$BIN_DIR/ikram-paktool"
    local sh
    sh="$(command -v bash 2>/dev/null || true)"
    [ -n "$sh" ] || sh="/bin/sh"
    {
        printf '#!%s\n' "$sh"
        printf '# Ikram Tool launcher (generated by install.sh %s)\n' "$SCRIPT_VERSION"
        printf 'TARGET="%s"\n' "$TARGET"
        printf 'PY="%s"\n' "$PY"
        # The core is 3.14 bytecode, so the fallback chain must test the
        # version, not just existence: a 3.15 interpreter on PATH used to be
        # accepted here and the app then died with "bad magic number".
        printf 'py_ok() { "$1" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,14) else 1)" >/dev/null 2>&1; }\n'
        printf 'py_ok "$PY" || PY=""\n'
        printf '[ -n "$PY" ] || for c in "$HOME/.ikram/py314/bin/python3.14" "$HOME/.ikram/py314/bin/python3" python3.14 python3 python; do\n'
        printf '  q="$c"; [ -x "$q" ] || q="$(command -v "$c" 2>/dev/null)"; [ -n "$q" ] || continue\n'
        printf '  py_ok "$q" && { PY="$q"; break; }\n'
        printf 'done\n'
        printf 'box_err() { printf "  +--------------------------------------------------------------+\\n"; printf "  | %%s - LAUNCHER ERROR                              |\\n" "$1"; printf "  +--------------------------------------------------------------+\\n"; printf "  | Main  : CPython 3.14                                         |\\n"; printf "  | Fix   : bash $TARGET/.engine/install.sh --force              |\\n"; printf "  +--------------------------------------------------------------+\\n"; }\n'
        printf '[ -n "$PY" ] || { box_err "IkramTool" >&2; exit 1; }\n'
        printf '[ -f "$TARGET/.engine/ikram_patch.py" ] || { box_err "IkramTool" >&2; exit 1; }\n'
        printf 'cd "$TARGET/.engine" || exit 1\n'
        printf 'export PYTHONDONTWRITEBYTECODE=1\n'
        printf 'exec "$PY" -X utf8 "$TARGET/.engine/ikram_patch.py" "$@"\n'
    } > "$launcher" || die "cannot write launcher: $launcher"
    chmod +x "$launcher" || warn "could not chmod $launcher"
    {
        printf '#!%s\n' "$sh"
        printf '# Ikram PakTool launcher (generated by install.sh %s)\n' "$SCRIPT_VERSION"
        printf 'TARGET="%s"\n' "$TARGET"
        printf 'PY="%s"\n' "$PY"
        printf 'py_ok() { "$1" -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,14) else 1)" >/dev/null 2>&1; }\n'
        printf 'py_ok "$PY" || PY=""\n'
        printf '[ -n "$PY" ] || for c in "$HOME/.ikram/py314/bin/python3.14" "$HOME/.ikram/py314/bin/python3" python3.14 python3 python; do\n'
        printf '  q="$c"; [ -x "$q" ] || q="$(command -v "$c" 2>/dev/null)"; [ -n "$q" ] || continue\n'
        printf '  py_ok "$q" && { PY="$q"; break; }\n'
        printf 'done\n'
        printf 'box_err() { printf "  +--------------------------------------------------------------+\\n"; printf "  | %%s - LAUNCHER ERROR                              |\\n" "$1"; printf "  +--------------------------------------------------------------+\\n"; printf "  | Main  : CPython 3.14                                         |\\n"; printf "  | Fix   : bash $TARGET/.engine/install.sh --force              |\\n"; printf "  +--------------------------------------------------------------+\\n"; }\n'
        printf '[ -n "$PY" ] || { box_err "Ikram PakTool" >&2; exit 1; }\n'
        printf '[ -f "$TARGET/.engine/PakTool.py" ] || { box_err "Ikram PakTool" >&2; exit 1; }\n'
        printf 'cd "$TARGET/.engine" || exit 1\n'
        printf 'export PYTHONDONTWRITEBYTECODE=1\n'
        printf 'exec "$PY" -X utf8 "$TARGET/.engine/PakTool.py" "$@"\n'
    } > "$paktool_launcher" || die "cannot write launcher: $paktool_launcher"
    chmod +x "$paktool_launcher" || true
    ok "launcher  : $launcher"
    ok "paktool   : $paktool_launcher"
    case ":$PATH:" in
        *":$BIN_DIR:"*) : ;;
        *) warn "$BIN_DIR is not on PATH - add: export PATH=\"$BIN_DIR:\$PATH\"" ;;
    esac
}

# ------------------------------------------------------------------- main ---
main() {
    parse_args "$@"     # --no-anim must be known before the banner is printed
    banner
    step "1/10" "platform"
    detect_platform

    # When install.sh is run from inside the extracted tree, SRC is the engine
    # dir itself (SRC == ENGINE). In that layout the runtime is already in
    # place, so skip the "already installed" early-return (which would leave
    # launchers unbuilt) and skip the --force wipe (which would delete this
    # very script and its source). Both only apply to a separate installer
    # bundle living outside $TARGET.
    if [ -f "$ENGINE/ikram.pyc" ] && [ "$FORCE" -eq 0 ] \
       && [ "$SRC" != "$TARGET" ] && [ "$SRC" != "$ENGINE" ]; then
        ok "already installed at $TARGET"
        info "use --force to reinstall, or run: ikram"
        return 0
    fi
    if [ -d "$TARGET" ] && [ "$FORCE" -eq 1 ] \
       && [ "$SRC" != "$TARGET" ] && [ "$SRC" != "$ENGINE" ]; then
        _spin "clean reinstall (wipe $TARGET)" rm -rf "$TARGET" || die "could not wipe $TARGET"
    fi

    step "2/10" "python $NEED_MAJOR.$NEED_MINOR"
    ensure_python
    if [ "$BUILD_STEP_DONE" -eq 0 ]; then
        step "3/10" "CPython $NEED_MAJOR.$NEED_MINOR build"
        warn "skipped - using $PY"
    fi
    stage_files
    validate_key_file
    fix_perms
    host_tools
    install_deps
    run_preflight
    setup_launcher

    printf '\n'
    hr
    printf '  %s%s installation complete %s\n' "${C_GR}${C_B}" "" "${C_RESET}"
    hr
    info "location : $TARGET  (only DROP/ and RESULT/ in root)"
    info "runtime  : $TARGET/.engine  (all tool files)"
    info "python   : $PY  ($(py_version_of "$PY"))"
    info "launcher : $BIN_DIR/ikram"
    info "paktool  : $BIN_DIR/ikram-paktool  (or: python3 $TARGET/.engine/PakTool.py)"
    printf '\n  %srun UI:%s  %sikram%s   %sPakTool:%s  %sikram-paktool --help%s\n\n' \
        "${C_DIM}" "${C_RESET}" "${C_CY}${C_B}" "${C_RESET}" "${C_DIM}" "${C_RESET}" "${C_CY}${C_B}" "${C_RESET}"
}

main "$@"
