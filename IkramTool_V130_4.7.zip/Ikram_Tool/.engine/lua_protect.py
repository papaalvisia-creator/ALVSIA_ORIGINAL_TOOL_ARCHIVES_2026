"""Windows-safe shim over the shipped ``lua_protect.pyc``.

The compiled ``protect_compile`` path died on every Windows .lua Compile with
``PermissionError: [WinError 32]``. Root cause is in its ``_compile_one`` /
``_compile_one_named`` helpers:

    fd, path = tempfile.mkstemp(suffix=".lua")
    tmp = Path(path)            # fd discarded, never closed
    ...
    tmp.unlink(missing_ok=True) # Windows: file still held by fd -> WinError 32

On POSIX an open descriptor does not block unlink, which is why the same code
worked on Android/Termux. This shim loads the original bytecode under a private
module name, replaces ONLY those two helpers with versions that close the
descriptor, and re-exports the rest of the namespace unchanged. All encryption,
BGMI conversion, profile reading and message strings stay in the shipped code.

``.py`` is found before ``.pyc`` by Python's FileFinder, so importing
``lua_protect`` resolves here without touching the original payload.
"""

import importlib.util
import os
import sys
import tempfile
from pathlib import Path

import ikram_logger

_HERE = Path(__file__).resolve().parent
_PYC = _HERE / "lua_protect.pyc"
_PRIVATE_NAME = "_ikram_lua_protect_pyc"

_spec = importlib.util.spec_from_file_location(_PRIVATE_NAME, str(_PYC))
_core = importlib.util.module_from_spec(_spec)
sys.modules[_PRIVATE_NAME] = _core
_spec.loader.exec_module(_core)


def _mkstemp_closed(suffix):
    """mkstemp path with the descriptor closed — unlink works on Windows."""
    fd, name = tempfile.mkstemp(suffix=suffix)
    try:
        os.close(fd)
    except OSError as _ikram_exc:
        ikram_logger.log_exc("lua_protect._mkstemp_closed", _ikram_exc)
    return Path(name)


def _compile_one(text, version):
    """Original contract: bytes on success, None on compiler error."""
    import univ

    tmp = _mkstemp_closed(".lua")
    out_tmp = _mkstemp_closed(".luc")
    try:
        tmp.write_text(text, encoding="utf-8")
        if version == "jit":
            err = univ._compile_luajit(tmp, out_tmp)
        else:
            err = univ.compile_lua(tmp, out_tmp, version=version, strip=False)
        if err:
            return None
        return out_tmp.read_bytes()
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_protect._compile_one", _ikram_exc)
        return None
    finally:
        tmp.unlink(missing_ok=True)
        out_tmp.unlink(missing_ok=True)


def _compile_one_named(text, version, chunkname):
    """Same as _compile_one but keeps the original chunk name."""
    import univ

    tmp = _mkstemp_closed(".lua")
    out_tmp = _mkstemp_closed(".luc")
    try:
        tmp.write_text(text, encoding="utf-8")
        err = univ._compile_lua_named(tmp, out_tmp, version, chunkname)
        if err:
            return None
        return out_tmp.read_bytes()
    except Exception as _ikram_exc:
        ikram_logger.log_exc("lua_protect._compile_one_named", _ikram_exc)
        return None
    finally:
        tmp.unlink(missing_ok=True)
        out_tmp.unlink(missing_ok=True)


# Patch the namespace the compiled functions actually look up.
_core._compile_one = _compile_one
_core._compile_one_named = _compile_one_named

# Re-export the entire shipped API, then let the two replacements win.
for _name in dir(_core):
    if not _name.startswith("__"):
        globals()[_name] = getattr(_core, _name)
globals()["_compile_one"] = _compile_one
globals()["_compile_one_named"] = _compile_one_named

_core_protect_compile = getattr(_core, "protect_compile")


def _unique_path(path):
    """Same `(1)` rule the menu layer uses for decompile and pak outputs."""
    if not path.exists():
        return path
    i = 1
    while True:
        cand = path.with_name("{} ({}).{}".format(path.stem, i, path.suffix.lstrip(".")))
        if not cand.exists():
            return cand
        i += 1


def protect_compile(src, out_root, version=None):
    """Keep the first compiled artifact when the same file is compiled twice.

    The bytecode writes `<stem> [compiled]<suffix>` directly. Moving an older
    output aside first keeps the shipped writer untouched and gives it a free
    target; if the writer fails, the original output is restored in place.
    """
    intended = Path(out_root) / "lua" / (
        Path(src).stem + " [compiled]" + Path(src).suffix)
    saved = None
    if intended.exists():
        saved = _unique_path(intended)
        intended.replace(saved)

    def _restore_saved():
        if saved is None or not saved.exists():
            return
        try:
            if intended.exists():
                intended.unlink()
        finally:
            if not intended.exists():
                saved.replace(intended)

    try:
        return _core_protect_compile(src, out_root, version)
    except OSError as exc:
        _restore_saved()
        detail = getattr(exc, "strerror", "") or str(exc)
        return False, "Output name is too long for this filesystem: {}".format(detail)
    except Exception:
        _restore_saved()
        raise


globals()["protect_compile"] = protect_compile

__all__ = [n for n in dir(_core) if not n.startswith("__")]
