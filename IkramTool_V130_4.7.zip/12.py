import os
import re
import zipfile
import json

from androguard.core.apk import APK

print("""
====================================
       MASTER APK SCANNER
====================================
[1] Scan APK URLs
[2] Extract SO Libraries
[3] Save Scan Report
[4] Exit
====================================
""")

apk_path = input("Enter APK path: ").strip()

if not os.path.isfile(apk_path):
    print("APK file not found!")
    exit()

urls = set()
libraries = []

try:
    apk = APK(apk_path)

    print("\n[+] Scanning APK...")

    with zipfile.ZipFile(apk_path, "r") as z:
        for name in z.namelist():

            if name.endswith(".so"):
                libraries.append(name)

            if name.endswith((".dex", ".xml", ".json",
                              ".txt", ".properties")):

                try:
                    data = z.read(name).decode(
                        "utf-8", errors="ignore"
                    )

                    found = re.findall(
                        r'https?://[^\s"\'<>]+',
                        data
                    )

                    for url in found:
                        urls.add(url.rstrip(".,;"))

                except Exception:
                    pass

    print("\n========== APK INFORMATION ==========")
    print("Package:", apk.get_package())
    print("App Name:", apk.get_app_name())
    print("Version:", apk.get_androidversion_name())

    print("\n========== FOUND URLS ==========")

    for url in sorted(urls):
        print("[URL]", url)

    print("\n========== SO LIBRARIES ==========")

    for lib in libraries:
        print("[LIB]", lib)

    print("\n========== SUMMARY ==========")
    print("Total URLs:", len(urls))
    print("Total Libraries:", len(libraries))

    report = {
        "package": apk.get_package(),
        "urls": sorted(urls),
        "libraries": libraries
    }

    with open("apk_report.json", "w") as f:
        json.dump(report, f, indent=4)

    with open("apk_urls.txt", "w") as f:
        f.write("\n".join(sorted(urls)))

    print("\n[+] Report saved!")
    print("[+] apk_report.json")
    print("[+] apk_urls.txt")

except Exception as e:
    print("\n[ERROR]", str(e))