# LUA/PAK DEWA PRO TOOL v3.1

Suite terpadu **satu-file** (`tool.py`) untuk mengelola file **PAK** dan **LUA**:
unpack, repack, rebuild, injek, proteksi APK, decompile penuh, dan protek lua.
Plus **engine game tertanam**: pak PUBG/ShadowTracker UE4-style v9-v14
(ZUC footer, index AES-256-CBC, SM4 Tencent-custom/SIMPLE1/SIMPLE2/DYN_SM4/
SM4_NEW, zlib/zstd/zstd-dict) dan **bytecode game termodifikasi**
(string XOR-32B + opcode rotate-17 -> vanilla 5.3 -> unluac).

```
  PAK  : UNPACK / REPACK / REBUILD / INJEK / PROTEKSI APK
  LUA  : DECOMPILE / INJEK / PROTEK
  BATCH: semua pak dalam folder -> folder hasil per-pak
```

## Persyaratan

| Komponen | Wajib? | Fungsi |
|---|---|---|
| Python 3.7+ | Wajib | menjalankan tool |
| `pip install lupa` | Disarankan | verifikasi sintaks + validasi runtime Lua NYATA (5.1-5.5/LuaJIT) di dalam Python |
| `pip install luaparser` | Opsional | verifikasi sintaks tambahan |
| `luac` / `lua` (binary) | Opsional | verifikasi sintaks + menjalankan hasil |
| `java` + `plugins/unluac.jar` | Opsional | **decompile bytecode Lua 5.x + bytecode game -> source penuh** (sudah disertakan di folder plugins) |
| `pip install pycryptodome gmalg zstandard` | Opsional | mengaktifkan engine pak game v14 (SM4/AES/ZUC/zstd) |
| `luadec` | Opsional | alternatif decompiler bytecode 5.1 |

Tool tetap berjalan tanpa backend opsional; fitur yang butuh backend akan
dilaporkan jujur sebagai "dilewati" beserta cara memasangnya.

## Menjalankan

```bash
python tool.py             # menu utama
python tool.py --selftest  # uji fungsi otomatis (fixture internal)
```

## Struktur menu

```
1. PAK   - UNPACK / REPACK / REBUILD / INJEK LUA / PROTEKSI APK
           / INFO-DETEKSI / CARVE (format tak dikenal)
2. LUA   - DECOMPILE 1 file / DECOMPILE folder (nol dilewati)
           / PROTEK 1 file / PROTEK folder / INJEK
           / VERIFIKASI-VALIDASI / ANALISIS isi file
3. BATCH - proses SEMUA .pak/.apk/.zip di sebuah folder;
           tiap pak dapat folder sendiri:
           <nama>_hasil/UNPACK/  -> hasil unpack
           <nama>_hasil/LUA/     -> dump/decript/decompile per file lua
           <nama>_hasil/PROTEK/  -> versi terproteksi
           <nama>_hasil/REPORTS/ -> laporan per operasi
           + _MASTER_REPORT.json/txt di folder induk
4. UTILITAS - hash, hexdump+entropy, diff, cari teks, backup, restore, statistik
5. UJI FUNGSI - self-test fixture internal
6. PENGATURAN - backend decompiler + intensitas protek
```

## Alur DECOMPILE (7 fase, tiap file lua)

1. **DETEKSI** - klasifikasi: source / bytecode Lua 5.1-5.4 / LuaJIT /
   gzip / zlib / base64 / terenkripsi
2. **DUMP** - `*.dump.txt`: header bytecode, struktur chunk 5.1 (parser
   internal), seluruh strings + offset, konstanta, entropy
3. **DECRIPT** - buka lapisan berlapis otomatis (gzip > zlib > base64 >
   brute-force XOR 1-byte + kunci manual); file yang tampak teks tapi
   bukan lua valid juga dicurigai dan dicoba dibuka
4. **DECOMPILE** - bytecode: otomatis pakai unluac/luadec bila ada;
   bila tidak: disassembly (`luac -l`) atau skeleton bertanda
5. **REKONSTRUKSI** - hasil ditulis sebagai `.lua` + dump pendukung
6. **VERIFIKASI** - cek sintaks hasil (luac > lupa > luaparser > heuristik)
7. **VALIDASI** - rantai hash input->output tercatat di laporan

**Kejujuran decompile**: bytecode -> source penuh butuh backend decompiler.
Tanpa backend, tool memberi analisis mendalam + skeleton yang ditandai jelas
sebagai BUKAN source penuh. `plugins/unluac.jar` sudah disertakan agar
decompile penuh langsung berjalan.

### Batas yang diketahui (jujur)
1. **File patologis obfuskator**: beberapa bytecode mengandung dead-code +
   ekspresi nested puluhan ribu level yang membuat unluac gagal
   (IllegalStateException/StackOverflow) pada stack JVM berapa pun yang
   diuji (-Xss 64m/512m/1500m). Untuk file ini tool menyediakan
   **disassembly + tabel string terdekripsi** (pemulihan level-instruksi
   100%), bukan source bersih. Source bersih butuh decompiler kustom.
2. **Entri pak terenkripsi SM4 #53 / DYN_SM4**: kunci diambil dari binary
   engine game (.so/.exe) yang tidak tersedia di sandbox - entri tercatat
   di manifest beserta alasannya, bukan hilang diam-diam.

## Alur PROTEK (4 fase, ter-embed di dalam hasil)

```
INPUT -> PROTECT -> VERIFIKASI -> VALIDASI
```

- **PROTECT**: payload dibungkus lapis acak (B64 / XOR / REV / ADD).
  Intensitas 100 = 10 lapis; 200 = 20 lapis (maks). Rantai deskriptor,
  checksum blob (anti-tamper), checksum payload, dan decoder murni Lua
  di-EMBED di dalam berkas hasil.
- **VERIFIKASI di dalam**: berkas hasil memeriksa integritas blob dan
  payload sebelum menjalankan apa pun; bila dimodifikasi -> error jelas.
- **VALIDASI di dalam**: payload wajib termuat sebagai Lua; bila gagal ->
  error jelas, bukan crash diam.
- **Verifikasi oleh tool**: mirror-decoder Python memastikan hasil dekode
  identik byte-per-byte (sha256), plus cek sintaks wrapper.
- **Validasi runtime** (bila lupa terpasang): berkas dijalankan beneran di
  Lua. Sudah diuji LULUS di Lua 5.1, 5.2, 5.3, 5.4, 5.5, LuaJIT 2.0, 2.1.
- Decoder 100% standard library -> kompatibel interpreter game umum.

Catatan jujur: protek ini pengaburan + anti-tamper, BUKAN enkripsi
kriptografi; pengetahuan orang cukup bisa membukanya. Untuk kerahasiaan
diperlukan enkripsi di sisi loader game.

## Jaminan non-destruktif

- File asli TIDAK PERNAH ditulis-ulang; semua keluaran di jalur baru.
- Sebelum/sesudah tiap operasi file sumber di-hash; bukti "NON-DESTRUKTIF:
  hash tidak berubah" tercatat di laporan.
- Entri berbahaya (zip-slip) ditolak; entri terenkripsi dilaporkan, bukan
  hilang diam-diam; file non-lua pun tercatat di laporan batch.

## APK (PROTEKSI APK)

- Semua `.lua` di dalam APK diprotek; `.luac` dipertahankan (decompile dulu
  via menu LUA bila perlu); `assets/DEWA_MANIFEST.json` ditambahkan.
- APK modifikasi **wajib di-sign ulang** (`apksigner`/`jarsigner`) sebelum
  bisa dipasang - tool melaporkan ketersediaan alat sign.

## Roadmap pengembangan (v3.1+)

- Diff/patch antar-pak (bandingkan entri dua pak, terapkan patch)
- Parser chunk penuh Lua 5.2/5.3/5.4 + LuaJIT (saat ini 5.1 penuh)
- Protek lapis LZMA + mini-VM decoder Lua
- Integrasi zipalign + signing otomatis bila alat tersedia
- GUI panel lokal (browser) di atas mesin yang sama
- Multi-thread untuk batch pak raksasa; format pak game spesifik via plugin

## Etika

Gunakan hanya pada file milik Anda sendiri atau yang Anda punya izin untuk
menganalisis/modifikasi.
