--[[
  ================================================================
  PROTEK DEWA v3  -  berkas terproteksi otomatis
  ----------------------------------------------------------------
  fase ter-embed : INPUT > PROTECT > VERIFIKASI > VALIDASI
  intensitas     : 100 (faktor kekuatan)
  jumlah lapis   : 10
  sumber         : alpha.lua (150 B)
  dibuat         : 2026-11-22 17:14:31
  ----------------------------------------------------------------
  VERIFIKASI-1 : checksum blob (anti-tamper) sebelum dekode
  VERIFIKASI-2 : checksum payload hasil dekode
  VALIDASI     : payload wajib termuat sebagai Lua
  Murni Lua standard - kompatibel Lua 5.1 s/d 5.4 dan LuaJIT
  ================================================================
]]
local B64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local XB={}
local function xb(a,b)
  local k=a*256+b; local v=XB[k]
  if v==nil then
    local r,p,aa,bb=0,1,a,b
    for _=1,8 do
      if aa%2~=bb%2 then r=r+p end
      aa=(aa-aa%2)/2; bb=(bb-bb%2)/2; p=p*2
    end
    v=r; XB[k]=v
  end
  return v
end
local function b64d(data)
  local map={}
  for i=1,#B64 do map[B64:sub(i,i)]=i-1 end
  local out,buf,bits={},0,0
  for i=1,#data do
    local v=map[data:sub(i,i)]
    if v then
      buf=buf*64+v; bits=bits+6
      while bits>=8 do
        local shift=bits-8
        local byte=math.floor(buf/2^shift)
        out[#out+1]=string.char(byte%256)
        buf=buf%2^shift
        bits=shift
      end
    end
  end
  return table.concat(out)
end
local function xorb(s,key)
  local n=#key; local t={}
  for i=1,#s do t[i]=string.char(xb(s:byte(i),key:byte((i-1)%n+1))) end
  return table.concat(t)
end
local function subs(s,n)
  local t={}
  for i=1,#s do t[i]=string.char((s:byte(i)-n)%256) end
  return table.concat(t)
end
local function fnv(s)
  local h=2166136261
  for i=1,#s do
    local lo=h%256
    h=xb(lo,s:byte(i))+(h-lo)
    local h1=h%65536
    local h2=(h-h1)/65536
    h=((h2*16777619)%4294967296*65536+h1*16777619)%4294967296
  end
  return h
end
local BLOB='E+oI6dXqFM3NzdXf3wPJ1xXqCM3NAdES1+3u383NCAYYAhD4FRAUFM0V5uvNBBTVFe7N1RLr4c4U6+Lf1RTJ1hgDydLNEuoU1dXxzhPs5c0YEAjg1uryFtLv7ukT6gwDFerv3xjqFAAU7tTOzdUYzRXuydbf7ObrGAHq383XAAYS7AfSydbizc3rFOET7u3NFxEN4tLV8uHJ1Rjw0BTNyRLqCNbQ6+LNE9/lzt8DGAAXEAfX0RDx0hPr6u7QAAjXGAPRztHV8s3NzdTSE+3N4BXu1eDSEPHSFAPQzt/qGAgYyc3VFesQ/xME7c7NBBPNzhIL09EQB9LN1RTf1RAH1xPu4u3Q1tTSFOrx0hLf4usTzc34zQEN4dAEFN8T6+IRGAEY7BTVFBTN7ebpF9cQEhgTzd8T680U1tXN7RPsABAS3+b/GAHJ0tTN1d8T6xD2E9Xy9BTq8c4T6gjh3+oX0hLqCM0VAAgWzgQY4c3X5dYV7cnSzQDJ0tXVze7VyRgSGOry3xXq798V7tTSE+zm3xgV5u0YAAgW0QHh0hPqF84VEAjNE9bm6s4E1M7N1ub2zuoIzdLV8dLN69Hg1RTNzRPuzeDR1hDNze3i7dUQCOEYydTS1RHn384ED8nW6wDl'
local OPS='WE9SOjEyMHxYT1I6ODl8WE9SOjY2fEI2NHxCNjR8QUREOjE2OXxCNjR8QUREOjEzN3xCNjR8QUREOjE1OA=='
local FNV_PAYLOAD=1218235677
local FNV_BLOB=1566409404
-- [VERIFIKASI-1] integritas blob (anti-tamper)
if fnv(BLOB)~=FNV_BLOB then error('[PROTEK-VERIFIKASI] blob termodifikasi - integritas GAGAL',2) end
-- buka rantai lapis (urutan terbalik)
local data=b64d(BLOB)
local ops=b64d(OPS)
local list={}
for tok in ops:gmatch('[^|]+') do list[#list+1]=tok end
for i=#list,1,-1 do
  local name,arg=list[i]:match('^([A-Z0-9]+):?(%d*)$')
  if name=='B64' then data=b64d(data)
  elseif name=='XOR' then data=xorb(data,string.char(tonumber(arg)))
  elseif name=='REV' then data=data:reverse()
  elseif name=='ADD' then data=subs(data,tonumber(arg))
  else error('[PROTEK] lapis tidak dikenal: '..tostring(name),2) end
end
-- [VERIFIKASI-2] integritas payload hasil dekode
if fnv(data)~=FNV_PAYLOAD then error('[PROTEK-VERIFIKASI] payload rusak - integritas GAGAL',2) end
-- [VALIDASI] payload harus termuat sebagai Lua
local loadfn=loadstring or load
local fn=loadfn(data,'@PROTEK_PAYLOAD')
if type(fn)~='function' then error('[PROTEK-VALIDASI] payload tidak dapat dimuat - VALIDASI GAGAL',2) end
-- [JALANKAN]
return fn()
