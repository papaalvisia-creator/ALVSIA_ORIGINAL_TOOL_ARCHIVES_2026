-- beta demo (komentar & string)
local NAME = 'beta'
local function greet(who)
  -- sapaan sederhana
  return 'halo ' .. who .. ' dari ' .. NAME
end
print(greet('dunia'))
for i = 1, 3 do
  print('beta iterasi ' .. i)
end
