--[[
  ================================================================
  PROTEK DEWA v3  -  berkas terproteksi otomatis
  ----------------------------------------------------------------
  fase ter-embed : INPUT > PROTECT > VERIFIKASI > VALIDASI
  intensitas     : 100 (faktor kekuatan)
  jumlah lapis   : 10
  sumber         : gamma.lua (221 B)
  dibuat         : 2026-11-22 17:14:31
  ----------------------------------------------------------------
  VERIFIKASI-1 : checksum blob (anti-tamper) sebelum dekode
  VERIFIKASI-2 : checksum payload hasil dekode
  VALIDASI     : payload wajib termuat sebagai Lua
  Murni Lua standard - kompatibel Lua 5.1 s/d 5.4 dan LuaJIT
  ================================================================
]]
local B64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local XB={}
local function xb(a,b)
  local k=a*256+b; local v=XB[k]
  if v==nil then
    local r,p,aa,bb=0,1,a,b
    for _=1,8 do
      if aa%2~=bb%2 then r=r+p end
      aa=(aa-aa%2)/2; bb=(bb-bb%2)/2; p=p*2
    end
    v=r; XB[k]=v
  end
  return v
end
local function b64d(data)
  local map={}
  for i=1,#B64 do map[B64:sub(i,i)]=i-1 end
  local out,buf,bits={},0,0
  for i=1,#data do
    local v=map[data:sub(i,i)]
    if v then
      buf=buf*64+v; bits=bits+6
      while bits>=8 do
        local shift=bits-8
        local byte=math.floor(buf/2^shift)
        out[#out+1]=string.char(byte%256)
        buf=buf%2^shift
        bits=shift
      end
    end
  end
  return table.concat(out)
end
local function xorb(s,key)
  local n=#key; local t={}
  for i=1,#s do t[i]=string.char(xb(s:byte(i),key:byte((i-1)%n+1))) end
  return table.concat(t)
end
local function subs(s,n)
  local t={}
  for i=1,#s do t[i]=string.char((s:byte(i)-n)%256) end
  return table.concat(t)
end
local function fnv(s)
  local h=2166136261
  for i=1,#s do
    local lo=h%256
    h=xb(lo,s:byte(i))+(h-lo)
    local h1=h%65536
    local h2=(h-h1)/65536
    h=((h2*16777619)%4294967296*65536+h1*16777619)%4294967296
  end
  return h
end
local BLOB='7fjx/fQM+Or1Ctv96vTb5OfT/Qb3D9Tm+NP88/cP8eb39OTr+NQP6vv52/PnHPn89BrbBucbFgjn1RLz9QrcB/ro6A/lCvzk9w79/fgO8OTl1PHm9A/U5OXU8f31D9QJ7fjx/fQM+QwIENjY5xsO/eca5PP1D9Ty9Brb5OcbDv3n1Avr+OTb/er02+Tn1AsF9w4G5OfUDwf4D/Hm+/Tb8+342P33DgcH9A7x5vvk3P33DtgJ9w8a8+oLEvPnHPjq+ugH9OXU8eb0D9Tk59QP/PUP8fD6+e3l59QX8vfpCwXt9OXy+NPt8eTk3BTn1e3ZBREO8/rT2PD66RYP5Q7l/fUP1Pf75Nvl59TU8vjUD+b6DwwO5Rrc/PoO7efn09j39A7T8+oLEuA='
local OPS='QUREOjIxM3xSRVZ8WE9SOjl8WE9SOjI0OXxBREQ6MjA3fFhPUjo2M3xYT1I6MjI4fEI2NHxBREQ6MTkwfEFERDoyMjk='
local FNV_PAYLOAD=3303335814
local FNV_BLOB=1065545432
-- [VERIFIKASI-1] integritas blob (anti-tamper)
if fnv(BLOB)~=FNV_BLOB then error('[PROTEK-VERIFIKASI] blob termodifikasi - integritas GAGAL',2) end
-- buka rantai lapis (urutan terbalik)
local data=b64d(BLOB)
local ops=b64d(OPS)
local list={}
for tok in ops:gmatch('[^|]+') do list[#list+1]=tok end
for i=#list,1,-1 do
  local name,arg=list[i]:match('^([A-Z0-9]+):?(%d*)$')
  if name=='B64' then data=b64d(data)
  elseif name=='XOR' then data=xorb(data,string.char(tonumber(arg)))
  elseif name=='REV' then data=data:reverse()
  elseif name=='ADD' then data=subs(data,tonumber(arg))
  else error('[PROTEK] lapis tidak dikenal: '..tostring(name),2) end
end
-- [VERIFIKASI-2] integritas payload hasil dekode
if fnv(data)~=FNV_PAYLOAD then error('[PROTEK-VERIFIKASI] payload rusak - integritas GAGAL',2) end
-- [VALIDASI] payload harus termuat sebagai Lua
local loadfn=loadstring or load
local fn=loadfn(data,'@PROTEK_PAYLOAD')
if type(fn)~='function' then error('[PROTEK-VALIDASI] payload tidak dapat dimuat - VALIDASI GAGAL',2) end
-- [JALANKAN]
return fn()
