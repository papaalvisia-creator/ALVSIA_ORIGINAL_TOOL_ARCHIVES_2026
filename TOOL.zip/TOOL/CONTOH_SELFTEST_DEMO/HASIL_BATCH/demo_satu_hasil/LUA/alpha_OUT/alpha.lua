-- alpha demo
local M = {}
function M.hello(name)
  return 'halo dari alpha, ' .. tostring(name)
end
function M.add(a, b)
  return a + b
end
return M
