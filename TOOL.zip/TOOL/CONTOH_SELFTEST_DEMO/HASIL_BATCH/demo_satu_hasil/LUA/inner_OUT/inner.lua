-- inner demo
local x = 42
print('inner:', x)
