--[[
  ================================================================
  PROTEK DEWA v3  -  berkas terproteksi otomatis
  ----------------------------------------------------------------
  fase ter-embed : INPUT > PROTECT > VERIFIKASI > VALIDASI
  intensitas     : 100 (faktor kekuatan)
  jumlah lapis   : 10
  sumber         : beta.lua (221 B)
  dibuat         : 2026-11-22 17:14:31
  ----------------------------------------------------------------
  VERIFIKASI-1 : checksum blob (anti-tamper) sebelum dekode
  VERIFIKASI-2 : checksum payload hasil dekode
  VALIDASI     : payload wajib termuat sebagai Lua
  Murni Lua standard - kompatibel Lua 5.1 s/d 5.4 dan LuaJIT
  ================================================================
]]
local B64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local XB={}
local function xb(a,b)
  local k=a*256+b; local v=XB[k]
  if v==nil then
    local r,p,aa,bb=0,1,a,b
    for _=1,8 do
      if aa%2~=bb%2 then r=r+p end
      aa=(aa-aa%2)/2; bb=(bb-bb%2)/2; p=p*2
    end
    v=r; XB[k]=v
  end
  return v
end
local function b64d(data)
  local map={}
  for i=1,#B64 do map[B64:sub(i,i)]=i-1 end
  local out,buf,bits={},0,0
  for i=1,#data do
    local v=map[data:sub(i,i)]
    if v then
      buf=buf*64+v; bits=bits+6
      while bits>=8 do
        local shift=bits-8
        local byte=math.floor(buf/2^shift)
        out[#out+1]=string.char(byte%256)
        buf=buf%2^shift
        bits=shift
      end
    end
  end
  return table.concat(out)
end
local function xorb(s,key)
  local n=#key; local t={}
  for i=1,#s do t[i]=string.char(xb(s:byte(i),key:byte((i-1)%n+1))) end
  return table.concat(t)
end
local function subs(s,n)
  local t={}
  for i=1,#s do t[i]=string.char((s:byte(i)-n)%256) end
  return table.concat(t)
end
local function fnv(s)
  local h=2166136261
  for i=1,#s do
    local lo=h%256
    h=xb(lo,s:byte(i))+(h-lo)
    local h1=h%65536
    local h2=(h-h1)/65536
    h=((h2*16777619)%4294967296*65536+h1*16777619)%4294967296
  end
  return h
end
local BLOB='ZWtWYWFrVW9mVVY0S2s5WWNYSTNXbmx6V2k5NktWcDdlbTE5WDNGV0xsbDdWRloxZjNNbExITkdSamR4VzFkWmRGVmJWSFp6VTFsNEtTcFBlRm9xV0hSVlYxdHNjMDlGZENsME0zc3BMbkozVkU5MGVTaGZjbkZGUzFoMFJWSW9laTBsSzNsRktXUitLSGxNY1ZWNVdIUnpWak4yY3pkR2V5OTlUSGhYVzBaNmJIUjFmeWhTWkhvdlRpcC9LRkl6ZEM5YUwzQkZYaXhzUlZOVWUwVlhkM1lvVTA1NWJGcGtlQ2hUWG45RlUxcDdiSEZLZUZWU2Vub29TMU40VjF0YWQwVk9OMnh6VjFselMxdE1leWg0ZUh0R2JIbHdjeVY0UlhKVFdYQXZVblI3TFNVdmNuTjRaWEJHZURkeExqZFpkQzlUVFd4RWJVWi9MMG96Y1VRM1dYdHNlVVp5S0ZkYWZpNWJXSFJVSld0MkwwNTFlMFUzZm5vb1MxdHhiQzUvZGloVFdIaHpKU3h6UmtZM2NXMUtMWHN2V21aNFZWTlpleWt0Skh0c1cxTjdWVTl3ZXloNFpINHZhVmg3TDJoNWVpbHhXSEZGS2w5RmJWZGZjVlpLTEhZb1RpOS9WU1VzUkhONEszc3BMU3g3Y0RkMFJVVTNXSGt2ZVV4L1N6ZFRkMFoxVkhSVlUzSi9LQ2txZnk5NWYzWXZUblYwVlY0dGZpOVBXM0ZiZlg5N0tGSXFiRVZQUkg0b1QxbHhjamQxZTJ4cFJua3ZiVVp5UzE5ZWUzTjVYM1lwZFZSN0tIMWZlaTlmWFg5eFJpNTZLWGd2ZVNnbGVFVnlVMWx4TDJsVGV5bHNMM0p5YVZsRWNqZE5mMnd1ZEhRdlNpdHhWRGRZY24xTFdIRXBMbGwyYlhobWMwVlhYM292ZERORUwxSWxlMVp0ZUhRcFYwVjRiWGxVZjIxYmYzWW9VMWgwS1Y1bWRDbExVMFJMVjFoN2JYbFlmeTlzWm5zb1dpdDBWMXRkZDFad0xteEZUMFI1S1hWWWNVWmJjSFl2UzNoN1ZTcGFlbTFQVzN0RlUzZDdLV3d6YkM5dFhuZ29lVTVzTHlWbWUzQXVmMnhGVW5sL0trOWVjVlpiU250dGVWaHpSVTlhZVM5UFUzRmFLbmg3Vm5WS2NFUWxMR3hHTjFSNFJrdEVkaTlUVG14elgwUitLRk5aY1ZSNWVYc3BhRE56VkcxWWNrdGZYbnR6ZVY4PQ=='
local OPS='QjY0fEI2NHxSRVZ8QjY0fEFERDozOXxBREQ6MTc1fEFERDo4N3xCNjR8WE9SOjI4fEI2NA=='
local FNV_PAYLOAD=3303335814
local FNV_BLOB=3807437681
-- [VERIFIKASI-1] integritas blob (anti-tamper)
if fnv(BLOB)~=FNV_BLOB then error('[PROTEK-VERIFIKASI] blob termodifikasi - integritas GAGAL',2) end
-- buka rantai lapis (urutan terbalik)
local data=b64d(BLOB)
local ops=b64d(OPS)
local list={}
for tok in ops:gmatch('[^|]+') do list[#list+1]=tok end
for i=#list,1,-1 do
  local name,arg=list[i]:match('^([A-Z0-9]+):?(%d*)$')
  if name=='B64' then data=b64d(data)
  elseif name=='XOR' then data=xorb(data,string.char(tonumber(arg)))
  elseif name=='REV' then data=data:reverse()
  elseif name=='ADD' then data=subs(data,tonumber(arg))
  else error('[PROTEK] lapis tidak dikenal: '..tostring(name),2) end
end
-- [VERIFIKASI-2] integritas payload hasil dekode
if fnv(data)~=FNV_PAYLOAD then error('[PROTEK-VERIFIKASI] payload rusak - integritas GAGAL',2) end
-- [VALIDASI] payload harus termuat sebagai Lua
local loadfn=loadstring or load
local fn=loadfn(data,'@PROTEK_PAYLOAD')
if type(fn)~='function' then error('[PROTEK-VALIDASI] payload tidak dapat dimuat - VALIDASI GAGAL',2) end
-- [JALANKAN]
return fn()
