--[[
  ================================================================
  PROTEK DEWA v3  -  berkas terproteksi otomatis
  ----------------------------------------------------------------
  fase ter-embed : INPUT > PROTECT > VERIFIKASI > VALIDASI
  intensitas     : 100 (faktor kekuatan)
  jumlah lapis   : 10
  sumber         : inner.lua (46 B)
  dibuat         : 2026-11-22 17:14:31
  ----------------------------------------------------------------
  VERIFIKASI-1 : checksum blob (anti-tamper) sebelum dekode
  VERIFIKASI-2 : checksum payload hasil dekode
  VALIDASI     : payload wajib termuat sebagai Lua
  Murni Lua standard - kompatibel Lua 5.1 s/d 5.4 dan LuaJIT
  ================================================================
]]
local B64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
local XB={}
local function xb(a,b)
  local k=a*256+b; local v=XB[k]
  if v==nil then
    local r,p,aa,bb=0,1,a,b
    for _=1,8 do
      if aa%2~=bb%2 then r=r+p end
      aa=(aa-aa%2)/2; bb=(bb-bb%2)/2; p=p*2
    end
    v=r; XB[k]=v
  end
  return v
end
local function b64d(data)
  local map={}
  for i=1,#B64 do map[B64:sub(i,i)]=i-1 end
  local out,buf,bits={},0,0
  for i=1,#data do
    local v=map[data:sub(i,i)]
    if v then
      buf=buf*64+v; bits=bits+6
      while bits>=8 do
        local shift=bits-8
        local byte=math.floor(buf/2^shift)
        out[#out+1]=string.char(byte%256)
        buf=buf%2^shift
        bits=shift
      end
    end
  end
  return table.concat(out)
end
local function xorb(s,key)
  local n=#key; local t={}
  for i=1,#s do t[i]=string.char(xb(s:byte(i),key:byte((i-1)%n+1))) end
  return table.concat(t)
end
local function subs(s,n)
  local t={}
  for i=1,#s do t[i]=string.char((s:byte(i)-n)%256) end
  return table.concat(t)
end
local function fnv(s)
  local h=2166136261
  for i=1,#s do
    local lo=h%256
    h=xb(lo,s:byte(i))+(h-lo)
    local h1=h%65536
    local h2=(h-h1)/65536
    h=((h2*16777619)%4294967296*65536+h1*16777619)%4294967296
  end
  return h
end
local BLOB='Oz8cHkwxVxxAMzVjUEMsYTYbThxMGzkgREJfOThVQR1OM1YeTz89X0Q+XzI/HTFjPkIbGzcbOF05Ll9lQWU9XDwbOTVOQD0zOTNBYkEeMV9MG09FNh0fHURZMV84WS1lPUBfN04/PTc5Mk9lT0BjW04dMR06PCgo'
local OPS='QjY0fFhPUjoyOHxYT1I6MjA1fFhPUjoxODZ8WE9SOjE2MHxSRVZ8QjY0fFJFVnxCNjR8QUREOjIzNQ=='
local FNV_PAYLOAD=3716435544
local FNV_BLOB=1558157527
-- [VERIFIKASI-1] integritas blob (anti-tamper)
if fnv(BLOB)~=FNV_BLOB then error('[PROTEK-VERIFIKASI] blob termodifikasi - integritas GAGAL',2) end
-- buka rantai lapis (urutan terbalik)
local data=b64d(BLOB)
local ops=b64d(OPS)
local list={}
for tok in ops:gmatch('[^|]+') do list[#list+1]=tok end
for i=#list,1,-1 do
  local name,arg=list[i]:match('^([A-Z0-9]+):?(%d*)$')
  if name=='B64' then data=b64d(data)
  elseif name=='XOR' then data=xorb(data,string.char(tonumber(arg)))
  elseif name=='REV' then data=data:reverse()
  elseif name=='ADD' then data=subs(data,tonumber(arg))
  else error('[PROTEK] lapis tidak dikenal: '..tostring(name),2) end
end
-- [VERIFIKASI-2] integritas payload hasil dekode
if fnv(data)~=FNV_PAYLOAD then error('[PROTEK-VERIFIKASI] payload rusak - integritas GAGAL',2) end
-- [VALIDASI] payload harus termuat sebagai Lua
local loadfn=loadstring or load
local fn=loadfn(data,'@PROTEK_PAYLOAD')
if type(fn)~='function' then error('[PROTEK-VALIDASI] payload tidak dapat dimuat - VALIDASI GAGAL',2) end
-- [JALANKAN]
return fn()
