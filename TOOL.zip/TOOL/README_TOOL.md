# LUA_PAK DEWA PRO FINAL V2 — PAKET LENGKAP

Tanggal    : 2026-11-23
Tool       : tool.py **v1.2.0** (satu file Python, semua menu)
Cakupan    : 22 pak + 1 chunk lua 44.2 MB — 572 pipeline lua — nol lua terlewat

## Isi paket

```
├── README.md                        <- file ini
├── TOOL/
│   ├── tool.py                      <- TOOL UTAMA v1.2.0 (1 file Python)
│   ├── README_TOOL.md               <- panduan pakai tool
│   ├── arsip/TOOL_v2.0_dewa_eksperimen.py   <- varian eksperimen (parser v14 mandiri)
│   └── plugins/unluac.jar           <- mesin decompile (terpakai otomatis)
├── SRC_ASLI/                        <- SOURCE LUA MURNI hasil pemulihan (608 file)
│   ├── pengujian1/ ... pengujian15/  (struktur folder = isi asli pak)
│   ├── game_patch_4.6.0.21605/ ...   (5 pak loose)
│   ├── test/                        (test.pak; CharacterBase digzip 3.8 MB)
│   ├── _loose_zip/                  (03704831068.lua)
│   └── pendamping_44mb/             (disassembly penuh chunk 44 MB, gzip)
├── HASIL_PENGUJIAN_NYATA/           <- BUKTI pipeline lengkap per pak (batch lama)
│   ├── pengujian1_HASIL/ ... pengujian12_HASIL/, test_HASIL/
│   ├── BUKTI/  _LEDGER.json  _AUDIT_NOL_TERLEWAT.json  LAPORAN_PROYEK.md
├── HASIL_PENGUJIAN_NYATA_BARU/      <- BUKTI pipeline pak baru (tool v1.2.0)
│   ├── pengujian13_HASIL/ ... pengujian15_HASIL/
│   ├── game_patch_4.6.0.21605_HASIL/ ... game_patch_4.7.0.21760_HASIL/
│   ├── pendamping_HASIL/
│   └── _AUDIT_NOL_TERLEWAT.json (per batch), LAPORAN_PAK.md per pak
└── LAPORAN/
    └── (laporan verifikasi & validasi)
```

Laporan total: `HASIL_PENGUJIAN_NYATA/LAPORAN_PROYEK_TOTAL.md`
(atau `pak_lua_tool/HASIL_PENGUJIAN_NYATA/LAPORAN_PROYEK_TOTAL.md` pada workspace).

## Cara membaca hasil per lua

Setiap lua diproses 7 tahap di folder
`LUA/<path-asli>/<nama>.lua/`:

| File | Isi |
|---|---|
| `01_analisis_detect.json` | tipe (source_text/bytecode_lua), versi, ukuran |
| `02_dump/` | hexdump, meta, strings |
| `03_dekripsi/` | kandidat dekripsi (bila terenkripsi) |
| `04_decompile/` | disassembly penuh / source unluac |
| `05_rekonstruksi.lua` | **SOURCE AKHIR hasil pemulihan** |
| `06_verifikasi.json` | verifikasi parser (LOLOS/GAGAL) |
| `07_validasi.json` | validasi runtime lupa (LULUS/PERIKSA) |
| `pipeline.json` | ringkasan 7 tahap |

## Cara pakai tool.py v1.2.0

```bash
# menu interaktif
python3 TOOL/tool.py

# batch: semua pak di folder -> unpack + pipeline semua lua + audit
python3 TOOL/tool.py --batch-all --input <folder_pak> --output <folder_hasil>

# unpack satu pak (mendukung pubg_ue_pak ShadowTracker v9-v14)
python3 TOOL/tool.py --unpack <file.pak> --output <folder_hasil>

# pipeline 7 tahap untuk 1 lua atau 1 folder lua
python3 TOOL/tool.py --pipeline <file.lua|folder> --output <folder_hasil>

# protek lua (input -> protect -> verifikasi -> validasi; lupa runtime)
python3 TOOL/tool.py --protek <source.lua> --protek-out <output.lua>

# injek lua ke pak / scan folder / rebuild
python3 TOOL/tool.py --injek <file.pak> <file.lua>
python3 TOOL/tool.py --scan <folder>
python3 TOOL/tool.py --rebuild <folder_HASIL>
```

Dependensi opsional (untuk kemampuan penuh):
```
pip install lupa gmalg pycryptodome zstandard
```
- `lupa`          -> validasi runtime protek & pipeline
- `gmalg`         -> ZUC footer pak ShadowTracker
- `pycryptodome`  -> AES-256-CBC indeks terenkripsi
- `zstandard`     -> blok zstd / zstd-dict
- java + `plugins/unluac.jar` -> decompile bytecode Lua 5.x

## Catatan penting

- **Entri CSV/Config pak v14 (metode enkripsi 53)** butuh secret SM4_NEW ke-23
  yang tidak tersedia publik; bukan bagian lua, jadi tidak ada lua yang terlewat.
- **Pendamping 44 MB**: decompile penuh butuh RAM besar; disassembly penuh
  (gzip) tersedia di `SRC_ASLI/pendamping_44mb/`.
- Semua operasi NON-DESTRUKTIF: file asli tidak pernah ditimpa.
